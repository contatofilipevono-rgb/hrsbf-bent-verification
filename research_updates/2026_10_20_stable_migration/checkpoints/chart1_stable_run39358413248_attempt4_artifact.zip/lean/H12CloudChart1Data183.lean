import H12CloudChart1Data182

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def leafEnv46367 : List Nat := [2,4,8,10,32,11,8,256,10,46,293,42,268,32,0,263,43,0,46,1,260,33,10,2,299,268,1,11,293,42,43,0,299,33,256,32,4,263,32,11,1,260,0]

def active46367 : List Nat := [0,1,2,4,7]

def tree46367 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46367 : H12WitnessSearch.Good tree46367 := H12GlobalWitnessIndex.good

theorem leafIdentity46367 : H12AffineFastState.composeSystem env46367 rootObs = leafEnv46367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46367 rootObs == leafEnv46367) = true)

theorem terminalChecked46367 : H12PackedTerminal.terminalCheckFast leafEnv46367 active46367 tree46367 = true := by decide +kernel

def env46368 : List Nat := [2,4,8,16,32,17,8,256,17,53,293,48,268,33,0,263,48,0,53,1,260,33,16,2,268,17,293,49,49,0,304,33,256,32,33,16]

theorem envBound46368 : H12AffineFastState.Bounded env46368 := by
  intro p hp
  have h : env46368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46365_46368 : H12AffineEnvironment.transform 8 17 env46365 = env46368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46365 == env46368) = true)

theorem identity46368 : scanCanonicalize (H12AffineFastState.compose env46368 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound46368 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46369 : List Nat := [2,4,8,16,32,17,8,5,17,53,32,48,9,33,0,2,48,0,53,1,1,33,16,2,9,17,32,49,49,0,53,33,5,32,33,16]

theorem envBound46369 : H12AffineFastState.Bounded env46369 := by
  intro p hp
  have h : env46369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46368_46369 : H12AffineEnvironment.transform 7 5 env46368 = env46369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env46368 == env46369) = true)

def leafEnv46369 : List Nat := [2,4,8,16,32,17,8,5,17,53,32,48,9,33,0,2,48,0,53,1,1,33,16,2,53,9,1,17,32,49,49,0,53,33,5,32,4,2,33,16,1,1,0]

def active46369 : List Nat := [0,1,2,3,4]

def tree46369 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46369 : H12WitnessSearch.Good tree46369 := H12GlobalWitnessIndex.good

theorem leafIdentity46369 : H12AffineFastState.composeSystem env46369 rootObs = leafEnv46369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46369 rootObs == leafEnv46369) = true)

theorem terminalChecked46369 : H12PackedTerminal.terminalCheckFast leafEnv46369 active46369 tree46369 = true := by decide +kernel

def env46370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound46370 : H12AffineFastState.Bounded env46370 := by
  intro p hp
  have h : env46370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46284_46370 : H12AffineEnvironment.transform 18 1025 env46284 = env46370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env46284 == env46370) = true)

theorem identity46370 : scanCanonicalize (H12AffineFastState.compose env46370 (packedSelected [13] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound46370 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29630611,18973836,10507600,8724626,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound46371 : H12AffineFastState.Bounded env46371 := by
  intro p hp
  have h : env46371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46370_46371 : H12AffineEnvironment.transform 16 123026 env46370 = env46371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env46370 == env46371) = true)

def env46372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,8388608,10588556,8328,64,6664479,8393984,10507600,8724626,2102684,12645452,257,21792,46213,2175563]

theorem envBound46372 : H12AffineFastState.Bounded env46372 := by
  intro p hp
  have h : env46372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46371_46372 : H12AffineEnvironment.transform 23 10588556 env46371 = env46372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env46371 == env46372) = true)

def env46373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6664479,2098512,17664,2437314,2102684,6349852,257,21792,46213,2175563]

theorem envBound46373 : H12AffineFastState.Bounded env46373 := by
  intro p hp
  have h : env46373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46372_46373 : H12AffineEnvironment.transform 22 2101328 env46372 = env46373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env46372 == env46373) = true)

def env46374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2202015,2098512,17664,2437314,2102684,2411676,257,21792,46213,2175563]

theorem envBound46374 : H12AffineFastState.Bounded env46374 := by
  intro p hp
  have h : env46374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46373_46374 : H12AffineEnvironment.transform 21 272512 env46373 = env46374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46373 == env46374) = true)

theorem identity46374 : scanCanonicalize (H12AffineFastState.compose env46374 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound46374 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46375 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,4161,272512,17,98780,8328,64,100830,5393,17664,336003,1501,318685,257,21792,46213,74250]

theorem envBound46375 : H12AffineFastState.Bounded env46375 := by
  intro p hp
  have h : env46375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46374_46375 : H12AffineEnvironment.transform 20 4161 env46374 = env46375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46374 == env46375) = true)

theorem identity46375 : scanCanonicalize (H12AffineFastState.compose env46375 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46375 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env46376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,4161,272512,17,41431,8328,64,43477,5393,17664,262280,1501,318685,257,21792,46213,513]

theorem envBound46376 : H12AffineFastState.Bounded env46376 := by
  intro p hp
  have h : env46376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46375_46376 : H12AffineEnvironment.transform 15 8203 env46375 = env46376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46375 == env46376) = true)

def env46377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2202014,2098512,17664,2437314,2102684,2411677,257,21792,46213,2175563]

theorem envBound46377 : H12AffineFastState.Bounded env46377 := by
  intro p hp
  have h : env46377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46373_46377 : H12AffineEnvironment.transform 21 272513 env46373 = env46377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46373 == env46377) = true)

def env46378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,2097152,272393,2101328,98644,8192,64,2201878,2098512,17664,2437194,2102548,2411541,257,21792,46093,2175563]

theorem envBound46378 : H12AffineFastState.Bounded env46378 := by
  intro p hp
  have h : env46378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46377_46378 : H12AffineEnvironment.transform 6 8 env46377 = env46378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46377 == env46378) = true)

theorem identity46378 : scanCanonicalize (H12AffineFastState.compose env46378 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 36928) := by decide +kernel

theorem selectedBound46378 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env46379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,36928,272393,32784,98644,8192,64,67926,38160,17664,368650,34132,285781,257,21792,46093,107019]

theorem envBound46379 : H12AffineFastState.Bounded env46379 := by
  intro p hp
  have h : env46379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46378_46379 : H12AffineEnvironment.transform 20 36928 env46378 = env46379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 36928 env46378 == env46379) = true)

theorem identity46379 : scanCanonicalize (H12AffineFastState.compose env46379 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound46379 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env46380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,57676,262144,1025,32769,36928,272393,32784,32770,8192,64,2048,38160,17664,303452,34132,285781,257,21792,46093,41821]

theorem envBound46380 : H12AffineFastState.Bounded env46380 := by
  intro p hp
  have h : env46380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46379_46380 : H12AffineEnvironment.transform 15 342 env46379 = env46380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env46379 == env46380) = true)

theorem identity46380 : scanCanonicalize (H12AffineFastState.compose env46380 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound46380 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,57676,2421,1025,32769,36928,8572,32784,32770,8192,64,2048,38160,17664,43049,34132,21792,257,21792,46093,41821]

theorem envBound46381 : H12AffineFastState.Bounded env46381 := by
  intro p hp
  have h : env46381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46380_46381 : H12AffineEnvironment.transform 17 2421 env46380 = env46381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env46380 == env46381) = true)

theorem identity46381 : scanCanonicalize (H12AffineFastState.compose env46381 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46381 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env46382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,342,24908,2421,1025,1,4160,8572,16,2,8192,64,2048,5392,17664,10281,1364,21792,257,21792,13325,9053]

theorem envBound46382 : H12AffineFastState.Bounded env46382 := by
  intro p hp
  have h : env46382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46381_46382 : H12AffineEnvironment.transform 14 0 env46381 = env46382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46381 == env46382) = true)

theorem identity46382 : scanCanonicalize (H12AffineFastState.compose env46382 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound46382 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env46383 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,0,342,5173,2421,1025,1,4160,8572,16,2,8192,64,2048,5392,12409,10281,1364,8281,257,8281,13325,9053]

theorem envBound46383 : H12AffineFastState.Bounded env46383 := by
  intro p hp
  have h : env46383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46382_46383 : H12AffineEnvironment.transform 13 13689 env46382 = env46383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env46382 == env46383) = true)

theorem identity46383 : scanCanonicalize (H12AffineFastState.compose env46383 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound46383 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env46384 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,8192,8460,0,342,64,2421,1025,1,1077,8572,16,2,8192,64,2048,357,9228,10281,1364,8281,257,8281,8312,9053]

theorem envBound46384 : H12AffineFastState.Bounded env46384 := by
  intro p hp
  have h : env46384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46383_46384 : H12AffineEnvironment.transform 11 1141 env46383 = env46384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env46383 == env46384) = true)

theorem identity46384 : scanCanonicalize (H12AffineFastState.compose env46384 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound46384 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env46385 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,1337,1077,0,342,64,2421,1025,1,1077,1093,16,2,1337,64,2048,357,309,3344,1364,1376,257,1376,1345,1636]

theorem envBound46385 : H12AffineFastState.Bounded env46385 := by
  intro p hp
  have h : env46385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46384_46385 : H12AffineEnvironment.transform 12 1337 env46384 = env46385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env46384 == env46385) = true)

def env46386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,2097152,272392,2101328,98645,8193,64,2201879,2098512,17664,2437195,2102549,2411540,257,21792,46092,2175563]

theorem envBound46386 : H12AffineFastState.Bounded env46386 := by
  intro p hp
  have h : env46386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46377_46386 : H12AffineEnvironment.transform 6 9 env46377 = env46386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46377 == env46386) = true)

def env46387 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4160,272392,16,98645,8193,64,100695,5392,17664,335883,1365,318548,257,21792,46092,74251]

theorem envBound46387 : H12AffineFastState.Bounded env46387 := by
  intro p hp
  have h : env46387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46386_46387 : H12AffineEnvironment.transform 20 4160 env46386 = env46387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46386 == env46387) = true)

theorem identity46387 : scanCanonicalize (H12AffineFastState.compose env46387 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 130094) := by decide +kernel

theorem selectedBound46387 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env46388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,130094,1025,32769,4160,119846,16,98645,8193,64,100695,5392,17664,56357,1365,73850,257,21792,46092,74251]

theorem envBound46388 : H12AffineFastState.Bounded env46388 := by
  intro p hp
  have h : env46388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46387_46388 : H12AffineEnvironment.transform 17 130094 env46387 = env46388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130094 env46387 == env46388) = true)

theorem identity46388 : scanCanonicalize (H12AffineFastState.compose env46388 (packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound46388 : packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,65536,103446,100387,1025,32769,4160,106539,16,98645,8193,64,100695,5392,12557,43048,1365,73850,257,8493,46092,74251]

theorem envBound46389 : H12AffineFastState.Bounded env46389 := by
  intro p hp
  have h : env46389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46388_46389 : H12AffineEnvironment.transform 13 13325 env46388 = env46389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env46388 == env46389) = true)

theorem identity46389 : scanCanonicalize (H12AffineFastState.compose env46389 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46389 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env46390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,8202,46108,43049,1025,32769,4160,32801,16,41311,8193,64,43357,5392,12557,43048,1365,112,257,8493,46092,513]

theorem envBound46390 : H12AffineFastState.Bounded env46390 := by
  intro p hp
  have h : env46390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46389_46390 : H12AffineEnvironment.transform 15 8202 env46389 = env46390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46389 == env46390) = true)

theorem identity46390 : scanCanonicalize (H12AffineFastState.compose env46390 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46390 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8541,8202,5441,2420,1025,8540,4160,8572,16,2,8193,64,2048,5392,12557,2421,1365,112,257,8493,5457,513]

theorem envBound46391 : H12AffineFastState.Bounded env46391 := by
  intro p hp
  have h : env46391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46390_46391 : H12AffineEnvironment.transform 14 8541 env46390 = env46391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46390 == env46391) = true)

def env46392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,272392,17,98645,8193,64,100694,5393,17664,335882,1364,318549,257,21792,46092,74250]

theorem envBound46392 : H12AffineFastState.Bounded env46392 := by
  intro p hp
  have h : env46392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46386_46392 : H12AffineEnvironment.transform 20 4161 env46386 = env46392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46386 == env46392) = true)

theorem identity46392 : scanCanonicalize (H12AffineFastState.compose env46392 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46392 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4161,33,17,98645,8193,64,100694,5393,17664,67619,1364,62588,257,21792,46092,74250]

theorem envBound46393 : H12AffineFastState.Bounded env46393 := by
  intro p hp
  have h : env46393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46392_46393 : H12AffineEnvironment.transform 17 10281 env46392 = env46393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46392 == env46393) = true)

theorem identity46393 : scanCanonicalize (H12AffineFastState.compose env46393 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound46393 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env46394 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,10281,1025,0,4161,33,17,65876,8193,64,67927,5393,17664,67619,1364,29821,257,21792,13325,74250]

theorem envBound46394 : H12AffineFastState.Bounded env46394 := by
  intro p hp
  have h : env46394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46393_46394 : H12AffineEnvironment.transform 14 1 env46393 = env46394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env46393 == env46394) = true)

theorem identity46394 : scanCanonicalize (H12AffineFastState.compose env46394 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46394 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46395 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8203,16401,10281,1025,0,4161,33,17,8543,8193,64,10588,5393,17664,10280,1364,29821,257,21792,13325,513]

theorem envBound46395 : H12AffineFastState.Bounded env46395 := by
  intro p hp
  have h : env46395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46394_46395 : H12AffineEnvironment.transform 15 8203 env46394 = env46395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46394 == env46395) = true)

theorem identity46395 : scanCanonicalize (H12AffineFastState.compose env46395 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46395 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env46396 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,1,342,16401,2420,1025,0,4161,33,17,2,348,64,2049,5393,17664,2421,1364,21792,257,21792,5456,513]

theorem envBound46396 : H12AffineFastState.Bounded env46396 := by
  intro p hp
  have h : env46396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46395_46396 : H12AffineEnvironment.transform 12 349 env46395 = env46396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46395 == env46396) = true)

theorem identity46396 : scanCanonicalize (H12AffineFastState.compose env46396 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound46396 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46397 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,4112,1,342,4097,2420,1025,0,4161,33,17,2,348,64,2049,5393,5392,2421,1364,1328,257,1328,5456,513]

theorem envBound46397 : H12AffineFastState.Bounded env46397 := by
  intro p hp
  have h : env46397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46396_46397 : H12AffineEnvironment.transform 13 4112 env46396 = env46397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env46396 == env46397) = true)

theorem identity46397 : scanCanonicalize (H12AffineFastState.compose env46397 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound46397 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46398 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8,4112,1,3,4097,2081,1025,0,4161,33,17,2,9,64,2049,5188,5189,2080,1025,1125,84,1125,5125,513]

theorem envBound46398 : H12AffineFastState.Bounded env46398 := by
  intro p hp
  have h : env46398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46397_46398 : H12AffineEnvironment.transform 7 85 env46397 = env46398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env46397 == env46398) = true)

theorem identity46398 : scanCanonicalize (H12AffineFastState.compose env46398 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46398 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env46399 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8,4112,1,3,4097,2081,1025,0,4112,33,17,2,9,17,2049,5141,5140,2080,1025,1076,5,1076,5125,513]

theorem envBound46399 : H12AffineFastState.Bounded env46399 := by
  intro p hp
  have h : env46399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46398_46399 : H12AffineEnvironment.transform 5 17 env46398 = env46399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46398 == env46399) = true)

theorem identity46399 : scanCanonicalize (H12AffineFastState.compose env46399 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound46399 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46400 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,48,8,32,1,3,49,2081,1025,0,32,33,17,2,9,17,2049,1061,1060,2080,1025,1076,5,1076,1077,513]

theorem envBound46400 : H12AffineFastState.Bounded env46400 := by
  intro p hp
  have h : env46400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46399_46400 : H12AffineEnvironment.transform 11 48 env46399 = env46400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46399 == env46400) = true)

theorem identity46400 : scanCanonicalize (H12AffineFastState.compose env46400 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1589) := by decide +kernel

theorem selectedBound46400 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env46401 : List Nat := [2,4,8,16,32,17,9,4,512,1024,1589,48,8,32,1,3,49,1556,1025,0,32,33,17,2,9,17,1588,1061,1060,1557,1025,1076,5,1076,1077,513]

theorem envBound46401 : H12AffineFastState.Bounded env46401 := by
  intro p hp
  have h : env46401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46400_46401 : H12AffineEnvironment.transform 10 1589 env46400 = env46401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1589 env46400 == env46401) = true)

theorem identity46401 : scanCanonicalize (H12AffineFastState.compose env46401 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound46401 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46402 : List Nat := [2,4,8,16,32,17,9,4,512,565,0,48,8,32,1,3,49,33,564,0,32,33,17,2,9,17,1,528,529,32,564,513,5,513,512,513]

theorem envBound46402 : H12AffineFastState.Bounded env46402 := by
  intro p hp
  have h : env46402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46401_46402 : H12AffineEnvironment.transform 9 565 env46401 = env46402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env46401 == env46402) = true)

theorem identity46402 : scanCanonicalize (H12AffineFastState.compose env46402 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46402 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46403 : List Nat := [2,4,8,16,16,17,9,4,512,517,0,0,8,16,1,3,1,17,516,0,16,17,17,2,9,17,1,528,529,16,516,513,5,513,512,513]

theorem envBound46403 : H12AffineFastState.Bounded env46403 := by
  intro p hp
  have h : env46403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46402_46403 : H12AffineEnvironment.transform 4 16 env46402 = env46403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46402 == env46403) = true)

theorem identity46403 : scanCanonicalize (H12AffineFastState.compose env46403 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound46403 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46404 : List Nat := [2,4,8,16,16,17,9,4,26,31,0,0,8,16,1,3,1,17,30,0,16,17,17,2,9,17,1,10,11,16,30,27,5,27,26,27]

theorem envBound46404 : H12AffineFastState.Bounded env46404 := by
  intro p hp
  have h : env46404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46403_46404 : H12AffineEnvironment.transform 8 26 env46403 = env46404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env46403 == env46404) = true)

theorem identity46404 : scanCanonicalize (H12AffineFastState.compose env46404 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46404 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env46405 : List Nat := [2,4,8,1,1,0,9,4,11,14,0,0,8,1,1,3,1,0,15,0,1,0,0,2,9,0,1,10,11,1,15,10,5,10,11,10]

theorem envBound46405 : H12AffineFastState.Bounded env46405 := by
  intro p hp
  have h : env46405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46404_46405 : H12AffineEnvironment.transform 3 1 env46404 = env46405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46404 == env46405) = true)

theorem identity46405 : scanCanonicalize (H12AffineFastState.compose env46405 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound46405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46406 : List Nat := [2,4,3,1,1,0,2,4,0,5,0,0,3,1,1,3,1,0,4,0,1,0,0,2,2,0,1,1,0,1,4,1,5,1,0,1]

theorem envBound46406 : H12AffineFastState.Bounded env46406 := by
  intro p hp
  have h : env46406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46405_46406 : H12AffineEnvironment.transform 2 3 env46405 = env46406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env46405 == env46406) = true)

def env46407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6664479,2098513,17665,2437315,2102684,6349853,257,21792,46213,2175563]

theorem envBound46407 : H12AffineFastState.Bounded env46407 := by
  intro p hp
  have h : env46407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46372_46407 : H12AffineEnvironment.transform 22 2101329 env46372 = env46407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env46372 == env46407) = true)

def env46408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2202015,2098513,17665,2437315,2102684,2411677,257,21792,46213,2175563]

theorem envBound46408 : H12AffineFastState.Bounded env46408 := by
  intro p hp
  have h : env46408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46407_46408 : H12AffineEnvironment.transform 21 272512 env46407 = env46408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46407 == env46408) = true)

theorem identity46408 : scanCanonicalize (H12AffineFastState.compose env46408 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound46408 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46409 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,58517,272512,62660,98781,8328,64,97546,57796,17665,382038,61705,272392,257,21792,46213,120542]

theorem envBound46409 : H12AffineFastState.Bounded env46409 := by
  intro p hp
  have h : env46409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46408_46409 : H12AffineEnvironment.transform 20 58517 env46408 = env46409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env46408 == env46409) = true)

def env46410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10280,1025,32769,58517,168,62660,98781,8328,64,97546,57796,17665,130174,61705,32,257,21792,46213,120542]

theorem envBound46410 : H12AffineFastState.Bounded env46410 := by
  intro p hp
  have h : env46410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46409_46410 : H12AffineEnvironment.transform 17 10280 env46409 = env46410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46409 == env46410) = true)

theorem identity46410 : scanCanonicalize (H12AffineFastState.compose env46410 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound46410 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env46411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,5393,10280,1025,32769,58517,168,62660,29790,8328,64,34953,57796,17665,2557,61705,32,257,21792,46213,9053]

theorem envBound46411 : H12AffineFastState.Bounded env46411 := by
  intro p hp
  have h : env46411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46410_46411 : H12AffineEnvironment.transform 15 62851 env46410 = env46411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env46410 == env46411) = true)

theorem identity46411 : scanCanonicalize (H12AffineFastState.compose env46411 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound46411 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,29963,5393,10280,1025,137,25629,168,29772,29790,8328,64,2049,24908,17665,2557,29057,32,257,21792,13325,9053]

theorem envBound46412 : H12AffineFastState.Bounded env46412 := by
  intro p hp
  have h : env46412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46411_46412 : H12AffineEnvironment.transform 14 136 env46411 = env46412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env46411 == env46412) = true)

theorem identity46412 : scanCanonicalize (H12AffineFastState.compose env46412 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46412 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46413 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,136,28698,4096,10280,272,137,24844,168,29021,29007,8328,64,2049,24908,16400,2557,29057,32,257,20529,12572,9053]

theorem envBound46413 : H12AffineFastState.Bounded env46413 := by
  intro p hp
  have h : env46413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46412_46413 : H12AffineEnvironment.transform 9 273 env46412 = env46413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46412 == env46413) = true)

theorem identity46413 : scanCanonicalize (H12AffineFastState.compose env46413 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46413 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env46414 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,349,16384,136,20807,4096,2421,272,137,16465,168,20480,20498,469,64,2049,16401,16400,2557,20700,32,257,20529,4161,512]

theorem envBound46414 : H12AffineFastState.Bounded env46414 := by
  intro p hp
  have h : env46414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46413_46414 : H12AffineEnvironment.transform 12 349 env46413 = env46414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46413 == env46414) = true)

theorem identity46414 : scanCanonicalize (H12AffineFastState.compose env46414 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4589) := by decide +kernel

theorem selectedBound46414 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46415 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,349,4589,136,170,4096,2421,272,137,4540,168,493,511,469,64,2049,4604,4605,2557,305,32,257,476,4161,512]

theorem envBound46415 : H12AffineFastState.Bounded env46415 := by
  intro p hp
  have h : env46415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46414_46415 : H12AffineEnvironment.transform 13 4589 env46414 = env46415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4589 env46414 == env46415) = true)

theorem identity46415 : scanCanonicalize (H12AffineFastState.compose env46415 (packedSelected [1,3,6,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 11) := by decide +kernel

theorem selectedBound46415 : packedSelected [1,3,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env46416 : List Nat := [2,4,8,16,32,64,128,11,512,26,2048,4096,86,4326,136,170,4096,2174,27,137,4279,168,230,244,222,64,2049,4343,4342,2294,58,32,10,215,4161,512]

theorem envBound46416 : H12AffineFastState.Bounded env46416 := by
  intro p hp
  have h : env46416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46415_46416 : H12AffineEnvironment.transform 7 11 env46415 = env46416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 11 env46415 == env46416) = true)

theorem identity46416 : scanCanonicalize (H12AffineFastState.compose env46416 (packedSelected [0,2,4,5,6,7,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 2170) := by decide +kernel

theorem selectedBound46416 : packedSelected [0,2,4,5,6,7,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env46417 : List Nat := [2,4,8,16,32,64,128,11,512,26,2048,2170,86,2204,136,170,2170,2174,27,137,2253,168,230,244,222,64,2049,2189,2188,2294,58,32,10,215,2107,512]

theorem envBound46417 : H12AffineFastState.Bounded env46417 := by
  intro p hp
  have h : env46417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46416_46417 : H12AffineEnvironment.transform 11 2170 env46416 = env46417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2170 env46416 == env46417) = true)

theorem identity46417 : scanCanonicalize (H12AffineFastState.compose env46417 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 118) := by decide +kernel

theorem selectedBound46417 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env46418 : List Nat := [2,4,8,16,32,64,118,11,512,26,2048,2170,86,2154,126,92,2170,2174,27,127,2107,94,16,2,40,64,2049,2171,2170,2048,58,32,10,33,2107,512]

theorem envBound46418 : H12AffineFastState.Bounded env46418 := by
  intro p hp
  have h : env46418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46417_46418 : H12AffineEnvironment.transform 6 118 env46417 = env46418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 118 env46417 == env46418) = true)

theorem identity46418 : scanCanonicalize (H12AffineFastState.compose env46418 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 84) := by decide +kernel

theorem selectedBound46418 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46419 : List Nat := [2,4,8,16,32,64,118,11,512,26,84,46,86,62,126,92,46,42,27,127,111,94,16,2,40,64,85,47,46,84,58,32,10,33,111,512]

theorem envBound46419 : H12AffineFastState.Bounded env46419 := by
  intro p hp
  have h : env46419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46418_46419 : H12AffineEnvironment.transform 10 84 env46418 = env46419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 84 env46418 == env46419) = true)

theorem identity46419 : scanCanonicalize (H12AffineFastState.compose env46419 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46419 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env46420 : List Nat := [2,4,8,16,1,64,87,11,512,26,84,15,86,31,95,92,15,11,27,94,78,94,16,2,9,64,85,14,15,84,27,1,10,0,78,512]

theorem envBound46420 : H12AffineFastState.Bounded env46420 := by
  intro p hp
  have h : env46420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46419_46420 : H12AffineEnvironment.transform 4 1 env46419 = env46420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46419 == env46420) = true)

theorem identity46420 : scanCanonicalize (H12AffineFastState.compose env46420 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 67) := by decide +kernel

theorem selectedBound46420 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46421 : List Nat := [2,4,8,16,1,64,87,11,67,26,84,15,86,31,95,92,15,11,27,94,78,94,16,2,9,64,85,14,15,84,27,1,10,0,78,67]

theorem envBound46421 : H12AffineFastState.Bounded env46421 := by
  intro p hp
  have h : env46421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46420_46421 : H12AffineEnvironment.transform 8 67 env46420 = env46421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 67 env46420 == env46421) = true)

def env46422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10281,1025,32769,58517,169,62660,98781,8328,64,97546,57796,17665,130175,61705,33,257,21792,46213,120542]

theorem envBound46422 : H12AffineFastState.Bounded env46422 := by
  intro p hp
  have h : env46422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46409_46422 : H12AffineEnvironment.transform 17 10281 env46409 = env46422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46409 == env46422) = true)

theorem identity46422 : scanCanonicalize (H12AffineFastState.compose env46422 (packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound46422 : packedSelected [1,5,8,11,12,15,17,18,19,23,24,26,32,38,41] rootPS < 2^1333 := by decide +kernel

def env46423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,13508,10281,1025,32769,58517,169,62660,21899,8328,64,43356,57796,17665,10281,61705,33,257,21792,46213,648]

theorem envBound46423 : H12AffineFastState.Bounded env46423 := by
  intro p hp
  have h : env46423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46422_46423 : H12AffineEnvironment.transform 15 54358 env46422 = env46423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env46422 == env46423) = true)

theorem identity46423 : scanCanonicalize (H12AffineFastState.compose env46423 (packedSelected [10,11,12,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound46423 : packedSelected [10,11,12,19,23] rootPS < 2^1333 := by decide +kernel

def env46424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,40970,13508,10281,1025,32769,37065,169,32920,8663,8328,64,43356,38296,12637,10281,34133,33,257,8572,46213,648]

theorem envBound46424 : H12AffineFastState.Bounded env46424 := by
  intro p hp
  have h : env46424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46423_46424 : H12AffineEnvironment.transform 13 13404 env46423 = env46424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env46423 == env46424) = true)

theorem identity46424 : scanCanonicalize (H12AffineFastState.compose env46424 (packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound46424 : packedSelected [0,1,2,6,7,8,10,12,16,17] rootPS < 2^1333 := by decide +kernel

def env46425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,32768,33110,5528,2421,1025,32769,37065,169,32920,139,468,64,34816,38296,4097,2421,34133,33,257,32,38361,648]

theorem envBound46425 : H12AffineFastState.Bounded env46425 := by
  intro p hp
  have h : env46425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46424_46425 : H12AffineEnvironment.transform 12 348 env46424 = env46425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env46424 == env46425) = true)

theorem identity46425 : scanCanonicalize (H12AffineFastState.compose env46425 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46425 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46426 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,33110,5392,2421,1025,32769,36929,33,32784,3,348,64,34816,38160,4097,2421,34133,33,257,32,38225,512]

theorem envBound46426 : H12AffineFastState.Bounded env46426 := by
  intro p hp
  have h : env46426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46425_46426 : H12AffineEnvironment.transform 6 8 env46425 = env46426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46425 == env46426) = true)

theorem identity46426 : scanCanonicalize (H12AffineFastState.compose env46426 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound46426 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46427 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,33,375,5392,2421,1025,32,4192,33,49,3,348,64,2081,5425,4097,2421,1396,33,257,32,5488,512]

theorem envBound46427 : H12AffineFastState.Bounded env46427 := by
  intro p hp
  have h : env46427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46426_46427 : H12AffineEnvironment.transform 14 33 env46426 = env46427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env46426 == env46427) = true)

theorem identity46427 : scanCanonicalize (H12AffineFastState.compose env46427 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46427 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env46428 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,5376,0,342,5392,2388,1025,1,4161,0,16,3,348,64,2048,5392,4097,2388,1365,0,257,1,5457,512]

theorem envBound46428 : H12AffineFastState.Bounded env46428 := by
  intro p hp
  have h : env46428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46427_46428 : H12AffineEnvironment.transform 4 1 env46427 = env46428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46427 == env46428) = true)

theorem identity46428 : scanCanonicalize (H12AffineFastState.compose env46428 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1355) := by decide +kernel

theorem selectedBound46428 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46429 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1355,4096,348,5376,0,342,5392,1055,1025,1,4161,0,16,3,348,64,1355,5392,4097,1055,1365,0,257,1,5457,512]

theorem envBound46429 : H12AffineFastState.Bounded env46429 := by
  intro p hp
  have h : env46429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46428_46429 : H12AffineEnvironment.transform 10 1355 env46428 = env46429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1355 env46428 == env46429) = true)

theorem identity46429 : scanCanonicalize (H12AffineFastState.compose env46429 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound46429 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46430 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1355,261,348,1029,0,342,1045,1055,1025,1,324,0,16,3,348,64,1355,1045,260,1055,1365,0,257,1,1108,512]

theorem envBound46430 : H12AffineFastState.Bounded env46430 := by
  intro p hp
  have h : env46430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46429_46430 : H12AffineEnvironment.transform 11 261 env46429 = env46430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env46429 == env46430) = true)

theorem identity46430 : scanCanonicalize (H12AffineFastState.compose env46430 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46430 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46431 : List Nat := [2,4,8,16,1,17,8,256,512,1024,1306,261,269,1029,0,263,1045,1055,1025,1,277,0,16,3,269,17,1306,1045,260,1055,1284,0,257,1,1029,512]

theorem envBound46431 : H12AffineFastState.Bounded env46431 := by
  intro p hp
  have h : env46431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46430_46431 : H12AffineEnvironment.transform 5 17 env46430 = env46431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46430 == env46431) = true)

theorem identity46431 : scanCanonicalize (H12AffineFastState.compose env46431 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound46431 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46432 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1054,1,9,1029,0,3,1045,1055,1025,1,17,0,16,3,9,17,1054,1045,0,1055,1024,0,5,1,1029,512]

theorem envBound46432 : H12AffineFastState.Bounded env46432 := by
  intro p hp
  have h : env46432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46431_46432 : H12AffineEnvironment.transform 7 4 env46431 = env46432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env46431 == env46432) = true)

theorem identity46432 : scanCanonicalize (H12AffineFastState.compose env46432 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound46432 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46433 : List Nat := [2,4,8,16,1,17,8,4,27,1024,1054,1,9,1029,0,3,1045,1055,1025,1,17,0,16,3,9,17,1054,1045,0,1055,1024,0,5,1,1029,27]

theorem envBound46433 : H12AffineFastState.Bounded env46433 := by
  intro p hp
  have h : env46433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46432_46433 : H12AffineEnvironment.transform 8 27 env46432 = env46433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env46432 == env46433) = true)

theorem identity46433 : scanCanonicalize (H12AffineFastState.compose env46433 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound46433 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46434 : List Nat := [2,4,8,2,1,3,8,4,9,1024,1036,1,9,1029,0,3,1031,1037,1025,1,3,0,2,3,9,3,1036,1031,0,1037,1024,0,5,1,1029,9]

theorem envBound46434 : H12AffineFastState.Bounded env46434 := by
  intro p hp
  have h : env46434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46433_46434 : H12AffineEnvironment.transform 3 2 env46433 = env46434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env46433 == env46434) = true)

theorem identity46434 : scanCanonicalize (H12AffineFastState.compose env46434 (packedSelected [0,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound46434 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env46435 : List Nat := [2,4,8,2,1,3,8,4,9,14,2,1,9,11,0,3,9,3,15,1,3,0,2,3,9,3,2,9,0,3,14,0,5,1,11,9]

theorem envBound46435 : H12AffineFastState.Bounded env46435 := by
  intro p hp
  have h : env46435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46434_46435 : H12AffineEnvironment.transform 9 14 env46434 = env46435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env46434 == env46435) = true)

def env46436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2202014,2098513,17665,2437315,2102684,2411676,257,21792,46213,2175563]

theorem envBound46436 : H12AffineFastState.Bounded env46436 := by
  intro p hp
  have h : env46436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46407_46436 : H12AffineEnvironment.transform 21 272513 env46407 = env46436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46407 == env46436) = true)

theorem identity46436 : scanCanonicalize (H12AffineFastState.compose env46436 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound46436 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70727,262144,1025,29908,2097152,272513,2101329,95496,8328,64,2190667,2098513,17665,2437315,2102684,2373705,257,21792,16464,2175563]

theorem envBound46437 : H12AffineFastState.Bounded env46437 := by
  intro p hp
  have h : env46437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46436_46437 : H12AffineEnvironment.transform 14 29909 env46436 = env46437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env46436 == env46437) = true)

def env46438 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70679,262144,1025,29828,2097152,272513,2101249,95496,8328,16,2190619,2098433,17665,2437267,2102684,2373657,257,21792,16384,2175515]

theorem envBound46438 : H12AffineFastState.Bounded env46438 := by
  intro p hp
  have h : env46438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46437_46438 : H12AffineEnvironment.transform 5 16 env46437 = env46438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46437 == env46438) = true)

theorem identity46438 : scanCanonicalize (H12AffineFastState.compose env46438 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound46438 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env46439 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70679,76079,1025,29828,2097152,65966,2101249,95496,8328,16,2190619,2098433,17665,2103740,2102684,2167094,257,21792,16384,2175515]

theorem envBound46439 : H12AffineFastState.Bounded env46439 := by
  intro p hp
  have h : env46439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46438_46439 : H12AffineEnvironment.transform 17 76079 env46438 = env46439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env46438 == env46439) = true)

theorem identity46439 : scanCanonicalize (H12AffineFastState.compose env46439 (packedSelected [1,3,10,24,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 12692) := by decide +kernel

theorem selectedBound46439 : packedSelected [1,3,10,24,28,31] rootPS < 2^1333 := by decide +kernel

def env46440 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,65536,70679,76079,1025,29828,12692,65966,8597,95496,8328,16,89231,13461,17665,10280,9224,73890,257,21792,16384,66447]

theorem envBound46440 : H12AffineFastState.Bounded env46440 := by
  intro p hp
  have h : env46440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46439_46440 : H12AffineEnvironment.transform 20 12692 env46439 = env46440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12692 env46439 == env46440) = true)

theorem identity46440 : scanCanonicalize (H12AffineFastState.compose env46440 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound46440 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env46441 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,16384,27797,65536,68615,76079,1025,27796,10628,65966,8597,93464,8328,16,83103,11397,17665,10280,9224,73890,257,19760,16384,66447]

theorem envBound46441 : H12AffineFastState.Bounded env46441 := by
  intro p hp
  have h : env46441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46440_46441 : H12AffineEnvironment.transform 11 2064 env46440 = env46441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env46440 == env46441) = true)

theorem identity46441 : scanCanonicalize (H12AffineFastState.compose env46441 (packedSelected [0,1,4,7,8,10,11,12,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 11326) := by decide +kernel

theorem selectedBound46441 : packedSelected [0,1,4,7,8,10,11,12,18,22] rootPS < 2^1333 := by decide +kernel

def env46442 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,16384,27797,11326,8249,1297,1025,27796,10628,11664,8597,16678,8328,16,26785,11397,17665,10280,9224,3228,257,19760,16384,12209]

theorem envBound46442 : H12AffineFastState.Bounded env46442 := by
  intro p hp
  have h : env46442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46441_46442 : H12AffineEnvironment.transform 15 11326 env46441 = env46442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 11326 env46441 == env46442) = true)

theorem identity46442 : scanCanonicalize (H12AffineFastState.compose env46442 (packedSelected [0,1,2,6,7,8,11,12,15,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 8581) := by decide +kernel

theorem selectedBound46442 : packedSelected [0,1,2,6,7,8,11,12,15,19,20,23] rootPS < 2^1333 := by decide +kernel

def env46443 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2064,8192,8581,3344,11326,8249,1297,1025,3345,10628,11664,8597,8355,8328,16,2340,11397,9348,10280,9224,3228,257,11445,8581,12209]

theorem envBound46443 : H12AffineFastState.Bounded env46443 := by
  intro p hp
  have h : env46443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46442_46443 : H12AffineEnvironment.transform 13 8581 env46442 = env46443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8581 env46442 == env46443) = true)

theorem identity46443 : scanCanonicalize (H12AffineFastState.compose env46443 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound46443 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env46444 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1296,1280,8192,8581,0,8494,8249,1297,1025,1,9364,8320,8597,8355,8328,16,1076,8597,9348,9528,9224,396,257,8613,8581,8865]

theorem envBound46444 : H12AffineFastState.Bounded env46444 := by
  intro p hp
  have h : env46444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46443_46444 : H12AffineEnvironment.transform 10 1296 env46443 = env46444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env46443 == env46444) = true)

theorem identity46444 : scanCanonicalize (H12AffineFastState.compose env46444 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound46444 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env46445 : List Nat := [2,4,8,16,32,16,128,256,512,408,136,152,8192,8581,0,8494,8249,137,409,1,8460,8320,8597,8355,8328,16,428,8597,8476,8352,8592,396,257,8613,8581,8865]

theorem envBound46445 : H12AffineFastState.Bounded env46445 := by
  intro p hp
  have h : env46445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46444_46445 : H12AffineEnvironment.transform 9 408 env46444 = env46445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env46444 == env46445) = true)

theorem identity46445 : scanCanonicalize (H12AffineFastState.compose env46445 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46445 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env46446 : List Nat := [2,4,8,16,32,16,128,256,512,408,136,152,41,428,0,263,16,137,409,1,293,169,444,138,161,16,428,444,309,137,441,396,257,396,428,648]

theorem envBound46446 : H12AffineFastState.Bounded env46446 := by
  intro p hp
  have h : env46446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46445_46446 : H12AffineEnvironment.transform 12 41 env46445 = env46446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46445 == env46446) = true)

theorem identity46446 : scanCanonicalize (H12AffineFastState.compose env46446 (packedSelected [0,1,3,4,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 386) := by decide +kernel

theorem selectedBound46446 : packedSelected [0,1,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env46447 : List Nat := [2,4,8,16,32,16,128,256,386,408,136,152,41,428,0,263,16,137,409,1,293,169,444,138,161,16,428,444,309,137,441,396,257,396,428,266]

theorem envBound46447 : H12AffineFastState.Bounded env46447 := by
  intro p hp
  have h : env46447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46446_46447 : H12AffineEnvironment.transform 8 386 env46446 = env46447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 386 env46446 == env46447) = true)

theorem identity46447 : scanCanonicalize (H12AffineFastState.compose env46447 (packedSelected [1,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46447 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env46448 : List Nat := [2,4,8,16,32,16,9,256,267,273,1,17,41,293,0,263,16,0,272,1,293,32,309,3,40,16,293,309,309,0,304,261,257,261,293,266]

theorem envBound46448 : H12AffineFastState.Bounded env46448 := by
  intro p hp
  have h : env46448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46447_46448 : H12AffineEnvironment.transform 6 9 env46447 = env46448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46447 == env46448) = true)

theorem identity46448 : scanCanonicalize (H12AffineFastState.compose env46448 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound46448 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46449 : List Nat := [2,4,8,16,5,16,9,256,267,273,1,17,12,256,0,263,16,0,272,1,256,5,272,3,13,16,256,272,272,0,277,261,257,261,256,266]

theorem envBound46449 : H12AffineFastState.Bounded env46449 := by
  intro p hp
  have h : env46449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46448_46449 : H12AffineEnvironment.transform 4 5 env46448 = env46449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env46448 == env46449) = true)

theorem identity46449 : scanCanonicalize (H12AffineFastState.compose env46449 (packedSelected [2,4] rootPS)) = affineNative (2^(7+1) ^^^ 0) := by decide +kernel

theorem selectedBound46449 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env46450 : List Nat := [2,4,8,16,5,16,9,0,11,17,1,17,12,0,0,7,16,0,16,1,0,5,16,3,13,16,0,16,16,0,21,5,1,5,0,10]

theorem envBound46450 : H12AffineFastState.Bounded env46450 := by
  intro p hp
  have h : env46450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46449_46450 : H12AffineEnvironment.transform 7 0 env46449 = env46450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 0 env46449 == env46450) = true)

theorem identity46450 : scanCanonicalize (H12AffineFastState.compose env46450 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound46450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46451 : List Nat := [2,4,3,16,5,16,2,0,0,17,1,17,7,0,0,7,16,0,16,1,0,5,16,3,6,16,0,16,16,0,21,5,1,5,0,1]

theorem envBound46451 : H12AffineFastState.Bounded env46451 := by
  intro p hp
  have h : env46451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46450_46451 : H12AffineEnvironment.transform 2 3 env46450 = env46451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env46450 == env46451) = true)

theorem identity46451 : scanCanonicalize (H12AffineFastState.compose env46451 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound46451 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46452 : List Nat := [2,4,3,3,5,3,2,0,0,2,1,2,7,0,0,7,3,0,3,1,0,5,3,3,6,3,0,3,3,0,6,5,1,5,0,1]

theorem envBound46452 : H12AffineFastState.Bounded env46452 := by
  intro p hp
  have h : env46452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46451_46452 : H12AffineEnvironment.transform 3 3 env46451 = env46452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env46451 == env46452) = true)

theorem identity46452 : scanCanonicalize (H12AffineFastState.compose env46452 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound46452 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46453 : List Nat := [2,1,3,3,0,3,2,0,0,2,1,2,2,0,0,2,3,0,3,1,0,0,3,3,3,3,0,3,3,0,3,0,1,0,0,1]

theorem envBound46453 : H12AffineFastState.Bounded env46453 := by
  intro p hp
  have h : env46453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46452_46453 : H12AffineEnvironment.transform 1 1 env46452 = env46453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env46452 == env46453) = true)

theorem identity46453 : scanCanonicalize (H12AffineFastState.compose env46453 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound46453 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46454 : List Nat := [1,1,0,0,0,0,1,0,0,1,1,1,1,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1]

theorem envBound46454 : H12AffineFastState.Bounded env46454 := by
  intro p hp
  have h : env46454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46453_46454 : H12AffineEnvironment.transform 0 1 env46453 = env46454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env46453 == env46454) = true)

def env46455 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,70678,262144,1025,29829,2097152,272513,2101248,95496,8328,17,2190618,2098432,17665,2437266,2102684,2373656,257,21792,16385,2175514]

theorem envBound46455 : H12AffineFastState.Bounded env46455 := by
  intro p hp
  have h : env46455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46437_46455 : H12AffineEnvironment.transform 5 17 env46437 = env46455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46437 == env46455) = true)

theorem identity46455 : scanCanonicalize (H12AffineFastState.compose env46455 (packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46455 : packedSelected [3,14,15,16,19,20,24,31,35,38] rootPS < 2^1333 := by decide +kernel

def env46456 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21896,65536,70678,262144,1025,21897,2097152,264589,2101248,87044,388,17,2182166,2098432,17665,2429342,2102684,2365716,257,21792,16385,2167574]

theorem envBound46456 : H12AffineFastState.Bounded env46456 := by
  intro p hp
  have h : env46456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46455_46456 : H12AffineEnvironment.transform 12 268 env46455 = env46456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46455 == env46456) = true)

theorem identity46456 : scanCanonicalize (H12AffineFastState.compose env46456 (packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 69911) := by decide +kernel

theorem selectedBound46456 : packedSelected [3,4,5,7,8,9,10,11,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env46457 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,16384,21896,65536,70678,262144,1025,21897,69911,264589,65815,87044,388,17,23809,70679,17665,262281,66699,329731,257,21792,16385,513]

theorem envBound46457 : H12AffineFastState.Bounded env46457 := by
  intro p hp
  have h : env46457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46456_46457 : H12AffineEnvironment.transform 20 69911 env46456 = env46457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 69911 env46456 == env46457) = true)

theorem identity46457 : scanCanonicalize (H12AffineFastState.compose env46457 (packedSelected [0,2,6,7,9,14,16,17,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound46457 : packedSelected [0,2,6,7,9,14,16,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env46458 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5512,0,65536,70678,262144,1025,1,69911,264589,65815,65932,388,17,2185,70679,4233,262281,66699,329731,257,168,5513,513]

theorem envBound46458 : H12AffineFastState.Bounded env46458 := by
  intro p hp
  have h : env46458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46457_46458 : H12AffineEnvironment.transform 13 5512 env46457 = env46458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env46457 == env46458) = true)

theorem identity46458 : scanCanonicalize (H12AffineFastState.compose env46458 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46458 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env46459 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,65536,70678,262144,1025,1,69911,264452,65815,65797,269,17,2048,70679,4096,262144,66562,329731,257,33,5376,513]

theorem envBound46459 : H12AffineFastState.Bounded env46459 := by
  intro p hp
  have h : env46459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46458_46459 : H12AffineEnvironment.transform 6 9 env46458 = env46459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46458 == env46459) = true)

theorem identity46459 : scanCanonicalize (H12AffineFastState.compose env46459 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound46459 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env46460 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,65536,70678,67619,1025,1,69911,65831,65815,65797,269,17,2048,70679,4096,67619,66562,32,257,33,5376,513]

theorem envBound46460 : H12AffineFastState.Bounded env46460 := by
  intro p hp
  have h : env46460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46459_46460 : H12AffineEnvironment.transform 17 67619 env46459 = env46460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env46459 == env46460) = true)

theorem identity46460 : scanCanonicalize (H12AffineFastState.compose env46460 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound46460 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46461 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1025,1,4113,33,17,3,269,17,2048,5393,4096,2341,1284,32,257,33,5376,513]

theorem envBound46461 : H12AffineFastState.Bounded env46461 := by
  intro p hp
  have h : env46461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46460_46461 : H12AffineEnvironment.transform 15 262 env46460 = env46461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env46460 == env46461) = true)

theorem identity46461 : scanCanonicalize (H12AffineFastState.compose env46461 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46461 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46462 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,0,34,5172,2049,1025,1,4113,33,17,3,41,17,2048,5173,4096,2049,1056,32,37,33,5156,513]

theorem envBound46462 : H12AffineFastState.Bounded env46462 := by
  intro p hp
  have h : env46462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46461_46462 : H12AffineEnvironment.transform 7 36 env46461 = env46462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46461 == env46462) = true)

theorem identity46462 : scanCanonicalize (H12AffineFastState.compose env46462 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound46462 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46463 : List Nat := [2,4,8,16,32,17,9,36,512,1024,522,4096,40,5157,0,34,5172,523,1025,1,4113,33,17,3,41,17,522,5173,4096,523,1056,32,37,33,5156,513]

theorem envBound46463 : H12AffineFastState.Bounded env46463 := by
  intro p hp
  have h : env46463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46462_46463 : H12AffineEnvironment.transform 10 522 env46462 = env46463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env46462 == env46463) = true)

theorem identity46463 : scanCanonicalize (H12AffineFastState.compose env46463 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46463 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46464 : List Nat := [2,4,8,16,1,17,9,5,512,1024,522,4096,9,5124,0,3,5141,523,1025,1,4113,0,17,3,8,17,522,5140,4096,523,1025,1,4,0,5125,513]

theorem envBound46464 : H12AffineFastState.Bounded env46464 := by
  intro p hp
  have h : env46464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46463_46464 : H12AffineEnvironment.transform 4 1 env46463 = env46464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46463 == env46464) = true)

def env46465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,8388608,10588557,8328,64,6664478,8393985,10507600,8724626,2102685,12645453,257,21793,46212,2175562]

theorem envBound46465 : H12AffineFastState.Bounded env46465 := by
  intro p hp
  have h : env46465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46371_46465 : H12AffineEnvironment.transform 23 10588557 env46371 = env46465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588557 env46371 == env46465) = true)

def env46466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6664478,2098513,17664,2437314,2102685,6349853,257,21793,46212,2175562]

theorem envBound46466 : H12AffineFastState.Bounded env46466 := by
  intro p hp
  have h : env46466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46465_46466 : H12AffineEnvironment.transform 22 2101328 env46465 = env46466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env46465 == env46466) = true)

def env46467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2202014,2098513,17664,2437314,2102685,2411677,257,21793,46212,2175562]

theorem envBound46467 : H12AffineFastState.Bounded env46467 := by
  intro p hp
  have h : env46467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46466_46467 : H12AffineEnvironment.transform 21 272512 env46466 = env46467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46466 == env46467) = true)

theorem identity46467 : scanCanonicalize (H12AffineFastState.compose env46467 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound46467 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,13388,262144,1025,32769,2097152,272512,2101328,21763,8328,64,2116928,2098513,17664,2417692,2102685,2411677,257,21793,46212,2156180]

theorem envBound46468 : H12AffineFastState.Bounded env46468 := by
  intro p hp
  have h : env46468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46467_46468 : H12AffineEnvironment.transform 15 54494 env46467 = env46468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env46467 == env46468) = true)

def env46469 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,13340,262144,1025,32769,2097152,272512,2101248,21763,8328,16,2116880,2098433,17664,2417692,2102685,2411677,257,21793,46212,2156180]

theorem envBound46469 : H12AffineFastState.Bounded env46469 := by
  intro p hp
  have h : env46469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46468_46469 : H12AffineEnvironment.transform 5 16 env46468 = env46469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46468 == env46469) = true)

theorem identity46469 : scanCanonicalize (H12AffineFastState.compose env46469 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 35245) := by decide +kernel

theorem selectedBound46469 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env46470 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,13340,35245,1025,32769,2097152,41261,2101248,21763,8328,16,2116880,2098433,17664,2125233,2102685,2114864,257,21793,46212,2156180]

theorem envBound46470 : H12AffineFastState.Bounded env46470 := by
  intro p hp
  have h : env46470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46469_46470 : H12AffineEnvironment.transform 17 35245 env46469 = env46470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35245 env46469 == env46470) = true)

theorem identity46470 : scanCanonicalize (H12AffineFastState.compose env46470 (packedSelected [1,4,5,7,8,9,10,16,19,20,24,26,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound46470 : packedSelected [1,4,5,7,8,9,10,16,19,20,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env46471 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,29962,13340,10281,1025,8581,2097152,169,2101248,21763,8328,16,2116880,2098433,17664,2125233,2102685,2114864,257,21793,5376,2115344]

theorem envBound46471 : H12AffineFastState.Bounded env46471 := by
  intro p hp
  have h : env46471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46470_46471 : H12AffineEnvironment.transform 14 8580 env46470 = env46471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env46470 == env46471) = true)

theorem identity46471 : scanCanonicalize (H12AffineFastState.compose env46471 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound46471 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46472 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,29962,13340,10281,1025,8581,17681,169,21777,21763,8328,16,2049,16400,17664,10400,20620,33,257,21793,5376,513]

theorem envBound46472 : H12AffineFastState.Bounded env46472 := by
  intro p hp
  have h : env46472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46471_46472 : H12AffineEnvironment.transform 20 17681 env46471 = env46472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env46471 == env46472) = true)

theorem identity46472 : scanCanonicalize (H12AffineFastState.compose env46472 (packedSelected [2,4,6,9,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46472 : packedSelected [2,4,6,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env46473 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8580,8203,13340,10281,1025,8581,4112,169,16,2,8328,16,2049,5393,4097,10400,1421,33,257,32,5376,513]

theorem envBound46473 : H12AffineFastState.Bounded env46473 := by
  intro p hp
  have h : env46473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46472_46473 : H12AffineEnvironment.transform 13 5377 env46472 = env46473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46472 == env46473) = true)

theorem identity46473 : scanCanonicalize (H12AffineFastState.compose env46473 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46473 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46474 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5377,136,263,5392,2341,1025,137,4112,169,16,2,388,16,2049,5393,4097,2476,1421,33,257,32,5376,513]

theorem envBound46474 : H12AffineFastState.Bounded env46474 := by
  intro p hp
  have h : env46474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46473_46474 : H12AffineEnvironment.transform 12 268 env46473 = env46474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46473 == env46474) = true)

theorem identity46474 : scanCanonicalize (H12AffineFastState.compose env46474 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound46474 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env46475 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2049,268,3328,136,263,3345,2341,1025,137,2065,169,16,2,388,16,2049,3344,2048,2476,1421,33,257,32,3329,513]

theorem envBound46475 : H12AffineFastState.Bounded env46475 := by
  intro p hp
  have h : env46475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46474_46475 : H12AffineEnvironment.transform 11 2049 env46474 = env46475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env46474 == env46475) = true)

theorem identity46475 : scanCanonicalize (H12AffineFastState.compose env46475 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound46475 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env46476 : List Nat := [2,4,8,16,32,16,128,256,512,1024,512,513,268,1792,136,263,1809,805,1025,137,529,169,16,2,388,16,513,1808,512,940,1421,33,257,32,1793,513]

theorem envBound46476 : H12AffineFastState.Bounded env46476 := by
  intro p hp
  have h : env46476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46475_46476 : H12AffineEnvironment.transform 10 512 env46475 = env46476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env46475 == env46476) = true)

theorem identity46476 : scanCanonicalize (H12AffineFastState.compose env46476 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46476 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env46477 : List Nat := [2,4,8,16,32,16,9,256,512,1024,512,513,268,1792,1,263,1809,805,1025,0,529,32,16,2,269,16,513,1808,512,805,1284,33,257,32,1793,513]

theorem envBound46477 : H12AffineFastState.Bounded env46477 := by
  intro p hp
  have h : env46477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46476_46477 : H12AffineEnvironment.transform 6 9 env46476 = env46477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46476 == env46477) = true)

theorem identity46477 : scanCanonicalize (H12AffineFastState.compose env46477 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound46477 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46478 : List Nat := [2,4,8,16,32,16,9,256,512,37,512,513,268,805,1,263,820,805,36,0,529,32,16,2,269,16,513,821,512,805,289,33,257,32,804,513]

theorem envBound46478 : H12AffineFastState.Bounded env46478 := by
  intro p hp
  have h : env46478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46477_46478 : H12AffineEnvironment.transform 9 37 env46477 = env46478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env46477 == env46478) = true)

def env46479 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,13341,262144,1025,32769,2097152,272512,2101249,21763,8328,17,2116881,2098432,17664,2417692,2102685,2411677,257,21793,46212,2156180]

theorem envBound46479 : H12AffineFastState.Bounded env46479 := by
  intro p hp
  have h : env46479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46468_46479 : H12AffineEnvironment.transform 5 17 env46468 = env46479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46468 == env46479) = true)

theorem identity46479 : scanCanonicalize (H12AffineFastState.compose env46479 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound46479 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env46480 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,33166,13341,262144,1025,32769,2097152,272512,2101249,2,8328,17,2103312,2098432,4097,2404637,2102685,2398620,257,32,46212,2143125]

theorem envBound46480 : H12AffineFastState.Bounded env46480 := by
  intro p hp
  have h : env46480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46479_46480 : H12AffineEnvironment.transform 13 5377 env46479 = env46480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46479 == env46480) = true)

theorem identity46480 : scanCanonicalize (H12AffineFastState.compose env46480 (packedSelected [0,4,5,7,8,11,16,17,18,19,20,22,23,24,28,31,32] rootPS)) = affineNative (2^(20+1) ^^^ 37017) := by decide +kernel

theorem selectedBound46480 : packedSelected [0,4,5,7,8,11,16,17,18,19,20,22,23,24,28,31,32] rootPS < 2^1333 := by decide +kernel

def env46481 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,33166,13341,262144,1025,32769,37017,272512,32920,2,8328,17,34953,38297,4097,270724,34052,264453,257,32,46212,8972]

theorem envBound46481 : H12AffineFastState.Bounded env46481 := by
  intro p hp
  have h : env46481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46480_46481 : H12AffineEnvironment.transform 20 37017 env46480 = env46481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 37017 env46480 == env46481) = true)

theorem identity46481 : scanCanonicalize (H12AffineFastState.compose env46481 (packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46481 : packedSelected [3,4,7,9,10,17,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env46482 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33031,13341,262144,1025,32769,36880,272393,32785,2,8193,17,34816,38160,4097,270605,34052,264453,257,32,46093,8972]

theorem envBound46482 : H12AffineFastState.Bounded env46482 := by
  intro p hp
  have h : env46482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46481_46482 : H12AffineEnvironment.transform 6 9 env46481 = env46482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46481 == env46482) = true)

theorem identity46482 : scanCanonicalize (H12AffineFastState.compose env46482 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound46482 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env46483 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,32768,33031,13341,43049,1025,32769,36880,32800,32785,2,8193,17,34816,38160,4097,35108,34052,41260,257,32,46093,8972]

theorem envBound46483 : H12AffineFastState.Bounded env46483 := by
  intro p hp
  have h : env46483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46482_46483 : H12AffineEnvironment.transform 17 43049 env46482 = env46483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env46482 == env46483) = true)

theorem identity46483 : scanCanonicalize (H12AffineFastState.compose env46483 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 9528) := by decide +kernel

theorem selectedBound46483 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env46484 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,9528,9279,13341,3345,1025,9529,13608,9496,9513,2,8193,17,11576,12328,4097,11292,8252,1044,257,32,4405,8972]

theorem envBound46484 : H12AffineFastState.Bounded env46484 := by
  intro p hp
  have h : env46484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46483_46484 : H12AffineEnvironment.transform 14 9528 env46483 = env46484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9528 env46483 == env46484) = true)

theorem identity46484 : scanCanonicalize (H12AffineFastState.compose env46484 (packedSelected [0,7,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46484 : packedSelected [0,7,11,14,15] rootPS < 2^1333 := by decide +kernel

def env46485 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1077,1330,5392,3345,1025,1076,5157,1045,1060,2,268,17,3125,4389,4097,3345,305,1044,257,32,4405,513]

theorem envBound46485 : H12AffineFastState.Bounded env46485 := by
  intro p hp
  have h : env46485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46484_46485 : H12AffineEnvironment.transform 12 269 env46484 = env46485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46484 == env46485) = true)

theorem identity46485 : scanCanonicalize (H12AffineFastState.compose env46485 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound46485 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46486 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,269,4404,0,263,4389,2340,52,1,4112,32,17,2,268,17,2048,4389,4097,2340,305,33,257,32,4405,513]

theorem envBound46486 : H12AffineFastState.Bounded env46486 := by
  intro p hp
  have h : env46486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46485_46486 : H12AffineEnvironment.transform 9 53 env46485 = env46486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46485 == env46486) = true)

theorem identity46486 : scanCanonicalize (H12AffineFastState.compose env46486 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46486 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46487 : List Nat := [2,4,8,16,1,17,9,256,512,20,2048,4096,269,4373,0,263,4356,2309,21,1,4112,1,17,2,268,17,2048,4356,4097,2309,272,0,257,1,4372,513]

theorem envBound46487 : H12AffineFastState.Bounded env46487 := by
  intro p hp
  have h : env46487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46486_46487 : H12AffineEnvironment.transform 4 1 env46486 = env46487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46486 == env46487) = true)

theorem identity46487 : scanCanonicalize (H12AffineFastState.compose env46487 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound46487 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46488 : List Nat := [2,4,8,16,1,17,9,256,512,20,522,4096,269,4373,0,263,4356,783,21,1,4112,1,17,2,268,17,522,4356,4097,783,272,0,257,1,4372,513]

theorem envBound46488 : H12AffineFastState.Bounded env46488 := by
  intro p hp
  have h : env46488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46487_46488 : H12AffineEnvironment.transform 10 522 env46487 = env46488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env46487 == env46488) = true)

theorem identity46488 : scanCanonicalize (H12AffineFastState.compose env46488 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound46488 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46489 : List Nat := [2,4,8,16,1,17,9,256,260,20,270,4096,269,4373,0,263,4356,11,21,1,4112,1,17,2,268,17,270,4356,4097,11,272,0,257,1,4372,261]

theorem envBound46489 : H12AffineFastState.Bounded env46489 := by
  intro p hp
  have h : env46489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46488_46489 : H12AffineEnvironment.transform 8 260 env46488 = env46489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env46488 == env46489) = true)

theorem identity46489 : scanCanonicalize (H12AffineFastState.compose env46489 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound46489 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46490 : List Nat := [2,4,8,16,1,17,9,256,260,20,270,0,269,277,0,263,260,11,21,1,16,1,17,2,268,17,270,260,1,11,272,0,257,1,276,261]

theorem envBound46490 : H12AffineFastState.Bounded env46490 := by
  intro p hp
  have h : env46490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46489_46490 : H12AffineEnvironment.transform 11 0 env46489 = env46490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env46489 == env46490) = true)

theorem identity46490 : scanCanonicalize (H12AffineFastState.compose env46490 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46490 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46491 : List Nat := [2,4,8,6,1,7,9,256,260,2,270,0,269,259,0,263,260,11,3,1,6,1,7,2,268,7,270,260,1,11,262,0,257,1,258,261]

theorem envBound46491 : H12AffineFastState.Bounded env46491 := by
  intro p hp
  have h : env46491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46490_46491 : H12AffineEnvironment.transform 3 6 env46490 = env46491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46490 == env46491) = true)

def env46492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2202015,2098513,17664,2437314,2102685,2411676,257,21793,46212,2175562]

theorem envBound46492 : H12AffineFastState.Bounded env46492 := by
  intro p hp
  have h : env46492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46466_46492 : H12AffineEnvironment.transform 21 272513 env46466 = env46492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46466 == env46492) = true)

theorem identity46492 : scanCanonicalize (H12AffineFastState.compose env46492 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound46492 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,115871,272513,120015,98781,8328,64,23808,115150,17664,324701,119042,329731,257,21793,46212,63189]

theorem envBound46493 : H12AffineFastState.Bounded env46493 := by
  intro p hp
  have h : env46493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46492_46493 : H12AffineEnvironment.transform 20 115871 env46492 = env46493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env46492 == env46493) = true)

def env46494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,115871,33,120015,98781,8328,64,23808,115150,17664,56573,119042,73891,257,21793,46212,63189]

theorem envBound46494 : H12AffineFastState.Bounded env46494 := by
  intro p hp
  have h : env46494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46493_46494 : H12AffineEnvironment.transform 17 10400 env46493 = env46494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46493 == env46494) = true)

theorem identity46494 : scanCanonicalize (H12AffineFastState.compose env46494 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound46494 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env46495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,65536,103631,10400,1025,32769,110786,33,106642,98781,8328,64,10589,112019,12637,43168,107871,73891,257,8572,46212,33416]

theorem envBound46495 : H12AffineFastState.Bounded env46495 := by
  intro p hp
  have h : env46495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46494_46495 : H12AffineEnvironment.transform 13 13405 env46494 = env46495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env46494 == env46495) = true)

theorem identity46495 : scanCanonicalize (H12AffineFastState.compose env46495 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46495 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8202,46277,10400,1025,32769,37064,33,32920,41431,8328,64,10589,38297,12637,43168,34133,169,257,8572,46212,33416]

theorem envBound46496 : H12AffineFastState.Bounded env46496 := by
  intro p hp
  have h : env46496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46495_46496 : H12AffineEnvironment.transform 15 8202 env46495 = env46496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46495 == env46496) = true)

theorem identity46496 : scanCanonicalize (H12AffineFastState.compose env46496 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46496 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env46497 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8202,46156,10281,1025,32769,36929,33,32785,41310,8193,64,10589,38160,12637,43049,34133,32,257,8572,46093,33281]

theorem envBound46497 : H12AffineFastState.Bounded env46497 := by
  intro p hp
  have h : env46497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46496_46497 : H12AffineEnvironment.transform 6 9 env46496 = env46497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46496 == env46497) = true)

theorem identity46497 : scanCanonicalize (H12AffineFastState.compose env46497 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound46497 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env46498 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8460,8202,5440,10281,1025,8461,12621,33,8477,82,8193,64,10589,13340,12637,2341,9305,32,257,8572,5377,8973]

theorem envBound46498 : H12AffineFastState.Bounded env46498 := by
  intro p hp
  have h : env46498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46497_46498 : H12AffineEnvironment.transform 14 8460 env46497 = env46498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env46497 == env46498) = true)

theorem identity46498 : scanCanonicalize (H12AffineFastState.compose env46498 (packedSelected [0,1,2,4,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound46498 : packedSelected [0,1,2,4,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env46499 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,0,262,5440,2341,1025,1,4161,33,17,82,269,64,2129,5392,4177,2341,1365,32,257,112,5377,513]

theorem envBound46499 : H12AffineFastState.Bounded env46499 := by
  intro p hp
  have h : env46499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46498_46499 : H12AffineEnvironment.transform 12 268 env46498 = env46499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env46498 == env46499) = true)

theorem identity46499 : scanCanonicalize (H12AffineFastState.compose env46499 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound46499 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env46500 : List Nat := [2,4,8,16,32,64,9,256,512,1024,782,4096,268,5457,0,262,5440,555,1025,1,4161,33,17,82,269,64,863,5392,4177,555,1365,32,257,112,5377,513]

theorem envBound46500 : H12AffineFastState.Bounded env46500 := by
  intro p hp
  have h : env46500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46499_46500 : H12AffineEnvironment.transform 10 782 env46499 = env46500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env46499 == env46500) = true)

theorem identity46500 : scanCanonicalize (H12AffineFastState.compose env46500 (packedSelected [0,2,3,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46500 : packedSelected [0,2,3,5,9] rootPS < 2^1333 := by decide +kernel

def env46501 : List Nat := [2,4,8,16,32,64,9,116,512,1024,634,4096,120,5157,0,114,5172,555,1025,1,4161,33,17,82,121,64,555,5220,4177,555,1057,32,117,112,5237,513]

theorem envBound46501 : H12AffineFastState.Bounded env46501 := by
  intro p hp
  have h : env46501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46500_46501 : H12AffineEnvironment.transform 7 116 env46500 = env46501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46500 == env46501) = true)

theorem identity46501 : scanCanonicalize (H12AffineFastState.compose env46501 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46501 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46502 : List Nat := [2,4,8,16,32,17,9,37,512,1024,555,4096,41,5157,0,35,5172,555,1025,1,4112,33,17,3,40,17,555,5173,4096,555,1057,32,36,33,5156,513]

theorem envBound46502 : H12AffineFastState.Bounded env46502 := by
  intro p hp
  have h : env46502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46501_46502 : H12AffineEnvironment.transform 5 17 env46501 = env46502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46501 == env46502) = true)

theorem identity46502 : scanCanonicalize (H12AffineFastState.compose env46502 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46502 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46503 : List Nat := [2,4,8,16,1,17,9,4,512,1024,522,4096,8,5124,0,2,5141,522,1025,1,4112,0,17,3,9,17,522,5140,4096,522,1024,1,5,0,5125,513]

theorem envBound46503 : H12AffineFastState.Bounded env46503 := by
  intro p hp
  have h : env46503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46502_46503 : H12AffineEnvironment.transform 4 1 env46502 = env46503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46502 == env46503) = true)

def env46504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,115871,32,120015,98781,8328,64,23808,115150,17664,56572,119042,73890,257,21793,46212,63189]

theorem envBound46504 : H12AffineFastState.Bounded env46504 := by
  intro p hp
  have h : env46504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46493_46504 : H12AffineEnvironment.transform 17 10401 env46493 = env46504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46493 == env46504) = true)

theorem identity46504 : scanCanonicalize (H12AffineFastState.compose env46504 (packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound46504 : packedSelected [4,7,9,11,14,18,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env46505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,115015,2420,1025,32769,115871,32,120015,98781,349,64,23808,115150,17664,56572,119042,65911,257,21793,38225,55040]

theorem envBound46505 : H12AffineFastState.Bounded env46505 := by
  intro p hp
  have h : env46505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46504_46505 : H12AffineEnvironment.transform 12 469 env46504 = env46505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env46504 == env46505) = true)

theorem identity46505 : scanCanonicalize (H12AffineFastState.compose env46505 (packedSelected [0,2,5,6,10,11,12,14,15,16,17,18,20,24,26,27,31] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46505 : packedSelected [0,2,5,6,10,11,12,14,15,16,17,18,20,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env46506 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,16384,32768,65536,114787,2128,1025,32769,115871,32,120015,98553,121,64,23588,114922,17444,56572,118822,65619,37,21509,38005,54820]

theorem envBound46506 : H12AffineFastState.Bounded env46506 := by
  intro p hp
  have h : env46506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46505_46506 : H12AffineEnvironment.transform 7 36 env46505 = env46506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46505 == env46506) = true)

theorem identity46506 : scanCanonicalize (H12AffineFastState.compose env46506 (packedSelected [0,2,4,6,7,9,11,14,16,17,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 32803) := by decide +kernel

theorem selectedBound46506 : packedSelected [0,2,4,6,7,9,11,14,16,17,20,23] rootPS < 2^1333 := by decide +kernel

def env46507 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,16384,32768,32803,16448,2128,1025,32769,17596,32,21740,218,121,64,23588,16585,17444,56572,20485,32880,37,21509,38005,54820]

theorem envBound46507 : H12AffineFastState.Bounded env46507 := by
  intro p hp
  have h : env46507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46506_46507 : H12AffineEnvironment.transform 15 32803 env46506 = env46507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32803 env46506 == env46507) = true)

theorem identity46507 : scanCanonicalize (H12AffineFastState.compose env46507 (packedSelected [1,2,3,4,5,6,8,10,11,16,17,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound46507 : packedSelected [1,2,3,4,5,6,8,10,11,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env46508 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,241,5236,32768,32803,5172,2128,1025,32769,4296,32,152,218,121,64,2128,5309,4176,34952,1137,32880,37,113,38005,33360]

theorem envBound46508 : H12AffineFastState.Bounded env46508 := by
  intro p hp
  have h : env46508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46507_46508 : H12AffineEnvironment.transform 13 5236 env46507 = env46508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env46507 == env46508) = true)

def env46509 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,4194304,2101329,98780,8328,64,6664478,2098512,17665,2437315,2102685,6349852,257,21793,46212,2175562]

theorem envBound46509 : H12AffineFastState.Bounded env46509 := by
  intro p hp
  have h : env46509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46465_46509 : H12AffineEnvironment.transform 22 2101329 env46465 = env46509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env46465 == env46509) = true)

def env46510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272512,2101329,98780,8328,64,2202014,2098512,17665,2437315,2102685,2411676,257,21793,46212,2175562]

theorem envBound46510 : H12AffineFastState.Bounded env46510 := by
  intro p hp
  have h : env46510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46509_46510 : H12AffineEnvironment.transform 21 272512 env46509 = env46510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46509 == env46510) = true)

theorem identity46510 : scanCanonicalize (H12AffineFastState.compose env46510 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound46510 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46511 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,2097152,272512,2101329,41431,8328,64,2144661,2098512,17665,2363592,2102685,2411676,257,21793,46212,2101825]

theorem envBound46511 : H12AffineFastState.Bounded env46511 := by
  intro p hp
  have h : env46511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46510_46511 : H12AffineEnvironment.transform 15 8203 env46510 = env46511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env46510 == env46511) = true)

def env46512 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,2097152,272513,2101329,98780,8328,64,2202015,2098512,17665,2437315,2102685,2411677,257,21793,46212,2175562]

theorem envBound46512 : H12AffineFastState.Bounded env46512 := by
  intro p hp
  have h : env46512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46509_46512 : H12AffineEnvironment.transform 21 272513 env46509 = env46512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46509 == env46512) = true)

theorem identity46512 : scanCanonicalize (H12AffineFastState.compose env46512 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound46512 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46513 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,77899,272513,73754,98780,8328,64,43476,79131,17665,262280,75222,392406,257,21793,46212,513]

theorem envBound46513 : H12AffineFastState.Bounded env46513 := by
  intro p hp
  have h : env46513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46512_46513 : H12AffineEnvironment.transform 20 77899 env46512 = env46513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env46512 == env46513) = true)

def env46514 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90258,262144,1025,1,77899,272513,73754,66012,8328,64,10708,79131,17665,262280,75222,359638,257,21793,13444,513]

theorem envBound46514 : H12AffineFastState.Bounded env46514 := by
  intro p hp
  have h : env46514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46513_46514 : H12AffineEnvironment.transform 14 0 env46513 = env46514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46513 == env46514) = true)

theorem identity46514 : scanCanonicalize (H12AffineFastState.compose env46514 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound46514 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env46515 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16400,262144,1025,1,4297,272513,152,8542,8328,64,10708,5529,17665,262280,1364,285780,257,21793,13444,513]

theorem envBound46515 : H12AffineFastState.Bounded env46515 := by
  intro p hp
  have h : env46515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46514_46515 : H12AffineEnvironment.transform 15 8322 env46514 = env46515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env46514 == env46515) = true)

theorem identity46515 : scanCanonicalize (H12AffineFastState.compose env46515 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46515 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env46516 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16400,10281,1025,1,4297,168,152,8542,8328,64,10708,5529,17665,10401,1364,29821,257,21793,13444,513]

theorem envBound46516 : H12AffineFastState.Bounded env46516 := by
  intro p hp
  have h : env46516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46515_46516 : H12AffineEnvironment.transform 17 10281 env46515 = env46516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46515 == env46516) = true)

theorem identity46516 : scanCanonicalize (H12AffineFastState.compose env46516 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound46516 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env46517 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,0,8322,5392,10281,1025,1,4297,168,152,8542,8328,64,10708,5529,4097,10401,1364,8573,257,33,13444,513]

theorem envBound46517 : H12AffineFastState.Bounded env46517 := by
  intro p hp
  have h : env46517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46516_46517 : H12AffineEnvironment.transform 13 5376 env46516 = env46517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46516 == env46517) = true)

theorem identity46517 : scanCanonicalize (H12AffineFastState.compose env46517 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46517 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46518 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,0,479,5392,2420,1025,1,4297,168,152,3,469,64,2185,5529,4097,2556,1364,32,257,33,5593,513]

theorem envBound46518 : H12AffineFastState.Bounded env46518 := by
  intro p hp
  have h : env46518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46517_46518 : H12AffineEnvironment.transform 12 349 env46517 = env46518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46517 == env46518) = true)

theorem identity46518 : scanCanonicalize (H12AffineFastState.compose env46518 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46518 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1025,1,4160,33,17,3,348,64,2048,5392,4097,2421,1364,32,257,33,5456,513]

theorem envBound46519 : H12AffineFastState.Bounded env46519 := by
  intro p hp
  have h : env46519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46518_46519 : H12AffineEnvironment.transform 6 9 env46518 = env46519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46518 == env46519) = true)

theorem identity46519 : scanCanonicalize (H12AffineFastState.compose env46519 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2074) := by decide +kernel

theorem selectedBound46519 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2074,349,3354,0,342,3338,2420,1025,1,2138,33,17,3,348,64,2048,3338,2075,2421,1364,32,257,33,3402,513]

theorem envBound46520 : H12AffineFastState.Bounded env46520 := by
  intro p hp
  have h : env46520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46519_46520 : H12AffineEnvironment.transform 11 2074 env46519 = env46520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2074 env46519 == env46520) = true)

theorem identity46520 : scanCanonicalize (H12AffineFastState.compose env46520 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound46520 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env46521 : List Nat := [2,4,8,16,32,64,9,111,512,1024,2048,2074,50,3189,0,57,3173,2075,1025,1,2138,33,17,3,51,64,2048,3173,2075,2074,1083,32,110,33,3109,513]

theorem envBound46521 : H12AffineFastState.Bounded env46521 := by
  intro p hp
  have h : env46521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46520_46521 : H12AffineEnvironment.transform 7 111 env46520 = env46521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env46520 == env46521) = true)

theorem identity46521 : scanCanonicalize (H12AffineFastState.compose env46521 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46521 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46522 : List Nat := [2,4,8,16,1,64,9,78,512,1024,2048,2074,19,3156,0,24,3140,2075,1025,1,2138,0,17,3,18,64,2048,3140,2075,2074,1050,1,79,0,3076,513]

theorem envBound46522 : H12AffineFastState.Bounded env46522 := by
  intro p hp
  have h : env46522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46521_46522 : H12AffineEnvironment.transform 4 1 env46521 = env46522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46521 == env46522) = true)

def env46523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90259,262144,1025,0,77899,272513,73754,66013,8328,64,10709,79131,17665,262280,75222,359639,257,21793,13445,513]

theorem envBound46523 : H12AffineFastState.Bounded env46523 := by
  intro p hp
  have h : env46523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46513_46523 : H12AffineEnvironment.transform 14 1 env46513 = env46523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env46513 == env46523) = true)

theorem identity46523 : scanCanonicalize (H12AffineFastState.compose env46523 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46523 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,262144,1025,0,77899,272392,73754,65876,8193,64,10588,79131,17665,262145,75103,359518,257,21793,13324,513]

theorem envBound46524 : H12AffineFastState.Bounded env46524 := by
  intro p hp
  have h : env46524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46523_46524 : H12AffineEnvironment.transform 6 9 env46523 = env46524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46523 == env46524) = true)

theorem identity46524 : scanCanonicalize (H12AffineFastState.compose env46524 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound46524 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env46525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,67618,1025,0,77899,73770,73754,65876,8193,64,10588,79131,17665,67619,75103,29820,257,21793,13324,513]

theorem envBound46525 : H12AffineFastState.Bounded env46525 := by
  intro p hp
  have h : env46525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46524_46525 : H12AffineEnvironment.transform 17 67618 env46524 = env46525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env46524 == env46525) = true)

def env46526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound46526 : H12AffineFastState.Bounded env46526 := by
  intro p hp
  have h : env46526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46283_46526 : H12AffineEnvironment.transform 26 30393345 env46283 = env46526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env46283 == env46526) = true)

def env46527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound46527 : H12AffineFastState.Bounded env46527 := by
  intro p hp
  have h : env46527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46526_46527 : H12AffineEnvironment.transform 18 1024 env46526 = env46527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env46526 == env46527) = true)

theorem identity46527 : scanCanonicalize (H12AffineFastState.compose env46527 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188755) := by decide +kernel

theorem selectedBound46527 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188755,16777216,8328,64,23504338,18973837,77955,2598355,18932163,23160257,256,16818559,16793818,18990613]

theorem envBound46528 : H12AffineFastState.Bounded env46528 := by
  intro p hp
  have h : env46528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46527_46528 : H12AffineEnvironment.transform 22 2188755 env46527 = env46528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188755 env46527 == env46528) = true)

def env46529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,16777216,8328,64,17227834,18973837,77955,2598355,18932163,16850985,256,16818559,16793818,18990613]

theorem envBound46529 : H12AffineFastState.Bounded env46529 := by
  intro p hp
  have h : env46529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46528_46529 : H12AffineEnvironment.transform 21 2115048 env46528 = env46529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115048 env46528 == env46529) = true)

def env46530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175048,8328,64,2609266,46277,77955,2598355,119179,2101345,256,2199863,2191506,63069]

theorem envBound46530 : H12AffineFastState.Bounded env46530 := by
  intro p hp
  have h : env46530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46529_46530 : H12AffineEnvironment.transform 23 2175048 env46529 = env46530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env46529 == env46530) = true)

def env46531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175048,8328,64,2590066,46277,77955,2598355,99467,2101345,256,2199863,2172306,41821]

theorem envBound46531 : H12AffineFastState.Bounded env46531 := by
  intro p hp
  have h : env46531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46530_46531 : H12AffineEnvironment.transform 13 5376 env46530 = env46531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46530 == env46531) = true)

theorem identity46531 : scanCanonicalize (H12AffineFastState.compose env46531 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound46531 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,8323,131072,262144,1024,32769,2097152,2101480,2101328,2101451,8328,64,2532849,46277,4096,2524496,41992,2101345,256,2142644,2098449,41821]

theorem envBound46532 : H12AffineFastState.Bounded env46532 := by
  intro p hp
  have h : env46532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46531_46532 : H12AffineEnvironment.transform 15 8323 env46531 = env46532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env46531 == env46532) = true)

def env46533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2532729,46157,4096,2524496,41992,2101345,256,2142524,2098449,41821]

theorem envBound46533 : H12AffineFastState.Bounded env46533 := by
  intro p hp
  have h : env46533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46532_46533 : H12AffineEnvironment.transform 6 8 env46532 = env46533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46532 == env46533) = true)

theorem identity46533 : scanCanonicalize (H12AffineFastState.compose env46533 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound46533 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,5393,262144,1024,32769,2097152,2101344,2101328,2101315,8192,64,2404456,46157,4096,2396225,41992,2101345,256,2142524,2098449,41821]

theorem envBound46534 : H12AffineFastState.Bounded env46534 := by
  intro p hp
  have h : env46534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46533_46534 : H12AffineEnvironment.transform 16 5393 env46533 = env46534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env46533 == env46534) = true)

theorem identity46534 : scanCanonicalize (H12AffineFastState.compose env46534 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46534 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env46535 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,262144,1024,8541,2097152,2101344,2101328,2101315,8192,64,2363700,5393,4096,2371869,1364,2101345,256,2101344,2098449,513]

theorem envBound46535 : H12AffineFastState.Bounded env46535 := by
  intro p hp
  have h : env46535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46534_46535 : H12AffineEnvironment.transform 14 8540 env46534 = env46535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46534 == env46535) = true)

theorem identity46535 : scanCanonicalize (H12AffineFastState.compose env46535 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound46535 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46536 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,262144,1024,8541,5456,1328,1280,1299,8192,64,263268,5393,4096,271437,1364,1329,256,1328,4161,513]

theorem envBound46536 : H12AffineFastState.Bounded env46536 := by
  intro p hp
  have h : env46536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46535_46536 : H12AffineEnvironment.transform 20 5456 env46535 = env46536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env46535 == env46536) = true)

theorem identity46536 : scanCanonicalize (H12AffineFastState.compose env46536 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound46536 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env46537 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5393,10280,1024,8541,5456,1328,1280,1299,8192,64,11340,5393,4096,3173,1364,1329,256,1328,4161,513]

theorem envBound46537 : H12AffineFastState.Bounded env46537 := by
  intro p hp
  have h : env46537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46536_46537 : H12AffineEnvironment.transform 17 10280 env46536 = env46537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46536 == env46537) = true)

def env46538 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2532728,46156,4096,2524496,41992,2101345,256,2142525,2098449,41821]

theorem envBound46538 : H12AffineFastState.Bounded env46538 := by
  intro p hp
  have h : env46538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46532_46538 : H12AffineEnvironment.transform 6 9 env46532 = env46538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46532 == env46538) = true)

theorem identity46538 : scanCanonicalize (H12AffineFastState.compose env46538 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound46538 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env46539 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,46156,262144,1024,32769,2097152,2101345,2101328,2101314,8193,64,2363700,46156,4096,2371868,41992,2101345,256,2142525,2098449,41821]

theorem envBound46539 : H12AffineFastState.Bounded env46539 := by
  intro p hp
  have h : env46539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46538_46539 : H12AffineEnvironment.transform 16 46156 env46538 = env46539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env46538 == env46539) = true)

theorem identity46539 : scanCanonicalize (H12AffineFastState.compose env46539 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound46539 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46540 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5392,262144,1024,8541,2097152,2101345,2101328,2101314,8193,64,2363700,5392,4096,2371868,1364,2101345,256,2101345,2098449,513]

theorem envBound46540 : H12AffineFastState.Bounded env46540 := by
  intro p hp
  have h : env46540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46539_46540 : H12AffineEnvironment.transform 14 8540 env46539 = env46540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env46539 == env46540) = true)

theorem identity46540 : scanCanonicalize (H12AffineFastState.compose env46540 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound46540 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46541 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8202,5392,262144,1024,8541,4161,32,17,3,8193,64,262517,5392,4096,270685,1364,32,256,32,5456,513]

theorem envBound46541 : H12AffineFastState.Bounded env46541 := by
  intro p hp
  have h : env46541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46540_46541 : H12AffineEnvironment.transform 20 4161 env46540 = env46541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46540 == env46541) = true)

def env46542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175048,8328,64,2590067,46277,77955,2598355,99466,2101345,256,2199863,2172307,41820]

theorem envBound46542 : H12AffineFastState.Bounded env46542 := by
  intro p hp
  have h : env46542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46530_46542 : H12AffineEnvironment.transform 13 5377 env46530 = env46542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46530 == env46542) = true)

theorem identity46542 : scanCanonicalize (H12AffineFastState.compose env46542 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 78018) := by decide +kernel

theorem selectedBound46542 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,78018,73771,16,138,8328,64,439729,46277,77955,431377,99466,73891,256,41461,5457,41820]

theorem envBound46543 : H12AffineFastState.Bounded env46543 := by
  intro p hp
  have h : env46543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46542_46543 : H12AffineEnvironment.transform 20 78018 env46542 = env46543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78018 env46542 == env46543) = true)

def env46544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,73771,16,2,8192,64,439609,46157,77835,431377,99330,73771,256,41341,5457,41820]

theorem envBound46544 : H12AffineFastState.Bounded env46544 := by
  intro p hp
  have h : env46544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46543_46544 : H12AffineEnvironment.transform 6 8 env46543 = env46544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46543 == env46544) = true)

theorem identity46544 : scanCanonicalize (H12AffineFastState.compose env46544 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46544 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46545 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77898,73771,16,2,8192,64,398436,5392,77835,406604,75103,73771,256,32,5457,513]

theorem envBound46545 : H12AffineFastState.Bounded env46545 := by
  intro p hp
  have h : env46545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46544_46545 : H12AffineEnvironment.transform 14 8541 env46544 = env46545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46544 == env46545) = true)

theorem identity46545 : scanCanonicalize (H12AffineFastState.compose env46545 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 4096) := by decide +kernel

theorem selectedBound46545 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env46546 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,4096,262144,1024,8540,77898,73771,16,2,8192,64,263268,5392,77835,271436,75103,73771,256,32,5457,513]

theorem envBound46546 : H12AffineFastState.Bounded env46546 := by
  intro p hp
  have h : env46546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46545_46546 : H12AffineEnvironment.transform 16 4096 env46545 = env46546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4096 env46545 == env46546) = true)

theorem identity46546 : scanCanonicalize (H12AffineFastState.compose env46546 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound46546 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env46547 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,9499,4096,262144,1024,8540,5457,1328,16,2,8192,64,263268,5392,5392,271436,68,1328,256,32,5457,513]

theorem envBound46547 : H12AffineFastState.Bounded env46547 := by
  intro p hp
  have h : env46547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46546_46547 : H12AffineEnvironment.transform 15 9499 env46546 = env46547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env46546 == env46547) = true)

theorem identity46547 : scanCanonicalize (H12AffineFastState.compose env46547 (packedSelected [2,6,12,15,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound46547 : packedSelected [2,6,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env46548 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,372,1330,4096,262144,1024,373,5457,1328,16,2,41,64,263268,5392,5392,263269,68,1328,256,32,5457,513]

theorem envBound46548 : H12AffineFastState.Bounded env46548 := by
  intro p hp
  have h : env46548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46547_46548 : H12AffineEnvironment.transform 12 41 env46547 = env46548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env46547 == env46548) = true)

theorem identity46548 : scanCanonicalize (H12AffineFastState.compose env46548 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound46548 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env46549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,372,1330,4096,3124,1024,373,5457,1328,16,2,41,64,2128,5392,5392,2129,68,1328,256,32,5457,513]

theorem envBound46549 : H12AffineFastState.Bounded env46549 := by
  intro p hp
  have h : env46549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46548_46549 : H12AffineEnvironment.transform 17 3124 env46548 = env46549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env46548 == env46549) = true)

theorem identity46549 : scanCanonicalize (H12AffineFastState.compose env46549 (packedSelected [0,1,4,5,7,8,9,12,14,15,24] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound46549 : packedSelected [0,1,4,5,7,8,9,12,14,15,24] rootPS < 2^1333 := by decide +kernel

def env46550 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,41,4453,372,342,4096,2128,100,373,4405,340,16,2,41,64,2128,4468,4468,2129,68,340,256,32,4405,513]

theorem envBound46550 : H12AffineFastState.Bounded env46550 := by
  intro p hp
  have h : env46550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46549_46550 : H12AffineEnvironment.transform 9 100 env46549 = env46550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env46549 == env46550) = true)

theorem identity46550 : scanCanonicalize (H12AffineFastState.compose env46550 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46550 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46551 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,4096,41,4161,80,114,4096,2128,100,81,4113,112,16,2,41,64,2128,4176,4176,2129,68,112,36,32,4113,513]

theorem envBound46551 : H12AffineFastState.Bounded env46551 := by
  intro p hp
  have h : env46551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46550_46551 : H12AffineEnvironment.transform 7 36 env46550 = env46551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46550 == env46551) = true)

theorem identity46551 : scanCanonicalize (H12AffineFastState.compose env46551 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound46551 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env46552 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,2112,41,2049,80,114,2112,2128,100,81,2129,112,16,2,41,64,2128,2064,2064,2129,68,112,36,32,2129,513]

theorem envBound46552 : H12AffineFastState.Bounded env46552 := by
  intro p hp
  have h : env46552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46551_46552 : H12AffineEnvironment.transform 11 2112 env46551 = env46552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env46551 == env46552) = true)

theorem identity46552 : scanCanonicalize (H12AffineFastState.compose env46552 (packedSelected [0,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound46552 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env46553 : List Nat := [2,4,8,16,32,64,8,36,512,100,97,33,41,96,80,114,33,49,100,81,48,112,16,2,41,64,49,113,113,48,68,112,36,32,48,513]

theorem envBound46553 : H12AffineFastState.Bounded env46553 := by
  intro p hp
  have h : env46553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46552_46553 : H12AffineEnvironment.transform 10 97 env46552 = env46553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env46552 == env46553) = true)

theorem identity46553 : scanCanonicalize (H12AffineFastState.compose env46553 (packedSelected [2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46553 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env46554 : List Nat := [2,4,8,16,1,64,8,5,512,69,64,0,8,65,80,83,0,16,69,81,17,81,16,2,8,64,16,80,80,17,68,81,5,1,17,513]

theorem envBound46554 : H12AffineFastState.Bounded env46554 := by
  intro p hp
  have h : env46554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46553_46554 : H12AffineEnvironment.transform 4 1 env46553 = env46554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46553 == env46554) = true)

theorem identity46554 : scanCanonicalize (H12AffineFastState.compose env46554 (packedSelected [0,1,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46554 : packedSelected [0,1,8] rootPS < 2^1333 := by decide +kernel

def env46555 : List Nat := [2,4,8,16,1,17,8,5,512,20,17,0,8,16,1,2,0,16,20,0,17,0,16,2,8,17,16,1,1,17,21,0,5,1,17,513]

theorem envBound46555 : H12AffineFastState.Bounded env46555 := by
  intro p hp
  have h : env46555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46554_46555 : H12AffineEnvironment.transform 5 17 env46554 = env46555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46554 == env46555) = true)

def env46556 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77899,73771,16,3,8193,64,439608,46156,77834,431377,99331,73770,256,41340,5457,41820]

theorem envBound46556 : H12AffineFastState.Bounded env46556 := by
  intro p hp
  have h : env46556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46543_46556 : H12AffineEnvironment.transform 6 9 env46543 = env46556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46543 == env46556) = true)

theorem identity46556 : scanCanonicalize (H12AffineFastState.compose env46556 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46556 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env46557 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,77899,73771,16,3,8193,64,398437,5393,77834,406604,75102,73770,256,33,5457,513]

theorem envBound46557 : H12AffineFastState.Bounded env46557 := by
  intro p hp
  have h : env46557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46556_46557 : H12AffineEnvironment.transform 14 8541 env46556 = env46557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46556 == env46557) = true)

theorem identity46557 : scanCanonicalize (H12AffineFastState.compose env46557 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46557 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env46558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77899,73771,16,3,8193,64,146508,5393,77834,138341,75102,73770,256,33,5457,513]

theorem envBound46558 : H12AffineFastState.Bounded env46558 := by
  intro p hp
  have h : env46558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46557_46558 : H12AffineEnvironment.transform 17 10281 env46557 = env46558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46557 == env46558) = true)

theorem identity46558 : scanCanonicalize (H12AffineFastState.compose env46558 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound46558 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env46559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,263,131072,10281,1024,8540,12620,8492,16,3,8193,64,146508,5393,12557,138341,9305,8493,256,33,5457,513]

theorem envBound46559 : H12AffineFastState.Bounded env46559 := by
  intro p hp
  have h : env46559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46558_46559 : H12AffineEnvironment.transform 15 263 env46558 = env46559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env46558 == env46559) = true)

theorem identity46559 : scanCanonicalize (H12AffineFastState.compose env46559 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound46559 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,263,13340,10281,1024,8540,12620,8492,16,3,8193,64,2128,5393,12557,10361,9305,8493,256,33,5457,513]

theorem envBound46560 : H12AffineFastState.Bounded env46560 := by
  intro p hp
  have h : env46560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46559_46560 : H12AffineEnvironment.transform 16 13340 env46559 = env46560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env46559 == env46560) = true)

theorem identity46560 : scanCanonicalize (H12AffineFastState.compose env46560 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound46560 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env46561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,263,5441,2420,1024,1,4113,113,16,3,348,64,2128,5393,4176,2340,1284,112,256,33,5457,513]

theorem envBound46561 : H12AffineFastState.Bounded env46561 := by
  intro p hp
  have h : env46561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46560_46561 : H12AffineEnvironment.transform 12 349 env46560 = env46561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env46560 == env46561) = true)

theorem identity46561 : scanCanonicalize (H12AffineFastState.compose env46561 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46561 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46562 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1024,1,4113,33,16,3,268,16,2048,5393,4096,2340,1284,32,256,33,5377,513]

theorem envBound46562 : H12AffineFastState.Bounded env46562 := by
  intro p hp
  have h : env46562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46561_46562 : H12AffineEnvironment.transform 5 16 env46561 = env46562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46561 == env46562) = true)

theorem identity46562 : scanCanonicalize (H12AffineFastState.compose env46562 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46562 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46563 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,0,34,5172,2049,1024,1,4113,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound46563 : H12AffineFastState.Bounded env46563 := by
  intro p hp
  have h : env46563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46562_46563 : H12AffineEnvironment.transform 7 37 env46562 = env46563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46562 == env46563) = true)

def env46564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115048,2188755,2175049,8328,64,2609267,46276,77955,2598355,119178,2101344,256,2199862,2191507,63068]

theorem envBound46564 : H12AffineFastState.Bounded env46564 := by
  intro p hp
  have h : env46564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46529_46564 : H12AffineEnvironment.transform 23 2175049 env46529 = env46564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175049 env46529 == env46564) = true)

def env46565 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101480,2175187,2175049,8328,64,2590067,46276,77955,2598355,99466,2101344,256,2199862,2172307,41820]

theorem envBound46565 : H12AffineFastState.Bounded env46565 := by
  intro p hp
  have h : env46565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46564_46565 : H12AffineEnvironment.transform 13 5376 env46564 = env46565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46564 == env46565) = true)

theorem identity46565 : scanCanonicalize (H12AffineFastState.compose env46565 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102814) := by decide +kernel

theorem selectedBound46565 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102814,98678,41293,41431,8328,64,398573,46276,77955,406605,99466,98814,256,168,46093,41820]

theorem envBound46566 : H12AffineFastState.Bounded env46566 := by
  intro p hp
  have h : env46566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46565_46566 : H12AffineEnvironment.transform 20 102814 env46565 = env46566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102814 env46565 == env46566) = true)

def env46567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,102814,98678,41293,41431,8328,64,146629,46276,77955,138341,99466,98814,256,168,46093,41820]

theorem envBound46567 : H12AffineFastState.Bounded env46567 := by
  intro p hp
  have h : env46567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46566_46567 : H12AffineEnvironment.transform 17 10280 env46566 = env46567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env46566 == env46567) = true)

theorem identity46567 : scanCanonicalize (H12AffineFastState.compose env46567 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound46567 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1024,8540,78019,73771,16,138,8328,64,146629,5529,77955,138341,75223,73891,256,168,5456,513]

theorem envBound46568 : H12AffineFastState.Bounded env46568 := by
  intro p hp
  have h : env46568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46567_46568 : H12AffineEnvironment.transform 14 8541 env46567 = env46568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env46567 == env46568) = true)

theorem identity46568 : scanCanonicalize (H12AffineFastState.compose env46568 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound46568 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,79130,10280,1024,8540,78019,73771,16,138,8328,64,68063,5529,77955,76159,75223,73891,256,168,5456,513]

theorem envBound46569 : H12AffineFastState.Bounded env46569 := by
  intro p hp
  have h : env46569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46568_46569 : H12AffineEnvironment.transform 16 79130 env46568 = env46569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env46568 == env46569) = true)

theorem identity46569 : scanCanonicalize (H12AffineFastState.compose env46569 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 9498) := by decide +kernel

theorem selectedBound46569 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,9498,4096,10280,1024,8540,5593,1329,16,138,8328,64,11461,5529,5529,3173,205,1465,256,168,5456,513]

theorem envBound46570 : H12AffineFastState.Bounded env46570 := by
  intro p hp
  have h : env46570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46569_46570 : H12AffineEnvironment.transform 15 9498 env46569 = env46570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9498 env46569 == env46570) = true)

theorem identity46570 : scanCanonicalize (H12AffineFastState.compose env46570 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound46570 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env46571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,160,5376,509,1466,4096,2184,1024,508,5593,1329,16,138,40,64,3173,5529,5529,3173,205,1465,256,168,5456,513]

theorem envBound46571 : H12AffineFastState.Bounded env46571 := by
  intro p hp
  have h : env46571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46570_46571 : H12AffineEnvironment.transform 12 160 env46570 = env46571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env46570 == env46571) = true)

theorem identity46571 : scanCanonicalize (H12AffineFastState.compose env46571 (packedSelected [2,6,11,12,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound46571 : packedSelected [2,6,11,12,15,23] rootPS < 2^1333 := by decide +kernel

def env46572 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,160,4452,509,478,4096,2184,100,508,4541,341,16,138,40,64,2049,4605,4605,2049,205,477,256,168,4404,513]

theorem envBound46572 : H12AffineFastState.Bounded env46572 := by
  intro p hp
  have h : env46572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46571_46572 : H12AffineEnvironment.transform 9 100 env46571 = env46572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env46571 == env46572) = true)

theorem identity46572 : scanCanonicalize (H12AffineFastState.compose env46572 (packedSelected [2,4,6,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound46572 : packedSelected [2,4,6,7,9,27] rootPS < 2^1333 := by decide +kernel

def env46573 : List Nat := [2,4,8,16,32,64,128,116,512,100,2048,4096,160,4112,137,170,4096,2184,100,136,4297,33,16,138,40,64,2049,4233,4233,2049,205,169,116,168,4160,513]

theorem envBound46573 : H12AffineFastState.Bounded env46573 := by
  intro p hp
  have h : env46573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46572_46573 : H12AffineEnvironment.transform 7 116 env46572 = env46573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env46572 == env46573) = true)

theorem identity46573 : scanCanonicalize (H12AffineFastState.compose env46573 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound46573 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46574 : List Nat := [2,4,8,16,32,64,89,116,512,100,2048,4096,121,4112,80,115,4096,2129,100,81,4112,33,16,83,40,64,2049,4176,4176,2049,20,112,116,113,4160,513]

theorem envBound46574 : H12AffineFastState.Bounded env46574 := by
  intro p hp
  have h : env46574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46573_46574 : H12AffineEnvironment.transform 6 89 env46573 = env46574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env46573 == env46574) = true)

theorem identity46574 : scanCanonicalize (H12AffineFastState.compose env46574 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 113) := by decide +kernel

theorem selectedBound46574 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env46575 : List Nat := [2,4,8,16,32,64,89,116,113,100,2048,4096,121,4112,80,115,4096,2129,100,81,4112,33,16,83,40,64,2049,4176,4176,2049,20,112,116,113,4160,112]

theorem envBound46575 : H12AffineFastState.Bounded env46575 := by
  intro p hp
  have h : env46575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46574_46575 : H12AffineEnvironment.transform 8 113 env46574 = env46575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 113 env46574 == env46575) = true)

theorem identity46575 : scanCanonicalize (H12AffineFastState.compose env46575 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound46575 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env46576 : List Nat := [2,4,8,16,1,64,89,85,80,69,2048,4096,88,4112,80,82,4096,2129,69,81,4112,0,16,83,9,64,2049,4176,4176,2049,20,81,85,80,4160,81]

theorem envBound46576 : H12AffineFastState.Bounded env46576 := by
  intro p hp
  have h : env46576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46575_46576 : H12AffineEnvironment.transform 4 1 env46575 = env46576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env46575 == env46576) = true)

theorem identity46576 : scanCanonicalize (H12AffineFastState.compose env46576 (packedSelected [0,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound46576 : packedSelected [0,4,7] rootPS < 2^1333 := by decide +kernel

def env46577 : List Nat := [2,4,8,16,1,64,89,85,80,69,2048,2113,88,2129,80,82,2113,2129,69,81,2129,0,16,83,9,64,2049,2065,2065,2049,20,81,85,80,2049,81]

theorem envBound46577 : H12AffineFastState.Bounded env46577 := by
  intro p hp
  have h : env46577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46576_46577 : H12AffineEnvironment.transform 11 2113 env46576 = env46577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env46576 == env46577) = true)

theorem identity46577 : scanCanonicalize (H12AffineFastState.compose env46577 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46577 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46578 : List Nat := [2,4,8,16,1,16,9,5,0,21,2048,2065,8,2049,0,2,2065,2049,21,1,2049,0,16,3,9,16,2049,2065,2065,2049,20,1,5,0,2049,1]

theorem envBound46578 : H12AffineFastState.Bounded env46578 := by
  intro p hp
  have h : env46578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46577_46578 : H12AffineEnvironment.transform 5 16 env46577 = env46578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46577 == env46578) = true)

theorem identity46578 : scanCanonicalize (H12AffineFastState.compose env46578 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46578 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46579 : List Nat := [2,4,8,16,1,16,9,5,0,21,1,16,8,0,0,2,16,0,21,1,0,0,16,3,9,16,0,16,16,0,20,1,5,0,0,1]

theorem envBound46579 : H12AffineFastState.Bounded env46579 := by
  intro p hp
  have h : env46579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46578_46579 : H12AffineEnvironment.transform 10 1 env46578 = env46579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46578 == env46579) = true)

theorem identity46579 : scanCanonicalize (H12AffineFastState.compose env46579 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound46579 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46580 : List Nat := [2,4,8,0,1,0,9,5,0,5,1,0,8,0,0,2,0,0,5,1,0,0,0,3,9,0,0,0,0,0,4,1,5,0,0,1]

theorem envBound46580 : H12AffineFastState.Bounded env46580 := by
  intro p hp
  have h : env46580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46579_46580 : H12AffineEnvironment.transform 3 0 env46579 = env46580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env46579 == env46580) = true)

def env46581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102814,98678,41293,41431,8328,64,146628,46276,77955,138340,99466,98814,256,168,46093,41820]

theorem envBound46581 : H12AffineFastState.Bounded env46581 := by
  intro p hp
  have h : env46581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46566_46581 : H12AffineEnvironment.transform 17 10281 env46566 = env46581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46566 == env46581) = true)

theorem identity46581 : scanCanonicalize (H12AffineFastState.compose env46581 (packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound46581 : packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env46582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10281,1024,8661,77898,73890,153,3,8328,64,146628,5392,77955,138340,75102,73770,256,168,5593,648]

theorem envBound46582 : H12AffineFastState.Bounded env46582 := by
  intro p hp
  have h : env46582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46581_46582 : H12AffineEnvironment.transform 14 8660 env46581 = env46582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env46581 == env46582) = true)

theorem identity46582 : scanCanonicalize (H12AffineFastState.compose env46582 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound46582 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env46583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8323,131072,10281,1024,8661,4297,33,153,3,8328,64,146628,5392,4096,138340,1501,169,256,168,5593,648]

theorem envBound46583 : H12AffineFastState.Bounded env46583 := by
  intro p hp
  have h : env46583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46582_46583 : H12AffineEnvironment.transform 15 8323 env46582 = env46583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env46582 == env46583) = true)

theorem identity46583 : scanCanonicalize (H12AffineFastState.compose env46583 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound46583 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env46584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,8323,13341,10281,1024,8661,4297,33,153,3,8328,64,2265,5392,4096,10361,1501,169,256,168,5593,648]

theorem envBound46584 : H12AffineFastState.Bounded env46584 := by
  intro p hp
  have h : env46584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46583_46584 : H12AffineEnvironment.transform 16 13341 env46583 = env46584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env46583 == env46584) = true)

theorem identity46584 : scanCanonicalize (H12AffineFastState.compose env46584 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46584 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env46585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,217,398,5392,2340,1024,216,4297,33,153,3,389,64,2265,5392,4096,2420,1501,169,256,168,5593,648]

theorem envBound46585 : H12AffineFastState.Bounded env46585 := by
  intro p hp
  have h : env46585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46584_46585 : H12AffineEnvironment.transform 12 269 env46584 = env46585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46584 == env46585) = true)

theorem identity46585 : scanCanonicalize (H12AffineFastState.compose env46585 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound46585 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env46586 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,241,5372,217,114,5356,2264,1024,216,4297,33,153,3,121,64,2265,5356,4096,2184,1057,169,252,168,5157,648]

theorem envBound46586 : H12AffineFastState.Bounded env46586 := by
  intro p hp
  have h : env46586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46585_46586 : H12AffineEnvironment.transform 7 252 env46585 = env46586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env46585 == env46586) = true)

theorem identity46586 : scanCanonicalize (H12AffineFastState.compose env46586 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound46586 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46587 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,80,114,5221,2129,1024,81,4160,33,16,3,121,64,2128,5221,4096,2049,1057,32,117,33,5157,513]

theorem envBound46587 : H12AffineFastState.Bounded env46587 := by
  intro p hp
  have h : env46587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46586_46587 : H12AffineEnvironment.transform 6 9 env46586 = env46587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46586 == env46587) = true)

theorem identity46587 : scanCanonicalize (H12AffineFastState.compose env46587 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46587 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env46588 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,34,5173,2049,1024,1,4112,33,16,3,41,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound46588 : H12AffineFastState.Bounded env46588 := by
  intro p hp
  have h : env46588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46587_46588 : H12AffineEnvironment.transform 5 16 env46587 = env46588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46587 == env46588) = true)

def env46589 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1045,0,34,1029,2049,1024,1,32,33,16,3,41,16,2048,1029,48,2049,1057,32,37,33,1045,513]

theorem envBound46589 : H12AffineFastState.Bounded env46589 := by
  intro p hp
  have h : env46589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46588_46589 : H12AffineEnvironment.transform 11 48 env46588 = env46589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46588 == env46589) = true)

def env46590 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,40,33,0,34,49,2049,52,1,32,33,16,3,41,16,2048,49,48,2049,21,32,37,33,33,513]

theorem envBound46590 : H12AffineFastState.Bounded env46590 := by
  intro p hp
  have h : env46590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46589_46590 : H12AffineEnvironment.transform 9 52 env46589 = env46590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46589 == env46590) = true)

theorem identity46590 : scanCanonicalize (H12AffineFastState.compose env46590 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound46590 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46591 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,48,40,33,0,34,49,2049,52,1,32,33,16,3,41,16,2048,49,48,2049,21,32,37,33,33,10]

theorem envBound46591 : H12AffineFastState.Bounded env46591 := by
  intro p hp
  have h : env46591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46590_46591 : H12AffineEnvironment.transform 8 11 env46590 = env46591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env46590 == env46591) = true)

def leafEnv46591 : List Nat := [2,4,8,16,32,16,9,37,11,52,2048,48,40,33,0,34,49,2049,52,1,32,33,16,3,21,41,1,16,2048,49,48,2049,21,32,37,33,4,35,33,10,1,32,0]

def active46591 : List Nat := [0,1,2,3,4,10]

def tree46591 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46591 : H12WitnessSearch.Good tree46591 := H12GlobalWitnessIndex.good

theorem leafIdentity46591 : H12AffineFastState.composeSystem env46591 rootObs = leafEnv46591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46591 rootObs == leafEnv46591) = true)

theorem terminalChecked46591 : H12PackedTerminal.terminalCheckFast leafEnv46591 active46591 tree46591 = true := by decide +kernel

def env46592 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,48,40,32,0,34,48,2049,53,1,32,33,16,3,41,16,2048,48,48,2049,20,32,37,33,32,513]

theorem envBound46592 : H12AffineFastState.Bounded env46592 := by
  intro p hp
  have h : env46592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46589_46592 : H12AffineEnvironment.transform 9 53 env46589 = env46592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46589 == env46592) = true)

theorem identity46592 : scanCanonicalize (H12AffineFastState.compose env46592 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46592 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46593 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,8,0,0,2,16,2049,21,1,0,1,16,3,9,16,2048,16,16,2049,20,0,5,1,0,513]

theorem envBound46593 : H12AffineFastState.Bounded env46593 := by
  intro p hp
  have h : env46593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46592_46593 : H12AffineEnvironment.transform 4 0 env46592 = env46593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46592 == env46593) = true)

def leafEnv46593 : List Nat := [2,4,8,16,0,16,9,5,512,21,2048,16,8,0,0,2,16,2049,21,1,0,1,16,3,20,9,1,16,2048,16,16,2049,20,0,5,1,4,3,0,513,1,0,0]

def active46593 : List Nat := [0,1,2,3,8,10]

def tree46593 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46593 : H12WitnessSearch.Good tree46593 := H12GlobalWitnessIndex.good

theorem leafIdentity46593 : H12AffineFastState.composeSystem env46593 rootObs = leafEnv46593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46593 rootObs == leafEnv46593) = true)

theorem terminalChecked46593 : H12PackedTerminal.terminalCheckFast leafEnv46593 active46593 tree46593 = true := by decide +kernel

def env46594 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1044,0,34,1028,2049,1024,1,33,33,16,3,41,16,2048,1028,49,2049,1057,32,37,33,1044,513]

theorem envBound46594 : H12AffineFastState.Bounded env46594 := by
  intro p hp
  have h : env46594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46588_46594 : H12AffineEnvironment.transform 11 49 env46588 = env46594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46588 == env46594) = true)

theorem identity46594 : scanCanonicalize (H12AffineFastState.compose env46594 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound46594 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46595 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,40,32,0,34,48,2049,52,1,33,33,16,3,41,16,2048,48,49,2049,21,32,37,33,32,513]

theorem envBound46595 : H12AffineFastState.Bounded env46595 := by
  intro p hp
  have h : env46595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46594_46595 : H12AffineEnvironment.transform 9 52 env46594 = env46595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46594 == env46595) = true)

theorem identity46595 : scanCanonicalize (H12AffineFastState.compose env46595 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound46595 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46596 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,49,40,32,0,34,48,2049,52,1,33,33,16,3,41,16,2048,48,49,2049,21,32,37,33,32,11]

theorem envBound46596 : H12AffineFastState.Bounded env46596 := by
  intro p hp
  have h : env46596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46595_46596 : H12AffineEnvironment.transform 8 10 env46595 = env46596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env46595 == env46596) = true)

def leafEnv46596 : List Nat := [2,4,8,16,32,16,9,37,10,52,2048,49,40,32,0,34,48,2049,52,1,33,33,16,3,21,41,1,16,2048,48,49,2049,21,32,37,33,4,35,32,11,1,33,0]

def active46596 : List Nat := [0,1,2,3,4,10]

def tree46596 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46596 : H12WitnessSearch.Good tree46596 := H12GlobalWitnessIndex.good

theorem leafIdentity46596 : H12AffineFastState.composeSystem env46596 rootObs = leafEnv46596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46596 rootObs == leafEnv46596) = true)

theorem terminalChecked46596 : H12PackedTerminal.terminalCheckFast leafEnv46596 active46596 tree46596 = true := by decide +kernel

def env46597 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,2101481,2175186,2175049,8328,64,2590066,46276,77955,2598355,99467,2101344,256,2199862,2172306,41821]

theorem envBound46597 : H12AffineFastState.Bounded env46597 := by
  intro p hp
  have h : env46597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46564_46597 : H12AffineEnvironment.transform 13 5377 env46564 = env46597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46564 == env46597) = true)

theorem identity46597 : scanCanonicalize (H12AffineFastState.compose env46597 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound46597 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46598 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,2097152,2101481,2142477,2142614,8328,64,2491565,46276,45404,2499596,1364,2101344,256,2101481,2139213,41821]

theorem envBound46598 : H12AffineFastState.Bounded env46598 := by
  intro p hp
  have h : env46598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46597_46598 : H12AffineEnvironment.transform 15 33247 env46597 = env46598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env46597 == env46598) = true)

theorem identity46598 : scanCanonicalize (H12AffineFastState.compose env46598 (packedSelected [1,12,15,19,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound46598 : packedSelected [1,12,15,19,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env46599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,5528,262144,1024,32769,2097152,2101481,2142477,2142614,8328,64,2363701,46276,45404,2371988,1364,2101344,256,2101481,2139213,41821]

theorem envBound46599 : H12AffineFastState.Bounded env46599 := by
  intro p hp
  have h : env46599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46598_46599 : H12AffineEnvironment.transform 16 5528 env46598 = env46599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env46598 == env46599) = true)

def env46600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,5528,262144,1024,32769,276704,272393,297453,297334,8328,64,10709,46276,45404,2420,1364,272512,256,272393,302253,41821]

theorem envBound46600 : H12AffineFastState.Bounded env46600 := by
  intro p hp
  have h : env46600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46599_46600 : H12AffineEnvironment.transform 20 276704 env46599 = env46600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276704 env46599 == env46600) = true)

theorem identity46600 : scanCanonicalize (H12AffineFastState.compose env46600 (packedSelected [3,5,8,10,21,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound46600 : packedSelected [3,5,8,10,21,28,31] rootPS < 2^1333 := by decide +kernel

def env46601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,5528,262144,1024,8660,276704,272393,272440,272547,8328,64,10709,5393,4233,2420,1364,272512,256,272393,277880,648]

theorem envBound46601 : H12AffineFastState.Bounded env46601 := by
  intro p hp
  have h : env46601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46600_46601 : H12AffineEnvironment.transform 14 8661 env46600 = env46601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env46600 == env46601) = true)

theorem identity46601 : scanCanonicalize (H12AffineFastState.compose env46601 (packedSelected [0,2,7,11,14,18,20] rootPS)) = affineNative (2^(17+1) ^^^ 10741) := by decide +kernel

theorem selectedBound46601 : packedSelected [0,2,7,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env46602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,5528,10741,1024,8660,4373,508,461,342,8328,64,10709,5393,4233,2420,1364,373,256,508,5261,648]

theorem envBound46602 : H12AffineFastState.Bounded env46602 := by
  intro p hp
  have h : env46602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46601_46602 : H12AffineEnvironment.transform 17 10741 env46601 = env46602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10741 env46601 == env46602) = true)

theorem identity46602 : scanCanonicalize (H12AffineFastState.compose env46602 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound46602 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env46603 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,8192,5341,8201,8202,5188,10281,1024,8200,4297,32,17,138,8328,64,10249,5325,4233,2216,1160,169,220,32,5261,648]

theorem envBound46603 : H12AffineFastState.Bounded env46603 := by
  intro p hp
  have h : env46603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46602_46603 : H12AffineEnvironment.transform 7 220 env46602 = env46603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env46602 == env46603) = true)

theorem identity46603 : scanCanonicalize (H12AffineFastState.compose env46603 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 209) := by decide +kernel

theorem selectedBound46603 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46604 : List Nat := [2,4,8,16,32,64,128,220,512,1024,2048,4096,209,5341,216,219,5188,2296,1024,217,4297,32,17,138,89,64,2264,5325,4233,2216,1160,169,220,32,5261,648]

theorem envBound46604 : H12AffineFastState.Bounded env46604 := by
  intro p hp
  have h : env46604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46603_46604 : H12AffineEnvironment.transform 12 209 env46603 = env46604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 209 env46603 == env46604) = true)

theorem identity46604 : scanCanonicalize (H12AffineFastState.compose env46604 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46604 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env46605 : List Nat := [2,4,8,16,32,17,128,141,512,1024,2048,4096,128,5260,137,138,5141,2217,1024,136,4248,32,17,138,8,17,2185,5276,4233,2216,1160,169,141,32,5261,648]

theorem envBound46605 : H12AffineFastState.Bounded env46605 := by
  intro p hp
  have h : env46605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46604_46605 : H12AffineEnvironment.transform 5 17 env46604 = env46605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46604 == env46605) = true)

theorem identity46605 : scanCanonicalize (H12AffineFastState.compose env46605 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound46605 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env46606 : List Nat := [2,4,8,16,32,17,128,141,136,1024,2048,4096,128,5260,137,138,5141,2217,1024,136,4248,32,17,138,8,17,2185,5276,4233,2216,1160,169,141,32,5261,0]

theorem envBound46606 : H12AffineFastState.Bounded env46606 := by
  intro p hp
  have h : env46606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46605_46606 : H12AffineEnvironment.transform 8 136 env46605 = env46606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env46605 == env46606) = true)

theorem identity46606 : scanCanonicalize (H12AffineFastState.compose env46606 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound46606 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env46607 : List Nat := [2,4,8,16,32,17,128,141,136,173,2048,4096,128,4129,137,138,4280,2217,173,136,4248,32,17,138,8,17,2185,4145,4233,2216,37,169,141,32,4128,0]

theorem envBound46607 : H12AffineFastState.Bounded env46607 := by
  intro p hp
  have h : env46607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46606_46607 : H12AffineEnvironment.transform 9 173 env46606 = env46607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env46606 == env46607) = true)

theorem identity46607 : scanCanonicalize (H12AffineFastState.compose env46607 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound46607 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env46608 : List Nat := [2,4,8,16,32,17,128,141,136,173,2048,2233,128,2200,137,138,2049,2217,173,136,2081,32,17,138,8,17,2185,2184,2096,2216,37,169,141,32,2201,0]

theorem envBound46608 : H12AffineFastState.Bounded env46608 := by
  intro p hp
  have h : env46608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46607_46608 : H12AffineEnvironment.transform 11 2233 env46607 = env46608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env46607 == env46608) = true)

theorem identity46608 : scanCanonicalize (H12AffineFastState.compose env46608 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound46608 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env46609 : List Nat := [2,4,8,16,32,17,128,141,136,173,168,17,128,48,137,138,169,1,173,136,137,32,17,138,8,17,33,32,152,0,37,169,141,32,49,0]

theorem envBound46609 : H12AffineFastState.Bounded env46609 := by
  intro p hp
  have h : env46609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46608_46609 : H12AffineEnvironment.transform 10 168 env46608 = env46609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env46608 == env46609) = true)

theorem identity46609 : scanCanonicalize (H12AffineFastState.compose env46609 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound46609 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46610 : List Nat := [2,4,8,16,16,17,128,141,136,157,152,17,128,0,137,138,153,1,157,136,137,16,17,138,8,17,17,16,152,0,21,153,141,16,1,0]

theorem envBound46610 : H12AffineFastState.Bounded env46610 := by
  intro p hp
  have h : env46610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46609_46610 : H12AffineEnvironment.transform 4 16 env46609 = env46610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env46609 == env46610) = true)

theorem identity46610 : scanCanonicalize (H12AffineFastState.compose env46610 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound46610 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env46611 : List Nat := [2,4,8,1,1,0,128,141,136,140,137,0,128,0,137,138,136,1,140,136,137,1,0,138,8,0,0,1,137,0,4,136,141,1,1,0]

theorem envBound46611 : H12AffineFastState.Bounded env46611 := by
  intro p hp
  have h : env46611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46610_46611 : H12AffineEnvironment.transform 3 1 env46610 = env46611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env46610 == env46611) = true)

theorem identity46611 : scanCanonicalize (H12AffineFastState.compose env46611 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46611 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46612 : List Nat := [2,4,8,1,1,0,8,5,0,4,1,0,8,0,1,2,0,1,4,0,1,1,0,2,8,0,0,1,1,0,4,0,5,1,1,0]

theorem envBound46612 : H12AffineFastState.Bounded env46612 := by
  intro p hp
  have h : env46612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46611_46612 : H12AffineEnvironment.transform 6 8 env46611 = env46612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46611 == env46612) = true)

theorem identity46612 : scanCanonicalize (H12AffineFastState.compose env46612 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound46612 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46613 : List Nat := [2,4,7,1,1,0,7,5,0,4,1,0,7,0,1,2,0,1,4,0,1,1,0,2,7,0,0,1,1,0,4,0,5,1,1,0]

theorem envBound46613 : H12AffineFastState.Bounded env46613 := by
  intro p hp
  have h : env46613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46612_46613 : H12AffineEnvironment.transform 2 7 env46612 = env46613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env46612 == env46613) = true)

def env46614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,5528,262144,1024,32769,276705,272392,297452,297335,8328,64,10708,46276,45404,2421,1364,272513,256,272392,302252,41821]

theorem envBound46614 : H12AffineFastState.Bounded env46614 := by
  intro p hp
  have h : env46614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46599_46614 : H12AffineEnvironment.transform 20 276705 env46599 = env46614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276705 env46599 == env46614) = true)

theorem identity46614 : scanCanonicalize (H12AffineFastState.compose env46614 (packedSelected [3,5,8,10,21,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound46614 : packedSelected [3,5,8,10,21,28,31] rootPS < 2^1333 := by decide +kernel

def env46615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,5528,10281,1024,32769,4296,33,41413,41310,8328,64,10708,46276,45404,2421,1364,168,256,33,46213,41821]

theorem envBound46615 : H12AffineFastState.Bounded env46615 := by
  intro p hp
  have h : env46615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46614_46615 : H12AffineEnvironment.transform 17 10281 env46614 = env46615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env46614 == env46615) = true)

theorem identity46615 : scanCanonicalize (H12AffineFastState.compose env46615 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound46615 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,8202,5528,10281,1024,8660,4296,33,16,139,8328,64,10708,5393,4233,2421,1364,168,256,33,5456,648]

theorem envBound46616 : H12AffineFastState.Bounded env46616 := by
  intro p hp
  have h : env46616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46615_46616 : H12AffineEnvironment.transform 14 8661 env46615 = env46616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env46615 == env46616) = true)

theorem identity46616 : scanCanonicalize (H12AffineFastState.compose env46616 (packedSelected [1,3,5,6,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46616 : packedSelected [1,3,5,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env46617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5377,509,34,5528,2049,1024,508,4296,33,16,139,160,64,2556,5393,4233,2421,1364,168,256,33,5456,648]

theorem envBound46617 : H12AffineFastState.Bounded env46617 := by
  intro p hp
  have h : env46617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46616_46617 : H12AffineEnvironment.transform 12 40 env46616 = env46617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46616 == env46617) = true)

theorem identity46617 : scanCanonicalize (H12AffineFastState.compose env46617 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound46617 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env46618 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,40,5292,80,34,5173,2049,1024,81,4296,33,16,139,160,64,2129,5308,4233,2264,1273,168,173,33,5373,648]

theorem envBound46618 : H12AffineFastState.Bounded env46618 := by
  intro p hp
  have h : env46618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46617_46618 : H12AffineEnvironment.transform 7 173 env46617 = env46618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env46617 == env46618) = true)

theorem identity46618 : scanCanonicalize (H12AffineFastState.compose env46618 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound46618 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46619 : List Nat := [2,4,8,16,32,64,128,173,512,237,2048,4096,40,4161,80,34,4312,2049,237,81,4296,33,16,139,160,64,2129,4177,4233,2264,20,168,173,33,4112,648]

theorem envBound46619 : H12AffineFastState.Bounded env46619 := by
  intro p hp
  have h : env46619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46618_46619 : H12AffineEnvironment.transform 9 237 env46618 = env46619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env46618 == env46619) = true)

def env46620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,16777216,8328,64,17227835,18973837,77955,2598355,18932163,16850984,256,16818559,16793818,18990613]

theorem envBound46620 : H12AffineFastState.Bounded env46620 := by
  intro p hp
  have h : env46620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46528_46620 : H12AffineEnvironment.transform 21 2115049 env46528 = env46620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env46528 == env46620) = true)

def env46621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2115049,2188755,2175048,8328,64,2609267,46277,77955,2598355,119179,2101344,256,2199863,2191506,63069]

theorem envBound46621 : H12AffineFastState.Bounded env46621 := by
  intro p hp
  have h : env46621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46620_46621 : H12AffineEnvironment.transform 23 2175048 env46620 = env46621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175048 env46620 == env46621) = true)

def env46622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,2101481,2175187,2175048,8328,64,2590067,46277,77955,2598355,99467,2101344,256,2199863,2172306,41821]

theorem envBound46622 : H12AffineFastState.Bounded env46622 := by
  intro p hp
  have h : env46622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46621_46622 : H12AffineEnvironment.transform 13 5376 env46621 = env46622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46621 == env46622) = true)

theorem identity46622 : scanCanonicalize (H12AffineFastState.compose env46622 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound46622 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,169,73875,73736,8328,64,496947,46277,77955,505235,99467,32,256,98679,79314,41821]

end H12CloudChart1