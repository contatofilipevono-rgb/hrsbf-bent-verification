import H12CloudChart1Data016

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env4188 : List Nat := [2,4,8,0,10,0,8,15,1,14,0,0,9,0,0,2,1,1,14,0,1,0,10,9,8,10,0,0,0,10,5,11,15,1,1,10]

theorem envBound4188 : H12AffineFastState.Bounded env4188 := by
  intro p hp
  have h : env4188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4187_4188 : H12AffineEnvironment.transform 3 0 env4187 = env4188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4187 == env4188) = true)

def env4189 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,91270,41002,8329,91271,323713,16384,16812,22561,74794,4298171,256,20480,1297,91963]

theorem envBound4189 : H12AffineFastState.Bounded env4189 := by
  intro p hp
  have h : env4189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4145_4189 : H12AffineEnvironment.transform 5 17 env4145 = env4189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4145 == env4189) = true)

theorem identity4189 : scanCanonicalize (H12AffineFastState.compose env4189 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound4189 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4190 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4525,262144,1024,32768,4097,4194304,445,41002,8329,444,323713,16384,16812,22561,16657,4255872,256,20480,1297,512]

theorem envBound4190 : H12AffineFastState.Bounded env4190 := by
  intro p hp
  have h : env4190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4189_4190 : H12AffineEnvironment.transform 15 25915 env4189 = env4190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env4189 == env4190) = true)

theorem identity4190 : scanCanonicalize (H12AffineFastState.compose env4190 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4190 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4191 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4525,262144,1024,32768,4097,41349,445,41002,8329,444,323713,16384,16812,22561,16657,20741,256,20480,1297,512]

theorem envBound4191 : H12AffineFastState.Bounded env4191 := by
  intro p hp
  have h : env4191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4190_4191 : H12AffineEnvironment.transform 21 41349 env4190 = env4191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4190 == env4191) = true)

theorem identity4191 : scanCanonicalize (H12AffineFastState.compose env4191 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29312) := by decide +kernel

theorem selectedBound4191 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4192 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29312,25915,4525,262144,1024,29312,4097,21253,445,21162,8329,444,262657,16384,16812,22561,16657,20741,256,20480,1297,512]

theorem envBound4192 : H12AffineFastState.Bounded env4192 := by
  intro p hp
  have h : env4192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4191_4192 : H12AffineEnvironment.transform 14 29312 env4191 = env4192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29312 env4191 == env4192) = true)

theorem identity4192 : scanCanonicalize (H12AffineFastState.compose env4192 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound4192 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4193 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26425,25915,1044,262144,1024,26425,1464,18108,445,18195,8329,444,262657,16384,16812,19864,16657,17596,256,17849,1297,512]

theorem envBound4193 : H12AffineFastState.Bounded env4193 := by
  intro p hp
  have h : env4193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4192_4193 : H12AffineEnvironment.transform 11 1465 env4192 = env4193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env4192 == env4193) = true)

theorem identity4193 : scanCanonicalize (H12AffineFastState.compose env4193 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound4193 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4194 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26425,25915,1044,20156,1024,26425,1464,18108,445,18195,8329,444,19645,16384,16812,19864,16657,17596,256,17849,1297,512]

theorem envBound4194 : H12AffineFastState.Bounded env4194 := by
  intro p hp
  have h : env4194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4193_4194 : H12AffineEnvironment.transform 17 20156 env4193 = env4194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env4193 == env4194) = true)

theorem identity4194 : scanCanonicalize (H12AffineFastState.compose env4194 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4194 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4195 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,1840,8201,8715,1044,2444,1024,8201,1464,396,445,35,8329,444,2957,1840,1692,2728,1569,908,256,649,1297,512]

theorem envBound4195 : H12AffineFastState.Bounded env4195 := by
  intro p hp
  have h : env4195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4194_4195 : H12AffineEnvironment.transform 13 1840 env4194 = env4195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env4194 == env4195) = true)

theorem identity4195 : scanCanonicalize (H12AffineFastState.compose env4195 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4195 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env4196 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1045,8192,1692,8201,8715,1044,2080,1024,8201,1044,32,17,35,8329,16,2593,1692,1692,2728,1569,544,172,649,1213,512]

theorem envBound4196 : H12AffineFastState.Bounded env4196 := by
  intro p hp
  have h : env4196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4195_4196 : H12AffineEnvironment.transform 7 172 env4195 = env4196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4195 == env4196) = true)

theorem identity4196 : scanCanonicalize (H12AffineFastState.compose env4196 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4196 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4197 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1551,1045,8192,1692,8201,8715,1044,1583,1024,8201,1044,32,17,35,8329,16,1070,1692,1692,1191,1569,544,172,649,1213,512]

theorem envBound4197 : H12AffineFastState.Bounded env4197 := by
  intro p hp
  have h : env4197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4196_4197 : H12AffineEnvironment.transform 10 1551 env4196 = env4197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env4196 == env4197) = true)

theorem identity4197 : scanCanonicalize (H12AffineFastState.compose env4197 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound4197 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env4198 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1551,1045,1031,1692,1038,1548,1044,1583,1024,1038,1044,32,17,35,1166,16,1070,1692,1692,1191,1569,544,172,649,1213,512]

theorem envBound4198 : H12AffineFastState.Bounded env4198 := by
  intro p hp
  have h : env4198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4197_4198 : H12AffineEnvironment.transform 12 1031 env4197 = env4198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env4197 == env4198) = true)

theorem identity4198 : scanCanonicalize (H12AffineFastState.compose env4198 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound4198 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4199 : List Nat := [2,4,8,16,32,17,128,172,169,1024,1190,1045,1031,1077,1038,1189,1044,1158,1024,1038,1044,32,17,35,1166,16,1070,1077,1077,1191,1160,137,172,32,1213,169]

theorem envBound4199 : H12AffineFastState.Bounded env4199 := by
  intro p hp
  have h : env4199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4198_4199 : H12AffineEnvironment.transform 8 169 env4198 = env4199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env4198 == env4199) = true)

theorem identity4199 : scanCanonicalize (H12AffineFastState.compose env4199 (packedSelected [2,3,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4199 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env4200 : List Nat := [2,4,8,16,27,17,128,151,146,1024,1181,1045,1031,1038,1038,1182,1044,1158,1024,1038,1044,27,17,24,1166,16,1045,1038,1038,1180,1160,137,151,27,1158,146]

theorem envBound4200 : H12AffineFastState.Bounded env4200 := by
  intro p hp
  have h : env4200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4199_4200 : H12AffineEnvironment.transform 4 27 env4199 = env4200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4199 == env4200) = true)

theorem identity4200 : scanCanonicalize (H12AffineFastState.compose env4200 (packedSelected [0,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound4200 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env4201 : List Nat := [2,4,8,16,27,17,18,5,0,1024,1039,1045,1031,1038,1038,1036,1044,1044,1024,1038,1044,27,17,24,1052,16,1045,1038,1038,1038,1050,27,5,27,1044,0]

theorem envBound4201 : H12AffineFastState.Bounded env4201 := by
  intro p hp
  have h : env4201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4200_4201 : H12AffineEnvironment.transform 6 18 env4200 = env4201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env4200 == env4201) = true)

def env4202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323793,16384,16893,22641,74795,12644669,257,20560,8479127,8389613]

theorem envBound4202 : H12AffineFastState.Bounded env4202 := by
  intro p hp
  have h : env4202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4143_4202 : H12AffineEnvironment.transform 18 1025 env4143 = env4202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4143 == env4202) = true)

theorem identity4202 : scanCanonicalize (H12AffineFastState.compose env4202 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8662) := by decide +kernel

theorem selectedBound4202 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8662,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323793,16384,16893,22641,1533,12644669,257,20560,8405057,8389613]

theorem envBound4203 : H12AffineFastState.Bounded env4203 := by
  intro p hp
  have h : env4203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4202_4203 : H12AffineEnvironment.transform 15 8662 env4202 = env4203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8662 env4202 == env4203) = true)

def env4204 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4097,4194304,8388608,41002,8329,8388609,323713,16384,16813,22561,1453,12644669,257,20480,8405009,8389565]

theorem envBound4204 : H12AffineFastState.Bounded env4204 := by
  intro p hp
  have h : env4204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4203_4204 : H12AffineEnvironment.transform 5 16 env4203 = env4204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4203 == env4204) = true)

theorem identity4204 : scanCanonicalize (H12AffineFastState.compose env4204 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4204 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4205 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4097,4194304,445,41002,8329,444,323713,16384,16813,22561,1453,4255872,257,20480,16812,512]

theorem envBound4205 : H12AffineFastState.Bounded env4205 := by
  intro p hp
  have h : env4205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4204_4205 : H12AffineEnvironment.transform 22 445 env4204 = env4205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4204 == env4205) = true)

theorem identity4205 : scanCanonicalize (H12AffineFastState.compose env4205 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4205 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4206 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1025,32768,4097,41348,445,41002,8329,444,323713,16384,16813,22561,1453,20740,257,20480,16812,512]

theorem envBound4206 : H12AffineFastState.Bounded env4206 := by
  intro p hp
  have h : env4206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4205_4206 : H12AffineEnvironment.transform 21 41348 env4205 = env4206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4205 == env4206) = true)

theorem identity4206 : scanCanonicalize (H12AffineFastState.compose env4206 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13885) := by decide +kernel

theorem selectedBound4206 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4207 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13885,8582,4524,262144,1025,13885,4097,6073,445,5655,8329,444,280252,16384,16813,22561,1453,20740,257,20480,16812,512]

theorem envBound4207 : H12AffineFastState.Bounded env4207 := by
  intro p hp
  have h : env4207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4206_4207 : H12AffineEnvironment.transform 14 13885 env4206 = env4207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13885 env4206 == env4207) = true)

theorem identity4207 : scanCanonicalize (H12AffineFastState.compose env4207 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound4207 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4208 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,13885,8582,4524,262144,1025,13885,4097,6073,445,5655,8329,444,268216,4356,4265,2341,1453,0,257,260,4264,512]

theorem envBound4208 : H12AffineFastState.Bounded env4208 := by
  intro p hp
  have h : env4208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4207_4208 : H12AffineEnvironment.transform 13 4356 env4207 = env4208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env4207 == env4208) = true)

theorem identity4208 : scanCanonicalize (H12AffineFastState.compose env4208 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4208 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env4209 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4097,13885,8323,4265,262144,1025,13885,4097,5820,184,5655,8329,185,267965,4097,4265,2080,1192,0,4,1,4264,512]

theorem envBound4209 : H12AffineFastState.Bounded env4209 := by
  intro p hp
  have h : env4209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4208_4209 : H12AffineEnvironment.transform 7 5 env4208 = env4209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4208 == env4209) = true)

theorem identity4209 : scanCanonicalize (H12AffineFastState.compose env4209 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound4209 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4210 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,4096,8192,4097,13885,8323,4265,2184,1025,13885,4097,5820,184,5655,8329,185,7733,4097,4265,2080,1192,0,4,1,4264,512]

theorem envBound4210 : H12AffineFastState.Bounded env4210 := by
  intro p hp
  have h : env4210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4209_4210 : H12AffineEnvironment.transform 17 2184 env4209 = env4210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env4209 == env4210) = true)

theorem identity4210 : scanCanonicalize (H12AffineFastState.compose env4210 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4210 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4211 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1692,8192,1693,8353,8323,1589,2184,1025,8353,1693,32,184,139,8329,185,2217,1693,1589,2080,1192,0,4,1,1588,512]

theorem envBound4211 : H12AffineFastState.Bounded env4211 := by
  intro p hp
  have h : env4211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4210_4211 : H12AffineEnvironment.transform 11 1692 env4210 = env4211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4210 == env4211) = true)

theorem identity4211 : scanCanonicalize (H12AffineFastState.compose env4211 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 19) := by decide +kernel

theorem selectedBound4211 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4212 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1692,19,1693,178,144,1589,2184,1025,178,1693,32,184,139,154,185,2217,1693,1589,2080,1192,0,4,1,1588,512]

theorem envBound4212 : H12AffineFastState.Bounded env4212 := by
  intro p hp
  have h : env4212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4211_4212 : H12AffineEnvironment.transform 12 19 env4211 = env4212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 19 env4211 == env4212) = true)

theorem identity4212 : scanCanonicalize (H12AffineFastState.compose env4212 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 691) := by decide +kernel

theorem selectedBound4212 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4213 : List Nat := [2,4,8,16,32,16,128,5,512,1024,691,1692,19,1693,178,144,1589,571,1025,178,1693,32,184,139,154,185,538,1693,1589,659,1192,0,4,1,1588,512]

theorem envBound4213 : H12AffineFastState.Bounded env4213 := by
  intro p hp
  have h : env4213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4212_4213 : H12AffineEnvironment.transform 10 691 env4212 = env4213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 691 env4212 == env4213) = true)

theorem identity4213 : scanCanonicalize (H12AffineFastState.compose env4213 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound4213 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4214 : List Nat := [2,4,8,16,32,16,18,5,512,1024,545,1550,19,1551,32,2,1589,571,1025,32,1551,32,42,25,8,43,538,1551,1589,513,1082,0,4,1,1588,512]

theorem envBound4214 : H12AffineFastState.Bounded env4214 := by
  intro p hp
  have h : env4214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4213_4214 : H12AffineEnvironment.transform 6 18 env4213 = env4214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env4213 == env4214) = true)

theorem identity4214 : scanCanonicalize (H12AffineFastState.compose env4214 (packedSelected [0,1,2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4214 : packedSelected [0,1,2,4,7] rootPS < 2^1333 := by decide +kernel

def env4215 : List Nat := [2,4,8,16,1,16,18,5,512,1024,512,1550,19,1551,1,2,1556,538,1025,1,1551,1,11,25,8,10,538,1551,1556,513,1051,0,4,1,1557,512]

theorem envBound4215 : H12AffineFastState.Bounded env4215 := by
  intro p hp
  have h : env4215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4214_4215 : H12AffineEnvironment.transform 4 1 env4214 = env4215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4214 == env4215) = true)

theorem identity4215 : scanCanonicalize (H12AffineFastState.compose env4215 (packedSelected [0,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4215 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env4216 : List Nat := [2,4,8,10,1,10,8,5,512,1024,512,1550,9,1551,1,2,1550,512,1025,1,1551,1,11,3,8,10,512,1551,1550,513,1025,0,4,1,1551,512]

theorem envBound4216 : H12AffineFastState.Bounded env4216 := by
  intro p hp
  have h : env4216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4215_4216 : H12AffineEnvironment.transform 3 10 env4215 = env4216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4215 == env4216) = true)

theorem identity4216 : scanCanonicalize (H12AffineFastState.compose env4216 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound4216 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4217 : List Nat := [2,4,8,10,1,10,8,5,10,1024,10,1028,9,1029,1,2,1028,10,1025,1,1029,1,11,3,8,10,10,1029,1028,11,1025,0,4,1,1029,10]

theorem envBound4217 : H12AffineFastState.Bounded env4217 := by
  intro p hp
  have h : env4217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4216_4217 : H12AffineEnvironment.transform 8 10 env4216 = env4217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env4216 == env4217) = true)

theorem identity4217 : scanCanonicalize (H12AffineFastState.compose env4217 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4217 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4218 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1028,2,1029,1,2,1028,1,1025,1,1029,1,0,3,3,1,1,1029,1028,0,1025,0,4,1,1029,1]

theorem envBound4218 : H12AffineFastState.Bounded env4218 := by
  intro p hp
  have h : env4218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4217_4218 : H12AffineEnvironment.transform 2 3 env4217 = env4218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4217 == env4218) = true)

def leafEnv4218 : List Nat := [2,4,3,1,1,1,3,5,1,1024,1,1028,2,1029,1,2,1028,1,1025,1,1029,1,0,3,1024,3,1,1,1,1029,1028,0,1025,0,4,1,5,2,1029,1,1,1028,0]

def active4218 : List Nat := [0,1,9]

def tree4218 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4218 : H12WitnessSearch.Good tree4218 := H12GlobalWitnessIndex.good

theorem leafIdentity4218 : H12AffineFastState.composeSystem env4218 rootObs = leafEnv4218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4218 rootObs == leafEnv4218) = true)

theorem terminalChecked4218 : H12PackedTerminal.terminalCheckFast leafEnv4218 active4218 tree4218 = true := by decide +kernel

def env4219 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1025,32768,4097,4194304,8388608,41002,8329,8388608,323712,16384,16812,22560,1452,12644669,257,20481,8405008,8389564]

theorem envBound4219 : H12AffineFastState.Bounded env4219 := by
  intro p hp
  have h : env4219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4203_4219 : H12AffineEnvironment.transform 5 17 env4203 = env4219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4203 == env4219) = true)

def env4220 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2080,1025,32768,4097,4194304,8388608,41002,8329,8388608,63648,16384,16812,22560,1452,12644669,257,20481,8405008,8389564]

theorem envBound4220 : H12AffineFastState.Bounded env4220 := by
  intro p hp
  have h : env4220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4219_4220 : H12AffineEnvironment.transform 17 2080 env4219 = env4220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4219 == env4220) = true)

theorem identity4220 : scanCanonicalize (H12AffineFastState.compose env4220 (packedSelected [0,4,5,7,8,10,11,13,17,22,24,26,28,32] rootPS)) = affineNative (2^(22+1) ^^^ 4214833) := by decide +kernel

theorem selectedBound4220 : packedSelected [0,4,5,7,8,10,11,13,17,22,24,26,28,32] rootPS < 2^1333 := by decide +kernel

def env4221 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2080,1025,32768,4097,4194304,4214833,41002,8329,4214833,63648,16384,16812,22560,1452,41228,257,20481,4198433,4215693]

theorem envBound4221 : H12AffineFastState.Bounded env4221 := by
  intro p hp
  have h : env4221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4220_4221 : H12AffineEnvironment.transform 22 4214833 env4220 = env4221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4214833 env4220 == env4221) = true)

theorem identity4221 : scanCanonicalize (H12AffineFastState.compose env4221 (packedSelected [0,2,3,5,6,11,12,20,21,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4221 : packedSelected [0,2,3,5,6,11,12,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4222 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,16384,32768,8234,4096,2080,1025,32768,4097,4194304,4214833,41002,8329,4214833,63648,16384,16385,22560,1025,41121,172,20481,4198433,4215328]

theorem envBound4222 : H12AffineFastState.Bounded env4222 := by
  intro p hp
  have h : env4222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4221_4222 : H12AffineEnvironment.transform 7 173 env4221 = env4222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4221 == env4222) = true)

theorem identity4222 : scanCanonicalize (H12AffineFastState.compose env4222 (packedSelected [2,4,5,6,7,15,21,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 4096) := by decide +kernel

theorem selectedBound4222 : packedSelected [2,4,5,6,7,15,21,23,24] rootPS < 2^1333 := by decide +kernel

def env4223 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,32768,8234,4096,2080,1025,32768,4097,4194304,4194353,41002,8329,4194353,43168,4096,4097,2080,1025,41121,172,1,4198433,4194848]

theorem envBound4223 : H12AffineFastState.Bounded env4223 := by
  intro p hp
  have h : env4223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4222_4223 : H12AffineEnvironment.transform 13 4096 env4222 = env4223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env4222 == env4223) = true)

theorem identity4223 : scanCanonicalize (H12AffineFastState.compose env4223 (packedSelected [4,9,20] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4223 : packedSelected [4,9,20] rootPS < 2^1333 := by decide +kernel

def env4224 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4096,8201,8234,4096,2080,1025,8201,4097,4194304,4194353,35,8329,4194353,2217,4096,4097,2080,1025,168,172,1,4198433,4194848]

theorem envBound4224 : H12AffineFastState.Bounded env4224 := by
  intro p hp
  have h : env4224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4223_4224 : H12AffineEnvironment.transform 14 8201 env4223 = env4224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4223 == env4224) = true)

theorem identity4224 : scanCanonicalize (H12AffineFastState.compose env4224 (packedSelected [3,4,5,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2600) := by decide +kernel

theorem selectedBound4224 : packedSelected [3,4,5,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4225 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,2600,4096,2593,2562,4096,2080,1025,2593,4097,4194304,4194353,35,2721,4194353,2217,4096,4097,2080,1025,168,172,1,4198433,4194848]

theorem envBound4225 : H12AffineFastState.Bounded env4225 := by
  intro p hp
  have h : env4225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4224_4225 : H12AffineEnvironment.transform 12 2600 env4224 = env4225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2600 env4224 == env4225) = true)

theorem identity4225 : scanCanonicalize (H12AffineFastState.compose env4225 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4225 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env4226 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1589,2600,1589,2593,2562,1589,2080,1025,2593,1588,4194304,4194353,35,2721,4194353,2217,1589,1588,2080,1025,168,172,1,4195860,4194848]

theorem envBound4226 : H12AffineFastState.Bounded env4226 := by
  intro p hp
  have h : env4226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4225_4226 : H12AffineEnvironment.transform 11 1589 env4225 = env4226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env4225 == env4226) = true)

def env4227 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1589,2600,1589,2593,2562,1589,2080,1025,2593,1588,4194304,4194353,35,2569,4194353,2049,1589,1588,2080,1025,0,4,1,4195860,4194848]

theorem envBound4227 : H12AffineFastState.Bounded env4227 := by
  intro p hp
  have h : env4227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4226_4227 : H12AffineEnvironment.transform 6 40 env4226 = env4227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4226 == env4227) = true)

theorem identity4227 : scanCanonicalize (H12AffineFastState.compose env4227 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound4227 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4228 : List Nat := [2,4,8,16,17,17,25,5,512,1024,2048,1540,2585,1540,2576,2562,1540,2065,1025,2576,1541,4194304,4194304,18,2569,4194304,2049,1540,1541,2065,1025,0,4,1,4195860,4194833]

theorem envBound4228 : H12AffineFastState.Bounded env4228 := by
  intro p hp
  have h : env4228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4227_4228 : H12AffineEnvironment.transform 4 17 env4227 = env4228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env4227 == env4228) = true)

theorem identity4228 : scanCanonicalize (H12AffineFastState.compose env4228 (packedSelected [0,4] rootPS)) = affineNative (2^(21+1) ^^^ 2587) := by decide +kernel

theorem selectedBound4228 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4229 : List Nat := [2,4,8,16,17,17,25,5,512,1024,2048,1540,2585,1540,2576,2562,1540,2065,1025,2576,1541,2587,2587,18,2569,2587,2049,1540,1541,2065,1025,0,4,1,3087,2058]

theorem envBound4229 : H12AffineFastState.Bounded env4229 := by
  intro p hp
  have h : env4229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4228_4229 : H12AffineEnvironment.transform 21 2587 env4228 = env4229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2587 env4228 == env4229) = true)

theorem identity4229 : scanCanonicalize (H12AffineFastState.compose env4229 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound4229 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4230 : List Nat := [2,4,8,16,17,17,25,5,512,1024,513,1540,24,1540,17,3,1540,528,1025,17,1541,26,26,18,8,26,512,1540,1541,528,1025,0,4,1,1550,523]

theorem envBound4230 : H12AffineFastState.Bounded env4230 := by
  intro p hp
  have h : env4230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4229_4230 : H12AffineEnvironment.transform 10 513 env4229 = env4230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env4229 == env4230) = true)

theorem identity4230 : scanCanonicalize (H12AffineFastState.compose env4230 (packedSelected [0,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4230 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4231 : List Nat := [2,4,8,11,10,10,2,5,512,1024,513,1540,3,1540,10,3,1540,523,1025,10,1541,1,1,9,8,1,512,1540,1541,523,1025,0,4,1,1550,523]

theorem envBound4231 : H12AffineFastState.Bounded env4231 := by
  intro p hp
  have h : env4231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4230_4231 : H12AffineEnvironment.transform 3 11 env4230 = env4231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4230 == env4231) = true)

theorem identity4231 : scanCanonicalize (H12AffineFastState.compose env4231 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4232 : List Nat := [2,4,3,0,1,1,2,5,512,1024,513,1540,3,1540,1,3,1540,512,1025,1,1541,1,1,2,3,1,512,1540,1541,512,1025,0,4,1,1541,512]

theorem envBound4232 : H12AffineFastState.Bounded env4232 := by
  intro p hp
  have h : env4232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4231_4232 : H12AffineEnvironment.transform 2 3 env4231 = env4232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4231 == env4232) = true)

theorem identity4232 : scanCanonicalize (H12AffineFastState.compose env4232 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4232 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4233 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1029,3,1029,1,3,1029,1,1025,1,1028,1,1,2,3,1,1,1029,1028,1,1025,0,4,1,1028,1]

theorem envBound4233 : H12AffineFastState.Bounded env4233 := by
  intro p hp
  have h : env4233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4232_4233 : H12AffineEnvironment.transform 8 1 env4232 = env4233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4232 == env4233) = true)

def leafEnv4233 : List Nat := [2,4,3,0,1,1,2,5,1,1024,0,1029,3,1029,1,3,1029,1,1025,1,1028,1,1,2,1024,3,1,1,1,1029,1028,1,1025,0,4,1,5,2,1028,1,1,1028,0]

def active4233 : List Nat := [0,1,9]

def tree4233 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4233 : H12WitnessSearch.Good tree4233 := H12GlobalWitnessIndex.good

theorem leafIdentity4233 : H12AffineFastState.composeSystem env4233 rootObs = leafEnv4233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4233 rootObs == leafEnv4233) = true)

theorem terminalChecked4233 : H12PackedTerminal.terminalCheckFast leafEnv4233 active4233 tree4233 = true := by decide +kernel

def env4234 : List Nat := [2,4,8,16,32,17,41,4,512,1024,2048,1589,2600,1589,2593,2562,1589,2080,1025,2593,1588,4194304,4194353,35,2568,4194353,2048,1589,1588,2080,1025,1,5,1,4195860,4194848]

theorem envBound4234 : H12AffineFastState.Bounded env4234 := by
  intro p hp
  have h : env4234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4226_4234 : H12AffineEnvironment.transform 6 41 env4226 = env4234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4226 == env4234) = true)

theorem identity4234 : scanCanonicalize (H12AffineFastState.compose env4234 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4234 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4235 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,1589,1063,1589,1070,1037,1589,1583,1025,1070,1588,4194304,4194353,35,1031,4194353,1551,1589,1588,1583,1025,1,5,1,4195860,4194848]

theorem envBound4235 : H12AffineFastState.Bounded env4235 := by
  intro p hp
  have h : env4235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4234_4235 : H12AffineEnvironment.transform 10 1551 env4234 = env4235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env4234 == env4235) = true)

theorem identity4235 : scanCanonicalize (H12AffineFastState.compose env4235 (packedSelected [2,11] rootPS)) = affineNative (2^(21+1) ^^^ 544) := by decide +kernel

theorem selectedBound4235 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env4236 : List Nat := [2,4,8,16,32,17,41,4,512,1024,1551,1589,1063,1589,1070,1037,1589,1583,1025,1070,1588,544,529,35,1031,529,1551,1589,1588,1583,1025,1,5,1,1076,0]

theorem envBound4236 : H12AffineFastState.Bounded env4236 := by
  intro p hp
  have h : env4236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4235_4236 : H12AffineEnvironment.transform 21 544 env4235 = env4236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 544 env4235 == env4236) = true)

theorem identity4236 : scanCanonicalize (H12AffineFastState.compose env4236 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound4236 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4237 : List Nat := [2,4,8,16,32,17,41,4,512,52,571,513,19,513,26,57,513,539,53,26,512,544,529,35,51,529,571,513,512,539,53,1,5,1,0,0]

theorem envBound4237 : H12AffineFastState.Bounded env4237 := by
  intro p hp
  have h : env4237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4236_4237 : H12AffineEnvironment.transform 9 52 env4236 = env4237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env4236 == env4237) = true)

def env4238 : List Nat := [2,4,8,16,32,17,41,4,0,52,59,1,19,1,26,57,1,27,53,26,0,32,17,35,51,17,59,1,0,27,53,1,5,1,0,0]

theorem envBound4238 : H12AffineFastState.Bounded env4238 := by
  intro p hp
  have h : env4238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4237_4238 : H12AffineEnvironment.transform 8 0 env4237 = env4238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4237 == env4238) = true)

theorem identity4238 : scanCanonicalize (H12AffineFastState.compose env4238 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4238 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4239 : List Nat := [2,4,8,11,32,10,41,4,0,47,32,1,8,1,1,34,1,0,46,1,0,32,10,35,40,10,32,1,0,0,46,1,5,1,0,0]

theorem envBound4239 : H12AffineFastState.Bounded env4239 := by
  intro p hp
  have h : env4239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4238_4239 : H12AffineEnvironment.transform 3 11 env4238 = env4239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4238 == env4239) = true)

def env4240 : List Nat := [2,4,8,16,32,17,41,4,1,52,58,0,19,0,26,57,0,26,53,26,1,33,16,35,51,16,58,0,1,26,53,1,5,1,0,0]

theorem envBound4240 : H12AffineFastState.Bounded env4240 := by
  intro p hp
  have h : env4240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4237_4240 : H12AffineEnvironment.transform 8 1 env4237 = env4240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4237 == env4240) = true)

theorem identity4240 : scanCanonicalize (H12AffineFastState.compose env4240 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound4240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4241 : List Nat := [2,4,8,16,14,17,7,4,1,26,20,0,19,0,26,23,0,26,27,26,1,15,16,13,29,16,20,0,1,26,27,1,5,1,0,0]

theorem envBound4241 : H12AffineFastState.Bounded env4241 := by
  intro p hp
  have h : env4241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4240_4241 : H12AffineEnvironment.transform 4 14 env4240 = env4241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env4240 == env4241) = true)

theorem identity4241 : scanCanonicalize (H12AffineFastState.compose env4241 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound4241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4242 : List Nat := [2,4,8,4,14,5,7,4,1,14,0,0,7,0,14,3,0,14,15,14,1,15,4,13,9,4,0,0,1,14,15,1,5,1,0,0]

theorem envBound4242 : H12AffineFastState.Bounded env4242 := by
  intro p hp
  have h : env4242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4241_4242 : H12AffineEnvironment.transform 3 4 env4241 = env4242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env4241 == env4242) = true)

theorem identity4242 : scanCanonicalize (H12AffineFastState.compose env4242 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4242 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4243 : List Nat := [2,0,8,0,10,1,3,0,1,10,0,0,3,0,10,3,0,10,11,10,1,11,0,9,9,0,0,0,1,10,11,1,1,1,0,0]

theorem envBound4243 : H12AffineFastState.Bounded env4243 := by
  intro p hp
  have h : env4243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4242_4243 : H12AffineEnvironment.transform 1 0 env4242 = env4243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4242 == env4243) = true)

def leafEnv4243 : List Nat := [2,0,8,0,10,1,3,0,1,10,0,0,3,0,10,3,0,10,11,10,1,11,0,9,10,9,1,0,0,0,1,10,11,1,1,1,1,9,0,0,1,1,0]

def active4243 : List Nat := [0,2]

def tree4243 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4243 : H12WitnessSearch.Good tree4243 := H12GlobalWitnessIndex.good

theorem leafIdentity4243 : H12AffineFastState.composeSystem env4243 rootObs = leafEnv4243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4243 rootObs == leafEnv4243) = true)

theorem terminalChecked4243 : H12PackedTerminal.terminalCheckFast leafEnv4243 active4243 tree4243 = true := by decide +kernel

def env4244 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2081,1025,32768,4097,4194304,8388608,41002,8329,8388608,63649,16384,16812,22560,1452,12644669,257,20481,8405008,8389564]

theorem envBound4244 : H12AffineFastState.Bounded env4244 := by
  intro p hp
  have h : env4244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4219_4244 : H12AffineEnvironment.transform 17 2081 env4219 = env4244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4219 == env4244) = true)

theorem identity4244 : scanCanonicalize (H12AffineFastState.compose env4244 (packedSelected [1,5,7,8,18,20,23,24,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235668) := by decide +kernel

theorem selectedBound4244 : packedSelected [1,5,7,8,18,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env4245 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2081,1025,32768,4097,4194304,4235668,41002,8329,4235668,63649,16384,16812,22560,1452,20649,257,20481,4252036,4235816]

theorem envBound4245 : H12AffineFastState.Bounded env4245 := by
  intro p hp
  have h : env4245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4244_4245 : H12AffineEnvironment.transform 22 4235668 env4244 = env4245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235668 env4244 == env4245) = true)

theorem identity4245 : scanCanonicalize (H12AffineFastState.compose env4245 (packedSelected [0,4,7,17,18,21,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound4245 : packedSelected [0,4,7,17,18,21,22,23] rootPS < 2^1333 := by decide +kernel

def env4246 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,2081,1025,32768,4097,293,41137,41002,8329,41137,63649,16384,16812,22560,1452,20649,257,20481,57505,41741]

theorem envBound4246 : H12AffineFastState.Bounded env4246 := by
  intro p hp
  have h : env4246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4245_4246 : H12AffineEnvironment.transform 21 293 env4245 = env4246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env4245 == env4246) = true)

theorem identity4246 : scanCanonicalize (H12AffineFastState.compose env4246 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4246 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4247 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13884,8583,4525,2081,1025,13884,4097,293,5773,5654,8329,5773,20125,16384,16812,22560,1452,20649,257,20481,22173,5425]

theorem envBound4247 : H12AffineFastState.Bounded env4247 := by
  intro p hp
  have h : env4247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4246_4247 : H12AffineEnvironment.transform 14 13884 env4246 = env4247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4246 == env4247) = true)

theorem identity4247 : scanCanonicalize (H12AffineFastState.compose env4247 (packedSelected [0,1,3,4,7,9,13,17,24,28] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4247 : packedSelected [0,1,3,4,7,9,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env4248 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,13884,8495,4357,2081,1025,13884,4097,293,5669,5654,8225,5669,20021,16384,16644,22560,1284,20481,257,20481,22069,5425]

theorem envBound4248 : H12AffineFastState.Bounded env4248 := by
  intro p hp
  have h : env4248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4247_4248 : H12AffineEnvironment.transform 6 40 env4247 = env4248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4247 == env4248) = true)

theorem identity4248 : scanCanonicalize (H12AffineFastState.compose env4248 (packedSelected [1,2,3,4,6,9,12,13] rootPS)) = affineNative (2^(9+1) ^^^ 779) := by decide +kernel

theorem selectedBound4248 : packedSelected [1,2,3,4,6,9,12,13] rootPS < 2^1333 := by decide +kernel

def env4249 : List Nat := [2,4,8,16,32,17,40,256,512,779,2048,4096,8192,16384,12599,8495,4357,2081,778,12599,4097,293,4398,4381,8225,4398,18750,16384,16644,22560,527,20481,257,20481,20798,4666]

theorem envBound4249 : H12AffineFastState.Bounded env4249 := by
  intro p hp
  have h : env4249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4248_4249 : H12AffineEnvironment.transform 9 779 env4248 = env4249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 779 env4248 == env4249) = true)

theorem identity4249 : scanCanonicalize (H12AffineFastState.compose env4249 (packedSelected [0,1,2,3,6,7,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 319) := by decide +kernel

theorem selectedBound4249 : packedSelected [0,1,2,3,6,7,12,17] rootPS < 2^1333 := by decide +kernel

def env4250 : List Nat := [2,4,8,16,32,17,40,256,512,779,2048,319,8192,16384,8200,8495,58,2081,778,8200,318,293,17,34,8225,17,18750,16384,16644,18719,527,16702,257,16702,16385,773]

theorem envBound4250 : H12AffineFastState.Bounded env4250 := by
  intro p hp
  have h : env4250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4249_4250 : H12AffineEnvironment.transform 11 319 env4249 = env4250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 319 env4249 == env4250) = true)

theorem identity4250 : scanCanonicalize (H12AffineFastState.compose env4250 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound4250 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4251 : List Nat := [2,4,8,16,26,17,18,256,512,779,2048,261,8192,16384,8200,8469,0,2075,778,8200,260,287,17,24,8219,17,18692,16384,16644,18719,527,16644,257,16644,16385,773]

theorem envBound4251 : H12AffineFastState.Bounded env4251 := by
  intro p hp
  have h : env4251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4250_4251 : H12AffineEnvironment.transform 4 26 env4250 = env4251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env4250 == env4251) = true)

theorem identity4251 : scanCanonicalize (H12AffineFastState.compose env4251 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound4251 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4252 : List Nat := [2,4,8,16,26,17,18,256,512,779,2048,261,8192,2048,8200,8469,0,2075,778,8200,260,287,17,24,8219,17,260,2048,2308,287,527,2308,257,2308,2049,773]

theorem envBound4252 : H12AffineFastState.Bounded env4252 := by
  intro p hp
  have h : env4252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4251_4252 : H12AffineEnvironment.transform 13 2048 env4251 = env4252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env4251 == env4252) = true)

theorem identity4252 : scanCanonicalize (H12AffineFastState.compose env4252 (packedSelected [1,8] rootPS)) = affineNative (2^(12+1) ^^^ 520) := by decide +kernel

theorem selectedBound4252 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env4253 : List Nat := [2,4,8,16,26,17,18,256,512,779,2048,261,520,2048,512,797,0,2075,778,512,260,287,17,24,531,17,260,2048,2308,287,527,2308,257,2308,2049,773]

theorem envBound4253 : H12AffineFastState.Bounded env4253 := by
  intro p hp
  have h : env4253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4252_4253 : H12AffineEnvironment.transform 12 520 env4252 = env4253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 520 env4252 == env4253) = true)

theorem identity4253 : scanCanonicalize (H12AffineFastState.compose env4253 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound4253 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4254 : List Nat := [2,4,8,16,26,17,18,256,512,779,0,261,520,0,512,797,0,27,778,512,260,287,17,24,531,17,260,0,260,287,527,260,257,260,1,773]

theorem envBound4254 : H12AffineFastState.Bounded env4254 := by
  intro p hp
  have h : env4254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4253_4254 : H12AffineEnvironment.transform 10 0 env4253 = env4254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env4253 == env4254) = true)

theorem identity4254 : scanCanonicalize (H12AffineFastState.compose env4254 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4254 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4255 : List Nat := [2,4,8,16,26,17,18,4,512,527,0,1,520,0,512,537,0,27,526,512,0,27,17,24,531,17,0,0,0,27,527,0,5,0,1,513]

theorem envBound4255 : H12AffineFastState.Bounded env4255 := by
  intro p hp
  have h : env4255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4254_4255 : H12AffineEnvironment.transform 7 4 env4254 = env4255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4254 == env4255) = true)

theorem identity4255 : scanCanonicalize (H12AffineFastState.compose env4255 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4255 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4256 : List Nat := [2,4,6,16,20,17,18,4,512,513,0,1,518,0,512,535,0,21,512,512,0,21,17,22,531,17,0,0,0,21,513,0,5,0,1,513]

theorem envBound4256 : H12AffineFastState.Bounded env4256 := by
  intro p hp
  have h : env4256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4255_4256 : H12AffineEnvironment.transform 2 6 env4255 = env4256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4255 == env4256) = true)

theorem identity4256 : scanCanonicalize (H12AffineFastState.compose env4256 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound4256 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4257 : List Nat := [2,4,6,4,0,5,6,4,512,513,0,1,518,0,512,515,0,1,512,512,0,1,5,2,519,5,0,0,0,1,513,0,5,0,1,513]

theorem envBound4257 : H12AffineFastState.Bounded env4257 := by
  intro p hp
  have h : env4257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4256_4257 : H12AffineEnvironment.transform 3 4 env4256 = env4257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env4256 == env4257) = true)

theorem identity4257 : scanCanonicalize (H12AffineFastState.compose env4257 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4257 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4258 : List Nat := [2,4,6,4,0,5,6,4,0,1,0,1,6,0,0,3,0,1,0,0,0,1,5,2,7,5,0,0,0,1,1,0,5,0,1,1]

theorem envBound4258 : H12AffineFastState.Bounded env4258 := by
  intro p hp
  have h : env4258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4257_4258 : H12AffineEnvironment.transform 8 0 env4257 = env4258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4257 == env4258) = true)

def env4259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849104,16385,16892,547952,598058,12644669,525568,545873,8479127,8914924]

theorem envBound4259 : H12AffineFastState.Bounded env4259 := by
  intro p hp
  have h : env4259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4142_4259 : H12AffineEnvironment.transform 27 16385 env4142 = env4259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env4142 == env4259) = true)

def env4260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323792,16385,16892,22640,74794,12644669,256,20561,8479127,8389612]

theorem envBound4260 : H12AffineFastState.Bounded env4260 := by
  intro p hp
  have h : env4260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4259_4260 : H12AffineEnvironment.transform 18 1024 env4259 = env4260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4259 == env4260) = true)

theorem identity4260 : scanCanonicalize (H12AffineFastState.compose env4260 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115782) := by decide +kernel

theorem selectedBound4260 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,115782,8388608,41002,8329,8388688,323792,16385,16892,22640,74794,8467835,256,20561,8479127,8389612]

theorem envBound4261 : H12AffineFastState.Bounded env4261 := by
  intro p hp
  have h : env4261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4260_4261 : H12AffineEnvironment.transform 21 115782 env4260 = env4261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115782 env4260 == env4261) = true)

def env4262 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115734,8388608,41002,8329,8388608,323712,16385,16812,22560,74794,8467755,256,20481,8479127,8389564]

theorem envBound4262 : H12AffineFastState.Bounded env4262 := by
  intro p hp
  have h : env4262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4261_4262 : H12AffineEnvironment.transform 5 16 env4261 = env4262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4261 == env4262) = true)

theorem identity4262 : scanCanonicalize (H12AffineFastState.compose env4262 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4262 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4263 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,115734,444,41002,8329,444,323712,16385,16812,22560,74794,78999,256,20481,90155,512]

theorem envBound4263 : H12AffineFastState.Bounded env4263 := by
  intro p hp
  have h : env4263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4262_4263 : H12AffineEnvironment.transform 22 444 env4262 = env4263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4262 == env4263) = true)

theorem identity4263 : scanCanonicalize (H12AffineFastState.compose env4263 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 26002) := by decide +kernel

theorem selectedBound4263 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4264 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1024,32768,4097,41348,444,41002,8329,444,323712,16385,16812,22560,16824,20741,256,20481,1465,512]

theorem envBound4264 : H12AffineFastState.Bounded env4264 := by
  intro p hp
  have h : env4264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4263_4264 : H12AffineEnvironment.transform 15 26002 env4263 = env4264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26002 env4263 == env4264) = true)

theorem identity4264 : scanCanonicalize (H12AffineFastState.compose env4264 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4264 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4265 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26002,4524,262144,1024,29225,4097,21421,444,20995,8329,444,262825,16385,16812,22560,16824,20741,256,20481,1465,512]

theorem envBound4265 : H12AffineFastState.Bounded env4265 := by
  intro p hp
  have h : env4265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4264_4265 : H12AffineEnvironment.transform 14 29225 env4264 = env4265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4264 == env4265) = true)

theorem identity4265 : scanCanonicalize (H12AffineFastState.compose env4265 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound4265 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4266 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26002,1213,262144,1024,26424,1296,18108,444,18194,8329,444,262825,16385,16812,19761,16824,17428,256,17680,1465,512]

theorem envBound4266 : H12AffineFastState.Bounded env4266 := by
  intro p hp
  have h : env4266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4265_4266 : H12AffineEnvironment.transform 11 1297 env4265 = env4266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4265 == env4266) = true)

theorem identity4266 : scanCanonicalize (H12AffineFastState.compose env4266 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4266 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4267 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,1297,8192,16384,26424,25914,1045,262144,1024,26424,1296,17940,276,18194,8225,276,262657,16385,16644,19761,16656,17428,256,17680,1297,512]

theorem envBound4267 : H12AffineFastState.Bounded env4267 := by
  intro p hp
  have h : env4267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4266_4267 : H12AffineEnvironment.transform 6 40 env4266 = env4267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4266 == env4267) = true)

def env4268 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115735,8388608,41002,8329,8388609,323713,16385,16813,22561,74794,8467754,256,20480,8479127,8389565]

theorem envBound4268 : H12AffineFastState.Bounded env4268 := by
  intro p hp
  have h : env4268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4261_4268 : H12AffineEnvironment.transform 5 17 env4261 = env4268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4261 == env4268) = true)

def env4269 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115735,5376,41002,8329,5377,323713,16385,16813,22561,74794,73770,256,20480,95383,5821]

theorem envBound4269 : H12AffineFastState.Bounded env4269 := by
  intro p hp
  have h : env4269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4268_4269 : H12AffineEnvironment.transform 22 5376 env4268 = env4269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5376 env4268 == env4269) = true)

theorem identity4269 : scanCanonicalize (H12AffineFastState.compose env4269 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 28680) := by decide +kernel

theorem selectedBound4269 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4270 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,28680,65536,4525,262144,1024,28680,4097,78879,5376,20514,8329,5377,262281,16385,16813,22561,74794,73770,256,20480,95383,5821]

theorem envBound4270 : H12AffineFastState.Bounded env4270 := by
  intro p hp
  have h : env4270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4269_4270 : H12AffineEnvironment.transform 14 28680 env4269 = env4270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28680 env4269 == env4270) = true)

theorem identity4270 : scanCanonicalize (H12AffineFastState.compose env4270 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound4270 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env4271 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,25781,65536,1296,262144,1024,25781,1212,73890,445,17567,8329,444,262281,16385,16813,19612,74794,73770,256,17597,90154,512]

theorem envBound4271 : H12AffineFastState.Bounded env4271 := by
  intro p hp
  have h : env4271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4270_4271 : H12AffineEnvironment.transform 11 1213 env4270 = env4271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env4270 == env4271) = true)

theorem identity4271 : scanCanonicalize (H12AffineFastState.compose env4271 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4271 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4272 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,8192,16384,25781,65536,1213,262144,1024,25781,1212,73890,16,17567,8329,17,262281,16385,16384,19612,74794,73770,173,17597,90154,512]

theorem envBound4272 : H12AffineFastState.Bounded env4272 := by
  intro p hp
  have h : env4272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4271_4272 : H12AffineEnvironment.transform 7 173 env4271 = env4272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4271 == env4272) = true)

theorem identity4272 : scanCanonicalize (H12AffineFastState.compose env4272 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 3222) := by decide +kernel

theorem selectedBound4272 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4273 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,8192,3222,10275,65536,1213,262144,1024,10275,1212,73890,16,2057,8329,17,262281,3223,3222,10,74794,73770,173,2091,76988,512]

theorem envBound4273 : H12AffineFastState.Bounded env4273 := by
  intro p hp
  have h : env4273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4272_4273 : H12AffineEnvironment.transform 13 3222 env4272 = env4273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3222 env4272 == env4273) = true)

theorem identity4273 : scanCanonicalize (H12AffineFastState.compose env4273 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 178) := by decide +kernel

theorem selectedBound4273 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4274 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,1213,8192,3222,10275,65536,1213,178,1024,10275,1212,73890,16,2057,8329,17,59,3223,3222,10,74794,73770,173,2091,76988,512]

theorem envBound4274 : H12AffineFastState.Bounded env4274 := by
  intro p hp
  have h : env4274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4273_4274 : H12AffineEnvironment.transform 17 178 env4273 = env4274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 178 env4273 == env4274) = true)

theorem identity4274 : scanCanonicalize (H12AffineFastState.compose env4274 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4274 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4275 : List Nat := [2,4,8,16,32,17,128,173,32,1024,2048,1213,8192,3222,10275,65536,1213,178,1024,10275,1212,73890,16,2057,8329,17,59,3223,3222,10,74794,73770,173,2091,76988,32]

theorem envBound4275 : H12AffineFastState.Bounded env4275 := by
  intro p hp
  have h : env4275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4274_4275 : H12AffineEnvironment.transform 8 32 env4274 = env4275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4274 == env4275) = true)

theorem identity4275 : scanCanonicalize (H12AffineFastState.compose env4275 (packedSelected [13,21] rootPS)) = affineNative (2^(15+1) ^^^ 10408) := by decide +kernel

theorem selectedBound4275 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4276 : List Nat := [2,4,8,16,32,17,128,173,32,1024,2048,1213,8192,3222,10275,10408,1213,178,1024,10275,1212,2058,16,2057,8329,17,59,3223,3222,10,3202,2178,173,2091,1044,32]

theorem envBound4276 : H12AffineFastState.Bounded env4276 := by
  intro p hp
  have h : env4276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4275_4276 : H12AffineEnvironment.transform 15 10408 env4275 = env4276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10408 env4275 == env4276) = true)

theorem identity4276 : scanCanonicalize (H12AffineFastState.compose env4276 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound4276 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4277 : List Nat := [2,4,8,16,32,17,128,173,32,1024,59,1213,8192,1197,8216,8339,1213,178,1024,8216,1212,49,16,50,8329,17,59,1196,1197,10,1209,185,173,16,1044,32]

theorem envBound4277 : H12AffineFastState.Bounded env4277 := by
  intro p hp
  have h : env4277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4276_4277 : H12AffineEnvironment.transform 10 59 env4276 = env4277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env4276 == env4277) = true)

def env4278 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,115735,5377,41002,8329,5376,323713,16385,16813,22561,74794,73771,256,20480,95382,5820]

theorem envBound4278 : H12AffineFastState.Bounded env4278 := by
  intro p hp
  have h : env4278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4268_4278 : H12AffineEnvironment.transform 22 5377 env4268 = env4278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5377 env4268 == env4278) = true)

theorem identity4278 : scanCanonicalize (H12AffineFastState.compose env4278 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4278 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env4279 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4097,115735,5377,41002,8225,5376,323625,16385,16645,22561,74794,73771,256,20480,95294,5652]

theorem envBound4279 : H12AffineFastState.Bounded env4279 := by
  intro p hp
  have h : env4279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4278_4279 : H12AffineEnvironment.transform 6 40 env4278 = env4279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4278 == env4279) = true)

theorem identity4279 : scanCanonicalize (H12AffineFastState.compose env4279 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4279 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env4280 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8201,65536,4357,262144,1024,8201,4097,91166,5377,35,8225,5376,282656,16385,16645,22561,74794,73771,256,20480,95294,5652]

theorem envBound4280 : H12AffineFastState.Bounded env4280 := by
  intro p hp
  have h : env4280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4279_4280 : H12AffineEnvironment.transform 14 8201 env4279 = env4280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4279 == env4280) = true)

theorem identity4280 : scanCanonicalize (H12AffineFastState.compose env4280 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4280 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4281 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8201,65536,4357,2080,1024,8201,4097,91166,5377,35,8225,5376,22528,16385,16645,22561,74794,73771,256,20480,95294,5652]

theorem envBound4281 : H12AffineFastState.Bounded env4281 := by
  intro p hp
  have h : env4281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4280_4281 : H12AffineEnvironment.transform 17 2080 env4280 = env4281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4280 == env4281) = true)

theorem identity4281 : scanCanonicalize (H12AffineFastState.compose env4281 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4128) := by decide +kernel

theorem selectedBound4281 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env4282 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4128,8201,65536,4357,2080,1024,8201,4097,78910,5377,35,8225,5376,2080,4129,4389,2049,74794,73771,256,32,74782,5652]

theorem envBound4282 : H12AffineFastState.Bounded env4282 := by
  intro p hp
  have h : env4282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4281_4282 : H12AffineEnvironment.transform 13 4128 env4281 = env4282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4128 env4281 == env4282) = true)

theorem identity4282 : scanCanonicalize (H12AffineFastState.compose env4282 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2342) := by decide +kernel

theorem selectedBound4282 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env4283 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4128,8201,2342,4357,2080,1024,8201,4097,15640,5377,35,8225,5376,2080,4129,4389,2049,11532,10509,256,32,11576,5652]

theorem envBound4283 : H12AffineFastState.Bounded env4283 := by
  intro p hp
  have h : env4283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4282_4283 : H12AffineEnvironment.transform 15 2342 env4282 = env4283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2342 env4282 == env4283) = true)

theorem identity4283 : scanCanonicalize (H12AffineFastState.compose env4283 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4283 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4284 : List Nat := [2,4,8,16,32,17,40,256,512,1024,1840,4096,8192,4128,8201,1558,4357,1808,1024,8201,4097,12840,5377,35,8225,5376,1808,4129,4389,1841,8764,9789,256,32,8712,5652]

theorem envBound4284 : H12AffineFastState.Bounded env4284 := by
  intro p hp
  have h : env4284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4283_4284 : H12AffineEnvironment.transform 10 1840 env4283 = env4284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1840 env4283 == env4284) = true)

theorem identity4284 : scanCanonicalize (H12AffineFastState.compose env4284 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4284 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env4285 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1589,4096,8192,4128,8201,1558,4096,1557,1024,8201,4097,12840,5124,35,8225,5125,1557,4129,4128,1588,8764,9789,5,32,8712,5652]

theorem envBound4285 : H12AffineFastState.Bounded env4285 := by
  intro p hp
  have h : env4285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4284_4285 : H12AffineEnvironment.transform 7 5 env4284 = env4285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4284 == env4285) = true)

theorem identity4285 : scanCanonicalize (H12AffineFastState.compose env4285 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound4285 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4286 : List Nat := [2,4,8,10,32,11,40,5,512,1024,1583,4096,8192,4128,8201,1548,4096,1551,1024,8201,4097,12840,5124,35,8225,5125,1551,4129,4128,1582,8742,9767,5,32,8712,5646]

theorem envBound4286 : H12AffineFastState.Bounded env4286 := by
  intro p hp
  have h : env4286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4285_4286 : H12AffineEnvironment.transform 3 10 env4285 = env4286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env4285 == env4286) = true)

theorem identity4286 : scanCanonicalize (H12AffineFastState.compose env4286 (packedSelected [10,15] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound4286 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env4287 : List Nat := [2,4,8,10,32,11,40,5,512,1024,1583,4096,1543,4128,1550,1548,4096,1551,1024,1550,4097,5167,5124,35,1574,5125,1551,4129,4128,1582,1057,32,5,32,1039,5646]

theorem envBound4287 : H12AffineFastState.Bounded env4287 := by
  intro p hp
  have h : env4287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4286_4287 : H12AffineEnvironment.transform 12 1543 env4286 = env4287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env4286 == env4287) = true)

def env4288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323793,16385,16892,22641,74795,12644669,257,20560,8479127,8389613]

theorem envBound4288 : H12AffineFastState.Bounded env4288 := by
  intro p hp
  have h : env4288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4259_4288 : H12AffineEnvironment.transform 18 1025 env4259 = env4288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4259 == env4288) = true)

theorem identity4288 : scanCanonicalize (H12AffineFastState.compose env4288 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4292934) := by decide +kernel

theorem selectedBound4288 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,4292934,41002,8329,4292887,323793,16385,16892,22641,74795,94331,257,20560,4251857,4293291]

theorem envBound4289 : H12AffineFastState.Bounded env4289 := by
  intro p hp
  have h : env4289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4288_4289 : H12AffineEnvironment.transform 22 4292934 env4288 = env4289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292934 env4288 == env4289) = true)

def env4290 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4292886,41002,8329,4292887,323713,16385,16812,22561,74795,94251,257,20480,4251777,4293291]

theorem envBound4290 : H12AffineFastState.Bounded env4290 := by
  intro p hp
  have h : env4290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4289_4290 : H12AffineEnvironment.transform 5 16 env4289 = env4290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4289 == env4290) = true)

def env4291 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,65536,4524,262144,1025,32768,4097,4194304,4292886,41002,8329,4292887,303233,4097,4524,2081,74795,73771,257,0,4239489,4293291]

theorem envBound4291 : H12AffineFastState.Bounded env4291 := by
  intro p hp
  have h : env4291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4290_4291 : H12AffineEnvironment.transform 13 4096 env4290 = env4291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env4290 == env4291) = true)

theorem identity4291 : scanCanonicalize (H12AffineFastState.compose env4291 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33063) := by decide +kernel

theorem selectedBound4291 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env4292 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,32768,33063,4524,262144,1025,32768,4097,4194304,4194353,41002,8329,4194352,303233,4097,4524,2081,42252,41228,257,0,4239489,4195212]

theorem envBound4292 : H12AffineFastState.Bounded env4292 := by
  intro p hp
  have h : env4292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4291_4292 : H12AffineEnvironment.transform 15 33063 env4291 = env4292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33063 env4291 == env4292) = true)

def env4293 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8495,4524,262144,1025,8200,4097,4194304,4194353,34,8329,4194352,262281,4097,4524,2081,1284,260,257,0,4198537,4195212]

theorem envBound4293 : H12AffineFastState.Bounded env4293 := by
  intro p hp
  have h : env4293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4292_4293 : H12AffineEnvironment.transform 14 8200 env4292 = env4293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4292 == env4293) = true)

theorem identity4293 : scanCanonicalize (H12AffineFastState.compose env4293 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 4383) := by decide +kernel

theorem selectedBound4293 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4294 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8200,8495,4524,4383,1025,8200,4097,4194304,4194353,34,8329,4194352,4502,4097,4524,2081,1284,260,257,0,4198537,4195212]

theorem envBound4294 : H12AffineFastState.Bounded env4294 := by
  intro p hp
  have h : env4294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4293_4294 : H12AffineEnvironment.transform 17 4383 env4293 = env4294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4383 env4293 == env4294) = true)

theorem identity4294 : scanCanonicalize (H12AffineFastState.compose env4294 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1840) := by decide +kernel

theorem selectedBound4294 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4295 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1840,8192,1840,8200,8495,1692,1583,1025,8200,1841,4194304,4194353,34,8329,4194352,1702,1841,1692,2081,1284,260,257,0,4196281,4195212]

theorem envBound4295 : H12AffineFastState.Bounded env4295 := by
  intro p hp
  have h : env4295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4294_4295 : H12AffineEnvironment.transform 11 1840 env4294 = env4295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1840 env4294 == env4295) = true)

theorem identity4295 : scanCanonicalize (H12AffineFastState.compose env4295 (packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound4295 : packedSelected [0,1,3,4,7,8,9,10,12,13,15,24] rootPS < 2^1333 := by decide +kernel

def env4296 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1702,1840,8192,1840,8200,8495,1692,1583,1025,8200,1841,4194304,4194353,34,8329,4194352,1702,1841,1692,1671,1284,260,257,0,4196281,4195212]

theorem envBound4296 : H12AffineFastState.Bounded env4296 := by
  intro p hp
  have h : env4296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4295_4296 : H12AffineEnvironment.transform 10 1702 env4295 = env4296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env4295 == env4296) = true)

theorem identity4296 : scanCanonicalize (H12AffineFastState.compose env4296 (packedSelected [3,4,5,7,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 1418) := by decide +kernel

theorem selectedBound4296 : packedSelected [3,4,5,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4297 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1702,1840,1418,1840,1410,1189,1692,1583,1025,1410,1841,4194304,4194353,34,1283,4194352,1702,1841,1692,1671,1284,260,257,0,4196281,4195212]

theorem envBound4297 : H12AffineFastState.Bounded env4297 := by
  intro p hp
  have h : env4297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4296_4297 : H12AffineEnvironment.transform 12 1418 env4296 = env4297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1418 env4296 == env4297) = true)

theorem identity4297 : scanCanonicalize (H12AffineFastState.compose env4297 (packedSelected [4,7,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4297 : packedSelected [4,7,10,11,15] rootPS < 2^1333 := by decide +kernel

def env4298 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1702,1692,1062,1692,1070,1189,1692,1583,1025,1070,1693,4194304,4194353,34,1199,4194352,1702,1693,1692,1671,1192,168,173,0,4195861,4194848]

theorem envBound4298 : H12AffineFastState.Bounded env4298 := by
  intro p hp
  have h : env4298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4297_4298 : H12AffineEnvironment.transform 7 172 env4297 = env4298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4297 == env4298) = true)

theorem identity4298 : scanCanonicalize (H12AffineFastState.compose env4298 (packedSelected [0,3,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4298 : packedSelected [0,3,8,9] rootPS < 2^1333 := by decide +kernel

def env4299 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1550,1588,1062,1588,1070,1037,1588,1583,1025,1070,1589,4194304,4194353,34,1031,4194352,1550,1589,1588,1583,1024,0,5,0,4195861,4194848]

theorem envBound4299 : H12AffineFastState.Bounded env4299 := by
  intro p hp
  have h : env4299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4298_4299 : H12AffineEnvironment.transform 6 40 env4298 = env4299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4298 == env4299) = true)

def env4300 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8494,4524,262144,1025,8201,4097,4194304,4194353,35,8329,4194352,262280,4097,4524,2081,1285,261,257,0,4198536,4195212]

theorem envBound4300 : H12AffineFastState.Bounded env4300 := by
  intro p hp
  have h : env4300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4292_4300 : H12AffineEnvironment.transform 14 8201 env4292 = env4300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4292 == env4300) = true)

theorem identity4300 : scanCanonicalize (H12AffineFastState.compose env4300 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 266386) := by decide +kernel

theorem selectedBound4300 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4301 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8494,4524,262144,1025,8201,4097,266386,266403,35,8329,266402,262280,4097,4524,2081,1285,261,257,0,262170,267038]

theorem envBound4301 : H12AffineFastState.Bounded env4301 := by
  intro p hp
  have h : env4301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4300_4301 : H12AffineEnvironment.transform 21 266386 env4300 = env4301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 266386 env4300 == env4301) = true)

theorem identity4301 : scanCanonicalize (H12AffineFastState.compose env4301 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1922) := by decide +kernel

theorem selectedBound4301 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4302 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4096,8201,8494,4524,1922,1025,8201,4097,5904,5921,35,8329,5920,1802,4097,4524,2081,1285,261,257,0,1944,5276]

theorem envBound4302 : H12AffineFastState.Bounded env4302 := by
  intro p hp
  have h : env4302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4301_4302 : H12AffineEnvironment.transform 17 1922 env4301 = env4302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1922 env4301 == env4302) = true)

theorem identity4302 : scanCanonicalize (H12AffineFastState.compose env4302 (packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS)) = affineNative (2^(10+1) ^^^ 1955) := by decide +kernel

theorem selectedBound4302 : packedSelected [0,4,7,8,9,10,12,15,17,28] rootPS < 2^1333 := by decide +kernel

def env4303 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1955,4096,8192,4096,8201,8494,4524,1922,1025,8201,4097,5904,5921,35,8329,5920,1802,4097,4524,1922,1285,261,257,0,1944,5276]

theorem envBound4303 : H12AffineFastState.Bounded env4303 := by
  intro p hp
  have h : env4303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4302_4303 : H12AffineEnvironment.transform 10 1955 env4302 = env4303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1955 env4302 == env4303) = true)

theorem identity4303 : scanCanonicalize (H12AffineFastState.compose env4303 (packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4763) := by decide +kernel

theorem selectedBound4303 : packedSelected [0,1,2,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4304 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1955,4096,4763,4096,4754,5045,4524,1922,1025,4754,4097,5904,5921,35,4626,5920,1802,4097,4524,1922,1285,261,257,0,1944,5276]

theorem envBound4304 : H12AffineFastState.Bounded env4304 := by
  intro p hp
  have h : env4304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4303_4304 : H12AffineEnvironment.transform 12 4763 env4303 = env4304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4763 env4303 == env4304) = true)

theorem identity4304 : scanCanonicalize (H12AffineFastState.compose env4304 (packedSelected [1,4,7,8,10,11,13] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound4304 : packedSelected [1,4,7,8,10,11,13] rootPS < 2^1333 := by decide +kernel

def env4305 : List Nat := [2,4,8,16,32,16,128,256,169,1024,1290,4096,4146,4096,4155,4380,4524,1323,1025,4155,4097,5561,5512,35,4283,5513,1443,4097,4524,1323,1285,261,257,0,1329,5276]

theorem envBound4305 : H12AffineFastState.Bounded env4305 := by
  intro p hp
  have h : env4305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4304_4305 : H12AffineEnvironment.transform 8 169 env4304 = env4305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env4304 == env4305) = true)

theorem identity4305 : scanCanonicalize (H12AffineFastState.compose env4305 (packedSelected [0,1,2,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound4305 : packedSelected [0,1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env4306 : List Nat := [2,4,8,16,32,16,128,256,169,1024,1290,261,311,261,318,25,169,1323,1025,318,260,1212,1165,35,446,1164,1443,260,169,1323,1285,261,257,0,1329,1433]

theorem envBound4306 : H12AffineFastState.Bounded env4306 := by
  intro p hp
  have h : env4306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4305_4306 : H12AffineEnvironment.transform 11 261 env4305 = env4306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env4305 == env4306) = true)

theorem identity4306 : scanCanonicalize (H12AffineFastState.compose env4306 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4306 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env4307 : List Nat := [2,4,8,16,32,16,128,172,169,1024,1190,169,155,169,146,25,169,1159,1025,146,168,1212,1165,35,18,1164,1039,168,169,1159,1193,169,173,0,1181,1077]

theorem envBound4307 : H12AffineFastState.Bounded env4307 := by
  intro p hp
  have h : env4307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4306_4307 : H12AffineEnvironment.transform 7 172 env4306 = env4307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4306 == env4307) = true)

theorem identity4307 : scanCanonicalize (H12AffineFastState.compose env4307 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4307 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4308 : List Nat := [2,4,8,16,32,16,41,5,0,1024,1039,0,50,0,59,25,0,1070,1025,59,1,1045,1060,35,18,1061,1039,1,0,1070,1024,0,4,0,1076,1077]

theorem envBound4308 : H12AffineFastState.Bounded env4308 := by
  intro p hp
  have h : env4308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4307_4308 : H12AffineEnvironment.transform 6 41 env4307 = env4308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4307 == env4308) = true)

def env4309 : List Nat := [2,4,8,16,32,16,41,5,0,32,47,0,50,0,59,25,0,14,33,59,1,53,4,35,18,5,47,1,0,14,32,0,4,0,20,21]

theorem envBound4309 : H12AffineFastState.Bounded env4309 := by
  intro p hp
  have h : env4309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4308_4309 : H12AffineEnvironment.transform 9 32 env4308 = env4309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4308 == env4309) = true)

theorem identity4309 : scanCanonicalize (H12AffineFastState.compose env4309 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound4309 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4310 : List Nat := [2,4,8,4,32,4,41,5,0,32,47,0,38,0,47,13,0,14,33,47,1,33,4,35,6,5,47,1,0,14,32,0,4,0,0,1]

theorem envBound4310 : H12AffineFastState.Bounded env4310 := by
  intro p hp
  have h : env4310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4309_4310 : H12AffineEnvironment.transform 3 4 env4309 = env4310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env4309 == env4310) = true)

theorem identity4310 : scanCanonicalize (H12AffineFastState.compose env4310 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound4310 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4311 : List Nat := [2,4,7,4,32,4,38,5,0,32,32,0,38,0,32,2,0,1,33,32,1,33,4,35,6,5,32,1,0,1,32,0,4,0,0,1]

theorem envBound4311 : H12AffineFastState.Bounded env4311 := by
  intro p hp
  have h : env4311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4310_4311 : H12AffineEnvironment.transform 2 7 env4310 = env4311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env4310 == env4311) = true)

theorem identity4311 : scanCanonicalize (H12AffineFastState.compose env4311 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4311 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4312 : List Nat := [2,1,2,1,32,1,35,0,0,32,32,0,35,0,32,2,0,1,33,32,1,33,1,35,3,0,32,1,0,1,32,0,1,0,0,1]

theorem envBound4312 : H12AffineFastState.Bounded env4312 := by
  intro p hp
  have h : env4312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4311_4312 : H12AffineEnvironment.transform 1 1 env4311 = env4312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4311 == env4312) = true)

def leafEnv4312 : List Nat := [2,1,2,1,32,1,35,0,0,32,32,0,35,0,32,2,0,1,33,32,1,33,1,35,33,3,1,0,32,1,0,1,32,0,1,0,0,34,0,1,1,1,0]

def active4312 : List Nat := [0,4]

def tree4312 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4312 : H12WitnessSearch.Good tree4312 := H12GlobalWitnessIndex.good

theorem leafIdentity4312 : H12AffineFastState.composeSystem env4312 rootObs = leafEnv4312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4312 rootObs == leafEnv4312) = true)

theorem terminalChecked4312 : H12PackedTerminal.terminalCheckFast leafEnv4312 active4312 tree4312 = true := by decide +kernel

def env4313 : List Nat := [2,4,8,16,32,16,41,5,0,33,46,0,50,0,59,25,0,15,32,59,1,52,5,35,18,4,46,1,0,15,33,0,4,0,21,20]

theorem envBound4313 : H12AffineFastState.Bounded env4313 := by
  intro p hp
  have h : env4313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4308_4313 : H12AffineEnvironment.transform 9 33 env4308 = env4313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 33 env4308 == env4313) = true)

def env4314 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,32768,65536,4524,262144,1025,32768,4097,4194304,4292886,41002,8329,4292887,303232,4096,4525,2080,74795,73770,257,1,4239488,4293291]

theorem envBound4314 : H12AffineFastState.Bounded env4314 := by
  intro p hp
  have h : env4314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4290_4314 : H12AffineEnvironment.transform 13 4097 env4290 = env4314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env4290 == env4314) = true)

theorem identity4314 : scanCanonicalize (H12AffineFastState.compose env4314 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4314 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4315 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,8201,65536,4524,262144,1025,8201,4097,4194304,4268319,35,8329,4268318,262281,4096,4525,2080,74795,73770,257,1,4198537,4268706]

theorem envBound4315 : H12AffineFastState.Bounded env4315 := by
  intro p hp
  have h : env4315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4314_4315 : H12AffineEnvironment.transform 14 8201 env4314 = env4315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4314 == env4315) = true)

theorem identity4315 : scanCanonicalize (H12AffineFastState.compose env4315 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound4315 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env4316 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4097,8201,65536,4524,262144,1025,8201,4097,73890,445,35,8329,444,262281,4096,4525,2080,74795,73770,257,1,77867,512]

theorem envBound4316 : H12AffineFastState.Bounded env4316 := by
  intro p hp
  have h : env4316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4315_4316 : H12AffineEnvironment.transform 21 73890 env4315 = env4316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env4315 == env4316) = true)

theorem identity4316 : scanCanonicalize (H12AffineFastState.compose env4316 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4316 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4317 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8201,65536,4096,262144,1025,8201,4097,73890,17,35,8329,16,262281,4096,4097,2080,74795,73770,173,1,77867,512]

theorem envBound4317 : H12AffineFastState.Bounded env4317 := by
  intro p hp
  have h : env4317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4316_4317 : H12AffineEnvironment.transform 7 172 env4316 = env4317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4316 == env4317) = true)

theorem identity4317 : scanCanonicalize (H12AffineFastState.compose env4317 (packedSelected [6,13,17] rootPS)) = affineNative (2^(15+1) ^^^ 15548) := by decide +kernel

theorem selectedBound4317 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4318 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8201,15548,4096,262144,1025,8201,4097,7198,17,35,8329,16,262281,4096,4097,2080,6295,7318,173,1,3223,512]

theorem envBound4318 : H12AffineFastState.Bounded env4318 := by
  intro p hp
  have h : env4318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4317_4318 : H12AffineEnvironment.transform 15 15548 env4317 = env4318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15548 env4317 == env4318) = true)

theorem identity4318 : scanCanonicalize (H12AffineFastState.compose env4318 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 5286) := by decide +kernel

theorem selectedBound4318 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4319 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,4097,8201,15548,4096,5286,1025,8201,4097,7198,17,35,8329,16,5167,4096,4097,2080,6295,7318,173,1,3223,512]

theorem envBound4319 : H12AffineFastState.Bounded env4319 := by
  intro p hp
  have h : env4319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4318_4319 : H12AffineEnvironment.transform 17 5286 env4318 = env4319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5286 env4318 == env4319) = true)

theorem identity4319 : scanCanonicalize (H12AffineFastState.compose env4319 (packedSelected [0,7,20] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4319 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4320 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,1692,8192,1693,8201,10784,1692,570,1025,8201,1693,2690,17,35,8329,16,691,1692,1693,2080,3595,2570,173,1,3223,512]

theorem envBound4320 : H12AffineFastState.Bounded env4320 := by
  intro p hp
  have h : env4320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4319_4320 : H12AffineEnvironment.transform 11 1692 env4319 = env4320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4319 == env4320) = true)

theorem identity4320 : scanCanonicalize (H12AffineFastState.compose env4320 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound4320 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4321 : List Nat := [2,4,8,16,32,16,128,172,512,1024,674,1692,8192,1693,8201,8322,1692,570,1025,8201,1693,32,17,35,8329,16,691,1692,1693,642,1193,168,173,1,1589,512]

theorem envBound4321 : H12AffineFastState.Bounded env4321 := by
  intro p hp
  have h : env4321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4320_4321 : H12AffineEnvironment.transform 10 674 env4320 = env4321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env4320 == env4321) = true)

theorem identity4321 : scanCanonicalize (H12AffineFastState.compose env4321 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4321 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4322 : List Nat := [2,4,8,1,32,1,128,172,512,1024,674,1677,8192,1676,8201,8322,1677,555,1025,8201,1676,32,0,35,8329,1,674,1677,1676,642,1193,168,173,1,1572,512]

theorem envBound4322 : H12AffineFastState.Bounded env4322 := by
  intro p hp
  have h : env4322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4321_4322 : H12AffineEnvironment.transform 3 1 env4321 = env4322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4321 == env4322) = true)

theorem identity4322 : scanCanonicalize (H12AffineFastState.compose env4322 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound4322 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env4323 : List Nat := [2,4,8,1,32,1,128,172,512,47,674,674,8192,675,8201,8322,674,555,46,8201,675,32,0,35,8329,1,674,674,675,642,134,168,173,1,523,512]

theorem envBound4323 : H12AffineFastState.Bounded env4323 := by
  intro p hp
  have h : env4323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4322_4323 : H12AffineEnvironment.transform 9 47 env4322 = env4323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env4322 == env4323) = true)

theorem identity4323 : scanCanonicalize (H12AffineFastState.compose env4323 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4323 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env4324 : List Nat := [2,4,8,1,32,1,41,5,512,47,523,523,8192,522,8201,8235,523,555,46,8201,522,32,0,35,8224,1,523,523,522,555,47,1,4,1,523,512]

theorem envBound4324 : H12AffineFastState.Bounded env4324 := by
  intro p hp
  have h : env4324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4323_4324 : H12AffineEnvironment.transform 6 41 env4323 = env4324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4323 == env4324) = true)

theorem identity4324 : scanCanonicalize (H12AffineFastState.compose env4324 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4324 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4325 : List Nat := [2,4,8,1,10,1,3,5,512,5,523,523,8192,522,8201,8193,523,513,4,8201,522,10,0,9,8202,1,523,523,522,513,5,1,4,1,523,512]

theorem envBound4325 : H12AffineFastState.Bounded env4325 := by
  intro p hp
  have h : env4325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4324_4325 : H12AffineEnvironment.transform 4 10 env4324 = env4325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4324 == env4325) = true)

theorem identity4325 : scanCanonicalize (H12AffineFastState.compose env4325 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 520) := by decide +kernel

theorem selectedBound4325 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4326 : List Nat := [2,4,8,1,10,1,3,5,512,5,523,523,520,522,513,521,523,513,4,513,522,10,0,9,514,1,523,523,522,513,5,1,4,1,523,512]

theorem envBound4326 : H12AffineFastState.Bounded env4326 := by
  intro p hp
  have h : env4326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4325_4326 : H12AffineEnvironment.transform 12 520 env4325 = env4326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 520 env4325 == env4326) = true)

theorem identity4326 : scanCanonicalize (H12AffineFastState.compose env4326 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4326 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4327 : List Nat := [2,4,8,1,10,1,3,5,0,5,11,11,8,10,1,9,11,1,4,1,10,10,0,9,2,1,11,11,10,1,5,1,4,1,11,0]

theorem envBound4327 : H12AffineFastState.Bounded env4327 := by
  intro p hp
  have h : env4327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4326_4327 : H12AffineEnvironment.transform 8 0 env4326 = env4327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4326 == env4327) = true)

theorem identity4327 : scanCanonicalize (H12AffineFastState.compose env4327 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4327 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4328 : List Nat := [2,4,2,1,0,1,3,5,0,5,1,1,2,0,1,3,1,1,4,1,0,0,0,3,2,1,1,1,0,1,5,1,4,1,1,0]

theorem envBound4328 : H12AffineFastState.Bounded env4328 := by
  intro p hp
  have h : env4328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4327_4328 : H12AffineEnvironment.transform 2 2 env4327 = env4328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4327 == env4328) = true)

def env4329 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4292887,41002,8329,4292887,323712,16385,16813,22560,74795,94250,257,20481,4251776,4293291]

theorem envBound4329 : H12AffineFastState.Bounded env4329 := by
  intro p hp
  have h : env4329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4289_4329 : H12AffineEnvironment.transform 5 17 env4289 = env4329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4289 == env4329) = true)

theorem identity4329 : scanCanonicalize (H12AffineFastState.compose env4329 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98475) := by decide +kernel

theorem selectedBound4329 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4330 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,98475,444,41002,8329,444,323712,16385,16813,22560,74795,94250,257,20481,90155,512]

theorem envBound4330 : H12AffineFastState.Bounded env4330 := by
  intro p hp
  have h : env4330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4329_4330 : H12AffineEnvironment.transform 21 98475 env4329 = env4330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98475 env4329 == env4330) = true)

theorem identity4330 : scanCanonicalize (H12AffineFastState.compose env4330 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4330 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4331 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1025,32768,4097,41349,444,41002,8329,444,323712,16385,16813,22560,1285,20740,257,20481,16645,512]

theorem envBound4331 : H12AffineFastState.Bounded env4331 := by
  intro p hp
  have h : env4331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4330_4331 : H12AffineEnvironment.transform 15 8494 env4330 = env4331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4330 == env4331) = true)

theorem identity4331 : scanCanonicalize (H12AffineFastState.compose env4331 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13973) := by decide +kernel

theorem selectedBound4331 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4332 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13973,8494,4525,262144,1025,13973,4097,5904,444,5823,8329,444,280085,16385,16813,22560,1285,20740,257,20481,16645,512]

theorem envBound4332 : H12AffineFastState.Bounded env4332 := by
  intro p hp
  have h : env4332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4331_4332 : H12AffineEnvironment.transform 14 13973 env4331 = env4332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13973 env4331 == env4332) = true)

theorem identity4332 : scanCanonicalize (H12AffineFastState.compose env4332 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4525) := by decide +kernel

theorem selectedBound4332 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4333 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,262144,1025,13973,4097,5904,444,5823,8329,444,268216,4524,4096,2445,1285,169,257,428,4264,512]

theorem envBound4333 : H12AffineFastState.Bounded env4333 := by
  intro p hp
  have h : env4333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4332_4333 : H12AffineEnvironment.transform 13 4525 env4332 = env4333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4525 env4332 == env4333) = true)

theorem identity4333 : scanCanonicalize (H12AffineFastState.compose env4333 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound4333 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4334 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4525,13973,8494,4525,7869,1025,13973,4097,5904,444,5823,8329,444,2309,4524,4096,2445,1285,169,257,428,4264,512]

theorem envBound4334 : H12AffineFastState.Bounded env4334 := by
  intro p hp
  have h : env4334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4333_4334 : H12AffineEnvironment.transform 17 7869 env4333 = env4334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env4333 == env4334) = true)

theorem identity4334 : scanCanonicalize (H12AffineFastState.compose env4334 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4334 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4335 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1841,8192,1692,8612,8494,1692,2444,1025,8612,1840,33,444,398,8329,444,2309,1693,1841,2445,1285,169,257,428,1945,512]

theorem envBound4335 : H12AffineFastState.Bounded env4335 := by
  intro p hp
  have h : env4335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4334_4335 : H12AffineEnvironment.transform 11 1841 env4334 = env4335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env4334 == env4335) = true)

theorem identity4335 : scanCanonicalize (H12AffineFastState.compose env4335 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4335 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4336 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1588,8192,1692,8353,8235,1692,2185,1025,8353,1589,33,185,139,8329,185,2048,1693,1588,2184,1024,169,4,169,1692,512]

theorem envBound4336 : H12AffineFastState.Bounded env4336 := by
  intro p hp
  have h : env4336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4335_4336 : H12AffineEnvironment.transform 7 5 env4335 = env4336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4335 == env4336) = true)

theorem identity4336 : scanCanonicalize (H12AffineFastState.compose env4336 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 2746) := by decide +kernel

theorem selectedBound4336 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env4337 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1588,2746,1692,2587,2705,1692,2185,1025,2587,1589,33,185,139,2611,185,2048,1693,1588,2184,1024,169,4,169,1692,512]

theorem envBound4337 : H12AffineFastState.Bounded env4337 := by
  intro p hp
  have h : env4337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4336_4337 : H12AffineEnvironment.transform 12 2746 env4336 = env4337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2746 env4336 == env4337) = true)

theorem identity4337 : scanCanonicalize (H12AffineFastState.compose env4337 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound4337 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env4338 : List Nat := [2,4,8,16,32,17,128,5,512,20,2048,544,2746,648,2587,2705,648,2185,21,2587,545,33,185,139,2611,185,2048,649,544,2184,20,169,4,169,648,512]

theorem envBound4338 : H12AffineFastState.Bounded env4338 := by
  intro p hp
  have h : env4338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4337_4338 : H12AffineEnvironment.transform 9 20 env4337 = env4338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env4337 == env4338) = true)

def env4339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,2097152,4194304,8388608,41002,8329,11015249,849105,268435456,268435965,547953,2699307,12644668,525568,545872,8479126,8914924]

theorem envBound4339 : H12AffineFastState.Bounded env4339 := by
  intro p hp
  have h : env4339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans3922_4339 : H12AffineEnvironment.transform 26 849105 env3922 = env4339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 849105 env3922 == env4339) = true)

def env4340 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849105,268435456,268435965,547953,598059,12644668,525568,545872,8479126,8914924]

theorem envBound4340 : H12AffineFastState.Bounded env4340 := by
  intro p hp
  have h : env4340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4339_4340 : H12AffineEnvironment.transform 20 4096 env4339 = env4340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env4339 == env4340) = true)

def env4341 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849105,16384,16893,547953,598059,12644668,525568,545872,8479126,8914924]

theorem envBound4341 : H12AffineFastState.Bounded env4341 := by
  intro p hp
  have h : env4341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4340_4341 : H12AffineEnvironment.transform 27 16384 env4340 = env4341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env4340 == env4341) = true)

def env4342 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323793,16384,16893,22641,74795,12644668,256,20560,8479126,8389612]

theorem envBound4342 : H12AffineFastState.Bounded env4342 := by
  intro p hp
  have h : env4342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4341_4342 : H12AffineEnvironment.transform 18 1024 env4341 = env4342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4341 == env4342) = true)

theorem identity4342 : scanCanonicalize (H12AffineFastState.compose env4342 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73922) := by decide +kernel

theorem selectedBound4342 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,73922,41002,8329,73875,323793,16384,16893,22641,74795,4313598,256,20560,16724,74542]

theorem envBound4343 : H12AffineFastState.Bounded env4343 := by
  intro p hp
  have h : env4343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4342_4343 : H12AffineEnvironment.transform 22 73922 env4342 = env4343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73922 env4342 == env4343) = true)

def env4344 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,73874,41002,8329,73875,323713,16384,16813,22561,74795,4313518,256,20480,16644,74542]

theorem envBound4344 : H12AffineFastState.Bounded env4344 := by
  intro p hp
  have h : env4344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4343_4344 : H12AffineEnvironment.transform 5 16 env4343 = env4344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4343 == env4344) = true)

def env4345 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41088,73874,41002,8329,73875,323713,16384,16813,22561,74795,94510,256,20480,16644,74542]

theorem envBound4345 : H12AffineFastState.Bounded env4345 := by
  intro p hp
  have h : env4345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4344_4345 : H12AffineEnvironment.transform 21 41088 env4344 = env4345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4344 == env4345) = true)

theorem identity4345 : scanCanonicalize (H12AffineFastState.compose env4345 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4345 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4346 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4264,262144,1024,32768,4096,41088,73874,41002,8329,73875,323713,16384,16553,22561,74795,94250,4,20480,16384,74282]

theorem envBound4346 : H12AffineFastState.Bounded env4346 := by
  intro p hp
  have h : env4346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4345_4346 : H12AffineEnvironment.transform 7 4 env4345 = env4346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4345 == env4346) = true)

theorem identity4346 : scanCanonicalize (H12AffineFastState.compose env4346 (packedSelected [0,3,7,10,11,13,17,18,20,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 38590) := by decide +kernel

theorem selectedBound4346 : packedSelected [0,3,7,10,11,13,17,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4347 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,38590,4264,262144,1024,32768,4096,41088,46636,41002,8329,46637,323713,16384,16553,22561,45717,59028,4,20480,16384,46228]

theorem envBound4347 : H12AffineFastState.Bounded env4347 := by
  intro p hp
  have h : env4347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4346_4347 : H12AffineEnvironment.transform 15 38590 env4346 = env4347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38590 env4346 == env4347) = true)

def env4348 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,32768,38590,4264,262144,1024,32768,4096,41088,46636,41002,8329,46637,303233,4096,4265,2081,45717,46740,4,0,4096,46228]

theorem envBound4348 : H12AffineFastState.Bounded env4348 := by
  intro p hp
  have h : env4348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4347_4348 : H12AffineEnvironment.transform 13 4096 env4347 = env4348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env4347 == env4348) = true)

theorem identity4348 : scanCanonicalize (H12AffineFastState.compose env4348 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound4348 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env4349 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1573,8192,1573,32768,32923,1677,262144,1024,32768,1573,41088,40969,41002,8329,40968,303233,1573,1676,2081,42160,41137,4,0,1573,41649]

theorem envBound4349 : H12AffineFastState.Bounded env4349 := by
  intro p hp
  have h : env4349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4348_4349 : H12AffineEnvironment.transform 11 1573 env4348 = env4349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env4348 == env4349) = true)

theorem identity4349 : scanCanonicalize (H12AffineFastState.compose env4349 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4349 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4350 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1573,8192,1573,32768,32906,1677,262144,1024,32768,1573,41088,40969,41002,8329,40968,303233,1573,1676,2081,42145,41120,4,0,1573,41632]

theorem envBound4350 : H12AffineFastState.Bounded env4350 := by
  intro p hp
  have h : env4350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4349_4350 : H12AffineEnvironment.transform 3 1 env4349 = env4350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4349 == env4350) = true)

theorem identity4350 : scanCanonicalize (H12AffineFastState.compose env4350 (packedSelected [6,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound4350 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4351 : List Nat := [2,4,8,1,32,1,128,4,512,1024,523,1573,8192,1573,32768,32906,1677,262144,1024,32768,1573,41088,40969,41002,8329,40968,303233,1573,1676,554,42145,41120,4,0,1573,41632]

theorem envBound4351 : H12AffineFastState.Bounded env4351 := by
  intro p hp
  have h : env4351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4350_4351 : H12AffineEnvironment.transform 10 523 env4350 = env4351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env4350 == env4351) = true)

theorem identity4351 : scanCanonicalize (H12AffineFastState.compose env4351 (packedSelected [13,21] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound4351 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4352 : List Nat := [2,4,8,1,32,1,128,4,512,1024,523,1573,8192,1573,8200,8322,1677,262144,1024,8200,1573,136,1,34,8329,0,262281,1573,1676,554,1193,168,4,0,1573,680]

theorem envBound4352 : H12AffineFastState.Bounded env4352 := by
  intro p hp
  have h : env4352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4351_4352 : H12AffineEnvironment.transform 14 8200 env4351 = env4352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env4351 == env4352) = true)

theorem identity4352 : scanCanonicalize (H12AffineFastState.compose env4352 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound4352 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4353 : List Nat := [2,4,8,1,32,1,128,4,512,1024,523,1573,8192,1573,8200,8322,1677,555,1024,8200,1573,136,1,34,8329,0,674,1573,1676,554,1193,168,4,0,1573,680]

theorem envBound4353 : H12AffineFastState.Bounded env4353 := by
  intro p hp
  have h : env4353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4352_4353 : H12AffineEnvironment.transform 17 555 env4352 = env4353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env4352 == env4353) = true)

theorem identity4353 : scanCanonicalize (H12AffineFastState.compose env4353 (packedSelected [2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 678) := by decide +kernel

theorem selectedBound4353 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env4354 : List Nat := [2,4,8,1,32,1,128,4,512,678,523,131,8192,131,8200,8322,43,555,678,8200,131,136,1,34,8329,0,674,131,42,554,527,168,4,0,131,680]

theorem envBound4354 : H12AffineFastState.Bounded env4354 := by
  intro p hp
  have h : env4354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4353_4354 : H12AffineEnvironment.transform 9 678 env4353 = env4354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 678 env4353 == env4354) = true)

theorem identity4354 : scanCanonicalize (H12AffineFastState.compose env4354 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound4354 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env4355 : List Nat := [2,4,8,1,32,1,128,4,131,37,136,131,8192,131,8200,8322,43,168,37,8200,131,136,1,34,8329,0,33,131,42,169,140,168,4,0,131,43]

theorem envBound4355 : H12AffineFastState.Bounded env4355 := by
  intro p hp
  have h : env4355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4354_4355 : H12AffineEnvironment.transform 8 131 env4354 = env4355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env4354 == env4355) = true)

theorem identity4355 : scanCanonicalize (H12AffineFastState.compose env4355 (packedSelected [4,7] rootPS)) = affineNative (2^(12+1) ^^^ 139) := by decide +kernel

theorem selectedBound4355 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env4356 : List Nat := [2,4,8,1,32,1,128,4,131,37,136,131,139,131,131,9,43,168,37,131,131,136,1,34,2,0,33,131,42,169,140,168,4,0,131,43]

theorem envBound4356 : H12AffineFastState.Bounded env4356 := by
  intro p hp
  have h : env4356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4355_4356 : H12AffineEnvironment.transform 12 139 env4355 = env4356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 139 env4355 == env4356) = true)

theorem identity4356 : scanCanonicalize (H12AffineFastState.compose env4356 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound4356 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4357 : List Nat := [2,4,8,1,32,1,8,4,11,37,0,11,3,11,11,9,43,32,37,11,11,0,1,34,2,0,33,11,42,33,4,32,4,0,11,43]

theorem envBound4357 : H12AffineFastState.Bounded env4357 := by
  intro p hp
  have h : env4357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4356_4357 : H12AffineEnvironment.transform 6 8 env4356 = env4357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env4356 == env4357) = true)

theorem identity4357 : scanCanonicalize (H12AffineFastState.compose env4357 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4357 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4358 : List Nat := [2,4,2,1,32,1,2,4,1,37,0,1,3,1,1,3,33,32,37,1,1,0,1,34,2,0,33,1,32,33,4,32,4,0,1,33]

theorem envBound4358 : H12AffineFastState.Bounded env4358 := by
  intro p hp
  have h : env4358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4357_4358 : H12AffineEnvironment.transform 2 2 env4357 = env4358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4357 == env4358) = true)

theorem identity4358 : scanCanonicalize (H12AffineFastState.compose env4358 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4358 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env4359 : List Nat := [2,4,2,1,1,1,2,4,1,4,0,1,3,1,1,3,0,1,4,1,1,0,1,3,2,0,0,1,1,0,4,1,4,0,1,0]

theorem envBound4359 : H12AffineFastState.Bounded env4359 := by
  intro p hp
  have h : env4359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4358_4359 : H12AffineEnvironment.transform 4 1 env4358 = env4359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4358 == env4359) = true)

theorem identity4359 : scanCanonicalize (H12AffineFastState.compose env4359 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4359 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4360 : List Nat := [2,1,2,1,1,1,2,1,1,1,0,1,3,1,1,3,0,1,1,1,1,0,1,3,2,0,0,1,1,0,1,1,1,0,1,0]

theorem envBound4360 : H12AffineFastState.Bounded env4360 := by
  intro p hp
  have h : env4360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4359_4360 : H12AffineEnvironment.transform 1 1 env4359 = env4360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4359 == env4360) = true)

def env4361 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,32768,38590,4264,262144,1024,32768,4096,41088,46636,41002,8329,46637,303232,4097,4264,2080,45717,46741,4,1,4097,46228]

theorem envBound4361 : H12AffineFastState.Bounded env4361 := by
  intro p hp
  have h : env4361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4347_4361 : H12AffineEnvironment.transform 13 4097 env4347 = env4361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env4347 == env4361) = true)

theorem identity4361 : scanCanonicalize (H12AffineFastState.compose env4361 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4361 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env4362 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1692,8192,1693,32768,32802,1588,262144,1024,32768,1692,41088,41136,41002,8329,41137,303232,1693,1588,2080,41993,40969,4,1,1693,41480]

theorem envBound4362 : H12AffineFastState.Bounded env4362 := by
  intro p hp
  have h : env4362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4361_4362 : H12AffineEnvironment.transform 11 1692 env4361 = env4362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4361 == env4362) = true)

theorem identity4362 : scanCanonicalize (H12AffineFastState.compose env4362 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1670) := by decide +kernel

theorem selectedBound4362 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4363 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1692,8192,1693,32768,32802,1588,1670,1024,32768,1692,41088,41136,41002,8329,41137,42502,1693,1588,2080,41993,40969,4,1,1693,41480]

theorem envBound4363 : H12AffineFastState.Bounded env4363 := by
  intro p hp
  have h : env4363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4362_4363 : H12AffineEnvironment.transform 17 1670 env4362 = env4363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1670 env4362 == env4363) = true)

theorem identity4363 : scanCanonicalize (H12AffineFastState.compose env4363 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 11951) := by decide +kernel

theorem selectedBound4363 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4364 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1692,8192,1693,11951,11917,1588,1670,1024,11951,1692,3631,3615,3717,8329,3614,2217,1693,1588,2080,2726,3750,4,1,1693,3239]

theorem envBound4364 : H12AffineFastState.Bounded env4364 := by
  intro p hp
  have h : env4364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4363_4364 : H12AffineEnvironment.transform 14 11951 env4363 = env4364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11951 env4363 == env4364) = true)

theorem identity4364 : scanCanonicalize (H12AffineFastState.compose env4364 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4364 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4365 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1551,1692,8192,1693,8352,8322,1588,1670,1024,8352,1692,32,16,138,8329,17,1702,1693,1588,1583,1193,169,4,1,1693,680]

theorem envBound4365 : H12AffineFastState.Bounded env4365 := by
  intro p hp
  have h : env4365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4364_4365 : H12AffineEnvironment.transform 10 1551 env4364 = env4365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env4364 == env4365) = true)

theorem identity4365 : scanCanonicalize (H12AffineFastState.compose env4365 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound4365 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4366 : List Nat := [2,4,8,16,32,16,19,4,512,1024,1551,1551,8192,1550,8243,8209,1588,1557,1024,8243,1551,32,16,25,8218,17,1589,1550,1588,1583,1082,58,4,1,1550,571]

theorem envBound4366 : H12AffineFastState.Bounded env4366 := by
  intro p hp
  have h : env4366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4365_4366 : H12AffineEnvironment.transform 6 19 env4365 = env4366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env4365 == env4366) = true)

theorem identity4366 : scanCanonicalize (H12AffineFastState.compose env4366 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound4366 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4367 : List Nat := [2,4,8,16,32,16,19,4,512,1024,1551,1551,1053,1550,1070,1036,1588,1557,1024,1070,1551,32,16,25,1031,17,1589,1550,1588,1583,1082,58,4,1,1550,571]

theorem envBound4367 : H12AffineFastState.Bounded env4367 := by
  intro p hp
  have h : env4367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4366_4367 : H12AffineEnvironment.transform 12 1053 env4366 = env4367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env4366 == env4367) = true)

theorem identity4367 : scanCanonicalize (H12AffineFastState.compose env4367 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4367 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4368 : List Nat := [2,4,8,16,27,16,19,4,512,1024,1551,1551,1053,1550,1045,1036,1551,1557,1024,1045,1551,27,16,25,1031,17,1550,1550,1551,1556,1025,1,4,1,1550,512]

theorem envBound4368 : H12AffineFastState.Bounded env4368 := by
  intro p hp
  have h : env4368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4367_4368 : H12AffineEnvironment.transform 4 27 env4367 = env4368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4367 == env4368) = true)

theorem identity4368 : scanCanonicalize (H12AffineFastState.compose env4368 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4368 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4369 : List Nat := [2,4,8,16,27,16,19,4,1,1024,1038,1038,1053,1039,1045,1036,1038,1044,1024,1045,1038,27,16,25,1031,17,1039,1039,1038,1045,1025,1,4,1,1039,1]

theorem envBound4369 : H12AffineFastState.Bounded env4369 := by
  intro p hp
  have h : env4369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4368_4369 : H12AffineEnvironment.transform 8 1 env4368 = env4369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4368 == env4369) = true)

theorem identity4369 : scanCanonicalize (H12AffineFastState.compose env4369 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound4369 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4370 : List Nat := [2,4,8,16,27,16,19,4,1,14,0,0,19,1,27,2,0,26,14,27,0,27,16,25,9,17,1,1,0,27,15,1,4,1,1,1]

theorem envBound4370 : H12AffineFastState.Bounded env4370 := by
  intro p hp
  have h : env4370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4369_4370 : H12AffineEnvironment.transform 9 14 env4369 = env4370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env4369 == env4370) = true)

def env4371 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,41089,73874,41002,8329,73875,323713,16384,16813,22561,74795,94511,256,20480,16644,74542]

theorem envBound4371 : H12AffineFastState.Bounded env4371 := by
  intro p hp
  have h : env4371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4344_4371 : H12AffineEnvironment.transform 21 41089 env4344 = env4371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4344 == env4371) = true)

theorem identity4371 : scanCanonicalize (H12AffineFastState.compose env4371 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound4371 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4372 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8235,4524,262144,1024,32768,4096,41089,185,41002,8329,184,323713,16384,16813,22561,1024,20740,256,20480,16644,773]

theorem envBound4372 : H12AffineFastState.Bounded env4372 := by
  intro p hp
  have h : env4372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4371_4372 : H12AffineEnvironment.transform 15 8235 env4371 = env4372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env4371 == env4372) = true)

theorem identity4372 : scanCanonicalize (H12AffineFastState.compose env4372 (packedSelected [0,1,5,7,8,11,15,20,24,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 61209) := by decide +kernel

theorem selectedBound4372 : packedSelected [0,1,5,7,8,11,15,20,24,32,38] rootPS < 2^1333 := by decide +kernel

def env4373 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8235,4524,61209,1024,32768,4096,41089,185,41002,8329,184,8088,16384,16813,22561,1024,20740,256,20480,16644,773]

theorem envBound4373 : H12AffineFastState.Bounded env4373 := by
  intro p hp
  have h : env4373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4372_4373 : H12AffineEnvironment.transform 17 61209 env4372 = env4373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 61209 env4372 == env4373) = true)

def env4374 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4264,32768,8235,4524,49073,1024,32768,4096,41089,185,41002,8329,184,8088,4264,4357,2185,1024,428,256,168,4524,773]

theorem envBound4374 : H12AffineFastState.Bounded env4374 := by
  intro p hp
  have h : env4374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4373_4374 : H12AffineEnvironment.transform 13 4264 env4373 = env4374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env4373 == env4374) = true)

theorem identity4374 : scanCanonicalize (H12AffineFastState.compose env4374 (packedSelected [17,21] rootPS)) = affineNative (2^(11+1) ^^^ 1944) := by decide +kernel

theorem selectedBound4374 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env4375 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1944,8192,1840,32768,8235,1588,43049,1024,32768,1944,41089,185,41002,8329,184,2048,1840,1693,2185,1024,428,256,168,1588,773]

theorem envBound4375 : H12AffineFastState.Bounded env4375 := by
  intro p hp
  have h : env4375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4374_4375 : H12AffineEnvironment.transform 11 1944 env4374 = env4375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1944 env4374 == env4375) = true)

theorem identity4375 : scanCanonicalize (H12AffineFastState.compose env4375 (packedSelected [1,4,5,8,9,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 8612) := by decide +kernel

theorem selectedBound4375 : packedSelected [1,4,5,8,9,20,24] rootPS < 2^1333 := by decide +kernel

def env4376 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1944,8192,1840,8612,8235,1588,2445,1024,8612,1944,293,185,398,8329,184,2048,1840,1693,2185,1024,428,256,168,1588,773]

theorem envBound4376 : H12AffineFastState.Bounded env4376 := by
  intro p hp
  have h : env4376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4375_4376 : H12AffineEnvironment.transform 14 8612 env4375 = env4376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8612 env4375 == env4376) = true)

theorem identity4376 : scanCanonicalize (H12AffineFastState.compose env4376 (packedSelected [1,2,6,7,8,9,11,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 2948) := by decide +kernel

theorem selectedBound4376 : packedSelected [1,2,6,7,8,9,11,13,15] rootPS < 2^1333 := by decide +kernel

def env4377 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1944,2948,1840,2592,2991,1588,2445,1024,2592,1944,293,185,398,2829,184,2048,1840,1693,2185,1024,428,256,168,1588,773]

theorem envBound4377 : H12AffineFastState.Bounded env4377 := by
  intro p hp
  have h : env4377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4376_4377 : H12AffineEnvironment.transform 12 2948 env4376 = env4377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2948 env4376 == env4377) = true)

theorem identity4377 : scanCanonicalize (H12AffineFastState.compose env4377 (packedSelected [0,1,2,4,6,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4377 : packedSelected [0,1,2,4,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env4378 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1038,1944,1930,1840,1582,1953,1588,1411,1024,1582,1944,293,185,398,1795,184,1038,1840,1693,1159,1024,428,256,168,1588,773]

theorem envBound4378 : H12AffineFastState.Bounded env4378 := by
  intro p hp
  have h : env4378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4377_4378 : H12AffineEnvironment.transform 10 1038 env4377 = env4378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env4377 == env4378) = true)

theorem identity4378 : scanCanonicalize (H12AffineFastState.compose env4378 (packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound4378 : packedSelected [1,2,3,4,5,6,8,9,12,13,18] rootPS < 2^1333 := by decide +kernel

def env4379 : List Nat := [2,4,8,16,32,16,128,256,168,1024,1038,1328,1314,1432,1158,1289,1180,1411,1024,1158,1328,293,185,398,1451,184,1038,1432,1077,1159,1024,428,256,168,1180,429]

theorem envBound4379 : H12AffineFastState.Bounded env4379 := by
  intro p hp
  have h : env4379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4378_4379 : H12AffineEnvironment.transform 8 168 env4378 = env4379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env4378 == env4379) = true)

theorem identity4379 : scanCanonicalize (H12AffineFastState.compose env4379 (packedSelected [6,7] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound4379 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env4380 : List Nat := [2,4,8,16,32,16,128,256,168,266,260,58,40,146,396,3,406,137,266,396,58,293,185,398,161,184,260,146,319,397,266,428,256,168,406,429]

theorem envBound4380 : H12AffineFastState.Bounded env4380 := by
  intro p hp
  have h : env4380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4379_4380 : H12AffineEnvironment.transform 9 266 env4379 = env4380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env4379 == env4380) = true)

theorem identity4380 : scanCanonicalize (H12AffineFastState.compose env4380 (packedSelected [0,1,2,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 19) := by decide +kernel

theorem selectedBound4380 : packedSelected [0,1,2,4,5,6] rootPS < 2^1333 := by decide +kernel

def env4381 : List Nat := [2,4,8,16,32,16,19,256,59,266,260,58,40,1,287,3,261,26,266,287,58,293,42,285,50,43,260,1,319,286,266,319,256,59,261,318]

theorem envBound4381 : H12AffineFastState.Bounded env4381 := by
  intro p hp
  have h : env4381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4380_4381 : H12AffineEnvironment.transform 6 19 env4380 = env4381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 19 env4380 == env4381) = true)

theorem identity4381 : scanCanonicalize (H12AffineFastState.compose env4381 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4381 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4382 : List Nat := [2,4,8,16,27,16,19,256,0,266,260,1,19,1,287,3,261,26,266,287,1,286,17,285,9,16,260,1,260,286,266,260,256,0,261,261]

theorem envBound4382 : H12AffineFastState.Bounded env4382 := by
  intro p hp
  have h : env4382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4381_4382 : H12AffineEnvironment.transform 4 27 env4381 = env4382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4381 == env4382) = true)

theorem identity4382 : scanCanonicalize (H12AffineFastState.compose env4382 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4382 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4383 : List Nat := [2,4,8,16,27,16,19,4,0,14,0,1,19,1,27,3,1,26,14,27,1,26,17,25,9,16,0,1,0,26,14,0,4,0,1,1]

theorem envBound4383 : H12AffineFastState.Bounded env4383 := by
  intro p hp
  have h : env4383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4382_4383 : H12AffineEnvironment.transform 7 4 env4382 = env4383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4382 == env4383) = true)

theorem identity4383 : scanCanonicalize (H12AffineFastState.compose env4383 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound4383 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4384 : List Nat := [2,4,8,5,14,5,6,4,0,14,0,1,6,1,14,3,1,15,14,14,1,15,4,12,9,5,0,1,0,15,14,0,4,0,1,1]

theorem envBound4384 : H12AffineFastState.Bounded env4384 := by
  intro p hp
  have h : env4384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4383_4384 : H12AffineEnvironment.transform 3 5 env4383 = env4384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env4383 == env4384) = true)

theorem identity4384 : scanCanonicalize (H12AffineFastState.compose env4384 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4384 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4385 : List Nat := [2,0,8,1,10,1,2,0,0,10,0,1,2,1,10,3,1,11,10,10,1,11,0,8,9,1,0,1,0,11,10,0,0,0,1,1]

theorem envBound4385 : H12AffineFastState.Bounded env4385 := by
  intro p hp
  have h : env4385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4384_4385 : H12AffineEnvironment.transform 1 0 env4384 = env4385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4384 == env4385) = true)

def leafEnv4385 : List Nat := [2,0,8,1,10,1,2,0,0,10,0,1,2,1,10,3,1,11,10,10,1,11,0,8,10,9,1,1,0,1,0,11,10,0,0,0,0,8,1,1,1,1,0]

def active4385 : List Nat := [0,2]

def tree4385 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4385 : H12WitnessSearch.Good tree4385 := H12GlobalWitnessIndex.good

theorem leafIdentity4385 : H12AffineFastState.composeSystem env4385 rootObs = leafEnv4385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4385 rootObs == leafEnv4385) = true)

theorem terminalChecked4385 : H12PackedTerminal.terminalCheckFast leafEnv4385 active4385 tree4385 = true := by decide +kernel

def env4386 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,8235,4524,49072,1024,32768,4096,41089,185,41002,8329,184,8088,4265,4356,2184,1024,429,256,169,4525,773]

theorem envBound4386 : H12AffineFastState.Bounded env4386 := by
  intro p hp
  have h : env4386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4373_4386 : H12AffineEnvironment.transform 13 4265 env4373 = env4386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env4373 == env4386) = true)

theorem identity4386 : scanCanonicalize (H12AffineFastState.compose env4386 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 14136) := by decide +kernel

theorem selectedBound4386 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env4387 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,14136,8235,4524,2184,1024,14136,4096,6073,185,5906,8329,184,8088,4265,4356,2184,1024,429,256,169,4525,773]

theorem envBound4387 : H12AffineFastState.Bounded env4387 := by
  intro p hp
  have h : env4387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4386_4387 : H12AffineEnvironment.transform 14 14136 env4386 = env4387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14136 env4386 == env4387) = true)

theorem identity4387 : scanCanonicalize (H12AffineFastState.compose env4387 (packedSelected [0,1,4,5,7,8,9,24] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4387 : packedSelected [0,1,4,5,7,8,9,24] rootPS < 2^1333 := by decide +kernel

def env4388 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1692,8192,1589,8612,8235,1840,2184,1024,8612,1692,293,185,398,8329,184,2308,1589,1944,2184,1024,429,256,169,1841,773]

theorem envBound4388 : H12AffineFastState.Bounded env4388 := by
  intro p hp
  have h : env4388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4387_4388 : H12AffineEnvironment.transform 11 1692 env4387 = env4388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4387 == env4388) = true)

theorem identity4388 : scanCanonicalize (H12AffineFastState.compose env4388 (packedSelected [1,2,3,5,6,7,8,9,10,13] rootPS)) = affineNative (2^(12+1) ^^^ 2568) := by decide +kernel

theorem selectedBound4388 : packedSelected [1,2,3,5,6,7,8,9,10,13] rootPS < 2^1333 := by decide +kernel

def env4389 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1692,2568,1589,2988,2595,1840,2184,1024,2988,1692,293,185,398,2689,184,2308,1589,1944,2184,1024,429,256,169,1841,773]

theorem envBound4389 : H12AffineFastState.Bounded env4389 := by
  intro p hp
  have h : env4389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4388_4389 : H12AffineEnvironment.transform 12 2568 env4388 = env4389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2568 env4388 == env4389) = true)

theorem identity4389 : scanCanonicalize (H12AffineFastState.compose env4389 (packedSelected [1,2,3,4,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4389 : packedSelected [1,2,3,4,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env4390 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1692,2568,1589,2729,2595,1589,2184,1024,2729,1692,32,185,139,2689,184,2049,1589,1693,2184,1024,168,5,169,1588,512]

theorem envBound4390 : H12AffineFastState.Bounded env4390 := by
  intro p hp
  have h : env4390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4389_4390 : H12AffineEnvironment.transform 7 5 env4389 = env4390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4389 == env4390) = true)

theorem identity4390 : scanCanonicalize (H12AffineFastState.compose env4390 (packedSelected [0,1,2] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4390 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env4391 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,1589,2568,1589,2560,2595,1589,2081,1024,2560,1589,32,16,34,2600,17,2049,1589,1588,2081,1024,1,5,0,1588,512]

theorem envBound4391 : H12AffineFastState.Bounded env4391 := by
  intro p hp
  have h : env4391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4390_4391 : H12AffineEnvironment.transform 6 41 env4390 = env4391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4390 == env4391) = true)

theorem identity4391 : scanCanonicalize (H12AffineFastState.compose env4391 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound4391 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4392 : List Nat := [2,4,8,16,16,16,25,5,512,1024,2048,1541,2568,1541,2560,2579,1541,2065,1024,2560,1541,16,16,18,2584,17,2049,1541,1540,2065,1024,1,5,0,1540,512]

theorem envBound4392 : H12AffineFastState.Bounded env4392 := by
  intro p hp
  have h : env4392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4391_4392 : H12AffineEnvironment.transform 4 16 env4391 = env4392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env4391 == env4392) = true)

theorem identity4392 : scanCanonicalize (H12AffineFastState.compose env4392 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound4392 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4393 : List Nat := [2,4,8,16,16,16,25,5,512,1024,539,1541,19,1541,27,8,1541,522,1024,27,1541,16,16,18,3,17,538,1541,1540,522,1024,1,5,0,1540,512]

theorem envBound4393 : H12AffineFastState.Bounded env4393 := by
  intro p hp
  have h : env4393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4392_4393 : H12AffineEnvironment.transform 10 539 env4392 = env4393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env4392 == env4393) = true)

theorem identity4393 : scanCanonicalize (H12AffineFastState.compose env4393 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4393 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env4394 : List Nat := [2,4,3,16,16,16,18,5,512,1024,528,1541,19,1541,16,3,1541,513,1024,16,1541,16,16,18,3,17,529,1541,1540,513,1024,1,5,0,1540,512]

theorem envBound4394 : H12AffineFastState.Bounded env4394 := by
  intro p hp
  have h : env4394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4393_4394 : H12AffineEnvironment.transform 2 3 env4393 = env4394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4393 == env4394) = true)

theorem identity4394 : scanCanonicalize (H12AffineFastState.compose env4394 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4394 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4395 : List Nat := [2,4,3,1,1,1,3,5,512,1024,513,1541,2,1541,1,3,1541,513,1024,1,1541,1,1,3,3,0,512,1541,1540,513,1024,1,5,0,1540,512]

theorem envBound4395 : H12AffineFastState.Bounded env4395 := by
  intro p hp
  have h : env4395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4394_4395 : H12AffineEnvironment.transform 3 1 env4394 = env4395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4394 == env4395) = true)

theorem identity4395 : scanCanonicalize (H12AffineFastState.compose env4395 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4396 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1028,2,1028,1,3,1028,0,1024,1,1028,1,1,3,3,0,1,1028,1029,0,1024,1,5,0,1029,1]

theorem envBound4396 : H12AffineFastState.Bounded env4396 := by
  intro p hp
  have h : env4396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4395_4396 : H12AffineEnvironment.transform 8 1 env4395 = env4396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4395 == env4396) = true)

def leafEnv4396 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1028,2,1028,1,3,1028,0,1024,1,1028,1,1,3,1024,3,1,0,1,1028,1029,0,1024,1,5,0,4,3,1029,1,1,1028,0]

def active4396 : List Nat := [0,1,9]

def tree4396 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4396 : H12WitnessSearch.Good tree4396 := H12GlobalWitnessIndex.good

theorem leafIdentity4396 : H12AffineFastState.composeSystem env4396 rootObs = leafEnv4396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4396 rootObs == leafEnv4396) = true)

theorem terminalChecked4396 : H12PackedTerminal.terminalCheckFast leafEnv4396 active4396 tree4396 = true := by decide +kernel

def env4397 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,4194304,73875,41002,8329,73875,323712,16384,16812,22560,74795,4313519,256,20481,16645,74542]

theorem envBound4397 : H12AffineFastState.Bounded env4397 := by
  intro p hp
  have h : env4397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4343_4397 : H12AffineEnvironment.transform 5 17 env4343 = env4397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4343 == env4397) = true)

theorem identity4397 : scanCanonicalize (H12AffineFastState.compose env4397 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4397 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4398 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,4194304,445,41002,8329,445,323712,16384,16812,22560,1285,4255873,256,20481,16645,512]

theorem envBound4398 : H12AffineFastState.Bounded env4398 := by
  intro p hp
  have h : env4398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4397_4398 : H12AffineEnvironment.transform 15 8494 env4397 = env4398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4397 == env4398) = true)

theorem identity4398 : scanCanonicalize (H12AffineFastState.compose env4398 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4398 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4399 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8494,4525,262144,1024,32768,4096,41348,445,41002,8329,445,323712,16384,16812,22560,1285,20741,256,20481,16645,512]

theorem envBound4399 : H12AffineFastState.Bounded env4399 := by
  intro p hp
  have h : env4399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4398_4399 : H12AffineEnvironment.transform 21 41348 env4398 = env4399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4398 == env4399) = true)

theorem identity4399 : scanCanonicalize (H12AffineFastState.compose env4399 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13972) := by decide +kernel

theorem selectedBound4399 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4400 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13972,8494,4525,262144,1024,13972,4096,5904,445,5822,8329,445,280084,16384,16812,22560,1285,20741,256,20481,16645,512]

theorem envBound4400 : H12AffineFastState.Bounded env4400 := by
  intro p hp
  have h : env4400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4399_4400 : H12AffineEnvironment.transform 14 13972 env4399 = env4400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13972 env4399 == env4400) = true)

theorem identity4400 : scanCanonicalize (H12AffineFastState.compose env4400 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound4400 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4401 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,262144,1024,13972,4096,5904,445,5822,8329,445,268216,4524,4096,2444,1285,169,256,429,4265,512]

theorem envBound4401 : H12AffineFastState.Bounded env4401 := by
  intro p hp
  have h : env4401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4400_4401 : H12AffineEnvironment.transform 13 4524 env4400 = env4401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env4400 == env4401) = true)

theorem identity4401 : scanCanonicalize (H12AffineFastState.compose env4401 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 7869) := by decide +kernel

theorem selectedBound4401 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4402 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,13972,8494,4525,7869,1024,13972,4096,5904,445,5822,8329,445,2309,4524,4096,2444,1285,169,256,429,4265,512]

theorem envBound4402 : H12AffineFastState.Bounded env4402 := by
  intro p hp
  have h : env4402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4401_4402 : H12AffineEnvironment.transform 17 7869 env4401 = env4402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7869 env4401 == env4402) = true)

theorem identity4402 : scanCanonicalize (H12AffineFastState.compose env4402 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4402 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env4403 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,4096,8192,4265,13972,8235,4264,7869,1024,13972,4096,5653,184,5822,8329,184,2048,4265,4096,2185,1024,169,5,168,4265,512]

theorem envBound4403 : H12AffineFastState.Bounded env4403 := by
  intro p hp
  have h : env4403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4402_4403 : H12AffineEnvironment.transform 7 5 env4402 = env4403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4402 == env4403) = true)

theorem identity4403 : scanCanonicalize (H12AffineFastState.compose env4403 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound4403 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4404 : List Nat := [2,4,8,16,32,17,128,5,512,1024,2048,1589,8192,1692,8353,8235,1693,2184,1024,8353,1589,32,184,139,8329,184,2048,1692,1589,2185,1024,169,5,168,1692,512]

theorem envBound4404 : H12AffineFastState.Bounded env4404 := by
  intro p hp
  have h : env4404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4403_4404 : H12AffineEnvironment.transform 11 1589 env4403 = env4404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env4403 == env4404) = true)

theorem identity4404 : scanCanonicalize (H12AffineFastState.compose env4404 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 539) := by decide +kernel

theorem selectedBound4404 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env4405 : List Nat := [2,4,8,16,32,17,128,5,512,1024,539,1589,8192,1692,8353,8235,1693,659,1024,8353,1589,32,184,139,8329,184,539,1692,1589,658,1024,169,5,168,1692,512]

theorem envBound4405 : H12AffineFastState.Bounded env4405 := by
  intro p hp
  have h : env4405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4404_4405 : H12AffineEnvironment.transform 10 539 env4404 = env4405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 539 env4404 == env4405) = true)

theorem identity4405 : scanCanonicalize (H12AffineFastState.compose env4405 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound4405 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env4406 : List Nat := [2,4,8,16,32,17,128,5,512,1024,539,1589,41,1692,136,2,1693,659,1024,136,1589,32,184,139,160,184,539,1692,1589,658,1024,169,5,168,1692,512]

theorem envBound4406 : H12AffineFastState.Bounded env4406 := by
  intro p hp
  have h : env4406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4405_4406 : H12AffineEnvironment.transform 12 41 env4405 = env4406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env4405 == env4406) = true)

theorem identity4406 : scanCanonicalize (H12AffineFastState.compose env4406 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4406 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4407 : List Nat := [2,4,8,16,32,17,40,5,512,1024,539,1589,41,1588,32,2,1589,571,1024,32,1589,32,16,35,8,16,539,1588,1589,570,1024,1,5,0,1588,512]

theorem envBound4407 : H12AffineFastState.Bounded env4407 := by
  intro p hp
  have h : env4407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4406_4407 : H12AffineEnvironment.transform 6 40 env4406 = env4407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4406 == env4407) = true)

theorem identity4407 : scanCanonicalize (H12AffineFastState.compose env4407 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4407 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4408 : List Nat := [2,4,8,16,10,17,2,5,512,1024,539,1567,3,1566,10,2,1567,529,1024,10,1567,10,16,9,8,16,539,1566,1567,528,1024,1,5,0,1566,512]

theorem envBound4408 : H12AffineFastState.Bounded env4408 := by
  intro p hp
  have h : env4408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4407_4408 : H12AffineEnvironment.transform 4 10 env4407 = env4408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4407 == env4408) = true)

theorem identity4408 : scanCanonicalize (H12AffineFastState.compose env4408 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4408 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4409 : List Nat := [2,4,8,11,10,10,2,5,512,1024,512,1540,3,1541,10,2,1540,522,1024,10,1540,10,11,9,8,11,512,1541,1540,523,1024,1,5,0,1541,512]

theorem envBound4409 : H12AffineFastState.Bounded env4409 := by
  intro p hp
  have h : env4409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4408_4409 : H12AffineEnvironment.transform 3 11 env4408 = env4409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4408 == env4409) = true)

theorem identity4409 : scanCanonicalize (H12AffineFastState.compose env4409 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4409 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env4410 : List Nat := [2,4,3,0,1,1,2,5,512,1024,512,1540,3,1541,1,2,1540,513,1024,1,1540,1,0,2,3,0,512,1541,1540,512,1024,1,5,0,1541,512]

theorem envBound4410 : H12AffineFastState.Bounded env4410 := by
  intro p hp
  have h : env4410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4409_4410 : H12AffineEnvironment.transform 2 3 env4409 = env4410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4409 == env4410) = true)

theorem identity4410 : scanCanonicalize (H12AffineFastState.compose env4410 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4410 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4411 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1029,3,1028,1,2,1029,0,1024,1,1029,1,0,2,3,0,1,1028,1029,1,1024,1,5,0,1028,1]

theorem envBound4411 : H12AffineFastState.Bounded env4411 := by
  intro p hp
  have h : env4411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4410_4411 : H12AffineEnvironment.transform 8 1 env4410 = env4411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4410 == env4411) = true)

def leafEnv4411 : List Nat := [2,4,3,0,1,1,2,5,1,1024,1,1029,3,1028,1,2,1029,0,1024,1,1029,1,0,2,1024,3,1,0,1,1028,1029,1,1024,1,5,0,4,3,1028,1,1,1028,0]

def active4411 : List Nat := [0,1,9]

def tree4411 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4411 : H12WitnessSearch.Good tree4411 := H12GlobalWitnessIndex.good

theorem leafIdentity4411 : H12AffineFastState.composeSystem env4411 rootObs = leafEnv4411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4411 rootObs == leafEnv4411) = true)

theorem terminalChecked4411 : H12PackedTerminal.terminalCheckFast leafEnv4411 active4411 tree4411 = true := by decide +kernel

def env4412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323792,16384,16893,22640,74794,12644668,257,20561,8479126,8389613]

theorem envBound4412 : H12AffineFastState.Bounded env4412 := by
  intro p hp
  have h : env4412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4341_4412 : H12AffineEnvironment.transform 18 1025 env4341 = env4412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4341 == env4412) = true)

theorem identity4412 : scanCanonicalize (H12AffineFastState.compose env4412 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound4412 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,26051,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323792,16384,16893,22640,16873,12644668,257,20561,8389717,8389613]

theorem envBound4413 : H12AffineFastState.Bounded env4413 := by
  intro p hp
  have h : env4413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4412_4413 : H12AffineEnvironment.transform 15 26051 env4412 = env4413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env4412 == env4413) = true)

def env4414 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,4194304,8388608,41002,8329,8388608,323712,16384,16813,22560,16825,12644668,257,20481,8389637,8389565]

theorem envBound4414 : H12AffineFastState.Bounded env4414 := by
  intro p hp
  have h : env4414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4413_4414 : H12AffineEnvironment.transform 5 16 env4413 = env4414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4413 == env4414) = true)

theorem identity4414 : scanCanonicalize (H12AffineFastState.compose env4414 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4414 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4415 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,4194304,445,41002,8329,445,323712,16384,16813,22560,16825,4255873,257,20481,1464,512]

theorem envBound4415 : H12AffineFastState.Bounded env4415 := by
  intro p hp
  have h : env4415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4414_4415 : H12AffineEnvironment.transform 22 445 env4414 = env4415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4414 == env4415) = true)

theorem identity4415 : scanCanonicalize (H12AffineFastState.compose env4415 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4415 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4416 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4524,262144,1025,32768,4096,41349,445,41002,8329,445,323712,16384,16813,22560,16825,20740,257,20481,1464,512]

theorem envBound4416 : H12AffineFastState.Bounded env4416 := by
  intro p hp
  have h : env4416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4415_4416 : H12AffineEnvironment.transform 21 41349 env4415 = env4416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4415 == env4416) = true)

theorem identity4416 : scanCanonicalize (H12AffineFastState.compose env4416 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29225) := by decide +kernel

theorem selectedBound4416 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4417 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29225,26003,4524,262144,1025,29225,4096,21420,445,20995,8329,445,262825,16384,16813,22560,16825,20740,257,20481,1464,512]

theorem envBound4417 : H12AffineFastState.Bounded env4417 := by
  intro p hp
  have h : env4417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4416_4417 : H12AffineEnvironment.transform 14 29225 env4416 = env4417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29225 env4416 == env4417) = true)

theorem identity4417 : scanCanonicalize (H12AffineFastState.compose env4417 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound4417 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4418 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,16384,26424,26003,1213,262144,1025,26424,1297,18109,445,18194,8329,445,262825,16384,16813,19761,16825,17429,257,17680,1464,512]

theorem envBound4418 : H12AffineFastState.Bounded env4418 := by
  intro p hp
  have h : env4418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4417_4418 : H12AffineEnvironment.transform 11 1297 env4417 = env4418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env4417 == env4418) = true)

theorem identity4418 : scanCanonicalize (H12AffineFastState.compose env4418 (packedSelected [11,12,15,18,23,24,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 1693) := by decide +kernel

theorem selectedBound4418 : packedSelected [11,12,15,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env4419 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1297,8192,1693,8613,8974,1213,262144,1025,8613,1297,32,445,399,8329,445,262825,1693,1840,2988,1828,648,257,909,1464,512]

theorem envBound4419 : H12AffineFastState.Bounded env4419 := by
  intro p hp
  have h : env4419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4418_4419 : H12AffineEnvironment.transform 13 1693 env4418 = env4419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1693 env4418 == env4419) = true)

theorem identity4419 : scanCanonicalize (H12AffineFastState.compose env4419 (packedSelected [8,10,12,15,18,23,24] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4419 : packedSelected [8,10,12,15,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4420 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1693,8200,8867,1213,262144,1025,8200,1212,32,16,34,8329,16,262825,1693,1693,2561,1673,648,172,544,1045,512]

theorem envBound4420 : H12AffineFastState.Bounded env4420 := by
  intro p hp
  have h : env4420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4419_4420 : H12AffineEnvironment.transform 7 173 env4419 = env4420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4419 == env4420) = true)

theorem identity4420 : scanCanonicalize (H12AffineFastState.compose env4420 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4420 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4421 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1212,8192,1693,8200,8867,1213,1583,1025,8200,1212,32,16,34,8329,16,1158,1693,1693,2561,1673,648,172,544,1045,512]

theorem envBound4421 : H12AffineFastState.Bounded env4421 := by
  intro p hp
  have h : env4421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4420_4421 : H12AffineEnvironment.transform 17 1583 env4420 = env4421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1583 env4420 == env4421) = true)

def env4422 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1025,32768,4096,4194304,8388608,41002,8329,8388609,323713,16384,16812,22561,16824,12644668,257,20480,8389636,8389564]

theorem envBound4422 : H12AffineFastState.Bounded env4422 := by
  intro p hp
  have h : env4422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4413_4422 : H12AffineEnvironment.transform 5 17 env4413 = env4422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4413 == env4422) = true)

def env4423 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1025,32768,4096,4194304,4240696,41002,8329,4240697,323713,16384,16812,22561,16824,17412,257,20480,4239676,4241028]

theorem envBound4423 : H12AffineFastState.Bounded env4423 := by
  intro p hp
  have h : env4423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4422_4423 : H12AffineEnvironment.transform 22 4240696 env4422 = env4423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240696 env4422 == env4423) = true)

theorem identity4423 : scanCanonicalize (H12AffineFastState.compose env4423 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13493) := by decide +kernel

theorem selectedBound4423 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4424 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13493,26002,4525,262144,1025,13493,4096,4194304,4194701,5279,8329,4194700,279604,16384,16812,22561,16824,17412,257,20480,4195721,4194865]

theorem envBound4424 : H12AffineFastState.Bounded env4424 := by
  intro p hp
  have h : env4424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4423_4424 : H12AffineEnvironment.transform 14 13493 env4423 = env4424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13493 env4423 == env4424) = true)

def env4425 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1448,8192,16384,8477,26002,1029,262144,1025,8477,1448,4194304,4194701,311,8329,4194700,279604,16384,16812,19849,16824,17412,257,17832,4195721,4194865]

theorem envBound4425 : H12AffineFastState.Bounded env4425 := by
  intro p hp
  have h : env4425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4424_4425 : H12AffineEnvironment.transform 11 1448 env4424 = env4425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env4424 == env4425) = true)

theorem identity4425 : scanCanonicalize (H12AffineFastState.compose env4425 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4425 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4426 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1028,8192,16384,8369,25662,1029,262144,1025,8369,1028,4194304,4194337,155,8329,4194336,279604,16384,16384,19493,16404,17412,173,17412,4195365,4194865]

theorem envBound4426 : H12AffineFastState.Bounded env4426 := by
  intro p hp
  have h : env4426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4425_4426 : H12AffineEnvironment.transform 7 172 env4425 = env4426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4425 == env4426) = true)

theorem identity4426 : scanCanonicalize (H12AffineFastState.compose env4426 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4426 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4427 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,16384,8216,25662,1029,262144,1025,8216,1028,4194304,4194337,50,8224,4194336,279604,16384,16384,19493,16404,17412,4,17412,4195365,4194865]

theorem envBound4427 : H12AffineFastState.Bounded env4427 := by
  intro p hp
  have h : env4427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4426_4427 : H12AffineEnvironment.transform 6 41 env4426 = env4427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4426 == env4427) = true)

theorem identity4427 : scanCanonicalize (H12AffineFastState.compose env4427 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4427 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4428 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,16384,8216,25662,1029,262144,1025,8216,1028,32,1,50,8224,0,279604,16384,16384,19493,16404,17412,4,17412,1029,529]

theorem envBound4428 : H12AffineFastState.Bounded env4428 := by
  intro p hp
  have h : env4428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4427_4428 : H12AffineEnvironment.transform 21 32 env4427 = env4428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4427 == env4428) = true)

theorem identity4428 : scanCanonicalize (H12AffineFastState.compose env4428 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound4428 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4429 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,16384,8216,25662,1029,19508,1025,8216,1028,32,1,50,8224,0,2048,16384,16384,19493,16404,17412,4,17412,1029,529]

theorem envBound4429 : H12AffineFastState.Bounded env4429 := by
  intro p hp
  have h : env4429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4428_4429 : H12AffineEnvironment.transform 17 19508 env4428 = env4429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env4428 == env4429) = true)

theorem identity4429 : scanCanonicalize (H12AffineFastState.compose env4429 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1573) := by decide +kernel

theorem selectedBound4429 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4430 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,8192,1573,8216,8731,1029,2577,1025,8216,1028,32,1,50,8224,0,2048,1573,1573,2560,1585,545,4,545,1029,529]

theorem envBound4430 : H12AffineFastState.Bounded env4430 := by
  intro p hp
  have h : env4430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4429_4430 : H12AffineEnvironment.transform 13 1573 env4429 = env4430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1573 env4429 == env4430) = true)

theorem identity4430 : scanCanonicalize (H12AffineFastState.compose env4430 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound4430 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env4431 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1028,1084,1573,1060,1575,1029,2577,1025,1060,1028,32,1,50,1052,0,2048,1573,1573,2560,1585,545,4,545,1029,529]

theorem envBound4431 : H12AffineFastState.Bounded env4431 := by
  intro p hp
  have h : env4431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4430_4431 : H12AffineEnvironment.transform 12 1084 env4430 = env4431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env4430 == env4431) = true)

theorem identity4431 : scanCanonicalize (H12AffineFastState.compose env4431 (packedSelected [3,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4431 : packedSelected [3,6,8,11] rootPS < 2^1333 := by decide +kernel

def env4432 : List Nat := [2,4,8,16,32,17,41,5,512,1024,1550,1028,1084,1573,1060,1575,1029,1055,1025,1060,1028,32,1,50,1052,0,1550,1573,1573,1038,1585,545,4,545,1029,529]

theorem envBound4432 : H12AffineFastState.Bounded env4432 := by
  intro p hp
  have h : env4432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4431_4432 : H12AffineEnvironment.transform 10 1550 env4431 = env4432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4431 == env4432) = true)

theorem identity4432 : scanCanonicalize (H12AffineFastState.compose env4432 (packedSelected [0,2,5,6,7,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound4432 : packedSelected [0,2,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env4433 : List Nat := [2,4,8,16,32,17,41,5,512,20,538,16,40,561,48,563,17,11,21,48,16,32,1,50,8,0,538,561,561,26,549,545,4,545,17,529]

theorem envBound4433 : H12AffineFastState.Bounded env4433 := by
  intro p hp
  have h : env4433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4432_4433 : H12AffineEnvironment.transform 9 20 env4432 = env4433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env4432 == env4433) = true)

theorem identity4433 : scanCanonicalize (H12AffineFastState.compose env4433 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4433 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4434 : List Nat := [2,4,8,16,32,17,41,5,33,20,59,16,40,16,48,18,17,11,21,48,16,32,1,50,8,0,59,16,16,26,4,0,4,0,17,48]

theorem envBound4434 : H12AffineFastState.Bounded env4434 := by
  intro p hp
  have h : env4434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4433_4434 : H12AffineEnvironment.transform 8 33 env4433 = env4434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4433 == env4434) = true)

theorem identity4434 : scanCanonicalize (H12AffineFastState.compose env4434 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound4434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4435 : List Nat := [2,4,8,16,27,17,18,5,26,20,0,16,19,16,11,18,17,11,21,11,16,27,1,9,8,0,0,16,16,26,4,0,4,0,17,11]

theorem envBound4435 : H12AffineFastState.Bounded env4435 := by
  intro p hp
  have h : env4435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4434_4435 : H12AffineEnvironment.transform 4 27 env4434 = env4435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env4434 == env4435) = true)

def env4436 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1449,8192,16384,8476,26002,1028,262144,1025,8476,1449,4194304,4194701,310,8329,4194700,279604,16384,16812,19848,16824,17412,257,17833,4195721,4194865]

theorem envBound4436 : H12AffineFastState.Bounded env4436 := by
  intro p hp
  have h : env4436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4424_4436 : H12AffineEnvironment.transform 11 1449 env4424 = env4436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env4424 == env4436) = true)

theorem identity4436 : scanCanonicalize (H12AffineFastState.compose env4436 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

end H12CloudChart1