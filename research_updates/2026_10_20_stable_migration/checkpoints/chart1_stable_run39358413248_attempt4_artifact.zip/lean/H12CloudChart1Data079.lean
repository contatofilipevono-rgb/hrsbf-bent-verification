import H12CloudChart1Data078

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound19965 : H12AffineFastState.Bounded env19965 := by
  intro p hp
  have h : env19965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19964_19965 : H12AffineEnvironment.transform 4 1 env19964 = env19965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19964 == env19965) = true)

theorem identity19965 : scanCanonicalize (H12AffineFastState.compose env19965 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19965 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19966 : List Nat := [2,4,8,16,1,16,128,5,512,1024,2048,4096,128,5125,136,2,5140,2048,1025,137,4113,1,152,138,8,16,2185,5276,4232,2049,1160,137,4,0,5261,648]

theorem envBound19966 : H12AffineFastState.Bounded env19966 := by
  intro p hp
  have h : env19966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19965_19966 : H12AffineEnvironment.transform 5 16 env19965 = env19966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19965 == env19966) = true)

theorem identity19966 : scanCanonicalize (H12AffineFastState.compose env19966 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19966 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19967 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5125,0,2,5140,2048,1025,1,4113,1,16,2,8,16,2049,5140,4096,2049,1024,1,4,0,5125,512]

theorem envBound19967 : H12AffineFastState.Bounded env19967 := by
  intro p hp
  have h : env19967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19966_19967 : H12AffineEnvironment.transform 6 8 env19966 = env19967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19966 == env19967) = true)

def env19968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237469,243089,8328,64,2144660,2240796,160076,2417693,2102684,2373705,257,21793,46213,2175563]

theorem envBound19968 : H12AffineFastState.Bounded env19968 := by
  intro p hp
  have h : env19968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19931_19968 : H12AffineEnvironment.transform 21 452633 env19931 = env19968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env19931 == env19968) = true)

def env19969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144477,243089,8328,64,43476,139612,160076,324701,1500,272393,257,21793,46213,74251]

theorem envBound19969 : H12AffineFastState.Bounded env19969 := by
  intro p hp
  have h : env19969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19968_19969 : H12AffineEnvironment.transform 20 4160 env19968 = env19969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19968 == env19969) = true)

theorem identity19969 : scanCanonicalize (H12AffineFastState.compose env19969 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound19969 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,4160,329867,120015,21763,8328,64,43476,115150,102878,324701,1500,272393,257,21793,46213,74251]

theorem envBound19970 : H12AffineFastState.Bounded env19970 := by
  intro p hp
  have h : env19970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19969_19970 : H12AffineEnvironment.transform 16 123026 env19969 = env19970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env19969 == env19970) = true)

def env19971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10400,1025,32769,4160,73771,120015,21763,8328,64,43476,115150,102878,56573,1500,169,257,21793,46213,74251]

theorem envBound19971 : H12AffineFastState.Bounded env19971 := by
  intro p hp
  have h : env19971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19970_19971 : H12AffineEnvironment.transform 17 10400 env19970 = env19971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19970 == env19971) = true)

def env19972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1025,32769,4160,73771,119879,21763,8192,64,43356,115014,102742,56437,1364,33,257,21793,46093,74251]

theorem envBound19972 : H12AffineFastState.Bounded env19972 := by
  intro p hp
  have h : env19972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19971_19972 : H12AffineEnvironment.transform 6 8 env19971 = env19972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19971 == env19972) = true)

theorem identity19972 : scanCanonicalize (H12AffineFastState.compose env19972 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound19972 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,24908,10280,1025,32769,4160,41341,21777,21763,8192,64,43356,16400,4096,56437,1364,33,257,21793,46093,41821]

theorem envBound19973 : H12AffineFastState.Bounded env19973 := by
  intro p hp
  have h : env19973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19972_19973 : H12AffineEnvironment.transform 15 33110 env19972 = env19973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env19972 == env19973) = true)

theorem identity19973 : scanCanonicalize (H12AffineFastState.compose env19973 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound19973 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,32768,33110,4096,10280,1025,32769,4160,41341,9309,9295,8192,64,43356,12636,4096,44345,1364,33,257,9325,46093,41821]

theorem envBound19974 : H12AffineFastState.Bounded env19974 := by
  intro p hp
  have h : env19974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19973_19974 : H12AffineEnvironment.transform 13 12620 env19973 = env19974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env19973 == env19974) = true)

theorem identity19974 : scanCanonicalize (H12AffineFastState.compose env19974 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19974 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env19975 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,12620,32768,33110,4096,10280,273,32769,4160,41341,8525,8543,8192,64,43356,12636,4096,43049,68,33,257,8573,45341,41821]

theorem envBound19975 : H12AffineFastState.Bounded env19975 := by
  intro p hp
  have h : env19975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19974_19975 : H12AffineEnvironment.transform 9 272 env19974 = env19975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19974 == env19975) = true)

def env19976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1025,32769,4160,73771,119878,21763,8193,64,43357,115015,102743,56436,1365,32,257,21793,46092,74251]

theorem envBound19976 : H12AffineFastState.Bounded env19976 := by
  intro p hp
  have h : env19976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19971_19976 : H12AffineEnvironment.transform 6 9 env19971 = env19976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19971 == env19976) = true)

theorem identity19976 : scanCanonicalize (H12AffineFastState.compose env19976 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19976 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10281,1025,32769,4160,33,62540,21763,8193,64,43357,57677,45405,56436,1365,32,257,21793,46092,513]

theorem envBound19977 : H12AffineFastState.Bounded env19977 := by
  intro p hp
  have h : env19977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19976_19977 : H12AffineEnvironment.transform 15 8202 env19976 = env19977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19976 == env19977) = true)

theorem identity19977 : scanCanonicalize (H12AffineFastState.compose env19977 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19977 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env19978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,24908,10281,1025,8540,4160,33,21777,21763,8193,64,2048,16400,4096,32041,1365,32,257,21793,5457,513]

theorem envBound19978 : H12AffineFastState.Bounded env19978 := by
  intro p hp
  have h : env19978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19977_19978 : H12AffineEnvironment.transform 14 8541 env19977 = env19978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19977 == env19978) = true)

theorem identity19978 : scanCanonicalize (H12AffineFastState.compose env19978 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound19978 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,13388,10281,1025,8540,4160,33,17,3,8193,64,2048,5392,4096,10281,1365,32,257,33,5457,513]

theorem envBound19979 : H12AffineFastState.Bounded env19979 := by
  intro p hp
  have h : env19979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19978_19979 : H12AffineEnvironment.transform 13 5376 env19978 = env19979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19978 == env19979) = true)

theorem identity19979 : scanCanonicalize (H12AffineFastState.compose env19979 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19979 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19980 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,13340,10281,1025,8460,4112,33,17,3,8193,16,2048,5392,4096,10281,1285,32,257,33,5377,513]

theorem envBound19980 : H12AffineFastState.Bounded env19980 := by
  intro p hp
  have h : env19980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19979_19980 : H12AffineEnvironment.transform 5 16 env19979 = env19980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19979 == env19980) = true)

theorem identity19980 : scanCanonicalize (H12AffineFastState.compose env19980 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19980 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19981 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,40,5376,293,34,5172,2049,1025,292,4112,33,17,3,41,16,2048,5392,4096,2049,1285,32,257,33,5377,513]

theorem envBound19981 : H12AffineFastState.Bounded env19981 := by
  intro p hp
  have h : env19981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19980_19981 : H12AffineEnvironment.transform 12 40 env19980 = env19981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19980 == env19981) = true)

theorem identity19981 : scanCanonicalize (H12AffineFastState.compose env19981 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19981 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env19982 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,34,5172,2049,1025,1,4112,33,17,3,41,16,2048,5173,4096,2049,1056,32,36,33,5156,513]

theorem envBound19982 : H12AffineFastState.Bounded env19982 := by
  intro p hp
  have h : env19982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19981_19982 : H12AffineEnvironment.transform 7 37 env19981 = env19982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19981 == env19982) = true)

theorem identity19982 : scanCanonicalize (H12AffineFastState.compose env19982 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19982 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19983 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,4096,40,4113,0,34,4096,2049,53,1,4112,33,17,3,41,16,2048,4097,4096,2049,20,32,36,33,4112,513]

theorem envBound19983 : H12AffineFastState.Bounded env19983 := by
  intro p hp
  have h : env19983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19982_19983 : H12AffineEnvironment.transform 9 52 env19982 = env19983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19982 == env19983) = true)

theorem identity19983 : scanCanonicalize (H12AffineFastState.compose env19983 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound19983 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19984 : List Nat := [2,4,8,16,4,16,9,1,512,16,2048,4096,12,4113,0,6,4096,2049,17,1,4112,5,17,3,13,16,2048,4097,4096,2049,20,4,0,5,4112,513]

theorem envBound19984 : H12AffineFastState.Bounded env19984 := by
  intro p hp
  have h : env19984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19983_19984 : H12AffineEnvironment.transform 4 4 env19983 = env19984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env19983 == env19984) = true)

theorem identity19984 : scanCanonicalize (H12AffineFastState.compose env19984 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2584) := by decide +kernel

theorem selectedBound19984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19985 : List Nat := [2,4,8,16,4,16,9,1,512,16,2048,2584,12,2569,0,6,2584,2049,17,1,2568,5,17,3,13,16,2048,2585,2584,2049,20,4,0,5,2568,513]

theorem envBound19985 : H12AffineFastState.Bounded env19985 := by
  intro p hp
  have h : env19985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19984_19985 : H12AffineEnvironment.transform 11 2584 env19984 = env19985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2584 env19984 == env19985) = true)

theorem identity19985 : scanCanonicalize (H12AffineFastState.compose env19985 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound19985 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19986 : List Nat := [2,4,8,16,4,16,9,1,512,16,522,18,12,3,0,6,18,523,17,1,2,5,17,3,13,16,522,19,18,523,20,4,0,5,2,513]

theorem envBound19986 : H12AffineFastState.Bounded env19986 := by
  intro p hp
  have h : env19986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19985_19986 : H12AffineEnvironment.transform 10 522 env19985 = env19986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env19985 == env19986) = true)

theorem identity19986 : scanCanonicalize (H12AffineFastState.compose env19986 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound19986 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19987 : List Nat := [2,1,8,16,1,16,9,1,512,16,522,18,9,3,0,3,18,523,17,1,2,0,17,3,8,16,522,19,18,523,17,1,0,0,2,513]

theorem envBound19987 : H12AffineFastState.Bounded env19987 := by
  intro p hp
  have h : env19987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19986_19987 : H12AffineEnvironment.transform 1 1 env19986 = env19987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env19986 == env19987) = true)

def env19988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,10401,1025,32769,4160,73770,120015,21763,8328,64,43476,115150,102878,56572,1500,168,257,21793,46213,74251]

theorem envBound19988 : H12AffineFastState.Bounded env19988 := by
  intro p hp
  have h : env19988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19970_19988 : H12AffineEnvironment.transform 17 10401 env19970 = env19988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19970 == env19988) = true)

def env19989 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1025,32769,4160,73770,119879,21763,8192,64,43356,115014,102742,56436,1364,32,257,21793,46093,74251]

theorem envBound19989 : H12AffineFastState.Bounded env19989 := by
  intro p hp
  have h : env19989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19988_19989 : H12AffineEnvironment.transform 6 8 env19988 = env19989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19988 == env19989) = true)

theorem identity19989 : scanCanonicalize (H12AffineFastState.compose env19989 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound19989 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111899,10281,1025,32769,4160,73770,98630,2,8192,64,43356,103495,102742,35189,1364,32,257,32,46093,74251]

theorem envBound19990 : H12AffineFastState.Bounded env19990 := by
  intro p hp
  have h : env19990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19989_19990 : H12AffineEnvironment.transform 13 5377 env19989 = env19990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19989 == env19990) = true)

theorem identity19990 : scanCanonicalize (H12AffineFastState.compose env19990 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound19990 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,32768,65536,103730,2048,1025,32769,4160,65539,98630,2,41,64,35189,103495,102742,35189,1364,32,257,32,37924,66082]

theorem envBound19991 : H12AffineFastState.Bounded env19991 := by
  intro p hp
  have h : env19991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19990_19991 : H12AffineEnvironment.transform 12 41 env19990 = env19991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19990 == env19991) = true)

theorem identity19991 : scanCanonicalize (H12AffineFastState.compose env19991 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound19991 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env19992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,32768,33111,5221,2048,1025,32769,4160,33108,17,2,41,64,35189,5392,4097,35189,1364,32,257,32,37924,33653]

theorem envBound19992 : H12AffineFastState.Bounded env19992 := by
  intro p hp
  have h : env19992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19991_19992 : H12AffineEnvironment.transform 15 33111 env19991 = env19992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env19991 == env19992) = true)

theorem identity19992 : scanCanonicalize (H12AffineFastState.compose env19992 (packedSelected [0,4,6,7,9,12] rootPS)) = affineNative (2^(14+1) ^^^ 3172) := by decide +kernel

theorem selectedBound19992 : packedSelected [0,4,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env19993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5377,3172,3379,5221,2048,1025,3173,4160,3376,17,2,41,64,1297,5392,4097,1297,1364,32,257,32,6208,3857]

theorem envBound19993 : H12AffineFastState.Bounded env19993 := by
  intro p hp
  have h : env19993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19992_19993 : H12AffineEnvironment.transform 14 3172 env19992 = env19993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 3172 env19992 == env19993) = true)

theorem identity19993 : scanCanonicalize (H12AffineFastState.compose env19993 (packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19993 : packedSelected [0,1,2,3,4,5,6,7,8,9,14] rootPS < 2^1333 := by decide +kernel

def env19994 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5156,3172,3094,5221,2048,1025,3173,4160,3093,17,2,41,64,1076,5173,4097,1076,1137,32,36,32,6208,3636]

theorem envBound19994 : H12AffineFastState.Bounded env19994 := by
  intro p hp
  have h : env19994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19993_19994 : H12AffineEnvironment.transform 7 37 env19993 = env19994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19993 == env19994) = true)

theorem identity19994 : scanCanonicalize (H12AffineFastState.compose env19994 (packedSelected [0,1,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19994 : packedSelected [0,1,8,9,11] rootPS < 2^1333 := by decide +kernel

def env19995 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,4096,41,4161,2049,2163,4096,2048,100,2048,4160,2160,17,2,41,64,81,4176,4097,81,20,32,36,32,6208,2641]

theorem envBound19995 : H12AffineFastState.Bounded env19995 := by
  intro p hp
  have h : env19995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19994_19995 : H12AffineEnvironment.transform 9 101 env19994 = env19995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19994 == env19995) = true)

theorem identity19995 : scanCanonicalize (H12AffineFastState.compose env19995 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound19995 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env19996 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,2112,41,2049,2049,2163,2112,2048,100,2048,2048,2160,17,2,41,64,81,2064,2113,81,20,32,36,32,0,2641]

theorem envBound19996 : H12AffineFastState.Bounded env19996 := by
  intro p hp
  have h : env19996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19995_19996 : H12AffineEnvironment.transform 11 2112 env19995 = env19996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env19995 == env19996) = true)

theorem identity19996 : scanCanonicalize (H12AffineFastState.compose env19996 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19996 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env19997 : List Nat := [2,4,8,16,32,64,8,37,512,101,0,64,41,1,1,115,64,0,100,0,0,112,17,2,41,64,81,16,65,81,20,32,36,32,0,593]

theorem envBound19997 : H12AffineFastState.Bounded env19997 := by
  intro p hp
  have h : env19997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19996_19997 : H12AffineEnvironment.transform 10 0 env19996 = env19997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19996 == env19997) = true)

theorem identity19997 : scanCanonicalize (H12AffineFastState.compose env19997 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19997 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19998 : List Nat := [2,4,8,16,0,64,8,5,512,69,0,64,9,1,1,83,64,0,68,0,0,80,17,2,9,64,81,16,65,81,20,0,4,0,0,593]

theorem envBound19998 : H12AffineFastState.Bounded env19998 := by
  intro p hp
  have h : env19998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19997_19998 : H12AffineEnvironment.transform 4 0 env19997 = env19998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19997 == env19998) = true)

def env19999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,4160,73770,119878,21763,8193,64,43357,115015,102743,56437,1365,33,257,21793,46092,74251]

theorem envBound19999 : H12AffineFastState.Bounded env19999 := by
  intro p hp
  have h : env19999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19988_19999 : H12AffineEnvironment.transform 6 9 env19988 = env19999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19988 == env19999) = true)

theorem identity19999 : scanCanonicalize (H12AffineFastState.compose env19999 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound19999 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,70727,10280,1025,29789,4160,73770,73754,21763,8193,64,23809,79131,91403,10281,1365,33,257,21793,16464,74251]

theorem envBound20000 : H12AffineFastState.Bounded env20000 := by
  intro p hp
  have h : env20000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19999_20000 : H12AffineEnvironment.transform 14 29788 env19999 = env20000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env19999 == env20000) = true)

theorem identity20000 : scanCanonicalize (H12AffineFastState.compose env20000 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20000 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env20001 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,13389,10280,1025,29789,4160,32,16,21763,8193,64,23809,5393,17665,10281,1365,33,257,21793,16464,513]

theorem envBound20001 : H12AffineFastState.Bounded env20001 := by
  intro p hp
  have h : env20001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20000_20001 : H12AffineEnvironment.transform 15 8202 env20000 = env20001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20000 == env20001) = true)

theorem identity20001 : scanCanonicalize (H12AffineFastState.compose env20001 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound20001 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env20002 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,9293,8202,13389,10280,1025,9292,4160,32,16,1298,8193,64,3344,5393,5392,10281,1365,33,257,1328,4161,513]

theorem envBound20002 : H12AffineFastState.Bounded env20002 := by
  intro p hp
  have h : env20002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20001_20002 : H12AffineEnvironment.transform 13 4113 env20001 = env20002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env20001 == env20002) = true)

theorem identity20002 : scanCanonicalize (H12AffineFastState.compose env20002 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound20002 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env20003 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,65,8192,80,9293,8202,9228,10280,1025,9292,1,32,16,1298,8193,64,3344,1360,1361,10281,1365,33,257,1328,0,513]

theorem envBound20003 : H12AffineFastState.Bounded env20003 := by
  intro p hp
  have h : env20003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20002_20003 : H12AffineEnvironment.transform 11 65 env20002 = env20003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env20002 == env20003) = true)

theorem identity20003 : scanCanonicalize (H12AffineFastState.compose env20003 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound20003 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20004 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,65,8192,80,8540,8202,8477,10280,272,8541,1,32,16,3,8193,64,2049,65,64,10281,68,33,257,33,0,513]

theorem envBound20004 : H12AffineFastState.Bounded env20004 := by
  intro p hp
  have h : env20004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20003_20004 : H12AffineEnvironment.transform 9 273 env20003 = env20004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20003 == env20004) = true)

theorem identity20004 : scanCanonicalize (H12AffineFastState.compose env20004 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20004 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20005 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,65,348,80,0,342,65,2420,272,1,1,32,16,3,349,64,2049,65,64,2421,68,33,257,33,0,513]

theorem envBound20005 : H12AffineFastState.Bounded env20005 := by
  intro p hp
  have h : env20005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20004_20005 : H12AffineEnvironment.transform 12 348 env20004 = env20005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20004 == env20005) = true)

theorem identity20005 : scanCanonicalize (H12AffineFastState.compose env20005 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound20005 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20006 : List Nat := [2,4,8,16,32,64,9,53,512,36,2048,65,105,80,0,99,65,2113,37,1,1,32,16,3,104,64,2049,65,64,2112,68,33,52,33,0,513]

theorem envBound20006 : H12AffineFastState.Bounded env20006 := by
  intro p hp
  have h : env20006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20005_20006 : H12AffineEnvironment.transform 7 53 env20005 = env20006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env20005 == env20006) = true)

theorem identity20006 : scanCanonicalize (H12AffineFastState.compose env20006 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound20006 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20007 : List Nat := [2,4,8,16,32,64,9,53,512,36,26,65,105,80,0,99,65,91,37,1,1,32,16,3,104,64,27,65,64,90,68,33,52,33,0,513]

theorem envBound20007 : H12AffineFastState.Bounded env20007 := by
  intro p hp
  have h : env20007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20006_20007 : H12AffineEnvironment.transform 10 26 env20006 = env20007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env20006 == env20007) = true)

theorem identity20007 : scanCanonicalize (H12AffineFastState.compose env20007 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound20007 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20008 : List Nat := [2,4,8,16,32,59,9,53,512,36,26,58,18,43,0,24,58,32,37,1,1,32,16,3,19,59,27,58,59,33,63,33,52,33,0,513]

theorem envBound20008 : H12AffineFastState.Bounded env20008 := by
  intro p hp
  have h : env20008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20007_20008 : H12AffineEnvironment.transform 5 59 env20007 = env20008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env20007 == env20008) = true)

theorem identity20008 : scanCanonicalize (H12AffineFastState.compose env20008 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20008 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20009 : List Nat := [2,4,8,0,32,43,9,37,512,36,10,42,2,43,0,8,42,32,37,1,1,32,0,3,3,43,11,42,43,33,47,33,36,33,0,513]

theorem envBound20009 : H12AffineFastState.Bounded env20009 := by
  intro p hp
  have h : env20009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20008_20009 : H12AffineEnvironment.transform 3 0 env20008 = env20009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20008 == env20009) = true)

theorem identity20009 : scanCanonicalize (H12AffineFastState.compose env20009 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound20009 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20010 : List Nat := [2,4,0,0,32,35,1,37,512,36,2,34,2,35,0,0,34,32,37,1,1,32,0,3,3,35,3,34,35,33,39,33,36,33,0,513]

theorem envBound20010 : H12AffineFastState.Bounded env20010 := by
  intro p hp
  have h : env20010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20009_20010 : H12AffineEnvironment.transform 2 0 env20009 = env20010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env20009 == env20010) = true)

def env20011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144476,243089,8328,64,43477,139613,160076,324700,1501,272392,257,21793,46213,74250]

theorem envBound20011 : H12AffineFastState.Bounded env20011 := by
  intro p hp
  have h : env20011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19968_20011 : H12AffineEnvironment.transform 20 4161 env19968 = env20011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19968 == env20011) = true)

theorem identity20011 : scanCanonicalize (H12AffineFastState.compose env20011 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20011 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,452633,144476,169370,8328,64,43477,139613,160076,324700,1501,272392,257,21793,46213,513]

theorem envBound20012 : H12AffineFastState.Bounded env20012 := by
  intro p hp
  have h : env20012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20011_20012 : H12AffineEnvironment.transform 15 8203 env20011 = env20012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20011 == env20012) = true)

def env20013 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,305161,29772,54666,8328,64,43477,24909,12636,324700,1501,272392,257,21793,46213,513]

theorem envBound20013 : H12AffineFastState.Bounded env20013 := by
  intro p hp
  have h : env20013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20012_20013 : H12AffineEnvironment.transform 16 16400 env20012 = env20013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20012 == env20013) = true)

theorem identity20013 : scanCanonicalize (H12AffineFastState.compose env20013 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound20013 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13389,262144,1025,32769,4161,305161,17,41431,8328,64,43477,5392,12636,294913,1501,272392,257,8572,46213,513]

theorem envBound20014 : H12AffineFastState.Bounded env20014 := by
  intro p hp
  have h : env20014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20013_20014 : H12AffineEnvironment.transform 13 13405 env20013 = env20014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env20013 == env20014) = true)

theorem identity20014 : scanCanonicalize (H12AffineFastState.compose env20014 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43168) := by decide +kernel

theorem selectedBound20014 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env20015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13389,43168,1025,32769,4161,169,17,41431,8328,64,43477,5392,12636,10401,1501,32936,257,8572,46213,513]

theorem envBound20015 : H12AffineFastState.Bounded env20015 := by
  intro p hp
  have h : env20015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20014_20015 : H12AffineEnvironment.transform 17 43168 env20014 = env20015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43168 env20014 == env20015) = true)

theorem identity20015 : scanCanonicalize (H12AffineFastState.compose env20015 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound20015 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env20016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8660,8203,13389,2420,1025,8661,4161,169,17,3,8328,64,2049,5392,12636,10401,1501,8572,257,8572,5457,513]

theorem envBound20016 : H12AffineFastState.Bounded env20016 := by
  intro p hp
  have h : env20016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20015_20016 : H12AffineEnvironment.transform 14 8660 env20015 = env20016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env20015 == env20016) = true)

theorem identity20016 : scanCanonicalize (H12AffineFastState.compose env20016 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound20016 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,0,479,5529,2420,1025,1,4161,169,17,3,348,64,2049,5392,4232,2421,1501,168,257,168,5457,513]

theorem envBound20017 : H12AffineFastState.Bounded env20017 := by
  intro p hp
  have h : env20017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20016_20017 : H12AffineEnvironment.transform 12 468 env20016 = env20017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env20016 == env20017) = true)

theorem identity20017 : scanCanonicalize (H12AffineFastState.compose env20017 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1432) := by decide +kernel

theorem selectedBound20017 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env20018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1432,468,17,0,479,1,2420,1025,1,1497,169,17,3,348,64,2049,136,1296,2421,1501,168,257,168,201,513]

theorem envBound20018 : H12AffineFastState.Bounded env20018 := by
  intro p hp
  have h : env20018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20017_20018 : H12AffineEnvironment.transform 11 1432 env20017 = env20018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env20017 == env20018) = true)

theorem identity20018 : scanCanonicalize (H12AffineFastState.compose env20018 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound20018 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env20019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,130,1432,468,17,0,479,1,502,1025,1,1497,169,17,3,348,64,131,136,1296,503,1501,168,257,168,201,513]

theorem envBound20019 : H12AffineFastState.Bounded env20019 := by
  intro p hp
  have h : env20019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20018_20019 : H12AffineEnvironment.transform 10 130 env20018 = env20019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env20018 == env20019) = true)

theorem identity20019 : scanCanonicalize (H12AffineFastState.compose env20019 (packedSelected [4,9,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20019 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env20020 : List Nat := [2,4,8,16,32,64,9,256,512,1024,11,1297,349,17,0,342,1,383,1025,1,1360,32,17,3,348,64,10,1,1296,382,1364,33,257,33,64,513]

theorem envBound20020 : H12AffineFastState.Bounded env20020 := by
  intro p hp
  have h : env20020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20019_20020 : H12AffineEnvironment.transform 6 9 env20019 = env20020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20019 == env20020) = true)

theorem identity20020 : scanCanonicalize (H12AffineFastState.compose env20020 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20020 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20021 : List Nat := [2,4,8,16,32,16,9,256,512,1024,11,1297,269,17,0,262,1,303,1025,1,1280,32,17,3,268,16,10,1,1296,302,1284,33,257,33,16,513]

theorem envBound20021 : H12AffineFastState.Bounded env20021 := by
  intro p hp
  have h : env20021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20020_20021 : H12AffineEnvironment.transform 5 16 env20020 = env20021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20020 == env20021) = true)

theorem identity20021 : scanCanonicalize (H12AffineFastState.compose env20021 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20021 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20022 : List Nat := [2,4,8,0,32,0,9,256,512,1024,11,1281,269,1,0,262,1,303,1025,1,1280,32,1,3,268,0,10,1,1280,302,1284,33,257,33,0,513]

theorem envBound20022 : H12AffineFastState.Bounded env20022 := by
  intro p hp
  have h : env20022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20021_20022 : H12AffineEnvironment.transform 3 0 env20021 = env20022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20021 == env20022) = true)

theorem identity20022 : scanCanonicalize (H12AffineFastState.compose env20022 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound20022 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20023 : List Nat := [2,4,8,0,11,0,9,256,512,1024,11,1281,269,1,0,262,1,260,1025,1,1280,11,1,3,268,0,10,1,1280,261,1284,10,257,10,0,513]

theorem envBound20023 : H12AffineFastState.Bounded env20023 := by
  intro p hp
  have h : env20023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20022_20023 : H12AffineEnvironment.transform 4 11 env20022 = env20023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env20022 == env20023) = true)

theorem identity20023 : scanCanonicalize (H12AffineFastState.compose env20023 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound20023 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20024 : List Nat := [2,4,8,0,11,0,9,256,512,256,11,1,269,1,0,262,1,260,257,1,0,11,1,3,268,0,10,1,0,261,4,10,257,10,0,513]

theorem envBound20024 : H12AffineFastState.Bounded env20024 := by
  intro p hp
  have h : env20024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20023_20024 : H12AffineEnvironment.transform 9 256 env20023 = env20024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env20023 == env20024) = true)

theorem identity20024 : scanCanonicalize (H12AffineFastState.compose env20024 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 12) := by decide +kernel

theorem selectedBound20024 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20025 : List Nat := [2,4,8,0,11,0,9,12,512,12,11,1,1,1,0,10,1,8,13,1,0,11,1,3,0,0,10,1,0,9,4,10,13,10,0,513]

theorem envBound20025 : H12AffineFastState.Bounded env20025 := by
  intro p hp
  have h : env20025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20024_20025 : H12AffineEnvironment.transform 7 12 env20024 = env20025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 12 env20024 == env20025) = true)

theorem identity20025 : scanCanonicalize (H12AffineFastState.compose env20025 (packedSelected [8] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound20025 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env20026 : List Nat := [2,4,1,0,2,0,0,5,512,5,2,1,1,1,0,3,1,1,4,1,0,2,1,3,0,0,3,1,0,0,4,3,4,3,0,513]

theorem envBound20026 : H12AffineFastState.Bounded env20026 := by
  intro p hp
  have h : env20026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20025_20026 : H12AffineEnvironment.transform 2 1 env20025 = env20026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env20025 == env20026) = true)

theorem identity20026 : scanCanonicalize (H12AffineFastState.compose env20026 (packedSelected [0,9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound20026 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env20027 : List Nat := [0,4,1,0,0,0,0,5,512,5,0,1,1,1,0,1,1,1,4,1,0,0,1,1,0,0,1,1,0,0,4,1,4,1,0,513]

theorem envBound20027 : H12AffineFastState.Bounded env20027 := by
  intro p hp
  have h : env20027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20026_20027 : H12AffineEnvironment.transform 0 0 env20026 = env20027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env20026 == env20027) = true)

theorem identity20027 : scanCanonicalize (H12AffineFastState.compose env20027 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound20027 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20028 : List Nat := [0,4,1,0,0,0,0,5,5,5,0,1,1,1,0,1,1,1,4,1,0,0,1,1,0,0,1,1,0,0,4,1,4,1,0,4]

theorem envBound20028 : H12AffineFastState.Bounded env20028 := by
  intro p hp
  have h : env20028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20027_20028 : H12AffineEnvironment.transform 8 5 env20027 = env20028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env20027 == env20028) = true)

def env20029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,305160,29773,54667,8328,64,43477,24908,12637,324700,1501,272392,257,21793,46213,513]

theorem envBound20029 : H12AffineFastState.Bounded env20029 := by
  intro p hp
  have h : env20029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20012_20029 : H12AffineEnvironment.transform 16 16401 env20012 = env20029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20012 == env20029) = true)

def env20030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,305160,29773,54531,8192,64,43357,24908,12637,324700,1365,272392,257,21793,46093,513]

theorem envBound20030 : H12AffineFastState.Bounded env20030 := by
  intro p hp
  have h : env20030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20029_20030 : H12AffineEnvironment.transform 6 8 env20029 = env20030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20029 == env20030) = true)

theorem identity20030 : scanCanonicalize (H12AffineFastState.compose env20030 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound20030 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env20031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,32768,1095,16401,262144,1025,32769,4161,298052,20481,54531,1100,64,36113,17664,5393,315408,1365,265284,257,21793,36929,513]

theorem envBound20031 : H12AffineFastState.Bounded env20031 := by
  intro p hp
  have h : env20031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20030_20031 : H12AffineEnvironment.transform 12 1100 env20030 = env20031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env20030 == env20031) = true)

theorem identity20031 : scanCanonicalize (H12AffineFastState.compose env20031 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20031 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env20032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,32768,1095,5393,262144,1025,32769,4161,298052,1281,32771,1100,64,36113,4096,5393,296208,1365,265284,257,33,36929,513]

theorem envBound20032 : H12AffineFastState.Bounded env20032 := by
  intro p hp
  have h : env20032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20031_20032 : H12AffineEnvironment.transform 13 5376 env20031 = env20032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20031 == env20032) = true)

theorem identity20032 : scanCanonicalize (H12AffineFastState.compose env20032 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound20032 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,32768,1095,5393,35189,1025,32769,4161,1329,1281,32771,1100,64,36113,4096,5393,3173,1365,34097,257,33,36929,513]

theorem envBound20033 : H12AffineFastState.Bounded env20033 := by
  intro p hp
  have h : env20033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20032_20033 : H12AffineEnvironment.transform 17 35189 env20032 = env20033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env20032 == env20033) = true)

theorem identity20033 : scanCanonicalize (H12AffineFastState.compose env20033 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20033 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5376,1297,1095,5393,3172,1025,1296,4161,1329,1281,1298,1100,64,2048,4096,5393,3173,1365,32,257,33,5456,513]

theorem envBound20034 : H12AffineFastState.Bounded env20034 := by
  intro p hp
  have h : env20034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20033_20034 : H12AffineEnvironment.transform 14 1297 env20033 = env20034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1297 env20033 == env20034) = true)

theorem identity20034 : scanCanonicalize (H12AffineFastState.compose env20034 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound20034 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env20035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,1100,3345,1297,1095,3328,3172,1025,1296,2128,1329,1281,1298,1100,64,2048,2065,3328,3173,1365,32,257,33,3393,513]

theorem envBound20035 : H12AffineFastState.Bounded env20035 := by
  intro p hp
  have h : env20035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20034_20035 : H12AffineEnvironment.transform 11 2065 env20034 = env20035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env20034 == env20035) = true)

theorem identity20035 : scanCanonicalize (H12AffineFastState.compose env20035 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1872) := by decide +kernel

theorem selectedBound20035 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env20036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1872,1857,1100,577,1297,1095,592,820,1025,1296,1792,1329,1281,1298,1100,64,1872,1857,592,821,1365,32,257,33,529,513]

theorem envBound20036 : H12AffineFastState.Bounded env20036 := by
  intro p hp
  have h : env20036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20035_20036 : H12AffineEnvironment.transform 10 1872 env20035 = env20036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1872 env20035 == env20036) = true)

theorem identity20036 : scanCanonicalize (H12AffineFastState.compose env20036 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound20036 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env20037 : List Nat := [2,4,8,16,32,64,8,256,512,100,820,805,40,577,373,35,592,820,101,372,868,341,357,374,40,64,820,805,592,821,305,32,257,33,529,513]

theorem envBound20037 : H12AffineFastState.Bounded env20037 := by
  intro p hp
  have h : env20037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20036_20037 : H12AffineEnvironment.transform 9 100 env20036 = env20037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env20036 == env20037) = true)

theorem identity20037 : scanCanonicalize (H12AffineFastState.compose env20037 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound20037 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env20038 : List Nat := [2,4,8,16,32,42,8,256,512,14,820,805,40,555,287,35,570,820,15,286,782,319,271,284,40,42,820,805,570,821,305,32,257,33,529,513]

theorem envBound20038 : H12AffineFastState.Bounded env20038 := by
  intro p hp
  have h : env20038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20037_20038 : H12AffineEnvironment.transform 5 42 env20037 = env20038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env20037 == env20038) = true)

theorem identity20038 : scanCanonicalize (H12AffineFastState.compose env20038 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 286) := by decide +kernel

theorem selectedBound20038 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env20039 : List Nat := [2,4,8,16,32,42,8,256,286,14,42,59,40,309,287,35,292,42,15,286,16,319,271,284,40,42,42,59,292,43,305,32,257,33,271,287]

theorem envBound20039 : H12AffineFastState.Bounded env20039 := by
  intro p hp
  have h : env20039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20038_20039 : H12AffineEnvironment.transform 8 286 env20038 = env20039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 286 env20038 == env20039) = true)

theorem identity20039 : scanCanonicalize (H12AffineFastState.compose env20039 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound20039 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20040 : List Nat := [2,4,8,16,10,0,8,256,286,14,0,17,2,287,287,9,270,0,15,286,16,277,271,284,2,0,0,17,270,1,283,10,257,11,271,287]

theorem envBound20040 : H12AffineFastState.Bounded env20040 := by
  intro p hp
  have h : env20040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20039_20040 : H12AffineEnvironment.transform 4 10 env20039 = env20040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env20039 == env20040) = true)

theorem identity20040 : scanCanonicalize (H12AffineFastState.compose env20040 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound20040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20041 : List Nat := [2,4,8,16,10,0,8,14,16,14,0,17,2,17,17,9,0,0,15,16,16,27,1,18,2,0,0,17,0,1,21,10,15,11,1,17]

theorem envBound20041 : H12AffineFastState.Bounded env20041 := by
  intro p hp
  have h : env20041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20040_20041 : H12AffineEnvironment.transform 7 14 env20040 = env20041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env20040 == env20041) = true)

theorem identity20041 : scanCanonicalize (H12AffineFastState.compose env20041 (packedSelected [1,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20041 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env20042 : List Nat := [2,4,8,1,10,0,8,14,1,14,0,0,2,0,0,9,0,0,15,1,1,10,1,3,2,0,0,0,0,1,4,10,15,11,1,0]

theorem envBound20042 : H12AffineFastState.Bounded env20042 := by
  intro p hp
  have h : env20042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20041_20042 : H12AffineEnvironment.transform 3 1 env20041 = env20042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20041 == env20042) = true)

def env20043 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4161,305160,29773,54530,8193,64,43356,24908,12637,324700,1364,272392,257,21793,46092,513]

theorem envBound20043 : H12AffineFastState.Bounded env20043 := by
  intro p hp
  have h : env20043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20029_20043 : H12AffineEnvironment.transform 6 9 env20029 = env20043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20029 == env20043) = true)

def env20044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound20044 : H12AffineFastState.Bounded env20044 := by
  intro p hp
  have h : env20044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19670_20044 : H12AffineEnvironment.transform 26 30393345 env19670 = env20044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env19670 == env20044) = true)

def env20045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound20045 : H12AffineFastState.Bounded env20045 := by
  intro p hp
  have h : env20045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20044_20045 : H12AffineEnvironment.transform 18 1024 env20044 = env20045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env20044 == env20045) = true)

theorem identity20045 : scanCanonicalize (H12AffineFastState.compose env20045 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20045 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,8388608,16777216,8328,64,29843804,18949585,10507601,8806749,25240909,23160256,256,27354608,27337993,25166491]

theorem envBound20046 : H12AffineFastState.Bounded env20046 := by
  intro p hp
  have h : env20046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20045_20046 : H12AffineEnvironment.transform 14 8541 env20045 = env20046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20045 == env20046) = true)

def env20047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,147456,16777216,8328,64,21307740,18949585,2233681,270685,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound20047 : H12AffineFastState.Bounded env20047 := by
  intro p hp
  have h : env20047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20046_20047 : H12AffineEnvironment.transform 22 147456 env20046 = env20047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env20046 == env20047) = true)

theorem identity20047 : scanCanonicalize (H12AffineFastState.compose env20047 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 147610) := by decide +kernel

theorem selectedBound20047 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,147456,147610,8328,64,4678086,2319691,2233681,270685,75223,6497626,256,2188650,2172307,513]

theorem envBound20048 : H12AffineFastState.Bounded env20048 := by
  intro p hp
  have h : env20048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20047_20048 : H12AffineEnvironment.transform 23 147610 env20047 = env20048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147610 env20047 == env20048) = true)

def env20049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147456,147610,8328,64,4409702,2319691,2233681,2557,75223,6497626,256,2188650,2172307,513]

theorem envBound20049 : H12AffineFastState.Bounded env20049 := by
  intro p hp
  have h : env20049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20048_20049 : H12AffineEnvironment.transform 17 10400 env20048 = env20049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20048 == env20049) = true)

def env20050 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,4194304,147456,147610,8328,16,4409654,2319643,2233601,2477,75143,6497546,256,2188602,2172307,513]

theorem envBound20050 : H12AffineFastState.Bounded env20050 := by
  intro p hp
  have h : env20050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20049_20050 : H12AffineEnvironment.transform 5 16 env20049 = env20050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20049 == env20050) = true)

theorem identity20050 : scanCanonicalize (H12AffineFastState.compose env20050 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20050 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env20051 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,0,65536,131072,2477,1024,1,2097152,4194304,147456,147610,389,16,4409654,2311190,2233601,2477,66698,6489095,256,2180151,2163870,513]

theorem envBound20051 : H12AffineFastState.Bounded env20051 := by
  intro p hp
  have h : env20051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20050_20051 : H12AffineEnvironment.transform 12 269 env20050 = env20051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20050 == env20051) = true)

theorem identity20051 : scanCanonicalize (H12AffineFastState.compose env20051 (packedSelected [0,1,3,5,7,8,9,12,16,18,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 132352) := by decide +kernel

theorem selectedBound20051 : packedSelected [0,1,3,5,7,8,9,12,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env20052 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,0,65536,131072,2477,1024,1,132352,4194304,147456,147610,389,16,4409654,82198,4097,2477,66698,4260103,256,213303,197022,513]

theorem envBound20052 : H12AffineFastState.Bounded env20052 := by
  intro p hp
  have h : env20052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20051_20052 : H12AffineEnvironment.transform 20 132352 env20051 = env20052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132352 env20051 == env20052) = true)

theorem identity20052 : scanCanonicalize (H12AffineFastState.compose env20052 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20052 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env20053 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,65536,131072,2340,1024,1,132352,4194304,147456,147475,268,16,4409654,82198,4097,2340,66563,4260103,256,213303,196887,513]

theorem envBound20053 : H12AffineFastState.Bounded env20053 := by
  intro p hp
  have h : env20053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20052_20053 : H12AffineEnvironment.transform 6 9 env20052 = env20053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20052 == env20053) = true)

theorem identity20053 : scanCanonicalize (H12AffineFastState.compose env20053 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound20053 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env20054 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,65536,16400,2340,1024,1,17680,4194304,16,3,268,16,4262182,82198,4097,2340,66563,4260103,256,65831,82183,513]

theorem envBound20054 : H12AffineFastState.Bounded env20054 := by
  intro p hp
  have h : env20054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20053_20054 : H12AffineEnvironment.transform 16 16400 env20053 = env20054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20053 == env20054) = true)

theorem identity20054 : scanCanonicalize (H12AffineFastState.compose env20054 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 65830) := by decide +kernel

theorem selectedBound20054 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20055 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,65536,16400,2340,1024,1,17680,65830,16,3,268,16,2048,82198,4097,2340,66563,33,256,65831,82183,513]

theorem envBound20055 : H12AffineFastState.Bounded env20055 := by
  intro p hp
  have h : env20055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20054_20055 : H12AffineEnvironment.transform 21 65830 env20054 = env20055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65830 env20054 == env20055) = true)

theorem identity20055 : scanCanonicalize (H12AffineFastState.compose env20055 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(15+1) ^^^ 20758) := by decide +kernel

theorem selectedBound20055 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env20056 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,20758,16400,2340,1024,1,17680,20528,16,3,268,16,2048,4096,4097,2340,21781,33,256,20529,4113,513]

theorem envBound20056 : H12AffineFastState.Bounded env20056 := by
  intro p hp
  have h : env20056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20055_20056 : H12AffineEnvironment.transform 15 20758 env20055 = env20056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20758 env20055 == env20056) = true)

def env20057 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,4194304,147456,147610,8328,17,4409655,2319642,2233600,2476,75142,6497547,256,2188603,2172307,513]

theorem envBound20057 : H12AffineFastState.Bounded env20057 := by
  intro p hp
  have h : env20057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20049_20057 : H12AffineEnvironment.transform 5 17 env20049 = env20057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20049 == env20057) = true)

theorem identity20057 : scanCanonicalize (H12AffineFastState.compose env20057 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 82967) := by decide +kernel

theorem selectedBound20057 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env20058 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,82967,4194304,147456,147610,8328,17,4409655,139533,217367,2476,75142,4350236,256,8492,24964,513]

theorem envBound20058 : H12AffineFastState.Bounded env20058 := by
  intro p hp
  have h : env20058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20057_20058 : H12AffineEnvironment.transform 20 82967 env20057 = env20058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env20057 == env20058) = true)

theorem identity20058 : scanCanonicalize (H12AffineFastState.compose env20058 (packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,17,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound20058 : packedSelected [0,3,4,5,7,9,10,11,12,14,15,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env20059 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,82967,147505,147456,147610,8328,17,67846,139533,217367,2476,75142,8493,256,8492,24964,513]

theorem envBound20059 : H12AffineFastState.Bounded env20059 := by
  intro p hp
  have h : env20059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20058_20059 : H12AffineEnvironment.transform 21 147505 env20058 = env20059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env20058 == env20059) = true)

theorem identity20059 : scanCanonicalize (H12AffineFastState.compose env20059 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20059 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env20060 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,8322,131072,10400,1024,8461,25749,147505,147456,147610,8328,17,10628,139533,160149,2476,1284,8493,256,8492,24964,513]

theorem envBound20060 : H12AffineFastState.Bounded env20060 := by
  intro p hp
  have h : env20060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20059_20060 : H12AffineEnvironment.transform 15 8322 env20059 = env20060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20059 == env20060) = true)

theorem identity20060 : scanCanonicalize (H12AffineFastState.compose env20060 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound20060 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env20061 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,137,263,131072,2341,1024,136,17680,147505,147456,147610,269,17,2049,131208,151568,2476,1284,168,256,169,16385,513]

theorem envBound20061 : H12AffineFastState.Bounded env20061 := by
  intro p hp
  have h : env20061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20060_20061 : H12AffineEnvironment.transform 12 389 env20060 = env20061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env20060 == env20061) = true)

theorem identity20061 : scanCanonicalize (H12AffineFastState.compose env20061 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound20061 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env20062 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,137,263,16536,2341,1024,136,17680,169,152,2,269,17,2049,16400,4232,2476,1284,168,256,169,16385,513]

theorem envBound20062 : H12AffineFastState.Bounded env20062 := by
  intro p hp
  have h : env20062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20061_20062 : H12AffineEnvironment.transform 16 16536 env20061 = env20062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env20061 == env20062) = true)

theorem identity20062 : scanCanonicalize (H12AffineFastState.compose env20062 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound20062 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env20063 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5292,137,263,5172,2341,1024,136,4540,169,152,2,269,17,2049,5308,4232,2476,1284,168,256,169,5293,513]

theorem envBound20063 : H12AffineFastState.Bounded env20063 := by
  intro p hp
  have h : env20063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20062_20063 : H12AffineEnvironment.transform 13 5292 env20062 = env20063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env20062 == env20063) = true)

theorem identity20063 : scanCanonicalize (H12AffineFastState.compose env20063 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20063 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20064 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,1,263,5172,2341,1024,0,4404,33,16,2,269,17,2049,5172,4096,2340,1284,32,256,33,5157,513]

theorem envBound20064 : H12AffineFastState.Bounded env20064 := by
  intro p hp
  have h : env20064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20063_20064 : H12AffineEnvironment.transform 6 8 env20063 = env20064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20063 == env20064) = true)

def env20065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,2097152,4194304,147456,147610,8328,64,4409703,2319691,2233681,2556,75223,6497626,256,2188650,2172307,513]

theorem envBound20065 : H12AffineFastState.Bounded env20065 := by
  intro p hp
  have h : env20065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20048_20065 : H12AffineEnvironment.transform 17 10401 env20048 = env20065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env20048 == env20065) = true)

theorem identity20065 : scanCanonicalize (H12AffineFastState.compose env20065 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound20065 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10401,1024,8540,2097152,4194304,16,138,8328,64,4262263,2172251,2118977,2556,75223,6382922,256,2188650,2172307,513]

theorem envBound20066 : H12AffineFastState.Bounded env20066 := by
  intro p hp
  have h : env20066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20065_20066 : H12AffineEnvironment.transform 16 16400 env20065 = env20066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20065 == env20066) = true)

theorem identity20066 : scanCanonicalize (H12AffineFastState.compose env20066 (packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20066 : packedSelected [0,1,3,5,7,8,9,10,14,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10401,1024,8540,2097152,4194304,16,138,8328,64,4204925,2098513,2118977,2556,1501,6309184,256,2114912,2098585,513]

theorem envBound20067 : H12AffineFastState.Bounded env20067 := by
  intro p hp
  have h : env20067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20066_20067 : H12AffineEnvironment.transform 15 8202 env20066 = env20067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20066 == env20067) = true)

theorem identity20067 : scanCanonicalize (H12AffineFastState.compose env20067 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound20067 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env20068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8541,8202,4096,10401,1024,8540,2097152,4194304,16,138,8328,64,4204925,2098513,2098513,2556,1501,6296912,256,2102640,2098585,513]

theorem envBound20068 : H12AffineFastState.Bounded env20068 := by
  intro p hp
  have h : env20068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20067_20068 : H12AffineEnvironment.transform 13 4112 env20067 = env20068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env20067 == env20068) = true)

theorem identity20068 : scanCanonicalize (H12AffineFastState.compose env20068 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 5592) := by decide +kernel

theorem selectedBound20068 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8541,8202,4096,10401,1024,8540,5592,4194304,16,138,8328,64,4204925,4233,4233,2556,1501,4194440,256,168,4161,513]

theorem envBound20069 : H12AffineFastState.Bounded env20069 := by
  intro p hp
  have h : env20069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20068_20069 : H12AffineEnvironment.transform 20 5592 env20068 = env20069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5592 env20068 == env20069) = true)

theorem identity20069 : scanCanonicalize (H12AffineFastState.compose env20069 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound20069 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env20070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4112,8541,8202,4096,10401,1024,8540,5592,248,16,138,8328,64,10629,4233,4233,2556,1501,112,256,168,4161,513]

theorem envBound20070 : H12AffineFastState.Bounded env20070 := by
  intro p hp
  have h : env20070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20069_20070 : H12AffineEnvironment.transform 21 248 env20069 = env20070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env20069 == env20070) = true)

theorem identity20070 : scanCanonicalize (H12AffineFastState.compose env20070 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 7585) := by decide +kernel

theorem selectedBound20070 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env20071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7585,4112,7420,7595,4096,5376,1024,7421,5592,248,16,138,7465,64,5156,4233,4233,2556,1501,112,256,168,4161,513]

theorem envBound20071 : H12AffineFastState.Bounded env20071 := by
  intro p hp
  have h : env20071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20070_20071 : H12AffineEnvironment.transform 12 7585 env20070 = env20071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7585 env20070 == env20071) = true)

theorem identity20071 : scanCanonicalize (H12AffineFastState.compose env20071 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound20071 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env20072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1360,2289,1344,2476,2299,1360,80,1024,2477,136,248,16,138,2169,64,372,1497,1497,2556,1501,112,256,168,1297,513]

theorem envBound20072 : H12AffineFastState.Bounded env20072 := by
  intro p hp
  have h : env20072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20071_20072 : H12AffineEnvironment.transform 11 1360 env20071 = env20072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env20071 == env20072) = true)

theorem identity20072 : scanCanonicalize (H12AffineFastState.compose env20072 (packedSelected [1,2,3,5,6,8,11,15,23] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound20072 : packedSelected [1,2,3,5,6,8,11,15,23] rootPS < 2^1333 := by decide +kernel

def env20073 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,309,2289,293,2476,2299,309,80,101,2477,136,248,16,138,2169,64,372,444,444,2556,440,112,256,168,372,513]

theorem envBound20073 : H12AffineFastState.Bounded env20073 := by
  intro p hp
  have h : env20073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20072_20073 : H12AffineEnvironment.transform 9 101 env20072 = env20073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env20072 == env20073) = true)

theorem identity20073 : scanCanonicalize (H12AffineFastState.compose env20073 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound20073 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env20074 : List Nat := [2,4,8,16,32,64,128,256,512,101,136,309,121,293,292,115,309,80,101,293,136,248,16,138,241,64,372,444,444,372,440,112,256,168,372,513]

theorem envBound20074 : H12AffineFastState.Bounded env20074 := by
  intro p hp
  have h : env20074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20073_20074 : H12AffineEnvironment.transform 10 136 env20073 = env20074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env20073 == env20074) = true)

theorem identity20074 : scanCanonicalize (H12AffineFastState.compose env20074 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound20074 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env20075 : List Nat := [2,4,8,16,32,64,88,256,512,101,80,309,121,293,292,115,309,80,101,293,80,32,16,82,41,64,372,356,356,372,352,112,256,112,372,513]

theorem envBound20075 : H12AffineFastState.Bounded env20075 := by
  intro p hp
  have h : env20075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20074_20075 : H12AffineEnvironment.transform 6 88 env20074 = env20075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env20074 == env20075) = true)

theorem identity20075 : scanCanonicalize (H12AffineFastState.compose env20075 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20075 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20076 : List Nat := [2,4,8,16,32,16,8,256,512,53,0,309,41,293,292,35,309,0,53,293,0,32,16,2,41,16,292,308,308,292,304,32,256,32,292,513]

theorem envBound20076 : H12AffineFastState.Bounded env20076 := by
  intro p hp
  have h : env20076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20075_20076 : H12AffineEnvironment.transform 5 16 env20075 = env20076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20075 == env20076) = true)

theorem identity20076 : scanCanonicalize (H12AffineFastState.compose env20076 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20076 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env20077 : List Nat := [2,4,8,16,16,16,8,256,512,5,0,261,25,277,276,19,261,0,5,277,0,16,16,2,25,16,276,260,260,276,256,16,256,16,276,513]

theorem envBound20077 : H12AffineFastState.Bounded env20077 := by
  intro p hp
  have h : env20077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20076_20077 : H12AffineEnvironment.transform 4 16 env20076 = env20077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20076 == env20077) = true)

theorem identity20077 : scanCanonicalize (H12AffineFastState.compose env20077 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound20077 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20078 : List Nat := [2,4,8,16,16,16,8,21,512,5,0,16,25,0,1,19,16,0,5,0,0,16,16,2,25,16,1,17,17,1,21,16,21,16,1,513]

theorem envBound20078 : H12AffineFastState.Bounded env20078 := by
  intro p hp
  have h : env20078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20077_20078 : H12AffineEnvironment.transform 7 21 env20077 = env20078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env20077 == env20078) = true)

theorem identity20078 : scanCanonicalize (H12AffineFastState.compose env20078 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20078 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20079 : List Nat := [2,4,8,16,16,16,8,21,0,5,0,16,25,0,1,19,16,0,5,0,0,16,16,2,25,16,1,17,17,1,21,16,21,16,1,1]

theorem envBound20079 : H12AffineFastState.Bounded env20079 := by
  intro p hp
  have h : env20079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20078_20079 : H12AffineEnvironment.transform 8 0 env20078 = env20079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20078 == env20079) = true)

def env20080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,147457,16777216,8328,64,21307741,18949585,2233680,270684,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound20080 : H12AffineFastState.Bounded env20080 := by
  intro p hp
  have h : env20080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20046_20080 : H12AffineEnvironment.transform 22 147457 env20046 = env20080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env20046 == env20080) = true)

def env20081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147457,16777216,8328,64,21039613,18949585,2233680,2556,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound20081 : H12AffineFastState.Bounded env20081 := by
  intro p hp
  have h : env20081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20080_20081 : H12AffineEnvironment.transform 17 10400 env20080 = env20081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20080 == env20081) = true)

theorem identity20081 : scanCanonicalize (H12AffineFastState.compose env20081 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 147611) := by decide +kernel

theorem selectedBound20081 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147457,147611,8328,64,4409702,2319690,2233680,2556,75223,6497627,256,2188650,2172307,513]

theorem envBound20082 : H12AffineFastState.Bounded env20082 := by
  intro p hp
  have h : env20082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20081_20082 : H12AffineEnvironment.transform 23 147611 env20081 = env20082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 147611 env20081 == env20082) = true)

def env20083 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,4194304,147457,147611,8328,16,4409654,2319642,2233600,2476,75143,6497547,256,2188602,2172307,513]

theorem envBound20083 : H12AffineFastState.Bounded env20083 := by
  intro p hp
  have h : env20083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20082_20083 : H12AffineEnvironment.transform 5 16 env20082 = env20083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20082 == env20083) = true)

theorem identity20083 : scanCanonicalize (H12AffineFastState.compose env20083 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 2180286) := by decide +kernel

theorem selectedBound20083 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env20084 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10400,1024,8460,2097152,2180286,147457,147611,8328,16,2231688,2319642,2233600,2476,75143,156085,256,2188602,2172307,513]

theorem envBound20084 : H12AffineFastState.Bounded env20084 := by
  intro p hp
  have h : env20084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20083_20084 : H12AffineEnvironment.transform 21 2180286 env20083 = env20084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2180286 env20083 == env20084) = true)

theorem identity20084 : scanCanonicalize (H12AffineFastState.compose env20084 (packedSelected [3,4,5,11,14,15,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound20084 : packedSelected [3,4,5,11,14,15,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20085 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,398,131072,10400,1024,8460,2097152,2114864,147457,147611,8328,16,2231688,2253972,2233600,2476,9225,156085,256,2122932,2106397,513]

theorem envBound20085 : H12AffineFastState.Bounded env20085 := by
  intro p hp
  have h : env20085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20084_20085 : H12AffineEnvironment.transform 15 398 env20084 = env20085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env20084 == env20085) = true)

theorem identity20085 : scanCanonicalize (H12AffineFastState.compose env20085 (packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound20085 : packedSelected [2,4,6,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env20086 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,398,16401,10400,1024,8460,2097152,2114864,16,138,8328,16,2117017,2106501,2118929,2476,9225,8612,256,2122932,2106397,513]

theorem envBound20086 : H12AffineFastState.Bounded env20086 := by
  intro p hp
  have h : env20086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20085_20086 : H12AffineEnvironment.transform 16 16401 env20085 = env20086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20085 == env20086) = true)

theorem identity20086 : scanCanonicalize (H12AffineFastState.compose env20086 (packedSelected [0,1,7,8,10,11,14,15,17] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound20086 : packedSelected [0,1,7,8,10,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env20087 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8461,398,16401,10400,1024,8460,25628,8492,16,138,8328,16,10629,16537,12557,2476,9225,8612,256,168,16385,513]

theorem envBound20087 : H12AffineFastState.Bounded env20087 := by
  intro p hp
  have h : env20087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20086_20087 : H12AffineEnvironment.transform 20 25628 env20086 = env20087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env20086 == env20087) = true)

theorem identity20087 : scanCanonicalize (H12AffineFastState.compose env20087 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound20087 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env20088 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,136,398,16401,2341,1024,137,17817,169,16,138,269,16,2048,16537,4232,2476,1420,33,256,168,16385,513]

theorem envBound20088 : H12AffineFastState.Bounded env20088 := by
  intro p hp
  have h : env20088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20087_20088 : H12AffineEnvironment.transform 12 389 env20087 = env20088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env20087 == env20088) = true)

def env20089 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,4194304,147457,147611,8328,17,4409655,2319643,2233601,2477,75142,6497546,256,2188603,2172307,513]

theorem envBound20089 : H12AffineFastState.Bounded env20089 := by
  intro p hp
  have h : env20089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20082_20089 : H12AffineEnvironment.transform 5 17 env20082 = env20089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20082 == env20089) = true)

theorem identity20089 : scanCanonicalize (H12AffineFastState.compose env20089 (packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS)) = affineNative (2^(21+1) ^^^ 8613) := by decide +kernel

theorem selectedBound20089 : packedSelected [0,2,3,6,8,10,11,12,17,20,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env20090 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,2097152,8613,147457,147611,8328,17,223378,2319643,2233601,2477,75142,2294959,256,2188603,2172307,513]

theorem envBound20090 : H12AffineFastState.Bounded env20090 := by
  intro p hp
  have h : env20090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20089_20090 : H12AffineEnvironment.transform 21 8613 env20089 = env20090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8613 env20089 == env20090) = true)

theorem identity20090 : scanCanonicalize (H12AffineFastState.compose env20090 (packedSelected [0,2,3,4,5,6,7,9,11,15,16,18,19,23] rootPS)) = affineNative (2^(20+1) ^^^ 197774) := by decide +kernel

theorem selectedBound20090 : packedSelected [0,2,3,4,5,6,7,9,11,15,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env20091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10400,1024,8461,197774,8613,147457,147611,8328,17,223378,24981,70031,2477,75142,33,256,156085,139549,513]

theorem envBound20091 : H12AffineFastState.Bounded env20091 := by
  intro p hp
  have h : env20091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20090_20091 : H12AffineEnvironment.transform 20 197774 env20090 = env20091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 197774 env20090 == env20091) = true)

theorem identity20091 : scanCanonicalize (H12AffineFastState.compose env20091 (packedSelected [0,1,2,4,6,7,8,9,10,12,16,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound20091 : packedSelected [0,1,2,4,6,7,8,9,10,12,16,17,18] rootPS < 2^1333 := by decide +kernel

def env20092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,65536,82199,10400,1024,8461,17817,8613,65814,65932,8328,17,10629,24981,70031,2477,75142,33,256,73890,90122,513]

theorem envBound20092 : H12AffineFastState.Bounded env20092 := by
  intro p hp
  have h : env20092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20091_20092 : H12AffineEnvironment.transform 16 82199 env20091 = env20092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env20091 == env20092) = true)

def env20093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,2097152,4194304,147457,16777216,8328,64,21039612,18949585,2233680,2557,16999756,23160256,256,19080689,19096840,16925338]

theorem envBound20093 : H12AffineFastState.Bounded env20093 := by
  intro p hp
  have h : env20093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20080_20093 : H12AffineEnvironment.transform 17 10401 env20080 = env20093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env20080 == env20093) = true)

theorem identity20093 : scanCanonicalize (H12AffineFastState.compose env20093 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 138) := by decide +kernel

theorem selectedBound20093 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env20094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,2097152,4194304,147457,138,8328,64,4262262,2172251,2233680,2557,222662,6382922,256,2303355,2319746,147984]

theorem envBound20094 : H12AffineFastState.Bounded env20094 := by
  intro p hp
  have h : env20094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20093_20094 : H12AffineEnvironment.transform 23 138 env20093 = env20094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 138 env20093 == env20094) = true)

def env20095 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147457,2,8192,64,4262262,2172251,2233680,2421,222542,6382922,256,2303355,2319626,147984]

theorem envBound20095 : H12AffineFastState.Bounded env20095 := by
  intro p hp
  have h : env20095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20094_20095 : H12AffineEnvironment.transform 6 8 env20094 = env20095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20094 == env20095) = true)

theorem identity20095 : scanCanonicalize (H12AffineFastState.compose env20095 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound20095 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env20096 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,17461,4194304,147457,2,8192,64,4262262,90478,151909,2421,222542,4268415,256,221518,205119,147984]

theorem envBound20096 : H12AffineFastState.Bounded env20096 := by
  intro p hp
  have h : env20096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20095_20096 : H12AffineEnvironment.transform 20 17461 env20095 = env20096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env20095 == env20096) = true)

theorem identity20096 : scanCanonicalize (H12AffineFastState.compose env20096 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20096 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env20097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1024,8540,17461,4194304,73755,2,8192,64,4262262,90478,78207,2421,1364,4268415,256,340,16677,74250]

theorem envBound20097 : H12AffineFastState.Bounded env20097 := by
  intro p hp
  have h : env20097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20096_20097 : H12AffineEnvironment.transform 16 90138 env20096 = env20097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20096 == env20097) = true)

theorem identity20097 : scanCanonicalize (H12AffineFastState.compose env20097 (packedSelected [1,3,4,5,8,9,10,14,17,18,19,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 260) := by decide +kernel

theorem selectedBound20097 : packedSelected [1,3,4,5,8,9,10,14,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env20098 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1024,8540,17461,260,73755,2,8192,64,67698,90478,78207,2421,1364,73851,256,340,16677,74250]

theorem envBound20098 : H12AffineFastState.Bounded env20098 := by
  intro p hp
  have h : env20098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20097_20098 : H12AffineEnvironment.transform 21 260 env20097 = env20098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 260 env20097 == env20098) = true)

theorem identity20098 : scanCanonicalize (H12AffineFastState.compose env20098 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20098 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20099 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,65536,82247,2420,1024,1,17461,260,65862,2,349,64,67698,81971,69666,2421,1364,65830,256,340,16677,66391]

theorem envBound20099 : H12AffineFastState.Bounded env20099 := by
  intro p hp
  have h : env20099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20098_20099 : H12AffineEnvironment.transform 12 349 env20098 = env20099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20098 == env20099) = true)

theorem identity20099 : scanCanonicalize (H12AffineFastState.compose env20099 (packedSelected [1,4,8,9,14,19,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20099 : packedSelected [1,4,8,9,14,19,20] rootPS < 2^1333 := by decide +kernel

def env20100 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,16384,0,65536,82019,2128,1024,1,17461,32,65634,2,121,64,67698,81971,69666,2129,1136,65538,36,112,16385,66163]

theorem envBound20100 : H12AffineFastState.Bounded env20100 := by
  intro p hp
  have h : env20100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20099_20100 : H12AffineEnvironment.transform 7 36 env20099 = env20100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20099 == env20100) = true)

def env20101 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,2097152,4194304,147457,3,8193,64,4262262,2172251,2233680,2420,222543,6382922,256,2303355,2319627,147984]

theorem envBound20101 : H12AffineFastState.Bounded env20101 := by
  intro p hp
  have h : env20101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20094_20101 : H12AffineEnvironment.transform 6 9 env20094 = env20101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20094 == env20101) = true)

theorem identity20101 : scanCanonicalize (H12AffineFastState.compose env20101 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20101 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env20102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1024,8540,2097152,4194304,73755,3,8193,64,4262262,2172251,2192714,2420,1365,6382922,256,2114913,2098449,74250]

theorem envBound20102 : H12AffineFastState.Bounded env20102 := by
  intro p hp
  have h : env20102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20101_20102 : H12AffineEnvironment.transform 16 90138 env20101 = env20102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20101 == env20102) = true)

theorem identity20102 : scanCanonicalize (H12AffineFastState.compose env20102 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 65911) := by decide +kernel

theorem selectedBound20102 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env20103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1024,8540,2097152,65911,73755,3,8193,64,2049,2172251,2192714,2420,1365,2122813,256,2114913,2098449,74250]

theorem envBound20103 : H12AffineFastState.Bounded env20103 := by
  intro p hp
  have h : env20103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20102_20103 : H12AffineEnvironment.transform 21 65911 env20102 = env20103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65911 env20102 == env20103) = true)

theorem identity20103 : scanCanonicalize (H12AffineFastState.compose env20103 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20103 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,65536,82246,2420,1024,0,2097152,65911,65863,3,349,64,2049,2163719,2184214,2420,1365,2114913,256,2114913,2098449,66390]

theorem envBound20104 : H12AffineFastState.Bounded env20104 := by
  intro p hp
  have h : env20104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20103_20104 : H12AffineEnvironment.transform 12 348 env20103 = env20104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20103 == env20104) = true)

theorem identity20104 : scanCanonicalize (H12AffineFastState.compose env20104 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 20806) := by decide +kernel

theorem selectedBound20104 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env20105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,20806,4096,2420,1024,0,2097152,20529,20481,3,349,64,2049,2118977,2098512,2420,1365,2114913,256,2114913,2098449,21008]

theorem envBound20105 : H12AffineFastState.Bounded env20105 := by
  intro p hp
  have h : env20105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20104_20105 : H12AffineEnvironment.transform 15 20806 env20104 = env20105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20806 env20104 == env20105) = true)

theorem identity20105 : scanCanonicalize (H12AffineFastState.compose env20105 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound20105 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env20106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,20806,4096,2420,1024,0,17728,20529,20481,3,349,64,2049,4097,16400,2420,1365,33,256,33,16465,21008]

theorem envBound20106 : H12AffineFastState.Bounded env20106 := by
  intro p hp
  have h : env20106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20105_20106 : H12AffineEnvironment.transform 20 17728 env20105 = env20106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env20105 == env20106) = true)

theorem identity20106 : scanCanonicalize (H12AffineFastState.compose env20106 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20106 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,1094,4096,2420,1024,0,4160,1329,1281,3,349,64,2049,4097,5392,2420,1365,33,256,33,5457,1808]

theorem envBound20107 : H12AffineFastState.Bounded env20107 := by
  intro p hp
  have h : env20107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20106_20107 : H12AffineEnvironment.transform 13 5376 env20106 = env20107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20106 == env20107) = true)

theorem identity20107 : scanCanonicalize (H12AffineFastState.compose env20107 (packedSelected [6,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound20107 : packedSelected [6,11,14] rootPS < 2^1333 := by decide +kernel

def env20108 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,276,348,1044,1,1094,276,2420,1024,0,340,1329,1281,3,349,64,2049,277,1028,2420,1365,33,256,33,1093,1808]

theorem envBound20108 : H12AffineFastState.Bounded env20108 := by
  intro p hp
  have h : env20108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20107_20108 : H12AffineEnvironment.transform 11 276 env20107 = env20108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env20107 == env20108) = true)

theorem identity20108 : scanCanonicalize (H12AffineFastState.compose env20108 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 1329) := by decide +kernel

theorem selectedBound20108 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env20109 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1329,276,348,1044,1,1094,276,1093,1024,0,340,1329,1281,3,349,64,1328,277,1028,1093,1365,33,256,33,1093,1808]

theorem envBound20109 : H12AffineFastState.Bounded env20109 := by
  intro p hp
  have h : env20109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20108_20109 : H12AffineEnvironment.transform 10 1329 env20108 = env20109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1329 env20108 == env20109) = true)

theorem identity20109 : scanCanonicalize (H12AffineFastState.compose env20109 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound20109 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env20110 : List Nat := [2,4,8,16,32,64,9,256,48,1024,1329,276,348,1044,1,1094,276,1093,1024,0,340,1329,1281,3,349,64,1328,277,1028,1093,1365,33,256,33,1093,1312]

theorem envBound20110 : H12AffineFastState.Bounded env20110 := by
  intro p hp
  have h : env20110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20109_20110 : H12AffineEnvironment.transform 8 48 env20109 = env20110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env20109 == env20110) = true)

theorem identity20110 : scanCanonicalize (H12AffineFastState.compose env20110 (packedSelected [3,4,5,6,7,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound20110 : packedSelected [3,4,5,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env20111 : List Nat := [2,4,8,16,32,64,9,256,48,69,372,276,348,81,1,3,276,0,69,0,340,372,324,3,349,64,373,277,65,0,272,33,256,33,0,357]

theorem envBound20111 : H12AffineFastState.Bounded env20111 := by
  intro p hp
  have h : env20111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20110_20111 : H12AffineEnvironment.transform 9 69 env20110 = env20111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env20110 == env20111) = true)

theorem identity20111 : scanCanonicalize (H12AffineFastState.compose env20111 (packedSelected [2,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound20111 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env20112 : List Nat := [2,4,8,16,17,64,9,256,1,69,325,276,348,81,1,3,276,0,69,0,340,325,324,3,349,64,324,277,65,0,272,16,256,16,0,340]

theorem envBound20112 : H12AffineFastState.Bounded env20112 := by
  intro p hp
  have h : env20112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20111_20112 : H12AffineEnvironment.transform 4 17 env20111 = env20112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env20111 == env20112) = true)

theorem identity20112 : scanCanonicalize (H12AffineFastState.compose env20112 (packedSelected [0,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20112 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env20113 : List Nat := [2,4,8,16,17,64,9,4,1,69,65,16,88,81,1,3,16,0,69,0,80,65,64,3,89,64,64,17,65,0,20,16,4,16,0,80]

theorem envBound20113 : H12AffineFastState.Bounded env20113 := by
  intro p hp
  have h : env20113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20112_20113 : H12AffineEnvironment.transform 7 4 env20112 = env20113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20112 == env20113) = true)

theorem identity20113 : scanCanonicalize (H12AffineFastState.compose env20113 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound20113 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20114 : List Nat := [2,4,8,16,17,1,9,4,1,4,0,16,25,16,1,3,16,0,4,0,17,0,1,3,24,1,1,17,0,0,20,16,4,16,0,17]

theorem envBound20114 : H12AffineFastState.Bounded env20114 := by
  intro p hp
  have h : env20114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20113_20114 : H12AffineEnvironment.transform 5 1 env20113 = env20114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env20113 == env20114) = true)

theorem identity20114 : scanCanonicalize (H12AffineFastState.compose env20114 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20114 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20115 : List Nat := [2,4,8,0,1,1,9,4,1,4,0,0,9,0,1,3,0,0,4,0,1,0,1,3,8,1,1,1,0,0,4,0,4,0,0,1]

theorem envBound20115 : H12AffineFastState.Bounded env20115 := by
  intro p hp
  have h : env20115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20114_20115 : H12AffineEnvironment.transform 3 0 env20114 = env20115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20114 == env20115) = true)

theorem identity20115 : scanCanonicalize (H12AffineFastState.compose env20115 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20115 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20116 : List Nat := [2,1,8,0,1,1,9,1,1,1,0,0,9,0,1,3,0,0,1,0,1,0,1,3,8,1,1,1,0,0,1,0,1,0,0,1]

theorem envBound20116 : H12AffineFastState.Bounded env20116 := by
  intro p hp
  have h : env20116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20115_20116 : H12AffineEnvironment.transform 1 1 env20115 = env20116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20115 == env20116) = true)

theorem identity20116 : scanCanonicalize (H12AffineFastState.compose env20116 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound20116 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20117 : List Nat := [1,1,8,0,1,1,9,1,1,1,0,0,9,0,1,0,0,0,1,0,1,0,1,0,8,1,1,1,0,0,1,0,1,0,0,1]

theorem envBound20117 : H12AffineFastState.Bounded env20117 := by
  intro p hp
  have h : env20117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20116_20117 : H12AffineEnvironment.transform 0 1 env20116 = env20117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env20116 == env20117) = true)

theorem identity20117 : scanCanonicalize (H12AffineFastState.compose env20117 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound20117 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20118 : List Nat := [1,1,1,0,1,1,0,1,1,1,0,0,0,0,1,0,0,0,1,0,1,0,1,0,1,1,1,1,0,0,1,0,1,0,0,1]

theorem envBound20118 : H12AffineFastState.Bounded env20118 := by
  intro p hp
  have h : env20118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20117_20118 : H12AffineEnvironment.transform 2 1 env20117 = env20118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env20117 == env20118) = true)

def env20119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound20119 : H12AffineFastState.Bounded env20119 := by
  intro p hp
  have h : env20119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20044_20119 : H12AffineEnvironment.transform 18 1025 env20044 = env20119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env20044 == env20119) = true)

theorem identity20119 : scanCanonicalize (H12AffineFastState.compose env20119 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8602077) := by decide +kernel

theorem selectedBound20119 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8602077,8328,64,4489693,10667344,10507601,8830977,181709,14820381,257,2262385,2254036,254490]

theorem envBound20120 : H12AffineFastState.Bounded env20120 := by
  intro p hp
  have h : env20120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20119_20120 : H12AffineEnvironment.transform 23 8602077 env20119 = env20120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8602077 env20119 == env20120) = true)

def env20121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,8388608,8602077,8328,64,4489693,8393984,8553729,8830977,181709,12645453,257,21793,46212,254490]

theorem envBound20121 : H12AffineFastState.Bounded env20121 := by
  intro p hp
  have h : env20121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20120_20121 : H12AffineEnvironment.transform 20 184400 env20120 = env20121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env20120 == env20121) = true)

def env20122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180224,98781,8328,64,4489693,185600,17665,262145,181709,4338765,257,21793,46212,254490]

theorem envBound20122 : H12AffineFastState.Bounded env20122 := by
  intro p hp
  have h : env20122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20121_20122 : H12AffineEnvironment.transform 22 180224 env20121 = env20122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env20121 == env20122) = true)

def env20123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180224,98781,8328,64,43357,185600,17665,262145,181709,400589,257,21793,46212,254490]

theorem envBound20123 : H12AffineFastState.Bounded env20123 := by
  intro p hp
  have h : env20123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20122_20123 : H12AffineEnvironment.transform 21 272512 env20122 = env20123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20122 == env20123) = true)

theorem identity20123 : scanCanonicalize (H12AffineFastState.compose env20123 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound20123 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20124 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77899,272512,73755,98781,8328,64,43357,79131,17665,262145,75222,392406,257,21793,46212,513]

theorem envBound20124 : H12AffineFastState.Bounded env20124 := by
  intro p hp
  have h : env20124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20123_20124 : H12AffineEnvironment.transform 16 122907 env20123 = env20124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env20123 == env20124) = true)

theorem identity20124 : scanCanonicalize (H12AffineFastState.compose env20124 (packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound20124 : packedSelected [3,4,9,10,12,14,15,17,20,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env20125 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1025,32769,77899,73891,73755,98781,8328,64,43357,79131,17665,67618,75222,62709,257,21793,46212,513]

theorem envBound20125 : H12AffineFastState.Bounded env20125 := by
  intro p hp
  have h : env20125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20124_20125 : H12AffineEnvironment.transform 17 67619 env20124 = env20125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env20124 == env20125) = true)

theorem identity20125 : scanCanonicalize (H12AffineFastState.compose env20125 (packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20125 : packedSelected [5,7,8,10,14,15,17,19,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env20126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90138,67619,1025,0,77899,73891,73755,66012,8328,64,10588,79131,17665,67618,75222,29940,257,21793,13445,513]

theorem envBound20126 : H12AffineFastState.Bounded env20126 := by
  intro p hp
  have h : env20126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20125_20126 : H12AffineEnvironment.transform 14 1 env20125 = env20126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20125 == env20126) = true)

def env20127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,90138,67619,1025,0,77899,73771,73755,65876,8192,64,10588,79131,17665,67618,75102,29820,257,21793,13325,513]

theorem envBound20127 : H12AffineFastState.Bounded env20127 := by
  intro p hp
  have h : env20127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20126_20127 : H12AffineEnvironment.transform 6 8 env20126 = env20127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20126 == env20127) = true)

theorem identity20127 : scanCanonicalize (H12AffineFastState.compose env20127 (packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound20127 : packedSelected [0,1,2,4,5,6,7,9,10,12,14,15,18,23,24,28] rootPS < 2^1333 := by decide +kernel

def env20128 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21591,13389,23668,1025,0,25628,29820,29772,21763,8192,64,10588,24908,17665,23669,28937,29820,257,21793,13325,513]

theorem envBound20128 : H12AffineFastState.Bounded env20128 := by
  intro p hp
  have h : env20128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20127_20128 : H12AffineEnvironment.transform 15 21591 env20127 = env20128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env20127 == env20128) = true)

theorem identity20128 : scanCanonicalize (H12AffineFastState.compose env20128 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20128 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20129 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21591,5393,23668,1025,0,17728,21792,21776,21763,348,64,2048,16400,17665,23669,20565,21792,257,21793,5457,513]

theorem envBound20129 : H12AffineFastState.Bounded env20129 := by
  intro p hp
  have h : env20129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20128_20129 : H12AffineEnvironment.transform 12 348 env20128 = env20129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20128 == env20129) = true)

theorem identity20129 : scanCanonicalize (H12AffineFastState.compose env20129 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20129 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20130 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,342,5393,2421,1025,0,4161,33,17,2,348,64,2048,5393,4096,2420,1364,33,257,32,5457,513]

theorem envBound20130 : H12AffineFastState.Bounded env20130 := by
  intro p hp
  have h : env20130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20129_20130 : H12AffineEnvironment.transform 13 5377 env20129 = env20130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20129 == env20130) = true)

theorem identity20130 : scanCanonicalize (H12AffineFastState.compose env20130 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound20130 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20131 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,356,348,1125,1,342,1141,2421,1025,0,293,33,17,2,348,64,2048,1141,356,2420,1364,33,257,32,1077,513]

theorem envBound20131 : H12AffineFastState.Bounded env20131 := by
  intro p hp
  have h : env20131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20130_20131 : H12AffineEnvironment.transform 11 356 env20130 = env20131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env20130 == env20131) = true)

theorem identity20131 : scanCanonicalize (H12AffineFastState.compose env20131 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound20131 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,356,348,1125,1,342,1141,1296,1025,0,293,33,17,2,348,64,1125,1141,356,1297,1364,33,257,32,1077,513]

theorem envBound20132 : H12AffineFastState.Bounded env20132 := by
  intro p hp
  have h : env20132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20131_20132 : H12AffineEnvironment.transform 10 1125 env20131 = env20132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env20131 == env20132) = true)

theorem identity20132 : scanCanonicalize (H12AffineFastState.compose env20132 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound20132 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env20133 : List Nat := [2,4,8,16,32,64,8,256,309,1024,1125,356,348,1125,1,342,1141,1296,1025,0,293,33,17,2,348,64,1125,1141,356,1297,1364,33,257,32,1077,308]

theorem envBound20133 : H12AffineFastState.Bounded env20133 := by
  intro p hp
  have h : env20133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20132_20133 : H12AffineEnvironment.transform 8 309 env20132 = env20133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env20132 == env20133) = true)

theorem identity20133 : scanCanonicalize (H12AffineFastState.compose env20133 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound20133 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env20134 : List Nat := [2,4,8,16,32,32,8,256,309,1024,1029,260,316,1029,1,310,1045,1296,1025,0,293,33,17,2,316,32,1029,1045,260,1297,1332,33,257,32,1077,308]

theorem envBound20134 : H12AffineFastState.Bounded env20134 := by
  intro p hp
  have h : env20134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20133_20134 : H12AffineEnvironment.transform 5 32 env20133 = env20134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env20133 == env20134) = true)

theorem identity20134 : scanCanonicalize (H12AffineFastState.compose env20134 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20134 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20135 : List Nat := [2,4,8,16,0,0,8,256,277,1024,1029,260,284,1029,1,278,1045,1296,1025,0,261,1,17,2,284,0,1029,1045,260,1297,1300,1,257,0,1045,276]

theorem envBound20135 : H12AffineFastState.Bounded env20135 := by
  intro p hp
  have h : env20135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20134_20135 : H12AffineEnvironment.transform 4 0 env20134 = env20135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20134 == env20135) = true)

theorem identity20135 : scanCanonicalize (H12AffineFastState.compose env20135 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20135 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env20136 : List Nat := [2,4,8,0,0,0,8,256,261,1024,1029,260,268,1029,1,262,1029,1280,1025,0,261,1,1,2,268,0,1029,1029,260,1281,1284,1,257,0,1029,260]

theorem envBound20136 : H12AffineFastState.Bounded env20136 := by
  intro p hp
  have h : env20136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20135_20136 : H12AffineEnvironment.transform 3 0 env20135 = env20136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20135 == env20136) = true)

theorem identity20136 : scanCanonicalize (H12AffineFastState.compose env20136 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound20136 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20137 : List Nat := [2,4,8,0,0,0,8,256,261,257,260,260,268,260,1,262,260,1,256,0,261,1,1,2,268,0,260,260,260,0,5,1,257,0,260,260]

theorem envBound20137 : H12AffineFastState.Bounded env20137 := by
  intro p hp
  have h : env20137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20136_20137 : H12AffineEnvironment.transform 9 257 env20136 = env20137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env20136 == env20137) = true)

theorem identity20137 : scanCanonicalize (H12AffineFastState.compose env20137 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20137 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20138 : List Nat := [2,4,8,0,0,0,8,4,1,5,0,0,8,0,1,2,0,1,4,0,1,1,1,2,8,0,0,0,0,0,5,1,5,0,0,0]

theorem envBound20138 : H12AffineFastState.Bounded env20138 := by
  intro p hp
  have h : env20138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20137_20138 : H12AffineEnvironment.transform 7 4 env20137 = env20138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20137 == env20138) = true)

def env20139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,67619,1025,0,77899,73770,73755,65877,8193,64,10588,79131,17665,67618,75103,29821,257,21793,13324,513]

theorem envBound20139 : H12AffineFastState.Bounded env20139 := by
  intro p hp
  have h : env20139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20126_20139 : H12AffineEnvironment.transform 6 9 env20126 = env20139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20126 == env20139) = true)

theorem identity20139 : scanCanonicalize (H12AffineFastState.compose env20139 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound20139 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,342,24908,2421,1025,0,12573,8572,8525,3,8193,64,10588,13389,17665,2420,9225,29821,257,21793,13324,513]

theorem envBound20140 : H12AffineFastState.Bounded env20140 := by
  intro p hp
  have h : env20140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20139_20140 : H12AffineEnvironment.transform 15 342 env20139 = env20140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env20139 == env20140) = true)

def env20141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180224,98781,8328,64,43356,185600,17665,262145,181709,400588,257,21793,46212,254490]

theorem envBound20141 : H12AffineFastState.Bounded env20141 := by
  intro p hp
  have h : env20141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20122_20141 : H12AffineEnvironment.transform 21 272513 env20122 = env20141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20122 == env20141) = true)

theorem identity20141 : scanCanonicalize (H12AffineFastState.compose env20141 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20141 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184400,272513,180224,41431,8328,64,43356,185600,17665,262145,181709,400588,257,21793,46212,180752]

theorem envBound20142 : H12AffineFastState.Bounded env20142 := by
  intro p hp
  have h : env20142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20141_20142 : H12AffineEnvironment.transform 15 8202 env20141 = env20142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20141 == env20142) = true)

theorem identity20142 : scanCanonicalize (H12AffineFastState.compose env20142 (packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound20142 : packedSelected [1,12,15,16,17,19,20,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env20143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190641,1025,32769,184400,180272,180224,41431,8328,64,43356,185600,17665,190640,181709,62589,257,21793,46212,180752]

theorem envBound20143 : H12AffineFastState.Bounded env20143 := by
  intro p hp
  have h : env20143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20142_20143 : H12AffineEnvironment.transform 17 190641 env20142 = env20143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env20142 == env20143) = true)

theorem identity20143 : scanCanonicalize (H12AffineFastState.compose env20143 (packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound20143 : packedSelected [1,4,7,9,16,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env20144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43168,1025,32769,36929,32801,32785,41431,8328,64,43356,38161,17665,43169,34268,62589,257,21793,46212,33281]

theorem envBound20144 : H12AffineFastState.Bounded env20144 := by
  intro p hp
  have h : env20144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20143_20144 : H12AffineEnvironment.transform 16 16401 env20143 = env20144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20143 == env20144) = true)

theorem identity20144 : scanCanonicalize (H12AffineFastState.compose env20144 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20144 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1025,32769,36929,32801,32785,41310,8193,64,43356,38161,17665,43048,34133,62589,257,21793,46093,33281]

theorem envBound20145 : H12AffineFastState.Bounded env20145 := by
  intro p hp
  have h : env20145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20144_20145 : H12AffineEnvironment.transform 6 9 env20144 = env20145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20144 == env20145) = true)

theorem identity20145 : scanCanonicalize (H12AffineFastState.compose env20145 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound20145 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,2420,1025,8540,12572,8572,8524,3,8193,64,2049,13388,17665,2421,9224,21792,257,21793,5456,9052]

theorem envBound20146 : H12AffineFastState.Bounded env20146 := by
  intro p hp
  have h : env20146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20145_20146 : H12AffineEnvironment.transform 14 8541 env20145 = env20146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env20145 == env20146) = true)

theorem identity20146 : scanCanonicalize (H12AffineFastState.compose env20146 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(13+1) ^^^ 1280) := by decide +kernel

theorem selectedBound20146 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env20147 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1280,8541,8202,1297,2420,1025,8540,12572,8572,8524,3,8193,64,2049,13388,1,2421,9224,4128,257,4129,5456,9052]

theorem envBound20147 : H12AffineFastState.Bounded env20147 := by
  intro p hp
  have h : env20147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20146_20147 : H12AffineEnvironment.transform 13 1280 env20146 = env20147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1280 env20146 == env20147) = true)

theorem identity20147 : scanCanonicalize (H12AffineFastState.compose env20147 (packedSelected [4,6,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 5432) := by decide +kernel

theorem selectedBound20147 : packedSelected [4,6,9,12,15] rootPS < 2^1333 := by decide +kernel

def env20148 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5432,1280,5221,5426,1297,2420,1025,5220,1060,5188,5236,3,5433,64,2049,372,1,2421,4400,4128,257,4129,5456,5732]

theorem envBound20148 : H12AffineFastState.Bounded env20148 := by
  intro p hp
  have h : env20148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20147_20148 : H12AffineEnvironment.transform 12 5432 env20147 = env20148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5432 env20147 == env20148) = true)

theorem identity20148 : scanCanonicalize (H12AffineFastState.compose env20148 (packedSelected [0,2,6,7,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound20148 : packedSelected [0,2,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env20149 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,373,1101,1280,1296,1095,1297,2420,1025,1297,1060,1329,1281,3,1100,64,2049,372,1,2421,69,341,257,340,1061,1809]

theorem envBound20149 : H12AffineFastState.Bounded env20149 := by
  intro p hp
  have h : env20149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20148_20149 : H12AffineEnvironment.transform 11 373 env20148 = env20149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env20148 == env20149) = true)

theorem identity20149 : scanCanonicalize (H12AffineFastState.compose env20149 (packedSelected [0,6,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20149 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env20150 : List Nat := [2,4,8,1,32,64,9,256,512,1024,2048,356,1101,1280,1281,1095,1280,2405,1025,1280,1060,1312,1281,3,1100,64,2049,357,1,2404,69,324,257,325,1061,1792]

theorem envBound20150 : H12AffineFastState.Bounded env20150 := by
  intro p hp
  have h : env20150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20149_20150 : H12AffineEnvironment.transform 3 1 env20149 = env20150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20149 == env20150) = true)

theorem identity20150 : scanCanonicalize (H12AffineFastState.compose env20150 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound20150 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20151 : List Nat := [2,4,8,1,32,64,9,256,512,256,2048,356,333,0,1,327,0,2405,257,0,292,32,1,3,332,64,2049,357,1,2404,69,324,257,325,293,512]

theorem envBound20151 : H12AffineFastState.Bounded env20151 := by
  intro p hp
  have h : env20151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20150_20151 : H12AffineEnvironment.transform 9 256 env20150 = env20151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env20150 == env20151) = true)

theorem identity20151 : scanCanonicalize (H12AffineFastState.compose env20151 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound20151 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20152 : List Nat := [2,4,8,1,32,64,9,69,512,69,2048,33,8,0,1,2,0,2080,68,0,97,32,1,3,9,64,2049,32,1,2081,69,1,68,0,96,512]

theorem envBound20152 : H12AffineFastState.Bounded env20152 := by
  intro p hp
  have h : env20152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20151_20152 : H12AffineEnvironment.transform 7 69 env20151 = env20152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env20151 == env20152) = true)

theorem identity20152 : scanCanonicalize (H12AffineFastState.compose env20152 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound20152 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20153 : List Nat := [2,4,8,1,32,64,9,69,33,69,2048,33,8,0,1,2,0,2080,68,0,97,32,1,3,9,64,2049,32,1,2081,69,1,68,0,96,33]

theorem envBound20153 : H12AffineFastState.Bounded env20153 := by
  intro p hp
  have h : env20153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20152_20153 : H12AffineEnvironment.transform 8 33 env20152 = env20153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env20152 == env20153) = true)

theorem identity20153 : scanCanonicalize (H12AffineFastState.compose env20153 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound20153 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20154 : List Nat := [2,4,8,1,32,33,9,36,33,36,2048,33,8,0,1,2,0,2080,37,0,0,32,1,3,9,33,2049,32,1,2081,36,1,37,0,1,33]

theorem envBound20154 : H12AffineFastState.Bounded env20154 := by
  intro p hp
  have h : env20154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20153_20154 : H12AffineEnvironment.transform 5 33 env20153 = env20154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env20153 == env20154) = true)

theorem identity20154 : scanCanonicalize (H12AffineFastState.compose env20154 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20154 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20155 : List Nat := [2,4,8,1,0,1,9,4,1,4,2048,1,8,0,1,2,0,2048,5,0,0,0,1,3,9,1,2049,0,1,2049,4,1,5,0,1,1]

theorem envBound20155 : H12AffineFastState.Bounded env20155 := by
  intro p hp
  have h : env20155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20154_20155 : H12AffineEnvironment.transform 4 0 env20154 = env20155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20154 == env20155) = true)

def env20156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,98780,8328,64,4489693,185601,17664,262144,181709,4338764,257,21793,46212,254490]

theorem envBound20156 : H12AffineFastState.Bounded env20156 := by
  intro p hp
  have h : env20156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20121_20156 : H12AffineEnvironment.transform 22 180225 env20121 = env20156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env20121 == env20156) = true)

def env20157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,98780,8328,64,43357,185601,17664,262144,181709,400588,257,21793,46212,254490]

theorem envBound20157 : H12AffineFastState.Bounded env20157 := by
  intro p hp
  have h : env20157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20156_20157 : H12AffineEnvironment.transform 21 272512 env20156 = env20157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20156 == env20157) = true)

theorem identity20157 : scanCanonicalize (H12AffineFastState.compose env20157 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound20157 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,115871,272512,120014,98780,8328,64,43357,115150,17664,262144,119042,329731,257,21793,46212,63189]

theorem envBound20158 : H12AffineFastState.Bounded env20158 := by
  intro p hp
  have h : env20158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20157_20158 : H12AffineEnvironment.transform 16 70863 env20157 = env20158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env20157 == env20158) = true)

theorem identity20158 : scanCanonicalize (H12AffineFastState.compose env20158 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound20158 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env20159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,70863,262144,1025,32769,110666,272512,106523,98780,8328,64,43357,111899,12757,262144,107991,329731,257,8692,46212,33280]

theorem envBound20159 : H12AffineFastState.Bounded env20159 := by
  intro p hp
  have h : env20159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20158_20159 : H12AffineEnvironment.transform 13 13525 env20158 = env20159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env20158 == env20159) = true)

theorem identity20159 : scanCanonicalize (H12AffineFastState.compose env20159 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20159 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,1,65536,70863,262144,1025,0,77899,272512,73754,66013,8328,64,10588,79130,12757,262144,75222,329731,257,8692,13445,513]

theorem envBound20160 : H12AffineFastState.Bounded env20160 := by
  intro p hp
  have h : env20160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20159_20160 : H12AffineEnvironment.transform 14 1 env20159 = env20160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20159 == env20160) = true)

def env20161 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,65536,70727,262144,1025,0,77899,272392,73754,65877,8192,64,10588,79130,12637,262144,75102,329731,257,8572,13325,513]

theorem envBound20161 : H12AffineFastState.Bounded env20161 := by
  intro p hp
  have h : env20161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20160_20161 : H12AffineEnvironment.transform 6 8 env20160 = env20161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20160 == env20161) = true)

theorem identity20161 : scanCanonicalize (H12AffineFastState.compose env20161 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20161 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env20162 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,65536,70679,262144,1025,0,77851,272392,73754,65797,8192,16,10508,79130,12557,262144,75022,329731,257,8492,13325,513]

theorem envBound20162 : H12AffineFastState.Bounded env20162 := by
  intro p hp
  have h : env20162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20161_20162 : H12AffineEnvironment.transform 5 16 env20161 = env20162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20161 == env20162) = true)

theorem identity20162 : scanCanonicalize (H12AffineFastState.compose env20162 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound20162 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env20163 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,263,5392,262144,1025,0,12572,272392,8477,2,8192,16,10508,13341,12557,262144,9225,264452,257,8492,13325,513]

theorem envBound20163 : H12AffineFastState.Bounded env20163 := by
  intro p hp
  have h : env20163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20162_20163 : H12AffineEnvironment.transform 15 263 env20162 = env20163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env20162 == env20163) = true)

theorem identity20163 : scanCanonicalize (H12AffineFastState.compose env20163 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound20163 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20164 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,263,5392,2341,1025,0,12572,8493,8477,2,8192,16,10508,13341,12557,2341,9225,33,257,8492,13325,513]

theorem envBound20164 : H12AffineFastState.Bounded env20164 := by
  intro p hp
  have h : env20164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20163_20164 : H12AffineEnvironment.transform 17 2341 env20163 = env20164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env20163 == env20164) = true)

theorem identity20164 : scanCanonicalize (H12AffineFastState.compose env20164 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 805) := by decide +kernel

theorem selectedBound20164 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env20165 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,805,8192,10024,1,263,1589,2341,1025,0,8761,8493,8477,2,8192,16,10508,10040,8744,2341,9225,33,257,8492,10024,513]

theorem envBound20165 : H12AffineFastState.Bounded env20165 := by
  intro p hp
  have h : env20165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20164_20165 : H12AffineEnvironment.transform 11 805 env20164 = env20165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 805 env20164 == env20165) = true)

theorem identity20165 : scanCanonicalize (H12AffineFastState.compose env20165 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound20165 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20166 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,805,8192,8988,1,263,513,2341,53,0,8761,8493,8477,2,8192,16,10508,8972,8744,2341,8253,33,257,8492,8988,513]

theorem envBound20166 : H12AffineFastState.Bounded env20166 := by
  intro p hp
  have h : env20166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20165_20166 : H12AffineEnvironment.transform 9 52 env20165 = env20166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env20165 == env20166) = true)

theorem identity20166 : scanCanonicalize (H12AffineFastState.compose env20166 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20166 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env20167 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,512,8192,8761,1,34,513,2048,53,0,8761,8200,8248,2,8192,16,10281,8745,8744,2048,8253,33,36,8201,8761,513]

theorem envBound20167 : H12AffineFastState.Bounded env20167 := by
  intro p hp
  have h : env20167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20166_20167 : H12AffineEnvironment.transform 7 37 env20166 = env20167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20166 == env20167) = true)

theorem identity20167 : scanCanonicalize (H12AffineFastState.compose env20167 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound20167 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env20168 : List Nat := [2,4,8,16,32,16,8,37,512,52,17,512,8192,8761,1,34,513,17,53,0,8761,8200,8248,2,8192,16,8248,8745,8744,17,8253,33,36,8201,8761,513]

theorem envBound20168 : H12AffineFastState.Bounded env20168 := by
  intro p hp
  have h : env20168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20167_20168 : H12AffineEnvironment.transform 10 17 env20167 = env20168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env20167 == env20168) = true)

theorem identity20168 : scanCanonicalize (H12AffineFastState.compose env20168 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound20168 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20169 : List Nat := [2,4,8,16,32,16,8,37,512,52,17,512,41,528,1,34,513,17,53,0,528,33,17,2,41,16,17,512,513,17,20,33,36,32,528,513]

theorem envBound20169 : H12AffineFastState.Bounded env20169 := by
  intro p hp
  have h : env20169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20168_20169 : H12AffineEnvironment.transform 12 41 env20168 = env20169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env20168 == env20169) = true)

theorem identity20169 : scanCanonicalize (H12AffineFastState.compose env20169 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound20169 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20170 : List Nat := [2,4,8,16,32,16,8,37,27,52,17,27,41,11,1,34,26,17,53,0,11,33,17,2,41,16,17,27,26,17,20,33,36,32,11,26]

theorem envBound20170 : H12AffineFastState.Bounded env20170 := by
  intro p hp
  have h : env20170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20169_20170 : H12AffineEnvironment.transform 8 27 env20169 = env20170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env20169 == env20170) = true)

theorem identity20170 : scanCanonicalize (H12AffineFastState.compose env20170 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound20170 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20171 : List Nat := [2,4,8,10,32,10,8,37,1,46,11,1,41,11,1,34,0,11,47,0,11,33,11,2,41,10,11,1,0,11,14,33,36,32,11,0]

theorem envBound20171 : H12AffineFastState.Bounded env20171 := by
  intro p hp
  have h : env20171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20170_20171 : H12AffineEnvironment.transform 3 10 env20170 = env20171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env20170 == env20171) = true)

def env20172 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,65536,70726,262144,1025,0,77899,272393,73754,65876,8193,64,10588,79130,12636,262144,75103,329731,257,8573,13324,513]

theorem envBound20172 : H12AffineFastState.Bounded env20172 := by
  intro p hp
  have h : env20172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20160_20172 : H12AffineEnvironment.transform 6 9 env20160 = env20172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20160 == env20172) = true)

theorem identity20172 : scanCanonicalize (H12AffineFastState.compose env20172 (packedSelected [2,6,17] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound20172 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env20173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,65536,70726,67699,1025,0,77899,73850,73754,65876,8193,64,10588,79130,12636,67699,75103,112,257,8573,13324,513]

theorem envBound20173 : H12AffineFastState.Bounded env20173 := by
  intro p hp
  have h : env20173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20172_20173 : H12AffineEnvironment.transform 17 67699 env20172 = env20173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env20172 == env20173) = true)

theorem identity20173 : scanCanonicalize (H12AffineFastState.compose env20173 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20173 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env20174 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,1,65536,70679,67618,1025,0,77850,73771,73754,65797,8193,17,10509,79130,12557,67618,75022,33,257,8492,13324,513]

theorem envBound20174 : H12AffineFastState.Bounded env20174 := by
  intro p hp
  have h : env20174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20173_20174 : H12AffineEnvironment.transform 5 17 env20173 = env20174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20173 == env20174) = true)

theorem identity20174 : scanCanonicalize (H12AffineFastState.compose env20174 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound20174 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20175 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,1,262,5393,2340,1025,0,12572,8493,8476,3,8193,17,10509,13340,12557,2340,9224,33,257,8492,13324,513]

theorem envBound20175 : H12AffineFastState.Bounded env20175 := by
  intro p hp
  have h : env20175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20174_20175 : H12AffineEnvironment.transform 15 262 env20174 = env20175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env20174 == env20175) = true)

theorem identity20175 : scanCanonicalize (H12AffineFastState.compose env20175 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound20175 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env20176 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,513,8192,9740,1,262,1808,2340,1025,0,8989,8493,8476,3,8193,17,10509,9757,8972,2340,9224,33,257,8492,9741,513]

theorem envBound20176 : H12AffineFastState.Bounded env20176 := by
  intro p hp
  have h : env20176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20175_20176 : H12AffineEnvironment.transform 11 513 env20175 = env20176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env20175 == env20176) = true)

theorem identity20176 : scanCanonicalize (H12AffineFastState.compose env20176 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2616) := by decide +kernel

theorem selectedBound20176 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env20177 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,513,2616,3124,1,262,1808,2340,1025,0,2341,2837,2852,3,2617,17,821,3109,2356,2340,3632,33,257,2836,3125,513]

theorem envBound20177 : H12AffineFastState.Bounded env20177 := by
  intro p hp
  have h : env20177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20176_20177 : H12AffineEnvironment.transform 12 2616 env20176 = env20177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2616 env20176 == env20177) = true)

theorem identity20177 : scanCanonicalize (H12AffineFastState.compose env20177 (packedSelected [4,9] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound20177 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20178 : List Nat := [2,4,8,16,32,17,9,256,512,1024,820,513,268,1792,1,262,1808,528,1025,0,529,33,16,3,269,17,821,1809,512,528,1284,33,257,32,1793,513]

theorem envBound20178 : H12AffineFastState.Bounded env20178 := by
  intro p hp
  have h : env20178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20177_20178 : H12AffineEnvironment.transform 10 820 env20177 = env20178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env20177 == env20178) = true)

theorem identity20178 : scanCanonicalize (H12AffineFastState.compose env20178 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 289) := by decide +kernel

theorem selectedBound20178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20179 : List Nat := [2,4,8,16,32,17,9,256,512,289,820,513,268,545,1,262,561,528,288,0,529,33,16,3,269,17,821,560,512,528,37,33,257,32,544,513]

theorem envBound20179 : H12AffineFastState.Bounded env20179 := by
  intro p hp
  have h : env20179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20178_20179 : H12AffineEnvironment.transform 9 289 env20178 = env20179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 289 env20178 == env20179) = true)

theorem identity20179 : scanCanonicalize (H12AffineFastState.compose env20179 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound20179 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20180 : List Nat := [2,4,8,16,32,17,9,53,512,20,513,513,57,545,1,51,561,528,21,0,529,33,16,3,56,17,512,560,512,528,37,33,52,32,544,513]

theorem envBound20180 : H12AffineFastState.Bounded env20180 := by
  intro p hp
  have h : env20180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20179_20180 : H12AffineEnvironment.transform 7 53 env20179 = env20180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env20179 == env20180) = true)

theorem identity20180 : scanCanonicalize (H12AffineFastState.compose env20180 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound20180 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20181 : List Nat := [2,4,8,16,16,17,9,5,512,20,513,513,9,529,1,3,513,528,21,0,529,17,16,3,8,17,512,512,512,528,21,17,4,16,528,513]

theorem envBound20181 : H12AffineFastState.Bounded env20181 := by
  intro p hp
  have h : env20181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20180_20181 : H12AffineEnvironment.transform 4 16 env20180 = env20181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env20180 == env20181) = true)

theorem identity20181 : scanCanonicalize (H12AffineFastState.compose env20181 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound20181 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20182 : List Nat := [2,4,8,16,16,17,9,5,1,20,0,0,9,16,1,3,0,17,21,0,16,17,16,3,8,17,1,1,1,17,21,17,4,16,17,0]

theorem envBound20182 : H12AffineFastState.Bounded env20182 := by
  intro p hp
  have h : env20182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20181_20182 : H12AffineEnvironment.transform 8 1 env20181 = env20182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env20181 == env20182) = true)

theorem identity20182 : scanCanonicalize (H12AffineFastState.compose env20182 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound20182 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20183 : List Nat := [2,4,3,16,16,17,2,5,1,20,0,0,2,16,1,3,0,17,21,0,16,17,16,3,3,17,1,1,1,17,21,17,4,16,17,0]

theorem envBound20183 : H12AffineFastState.Bounded env20183 := by
  intro p hp
  have h : env20183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20182_20183 : H12AffineEnvironment.transform 2 3 env20182 = env20183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env20182 == env20183) = true)

theorem identity20183 : scanCanonicalize (H12AffineFastState.compose env20183 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20183 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env20184 : List Nat := [2,4,3,0,0,1,2,5,1,4,0,0,2,0,1,3,0,1,5,0,0,1,0,3,3,1,1,1,1,1,5,1,4,0,1,0]

theorem envBound20184 : H12AffineFastState.Bounded env20184 := by
  intro p hp
  have h : env20184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20183_20184 : H12AffineEnvironment.transform 3 0 env20183 = env20184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20183 == env20184) = true)

def env20185 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,98780,8328,64,43356,185601,17664,262144,181709,400589,257,21793,46212,254490]

theorem envBound20185 : H12AffineFastState.Bounded env20185 := by
  intro p hp
  have h : env20185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20156_20185 : H12AffineEnvironment.transform 21 272513 env20156 = env20185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20156 == env20185) = true)

theorem identity20185 : scanCanonicalize (H12AffineFastState.compose env20185 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound20185 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184400,272513,180225,21763,8328,64,43356,185601,17664,262144,181709,400589,257,21793,46212,145093]

theorem envBound20186 : H12AffineFastState.Bounded env20186 := by
  intro p hp
  have h : env20186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20185_20186 : H12AffineEnvironment.transform 15 54495 env20185 = env20186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env20185 == env20186) = true)

def env20187 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,184320,272513,180225,21763,8328,16,43276,185601,17664,262144,181661,400541,257,21793,46212,145045]

theorem envBound20187 : H12AffineFastState.Bounded env20187 := by
  intro p hp
  have h : env20187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20186_20187 : H12AffineEnvironment.transform 5 16 env20186 = env20187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20186 == env20187) = true)

theorem identity20187 : scanCanonicalize (H12AffineFastState.compose env20187 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound20187 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env20188 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,35109,1025,32769,184320,41380,180225,21763,8328,16,43276,185601,17664,35109,181661,169400,257,21793,46212,145045]

theorem envBound20188 : H12AffineFastState.Bounded env20188 := by
  intro p hp
  have h : env20188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20187_20188 : H12AffineEnvironment.transform 17 35109 env20187 = env20188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env20187 == env20188) = true)

theorem identity20188 : scanCanonicalize (H12AffineFastState.compose env20188 (packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20188 : packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env20189 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,33031,131072,35109,1025,32769,165256,41380,169353,139,8328,16,43276,163977,4232,35109,167957,169400,257,169,46212,145045]

theorem envBound20189 : H12AffineFastState.Bounded env20189 := by
  intro p hp
  have h : env20189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20188_20189 : H12AffineEnvironment.transform 13 5512 env20188 = env20189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20188 == env20189) = true)

theorem identity20189 : scanCanonicalize (H12AffineFastState.compose env20189 (packedSelected [1,3,8,14,17,18,19,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 46229) := by decide +kernel

theorem selectedBound20189 : packedSelected [1,3,8,14,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env20190 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,32768,33031,46229,35109,1025,32769,12573,41380,8476,139,8328,16,43276,13340,4232,35109,9344,8493,257,169,46212,33280]

theorem envBound20190 : H12AffineFastState.Bounded env20190 := by
  intro p hp
  have h : env20190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20189_20190 : H12AffineEnvironment.transform 16 46229 env20189 = env20190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46229 env20189 == env20190) = true)

theorem identity20190 : scanCanonicalize (H12AffineFastState.compose env20190 (packedSelected [3,5,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound20190 : packedSelected [3,5,14,16,19] rootPS < 2^1333 := by decide +kernel

def env20191 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5512,8460,8203,5529,10281,1025,8461,12573,168,8476,139,8328,16,2048,13340,4232,10281,9344,8493,257,169,5512,8972]

theorem envBound20191 : H12AffineFastState.Bounded env20191 := by
  intro p hp
  have h : env20191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20190_20191 : H12AffineEnvironment.transform 14 8460 env20190 = env20191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env20190 == env20191) = true)

theorem identity20191 : scanCanonicalize (H12AffineFastState.compose env20191 (packedSelected [2,3,4,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 700) := by decide +kernel

theorem selectedBound20191 : packedSelected [2,3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env20192 : List Nat := [2,4,8,16,32,16,128,256,512,700,2048,4096,8192,4916,8460,8203,4901,10281,701,8461,12573,168,8476,139,8328,16,2048,12960,4232,10281,8764,8493,257,169,4916,8972]

theorem envBound20192 : H12AffineFastState.Bounded env20192 := by
  intro p hp
  have h : env20192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20191_20192 : H12AffineEnvironment.transform 9 700 env20191 = env20192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 700 env20191 == env20192) = true)

theorem identity20192 : scanCanonicalize (H12AffineFastState.compose env20192 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 4996) := by decide +kernel

theorem selectedBound20192 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env20193 : List Nat := [2,4,8,16,32,16,128,256,512,700,2048,4096,4996,4916,4744,5007,4901,7085,701,4745,665,168,4760,139,4876,16,2048,292,4232,7085,4536,4777,257,169,4916,4232]

theorem envBound20193 : H12AffineFastState.Bounded env20193 := by
  intro p hp
  have h : env20193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20192_20193 : H12AffineEnvironment.transform 12 4996 env20192 = env20193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4996 env20192 == env20193) = true)

theorem identity20193 : scanCanonicalize (H12AffineFastState.compose env20193 (packedSelected [1,3,4,5,6,8,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound20193 : packedSelected [1,3,4,5,6,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env20194 : List Nat := [2,4,8,16,32,16,128,256,512,700,2048,545,421,277,169,430,260,2444,701,168,665,168,185,139,301,16,2048,292,681,2444,921,136,257,169,277,681]

theorem envBound20194 : H12AffineFastState.Bounded env20194 := by
  intro p hp
  have h : env20194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20193_20194 : H12AffineEnvironment.transform 11 545 env20193 = env20194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env20193 == env20194) = true)

theorem identity20194 : scanCanonicalize (H12AffineFastState.compose env20194 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20194 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env20195 : List Nat := [2,4,8,16,32,16,9,256,512,565,2048,545,300,277,32,295,260,2309,564,33,528,33,48,2,301,16,2048,292,544,2309,784,1,257,32,277,544]

theorem envBound20195 : H12AffineFastState.Bounded env20195 := by
  intro p hp
  have h : env20195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20194_20195 : H12AffineEnvironment.transform 6 9 env20194 = env20195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20194 == env20195) = true)

theorem identity20195 : scanCanonicalize (H12AffineFastState.compose env20195 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound20195 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20196 : List Nat := [2,4,8,16,32,16,9,5,512,565,2048,545,41,16,32,34,1,2048,564,33,528,33,48,2,40,16,2048,33,544,2048,533,1,4,32,16,544]

theorem envBound20196 : H12AffineFastState.Bounded env20196 := by
  intro p hp
  have h : env20196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20195_20196 : H12AffineEnvironment.transform 7 5 env20195 = env20196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env20195 == env20196) = true)

theorem identity20196 : scanCanonicalize (H12AffineFastState.compose env20196 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20196 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20197 : List Nat := [2,4,8,16,1,16,9,5,512,532,2048,512,8,16,1,3,1,2048,533,0,528,0,17,2,9,16,2048,0,513,2048,533,1,4,1,16,513]

theorem envBound20197 : H12AffineFastState.Bounded env20197 := by
  intro p hp
  have h : env20197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20196_20197 : H12AffineEnvironment.transform 4 1 env20196 = env20197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20196 == env20197) = true)

def env20198 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,184321,272513,180225,21763,8328,17,43277,185601,17664,262144,181660,400540,257,21793,46212,145044]

theorem envBound20198 : H12AffineFastState.Bounded env20198 := by
  intro p hp
  have h : env20198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20186_20198 : H12AffineEnvironment.transform 5 17 env20186 = env20198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20186 == env20198) = true)

theorem identity20198 : scanCanonicalize (H12AffineFastState.compose env20198 (packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound20198 : packedSelected [4,7,9,10,15,16,17,19,20,26,27,31,38] rootPS < 2^1333 := by decide +kernel

def env20199 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33031,131072,262144,1025,32769,165256,272513,169352,138,8328,17,43277,163976,4233,262144,167957,400540,257,168,46212,145044]

theorem envBound20199 : H12AffineFastState.Bounded env20199 := by
  intro p hp
  have h : env20199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20198_20199 : H12AffineEnvironment.transform 13 5513 env20198 = env20199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env20198 == env20199) = true)

theorem identity20199 : scanCanonicalize (H12AffineFastState.compose env20199 (packedSelected [3,19,24,31] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound20199 : packedSelected [3,19,24,31] rootPS < 2^1333 := by decide +kernel

def env20200 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33031,38296,262144,1025,32769,4112,272513,16,138,8328,17,43277,5392,4233,262144,1421,297220,257,168,46212,41740]

theorem envBound20200 : H12AffineFastState.Bounded env20200 := by
  intro p hp
  have h : env20200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20199_20200 : H12AffineEnvironment.transform 16 38296 env20199 = env20200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env20199 == env20200) = true)

theorem identity20200 : scanCanonicalize (H12AffineFastState.compose env20200 (packedSelected [17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound20200 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env20201 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8580,8323,13340,262144,1025,8581,4112,272513,16,138,8328,17,2185,5392,4233,262144,1421,272512,257,168,5376,648]

theorem envBound20201 : H12AffineFastState.Bounded env20201 := by
  intro p hp
  have h : env20201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20200_20201 : H12AffineEnvironment.transform 14 8580 env20200 = env20201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env20200 == env20201) = true)

theorem identity20201 : scanCanonicalize (H12AffineFastState.compose env20201 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound20201 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env20202 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5156,8233,8323,13340,262144,1025,8232,4112,272513,16,138,8328,17,2185,5309,4233,262144,1056,272512,172,168,5293,648]

theorem envBound20202 : H12AffineFastState.Bounded env20202 := by
  intro p hp
  have h : env20202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20201_20202 : H12AffineEnvironment.transform 7 173 env20201 = env20202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env20201 == env20202) = true)

theorem identity20202 : scanCanonicalize (H12AffineFastState.compose env20202 (packedSelected [6,14] rootPS)) = affineNative (2^(17+1) ^^^ 3125) := by decide +kernel

theorem selectedBound20202 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env20203 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,5156,8233,8323,13340,3125,1025,8232,4112,9396,16,138,8328,17,2185,5309,4233,3125,1056,9397,172,168,5293,648]

theorem envBound20203 : H12AffineFastState.Bounded env20203 := by
  intro p hp
  have h : env20203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20202_20203 : H12AffineEnvironment.transform 17 3125 env20202 = env20203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3125 env20202 == env20203) = true)

theorem identity20203 : scanCanonicalize (H12AffineFastState.compose env20203 (packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound20203 : packedSelected [0,1,2,3,4,5,6,7,8,9,16] rootPS < 2^1333 := by decide +kernel

def env20204 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2064,8192,3124,8233,8323,11276,3125,1025,8232,2048,9396,16,138,8328,17,2185,3245,2201,3125,1056,9397,172,168,3261,648]

theorem envBound20204 : H12AffineFastState.Bounded env20204 := by
  intro p hp
  have h : env20204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20203_20204 : H12AffineEnvironment.transform 11 2064 env20203 = env20204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env20203 == env20204) = true)

theorem identity20204 : scanCanonicalize (H12AffineFastState.compose env20204 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 3221) := by decide +kernel

theorem selectedBound20204 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env20205 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,2064,3221,3124,3260,3094,153,3125,1025,3261,2048,2081,16,138,3101,17,2185,3245,2201,3125,1056,2080,172,168,3261,648]

theorem envBound20205 : H12AffineFastState.Bounded env20205 := by
  intro p hp
  have h : env20205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20204_20205 : H12AffineEnvironment.transform 12 3221 env20204 = env20205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3221 env20204 == env20205) = true)

theorem identity20205 : scanCanonicalize (H12AffineFastState.compose env20205 (packedSelected [0,1,3,5,6,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound20205 : packedSelected [0,1,3,5,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env20206 : List Nat := [2,4,8,16,32,17,128,173,512,1024,1076,1060,161,0,136,34,153,1,1025,137,1076,1045,16,138,41,17,1213,153,1197,1,1056,1044,172,168,137,648]

theorem envBound20206 : H12AffineFastState.Bounded env20206 := by
  intro p hp
  have h : env20206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20205_20206 : H12AffineEnvironment.transform 10 1076 env20205 = env20206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env20205 == env20206) = true)

theorem identity20206 : scanCanonicalize (H12AffineFastState.compose env20206 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20206 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20207 : List Nat := [2,4,8,1,32,0,128,173,512,1024,1061,1060,161,0,136,34,136,1,1025,137,1061,1028,1,138,41,0,1196,136,1197,1,1056,1029,172,168,137,648]

theorem envBound20207 : H12AffineFastState.Bounded env20207 := by
  intro p hp
  have h : env20207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20206_20207 : H12AffineEnvironment.transform 3 1 env20206 = env20207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20206 == env20207) = true)

theorem identity20207 : scanCanonicalize (H12AffineFastState.compose env20207 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound20207 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env20208 : List Nat := [2,4,8,1,32,0,128,173,512,173,136,137,161,0,136,34,136,1,172,137,136,169,1,138,41,0,1,136,0,1,141,168,172,168,137,648]

theorem envBound20208 : H12AffineFastState.Bounded env20208 := by
  intro p hp
  have h : env20208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20207_20208 : H12AffineEnvironment.transform 9 173 env20207 = env20208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env20207 == env20208) = true)

theorem identity20208 : scanCanonicalize (H12AffineFastState.compose env20208 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20208 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20209 : List Nat := [2,4,8,1,32,0,8,37,512,37,0,1,41,0,0,34,0,1,36,1,0,33,1,2,41,0,1,0,0,1,5,32,36,32,1,512]

theorem envBound20209 : H12AffineFastState.Bounded env20209 := by
  intro p hp
  have h : env20209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20208_20209 : H12AffineEnvironment.transform 6 8 env20208 = env20209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20208 == env20209) = true)

theorem identity20209 : scanCanonicalize (H12AffineFastState.compose env20209 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound20209 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20210 : List Nat := [2,4,8,1,5,0,8,0,512,0,0,1,12,0,0,7,0,1,1,1,0,4,1,2,12,0,1,0,0,1,5,5,1,5,1,512]

theorem envBound20210 : H12AffineFastState.Bounded env20210 := by
  intro p hp
  have h : env20210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20209_20210 : H12AffineEnvironment.transform 4 5 env20209 = env20210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env20209 == env20210) = true)

theorem identity20210 : scanCanonicalize (H12AffineFastState.compose env20210 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound20210 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20211 : List Nat := [2,4,0,1,5,0,0,0,512,0,0,1,4,0,0,7,0,1,1,1,0,4,1,2,4,0,1,0,0,1,5,5,1,5,1,512]

theorem envBound20211 : H12AffineFastState.Bounded env20211 := by
  intro p hp
  have h : env20211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20210_20211 : H12AffineEnvironment.transform 2 0 env20210 = env20211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env20210 == env20211) = true)

theorem identity20211 : scanCanonicalize (H12AffineFastState.compose env20211 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound20211 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20212 : List Nat := [2,2,0,1,3,0,0,0,512,0,0,1,2,0,0,1,0,1,1,1,0,2,1,2,2,0,1,0,0,1,3,3,1,3,1,512]

theorem envBound20212 : H12AffineFastState.Bounded env20212 := by
  intro p hp
  have h : env20212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20211_20212 : H12AffineEnvironment.transform 1 2 env20211 = env20212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env20211 == env20212) = true)

theorem identity20212 : scanCanonicalize (H12AffineFastState.compose env20212 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20212 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env20213 : List Nat := [2,2,0,1,3,0,0,0,0,0,0,1,2,0,0,1,0,1,1,1,0,2,1,2,2,0,1,0,0,1,3,3,1,3,1,0]

theorem envBound20213 : H12AffineFastState.Bounded env20213 := by
  intro p hp
  have h : env20213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20212_20213 : H12AffineEnvironment.transform 8 0 env20212 = env20213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20212 == env20213) = true)

theorem identity20213 : scanCanonicalize (H12AffineFastState.compose env20213 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound20213 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20214 : List Nat := [0,0,0,1,1,0,0,0,0,0,0,1,0,0,0,1,0,1,1,1,0,0,1,0,0,0,1,0,0,1,1,1,1,1,1,0]

theorem envBound20214 : H12AffineFastState.Bounded env20214 := by
  intro p hp
  have h : env20214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20213_20214 : H12AffineEnvironment.transform 0 0 env20213 = env20214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env20213 == env20214) = true)

def env20215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,8388608,8602077,8328,64,4489693,8393985,8553728,8830977,181709,12645452,257,21792,46213,254490]

theorem envBound20215 : H12AffineFastState.Bounded env20215 := by
  intro p hp
  have h : env20215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20120_20215 : H12AffineEnvironment.transform 20 184401 env20120 = env20215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env20120 == env20215) = true)

def env20216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,98781,8328,64,4489693,185601,17664,262145,181709,4338764,257,21792,46213,254490]

theorem envBound20216 : H12AffineFastState.Bounded env20216 := by
  intro p hp
  have h : env20216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20215_20216 : H12AffineEnvironment.transform 22 180224 env20215 = env20216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180224 env20215 == env20216) = true)

def env20217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,98781,8328,64,43357,185601,17664,262145,181709,400588,257,21792,46213,254490]

theorem envBound20217 : H12AffineFastState.Bounded env20217 := by
  intro p hp
  have h : env20217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20216_20217 : H12AffineEnvironment.transform 21 272512 env20216 = env20217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20216 == env20217) = true)

def env20218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180224,98645,8192,64,43357,185601,17664,262145,181573,400452,257,21792,46093,254490]

theorem envBound20218 : H12AffineFastState.Bounded env20218 := by
  intro p hp
  have h : env20218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20217_20218 : H12AffineEnvironment.transform 6 8 env20217 = env20218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20217 == env20218) = true)

theorem identity20218 : scanCanonicalize (H12AffineFastState.compose env20218 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound20218 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,77898,272392,73755,98645,8192,64,43357,79130,17664,262145,75102,392287,257,21792,46093,513]

theorem envBound20219 : H12AffineFastState.Bounded env20219 := by
  intro p hp
  have h : env20219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20218_20219 : H12AffineEnvironment.transform 16 122907 env20218 = env20219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env20218 == env20219) = true)

theorem identity20219 : scanCanonicalize (H12AffineFastState.compose env20219 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound20219 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env20220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122907,67619,1025,32769,77898,73771,73755,98645,8192,64,43357,79130,17664,67618,75102,62588,257,21792,46093,513]

theorem envBound20220 : H12AffineFastState.Bounded env20220 := by
  intro p hp
  have h : env20220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20219_20220 : H12AffineEnvironment.transform 17 67619 env20219 = env20220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env20219 == env20220) = true)

theorem identity20220 : scanCanonicalize (H12AffineFastState.compose env20220 (packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound20220 : packedSelected [0,3,7,10,11,16,18,19,23,24,32] rootPS < 2^1333 := by decide +kernel

def env20221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,65536,70678,67619,1025,29708,77898,73771,73755,95576,8192,64,23888,79130,17664,67618,75102,113,257,21792,16384,513]

theorem envBound20221 : H12AffineFastState.Bounded env20221 := by
  intro p hp
  have h : env20221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20220_20221 : H12AffineEnvironment.transform 14 29709 env20220 = env20221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env20220 == env20221) = true)

theorem identity20221 : scanCanonicalize (H12AffineFastState.compose env20221 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound20221 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env20222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,1,65536,70678,67619,1025,0,77898,73771,73755,65876,8192,64,10588,79130,12556,67618,75102,113,257,8492,13324,513]

theorem envBound20222 : H12AffineFastState.Bounded env20222 := by
  intro p hp
  have h : env20222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20221_20222 : H12AffineEnvironment.transform 13 13324 env20221 = env20222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env20221 == env20222) = true)

theorem identity20222 : scanCanonicalize (H12AffineFastState.compose env20222 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound20222 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env20223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,1,262,5392,2341,1025,0,12620,8493,8477,82,8192,64,10588,13340,12556,2340,9304,113,257,8492,13324,513]

end H12CloudChart1