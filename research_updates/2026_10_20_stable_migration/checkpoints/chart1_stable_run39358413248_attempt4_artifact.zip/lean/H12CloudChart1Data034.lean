import H12CloudChart1Data033

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound8442 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env8443 : List Nat := [2,4,8,16,32,0,56,5,512,5,58,16,8192,0,8201,8714,16,555,564,8201,1,512,545,531,8241,545,522,545,544,570,5,16,564,544,17,49]

theorem envBound8443 : H12AffineFastState.Bounded env8443 := by
  intro p hp
  have h : env8443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8442_8443 : H12AffineEnvironment.transform 15 8714 env8442 = env8443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8442 == env8443) = true)

theorem identity8443 : scanCanonicalize (H12AffineFastState.compose env8443 (packedSelected [0,5,7,8,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 56) := by decide +kernel

theorem selectedBound8443 : packedSelected [0,5,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env8444 : List Nat := [2,4,8,16,32,0,56,5,512,5,58,16,56,0,49,562,16,555,564,49,1,512,545,531,9,545,522,545,544,570,5,16,564,544,17,49]

theorem envBound8444 : H12AffineFastState.Bounded env8444 := by
  intro p hp
  have h : env8444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8443_8444 : H12AffineEnvironment.transform 12 56 env8443 = env8444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 56 env8443 == env8444) = true)

theorem identity8444 : scanCanonicalize (H12AffineFastState.compose env8444 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound8444 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8445 : List Nat := [2,4,8,16,32,0,56,5,42,5,58,16,56,0,49,24,16,1,30,49,1,42,11,57,9,11,32,11,10,16,5,16,30,10,17,49]

theorem envBound8445 : H12AffineFastState.Bounded env8445 := by
  intro p hp
  have h : env8445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8444_8445 : H12AffineEnvironment.transform 8 42 env8444 = env8445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env8444 == env8445) = true)

theorem identity8445 : scanCanonicalize (H12AffineFastState.compose env8445 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound8445 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env8446 : List Nat := [2,4,8,16,26,0,2,5,16,5,0,16,2,0,11,24,16,1,30,11,1,16,11,3,9,11,26,11,10,16,5,16,30,10,17,11]

theorem envBound8446 : H12AffineFastState.Bounded env8446 := by
  intro p hp
  have h : env8446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8445_8446 : H12AffineEnvironment.transform 4 26 env8445 = env8446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env8445 == env8446) = true)

theorem identity8446 : scanCanonicalize (H12AffineFastState.compose env8446 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8447 : List Nat := [2,4,2,16,16,0,2,5,16,5,0,16,2,0,1,18,16,1,20,1,1,16,1,3,3,1,16,1,0,16,5,16,20,0,17,1]

theorem envBound8447 : H12AffineFastState.Bounded env8447 := by
  intro p hp
  have h : env8447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8446_8447 : H12AffineEnvironment.transform 2 2 env8446 = env8447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8446 == env8447) = true)

theorem identity8447 : scanCanonicalize (H12AffineFastState.compose env8447 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8447 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env8448 : List Nat := [2,4,2,1,1,0,2,5,1,5,0,1,2,0,1,3,1,1,5,1,1,1,1,3,3,1,1,1,0,1,5,1,5,0,0,1]

theorem envBound8448 : H12AffineFastState.Bounded env8448 := by
  intro p hp
  have h : env8448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8447_8448 : H12AffineEnvironment.transform 3 1 env8447 = env8448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8447 == env8448) = true)

def env8449 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,17,8192,16384,8201,65536,17,90145,565,8201,0,90122,545,90136,8241,16928,73729,73771,73770,75786,5,16400,565,73770,74267,90682]

theorem envBound8449 : H12AffineFastState.Bounded env8449 := by
  intro p hp
  have h : env8449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8439_8449 : H12AffineEnvironment.transform 5 1 env8439 = env8449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8439 == env8449) = true)

theorem identity8449 : scanCanonicalize (H12AffineFastState.compose env8449 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 25098) := by decide +kernel

theorem selectedBound8449 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8450 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,17,8192,16384,8201,25098,17,555,565,8201,0,512,545,530,8241,16928,16907,16929,16928,18944,5,16400,565,16928,16401,48]

theorem envBound8450 : H12AffineFastState.Bounded env8450 := by
  intro p hp
  have h : env8450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8449_8450 : H12AffineEnvironment.transform 15 25098 env8449 = env8450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25098 env8449 == env8450) = true)

theorem identity8450 : scanCanonicalize (H12AffineFastState.compose env8450 (packedSelected [14] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound8450 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8451 : List Nat := [2,4,8,16,32,1,56,4,49,4,2048,17,8192,16384,8201,24635,17,26,4,8201,0,49,16,35,8241,16401,16442,16400,16401,18481,5,16400,4,16401,16401,48]

theorem envBound8451 : H12AffineFastState.Bounded env8451 := by
  intro p hp
  have h : env8451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8450_8451 : H12AffineEnvironment.transform 8 49 env8450 = env8451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env8450 == env8451) = true)

theorem identity8451 : scanCanonicalize (H12AffineFastState.compose env8451 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 59) := by decide +kernel

theorem selectedBound8451 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8452 : List Nat := [2,4,8,16,32,1,56,4,49,4,59,17,8192,16384,8201,24635,17,26,4,8201,0,49,16,35,8241,16401,16442,16400,16401,16394,5,16400,4,16401,16401,48]

theorem envBound8452 : H12AffineFastState.Bounded env8452 := by
  intro p hp
  have h : env8452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8451_8452 : H12AffineEnvironment.transform 10 59 env8451 = env8452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 59 env8451 == env8452) = true)

theorem identity8452 : scanCanonicalize (H12AffineFastState.compose env8452 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 8201) := by decide +kernel

theorem selectedBound8452 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8453 : List Nat := [2,4,8,16,32,1,56,4,49,4,59,17,8192,8201,8201,50,17,26,4,8201,0,49,16,35,8241,8216,8243,8217,8216,8195,5,8217,4,8216,8216,48]

theorem envBound8453 : H12AffineFastState.Bounded env8453 := by
  intro p hp
  have h : env8453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8452_8453 : H12AffineEnvironment.transform 13 8201 env8452 = env8453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8201 env8452 == env8453) = true)

theorem identity8453 : scanCanonicalize (H12AffineFastState.compose env8453 (packedSelected [1,2,3,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8453 : packedSelected [1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env8454 : List Nat := [2,0,8,16,32,1,56,0,49,0,59,17,8192,8201,8201,50,17,26,0,8201,0,49,16,35,8241,8216,8243,8217,8216,8195,1,8217,0,8216,8216,48]

theorem envBound8454 : H12AffineFastState.Bounded env8454 := by
  intro p hp
  have h : env8454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8453_8454 : H12AffineEnvironment.transform 1 0 env8453 = env8454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8453 == env8454) = true)

def env8455 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,81,8192,16384,8201,65536,81,90144,629,8201,65,90123,544,90201,8241,16992,73793,73771,73770,75786,5,16401,629,73770,74266,90747]

theorem envBound8455 : H12AffineFastState.Bounded env8455 := by
  intro p hp
  have h : env8455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8438_8455 : H12AffineEnvironment.transform 11 81 env8438 = env8455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env8438 == env8455) = true)

def env8456 : List Nat := [2,4,8,16,32,0,56,5,512,5,2048,17,8192,16384,8201,65536,17,90144,565,8201,1,90123,544,90137,8241,16928,73729,73771,73770,75786,5,16401,565,73770,74266,90683]

theorem envBound8456 : H12AffineFastState.Bounded env8456 := by
  intro p hp
  have h : env8456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8455_8456 : H12AffineEnvironment.transform 5 0 env8455 = env8456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8455 == env8456) = true)

theorem identity8456 : scanCanonicalize (H12AffineFastState.compose env8456 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound8456 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8457 : List Nat := [2,4,8,16,32,0,56,5,49,5,2048,17,8192,16384,8201,65536,17,90144,4,8201,1,90123,17,90137,8241,16401,73729,73771,73770,75786,5,16401,4,73770,73771,90122]

theorem envBound8457 : H12AffineFastState.Bounded env8457 := by
  intro p hp
  have h : env8457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8456_8457 : H12AffineEnvironment.transform 8 49 env8456 = env8457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env8456 == env8457) = true)

theorem identity8457 : scanCanonicalize (H12AffineFastState.compose env8457 (packedSelected [1,5,10,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound8457 : packedSelected [1,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8458 : List Nat := [2,4,8,16,32,0,56,5,49,5,58,17,8192,16384,8201,65536,17,90144,4,8201,1,90123,17,90137,8241,16401,73729,73771,73770,73776,5,16401,4,73770,73771,90122]

theorem envBound8458 : H12AffineFastState.Bounded env8458 := by
  intro p hp
  have h : env8458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8457_8458 : H12AffineEnvironment.transform 10 58 env8457 = env8458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env8457 == env8458) = true)

theorem identity8458 : scanCanonicalize (H12AffineFastState.compose env8458 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound8458 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8459 : List Nat := [2,4,8,16,32,0,56,5,49,5,58,17,8192,16384,8201,8251,17,16411,4,8201,1,16432,17,16418,8241,16401,58,16,17,11,5,16401,4,17,16,16433]

theorem envBound8459 : H12AffineFastState.Bounded env8459 := by
  intro p hp
  have h : env8459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8458_8459 : H12AffineEnvironment.transform 15 8251 env8458 = env8459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env8458 == env8459) = true)

theorem identity8459 : scanCanonicalize (H12AffineFastState.compose env8459 (packedSelected [0,3,7,8,11] rootPS)) = affineNative (2^(13+1) ^^^ 8233) := by decide +kernel

theorem selectedBound8459 : packedSelected [0,3,7,8,11] rootPS < 2^1333 := by decide +kernel

def env8460 : List Nat := [2,4,8,16,32,0,56,5,49,5,58,17,8192,8233,8201,8251,17,8242,4,8201,1,8217,17,8203,8241,8248,58,16,17,11,5,8248,4,17,16,8216]

theorem envBound8460 : H12AffineFastState.Bounded env8460 := by
  intro p hp
  have h : env8460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8459_8460 : H12AffineEnvironment.transform 13 8233 env8459 = env8460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8233 env8459 == env8460) = true)

theorem identity8460 : scanCanonicalize (H12AffineFastState.compose env8460 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound8460 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8461 : List Nat := [2,4,8,16,32,0,56,5,49,5,58,17,51,26,58,8,17,1,4,58,1,42,17,56,2,11,58,16,17,11,5,11,4,17,16,43]

theorem envBound8461 : H12AffineFastState.Bounded env8461 := by
  intro p hp
  have h : env8461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8460_8461 : H12AffineEnvironment.transform 12 51 env8460 = env8461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env8460 == env8461) = true)

theorem identity8461 : scanCanonicalize (H12AffineFastState.compose env8461 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8461 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env8462 : List Nat := [2,4,3,16,32,0,51,5,49,5,49,17,51,17,49,3,17,1,4,49,1,33,17,51,2,0,49,16,17,0,5,0,4,17,16,32]

theorem envBound8462 : H12AffineFastState.Bounded env8462 := by
  intro p hp
  have h : env8462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8461_8462 : H12AffineEnvironment.transform 2 3 env8461 = env8462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8461 == env8462) = true)

theorem identity8462 : scanCanonicalize (H12AffineFastState.compose env8462 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8462 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8463 : List Nat := [2,4,3,16,17,0,2,5,0,5,0,17,2,17,0,3,17,1,4,0,1,16,17,2,2,0,0,16,17,0,5,0,4,17,16,17]

theorem envBound8463 : H12AffineFastState.Bounded env8463 := by
  intro p hp
  have h : env8463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8462_8463 : H12AffineEnvironment.transform 4 17 env8462 = env8463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8462 == env8463) = true)

theorem identity8463 : scanCanonicalize (H12AffineFastState.compose env8463 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8463 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8464 : List Nat := [2,4,3,1,0,0,2,5,0,5,0,0,2,0,0,3,0,1,4,0,1,1,0,2,2,0,0,1,0,0,5,0,4,0,1,0]

theorem envBound8464 : H12AffineFastState.Bounded env8464 := by
  intro p hp
  have h : env8464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8463_8464 : H12AffineEnvironment.transform 3 1 env8463 = env8464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8463 == env8464) = true)

def env8465 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,16,8192,16384,8201,65536,16,90144,564,8201,0,90123,544,90136,8241,16929,73728,73771,73770,75786,5,16401,564,73770,74266,90682]

theorem envBound8465 : H12AffineFastState.Bounded env8465 := by
  intro p hp
  have h : env8465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8455_8465 : H12AffineEnvironment.transform 5 1 env8455 = env8465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8455 == env8465) = true)

theorem identity8465 : scanCanonicalize (H12AffineFastState.compose env8465 (packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8251) := by decide +kernel

theorem selectedBound8465 : packedSelected [1,2,3,5,8,10,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8466 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,16,8192,16384,8201,8251,16,16411,564,8201,0,16432,544,16419,8241,16929,59,16,17,2097,5,16401,564,17,545,16897]

theorem envBound8466 : H12AffineFastState.Bounded env8466 := by
  intro p hp
  have h : env8466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8465_8466 : H12AffineEnvironment.transform 15 8251 env8465 = env8466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8251 env8465 == env8466) = true)

theorem identity8466 : scanCanonicalize (H12AffineFastState.compose env8466 (packedSelected [1,3,12,13,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound8466 : packedSelected [1,3,12,13,14,15,17] rootPS < 2^1333 := by decide +kernel

def env8467 : List Nat := [2,4,8,16,32,1,56,4,512,4,2048,16,8192,0,8201,8251,16,27,564,8201,0,48,544,35,8241,545,59,16,17,2097,5,17,564,17,545,513]

theorem envBound8467 : H12AffineFastState.Bounded env8467 := by
  intro p hp
  have h : env8467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8466_8467 : H12AffineEnvironment.transform 13 0 env8466 = env8467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env8466 == env8467) = true)

theorem identity8467 : scanCanonicalize (H12AffineFastState.compose env8467 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound8467 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env8468 : List Nat := [2,4,8,16,32,1,56,4,33,4,2048,16,8192,0,8201,8251,16,27,21,8201,0,48,1,35,8241,0,59,16,17,2097,5,17,21,17,0,32]

theorem envBound8468 : H12AffineFastState.Bounded env8468 := by
  intro p hp
  have h : env8468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8467_8468 : H12AffineEnvironment.transform 8 33 env8467 = env8468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env8467 == env8468) = true)

theorem identity8468 : scanCanonicalize (H12AffineFastState.compose env8468 (packedSelected [2,8] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound8468 : packedSelected [2,8] rootPS < 2^1333 := by decide +kernel

def env8469 : List Nat := [2,4,8,16,32,1,56,4,33,4,5,16,8192,0,8201,8251,16,27,21,8201,0,48,1,35,8241,0,59,16,17,52,5,17,21,17,0,32]

theorem envBound8469 : H12AffineFastState.Bounded env8469 := by
  intro p hp
  have h : env8469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8468_8469 : H12AffineEnvironment.transform 10 5 env8468 = env8469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env8468 == env8469) = true)

theorem identity8469 : scanCanonicalize (H12AffineFastState.compose env8469 (packedSelected [2,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8469 : packedSelected [2,12] rootPS < 2^1333 := by decide +kernel

def env8470 : List Nat := [2,4,8,11,32,1,35,4,33,4,5,11,8192,0,8201,8224,11,0,14,8201,0,43,1,35,8234,0,32,11,10,47,5,10,14,10,0,32]

theorem envBound8470 : H12AffineFastState.Bounded env8470 := by
  intro p hp
  have h : env8470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8469_8470 : H12AffineEnvironment.transform 3 11 env8469 = env8470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8469 == env8470) = true)

theorem identity8470 : scanCanonicalize (H12AffineFastState.compose env8470 (packedSelected [1,4,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8470 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env8471 : List Nat := [2,4,2,1,32,1,35,4,33,4,5,1,8192,0,8195,8224,1,0,4,8195,0,33,1,35,8224,0,32,1,0,37,5,0,4,0,0,32]

theorem envBound8471 : H12AffineFastState.Bounded env8471 := by
  intro p hp
  have h : env8471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8470_8471 : H12AffineEnvironment.transform 2 2 env8470 = env8471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8470 == env8471) = true)

theorem identity8471 : scanCanonicalize (H12AffineFastState.compose env8471 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 39) := by decide +kernel

theorem selectedBound8471 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8472 : List Nat := [2,4,2,1,32,1,35,4,33,4,5,1,39,0,36,7,1,0,4,36,0,33,1,35,7,0,32,1,0,37,5,0,4,0,0,32]

theorem envBound8472 : H12AffineFastState.Bounded env8472 := by
  intro p hp
  have h : env8472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8471_8472 : H12AffineEnvironment.transform 12 39 env8471 = env8472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 39 env8471 == env8472) = true)

theorem identity8472 : scanCanonicalize (H12AffineFastState.compose env8472 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8473 : List Nat := [2,0,2,1,32,1,35,0,33,0,1,1,35,0,32,3,1,0,0,32,0,33,1,35,3,0,32,1,0,33,1,0,0,0,0,32]

theorem envBound8473 : H12AffineFastState.Bounded env8473 := by
  intro p hp
  have h : env8473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8472_8473 : H12AffineEnvironment.transform 1 0 env8472 = env8473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8472 == env8473) = true)

def env8474 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,65536,4096,94321,4645,8201,65,4194304,4721,90200,8240,21041,77840,4214896,4214897,75786,5,4268059,4645,73770,78410,90746]

theorem envBound8474 : H12AffineFastState.Bounded env8474 := by
  intro p hp
  have h : env8474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8436_8474 : H12AffineEnvironment.transform 6 57 env8436 = env8474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8436 == env8474) = true)

theorem identity8474 : scanCanonicalize (H12AffineFastState.compose env8474 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound8474 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8475 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8201,65536,16,90209,565,8201,65,4194304,609,90200,8240,16929,73728,4210784,4210785,75786,5,4268059,565,73770,74330,90746]

theorem envBound8475 : H12AffineFastState.Bounded env8475 := by
  intro p hp
  have h : env8475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8474_8475 : H12AffineEnvironment.transform 11 16 env8474 = env8475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env8474 == env8475) = true)

def env8476 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8201,65536,16,90209,565,8201,65,16960,609,90200,8240,16929,73728,544,545,75786,5,90715,565,73770,74330,90746]

theorem envBound8476 : H12AffineFastState.Bounded env8476 := by
  intro p hp
  have h : env8476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8475_8476 : H12AffineEnvironment.transform 21 16960 env8475 = env8476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env8475 == env8476) = true)

theorem identity8476 : scanCanonicalize (H12AffineFastState.compose env8476 (packedSelected [5,8,10,12,13,14,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8476 : packedSelected [5,8,10,12,13,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env8477 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8201,8715,16,17002,565,8201,65,16960,609,16979,8240,16929,523,544,545,2561,5,16464,565,545,81,16497]

theorem envBound8477 : H12AffineFastState.Bounded env8477 := by
  intro p hp
  have h : env8477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8476_8477 : H12AffineEnvironment.transform 15 8715 env8476 = env8477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8476 == env8477) = true)

theorem identity8477 : scanCanonicalize (H12AffineFastState.compose env8477 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 625) := by decide +kernel

theorem selectedBound8477 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8478 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,625,8201,8715,16,27,565,8201,65,49,609,34,8240,80,523,544,545,2561,5,545,565,545,81,512]

theorem envBound8478 : H12AffineFastState.Bounded env8478 := by
  intro p hp
  have h : env8478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8477_8478 : H12AffineEnvironment.transform 13 625 env8477 = env8478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 625 env8477 == env8478) = true)

theorem identity8478 : scanCanonicalize (H12AffineFastState.compose env8478 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8478 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8479 : List Nat := [2,4,8,0,32,64,41,68,512,68,2048,0,8192,609,8201,8715,0,11,549,8201,65,33,609,34,8224,64,523,544,545,2561,5,545,549,545,65,512]

theorem envBound8479 : H12AffineFastState.Bounded env8479 := by
  intro p hp
  have h : env8479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8478_8479 : H12AffineEnvironment.transform 3 0 env8478 = env8479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8478 == env8479) = true)

theorem identity8479 : scanCanonicalize (H12AffineFastState.compose env8479 (packedSelected [8,13] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound8479 : packedSelected [8,13] rootPS < 2^1333 := by decide +kernel

def env8480 : List Nat := [2,4,8,0,32,64,41,68,512,68,32,0,8192,609,8201,8715,0,11,549,8201,65,33,609,34,8224,64,523,544,545,545,5,545,549,545,65,512]

theorem envBound8480 : H12AffineFastState.Bounded env8480 := by
  intro p hp
  have h : env8480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8479_8480 : H12AffineEnvironment.transform 10 32 env8479 = env8480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env8479 == env8480) = true)

theorem identity8480 : scanCanonicalize (H12AffineFastState.compose env8480 (packedSelected [1,2,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 552) := by decide +kernel

theorem selectedBound8480 : packedSelected [1,2,5,8,12] rootPS < 2^1333 := by decide +kernel

def env8481 : List Nat := [2,4,8,0,32,64,41,68,512,68,32,0,552,609,545,35,0,11,549,545,65,33,609,34,520,64,523,544,545,545,5,545,549,545,65,512]

theorem envBound8481 : H12AffineFastState.Bounded env8481 := by
  intro p hp
  have h : env8481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8480_8481 : H12AffineEnvironment.transform 12 552 env8480 = env8481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 552 env8480 == env8481) = true)

theorem identity8481 : scanCanonicalize (H12AffineFastState.compose env8481 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8481 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8482 : List Nat := [2,4,8,0,32,10,41,14,512,14,32,0,552,555,545,35,0,11,549,545,11,33,555,34,520,10,523,544,545,545,5,545,549,545,11,512]

theorem envBound8482 : H12AffineFastState.Bounded env8482 := by
  intro p hp
  have h : env8482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8481_8482 : H12AffineEnvironment.transform 5 10 env8481 = env8482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8481 == env8482) = true)

theorem identity8482 : scanCanonicalize (H12AffineFastState.compose env8482 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8482 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env8483 : List Nat := [2,4,8,0,1,10,8,14,512,14,1,0,521,522,512,2,0,11,516,512,11,0,522,3,520,10,523,513,512,512,5,512,516,512,11,512]

theorem envBound8483 : H12AffineFastState.Bounded env8483 := by
  intro p hp
  have h : env8483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8482_8483 : H12AffineEnvironment.transform 4 1 env8482 = env8483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8482 == env8483) = true)

theorem identity8483 : scanCanonicalize (H12AffineFastState.compose env8483 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound8483 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8484 : List Nat := [2,4,8,0,1,10,8,14,10,14,1,0,3,0,10,2,0,11,14,10,11,0,0,3,2,10,1,11,10,10,5,10,14,10,11,10]

theorem envBound8484 : H12AffineFastState.Bounded env8484 := by
  intro p hp
  have h : env8484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8483_8484 : H12AffineEnvironment.transform 8 10 env8483 = env8484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env8483 == env8484) = true)

theorem identity8484 : scanCanonicalize (H12AffineFastState.compose env8484 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8484 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8485 : List Nat := [2,4,3,0,1,1,3,5,1,5,1,0,3,0,1,2,0,0,5,1,0,0,0,3,2,1,1,0,1,1,5,1,5,1,0,1]

theorem envBound8485 : H12AffineFastState.Bounded env8485 := by
  intro p hp
  have h : env8485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8484_8485 : H12AffineEnvironment.transform 2 3 env8484 = env8485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8484 == env8485) = true)

def env8486 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8201,65536,16,90209,565,8201,65,16961,609,90200,8240,16929,73728,545,544,75786,5,90714,565,73770,74330,90746]

theorem envBound8486 : H12AffineFastState.Bounded env8486 := by
  intro p hp
  have h : env8486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8475_8486 : H12AffineEnvironment.transform 21 16961 env8475 = env8486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env8475 == env8486) = true)

theorem identity8486 : scanCanonicalize (H12AffineFastState.compose env8486 (packedSelected [5,8,10,12,13,14,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8315) := by decide +kernel

theorem selectedBound8486 : packedSelected [5,8,10,12,13,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env8487 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,16384,8201,8315,16,16410,565,8201,65,16961,609,16419,8240,16929,123,545,544,2161,5,16929,565,81,545,16897]

theorem envBound8487 : H12AffineFastState.Bounded env8487 := by
  intro p hp
  have h : env8487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8486_8487 : H12AffineEnvironment.transform 15 8315 env8486 = env8487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8315 env8486 == env8487) = true)

theorem identity8487 : scanCanonicalize (H12AffineFastState.compose env8487 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2106) := by decide +kernel

theorem selectedBound8487 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env8488 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,16,8192,2106,8201,8315,16,2080,565,8201,65,2683,609,2073,8240,2587,123,545,544,2161,5,2587,565,81,545,2619]

theorem envBound8488 : H12AffineFastState.Bounded env8488 := by
  intro p hp
  have h : env8488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8487_8488 : H12AffineEnvironment.transform 13 2106 env8487 = env8488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2106 env8487 == env8488) = true)

theorem identity8488 : scanCanonicalize (H12AffineFastState.compose env8488 (packedSelected [0,1,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8488 : packedSelected [0,1,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8489 : List Nat := [2,4,8,16,32,64,57,68,512,68,42,16,8192,16,8201,8315,16,10,565,8201,65,593,609,51,8240,561,123,545,544,91,5,561,565,81,545,529]

theorem envBound8489 : H12AffineFastState.Bounded env8489 := by
  intro p hp
  have h : env8489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8488_8489 : H12AffineEnvironment.transform 10 42 env8488 = env8489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8488 == env8489) = true)

theorem identity8489 : scanCanonicalize (H12AffineFastState.compose env8489 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8489 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env8490 : List Nat := [2,4,8,0,32,64,41,68,512,68,42,0,8192,0,8201,8299,0,10,549,8201,65,577,609,35,8224,545,107,545,544,75,5,545,549,65,545,513]

theorem envBound8490 : H12AffineFastState.Bounded env8490 := by
  intro p hp
  have h : env8490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8489_8490 : H12AffineEnvironment.transform 3 0 env8489 = env8490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8489 == env8490) = true)

theorem identity8490 : scanCanonicalize (H12AffineFastState.compose env8490 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 584) := by decide +kernel

theorem selectedBound8490 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env8491 : List Nat := [2,4,8,0,32,64,41,68,512,68,42,0,584,0,577,547,0,10,549,577,65,577,609,35,616,545,107,545,544,75,5,545,549,65,545,513]

theorem envBound8491 : H12AffineFastState.Bounded env8491 := by
  intro p hp
  have h : env8491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8490_8491 : H12AffineEnvironment.transform 12 584 env8490 = env8491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 584 env8490 == env8491) = true)

theorem identity8491 : scanCanonicalize (H12AffineFastState.compose env8491 (packedSelected [2,5] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound8491 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env8492 : List Nat := [2,4,8,0,32,64,41,68,46,68,42,0,102,0,111,13,0,10,11,111,65,111,79,35,70,15,107,15,14,75,5,15,11,65,15,47]

theorem envBound8492 : H12AffineFastState.Bounded env8492 := by
  intro p hp
  have h : env8492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8491_8492 : H12AffineEnvironment.transform 8 46 env8491 = env8492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env8491 == env8492) = true)

theorem identity8492 : scanCanonicalize (H12AffineFastState.compose env8492 (packedSelected [0,1,9] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound8492 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env8493 : List Nat := [2,4,6,0,32,64,39,68,32,68,36,0,102,0,97,3,0,4,5,97,65,97,65,35,70,1,101,1,0,69,5,1,5,65,1,33]

theorem envBound8493 : H12AffineFastState.Bounded env8493 := by
  intro p hp
  have h : env8493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8492_8493 : H12AffineEnvironment.transform 2 6 env8492 = env8493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env8492 == env8493) = true)

theorem identity8493 : scanCanonicalize (H12AffineFastState.compose env8493 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8493 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8494 : List Nat := [2,0,2,0,32,64,35,64,32,64,32,0,98,0,97,3,0,0,1,97,65,97,65,35,66,1,97,1,0,65,1,1,1,65,1,33]

theorem envBound8494 : H12AffineFastState.Bounded env8494 := by
  intro p hp
  have h : env8494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8493_8494 : H12AffineEnvironment.transform 1 0 env8493 = env8494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8493 == env8494) = true)

theorem identity8494 : scanCanonicalize (H12AffineFastState.compose env8494 (packedSelected [0,3] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound8494 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env8495 : List Nat := [2,0,2,0,32,33,35,33,32,33,32,0,3,0,0,3,0,0,1,0,32,0,32,35,35,1,0,1,0,32,1,1,1,32,1,33]

theorem envBound8495 : H12AffineFastState.Bounded env8495 := by
  intro p hp
  have h : env8495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8494_8495 : H12AffineEnvironment.transform 5 33 env8494 = env8495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env8494 == env8495) = true)

def env8496 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,16777216,8329,16855760,807681,4735913,4735573,17324939,529049,21517022,524288,17322923,19415347,16778207]

theorem envBound8496 : H12AffineFastState.Bounded env8496 := by
  intro p hp
  have h : env8496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8147_8496 : H12AffineEnvironment.transform 26 807681 env8147 = env8496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 807681 env8147 == env8496) = true)

def env8497 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,90336,8329,21040,807681,4735913,4735573,605035,529049,4796990,524288,602955,2695635,90943]

theorem envBound8497 : H12AffineFastState.Bounded env8497 := by
  intro p hp
  have h : env8497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8496_8497 : H12AffineEnvironment.transform 23 90336 env8496 = env8497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90336 env8496 == env8497) = true)

def env8498 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5005,90336,8329,21040,278625,4214985,4215093,75787,505,4268382,4960,73771,2175667,90943]

theorem envBound8498 : H12AffineFastState.Bounded env8498 := by
  intro p hp
  have h : env8498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8497_8498 : H12AffineEnvironment.transform 18 4960 env8497 = env8498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8497 == env8498) = true)

theorem identity8498 : scanCanonicalize (H12AffineFastState.compose env8498 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 24770) := by decide +kernel

theorem selectedBound8498 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8499 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,2097152,4194304,5005,34,8329,21040,278625,4214985,4215093,18633,505,4211100,4960,16617,2118257,1021]

theorem envBound8499 : H12AffineFastState.Bounded env8499 := by
  intro p hp
  have h : env8499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8498_8499 : H12AffineEnvironment.transform 15 24770 env8498 = env8499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 24770 env8498 == env8499) = true)

def env8500 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,64,4194304,5005,34,8329,21040,278625,4214985,4215093,18633,505,4211100,4960,16617,21041,1021]

theorem envBound8500 : H12AffineFastState.Bounded env8500 := by
  intro p hp
  have h : env8500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8499_8500 : H12AffineEnvironment.transform 20 64 env8499 = env8500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8499 == env8500) = true)

theorem identity8500 : scanCanonicalize (H12AffineFastState.compose env8500 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 282926) := by decide +kernel

theorem selectedBound8500 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8501 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,64,282926,5005,34,8329,21040,278625,262631,262171,18633,505,266418,4960,16617,21041,1021]

theorem envBound8501 : H12AffineFastState.Bounded env8501 := by
  intro p hp
  have h : env8501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8500_8501 : H12AffineEnvironment.transform 21 282926 env8500 = env8501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282926 env8500 == env8501) = true)

def env8502 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8692,8946,4605,262144,4960,8692,64,267038,5005,34,8329,4096,262737,262631,262171,2809,505,266418,4960,729,4097,1021]

theorem envBound8502 : H12AffineFastState.Bounded env8502 := by
  intro p hp
  have h : env8502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8501_8502 : H12AffineEnvironment.transform 13 560 env8501 = env8502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8501 == env8502) = true)

def env8503 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8692,8234,4605,262144,4536,8692,64,266694,4437,34,8329,4096,262281,262631,262171,2081,505,266418,4536,1,4097,293]

theorem envBound8503 : H12AffineFastState.Bounded env8503 := by
  intro p hp
  have h : env8503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8502_8503 : H12AffineEnvironment.transform 8 216 env8502 = env8503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8502 == env8503) = true)

theorem identity8503 : scanCanonicalize (H12AffineFastState.compose env8503 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8503 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8504 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,4096,8192,232,8352,8234,4265,262144,4332,8352,64,266386,4097,34,8329,4096,262281,262323,262171,2081,173,266418,4332,1,4097,113]

theorem envBound8504 : H12AffineFastState.Bounded env8504 := by
  intro p hp
  have h : env8504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8503_8504 : H12AffineEnvironment.transform 7 84 env8503 = env8504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8503 == env8504) = true)

theorem identity8504 : scanCanonicalize (H12AffineFastState.compose env8504 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8504 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8505 : List Nat := [2,4,8,16,32,64,128,84,216,84,2048,64,8192,232,8352,8234,233,262144,172,8352,64,262354,65,34,8329,64,262281,262323,262171,2081,173,262386,172,1,65,113]

theorem envBound8505 : H12AffineFastState.Bounded env8505 := by
  intro p hp
  have h : env8505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8504_8505 : H12AffineEnvironment.transform 11 64 env8504 = env8505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8504 == env8505) = true)

theorem identity8505 : scanCanonicalize (H12AffineFastState.compose env8505 (packedSelected [5,8,10,12,15,19] rootPS)) = affineNative (2^(10+1) ^^^ 130) := by decide +kernel

theorem selectedBound8505 : packedSelected [5,8,10,12,15,19] rootPS < 2^1333 := by decide +kernel

def env8506 : List Nat := [2,4,8,16,32,64,128,84,216,84,130,64,8192,232,8352,8234,233,262144,172,8352,64,262354,65,34,8329,64,262281,262323,262171,163,173,262386,172,1,65,113]

theorem envBound8506 : H12AffineFastState.Bounded env8506 := by
  intro p hp
  have h : env8506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8505_8506 : H12AffineEnvironment.transform 10 130 env8505 = env8506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 130 env8505 == env8506) = true)

theorem identity8506 : scanCanonicalize (H12AffineFastState.compose env8506 (packedSelected [1,2,3,4,5,8,9,10,11,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound8506 : packedSelected [1,2,3,4,5,8,9,10,11,13,18] rootPS < 2^1333 := by decide +kernel

def env8507 : List Nat := [2,4,8,16,32,64,128,84,216,84,130,64,98,232,194,72,233,262144,172,194,64,262354,65,34,235,64,262281,262323,262171,163,173,262386,172,1,65,113]

theorem envBound8507 : H12AffineFastState.Bounded env8507 := by
  intro p hp
  have h : env8507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8506_8507 : H12AffineEnvironment.transform 12 98 env8506 = env8507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env8506 == env8507) = true)

theorem identity8507 : scanCanonicalize (H12AffineFastState.compose env8507 (packedSelected [4,7,10,11,12,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound8507 : packedSelected [4,7,10,11,12,14,17] rootPS < 2^1333 := by decide +kernel

def env8508 : List Nat := [2,4,8,16,32,64,128,84,216,84,130,64,98,232,194,72,233,26,172,194,64,200,65,34,235,64,147,169,1,163,173,232,172,1,65,113]

theorem envBound8508 : H12AffineFastState.Bounded env8508 := by
  intro p hp
  have h : env8508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8507_8508 : H12AffineEnvironment.transform 17 26 env8507 = env8508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env8507 == env8508) = true)

theorem identity8508 : scanCanonicalize (H12AffineFastState.compose env8508 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 104) := by decide +kernel

theorem selectedBound8508 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8509 : List Nat := [2,4,8,16,32,64,104,84,48,84,106,64,98,0,42,72,1,26,68,42,64,32,65,34,3,64,123,65,1,75,69,0,68,1,65,113]

theorem envBound8509 : H12AffineFastState.Bounded env8509 := by
  intro p hp
  have h : env8509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8508_8509 : H12AffineEnvironment.transform 6 104 env8508 = env8509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 104 env8508 == env8509) = true)

theorem identity8509 : scanCanonicalize (H12AffineFastState.compose env8509 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound8509 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8510 : List Nat := [2,4,8,16,32,43,3,63,48,63,1,43,9,0,42,35,1,26,47,42,43,32,42,34,3,43,16,42,1,32,46,0,47,1,42,26]

theorem envBound8510 : H12AffineFastState.Bounded env8510 := by
  intro p hp
  have h : env8510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8509_8510 : H12AffineEnvironment.transform 5 43 env8509 = env8510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env8509 == env8510) = true)

theorem identity8510 : scanCanonicalize (H12AffineFastState.compose env8510 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8510 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env8511 : List Nat := [2,4,8,16,17,26,3,14,1,14,1,26,9,0,27,18,1,26,30,27,26,17,27,19,3,26,16,27,1,17,31,0,30,1,27,26]

theorem envBound8511 : H12AffineFastState.Bounded env8511 := by
  intro p hp
  have h : env8511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8510_8511 : H12AffineEnvironment.transform 4 17 env8510 = env8511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8510 == env8511) = true)

theorem identity8511 : scanCanonicalize (H12AffineFastState.compose env8511 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8511 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env8512 : List Nat := [2,4,8,10,11,0,3,14,1,14,1,0,9,0,1,8,1,0,4,1,0,11,1,9,3,0,10,1,1,11,5,0,4,1,1,0]

theorem envBound8512 : H12AffineFastState.Bounded env8512 := by
  intro p hp
  have h : env8512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8511_8512 : H12AffineEnvironment.transform 3 10 env8511 = env8512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8511 == env8512) = true)

theorem identity8512 : scanCanonicalize (H12AffineFastState.compose env8512 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8512 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8513 : List Nat := [2,4,3,1,0,0,3,5,1,5,1,0,2,0,1,3,1,0,4,1,0,0,1,2,3,0,1,1,1,0,5,0,4,1,1,0]

theorem envBound8513 : H12AffineFastState.Bounded env8513 := by
  intro p hp
  have h : env8513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8512_8513 : H12AffineEnvironment.transform 2 3 env8512 = env8513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8512 == env8513) = true)

theorem identity8513 : scanCanonicalize (H12AffineFastState.compose env8513 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8513 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8514 : List Nat := [2,1,3,1,0,0,3,0,1,0,1,0,2,0,1,3,1,0,1,1,0,0,1,2,3,0,1,1,1,0,0,0,1,1,1,0]

theorem envBound8514 : H12AffineFastState.Bounded env8514 := by
  intro p hp
  have h : env8514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8513_8514 : H12AffineEnvironment.transform 1 1 env8513 = env8514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8513 == env8514) = true)

def env8515 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8692,8235,4605,262144,4537,8692,64,266695,4436,34,8329,4096,262280,262631,262171,2080,505,266418,4537,0,4097,292]

theorem envBound8515 : H12AffineFastState.Bounded env8515 := by
  intro p hp
  have h : env8515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8502_8515 : H12AffineEnvironment.transform 8 217 env8502 = env8515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8502 == env8515) = true)

theorem identity8515 : scanCanonicalize (H12AffineFastState.compose env8515 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4122) := by decide +kernel

theorem selectedBound8515 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8516 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8692,8235,4605,4122,4537,8692,64,477,4436,34,8329,4096,4242,4605,4097,2080,505,168,4537,0,4097,292]

theorem envBound8516 : H12AffineFastState.Bounded env8516 := by
  intro p hp
  have h : env8516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8515_8516 : H12AffineEnvironment.transform 17 4122 env8515 = env8516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4122 env8515 == env8516) = true)

theorem identity8516 : scanCanonicalize (H12AffineFastState.compose env8516 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound8516 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8517 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,445,8192,233,8692,8235,64,423,4,8692,64,477,233,34,8329,445,303,64,444,2080,505,168,4,0,444,292]

theorem envBound8517 : H12AffineFastState.Bounded env8517 := by
  intro p hp
  have h : env8517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8516_8517 : H12AffineEnvironment.transform 11 445 env8516 = env8517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env8516 == env8517) = true)

theorem identity8517 : scanCanonicalize (H12AffineFastState.compose env8517 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 211) := by decide +kernel

theorem selectedBound8517 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8518 : List Nat := [2,4,8,16,32,64,128,256,217,256,211,445,8192,233,8692,8235,64,423,4,8692,64,477,233,34,8329,445,303,64,444,243,505,168,4,0,444,292]

theorem envBound8518 : H12AffineFastState.Bounded env8518 := by
  intro p hp
  have h : env8518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8517_8518 : H12AffineEnvironment.transform 10 211 env8517 = env8518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 211 env8517 == env8518) = true)

theorem identity8518 : scanCanonicalize (H12AffineFastState.compose env8518 (packedSelected [0,7,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound8518 : packedSelected [0,7,14,20] rootPS < 2^1333 := by decide +kernel

def env8519 : List Nat := [2,4,8,16,32,64,128,5,217,5,211,184,8192,233,8433,8235,64,162,4,8433,64,216,233,34,8329,184,42,64,185,243,252,168,4,0,185,33]

theorem envBound8519 : H12AffineFastState.Bounded env8519 := by
  intro p hp
  have h : env8519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8518_8519 : H12AffineEnvironment.transform 7 5 env8518 = env8519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env8518 == env8519) = true)

theorem identity8519 : scanCanonicalize (H12AffineFastState.compose env8519 (packedSelected [0,1,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 35) := by decide +kernel

theorem selectedBound8519 : packedSelected [0,1,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env8520 : List Nat := [2,4,8,16,32,64,128,5,217,5,211,184,35,233,210,8,64,162,4,210,64,216,233,34,170,184,42,64,185,243,252,168,4,0,185,33]

theorem envBound8520 : H12AffineFastState.Bounded env8520 := by
  intro p hp
  have h : env8520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8519_8520 : H12AffineEnvironment.transform 12 35 env8519 = env8520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 35 env8519 == env8520) = true)

theorem identity8520 : scanCanonicalize (H12AffineFastState.compose env8520 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound8520 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env8521 : List Nat := [2,4,8,16,32,64,51,5,106,5,96,11,35,90,97,8,64,17,4,97,64,107,90,34,25,11,42,64,10,64,79,27,4,0,10,33]

theorem envBound8521 : H12AffineFastState.Bounded env8521 := by
  intro p hp
  have h : env8521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8520_8521 : H12AffineEnvironment.transform 6 51 env8520 = env8521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env8520 == env8521) = true)

theorem identity8521 : scanCanonicalize (H12AffineFastState.compose env8521 (packedSelected [0,1,3,5,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8521 : packedSelected [0,1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env8522 : List Nat := [2,4,2,16,32,64,51,5,96,5,96,1,35,80,97,2,64,17,4,97,64,97,80,34,19,1,32,64,0,64,69,17,4,0,0,33]

theorem envBound8522 : H12AffineFastState.Bounded env8522 := by
  intro p hp
  have h : env8522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8521_8522 : H12AffineEnvironment.transform 2 2 env8521 = env8522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8521 == env8522) = true)

theorem identity8522 : scanCanonicalize (H12AffineFastState.compose env8522 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8522 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8523 : List Nat := [2,4,2,16,16,64,3,5,80,5,80,1,19,80,81,2,64,17,4,81,64,81,80,18,19,1,16,64,0,64,69,17,4,0,0,17]

theorem envBound8523 : H12AffineFastState.Bounded env8523 := by
  intro p hp
  have h : env8523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8522_8523 : H12AffineEnvironment.transform 4 16 env8522 = env8523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8522 == env8523) = true)

theorem identity8523 : scanCanonicalize (H12AffineFastState.compose env8523 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8523 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8524 : List Nat := [2,4,2,16,16,17,3,5,1,5,1,1,19,1,0,2,17,17,4,0,17,0,1,18,19,1,16,17,0,17,20,17,4,0,0,17]

theorem envBound8524 : H12AffineFastState.Bounded env8524 := by
  intro p hp
  have h : env8524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8523_8524 : H12AffineEnvironment.transform 5 17 env8523 = env8524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8523 == env8524) = true)

theorem identity8524 : scanCanonicalize (H12AffineFastState.compose env8524 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8525 : List Nat := [2,4,2,1,1,0,3,5,1,5,1,1,2,1,0,2,0,0,4,0,0,0,1,3,2,1,1,0,0,0,5,0,4,0,0,0]

theorem envBound8525 : H12AffineFastState.Bounded env8525 := by
  intro p hp
  have h : env8525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8524_8525 : H12AffineEnvironment.transform 3 1 env8524 = env8525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8524 == env8525) = true)

theorem identity8525 : scanCanonicalize (H12AffineFastState.compose env8525 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8525 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8526 : List Nat := [2,1,2,1,1,0,3,0,1,0,1,1,2,1,0,2,0,0,1,0,0,0,1,3,2,1,1,0,0,0,0,0,1,0,0,0]

theorem envBound8526 : H12AffineFastState.Bounded env8526 := by
  intro p hp
  have h : env8526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8525_8526 : H12AffineEnvironment.transform 1 1 env8525 = env8526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8525 == env8526) = true)

def env8527 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8692,8947,4605,262144,4960,8692,64,267039,5005,34,8329,4097,262736,262631,262171,2808,505,266418,4960,728,4096,1021]

theorem envBound8527 : H12AffineFastState.Bounded env8527 := by
  intro p hp
  have h : env8527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8501_8527 : H12AffineEnvironment.transform 13 561 env8501 = env8527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8501 == env8527) = true)

def env8528 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8692,8235,4605,262144,4536,8692,64,266695,4437,34,8329,4097,262280,262631,262171,2080,505,266418,4536,0,4096,293]

theorem envBound8528 : H12AffineFastState.Bounded env8528 := by
  intro p hp
  have h : env8528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8527_8528 : H12AffineEnvironment.transform 8 216 env8527 = env8528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8527 == env8528) = true)

theorem identity8528 : scanCanonicalize (H12AffineFastState.compose env8528 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 4122) := by decide +kernel

theorem selectedBound8528 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8529 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8692,8235,4605,4122,4536,8692,64,477,4437,34,8329,4097,4242,4605,4097,2080,505,168,4536,0,4096,293]

theorem envBound8529 : H12AffineFastState.Bounded env8529 := by
  intro p hp
  have h : env8529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8528_8529 : H12AffineEnvironment.transform 17 4122 env8528 = env8529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 4122 env8528 == env8529) = true)

theorem identity8529 : scanCanonicalize (H12AffineFastState.compose env8529 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 232) := by decide +kernel

theorem selectedBound8529 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8530 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,232,8192,233,8692,8235,277,242,336,8692,64,477,445,34,8329,233,122,277,233,2080,505,168,336,0,232,293]

theorem envBound8530 : H12AffineFastState.Bounded env8530 := by
  intro p hp
  have h : env8530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8529_8530 : H12AffineEnvironment.transform 11 232 env8529 = env8530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 232 env8529 == env8530) = true)

theorem identity8530 : scanCanonicalize (H12AffineFastState.compose env8530 (packedSelected [0,1,3,7,12,15,20] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound8530 : packedSelected [0,1,3,7,12,15,20] rootPS < 2^1333 := by decide +kernel

def env8531 : List Nat := [2,4,8,16,32,64,128,256,216,256,303,232,8192,233,8692,8235,277,242,336,8692,64,477,445,34,8329,233,122,277,233,271,505,168,336,0,232,293]

theorem envBound8531 : H12AffineFastState.Bounded env8531 := by
  intro p hp
  have h : env8531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8530_8531 : H12AffineEnvironment.transform 10 303 env8530 = env8531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env8530 == env8531) = true)

theorem identity8531 : scanCanonicalize (H12AffineFastState.compose env8531 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8531 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env8532 : List Nat := [2,4,8,16,32,64,120,256,32,256,303,16,8192,17,8460,8235,277,10,336,8460,64,293,325,34,8305,17,122,277,17,271,257,80,336,0,16,293]

theorem envBound8532 : H12AffineFastState.Bounded env8532 := by
  intro p hp
  have h : env8532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8531_8532 : H12AffineEnvironment.transform 6 120 env8531 = env8532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8531 == env8532) = true)

theorem identity8532 : scanCanonicalize (H12AffineFastState.compose env8532 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 78) := by decide +kernel

theorem selectedBound8532 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env8533 : List Nat := [2,4,8,16,32,64,120,78,32,78,97,16,8192,17,8258,8235,91,10,30,8258,64,107,11,34,8305,17,122,91,17,65,79,80,30,0,16,107]

theorem envBound8533 : H12AffineFastState.Bounded env8533 := by
  intro p hp
  have h : env8533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8532_8533 : H12AffineEnvironment.transform 7 78 env8532 = env8533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 78 env8532 == env8533) = true)

theorem identity8533 : scanCanonicalize (H12AffineFastState.compose env8533 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 105) := by decide +kernel

theorem selectedBound8533 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env8534 : List Nat := [2,4,8,16,32,64,120,78,32,78,97,16,105,17,43,66,91,10,30,43,64,107,11,34,24,17,122,91,17,65,79,80,30,0,16,107]

theorem envBound8534 : H12AffineFastState.Bounded env8534 := by
  intro p hp
  have h : env8534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8533_8534 : H12AffineEnvironment.transform 12 105 env8533 = env8534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 105 env8533 == env8534) = true)

theorem identity8534 : scanCanonicalize (H12AffineFastState.compose env8534 (packedSelected [1,2,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8534 : packedSelected [1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env8535 : List Nat := [2,4,8,16,16,64,72,78,16,78,81,16,89,17,27,66,91,10,30,27,64,91,11,18,24,17,74,91,17,65,79,80,30,0,16,91]

theorem envBound8535 : H12AffineFastState.Bounded env8535 := by
  intro p hp
  have h : env8535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8534_8535 : H12AffineEnvironment.transform 4 16 env8534 = env8535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8534 == env8535) = true)

theorem identity8535 : scanCanonicalize (H12AffineFastState.compose env8535 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8535 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8536 : List Nat := [2,4,8,10,10,64,72,78,10,78,75,10,67,11,1,66,65,10,4,1,64,65,11,8,2,11,74,65,11,65,79,74,4,0,10,65]

theorem envBound8536 : H12AffineFastState.Bounded env8536 := by
  intro p hp
  have h : env8536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8535_8536 : H12AffineEnvironment.transform 3 10 env8535 = env8536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8535 == env8536) = true)

theorem identity8536 : scanCanonicalize (H12AffineFastState.compose env8536 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8536 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8537 : List Nat := [2,4,8,10,10,1,9,15,10,15,10,10,2,11,1,3,0,10,4,1,1,0,11,8,2,11,11,0,11,0,14,11,4,0,10,0]

theorem envBound8537 : H12AffineFastState.Bounded env8537 := by
  intro p hp
  have h : env8537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8536_8537 : H12AffineEnvironment.transform 5 1 env8536 = env8537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8536 == env8537) = true)

theorem identity8537 : scanCanonicalize (H12AffineFastState.compose env8537 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8537 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8538 : List Nat := [2,4,2,0,0,1,3,5,0,5,0,0,2,1,1,3,0,0,4,1,1,0,1,2,2,1,1,0,1,0,4,1,4,0,0,0]

theorem envBound8538 : H12AffineFastState.Bounded env8538 := by
  intro p hp
  have h : env8538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8537_8538 : H12AffineEnvironment.transform 2 2 env8537 = env8538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8537 == env8538) = true)

def leafEnv8538 : List Nat := [2,4,2,0,0,1,3,5,0,5,0,0,2,1,1,3,0,0,4,1,1,0,1,2,5,2,1,1,1,0,1,0,4,1,4,0,5,2,0,0,1,1,0]

def active8538 : List Nat := [0,1]

def tree8538 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8538 : H12WitnessSearch.Good tree8538 := H12GlobalWitnessIndex.good

theorem leafIdentity8538 : H12AffineFastState.composeSystem env8538 rootObs = leafEnv8538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8538 rootObs == leafEnv8538) = true)

theorem terminalChecked8538 : H12PackedTerminal.terminalCheckFast leafEnv8538 active8538 tree8538 = true := by decide +kernel

def env8539 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8692,8234,4605,262144,4537,8692,64,266694,4436,34,8329,4097,262281,262631,262171,2081,505,266418,4537,1,4096,292]

theorem envBound8539 : H12AffineFastState.Bounded env8539 := by
  intro p hp
  have h : env8539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8527_8539 : H12AffineEnvironment.transform 8 217 env8527 = env8539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8527 == env8539) = true)

theorem identity8539 : scanCanonicalize (H12AffineFastState.compose env8539 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound8539 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8540 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,4096,8192,232,8352,8234,4265,262144,4333,8352,64,266386,4096,34,8329,4097,262281,262323,262171,2081,173,266418,4333,1,4096,112]

theorem envBound8540 : H12AffineFastState.Bounded env8540 := by
  intro p hp
  have h : env8540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8539_8540 : H12AffineEnvironment.transform 7 84 env8539 = env8540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env8539 == env8540) = true)

theorem identity8540 : scanCanonicalize (H12AffineFastState.compose env8540 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound8540 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8541 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,4096,8192,232,8352,8234,4265,90,4333,8352,64,4296,4096,34,8329,4097,211,233,65,2081,173,4328,4333,1,4096,112]

theorem envBound8541 : H12AffineFastState.Bounded env8541 := by
  intro p hp
  have h : env8541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8540_8541 : H12AffineEnvironment.transform 17 90 env8540 = env8541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env8540 == env8541) = true)

theorem identity8541 : scanCanonicalize (H12AffineFastState.compose env8541 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8541 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8542 : List Nat := [2,4,8,16,32,64,128,84,217,84,2048,2155,8192,232,8352,8234,2242,90,2182,8352,64,2211,2155,34,8329,2154,211,233,65,2081,173,2179,2182,1,2155,112]

theorem envBound8542 : H12AffineFastState.Bounded env8542 := by
  intro p hp
  have h : env8542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8541_8542 : H12AffineEnvironment.transform 11 2155 env8541 = env8542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8541 == env8542) = true)

theorem identity8542 : scanCanonicalize (H12AffineFastState.compose env8542 (packedSelected [1,3,5,8,10,14,18,19,23] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8542 : packedSelected [1,3,5,8,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env8543 : List Nat := [2,4,8,16,32,64,41,84,112,84,2048,2155,8192,65,8201,8234,2155,90,2095,8201,64,2058,2155,34,8224,2154,122,64,65,2081,4,2090,2095,1,2155,112]

theorem envBound8543 : H12AffineFastState.Bounded env8543 := by
  intro p hp
  have h : env8543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8542_8543 : H12AffineEnvironment.transform 6 41 env8542 = env8543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8542 == env8543) = true)

theorem identity8543 : scanCanonicalize (H12AffineFastState.compose env8543 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8543 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8544 : List Nat := [2,4,8,16,32,64,41,84,112,84,42,65,8192,65,8201,8234,65,90,5,8201,64,32,65,34,8224,64,122,64,65,11,4,0,5,1,65,112]

theorem envBound8544 : H12AffineFastState.Bounded env8544 := by
  intro p hp
  have h : env8544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8543_8544 : H12AffineEnvironment.transform 10 42 env8543 = env8544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8543 == env8544) = true)

theorem identity8544 : scanCanonicalize (H12AffineFastState.compose env8544 (packedSelected [0,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8544 : packedSelected [0,2,4,5] rootPS < 2^1333 := by decide +kernel

def env8545 : List Nat := [2,4,8,16,17,64,24,84,65,84,27,65,8192,65,8201,8219,65,90,5,8201,64,17,65,19,8209,64,75,64,65,11,4,0,5,1,65,65]

theorem envBound8545 : H12AffineFastState.Bounded env8545 := by
  intro p hp
  have h : env8545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8544_8545 : H12AffineEnvironment.transform 4 17 env8544 = env8545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8544 == env8545) = true)

theorem identity8545 : scanCanonicalize (H12AffineFastState.compose env8545 (packedSelected [1] rootPS)) = affineNative (2^(12+1) ^^^ 24) := by decide +kernel

theorem selectedBound8545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8546 : List Nat := [2,4,8,16,17,64,24,84,65,84,27,65,24,65,17,3,65,90,5,17,64,17,65,19,9,64,75,64,65,11,4,0,5,1,65,65]

theorem envBound8546 : H12AffineFastState.Bounded env8546 := by
  intro p hp
  have h : env8546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8545_8546 : H12AffineEnvironment.transform 12 24 env8545 = env8546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 24 env8545 == env8546) = true)

theorem identity8546 : scanCanonicalize (H12AffineFastState.compose env8546 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound8546 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8547 : List Nat := [2,4,8,16,17,27,24,15,26,15,27,26,24,26,17,3,26,1,5,17,27,17,26,19,9,27,16,27,26,11,4,0,5,1,26,26]

theorem envBound8547 : H12AffineFastState.Bounded env8547 := by
  intro p hp
  have h : env8547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8546_8547 : H12AffineEnvironment.transform 5 27 env8546 = env8547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env8546 == env8547) = true)

theorem identity8547 : scanCanonicalize (H12AffineFastState.compose env8547 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8547 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8548 : List Nat := [2,4,3,16,17,16,19,4,17,4,16,17,19,17,17,3,17,1,5,17,16,17,17,19,2,16,16,16,17,0,4,0,5,1,17,17]

theorem envBound8548 : H12AffineFastState.Bounded env8548 := by
  intro p hp
  have h : env8548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8547_8548 : H12AffineEnvironment.transform 2 3 env8547 = env8548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8547 == env8548) = true)

theorem identity8548 : scanCanonicalize (H12AffineFastState.compose env8548 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8548 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8549 : List Nat := [2,4,3,0,1,0,3,4,1,4,0,1,3,1,1,3,1,1,5,1,0,1,1,3,2,0,0,0,1,0,4,0,5,1,1,1]

theorem envBound8549 : H12AffineFastState.Bounded env8549 := by
  intro p hp
  have h : env8549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8548_8549 : H12AffineEnvironment.transform 3 0 env8548 = env8549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8548 == env8549) = true)

def leafEnv8549 : List Nat := [2,4,3,0,1,0,3,4,1,4,0,1,3,1,1,3,1,1,5,1,0,1,1,3,5,2,1,0,0,0,1,0,4,0,5,1,5,3,1,1,1,1,0]

def active8549 : List Nat := [0,1]

def tree8549 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood8549 : H12WitnessSearch.Good tree8549 := H12GlobalWitnessIndex.good

theorem leafIdentity8549 : H12AffineFastState.composeSystem env8549 rootObs = leafEnv8549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env8549 rootObs == leafEnv8549) = true)

theorem terminalChecked8549 : H12PackedTerminal.terminalCheckFast leafEnv8549 active8549 tree8549 = true := by decide +kernel

def env8550 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,65,4194304,5005,34,8329,21040,278625,4214985,4215093,18633,505,4211100,4960,16617,21040,1021]

theorem envBound8550 : H12AffineFastState.Bounded env8550 := by
  intro p hp
  have h : env8550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8499_8550 : H12AffineEnvironment.transform 20 65 env8499 = env8550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8499 == env8550) = true)

theorem identity8550 : scanCanonicalize (H12AffineFastState.compose env8550 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 279374) := by decide +kernel

theorem selectedBound8550 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8551 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,24770,4605,262144,4960,8692,65,279374,5005,34,8329,21040,278625,267143,266875,18633,505,262866,4960,16617,21040,1021]

theorem envBound8551 : H12AffineFastState.Bounded env8551 := by
  intro p hp
  have h : env8551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8550_8551 : H12AffineEnvironment.transform 21 279374 env8550 = env8551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 279374 env8550 == env8551) = true)

def env8552 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,560,8692,8946,4605,262144,4960,8692,65,262526,5005,34,8329,4096,262737,267143,266875,2809,505,262866,4960,729,4096,1021]

theorem envBound8552 : H12AffineFastState.Bounded env8552 := by
  intro p hp
  have h : env8552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8551_8552 : H12AffineEnvironment.transform 13 560 env8551 = env8552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8551 == env8552) = true)

def env8553 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,232,8692,8234,4605,262144,4536,8692,65,262526,4437,34,8329,4096,262281,266591,266403,2081,505,262154,4536,1,4096,293]

theorem envBound8553 : H12AffineFastState.Bounded env8553 := by
  intro p hp
  have h : env8553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8552_8553 : H12AffineEnvironment.transform 8 216 env8552 = env8553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8552 == env8553) = true)

theorem identity8553 : scanCanonicalize (H12AffineFastState.compose env8553 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8553 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8554 : List Nat := [2,4,8,16,32,64,128,85,216,85,2048,4096,8192,232,8353,8234,4264,262144,4333,8353,65,262187,4096,34,8329,4096,262281,266250,266403,2081,172,262154,4333,1,4096,112]

theorem envBound8554 : H12AffineFastState.Bounded env8554 := by
  intro p hp
  have h : env8554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8553_8554 : H12AffineEnvironment.transform 7 85 env8553 = env8554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8553 == env8554) = true)

theorem identity8554 : scanCanonicalize (H12AffineFastState.compose env8554 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90) := by decide +kernel

theorem selectedBound8554 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8555 : List Nat := [2,4,8,16,32,64,128,85,216,85,2048,4096,8192,232,8353,8234,4264,90,4333,8353,65,113,4096,34,8329,4096,211,4176,4345,2081,172,80,4333,1,4096,112]

theorem envBound8555 : H12AffineFastState.Bounded env8555 := by
  intro p hp
  have h : env8555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8554_8555 : H12AffineEnvironment.transform 17 90 env8554 = env8555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90 env8554 == env8555) = true)

theorem identity8555 : scanCanonicalize (H12AffineFastState.compose env8555 (packedSelected [1,3,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound8555 : packedSelected [1,3,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8556 : List Nat := [2,4,8,16,32,64,121,85,33,85,2048,4096,8192,17,8280,8234,4177,90,4116,8280,65,113,4096,34,8304,4096,42,4176,4096,2081,85,80,4116,1,4096,112]

theorem envBound8556 : H12AffineFastState.Bounded env8556 := by
  intro p hp
  have h : env8556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8555_8556 : H12AffineEnvironment.transform 6 121 env8555 = env8556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env8555 == env8556) = true)

theorem identity8556 : scanCanonicalize (H12AffineFastState.compose env8556 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 2107) := by decide +kernel

theorem selectedBound8556 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env8557 : List Nat := [2,4,8,16,32,64,121,85,33,85,2048,2107,8192,17,8280,8234,2154,90,2095,8280,65,113,2107,34,8304,2107,42,2155,2107,2081,85,80,2095,1,2107,112]

theorem envBound8557 : H12AffineFastState.Bounded env8557 := by
  intro p hp
  have h : env8557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8556_8557 : H12AffineEnvironment.transform 11 2107 env8556 = env8557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2107 env8556 == env8557) = true)

theorem identity8557 : scanCanonicalize (H12AffineFastState.compose env8557 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound8557 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8558 : List Nat := [2,4,8,16,32,48,9,37,33,37,2048,2107,8192,17,8232,8234,2074,42,2095,8232,49,1,2107,34,8192,2107,42,2075,2107,2081,37,32,2095,1,2107,0]

theorem envBound8558 : H12AffineFastState.Bounded env8558 := by
  intro p hp
  have h : env8558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8557_8558 : H12AffineEnvironment.transform 5 48 env8557 = env8558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env8557 == env8558) = true)

theorem identity8558 : scanCanonicalize (H12AffineFastState.compose env8558 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound8558 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8559 : List Nat := [2,4,8,16,0,16,9,5,1,5,2048,2075,8192,17,8200,8202,2074,10,2063,8200,17,1,2075,2,8192,2075,10,2075,2075,2049,5,0,2063,1,2075,0]

theorem envBound8559 : H12AffineFastState.Bounded env8559 := by
  intro p hp
  have h : env8559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8558_8559 : H12AffineEnvironment.transform 4 0 env8558 = env8559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env8558 == env8559) = true)

theorem identity8559 : scanCanonicalize (H12AffineFastState.compose env8559 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8560 : List Nat := [2,4,2,16,0,16,3,5,1,5,2048,2065,8192,17,8194,8192,2064,0,2053,8194,17,1,2065,2,8192,2065,0,2065,2065,2049,5,0,2053,1,2065,0]

theorem envBound8560 : H12AffineFastState.Bounded env8560 := by
  intro p hp
  have h : env8560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8559_8560 : H12AffineEnvironment.transform 2 2 env8559 = env8560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8559 == env8560) = true)

theorem identity8560 : scanCanonicalize (H12AffineFastState.compose env8560 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound8560 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8561 : List Nat := [2,4,2,16,0,16,3,5,1,5,2048,2065,2,17,0,2,2064,0,2053,0,17,1,2065,2,2,2065,0,2065,2065,2049,5,0,2053,1,2065,0]

theorem envBound8561 : H12AffineFastState.Bounded env8561 := by
  intro p hp
  have h : env8561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8560_8561 : H12AffineEnvironment.transform 12 2 env8560 = env8561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env8560 == env8561) = true)

theorem identity8561 : scanCanonicalize (H12AffineFastState.compose env8561 (packedSelected [1,4] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound8561 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env8562 : List Nat := [2,4,2,16,0,16,3,5,1,5,20,5,2,17,0,2,4,0,17,0,17,1,5,2,2,5,0,5,5,21,5,0,17,1,5,0]

theorem envBound8562 : H12AffineFastState.Bounded env8562 := by
  intro p hp
  have h : env8562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8561_8562 : H12AffineEnvironment.transform 10 20 env8561 = env8562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env8561 == env8562) = true)

theorem identity8562 : scanCanonicalize (H12AffineFastState.compose env8562 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8562 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env8563 : List Nat := [2,4,2,0,0,0,3,5,1,5,4,5,2,1,0,2,4,0,1,0,1,1,5,2,2,5,0,5,5,5,5,0,1,1,5,0]

theorem envBound8563 : H12AffineFastState.Bounded env8563 := by
  intro p hp
  have h : env8563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8562_8563 : H12AffineEnvironment.transform 3 0 env8562 = env8563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8562 == env8563) = true)

theorem identity8563 : scanCanonicalize (H12AffineFastState.compose env8563 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8563 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env8564 : List Nat := [2,0,2,0,0,0,3,1,1,1,0,1,2,1,0,2,0,0,1,0,1,1,1,2,2,1,0,1,1,1,1,0,1,1,1,0]

theorem envBound8564 : H12AffineFastState.Bounded env8564 := by
  intro p hp
  have h : env8564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8563_8564 : H12AffineEnvironment.transform 1 0 env8563 = env8564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8563 == env8564) = true)

def env8565 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8692,8235,4605,262144,4537,8692,65,262526,4436,34,8329,4096,262280,266590,266402,2080,505,262155,4537,0,4096,292]

theorem envBound8565 : H12AffineFastState.Bounded env8565 := by
  intro p hp
  have h : env8565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8552_8565 : H12AffineEnvironment.transform 8 217 env8552 = env8565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8552 == env8565) = true)

theorem identity8565 : scanCanonicalize (H12AffineFastState.compose env8565 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 162) := by decide +kernel

theorem selectedBound8565 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8566 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,233,8692,8235,4605,162,4537,8692,65,476,4436,34,8329,4096,42,4604,4096,2080,505,169,4537,0,4096,292]

theorem envBound8566 : H12AffineFastState.Bounded env8566 := by
  intro p hp
  have h : env8566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8565_8566 : H12AffineEnvironment.transform 17 162 env8565 = env8566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 162 env8565 == env8566) = true)

theorem identity8566 : scanCanonicalize (H12AffineFastState.compose env8566 (packedSelected [7,20,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8566 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8567 : List Nat := [2,4,8,16,32,17,128,256,136,256,2048,4096,8192,184,8613,8235,4524,162,4537,8613,16,397,4357,34,8329,4096,42,4525,4096,2080,424,169,4537,0,4096,292]

theorem envBound8567 : H12AffineFastState.Bounded env8567 := by
  intro p hp
  have h : env8567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8566_8567 : H12AffineEnvironment.transform 5 17 env8566 = env8567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8566 == env8567) = true)

theorem identity8567 : scanCanonicalize (H12AffineFastState.compose env8567 (packedSelected [13,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 2106) := by decide +kernel

theorem selectedBound8567 : packedSelected [13,14,17] rootPS < 2^1333 := by decide +kernel

def env8568 : List Nat := [2,4,8,16,32,17,128,256,136,256,2048,2106,8192,184,8613,8235,2454,162,2435,8613,16,397,2367,34,8329,2106,42,2455,2106,2080,424,169,2435,0,2106,292]

theorem envBound8568 : H12AffineFastState.Bounded env8568 := by
  intro p hp
  have h : env8568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8567_8568 : H12AffineEnvironment.transform 11 2106 env8567 = env8568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2106 env8567 == env8568) = true)

theorem identity8568 : scanCanonicalize (H12AffineFastState.compose env8568 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8568 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8569 : List Nat := [2,4,8,16,32,17,128,4,136,4,2048,2106,8192,184,8353,8235,2194,162,2183,8353,16,137,2107,34,8329,2106,42,2195,2106,2080,172,169,2183,0,2106,32]

theorem envBound8569 : H12AffineFastState.Bounded env8569 := by
  intro p hp
  have h : env8569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8568_8569 : H12AffineEnvironment.transform 7 4 env8568 = env8569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8568 == env8569) = true)

theorem identity8569 : scanCanonicalize (H12AffineFastState.compose env8569 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound8569 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env8570 : List Nat := [2,4,8,16,32,17,51,4,59,4,2048,2106,8192,11,8210,8235,2081,17,2100,8210,16,58,2107,34,8250,2106,42,2080,2106,2080,31,26,2100,0,2106,32]

theorem envBound8570 : H12AffineFastState.Bounded env8570 := by
  intro p hp
  have h : env8570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8569_8570 : H12AffineEnvironment.transform 6 51 env8569 = env8570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env8569 == env8570) = true)

theorem identity8570 : scanCanonicalize (H12AffineFastState.compose env8570 (packedSelected [0,1,2,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound8570 : packedSelected [0,1,2,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env8571 : List Nat := [2,4,8,16,32,17,51,4,59,4,2048,2106,25,11,11,50,2081,17,2100,11,16,58,2107,34,35,2106,42,2080,2106,2080,31,26,2100,0,2106,32]

theorem envBound8571 : H12AffineFastState.Bounded env8571 := by
  intro p hp
  have h : env8571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8570_8571 : H12AffineEnvironment.transform 12 25 env8570 = env8571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env8570 == env8571) = true)

theorem identity8571 : scanCanonicalize (H12AffineFastState.compose env8571 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound8571 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8572 : List Nat := [2,4,8,16,17,17,2,4,10,4,2048,2059,25,11,11,3,2064,17,2053,11,16,11,2058,19,18,2059,27,2065,2059,2065,31,26,2053,0,2059,17]

theorem envBound8572 : H12AffineFastState.Bounded env8572 := by
  intro p hp
  have h : env8572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8571_8572 : H12AffineEnvironment.transform 4 17 env8571 = env8572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env8571 == env8572) = true)

theorem identity8572 : scanCanonicalize (H12AffineFastState.compose env8572 (packedSelected [2,4] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8572 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env8573 : List Nat := [2,4,8,10,11,11,2,4,10,4,2048,2059,3,11,11,3,2058,11,2053,11,10,11,2058,9,8,2059,1,2059,2059,2059,5,0,2053,0,2059,11]

theorem envBound8573 : H12AffineFastState.Bounded env8573 := by
  intro p hp
  have h : env8573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8572_8573 : H12AffineEnvironment.transform 3 10 env8572 = env8573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8572 == env8573) = true)

theorem identity8573 : scanCanonicalize (H12AffineFastState.compose env8573 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8573 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8574 : List Nat := [2,0,8,10,11,11,2,0,10,0,2048,2059,3,11,11,3,2058,11,2049,11,10,11,2058,9,8,2059,1,2059,2059,2059,1,0,2049,0,2059,11]

theorem envBound8574 : H12AffineFastState.Bounded env8574 := by
  intro p hp
  have h : env8574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8573_8574 : H12AffineEnvironment.transform 1 0 env8573 = env8574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8573 == env8574) = true)

theorem identity8574 : scanCanonicalize (H12AffineFastState.compose env8574 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound8574 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8575 : List Nat := [2,0,8,10,11,11,2,0,10,0,10,1,3,11,11,3,0,11,11,11,10,11,0,9,8,1,1,1,1,1,1,0,11,0,1,11]

theorem envBound8575 : H12AffineFastState.Bounded env8575 := by
  intro p hp
  have h : env8575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8574_8575 : H12AffineEnvironment.transform 10 10 env8574 = env8575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env8574 == env8575) = true)

theorem identity8575 : scanCanonicalize (H12AffineFastState.compose env8575 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8575 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8576 : List Nat := [2,0,2,0,1,1,2,0,0,0,0,1,3,1,1,3,0,1,1,1,0,1,0,3,2,1,1,1,1,1,1,0,1,0,1,1]

theorem envBound8576 : H12AffineFastState.Bounded env8576 := by
  intro p hp
  have h : env8576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8575_8576 : H12AffineEnvironment.transform 2 2 env8575 = env8576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8575 == env8576) = true)

def env8577 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,561,8692,8947,4605,262144,4960,8692,65,262527,5005,34,8329,4097,262736,267143,266875,2808,505,262866,4960,728,4097,1021]

theorem envBound8577 : H12AffineFastState.Bounded env8577 := by
  intro p hp
  have h : env8577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8551_8577 : H12AffineEnvironment.transform 13 561 env8551 = env8577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8551 == env8577) = true)

def env8578 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8692,8235,4605,262144,4536,8692,65,262527,4437,34,8329,4097,262280,266591,266403,2080,505,262154,4536,0,4097,293]

theorem envBound8578 : H12AffineFastState.Bounded env8578 := by
  intro p hp
  have h : env8578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8577_8578 : H12AffineEnvironment.transform 8 216 env8577 = env8578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env8577 == env8578) = true)

theorem identity8578 : scanCanonicalize (H12AffineFastState.compose env8578 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 163) := by decide +kernel

theorem selectedBound8578 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8579 : List Nat := [2,4,8,16,32,64,128,256,216,256,2048,4096,8192,233,8692,8235,4605,163,4536,8692,65,476,4437,34,8329,4097,43,4604,4096,2080,505,169,4536,0,4097,293]

theorem envBound8579 : H12AffineFastState.Bounded env8579 := by
  intro p hp
  have h : env8579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8578_8579 : H12AffineEnvironment.transform 17 163 env8578 = env8579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 163 env8578 == env8579) = true)

theorem identity8579 : scanCanonicalize (H12AffineFastState.compose env8579 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound8579 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8580 : List Nat := [2,4,8,16,32,64,128,4,216,4,2048,4096,8192,233,8432,8235,4345,163,4284,8432,65,216,4177,34,8329,4097,43,4344,4096,2080,253,169,4284,0,4097,33]

theorem envBound8580 : H12AffineFastState.Bounded env8580 := by
  intro p hp
  have h : env8580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8579_8580 : H12AffineEnvironment.transform 7 4 env8579 = env8580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env8579 == env8580) = true)

theorem identity8580 : scanCanonicalize (H12AffineFastState.compose env8580 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2242) := by decide +kernel

theorem selectedBound8580 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8581 : List Nat := [2,4,8,16,32,64,128,4,216,4,2048,2242,8192,233,8432,8235,2107,163,2174,8432,65,216,2195,34,8329,2243,43,2106,2242,2080,253,169,2174,0,2243,33]

theorem envBound8581 : H12AffineFastState.Bounded env8581 := by
  intro p hp
  have h : env8581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8580_8581 : H12AffineEnvironment.transform 11 2242 env8580 = env8581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2242 env8580 == env8581) = true)

theorem identity8581 : scanCanonicalize (H12AffineFastState.compose env8581 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound8581 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8582 : List Nat := [2,4,8,16,32,64,41,4,113,4,2048,2155,8192,64,8281,8235,2107,10,2174,8281,65,113,2106,34,8224,2154,43,2106,2155,2080,84,0,2174,0,2154,33]

theorem envBound8582 : H12AffineFastState.Bounded env8582 := by
  intro p hp
  have h : env8582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8581_8582 : H12AffineEnvironment.transform 6 41 env8581 = env8582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env8581 == env8582) = true)

theorem identity8582 : scanCanonicalize (H12AffineFastState.compose env8582 (packedSelected [0,2,4,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound8582 : packedSelected [0,2,4,10] rootPS < 2^1333 := by decide +kernel

def env8583 : List Nat := [2,4,8,16,32,16,41,4,33,4,2048,2107,8192,16,8201,8235,2107,10,2094,8201,17,33,2106,34,8224,2106,43,2106,2107,2080,4,0,2094,0,2106,33]

theorem envBound8583 : H12AffineFastState.Bounded env8583 := by
  intro p hp
  have h : env8583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8582_8583 : H12AffineEnvironment.transform 5 16 env8582 = env8583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env8582 == env8583) = true)

theorem identity8583 : scanCanonicalize (H12AffineFastState.compose env8583 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound8583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8584 : List Nat := [2,4,8,16,32,16,41,4,33,4,2048,2107,2089,16,2080,2050,2107,10,2094,2080,17,33,2106,34,2057,2106,43,2106,2107,2080,4,0,2094,0,2106,33]

theorem envBound8584 : H12AffineFastState.Bounded env8584 := by
  intro p hp
  have h : env8584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8583_8584 : H12AffineEnvironment.transform 12 2089 env8583 = env8584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env8583 == env8584) = true)

theorem identity8584 : scanCanonicalize (H12AffineFastState.compose env8584 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound8584 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8585 : List Nat := [2,4,8,16,32,16,41,4,33,4,1,58,40,16,33,3,58,10,47,33,17,33,59,34,8,59,43,59,58,33,4,0,47,0,59,33]

theorem envBound8585 : H12AffineFastState.Bounded env8585 := by
  intro p hp
  have h : env8585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8584_8585 : H12AffineEnvironment.transform 10 1 env8584 = env8585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env8584 == env8585) = true)

def env8586 : List Nat := [2,4,8,16,32,64,128,256,217,256,2048,4096,8192,232,8692,8234,4605,262144,4537,8692,65,262527,4436,34,8329,4097,262281,266590,266402,2081,505,262155,4537,1,4097,292]

theorem envBound8586 : H12AffineFastState.Bounded env8586 := by
  intro p hp
  have h : env8586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8577_8586 : H12AffineEnvironment.transform 8 217 env8577 = env8586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 217 env8577 == env8586) = true)

theorem identity8586 : scanCanonicalize (H12AffineFastState.compose env8586 (packedSelected [0,7,13,20,21] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound8586 : packedSelected [0,7,13,20,21] rootPS < 2^1333 := by decide +kernel

def env8587 : List Nat := [2,4,8,16,32,64,128,85,217,85,2048,4096,8192,232,8353,8234,4264,262144,4332,8353,65,262186,4097,34,8329,4097,262281,266251,266402,2081,172,262155,4332,1,4097,113]

theorem envBound8587 : H12AffineFastState.Bounded env8587 := by
  intro p hp
  have h : env8587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8586_8587 : H12AffineEnvironment.transform 7 85 env8586 = env8587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env8586 == env8587) = true)

theorem identity8587 : scanCanonicalize (H12AffineFastState.compose env8587 (packedSelected [0,1,3,5,8,10,19,27] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8587 : packedSelected [0,1,3,5,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env8588 : List Nat := [2,4,8,16,32,64,120,85,33,85,2048,4096,8192,16,8281,8234,4176,262144,4116,8281,65,262186,4097,34,8305,4097,262257,266251,266330,2081,84,262155,4116,1,4097,113]

theorem envBound8588 : H12AffineFastState.Bounded env8588 := by
  intro p hp
  have h : env8588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8587_8588 : H12AffineEnvironment.transform 6 120 env8587 = env8588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8587 == env8588) = true)

theorem identity8588 : scanCanonicalize (H12AffineFastState.compose env8588 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 6193) := by decide +kernel

theorem selectedBound8588 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env8589 : List Nat := [2,4,8,16,32,64,120,85,33,85,2048,4096,8192,16,8281,8234,4176,6193,4116,8281,65,6171,4097,34,8305,4097,6208,2106,2155,2081,84,6202,4116,1,4097,113]

theorem envBound8589 : H12AffineFastState.Bounded env8589 := by
  intro p hp
  have h : env8589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8588_8589 : H12AffineEnvironment.transform 17 6193 env8588 = env8589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6193 env8588 == env8589) = true)

theorem identity8589 : scanCanonicalize (H12AffineFastState.compose env8589 (packedSelected [2,3,4,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 26) := by decide +kernel

theorem selectedBound8589 : packedSelected [2,3,4,7,8,14] rootPS < 2^1333 := by decide +kernel

def env8590 : List Nat := [2,4,8,16,32,64,120,85,33,85,2048,26,8192,16,8281,8234,74,2091,14,8281,65,2049,27,34,8305,27,2138,2106,2155,2081,84,2080,14,1,27,113]

theorem envBound8590 : H12AffineFastState.Bounded env8590 := by
  intro p hp
  have h : env8590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8589_8590 : H12AffineEnvironment.transform 11 26 env8589 = env8590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 26 env8589 == env8590) = true)

theorem identity8590 : scanCanonicalize (H12AffineFastState.compose env8590 (packedSelected [0,2,3,7,8,10,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 2162) := by decide +kernel

theorem selectedBound8590 : packedSelected [0,2,3,7,8,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env8591 : List Nat := [2,4,8,16,32,64,120,85,33,85,2048,26,2162,16,2091,2136,74,2091,14,2091,65,2049,27,34,2051,27,2138,2106,2155,2081,84,2080,14,1,27,113]

theorem envBound8591 : H12AffineFastState.Bounded env8591 := by
  intro p hp
  have h : env8591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8590_8591 : H12AffineEnvironment.transform 12 2162 env8590 = env8591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2162 env8590 == env8591) = true)

theorem identity8591 : scanCanonicalize (H12AffineFastState.compose env8591 (packedSelected [1,3,4,5,7,8,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound8591 : packedSelected [1,3,4,5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env8592 : List Nat := [2,4,8,16,32,64,120,85,33,85,97,26,19,16,74,57,74,74,14,74,65,96,27,34,98,27,59,91,10,64,84,65,14,1,27,113]

theorem envBound8592 : H12AffineFastState.Bounded env8592 := by
  intro p hp
  have h : env8592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8591_8592 : H12AffineEnvironment.transform 10 97 env8591 = env8592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env8591 == env8592) = true)

theorem identity8592 : scanCanonicalize (H12AffineFastState.compose env8592 (packedSelected [3,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound8592 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env8593 : List Nat := [2,4,8,11,32,64,99,78,33,78,97,1,8,11,74,34,74,74,14,74,65,96,0,34,98,0,32,64,10,64,79,65,14,1,0,106]

theorem envBound8593 : H12AffineFastState.Bounded env8593 := by
  intro p hp
  have h : env8593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8592_8593 : H12AffineEnvironment.transform 3 11 env8592 = env8593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env8592 == env8593) = true)

theorem identity8593 : scanCanonicalize (H12AffineFastState.compose env8593 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound8593 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env8594 : List Nat := [2,4,8,11,32,10,41,4,33,4,43,1,8,11,0,34,0,0,14,0,11,42,0,34,40,0,32,10,10,10,5,11,14,1,0,32]

theorem envBound8594 : H12AffineFastState.Bounded env8594 := by
  intro p hp
  have h : env8594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8593_8594 : H12AffineEnvironment.transform 5 10 env8593 = env8594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env8593 == env8594) = true)

def env8595 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4961,8692,2097152,4194304,5004,90336,8329,21040,278624,4214984,4215092,75786,504,4268383,4961,73770,2175666,90943]

theorem envBound8595 : H12AffineFastState.Bounded env8595 := by
  intro p hp
  have h : env8595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8497_8595 : H12AffineEnvironment.transform 18 4961 env8497 = env8595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4961 env8497 == env8595) = true)

theorem identity8595 : scanCanonicalize (H12AffineFastState.compose env8595 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8595 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8596 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,2097152,4194304,4721,90336,8329,21040,278624,4214984,4214985,75786,5,4268194,4764,73770,2175666,90818]

theorem envBound8596 : H12AffineFastState.Bounded env8596 := by
  intro p hp
  have h : env8596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8595_8596 : H12AffineEnvironment.transform 7 253 env8595 = env8596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8595 == env8596) = true)

def env8597 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,64,4194304,4721,90336,8329,21040,278624,4214984,4214985,75786,5,4268194,4764,73770,78578,90818]

theorem envBound8597 : H12AffineFastState.Bounded env8597 := by
  intro p hp
  have h : env8597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8596_8597 : H12AffineEnvironment.transform 20 64 env8596 = env8597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8596 == env8597) = true)

theorem identity8597 : scanCanonicalize (H12AffineFastState.compose env8597 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 77920) := by decide +kernel

theorem selectedBound8597 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8598 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,77920,4764,8201,64,4194304,4721,90336,8329,21040,94208,4214984,4214985,75786,5,4268194,4764,73770,78578,90818]

theorem envBound8598 : H12AffineFastState.Bounded env8598 := by
  intro p hp
  have h : env8598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8597_8598 : H12AffineEnvironment.transform 17 77920 env8597 = env8598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 77920 env8597 == env8598) = true)

def env8599 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,77920,4764,8201,64,16960,4721,90336,8329,21040,94208,4744,4745,75786,5,90850,4764,73770,78578,90818]

theorem envBound8599 : H12AffineFastState.Bounded env8599 := by
  intro p hp
  have h : env8599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8598_8599 : H12AffineEnvironment.transform 21 16960 env8598 = env8599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16960 env8598 == env8599) = true)

def env8600 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,77920,4764,8201,64,112,4721,74448,8329,4096,78384,4744,4745,75786,5,73938,4764,73770,78578,73970]

theorem envBound8600 : H12AffineFastState.Bounded env8600 := by
  intro p hp
  have h : env8600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8599_8600 : H12AffineEnvironment.transform 13 560 env8599 = env8600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8599 == env8600) = true)

theorem identity8600 : scanCanonicalize (H12AffineFastState.compose env8600 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8600 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8601 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,64,8192,560,8201,65536,64,73760,732,8201,64,112,561,74448,8329,64,74352,712,713,75786,5,73938,732,73770,74418,73970]

theorem envBound8601 : H12AffineFastState.Bounded env8601 := by
  intro p hp
  have h : env8601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8600_8601 : H12AffineEnvironment.transform 11 64 env8600 = env8601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8600 == env8601) = true)

theorem identity8601 : scanCanonicalize (H12AffineFastState.compose env8601 (packedSelected [1,3,5,8,10,14,17,19,21] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound8601 : packedSelected [1,3,5,8,10,14,17,19,21] rootPS < 2^1333 := by decide +kernel

def env8602 : List Nat := [2,4,8,16,32,64,128,253,512,253,675,64,8192,560,8201,65536,64,73760,732,8201,64,112,561,74448,8329,64,74352,712,713,74409,5,73938,732,73770,74418,73970]

theorem envBound8602 : H12AffineFastState.Bounded env8602 := by
  intro p hp
  have h : env8602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8601_8602 : H12AffineEnvironment.transform 10 675 env8601 = env8602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env8601 == env8602) = true)

theorem identity8602 : scanCanonicalize (H12AffineFastState.compose env8602 (packedSelected [1,3,4,9,12,14,15,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound8602 : packedSelected [1,3,4,9,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env8603 : List Nat := [2,4,8,16,32,64,128,253,512,253,675,64,8192,560,8201,8714,64,554,732,8201,64,112,561,218,8329,64,122,712,713,163,5,728,732,544,184,760]

theorem envBound8603 : H12AffineFastState.Bounded env8603 := by
  intro p hp
  have h : env8603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8602_8603 : H12AffineEnvironment.transform 15 8714 env8602 = env8603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8602 == env8603) = true)

def env8604 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,77920,4764,8201,64,113,4721,74449,8329,4097,78385,4744,4745,75786,5,73939,4764,73770,78578,73971]

theorem envBound8604 : H12AffineFastState.Bounded env8604 := by
  intro p hp
  have h : env8604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8599_8604 : H12AffineEnvironment.transform 13 561 env8599 = env8604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8599 == env8604) = true)

theorem identity8604 : scanCanonicalize (H12AffineFastState.compose env8604 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound8604 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8605 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,184,8192,561,8201,65536,184,73944,548,8201,64,113,713,74449,8329,185,74377,560,561,75786,5,73939,548,73770,74314,73971]

theorem envBound8605 : H12AffineFastState.Bounded env8605 := by
  intro p hp
  have h : env8605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8604_8605 : H12AffineEnvironment.transform 11 184 env8604 = env8605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env8604 == env8605) = true)

theorem identity8605 : scanCanonicalize (H12AffineFastState.compose env8605 (packedSelected [13,14,21] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound8605 : packedSelected [13,14,21] rootPS < 2^1333 := by decide +kernel

def env8606 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,16,8192,561,8201,65536,16,73840,548,8201,64,113,609,74361,8225,17,74273,560,561,75786,5,73851,548,73770,74314,73819]

theorem envBound8606 : H12AffineFastState.Bounded env8606 := by
  intro p hp
  have h : env8606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8605_8606 : H12AffineEnvironment.transform 6 40 env8605 = env8606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env8605 == env8606) = true)

theorem identity8606 : scanCanonicalize (H12AffineFastState.compose env8606 (packedSelected [5,8,10,12,13,14,15,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8714) := by decide +kernel

theorem selectedBound8606 : packedSelected [5,8,10,12,13,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env8607 : List Nat := [2,4,8,16,32,64,40,85,512,85,2048,16,8192,561,8201,8714,16,634,548,8201,64,113,609,115,8225,17,43,560,561,2560,5,625,548,544,64,593]

theorem envBound8607 : H12AffineFastState.Bounded env8607 := by
  intro p hp
  have h : env8607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8606_8607 : H12AffineEnvironment.transform 15 8714 env8606 = env8607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8714 env8606 == env8607) = true)

def env8608 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,77920,4764,8201,64,16961,4721,90336,8329,21040,94208,4745,4744,75786,5,90851,4764,73770,78578,90818]

theorem envBound8608 : H12AffineFastState.Bounded env8608 := by
  intro p hp
  have h : env8608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8598_8608 : H12AffineEnvironment.transform 21 16961 env8598 = env8608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 16961 env8598 == env8608) = true)

def env8609 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,77920,4764,8201,64,113,4721,74448,8329,4096,78384,4745,4744,75786,5,73939,4764,73770,78578,73970]

theorem envBound8609 : H12AffineFastState.Bounded env8609 := by
  intro p hp
  have h : env8609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8608_8609 : H12AffineEnvironment.transform 13 560 env8608 = env8609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8608 == env8609) = true)

theorem identity8609 : scanCanonicalize (H12AffineFastState.compose env8609 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12978) := by decide +kernel

theorem selectedBound8609 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8610 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,12978,4096,722,4764,8201,64,113,4721,4194,8329,4096,130,4745,4744,6840,5,4705,4764,4760,64,4672]

theorem envBound8610 : H12AffineFastState.Bounded env8610 := by
  intro p hp
  have h : env8610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8609_8610 : H12AffineEnvironment.transform 15 12978 env8609 = env8610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12978 env8609 == env8610) = true)

theorem identity8610 : scanCanonicalize (H12AffineFastState.compose env8610 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 184) := by decide +kernel

theorem selectedBound8610 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8611 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,184,8192,560,8201,8714,184,722,548,8201,64,113,713,218,8329,184,130,561,560,2560,5,729,548,544,64,760]

theorem envBound8611 : H12AffineFastState.Bounded env8611 := by
  intro p hp
  have h : env8611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8610_8611 : H12AffineEnvironment.transform 11 184 env8610 = env8611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 184 env8610 == env8611) = true)

theorem identity8611 : scanCanonicalize (H12AffineFastState.compose env8611 (packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound8611 : packedSelected [1,2,3,5,8,10,11,13,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8612 : List Nat := [2,4,8,16,32,64,128,253,137,253,2048,184,8192,185,8201,8323,184,91,173,8201,64,113,64,218,8329,184,130,184,185,2185,5,80,173,169,64,113]

theorem envBound8612 : H12AffineFastState.Bounded env8612 := by
  intro p hp
  have h : env8612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8611_8612 : H12AffineEnvironment.transform 8 137 env8611 = env8612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env8611 == env8612) = true)

theorem identity8612 : scanCanonicalize (H12AffineFastState.compose env8612 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound8612 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8613 : List Nat := [2,4,8,16,32,64,128,253,137,253,122,184,8192,185,8201,8323,184,91,173,8201,64,113,64,218,8329,184,130,184,185,243,5,80,173,169,64,113]

theorem envBound8613 : H12AffineFastState.Bounded env8613 := by
  intro p hp
  have h : env8613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8612_8613 : H12AffineEnvironment.transform 10 122 env8612 = env8613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env8612 == env8613) = true)

theorem identity8613 : scanCanonicalize (H12AffineFastState.compose env8613 (packedSelected [11] rootPS)) = affineNative (2^(12+1) ^^^ 98) := by decide +kernel

theorem selectedBound8613 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env8614 : List Nat := [2,4,8,16,32,64,128,253,137,253,122,184,98,185,107,225,184,91,173,107,64,113,64,218,235,184,130,184,185,243,5,80,173,169,64,113]

theorem envBound8614 : H12AffineFastState.Bounded env8614 := by
  intro p hp
  have h : env8614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8613_8614 : H12AffineEnvironment.transform 12 98 env8613 = env8614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 98 env8613 == env8614) = true)

theorem identity8614 : scanCanonicalize (H12AffineFastState.compose env8614 (packedSelected [0,5,8,9,10] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound8614 : packedSelected [0,5,8,9,10] rootPS < 2^1333 := by decide +kernel

def env8615 : List Nat := [2,4,8,16,32,64,114,15,123,15,122,74,98,75,107,19,74,91,95,107,64,113,64,40,25,74,112,74,75,1,5,80,95,91,64,113]

theorem envBound8615 : H12AffineFastState.Bounded env8615 := by
  intro p hp
  have h : env8615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8614_8615 : H12AffineEnvironment.transform 6 114 env8614 = env8615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env8614 == env8615) = true)

theorem identity8615 : scanCanonicalize (H12AffineFastState.compose env8615 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound8615 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env8616 : List Nat := [2,4,8,10,32,64,104,15,97,15,96,74,98,75,107,9,74,65,69,107,64,107,64,40,3,74,106,74,75,1,5,74,69,65,64,107]

theorem envBound8616 : H12AffineFastState.Bounded env8616 := by
  intro p hp
  have h : env8616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8615_8616 : H12AffineEnvironment.transform 3 10 env8615 = env8616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env8615 == env8616) = true)

theorem identity8616 : scanCanonicalize (H12AffineFastState.compose env8616 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8617 : List Nat := [2,4,8,10,10,64,66,15,75,15,74,74,72,75,65,9,74,65,69,65,64,65,64,2,3,74,64,74,75,1,5,74,69,65,64,65]

theorem envBound8617 : H12AffineFastState.Bounded env8617 := by
  intro p hp
  have h : env8617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8616_8617 : H12AffineEnvironment.transform 4 10 env8616 = env8617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8616 == env8617) = true)

theorem identity8617 : scanCanonicalize (H12AffineFastState.compose env8617 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8617 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8618 : List Nat := [2,4,2,0,0,64,66,5,65,5,64,64,66,65,65,3,64,65,69,65,64,65,64,2,3,64,64,64,65,1,5,64,69,65,64,65]

theorem envBound8618 : H12AffineFastState.Bounded env8618 := by
  intro p hp
  have h : env8618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8617_8618 : H12AffineEnvironment.transform 2 2 env8617 = env8618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8617 == env8618) = true)

theorem identity8618 : scanCanonicalize (H12AffineFastState.compose env8618 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8618 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8619 : List Nat := [2,4,2,0,0,0,2,5,1,5,0,0,2,1,1,3,0,1,5,1,0,1,0,2,3,0,0,0,1,1,5,0,5,1,0,1]

theorem envBound8619 : H12AffineFastState.Bounded env8619 := by
  intro p hp
  have h : env8619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8618_8619 : H12AffineEnvironment.transform 5 0 env8618 = env8619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8618 == env8619) = true)

def env8620 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,77920,4764,8201,64,112,4721,74449,8329,4097,78385,4745,4744,75786,5,73938,4764,73770,78578,73971]

theorem envBound8620 : H12AffineFastState.Bounded env8620 := by
  intro p hp
  have h : env8620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8608_8620 : H12AffineEnvironment.transform 13 561 env8608 = env8620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8608 == env8620) = true)

theorem identity8620 : scanCanonicalize (H12AffineFastState.compose env8620 (packedSelected [7,20,27] rootPS)) = affineNative (2^(15+1) ^^^ 12874) := by decide +kernel

theorem selectedBound8620 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8621 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,12874,4096,554,4764,8201,64,112,4721,4251,8329,4097,123,4745,4744,6720,5,4760,4764,4704,184,4793]

theorem envBound8621 : H12AffineFastState.Bounded env8621 := by
  intro p hp
  have h : env8621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8620_8621 : H12AffineEnvironment.transform 15 12874 env8620 = env8621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12874 env8620 == env8621) = true)

theorem identity8621 : scanCanonicalize (H12AffineFastState.compose env8621 (packedSelected [1,3,5,8,10,13,14,17,19] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound8621 : packedSelected [1,3,5,8,10,13,14,17,19] rootPS < 2^1333 := by decide +kernel

def env8622 : List Nat := [2,4,8,16,32,64,128,253,512,253,522,4096,8192,561,8201,12874,4096,554,4764,8201,64,112,4721,4251,8329,4097,123,4745,4744,4170,5,4760,4764,4704,184,4793]

theorem envBound8622 : H12AffineFastState.Bounded env8622 := by
  intro p hp
  have h : env8622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8621_8622 : H12AffineEnvironment.transform 10 522 env8621 = env8622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8621 == env8622) = true)

theorem identity8622 : scanCanonicalize (H12AffineFastState.compose env8622 (packedSelected [0,4,7,9,14,17,21] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound8622 : packedSelected [0,4,7,9,14,17,21] rootPS < 2^1333 := by decide +kernel

def env8623 : List Nat := [2,4,8,16,32,64,120,5,512,5,522,4096,8192,561,8201,12874,4096,554,4708,8201,64,112,4721,4195,8305,4097,123,4721,4720,4170,5,4704,4708,4704,64,4673]

theorem envBound8623 : H12AffineFastState.Bounded env8623 := by
  intro p hp
  have h : env8623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8622_8623 : H12AffineEnvironment.transform 6 120 env8622 = env8623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env8622 == env8623) = true)

theorem identity8623 : scanCanonicalize (H12AffineFastState.compose env8623 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8623 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env8624 : List Nat := [2,4,8,16,32,64,120,5,512,5,522,64,8192,561,8201,8714,64,554,548,8201,64,112,561,35,8305,65,123,561,560,10,5,544,548,544,64,513]

theorem envBound8624 : H12AffineFastState.Bounded env8624 := by
  intro p hp
  have h : env8624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8623_8624 : H12AffineEnvironment.transform 11 64 env8623 = env8624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8623 == env8624) = true)

theorem identity8624 : scanCanonicalize (H12AffineFastState.compose env8624 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8624 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env8625 : List Nat := [2,4,8,1,32,64,105,5,512,5,522,64,8192,544,8201,8714,64,554,548,8201,64,97,544,35,8288,65,106,544,545,10,5,544,548,544,64,513]

theorem envBound8625 : H12AffineFastState.Bounded env8625 := by
  intro p hp
  have h : env8625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8624_8625 : H12AffineEnvironment.transform 3 1 env8624 = env8625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8624 == env8625) = true)

theorem identity8625 : scanCanonicalize (H12AffineFastState.compose env8625 (packedSelected [0,2,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 616) := by decide +kernel

theorem selectedBound8625 : packedSelected [0,2,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env8626 : List Nat := [2,4,8,1,32,64,105,5,512,5,522,64,616,544,609,98,64,554,548,609,64,97,544,35,520,65,106,544,545,10,5,544,548,544,64,513]

theorem envBound8626 : H12AffineFastState.Bounded env8626 := by
  intro p hp
  have h : env8626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8625_8626 : H12AffineEnvironment.transform 12 616 env8625 = env8626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 616 env8625 == env8626) = true)

theorem identity8626 : scanCanonicalize (H12AffineFastState.compose env8626 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound8626 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env8627 : List Nat := [2,4,8,1,32,64,105,5,32,5,42,64,72,0,65,98,64,10,4,65,64,97,0,35,40,65,106,0,1,10,5,0,4,0,64,33]

theorem envBound8627 : H12AffineFastState.Bounded env8627 := by
  intro p hp
  have h : env8627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8626_8627 : H12AffineEnvironment.transform 8 32 env8626 = env8627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env8626 == env8627) = true)

theorem identity8627 : scanCanonicalize (H12AffineFastState.compose env8627 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8627 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env8628 : List Nat := [2,4,8,1,10,64,67,5,10,5,0,64,72,0,65,72,64,10,4,65,64,75,0,9,2,65,64,0,1,10,5,0,4,0,64,11]

theorem envBound8628 : H12AffineFastState.Bounded env8628 := by
  intro p hp
  have h : env8628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8627_8628 : H12AffineEnvironment.transform 4 10 env8627 = env8628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8627 == env8628) = true)

theorem identity8628 : scanCanonicalize (H12AffineFastState.compose env8628 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound8628 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env8629 : List Nat := [2,1,8,1,10,64,67,0,10,0,0,64,72,0,65,72,64,10,1,65,64,75,0,9,2,65,64,0,1,10,0,0,1,0,64,11]

theorem envBound8629 : H12AffineFastState.Bounded env8629 := by
  intro p hp
  have h : env8629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8628_8629 : H12AffineEnvironment.transform 1 1 env8628 = env8629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env8628 == env8629) = true)

theorem identity8629 : scanCanonicalize (H12AffineFastState.compose env8629 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8629 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env8630 : List Nat := [2,1,3,1,1,64,67,0,1,0,0,64,67,0,65,67,64,1,1,65,64,64,0,2,2,65,64,0,1,1,0,0,1,0,64,0]

theorem envBound8630 : H12AffineFastState.Bounded env8630 := by
  intro p hp
  have h : env8630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8629_8630 : H12AffineEnvironment.transform 2 3 env8629 = env8630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8629 == env8630) = true)

theorem identity8630 : scanCanonicalize (H12AffineFastState.compose env8630 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound8630 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8631 : List Nat := [2,1,3,1,1,0,3,0,1,0,0,0,3,0,1,3,0,1,1,1,0,0,0,2,2,1,0,0,1,1,0,0,1,0,0,0]

theorem envBound8631 : H12AffineFastState.Bounded env8631 := by
  intro p hp
  have h : env8631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8630_8631 : H12AffineEnvironment.transform 5 0 env8630 = env8631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env8630 == env8631) = true)

def env8632 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4764,8201,65,4194304,4721,90336,8329,21040,278624,4214984,4214985,75786,5,4268194,4764,73770,78579,90818]

theorem envBound8632 : H12AffineFastState.Bounded env8632 := by
  intro p hp
  have h : env8632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8596_8632 : H12AffineEnvironment.transform 20 65 env8596 = env8632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8596 == env8632) = true)

theorem identity8632 : scanCanonicalize (H12AffineFastState.compose env8632 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 74241) := by decide +kernel

theorem selectedBound8632 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8633 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,74241,4764,8201,65,4194304,4721,90336,8329,21040,90721,4214984,4214985,75786,5,4268194,4764,73770,78579,90818]

theorem envBound8633 : H12AffineFastState.Bounded env8633 := by
  intro p hp
  have h : env8633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8632_8633 : H12AffineEnvironment.transform 17 74241 env8632 = env8633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 74241 env8632 == env8633) = true)

def env8634 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,65536,4096,74241,4644,8201,65,4194304,4721,90200,8241,21040,90721,4214896,4214897,75786,5,4268058,4644,73770,78411,90746]

theorem envBound8634 : H12AffineFastState.Bounded env8634 := by
  intro p hp
  have h : env8634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8633_8634 : H12AffineEnvironment.transform 6 56 env8633 = env8634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8633 == env8634) = true)

theorem identity8634 : scanCanonicalize (H12AffineFastState.compose env8634 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 609) := by decide +kernel

theorem selectedBound8634 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8635 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,609,8201,65536,4096,74241,4644,8201,65,4194304,4721,74297,8241,4177,73728,4198929,4198928,75786,5,4268058,4644,73770,78411,73755]

theorem envBound8635 : H12AffineFastState.Bounded env8635 := by
  intro p hp
  have h : env8635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8634_8635 : H12AffineEnvironment.transform 13 609 env8634 = env8635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 609 env8634 == env8635) = true)

theorem identity8635 : scanCanonicalize (H12AffineFastState.compose env8635 (packedSelected [1,8,13,19,21] rootPS)) = affineNative (2^(21+1) ^^^ 74283) := by decide +kernel

theorem selectedBound8635 : packedSelected [1,8,13,19,21] rootPS < 2^1333 := by decide +kernel

def env8636 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,609,8201,65536,4096,74241,4644,8201,65,74283,4721,74297,8241,4177,73728,77882,77883,75786,5,561,4644,73770,78411,73755]

theorem envBound8636 : H12AffineFastState.Bounded env8636 := by
  intro p hp
  have h : env8636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8635_8636 : H12AffineEnvironment.transform 21 74283 env8635 = env8636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74283 env8635 == env8636) = true)

theorem identity8636 : scanCanonicalize (H12AffineFastState.compose env8636 (packedSelected [1,8,19] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8636 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env8637 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,4096,8192,609,8201,65536,4096,74241,4644,8201,65,74283,4705,74281,8225,4161,73728,77866,77867,75786,5,545,4644,73770,78411,73739]

theorem envBound8637 : H12AffineFastState.Bounded env8637 := by
  intro p hp
  have h : env8637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8636_8637 : H12AffineEnvironment.transform 3 0 env8636 = env8637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8636 == env8637) = true)

theorem identity8637 : scanCanonicalize (H12AffineFastState.compose env8637 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 8715) := by decide +kernel

theorem selectedBound8637 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8638 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,4096,8192,609,8201,8715,4096,10,4644,8201,65,32,4705,34,8225,4161,523,4641,4640,2561,5,545,4644,545,4160,512]

theorem envBound8638 : H12AffineFastState.Bounded env8638 := by
  intro p hp
  have h : env8638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8637_8638 : H12AffineEnvironment.transform 15 8715 env8637 = env8638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8715 env8637 == env8638) = true)

theorem identity8638 : scanCanonicalize (H12AffineFastState.compose env8638 (packedSelected [0,1,3,4,7,9,12,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2090) := by decide +kernel

theorem selectedBound8638 : packedSelected [0,1,3,4,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env8639 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,2090,8192,609,8201,8715,2090,10,2574,8201,65,32,2635,34,8225,2155,523,2571,2570,2561,5,545,2574,545,2154,512]

theorem envBound8639 : H12AffineFastState.Bounded env8639 := by
  intro p hp
  have h : env8639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8638_8639 : H12AffineEnvironment.transform 11 2090 env8638 = env8639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2090 env8638 == env8639) = true)

theorem identity8639 : scanCanonicalize (H12AffineFastState.compose env8639 (packedSelected [0,1,2,3,4,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 99) := by decide +kernel

theorem selectedBound8639 : packedSelected [0,1,2,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env8640 : List Nat := [2,4,8,0,32,64,40,69,512,69,2048,2090,99,609,106,616,2090,10,2574,106,65,32,2635,34,66,2155,523,2571,2570,2561,5,545,2574,545,2154,512]

theorem envBound8640 : H12AffineFastState.Bounded env8640 := by
  intro p hp
  have h : env8640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8639_8640 : H12AffineEnvironment.transform 12 99 env8639 = env8640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 99 env8639 == env8640) = true)

theorem identity8640 : scanCanonicalize (H12AffineFastState.compose env8640 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound8640 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env8641 : List Nat := [2,4,8,0,32,64,40,69,512,69,43,1,99,609,106,616,1,10,549,106,65,32,608,34,66,64,523,544,545,554,5,545,549,545,65,512]

theorem envBound8641 : H12AffineFastState.Bounded env8641 := by
  intro p hp
  have h : env8641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8640_8641 : H12AffineEnvironment.transform 10 43 env8640 = env8641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env8640 == env8641) = true)

theorem identity8641 : scanCanonicalize (H12AffineFastState.compose env8641 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8641 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8642 : List Nat := [2,4,8,0,32,1,40,4,512,4,43,1,34,544,43,553,1,10,549,43,0,32,545,34,3,1,523,544,545,554,5,545,549,545,0,512]

theorem envBound8642 : H12AffineFastState.Bounded env8642 := by
  intro p hp
  have h : env8642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8641_8642 : H12AffineEnvironment.transform 5 1 env8641 = env8642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8641 == env8642) = true)

theorem identity8642 : scanCanonicalize (H12AffineFastState.compose env8642 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound8642 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8643 : List Nat := [2,4,8,0,10,1,2,4,512,4,1,1,8,522,1,515,1,10,527,1,0,10,523,8,3,1,523,522,523,512,5,523,527,523,0,512]

theorem envBound8643 : H12AffineFastState.Bounded env8643 := by
  intro p hp
  have h : env8643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8642_8643 : H12AffineEnvironment.transform 4 10 env8642 = env8643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env8642 == env8643) = true)

theorem identity8643 : scanCanonicalize (H12AffineFastState.compose env8643 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound8643 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8644 : List Nat := [2,4,8,0,10,1,2,4,10,4,1,1,8,0,1,9,1,10,5,1,0,10,1,8,3,1,1,0,1,10,5,1,5,1,0,10]

theorem envBound8644 : H12AffineFastState.Bounded env8644 := by
  intro p hp
  have h : env8644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8643_8644 : H12AffineEnvironment.transform 8 10 env8643 = env8644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env8643 == env8644) = true)

theorem identity8644 : scanCanonicalize (H12AffineFastState.compose env8644 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8644 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8645 : List Nat := [2,4,2,0,0,1,2,4,0,4,1,1,2,0,1,3,1,0,5,1,0,0,1,2,3,1,1,0,1,0,5,1,5,1,0,0]

theorem envBound8645 : H12AffineFastState.Bounded env8645 := by
  intro p hp
  have h : env8645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8644_8645 : H12AffineEnvironment.transform 2 2 env8644 = env8645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env8644 == env8645) = true)

def env8646 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,65536,4096,74241,4645,8201,65,4194304,4721,90201,8240,21040,90721,4214897,4214896,75786,5,4268059,4645,73770,78410,90747]

theorem envBound8646 : H12AffineFastState.Bounded env8646 := by
  intro p hp
  have h : env8646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8633_8646 : H12AffineEnvironment.transform 6 57 env8633 = env8646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8633 == env8646) = true)

theorem identity8646 : scanCanonicalize (H12AffineFastState.compose env8646 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 74282) := by decide +kernel

theorem selectedBound8646 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8647 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,65536,4096,74241,4645,8201,65,74282,4721,90201,8240,21040,90721,94811,94810,75786,5,561,4645,73770,78410,90747]

theorem envBound8647 : H12AffineFastState.Bounded env8647 := by
  intro p hp
  have h : env8647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8646_8647 : H12AffineEnvironment.transform 21 74282 env8646 = env8647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 74282 env8646 == env8647) = true)

theorem identity8647 : scanCanonicalize (H12AffineFastState.compose env8647 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8731) := by decide +kernel

theorem selectedBound8647 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env8648 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,8731,4096,26,4645,8201,65,49,4721,16962,8240,21040,16506,20544,20545,2577,5,561,4645,561,4177,16480]

theorem envBound8648 : H12AffineFastState.Bounded env8648 := by
  intro p hp
  have h : env8648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8647_8648 : H12AffineEnvironment.transform 15 8731 env8647 = env8648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8731 env8647 == env8648) = true)

theorem identity8648 : scanCanonicalize (H12AffineFastState.compose env8648 (packedSelected [1,2,8,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound8648 : packedSelected [1,2,8,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8649 : List Nat := [2,4,8,16,32,64,57,68,97,68,2048,4096,8192,16384,8201,8314,4096,26,4164,8201,65,49,4112,16419,8240,20561,16506,20544,20545,2160,5,80,4164,80,4177,16480]

theorem envBound8649 : H12AffineFastState.Bounded env8649 := by
  intro p hp
  have h : env8649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8648_8649 : H12AffineEnvironment.transform 8 97 env8648 = env8649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env8648 == env8649) = true)

theorem identity8649 : scanCanonicalize (H12AffineFastState.compose env8649 (packedSelected [13,17] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8649 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8650 : List Nat := [2,4,8,16,32,64,57,68,97,68,2048,2155,8192,16384,8201,8314,2155,26,2095,8201,65,49,2171,16419,8240,18490,16506,18475,18474,2160,5,80,2095,80,2106,16480]

theorem envBound8650 : H12AffineFastState.Bounded env8650 := by
  intro p hp
  have h : env8650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8649_8650 : H12AffineEnvironment.transform 11 2155 env8649 = env8650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8649 == env8650) = true)

theorem identity8650 : scanCanonicalize (H12AffineFastState.compose env8650 (packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound8650 : packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS < 2^1333 := by decide +kernel

def env8651 : List Nat := [2,4,8,16,32,64,57,68,97,68,2048,2155,8192,0,8201,8314,2155,26,2095,8201,65,49,2171,35,8240,2106,122,2091,2090,2160,5,80,2095,80,2106,96]

theorem envBound8651 : H12AffineFastState.Bounded env8651 := by
  intro p hp
  have h : env8651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8650_8651 : H12AffineEnvironment.transform 13 0 env8650 = env8651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env8650 == env8651) = true)

theorem identity8651 : scanCanonicalize (H12AffineFastState.compose env8651 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound8651 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env8652 : List Nat := [2,4,8,16,32,1,57,5,32,5,2048,2090,8192,0,8201,8251,2090,26,2095,8201,0,49,2106,35,8240,2106,59,2091,2090,2097,5,17,2095,17,2106,33]

theorem envBound8652 : H12AffineFastState.Bounded env8652 := by
  intro p hp
  have h : env8652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8651_8652 : H12AffineEnvironment.transform 5 1 env8651 = env8652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env8651 == env8652) = true)

theorem identity8652 : scanCanonicalize (H12AffineFastState.compose env8652 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound8652 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env8653 : List Nat := [2,4,8,16,32,1,57,5,32,5,16,58,8192,0,8201,8251,58,26,63,8201,0,49,42,35,8240,42,59,59,58,33,5,17,63,17,42,33]

theorem envBound8653 : H12AffineFastState.Bounded env8653 := by
  intro p hp
  have h : env8653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8652_8653 : H12AffineEnvironment.transform 10 16 env8652 = env8653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env8652 == env8653) = true)

theorem identity8653 : scanCanonicalize (H12AffineFastState.compose env8653 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound8653 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8654 : List Nat := [2,4,8,16,1,1,24,5,1,5,16,27,8192,0,8201,8218,27,26,30,8201,0,16,11,2,8209,11,26,26,27,0,5,17,30,17,11,0]

theorem envBound8654 : H12AffineFastState.Bounded env8654 := by
  intro p hp
  have h : env8654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8653_8654 : H12AffineEnvironment.transform 4 1 env8653 = env8654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env8653 == env8654) = true)

theorem identity8654 : scanCanonicalize (H12AffineFastState.compose env8654 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8654 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8655 : List Nat := [2,4,3,16,1,1,19,5,1,5,16,16,8192,0,8194,8209,16,17,21,8194,0,16,0,2,8209,0,17,17,16,0,5,17,21,17,0,0]

theorem envBound8655 : H12AffineFastState.Bounded env8655 := by
  intro p hp
  have h : env8655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8654_8655 : H12AffineEnvironment.transform 2 3 env8654 = env8655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8654 == env8655) = true)

theorem identity8655 : scanCanonicalize (H12AffineFastState.compose env8655 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound8655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env8656 : List Nat := [2,0,3,16,1,1,19,1,1,1,16,16,8192,0,8194,8209,16,17,17,8194,0,16,0,2,8209,0,17,17,16,0,1,17,17,17,0,0]

theorem envBound8656 : H12AffineFastState.Bounded env8656 := by
  intro p hp
  have h : env8656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8655_8656 : H12AffineEnvironment.transform 1 0 env8655 = env8656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env8655 == env8656) = true)

theorem identity8656 : scanCanonicalize (H12AffineFastState.compose env8656 (packedSelected [4] rootPS)) = affineNative (2^(12+1) ^^^ 3) := by decide +kernel

theorem selectedBound8656 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env8657 : List Nat := [2,0,3,16,1,1,19,1,1,1,16,16,3,0,1,18,16,17,17,1,0,16,0,2,18,0,17,17,16,0,1,17,17,17,0,0]

theorem envBound8657 : H12AffineFastState.Bounded env8657 := by
  intro p hp
  have h : env8657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8656_8657 : H12AffineEnvironment.transform 12 3 env8656 = env8657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3 env8656 == env8657) = true)

def env8658 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,524288,8692,2097152,4194304,524525,90337,8329,21041,807681,4735913,4735573,605034,529049,4796991,524288,602954,2695634,90942]

theorem envBound8658 : H12AffineFastState.Bounded env8658 := by
  intro p hp
  have h : env8658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8496_8658 : H12AffineEnvironment.transform 23 90337 env8496 = env8658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 90337 env8496 == env8658) = true)

def env8659 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,4096,8192,16384,8692,65536,4605,262144,4960,8692,2097152,4194304,5005,90337,8329,21041,278625,4214985,4215093,75786,505,4268383,4960,73770,2175666,90942]

theorem envBound8659 : H12AffineFastState.Bounded env8659 := by
  intro p hp
  have h : env8659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8658_8659 : H12AffineEnvironment.transform 18 4960 env8658 = env8659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 4960 env8658 == env8659) = true)

theorem identity8659 : scanCanonicalize (H12AffineFastState.compose env8659 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound8659 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env8660 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,2097152,4194304,4720,90337,8329,21041,278625,4214985,4214984,75786,4,4268194,4765,73770,2175666,90819]

theorem envBound8660 : H12AffineFastState.Bounded env8660 := by
  intro p hp
  have h : env8660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8659_8660 : H12AffineEnvironment.transform 7 253 env8659 = env8660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env8659 == env8660) = true)

def env8661 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,64,4194304,4720,90337,8329,21041,278625,4214985,4214984,75786,4,4268194,4765,73770,78578,90819]

theorem envBound8661 : H12AffineFastState.Bounded env8661 := by
  intro p hp
  have h : env8661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8660_8661 : H12AffineEnvironment.transform 20 64 env8660 = env8661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 64 env8660 == env8661) = true)

theorem identity8661 : scanCanonicalize (H12AffineFastState.compose env8661 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 336521) := by decide +kernel

theorem selectedBound8661 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8662 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,64,336521,4720,90337,8329,21041,278625,356928,356929,75786,4,262699,4765,73770,78578,90819]

theorem envBound8662 : H12AffineFastState.Bounded env8662 := by
  intro p hp
  have h : env8662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8661_8662 : H12AffineEnvironment.transform 21 336521 env8661 = env8662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 336521 env8661 == env8662) = true)

def env8663 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,65536,4096,262144,4645,8201,64,336433,4720,90201,8241,21041,278625,356928,356929,75786,4,262699,4645,73770,78410,90747]

theorem envBound8663 : H12AffineFastState.Bounded env8663 := by
  intro p hp
  have h : env8663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8662_8663 : H12AffineEnvironment.transform 6 56 env8662 = env8663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env8662 == env8663) = true)

theorem identity8663 : scanCanonicalize (H12AffineFastState.compose env8663 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8731) := by decide +kernel

theorem selectedBound8663 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8664 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,8731,4096,262144,4645,8201,64,262186,4720,16962,8241,21041,278625,282715,282714,2577,4,262699,4645,561,4177,16480]

theorem envBound8664 : H12AffineFastState.Bounded env8664 := by
  intro p hp
  have h : env8664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8663_8664 : H12AffineEnvironment.transform 15 8731 env8663 = env8664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8731 env8663 == env8664) = true)

theorem identity8664 : scanCanonicalize (H12AffineFastState.compose env8664 (packedSelected [1,8,13,19,21] rootPS)) = affineNative (2^(17+1) ^^^ 26) := by decide +kernel

theorem selectedBound8664 : packedSelected [1,8,13,19,21] rootPS < 2^1333 := by decide +kernel

def env8665 : List Nat := [2,4,8,16,32,64,56,69,512,69,2048,4096,8192,16384,8201,8731,4096,26,4645,8201,64,48,4720,16962,8241,21041,16507,20545,20544,2577,4,561,4645,561,4177,16480]

theorem envBound8665 : H12AffineFastState.Bounded env8665 := by
  intro p hp
  have h : env8665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8664_8665 : H12AffineEnvironment.transform 17 26 env8664 = env8665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 26 env8664 == env8665) = true)

theorem identity8665 : scanCanonicalize (H12AffineFastState.compose env8665 (packedSelected [1,2,8,11,13,14,17,18,19] rootPS)) = affineNative (2^(8+1) ^^^ 96) := by decide +kernel

theorem selectedBound8665 : packedSelected [1,2,8,11,13,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env8666 : List Nat := [2,4,8,16,32,64,56,69,96,69,2048,4096,8192,16384,8201,8315,4096,26,4165,8201,64,48,4112,16418,8241,20561,16507,20545,20544,2161,4,81,4165,81,4177,16480]

theorem envBound8666 : H12AffineFastState.Bounded env8666 := by
  intro p hp
  have h : env8666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8665_8666 : H12AffineEnvironment.transform 8 96 env8665 = env8666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 96 env8665 == env8666) = true)

theorem identity8666 : scanCanonicalize (H12AffineFastState.compose env8666 (packedSelected [13,17] rootPS)) = affineNative (2^(13+1) ^^^ 6250) := by decide +kernel

theorem selectedBound8666 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env8667 : List Nat := [2,4,8,16,32,64,56,69,96,69,2048,4096,8192,6250,8201,8315,4096,26,4165,8201,64,48,4112,6216,8241,2107,6161,2091,2090,2161,4,81,4165,81,4177,6154]

theorem envBound8667 : H12AffineFastState.Bounded env8667 := by
  intro p hp
  have h : env8667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8666_8667 : H12AffineEnvironment.transform 13 6250 env8666 = env8667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6250 env8666 == env8667) = true)

theorem identity8667 : scanCanonicalize (H12AffineFastState.compose env8667 (packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS)) = affineNative (2^(11+1) ^^^ 2155) := by decide +kernel

theorem selectedBound8667 : packedSelected [0,1,2,3,4,7,9,11,14,18,24,28] rootPS < 2^1333 := by decide +kernel

def env8668 : List Nat := [2,4,8,16,32,64,56,69,96,69,2048,2155,8192,1,8201,8315,2155,26,2094,8201,64,48,2171,35,8241,2107,122,2091,2090,2161,4,81,2094,81,2106,97]

theorem envBound8668 : H12AffineFastState.Bounded env8668 := by
  intro p hp
  have h : env8668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8667_8668 : H12AffineEnvironment.transform 11 2155 env8667 = env8668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2155 env8667 == env8668) = true)

def env8669 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,65536,4096,262144,4644,8201,64,336432,4720,90200,8240,21041,278625,356928,356929,75786,4,262699,4644,73770,78411,90746]

theorem envBound8669 : H12AffineFastState.Bounded env8669 := by
  intro p hp
  have h : env8669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8662_8669 : H12AffineEnvironment.transform 6 57 env8662 = env8669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env8662 == env8669) = true)

theorem identity8669 : scanCanonicalize (H12AffineFastState.compose env8669 (packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS)) = affineNative (2^(17+1) ^^^ 90208) := by decide +kernel

theorem selectedBound8669 : packedSelected [0,1,2,3,5,8,10,11,13,14,17,18,19,27] rootPS < 2^1333 := by decide +kernel

def env8670 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,65536,4096,90208,4644,8201,64,16976,4720,90200,8240,21041,73729,4640,4641,75786,4,90699,4644,73770,78411,90746]

theorem envBound8670 : H12AffineFastState.Bounded env8670 := by
  intro p hp
  have h : env8670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8669_8670 : H12AffineEnvironment.transform 17 90208 env8669 = env8670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 90208 env8669 == env8670) = true)

theorem identity8670 : scanCanonicalize (H12AffineFastState.compose env8670 (packedSelected [0,1,7,8,13,19,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 8731) := by decide +kernel

theorem selectedBound8670 : packedSelected [0,1,7,8,13,19,20,21] rootPS < 2^1333 := by decide +kernel

def env8671 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,16384,8201,8731,4096,17019,4644,8201,64,16976,4720,16963,8240,21041,538,4640,4641,2577,4,16464,4644,561,4176,16481]

theorem envBound8671 : H12AffineFastState.Bounded env8671 := by
  intro p hp
  have h : env8671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8670_8671 : H12AffineEnvironment.transform 15 8731 env8670 = env8671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8731 env8670 == env8671) = true)

theorem identity8671 : scanCanonicalize (H12AffineFastState.compose env8671 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 625) := by decide +kernel

theorem selectedBound8671 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env8672 : List Nat := [2,4,8,16,32,64,57,68,512,68,2048,4096,8192,625,8201,8731,4096,10,4644,8201,64,33,4720,50,8240,4160,538,4640,4641,2577,4,545,4644,561,4176,528]

theorem envBound8672 : H12AffineFastState.Bounded env8672 := by
  intro p hp
  have h : env8672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8671_8672 : H12AffineEnvironment.transform 13 625 env8671 = env8672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 625 env8671 == env8672) = true)

theorem identity8672 : scanCanonicalize (H12AffineFastState.compose env8672 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 586) := by decide +kernel

theorem selectedBound8672 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8673 : List Nat := [2,4,8,16,32,64,57,68,512,68,586,4096,8192,625,8201,8731,4096,10,4644,8201,64,33,4720,50,8240,4160,538,4640,4641,91,4,545,4644,561,4176,528]

theorem envBound8673 : H12AffineFastState.Bounded env8673 := by
  intro p hp
  have h : env8673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8672_8673 : H12AffineEnvironment.transform 10 586 env8672 = env8673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 586 env8672 == env8673) = true)

theorem identity8673 : scanCanonicalize (H12AffineFastState.compose env8673 (packedSelected [0,7,20] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound8673 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env8674 : List Nat := [2,4,8,0,32,64,41,68,512,68,586,4096,8192,609,8201,8715,4096,10,4644,8201,64,33,4704,34,8224,4160,522,4640,4641,75,4,545,4644,545,4160,512]

theorem envBound8674 : H12AffineFastState.Bounded env8674 := by
  intro p hp
  have h : env8674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8673_8674 : H12AffineEnvironment.transform 3 0 env8673 = env8674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env8673 == env8674) = true)

theorem identity8674 : scanCanonicalize (H12AffineFastState.compose env8674 (packedSelected [3,4,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 4680) := by decide +kernel

theorem selectedBound8674 : packedSelected [3,4,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env8675 : List Nat := [2,4,8,0,32,64,41,68,512,68,586,4096,4680,609,4673,4163,4096,10,4644,4673,64,33,4704,34,4712,4160,522,4640,4641,75,4,545,4644,545,4160,512]

theorem envBound8675 : H12AffineFastState.Bounded env8675 := by
  intro p hp
  have h : env8675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8674_8675 : H12AffineEnvironment.transform 12 4680 env8674 = env8675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4680 env8674 == env8675) = true)

theorem identity8675 : scanCanonicalize (H12AffineFastState.compose env8675 (packedSelected [0,2,3,5,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 608) := by decide +kernel

theorem selectedBound8675 : packedSelected [0,2,3,5,8,9] rootPS < 2^1333 := by decide +kernel

def env8676 : List Nat := [2,4,8,0,32,64,41,68,512,68,586,608,40,609,33,547,608,10,68,33,64,33,0,34,8,544,522,64,65,75,4,545,68,545,544,512]

theorem envBound8676 : H12AffineFastState.Bounded env8676 := by
  intro p hp
  have h : env8676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8675_8676 : H12AffineEnvironment.transform 11 608 env8675 = env8676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 608 env8675 == env8676) = true)

def env8677 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,65,4194304,4720,90337,8329,21041,278625,4214985,4214984,75786,4,4268194,4765,73770,78579,90819]

theorem envBound8677 : H12AffineFastState.Bounded env8677 := by
  intro p hp
  have h : env8677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8660_8677 : H12AffineEnvironment.transform 20 65 env8660 = env8677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 65 env8660 == env8677) = true)

theorem identity8677 : scanCanonicalize (H12AffineFastState.compose env8677 (packedSelected [6] rootPS)) = affineNative (2^(21+1) ^^^ 340201) := by decide +kernel

theorem selectedBound8677 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env8678 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,262144,4765,8201,65,340201,4720,90337,8329,21041,278625,352288,352289,75786,4,266315,4765,73770,78579,90819]

theorem envBound8678 : H12AffineFastState.Bounded env8678 := by
  intro p hp
  have h : env8678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8677_8678 : H12AffineEnvironment.transform 21 340201 env8677 = env8678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 340201 env8677 == env8678) = true)

def env8679 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,16384,8201,65536,4096,94888,4765,8201,65,16961,4720,90337,8329,21041,78537,4744,4745,75786,4,90851,4765,73770,78579,90819]

theorem envBound8679 : H12AffineFastState.Bounded env8679 := by
  intro p hp
  have h : env8679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8678_8679 : H12AffineEnvironment.transform 17 94888 env8678 = env8679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 94888 env8678 == env8679) = true)

def env8680 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,560,8201,65536,4096,77976,4765,8201,65,113,4720,74449,8329,4097,78537,4744,4745,75786,4,73939,4765,73770,78579,73971]

theorem envBound8680 : H12AffineFastState.Bounded env8680 := by
  intro p hp
  have h : env8680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8679_8680 : H12AffineEnvironment.transform 13 560 env8679 = env8680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 560 env8679 == env8680) = true)

theorem identity8680 : scanCanonicalize (H12AffineFastState.compose env8680 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound8680 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8681 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,64,8192,560,8201,65536,64,73944,733,8201,65,113,560,74449,8329,65,74377,712,713,75786,4,73939,733,73770,74419,73971]

theorem envBound8681 : H12AffineFastState.Bounded env8681 := by
  intro p hp
  have h : env8681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8680_8681 : H12AffineEnvironment.transform 11 64 env8680 = env8681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env8680 == env8681) = true)

theorem identity8681 : scanCanonicalize (H12AffineFastState.compose env8681 (packedSelected [1,3,5,8,10,14,17,19,21] rootPS)) = affineNative (2^(15+1) ^^^ 10864) := by decide +kernel

theorem selectedBound8681 : packedSelected [1,3,5,8,10,14,17,19,21] rootPS < 2^1333 := by decide +kernel

def env8682 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,64,8192,560,8201,10864,64,2728,733,8201,65,113,560,2209,8329,65,2297,712,713,634,4,2723,733,2650,2243,2691]

theorem envBound8682 : H12AffineFastState.Bounded env8682 := by
  intro p hp
  have h : env8682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8681_8682 : H12AffineEnvironment.transform 15 10864 env8681 = env8682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 10864 env8681 == env8682) = true)

theorem identity8682 : scanCanonicalize (H12AffineFastState.compose env8682 (packedSelected [1,3,4,9,12,14,15,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound8682 : packedSelected [1,3,4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env8683 : List Nat := [2,4,8,16,32,17,128,172,512,172,2048,17,8192,560,8201,10785,17,2728,652,8201,16,32,560,2209,8329,16,2216,665,664,555,4,2723,652,2571,2194,2691]

theorem envBound8683 : H12AffineFastState.Bounded env8683 := by
  intro p hp
  have h : env8683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8682_8683 : H12AffineEnvironment.transform 5 17 env8682 = env8683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env8682 == env8683) = true)

theorem identity8683 : scanCanonicalize (H12AffineFastState.compose env8683 (packedSelected [1,3,12,13,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound8683 : packedSelected [1,3,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env8684 : List Nat := [2,4,8,16,32,17,128,172,512,172,42,17,8192,560,8201,8715,17,642,652,8201,16,32,560,139,8329,16,130,665,664,555,4,649,652,545,184,681]

theorem envBound8684 : H12AffineFastState.Bounded env8684 := by
  intro p hp
  have h : env8684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8683_8684 : H12AffineEnvironment.transform 10 42 env8683 = env8684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env8683 == env8684) = true)

theorem identity8684 : scanCanonicalize (H12AffineFastState.compose env8684 (packedSelected [3,7,8,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 657) := by decide +kernel

theorem selectedBound8684 : packedSelected [3,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env8685 : List Nat := [2,4,8,16,32,17,128,172,512,172,42,17,657,560,664,154,17,642,652,664,16,32,560,139,536,16,130,665,664,555,4,649,652,545,184,681]

theorem envBound8685 : H12AffineFastState.Bounded env8685 := by
  intro p hp
  have h : env8685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8684_8685 : H12AffineEnvironment.transform 12 657 env8684 = env8685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 657 env8684 == env8685) = true)

theorem identity8685 : scanCanonicalize (H12AffineFastState.compose env8685 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound8685 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env8686 : List Nat := [2,4,8,16,32,17,128,172,33,172,42,17,176,17,185,154,17,163,173,185,16,32,17,139,57,16,130,184,185,10,4,168,173,0,184,136]

theorem envBound8686 : H12AffineFastState.Bounded env8686 := by
  intro p hp
  have h : env8686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8685_8686 : H12AffineEnvironment.transform 8 33 env8685 = env8686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env8685 == env8686) = true)

theorem identity8686 : scanCanonicalize (H12AffineFastState.compose env8686 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound8686 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env8687 : List Nat := [2,4,8,16,32,17,18,62,33,62,42,17,34,17,43,8,17,49,63,43,16,32,17,25,57,16,16,42,43,10,4,58,63,0,42,26]

theorem envBound8687 : H12AffineFastState.Bounded env8687 := by
  intro p hp
  have h : env8687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8686_8687 : H12AffineEnvironment.transform 6 18 env8686 = env8687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env8686 == env8687) = true)

theorem identity8687 : scanCanonicalize (H12AffineFastState.compose env8687 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound8687 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env8688 : List Nat := [2,4,8,16,16,17,18,14,17,14,26,17,18,17,27,8,17,1,15,27,16,16,17,25,9,16,16,26,27,10,4,10,15,0,26,26]

theorem envBound8688 : H12AffineFastState.Bounded env8688 := by
  intro p hp
  have h : env8688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8687_8688 : H12AffineEnvironment.transform 4 16 env8687 = env8688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env8687 == env8688) = true)

theorem identity8688 : scanCanonicalize (H12AffineFastState.compose env8688 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound8688 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env8689 : List Nat := [2,4,3,16,16,17,18,5,17,5,17,17,18,17,16,3,17,1,4,16,16,16,17,18,2,16,16,17,16,1,4,1,4,0,17,17]

theorem envBound8689 : H12AffineFastState.Bounded env8689 := by
  intro p hp
  have h : env8689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8688_8689 : H12AffineEnvironment.transform 2 3 env8688 = env8689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env8688 == env8689) = true)

theorem identity8689 : scanCanonicalize (H12AffineFastState.compose env8689 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound8689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env8690 : List Nat := [2,4,3,1,1,0,3,5,0,5,0,0,3,0,1,3,0,1,4,1,1,1,0,3,2,1,1,0,1,1,4,1,4,0,0,0]

theorem envBound8690 : H12AffineFastState.Bounded env8690 := by
  intro p hp
  have h : env8690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8689_8690 : H12AffineEnvironment.transform 3 1 env8689 = env8690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env8689 == env8690) = true)

def env8691 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,4096,8192,561,8201,65536,4096,77977,4765,8201,65,112,4720,74448,8329,4096,78537,4744,4745,75786,4,73938,4765,73770,78579,73970]

theorem envBound8691 : H12AffineFastState.Bounded env8691 := by
  intro p hp
  have h : env8691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8679_8691 : H12AffineEnvironment.transform 13 561 env8679 = env8691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 561 env8679 == env8691) = true)

theorem identity8691 : scanCanonicalize (H12AffineFastState.compose env8691 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 185) := by decide +kernel

theorem selectedBound8691 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env8692 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,185,8192,561,8201,65536,185,73760,548,8201,65,112,713,74448,8329,185,74352,561,560,75786,4,73938,548,73770,74314,73970]

theorem envBound8692 : H12AffineFastState.Bounded env8692 := by
  intro p hp
  have h : env8692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8691_8692 : H12AffineEnvironment.transform 11 185 env8691 = env8692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 185 env8691 == env8692) = true)

theorem identity8692 : scanCanonicalize (H12AffineFastState.compose env8692 (packedSelected [13,14,21] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound8692 : packedSelected [13,14,21] rootPS < 2^1333 := by decide +kernel

def env8693 : List Nat := [2,4,8,16,32,64,128,253,512,253,2048,185,8192,561,8201,8323,185,163,548,8201,65,112,713,595,8329,185,755,561,560,2185,4,81,548,169,713,113]

theorem envBound8693 : H12AffineFastState.Bounded env8693 := by
  intro p hp
  have h : env8693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8692_8693 : H12AffineEnvironment.transform 15 8323 env8692 = env8693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env8692 == env8693) = true)

theorem identity8693 : scanCanonicalize (H12AffineFastState.compose env8693 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound8693 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env8694 : List Nat := [2,4,8,16,32,64,128,253,512,253,522,185,8192,561,8201,8323,185,163,548,8201,65,112,713,595,8329,185,755,561,560,643,4,81,548,169,713,113]

theorem envBound8694 : H12AffineFastState.Bounded env8694 := by
  intro p hp
  have h : env8694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8693_8694 : H12AffineEnvironment.transform 10 522 env8693 = env8694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env8693 == env8694) = true)

theorem identity8694 : scanCanonicalize (H12AffineFastState.compose env8694 (packedSelected [4,5,8,9,11,12,13,18] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound8694 : packedSelected [4,5,8,9,11,12,13,18] rootPS < 2^1333 := by decide +kernel

def env8695 : List Nat := [2,4,8,16,11,64,128,214,512,214,522,146,8192,538,8201,8323,146,136,527,8201,65,91,713,595,8329,146,728,538,539,643,4,81,527,130,713,90]

theorem envBound8695 : H12AffineFastState.Bounded env8695 := by
  intro p hp
  have h : env8695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8694_8695 : H12AffineEnvironment.transform 4 11 env8694 = env8695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env8694 == env8695) = true)

theorem identity8695 : scanCanonicalize (H12AffineFastState.compose env8695 (packedSelected [2,3,4,7,8,11,13,14] rootPS)) = affineNative (2^(12+1) ^^^ 145) := by decide +kernel

theorem selectedBound8695 : packedSelected [2,3,4,7,8,11,13,14] rootPS < 2^1333 := by decide +kernel

def env8696 : List Nat := [2,4,8,16,11,64,128,214,512,214,522,146,145,538,152,18,146,136,527,152,65,91,713,595,24,146,728,538,539,643,4,81,527,130,713,90]

theorem envBound8696 : H12AffineFastState.Bounded env8696 := by
  intro p hp
  have h : env8696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8695_8696 : H12AffineEnvironment.transform 12 145 env8695 = env8696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 145 env8695 == env8696) = true)

theorem identity8696 : scanCanonicalize (H12AffineFastState.compose env8696 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound8696 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env8697 : List Nat := [2,4,8,16,11,64,128,214,1,214,11,146,145,27,152,18,146,136,14,152,65,91,200,82,24,146,217,27,26,130,4,81,14,130,200,90]

theorem envBound8697 : H12AffineFastState.Bounded env8697 := by
  intro p hp
  have h : env8697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans8696_8697 : H12AffineEnvironment.transform 8 1 env8696 = env8697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env8696 == env8697) = true)

theorem identity8697 : scanCanonicalize (H12AffineFastState.compose env8697 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound8697 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1