import H12CloudChart1Data145

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env37022 : List Nat := [2,4,8,16,32,17,9,4,512,21,0,48,9,32,0,3,49,32,20,1,33,33,17,3,8,17,1,48,48,33,20,32,5,32,33,512]

theorem envBound37022 : H12AffineFastState.Bounded env37022 := by
  intro p hp
  have h : env37022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37021_37022 : H12AffineEnvironment.transform 10 0 env37021 = env37022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37021 == env37022) = true)

theorem identity37022 : scanCanonicalize (H12AffineFastState.compose env37022 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound37022 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37023 : List Nat := [2,4,8,16,32,17,9,4,43,21,0,48,9,32,0,3,49,32,20,1,33,33,17,3,8,17,1,48,48,33,20,32,5,32,33,43]

theorem envBound37023 : H12AffineFastState.Bounded env37023 := by
  intro p hp
  have h : env37023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37022_37023 : H12AffineEnvironment.transform 8 43 env37022 = env37023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env37022 == env37023) = true)

def env37024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,8388608,8601941,8328,64,4489557,8393985,8553865,8830977,181573,12645452,257,21792,46213,254610]

theorem envBound37024 : H12AffineFastState.Bounded env37024 := by
  intro p hp
  have h : env37024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36941_37024 : H12AffineEnvironment.transform 20 184537 env36941 = env37024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184537 env36941 == env37024) = true)

def env37025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180360,98781,8328,64,4489557,185737,17665,262281,181573,4338884,257,21792,46213,254610]

theorem envBound37025 : H12AffineFastState.Bounded env37025 := by
  intro p hp
  have h : env37025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37024_37025 : H12AffineEnvironment.transform 22 180360 env37024 = env37025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180360 env37024 == env37025) = true)

def env37026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180360,98781,8328,64,43477,185737,17665,262281,181573,400452,257,21792,46213,254610]

theorem envBound37026 : H12AffineFastState.Bounded env37026 := by
  intro p hp
  have h : env37026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37025_37026 : H12AffineEnvironment.transform 21 272512 env37025 = env37026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37025 == env37026) = true)

theorem identity37026 : scanCanonicalize (H12AffineFastState.compose env37026 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound37026 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,184537,272512,180360,21762,8328,64,43477,185737,17665,262281,181573,400452,257,21792,46213,144973]

theorem envBound37027 : H12AffineFastState.Bounded env37027 := by
  intro p hp
  have h : env37027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37026_37027 : H12AffineEnvironment.transform 15 54495 env37026 = env37027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env37026 == env37027) = true)

def env37028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,184401,272392,180224,21762,8192,64,43357,185601,17665,262145,181573,400452,257,21792,46093,144973]

theorem envBound37028 : H12AffineFastState.Bounded env37028 := by
  intro p hp
  have h : env37028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37027_37028 : H12AffineEnvironment.transform 6 8 env37027 = env37028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37027 == env37028) = true)

theorem identity37028 : scanCanonicalize (H12AffineFastState.compose env37028 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(16+1) ^^^ 49508) := by decide +kernel

theorem selectedBound37028 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env37029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49508,262144,1025,32769,4405,272392,356,21762,8192,64,43357,5221,17665,262145,1057,318752,257,21792,46093,63273]

theorem envBound37029 : H12AffineFastState.Bounded env37029 := by
  intro p hp
  have h : env37029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37028_37029 : H12AffineEnvironment.transform 16 49508 env37028 = env37029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49508 env37028 == env37029) = true)

theorem identity37029 : scanCanonicalize (H12AffineFastState.compose env37029 (packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound37029 : packedSelected [1,3,7,8,10,14,15,16,17,18,23,24,27,41] rootPS < 2^1333 := by decide +kernel

def env37030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49508,23669,1025,32769,4405,29821,356,21762,8192,64,43357,5221,17665,23668,1057,33109,257,21792,46093,63273]

theorem envBound37030 : H12AffineFastState.Bounded env37030 := by
  intro p hp
  have h : env37030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37029_37030 : H12AffineEnvironment.transform 17 23669 env37029 = env37030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env37029 == env37030) = true)

theorem identity37030 : scanCanonicalize (H12AffineFastState.compose env37030 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37030 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env37031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,54359,49508,23669,1025,32769,4405,21793,356,21762,348,64,34817,5221,17665,23668,1057,33109,257,21792,38225,54901]

theorem envBound37031 : H12AffineFastState.Bounded env37031 := by
  intro p hp
  have h : env37031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37030_37031 : H12AffineEnvironment.transform 12 348 env37030 = env37031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37030 == env37031) = true)

theorem identity37031 : scanCanonicalize (H12AffineFastState.compose env37031 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37031 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env37032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,21590,16741,23669,1025,0,4405,21793,356,21762,348,64,2048,5221,17665,23668,1057,340,257,21792,5456,22132]

theorem envBound37032 : H12AffineFastState.Bounded env37032 := by
  intro p hp
  have h : env37032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37031_37032 : H12AffineEnvironment.transform 14 1 env37031 = env37032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37031 == env37032) = true)

theorem identity37032 : scanCanonicalize (H12AffineFastState.compose env37032 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37032 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,1,342,5221,2421,1025,0,4405,33,356,2,348,64,2048,5221,4097,2420,1057,340,257,32,5456,884]

theorem envBound37033 : H12AffineFastState.Bounded env37033 := by
  intro p hp
  have h : env37033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37032_37033 : H12AffineEnvironment.transform 13 5376 env37032 = env37033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37032 == env37033) = true)

theorem identity37033 : scanCanonicalize (H12AffineFastState.compose env37033 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37033 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37034 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,89,5125,1,83,5221,2160,1025,0,4144,33,97,2,89,64,2048,5221,4097,2161,1057,81,4,32,5205,625]

theorem envBound37034 : H12AffineFastState.Bounded env37034 := by
  intro p hp
  have h : env37034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37033_37034 : H12AffineEnvironment.transform 7 5 env37033 = env37034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37033 == env37034) = true)

theorem identity37034 : scanCanonicalize (H12AffineFastState.compose env37034 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37034 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37035 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,9,5125,1,3,5173,2080,1025,0,4144,33,49,2,9,16,2048,5173,4097,2081,1057,1,4,32,5125,545]

theorem envBound37035 : H12AffineFastState.Bounded env37035 := by
  intro p hp
  have h : env37035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37034_37035 : H12AffineEnvironment.transform 5 16 env37034 = env37035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37034 == env37035) = true)

theorem identity37035 : scanCanonicalize (H12AffineFastState.compose env37035 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound37035 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37036 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,2065,9,3092,1,3,3108,2080,1025,0,2081,33,49,2,9,16,2048,3108,2064,2081,1057,1,4,32,3092,545]

theorem envBound37036 : H12AffineFastState.Bounded env37036 := by
  intro p hp
  have h : env37036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37035_37036 : H12AffineEnvironment.transform 11 2065 env37035 = env37036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env37035 == env37036) = true)

theorem identity37036 : scanCanonicalize (H12AffineFastState.compose env37036 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound37036 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env37037 : List Nat := [2,4,8,16,32,16,8,5,16,1024,2048,2065,9,3092,1,3,3108,2080,1025,0,2081,33,49,2,9,16,2048,3108,2064,2081,1057,1,4,32,3092,49]

theorem envBound37037 : H12AffineFastState.Bounded env37037 := by
  intro p hp
  have h : env37037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37036_37037 : H12AffineEnvironment.transform 8 16 env37036 = env37037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37036 == env37037) = true)

theorem identity37037 : scanCanonicalize (H12AffineFastState.compose env37037 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound37037 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env37038 : List Nat := [2,4,8,16,32,16,8,5,16,63,2048,2065,9,2091,1,3,2075,2080,62,0,2081,33,49,2,9,16,2048,2075,2064,2081,30,1,4,32,2091,49]

theorem envBound37038 : H12AffineFastState.Bounded env37038 := by
  intro p hp
  have h : env37038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37037_37038 : H12AffineEnvironment.transform 9 63 env37037 = env37038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env37037 == env37038) = true)

theorem identity37038 : scanCanonicalize (H12AffineFastState.compose env37038 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37038 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env37039 : List Nat := [2,4,8,16,0,16,8,5,16,31,2048,2065,9,2059,1,3,2075,2048,30,0,2049,1,17,2,9,16,2048,2075,2064,2049,30,1,4,0,2059,17]

theorem envBound37039 : H12AffineFastState.Bounded env37039 := by
  intro p hp
  have h : env37039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37038_37039 : H12AffineEnvironment.transform 4 0 env37038 = env37039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37038 == env37039) = true)

theorem identity37039 : scanCanonicalize (H12AffineFastState.compose env37039 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37039 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37040 : List Nat := [2,4,3,16,0,16,3,5,16,20,2048,2065,2,2048,1,3,2064,2048,21,0,2049,1,17,2,2,16,2048,2064,2064,2049,21,1,4,0,2048,17]

theorem envBound37040 : H12AffineFastState.Bounded env37040 := by
  intro p hp
  have h : env37040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37039_37040 : H12AffineEnvironment.transform 2 3 env37039 = env37040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37039 == env37040) = true)

theorem identity37040 : scanCanonicalize (H12AffineFastState.compose env37040 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound37040 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37041 : List Nat := [2,4,3,16,0,16,3,5,16,20,5,20,2,5,1,3,21,5,21,0,4,1,17,2,2,16,5,21,21,4,21,1,4,0,5,17]

theorem envBound37041 : H12AffineFastState.Bounded env37041 := by
  intro p hp
  have h : env37041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37040_37041 : H12AffineEnvironment.transform 10 5 env37040 = env37041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env37040 == env37041) = true)

theorem identity37041 : scanCanonicalize (H12AffineFastState.compose env37041 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37042 : List Nat := [0,4,1,16,0,16,1,5,16,20,5,20,0,5,1,1,21,5,21,0,4,1,17,0,0,16,5,21,21,4,21,1,4,0,5,17]

theorem envBound37042 : H12AffineFastState.Bounded env37042 := by
  intro p hp
  have h : env37042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37041_37042 : H12AffineEnvironment.transform 0 0 env37041 = env37042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37041 == env37042) = true)

theorem identity37042 : scanCanonicalize (H12AffineFastState.compose env37042 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37042 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37043 : List Nat := [0,4,1,0,0,0,1,5,0,4,5,4,0,5,1,1,5,5,5,0,4,1,1,0,0,0,5,5,5,4,5,1,4,0,5,1]

theorem envBound37043 : H12AffineFastState.Bounded env37043 := by
  intro p hp
  have h : env37043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37042_37043 : H12AffineEnvironment.transform 3 0 env37042 = env37043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37042 == env37043) = true)

theorem identity37043 : scanCanonicalize (H12AffineFastState.compose env37043 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37043 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env37044 : List Nat := [0,1,1,0,0,0,1,0,0,1,0,1,0,0,1,1,0,0,0,0,1,1,1,0,0,0,0,0,0,1,0,1,1,0,0,1]

theorem envBound37044 : H12AffineFastState.Bounded env37044 := by
  intro p hp
  have h : env37044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37043_37044 : H12AffineEnvironment.transform 1 1 env37043 = env37044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37043 == env37044) = true)

def env37045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,184400,272393,180225,21762,8193,64,43356,185600,17665,262144,181573,400452,257,21792,46092,144973]

theorem envBound37045 : H12AffineFastState.Bounded env37045 := by
  intro p hp
  have h : env37045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37027_37045 : H12AffineEnvironment.transform 6 9 env37027 = env37045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37027 == env37045) = true)

theorem identity37045 : scanCanonicalize (H12AffineFastState.compose env37045 (packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound37045 : packedSelected [0,3,4,8,10,12,14,18,19,20,22,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env37046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179512,1025,32769,184400,169265,180225,21762,8193,64,43356,185600,17665,179512,181573,41340,257,21792,46092,144973]

theorem envBound37046 : H12AffineFastState.Bounded env37046 := by
  intro p hp
  have h : env37046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37045_37046 : H12AffineEnvironment.transform 17 179512 env37045 = env37046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env37045 == env37046) = true)

theorem identity37046 : scanCanonicalize (H12AffineFastState.compose env37046 (packedSelected [3,5,7,10,12,14,15,16,17,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound37046 : packedSelected [3,5,7,10,12,14,15,16,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env37047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8461,30043,131072,138293,1025,8460,160093,144444,155916,21762,8193,64,2129,160781,17665,138293,156744,113,257,21792,5377,144973]

theorem envBound37047 : H12AffineFastState.Bounded env37047 := by
  intro p hp
  have h : env37047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37046_37047 : H12AffineEnvironment.transform 14 8461 env37046 = env37047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env37046 == env37047) = true)

theorem identity37047 : scanCanonicalize (H12AffineFastState.compose env37047 (packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37047 : packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env37048 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,29963,131072,138293,1025,8460,160013,144444,155916,21762,8193,16,2049,160781,17665,138293,156696,33,257,21792,5377,144925]

theorem envBound37048 : H12AffineFastState.Bounded env37048 := by
  intro p hp
  have h : env37048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37047_37048 : H12AffineEnvironment.transform 5 16 env37047 = env37048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37047 == env37048) = true)

theorem identity37048 : scanCanonicalize (H12AffineFastState.compose env37048 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37048 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env37049 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,131072,138293,1025,8460,140300,144444,144397,3,8193,16,2049,139532,4096,138293,143641,33,257,33,5377,144925]

theorem envBound37049 : H12AffineFastState.Bounded env37049 := by
  intro p hp
  have h : env37049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37048_37049 : H12AffineEnvironment.transform 13 5377 env37048 = env37049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37048 == env37049) = true)

theorem identity37049 : scanCanonicalize (H12AffineFastState.compose env37049 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 10557) := by decide +kernel

theorem selectedBound37049 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env37050 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8461,8202,10557,13576,1025,8460,3377,7425,7472,3,8193,16,2049,2097,4096,13576,6180,33,257,33,5377,7968]

theorem envBound37050 : H12AffineFastState.Bounded env37050 := by
  intro p hp
  have h : env37050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37049_37050 : H12AffineEnvironment.transform 16 10557 env37049 = env37050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 10557 env37049 == env37050) = true)

theorem identity37050 : scanCanonicalize (H12AffineFastState.compose env37050 (packedSelected [0,3,5,6,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound37050 : packedSelected [0,3,5,6,7,10] rootPS < 2^1333 := by decide +kernel

def env37051 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,4380,5377,4113,4374,6177,1044,1025,4112,3377,7425,7472,3,4381,16,2049,2097,4096,1044,6180,33,257,33,5377,7968]

theorem envBound37051 : H12AffineFastState.Bounded env37051 := by
  intro p hp
  have h : env37051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37050_37051 : H12AffineEnvironment.transform 12 4380 env37050 = env37051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env37050 == env37051) = true)

theorem identity37051 : scanCanonicalize (H12AffineFastState.compose env37051 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound37051 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env37052 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,17,269,1296,0,263,2096,1044,1025,1,3377,3344,3361,3,268,16,2049,2097,17,1044,2101,33,257,33,1296,3889]

theorem envBound37052 : H12AffineFastState.Bounded env37052 := by
  intro p hp
  have h : env37052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37051_37052 : H12AffineEnvironment.transform 11 17 env37051 = env37052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37051 == env37052) = true)

theorem identity37052 : scanCanonicalize (H12AffineFastState.compose env37052 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound37052 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env37053 : List Nat := [2,4,8,16,32,16,9,256,512,256,2048,17,269,16,0,263,2096,276,257,1,2097,2064,2081,3,268,16,2049,2097,17,276,2101,33,257,33,16,2609]

theorem envBound37053 : H12AffineFastState.Bounded env37053 := by
  intro p hp
  have h : env37053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37052_37053 : H12AffineEnvironment.transform 9 256 env37052 = env37053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env37052 == env37053) = true)

theorem identity37053 : scanCanonicalize (H12AffineFastState.compose env37053 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37053 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env37054 : List Nat := [2,4,8,16,32,16,9,256,512,256,0,17,269,16,0,263,48,276,257,1,49,16,33,3,268,16,1,49,17,276,53,33,257,33,16,561]

theorem envBound37054 : H12AffineFastState.Bounded env37054 := by
  intro p hp
  have h : env37054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37053_37054 : H12AffineEnvironment.transform 10 0 env37053 = env37054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37053 == env37054) = true)

def env37055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180360,98781,8328,64,43476,185737,17665,262281,181573,400453,257,21792,46213,254610]

theorem envBound37055 : H12AffineFastState.Bounded env37055 := by
  intro p hp
  have h : env37055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37025_37055 : H12AffineEnvironment.transform 21 272513 env37025 = env37055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37025 == env37055) = true)

theorem identity37055 : scanCanonicalize (H12AffineFastState.compose env37055 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound37055 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,115871,272513,120014,98781,8328,64,43476,115151,17665,262281,119043,329731,257,21792,46213,63188]

theorem envBound37056 : H12AffineFastState.Bounded env37056 := by
  intro p hp
  have h : env37056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37055_37056 : H12AffineEnvironment.transform 16 70726 env37055 = env37056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env37055 == env37056) = true)

def env37057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,115871,33,120014,98781,8328,64,43476,115151,17665,10281,119043,73891,257,21792,46213,63188]

theorem envBound37057 : H12AffineFastState.Bounded env37057 := by
  intro p hp
  have h : env37057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37056_37057 : H12AffineEnvironment.transform 17 10400 env37056 = env37057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37056 == env37057) = true)

theorem identity37057 : scanCanonicalize (H12AffineFastState.compose env37057 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound37057 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env37058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,65536,70726,10400,1025,32769,110787,33,106642,98781,8328,64,43476,112019,12637,10281,107871,73891,257,8572,46213,33416]

theorem envBound37058 : H12AffineFastState.Bounded env37058 := by
  intro p hp
  have h : env37058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37057_37058 : H12AffineEnvironment.transform 13 13404 env37057 = env37058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env37057 == env37058) = true)

theorem identity37058 : scanCanonicalize (H12AffineFastState.compose env37058 (packedSelected [0,1,5,8,9,16,17,18,20,22,23,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound37058 : packedSelected [0,1,5,8,9,16,17,18,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env37059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,343,5393,10400,1025,32769,45460,33,41413,32906,8328,64,43476,46276,12637,10281,41992,8692,257,8572,46213,33416]

theorem envBound37059 : H12AffineFastState.Bounded env37059 := by
  intro p hp
  have h : env37059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37058_37059 : H12AffineEnvironment.transform 15 343 env37058 = env37059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env37058 == env37059) = true)

theorem identity37059 : scanCanonicalize (H12AffineFastState.compose env37059 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37059 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env37060 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,343,5393,10281,1025,32769,45341,33,41292,32771,8193,64,43357,46157,12637,10281,41992,8573,257,8572,46092,33281]

theorem envBound37060 : H12AffineFastState.Bounded env37060 := by
  intro p hp
  have h : env37060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37059_37060 : H12AffineEnvironment.transform 6 9 env37059 = env37060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37059 == env37060) = true)

theorem identity37060 : scanCanonicalize (H12AffineFastState.compose env37060 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37060 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,343,5393,10281,1025,8540,4160,33,17,8542,8193,64,2048,5392,12637,10281,1365,8573,257,8572,5457,9052]

theorem envBound37061 : H12AffineFastState.Bounded env37061 := by
  intro p hp
  have h : env37061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37060_37061 : H12AffineEnvironment.transform 14 8541 env37060 = env37061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37060 == env37061) = true)

theorem identity37061 : scanCanonicalize (H12AffineFastState.compose env37061 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound37061 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,373,343,5393,2049,1025,372,4160,33,17,374,41,64,2048,5392,4469,2049,1365,341,257,340,5457,884]

theorem envBound37062 : H12AffineFastState.Bounded env37062 := by
  intro p hp
  have h : env37062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37061_37062 : H12AffineEnvironment.transform 12 40 env37061 = env37062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env37061 == env37062) = true)

theorem identity37062 : scanCanonicalize (H12AffineFastState.compose env37062 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound37062 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37063 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,0,34,5220,2049,1025,1,4160,33,17,3,41,64,2048,5221,4096,2049,1056,32,116,33,5156,513]

theorem envBound37063 : H12AffineFastState.Bounded env37063 := by
  intro p hp
  have h : env37063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37062_37063 : H12AffineEnvironment.transform 7 117 env37062 = env37063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env37062 == env37063) = true)

theorem identity37063 : scanCanonicalize (H12AffineFastState.compose env37063 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound37063 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37064 : List Nat := [2,4,8,16,32,64,9,117,512,1024,523,4096,40,5236,0,34,5220,522,1025,1,4160,33,17,3,41,64,523,5221,4096,522,1056,32,116,33,5156,513]

theorem envBound37064 : H12AffineFastState.Bounded env37064 := by
  intro p hp
  have h : env37064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37063_37064 : H12AffineEnvironment.transform 10 523 env37063 = env37064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env37063 == env37064) = true)

theorem identity37064 : scanCanonicalize (H12AffineFastState.compose env37064 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37064 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37065 : List Nat := [2,4,8,16,32,17,9,36,512,1024,523,4096,40,5157,0,34,5173,522,1025,1,4113,33,17,3,41,17,523,5172,4096,522,1056,32,37,33,5156,513]

theorem envBound37065 : H12AffineFastState.Bounded env37065 := by
  intro p hp
  have h : env37065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37064_37065 : H12AffineEnvironment.transform 5 17 env37064 = env37065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37064 == env37065) = true)

theorem identity37065 : scanCanonicalize (H12AffineFastState.compose env37065 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37065 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37066 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,4096,9,5124,0,3,5140,522,1025,1,4113,0,17,3,8,17,523,5141,4096,522,1025,1,4,0,5125,513]

theorem envBound37066 : H12AffineFastState.Bounded env37066 := by
  intro p hp
  have h : env37066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37065_37066 : H12AffineEnvironment.transform 4 1 env37065 = env37066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37065 == env37066) = true)

def env37067 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,16,9,1044,0,3,1028,522,1025,1,1,0,17,3,8,17,523,1029,16,522,1025,1,4,0,1045,513]

theorem envBound37067 : H12AffineFastState.Bounded env37067 := by
  intro p hp
  have h : env37067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37066_37067 : H12AffineEnvironment.transform 11 16 env37066 = env37067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env37066 == env37067) = true)

theorem identity37067 : scanCanonicalize (H12AffineFastState.compose env37067 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound37067 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37068 : List Nat := [2,4,8,16,1,17,9,5,512,1,523,16,9,21,0,3,5,522,0,1,1,0,17,3,8,17,523,4,16,522,0,1,4,0,20,513]

theorem envBound37068 : H12AffineFastState.Bounded env37068 := by
  intro p hp
  have h : env37068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37067_37068 : H12AffineEnvironment.transform 9 1 env37067 = env37068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env37067 == env37068) = true)

def env37069 : List Nat := [2,4,8,4,1,5,9,5,512,1,523,4,9,1,0,3,5,522,0,1,1,0,5,3,8,5,523,4,4,522,0,1,4,0,0,513]

theorem envBound37069 : H12AffineFastState.Bounded env37069 := by
  intro p hp
  have h : env37069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37068_37069 : H12AffineEnvironment.transform 3 4 env37068 = env37069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37068 == env37069) = true)

theorem identity37069 : scanCanonicalize (H12AffineFastState.compose env37069 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound37069 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37070 : List Nat := [2,4,8,4,1,5,9,5,9,1,2,4,9,1,0,3,5,3,0,1,1,0,5,3,8,5,2,4,4,3,0,1,4,0,0,8]

theorem envBound37070 : H12AffineFastState.Bounded env37070 := by
  intro p hp
  have h : env37070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37069_37070 : H12AffineEnvironment.transform 8 9 env37069 = env37070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env37069 == env37070) = true)

def leafEnv37070 : List Nat := [2,4,8,4,1,5,9,5,9,1,2,4,9,1,0,3,5,3,0,1,1,0,5,3,0,8,1,5,2,4,4,3,0,1,4,0,4,2,0,8,1,0,0]

def active37070 : List Nat := [0,1,2]

def tree37070 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37070 : H12WitnessSearch.Good tree37070 := H12GlobalWitnessIndex.good

theorem leafIdentity37070 : H12AffineFastState.composeSystem env37070 rootObs = leafEnv37070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37070 rootObs == leafEnv37070) = true)

theorem terminalChecked37070 : H12PackedTerminal.terminalCheckFast leafEnv37070 active37070 tree37070 = true := by decide +kernel

def env37071 : List Nat := [2,4,8,5,1,4,9,5,512,1,523,5,9,0,0,3,5,522,0,1,1,0,4,3,8,4,523,4,5,522,0,1,4,0,1,513]

theorem envBound37071 : H12AffineFastState.Bounded env37071 := by
  intro p hp
  have h : env37071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37068_37071 : H12AffineEnvironment.transform 3 5 env37068 = env37071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env37068 == env37071) = true)

theorem identity37071 : scanCanonicalize (H12AffineFastState.compose env37071 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound37071 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37072 : List Nat := [1,4,8,5,1,4,9,5,512,1,520,5,9,0,0,0,5,521,0,1,1,0,4,0,8,4,520,4,5,521,0,1,4,0,1,513]

theorem envBound37072 : H12AffineFastState.Bounded env37072 := by
  intro p hp
  have h : env37072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37071_37072 : H12AffineEnvironment.transform 0 1 env37071 = env37072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env37071 == env37072) = true)

def leafEnv37072 : List Nat := [1,4,8,5,1,4,9,5,512,1,520,5,9,0,0,0,5,521,0,1,1,0,4,0,0,8,1,4,520,4,5,521,0,1,4,0,4,1,1,513,1,0,0]

def active37072 : List Nat := [1,2,8]

def tree37072 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37072 : H12WitnessSearch.Good tree37072 := H12GlobalWitnessIndex.good

theorem leafIdentity37072 : H12AffineFastState.composeSystem env37072 rootObs = leafEnv37072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37072 rootObs == leafEnv37072) = true)

theorem terminalChecked37072 : H12PackedTerminal.terminalCheckFast leafEnv37072 active37072 tree37072 = true := by decide +kernel

def env37073 : List Nat := [2,4,8,16,1,17,9,5,512,1024,523,17,9,1045,0,3,1029,522,1025,1,0,0,17,3,8,17,523,1028,17,522,1025,1,4,0,1044,513]

theorem envBound37073 : H12AffineFastState.Bounded env37073 := by
  intro p hp
  have h : env37073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37066_37073 : H12AffineEnvironment.transform 11 17 env37066 = env37073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37066 == env37073) = true)

theorem identity37073 : scanCanonicalize (H12AffineFastState.compose env37073 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound37073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37074 : List Nat := [2,4,8,4,1,5,9,5,512,1024,523,5,9,1025,0,3,1029,522,1025,1,0,0,5,3,8,5,523,1028,5,522,1025,1,4,0,1024,513]

theorem envBound37074 : H12AffineFastState.Bounded env37074 := by
  intro p hp
  have h : env37074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37073_37074 : H12AffineEnvironment.transform 3 4 env37073 = env37074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env37073 == env37074) = true)

def env37075 : List Nat := [2,4,8,4,1,5,9,5,512,0,523,5,9,1,0,3,5,522,1,1,0,0,5,3,8,5,523,4,5,522,1,1,4,0,0,513]

theorem envBound37075 : H12AffineFastState.Bounded env37075 := by
  intro p hp
  have h : env37075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37074_37075 : H12AffineEnvironment.transform 9 0 env37074 = env37075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env37074 == env37075) = true)

theorem identity37075 : scanCanonicalize (H12AffineFastState.compose env37075 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37075 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37076 : List Nat := [0,4,8,4,1,5,9,5,512,0,521,5,9,1,0,1,5,520,1,1,0,0,5,1,8,5,521,4,5,520,1,1,4,0,0,513]

theorem envBound37076 : H12AffineFastState.Bounded env37076 := by
  intro p hp
  have h : env37076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37075_37076 : H12AffineEnvironment.transform 0 0 env37075 = env37076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37075 == env37076) = true)

def leafEnv37076 : List Nat := [0,4,8,4,1,5,9,5,512,0,521,5,9,1,0,1,5,520,1,1,0,0,5,1,1,8,1,5,521,4,5,520,1,1,4,0,4,0,0,513,1,1,0]

def active37076 : List Nat := [1,2,8]

def tree37076 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37076 : H12WitnessSearch.Good tree37076 := H12GlobalWitnessIndex.good

theorem leafIdentity37076 : H12AffineFastState.composeSystem env37076 rootObs = leafEnv37076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37076 rootObs == leafEnv37076) = true)

theorem terminalChecked37076 : H12PackedTerminal.terminalCheckFast leafEnv37076 active37076 tree37076 = true := by decide +kernel

def env37077 : List Nat := [2,4,8,4,1,5,9,5,512,1,523,5,9,0,0,3,4,522,0,1,0,0,5,3,8,5,523,5,5,522,0,1,4,0,1,513]

theorem envBound37077 : H12AffineFastState.Bounded env37077 := by
  intro p hp
  have h : env37077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37074_37077 : H12AffineEnvironment.transform 9 1 env37074 = env37077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env37074 == env37077) = true)

theorem identity37077 : scanCanonicalize (H12AffineFastState.compose env37077 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound37077 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37078 : List Nat := [2,4,8,4,1,5,9,5,8,1,3,5,9,0,0,3,4,2,0,1,0,0,5,3,8,5,3,5,5,2,0,1,4,0,1,9]

theorem envBound37078 : H12AffineFastState.Bounded env37078 := by
  intro p hp
  have h : env37078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37077_37078 : H12AffineEnvironment.transform 8 8 env37077 = env37078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env37077 == env37078) = true)

def leafEnv37078 : List Nat := [2,4,8,4,1,5,9,5,8,1,3,5,9,0,0,3,4,2,0,1,0,0,5,3,0,8,1,5,3,5,5,2,0,1,4,0,4,2,1,9,1,1,0]

def active37078 : List Nat := [0,1,2]

def tree37078 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37078 : H12WitnessSearch.Good tree37078 := H12GlobalWitnessIndex.good

theorem leafIdentity37078 : H12AffineFastState.composeSystem env37078 rootObs = leafEnv37078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37078 rootObs == leafEnv37078) = true)

theorem terminalChecked37078 : H12PackedTerminal.terminalCheckFast leafEnv37078 active37078 tree37078 = true := by decide +kernel

def env37079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,115871,32,120014,98781,8328,64,43476,115151,17665,10280,119043,73890,257,21792,46213,63188]

theorem envBound37079 : H12AffineFastState.Bounded env37079 := by
  intro p hp
  have h : env37079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37056_37079 : H12AffineEnvironment.transform 17 10401 env37056 = env37079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37056 == env37079) = true)

theorem identity37079 : scanCanonicalize (H12AffineFastState.compose env37079 (packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 41090) := by decide +kernel

theorem selectedBound37079 : packedSelected [1,3,10,12,15,16,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env37080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41090,46276,10401,1025,32769,25629,32,29772,8543,8328,64,43476,24909,17665,10280,29057,32800,257,21792,46213,63188]

theorem envBound37080 : H12AffineFastState.Bounded env37080 := by
  intro p hp
  have h : env37080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37079_37080 : H12AffineEnvironment.transform 15 41090 env37079 = env37080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41090 env37079 == env37080) = true)

theorem identity37080 : scanCanonicalize (H12AffineFastState.compose env37080 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound37080 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env37081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,21727,16537,10401,1025,29788,25629,32,29772,8543,8328,64,23945,24909,17665,10280,29057,29821,257,21792,16600,649]

theorem envBound37081 : H12AffineFastState.Bounded env37081 := by
  intro p hp
  have h : env37081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37080_37081 : H12AffineEnvironment.transform 14 29789 env37080 = env37081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37080 == env37081) = true)

theorem identity37081 : scanCanonicalize (H12AffineFastState.compose env37081 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound37081 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env37082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,80,8402,13460,10401,1025,81,4112,32,65,8543,8328,64,10628,5440,12556,10280,1420,112,257,8493,13525,649]

theorem envBound37082 : H12AffineFastState.Bounded env37082 := by
  intro p hp
  have h : env37082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37081_37082 : H12AffineEnvironment.transform 13 13325 env37081 = env37082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env37081 == env37082) = true)

theorem identity37082 : scanCanonicalize (H12AffineFastState.compose env37082 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound37082 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env37083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5513,80,342,5392,2341,1025,81,4112,32,65,219,268,64,2048,5440,4232,2476,1420,112,257,169,5457,649]

theorem envBound37083 : H12AffineFastState.Bounded env37083 := by
  intro p hp
  have h : env37083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37082_37083 : H12AffineEnvironment.transform 12 388 env37082 = env37083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env37082 == env37083) = true)

theorem identity37083 : scanCanonicalize (H12AffineFastState.compose env37083 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound37083 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37084 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,120,5237,80,170,5356,2265,1025,81,4112,32,65,219,240,64,2048,5308,4232,2128,1136,112,253,169,5293,649]

theorem envBound37084 : H12AffineFastState.Bounded env37084 := by
  intro p hp
  have h : env37084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37083_37084 : H12AffineEnvironment.transform 7 252 env37083 = env37084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env37083 == env37084) = true)

theorem identity37084 : scanCanonicalize (H12AffineFastState.compose env37084 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37084 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37085 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,40,5157,0,170,5308,2185,1025,1,4112,32,17,139,160,16,2048,5308,4232,2048,1056,32,173,169,5293,649]

theorem envBound37085 : H12AffineFastState.Bounded env37085 := by
  intro p hp
  have h : env37085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37084_37085 : H12AffineEnvironment.transform 5 16 env37084 = env37085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37084 == env37085) = true)

theorem identity37085 : scanCanonicalize (H12AffineFastState.compose env37085 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound37085 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37086 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,3245,40,2184,0,170,2065,2185,1025,1,3261,32,17,139,160,16,2048,2065,3109,2048,1056,32,173,169,2048,649]

theorem envBound37086 : H12AffineFastState.Bounded env37086 := by
  intro p hp
  have h : env37086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37085_37086 : H12AffineEnvironment.transform 11 3245 env37085 = env37086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env37085 == env37086) = true)

theorem identity37086 : scanCanonicalize (H12AffineFastState.compose env37086 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound37086 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env37087 : List Nat := [2,4,8,16,32,16,128,172,512,1024,1076,153,40,1212,0,170,1061,1213,1025,1,137,32,17,139,160,16,1076,1061,17,1076,1056,32,173,169,1076,649]

theorem envBound37087 : H12AffineFastState.Bounded env37087 := by
  intro p hp
  have h : env37087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37086_37087 : H12AffineEnvironment.transform 10 1076 env37086 = env37087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env37086 == env37087) = true)

theorem identity37087 : scanCanonicalize (H12AffineFastState.compose env37087 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37087 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37088 : List Nat := [2,4,8,0,32,0,128,172,512,1024,1060,137,40,1196,0,170,1061,1197,1025,1,137,32,1,139,160,0,1060,1061,1,1060,1056,32,173,169,1060,649]

theorem envBound37088 : H12AffineFastState.Bounded env37088 := by
  intro p hp
  have h : env37088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37087_37088 : H12AffineEnvironment.transform 3 0 env37087 = env37088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37087 == env37088) = true)

theorem identity37088 : scanCanonicalize (H12AffineFastState.compose env37088 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound37088 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env37089 : List Nat := [2,4,8,0,32,0,128,172,512,37,1,137,40,137,0,170,0,136,36,1,137,32,1,139,160,0,1,0,1,1,5,32,173,169,1,649]

theorem envBound37089 : H12AffineFastState.Bounded env37089 := by
  intro p hp
  have h : env37089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37088_37089 : H12AffineEnvironment.transform 9 37 env37088 = env37089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env37088 == env37089) = true)

theorem identity37089 : scanCanonicalize (H12AffineFastState.compose env37089 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37089 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37090 : List Nat := [2,4,8,0,32,0,8,36,512,37,1,1,40,1,0,34,0,0,36,1,1,32,1,3,40,0,1,0,1,1,5,32,37,33,1,513]

theorem envBound37090 : H12AffineFastState.Bounded env37090 := by
  intro p hp
  have h : env37090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37089_37090 : H12AffineEnvironment.transform 6 8 env37089 = env37090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37089 == env37090) = true)

theorem identity37090 : scanCanonicalize (H12AffineFastState.compose env37090 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound37090 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37091 : List Nat := [2,4,8,0,32,0,8,36,0,37,1,1,40,1,0,34,0,0,36,1,1,32,1,3,40,0,1,0,1,1,5,32,37,33,1,1]

theorem envBound37091 : H12AffineFastState.Bounded env37091 := by
  intro p hp
  have h : env37091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37090_37091 : H12AffineEnvironment.transform 8 0 env37090 = env37091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env37090 == env37091) = true)

theorem identity37091 : scanCanonicalize (H12AffineFastState.compose env37091 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37091 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37092 : List Nat := [2,4,2,0,32,0,2,36,0,37,1,1,34,1,0,34,0,0,36,1,1,32,1,3,34,0,1,0,1,1,5,32,37,33,1,1]

theorem envBound37092 : H12AffineFastState.Bounded env37092 := by
  intro p hp
  have h : env37092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37091_37092 : H12AffineEnvironment.transform 2 2 env37091 = env37092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37091 == env37092) = true)

def env37093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,4194304,180361,98780,8328,64,4489557,185736,17664,262280,181573,4338885,257,21792,46213,254610]

theorem envBound37093 : H12AffineFastState.Bounded env37093 := by
  intro p hp
  have h : env37093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37024_37093 : H12AffineEnvironment.transform 22 180361 env37024 = env37093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180361 env37024 == env37093) = true)

def env37094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272512,180361,98780,8328,64,43477,185736,17664,262280,181573,400453,257,21792,46213,254610]

theorem envBound37094 : H12AffineFastState.Bounded env37094 := by
  intro p hp
  have h : env37094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37093_37094 : H12AffineEnvironment.transform 21 272512 env37093 = env37094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37093 == env37094) = true)

theorem identity37094 : scanCanonicalize (H12AffineFastState.compose env37094 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37094 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,184537,272512,180361,41431,8328,64,43477,185736,17664,262280,181573,400453,257,21792,46213,180889]

theorem envBound37095 : H12AffineFastState.Bounded env37095 := by
  intro p hp
  have h : env37095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37094_37095 : H12AffineEnvironment.transform 15 8203 env37094 = env37095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37094 == env37095) = true)

theorem identity37095 : scanCanonicalize (H12AffineFastState.compose env37095 (packedSelected [4,7,9,12,15,27,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37095 : packedSelected [4,7,9,12,15,27,38,41] rootPS < 2^1333 := by decide +kernel

def env37096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,37065,272512,32921,41431,8328,64,43477,38296,17664,262280,34133,285781,257,21792,46213,33417]

theorem envBound37096 : H12AffineFastState.Bounded env37096 := by
  intro p hp
  have h : env37096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37095_37096 : H12AffineEnvironment.transform 16 16400 env37095 = env37096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37095 == env37096) = true)

theorem identity37096 : scanCanonicalize (H12AffineFastState.compose env37096 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 64889) := by decide +kernel

theorem selectedBound37096 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env37097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,64889,1025,32769,37065,54777,32921,41431,8328,64,43477,38296,17664,65009,34133,41260,257,21792,46213,33417]

theorem envBound37097 : H12AffineFastState.Bounded env37097 := by
  intro p hp
  have h : env37097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37096_37097 : H12AffineEnvironment.transform 17 64889 env37096 = env37097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64889 env37096 == env37097) = true)

theorem identity37097 : scanCanonicalize (H12AffineFastState.compose env37097 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound37097 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env37098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21840,8203,16400,10281,1025,21841,17817,169,21961,29831,8328,64,31877,16584,17664,10401,20485,29820,257,21792,25045,22489]

theorem envBound37098 : H12AffineFastState.Bounded env37098 := by
  intro p hp
  have h : env37098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37097_37098 : H12AffineEnvironment.transform 14 21840 env37097 = env37098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env37097 == env37098) = true)

def env37099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184537,272513,180361,98780,8328,64,43476,185736,17664,262280,181573,400452,257,21792,46213,254610]

theorem envBound37099 : H12AffineFastState.Bounded env37099 := by
  intro p hp
  have h : env37099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37093_37099 : H12AffineEnvironment.transform 21 272513 env37093 = env37099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37093 == env37099) = true)

theorem identity37099 : scanCanonicalize (H12AffineFastState.compose env37099 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123027) := by decide +kernel

theorem selectedBound37099 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123027,262144,1025,32769,77898,272513,73754,98780,8328,64,43476,79131,17664,262280,75222,392407,257,21792,46213,513]

theorem envBound37100 : H12AffineFastState.Bounded env37100 := by
  intro p hp
  have h : env37100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37099_37100 : H12AffineEnvironment.transform 16 123027 env37099 = env37100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123027 env37099 == env37100) = true)

def env37101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,65536,90259,262144,1025,1,77898,272513,73754,66012,8328,64,10708,79131,17664,262280,75222,359639,257,21792,13445,513]

theorem envBound37101 : H12AffineFastState.Bounded env37101 := by
  intro p hp
  have h : env37101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37100_37101 : H12AffineEnvironment.transform 14 0 env37100 = env37101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37100 == env37101) = true)

theorem identity37101 : scanCanonicalize (H12AffineFastState.compose env37101 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound37101 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env37102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16401,262144,1025,1,4296,272513,152,8542,8328,64,10708,5529,17664,262280,1364,285781,257,21792,13445,513]

theorem envBound37102 : H12AffineFastState.Bounded env37102 := by
  intro p hp
  have h : env37102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37101_37102 : H12AffineEnvironment.transform 15 8322 env37101 = env37102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env37101 == env37102) = true)

theorem identity37102 : scanCanonicalize (H12AffineFastState.compose env37102 (packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound37102 : packedSelected [1,3,4,5,8,9,10,14,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8322,16401,10281,1025,1,4296,168,152,8542,8328,64,10708,5529,17664,10401,1364,29820,257,21792,13445,513]

theorem envBound37103 : H12AffineFastState.Bounded env37103 := by
  intro p hp
  have h : env37103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37102_37103 : H12AffineEnvironment.transform 17 10281 env37102 = env37103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37102 == env37103) = true)

theorem identity37103 : scanCanonicalize (H12AffineFastState.compose env37103 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37103 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env37104 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,0,8322,5392,10281,1025,1,4296,168,152,8542,8328,64,10708,5529,4097,10401,1364,8573,257,33,13445,513]

theorem envBound37104 : H12AffineFastState.Bounded env37104 := by
  intro p hp
  have h : env37104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37103_37104 : H12AffineEnvironment.transform 13 5377 env37103 = env37104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37103 == env37104) = true)

theorem identity37104 : scanCanonicalize (H12AffineFastState.compose env37104 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37104 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37105 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,0,479,5392,2420,1025,1,4296,168,152,3,469,64,2185,5529,4097,2556,1364,32,257,33,5592,513]

theorem envBound37105 : H12AffineFastState.Bounded env37105 := by
  intro p hp
  have h : env37105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37104_37105 : H12AffineEnvironment.transform 12 349 env37104 = env37105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37104 == env37105) = true)

theorem identity37105 : scanCanonicalize (H12AffineFastState.compose env37105 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37105 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5392,2420,1025,1,4161,33,17,3,348,64,2048,5392,4097,2421,1364,32,257,33,5457,513]

theorem envBound37106 : H12AffineFastState.Bounded env37106 := by
  intro p hp
  have h : env37106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37105_37106 : H12AffineEnvironment.transform 6 9 env37105 = env37106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37105 == env37106) = true)

theorem identity37106 : scanCanonicalize (H12AffineFastState.compose env37106 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound37106 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37107 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2075,349,3354,0,342,3339,2420,1025,1,2138,33,17,3,348,64,2048,3339,2074,2421,1364,32,257,33,3402,513]

theorem envBound37107 : H12AffineFastState.Bounded env37107 := by
  intro p hp
  have h : env37107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37106_37107 : H12AffineEnvironment.transform 11 2075 env37106 = env37107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env37106 == env37107) = true)

theorem identity37107 : scanCanonicalize (H12AffineFastState.compose env37107 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 111) := by decide +kernel

theorem selectedBound37107 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37108 : List Nat := [2,4,8,16,32,64,9,111,512,1024,2048,2075,50,3189,0,57,3172,2075,1025,1,2138,33,17,3,51,64,2048,3172,2074,2074,1083,32,110,33,3109,513]

theorem envBound37108 : H12AffineFastState.Bounded env37108 := by
  intro p hp
  have h : env37108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37107_37108 : H12AffineEnvironment.transform 7 111 env37107 = env37108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 111 env37107 == env37108) = true)

theorem identity37108 : scanCanonicalize (H12AffineFastState.compose env37108 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37108 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37109 : List Nat := [2,4,8,16,0,64,9,79,512,1024,2048,2075,18,3157,0,25,3140,2075,1025,1,2138,1,17,3,19,64,2048,3140,2074,2074,1051,0,78,1,3077,513]

theorem envBound37109 : H12AffineFastState.Bounded env37109 := by
  intro p hp
  have h : env37109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37108_37109 : H12AffineEnvironment.transform 4 0 env37108 = env37109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37108 == env37109) = true)

def env37110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,65536,90258,262144,1025,0,77898,272513,73754,66013,8328,64,10709,79131,17664,262280,75222,359638,257,21792,13444,513]

theorem envBound37110 : H12AffineFastState.Bounded env37110 := by
  intro p hp
  have h : env37110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37100_37110 : H12AffineEnvironment.transform 14 1 env37100 = env37110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37100 == env37110) = true)

theorem identity37110 : scanCanonicalize (H12AffineFastState.compose env37110 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37110 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env37111 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,262144,1025,0,77898,272392,73754,65876,8193,64,10588,79131,17664,262145,75103,359519,257,21792,13325,513]

theorem envBound37111 : H12AffineFastState.Bounded env37111 := by
  intro p hp
  have h : env37111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37110_37111 : H12AffineEnvironment.transform 6 9 env37110 = env37111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37110 == env37111) = true)

theorem identity37111 : scanCanonicalize (H12AffineFastState.compose env37111 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound37111 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env37112 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,90139,67618,1025,0,77898,73770,73754,65876,8193,64,10588,79131,17664,67619,75103,29821,257,21792,13325,513]

theorem envBound37112 : H12AffineFastState.Bounded env37112 := by
  intro p hp
  have h : env37112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37111_37112 : H12AffineEnvironment.transform 17 67618 env37111 = env37112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env37111 == env37112) = true)

def env37113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound37113 : H12AffineFastState.Bounded env37113 := by
  intro p hp
  have h : env37113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36382_37113 : H12AffineEnvironment.transform 25 65 env36382 = env37113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env36382 == env37113) = true)

def env37114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound37114 : H12AffineFastState.Bounded env37114 := by
  intro p hp
  have h : env37114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37113_37114 : H12AffineEnvironment.transform 26 30393344 env37113 = env37114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env37113 == env37114) = true)

def env37115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound37115 : H12AffineFastState.Bounded env37115 := by
  intro p hp
  have h : env37115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37114_37115 : H12AffineEnvironment.transform 18 1024 env37114 = env37115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env37114 == env37115) = true)

theorem identity37115 : scanCanonicalize (H12AffineFastState.compose env37115 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493493) := by decide +kernel

theorem selectedBound37115 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37116 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493493,16777216,8328,65,23186485,18973836,416100,2149428,19367972,23160257,256,17287321,17246524,19312627]

theorem envBound37116 : H12AffineFastState.Bounded env37116 := by
  intro p hp
  have h : env37116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37115_37116 : H12AffineEnvironment.transform 22 2493493 env37115 = env37116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493493 env37115 == env37116) = true)

def env37117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493493,499128,8328,65,6705549,2496820,416100,2149428,2102684,6748281,256,21793,46212,2175563]

theorem envBound37117 : H12AffineFastState.Bounded env37117 := by
  intro p hp
  have h : env37117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37116_37117 : H12AffineEnvironment.transform 23 499128 env37116 = env37117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499128 env37116 == env37117) = true)

def env37118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493493,499128,8328,65,2396605,2496820,416100,2149428,2102684,2373705,256,21793,46212,2175563]

theorem envBound37118 : H12AffineFastState.Bounded env37118 := by
  intro p hp
  have h : env37118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37117_37118 : H12AffineEnvironment.transform 21 180272 env37117 = env37118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env37117 == env37118) = true)

def env37119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400501,499128,8328,65,295421,395636,416100,56436,1500,272393,256,21793,46212,74251]

theorem envBound37119 : H12AffineFastState.Bounded env37119 := by
  intro p hp
  have h : env37119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37118_37119 : H12AffineEnvironment.transform 20 4160 env37118 = env37119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37118 == env37119) = true)

theorem identity37119 : scanCanonicalize (H12AffineFastState.compose env37119 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound37119 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,180272,120014,21763,8328,65,215366,115151,102879,56436,1500,254130,256,21793,46212,74251]

theorem envBound37120 : H12AffineFastState.Bounded env37120 := by
  intro p hp
  have h : env37120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37119_37120 : H12AffineEnvironment.transform 17 247995 env37119 = env37120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env37119 == env37120) = true)

def env37121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130175,1024,32769,4160,62708,120014,21763,8328,65,97666,115151,102879,56436,1500,119926,256,21793,46212,74251]

theorem envBound37121 : H12AffineFastState.Bounded env37121 := by
  intro p hp
  have h : env37121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37120_37121 : H12AffineEnvironment.transform 16 13508 env37120 = env37121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env37120 == env37121) = true)

def env37122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130175,1024,32769,4160,62588,119878,21763,8192,65,97546,115015,102743,56436,1364,119926,256,21793,46092,74251]

theorem envBound37122 : H12AffineFastState.Bounded env37122 := by
  intro p hp
  have h : env37122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37121_37122 : H12AffineEnvironment.transform 6 8 env37121 = env37122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37121 == env37122) = true)

theorem identity37122 : scanCanonicalize (H12AffineFastState.compose env37122 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound37122 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,13388,35188,1024,32769,4160,62588,41293,21763,8192,65,2049,46156,58460,56436,1364,41341,256,21793,46092,22272]

theorem envBound37123 : H12AffineFastState.Bounded env37123 := by
  intro p hp
  have h : env37123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37122_37123 : H12AffineEnvironment.transform 15 29963 env37122 = env37123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env37122 == env37123) = true)

theorem identity37123 : scanCanonicalize (H12AffineFastState.compose env37123 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37123 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env37124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,21590,5393,35188,1024,32769,4160,54561,32784,21763,349,65,2049,38161,50433,56436,1364,32800,256,21793,38225,22272]

theorem envBound37124 : H12AffineFastState.Bounded env37124 := by
  intro p hp
  have h : env37124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37123_37124 : H12AffineEnvironment.transform 12 349 env37123 = env37124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37123 == env37124) = true)

theorem identity37124 : scanCanonicalize (H12AffineFastState.compose env37124 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37124 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env37125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,21590,5393,2421,1024,0,4160,21792,17,21763,349,65,2049,5392,17664,23669,1364,33,256,21793,5456,22272]

theorem envBound37125 : H12AffineFastState.Bounded env37125 := by
  intro p hp
  have h : env37125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37124_37125 : H12AffineEnvironment.transform 14 1 env37124 = env37125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37124 == env37125) = true)

theorem identity37125 : scanCanonicalize (H12AffineFastState.compose env37125 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound37125 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1,1094,5393,2421,1024,0,4160,1328,17,1299,349,65,2049,5392,5392,3173,1364,33,256,1329,5456,1808]

theorem envBound37126 : H12AffineFastState.Bounded env37126 := by
  intro p hp
  have h : env37126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37125_37126 : H12AffineEnvironment.transform 13 4112 env37125 = env37126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env37125 == env37126) = true)

theorem identity37126 : scanCanonicalize (H12AffineFastState.compose env37126 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound37126 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env37127 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,349,4112,1,263,4176,2421,321,0,4160,113,17,82,349,65,2049,4177,4177,2340,21,33,256,112,4113,593]

theorem envBound37127 : H12AffineFastState.Bounded env37127 := by
  intro p hp
  have h : env37127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37126_37127 : H12AffineEnvironment.transform 9 321 env37126 = env37127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env37126 == env37127) = true)

theorem identity37127 : scanCanonicalize (H12AffineFastState.compose env37127 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound37127 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37128 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,2113,349,2129,1,263,2065,2421,321,0,2049,113,17,82,349,65,2049,2064,2064,2340,21,33,256,112,2128,593]

theorem envBound37128 : H12AffineFastState.Bounded env37128 := by
  intro p hp
  have h : env37128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37127_37128 : H12AffineEnvironment.transform 11 2113 env37127 = env37128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env37127 == env37128) = true)

def env37129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130175,1024,32769,4160,62589,119879,21763,8193,65,97547,115014,102742,56436,1365,119926,256,21793,46093,74251]

theorem envBound37129 : H12AffineFastState.Bounded env37129 := by
  intro p hp
  have h : env37129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37121_37129 : H12AffineEnvironment.transform 6 9 env37121 = env37129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37121 == env37129) = true)

theorem identity37129 : scanCanonicalize (H12AffineFastState.compose env37129 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound37129 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13389,10281,1024,32769,4160,62589,17,21763,8193,65,43357,5392,17664,56436,1365,32,256,21793,46093,63069]

theorem envBound37130 : H12AffineFastState.Bounded env37130 := by
  intro p hp
  have h : env37130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37129_37130 : H12AffineEnvironment.transform 15 54358 env37129 = env37130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env37129 == env37130) = true)

def env37131 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130174,1024,32769,4160,62709,120014,21763,8328,65,97667,115151,102879,56436,1500,119927,256,21793,46212,74251]

theorem envBound37131 : H12AffineFastState.Bounded env37131 := by
  intro p hp
  have h : env37131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37120_37131 : H12AffineEnvironment.transform 16 13509 env37120 = env37131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env37120 == env37131) = true)

def env37132 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130174,1024,32769,4160,62589,119878,21763,8192,65,97547,115015,102743,56436,1364,119927,256,21793,46092,74251]

theorem envBound37132 : H12AffineFastState.Bounded env37132 := by
  intro p hp
  have h : env37132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37131_37132 : H12AffineEnvironment.transform 6 8 env37131 = env37132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37131 == env37132) = true)

theorem identity37132 : scanCanonicalize (H12AffineFastState.compose env37132 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37132 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37133 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,13389,89378,1024,8541,4160,21793,95514,21763,8192,65,97547,90139,77835,32040,1364,95531,256,21793,5456,74251]

theorem envBound37133 : H12AffineFastState.Bounded env37133 := by
  intro p hp
  have h : env37133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37132_37133 : H12AffineEnvironment.transform 14 8540 env37132 = env37133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37132 == env37133) = true)

theorem identity37133 : scanCanonicalize (H12AffineFastState.compose env37133 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound37133 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env37134 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,34,13389,23808,1024,8541,4160,21793,30008,21763,8192,65,32041,24633,12329,32040,1364,29961,256,21793,5456,8745]

theorem envBound37134 : H12AffineFastState.Bounded env37134 := by
  intro p hp
  have h : env37134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37133_37134 : H12AffineEnvironment.transform 15 34 env37133 = env37134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env37133 == env37134) = true)

theorem identity37134 : scanCanonicalize (H12AffineFastState.compose env37134 (packedSelected [2,4,9,11,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37134 : packedSelected [2,4,9,11,18,20] rootPS < 2^1333 := by decide +kernel

def env37135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,0,34,5393,23808,1024,1,4160,21793,21604,21763,348,65,23669,16741,4469,23668,1364,21589,256,21793,5456,885]

theorem envBound37135 : H12AffineFastState.Bounded env37135 := by
  intro p hp
  have h : env37135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37134_37135 : H12AffineEnvironment.transform 12 348 env37134 = env37135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37134 == env37135) = true)

theorem identity37135 : scanCanonicalize (H12AffineFastState.compose env37135 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37135 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37136 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,34,5393,23808,1024,1,4113,21793,21557,21763,269,16,23588,16692,4388,23589,1285,21508,256,21793,5377,804]

theorem envBound37136 : H12AffineFastState.Bounded env37136 := by
  intro p hp
  have h : env37136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37135_37136 : H12AffineEnvironment.transform 5 17 env37135 = env37136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37135 == env37136) = true)

theorem identity37136 : scanCanonicalize (H12AffineFastState.compose env37136 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37136 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env37137 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,16384,0,34,5172,23589,1024,1,4113,21508,21557,21542,40,16,23588,16401,4097,23589,1056,21508,37,21508,5156,513]

theorem envBound37137 : H12AffineFastState.Bounded env37137 := by
  intro p hp
  have h : env37137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37136_37137 : H12AffineEnvironment.transform 7 37 env37136 = env37137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37136 == env37137) = true)

theorem identity37137 : scanCanonicalize (H12AffineFastState.compose env37137 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound37137 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env37138 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,34,5172,2049,1024,1,4113,32,17,2,40,16,2048,5173,4097,2049,1056,32,37,32,5156,513]

theorem envBound37138 : H12AffineFastState.Bounded env37138 := by
  intro p hp
  have h : env37138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37137_37138 : H12AffineEnvironment.transform 13 5156 env37137 = env37138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env37137 == env37138) = true)

def env37139 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130174,1024,32769,4160,62588,119879,21763,8193,65,97546,115014,102742,56436,1365,119927,256,21793,46093,74251]

theorem envBound37139 : H12AffineFastState.Bounded env37139 := by
  intro p hp
  have h : env37139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37131_37139 : H12AffineEnvironment.transform 6 9 env37131 = env37139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37131 == env37139) = true)

theorem identity37139 : scanCanonicalize (H12AffineFastState.compose env37139 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound37139 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env37140 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,13388,10281,1024,32769,4160,62588,16,21763,8193,65,43357,5393,17665,56436,1365,32,256,21793,46093,63068]

theorem envBound37140 : H12AffineFastState.Bounded env37140 := by
  intro p hp
  have h : env37140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37139_37140 : H12AffineEnvironment.transform 15 54359 env37139 = env37140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env37139 == env37140) = true)

theorem identity37140 : scanCanonicalize (H12AffineFastState.compose env37140 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound37140 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37141 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13388,10281,1024,29788,4160,33,16,21763,8193,65,23808,5393,17665,10281,1365,32,256,21793,16464,513]

theorem envBound37141 : H12AffineFastState.Bounded env37141 := by
  intro p hp
  have h : env37141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37140_37141 : H12AffineEnvironment.transform 14 29789 env37140 = env37141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37140 == env37141) = true)

theorem identity37141 : scanCanonicalize (H12AffineFastState.compose env37141 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound37141 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env37142 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,81,8202,13388,10281,1024,80,4160,33,16,8463,8193,65,10508,5393,12557,10281,1365,32,256,8493,13404,513]

theorem envBound37142 : H12AffineFastState.Bounded env37142 := by
  intro p hp
  have h : env37142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37141_37142 : H12AffineEnvironment.transform 13 13324 env37141 = env37142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env37141 == env37142) = true)

theorem identity37142 : scanCanonicalize (H12AffineFastState.compose env37142 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37142 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env37143 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,8202,13341,10281,1024,1,4113,33,16,8463,8193,16,10508,5393,12557,10281,1284,32,256,8493,13325,513]

theorem envBound37143 : H12AffineFastState.Bounded env37143 := by
  intro p hp
  have h : env37143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37142_37143 : H12AffineEnvironment.transform 5 17 env37142 = env37143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37142 == env37143) = true)

theorem identity37143 : scanCanonicalize (H12AffineFastState.compose env37143 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37143 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env37144 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8192,13324,0,8202,13341,10281,1024,1,4113,33,16,8203,8193,16,10248,5141,12297,10281,1024,32,4,8233,13325,513]

theorem envBound37144 : H12AffineFastState.Bounded env37144 := by
  intro p hp
  have h : env37144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37143_37144 : H12AffineEnvironment.transform 7 4 env37143 = env37144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37143 == env37144) = true)

theorem identity37144 : scanCanonicalize (H12AffineFastState.compose env37144 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound37144 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37145 : List Nat := [2,4,8,16,32,17,9,4,512,1024,2048,4096,8,5124,0,2,5141,2081,1024,1,4113,33,16,3,9,16,2048,5141,4097,2081,1024,32,4,33,5125,513]

theorem envBound37145 : H12AffineFastState.Bounded env37145 := by
  intro p hp
  have h : env37145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37144_37145 : H12AffineEnvironment.transform 12 8 env37144 = env37145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env37144 == env37145) = true)

theorem identity37145 : scanCanonicalize (H12AffineFastState.compose env37145 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37145 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37146 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,4096,8,5124,0,2,5141,2048,1024,1,4113,0,16,3,9,16,2048,5141,4097,2048,1024,1,4,0,5125,513]

theorem envBound37146 : H12AffineFastState.Bounded env37146 := by
  intro p hp
  have h : env37146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37145_37146 : H12AffineEnvironment.transform 4 1 env37145 = env37146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37145 == env37146) = true)

theorem identity37146 : scanCanonicalize (H12AffineFastState.compose env37146 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound37146 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37147 : List Nat := [2,4,8,16,1,17,9,4,512,1024,523,4096,8,5124,0,2,5141,523,1024,1,4113,0,16,3,9,16,523,5141,4097,523,1024,1,4,0,5125,513]

theorem envBound37147 : H12AffineFastState.Bounded env37147 := by
  intro p hp
  have h : env37147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37146_37147 : H12AffineEnvironment.transform 10 523 env37146 = env37147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env37146 == env37147) = true)

def env37148 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180272,400500,499128,8328,65,295420,395637,416100,56437,1501,272392,256,21793,46212,74250]

theorem envBound37148 : H12AffineFastState.Bounded env37148 := by
  intro p hp
  have h : env37148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37118_37148 : H12AffineEnvironment.transform 20 4161 env37118 = env37148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37118 == env37148) = true)

theorem identity37148 : scanCanonicalize (H12AffineFastState.compose env37148 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37148 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,180272,400500,441779,8328,65,295420,395637,416100,56437,1501,272392,256,21793,46212,513]

theorem envBound37149 : H12AffineFastState.Bounded env37149 := by
  intro p hp
  have h : env37149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37148_37149 : H12AffineEnvironment.transform 15 8203 env37148 = env37149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37148 == env37149) = true)

def env37150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4161,32800,285796,327075,8328,65,295420,280933,268660,56437,1501,272392,256,21793,46212,513]

theorem envBound37150 : H12AffineFastState.Bounded env37150 := by
  intro p hp
  have h : env37150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37149_37150 : H12AffineEnvironment.transform 16 16400 env37149 = env37150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37149 == env37150) = true)

theorem identity37150 : scanCanonicalize (H12AffineFastState.compose env37150 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound37150 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,23668,1024,32769,4161,32800,16,41431,8328,65,56712,5393,17664,56437,1501,29820,256,21793,46212,513]

theorem envBound37151 : H12AffineFastState.Bounded env37151 := by
  intro p hp
  have h : env37151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37150_37151 : H12AffineEnvironment.transform 17 23668 env37150 = env37151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env37150 == env37151) = true)

theorem identity37151 : scanCanonicalize (H12AffineFastState.compose env37151 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound37151 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,8203,16400,23668,1024,136,4161,169,16,8542,8328,65,23809,5393,17664,23804,1501,29820,256,21793,13325,513]

theorem envBound37152 : H12AffineFastState.Bounded env37152 := by
  intro p hp
  have h : env37152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37151_37152 : H12AffineEnvironment.transform 14 137 env37151 = env37152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env37151 == env37152) = true)

theorem identity37152 : scanCanonicalize (H12AffineFastState.compose env37152 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound37152 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env37153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,137,479,16400,23668,1024,136,4161,169,16,138,348,65,23809,5393,17664,23804,1501,21928,256,21793,5593,513]

theorem envBound37153 : H12AffineFastState.Bounded env37153 := by
  intro p hp
  have h : env37153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37152_37153 : H12AffineEnvironment.transform 12 468 env37152 = env37153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env37152 == env37153) = true)

theorem identity37153 : scanCanonicalize (H12AffineFastState.compose env37153 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound37153 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,479,5529,2557,1024,136,4161,169,16,138,348,65,2184,5393,4233,2421,1501,33,256,168,5593,513]

theorem envBound37154 : H12AffineFastState.Bounded env37154 := by
  intro p hp
  have h : env37154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37153_37154 : H12AffineEnvironment.transform 13 5513 env37153 = env37154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env37153 == env37154) = true)

theorem identity37154 : scanCanonicalize (H12AffineFastState.compose env37154 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 508) := by decide +kernel

theorem selectedBound37154 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,508,468,1141,137,479,1125,2557,1024,136,445,169,16,138,348,65,2184,1261,373,2421,1501,33,256,168,1061,513]

theorem envBound37155 : H12AffineFastState.Bounded env37155 := by
  intro p hp
  have h : env37155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37154_37155 : H12AffineEnvironment.transform 11 508 env37154 = env37155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 508 env37154 == env37155) = true)

theorem identity37155 : scanCanonicalize (H12AffineFastState.compose env37155 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound37155 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env37156 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,0,40,1141,137,35,1125,2049,1024,136,65,169,16,138,160,65,2184,1261,137,2185,1057,33,252,168,1061,513]

theorem envBound37156 : H12AffineFastState.Bounded env37156 := by
  intro p hp
  have h : env37156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37155_37156 : H12AffineEnvironment.transform 7 252 env37155 = env37156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env37155 == env37156) = true)

def env37157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4161,32801,285797,327074,8328,65,295420,280932,268661,56437,1501,272392,256,21793,46212,513]

theorem envBound37157 : H12AffineFastState.Bounded env37157 := by
  intro p hp
  have h : env37157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37149_37157 : H12AffineEnvironment.transform 16 16401 env37149 = env37157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37149 == env37157) = true)

def env37158 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4113,32801,285749,327074,8328,17,295340,280884,268581,56357,1421,272392,256,21793,46212,513]

theorem envBound37158 : H12AffineFastState.Bounded env37158 := by
  intro p hp
  have h : env37158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37157_37158 : H12AffineEnvironment.transform 5 16 env37157 = env37158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37157 == env37158) = true)

theorem identity37158 : scanCanonicalize (H12AffineFastState.compose env37158 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound37158 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env37159 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56356,1024,32769,4113,32801,32785,8582,8328,17,23944,38160,50433,56357,1421,62508,256,21793,46212,513]

theorem envBound37159 : H12AffineFastState.Bounded env37159 := by
  intro p hp
  have h : env37159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37158_37159 : H12AffineEnvironment.transform 17 56356 env37158 = env37159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env37158 == env37159) = true)

theorem identity37159 : scanCanonicalize (H12AffineFastState.compose env37159 (packedSelected [2,4,6,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37159 : packedSelected [2,4,6,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env37160 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56356,1024,32769,4113,32801,32785,8462,8192,17,23808,38160,50433,56357,1285,62508,256,21793,46092,513]

theorem envBound37160 : H12AffineFastState.Bounded env37160 := by
  intro p hp
  have h : env37160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37159_37160 : H12AffineEnvironment.transform 6 8 env37159 = env37160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37159 == env37160) = true)

theorem identity37160 : scanCanonicalize (H12AffineFastState.compose env37160 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound37160 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37161 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1053,16384,32768,1046,16401,56356,1024,32769,4113,32801,32785,1299,1053,17,23808,38160,50433,56357,1285,53297,256,21793,36881,513]

theorem envBound37161 : H12AffineFastState.Bounded env37161 := by
  intro p hp
  have h : env37161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37160_37161 : H12AffineEnvironment.transform 12 1053 env37160 = env37161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env37160 == env37161) = true)

theorem identity37161 : scanCanonicalize (H12AffineFastState.compose env37161 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound37161 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env37162 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,41,16384,32768,34,16401,55312,52,32769,4113,32801,32785,295,41,17,22836,37156,49461,55313,305,53297,256,20757,36881,513]

theorem envBound37162 : H12AffineFastState.Bounded env37162 := by
  intro p hp
  have h : env37162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37161_37162 : H12AffineEnvironment.transform 9 52 env37161 = env37162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37161 == env37162) = true)

theorem identity37162 : scanCanonicalize (H12AffineFastState.compose env37162 (packedSelected [3,5,10,11,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 20496) := by decide +kernel

theorem selectedBound37162 : packedSelected [3,5,10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env37163 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,41,16384,20496,34,16401,2048,52,20497,4113,20529,20481,295,41,17,22836,16692,4389,2049,305,33,256,20757,16385,513]

theorem envBound37163 : H12AffineFastState.Bounded env37163 := by
  intro p hp
  have h : env37163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37162_37163 : H12AffineEnvironment.transform 14 20496 env37162 = env37163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20496 env37162 == env37163) = true)

theorem identity37163 : scanCanonicalize (H12AffineFastState.compose env37163 (packedSelected [0,2,4,5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound37163 : packedSelected [0,2,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env37164 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,41,513,4625,34,528,2048,52,4624,4113,4656,4608,295,41,17,6965,821,4389,2049,305,33,256,4884,512,513]

theorem envBound37164 : H12AffineFastState.Bounded env37164 := by
  intro p hp
  have h : env37164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37163_37164 : H12AffineEnvironment.transform 13 513 env37163 = env37164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env37163 == env37164) = true)

theorem identity37164 : scanCanonicalize (H12AffineFastState.compose env37164 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound37164 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env37165 : List Nat := [2,4,8,16,32,16,8,256,512,52,821,4096,41,513,4625,34,528,821,52,4624,4113,4656,4608,295,41,17,4096,821,4389,820,305,33,256,4884,512,513]

theorem envBound37165 : H12AffineFastState.Bounded env37165 := by
  intro p hp
  have h : env37165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37164_37165 : H12AffineEnvironment.transform 10 821 env37164 = env37165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env37164 == env37165) = true)

theorem identity37165 : scanCanonicalize (H12AffineFastState.compose env37165 (packedSelected [3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound37165 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env37166 : List Nat := [2,4,8,16,32,16,8,256,512,52,821,544,41,513,49,34,528,821,52,48,561,16,32,295,41,17,544,821,773,820,305,33,256,308,512,513]

theorem envBound37166 : H12AffineFastState.Bounded env37166 := by
  intro p hp
  have h : env37166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37165_37166 : H12AffineEnvironment.transform 11 544 env37165 = env37166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env37165 == env37166) = true)

theorem identity37166 : scanCanonicalize (H12AffineFastState.compose env37166 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37166 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env37167 : List Nat := [2,4,8,16,32,16,8,37,512,52,528,544,41,513,49,34,528,528,52,48,561,16,32,2,41,17,544,528,544,529,20,33,37,17,512,513]

theorem envBound37167 : H12AffineFastState.Bounded env37167 := by
  intro p hp
  have h : env37167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37166_37167 : H12AffineEnvironment.transform 7 37 env37166 = env37167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37166 == env37167) = true)

theorem identity37167 : scanCanonicalize (H12AffineFastState.compose env37167 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound37167 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37168 : List Nat := [2,4,8,16,32,16,8,37,1,52,17,33,41,0,49,34,17,17,52,48,48,16,32,2,41,17,33,17,33,16,20,33,37,17,1,0]

theorem envBound37168 : H12AffineFastState.Bounded env37168 := by
  intro p hp
  have h : env37168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37167_37168 : H12AffineEnvironment.transform 8 1 env37167 = env37168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env37167 == env37168) = true)

theorem identity37168 : scanCanonicalize (H12AffineFastState.compose env37168 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37169 : List Nat := [2,4,8,0,32,0,8,37,1,36,1,33,41,0,33,34,1,1,36,32,32,0,32,2,41,1,33,1,33,0,4,33,37,1,1,0]

theorem envBound37169 : H12AffineFastState.Bounded env37169 := by
  intro p hp
  have h : env37169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37168_37169 : H12AffineEnvironment.transform 3 0 env37168 = env37169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37168 == env37169) = true)

def env37170 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4112,32801,285748,327074,8328,16,295341,280885,268580,56356,1420,272392,256,21793,46212,513]

theorem envBound37170 : H12AffineFastState.Bounded env37170 := by
  intro p hp
  have h : env37170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37157_37170 : H12AffineEnvironment.transform 5 17 env37157 = env37170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37157 == env37170) = true)

theorem identity37170 : scanCanonicalize (H12AffineFastState.compose env37170 (packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37170 : packedSelected [3,4,5,8,9,14,17,18,20,23,28] rootPS < 2^1333 := by decide +kernel

def env37171 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,5392,262144,1024,32769,4112,32801,264501,305315,8328,16,295341,269364,268580,35109,1420,272392,256,32,46212,513]

theorem envBound37171 : H12AffineFastState.Bounded env37171 := by
  intro p hp
  have h : env37171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37170_37171 : H12AffineEnvironment.transform 13 5377 env37170 = env37171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37170 == env37171) = true)

theorem identity37171 : scanCanonicalize (H12AffineFastState.compose env37171 (packedSelected [1,5,7,8,11,14,17,20,24,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound37171 : packedSelected [1,5,7,8,11,14,17,20,24,27,32] rootPS < 2^1333 := by decide +kernel

def env37172 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,8203,5392,10280,1024,32769,4112,32801,8477,32907,8328,16,43397,13340,12556,35109,1420,32,256,32,46212,513]

theorem envBound37172 : H12AffineFastState.Bounded env37172 := by
  intro p hp
  have h : env37172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37171_37172 : H12AffineEnvironment.transform 17 10280 env37171 = env37172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env37171 == env37172) = true)

theorem identity37172 : scanCanonicalize (H12AffineFastState.compose env37172 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound37172 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env37173 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1052,5377,32768,1047,5392,3124,1024,32769,4112,32801,1281,32907,1172,16,36249,4096,5392,35109,1420,32,256,32,37016,513]

theorem envBound37173 : H12AffineFastState.Bounded env37173 := by
  intro p hp
  have h : env37173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37172_37173 : H12AffineEnvironment.transform 12 1052 env37172 = env37173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env37172 == env37173) = true)

theorem identity37173 : scanCanonicalize (H12AffineFastState.compose env37173 (packedSelected [3,5,10,11,15] rootPS)) = affineNative (2^(14+1) ^^^ 7424) := by decide +kernel

theorem selectedBound37173 : packedSelected [3,5,10,11,15] rootPS < 2^1333 := by decide +kernel

def env37174 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1052,5377,7424,1047,5392,3124,1024,7425,4112,7457,1281,7563,1172,16,4249,4096,5392,5157,1420,32,256,32,3480,513]

theorem envBound37174 : H12AffineFastState.Bounded env37174 := by
  intro p hp
  have h : env37174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37173_37174 : H12AffineEnvironment.transform 14 7424 env37173 = env37174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7424 env37173 == env37174) = true)

theorem identity37174 : scanCanonicalize (H12AffineFastState.compose env37174 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound37174 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env37175 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,388,4249,6296,399,4232,2476,408,6297,4112,6329,153,6163,268,16,4249,4096,4232,4541,20,32,256,32,2048,513]

theorem envBound37175 : H12AffineFastState.Bounded env37175 := by
  intro p hp
  have h : env37175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37174_37175 : H12AffineEnvironment.transform 9 408 env37174 = env37175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env37174 == env37175) = true)

def env37176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,2493493,499128,8328,65,2396604,2496820,416100,2149428,2102684,2373704,256,21793,46212,2175563]

theorem envBound37176 : H12AffineFastState.Bounded env37176 := by
  intro p hp
  have h : env37176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37117_37176 : H12AffineEnvironment.transform 21 180273 env37117 = env37176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env37117 == env37176) = true)

def env37177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,400501,499128,8328,65,295420,395636,416100,56436,1500,272392,256,21793,46212,74251]

theorem envBound37177 : H12AffineFastState.Bounded env37177 := by
  intro p hp
  have h : env37177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37176_37177 : H12AffineEnvironment.transform 20 4160 env37176 = env37177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37176 == env37177) = true)

theorem identity37177 : scanCanonicalize (H12AffineFastState.compose env37177 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound37177 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,180273,400501,412006,8328,65,295420,395636,416100,56436,1500,272392,256,21793,46212,63189]

theorem envBound37178 : H12AffineFastState.Bounded env37178 := by
  intro p hp
  have h : env37178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37177_37178 : H12AffineEnvironment.transform 15 54494 env37177 = env37178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env37177 == env37178) = true)

def env37179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180273,400501,412006,8192,65,295284,395636,416100,56436,1364,272392,256,21793,46092,63069]

theorem envBound37179 : H12AffineFastState.Bounded env37179 := by
  intro p hp
  have h : env37179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37178_37179 : H12AffineEnvironment.transform 6 8 env37178 = env37179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37178 == env37179) = true)

theorem identity37179 : scanCanonicalize (H12AffineFastState.compose env37179 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 5173) := by decide +kernel

theorem selectedBound37179 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env37180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,5173,262144,1024,32769,4160,54276,264256,286035,8192,65,295284,269633,281937,56436,1364,272392,256,21793,46092,63069]

theorem envBound37180 : H12AffineFastState.Bounded env37180 := by
  intro p hp
  have h : env37180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37179_37180 : H12AffineEnvironment.transform 16 5173 env37179 = env37180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5173 env37179 == env37180) = true)

theorem identity37180 : scanCanonicalize (H12AffineFastState.compose env37180 (packedSelected [0,8,9,10,12,15,17,22,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 56356) := by decide +kernel

theorem selectedBound37180 : packedSelected [0,8,9,10,12,15,17,22,27,28] rootPS < 2^1333 := by decide +kernel

def env37181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,5173,56356,1024,32769,4160,54276,54372,33143,8192,65,23888,49509,37237,56436,1364,62508,256,21793,46092,63069]

theorem envBound37181 : H12AffineFastState.Bounded env37181 := by
  intro p hp
  have h : env37181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37180_37181 : H12AffineEnvironment.transform 17 56356 env37180 = env37181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56356 env37180 == env37181) = true)

theorem identity37181 : scanCanonicalize (H12AffineFastState.compose env37181 (packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound37181 : packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env37182 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,41263,5173,43357,1024,32769,4160,41341,41245,33143,8192,65,10281,46108,37237,43277,1364,33109,256,8280,46092,33572]

theorem envBound37182 : H12AffineFastState.Bounded env37182 := by
  intro p hp
  have h : env37182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37181_37182 : H12AffineEnvironment.transform 13 13689 env37181 = env37182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env37181 == env37182) = true)

def env37183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180273,400501,412006,8193,65,295285,395636,416100,56436,1365,272392,256,21793,46093,63068]

theorem envBound37183 : H12AffineFastState.Bounded env37183 := by
  intro p hp
  have h : env37183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37178_37183 : H12AffineEnvironment.transform 6 9 env37178 = env37183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37178 == env37183) = true)

theorem identity37183 : scanCanonicalize (H12AffineFastState.compose env37183 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 16448) := by decide +kernel

theorem selectedBound37183 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env37184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,16448,262144,1024,32769,4160,32881,285749,264486,8193,65,295285,280884,268580,56436,1365,272392,256,21793,46093,63068]

theorem envBound37184 : H12AffineFastState.Bounded env37184 := by
  intro p hp
  have h : env37184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37183_37184 : H12AffineEnvironment.transform 16 16448 env37183 = env37184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env37183 == env37184) = true)

theorem identity37184 : scanCanonicalize (H12AffineFastState.compose env37184 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound37184 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env37185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,16448,262144,1024,29788,4160,29740,285749,264486,8193,65,292136,280884,268580,10281,1365,272392,256,21793,16464,513]

theorem envBound37185 : H12AffineFastState.Bounded env37185 := by
  intro p hp
  have h : env37185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37184_37185 : H12AffineEnvironment.transform 14 29789 env37184 = env37185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env37184 == env37185) = true)

theorem identity37185 : scanCanonicalize (H12AffineFastState.compose env37185 (packedSelected [2,3,5,6,10,12,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound37185 : packedSelected [2,3,5,6,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env37186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,16448,262144,1024,21760,4160,21872,285749,264486,349,65,283764,280884,268580,2421,1365,264532,256,21793,16464,513]

theorem envBound37186 : H12AffineFastState.Bounded env37186 := by
  intro p hp
  have h : env37186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37185_37186 : H12AffineEnvironment.transform 12 348 env37185 = env37186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env37185 == env37186) = true)

theorem identity37186 : scanCanonicalize (H12AffineFastState.compose env37186 (packedSelected [0,4,7,9,14,17] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound37186 : packedSelected [0,4,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env37187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,342,16448,2341,1024,21760,4160,21872,21776,3,349,65,23889,16401,4097,2421,1365,113,256,21793,16464,513]

theorem envBound37187 : H12AffineFastState.Bounded env37187 := by
  intro p hp
  have h : env37187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37186_37187 : H12AffineEnvironment.transform 17 2341 env37186 = env37187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env37186 == env37187) = true)

theorem identity37187 : scanCanonicalize (H12AffineFastState.compose env37187 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37187 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37188 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,262,16400,2341,1024,21760,4112,21792,21776,3,269,17,23809,16401,4097,2341,1285,33,256,21793,16384,513]

theorem envBound37188 : H12AffineFastState.Bounded env37188 := by
  intro p hp
  have h : env37188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37187_37188 : H12AffineEnvironment.transform 5 16 env37187 = env37188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37187 == env37188) = true)

theorem identity37188 : scanCanonicalize (H12AffineFastState.compose env37188 (packedSelected [0,4,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37188 : packedSelected [0,4,5,8] rootPS < 2^1333 := by decide +kernel

def env37189 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1024,1,4112,33,17,3,269,17,2048,5392,4097,2341,1285,33,256,32,5377,513]

theorem envBound37189 : H12AffineFastState.Bounded env37189 := by
  intro p hp
  have h : env37189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37188_37189 : H12AffineEnvironment.transform 13 5377 env37188 = env37189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37188 == env37189) = true)

theorem identity37189 : scanCanonicalize (H12AffineFastState.compose env37189 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37189 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37190 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,35,5172,2048,1024,1,4112,33,17,3,40,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound37190 : H12AffineFastState.Bounded env37190 := by
  intro p hp
  have h : env37190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37189_37190 : H12AffineEnvironment.transform 7 37 env37189 = env37190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37189 == env37190) = true)

def env37191 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,0,35,1028,2048,1024,1,32,33,17,3,40,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound37191 : H12AffineFastState.Bounded env37191 := by
  intro p hp
  have h : env37191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37190_37191 : H12AffineEnvironment.transform 11 48 env37190 = env37191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37190 == env37191) = true)

theorem identity37191 : scanCanonicalize (H12AffineFastState.compose env37191 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound37191 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37192 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1541,48,41,1044,0,35,1028,1541,1024,1,32,33,17,3,40,17,1541,1029,49,1541,1056,33,37,32,1044,513]

theorem envBound37192 : H12AffineFastState.Bounded env37192 := by
  intro p hp
  have h : env37192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37191_37192 : H12AffineEnvironment.transform 10 1541 env37191 = env37192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env37191 == env37192) = true)

def env37193 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,48,41,32,0,35,48,561,52,1,32,33,17,3,40,17,561,49,49,561,20,33,37,32,32,513]

theorem envBound37193 : H12AffineFastState.Bounded env37193 := by
  intro p hp
  have h : env37193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37192_37193 : H12AffineEnvironment.transform 9 52 env37192 = env37193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37192 == env37193) = true)

theorem identity37193 : scanCanonicalize (H12AffineFastState.compose env37193 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound37193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37194 : List Nat := [2,4,8,16,26,16,9,31,512,14,523,10,19,26,0,25,10,523,14,1,26,27,17,3,18,17,523,11,11,523,20,27,31,26,26,513]

theorem envBound37194 : H12AffineFastState.Bounded env37194 := by
  intro p hp
  have h : env37194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37193_37194 : H12AffineEnvironment.transform 4 26 env37193 = env37194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env37193 == env37194) = true)

def leafEnv37194 : List Nat := [2,4,8,16,26,16,9,31,512,14,523,10,19,26,0,25,10,523,14,1,26,27,17,3,20,18,1,17,523,11,11,523,20,27,31,26,4,24,26,513,1,26,0]

def active37194 : List Nat := [0,1,2,3,8]

def tree37194 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37194 : H12WitnessSearch.Good tree37194 := H12GlobalWitnessIndex.good

theorem leafIdentity37194 : H12AffineFastState.composeSystem env37194 rootObs = leafEnv37194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37194 rootObs == leafEnv37194) = true)

theorem terminalChecked37194 : H12PackedTerminal.terminalCheckFast leafEnv37194 active37194 tree37194 = true := by decide +kernel

def env37195 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,48,41,33,0,35,49,560,53,1,32,33,17,3,40,17,560,48,49,560,21,33,37,32,33,513]

theorem envBound37195 : H12AffineFastState.Bounded env37195 := by
  intro p hp
  have h : env37195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37192_37195 : H12AffineEnvironment.transform 9 53 env37192 = env37195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37192 == env37195) = true)

theorem identity37195 : scanCanonicalize (H12AffineFastState.compose env37195 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound37195 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37196 : List Nat := [2,4,8,16,32,16,9,37,17,53,33,48,41,33,0,35,49,33,53,1,32,33,17,3,40,17,33,48,49,33,21,33,37,32,33,16]

theorem envBound37196 : H12AffineFastState.Bounded env37196 := by
  intro p hp
  have h : env37196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37195_37196 : H12AffineEnvironment.transform 8 17 env37195 = env37196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env37195 == env37196) = true)

def leafEnv37196 : List Nat := [2,4,8,16,32,16,9,37,17,53,33,48,41,33,0,35,49,33,53,1,32,33,17,3,21,40,1,17,33,48,49,33,21,33,37,32,4,34,33,16,1,32,0]

def active37196 : List Nat := [0,1,2,3,4]

def tree37196 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37196 : H12WitnessSearch.Good tree37196 := H12GlobalWitnessIndex.good

theorem leafIdentity37196 : H12AffineFastState.composeSystem env37196 rootObs = leafEnv37196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37196 rootObs == leafEnv37196) = true)

theorem terminalChecked37196 : H12PackedTerminal.terminalCheckFast leafEnv37196 active37196 tree37196 = true := by decide +kernel

def env37197 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,0,35,1029,2048,1024,1,33,33,17,3,40,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound37197 : H12AffineFastState.Bounded env37197 := by
  intro p hp
  have h : env37197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37190_37197 : H12AffineEnvironment.transform 11 49 env37190 = env37197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37190 == env37197) = true)

theorem identity37197 : scanCanonicalize (H12AffineFastState.compose env37197 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound37197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37198 : List Nat := [2,4,8,16,32,16,9,37,512,1024,560,49,41,1045,0,35,1029,560,1024,1,33,33,17,3,40,17,560,1028,48,560,1056,33,37,32,1045,513]

theorem envBound37198 : H12AffineFastState.Bounded env37198 := by
  intro p hp
  have h : env37198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37197_37198 : H12AffineEnvironment.transform 10 560 env37197 = env37198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env37197 == env37198) = true)

def env37199 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,49,41,33,0,35,49,560,52,1,33,33,17,3,40,17,560,48,48,560,20,33,37,32,33,513]

theorem envBound37199 : H12AffineFastState.Bounded env37199 := by
  intro p hp
  have h : env37199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37198_37199 : H12AffineEnvironment.transform 9 52 env37198 = env37199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37198 == env37199) = true)

theorem identity37199 : scanCanonicalize (H12AffineFastState.compose env37199 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound37199 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37200 : List Nat := [2,4,8,16,27,16,9,30,512,15,523,10,18,26,0,24,10,523,15,1,26,26,17,3,19,17,523,11,11,523,20,26,30,27,26,513]

theorem envBound37200 : H12AffineFastState.Bounded env37200 := by
  intro p hp
  have h : env37200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37199_37200 : H12AffineEnvironment.transform 4 27 env37199 = env37200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env37199 == env37200) = true)

def leafEnv37200 : List Nat := [2,4,8,16,27,16,9,30,512,15,523,10,18,26,0,24,10,523,15,1,26,26,17,3,20,19,1,17,523,11,11,523,20,26,30,27,4,25,26,513,1,26,0]

def active37200 : List Nat := [0,1,2,3,8]

def tree37200 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37200 : H12WitnessSearch.Good tree37200 := H12GlobalWitnessIndex.good

theorem leafIdentity37200 : H12AffineFastState.composeSystem env37200 rootObs = leafEnv37200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37200 rootObs == leafEnv37200) = true)

theorem terminalChecked37200 : H12PackedTerminal.terminalCheckFast leafEnv37200 active37200 tree37200 = true := by decide +kernel

def env37201 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,49,41,32,0,35,48,560,53,1,33,33,17,3,40,17,560,49,48,560,21,33,37,32,32,513]

theorem envBound37201 : H12AffineFastState.Bounded env37201 := by
  intro p hp
  have h : env37201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37198_37201 : H12AffineEnvironment.transform 9 53 env37198 = env37201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37198 == env37201) = true)

theorem identity37201 : scanCanonicalize (H12AffineFastState.compose env37201 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound37201 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37202 : List Nat := [2,4,8,16,32,16,9,37,16,53,32,49,41,32,0,35,48,32,53,1,33,33,17,3,40,17,32,49,48,32,21,33,37,32,32,17]

theorem envBound37202 : H12AffineFastState.Bounded env37202 := by
  intro p hp
  have h : env37202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37201_37202 : H12AffineEnvironment.transform 8 16 env37201 = env37202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37201 == env37202) = true)

def leafEnv37202 : List Nat := [2,4,8,16,32,16,9,37,16,53,32,49,41,32,0,35,48,32,53,1,33,33,17,3,21,40,1,17,32,49,48,32,21,33,37,32,4,34,32,17,1,33,0]

def active37202 : List Nat := [0,1,2,3,4]

def tree37202 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37202 : H12WitnessSearch.Good tree37202 := H12GlobalWitnessIndex.good

theorem leafIdentity37202 : H12AffineFastState.composeSystem env37202 rootObs = leafEnv37202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37202 rootObs == leafEnv37202) = true)

theorem terminalChecked37202 : H12PackedTerminal.terminalCheckFast leafEnv37202 active37202 tree37202 = true := by decide +kernel

def env37203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,400500,499128,8328,65,295421,395637,416100,56437,1501,272393,256,21793,46212,74250]

theorem envBound37203 : H12AffineFastState.Bounded env37203 := by
  intro p hp
  have h : env37203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37176_37203 : H12AffineEnvironment.transform 20 4161 env37176 = env37203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37176 == env37203) = true)

theorem identity37203 : scanCanonicalize (H12AffineFastState.compose env37203 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound37203 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4161,180273,73755,41431,8328,65,245138,79130,91403,56437,1501,201830,256,21793,46212,74250]

theorem envBound37204 : H12AffineFastState.Bounded env37204 := by
  intro p hp
  have h : env37204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37203_37204 : H12AffineEnvironment.transform 17 212079 env37203 = env37204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env37203 == env37204) = true)

def env37205 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212031,1024,32769,4113,180273,73755,41351,8328,17,245138,79130,91403,56357,1421,201782,256,21793,46212,74250]

theorem envBound37205 : H12AffineFastState.Bounded env37205 := by
  intro p hp
  have h : env37205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37204_37205 : H12AffineEnvironment.transform 5 16 env37204 = env37205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37204 == env37205) = true)

theorem identity37205 : scanCanonicalize (H12AffineFastState.compose env37205 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 82198) := by decide +kernel

theorem selectedBound37205 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env37206 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,32041,1024,32769,4113,98599,73755,41351,8328,17,64644,79130,91403,56357,1421,21792,256,21793,46212,74250]

theorem envBound37206 : H12AffineFastState.Bounded env37206 := by
  intro p hp
  have h : env37206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37205_37206 : H12AffineEnvironment.transform 16 82198 env37205 = env37206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82198 env37205 == env37206) = true)

theorem identity37206 : scanCanonicalize (H12AffineFastState.compose env37206 (packedSelected [1,3,4,7,9,17,18,19,23,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound37206 : packedSelected [1,3,4,7,9,17,18,19,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env37207 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,38297,32041,1024,32769,4113,21928,62612,41351,8328,17,64644,57749,45444,56357,1421,21792,256,21793,46212,63109]

theorem envBound37207 : H12AffineFastState.Bounded env37207 := by
  intro p hp
  have h : env37207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37206_37207 : H12AffineEnvironment.transform 15 54415 env37206 = env37207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env37206 == env37207) = true)

theorem identity37207 : scanCanonicalize (H12AffineFastState.compose env37207 (packedSelected [0,3,5,6,7,10,14,15,20,23] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound37207 : packedSelected [0,3,5,6,7,10,14,15,20,23] rootPS < 2^1333 := by decide +kernel

def env37208 : List Nat := [2,4,8,16,32,16,128,256,512,304,2048,4096,8192,16384,32768,53695,37033,30745,304,32769,4113,20632,61860,41351,8328,17,63924,57749,45444,55573,189,20496,256,20497,45492,62389]

theorem envBound37208 : H12AffineFastState.Bounded env37208 := by
  intro p hp
  have h : env37208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37207_37208 : H12AffineEnvironment.transform 9 304 env37207 = env37208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env37207 == env37208) = true)

theorem identity37208 : scanCanonicalize (H12AffineFastState.compose env37208 (packedSelected [5,9,11,14,15,19,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound37208 : packedSelected [5,9,11,14,15,19,22,24] rootPS < 2^1333 := by decide +kernel

def env37209 : List Nat := [2,4,8,16,32,16,128,256,512,304,2048,4096,300,16384,32768,53695,37033,22837,304,32769,4113,20632,53384,32939,420,17,55448,49337,37032,55573,189,20496,256,20497,37016,53913]

theorem envBound37209 : H12AffineFastState.Bounded env37209 := by
  intro p hp
  have h : env37209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37208_37209 : H12AffineEnvironment.transform 12 300 env37208 = env37209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env37208 == env37209) = true)

theorem identity37209 : scanCanonicalize (H12AffineFastState.compose env37209 (packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 4280) := by decide +kernel

theorem selectedBound37209 : packedSelected [0,2,3,4,5,7,9,10,11,18] rootPS < 2^1333 := by decide +kernel

def env37210 : List Nat := [2,4,8,16,32,16,128,256,512,304,2048,4096,300,4280,32768,33031,37033,2445,304,32769,4113,32,32816,32939,420,17,34848,36865,37032,35245,189,168,256,169,37016,33313]

theorem envBound37210 : H12AffineFastState.Bounded env37210 := by
  intro p hp
  have h : env37210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37209_37210 : H12AffineEnvironment.transform 13 4280 env37209 = env37210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4280 env37209 == env37210) = true)

theorem identity37210 : scanCanonicalize (H12AffineFastState.compose env37210 (packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37210 : packedSelected [0,3,4,5,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37211 : List Nat := [2,4,8,16,32,16,128,4,512,52,2048,4096,40,4280,32768,32771,37033,2185,52,32769,4113,32,32816,32939,160,17,34848,36865,37032,34985,189,168,4,169,37016,33313]

theorem envBound37211 : H12AffineFastState.Bounded env37211 := by
  intro p hp
  have h : env37211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37210_37211 : H12AffineEnvironment.transform 7 4 env37210 = env37211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37210 == env37211) = true)

theorem identity37211 : scanCanonicalize (H12AffineFastState.compose env37211 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound37211 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37212 : List Nat := [2,4,8,16,32,16,128,4,512,52,2048,4096,40,4280,0,3,4265,2185,52,1,4113,32,48,171,160,17,2080,4097,4264,2217,189,168,4,169,4248,545]

theorem envBound37212 : H12AffineFastState.Bounded env37212 := by
  intro p hp
  have h : env37212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37211_37212 : H12AffineEnvironment.transform 14 0 env37211 = env37212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37211 == env37212) = true)

theorem identity37212 : scanCanonicalize (H12AffineFastState.compose env37212 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound37212 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37213 : List Nat := [2,4,8,16,32,16,40,4,512,52,2048,4096,40,4112,0,3,4097,2081,52,1,4113,32,48,3,8,17,2080,4097,4096,2049,21,0,4,1,4144,545]

theorem envBound37213 : H12AffineFastState.Bounded env37213 := by
  intro p hp
  have h : env37213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37212_37213 : H12AffineEnvironment.transform 6 40 env37212 = env37213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env37212 == env37213) = true)

theorem identity37213 : scanCanonicalize (H12AffineFastState.compose env37213 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound37213 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env37214 : List Nat := [2,4,8,16,32,16,40,4,512,52,2048,2065,40,2049,0,3,2064,2081,52,1,2048,32,48,3,8,17,2080,2064,2065,2049,21,0,4,1,2081,545]

theorem envBound37214 : H12AffineFastState.Bounded env37214 := by
  intro p hp
  have h : env37214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37213_37214 : H12AffineEnvironment.transform 11 2065 env37213 = env37214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env37213 == env37214) = true)

theorem identity37214 : scanCanonicalize (H12AffineFastState.compose env37214 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37214 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37215 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,2065,9,2049,0,3,2064,2048,21,1,2048,1,17,3,8,17,2049,2064,2065,2049,21,0,4,1,2048,512]

theorem envBound37215 : H12AffineFastState.Bounded env37215 := by
  intro p hp
  have h : env37215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37214_37215 : H12AffineEnvironment.transform 4 1 env37214 = env37215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37214 == env37215) = true)

def env37216 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212030,1024,32769,4112,180273,73755,41350,8328,16,245138,79130,91403,56356,1420,201783,256,21793,46212,74250]

theorem envBound37216 : H12AffineFastState.Bounded env37216 := by
  intro p hp
  have h : env37216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37204_37216 : H12AffineEnvironment.transform 5 17 env37204 = env37216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37204 == env37216) = true)

theorem identity37216 : scanCanonicalize (H12AffineFastState.compose env37216 (packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound37216 : packedSelected [3,4,7,9,10,12,16,17,19,20,24,27,41] rootPS < 2^1333 := by decide +kernel

def env37217 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,56492,1024,32769,4112,73891,73755,41350,8328,16,23808,79130,91403,56356,1420,62629,256,21793,46212,74250]

theorem envBound37217 : H12AffineFastState.Bounded env37217 := by
  intro p hp
  have h : env37217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37216_37217 : H12AffineEnvironment.transform 16 123026 env37216 = env37217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env37216 == env37217) = true)

theorem identity37217 : scanCanonicalize (H12AffineFastState.compose env37217 (packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound37217 : packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env37218 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,13340,56492,1024,32769,4112,62509,62613,41350,8328,16,23808,57748,45445,56356,1420,62629,256,21793,46212,63108]

theorem envBound37218 : H12AffineFastState.Bounded env37218 := by
  intro p hp
  have h : env37218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37217_37218 : H12AffineEnvironment.transform 15 54414 env37217 = env37218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env37217 == env37218) = true)

theorem identity37218 : scanCanonicalize (H12AffineFastState.compose env37218 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound37218 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env37219 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,8202,13340,10280,1024,29829,4112,169,17,21762,8328,16,23808,5392,17665,10400,1420,33,256,21793,16384,512]

theorem envBound37219 : H12AffineFastState.Bounded env37219 := by
  intro p hp
  have h : env37219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37218_37219 : H12AffineEnvironment.transform 14 29828 env37218 = env37219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env37218 == env37219) = true)

theorem identity37219 : scanCanonicalize (H12AffineFastState.compose env37219 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound37219 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env37220 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,16384,29828,8202,13340,10280,1024,29829,4112,169,17,21678,8328,16,23724,5308,17581,10400,1056,33,172,21645,16384,512]

theorem envBound37220 : H12AffineFastState.Bounded env37220 := by
  intro p hp
  have h : env37220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37219_37220 : H12AffineEnvironment.transform 7 172 env37219 = env37220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env37219 == env37220) = true)

theorem identity37220 : scanCanonicalize (H12AffineFastState.compose env37220 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound37220 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env37221 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,16384,20633,1047,4097,3125,1024,20632,4112,169,17,21678,1173,16,23724,5308,17581,3261,1056,33,172,21645,16384,512]

theorem envBound37221 : H12AffineFastState.Bounded env37221 := by
  intro p hp
  have h : env37221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37220_37221 : H12AffineEnvironment.transform 12 1053 env37220 = env37221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env37220 == env37221) = true)

theorem identity37221 : scanCanonicalize (H12AffineFastState.compose env37221 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4248) := by decide +kernel

theorem selectedBound37221 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env37222 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,1053,4248,1,1047,4097,3125,1024,0,4112,169,17,1078,1173,16,3124,5308,5173,3261,1056,33,172,1045,4248,512]

theorem envBound37222 : H12AffineFastState.Bounded env37222 := by
  intro p hp
  have h : env37222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37221_37222 : H12AffineEnvironment.transform 13 4248 env37221 = env37222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4248 env37221 == env37222) = true)

theorem identity37222 : scanCanonicalize (H12AffineFastState.compose env37222 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound37222 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env37223 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,2097,1053,2217,1,1047,2096,3125,1024,0,2081,169,17,1078,1173,16,3124,3213,3076,3261,1056,33,172,1045,2217,512]

theorem envBound37223 : H12AffineFastState.Bounded env37223 := by
  intro p hp
  have h : env37223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37222_37223 : H12AffineEnvironment.transform 11 2097 env37222 = env37223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env37222 == env37223) = true)

theorem identity37223 : scanCanonicalize (H12AffineFastState.compose env37223 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound37223 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env37224 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1212,1165,1053,1045,1,1047,1164,137,1024,0,1181,169,17,1078,1173,16,136,49,184,1,1056,33,172,1045,1045,512]

theorem envBound37224 : H12AffineFastState.Bounded env37224 := by
  intro p hp
  have h : env37224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37223_37224 : H12AffineEnvironment.transform 10 1212 env37223 = env37224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env37223 == env37224) = true)

theorem identity37224 : scanCanonicalize (H12AffineFastState.compose env37224 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37224 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37225 : List Nat := [2,4,8,16,1,17,128,141,512,1024,1181,1165,1053,1045,1,1047,1164,137,1024,0,1181,136,17,1047,1173,16,136,16,153,1,1025,0,141,1045,1045,512]

theorem envBound37225 : H12AffineFastState.Bounded env37225 := by
  intro p hp
  have h : env37225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37224_37225 : H12AffineEnvironment.transform 4 1 env37224 = env37225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37224 == env37225) = true)

theorem identity37225 : scanCanonicalize (H12AffineFastState.compose env37225 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound37225 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env37226 : List Nat := [2,4,8,16,1,17,128,141,512,21,136,152,8,0,1,2,153,137,21,0,136,136,17,2,128,16,136,16,153,1,20,0,141,0,0,512]

theorem envBound37226 : H12AffineFastState.Bounded env37226 := by
  intro p hp
  have h : env37226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37225_37226 : H12AffineEnvironment.transform 9 21 env37225 = env37226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env37225 == env37226) = true)

def env37227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493493,499129,8328,65,6705548,2496821,416100,2149428,2102685,6748280,256,21792,46213,2175562]

theorem envBound37227 : H12AffineFastState.Bounded env37227 := by
  intro p hp
  have h : env37227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37116_37227 : H12AffineEnvironment.transform 23 499129 env37116 = env37227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env37116 == env37227) = true)

def env37228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180272,2493493,499129,8328,65,2396604,2496821,416100,2149428,2102685,2373704,256,21792,46213,2175562]

theorem envBound37228 : H12AffineFastState.Bounded env37228 := by
  intro p hp
  have h : env37228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37227_37228 : H12AffineEnvironment.transform 21 180272 env37227 = env37228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env37227 == env37228) = true)

def env37229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180272,400501,499129,8328,65,295420,395637,416100,56436,1501,272392,256,21792,46213,74250]

theorem envBound37229 : H12AffineFastState.Bounded env37229 := by
  intro p hp
  have h : env37229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37228_37229 : H12AffineEnvironment.transform 20 4160 env37228 = env37229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37228 == env37229) = true)

def env37230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180272,144477,243089,8328,65,43476,139613,160076,56436,1501,32,256,21792,46213,74250]

theorem envBound37230 : H12AffineFastState.Bounded env37230 := by
  intro p hp
  have h : env37230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37229_37230 : H12AffineEnvironment.transform 17 10280 env37229 = env37230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env37229 == env37230) = true)

def env37231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4160,21792,41293,73857,8328,65,43476,46157,58460,56436,1501,32,256,21792,46213,74250]

theorem envBound37231 : H12AffineFastState.Bounded env37231 := by
  intro p hp
  have h : env37231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37230_37231 : H12AffineEnvironment.transform 16 38160 env37230 = env37231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env37230 == env37231) = true)

theorem identity37231 : scanCanonicalize (H12AffineFastState.compose env37231 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37231 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,13388,10280,1024,8541,4160,21792,17,73857,8328,65,2184,5393,17664,32040,1501,32,256,21792,5593,74250]

theorem envBound37232 : H12AffineFastState.Bounded env37232 := by
  intro p hp
  have h : env37232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37231_37232 : H12AffineEnvironment.transform 14 8540 env37231 = env37232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37231 == env37232) = true)

theorem identity37232 : scanCanonicalize (H12AffineFastState.compose env37232 (packedSelected [5,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound37232 : packedSelected [5,24,26] rootPS < 2^1333 := by decide +kernel

def env37233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,28698,13388,10280,1024,8541,4160,21792,17,20635,8328,65,2184,5393,17664,32040,1501,32,256,21792,5593,21008]

theorem envBound37233 : H12AffineFastState.Bounded env37233 := by
  intro p hp
  have h : env37233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37232_37233 : H12AffineEnvironment.transform 15 28698 env37232 = env37233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env37232 == env37233) = true)

theorem identity37233 : scanCanonicalize (H12AffineFastState.compose env37233 (packedSelected [1,3,5,8,10,11,16,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound37233 : packedSelected [1,3,5,8,10,11,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env37234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4404,8540,8494,13388,10280,1024,8541,4160,1044,17,431,8328,65,2184,5393,5172,11292,1501,32,256,1044,5593,804]

theorem envBound37234 : H12AffineFastState.Bounded env37234 := by
  intro p hp
  have h : env37234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37233_37234 : H12AffineEnvironment.transform 13 4404 env37233 = env37234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env37233 == env37234) = true)

theorem identity37234 : scanCanonicalize (H12AffineFastState.compose env37234 (packedSelected [0,1,4,5,8,12,14,15,16,22,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound37234 : packedSelected [0,1,4,5,8,12,14,15,16,22,24,27] rootPS < 2^1333 := by decide +kernel

def env37235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,4404,428,478,5308,2264,1024,429,4160,1044,17,431,120,65,2184,5393,5172,3308,1501,32,256,1044,5593,804]

theorem envBound37235 : H12AffineFastState.Bounded env37235 := by
  intro p hp
  have h : env37235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37234_37235 : H12AffineEnvironment.transform 12 240 env37234 = env37235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env37234 == env37235) = true)

theorem identity37235 : scanCanonicalize (H12AffineFastState.compose env37235 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound37235 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37236 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,240,4404,428,478,4389,2264,409,429,4160,397,17,431,120,65,2184,4232,4525,2421,68,32,256,397,4160,804]

theorem envBound37236 : H12AffineFastState.Bounded env37236 := by
  intro p hp
  have h : env37236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37235_37236 : H12AffineEnvironment.transform 9 409 env37235 = env37236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env37235 == env37236) = true)

theorem identity37236 : scanCanonicalize (H12AffineFastState.compose env37236 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound37236 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env37237 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,2200,240,2476,428,478,2493,2264,409,429,2264,397,17,431,120,65,2184,2064,2357,2421,68,32,256,397,2264,804]

theorem envBound37237 : H12AffineFastState.Bounded env37237 := by
  intro p hp
  have h : env37237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37236_37237 : H12AffineEnvironment.transform 11 2200 env37236 = env37237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env37236 == env37237) = true)

theorem identity37237 : scanCanonicalize (H12AffineFastState.compose env37237 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound37237 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37238 : List Nat := [2,4,8,16,32,64,128,256,512,409,0,152,240,428,428,478,445,216,409,429,216,397,17,431,120,65,136,16,309,373,68,32,256,397,216,804]

theorem envBound37238 : H12AffineFastState.Bounded env37238 := by
  intro p hp
  have h : env37238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37237_37238 : H12AffineEnvironment.transform 10 0 env37237 = env37238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env37237 == env37238) = true)

theorem identity37238 : scanCanonicalize (H12AffineFastState.compose env37238 (packedSelected [0,3,4,5,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound37238 : packedSelected [0,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37239 : List Nat := [2,4,8,16,32,64,128,253,512,100,0,152,240,81,81,35,64,216,100,80,216,112,17,82,120,65,136,16,200,136,68,32,253,112,216,729]

theorem envBound37239 : H12AffineFastState.Bounded env37239 := by
  intro p hp
  have h : env37239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37238_37239 : H12AffineEnvironment.transform 7 253 env37238 = env37239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env37238 == env37239) = true)

theorem identity37239 : scanCanonicalize (H12AffineFastState.compose env37239 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37239 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env37240 : List Nat := [2,4,8,16,32,16,128,173,512,52,0,152,160,1,1,35,16,136,52,0,136,32,17,2,40,17,136,16,152,136,20,32,173,32,136,649]

theorem envBound37240 : H12AffineFastState.Bounded env37240 := by
  intro p hp
  have h : env37240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37239_37240 : H12AffineEnvironment.transform 5 16 env37239 = env37240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37239 == env37240) = true)

theorem identity37240 : scanCanonicalize (H12AffineFastState.compose env37240 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound37240 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env37241 : List Nat := [2,4,8,16,32,16,128,173,16,52,0,152,160,1,1,35,16,136,52,0,136,32,17,2,40,17,136,16,152,136,20,32,173,32,136,153]

theorem envBound37241 : H12AffineFastState.Bounded env37241 := by
  intro p hp
  have h : env37241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37240_37241 : H12AffineEnvironment.transform 8 16 env37240 = env37241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env37240 == env37241) = true)

theorem identity37241 : scanCanonicalize (H12AffineFastState.compose env37241 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37241 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env37242 : List Nat := [2,4,8,16,32,16,8,37,16,52,0,16,40,1,1,35,16,0,52,0,0,32,17,2,40,17,0,16,16,0,20,32,37,32,0,17]

theorem envBound37242 : H12AffineFastState.Bounded env37242 := by
  intro p hp
  have h : env37242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37241_37242 : H12AffineEnvironment.transform 6 8 env37241 = env37242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37241 == env37242) = true)

theorem identity37242 : scanCanonicalize (H12AffineFastState.compose env37242 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37242 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37243 : List Nat := [2,4,8,1,32,1,8,37,1,37,0,1,40,1,1,35,1,0,37,0,0,32,0,2,40,0,0,1,1,0,5,32,37,32,0,0]

theorem envBound37243 : H12AffineFastState.Bounded env37243 := by
  intro p hp
  have h : env37243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37242_37243 : H12AffineEnvironment.transform 3 1 env37242 = env37243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37242 == env37243) = true)

theorem identity37243 : scanCanonicalize (H12AffineFastState.compose env37243 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37243 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37244 : List Nat := [2,4,8,1,10,1,8,15,1,15,0,1,2,1,1,9,1,0,15,0,0,10,0,2,2,0,0,1,1,0,5,10,15,10,0,0]

theorem envBound37244 : H12AffineFastState.Bounded env37244 := by
  intro p hp
  have h : env37244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37243_37244 : H12AffineEnvironment.transform 4 10 env37243 = env37244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37243 == env37244) = true)

def env37245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4160,21793,41292,73856,8328,65,43476,46156,58461,56436,1501,32,256,21792,46213,74250]

theorem envBound37245 : H12AffineFastState.Bounded env37245 := by
  intro p hp
  have h : env37245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37230_37245 : H12AffineEnvironment.transform 16 38161 env37230 = env37245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env37230 == env37245) = true)

theorem identity37245 : scanCanonicalize (H12AffineFastState.compose env37245 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound37245 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,13509,10280,1024,8661,4160,21793,152,73856,8328,65,2048,5528,17801,32160,1501,32,256,21792,5457,74250]

theorem envBound37246 : H12AffineFastState.Bounded env37246 := by
  intro p hp
  have h : env37246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37245_37246 : H12AffineEnvironment.transform 14 8660 env37245 = env37246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env37245 == env37246) = true)

theorem identity37246 : scanCanonicalize (H12AffineFastState.compose env37246 (packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound37246 : packedSelected [0,2,3,6,7,8,11,16,18,24,26,28] rootPS < 2^1333 := by decide +kernel

def env37247 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,16384,8660,65536,12328,10280,237,8661,4160,20940,152,73856,8328,65,2048,4469,16740,31053,304,32,256,20941,4540,74250]

theorem envBound37247 : H12AffineFastState.Bounded env37247 := by
  intro p hp
  have h : env37247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37246_37247 : H12AffineEnvironment.transform 9 237 env37246 = env37247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env37246 == env37247) = true)

theorem identity37247 : scanCanonicalize (H12AffineFastState.compose env37247 (packedSelected [0,1,2,5,6,7,8,12,15,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8694) := by decide +kernel

theorem selectedBound37247 : packedSelected [0,1,2,5,6,7,8,12,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env37248 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,8192,16384,8660,8694,12328,10280,237,8661,4160,20940,152,374,8328,65,2048,4469,16740,31053,304,32,256,20941,4540,1020]

theorem envBound37248 : H12AffineFastState.Bounded env37248 := by
  intro p hp
  have h : env37248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37247_37248 : H12AffineEnvironment.transform 15 8694 env37247 = env37248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8694 env37247 == env37248) = true)

theorem identity37248 : scanCanonicalize (H12AffineFastState.compose env37248 (packedSelected [3,4,5,9,10,11,14,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound37248 : packedSelected [3,4,5,9,10,11,14,20,23] rootPS < 2^1333 := by decide +kernel

def env37249 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,120,16384,428,398,4176,2128,237,429,4160,20940,152,374,240,65,2048,4469,16740,22837,304,32,256,20941,4540,1020]

theorem envBound37249 : H12AffineFastState.Bounded env37249 := by
  intro p hp
  have h : env37249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37248_37249 : H12AffineEnvironment.transform 12 120 env37248 = env37249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env37248 == env37249) = true)

theorem identity37249 : scanCanonicalize (H12AffineFastState.compose env37249 (packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound37249 : packedSelected [0,1,2,6,7,8,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env37250 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,120,4541,428,398,4176,2128,237,429,4160,113,152,374,240,65,2048,4469,4313,2184,304,32,256,112,4540,1020]

theorem envBound37250 : H12AffineFastState.Bounded env37250 := by
  intro p hp
  have h : env37250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37249_37250 : H12AffineEnvironment.transform 13 4541 env37249 = env37250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env37249 == env37250) = true)

theorem identity37250 : scanCanonicalize (H12AffineFastState.compose env37250 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37250 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env37251 : List Nat := [2,4,8,16,32,64,128,36,512,237,2048,4096,120,4249,136,170,4176,2128,237,137,4160,113,152,82,240,65,2048,4177,4313,2184,20,32,36,112,4248,728]

theorem envBound37251 : H12AffineFastState.Bounded env37251 := by
  intro p hp
  have h : env37251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37250_37251 : H12AffineEnvironment.transform 7 36 env37250 = env37251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37250 == env37251) = true)

theorem identity37251 : scanCanonicalize (H12AffineFastState.compose env37251 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37251 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37252 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,4096,120,4112,1,35,4176,2128,100,0,4160,113,17,82,121,65,2048,4177,4176,2049,20,32,36,112,4113,593]

theorem envBound37252 : H12AffineFastState.Bounded env37252 := by
  intro p hp
  have h : env37252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37251_37252 : H12AffineEnvironment.transform 6 9 env37251 = env37252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37251 == env37252) = true)

theorem identity37252 : scanCanonicalize (H12AffineFastState.compose env37252 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2144) := by decide +kernel

theorem selectedBound37252 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37253 : List Nat := [2,4,8,16,32,64,9,36,512,100,2048,2144,120,2160,1,35,2096,2128,100,0,2080,113,17,82,121,65,2048,2097,2096,2049,20,32,36,112,2161,593]

theorem envBound37253 : H12AffineFastState.Bounded env37253 := by
  intro p hp
  have h : env37253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37252_37253 : H12AffineEnvironment.transform 11 2144 env37252 = env37253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2144 env37252 == env37253) = true)

theorem identity37253 : scanCanonicalize (H12AffineFastState.compose env37253 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37253 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37254 : List Nat := [2,4,8,16,32,48,9,36,512,20,2048,2064,8,2048,1,35,2096,2080,20,0,2080,1,17,34,9,49,2048,2097,2096,2049,20,32,36,0,2049,545]

theorem envBound37254 : H12AffineFastState.Bounded env37254 := by
  intro p hp
  have h : env37254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37253_37254 : H12AffineEnvironment.transform 5 48 env37253 = env37254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37253 == env37254) = true)

theorem identity37254 : scanCanonicalize (H12AffineFastState.compose env37254 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37254 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env37255 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,2064,8,2048,1,2,2065,2049,20,0,2049,1,17,3,9,16,2048,2064,2065,2049,20,1,5,0,2049,512]

theorem envBound37255 : H12AffineFastState.Bounded env37255 := by
  intro p hp
  have h : env37255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37254_37255 : H12AffineEnvironment.transform 4 1 env37254 = env37255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37254 == env37255) = true)

def env37256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180272,144476,243088,8328,65,43477,139612,160077,56436,1501,33,256,21792,46213,74250]

theorem envBound37256 : H12AffineFastState.Bounded env37256 := by
  intro p hp
  have h : env37256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37229_37256 : H12AffineEnvironment.transform 17 10281 env37229 = env37256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37229 == env37256) = true)

def env37257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,21792,41292,73856,8328,65,43477,46156,58461,56436,1501,33,256,21792,46213,74250]

theorem envBound37257 : H12AffineFastState.Bounded env37257 := by
  intro p hp
  have h : env37257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37256_37257 : H12AffineEnvironment.transform 16 38160 env37256 = env37257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env37256 == env37257) = true)

theorem identity37257 : scanCanonicalize (H12AffineFastState.compose env37257 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound37257 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37258 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,21792,41292,73737,8193,65,43356,46156,58461,56436,1364,33,256,21792,46092,74250]

theorem envBound37258 : H12AffineFastState.Bounded env37258 := by
  intro p hp
  have h : env37258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37257_37258 : H12AffineEnvironment.transform 6 9 env37257 = env37258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37257 == env37258) = true)

theorem identity37258 : scanCanonicalize (H12AffineFastState.compose env37258 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound37258 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37259 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,38160,10281,1024,32769,4160,21792,41292,54530,8193,65,43356,46156,58461,56436,1364,33,256,21792,46092,55041]

theorem envBound37259 : H12AffineFastState.Bounded env37259 := by
  intro p hp
  have h : env37259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37258_37259 : H12AffineEnvironment.transform 15 62731 env37258 = env37259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env37258 == env37259) = true)

theorem identity37259 : scanCanonicalize (H12AffineFastState.compose env37259 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound37259 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,29963,5392,10281,1024,1,4160,21792,8524,21762,8193,65,10588,13388,25693,23668,1364,33,256,21792,13324,22273]

theorem envBound37260 : H12AffineFastState.Bounded env37260 := by
  intro p hp
  have h : env37260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37259_37260 : H12AffineEnvironment.transform 14 0 env37259 = env37260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env37259 == env37260) = true)

theorem identity37260 : scanCanonicalize (H12AffineFastState.compose env37260 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound37260 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env37261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,0,262,5392,10281,1024,1,4160,8493,8524,8463,8193,65,10588,13388,4176,10361,1364,33,256,8493,13324,8972]

theorem envBound37261 : H12AffineFastState.Bounded env37261 := by
  intro p hp
  have h : env37261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37260_37261 : H12AffineEnvironment.transform 13 13325 env37260 = env37261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env37260 == env37261) = true)

theorem identity37261 : scanCanonicalize (H12AffineFastState.compose env37261 (packedSelected [0,3,5,6,7,10,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37261 : packedSelected [0,3,5,6,7,10,14,16] rootPS < 2^1333 := by decide +kernel

def env37262 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,262,5392,10281,1024,1,4112,8493,8476,8463,8193,17,10508,13340,4096,10281,1284,33,256,8493,13324,8972]

theorem envBound37262 : H12AffineFastState.Bounded env37262 := by
  intro p hp
  have h : env37262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37261_37262 : H12AffineEnvironment.transform 5 16 env37261 = env37262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37261 == env37262) = true)

theorem identity37262 : scanCanonicalize (H12AffineFastState.compose env37262 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound37262 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env37263 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2097,8192,11324,0,262,3361,10281,1024,1,2081,8493,8476,8463,8193,17,10508,11309,2097,10281,1284,33,256,8493,11325,8972]

theorem envBound37263 : H12AffineFastState.Bounded env37263 := by
  intro p hp
  have h : env37263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37262_37263 : H12AffineEnvironment.transform 11 2097 env37262 = env37263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env37262 == env37263) = true)

theorem identity37263 : scanCanonicalize (H12AffineFastState.compose env37263 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound37263 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env37264 : List Nat := [2,4,8,16,32,16,9,256,512,20,2048,2097,8192,10280,0,262,2357,10281,20,1,2081,8493,8476,8463,8193,17,10508,10297,2097,10281,272,33,256,8493,10281,8972]

theorem envBound37264 : H12AffineFastState.Bounded env37264 := by
  intro p hp
  have h : env37264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37263_37264 : H12AffineEnvironment.transform 9 20 env37263 = env37264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env37263 == env37264) = true)

theorem identity37264 : scanCanonicalize (H12AffineFastState.compose env37264 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37264 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env37265 : List Nat := [2,4,8,16,32,16,9,4,512,20,2048,2097,8192,10280,0,2,2097,10281,20,1,2081,8233,8216,8203,8193,17,10248,10297,2097,10281,20,33,4,8233,10281,8712]

theorem envBound37265 : H12AffineFastState.Bounded env37265 := by
  intro p hp
  have h : env37265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37264_37265 : H12AffineEnvironment.transform 7 4 env37264 = env37265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37264 == env37265) = true)

def env37266 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,21793,41293,73857,8328,65,43477,46157,58460,56436,1501,33,256,21792,46213,74250]

theorem envBound37266 : H12AffineFastState.Bounded env37266 := by
  intro p hp
  have h : env37266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37256_37266 : H12AffineEnvironment.transform 16 38161 env37256 = env37266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env37256 == env37266) = true)

theorem identity37266 : scanCanonicalize (H12AffineFastState.compose env37266 (packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound37266 : packedSelected [3,5,8,10,11,18,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38161,10281,1024,32769,4160,21793,41293,3,8328,65,43477,46157,58460,56436,1501,33,256,21792,46213,648]

theorem envBound37267 : H12AffineFastState.Bounded env37267 := by
  intro p hp
  have h : env37267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37266_37267 : H12AffineEnvironment.transform 15 8322 env37266 = env37267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env37266 == env37267) = true)

theorem identity37267 : scanCanonicalize (H12AffineFastState.compose env37267 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37267 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env37268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,479,38161,2420,1024,32769,4160,21793,32784,3,469,65,34952,38160,50433,56436,1501,33,256,21792,38360,648]

theorem envBound37268 : H12AffineFastState.Bounded env37268 := by
  intro p hp
  have h : env37268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37267_37268 : H12AffineEnvironment.transform 12 349 env37267 = env37268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37267 == env37268) = true)

theorem identity37268 : scanCanonicalize (H12AffineFastState.compose env37268 (packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound37268 : packedSelected [0,1,4,7,8,9,10,12,16,18] rootPS < 2^1333 := by decide +kernel

def env37269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,216,479,5577,2420,1024,217,4160,21793,200,3,469,65,2128,5576,17881,23724,1501,33,256,21792,5376,648]

theorem envBound37269 : H12AffineFastState.Bounded env37269 := by
  intro p hp
  have h : env37269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37268_37269 : H12AffineEnvironment.transform 14 216 env37268 = env37269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env37268 == env37269) = true)

theorem identity37269 : scanCanonicalize (H12AffineFastState.compose env37269 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound37269 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37270 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,0,263,5393,2420,1024,1,4160,21793,16,3,269,65,2128,5392,17665,23668,1285,33,256,21792,5376,592]

theorem envBound37270 : H12AffineFastState.Bounded env37270 := by
  intro p hp
  have h : env37270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37269_37270 : H12AffineEnvironment.transform 6 88 env37269 = env37270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env37269 == env37270) = true)

theorem identity37270 : scanCanonicalize (H12AffineFastState.compose env37270 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37270 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env37271 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5376,0,263,5393,2420,1024,1,4160,33,16,3,269,65,2128,5392,4097,2420,1285,33,256,32,5376,592]

theorem envBound37271 : H12AffineFastState.Bounded env37271 := by
  intro p hp
  have h : env37271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37270_37271 : H12AffineEnvironment.transform 13 5376 env37270 = env37271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37270 == env37271) = true)

theorem identity37271 : scanCanonicalize (H12AffineFastState.compose env37271 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 869) := by decide +kernel

theorem selectedBound37271 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env37272 : List Nat := [2,4,8,16,32,64,88,256,512,1024,869,4096,349,5376,0,263,5393,529,1024,1,4160,33,16,3,269,65,821,5392,4097,529,1285,33,256,32,5376,592]

theorem envBound37272 : H12AffineFastState.Bounded env37272 := by
  intro p hp
  have h : env37272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37271_37272 : H12AffineEnvironment.transform 10 869 env37271 = env37272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 869 env37271 == env37272) = true)

theorem identity37272 : scanCanonicalize (H12AffineFastState.compose env37272 (packedSelected [2,3,5,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound37272 : packedSelected [2,3,5,7,9] rootPS < 2^1333 := by decide +kernel

def env37273 : List Nat := [2,4,8,16,32,49,41,256,512,1024,788,4096,300,5376,0,263,5393,529,1024,1,4145,33,16,3,269,48,821,5392,4097,529,1285,33,256,32,5376,545]

theorem envBound37273 : H12AffineFastState.Bounded env37273 := by
  intro p hp
  have h : env37273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37272_37273 : H12AffineEnvironment.transform 5 49 env37272 = env37273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env37272 == env37273) = true)

theorem identity37273 : scanCanonicalize (H12AffineFastState.compose env37273 (packedSelected [0,1,2,3,7,14] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound37273 : packedSelected [0,1,2,3,7,14] rootPS < 2^1333 := by decide +kernel

def env37274 : List Nat := [2,4,8,16,32,49,41,256,512,1024,788,1589,300,821,0,263,804,529,1024,1,1540,33,16,3,269,48,821,805,1588,529,1285,33,256,32,821,545]

theorem envBound37274 : H12AffineFastState.Bounded env37274 := by
  intro p hp
  have h : env37274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37273_37274 : H12AffineEnvironment.transform 11 1589 env37273 = env37274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env37273 == env37274) = true)

theorem identity37274 : scanCanonicalize (H12AffineFastState.compose env37274 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37274 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37275 : List Nat := [2,4,8,16,32,49,41,256,512,53,788,512,300,821,0,263,804,529,53,1,561,33,16,3,269,48,821,805,513,529,304,33,256,32,821,545]

theorem envBound37275 : H12AffineFastState.Bounded env37275 := by
  intro p hp
  have h : env37275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37274_37275 : H12AffineEnvironment.transform 9 53 env37274 = env37275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37274 == env37275) = true)

end H12CloudChart1