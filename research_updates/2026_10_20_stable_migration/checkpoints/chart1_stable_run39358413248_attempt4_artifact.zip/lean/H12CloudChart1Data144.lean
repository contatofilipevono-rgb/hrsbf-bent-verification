import H12CloudChart1Data143

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans36523_36524 : H12AffineEnvironment.transform 13 5456 env36523 = env36524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env36523 == env36524) = true)

theorem identity36524 : scanCanonicalize (H12AffineFastState.compose env36524 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36524 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,0,263,5441,2340,1024,1,4112,113,64,83,348,64,2128,5441,4176,2420,1284,112,256,113,5456,513]

theorem envBound36525 : H12AffineFastState.Bounded env36525 := by
  intro p hp
  have h : env36525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36524_36525 : H12AffineEnvironment.transform 12 349 env36524 = env36525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36524 == env36525) = true)

theorem identity36525 : scanCanonicalize (H12AffineFastState.compose env36525 (packedSelected [1,3,4,5,8,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36525 : packedSelected [1,3,4,5,8,9,11] rootPS < 2^1333 := by decide +kernel

def env36526 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,0,263,5393,2340,1024,1,4112,33,16,3,268,16,2048,5393,4096,2340,1284,32,256,33,5376,513]

theorem envBound36526 : H12AffineFastState.Bounded env36526 := by
  intro p hp
  have h : env36526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36525_36526 : H12AffineEnvironment.transform 5 16 env36525 = env36526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36525 == env36526) = true)

theorem identity36526 : scanCanonicalize (H12AffineFastState.compose env36526 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36526 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36527 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,0,34,5172,2049,1024,1,4112,33,16,3,41,16,2048,5172,4096,2049,1057,32,37,33,5157,513]

theorem envBound36527 : H12AffineFastState.Bounded env36527 := by
  intro p hp
  have h : env36527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36526_36527 : H12AffineEnvironment.transform 7 37 env36526 = env36527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36526 == env36527) = true)

def env36528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,4194304,21913,98645,8328,64,4592844,16536,17800,431512,20700,4235733,256,21793,46212,96010]

theorem envBound36528 : H12AffineFastState.Bounded env36528 := by
  intro p hp
  have h : env36528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36499_36528 : H12AffineEnvironment.transform 20 17729 env36499 = env36528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env36499 == env36528) = true)

def env36529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21792,21913,98645,8328,64,410092,16536,17800,431512,20700,62709,256,21793,46212,96010]

theorem envBound36529 : H12AffineFastState.Bounded env36529 := by
  intro p hp
  have h : env36529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36528_36529 : H12AffineEnvironment.transform 21 21792 env36528 = env36529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env36528 == env36529) = true)

theorem identity36529 : scanCanonicalize (H12AffineFastState.compose env36529 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound36529 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,17729,21792,21913,21763,8328,64,410092,16536,17800,431512,20700,62709,256,21793,46212,41820]

theorem envBound36530 : H12AffineFastState.Bounded env36530 := by
  intro p hp
  have h : env36530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36529_36530 : H12AffineEnvironment.transform 15 54358 env36529 = env36530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env36529 == env36530) = true)

theorem identity36530 : scanCanonicalize (H12AffineFastState.compose env36530 (packedSelected [3,10,12,15,21,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound36530 : packedSelected [3,10,12,15,21,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env36531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35325,1024,32769,17729,21792,21913,21763,8328,64,182289,16536,17800,138341,20700,62709,256,21793,46212,41820]

theorem envBound36531 : H12AffineFastState.Bounded env36531 := by
  intro p hp
  have h : env36531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36530_36531 : H12AffineEnvironment.transform 17 35325 env36530 = env36531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env36530 == env36531) = true)

theorem identity36531 : scanCanonicalize (H12AffineFastState.compose env36531 (packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 30113) := by decide +kernel

theorem selectedBound36531 : packedSelected [0,1,3,4,5,6,7,8,9,10,11,12,15,19,21,23] rootPS < 2^1333 := by decide +kernel

def env36532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30113,8695,131072,31836,1024,30112,17729,21792,21913,21763,8328,64,146864,16536,17800,138341,20700,340,256,21793,16677,22269]

theorem envBound36532 : H12AffineFastState.Bounded env36532 := by
  intro p hp
  have h : env36532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36531_36532 : H12AffineEnvironment.transform 14 30113 env36531 = env36532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30113 env36531 == env36532) = true)

theorem identity36532 : scanCanonicalize (H12AffineFastState.compose env36532 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound36532 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env36533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8233,8695,131072,10708,1024,8232,4297,168,17,139,8328,64,146864,5392,4096,138341,1364,340,256,169,5293,885]

theorem envBound36533 : H12AffineFastState.Bounded env36533 := by
  intro p hp
  have h : env36533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36532_36533 : H12AffineEnvironment.transform 13 5512 env36532 = env36533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env36532 == env36533) = true)

theorem identity36533 : scanCanonicalize (H12AffineFastState.compose env36533 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound36533 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env36534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8233,8695,5357,10708,1024,8232,4297,168,17,139,8328,64,10589,5392,4096,2184,1364,340,256,169,5293,885]

theorem envBound36534 : H12AffineFastState.Bounded env36534 := by
  intro p hp
  have h : env36534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36533_36534 : H12AffineEnvironment.transform 16 5357 env36533 = env36534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env36533 == env36534) = true)

theorem identity36534 : scanCanonicalize (H12AffineFastState.compose env36534 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound36534 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5512,0,478,5357,2557,1024,1,4297,168,17,139,161,64,2420,5392,4096,2184,1364,340,256,169,5293,885]

theorem envBound36535 : H12AffineFastState.Bounded env36535 := by
  intro p hp
  have h : env36535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36534_36535 : H12AffineEnvironment.transform 12 41 env36534 = env36535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env36534 == env36535) = true)

theorem identity36535 : scanCanonicalize (H12AffineFastState.compose env36535 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound36535 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env36536 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,41,5157,0,115,5357,2128,1024,1,4297,168,17,139,161,64,2265,5309,4096,2184,1273,249,173,169,5293,728]

theorem envBound36536 : H12AffineFastState.Bounded env36536 := by
  intro p hp
  have h : env36536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36535_36536 : H12AffineEnvironment.transform 7 173 env36535 = env36536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env36535 == env36536) = true)

theorem identity36536 : scanCanonicalize (H12AffineFastState.compose env36536 (packedSelected [6,12] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound36536 : packedSelected [6,12] rootPS < 2^1333 := by decide +kernel

def env36537 : List Nat := [2,4,8,16,32,64,128,173,512,172,2048,4096,41,4233,0,115,4161,2128,172,1,4297,168,17,139,161,64,2265,4113,4096,2184,85,249,173,169,4097,728]

theorem envBound36537 : H12AffineFastState.Bounded env36537 := by
  intro p hp
  have h : env36537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36536_36537 : H12AffineEnvironment.transform 9 172 env36536 = env36537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env36536 == env36537) = true)

theorem identity36537 : scanCanonicalize (H12AffineFastState.compose env36537 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36537 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env36538 : List Nat := [2,4,8,16,32,64,9,36,512,37,2048,4096,41,4096,0,115,4161,2128,37,1,4160,33,17,2,40,64,2128,4113,4096,2049,85,112,36,32,4097,593]

theorem envBound36538 : H12AffineFastState.Bounded env36538 := by
  intro p hp
  have h : env36538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36537_36538 : H12AffineEnvironment.transform 6 9 env36537 = env36538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36537 == env36538) = true)

theorem identity36538 : scanCanonicalize (H12AffineFastState.compose env36538 (packedSelected [0,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound36538 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env36539 : List Nat := [2,4,8,16,32,64,9,36,512,37,80,4096,41,4096,0,115,4161,0,37,1,4160,33,17,2,40,64,0,4113,4096,81,85,112,36,32,4097,593]

theorem envBound36539 : H12AffineFastState.Bounded env36539 := by
  intro p hp
  have h : env36539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36538_36539 : H12AffineEnvironment.transform 10 80 env36538 = env36539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env36538 == env36539) = true)

theorem identity36539 : scanCanonicalize (H12AffineFastState.compose env36539 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound36539 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36540 : List Nat := [2,4,8,16,32,64,9,36,512,37,80,64,41,64,0,115,1,0,37,1,0,33,17,2,40,64,0,81,64,81,85,112,36,32,65,593]

theorem envBound36540 : H12AffineFastState.Bounded env36540 := by
  intro p hp
  have h : env36540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36539_36540 : H12AffineEnvironment.transform 11 64 env36539 = env36540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env36539 == env36540) = true)

theorem identity36540 : scanCanonicalize (H12AffineFastState.compose env36540 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36540 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36541 : List Nat := [2,4,8,16,32,17,9,36,512,37,1,17,41,17,0,34,1,0,37,1,0,33,17,2,40,17,0,0,17,0,4,33,36,32,16,512]

theorem envBound36541 : H12AffineFastState.Bounded env36541 := by
  intro p hp
  have h : env36541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36540_36541 : H12AffineEnvironment.transform 5 17 env36540 = env36541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36540 == env36541) = true)

theorem identity36541 : scanCanonicalize (H12AffineFastState.compose env36541 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36541 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36542 : List Nat := [2,4,8,16,1,17,9,5,512,4,1,17,8,17,0,3,1,0,4,1,0,0,17,2,9,17,0,0,17,0,4,0,5,1,16,512]

theorem envBound36542 : H12AffineFastState.Bounded env36542 := by
  intro p hp
  have h : env36542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36541_36542 : H12AffineEnvironment.transform 4 1 env36541 = env36542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36541 == env36542) = true)

theorem identity36542 : scanCanonicalize (H12AffineFastState.compose env36542 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound36542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36543 : List Nat := [2,4,8,16,1,17,9,5,5,4,1,17,8,17,0,3,1,0,4,1,0,0,17,2,9,17,0,0,17,0,4,0,5,1,16,5]

theorem envBound36543 : H12AffineFastState.Bounded env36543 := by
  intro p hp
  have h : env36543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36542_36543 : H12AffineEnvironment.transform 8 5 env36542 = env36543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env36542 == env36543) = true)

theorem identity36543 : scanCanonicalize (H12AffineFastState.compose env36543 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound36543 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36544 : List Nat := [2,4,8,10,1,11,9,5,5,4,1,11,8,11,0,3,1,0,4,1,0,0,11,2,9,11,0,0,11,0,4,0,5,1,10,5]

theorem envBound36544 : H12AffineFastState.Bounded env36544 := by
  intro p hp
  have h : env36544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36543_36544 : H12AffineEnvironment.transform 3 10 env36543 = env36544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env36543 == env36544) = true)

theorem identity36544 : scanCanonicalize (H12AffineFastState.compose env36544 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound36544 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36545 : List Nat := [2,4,3,1,1,0,2,5,5,4,1,0,3,0,0,3,1,0,4,1,0,0,0,2,2,0,0,0,0,0,4,0,5,1,1,5]

theorem envBound36545 : H12AffineFastState.Bounded env36545 := by
  intro p hp
  have h : env36545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36544_36545 : H12AffineEnvironment.transform 2 3 env36544 = env36545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env36544 == env36545) = true)

theorem identity36545 : scanCanonicalize (H12AffineFastState.compose env36545 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound36545 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36546 : List Nat := [2,3,3,1,1,0,2,2,2,3,1,0,3,0,0,3,1,0,3,1,0,0,0,2,2,0,0,0,0,0,3,0,2,1,1,2]

theorem envBound36546 : H12AffineFastState.Bounded env36546 := by
  intro p hp
  have h : env36546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36545_36546 : H12AffineEnvironment.transform 1 3 env36545 = env36546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env36545 == env36546) = true)

def env36547 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17729,21793,21913,98645,8328,64,410093,16536,17800,431512,20700,62708,256,21793,46212,96010]

theorem envBound36547 : H12AffineFastState.Bounded env36547 := by
  intro p hp
  have h : env36547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36528_36547 : H12AffineEnvironment.transform 21 21793 env36528 = env36547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env36528 == env36547) = true)

theorem identity36547 : scanCanonicalize (H12AffineFastState.compose env36547 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound36547 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,131072,262144,1024,32769,17729,21793,21913,138,8328,64,410093,16536,17800,431512,20700,62708,256,21793,46212,63189]

theorem envBound36548 : H12AffineFastState.Bounded env36548 := by
  intro p hp
  have h : env36548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36547_36548 : H12AffineEnvironment.transform 15 33247 env36547 = env36548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env36547 == env36548) = true)

def env36549 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33031,131072,262144,1024,32769,17729,21793,21825,82,8272,64,409909,16448,17744,431424,20484,62508,256,21793,46172,62989]

theorem envBound36549 : H12AffineFastState.Bounded env36549 := by
  intro p hp
  have h : env36549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36548_36549 : H12AffineEnvironment.transform 6 88 env36548 = env36549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env36548 == env36549) = true)

theorem identity36549 : scanCanonicalize (H12AffineFastState.compose env36549 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound36549 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env36550 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,33031,131072,146744,1024,32769,17729,21793,21825,82,8272,64,31757,16448,17744,43128,20484,62508,256,21793,46172,62989]

theorem envBound36550 : H12AffineFastState.Bounded env36550 := by
  intro p hp
  have h : env36550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36549_36550 : H12AffineEnvironment.transform 17 146744 env36549 = env36550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env36549 == env36550) = true)

theorem identity36550 : scanCanonicalize (H12AffineFastState.compose env36550 (packedSelected [0,9,21,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound36550 : packedSelected [0,9,21,22,27] rootPS < 2^1333 := by decide +kernel

def env36551 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,8541,8282,131072,146744,1024,8540,17729,21793,21825,82,8272,64,31757,16448,17744,2341,20484,21873,256,21793,5377,22352]

theorem envBound36551 : H12AffineFastState.Bounded env36551 := by
  intro p hp
  have h : env36551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36550_36551 : H12AffineEnvironment.transform 14 8541 env36550 = env36551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env36550 == env36551) = true)

theorem identity36551 : scanCanonicalize (H12AffineFastState.compose env36551 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound36551 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env36552 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,8541,8282,131072,146744,1024,8540,4112,112,16,82,8272,64,10588,5393,4097,2341,1365,32,256,112,5377,513]

theorem envBound36552 : H12AffineFastState.Bounded env36552 := by
  intro p hp
  have h : env36552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36551_36552 : H12AffineEnvironment.transform 13 5457 env36551 = env36552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env36551 == env36552) = true)

theorem identity36552 : scanCanonicalize (H12AffineFastState.compose env36552 (packedSelected [0,2,6,7,9,14,20,22] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36552 : packedSelected [0,2,6,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env36553 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8202,131072,146744,1024,8460,4112,32,16,2,8192,16,10508,5393,4097,2341,1285,32,256,32,5377,513]

theorem envBound36553 : H12AffineFastState.Bounded env36553 := by
  intro p hp
  have h : env36553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36552_36553 : H12AffineEnvironment.transform 5 16 env36552 = env36553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36552 == env36553) = true)

theorem identity36553 : scanCanonicalize (H12AffineFastState.compose env36553 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound36553 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36554 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8202,5392,10280,1024,8460,4112,32,16,2,8192,16,10508,5393,4097,2341,1285,32,256,32,5377,513]

theorem envBound36554 : H12AffineFastState.Bounded env36554 := by
  intro p hp
  have h : env36554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36553_36554 : H12AffineEnvironment.transform 16 5392 env36553 = env36554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env36553 == env36554) = true)

theorem identity36554 : scanCanonicalize (H12AffineFastState.compose env36554 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound36554 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36555 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8,5377,261,2,5392,2080,1024,260,4112,32,16,2,8,16,2308,5393,4097,2341,1285,32,256,32,5377,513]

theorem envBound36555 : H12AffineFastState.Bounded env36555 := by
  intro p hp
  have h : env36555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36554_36555 : H12AffineEnvironment.transform 12 8 env36554 = env36555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env36554 == env36555) = true)

theorem identity36555 : scanCanonicalize (H12AffineFastState.compose env36555 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound36555 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36556 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8,4405,261,2,4388,2080,52,260,4112,32,16,2,8,16,2308,4389,4097,2341,305,32,256,32,4405,513]

theorem envBound36556 : H12AffineFastState.Bounded env36556 := by
  intro p hp
  have h : env36556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36555_36556 : H12AffineEnvironment.transform 9 52 env36555 = env36556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36555 == env36556) = true)

theorem identity36556 : scanCanonicalize (H12AffineFastState.compose env36556 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound36556 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env36557 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2064,8,2341,261,2,2356,2080,52,260,2048,32,16,2,8,16,2308,2357,2065,2341,305,32,256,32,2341,513]

theorem envBound36557 : H12AffineFastState.Bounded env36557 := by
  intro p hp
  have h : env36557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36556_36557 : H12AffineEnvironment.transform 11 2064 env36556 = env36557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env36556 == env36557) = true)

theorem identity36557 : scanCanonicalize (H12AffineFastState.compose env36557 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound36557 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env36558 : List Nat := [2,4,8,16,32,16,8,256,512,52,529,513,8,820,261,2,805,561,52,260,529,32,16,2,8,16,789,804,512,820,305,32,256,32,820,513]

theorem envBound36558 : H12AffineFastState.Bounded env36558 := by
  intro p hp
  have h : env36558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36557_36558 : H12AffineEnvironment.transform 10 529 env36557 = env36558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env36557 == env36558) = true)

theorem identity36558 : scanCanonicalize (H12AffineFastState.compose env36558 (packedSelected [1,3,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36558 : packedSelected [1,3,4,9] rootPS < 2^1333 := by decide +kernel

def env36559 : List Nat := [2,4,8,16,32,16,8,36,512,52,529,513,8,528,33,2,513,561,52,32,529,32,16,2,8,16,561,512,512,528,21,32,36,32,528,513]

theorem envBound36559 : H12AffineFastState.Bounded env36559 := by
  intro p hp
  have h : env36559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36558_36559 : H12AffineEnvironment.transform 7 36 env36558 = env36559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36558 == env36559) = true)

theorem identity36559 : scanCanonicalize (H12AffineFastState.compose env36559 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound36559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36560 : List Nat := [2,4,8,16,32,16,8,36,17,52,0,16,8,1,33,2,16,32,52,32,0,32,16,2,8,16,32,17,17,1,21,32,36,32,1,16]

theorem envBound36560 : H12AffineFastState.Bounded env36560 := by
  intro p hp
  have h : env36560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36559_36560 : H12AffineEnvironment.transform 8 17 env36559 = env36560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36559 == env36560) = true)

theorem identity36560 : scanCanonicalize (H12AffineFastState.compose env36560 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36561 : List Nat := [2,4,8,16,16,16,8,20,17,4,0,16,8,1,17,2,16,16,4,16,0,16,16,2,8,16,16,17,17,1,21,16,20,16,1,16]

theorem envBound36561 : H12AffineFastState.Bounded env36561 := by
  intro p hp
  have h : env36561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36560_36561 : H12AffineEnvironment.transform 4 16 env36560 = env36561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36560 == env36561) = true)

theorem identity36561 : scanCanonicalize (H12AffineFastState.compose env36561 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36561 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36562 : List Nat := [2,4,8,0,0,0,8,4,1,4,0,0,8,1,1,2,0,0,4,0,0,0,0,2,8,0,0,1,1,1,5,0,4,0,1,0]

theorem envBound36562 : H12AffineFastState.Bounded env36562 := by
  intro p hp
  have h : env36562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36561_36562 : H12AffineEnvironment.transform 3 0 env36561 = env36562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36561 == env36562) = true)

def env36563 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33030,131072,262144,1024,32769,17729,21793,21824,83,8273,64,409908,16449,17745,431425,20485,62509,256,21793,46173,62988]

theorem envBound36563 : H12AffineFastState.Bounded env36563 := by
  intro p hp
  have h : env36563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36548_36563 : H12AffineEnvironment.transform 6 89 env36548 = env36563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env36548 == env36563) = true)

theorem identity36563 : scanCanonicalize (H12AffineFastState.compose env36563 (packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS)) = affineNative (2^(17+1) ^^^ 171061) := by decide +kernel

theorem selectedBound36563 : packedSelected [0,3,4,7,10,14,16,20,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env36564 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,33030,131072,171061,1024,32769,17729,21793,21824,83,8273,64,56577,16449,17745,2420,20485,62509,256,21793,46173,62988]

theorem envBound36564 : H12AffineFastState.Bounded env36564 := by
  intro p hp
  have h : env36564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36563_36564 : H12AffineEnvironment.transform 17 171061 env36563 = env36564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171061 env36563 == env36564) = true)

theorem identity36564 : scanCanonicalize (H12AffineFastState.compose env36564 (packedSelected [3,4,5,7,8,9,10,16,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound36564 : packedSelected [3,4,5,7,8,9,10,16,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env36565 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29709,29963,131072,157752,1024,29708,17729,21793,21824,83,8273,64,10508,16449,17745,2420,20485,32,256,21793,16464,513]

theorem envBound36565 : H12AffineFastState.Bounded env36565 := by
  intro p hp
  have h : env36565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36564_36565 : H12AffineEnvironment.transform 14 29709 env36564 = env36565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env36564 == env36565) = true)

def env36566 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound36566 : H12AffineFastState.Bounded env36566 := by
  intro p hp
  have h : env36566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36384_36566 : H12AffineEnvironment.transform 18 1025 env36384 = env36566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env36384 == env36566) = true)

theorem identity36566 : scanCanonicalize (H12AffineFastState.compose env36566 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237589) := by decide +kernel

theorem selectedBound36566 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env36567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237589,16777216,8328,64,23454868,18973837,160197,2417813,19112069,23160257,257,17031224,16974236,19040082]

theorem envBound36567 : H12AffineFastState.Bounded env36567 := by
  intro p hp
  have h : env36567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36566_36567 : H12AffineEnvironment.transform 22 2237589 env36566 = env36567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237589 env36566 == env36567) = true)

def env36568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237589,242968,8328,64,6705548,2240917,160197,2417813,2102685,6475993,257,21792,46212,2175562]

theorem envBound36568 : H12AffineFastState.Bounded env36568 := by
  intro p hp
  have h : env36568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36567_36568 : H12AffineEnvironment.transform 23 242968 env36567 = env36568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242968 env36567 == env36568) = true)

def env36569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237589,242968,8328,64,2144540,2240917,160197,2417813,2102685,2373705,257,21792,46212,2175562]

theorem envBound36569 : H12AffineFastState.Bounded env36569 := by
  intro p hp
  have h : env36569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36568_36569 : H12AffineEnvironment.transform 21 452752 env36568 = env36569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env36568 == env36569) = true)

def env36570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144597,242968,8328,64,43356,139733,160197,324821,1501,272393,257,21792,46212,74250]

theorem envBound36570 : H12AffineFastState.Bounded env36570 := by
  intro p hp
  have h : env36570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36569_36570 : H12AffineEnvironment.transform 20 4160 env36569 = env36570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36569 == env36570) = true)

theorem identity36570 : scanCanonicalize (H12AffineFastState.compose env36570 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound36570 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,452752,144597,156102,8328,64,43356,139733,160197,324821,1501,272393,257,21792,46212,63188]

theorem envBound36571 : H12AffineFastState.Bounded env36571 := by
  intro p hp
  have h : env36571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36570_36571 : H12AffineEnvironment.transform 15 54494 env36570 = env36571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env36570 == env36571) = true)

def env36572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,262144,1025,32769,4160,305360,29845,8582,8328,64,43356,24981,12677,324821,1501,272393,257,21792,46212,63188]

theorem envBound36572 : H12AffineFastState.Bounded env36572 := by
  intro p hp
  have h : env36572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36571_36572 : H12AffineEnvironment.transform 16 16448 env36571 = env36572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env36571 == env36572) = true)

theorem identity36572 : scanCanonicalize (H12AffineFastState.compose env36572 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound36572 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29963,16448,262144,1025,8660,4160,264453,29845,8582,8328,64,2185,24981,12677,283904,1501,272393,257,21792,5457,22273]

theorem envBound36573 : H12AffineFastState.Bounded env36573 := by
  intro p hp
  have h : env36573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36572_36573 : H12AffineEnvironment.transform 14 8661 env36572 = env36573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env36572 == env36573) = true)

theorem identity36573 : scanCanonicalize (H12AffineFastState.compose env36573 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36573 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env36574 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,29963,16448,10281,1025,8660,4160,8492,29845,8582,8328,64,2185,24981,12677,32041,1501,32,257,21792,5457,22273]

theorem envBound36574 : H12AffineFastState.Bounded env36574 := by
  intro p hp
  have h : env36574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36573_36574 : H12AffineEnvironment.transform 17 10281 env36573 = env36574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36573 == env36574) = true)

theorem identity36574 : scanCanonicalize (H12AffineFastState.compose env36574 (packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36574 : packedSelected [0,1,2,5,6,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env36575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,16448,10281,1025,8540,4160,8492,29725,8462,8192,64,2049,24861,12557,32041,1365,32,257,21792,5457,22273]

theorem envBound36575 : H12AffineFastState.Bounded env36575 := by
  intro p hp
  have h : env36575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36574_36575 : H12AffineEnvironment.transform 6 8 env36574 = env36575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36574 == env36575) = true)

theorem identity36575 : scanCanonicalize (H12AffineFastState.compose env36575 (packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36575 : packedSelected [0,1,2,6,7,8,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env36576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,5441,10281,1025,8540,4160,8492,8476,8462,8192,64,2049,13340,12557,10280,1365,32,257,33,5457,512]

theorem envBound36576 : H12AffineFastState.Bounded env36576 := by
  intro p hp
  have h : env36576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36575_36576 : H12AffineEnvironment.transform 13 5377 env36575 = env36576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36575 == env36576) = true)

theorem identity36576 : scanCanonicalize (H12AffineFastState.compose env36576 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36576 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36577 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,5441,10248,1025,8540,4160,8461,8476,8462,8192,64,2049,13340,12557,10249,1365,1,257,0,5457,512]

theorem envBound36577 : H12AffineFastState.Bounded env36577 := by
  intro p hp
  have h : env36577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36576_36577 : H12AffineEnvironment.transform 4 1 env36576 = env36577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36576 == env36577) = true)

theorem identity36577 : scanCanonicalize (H12AffineFastState.compose env36577 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36577 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36578 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,5377,0,343,5441,2389,1025,1,4160,80,65,83,349,64,2049,5441,4176,2388,1365,1,257,0,5457,512]

theorem envBound36578 : H12AffineFastState.Bounded env36578 := by
  intro p hp
  have h : env36578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36577_36578 : H12AffineEnvironment.transform 12 349 env36577 = env36578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36577 == env36578) = true)

theorem identity36578 : scanCanonicalize (H12AffineFastState.compose env36578 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound36578 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env36579 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,16,349,1297,0,343,1361,2389,1025,1,80,80,65,83,349,64,2049,1361,64,2388,1365,1,257,0,1345,512]

theorem envBound36579 : H12AffineFastState.Bounded env36579 := by
  intro p hp
  have h : env36579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36578_36579 : H12AffineEnvironment.transform 11 16 env36578 = env36579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36578 == env36579) = true)

theorem identity36579 : scanCanonicalize (H12AffineFastState.compose env36579 (packedSelected [11] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound36579 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env36580 : List Nat := [2,4,8,16,1,64,8,256,512,321,2048,16,349,80,0,343,16,2389,320,1,80,80,65,83,349,64,2049,16,64,2388,20,1,257,0,0,512]

theorem envBound36580 : H12AffineFastState.Bounded env36580 := by
  intro p hp
  have h : env36580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36579_36580 : H12AffineEnvironment.transform 9 321 env36579 = env36580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36579 == env36580) = true)

theorem identity36580 : scanCanonicalize (H12AffineFastState.compose env36580 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound36580 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36581 : List Nat := [2,4,8,16,1,64,8,256,512,321,260,16,349,80,0,343,16,81,320,1,80,80,65,83,349,64,261,16,64,80,20,1,257,0,0,512]

theorem envBound36581 : H12AffineFastState.Bounded env36581 := by
  intro p hp
  have h : env36581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36580_36581 : H12AffineEnvironment.transform 10 260 env36580 = env36581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env36580 == env36581) = true)

theorem identity36581 : scanCanonicalize (H12AffineFastState.compose env36581 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound36581 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env36582 : List Nat := [2,4,8,16,1,64,8,84,512,21,80,16,9,80,0,3,16,81,20,1,80,80,65,83,9,64,81,16,64,80,20,1,85,0,0,512]

theorem envBound36582 : H12AffineFastState.Bounded env36582 := by
  intro p hp
  have h : env36582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36581_36582 : H12AffineEnvironment.transform 7 84 env36581 = env36582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env36581 == env36582) = true)

theorem identity36582 : scanCanonicalize (H12AffineFastState.compose env36582 (packedSelected [15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36582 : packedSelected [15] rootPS < 2^1333 := by decide +kernel

def env36583 : List Nat := [2,4,8,16,1,16,8,4,512,21,0,16,9,0,0,3,16,1,20,1,0,0,17,3,9,16,1,16,16,0,20,1,5,0,0,512]

theorem envBound36583 : H12AffineFastState.Bounded env36583 := by
  intro p hp
  have h : env36583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36582_36583 : H12AffineEnvironment.transform 5 16 env36582 = env36583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36582 == env36583) = true)

theorem identity36583 : scanCanonicalize (H12AffineFastState.compose env36583 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36583 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36584 : List Nat := [2,4,8,1,1,1,8,4,512,4,0,1,9,0,0,3,1,1,5,1,0,0,0,3,9,1,1,1,1,0,5,1,5,0,0,512]

theorem envBound36584 : H12AffineFastState.Bounded env36584 := by
  intro p hp
  have h : env36584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36583_36584 : H12AffineEnvironment.transform 3 1 env36583 = env36584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36583 == env36584) = true)

theorem identity36584 : scanCanonicalize (H12AffineFastState.compose env36584 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound36584 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36585 : List Nat := [2,1,8,1,1,1,8,1,512,1,0,1,9,0,0,3,1,1,0,1,0,0,0,3,9,1,1,1,1,0,0,1,0,0,0,512]

theorem envBound36585 : H12AffineFastState.Bounded env36585 := by
  intro p hp
  have h : env36585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36584_36585 : H12AffineEnvironment.transform 1 1 env36584 = env36585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env36584 == env36585) = true)

theorem identity36585 : scanCanonicalize (H12AffineFastState.compose env36585 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36585 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36586 : List Nat := [2,1,8,1,1,1,8,1,1,1,0,1,9,0,0,3,1,1,0,1,0,0,0,3,9,1,1,1,1,0,0,1,0,0,0,1]

theorem envBound36586 : H12AffineFastState.Bounded env36586 := by
  intro p hp
  have h : env36586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36585_36586 : H12AffineEnvironment.transform 8 1 env36585 = env36586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36585 == env36586) = true)

def env36587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,262144,1025,32769,4160,305361,29844,8583,8328,64,43356,24980,12676,324821,1501,272393,257,21792,46212,63188]

theorem envBound36587 : H12AffineFastState.Bounded env36587 := by
  intro p hp
  have h : env36587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36571_36587 : H12AffineEnvironment.transform 16 16449 env36571 = env36587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env36571 == env36587) = true)

theorem identity36587 : scanCanonicalize (H12AffineFastState.compose env36587 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound36587 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30082,16449,262144,1025,8541,4160,264589,29844,8583,8328,64,2048,24980,12676,284041,1501,272393,257,21792,5592,22408]

theorem envBound36588 : H12AffineFastState.Bounded env36588 := by
  intro p hp
  have h : env36588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36587_36588 : H12AffineEnvironment.transform 14 8540 env36587 = env36588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env36587 == env36588) = true)

theorem identity36588 : scanCanonicalize (H12AffineFastState.compose env36588 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound36588 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env36589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30082,16449,32040,1025,8541,4160,29861,29844,8583,8328,64,2048,24980,12676,10401,1501,21793,257,21792,5592,22408]

theorem envBound36589 : H12AffineFastState.Bounded env36589 := by
  intro p hp
  have h : env36589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36588_36589 : H12AffineEnvironment.transform 17 32040 env36588 = env36589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env36588 == env36589) = true)

theorem identity36589 : scanCanonicalize (H12AffineFastState.compose env36589 (packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36589 : packedSelected [0,3,4,5,7,9,11,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env36590 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8461,30082,16400,32040,1025,8460,4113,29861,29844,8583,8328,17,2048,24980,12676,10401,1420,21793,257,21792,5513,22408]

theorem envBound36590 : H12AffineFastState.Bounded env36590 := by
  intro p hp
  have h : env36590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36589_36590 : H12AffineEnvironment.transform 5 17 env36589 = env36590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36589 == env36590) = true)

theorem identity36590 : scanCanonicalize (H12AffineFastState.compose env36590 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36590 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env36591 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,29962,16400,32040,1025,8460,4113,29741,29724,8463,8192,17,2048,24860,12556,10281,1284,21793,257,21792,5377,22272]

theorem envBound36591 : H12AffineFastState.Bounded env36591 := by
  intro p hp
  have h : env36591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36590_36591 : H12AffineEnvironment.transform 6 8 env36590 = env36591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36590 == env36591) = true)

theorem identity36591 : scanCanonicalize (H12AffineFastState.compose env36591 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound36591 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env36592 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8461,8203,5393,10281,1025,8460,4113,8492,8477,8463,8192,17,2048,13341,12556,10281,1284,32,257,33,5377,513]

theorem envBound36592 : H12AffineFastState.Bounded env36592 := by
  intro p hp
  have h : env36592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36591_36592 : H12AffineEnvironment.transform 13 5377 env36591 = env36592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env36591 == env36592) = true)

theorem identity36592 : scanCanonicalize (H12AffineFastState.compose env36592 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound36592 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36593 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1025,1,4113,33,16,2,269,17,2048,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound36593 : H12AffineFastState.Bounded env36593 := by
  intro p hp
  have h : env36593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36592_36593 : H12AffineEnvironment.transform 12 269 env36592 = env36593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env36592 == env36593) = true)

theorem identity36593 : scanCanonicalize (H12AffineFastState.compose env36593 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36593 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36594 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,35,5172,2049,1025,1,4113,33,16,2,40,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound36594 : H12AffineFastState.Bounded env36594 := by
  intro p hp
  have h : env36594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36593_36594 : H12AffineEnvironment.transform 7 37 env36593 = env36594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36593 == env36594) = true)

def env36595 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,0,35,1028,2049,1025,1,33,33,16,2,40,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound36595 : H12AffineFastState.Bounded env36595 := by
  intro p hp
  have h : env36595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36594_36595 : H12AffineEnvironment.transform 11 48 env36594 = env36595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36594 == env36595) = true)

theorem identity36595 : scanCanonicalize (H12AffineFastState.compose env36595 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound36595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36596 : List Nat := [2,4,8,16,32,17,8,37,512,548,2048,48,40,560,0,35,544,2049,549,1,33,33,16,2,40,17,2048,545,49,2049,517,32,36,33,560,513]

theorem envBound36596 : H12AffineFastState.Bounded env36596 := by
  intro p hp
  have h : env36596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36595_36596 : H12AffineEnvironment.transform 9 548 env36595 = env36596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env36595 == env36596) = true)

def env36597 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,48,40,32,0,35,48,2049,53,1,33,33,16,2,40,17,2048,49,49,2049,21,32,36,33,32,17]

theorem envBound36597 : H12AffineFastState.Bounded env36597 := by
  intro p hp
  have h : env36597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36596_36597 : H12AffineEnvironment.transform 8 16 env36596 = env36597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36596 == env36597) = true)

theorem identity36597 : scanCanonicalize (H12AffineFastState.compose env36597 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound36597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36598 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,40,32,0,35,48,27,53,1,33,33,16,2,40,17,26,49,49,27,21,32,36,33,32,17]

theorem envBound36598 : H12AffineFastState.Bounded env36598 := by
  intro p hp
  have h : env36598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36597_36598 : H12AffineEnvironment.transform 10 26 env36597 = env36598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env36597 == env36598) = true)

def leafEnv36598 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,48,40,32,0,35,48,27,53,1,33,33,16,2,20,40,1,17,26,49,49,27,21,32,36,33,5,35,32,17,1,33,0]

def active36598 : List Nat := [0,1,2,3,4]

def tree36598 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36598 : H12WitnessSearch.Good tree36598 := H12GlobalWitnessIndex.good

theorem leafIdentity36598 : H12AffineFastState.composeSystem env36598 rootObs = leafEnv36598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36598 rootObs == leafEnv36598) = true)

theorem terminalChecked36598 : H12PackedTerminal.terminalCheckFast leafEnv36598 active36598 tree36598 = true := by decide +kernel

def env36599 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,48,40,33,0,35,49,2049,52,1,33,33,16,2,40,17,2048,48,49,2049,20,32,36,33,33,16]

theorem envBound36599 : H12AffineFastState.Bounded env36599 := by
  intro p hp
  have h : env36599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36596_36599 : H12AffineEnvironment.transform 8 17 env36596 = env36599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env36596 == env36599) = true)

theorem identity36599 : scanCanonicalize (H12AffineFastState.compose env36599 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound36599 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36600 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,48,40,33,0,35,49,32,52,1,33,33,16,2,40,17,33,48,49,32,20,32,36,33,33,16]

theorem envBound36600 : H12AffineFastState.Bounded env36600 := by
  intro p hp
  have h : env36600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36599_36600 : H12AffineEnvironment.transform 10 33 env36599 = env36600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env36599 == env36600) = true)

def leafEnv36600 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,48,40,33,0,35,49,32,52,1,33,33,16,2,21,40,1,17,33,48,49,32,20,32,36,33,5,35,33,16,1,33,0]

def active36600 : List Nat := [0,1,2,3,4]

def tree36600 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36600 : H12WitnessSearch.Good tree36600 := H12GlobalWitnessIndex.good

theorem leafIdentity36600 : H12AffineFastState.composeSystem env36600 rootObs = leafEnv36600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36600 rootObs == leafEnv36600) = true)

theorem terminalChecked36600 : H12PackedTerminal.terminalCheckFast leafEnv36600 active36600 tree36600 = true := by decide +kernel

def env36601 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,0,35,1029,2049,1025,1,32,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound36601 : H12AffineFastState.Bounded env36601 := by
  intro p hp
  have h : env36601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36594_36601 : H12AffineEnvironment.transform 11 49 env36594 = env36601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36594 == env36601) = true)

theorem identity36601 : scanCanonicalize (H12AffineFastState.compose env36601 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36601 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36602 : List Nat := [2,4,8,16,32,17,8,37,16,1024,2048,49,40,1045,0,35,1029,2049,1025,1,32,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1045,17]

theorem envBound36602 : H12AffineFastState.Bounded env36602 := by
  intro p hp
  have h : env36602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36601_36602 : H12AffineEnvironment.transform 8 16 env36601 = env36602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36601 == env36602) = true)

def env36603 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,49,40,33,0,35,49,2049,53,1,32,33,16,2,40,17,2048,48,48,2049,21,32,36,33,33,17]

theorem envBound36603 : H12AffineFastState.Bounded env36603 := by
  intro p hp
  have h : env36603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36602_36603 : H12AffineEnvironment.transform 9 52 env36602 = env36603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36602 == env36603) = true)

theorem identity36603 : scanCanonicalize (H12AffineFastState.compose env36603 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound36603 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36604 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,40,33,0,35,49,27,53,1,32,33,16,2,40,17,26,48,48,27,21,32,36,33,33,17]

theorem envBound36604 : H12AffineFastState.Bounded env36604 := by
  intro p hp
  have h : env36604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36603_36604 : H12AffineEnvironment.transform 10 26 env36603 = env36604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env36603 == env36604) = true)

def leafEnv36604 : List Nat := [2,4,8,16,32,17,8,37,16,52,26,49,40,33,0,35,49,27,53,1,32,33,16,2,20,40,1,17,26,48,48,27,21,32,36,33,5,35,33,17,1,32,0]

def active36604 : List Nat := [0,1,2,3,4]

def tree36604 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36604 : H12WitnessSearch.Good tree36604 := H12GlobalWitnessIndex.good

theorem leafIdentity36604 : H12AffineFastState.composeSystem env36604 rootObs = leafEnv36604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36604 rootObs == leafEnv36604) = true)

theorem terminalChecked36604 : H12PackedTerminal.terminalCheckFast leafEnv36604 active36604 tree36604 = true := by decide +kernel

def env36605 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,49,40,32,0,35,48,2049,52,1,32,33,16,2,40,17,2048,49,48,2049,20,32,36,33,32,17]

theorem envBound36605 : H12AffineFastState.Bounded env36605 := by
  intro p hp
  have h : env36605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36602_36605 : H12AffineEnvironment.transform 9 53 env36602 = env36605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36602 == env36605) = true)

theorem identity36605 : scanCanonicalize (H12AffineFastState.compose env36605 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound36605 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36606 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,49,40,32,0,35,48,33,52,1,32,33,16,2,40,17,32,49,48,33,20,32,36,33,32,17]

theorem envBound36606 : H12AffineFastState.Bounded env36606 := by
  intro p hp
  have h : env36606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36605_36606 : H12AffineEnvironment.transform 10 32 env36605 = env36606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env36605 == env36606) = true)

def leafEnv36606 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,49,40,32,0,35,48,33,52,1,32,33,16,2,21,40,1,17,32,49,48,33,20,32,36,33,5,35,32,17,1,32,0]

def active36606 : List Nat := [0,1,2,3,4]

def tree36606 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36606 : H12WitnessSearch.Good tree36606 := H12GlobalWitnessIndex.good

theorem leafIdentity36606 : H12AffineFastState.composeSystem env36606 rootObs = leafEnv36606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36606 rootObs == leafEnv36606) = true)

theorem terminalChecked36606 : H12PackedTerminal.terminalCheckFast leafEnv36606 active36606 tree36606 = true := by decide +kernel

def env36607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144596,242968,8328,64,43357,139732,160197,324820,1500,272392,257,21792,46212,74251]

theorem envBound36607 : H12AffineFastState.Bounded env36607 := by
  intro p hp
  have h : env36607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36569_36607 : H12AffineEnvironment.transform 20 4161 env36569 = env36607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36569 == env36607) = true)

theorem identity36607 : scanCanonicalize (H12AffineFastState.compose env36607 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70863) := by decide +kernel

theorem selectedBound36607 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70863,262144,1025,32769,4161,392287,73755,41431,8328,64,43357,79131,91402,324820,1500,272392,257,21792,46212,74251]

theorem envBound36608 : H12AffineFastState.Bounded env36608 := by
  intro p hp
  have h : env36608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36607_36608 : H12AffineEnvironment.transform 16 70863 env36607 = env36608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70863 env36607 == env36608) = true)

def env36609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4161,392287,73755,41311,8192,64,43357,79131,91402,324700,1364,272392,257,21792,46092,74251]

theorem envBound36609 : H12AffineFastState.Bounded env36609 := by
  intro p hp
  have h : env36609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36608_36609 : H12AffineEnvironment.transform 6 8 env36608 = env36609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36608 == env36609) = true)

theorem identity36609 : scanCanonicalize (H12AffineFastState.compose env36609 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound36609 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70727,67619,1025,32769,4161,62588,73755,41311,8192,64,43357,79131,91402,130175,1364,73771,257,21792,46092,74251]

theorem envBound36610 : H12AffineFastState.Bounded env36610 := by
  intro p hp
  have h : env36610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36609_36610 : H12AffineEnvironment.transform 17 67619 env36609 = env36610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env36609 == env36610) = true)

theorem identity36610 : scanCanonicalize (H12AffineFastState.compose env36610 (packedSelected [0,2,4,5,6,7,10,14,15,16,18,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound36610 : packedSelected [0,2,4,5,6,7,10,14,15,16,18,22,24] rootPS < 2^1333 := by decide +kernel

def env36611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,56437,1025,32769,4161,62588,62541,41311,8192,64,43357,57677,45404,10281,1364,62589,257,21792,46092,63069]

theorem envBound36611 : H12AffineFastState.Bounded env36611 := by
  intro p hp
  have h : env36611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36610_36611 : H12AffineEnvironment.transform 15 54358 env36610 = env36611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env36610 == env36611) = true)

theorem identity36611 : scanCanonicalize (H12AffineFastState.compose env36611 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound36611 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env36612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,13388,10280,1025,29788,4161,33,16,21762,8192,64,23808,5392,17665,10281,1364,32,257,21792,16465,512]

theorem envBound36612 : H12AffineFastState.Bounded env36612 := by
  intro p hp
  have h : env36612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36611_36612 : H12AffineEnvironment.transform 14 29789 env36611 = env36612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env36611 == env36612) = true)

theorem identity36612 : scanCanonicalize (H12AffineFastState.compose env36612 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound36612 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4145,9324,8203,13388,10280,1025,9325,4161,33,16,1331,8192,64,3377,5392,5424,10281,1364,32,257,1297,4192,512]

theorem envBound36613 : H12AffineFastState.Bounded env36613 := by
  intro p hp
  have h : env36613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36612_36613 : H12AffineEnvironment.transform 13 4145 env36612 = env36613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env36612 == env36613) = true)

theorem identity36613 : scanCanonicalize (H12AffineFastState.compose env36613 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound36613 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3076,8192,3125,9324,8203,10312,10280,1025,9325,3141,33,16,1331,8192,64,3377,2324,2356,10281,1364,32,257,1297,3172,512]

theorem envBound36614 : H12AffineFastState.Bounded env36614 := by
  intro p hp
  have h : env36614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36613_36614 : H12AffineEnvironment.transform 11 3076 env36613 = env36614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env36613 == env36614) = true)

theorem identity36614 : scanCanonicalize (H12AffineFastState.compose env36614 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36614 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36615 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,2144,8192,2129,8200,8203,10312,10280,101,8201,2081,33,16,343,8192,64,2389,2324,2356,10281,304,32,257,373,2048,512]

theorem envBound36615 : H12AffineFastState.Bounded env36615 := by
  intro p hp
  have h : env36615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36614_36615 : H12AffineEnvironment.transform 9 100 env36614 = env36615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36614 == env36615) = true)

theorem identity36615 : scanCanonicalize (H12AffineFastState.compose env36615 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound36615 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env36616 : List Nat := [2,4,8,16,32,64,8,5,512,100,2048,2144,8192,2129,8200,8203,10312,10280,101,8201,2081,33,16,82,8192,64,2128,2065,2097,10281,53,32,4,112,2048,512]

theorem envBound36616 : H12AffineFastState.Bounded env36616 := by
  intro p hp
  have h : env36616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36615_36616 : H12AffineEnvironment.transform 7 5 env36615 = env36616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env36615 == env36616) = true)

theorem identity36616 : scanCanonicalize (H12AffineFastState.compose env36616 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2633) := by decide +kernel

theorem selectedBound36616 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36617 : List Nat := [2,4,8,16,32,64,8,5,512,100,2048,2144,2633,2129,2625,2626,513,609,101,2624,2081,33,16,82,2633,64,2128,2065,2097,608,53,32,4,112,2048,512]

theorem envBound36617 : H12AffineFastState.Bounded env36617 := by
  intro p hp
  have h : env36617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36616_36617 : H12AffineEnvironment.transform 12 2633 env36616 = env36617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2633 env36616 == env36617) = true)

theorem identity36617 : scanCanonicalize (H12AffineFastState.compose env36617 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound36617 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env36618 : List Nat := [2,4,8,16,32,48,8,5,512,20,2048,2064,2617,2081,2609,2610,513,529,21,2608,2081,33,16,34,2617,48,2080,2065,2097,528,53,32,4,0,2048,512]

theorem envBound36618 : H12AffineFastState.Bounded env36618 := by
  intro p hp
  have h : env36618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36617_36618 : H12AffineEnvironment.transform 5 48 env36617 = env36618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env36617 == env36618) = true)

theorem identity36618 : scanCanonicalize (H12AffineFastState.compose env36618 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound36618 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env36619 : List Nat := [2,4,8,16,32,48,8,5,512,20,528,512,41,561,33,34,513,529,21,32,561,33,16,34,41,48,560,513,545,528,53,32,4,0,528,512]

theorem envBound36619 : H12AffineFastState.Bounded env36619 := by
  intro p hp
  have h : env36619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36618_36619 : H12AffineEnvironment.transform 10 528 env36618 = env36619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env36618 == env36619) = true)

theorem identity36619 : scanCanonicalize (H12AffineFastState.compose env36619 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound36619 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36620 : List Nat := [2,4,8,16,32,48,8,5,33,20,49,33,41,16,33,34,32,48,21,32,16,33,16,34,41,48,17,32,0,49,53,32,4,0,49,33]

theorem envBound36620 : H12AffineFastState.Bounded env36620 := by
  intro p hp
  have h : env36620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36619_36620 : H12AffineEnvironment.transform 8 33 env36619 = env36620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env36619 == env36620) = true)

def env36621 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4161,392287,73755,41310,8193,64,43357,79131,91402,324701,1365,272392,257,21792,46093,74251]

theorem envBound36621 : H12AffineFastState.Bounded env36621 := by
  intro p hp
  have h : env36621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36608_36621 : H12AffineEnvironment.transform 6 9 env36608 = env36621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36608 == env36621) = true)

theorem identity36621 : scanCanonicalize (H12AffineFastState.compose env36621 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound36621 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env36622 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,4161,54561,73755,41310,8193,64,43357,79131,91402,122147,1365,65910,257,21792,46093,74251]

theorem envBound36622 : H12AffineFastState.Bounded env36622 := by
  intro p hp
  have h : env36622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36621_36622 : H12AffineEnvironment.transform 17 76158 env36621 = env36622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env36621 == env36622) = true)

theorem identity36622 : scanCanonicalize (H12AffineFastState.compose env36622 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound36622 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env36623 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,16401,32041,1025,32769,4161,54561,29772,41310,8193,64,43357,24908,12637,35188,1365,21793,257,21792,46093,30300]

theorem envBound36623 : H12AffineFastState.Bounded env36623 := by
  intro p hp
  have h : env36623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36622_36623 : H12AffineEnvironment.transform 15 21591 env36622 = env36623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env36622 == env36623) = true)

theorem identity36623 : scanCanonicalize (H12AffineFastState.compose env36623 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound36623 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env36624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21591,16401,32041,1025,29788,4161,8572,29772,21763,8193,64,23808,24908,12637,32041,1365,21793,257,21792,16464,30300]

theorem envBound36624 : H12AffineFastState.Bounded env36624 := by
  intro p hp
  have h : env36624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36623_36624 : H12AffineEnvironment.transform 14 29789 env36623 = env36624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env36623 == env36624) = true)

theorem identity36624 : scanCanonicalize (H12AffineFastState.compose env36624 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound36624 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13608,373,8575,13625,2049,1025,372,4161,8572,356,8235,8193,64,10280,5220,12637,2049,1365,8201,257,8200,13688,884]

theorem envBound36625 : H12AffineFastState.Bounded env36625 := by
  intro p hp
  have h : env36625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36624_36625 : H12AffineEnvironment.transform 13 13608 env36624 = env36625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env36624 == env36625) = true)

theorem identity36625 : scanCanonicalize (H12AffineFastState.compose env36625 (packedSelected [2,3,5,10,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound36625 : packedSelected [2,3,5,10,12,14] rootPS < 2^1333 := by decide +kernel

def env36626 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,12620,373,8575,12637,2049,101,372,4161,8572,356,8235,8193,64,10280,4096,12637,2049,305,8201,257,8200,12572,884]

theorem envBound36626 : H12AffineFastState.Bounded env36626 := by
  intro p hp
  have h : env36626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36625_36626 : H12AffineEnvironment.transform 9 100 env36625 = env36626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env36625 == env36626) = true)

theorem identity36626 : scanCanonicalize (H12AffineFastState.compose env36626 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound36626 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36627 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,12345,0,8202,12328,2049,101,1,4161,8201,17,8235,8193,64,10280,4096,12328,2049,68,8201,116,8200,12393,513]

theorem envBound36627 : H12AffineFastState.Bounded env36627 := by
  intro p hp
  have h : env36627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36626_36627 : H12AffineEnvironment.transform 7 117 env36626 = env36627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env36626 == env36627) = true)

def env36628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237589,242968,8328,64,2144541,2240917,160197,2417813,2102685,2373704,257,21792,46212,2175562]

theorem envBound36628 : H12AffineFastState.Bounded env36628 := by
  intro p hp
  have h : env36628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36568_36628 : H12AffineEnvironment.transform 21 452753 env36568 = env36628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env36568 == env36628) = true)

def env36629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144597,242968,8328,64,43357,139733,160197,324821,1501,272392,257,21792,46212,74250]

theorem envBound36629 : H12AffineFastState.Bounded env36629 := by
  intro p hp
  have h : env36629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36628_36629 : H12AffineEnvironment.transform 20 4160 env36628 = env36629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36628 == env36629) = true)

theorem identity36629 : scanCanonicalize (H12AffineFastState.compose env36629 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound36629 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36630 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4160,329867,120015,21762,8328,64,43357,115151,102879,324821,1501,272392,257,21792,46212,74250]

theorem envBound36630 : H12AffineFastState.Bounded env36630 := by
  intro p hp
  have h : env36630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36629_36630 : H12AffineEnvironment.transform 16 122906 env36629 = env36630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env36629 == env36630) = true)

def env36631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10400,1025,32769,4160,73771,120015,21762,8328,64,43357,115151,102879,56437,1501,168,257,21792,46212,74250]

theorem envBound36631 : H12AffineFastState.Bounded env36631 := by
  intro p hp
  have h : env36631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36630_36631 : H12AffineEnvironment.transform 17 10400 env36630 = env36631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env36630 == env36631) = true)

theorem identity36631 : scanCanonicalize (H12AffineFastState.compose env36631 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound36631 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21590,46156,10400,1025,32769,4160,29821,32921,21762,8328,64,43357,38297,50569,56437,1501,168,257,21792,46212,30300]

theorem envBound36632 : H12AffineFastState.Bounded env36632 := by
  intro p hp
  have h : env36632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36631_36632 : H12AffineEnvironment.transform 15 21590 env36631 = env36632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env36631 == env36632) = true)

theorem identity36632 : scanCanonicalize (H12AffineFastState.compose env36632 (packedSelected [2,3,4,5,6,7,10,12,14,17,22,23,27,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound36632 : packedSelected [2,3,4,5,6,7,10,12,14,17,22,23,27,32,38] rootPS < 2^1333 := by decide +kernel

def env36633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29992,21590,16740,10400,1025,29993,4160,29821,30129,21762,8328,64,23669,24753,12449,10589,1501,168,257,21792,16812,30300]

theorem envBound36633 : H12AffineFastState.Bounded env36633 := by
  intro p hp
  have h : env36633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36632_36633 : H12AffineEnvironment.transform 14 29992 env36632 = env36633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env36632 == env36633) = true)

theorem identity36633 : scanCanonicalize (H12AffineFastState.compose env36633 (packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound36633 : packedSelected [1,2,3,4,5,8,9,10,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env36634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13728,136,8694,13508,10400,1025,137,4160,477,17,8354,8328,64,10709,5393,12449,10589,1501,168,257,8320,13324,1020]

theorem envBound36634 : H12AffineFastState.Bounded env36634 := by
  intro p hp
  have h : env36634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36633_36634 : H12AffineEnvironment.transform 13 13728 env36633 = env36634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env36633 == env36634) = true)

theorem identity36634 : scanCanonicalize (H12AffineFastState.compose env36634 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound36634 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36635 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,13405,136,8203,13508,10400,1025,137,4160,32,17,8354,8328,64,10280,5356,12449,10400,1056,168,252,8320,13324,513]

theorem envBound36635 : H12AffineFastState.Bounded env36635 := by
  intro p hp
  have h : env36635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36634_36635 : H12AffineEnvironment.transform 7 253 env36634 = env36635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env36634 == env36635) = true)

theorem identity36635 : scanCanonicalize (H12AffineFastState.compose env36635 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound36635 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36636 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,241,5292,136,250,5173,2129,1025,137,4160,32,17,83,121,64,2265,5356,4176,2129,1056,168,252,113,5373,513]

theorem envBound36636 : H12AffineFastState.Bounded env36636 := by
  intro p hp
  have h : env36636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36635_36636 : H12AffineEnvironment.transform 12 241 env36635 = env36636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env36635 == env36636) = true)

theorem identity36636 : scanCanonicalize (H12AffineFastState.compose env36636 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound36636 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36637 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,4096,41,5236,80,34,5173,2129,1025,81,4160,32,17,83,121,64,2049,5172,4176,2129,1056,112,36,113,5157,513]

theorem envBound36637 : H12AffineFastState.Bounded env36637 := by
  intro p hp
  have h : env36637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36636_36637 : H12AffineEnvironment.transform 6 88 env36636 = env36637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env36636 == env36637) = true)

theorem identity36637 : scanCanonicalize (H12AffineFastState.compose env36637 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound36637 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env36638 : List Nat := [2,4,8,16,32,64,88,37,512,1024,2048,3109,41,2129,80,34,2064,2129,1025,81,3173,32,17,83,121,64,2049,2065,3189,2129,1056,112,36,113,2048,513]

theorem envBound36638 : H12AffineFastState.Bounded env36638 := by
  intro p hp
  have h : env36638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36637_36638 : H12AffineEnvironment.transform 11 3109 env36637 = env36638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env36637 == env36638) = true)

theorem identity36638 : scanCanonicalize (H12AffineFastState.compose env36638 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound36638 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env36639 : List Nat := [2,4,8,16,32,64,88,37,512,1024,80,1141,41,1,80,34,64,1,1025,81,1077,32,17,83,121,64,81,65,1061,1,1056,112,36,113,80,513]

theorem envBound36639 : H12AffineFastState.Bounded env36639 := by
  intro p hp
  have h : env36639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36638_36639 : H12AffineEnvironment.transform 10 80 env36638 = env36639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env36638 == env36639) = true)

theorem identity36639 : scanCanonicalize (H12AffineFastState.compose env36639 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound36639 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env36640 : List Nat := [2,4,8,16,32,64,88,37,512,101,80,16,41,1,80,34,64,1,100,81,80,32,17,83,121,64,81,65,64,1,69,112,36,113,80,513]

theorem envBound36640 : H12AffineFastState.Bounded env36640 := by
  intro p hp
  have h : env36640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36639_36640 : H12AffineEnvironment.transform 9 101 env36639 = env36640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env36639 == env36640) = true)

theorem identity36640 : scanCanonicalize (H12AffineFastState.compose env36640 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36640 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env36641 : List Nat := [2,4,8,16,32,16,8,37,512,53,0,16,41,1,0,34,16,1,52,1,0,32,17,3,41,16,1,17,16,1,21,32,36,33,0,513]

theorem envBound36641 : H12AffineFastState.Bounded env36641 := by
  intro p hp
  have h : env36641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36640_36641 : H12AffineEnvironment.transform 5 16 env36640 = env36641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36640 == env36641) = true)

theorem identity36641 : scanCanonicalize (H12AffineFastState.compose env36641 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound36641 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36642 : List Nat := [2,4,8,16,5,16,8,0,512,16,0,16,12,1,0,7,16,1,17,1,0,5,17,3,12,16,1,17,16,1,21,5,1,4,0,513]

theorem envBound36642 : H12AffineFastState.Bounded env36642 := by
  intro p hp
  have h : env36642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36641_36642 : H12AffineEnvironment.transform 4 5 env36641 = env36642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env36641 == env36642) = true)

theorem identity36642 : scanCanonicalize (H12AffineFastState.compose env36642 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 25) := by decide +kernel

theorem selectedBound36642 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36643 : List Nat := [2,4,8,16,5,16,8,0,25,16,0,16,12,1,0,7,16,1,17,1,0,5,17,3,12,16,1,17,16,1,21,5,1,4,0,24]

theorem envBound36643 : H12AffineFastState.Bounded env36643 := by
  intro p hp
  have h : env36643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36642_36643 : H12AffineEnvironment.transform 8 25 env36642 = env36643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 25 env36642 == env36643) = true)

theorem identity36643 : scanCanonicalize (H12AffineFastState.compose env36643 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound36643 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env36644 : List Nat := [2,4,8,3,5,3,8,0,10,3,0,3,12,1,0,7,3,1,2,1,0,5,2,3,12,3,1,2,3,1,6,5,1,4,0,11]

theorem envBound36644 : H12AffineFastState.Bounded env36644 := by
  intro p hp
  have h : env36644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36643_36644 : H12AffineEnvironment.transform 3 3 env36643 = env36644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env36643 == env36644) = true)

theorem identity36644 : scanCanonicalize (H12AffineFastState.compose env36644 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36644 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env36645 : List Nat := [2,0,8,3,1,3,8,0,10,3,0,3,8,1,0,3,3,1,2,1,0,1,2,3,8,3,1,2,3,1,2,1,1,0,0,11]

theorem envBound36645 : H12AffineFastState.Bounded env36645 := by
  intro p hp
  have h : env36645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36644_36645 : H12AffineEnvironment.transform 1 0 env36644 = env36645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36644 == env36645) = true)

def env36646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10401,1025,32769,4160,73770,120015,21762,8328,64,43357,115151,102879,56436,1501,169,257,21792,46212,74250]

theorem envBound36646 : H12AffineFastState.Bounded env36646 := by
  intro p hp
  have h : env36646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36630_36646 : H12AffineEnvironment.transform 17 10401 env36630 = env36646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env36630 == env36646) = true)

theorem identity36646 : scanCanonicalize (H12AffineFastState.compose env36646 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound36646 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env36647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,70727,10401,1025,29788,4160,73770,73874,21762,8328,64,23808,79250,91522,10281,1501,169,257,21792,16601,74250]

theorem envBound36647 : H12AffineFastState.Bounded env36647 := by
  intro p hp
  have h : env36647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36646_36647 : H12AffineEnvironment.transform 14 29789 env36646 = env36647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env36646 == env36647) = true)

theorem identity36647 : scanCanonicalize (H12AffineFastState.compose env36647 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36647 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env36648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8203,13388,10401,1025,29788,4160,33,153,21762,8328,64,23808,5529,17801,10281,1501,169,257,21792,16601,513]

theorem envBound36648 : H12AffineFastState.Bounded env36648 := by
  intro p hp
  have h : env36648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36647_36648 : H12AffineEnvironment.transform 15 8203 env36647 = env36648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36647 == env36648) = true)

theorem identity36648 : scanCanonicalize (H12AffineFastState.compose env36648 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound36648 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env36649 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21896,478,5529,2420,1025,21897,4160,33,153,21762,349,64,23808,5529,17801,2556,1501,169,257,21792,16601,513]

theorem envBound36649 : H12AffineFastState.Bounded env36649 := by
  intro p hp
  have h : env36649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36648_36649 : H12AffineEnvironment.transform 12 469 env36648 = env36649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env36648 == env36649) = true)

theorem identity36649 : scanCanonicalize (H12AffineFastState.compose env36649 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36649 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env36650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,342,5393,2420,1025,21761,4160,33,17,21762,349,64,23808,5393,17665,2420,1365,33,257,21792,16465,513]

theorem envBound36650 : H12AffineFastState.Bounded env36650 := by
  intro p hp
  have h : env36650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36649_36650 : H12AffineEnvironment.transform 6 8 env36649 = env36650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36649 == env36650) = true)

theorem identity36650 : scanCanonicalize (H12AffineFastState.compose env36650 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound36650 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,80,342,5393,2420,1025,81,4160,33,17,82,349,64,2128,5393,4177,2420,1365,33,257,112,5377,513]

theorem envBound36651 : H12AffineFastState.Bounded env36651 := by
  intro p hp
  have h : env36651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36650_36651 : H12AffineEnvironment.transform 13 5456 env36650 = env36651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env36650 == env36651) = true)

theorem identity36651 : scanCanonicalize (H12AffineFastState.compose env36651 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36651 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env36652 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,262,5393,2340,1025,1,4112,33,17,2,269,16,2048,5393,4097,2340,1285,33,257,32,5377,513]

theorem envBound36652 : H12AffineFastState.Bounded env36652 := by
  intro p hp
  have h : env36652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36651_36652 : H12AffineEnvironment.transform 5 16 env36651 = env36652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36651 == env36652) = true)

theorem identity36652 : scanCanonicalize (H12AffineFastState.compose env36652 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36653 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5173,2048,1025,1,4112,33,17,2,41,16,2048,5173,4097,2048,1057,33,37,32,5157,513]

theorem envBound36653 : H12AffineFastState.Bounded env36653 := by
  intro p hp
  have h : env36653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36652_36653 : H12AffineEnvironment.transform 7 36 env36652 = env36653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36652 == env36653) = true)

theorem identity36653 : scanCanonicalize (H12AffineFastState.compose env36653 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound36653 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36654 : List Nat := [2,4,8,16,32,16,8,36,512,1024,523,4096,41,5156,0,34,5173,523,1025,1,4112,33,17,2,41,16,523,5173,4097,523,1057,33,37,32,5157,513]

theorem envBound36654 : H12AffineFastState.Bounded env36654 := by
  intro p hp
  have h : env36654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36653_36654 : H12AffineEnvironment.transform 10 523 env36653 = env36654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env36653 == env36654) = true)

theorem identity36654 : scanCanonicalize (H12AffineFastState.compose env36654 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36654 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36655 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,4096,9,5124,0,2,5141,523,1025,1,4112,1,17,2,9,16,523,5141,4097,523,1025,1,5,0,5125,513]

theorem envBound36655 : H12AffineFastState.Bounded env36655 := by
  intro p hp
  have h : env36655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36654_36655 : H12AffineEnvironment.transform 4 0 env36654 = env36655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36654 == env36655) = true)

def env36656 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,16,9,1044,0,2,1029,523,1025,1,0,1,17,2,9,16,523,1029,17,523,1025,1,5,0,1045,513]

theorem envBound36656 : H12AffineFastState.Bounded env36656 := by
  intro p hp
  have h : env36656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36655_36656 : H12AffineEnvironment.transform 11 16 env36655 = env36656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env36655 == env36656) = true)

theorem identity36656 : scanCanonicalize (H12AffineFastState.compose env36656 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound36656 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36657 : List Nat := [2,4,8,16,0,16,8,4,30,1024,21,16,9,1044,0,2,1029,21,1025,1,0,1,17,2,9,16,21,1029,17,21,1025,1,5,0,1045,31]

theorem envBound36657 : H12AffineFastState.Bounded env36657 := by
  intro p hp
  have h : env36657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36656_36657 : H12AffineEnvironment.transform 8 30 env36656 = env36657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env36656 == env36657) = true)

def env36658 : List Nat := [2,4,8,16,0,16,8,4,30,0,21,16,9,20,0,2,5,21,1,1,0,1,17,2,9,16,21,5,17,21,1,1,5,0,21,31]

theorem envBound36658 : H12AffineFastState.Bounded env36658 := by
  intro p hp
  have h : env36658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36657_36658 : H12AffineEnvironment.transform 9 0 env36657 = env36658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env36657 == env36658) = true)

theorem identity36658 : scanCanonicalize (H12AffineFastState.compose env36658 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36658 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36659 : List Nat := [1,4,8,16,0,16,8,4,29,0,21,16,9,20,0,1,5,21,1,1,0,1,17,1,9,16,21,5,17,21,1,1,5,0,21,28]

theorem envBound36659 : H12AffineFastState.Bounded env36659 := by
  intro p hp
  have h : env36659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36658_36659 : H12AffineEnvironment.transform 0 1 env36658 = env36659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36658 == env36659) = true)

def leafEnv36659 : List Nat := [1,4,8,16,0,16,8,4,29,0,21,16,9,20,0,1,5,21,1,1,0,1,17,1,1,9,1,16,21,5,17,21,1,1,5,0,4,1,21,28,1,1,0]

def active36659 : List Nat := [1,2,3]

def tree36659 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36659 : H12WitnessSearch.Good tree36659 := H12GlobalWitnessIndex.good

theorem leafIdentity36659 : H12AffineFastState.composeSystem env36659 rootObs = leafEnv36659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36659 rootObs == leafEnv36659) = true)

theorem terminalChecked36659 : H12PackedTerminal.terminalCheckFast leafEnv36659 active36659 tree36659 = true := by decide +kernel

def env36660 : List Nat := [2,4,8,16,0,16,8,4,30,1,21,16,9,21,0,2,4,21,0,1,0,1,17,2,9,16,21,4,17,21,0,1,5,0,20,31]

theorem envBound36660 : H12AffineFastState.Bounded env36660 := by
  intro p hp
  have h : env36660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36657_36660 : H12AffineEnvironment.transform 9 1 env36657 = env36660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env36657 == env36660) = true)

theorem identity36660 : scanCanonicalize (H12AffineFastState.compose env36660 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound36660 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36661 : List Nat := [2,4,8,7,0,7,8,4,9,1,2,7,9,2,0,2,4,2,0,1,0,1,6,2,9,7,2,4,6,2,0,1,5,0,3,8]

theorem envBound36661 : H12AffineFastState.Bounded env36661 := by
  intro p hp
  have h : env36661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36660_36661 : H12AffineEnvironment.transform 3 7 env36660 = env36661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env36660 == env36661) = true)

def leafEnv36661 : List Nat := [2,4,8,7,0,7,8,4,9,1,2,7,9,2,0,2,4,2,0,1,0,1,6,2,0,9,1,7,2,4,6,2,0,1,5,0,4,2,3,8,1,1,0]

def active36661 : List Nat := [0,1,2]

def tree36661 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36661 : H12WitnessSearch.Good tree36661 := H12GlobalWitnessIndex.good

theorem leafIdentity36661 : H12AffineFastState.composeSystem env36661 rootObs = leafEnv36661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36661 rootObs == leafEnv36661) = true)

theorem terminalChecked36661 : H12PackedTerminal.terminalCheckFast leafEnv36661 active36661 tree36661 = true := by decide +kernel

def env36662 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,17,9,1045,0,2,1028,523,1025,1,1,1,17,2,9,16,523,1028,16,523,1025,1,5,0,1044,513]

theorem envBound36662 : H12AffineFastState.Bounded env36662 := by
  intro p hp
  have h : env36662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36655_36662 : H12AffineEnvironment.transform 11 17 env36655 = env36662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env36655 == env36662) = true)

theorem identity36662 : scanCanonicalize (H12AffineFastState.compose env36662 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound36662 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36663 : List Nat := [2,4,8,16,0,16,8,4,512,522,523,17,9,543,0,2,526,523,523,1,1,1,17,2,9,16,523,526,16,523,523,1,5,0,542,513]

theorem envBound36663 : H12AffineFastState.Bounded env36663 := by
  intro p hp
  have h : env36663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36662_36663 : H12AffineEnvironment.transform 9 522 env36662 = env36663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env36662 == env36663) = true)

def env36664 : List Nat := [2,4,8,4,0,4,8,4,512,522,523,5,9,523,0,2,526,523,523,1,1,1,5,2,9,4,523,526,4,523,523,1,5,0,522,513]

theorem envBound36664 : H12AffineFastState.Bounded env36664 := by
  intro p hp
  have h : env36664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36663_36664 : H12AffineEnvironment.transform 3 4 env36663 = env36664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env36663 == env36664) = true)

theorem identity36664 : scanCanonicalize (H12AffineFastState.compose env36664 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound36664 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36665 : List Nat := [1,4,8,4,0,4,8,4,512,521,520,5,9,520,0,1,525,520,520,1,1,1,5,1,9,4,520,525,4,520,520,1,5,0,521,513]

theorem envBound36665 : H12AffineFastState.Bounded env36665 := by
  intro p hp
  have h : env36665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36664_36665 : H12AffineEnvironment.transform 0 1 env36664 = env36665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env36664 == env36665) = true)

def leafEnv36665 : List Nat := [1,4,8,4,0,4,8,4,512,521,520,5,9,520,0,1,525,520,520,1,1,1,5,1,520,9,1,4,520,525,4,520,520,1,5,0,4,1,521,513,1,0,0]

def active36665 : List Nat := [1,2,8]

def tree36665 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36665 : H12WitnessSearch.Good tree36665 := H12GlobalWitnessIndex.good

theorem leafIdentity36665 : H12AffineFastState.composeSystem env36665 rootObs = leafEnv36665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36665 rootObs == leafEnv36665) = true)

theorem terminalChecked36665 : H12PackedTerminal.terminalCheckFast leafEnv36665 active36665 tree36665 = true := by decide +kernel

def env36666 : List Nat := [2,4,8,5,0,5,8,4,512,522,523,4,9,522,0,2,526,523,523,1,1,1,4,2,9,5,523,526,5,523,523,1,5,0,523,513]

theorem envBound36666 : H12AffineFastState.Bounded env36666 := by
  intro p hp
  have h : env36666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36663_36666 : H12AffineEnvironment.transform 3 5 env36663 = env36666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env36663 == env36666) = true)

theorem identity36666 : scanCanonicalize (H12AffineFastState.compose env36666 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound36666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36667 : List Nat := [2,4,8,5,0,5,8,4,9,3,2,4,9,3,0,2,7,2,2,1,1,1,4,2,9,5,2,7,5,2,2,1,5,0,2,8]

theorem envBound36667 : H12AffineFastState.Bounded env36667 := by
  intro p hp
  have h : env36667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36666_36667 : H12AffineEnvironment.transform 8 9 env36666 = env36667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env36666 == env36667) = true)

def leafEnv36667 : List Nat := [2,4,8,5,0,5,8,4,9,3,2,4,9,3,0,2,7,2,2,1,1,1,4,2,2,9,1,5,2,7,5,2,2,1,5,0,4,2,2,8,1,0,0]

def active36667 : List Nat := [0,1,2]

def tree36667 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36667 : H12WitnessSearch.Good tree36667 := H12GlobalWitnessIndex.good

theorem leafIdentity36667 : H12AffineFastState.composeSystem env36667 rootObs = leafEnv36667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36667 rootObs == leafEnv36667) = true)

theorem terminalChecked36667 : H12PackedTerminal.terminalCheckFast leafEnv36667 active36667 tree36667 = true := by decide +kernel

def env36668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144596,242968,8328,64,43356,139732,160197,324820,1500,272393,257,21792,46212,74251]

theorem envBound36668 : H12AffineFastState.Bounded env36668 := by
  intro p hp
  have h : env36668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36628_36668 : H12AffineEnvironment.transform 20 4161 env36628 = env36668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36628 == env36668) = true)

theorem identity36668 : scanCanonicalize (H12AffineFastState.compose env36668 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound36668 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,452753,144596,169234,8328,64,43356,139732,160197,324820,1500,272393,257,21792,46212,513]

theorem envBound36669 : H12AffineFastState.Bounded env36669 := by
  intro p hp
  have h : env36669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36668_36669 : H12AffineEnvironment.transform 15 8202 env36668 = env36669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env36668 == env36669) = true)

def env36670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,305281,29892,54530,8328,64,43356,25028,12757,324820,1500,272393,257,21792,46212,513]

theorem envBound36670 : H12AffineFastState.Bounded env36670 := by
  intro p hp
  have h : env36670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36669_36670 : H12AffineEnvironment.transform 16 16400 env36669 = env36670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env36669 == env36670) = true)

theorem identity36670 : scanCanonicalize (H12AffineFastState.compose env36670 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound36670 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env36671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,13509,262144,1025,32769,4161,305281,17,41431,8328,64,43356,5393,12757,294913,1500,272393,257,8693,46212,513]

theorem envBound36671 : H12AffineFastState.Bounded env36671 := by
  intro p hp
  have h : env36671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36670_36671 : H12AffineEnvironment.transform 13 13525 env36670 = env36671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env36670 == env36671) = true)

theorem identity36671 : scanCanonicalize (H12AffineFastState.compose env36671 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound36671 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env36672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,13509,43049,1025,32769,4161,168,17,41431,8328,64,43356,5393,12757,10280,1500,32800,257,8693,46212,513]

theorem envBound36672 : H12AffineFastState.Bounded env36672 := by
  intro p hp
  have h : env36672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36671_36672 : H12AffineEnvironment.transform 17 43049 env36671 = env36672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env36671 == env36672) = true)

theorem identity36672 : scanCanonicalize (H12AffineFastState.compose env36672 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36672 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env36673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,8202,13389,43049,1025,32769,4161,32,17,41311,8192,64,43356,5393,12637,10280,1364,32800,257,8573,46092,513]

theorem envBound36673 : H12AffineFastState.Bounded env36673 := by
  intro p hp
  have h : env36673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36672_36673 : H12AffineEnvironment.transform 6 8 env36672 = env36673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36672 == env36673) = true)

theorem identity36673 : scanCanonicalize (H12AffineFastState.compose env36673 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound36673 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,8202,13389,10281,1025,1,4161,32,17,8543,8192,64,10588,5393,12637,10280,1364,32,257,8573,13324,513]

theorem envBound36674 : H12AffineFastState.Bounded env36674 := by
  intro p hp
  have h : env36674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36673_36674 : H12AffineEnvironment.transform 14 0 env36673 = env36674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env36673 == env36674) = true)

theorem identity36674 : scanCanonicalize (H12AffineFastState.compose env36674 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36674 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,343,5392,2420,1025,1,4161,32,17,2,349,64,2049,5393,4096,2421,1364,32,257,32,5457,513]

theorem envBound36675 : H12AffineFastState.Bounded env36675 := by
  intro p hp
  have h : env36675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36674_36675 : H12AffineEnvironment.transform 12 349 env36674 = env36675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36674 == env36675) = true)

theorem identity36675 : scanCanonicalize (H12AffineFastState.compose env36675 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound36675 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,303,4096,349,5376,0,343,5392,91,1025,1,4161,32,17,2,349,64,302,5393,4096,90,1364,32,257,32,5457,513]

theorem envBound36676 : H12AffineFastState.Bounded env36676 := by
  intro p hp
  have h : env36676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36675_36676 : H12AffineEnvironment.transform 10 303 env36675 = env36676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env36675 == env36676) = true)

theorem identity36676 : scanCanonicalize (H12AffineFastState.compose env36676 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound36676 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,303,0,349,1280,0,343,1296,91,1025,1,65,32,17,2,349,64,302,1297,0,90,1364,32,257,32,1361,513]

theorem envBound36677 : H12AffineFastState.Bounded env36677 := by
  intro p hp
  have h : env36677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36676_36677 : H12AffineEnvironment.transform 11 0 env36676 = env36677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env36676 == env36677) = true)

theorem identity36677 : scanCanonicalize (H12AffineFastState.compose env36677 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound36677 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env36678 : List Nat := [2,4,8,16,32,64,8,116,512,1024,91,0,41,1140,0,35,1124,91,1025,1,65,32,17,2,41,64,90,1125,0,90,1056,32,117,32,1061,513]

theorem envBound36678 : H12AffineFastState.Bounded env36678 := by
  intro p hp
  have h : env36678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36677_36678 : H12AffineEnvironment.transform 7 116 env36677 = env36678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env36677 == env36678) = true)

theorem identity36678 : scanCanonicalize (H12AffineFastState.compose env36678 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 63) := by decide +kernel

theorem selectedBound36678 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36679 : List Nat := [2,4,8,16,32,64,8,116,512,63,91,0,41,75,0,35,91,91,62,1,65,32,17,2,41,64,90,90,0,90,31,32,117,32,26,513]

theorem envBound36679 : H12AffineFastState.Bounded env36679 := by
  intro p hp
  have h : env36679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36678_36679 : H12AffineEnvironment.transform 9 63 env36678 = env36679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 63 env36678 == env36679) = true)

theorem identity36679 : scanCanonicalize (H12AffineFastState.compose env36679 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound36679 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env36680 : List Nat := [2,4,8,16,32,48,8,4,512,63,43,0,41,59,0,35,43,43,62,1,49,32,17,2,41,48,42,42,0,42,31,32,5,32,26,513]

theorem envBound36680 : H12AffineFastState.Bounded env36680 := by
  intro p hp
  have h : env36680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36679_36680 : H12AffineEnvironment.transform 5 48 env36679 = env36680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env36679 == env36680) = true)

def env36681 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,305280,29893,54531,8328,64,43356,25029,12756,324820,1500,272393,257,21792,46212,513]

theorem envBound36681 : H12AffineFastState.Bounded env36681 := by
  intro p hp
  have h : env36681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36669_36681 : H12AffineEnvironment.transform 16 16401 env36669 = env36681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env36669 == env36681) = true)

def env36682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,305160,29773,54531,8192,64,43356,24909,12636,324700,1364,272393,257,21792,46092,513]

theorem envBound36682 : H12AffineFastState.Bounded env36682 := by
  intro p hp
  have h : env36682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36681_36682 : H12AffineEnvironment.transform 6 8 env36681 = env36682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36681 == env36682) = true)

def env36683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1025,32769,4161,305161,29772,54531,8193,64,43356,24908,12637,324701,1365,272393,257,21792,46093,513]

theorem envBound36683 : H12AffineFastState.Bounded env36683 := by
  intro p hp
  have h : env36683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36681_36683 : H12AffineEnvironment.transform 6 9 env36681 = env36683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36681 == env36683) = true)

theorem identity36683 : scanCanonicalize (H12AffineFastState.compose env36683 (packedSelected [0,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound36683 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env36684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,32768,1095,16401,262144,1025,32769,4161,298052,20481,54531,1100,64,36113,17665,5392,315408,1365,265284,257,21792,36928,513]

theorem envBound36684 : H12AffineFastState.Bounded env36684 := by
  intro p hp
  have h : env36684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36683_36684 : H12AffineEnvironment.transform 12 1101 env36683 = env36684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env36683 == env36684) = true)

theorem identity36684 : scanCanonicalize (H12AffineFastState.compose env36684 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 20497) := by decide +kernel

theorem selectedBound36684 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env36685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,20497,1095,16401,262144,1025,20496,4161,285781,20481,1298,1100,64,23808,17665,5392,262145,1365,265284,257,21792,16465,513]

theorem envBound36685 : H12AffineFastState.Bounded env36685 := by
  intro p hp
  have h : env36685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36684_36685 : H12AffineEnvironment.transform 14 20497 env36684 = env36685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20497 env36684 == env36685) = true)

theorem identity36685 : scanCanonicalize (H12AffineFastState.compose env36685 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound36685 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,16384,20497,1095,16401,3173,1025,20496,4161,20528,20481,1298,1100,64,23808,17665,5392,3172,1365,33,257,21792,16465,513]

theorem envBound36686 : H12AffineFastState.Bounded env36686 := by
  intro p hp
  have h : env36686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36685_36686 : H12AffineEnvironment.transform 17 3173 env36685 = env36686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env36685 == env36686) = true)

theorem identity36686 : scanCanonicalize (H12AffineFastState.compose env36686 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound36686 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env36687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,2340,6453,1095,2357,3173,1025,6452,4161,6420,6437,1298,1100,64,5156,3109,5392,3172,1365,33,257,7172,2421,513]

theorem envBound36687 : H12AffineFastState.Bounded env36687 := by
  intro p hp
  have h : env36687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36686_36687 : H12AffineEnvironment.transform 13 2340 env36686 = env36687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env36686 == env36687) = true)

theorem identity36687 : scanCanonicalize (H12AffineFastState.compose env36687 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound36687 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env36688 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,268,2340,6453,262,2357,2340,320,6452,4161,6420,6437,83,269,64,4453,2404,4177,2341,20,33,257,6469,2421,513]

theorem envBound36688 : H12AffineFastState.Bounded env36688 := by
  intro p hp
  have h : env36688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36687_36688 : H12AffineEnvironment.transform 9 321 env36687 = env36688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env36687 == env36688) = true)

theorem identity36688 : scanCanonicalize (H12AffineFastState.compose env36688 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound36688 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36689 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,2404,268,2340,81,262,2357,2340,320,80,2341,112,65,83,269,64,2049,2404,2357,2341,20,33,257,33,2421,513]

theorem envBound36689 : H12AffineFastState.Bounded env36689 := by
  intro p hp
  have h : env36689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36688_36689 : H12AffineEnvironment.transform 11 2404 env36688 = env36689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env36688 == env36689) = true)

theorem identity36689 : scanCanonicalize (H12AffineFastState.compose env36689 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36689 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env36690 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,2113,41,2049,81,35,2064,2049,101,80,2048,112,65,83,40,64,2049,2113,2064,2048,20,33,36,33,2128,513]

theorem envBound36690 : H12AffineFastState.Bounded env36690 := by
  intro p hp
  have h : env36690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36689_36690 : H12AffineEnvironment.transform 7 37 env36689 = env36690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36689 == env36690) = true)

theorem identity36690 : scanCanonicalize (H12AffineFastState.compose env36690 (packedSelected [1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound36690 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env36691 : List Nat := [2,4,8,16,32,64,9,37,512,100,513,576,41,512,81,35,529,512,101,80,513,112,65,83,40,64,512,576,529,513,20,33,36,33,593,513]

theorem envBound36691 : H12AffineFastState.Bounded env36691 := by
  intro p hp
  have h : env36691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36690_36691 : H12AffineEnvironment.transform 10 513 env36690 = env36691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env36690 == env36691) = true)

theorem identity36691 : scanCanonicalize (H12AffineFastState.compose env36691 (packedSelected [2,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound36691 : packedSelected [2,5] rootPS < 2^1333 := by decide +kernel

def env36692 : List Nat := [2,4,8,11,32,64,9,37,512,100,513,576,41,512,74,35,522,512,101,75,513,107,65,72,40,64,512,576,522,513,15,33,36,33,586,513]

theorem envBound36692 : H12AffineFastState.Bounded env36692 := by
  intro p hp
  have h : env36692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36691_36692 : H12AffineEnvironment.transform 3 11 env36691 = env36692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env36691 == env36692) = true)

theorem identity36692 : scanCanonicalize (H12AffineFastState.compose env36692 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 75) := by decide +kernel

theorem selectedBound36692 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env36693 : List Nat := [2,4,8,11,32,64,9,37,75,100,74,11,41,75,74,35,65,75,101,75,74,107,65,72,40,64,75,11,65,74,15,33,36,33,1,74]

theorem envBound36693 : H12AffineFastState.Bounded env36693 := by
  intro p hp
  have h : env36693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36692_36693 : H12AffineEnvironment.transform 8 75 env36692 = env36693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 75 env36692 == env36693) = true)

theorem identity36693 : scanCanonicalize (H12AffineFastState.compose env36693 (packedSelected [9] rootPS)) = affineNative (2^(5+1) ^^^ 11) := by decide +kernel

theorem selectedBound36693 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env36694 : List Nat := [2,4,8,11,32,11,9,37,0,47,1,11,41,0,1,35,10,0,46,0,1,32,10,3,40,11,0,11,10,1,15,33,36,33,1,1]

theorem envBound36694 : H12AffineFastState.Bounded env36694 := by
  intro p hp
  have h : env36694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36693_36694 : H12AffineEnvironment.transform 5 11 env36693 = env36694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 11 env36693 == env36694) = true)

def env36695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237589,242969,8328,64,6705549,2240916,160197,2417813,2102684,6475992,257,21793,46213,2175563]

theorem envBound36695 : H12AffineFastState.Bounded env36695 := by
  intro p hp
  have h : env36695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36567_36695 : H12AffineEnvironment.transform 23 242969 env36567 = env36695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 242969 env36567 == env36695) = true)

def env36696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452752,2237589,242969,8328,64,2144541,2240916,160197,2417813,2102684,2373704,257,21793,46213,2175563]

theorem envBound36696 : H12AffineFastState.Bounded env36696 := by
  intro p hp
  have h : env36696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36695_36696 : H12AffineEnvironment.transform 21 452752 env36695 = env36696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452752 env36695 == env36696) = true)

def env36697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452752,144597,242969,8328,64,43357,139732,160197,324821,1500,272392,257,21793,46213,74251]

theorem envBound36697 : H12AffineFastState.Bounded env36697 := by
  intro p hp
  have h : env36697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36696_36697 : H12AffineEnvironment.transform 20 4160 env36696 = env36697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36696 == env36697) = true)

theorem identity36697 : scanCanonicalize (H12AffineFastState.compose env36697 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound36697 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4160,318548,17,98781,8328,64,43357,5392,17665,324821,1500,272392,257,21793,46213,74251]

theorem envBound36698 : H12AffineFastState.Bounded env36698 := by
  intro p hp
  have h : env36698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36697_36698 : H12AffineEnvironment.transform 16 13508 env36697 = env36698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env36697 == env36698) = true)

def env36699 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318548,17,98645,8192,64,43357,5392,17665,324701,1364,272392,257,21793,46093,74251]

theorem envBound36699 : H12AffineFastState.Bounded env36699 := by
  intro p hp
  have h : env36699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36698_36699 : H12AffineEnvironment.transform 6 8 env36698 = env36699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36698 == env36699) = true)

theorem identity36699 : scanCanonicalize (H12AffineFastState.compose env36699 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound36699 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36700 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1025,32769,4160,62589,17,98645,8192,64,43357,5392,17665,56436,1364,33,257,21793,46093,74251]

theorem envBound36700 : H12AffineFastState.Bounded env36700 := by
  intro p hp
  have h : env36700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36699_36700 : H12AffineEnvironment.transform 17 10281 env36699 = env36700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env36699 == env36700) = true)

theorem identity36700 : scanCanonicalize (H12AffineFastState.compose env36700 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound36700 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36701 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1025,29789,4160,33,17,95497,8192,64,23809,5392,17665,10280,1364,33,257,21793,16465,74251]

theorem envBound36701 : H12AffineFastState.Bounded env36701 := by
  intro p hp
  have h : env36701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36700_36701 : H12AffineEnvironment.transform 14 29788 env36700 = env36701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env36700 == env36701) = true)

theorem identity36701 : scanCanonicalize (H12AffineFastState.compose env36701 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound36701 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env36702 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21591,13388,10281,1025,29789,4160,33,17,8542,8192,64,23809,5392,17665,10280,1364,33,257,21793,16465,30300]

theorem envBound36702 : H12AffineFastState.Bounded env36702 := by
  intro p hp
  have h : env36702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36701_36702 : H12AffineEnvironment.transform 15 21591 env36701 = env36702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env36701 == env36702) = true)

theorem identity36702 : scanCanonicalize (H12AffineFastState.compose env36702 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound36702 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env36703 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,13388,10281,1025,0,4160,33,17,8542,8192,64,10588,5392,12636,10280,1364,33,257,8572,13324,513]

theorem envBound36703 : H12AffineFastState.Bounded env36703 := by
  intro p hp
  have h : env36703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36702_36703 : H12AffineEnvironment.transform 13 13405 env36702 = env36703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env36702 == env36703) = true)

theorem identity36703 : scanCanonicalize (H12AffineFastState.compose env36703 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound36703 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36704 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5393,2420,1025,0,4160,33,17,3,349,64,2049,5392,4097,2421,1364,33,257,33,5457,513]

theorem envBound36704 : H12AffineFastState.Bounded env36704 := by
  intro p hp
  have h : env36704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36703_36704 : H12AffineEnvironment.transform 12 349 env36703 = env36704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env36703 == env36704) = true)

theorem identity36704 : scanCanonicalize (H12AffineFastState.compose env36704 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound36704 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36705 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,1,262,5393,2341,1025,0,4113,33,17,3,268,17,2049,5392,4097,2340,1285,33,257,33,5376,513]

theorem envBound36705 : H12AffineFastState.Bounded env36705 := by
  intro p hp
  have h : env36705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36704_36705 : H12AffineEnvironment.transform 5 17 env36704 = env36705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36704 == env36705) = true)

theorem identity36705 : scanCanonicalize (H12AffineFastState.compose env36705 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound36705 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36706 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1313,268,33,1,262,48,2341,1025,0,1328,33,17,3,268,17,2049,49,1312,2340,1285,33,257,33,33,513]

theorem envBound36706 : H12AffineFastState.Bounded env36706 := by
  intro p hp
  have h : env36706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36705_36706 : H12AffineEnvironment.transform 11 1313 env36705 = env36706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env36705 == env36706) = true)

theorem identity36706 : scanCanonicalize (H12AffineFastState.compose env36706 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 804) := by decide +kernel

theorem selectedBound36706 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36707 : List Nat := [2,4,8,16,32,17,8,256,512,1024,804,1313,268,33,1,262,48,513,1025,0,1328,33,17,3,268,17,805,49,1312,512,1285,33,257,33,33,513]

theorem envBound36707 : H12AffineFastState.Bounded env36707 := by
  intro p hp
  have h : env36707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36706_36707 : H12AffineEnvironment.transform 10 804 env36706 = env36707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 804 env36706 == env36707) = true)

theorem identity36707 : scanCanonicalize (H12AffineFastState.compose env36707 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound36707 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36708 : List Nat := [2,4,8,16,32,17,8,256,512,769,804,544,268,33,1,262,48,513,768,0,561,33,17,3,268,17,805,49,545,512,516,33,257,33,33,513]

theorem envBound36708 : H12AffineFastState.Bounded env36708 := by
  intro p hp
  have h : env36708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36707_36708 : H12AffineEnvironment.transform 9 769 env36707 = env36708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env36707 == env36708) = true)

theorem identity36708 : scanCanonicalize (H12AffineFastState.compose env36708 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound36708 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36709 : List Nat := [2,4,8,16,32,17,8,256,16,273,308,48,268,33,1,262,48,17,272,0,33,33,17,3,268,17,309,49,49,16,20,33,257,33,33,17]

theorem envBound36709 : H12AffineFastState.Bounded env36709 := by
  intro p hp
  have h : env36709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36708_36709 : H12AffineEnvironment.transform 8 16 env36708 = env36709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env36708 == env36709) = true)

theorem identity36709 : scanCanonicalize (H12AffineFastState.compose env36709 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36709 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36710 : List Nat := [2,4,8,16,32,17,8,36,16,53,16,48,40,33,1,34,48,17,52,0,33,33,17,3,40,17,17,49,49,16,20,33,37,33,33,17]

theorem envBound36710 : H12AffineFastState.Bounded env36710 := by
  intro p hp
  have h : env36710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36709_36710 : H12AffineEnvironment.transform 7 36 env36709 = env36710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36709 == env36710) = true)

theorem identity36710 : scanCanonicalize (H12AffineFastState.compose env36710 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36710 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36711 : List Nat := [2,4,8,1,32,0,8,36,1,36,1,33,40,33,1,34,33,0,37,0,33,33,0,3,40,0,0,32,32,1,5,33,37,33,33,0]

theorem envBound36711 : H12AffineFastState.Bounded env36711 := by
  intro p hp
  have h : env36711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36710_36711 : H12AffineEnvironment.transform 3 1 env36710 = env36711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36710 == env36711) = true)

theorem identity36711 : scanCanonicalize (H12AffineFastState.compose env36711 (packedSelected [9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36711 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env36712 : List Nat := [2,4,8,1,0,0,8,4,1,4,1,1,8,1,1,2,1,0,5,0,1,1,0,3,8,0,0,0,0,1,5,1,5,1,1,0]

theorem envBound36712 : H12AffineFastState.Bounded env36712 := by
  intro p hp
  have h : env36712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36711_36712 : H12AffineEnvironment.transform 4 0 env36711 = env36712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36711 == env36712) = true)

def env36713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4160,318548,17,98644,8193,64,43357,5392,17665,324700,1365,272392,257,21793,46092,74251]

theorem envBound36713 : H12AffineFastState.Bounded env36713 := by
  intro p hp
  have h : env36713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36698_36713 : H12AffineEnvironment.transform 6 9 env36698 = env36713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36698 == env36713) = true)

theorem identity36713 : scanCanonicalize (H12AffineFastState.compose env36713 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound36713 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,35188,1025,32769,4160,21792,17,98644,8193,64,43357,5392,17665,32040,1365,41340,257,21793,46092,74251]

theorem envBound36714 : H12AffineFastState.Bounded env36714 := by
  intro p hp
  have h : env36714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36713_36714 : H12AffineEnvironment.transform 17 35188 env36713 = env36714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env36713 == env36714) = true)

theorem identity36714 : scanCanonicalize (H12AffineFastState.compose env36714 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 62811) := by decide +kernel

theorem selectedBound36714 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env36715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62811,13389,35188,1025,32769,4160,21792,17,29711,8193,64,43357,5392,17665,32040,1365,41340,257,21793,46092,55120]

theorem envBound36715 : H12AffineFastState.Bounded env36715 := by
  intro p hp
  have h : env36715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36714_36715 : H12AffineEnvironment.transform 15 62811 env36714 = env36715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62811 env36714 == env36715) = true)

theorem identity36715 : scanCanonicalize (H12AffineFastState.compose env36715 (packedSelected [3,4,5,9,10,12,14,15,16,19,26] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound36715 : packedSelected [3,4,5,9,10,12,14,15,16,19,26] rootPS < 2^1333 := by decide +kernel

def env36716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,29742,13389,2049,1025,372,4160,21792,17,29711,8193,64,10280,5392,17665,32040,1365,8201,257,21793,13689,22053]

theorem envBound36716 : H12AffineFastState.Bounded env36716 := by
  intro p hp
  have h : env36716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36715_36716 : H12AffineEnvironment.transform 14 373 env36715 = env36716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env36715 == env36716) = true)

theorem identity36716 : scanCanonicalize (H12AffineFastState.compose env36716 (packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound36716 : packedSelected [0,2,3,4,6,7,9,10,11,14,18,19,24] rootPS < 2^1333 := by decide +kernel

def env36717 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,373,8575,13389,2049,1025,372,4160,113,17,8542,8193,64,10280,5392,4176,10361,1365,8201,257,112,13689,884]

theorem envBound36717 : H12AffineFastState.Bounded env36717 := by
  intro p hp
  have h : env36717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36716_36717 : H12AffineEnvironment.transform 13 5457 env36716 = env36717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env36716 == env36717) = true)

theorem identity36717 : scanCanonicalize (H12AffineFastState.compose env36717 (packedSelected [1,8,12,15,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound36717 : packedSelected [1,8,12,15,16,19,20] rootPS < 2^1333 := by decide +kernel

def env36718 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5457,373,35,5393,2049,1025,372,4160,113,17,2,349,64,2420,5392,4176,2341,1365,341,257,112,5157,884]

theorem envBound36718 : H12AffineFastState.Bounded env36718 := by
  intro p hp
  have h : env36718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36717_36718 : H12AffineEnvironment.transform 12 348 env36717 = env36718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env36717 == env36718) = true)

theorem identity36718 : scanCanonicalize (H12AffineFastState.compose env36718 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36718 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36719 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,121,5236,80,35,5172,2049,1025,81,4160,113,17,2,120,64,2129,5173,4176,2048,1136,112,36,112,5157,593]

theorem envBound36719 : H12AffineFastState.Bounded env36719 := by
  intro p hp
  have h : env36719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36718_36719 : H12AffineEnvironment.transform 7 37 env36718 = env36719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36718 == env36719) = true)

theorem identity36719 : scanCanonicalize (H12AffineFastState.compose env36719 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound36719 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36720 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,9,5124,32,35,5172,2049,1025,33,4144,1,17,2,8,48,2081,5173,4128,2048,1024,0,36,0,5157,545]

theorem envBound36720 : H12AffineFastState.Bounded env36720 := by
  intro p hp
  have h : env36720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36719_36720 : H12AffineEnvironment.transform 5 48 env36719 = env36720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env36719 == env36720) = true)

theorem identity36720 : scanCanonicalize (H12AffineFastState.compose env36720 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound36720 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env36721 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5124,0,3,5140,2049,1025,1,4112,1,17,2,8,16,2049,5141,4096,2048,1024,0,4,0,5125,513]

theorem envBound36721 : H12AffineFastState.Bounded env36721 := by
  intro p hp
  have h : env36721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36720_36721 : H12AffineEnvironment.transform 4 0 env36720 = env36721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env36720 == env36721) = true)

theorem identity36721 : scanCanonicalize (H12AffineFastState.compose env36721 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound36721 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36722 : List Nat := [2,4,8,1,0,1,9,5,512,1024,2048,4096,9,5124,0,3,5125,2049,1025,1,4097,1,0,2,8,1,2049,5124,4096,2048,1024,0,4,0,5125,513]

theorem envBound36722 : H12AffineFastState.Bounded env36722 := by
  intro p hp
  have h : env36722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36721_36722 : H12AffineEnvironment.transform 3 1 env36721 = env36722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env36721 == env36722) = true)

theorem identity36722 : scanCanonicalize (H12AffineFastState.compose env36722 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound36722 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36723 : List Nat := [2,4,8,1,0,1,9,5,512,1024,1039,4096,9,5124,0,3,5125,1038,1025,1,4097,1,0,2,8,1,1038,5124,4096,1039,1024,0,4,0,5125,513]

theorem envBound36723 : H12AffineFastState.Bounded env36723 := by
  intro p hp
  have h : env36723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36722_36723 : H12AffineEnvironment.transform 10 1039 env36722 = env36723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env36722 == env36723) = true)

theorem identity36723 : scanCanonicalize (H12AffineFastState.compose env36723 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound36723 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36724 : List Nat := [2,4,8,1,0,1,9,5,10,1024,1039,4096,9,5124,0,3,5125,1038,1025,1,4097,1,0,2,8,1,1038,5124,4096,1039,1024,0,4,0,5125,11]

theorem envBound36724 : H12AffineFastState.Bounded env36724 := by
  intro p hp
  have h : env36724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36723_36724 : H12AffineEnvironment.transform 8 10 env36723 = env36724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env36723 == env36724) = true)

theorem identity36724 : scanCanonicalize (H12AffineFastState.compose env36724 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound36724 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36725 : List Nat := [0,4,8,1,0,1,9,5,8,1024,1037,4096,9,5124,0,1,5125,1036,1025,1,4097,1,0,0,8,1,1036,5124,4096,1037,1024,0,4,0,5125,9]

theorem envBound36725 : H12AffineFastState.Bounded env36725 := by
  intro p hp
  have h : env36725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36724_36725 : H12AffineEnvironment.transform 0 0 env36724 = env36725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env36724 == env36725) = true)

theorem identity36725 : scanCanonicalize (H12AffineFastState.compose env36725 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound36725 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env36726 : List Nat := [0,4,0,1,0,1,1,5,0,1024,1029,4096,1,5124,0,1,5125,1028,1025,1,4097,1,0,0,0,1,1028,5124,4096,1029,1024,0,4,0,5125,1]

theorem envBound36726 : H12AffineFastState.Bounded env36726 := by
  intro p hp
  have h : env36726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36725_36726 : H12AffineEnvironment.transform 2 0 env36725 = env36726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env36725 == env36726) = true)

theorem identity36726 : scanCanonicalize (H12AffineFastState.compose env36726 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound36726 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env36727 : List Nat := [0,4,0,1,0,1,1,5,0,1024,1029,1029,1,1,0,1,0,1028,1025,1,1028,1,0,0,0,1,1028,1,1029,1029,1024,0,4,0,0,1]

theorem envBound36727 : H12AffineFastState.Bounded env36727 := by
  intro p hp
  have h : env36727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36726_36727 : H12AffineEnvironment.transform 11 1029 env36726 = env36727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env36726 == env36727) = true)

theorem identity36727 : scanCanonicalize (H12AffineFastState.compose env36727 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound36727 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36728 : List Nat := [0,0,0,1,0,1,1,1,0,1024,1025,1025,1,1,0,1,0,1024,1025,1,1024,1,0,0,0,1,1024,1,1025,1025,1024,0,0,0,0,1]

theorem envBound36728 : H12AffineFastState.Bounded env36728 := by
  intro p hp
  have h : env36728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36727_36728 : H12AffineEnvironment.transform 1 0 env36727 = env36728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env36727 == env36728) = true)

theorem identity36728 : scanCanonicalize (H12AffineFastState.compose env36728 (packedSelected [8] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound36728 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env36729 : List Nat := [0,0,0,1,0,1,1,1,0,0,1,1,1,1,0,1,0,0,1,1,0,1,0,0,0,1,0,1,1,1,0,0,0,0,0,1]

theorem envBound36729 : H12AffineFastState.Bounded env36729 := by
  intro p hp
  have h : env36729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36728_36729 : H12AffineEnvironment.transform 9 0 env36728 = env36729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env36728 == env36729) = true)

def env36730 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452752,144596,242969,8328,64,43356,139733,160197,324820,1501,272393,257,21793,46213,74250]

theorem envBound36730 : H12AffineFastState.Bounded env36730 := by
  intro p hp
  have h : env36730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36696_36730 : H12AffineEnvironment.transform 20 4161 env36696 = env36730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env36696 == env36730) = true)

theorem identity36730 : scanCanonicalize (H12AffineFastState.compose env36730 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound36730 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36731 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,400452,144596,213453,8328,64,23944,139733,160197,262144,1501,272393,257,21793,16465,74250]

theorem envBound36731 : H12AffineFastState.Bounded env36731 := by
  intro p hp
  have h : env36731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36730_36731 : H12AffineEnvironment.transform 14 29908 env36730 = env36731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env36730 == env36731) = true)

def env36732 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4113,400404,144516,213405,8328,16,23944,139653,160149,262144,1421,272393,257,21793,16385,74250]

theorem envBound36732 : H12AffineFastState.Bounded env36732 := by
  intro p hp
  have h : env36732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36731_36732 : H12AffineEnvironment.transform 5 16 env36731 = env36732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36731 == env36732) = true)

theorem identity36732 : scanCanonicalize (H12AffineFastState.compose env36732 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound36732 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36733 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,79130,262144,1025,29829,4113,338190,65950,29831,8328,16,23944,70815,83087,262144,1421,272393,257,21793,16385,74250]

theorem envBound36733 : H12AffineFastState.Bounded env36733 := by
  intro p hp
  have h : env36733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36732_36733 : H12AffineEnvironment.transform 16 79130 env36732 = env36733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env36732 == env36733) = true)

theorem identity36733 : scanCanonicalize (H12AffineFastState.compose env36733 (packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound36733 : packedSelected [1,3,4,7,9,10,11,14,17,24,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env36734 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,5528,262144,1025,29829,4113,264588,8476,29831,8328,16,23944,13341,25613,262144,1421,272393,257,21793,16385,648]

theorem envBound36734 : H12AffineFastState.Bounded env36734 := by
  intro p hp
  have h : env36734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36733_36734 : H12AffineEnvironment.transform 15 8322 env36733 = env36734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env36733 == env36734) = true)

theorem identity36734 : scanCanonicalize (H12AffineFastState.compose env36734 (packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 3481) := by decide +kernel

theorem selectedBound36734 : packedSelected [0,2,3,5,6,7,10,12,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env36735 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,8322,5528,3481,1025,29829,4113,1045,8476,29831,8328,16,23944,13341,25613,3481,1421,9616,257,21793,16385,648]

theorem envBound36735 : H12AffineFastState.Bounded env36735 := by
  intro p hp
  have h : env36735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36734_36735 : H12AffineEnvironment.transform 17 3481 env36734 = env36735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3481 env36734 == env36735) = true)

theorem identity36735 : scanCanonicalize (H12AffineFastState.compose env36735 (packedSelected [1,2,3,4,5,6,8,10,11,12,15,16,17,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound36735 : packedSelected [1,2,3,4,5,6,8,10,11,12,15,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env36736 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13608,428,8322,5528,3481,1025,429,4113,1045,8476,431,8328,16,10400,13341,4389,3481,1421,9616,257,8201,13609,648]

theorem envBound36736 : H12AffineFastState.Bounded env36736 := by
  intro p hp
  have h : env36736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36735_36736 : H12AffineEnvironment.transform 13 13608 env36735 = env36736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env36735 == env36736) = true)

theorem identity36736 : scanCanonicalize (H12AffineFastState.compose env36736 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound36736 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env36737 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13608,293,8203,5393,3344,1025,292,4113,1045,8476,294,8193,16,10281,13341,4389,3344,1284,9497,257,8201,13609,513]

theorem envBound36737 : H12AffineFastState.Bounded env36737 := by
  intro p hp
  have h : env36737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36736_36737 : H12AffineEnvironment.transform 6 9 env36736 = env36737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env36736 == env36737) = true)

theorem identity36737 : scanCanonicalize (H12AffineFastState.compose env36737 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36737 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36738 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,0,8203,5172,3125,1025,1,4113,1045,8249,3,8193,16,10281,13341,4096,3125,1057,9276,36,8201,13324,513]

theorem envBound36738 : H12AffineFastState.Bounded env36738 := by
  intro p hp
  have h : env36738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36737_36738 : H12AffineEnvironment.transform 7 37 env36737 = env36738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36737 == env36738) = true)

def env36739 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4112,400405,144517,213404,8328,17,23944,139652,160148,262144,1420,272393,257,21793,16384,74250]

theorem envBound36739 : H12AffineFastState.Bounded env36739 := by
  intro p hp
  have h : env36739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36731_36739 : H12AffineEnvironment.transform 5 17 env36731 = env36739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env36731 == env36739) = true)

theorem identity36739 : scanCanonicalize (H12AffineFastState.compose env36739 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound36739 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env36740 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,79251,262144,1025,29828,4112,338310,65814,29711,8328,17,23944,70679,82951,262144,1420,272393,257,21793,16384,74250]

theorem envBound36740 : H12AffineFastState.Bounded env36740 := by
  intro p hp
  have h : env36740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36739_36740 : H12AffineEnvironment.transform 16 79251 env36739 = env36740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env36739 == env36740) = true)

theorem identity36740 : scanCanonicalize (H12AffineFastState.compose env36740 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound36740 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env36741 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,79251,67754,1025,29828,4112,8492,65814,29711,8328,17,23944,70679,82951,67754,1420,73891,257,21793,16384,74250]

theorem envBound36741 : H12AffineFastState.Bounded env36741 := by
  intro p hp
  have h : env36741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36740_36741 : H12AffineEnvironment.transform 17 67754 env36740 = env36741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env36740 == env36741) = true)

theorem identity36741 : scanCanonicalize (H12AffineFastState.compose env36741 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36741 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env36742 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8581,65536,79251,67754,1025,8580,4112,8492,65814,8463,8328,17,2184,70679,69895,67754,1420,73891,257,33,5376,74250]

theorem envBound36742 : H12AffineFastState.Bounded env36742 := by
  intro p hp
  have h : env36742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36741_36742 : H12AffineEnvironment.transform 13 5376 env36741 = env36742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36741 == env36742) = true)

theorem identity36742 : scanCanonicalize (H12AffineFastState.compose env36742 (packedSelected [0,2,4,6,7,9,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound36742 : packedSelected [0,2,4,6,7,9,12,16] rootPS < 2^1333 := by decide +kernel

def env36743 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,65536,70678,67754,1025,1,4112,169,65814,138,269,17,2184,70679,69895,67754,1420,65830,257,33,5376,66447]

theorem envBound36743 : H12AffineFastState.Bounded env36743 := by
  intro p hp
  have h : env36743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36742_36743 : H12AffineEnvironment.transform 12 389 env36742 = env36743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env36742 == env36743) = true)

theorem identity36743 : scanCanonicalize (H12AffineFastState.compose env36743 (packedSelected [3,4,5,9,10,12,17] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound36743 : packedSelected [3,4,5,9,10,12,17] rootPS < 2^1333 := by decide +kernel

def env36744 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,0,398,5528,2340,1025,1,4112,169,152,138,269,17,2184,5529,4233,2340,1420,168,257,33,5376,513]

theorem envBound36744 : H12AffineFastState.Bounded env36744 := by
  intro p hp
  have h : env36744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36743_36744 : H12AffineEnvironment.transform 15 398 env36743 = env36744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env36743 == env36744) = true)

theorem identity36744 : scanCanonicalize (H12AffineFastState.compose env36744 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound36744 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env36745 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,161,5156,0,170,5308,2048,1025,1,4112,169,152,138,41,17,2184,5309,4233,2048,1192,168,37,33,5156,513]

theorem envBound36745 : H12AffineFastState.Bounded env36745 := by
  intro p hp
  have h : env36745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36744_36745 : H12AffineEnvironment.transform 7 36 env36744 = env36745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env36744 == env36745) = true)

theorem identity36745 : scanCanonicalize (H12AffineFastState.compose env36745 (packedSelected [0,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound36745 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env36746 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,0,34,5172,2048,1025,1,4112,33,16,2,41,17,2048,5173,4097,2048,1056,32,37,33,5156,513]

theorem envBound36746 : H12AffineFastState.Bounded env36746 := by
  intro p hp
  have h : env36746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36745_36746 : H12AffineEnvironment.transform 6 8 env36745 = env36746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36745 == env36746) = true)

def env36747 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1044,0,34,1028,2048,1025,1,32,33,16,2,41,17,2048,1029,49,2048,1056,32,37,33,1044,513]

theorem envBound36747 : H12AffineFastState.Bounded env36747 := by
  intro p hp
  have h : env36747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36746_36747 : H12AffineEnvironment.transform 11 48 env36746 = env36747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36746 == env36747) = true)

theorem identity36747 : scanCanonicalize (H12AffineFastState.compose env36747 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound36747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36748 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,41,1044,0,34,1028,0,1025,1,32,33,16,2,41,17,0,1029,49,0,1056,32,37,33,1044,513]

theorem envBound36748 : H12AffineFastState.Bounded env36748 := by
  intro p hp
  have h : env36748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36747_36748 : H12AffineEnvironment.transform 10 0 env36747 = env36748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env36747 == env36748) = true)

def env36749 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,41,32,0,34,48,0,53,1,32,33,16,2,41,17,0,49,49,0,20,32,37,33,32,513]

theorem envBound36749 : H12AffineFastState.Bounded env36749 := by
  intro p hp
  have h : env36749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36748_36749 : H12AffineEnvironment.transform 9 52 env36748 = env36749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36748 == env36749) = true)

theorem identity36749 : scanCanonicalize (H12AffineFastState.compose env36749 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36749 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36750 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,41,32,0,34,48,0,53,1,32,33,16,2,41,17,0,49,49,0,20,32,37,33,32,10]

theorem envBound36750 : H12AffineFastState.Bounded env36750 := by
  intro p hp
  have h : env36750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36749_36750 : H12AffineEnvironment.transform 8 11 env36749 = env36750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36749 == env36750) = true)

def leafEnv36750 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,48,41,32,0,34,48,0,53,1,32,33,16,2,21,41,1,17,0,49,49,0,20,32,37,33,5,34,32,10,1,32,0]

def active36750 : List Nat := [0,1,2,3,4]

def tree36750 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36750 : H12WitnessSearch.Good tree36750 := H12GlobalWitnessIndex.good

theorem leafIdentity36750 : H12AffineFastState.composeSystem env36750 rootObs = leafEnv36750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36750 rootObs == leafEnv36750) = true)

theorem terminalChecked36750 : H12PackedTerminal.terminalCheckFast leafEnv36750 active36750 tree36750 = true := by decide +kernel

def env36751 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,33,0,34,49,0,52,1,32,33,16,2,41,17,0,48,49,0,21,32,37,33,33,513]

theorem envBound36751 : H12AffineFastState.Bounded env36751 := by
  intro p hp
  have h : env36751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36748_36751 : H12AffineEnvironment.transform 9 53 env36748 = env36751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36748 == env36751) = true)

theorem identity36751 : scanCanonicalize (H12AffineFastState.compose env36751 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36752 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,8,0,0,3,16,0,21,1,1,0,16,2,8,17,0,17,16,0,21,1,4,0,0,513]

theorem envBound36752 : H12AffineFastState.Bounded env36752 := by
  intro p hp
  have h : env36752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36751_36752 : H12AffineEnvironment.transform 4 1 env36751 = env36752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36751 == env36752) = true)

def leafEnv36752 : List Nat := [2,4,8,16,1,17,8,5,512,20,0,17,8,0,0,3,16,0,21,1,1,0,16,2,20,8,1,17,0,17,16,0,21,1,4,0,5,3,0,513,1,1,0]

def active36752 : List Nat := [0,1,2,3,8]

def tree36752 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36752 : H12WitnessSearch.Good tree36752 := H12GlobalWitnessIndex.good

theorem leafIdentity36752 : H12AffineFastState.composeSystem env36752 rootObs = leafEnv36752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36752 rootObs == leafEnv36752) = true)

theorem terminalChecked36752 : H12PackedTerminal.terminalCheckFast leafEnv36752 active36752 tree36752 = true := by decide +kernel

def env36753 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1045,0,34,1029,2048,1025,1,33,33,16,2,41,17,2048,1028,48,2048,1056,32,37,33,1045,513]

theorem envBound36753 : H12AffineFastState.Bounded env36753 := by
  intro p hp
  have h : env36753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36746_36753 : H12AffineEnvironment.transform 11 49 env36746 = env36753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env36746 == env36753) = true)

theorem identity36753 : scanCanonicalize (H12AffineFastState.compose env36753 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound36753 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36754 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,41,1045,0,34,1029,1076,1025,1,33,33,16,2,41,17,1076,1028,48,1076,1056,32,37,33,1045,513]

theorem envBound36754 : H12AffineFastState.Bounded env36754 := by
  intro p hp
  have h : env36754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36753_36754 : H12AffineEnvironment.transform 10 1076 env36753 = env36754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env36753 == env36754) = true)

def env36755 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,33,0,34,49,0,53,1,33,33,16,2,41,17,0,48,48,0,20,32,37,33,33,513]

theorem envBound36755 : H12AffineFastState.Bounded env36755 := by
  intro p hp
  have h : env36755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36754_36755 : H12AffineEnvironment.transform 9 52 env36754 = env36755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env36754 == env36755) = true)

theorem identity36755 : scanCanonicalize (H12AffineFastState.compose env36755 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound36755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36756 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,41,33,0,34,49,0,53,1,33,33,16,2,41,17,0,48,48,0,20,32,37,33,33,10]

theorem envBound36756 : H12AffineFastState.Bounded env36756 := by
  intro p hp
  have h : env36756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36755_36756 : H12AffineEnvironment.transform 8 11 env36755 = env36756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env36755 == env36756) = true)

def leafEnv36756 : List Nat := [2,4,8,16,32,17,8,36,11,52,0,49,41,33,0,34,49,0,53,1,33,33,16,2,21,41,1,17,0,48,48,0,20,32,37,33,5,34,33,10,1,33,0]

def active36756 : List Nat := [0,1,2,3,4]

def tree36756 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36756 : H12WitnessSearch.Good tree36756 := H12GlobalWitnessIndex.good

theorem leafIdentity36756 : H12AffineFastState.composeSystem env36756 rootObs = leafEnv36756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36756 rootObs == leafEnv36756) = true)

theorem terminalChecked36756 : H12PackedTerminal.terminalCheckFast leafEnv36756 active36756 tree36756 = true := by decide +kernel

def env36757 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,41,32,0,34,48,1,52,1,33,33,16,2,41,17,1,49,48,1,21,32,37,33,32,513]

theorem envBound36757 : H12AffineFastState.Bounded env36757 := by
  intro p hp
  have h : env36757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36754_36757 : H12AffineEnvironment.transform 9 53 env36754 = env36757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36754 == env36757) = true)

theorem identity36757 : scanCanonicalize (H12AffineFastState.compose env36757 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound36757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env36758 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,8,1,0,3,17,1,21,1,0,0,16,2,8,17,1,16,17,1,21,1,4,0,1,513]

theorem envBound36758 : H12AffineFastState.Bounded env36758 := by
  intro p hp
  have h : env36758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36757_36758 : H12AffineEnvironment.transform 4 1 env36757 = env36758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env36757 == env36758) = true)

def leafEnv36758 : List Nat := [2,4,8,16,1,17,8,5,512,20,1,16,8,1,0,3,17,1,21,1,0,0,16,2,20,8,1,17,1,16,17,1,21,1,4,0,5,3,1,513,1,0,0]

def active36758 : List Nat := [0,1,2,3,8]

def tree36758 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood36758 : H12WitnessSearch.Good tree36758 := H12GlobalWitnessIndex.good

theorem leafIdentity36758 : H12AffineFastState.composeSystem env36758 rootObs = leafEnv36758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env36758 rootObs == leafEnv36758) = true)

theorem terminalChecked36758 : H12PackedTerminal.terminalCheckFast leafEnv36758 active36758 tree36758 = true := by decide +kernel

def env36759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452753,2237589,242969,8328,64,2144540,2240916,160197,2417813,2102684,2373705,257,21793,46213,2175563]

theorem envBound36759 : H12AffineFastState.Bounded env36759 := by
  intro p hp
  have h : env36759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36695_36759 : H12AffineEnvironment.transform 21 452753 env36695 = env36759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452753 env36695 == env36759) = true)

def env36760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452753,144597,242969,8328,64,43356,139732,160197,324821,1500,272393,257,21793,46213,74251]

theorem envBound36760 : H12AffineFastState.Bounded env36760 := by
  intro p hp
  have h : env36760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36759_36760 : H12AffineEnvironment.transform 20 4160 env36759 = env36760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env36759 == env36760) = true)

def env36761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180409,144597,242969,8328,64,43356,139732,160197,56573,1500,33,257,21793,46213,74251]

theorem envBound36761 : H12AffineFastState.Bounded env36761 := by
  intro p hp
  have h : env36761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36760_36761 : H12AffineEnvironment.transform 17 10280 env36760 = env36761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env36760 == env36761) = true)

def env36762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4160,21929,41413,73737,8328,64,43356,46276,58581,56573,1500,33,257,21793,46213,74251]

theorem envBound36762 : H12AffineFastState.Bounded env36762 := by
  intro p hp
  have h : env36762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36761_36762 : H12AffineEnvironment.transform 16 38160 env36761 = env36762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env36761 == env36762) = true)

theorem identity36762 : scanCanonicalize (H12AffineFastState.compose env36762 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound36762 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13509,10280,1025,8660,4160,21929,16,73737,8328,64,2185,5393,17664,32040,1500,33,257,21793,5456,74251]

theorem envBound36763 : H12AffineFastState.Bounded env36763 := by
  intro p hp
  have h : env36763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36762_36763 : H12AffineEnvironment.transform 14 8661 env36762 = env36763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env36762 == env36763) = true)

theorem identity36763 : scanCanonicalize (H12AffineFastState.compose env36763 (packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 20578) := by decide +kernel

theorem selectedBound36763 : packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS < 2^1333 := by decide +kernel

def env36764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,20578,13509,10280,1025,8660,4160,21929,16,28779,8328,64,2185,5393,17664,32040,1500,33,257,21793,5456,29289]

theorem envBound36764 : H12AffineFastState.Bounded env36764 := by
  intro p hp
  have h : env36764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36763_36764 : H12AffineEnvironment.transform 15 20578 env36763 = env36764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20578 env36763 == env36764) = true)

theorem identity36764 : scanCanonicalize (H12AffineFastState.compose env36764 (packedSelected [2,3,6,7,9,10,12,15,19,20,22,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound36764 : packedSelected [2,3,6,7,9,10,12,15,19,20,22,24,27] rootPS < 2^1333 := by decide +kernel

def env36765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8661,1046,13509,10280,1025,8660,4160,477,16,9247,8328,64,2185,5393,4468,10588,1500,33,257,341,5456,9757]

theorem envBound36765 : H12AffineFastState.Bounded env36765 := by
  intro p hp
  have h : env36765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36764_36765 : H12AffineEnvironment.transform 13 5236 env36764 = env36765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env36764 == env36765) = true)

theorem identity36765 : scanCanonicalize (H12AffineFastState.compose env36765 (packedSelected [2,4,6,18,20,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound36765 : packedSelected [2,4,6,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env36766 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5156,8581,1046,13461,10280,1025,8580,4112,397,16,9247,8328,16,2185,5393,4388,10508,1420,33,257,261,5376,9757]

theorem envBound36766 : H12AffineFastState.Bounded env36766 := by
  intro p hp
  have h : env36766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36765_36766 : H12AffineEnvironment.transform 5 16 env36765 = env36766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env36765 == env36766) = true)

theorem identity36766 : scanCanonicalize (H12AffineFastState.compose env36766 (packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound36766 : packedSelected [1,3,4,5,8,9,10,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env36767 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1052,5156,1433,1046,4233,3124,1025,1432,4112,397,16,3,1172,16,2185,5393,4388,3344,1420,33,257,261,5376,513]

theorem envBound36767 : H12AffineFastState.Bounded env36767 := by
  intro p hp
  have h : env36767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36766_36767 : H12AffineEnvironment.transform 12 1052 env36766 = env36767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env36766 == env36767) = true)

theorem identity36767 : scanCanonicalize (H12AffineFastState.compose env36767 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound36767 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env36768 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,4096,161,4249,292,171,4233,2185,188,293,4112,397,16,3,41,16,2185,4524,4388,2477,305,33,257,261,4541,513]

theorem envBound36768 : H12AffineFastState.Bounded env36768 := by
  intro p hp
  have h : env36768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36767_36768 : H12AffineEnvironment.transform 9 189 env36767 = env36768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env36767 == env36768) = true)

theorem identity36768 : scanCanonicalize (H12AffineFastState.compose env36768 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 130) := by decide +kernel

theorem selectedBound36768 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36769 : List Nat := [2,4,8,16,32,16,128,256,130,189,2048,4096,161,4249,292,171,4233,2185,188,293,4112,397,16,3,41,16,2185,4524,4388,2477,305,33,257,261,4541,131]

theorem envBound36769 : H12AffineFastState.Bounded env36769 := by
  intro p hp
  have h : env36769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36768_36769 : H12AffineEnvironment.transform 8 130 env36768 = env36769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 130 env36768 == env36769) = true)

theorem identity36769 : scanCanonicalize (H12AffineFastState.compose env36769 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 444) := by decide +kernel

theorem selectedBound36769 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36770 : List Nat := [2,4,8,16,32,16,128,256,130,189,2048,444,161,293,292,171,309,2185,188,293,428,397,16,3,41,16,2185,16,152,2477,305,33,257,261,1,131]

theorem envBound36770 : H12AffineFastState.Bounded env36770 := by
  intro p hp
  have h : env36770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36769_36770 : H12AffineEnvironment.transform 11 444 env36769 = env36770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 444 env36769 == env36770) = true)

theorem identity36770 : scanCanonicalize (H12AffineFastState.compose env36770 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound36770 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env36771 : List Nat := [2,4,8,16,32,16,128,256,130,189,137,444,161,293,292,171,309,0,188,293,428,397,16,3,41,16,0,16,152,292,305,33,257,261,1,131]

end H12CloudChart1