import H12CloudChart1Data079

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound20223 : H12AffineFastState.Bounded env20223 := by
  intro p hp
  have h : env20223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20222_20223 : H12AffineEnvironment.transform 15 262 env20222 = env20223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env20222 == env20223) = true)

theorem identity20223 : scanCanonicalize (H12AffineFastState.compose env20223 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20223 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20224 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,262,5392,2341,1025,0,12572,8493,8477,2,8192,16,10508,13340,12556,2340,9224,33,257,8492,13324,513]

theorem envBound20224 : H12AffineFastState.Bounded env20224 := by
  intro p hp
  have h : env20224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20223_20224 : H12AffineEnvironment.transform 5 16 env20223 = env20224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20223 == env20224) = true)

theorem identity20224 : scanCanonicalize (H12AffineFastState.compose env20224 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20224 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env20225 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,8192,12572,1,262,4096,2341,273,0,12572,8493,8477,2,8192,16,10508,12556,12556,2340,8472,33,257,8492,12572,513]

theorem envBound20225 : H12AffineFastState.Bounded env20225 := by
  intro p hp
  have h : env20225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20224_20225 : H12AffineEnvironment.transform 9 272 env20224 = env20225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20224 == env20225) = true)

theorem identity20225 : scanCanonicalize (H12AffineFastState.compose env20225 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20225 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20226 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,268,4112,1,262,4096,2341,273,0,4112,33,17,2,268,16,2048,4096,4096,2340,20,33,257,32,4112,513]

theorem envBound20226 : H12AffineFastState.Bounded env20226 := by
  intro p hp
  have h : env20226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20225_20226 : H12AffineEnvironment.transform 12 268 env20225 = env20226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20225 == env20226) = true)

theorem identity20226 : scanCanonicalize (H12AffineFastState.compose env20226 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound20226 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20227 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,276,268,260,1,262,276,2341,273,0,260,33,17,2,268,16,2048,276,276,2340,20,33,257,32,260,513]

theorem envBound20227 : H12AffineFastState.Bounded env20227 := by
  intro p hp
  have h : env20227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20226_20227 : H12AffineEnvironment.transform 11 276 env20226 = env20227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env20226 == env20227) = true)

theorem identity20227 : scanCanonicalize (H12AffineFastState.compose env20227 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20227 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20228 : List Nat := [2,4,8,16,1,16,8,256,512,272,2048,276,268,260,1,262,276,2308,273,0,260,0,17,2,268,16,2048,276,276,2309,20,0,257,1,260,513]

theorem envBound20228 : H12AffineFastState.Bounded env20228 := by
  intro p hp
  have h : env20228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20227_20228 : H12AffineEnvironment.transform 4 1 env20227 = env20228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20227 == env20228) = true)

theorem identity20228 : scanCanonicalize (H12AffineFastState.compose env20228 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound20228 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20229 : List Nat := [2,4,8,16,1,16,8,256,512,272,512,276,268,260,1,262,276,772,273,0,260,0,17,2,268,16,512,276,276,773,20,0,257,1,260,513]

theorem envBound20229 : H12AffineFastState.Bounded env20229 := by
  intro p hp
  have h : env20229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20228_20229 : H12AffineEnvironment.transform 10 512 env20228 = env20229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env20228 == env20229) = true)

theorem identity20229 : scanCanonicalize (H12AffineFastState.compose env20229 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20229 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20230 : List Nat := [2,4,8,1,1,1,8,256,512,257,512,261,268,260,1,262,261,772,256,0,260,0,0,2,268,1,512,261,261,773,5,0,257,1,260,513]

theorem envBound20230 : H12AffineFastState.Bounded env20230 := by
  intro p hp
  have h : env20230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20229_20230 : H12AffineEnvironment.transform 3 1 env20229 = env20230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20229 == env20230) = true)

theorem identity20230 : scanCanonicalize (H12AffineFastState.compose env20230 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound20230 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20231 : List Nat := [2,4,8,1,1,1,8,4,512,5,512,1,8,0,1,2,1,512,4,0,0,0,0,2,8,1,512,1,1,513,5,0,5,1,0,513]

theorem envBound20231 : H12AffineFastState.Bounded env20231 := by
  intro p hp
  have h : env20231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20230_20231 : H12AffineEnvironment.transform 7 4 env20230 = env20231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env20230 == env20231) = true)

theorem identity20231 : scanCanonicalize (H12AffineFastState.compose env20231 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20231 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env20232 : List Nat := [2,4,8,1,1,1,8,4,0,5,0,1,8,0,1,2,1,0,4,0,0,0,0,2,8,1,0,1,1,1,5,0,5,1,0,1]

theorem envBound20232 : H12AffineFastState.Bounded env20232 := by
  intro p hp
  have h : env20232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20231_20232 : H12AffineEnvironment.transform 8 0 env20231 = env20232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20231 == env20232) = true)

def env20233 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180224,98644,8193,64,43357,185601,17664,262145,181572,400453,257,21792,46092,254490]

theorem envBound20233 : H12AffineFastState.Bounded env20233 := by
  intro p hp
  have h : env20233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20217_20233 : H12AffineEnvironment.transform 6 9 env20217 = env20233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20217 == env20233) = true)

theorem identity20233 : scanCanonicalize (H12AffineFastState.compose env20233 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound20233 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env20234 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,36928,272393,32785,98644,8193,64,43357,38160,17664,262145,34133,285780,257,21792,46092,107019]

theorem envBound20234 : H12AffineFastState.Bounded env20234 := by
  intro p hp
  have h : env20234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20233_20234 : H12AffineEnvironment.transform 16 16401 env20233 = env20234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20233 == env20234) = true)

theorem identity20234 : scanCanonicalize (H12AffineFastState.compose env20234 (packedSelected [0,1,4,7,19,22,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound20234 : packedSelected [0,1,4,7,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env20235 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,43049,1025,32769,36928,32800,32785,98644,8193,64,43357,38160,17664,43048,34133,62589,257,21792,46092,107019]

theorem envBound20235 : H12AffineFastState.Bounded env20235 := by
  intro p hp
  have h : env20235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20234_20235 : H12AffineEnvironment.transform 17 43049 env20234 = env20235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env20234 == env20235) = true)

theorem identity20235 : scanCanonicalize (H12AffineFastState.compose env20235 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound20235 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20236 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33111,16401,43049,1025,32769,36928,32800,32785,3,8193,64,43357,38160,17664,43048,34133,62589,257,21792,46092,9052]

theorem envBound20236 : H12AffineFastState.Bounded env20236 := by
  intro p hp
  have h : env20236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20235_20236 : H12AffineEnvironment.transform 15 33111 env20235 = env20236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env20235 == env20236) = true)

theorem identity20236 : scanCanonicalize (H12AffineFastState.compose env20236 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound20236 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20237 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16401,2421,1025,8541,12572,8572,8525,3,8193,64,2049,13388,17664,2420,9225,21793,257,21792,5456,9052]

theorem envBound20237 : H12AffineFastState.Bounded env20237 := by
  intro p hp
  have h : env20237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20236_20237 : H12AffineEnvironment.transform 14 8540 env20236 = env20237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env20236 == env20237) = true)

theorem identity20237 : scanCanonicalize (H12AffineFastState.compose env20237 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound20237 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env20238 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8540,8203,5221,2421,1025,8541,12572,8572,8525,3,8193,64,2049,13388,4468,2420,9225,341,257,340,5456,9052]

theorem envBound20238 : H12AffineFastState.Bounded env20238 := by
  intro p hp
  have h : env20238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20237_20238 : H12AffineEnvironment.transform 13 5236 env20237 = env20238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env20237 == env20238) = true)

theorem identity20238 : scanCanonicalize (H12AffineFastState.compose env20238 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound20238 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env20239 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5236,80,263,5221,2421,1025,81,4112,112,65,3,269,64,2049,5440,4468,2420,1285,341,257,340,5456,592]

theorem envBound20239 : H12AffineFastState.Bounded env20239 := by
  intro p hp
  have h : env20239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20238_20239 : H12AffineEnvironment.transform 12 268 env20238 = env20239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env20238 == env20239) = true)

theorem identity20239 : scanCanonicalize (H12AffineFastState.compose env20239 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20239 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env20240 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,80,114,5221,2048,1025,81,4112,112,65,3,120,64,2049,5173,4097,2049,1136,32,116,33,5157,592]

theorem envBound20240 : H12AffineFastState.Bounded env20240 := by
  intro p hp
  have h : env20240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20239_20240 : H12AffineEnvironment.transform 7 117 env20239 = env20240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20239 == env20240) = true)

theorem identity20240 : scanCanonicalize (H12AffineFastState.compose env20240 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20240 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env20241 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,0,34,5173,2048,1025,1,4112,32,17,3,40,16,2049,5173,4097,2049,1056,32,36,33,5157,512]

theorem envBound20241 : H12AffineFastState.Bounded env20241 := by
  intro p hp
  have h : env20241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20240_20241 : H12AffineEnvironment.transform 5 16 env20240 = env20241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20240 == env20241) = true)

theorem identity20241 : scanCanonicalize (H12AffineFastState.compose env20241 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20242 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5124,0,2,5141,2048,1025,1,4112,0,17,3,8,16,2049,5141,4097,2049,1024,0,4,1,5125,512]

theorem envBound20242 : H12AffineFastState.Bounded env20242 := by
  intro p hp
  have h : env20242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20241_20242 : H12AffineEnvironment.transform 4 0 env20241 = env20242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20241 == env20242) = true)

theorem identity20242 : scanCanonicalize (H12AffineFastState.compose env20242 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound20242 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20243 : List Nat := [2,4,8,16,0,16,9,5,512,1024,523,4096,9,5124,0,2,5141,523,1025,1,4112,0,17,3,8,16,522,5141,4097,522,1024,0,4,1,5125,512]

theorem envBound20243 : H12AffineFastState.Bounded env20243 := by
  intro p hp
  have h : env20243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20242_20243 : H12AffineEnvironment.transform 10 523 env20242 = env20243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env20242 == env20243) = true)

def env20244 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,98781,8328,64,43356,185601,17664,262145,181709,400589,257,21792,46213,254490]

theorem envBound20244 : H12AffineFastState.Bounded env20244 := by
  intro p hp
  have h : env20244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20216_20244 : H12AffineEnvironment.transform 21 272513 env20216 = env20244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20216 == env20244) = true)

theorem identity20244 : scanCanonicalize (H12AffineFastState.compose env20244 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound20244 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20245 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272513,17,98781,8328,64,43356,5392,17664,262145,1500,318684,257,21792,46213,74251]

theorem envBound20245 : H12AffineFastState.Bounded env20245 := by
  intro p hp
  have h : env20245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20244_20245 : H12AffineEnvironment.transform 16 49169 env20244 = env20245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env20244 == env20245) = true)

theorem identity20245 : scanCanonicalize (H12AffineFastState.compose env20245 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20245 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20246 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4160,272513,17,41431,8328,64,43356,5392,17664,262145,1500,318684,257,21792,46213,513]

theorem envBound20246 : H12AffineFastState.Bounded env20246 := by
  intro p hp
  have h : env20246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20245_20246 : H12AffineEnvironment.transform 15 8202 env20245 = env20246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20245 == env20246) = true)

theorem identity20246 : scanCanonicalize (H12AffineFastState.compose env20246 (packedSelected [3,4,9,10,14,20,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound20246 : packedSelected [3,4,9,10,14,20,24,26] rootPS < 2^1333 := by decide +kernel

def env20247 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10400,1025,32769,4160,33,17,41431,8328,64,43356,5392,17664,10401,1500,62588,257,21792,46213,513]

theorem envBound20247 : H12AffineFastState.Bounded env20247 := by
  intro p hp
  have h : env20247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20246_20247 : H12AffineEnvironment.transform 17 10400 env20246 = env20247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env20246 == env20247) = true)

theorem identity20247 : scanCanonicalize (H12AffineFastState.compose env20247 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20247 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env20248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16400,10400,1025,0,4160,33,17,8662,8328,64,10589,5392,17664,10401,1500,29821,257,21792,13444,513]

theorem envBound20248 : H12AffineFastState.Bounded env20248 := by
  intro p hp
  have h : env20248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20247_20248 : H12AffineEnvironment.transform 14 1 env20247 = env20248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20247 == env20248) = true)

theorem identity20248 : scanCanonicalize (H12AffineFastState.compose env20248 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound20248 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env20249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4113,1,8202,4097,10400,1025,0,4160,33,17,8662,8328,64,10589,5392,5393,10401,1500,9324,257,1329,13444,513]

theorem envBound20249 : H12AffineFastState.Bounded env20249 := by
  intro p hp
  have h : env20249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20248_20249 : H12AffineEnvironment.transform 13 4113 env20248 = env20249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env20248 == env20249) = true)

theorem identity20249 : scanCanonicalize (H12AffineFastState.compose env20249 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound20249 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1101,4113,1,1095,4097,3309,1025,0,4160,33,17,1435,1221,64,3344,5392,5393,3308,1500,33,257,1329,4297,513]

theorem envBound20250 : H12AffineFastState.Bounded env20250 := by
  intro p hp
  have h : env20250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20249_20250 : H12AffineEnvironment.transform 12 1101 env20249 = env20250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env20249 == env20250) = true)

theorem identity20250 : scanCanonicalize (H12AffineFastState.compose env20250 (packedSelected [0,1,3,5,7,8,11,15] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound20250 : packedSelected [0,1,3,5,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env20251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1076,4096,1101,4113,1,1095,4097,217,1025,0,4160,33,17,1435,1221,64,292,5392,5393,216,1500,33,257,1329,4297,513]

theorem envBound20251 : H12AffineFastState.Bounded env20251 := by
  intro p hp
  have h : env20251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20250_20251 : H12AffineEnvironment.transform 10 1076 env20250 = env20251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env20250 == env20251) = true)

theorem identity20251 : scanCanonicalize (H12AffineFastState.compose env20251 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound20251 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env20252 : List Nat := [2,4,8,16,32,64,128,256,512,273,293,4096,348,4113,1,342,4097,217,272,0,4160,33,17,138,468,64,292,4097,4096,216,205,33,257,32,4297,513]

theorem envBound20252 : H12AffineFastState.Bounded env20252 := by
  intro p hp
  have h : env20252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20251_20252 : H12AffineEnvironment.transform 9 273 env20251 = env20252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env20251 == env20252) = true)

theorem identity20252 : scanCanonicalize (H12AffineFastState.compose env20252 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound20252 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20253 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,4096,241,4113,1,251,4097,217,189,0,4160,33,17,138,121,64,137,4097,4096,216,205,33,172,32,4297,513]

theorem envBound20253 : H12AffineFastState.Bounded env20253 := by
  intro p hp
  have h : env20253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20252_20253 : H12AffineEnvironment.transform 7 173 env20252 = env20253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env20252 == env20253) = true)

theorem identity20253 : scanCanonicalize (H12AffineFastState.compose env20253 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound20253 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20254 : List Nat := [2,4,8,16,32,64,128,173,512,188,136,153,241,136,1,251,152,217,189,0,217,33,17,138,121,64,137,152,153,216,205,33,172,32,80,513]

theorem envBound20254 : H12AffineFastState.Bounded env20254 := by
  intro p hp
  have h : env20254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20253_20254 : H12AffineEnvironment.transform 11 153 env20253 = env20254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env20253 == env20254) = true)

theorem identity20254 : scanCanonicalize (H12AffineFastState.compose env20254 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20254 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20255 : List Nat := [2,4,8,16,32,16,128,173,512,188,136,153,161,136,1,171,152,137,189,0,137,33,17,138,41,16,137,152,153,136,157,33,172,32,0,513]

theorem envBound20255 : H12AffineFastState.Bounded env20255 := by
  intro p hp
  have h : env20255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20254_20255 : H12AffineEnvironment.transform 5 16 env20254 = env20255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20254 == env20255) = true)

theorem identity20255 : scanCanonicalize (H12AffineFastState.compose env20255 (packedSelected [1,5] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20255 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20256 : List Nat := [2,4,8,16,32,16,9,36,512,53,1,16,40,1,1,34,17,0,52,0,0,33,17,3,41,16,0,17,16,1,20,33,37,32,0,513]

theorem envBound20256 : H12AffineFastState.Bounded env20256 := by
  intro p hp
  have h : env20256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20255_20256 : H12AffineEnvironment.transform 6 9 env20255 = env20256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20255 == env20256) = true)

theorem identity20256 : scanCanonicalize (H12AffineFastState.compose env20256 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound20256 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20257 : List Nat := [2,4,8,16,32,16,9,36,17,53,1,16,40,1,1,34,17,0,52,0,0,33,17,3,41,16,0,17,16,1,20,33,37,32,0,16]

theorem envBound20257 : H12AffineFastState.Bounded env20257 := by
  intro p hp
  have h : env20257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20256_20257 : H12AffineEnvironment.transform 8 17 env20256 = env20257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env20256 == env20257) = true)

theorem identity20257 : scanCanonicalize (H12AffineFastState.compose env20257 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound20257 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20258 : List Nat := [2,4,8,16,26,16,9,30,17,15,1,16,18,1,1,24,17,0,14,0,0,27,17,3,19,16,0,17,16,1,20,27,31,26,0,16]

theorem envBound20258 : H12AffineFastState.Bounded env20258 := by
  intro p hp
  have h : env20258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20257_20258 : H12AffineEnvironment.transform 4 26 env20257 = env20258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env20257 == env20258) = true)

def env20259 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,98780,8328,64,4489693,185600,17665,262144,181709,4338765,257,21792,46213,254490]

theorem envBound20259 : H12AffineFastState.Bounded env20259 := by
  intro p hp
  have h : env20259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20215_20259 : H12AffineEnvironment.transform 22 180225 env20215 = env20259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env20215 == env20259) = true)

def env20260 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,98780,8328,64,43357,185600,17665,262144,181709,400589,257,21792,46213,254490]

theorem envBound20260 : H12AffineFastState.Bounded env20260 := by
  intro p hp
  have h : env20260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20259_20260 : H12AffineEnvironment.transform 21 272512 env20259 = env20260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env20259 == env20260) = true)

theorem identity20260 : scanCanonicalize (H12AffineFastState.compose env20260 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound20260 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20261 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,140420,272512,144596,95497,8328,64,23944,139733,17665,262144,143640,400589,257,21792,16464,202447]

theorem envBound20261 : H12AffineFastState.Bounded env20261 := by
  intro p hp
  have h : env20261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20260_20261 : H12AffineEnvironment.transform 14 29909 env20260 = env20261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env20260 == env20261) = true)

theorem identity20261 : scanCanonicalize (H12AffineFastState.compose env20261 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound20261 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env20262 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90138,262144,1025,29908,83102,272512,87246,95497,8328,64,23944,82383,17665,262144,86274,359639,257,21792,16464,30421]

theorem envBound20262 : H12AffineFastState.Bounded env20262 := by
  intro p hp
  have h : env20262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20261_20262 : H12AffineEnvironment.transform 16 90138 env20261 = env20262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env20261 == env20262) = true)

theorem identity20262 : scanCanonicalize (H12AffineFastState.compose env20262 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound20262 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env20263 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1,65536,70862,262144,1025,0,77898,272512,73754,66013,8328,64,10588,79131,12757,262144,75222,329731,257,8692,13444,513]

theorem envBound20263 : H12AffineFastState.Bounded env20263 := by
  intro p hp
  have h : env20263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20262_20263 : H12AffineEnvironment.transform 13 13524 env20262 = env20263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env20262 == env20263) = true)

def env20264 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,65536,70726,262144,1025,0,77898,272392,73754,65877,8192,64,10588,79131,12637,262144,75102,329731,257,8572,13324,513]

theorem envBound20264 : H12AffineFastState.Bounded env20264 := by
  intro p hp
  have h : env20264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20263_20264 : H12AffineEnvironment.transform 6 8 env20263 = env20264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20263 == env20264) = true)

theorem identity20264 : scanCanonicalize (H12AffineFastState.compose env20264 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20264 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env20265 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,65536,70678,262144,1025,0,77850,272392,73754,65797,8192,16,10508,79131,12557,262144,75022,329731,257,8492,13324,513]

theorem envBound20265 : H12AffineFastState.Bounded env20265 := by
  intro p hp
  have h : env20265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20264_20265 : H12AffineEnvironment.transform 5 16 env20264 = env20265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20264 == env20265) = true)

theorem identity20265 : scanCanonicalize (H12AffineFastState.compose env20265 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound20265 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env20266 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,65536,70678,76078,1025,0,77850,65830,73754,65797,8192,16,10508,79131,12557,76078,75022,8493,257,8492,13324,513]

theorem envBound20266 : H12AffineFastState.Bounded env20266 := by
  intro p hp
  have h : env20266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20265_20266 : H12AffineEnvironment.transform 17 76078 env20265 = env20266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env20265 == env20266) = true)

theorem identity20266 : scanCanonicalize (H12AffineFastState.compose env20266 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20266 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20267 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,1,8203,13341,2341,1025,0,4113,8493,17,8462,8192,16,10508,5392,12557,2341,1285,8493,257,8492,13324,513]

theorem envBound20267 : H12AffineFastState.Bounded env20267 := by
  intro p hp
  have h : env20267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20266_20267 : H12AffineEnvironment.transform 15 8203 env20266 = env20267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20266 == env20267) = true)

theorem identity20267 : scanCanonicalize (H12AffineFastState.compose env20267 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 780) := by decide +kernel

theorem selectedBound20267 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20268 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,780,5888,1,775,5905,2341,1025,0,4113,545,17,514,780,16,2560,5392,4609,2341,1285,545,257,544,5888,513]

theorem envBound20268 : H12AffineFastState.Bounded env20268 := by
  intro p hp
  have h : env20268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20267_20268 : H12AffineEnvironment.transform 12 780 env20267 = env20268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 780 env20267 == env20268) = true)

theorem identity20268 : scanCanonicalize (H12AffineFastState.compose env20268 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20268 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20269 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,4096,268,5376,1,263,5393,2341,1025,0,4113,33,17,2,268,16,2048,5392,4097,2341,1285,33,257,32,5376,1]

theorem envBound20269 : H12AffineFastState.Bounded env20269 := by
  intro p hp
  have h : env20269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20268_20269 : H12AffineEnvironment.transform 8 0 env20268 = env20269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20268 == env20269) = true)

theorem identity20269 : scanCanonicalize (H12AffineFastState.compose env20269 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound20269 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20270 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,292,268,1060,1,263,1077,2341,1025,0,309,33,17,2,268,16,2048,1076,293,2341,1285,33,257,32,1060,1]

theorem envBound20270 : H12AffineFastState.Bounded env20270 := by
  intro p hp
  have h : env20270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20269_20270 : H12AffineEnvironment.transform 11 292 env20269 = env20270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env20269 == env20270) = true)

def env20271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,65536,70727,262144,1025,0,77898,272393,73754,65876,8193,64,10588,79131,12636,262144,75103,329731,257,8573,13325,513]

theorem envBound20271 : H12AffineFastState.Bounded env20271 := by
  intro p hp
  have h : env20271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20263_20271 : H12AffineEnvironment.transform 6 9 env20263 = env20271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20263 == env20271) = true)

theorem identity20271 : scanCanonicalize (H12AffineFastState.compose env20271 (packedSelected [2,6,17] rootPS)) = affineNative (2^(17+1) ^^^ 67699) := by decide +kernel

theorem selectedBound20271 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env20272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,65536,70727,67699,1025,0,77898,73850,73754,65876,8193,64,10588,79131,12636,67699,75103,112,257,8573,13325,513]

theorem envBound20272 : H12AffineFastState.Bounded env20272 := by
  intro p hp
  have h : env20272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20271_20272 : H12AffineEnvironment.transform 17 67699 env20271 = env20272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67699 env20271 == env20272) = true)

theorem identity20272 : scanCanonicalize (H12AffineFastState.compose env20272 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20272 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env20273 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,65536,70678,67618,1025,0,77851,73771,73754,65797,8193,17,10509,79131,12557,67618,75022,33,257,8492,13325,513]

theorem envBound20273 : H12AffineFastState.Bounded env20273 := by
  intro p hp
  have h : env20273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20272_20273 : H12AffineEnvironment.transform 5 17 env20272 = env20273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20272 == env20273) = true)

theorem identity20273 : scanCanonicalize (H12AffineFastState.compose env20273 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound20273 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20274 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,1,262,5392,2340,1025,0,12573,8493,8476,3,8193,17,10509,13341,12557,2340,9224,33,257,8492,13325,513]

theorem envBound20274 : H12AffineFastState.Bounded env20274 := by
  intro p hp
  have h : env20274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20273_20274 : H12AffineEnvironment.transform 15 262 env20273 = env20274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env20273 == env20274) = true)

theorem identity20274 : scanCanonicalize (H12AffineFastState.compose env20274 (packedSelected [0,1,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 4877) := by decide +kernel

theorem selectedBound20274 : packedSelected [0,1,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env20275 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,4877,1793,1,262,5392,2340,1025,0,528,4640,4625,3,4876,17,6656,1808,512,2340,5893,33,257,4641,1792,513]

theorem envBound20275 : H12AffineFastState.Bounded env20275 := by
  intro p hp
  have h : env20275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20274_20275 : H12AffineEnvironment.transform 12 4877 env20274 = env20275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4877 env20274 == env20275) = true)

theorem identity20275 : scanCanonicalize (H12AffineFastState.compose env20275 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound20275 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env20276 : List Nat := [2,4,8,16,32,17,9,256,512,1024,821,4096,4877,1793,1,262,5392,529,1025,0,528,4640,4625,3,4876,17,4405,1808,512,529,5893,33,257,4641,1792,513]

theorem envBound20276 : H12AffineFastState.Bounded env20276 := by
  intro p hp
  have h : env20276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20275_20276 : H12AffineEnvironment.transform 10 821 env20275 = env20276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env20275 == env20276) = true)

theorem identity20276 : scanCanonicalize (H12AffineFastState.compose env20276 (packedSelected [0,3,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound20276 : packedSelected [0,3,4,8,11] rootPS < 2^1333 := by decide +kernel

def env20277 : List Nat := [2,4,8,16,32,17,9,256,512,1024,821,528,285,1793,1,262,1792,529,1025,0,528,48,1,3,284,17,805,1808,512,529,1301,33,257,49,1792,513]

theorem envBound20277 : H12AffineFastState.Bounded env20277 := by
  intro p hp
  have h : env20277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20276_20277 : H12AffineEnvironment.transform 11 528 env20276 = env20277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env20276 == env20277) = true)

theorem identity20277 : scanCanonicalize (H12AffineFastState.compose env20277 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20277 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env20278 : List Nat := [2,4,8,1,32,0,9,256,512,1024,804,513,268,1793,1,262,1792,512,1025,0,513,33,1,3,269,0,805,1793,512,512,1284,33,257,32,1792,513]

theorem envBound20278 : H12AffineFastState.Bounded env20278 := by
  intro p hp
  have h : env20278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20277_20278 : H12AffineEnvironment.transform 3 1 env20277 = env20278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20277 == env20278) = true)

theorem identity20278 : scanCanonicalize (H12AffineFastState.compose env20278 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound20278 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20279 : List Nat := [2,4,8,1,32,0,9,256,512,288,804,513,268,545,1,262,544,512,289,0,513,33,1,3,269,0,805,545,512,512,36,33,257,32,544,513]

theorem envBound20279 : H12AffineFastState.Bounded env20279 := by
  intro p hp
  have h : env20279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20278_20279 : H12AffineEnvironment.transform 9 288 env20278 = env20279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env20278 == env20279) = true)

theorem identity20279 : scanCanonicalize (H12AffineFastState.compose env20279 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20279 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20280 : List Nat := [2,4,8,1,32,0,9,36,512,4,512,513,40,545,1,34,544,512,5,0,513,33,1,3,41,0,513,545,512,512,36,33,37,32,544,513]

theorem envBound20280 : H12AffineFastState.Bounded env20280 := by
  intro p hp
  have h : env20280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20279_20280 : H12AffineEnvironment.transform 7 36 env20279 = env20280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20279 == env20280) = true)

theorem identity20280 : scanCanonicalize (H12AffineFastState.compose env20280 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20280 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20281 : List Nat := [2,4,8,1,1,0,9,5,512,4,512,513,9,512,1,3,513,512,5,0,513,0,1,3,8,0,513,512,512,512,5,0,4,1,513,513]

theorem envBound20281 : H12AffineFastState.Bounded env20281 := by
  intro p hp
  have h : env20281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20280_20281 : H12AffineEnvironment.transform 4 1 env20280 = env20281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20280 == env20281) = true)

theorem identity20281 : scanCanonicalize (H12AffineFastState.compose env20281 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20282 : List Nat := [2,4,8,1,1,0,9,5,0,4,0,1,9,0,1,3,1,0,5,0,1,0,1,3,8,0,1,0,0,0,5,0,4,1,1,1]

theorem envBound20282 : H12AffineFastState.Bounded env20282 := by
  intro p hp
  have h : env20282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20281_20282 : H12AffineEnvironment.transform 8 0 env20281 = env20282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20281 == env20282) = true)

theorem identity20282 : scanCanonicalize (H12AffineFastState.compose env20282 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound20282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20283 : List Nat := [2,4,2,1,1,0,3,5,0,4,0,1,3,0,1,3,1,0,5,0,1,0,1,3,2,0,1,0,0,0,5,0,4,1,1,1]

theorem envBound20283 : H12AffineFastState.Bounded env20283 := by
  intro p hp
  have h : env20283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20282_20283 : H12AffineEnvironment.transform 2 2 env20282 = env20283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env20282 == env20283) = true)

def env20284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,98780,8328,64,43356,185600,17665,262144,181709,400588,257,21792,46213,254490]

theorem envBound20284 : H12AffineFastState.Bounded env20284 := by
  intro p hp
  have h : env20284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20259_20284 : H12AffineEnvironment.transform 21 272513 env20259 = env20284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env20259 == env20284) = true)

theorem identity20284 : scanCanonicalize (H12AffineFastState.compose env20284 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound20284 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,262144,1025,32769,58516,272513,62660,98780,8328,64,43356,57797,17665,262144,61704,272393,257,21792,46213,120543]

theorem envBound20285 : H12AffineFastState.Bounded env20285 := by
  intro p hp
  have h : env20285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20284_20285 : H12AffineEnvironment.transform 16 13509 env20284 = env20285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env20284 == env20285) = true)

def env20286 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13461,262144,1025,32769,58516,272513,62612,98700,8328,16,43276,57749,17665,262144,61704,272393,257,21792,46213,120463]

theorem envBound20286 : H12AffineFastState.Bounded env20286 := by
  intro p hp
  have h : env20286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20285_20286 : H12AffineEnvironment.transform 5 16 env20285 = env20286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20285 == env20286) = true)

theorem identity20286 : scanCanonicalize (H12AffineFastState.compose env20286 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound20286 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env20287 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8580,65536,13461,262144,1025,8581,17680,272513,21776,73736,8328,16,2184,16401,17665,262144,20620,272393,257,21792,5377,96011]

theorem envBound20287 : H12AffineFastState.Bounded env20287 := by
  intro p hp
  have h : env20287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20286_20287 : H12AffineEnvironment.transform 14 8580 env20286 = env20287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env20286 == env20287) = true)

theorem identity20287 : scanCanonicalize (H12AffineFastState.compose env20287 (packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20287 : packedSelected [4,5,7,8,9,11,18,19,23,24,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env20288 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,65536,13341,262144,1025,8461,17680,272393,21776,73736,8192,16,2048,16401,17665,262144,20484,272393,257,21792,5377,96011]

theorem envBound20288 : H12AffineFastState.Bounded env20288 := by
  intro p hp
  have h : env20288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20287_20288 : H12AffineEnvironment.transform 6 8 env20287 = env20288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20287 == env20288) = true)

theorem identity20288 : scanCanonicalize (H12AffineFastState.compose env20288 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound20288 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env20289 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,65536,13341,89379,1025,8461,17680,95530,21776,73736,8192,16,2048,16401,17665,89379,20484,95530,257,21792,5377,96011]

theorem envBound20289 : H12AffineFastState.Bounded env20289 := by
  intro p hp
  have h : env20289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20288_20289 : H12AffineEnvironment.transform 17 89379 env20288 = env20289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env20288 == env20289) = true)

theorem identity20289 : scanCanonicalize (H12AffineFastState.compose env20289 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound20289 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env20290 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,65536,13341,67619,1025,8461,4112,73770,16,73736,8192,16,2048,5393,4097,67619,1284,73770,257,32,5377,74251]

theorem envBound20290 : H12AffineFastState.Bounded env20290 := by
  intro p hp
  have h : env20290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20289_20290 : H12AffineEnvironment.transform 13 5376 env20289 = env20290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env20289 == env20290) = true)

theorem identity20290 : scanCanonicalize (H12AffineFastState.compose env20290 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound20290 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20291 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8495,13341,10508,1025,8461,4112,261,16,295,8192,16,2048,5393,4097,10508,1284,261,257,32,5377,804]

theorem envBound20291 : H12AffineFastState.Bounded env20291 := by
  intro p hp
  have h : env20291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20290_20291 : H12AffineEnvironment.transform 15 8495 env20290 = env20291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env20290 == env20291) = true)

theorem identity20291 : scanCanonicalize (H12AffineFastState.compose env20291 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound20291 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env20292 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,8192,3125,8460,8495,11560,10508,1025,8461,2341,261,16,295,8192,16,2048,3108,2356,10508,1284,261,257,32,3124,804]

theorem envBound20292 : H12AffineFastState.Bounded env20292 := by
  intro p hp
  have h : env20292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20291_20292 : H12AffineEnvironment.transform 11 2357 env20291 = env20292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env20291 == env20292) = true)

theorem identity20292 : scanCanonicalize (H12AffineFastState.compose env20292 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20292 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env20293 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,2357,269,3125,1,34,3109,2049,1025,0,2341,261,16,295,269,16,2048,3108,2356,2049,1284,261,257,32,3124,804]

theorem envBound20293 : H12AffineFastState.Bounded env20293 := by
  intro p hp
  have h : env20293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20292_20293 : H12AffineEnvironment.transform 12 269 env20292 = env20293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20292 == env20293) = true)

theorem identity20293 : scanCanonicalize (H12AffineFastState.compose env20293 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound20293 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env20294 : List Nat := [2,4,8,16,32,16,8,256,0,1024,2048,2357,269,3125,1,34,3109,2049,1025,0,2341,261,16,295,269,16,2048,3108,2356,2049,1284,261,257,32,3124,292]

theorem envBound20294 : H12AffineFastState.Bounded env20294 := by
  intro p hp
  have h : env20294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20293_20294 : H12AffineEnvironment.transform 8 0 env20293 = env20294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env20293 == env20294) = true)

theorem identity20294 : scanCanonicalize (H12AffineFastState.compose env20294 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 1061) := by decide +kernel

theorem selectedBound20294 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env20295 : List Nat := [2,4,8,16,32,16,8,256,0,1024,1061,1296,269,16,1,34,0,1060,1025,0,1280,261,16,295,269,16,1061,1,1297,1060,1284,261,257,32,17,292]

theorem envBound20295 : H12AffineFastState.Bounded env20295 := by
  intro p hp
  have h : env20295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20294_20295 : H12AffineEnvironment.transform 10 1061 env20294 = env20295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1061 env20294 == env20295) = true)

theorem identity20295 : scanCanonicalize (H12AffineFastState.compose env20295 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20295 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env20296 : List Nat := [2,4,8,16,32,16,8,256,0,272,309,0,269,16,1,34,0,308,273,0,16,261,16,295,269,16,309,1,1,308,20,261,257,32,17,292]

theorem envBound20296 : H12AffineFastState.Bounded env20296 := by
  intro p hp
  have h : env20296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20295_20296 : H12AffineEnvironment.transform 9 272 env20295 = env20296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20295 == env20296) = true)

theorem identity20296 : scanCanonicalize (H12AffineFastState.compose env20296 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound20296 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20297 : List Nat := [2,4,8,16,32,16,8,53,0,37,0,0,56,16,1,34,0,1,36,0,16,48,16,18,56,16,0,1,1,1,20,48,52,32,17,17]

theorem envBound20297 : H12AffineFastState.Bounded env20297 := by
  intro p hp
  have h : env20297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20296_20297 : H12AffineEnvironment.transform 7 53 env20296 = env20297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env20296 == env20297) = true)

theorem identity20297 : scanCanonicalize (H12AffineFastState.compose env20297 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20297 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20298 : List Nat := [2,4,8,1,32,1,8,36,0,37,0,0,41,1,1,34,0,1,36,0,1,33,1,3,41,1,0,1,1,1,5,33,37,32,0,0]

theorem envBound20298 : H12AffineFastState.Bounded env20298 := by
  intro p hp
  have h : env20298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20297_20298 : H12AffineEnvironment.transform 3 1 env20297 = env20298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20297 == env20298) = true)

theorem identity20298 : scanCanonicalize (H12AffineFastState.compose env20298 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound20298 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20299 : List Nat := [2,4,7,1,32,1,7,36,0,37,0,0,38,1,1,34,0,1,36,0,1,33,1,3,38,1,0,1,1,1,5,33,37,32,0,0]

theorem envBound20299 : H12AffineFastState.Bounded env20299 := by
  intro p hp
  have h : env20299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20298_20299 : H12AffineEnvironment.transform 2 7 env20298 = env20299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env20298 == env20299) = true)

theorem identity20299 : scanCanonicalize (H12AffineFastState.compose env20299 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20299 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20300 : List Nat := [2,4,7,1,0,1,7,4,0,5,0,0,6,1,1,2,0,1,4,0,1,1,1,3,6,1,0,1,1,1,5,1,5,0,0,0]

theorem envBound20300 : H12AffineFastState.Bounded env20300 := by
  intro p hp
  have h : env20300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20299_20300 : H12AffineEnvironment.transform 4 0 env20299 = env20300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20299 == env20300) = true)

def env20301 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,13460,262144,1025,32769,58516,272513,62613,98701,8328,17,43277,57748,17665,262144,61704,272393,257,21792,46213,120462]

theorem envBound20301 : H12AffineFastState.Bounded env20301 := by
  intro p hp
  have h : env20301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20285_20301 : H12AffineEnvironment.transform 5 17 env20285 = env20301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20285 == env20301) = true)

theorem identity20301 : scanCanonicalize (H12AffineFastState.compose env20301 (packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20301 : packedSelected [3,10,12,15,16,17,18,20,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env20302 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,262144,1025,32769,45340,272513,41245,98701,8328,17,43277,46108,4233,262144,42112,272393,257,168,46213,99078]

theorem envBound20302 : H12AffineFastState.Bounded env20302 := by
  intro p hp
  have h : env20302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20301_20302 : H12AffineEnvironment.transform 13 5512 env20301 = env20302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20301 == env20302) = true)

theorem identity20302 : scanCanonicalize (H12AffineFastState.compose env20302 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound20302 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env20303 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,65536,13460,10281,1025,32769,45340,168,41245,98701,8328,17,43277,46108,4233,10281,42112,32,257,168,46213,99078]

theorem envBound20303 : H12AffineFastState.Bounded env20303 := by
  intro p hp
  have h : env20303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20302_20303 : H12AffineEnvironment.transform 17 10281 env20302 = env20303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env20302 == env20303) = true)

theorem identity20303 : scanCanonicalize (H12AffineFastState.compose env20303 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound20303 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20304 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,32768,33031,13460,10281,1025,32769,45340,168,41245,138,8328,17,43277,46108,4233,10281,42112,32,257,168,46213,513]

theorem envBound20304 : H12AffineFastState.Bounded env20304 := by
  intro p hp
  have h : env20304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20303_20304 : H12AffineEnvironment.transform 15 33031 env20303 = env20304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env20303 == env20304) = true)

theorem identity20304 : scanCanonicalize (H12AffineFastState.compose env20304 (packedSelected [2,3,4,5,6,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20304 : packedSelected [2,3,4,5,6,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env20305 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5512,0,263,13460,10281,1025,1,12572,168,8477,138,8328,17,10509,13340,4233,10281,9344,32,257,168,13445,513]

theorem envBound20305 : H12AffineFastState.Bounded env20305 := by
  intro p hp
  have h : env20305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20304_20305 : H12AffineEnvironment.transform 14 0 env20304 = env20305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20304 == env20305) = true)

theorem identity20305 : scanCanonicalize (H12AffineFastState.compose env20305 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound20305 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20306 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5512,0,263,5392,2477,1025,1,4248,168,153,138,268,17,2185,5528,4233,2477,1284,32,257,168,5377,513]

theorem envBound20306 : H12AffineFastState.Bounded env20306 := by
  intro p hp
  have h : env20306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20305_20306 : H12AffineEnvironment.transform 12 388 env20305 = env20306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env20305 == env20306) = true)

theorem identity20306 : scanCanonicalize (H12AffineFastState.compose env20306 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 695) := by decide +kernel

theorem selectedBound20306 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env20307 : List Nat := [2,4,8,16,32,17,128,256,512,695,2048,4096,388,4927,0,263,5031,2477,694,1,4248,168,153,138,268,17,2185,4911,4233,2477,947,32,257,168,5046,513]

theorem envBound20307 : H12AffineFastState.Bounded env20307 := by
  intro p hp
  have h : env20307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20306_20307 : H12AffineEnvironment.transform 9 695 env20306 = env20307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 695 env20306 == env20307) = true)

theorem identity20307 : scanCanonicalize (H12AffineFastState.compose env20307 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20307 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20308 : List Nat := [2,4,8,16,32,17,8,256,512,575,2048,4096,268,4927,0,263,4911,2341,574,1,4112,32,17,2,268,17,2049,4911,4097,2341,827,32,257,32,4926,513]

theorem envBound20308 : H12AffineFastState.Bounded env20308 := by
  intro p hp
  have h : env20308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20307_20308 : H12AffineEnvironment.transform 6 8 env20307 = env20308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20307 == env20308) = true)

theorem identity20308 : scanCanonicalize (H12AffineFastState.compose env20308 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound20308 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20309 : List Nat := [2,4,8,16,32,17,8,256,270,305,2048,4096,268,4145,0,263,4129,2341,304,1,4112,32,17,2,268,17,2049,4129,4097,2341,53,32,257,32,4144,271]

theorem envBound20309 : H12AffineFastState.Bounded env20309 := by
  intro p hp
  have h : env20309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20308_20309 : H12AffineEnvironment.transform 8 270 env20308 = env20309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env20308 == env20309) = true)

theorem identity20309 : scanCanonicalize (H12AffineFastState.compose env20309 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound20309 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20310 : List Nat := [2,4,8,16,32,17,8,256,270,305,2048,2325,268,2340,0,263,2356,2341,304,1,2309,32,17,2,268,17,2049,2356,2324,2341,53,32,257,32,2341,271]

theorem envBound20310 : H12AffineFastState.Bounded env20310 := by
  intro p hp
  have h : env20310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20309_20310 : H12AffineEnvironment.transform 11 2325 env20309 = env20310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env20309 == env20310) = true)

theorem identity20310 : scanCanonicalize (H12AffineFastState.compose env20310 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound20310 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20311 : List Nat := [2,4,8,16,11,17,8,256,270,282,2048,2325,268,2319,0,263,2335,2318,283,1,2309,11,17,2,268,17,2049,2335,2324,2318,30,11,257,11,2318,271]

theorem envBound20311 : H12AffineFastState.Bounded env20311 := by
  intro p hp
  have h : env20311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20310_20311 : H12AffineEnvironment.transform 4 11 env20310 = env20311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env20310 == env20311) = true)

theorem identity20311 : scanCanonicalize (H12AffineFastState.compose env20311 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound20311 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20312 : List Nat := [2,4,8,16,11,17,8,21,27,15,2048,2048,25,2074,0,18,2058,2075,14,1,2064,11,17,2,25,17,2049,2058,2049,2075,30,11,20,11,2075,26]

theorem envBound20312 : H12AffineFastState.Bounded env20312 := by
  intro p hp
  have h : env20312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20311_20312 : H12AffineEnvironment.transform 7 21 env20311 = env20312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env20311 == env20312) = true)

theorem identity20312 : scanCanonicalize (H12AffineFastState.compose env20312 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound20312 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20313 : List Nat := [2,4,8,9,11,8,8,12,2,15,2048,2048,0,2051,0,11,2058,2050,14,1,2057,11,8,2,0,8,2049,2058,2049,2050,7,11,13,11,2050,3]

theorem envBound20313 : H12AffineFastState.Bounded env20313 := by
  intro p hp
  have h : env20313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20312_20313 : H12AffineEnvironment.transform 3 9 env20312 = env20313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env20312 == env20313) = true)

theorem identity20313 : scanCanonicalize (H12AffineFastState.compose env20313 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound20313 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20314 : List Nat := [2,4,8,9,11,8,8,12,2,15,10,10,0,9,0,11,0,8,14,1,3,11,8,2,0,8,11,0,11,8,7,11,13,11,8,3]

theorem envBound20314 : H12AffineFastState.Bounded env20314 := by
  intro p hp
  have h : env20314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20313_20314 : H12AffineEnvironment.transform 10 10 env20313 = env20314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env20313 == env20314) = true)

theorem identity20314 : scanCanonicalize (H12AffineFastState.compose env20314 (packedSelected [0,9] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound20314 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env20315 : List Nat := [2,4,0,1,3,0,0,4,2,7,2,2,0,1,0,3,0,0,6,1,3,3,0,2,0,0,3,0,3,0,7,3,5,3,0,3]

theorem envBound20315 : H12AffineFastState.Bounded env20315 := by
  intro p hp
  have h : env20315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20314_20315 : H12AffineEnvironment.transform 2 0 env20314 = env20315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env20314 == env20315) = true)

theorem identity20315 : scanCanonicalize (H12AffineFastState.compose env20315 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound20315 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20316 : List Nat := [2,0,0,1,3,0,0,0,2,3,2,2,0,1,0,3,0,0,2,1,3,3,0,2,0,0,3,0,3,0,3,3,1,3,0,3]

theorem envBound20316 : H12AffineFastState.Bounded env20316 := by
  intro p hp
  have h : env20316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20315_20316 : H12AffineEnvironment.transform 1 0 env20315 = env20316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env20315 == env20316) = true)

def env20317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265169,145662401,525568,140903596,27337993,25733062]

theorem envBound20317 : H12AffineFastState.Bounded env20317 := by
  intro p hp
  have h : env20317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19669_20317 : H12AffineEnvironment.transform 25 65 env19669 = env20317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env19669 == env20317) = true)

def env20318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound20318 : H12AffineFastState.Bounded env20318 := by
  intro p hp
  have h : env20318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20317_20318 : H12AffineEnvironment.transform 26 30393344 env20317 = env20318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env20317 == env20318) = true)

def env20319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound20319 : H12AffineFastState.Bounded env20319 := by
  intro p hp
  have h : env20319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20318_20319 : H12AffineEnvironment.transform 18 1024 env20318 = env20319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env20318 == env20319) = true)

theorem identity20319 : scanCanonicalize (H12AffineFastState.compose env20319 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493629) := by decide +kernel

theorem selectedBound20319 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env20320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493629,16777216,8328,65,23186621,18973836,416237,2149564,19368108,23160257,256,17287185,17246644,19312507]

theorem envBound20320 : H12AffineFastState.Bounded env20320 := by
  intro p hp
  have h : env20320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20319_20320 : H12AffineEnvironment.transform 22 2493629 env20319 = env20320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493629 env20319 == env20320) = true)

def env20321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493629,498992,8328,65,6705549,2496956,416237,2149564,2102684,6748401,256,21793,46212,2175563]

theorem envBound20321 : H12AffineFastState.Bounded env20321 := by
  intro p hp
  have h : env20321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20320_20321 : H12AffineEnvironment.transform 23 498992 env20320 = env20321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env20320 == env20321) = true)

def env20322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493629,498992,8328,65,2396469,2496956,416237,2149564,2102684,2373705,256,21793,46212,2175563]

theorem envBound20322 : H12AffineFastState.Bounded env20322 := by
  intro p hp
  have h : env20322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20321_20322 : H12AffineEnvironment.transform 21 180408 env20321 = env20322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env20321 == env20322) = true)

def env20323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400637,498992,8328,65,295285,395772,416237,56572,1500,272393,256,21793,46212,74251]

theorem envBound20323 : H12AffineFastState.Bounded env20323 := by
  intro p hp
  have h : env20323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20322_20323 : H12AffineEnvironment.transform 20 4160 env20322 = env20323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20322 == env20323) = true)

def env20324 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,180408,144597,242968,8328,65,43357,139732,160197,56572,1500,33,256,21793,46212,74251]

theorem envBound20324 : H12AffineFastState.Bounded env20324 := by
  intro p hp
  have h : env20324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20323_20324 : H12AffineEnvironment.transform 17 10280 env20323 = env20324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env20323 == env20324) = true)

def env20325 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4160,21928,41413,73736,8328,65,43357,46276,58581,56572,1500,33,256,21793,46212,74251]

theorem envBound20325 : H12AffineFastState.Bounded env20325 := by
  intro p hp
  have h : env20325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20324_20325 : H12AffineEnvironment.transform 16 38160 env20324 = env20325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env20324 == env20325) = true)

theorem identity20325 : scanCanonicalize (H12AffineFastState.compose env20325 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound20325 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,38160,10280,1024,32769,4160,21928,41413,41310,8328,65,43357,46276,58581,56572,1500,33,256,21793,46212,41821]

theorem envBound20326 : H12AffineFastState.Bounded env20326 := by
  intro p hp
  have h : env20326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20325_20326 : H12AffineEnvironment.transform 15 33110 env20325 = env20326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env20325 == env20326) = true)

theorem identity20326 : scanCanonicalize (H12AffineFastState.compose env20326 (packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 9412) := by decide +kernel

theorem selectedBound20326 : packedSelected [0,1,3,4,7,8,10,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env20327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9412,9618,12756,10280,1024,9413,4160,21928,1281,1434,8328,65,3481,4096,16401,30776,1500,33,256,21793,4160,1945]

theorem envBound20327 : H12AffineFastState.Bounded env20327 := by
  intro p hp
  have h : env20327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20326_20327 : H12AffineEnvironment.transform 14 9412 env20326 = env20327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9412 env20326 == env20327) = true)

theorem identity20327 : scanCanonicalize (H12AffineFastState.compose env20327 (packedSelected [0,1,2,3,4,5,6,9,11,16,18,19,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound20327 : packedSelected [0,1,2,3,4,5,6,9,11,16,18,19,27,28] rootPS < 2^1333 := by decide +kernel

def env20328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,16384,293,115,5173,3529,1024,292,4160,21928,1281,1434,1385,65,3481,4096,16401,24025,1500,33,256,21793,4160,1945]

theorem envBound20328 : H12AffineFastState.Bounded env20328 := by
  intro p hp
  have h : env20328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20327_20328 : H12AffineEnvironment.transform 12 1505 env20327 = env20328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env20327 == env20328) = true)

theorem identity20328 : scanCanonicalize (H12AffineFastState.compose env20328 (packedSelected [0,2,3,4,6,7,9,10,12,14,15,19,24] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound20328 : packedSelected [0,2,3,4,6,7,9,10,12,14,15,19,24] rootPS < 2^1333 := by decide +kernel

def env20329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,5593,293,115,5173,3529,1024,292,4160,113,1281,1434,1385,65,3481,4096,5576,2048,1500,33,256,248,4160,1945]

theorem envBound20329 : H12AffineFastState.Bounded env20329 := by
  intro p hp
  have h : env20329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20328_20329 : H12AffineEnvironment.transform 13 5593 env20328 = env20329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env20328 == env20329) = true)

theorem identity20329 : scanCanonicalize (H12AffineFastState.compose env20329 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 457) := by decide +kernel

theorem selectedBound20329 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20330 : List Nat := [2,4,8,16,32,64,128,256,512,457,2048,4096,40,4112,293,115,4604,2048,457,292,4160,113,200,83,160,65,2128,4096,4097,2048,21,33,256,248,4160,592]

theorem envBound20330 : H12AffineFastState.Bounded env20330 := by
  intro p hp
  have h : env20330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20329_20330 : H12AffineEnvironment.transform 9 457 env20329 = env20330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 457 env20329 == env20330) = true)

theorem identity20330 : scanCanonicalize (H12AffineFastState.compose env20330 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound20330 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env20331 : List Nat := [2,4,8,16,32,64,128,252,512,53,2048,4096,40,4112,217,115,4096,2048,53,216,4160,113,200,83,160,65,2128,4096,4097,2048,21,33,252,248,4160,592]

theorem envBound20331 : H12AffineFastState.Bounded env20331 := by
  intro p hp
  have h : env20331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20330_20331 : H12AffineEnvironment.transform 7 252 env20330 = env20331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env20330 == env20331) = true)

theorem identity20331 : scanCanonicalize (H12AffineFastState.compose env20331 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2178) := by decide +kernel

theorem selectedBound20331 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env20332 : List Nat := [2,4,8,16,32,64,128,252,512,53,2048,2178,40,2194,217,115,2178,2048,53,216,2242,113,200,83,160,65,2128,2178,2179,2048,21,33,252,248,2242,592]

theorem envBound20332 : H12AffineFastState.Bounded env20332 := by
  intro p hp
  have h : env20332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20331_20332 : H12AffineEnvironment.transform 11 2178 env20331 = env20332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2178 env20331 == env20332) = true)

theorem identity20332 : scanCanonicalize (H12AffineFastState.compose env20332 (packedSelected [1,3,4,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20332 : packedSelected [1,3,4,7,10] rootPS < 2^1333 := by decide +kernel

def env20333 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,2058,40,2074,81,115,2058,2048,53,80,2122,113,64,83,40,65,2128,2058,2059,2048,21,33,116,112,2122,592]

theorem envBound20333 : H12AffineFastState.Bounded env20333 := by
  intro p hp
  have h : env20333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20332_20333 : H12AffineEnvironment.transform 6 8 env20332 = env20333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20332 == env20333) = true)

theorem identity20333 : scanCanonicalize (H12AffineFastState.compose env20333 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound20333 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env20334 : List Nat := [2,4,8,16,32,64,8,116,512,53,555,545,40,561,81,115,545,555,53,80,609,113,64,83,40,65,635,545,544,555,21,33,116,112,609,592]

theorem envBound20334 : H12AffineFastState.Bounded env20334 := by
  intro p hp
  have h : env20334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20333_20334 : H12AffineEnvironment.transform 10 555 env20333 = env20334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env20333 == env20334) = true)

theorem identity20334 : scanCanonicalize (H12AffineFastState.compose env20334 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound20334 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20335 : List Nat := [2,4,8,16,32,64,8,116,14,53,37,47,40,63,81,115,47,37,53,80,111,113,64,83,40,65,117,47,46,37,21,33,116,112,111,94]

theorem envBound20335 : H12AffineFastState.Bounded env20335 := by
  intro p hp
  have h : env20335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20334_20335 : H12AffineEnvironment.transform 8 14 env20334 = env20335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env20334 == env20335) = true)

theorem identity20335 : scanCanonicalize (H12AffineFastState.compose env20335 (packedSelected [1,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 5) := by decide +kernel

theorem selectedBound20335 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env20336 : List Nat := [2,4,8,16,32,5,8,49,14,53,37,47,40,63,20,54,47,37,53,21,42,52,5,22,40,4,48,47,46,37,21,33,49,53,42,27]

theorem envBound20336 : H12AffineFastState.Bounded env20336 := by
  intro p hp
  have h : env20336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20335_20336 : H12AffineEnvironment.transform 5 5 env20335 = env20336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 5 env20335 == env20336) = true)

theorem identity20336 : scanCanonicalize (H12AffineFastState.compose env20336 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 13) := by decide +kernel

theorem selectedBound20336 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env20337 : List Nat := [2,4,8,16,13,5,8,28,14,24,8,2,5,18,20,27,2,8,24,21,7,25,5,22,5,4,29,2,3,8,21,12,28,24,7,27]

theorem envBound20337 : H12AffineFastState.Bounded env20337 := by
  intro p hp
  have h : env20337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20336_20337 : H12AffineEnvironment.transform 4 13 env20336 = env20337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env20336 == env20337) = true)

def env20338 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4160,21929,41412,73737,8328,65,43357,46277,58580,56572,1500,33,256,21793,46212,74251]

theorem envBound20338 : H12AffineFastState.Bounded env20338 := by
  intro p hp
  have h : env20338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20324_20338 : H12AffineEnvironment.transform 16 38161 env20324 = env20338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env20324 == env20338) = true)

theorem identity20338 : scanCanonicalize (H12AffineFastState.compose env20338 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound20338 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20339 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,38161,10280,1024,32769,4160,21929,41412,41430,8328,65,43357,46277,58580,56572,1500,33,256,21793,46212,41940]

theorem envBound20339 : H12AffineFastState.Bounded env20339 := by
  intro p hp
  have h : env20339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20338_20339 : H12AffineEnvironment.transform 15 33247 env20338 = env20339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env20338 == env20339) = true)

theorem identity20339 : scanCanonicalize (H12AffineFastState.compose env20339 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound20339 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env20340 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32803,38125,10280,1024,32769,4160,21589,41016,41002,8328,65,43169,46277,58580,56572,1056,33,252,21725,46212,41512]

theorem envBound20340 : H12AffineFastState.Bounded env20340 := by
  intro p hp
  have h : env20340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20339_20340 : H12AffineEnvironment.transform 7 252 env20339 = env20340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env20339 == env20340) = true)

theorem identity20340 : scanCanonicalize (H12AffineFastState.compose env20340 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 12345) := by decide +kernel

theorem selectedBound20340 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env20341 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,12345,32768,32803,38125,10280,1024,32769,4160,9324,41016,41002,8328,65,43169,46277,38125,44229,1056,33,252,9444,46212,41512]

theorem envBound20341 : H12AffineFastState.Bounded env20341 := by
  intro p hp
  have h : env20341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20340_20341 : H12AffineEnvironment.transform 13 12345 env20340 = env20341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12345 env20340 == env20341) = true)

theorem identity20341 : scanCanonicalize (H12AffineFastState.compose env20341 (packedSelected [3,10,12,15,18,19,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound20341 : packedSelected [3,10,12,15,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env20342 : List Nat := [2,4,8,16,32,64,128,252,512,189,2048,4096,8192,12345,32768,32803,36944,10280,189,32769,4160,8401,41016,41002,8328,65,43169,45176,36944,43128,157,33,252,8281,45113,41512]

theorem envBound20342 : H12AffineFastState.Bounded env20342 := by
  intro p hp
  have h : env20342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20341_20342 : H12AffineEnvironment.transform 9 189 env20341 = env20342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env20341 == env20342) = true)

theorem identity20342 : scanCanonicalize (H12AffineFastState.compose env20342 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound20342 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env20343 : List Nat := [2,4,8,16,32,64,128,252,512,189,2048,4096,8192,12345,136,171,4312,10280,189,137,4160,8401,8368,8354,8328,65,10281,12528,4312,10480,157,33,252,8281,12465,8864]

theorem envBound20343 : H12AffineFastState.Bounded env20343 := by
  intro p hp
  have h : env20343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20342_20343 : H12AffineEnvironment.transform 14 136 env20342 = env20343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env20342 == env20343) = true)

theorem identity20343 : scanCanonicalize (H12AffineFastState.compose env20343 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound20343 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20344 : List Nat := [2,4,8,16,32,64,128,252,512,189,2048,4096,160,4249,136,171,4312,2184,189,137,4160,113,16,2,40,65,2185,4176,4312,2128,157,33,252,249,4113,512]

theorem envBound20344 : H12AffineFastState.Bounded env20344 := by
  intro p hp
  have h : env20344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20343_20344 : H12AffineEnvironment.transform 12 160 env20343 = env20344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env20343 == env20344) = true)

theorem identity20344 : scanCanonicalize (H12AffineFastState.compose env20344 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound20344 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20345 : List Nat := [2,4,8,16,32,64,40,84,512,21,2048,4096,8,4145,32,3,4208,2080,21,33,4160,113,16,2,40,65,2081,4176,4208,2128,53,33,84,81,4113,512]

theorem envBound20345 : H12AffineFastState.Bounded env20345 := by
  intro p hp
  have h : env20345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20344_20345 : H12AffineEnvironment.transform 6 40 env20344 = env20345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env20344 == env20345) = true)

theorem identity20345 : scanCanonicalize (H12AffineFastState.compose env20345 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20345 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20346 : List Nat := [2,4,8,16,32,17,40,5,512,21,2048,4096,8,4145,32,3,4129,2080,21,33,4113,32,16,2,40,16,2081,4097,4129,2049,53,33,5,0,4113,512]

theorem envBound20346 : H12AffineFastState.Bounded env20346 := by
  intro p hp
  have h : env20346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20345_20346 : H12AffineEnvironment.transform 5 17 env20345 = env20346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20345 == env20346) = true)

def env20347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,180408,144596,242969,8328,65,43356,139733,160196,56572,1500,32,256,21793,46212,74251]

theorem envBound20347 : H12AffineFastState.Bounded env20347 := by
  intro p hp
  have h : env20347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20323_20347 : H12AffineEnvironment.transform 17 10281 env20323 = env20347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env20323 == env20347) = true)

def env20348 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4160,21928,41412,73737,8328,65,43356,46277,58580,56572,1500,32,256,21793,46212,74251]

theorem envBound20348 : H12AffineFastState.Bounded env20348 := by
  intro p hp
  have h : env20348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20347_20348 : H12AffineEnvironment.transform 16 38160 env20347 = env20348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env20347 == env20348) = true)

theorem identity20348 : scanCanonicalize (H12AffineFastState.compose env20348 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20348 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1024,32769,4160,21928,41412,3,8328,65,43356,46277,58580,56572,1500,32,256,21793,46212,513]

theorem envBound20349 : H12AffineFastState.Bounded env20349 := by
  intro p hp
  have h : env20349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20348_20349 : H12AffineEnvironment.transform 15 8202 env20348 = env20349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20348 == env20349) = true)

theorem identity20349 : scanCanonicalize (H12AffineFastState.compose env20349 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound20349 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env20350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8202,38160,10281,1024,32769,4160,32,41412,3,8328,65,43356,46277,45404,35188,1500,32,256,169,46212,513]

theorem envBound20350 : H12AffineFastState.Bounded env20350 := by
  intro p hp
  have h : env20350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20349_20350 : H12AffineEnvironment.transform 13 5512 env20349 = env20350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env20349 == env20350) = true)

theorem identity20350 : scanCanonicalize (H12AffineFastState.compose env20350 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound20350 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env20351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,32768,479,38160,2556,1024,32769,4160,32,32785,3,349,65,34953,38160,37001,35188,1500,32,256,169,38225,513]

theorem envBound20351 : H12AffineFastState.Bounded env20351 := by
  intro p hp
  have h : env20351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20350_20351 : H12AffineEnvironment.transform 12 469 env20350 = env20351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env20350 == env20351) = true)

theorem identity20351 : scanCanonicalize (H12AffineFastState.compose env20351 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound20351 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5512,137,479,5529,2556,1024,136,4160,32,152,3,349,65,2048,5529,4096,2557,1500,32,256,169,5592,513]

theorem envBound20352 : H12AffineFastState.Bounded env20352 := by
  intro p hp
  have h : env20352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20351_20352 : H12AffineEnvironment.transform 14 137 env20351 = env20352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env20351 == env20352) = true)

theorem identity20352 : scanCanonicalize (H12AffineFastState.compose env20352 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound20352 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env20353 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,342,5392,2421,1024,1,4160,32,17,3,349,65,2048,5392,4096,2420,1365,32,256,32,5457,513]

theorem envBound20353 : H12AffineFastState.Bounded env20353 := by
  intro p hp
  have h : env20353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20352_20353 : H12AffineEnvironment.transform 6 9 env20352 = env20353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20352 == env20353) = true)

theorem identity20353 : scanCanonicalize (H12AffineFastState.compose env20353 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1793) := by decide +kernel

theorem selectedBound20353 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20354 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1793,348,512,0,342,529,2421,1024,1,1857,32,17,3,349,65,2048,529,1793,2420,1365,32,256,32,592,513]

theorem envBound20354 : H12AffineFastState.Bounded env20354 := by
  intro p hp
  have h : env20354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20353_20354 : H12AffineEnvironment.transform 11 1793 env20353 = env20354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1793 env20353 == env20354) = true)

theorem identity20354 : scanCanonicalize (H12AffineFastState.compose env20354 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20354 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20355 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1793,269,512,0,263,529,2340,1024,1,1808,32,17,3,268,16,2048,529,1793,2341,1284,32,256,32,513,513]

theorem envBound20355 : H12AffineFastState.Bounded env20355 := by
  intro p hp
  have h : env20355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20354_20355 : H12AffineEnvironment.transform 5 17 env20354 = env20355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20354 == env20355) = true)

theorem identity20355 : scanCanonicalize (H12AffineFastState.compose env20355 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound20355 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20356 : List Nat := [2,4,8,16,32,17,9,256,512,288,2048,545,269,512,0,263,529,2340,288,1,560,32,17,3,268,16,2048,529,545,2341,36,32,256,32,513,513]

theorem envBound20356 : H12AffineFastState.Bounded env20356 := by
  intro p hp
  have h : env20356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20355_20356 : H12AffineEnvironment.transform 9 288 env20355 = env20356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env20355 == env20356) = true)

theorem identity20356 : scanCanonicalize (H12AffineFastState.compose env20356 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound20356 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20357 : List Nat := [2,4,8,16,32,17,9,256,512,288,49,545,269,512,0,263,529,277,288,1,560,32,17,3,268,16,49,529,545,276,36,32,256,32,513,513]

theorem envBound20357 : H12AffineFastState.Bounded env20357 := by
  intro p hp
  have h : env20357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20356_20357 : H12AffineEnvironment.transform 10 49 env20356 = env20357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env20356 == env20357) = true)

theorem identity20357 : scanCanonicalize (H12AffineFastState.compose env20357 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound20357 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20358 : List Nat := [2,4,8,16,32,17,9,256,16,288,49,49,269,16,0,263,1,277,288,1,32,32,17,3,268,16,49,1,49,276,36,32,256,32,17,17]

theorem envBound20358 : H12AffineFastState.Bounded env20358 := by
  intro p hp
  have h : env20358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20357_20358 : H12AffineEnvironment.transform 8 16 env20357 = env20358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env20357 == env20358) = true)

theorem identity20358 : scanCanonicalize (H12AffineFastState.compose env20358 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound20358 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20359 : List Nat := [2,4,8,16,32,17,9,21,16,53,49,49,24,16,0,18,1,0,53,1,32,32,17,3,25,16,49,1,49,1,36,32,21,32,17,17]

theorem envBound20359 : H12AffineFastState.Bounded env20359 := by
  intro p hp
  have h : env20359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20358_20359 : H12AffineEnvironment.transform 7 21 env20358 = env20359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env20358 == env20359) = true)

theorem identity20359 : scanCanonicalize (H12AffineFastState.compose env20359 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound20359 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20360 : List Nat := [2,4,8,0,32,1,9,5,0,37,33,33,8,0,0,2,1,0,37,1,32,32,1,3,9,0,33,1,33,1,36,32,5,32,1,1]

theorem envBound20360 : H12AffineFastState.Bounded env20360 := by
  intro p hp
  have h : env20360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20359_20360 : H12AffineEnvironment.transform 3 0 env20359 = env20360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env20359 == env20360) = true)

def env20361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4160,21929,41413,73736,8328,65,43356,46276,58581,56572,1500,32,256,21793,46212,74251]

theorem envBound20361 : H12AffineFastState.Bounded env20361 := by
  intro p hp
  have h : env20361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20347_20361 : H12AffineEnvironment.transform 16 38161 env20347 = env20361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env20347 == env20361) = true)

theorem identity20361 : scanCanonicalize (H12AffineFastState.compose env20361 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound20361 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38161,10281,1024,32769,4160,21929,41413,138,8328,65,43356,46276,58581,56572,1500,32,256,21793,46212,649]

theorem envBound20362 : H12AffineFastState.Bounded env20362 := by
  intro p hp
  have h : env20362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20361_20362 : H12AffineEnvironment.transform 15 8322 env20361 = env20362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env20361 == env20362) = true)

theorem identity20362 : scanCanonicalize (H12AffineFastState.compose env20362 (packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound20362 : packedSelected [0,1,2,6,7,8,10,11,12,18,20] rootPS < 2^1333 := by decide +kernel

def env20363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29828,8322,24981,10281,1024,29829,4160,21929,21825,138,8328,65,24024,16448,4177,10360,1500,32,256,21793,16384,649]

theorem envBound20363 : H12AffineFastState.Bounded env20363 := by
  intro p hp
  have h : env20363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20362_20363 : H12AffineEnvironment.transform 14 29828 env20362 = env20363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env20362 == env20363) = true)

theorem identity20363 : scanCanonicalize (H12AffineFastState.compose env20363 (packedSelected [10,11,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound20363 : packedSelected [10,11,15,18,19] rootPS < 2^1333 := by decide +kernel

def env20364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21760,262,16401,2477,1024,21761,4160,21929,21825,138,268,65,24024,16448,4177,2556,1500,32,256,21793,16384,649]

theorem envBound20364 : H12AffineFastState.Bounded env20364 := by
  intro p hp
  have h : env20364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20363_20364 : H12AffineEnvironment.transform 12 388 env20363 = env20364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env20363 == env20364) = true)

theorem identity20364 : scanCanonicalize (H12AffineFastState.compose env20364 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20364 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20365 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,21760,262,16401,2477,1024,21761,4112,21929,21777,138,268,17,23944,16400,4097,2476,1420,32,256,21793,16384,649]

theorem envBound20365 : H12AffineFastState.Bounded env20365 := by
  intro p hp
  have h : env20365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20364_20365 : H12AffineEnvironment.transform 5 16 env20364 = env20365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20364 == env20365) = true)

theorem identity20365 : scanCanonicalize (H12AffineFastState.compose env20365 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound20365 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env20366 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,137,262,5528,2477,1024,136,4112,32,152,138,268,17,2049,5529,4097,2476,1420,32,256,168,5513,649]

theorem envBound20366 : H12AffineFastState.Bounded env20366 := by
  intro p hp
  have h : env20366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20365_20366 : H12AffineEnvironment.transform 13 5513 env20365 = env20366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env20365 == env20366) = true)

def env20367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400636,498992,8328,65,295284,395773,416237,56573,1501,272392,256,21793,46212,74250]

theorem envBound20367 : H12AffineFastState.Bounded env20367 := by
  intro p hp
  have h : env20367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20322_20367 : H12AffineEnvironment.transform 20 4161 env20322 = env20367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20322 == env20367) = true)

theorem identity20367 : scanCanonicalize (H12AffineFastState.compose env20367 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound20367 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20368 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,180408,62660,95496,8328,65,158028,57797,45525,56573,1501,180272,256,21793,46212,74250]

theorem envBound20368 : H12AffineFastState.Bounded env20368 := by
  intro p hp
  have h : env20368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20367_20368 : H12AffineEnvironment.transform 17 190520 env20367 = env20368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env20367 == env20368) = true)

theorem identity20368 : scanCanonicalize (H12AffineFastState.compose env20368 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20368 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env20369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4161,180408,62660,21763,8328,65,158028,57797,45525,56573,1501,180272,256,21793,46212,513]

theorem envBound20369 : H12AffineFastState.Bounded env20369 := by
  intro p hp
  have h : env20369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20368_20369 : H12AffineEnvironment.transform 15 8203 env20368 = env20369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20368 == env20369) = true)

def env20370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493629,498992,8328,65,2396468,2496956,416237,2149564,2102684,2373704,256,21793,46212,2175563]

theorem envBound20370 : H12AffineFastState.Bounded env20370 := by
  intro p hp
  have h : env20370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20321_20370 : H12AffineEnvironment.transform 21 180409 env20321 = env20370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env20321 == env20370) = true)

def env20371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400637,498992,8328,65,295284,395772,416237,56572,1500,272392,256,21793,46212,74251]

theorem envBound20371 : H12AffineFastState.Bounded env20371 := by
  intro p hp
  have h : env20371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20370_20371 : H12AffineEnvironment.transform 20 4160 env20370 = env20371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20370 == env20371) = true)

theorem identity20371 : scanCanonicalize (H12AffineFastState.compose env20371 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound20371 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,4160,180409,16,98781,8328,65,171417,5393,17664,56572,1500,144613,256,21793,46212,74251]

theorem envBound20372 : H12AffineFastState.Bounded env20372 := by
  intro p hp
  have h : env20372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20371_20372 : H12AffineEnvironment.transform 17 138477 env20371 = env20372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env20371 == env20372) = true)

def env20373 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4160,180273,16,98645,8192,65,171281,5393,17664,56436,1364,144493,256,21793,46092,74251]

theorem envBound20373 : H12AffineFastState.Bounded env20373 := by
  intro p hp
  have h : env20373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20372_20373 : H12AffineEnvironment.transform 6 8 env20372 = env20373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20372 == env20373) = true)

theorem identity20373 : scanCanonicalize (H12AffineFastState.compose env20373 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound20373 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20374 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,67619,1024,32769,4160,119927,16,98645,8192,65,100695,5393,17664,56436,1364,73771,256,21793,46092,74251]

theorem envBound20374 : H12AffineFastState.Bounded env20374 := by
  intro p hp
  have h : env20374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20373_20374 : H12AffineEnvironment.transform 16 70726 env20373 = env20374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env20373 == env20374) = true)

theorem identity20374 : scanCanonicalize (H12AffineFastState.compose env20374 (packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound20374 : packedSelected [1,3,8,9,11,15,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env20375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,65536,70726,67619,1024,32769,4160,106538,16,98645,8192,65,100695,5393,12637,43049,1364,73771,256,8572,46092,74251]

theorem envBound20375 : H12AffineFastState.Bounded env20375 := by
  intro p hp
  have h : env20375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20374_20375 : H12AffineEnvironment.transform 13 13405 env20374 = env20375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env20374 == env20375) = true)

theorem identity20375 : scanCanonicalize (H12AffineFastState.compose env20375 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20375 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env20376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,65536,70726,67619,1024,32769,4160,98678,16,98645,348,65,100695,5393,4097,35189,1364,65911,256,32,38224,66391]

theorem envBound20376 : H12AffineFastState.Bounded env20376 := by
  intro p hp
  have h : env20376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20375_20376 : H12AffineEnvironment.transform 12 348 env20375 = env20376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20375 == env20376) = true)

theorem identity20376 : scanCanonicalize (H12AffineFastState.compose env20376 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20376 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env20377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,70726,67619,1024,0,4160,65911,16,65876,348,65,67926,5393,4097,2420,1364,65911,256,32,5457,66391]

theorem envBound20377 : H12AffineFastState.Bounded env20377 := by
  intro p hp
  have h : env20377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20376_20377 : H12AffineEnvironment.transform 14 1 env20376 = env20377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20376 == env20377) = true)

theorem identity20377 : scanCanonicalize (H12AffineFastState.compose env20377 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20377 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env20378 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,5377,1,65536,70726,67586,1024,0,4160,65878,16,65876,348,65,67926,5393,4097,2389,1364,65878,256,1,5457,66391]

theorem envBound20378 : H12AffineFastState.Bounded env20378 := by
  intro p hp
  have h : env20378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20377_20378 : H12AffineEnvironment.transform 4 1 env20377 = env20378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20377 == env20378) = true)

theorem identity20378 : scanCanonicalize (H12AffineFastState.compose env20378 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound20378 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env20379 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1093,4096,348,5377,1,65536,70726,66631,1024,0,4160,65878,16,65876,348,65,66835,5393,4097,1296,1364,65878,256,1,5457,66391]

theorem envBound20379 : H12AffineFastState.Bounded env20379 := by
  intro p hp
  have h : env20379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20378_20379 : H12AffineEnvironment.transform 10 1093 env20378 = env20379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env20378 == env20379) = true)

def env20380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,180272,16,98644,8193,65,171280,5393,17664,56437,1365,144492,256,21793,46093,74251]

theorem envBound20380 : H12AffineFastState.Bounded env20380 := by
  intro p hp
  have h : env20380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20372_20380 : H12AffineEnvironment.transform 6 9 env20372 = env20380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20372 == env20380) = true)

theorem identity20380 : scanCanonicalize (H12AffineFastState.compose env20380 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound20380 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20381 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111898,108926,1024,32769,4160,95530,16,98644,8193,65,75786,5393,17664,56437,1365,98678,256,21793,46093,74251]

theorem envBound20381 : H12AffineFastState.Bounded env20381 := by
  intro p hp
  have h : env20381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20380_20381 : H12AffineEnvironment.transform 16 111898 env20380 = env20381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env20380 == env20381) = true)

theorem identity20381 : scanCanonicalize (H12AffineFastState.compose env20381 (packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound20381 : packedSelected [0,3,4,7,18,22,23,24,26,31] rootPS < 2^1333 := by decide +kernel

def env20382 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,30043,49217,56357,1024,32769,4160,113,16,62479,8193,65,23889,5393,17664,56437,1365,62509,256,21793,46093,22352]

theorem envBound20382 : H12AffineFastState.Bounded env20382 := by
  intro p hp
  have h : env20382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20381_20382 : H12AffineEnvironment.transform 15 30043 env20381 = env20382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env20381 == env20382) = true)

theorem identity20382 : scanCanonicalize (H12AffineFastState.compose env20382 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound20382 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env20383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,21590,49217,56357,1024,32769,4160,113,16,54530,268,65,23889,5393,17664,56437,1365,54560,256,21793,38144,22352]

theorem envBound20383 : H12AffineFastState.Bounded env20383 := by
  intro p hp
  have h : env20383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20382_20383 : H12AffineEnvironment.transform 12 269 env20382 = env20383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env20382 == env20383) = true)

theorem identity20383 : scanCanonicalize (H12AffineFastState.compose env20383 (packedSelected [1,4,8,9,12,14,15,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound20383 : packedSelected [1,4,8,9,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env20384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,21540,21590,5221,2049,1024,21541,4160,113,16,294,268,65,23889,5393,17664,2129,1365,260,256,21793,16676,22352]

theorem envBound20384 : H12AffineFastState.Bounded env20384 := by
  intro p hp
  have h : env20384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20383_20384 : H12AffineEnvironment.transform 14 21540 env20383 = env20384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env20383 == env20384) = true)

theorem identity20384 : scanCanonicalize (H12AffineFastState.compose env20384 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound20384 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env20385 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,16384,21540,21590,5221,2049,1024,21541,4160,113,16,3,41,65,23668,5172,17445,2129,1136,33,37,21508,16385,22133]

theorem envBound20385 : H12AffineFastState.Bounded env20385 := by
  intro p hp
  have h : env20385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20384_20385 : H12AffineEnvironment.transform 7 37 env20384 = env20385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env20384 == env20385) = true)

theorem identity20385 : scanCanonicalize (H12AffineFastState.compose env20385 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound20385 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env20386 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5156,0,114,5221,2049,1024,1,4160,113,16,3,41,65,2128,5172,4097,2129,1136,33,37,32,5157,593]

theorem envBound20386 : H12AffineFastState.Bounded env20386 := by
  intro p hp
  have h : env20386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20385_20386 : H12AffineEnvironment.transform 13 5156 env20385 = env20386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env20385 == env20386) = true)

theorem identity20386 : scanCanonicalize (H12AffineFastState.compose env20386 (packedSelected [0,4,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20386 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env20387 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,0,35,5172,2049,1024,1,4113,32,16,3,41,16,2049,5172,4097,2048,1057,33,37,32,5157,512]

theorem envBound20387 : H12AffineFastState.Bounded env20387 := by
  intro p hp
  have h : env20387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20386_20387 : H12AffineEnvironment.transform 5 17 env20386 = env20387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20386 == env20387) = true)

theorem identity20387 : scanCanonicalize (H12AffineFastState.compose env20387 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound20387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20388 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8,5124,0,3,5140,2049,1024,1,4113,0,16,3,9,16,2049,5140,4097,2048,1025,1,5,0,5125,512]

theorem envBound20388 : H12AffineFastState.Bounded env20388 := by
  intro p hp
  have h : env20388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20387_20388 : H12AffineEnvironment.transform 4 0 env20387 = env20388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env20387 == env20388) = true)

theorem identity20388 : scanCanonicalize (H12AffineFastState.compose env20388 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound20388 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20389 : List Nat := [2,4,8,16,0,17,9,5,512,1024,523,4096,8,5124,0,3,5140,522,1024,1,4113,0,16,3,9,16,522,5140,4097,523,1025,1,5,0,5125,512]

theorem envBound20389 : H12AffineFastState.Bounded env20389 := by
  intro p hp
  have h : env20389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20388_20389 : H12AffineEnvironment.transform 10 523 env20388 = env20389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env20388 == env20389) = true)

def env20390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400636,498992,8328,65,295285,395773,416237,56573,1501,272393,256,21793,46212,74250]

theorem envBound20390 : H12AffineFastState.Bounded env20390 := by
  intro p hp
  have h : env20390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20370_20390 : H12AffineEnvironment.transform 20 4161 env20370 = env20390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20370 == env20390) = true)

theorem identity20390 : scanCanonicalize (H12AffineFastState.compose env20390 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound20390 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,144493,400636,485860,8328,65,292257,395773,416237,10281,1501,272393,256,21793,16464,74250]

theorem envBound20391 : H12AffineFastState.Bounded env20391 := by
  intro p hp
  have h : env20391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20390_20391 : H12AffineEnvironment.transform 14 29908 env20390 = env20391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env20390 == env20391) = true)

def env20392 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4161,144493,400500,485740,8192,65,292137,395637,416101,10281,1365,272393,256,21793,16464,74250]

theorem envBound20392 : H12AffineFastState.Bounded env20392 := by
  intro p hp
  have h : env20392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20391_20392 : H12AffineEnvironment.transform 6 8 env20391 = env20392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20391 == env20392) = true)

theorem identity20392 : scanCanonicalize (H12AffineFastState.compose env20392 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound20392 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env20393 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,5440,262144,1024,29789,4161,8493,264500,359468,8192,65,292137,269365,281637,10281,1365,272393,256,21793,16464,74250]

theorem envBound20393 : H12AffineFastState.Bounded env20393 := by
  intro p hp
  have h : env20393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20392_20393 : H12AffineEnvironment.transform 16 5440 env20392 = env20393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env20392 == env20393) = true)

theorem identity20393 : scanCanonicalize (H12AffineFastState.compose env20393 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound20393 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env20394 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,5440,262144,1024,29789,4161,8493,264500,272506,8192,65,292137,269365,281637,10281,1365,272393,256,21793,16464,30300]

theorem envBound20394 : H12AffineFastState.Bounded env20394 := by
  intro p hp
  have h : env20394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20393_20394 : H12AffineEnvironment.transform 15 21590 env20393 = env20394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env20393 == env20394) = true)

theorem identity20394 : scanCanonicalize (H12AffineFastState.compose env20394 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound20394 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env20395 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21590,5440,10360,1024,29789,4161,8493,8524,2,8192,65,23889,13389,25693,10281,1365,113,256,21793,16464,30300]

theorem envBound20395 : H12AffineFastState.Bounded env20395 := by
  intro p hp
  have h : env20395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20394_20395 : H12AffineEnvironment.transform 17 10360 env20394 = env20395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env20394 == env20395) = true)

theorem identity20395 : scanCanonicalize (H12AffineFastState.compose env20395 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound20395 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env20396 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,81,8283,5440,10360,1024,80,4161,8493,8524,2,8192,65,10588,13389,4176,10281,1365,113,256,8492,13405,593]

theorem envBound20396 : H12AffineFastState.Bounded env20396 := by
  intro p hp
  have h : env20396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20395_20396 : H12AffineEnvironment.transform 13 13325 env20395 = env20396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env20395 == env20396) = true)

theorem identity20396 : scanCanonicalize (H12AffineFastState.compose env20396 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound20396 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env20397 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,6428,3345,81,6471,5440,4452,1024,80,4161,6193,6224,2,6428,65,4160,3409,4176,4405,1365,113,256,6192,3393,593]

theorem envBound20397 : H12AffineFastState.Bounded env20397 := by
  intro p hp
  have h : env20397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20396_20397 : H12AffineEnvironment.transform 12 6428 env20396 = env20397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env20396 == env20397) = true)

theorem identity20397 : scanCanonicalize (H12AffineFastState.compose env20397 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound20397 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20398 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,5133,0,81,5206,5440,4452,1024,80,4161,5408,5441,2,5133,65,4160,64,4176,4405,1365,113,256,5409,80,593]

theorem envBound20398 : H12AffineFastState.Bounded env20398 := by
  intro p hp
  have h : env20398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20397_20398 : H12AffineEnvironment.transform 10 1297 env20397 = env20398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env20397 == env20398) = true)

theorem identity20398 : scanCanonicalize (H12AffineFastState.compose env20398 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound20398 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env20399 : List Nat := [2,4,8,16,32,64,8,256,512,272,1,4096,4381,0,81,4422,4176,4452,272,80,4161,4144,4177,2,4381,65,4160,64,4176,4405,69,113,256,4145,80,593]

theorem envBound20399 : H12AffineFastState.Bounded env20399 := by
  intro p hp
  have h : env20399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20398_20399 : H12AffineEnvironment.transform 9 272 env20398 = env20399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env20398 == env20399) = true)

theorem identity20399 : scanCanonicalize (H12AffineFastState.compose env20399 (packedSelected [12,17] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound20399 : packedSelected [12,17] rootPS < 2^1333 := by decide +kernel

def env20400 : List Nat := [2,4,8,16,32,64,8,256,512,272,1,64,349,0,81,262,16,292,272,80,1,112,17,2,349,65,0,64,16,373,69,113,256,113,80,593]

theorem envBound20400 : H12AffineFastState.Bounded env20400 := by
  intro p hp
  have h : env20400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20399_20400 : H12AffineEnvironment.transform 11 64 env20399 = env20400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env20399 == env20400) = true)

theorem identity20400 : scanCanonicalize (H12AffineFastState.compose env20400 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20400 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env20401 : List Nat := [2,4,8,16,32,17,8,256,512,272,1,17,268,0,0,262,16,292,272,1,1,33,17,2,268,16,0,17,16,292,20,32,256,32,1,512]

theorem envBound20401 : H12AffineFastState.Bounded env20401 := by
  intro p hp
  have h : env20401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20400_20401 : H12AffineEnvironment.transform 5 17 env20400 = env20401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20400 == env20401) = true)

theorem identity20401 : scanCanonicalize (H12AffineFastState.compose env20401 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound20401 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20402 : List Nat := [2,4,8,16,32,17,8,53,512,37,1,17,57,0,0,51,16,17,37,1,1,33,17,2,57,16,0,17,16,17,20,32,53,32,1,512]

theorem envBound20402 : H12AffineFastState.Bounded env20402 := by
  intro p hp
  have h : env20402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20401_20402 : H12AffineEnvironment.transform 7 53 env20401 = env20402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env20401 == env20402) = true)

theorem identity20402 : scanCanonicalize (H12AffineFastState.compose env20402 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound20402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20403 : List Nat := [2,4,8,16,32,17,8,53,4,37,1,17,57,0,0,51,16,17,37,1,1,33,17,2,57,16,0,17,16,17,20,32,53,32,1,4]

theorem envBound20403 : H12AffineFastState.Bounded env20403 := by
  intro p hp
  have h : env20403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20402_20403 : H12AffineEnvironment.transform 8 4 env20402 = env20403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env20402 == env20403) = true)

theorem identity20403 : scanCanonicalize (H12AffineFastState.compose env20403 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound20403 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env20404 : List Nat := [2,4,8,16,4,17,8,17,4,1,1,17,29,0,0,23,16,17,1,1,1,5,17,2,29,16,0,17,16,17,20,4,17,4,1,4]

theorem envBound20404 : H12AffineFastState.Bounded env20404 := by
  intro p hp
  have h : env20404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20403_20404 : H12AffineEnvironment.transform 4 4 env20403 = env20404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env20403 == env20404) = true)

theorem identity20404 : scanCanonicalize (H12AffineFastState.compose env20404 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound20404 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env20405 : List Nat := [2,0,8,16,0,17,8,17,0,1,1,17,25,0,0,19,16,17,1,1,1,1,17,2,25,16,0,17,16,17,16,0,17,0,1,0]

theorem envBound20405 : H12AffineFastState.Bounded env20405 := by
  intro p hp
  have h : env20405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20404_20405 : H12AffineEnvironment.transform 1 0 env20404 = env20405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env20404 == env20405) = true)

theorem identity20405 : scanCanonicalize (H12AffineFastState.compose env20405 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound20405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20406 : List Nat := [2,0,8,1,0,0,8,0,0,1,1,0,8,0,0,2,1,0,1,1,1,1,0,2,8,1,0,0,1,0,1,0,0,0,1,0]

theorem envBound20406 : H12AffineFastState.Bounded env20406 := by
  intro p hp
  have h : env20406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20405_20406 : H12AffineEnvironment.transform 3 1 env20405 = env20406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env20405 == env20406) = true)

def env20407 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4161,144493,400501,485741,8193,65,292136,395636,416100,10281,1364,272393,256,21793,16464,74250]

theorem envBound20407 : H12AffineFastState.Bounded env20407 := by
  intro p hp
  have h : env20407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20391_20407 : H12AffineEnvironment.transform 6 9 env20391 = env20407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20391 == env20407) = true)

theorem identity20407 : scanCanonicalize (H12AffineFastState.compose env20407 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound20407 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env20408 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,79130,262144,1024,29788,4161,65911,338287,285815,8193,65,292136,343150,355454,10281,1364,272393,256,21793,16464,74250]

theorem envBound20408 : H12AffineFastState.Bounded env20408 := by
  intro p hp
  have h : env20408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20407_20408 : H12AffineEnvironment.transform 16 79130 env20407 = env20408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env20407 == env20408) = true)

theorem identity20408 : scanCanonicalize (H12AffineFastState.compose env20408 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound20408 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env20409 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,262144,1024,8541,4161,65911,338287,264566,8193,65,270377,343150,342399,10281,1364,272393,256,32,5457,74250]

theorem envBound20409 : H12AffineFastState.Bounded env20409 := by
  intro p hp
  have h : env20409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20408_20409 : H12AffineEnvironment.transform 13 5377 env20408 = env20409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env20408 == env20409) = true)

theorem identity20409 : scanCanonicalize (H12AffineFastState.compose env20409 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound20409 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env20410 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,65536,79130,2421,1024,8541,4161,65911,73754,3,8193,65,10588,79131,77834,10281,1364,8572,256,32,5457,74250]

theorem envBound20410 : H12AffineFastState.Bounded env20410 := by
  intro p hp
  have h : env20410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20409_20410 : H12AffineEnvironment.transform 17 2421 env20409 = env20410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env20409 == env20410) = true)

theorem identity20410 : scanCanonicalize (H12AffineFastState.compose env20410 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound20410 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env20411 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5393,2421,1024,8541,4161,8572,17,3,8193,65,10588,5392,4097,10281,1364,8572,256,32,5457,513]

theorem envBound20411 : H12AffineFastState.Bounded env20411 := by
  intro p hp
  have h : env20411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20410_20411 : H12AffineEnvironment.transform 15 8203 env20410 = env20411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env20410 == env20411) = true)

theorem identity20411 : scanCanonicalize (H12AffineFastState.compose env20411 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound20411 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20412 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,0,343,5393,2421,1024,1,4161,32,17,3,349,65,2048,5392,4097,2421,1364,32,256,32,5457,513]

theorem envBound20412 : H12AffineFastState.Bounded env20412 := by
  intro p hp
  have h : env20412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20411_20412 : H12AffineEnvironment.transform 12 348 env20411 = env20412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env20411 == env20412) = true)

theorem identity20412 : scanCanonicalize (H12AffineFastState.compose env20412 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound20412 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20413 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,348,4452,0,343,4468,2421,101,1,4161,32,17,3,349,65,2048,4469,4097,2421,305,32,256,32,4404,513]

theorem envBound20413 : H12AffineFastState.Bounded env20413 := by
  intro p hp
  have h : env20413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20412_20413 : H12AffineEnvironment.transform 9 101 env20412 = env20413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env20412 == env20413) = true)

theorem identity20413 : scanCanonicalize (H12AffineFastState.compose env20413 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20413 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env20414 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4405,0,262,4389,2340,52,1,4112,32,17,3,268,16,2048,4388,4097,2340,305,32,256,32,4404,513]

theorem envBound20414 : H12AffineFastState.Bounded env20414 := by
  intro p hp
  have h : env20414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20413_20414 : H12AffineEnvironment.transform 5 17 env20413 = env20414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20413 == env20414) = true)

theorem identity20414 : scanCanonicalize (H12AffineFastState.compose env20414 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound20414 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20415 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,16,269,293,0,262,309,2340,52,1,0,32,17,3,268,16,2048,308,17,2340,305,32,256,32,292,513]

theorem envBound20415 : H12AffineFastState.Bounded env20415 := by
  intro p hp
  have h : env20415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20414_20415 : H12AffineEnvironment.transform 11 16 env20414 = env20415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env20414 == env20415) = true)

theorem identity20415 : scanCanonicalize (H12AffineFastState.compose env20415 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound20415 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env20416 : List Nat := [2,4,8,16,32,17,9,256,512,52,292,16,269,293,0,262,309,0,52,1,0,32,17,3,268,16,292,308,17,0,305,32,256,32,292,513]

theorem envBound20416 : H12AffineFastState.Bounded env20416 := by
  intro p hp
  have h : env20416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20415_20416 : H12AffineEnvironment.transform 10 292 env20415 = env20416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env20415 == env20416) = true)

theorem identity20416 : scanCanonicalize (H12AffineFastState.compose env20416 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20416 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env20417 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,16,41,1,0,34,17,0,52,1,0,32,17,3,40,16,0,16,17,0,21,32,36,32,0,513]

theorem envBound20417 : H12AffineFastState.Bounded env20417 := by
  intro p hp
  have h : env20417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20416_20417 : H12AffineEnvironment.transform 7 36 env20416 = env20417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20416 == env20417) = true)

theorem identity20417 : scanCanonicalize (H12AffineFastState.compose env20417 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound20417 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20418 : List Nat := [2,4,8,16,32,17,9,36,32,52,0,16,41,1,0,34,17,0,52,1,0,32,17,3,40,16,0,16,17,0,21,32,36,32,0,33]

theorem envBound20418 : H12AffineFastState.Bounded env20418 := by
  intro p hp
  have h : env20418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20417_20418 : H12AffineEnvironment.transform 8 32 env20417 = env20418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env20417 == env20418) = true)

def env20419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493629,498993,8328,65,6705548,2496957,416237,2149564,2102685,6748400,256,21792,46213,2175562]

theorem envBound20419 : H12AffineFastState.Bounded env20419 := by
  intro p hp
  have h : env20419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20320_20419 : H12AffineEnvironment.transform 23 498993 env20320 = env20419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env20320 == env20419) = true)

def env20420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493629,498993,8328,65,2396468,2496957,416237,2149564,2102685,2373704,256,21792,46213,2175562]

theorem envBound20420 : H12AffineFastState.Bounded env20420 := by
  intro p hp
  have h : env20420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20419_20420 : H12AffineEnvironment.transform 21 180408 env20419 = env20420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env20419 == env20420) = true)

def env20421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400637,498993,8328,65,295284,395773,416237,56572,1501,272392,256,21792,46213,74250]

theorem envBound20421 : H12AffineFastState.Bounded env20421 := by
  intro p hp
  have h : env20421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20420_20421 : H12AffineEnvironment.transform 20 4160 env20420 = env20421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20420 == env20421) = true)

theorem identity20421 : scanCanonicalize (H12AffineFastState.compose env20421 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound20421 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180408,120014,21762,8328,65,215367,115150,102878,56572,1501,254011,256,21792,46213,74250]

theorem envBound20422 : H12AffineFastState.Bounded env20422 := by
  intro p hp
  have h : env20422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20421_20422 : H12AffineEnvironment.transform 17 247859 env20421 = env20422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env20421 == env20422) = true)

def env20423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130175,1024,32769,4160,62708,120014,21762,8328,65,97547,115150,102878,56572,1501,119927,256,21792,46213,74250]

theorem envBound20423 : H12AffineFastState.Bounded env20423 := by
  intro p hp
  have h : env20423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20422_20423 : H12AffineEnvironment.transform 16 13388 env20422 = env20423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env20422 == env20423) = true)

theorem identity20423 : scanCanonicalize (H12AffineFastState.compose env20423 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20423 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env20424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,13388,56437,1024,32769,4160,62708,62660,21762,8328,65,23809,57796,45524,56572,1501,62589,256,21792,46213,512]

theorem envBound20424 : H12AffineFastState.Bounded env20424 := by
  intro p hp
  have h : env20424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20423_20424 : H12AffineEnvironment.transform 15 8202 env20423 = env20424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20423 == env20424) = true)

theorem identity20424 : scanCanonicalize (H12AffineFastState.compose env20424 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound20424 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env20425 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,32768,8202,13388,56437,1024,32769,4160,62708,62660,21759,8328,65,23804,57401,45097,56572,1056,62589,253,21725,46213,512]

theorem envBound20425 : H12AffineFastState.Bounded env20425 := by
  intro p hp
  have h : env20425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20424_20425 : H12AffineEnvironment.transform 7 253 env20424 = env20425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env20424 == env20425) = true)

theorem identity20425 : scanCanonicalize (H12AffineFastState.compose env20425 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20425 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env20426 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,8202,13388,56437,1024,32769,4160,62588,62540,21623,8192,65,23668,57401,45097,56436,1056,62589,117,21589,46093,512]

theorem envBound20426 : H12AffineFastState.Bounded env20426 := by
  intro p hp
  have h : env20426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20425_20426 : H12AffineEnvironment.transform 6 8 env20425 = env20426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20425 == env20426) = true)

theorem identity20426 : scanCanonicalize (H12AffineFastState.compose env20426 (packedSelected [4,6,9,16] rootPS)) = affineNative (2^(13+1) ^^^ 12312) := by decide +kernel

theorem selectedBound20426 : packedSelected [4,6,9,16] rootPS < 2^1333 := by decide +kernel

def env20427 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,12312,32768,8202,13388,44141,1024,32769,4160,33892,33876,9327,8192,65,11372,36897,45097,44140,1056,33893,117,9293,46093,512]

theorem envBound20427 : H12AffineFastState.Bounded env20427 := by
  intro p hp
  have h : env20427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20426_20427 : H12AffineEnvironment.transform 13 12312 env20426 = env20427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12312 env20426 == env20427) = true)

def env20428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,130174,1024,32769,4160,62709,120014,21762,8328,65,97546,115150,102878,56572,1501,119926,256,21792,46213,74250]

theorem envBound20428 : H12AffineFastState.Bounded env20428 := by
  intro p hp
  have h : env20428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20422_20428 : H12AffineEnvironment.transform 16 13389 env20422 = env20428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env20422 == env20428) = true)

def env20429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400636,498993,8328,65,295285,395772,416237,56573,1500,272393,256,21792,46213,74251]

theorem envBound20429 : H12AffineFastState.Bounded env20429 := by
  intro p hp
  have h : env20429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20420_20429 : H12AffineEnvironment.transform 20 4161 env20420 = env20429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env20420 == env20429) = true)

theorem identity20429 : scanCanonicalize (H12AffineFastState.compose env20429 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound20429 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,180408,400636,441659,8328,65,295285,395772,416237,56573,1500,272393,256,21792,46213,513]

theorem envBound20430 : H12AffineFastState.Bounded env20430 := by
  intro p hp
  have h : env20430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20429_20430 : H12AffineEnvironment.transform 15 8202 env20429 = env20430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env20429 == env20430) = true)

def env20431 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4161,32936,285932,326955,8328,65,295285,281068,268797,56573,1500,272393,256,21792,46213,513]

theorem envBound20431 : H12AffineFastState.Bounded env20431 := by
  intro p hp
  have h : env20431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20430_20431 : H12AffineEnvironment.transform 16 16400 env20430 = env20431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env20430 == env20431) = true)

theorem identity20431 : scanCanonicalize (H12AffineFastState.compose env20431 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23804) := by decide +kernel

theorem selectedBound20431 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env20432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,23804,1024,32769,4161,32936,16,41431,8328,65,56713,5392,17665,56573,1500,29941,256,21792,46213,513]

theorem envBound20432 : H12AffineFastState.Bounded env20432 := by
  intro p hp
  have h : env20432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20431_20432 : H12AffineEnvironment.transform 17 23804 env20431 = env20432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23804 env20431 == env20432) = true)

theorem identity20432 : scanCanonicalize (H12AffineFastState.compose env20432 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound20432 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env20433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16400,23804,1024,1,4161,168,16,8663,8328,65,23945,5392,17665,23805,1500,29941,256,21792,13445,513]

theorem envBound20433 : H12AffineFastState.Bounded env20433 := by
  intro p hp
  have h : env20433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20432_20433 : H12AffineEnvironment.transform 14 0 env20432 = env20433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env20432 == env20433) = true)

theorem identity20433 : scanCanonicalize (H12AffineFastState.compose env20433 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound20433 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env20434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,0,8202,13389,10401,1024,1,4161,168,16,8663,8328,65,10708,5392,12636,10400,1500,168,256,8573,13445,513]

theorem envBound20434 : H12AffineFastState.Bounded env20434 := by
  intro p hp
  have h : env20434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20433_20434 : H12AffineEnvironment.transform 13 13405 env20433 = env20434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env20433 == env20434) = true)

theorem identity20434 : scanCanonicalize (H12AffineFastState.compose env20434 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound20434 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env20435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,0,343,5392,2556,1024,1,4161,168,16,138,469,65,2185,5392,4097,2557,1500,168,256,32,5592,513]

theorem envBound20435 : H12AffineFastState.Bounded env20435 := by
  intro p hp
  have h : env20435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20434_20435 : H12AffineEnvironment.transform 12 349 env20434 = env20435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env20434 == env20435) = true)

theorem identity20435 : scanCanonicalize (H12AffineFastState.compose env20435 (packedSelected [0,1,4,5,7,9,10,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3522) := by decide +kernel

theorem selectedBound20435 : packedSelected [0,1,4,5,7,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env20436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3522,349,2242,0,343,2258,2556,1024,1,3459,168,16,138,469,65,2185,2258,3523,2557,1500,168,256,32,2074,513]

theorem envBound20436 : H12AffineFastState.Bounded env20436 := by
  intro p hp
  have h : env20436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20435_20436 : H12AffineEnvironment.transform 11 3522 env20435 = env20436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3522 env20435 == env20436) = true)

theorem identity20436 : scanCanonicalize (H12AffineFastState.compose env20436 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound20436 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3402,349,2122,0,343,2138,2420,1024,1,3339,32,16,2,349,65,2049,2138,3403,2421,1364,32,256,32,2074,513]

theorem envBound20437 : H12AffineFastState.Bounded env20437 := by
  intro p hp
  have h : env20437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20436_20437 : H12AffineEnvironment.transform 6 8 env20436 = env20437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20436 == env20437) = true)

theorem identity20437 : scanCanonicalize (H12AffineFastState.compose env20437 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 90) := by decide +kernel

theorem selectedBound20437 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env20438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,90,1296,349,16,0,343,0,302,1024,1,1361,32,16,2,349,65,91,0,1297,303,1364,32,256,32,64,513]

theorem envBound20438 : H12AffineFastState.Bounded env20438 := by
  intro p hp
  have h : env20438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20437_20438 : H12AffineEnvironment.transform 10 90 env20437 = env20438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 90 env20437 == env20438) = true)

theorem identity20438 : scanCanonicalize (H12AffineFastState.compose env20438 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound20438 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env20439 : List Nat := [2,4,8,16,32,64,8,117,512,1024,90,1125,40,16,0,34,0,91,1024,1,1060,32,16,2,40,65,91,0,1124,90,1057,32,117,32,64,513]

theorem envBound20439 : H12AffineFastState.Bounded env20439 := by
  intro p hp
  have h : env20439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20438_20439 : H12AffineEnvironment.transform 7 117 env20438 = env20439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env20438 == env20439) = true)

theorem identity20439 : scanCanonicalize (H12AffineFastState.compose env20439 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound20439 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env20440 : List Nat := [2,4,8,16,32,64,8,117,512,110,90,11,40,16,0,34,0,91,110,1,74,32,16,2,40,65,91,0,10,90,79,32,117,32,64,513]

theorem envBound20440 : H12AffineFastState.Bounded env20440 := by
  intro p hp
  have h : env20440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20439_20440 : H12AffineEnvironment.transform 9 110 env20439 = env20440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env20439 == env20440) = true)

theorem identity20440 : scanCanonicalize (H12AffineFastState.compose env20440 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20440 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env20441 : List Nat := [2,4,8,16,1,64,8,84,512,79,90,11,9,16,0,3,0,91,79,1,74,1,16,2,9,65,91,0,10,90,79,1,84,1,64,513]

theorem envBound20441 : H12AffineFastState.Bounded env20441 := by
  intro p hp
  have h : env20441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20440_20441 : H12AffineEnvironment.transform 4 1 env20440 = env20441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20440 == env20441) = true)

def env20442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,32937,285933,326954,8328,65,295285,281069,268796,56573,1500,272393,256,21792,46213,513]

theorem envBound20442 : H12AffineFastState.Bounded env20442 := by
  intro p hp
  have h : env20442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20430_20442 : H12AffineEnvironment.transform 16 16401 env20430 = env20442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env20430 == env20442) = true)

def env20443 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,32801,285797,326954,8192,65,295285,280933,268660,56437,1364,272393,256,21792,46093,513]

theorem envBound20443 : H12AffineFastState.Bounded env20443 := by
  intro p hp
  have h : env20443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20442_20443 : H12AffineEnvironment.transform 6 8 env20442 = env20443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20442 == env20443) = true)

def env20444 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,32800,285796,326954,8193,65,295285,280932,268661,56436,1365,272393,256,21792,46092,513]

theorem envBound20444 : H12AffineFastState.Bounded env20444 := by
  intro p hp
  have h : env20444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20442_20444 : H12AffineEnvironment.transform 6 9 env20442 = env20444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20442 == env20444) = true)

theorem identity20444 : scanCanonicalize (H12AffineFastState.compose env20444 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound20444 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env20445 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,3172,1024,32769,4161,32800,20480,61774,8193,65,36113,17664,5393,56436,1365,9325,256,21792,46092,513]

theorem envBound20445 : H12AffineFastState.Bounded env20445 := by
  intro p hp
  have h : env20445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20444_20445 : H12AffineEnvironment.transform 17 3172 env20444 = env20445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env20444 == env20445) = true)

theorem identity20445 : scanCanonicalize (H12AffineFastState.compose env20445 (packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound20445 : packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env20446 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,32768,1094,16401,3172,1024,32769,4161,32800,20480,54530,1101,65,36113,17664,5393,56436,1365,33,256,21792,36928,513]

theorem envBound20446 : H12AffineFastState.Bounded env20446 := by
  intro p hp
  have h : env20446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20445_20446 : H12AffineEnvironment.transform 12 1100 env20445 = env20446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env20445 == env20446) = true)

theorem identity20446 : scanCanonicalize (H12AffineFastState.compose env20446 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 7204) := by decide +kernel

theorem selectedBound20446 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env20447 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,16384,7204,1094,16401,3172,1024,7205,4161,7172,20480,18726,1101,65,4405,17664,5393,16464,1365,33,256,21792,3172,513]

theorem envBound20447 : H12AffineFastState.Bounded env20447 := by
  intro p hp
  have h : env20447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20446_20447 : H12AffineEnvironment.transform 14 7204 env20446 = env20447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7204 env20446 == env20447) = true)

theorem identity20447 : scanCanonicalize (H12AffineFastState.compose env20447 (packedSelected [17] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound20447 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env20448 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1100,16384,1296,1094,16401,3172,1024,1297,2421,1328,18740,18726,1101,65,2049,17664,3109,16464,1365,33,256,19476,3172,513]

theorem envBound20448 : H12AffineFastState.Bounded env20448 := by
  intro p hp
  have h : env20448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20447_20448 : H12AffineEnvironment.transform 11 2356 env20447 = env20448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env20447 == env20448) = true)

theorem identity20448 : scanCanonicalize (H12AffineFastState.compose env20448 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound20448 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env20449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1100,2048,1296,1094,2065,3172,1024,1297,2421,1328,308,294,1101,65,2049,3328,3109,2128,1365,33,256,1044,3172,513]

theorem envBound20449 : H12AffineFastState.Bounded env20449 := by
  intro p hp
  have h : env20449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20448_20449 : H12AffineEnvironment.transform 13 2048 env20448 = env20449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env20448 == env20449) = true)

theorem identity20449 : scanCanonicalize (H12AffineFastState.compose env20449 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound20449 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env20450 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2112,1100,2048,1124,1094,2065,3172,1024,1125,2049,1092,64,82,1101,65,2049,3188,3109,2128,1057,33,116,1044,3172,513]

theorem envBound20450 : H12AffineFastState.Bounded env20450 := by
  intro p hp
  have h : env20450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20449_20450 : H12AffineEnvironment.transform 7 116 env20449 = env20450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env20449 == env20450) = true)

theorem identity20450 : scanCanonicalize (H12AffineFastState.compose env20450 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20450 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20451 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2064,1052,2048,1076,1046,2065,3124,1024,1077,2049,1044,16,2,1053,17,2049,3108,3109,2048,1057,33,36,1044,3124,513]

theorem envBound20451 : H12AffineFastState.Bounded env20451 := by
  intro p hp
  have h : env20451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20450_20451 : H12AffineEnvironment.transform 5 16 env20450 = env20451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20450 == env20451) = true)

theorem identity20451 : scanCanonicalize (H12AffineFastState.compose env20451 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound20451 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env20452 : List Nat := [2,4,8,16,32,16,9,36,512,1024,27,11,1052,27,1076,1046,10,1071,1024,1077,26,1044,16,2,1053,17,26,1087,1086,27,1057,33,36,1044,1071,513]

theorem envBound20452 : H12AffineFastState.Bounded env20452 := by
  intro p hp
  have h : env20452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20451_20452 : H12AffineEnvironment.transform 10 27 env20451 = env20452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env20451 == env20452) = true)

theorem identity20452 : scanCanonicalize (H12AffineFastState.compose env20452 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound20452 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env20453 : List Nat := [2,4,8,16,32,16,9,36,512,52,27,11,40,27,0,34,10,27,52,1,26,32,16,2,41,17,26,11,10,27,21,33,36,32,27,513]

theorem envBound20453 : H12AffineFastState.Bounded env20453 := by
  intro p hp
  have h : env20453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20452_20453 : H12AffineEnvironment.transform 9 52 env20452 = env20453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env20452 == env20453) = true)

theorem identity20453 : scanCanonicalize (H12AffineFastState.compose env20453 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound20453 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20454 : List Nat := [2,4,8,11,32,11,9,36,512,47,0,11,40,0,0,34,10,0,47,1,1,32,11,2,41,10,1,11,10,0,14,33,36,32,0,513]

theorem envBound20454 : H12AffineFastState.Bounded env20454 := by
  intro p hp
  have h : env20454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20453_20454 : H12AffineEnvironment.transform 3 11 env20453 = env20454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env20453 == env20454) = true)

def env20455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493629,498993,8328,65,2396469,2496957,416237,2149564,2102685,2373705,256,21792,46213,2175562]

theorem envBound20455 : H12AffineFastState.Bounded env20455 := by
  intro p hp
  have h : env20455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20419_20455 : H12AffineEnvironment.transform 21 180409 env20419 = env20455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env20419 == env20455) = true)

def env20456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400637,498993,8328,65,295285,395773,416237,56572,1501,272393,256,21792,46213,74250]

theorem envBound20456 : H12AffineFastState.Bounded env20456 := by
  intro p hp
  have h : env20456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20455_20456 : H12AffineEnvironment.transform 20 4160 env20455 = env20456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env20455 == env20456) = true)

theorem identity20456 : scanCanonicalize (H12AffineFastState.compose env20456 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound20456 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env20457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,180409,400637,412143,8328,65,295285,395773,416237,56572,1501,272393,256,21792,46213,63188]

theorem envBound20457 : H12AffineFastState.Bounded env20457 := by
  intro p hp
  have h : env20457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20456_20457 : H12AffineEnvironment.transform 15 54494 env20456 = env20457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env20456 == env20457) = true)

def env20458 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180273,400501,412007,8192,65,295285,395637,416101,56436,1365,272393,256,21792,46093,63068]

theorem envBound20458 : H12AffineFastState.Bounded env20458 := by
  intro p hp
  have h : env20458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20457_20458 : H12AffineEnvironment.transform 6 8 env20457 = env20458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env20457 == env20458) = true)

theorem identity20458 : scanCanonicalize (H12AffineFastState.compose env20458 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 23589) := by decide +kernel

theorem selectedBound20458 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env20459 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,23589,1024,32769,4160,180273,147536,136514,8192,65,56656,152912,132416,56436,1365,29740,256,21792,46093,63068]

theorem envBound20459 : H12AffineFastState.Bounded env20459 := by
  intro p hp
  have h : env20459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20458_20459 : H12AffineEnvironment.transform 17 23589 env20458 = env20459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23589 env20458 == env20459) = true)

theorem identity20459 : scanCanonicalize (H12AffineFastState.compose env20459 (packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound20459 : packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env20460 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,57677,23589,1024,32769,4160,8572,41245,62479,8192,65,56656,46109,58381,56436,1365,29740,256,21792,46093,63068]

theorem envBound20460 : H12AffineFastState.Bounded env20460 := by
  intro p hp
  have h : env20460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20459_20460 : H12AffineEnvironment.transform 16 57677 env20459 = env20460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env20459 == env20460) = true)

theorem identity20460 : scanCanonicalize (H12AffineFastState.compose env20460 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound20460 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env20461 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,38160,10360,1024,32769,4160,8572,41245,32850,8192,65,43277,46109,36944,43049,1365,113,256,8573,46093,33281]

theorem envBound20461 : H12AffineFastState.Bounded env20461 := by
  intro p hp
  have h : env20461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20460_20461 : H12AffineEnvironment.transform 13 13405 env20460 = env20461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env20460 == env20461) = true)

theorem identity20461 : scanCanonicalize (H12AffineFastState.compose env20461 (packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound20461 : packedSelected [1,4,8,9,12,14,15,17,19,20] rootPS < 2^1333 := by decide +kernel

def env20462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,1,8202,5393,10360,1024,0,4160,8572,8476,83,8192,65,10508,13340,4177,10280,1365,113,256,8573,13324,512]

theorem envBound20462 : H12AffineFastState.Bounded env20462 := by
  intro p hp
  have h : env20462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20461_20462 : H12AffineEnvironment.transform 14 1 env20461 = env20462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env20461 == env20462) = true)

theorem identity20462 : scanCanonicalize (H12AffineFastState.compose env20462 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound20462 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env20463 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,13405,1,8202,5393,10329,1024,0,4160,8541,8476,83,8192,65,10508,13340,4177,10249,1365,80,256,8540,13324,512]

theorem envBound20463 : H12AffineFastState.Bounded env20463 := by
  intro p hp
  have h : env20463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20462_20463 : H12AffineEnvironment.transform 4 1 env20462 = env20463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env20462 == env20463) = true)

theorem identity20463 : scanCanonicalize (H12AffineFastState.compose env20463 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound20463 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env20464 : List Nat := [2,4,8,16,1,64,8,256,512,20,2048,4096,8192,12361,1,8202,4357,10329,20,0,4160,8541,8476,83,8192,65,10508,12296,4177,10249,321,80,256,8540,12312,512]

theorem envBound20464 : H12AffineFastState.Bounded env20464 := by
  intro p hp
  have h : env20464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20463_20464 : H12AffineEnvironment.transform 9 20 env20463 = env20464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env20463 == env20464) = true)

theorem identity20464 : scanCanonicalize (H12AffineFastState.compose env20464 (packedSelected [0,3,5,7,10,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound20464 : packedSelected [0,3,5,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env20465 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,4096,8192,12313,1,8202,4357,10249,20,0,4112,8461,8476,3,8192,17,10508,12296,4097,10249,273,0,256,8460,12312,512]

theorem envBound20465 : H12AffineFastState.Bounded env20465 := by
  intro p hp
  have h : env20465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20464_20465 : H12AffineEnvironment.transform 5 16 env20464 = env20465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env20464 == env20465) = true)

theorem identity20465 : scanCanonicalize (H12AffineFastState.compose env20465 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound20465 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env20466 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,4096,4380,261,1,4374,4357,6421,20,0,4112,4113,4096,3,4380,17,6160,276,4097,6421,273,0,256,4112,260,512]

theorem envBound20466 : H12AffineFastState.Bounded env20466 := by
  intro p hp
  have h : env20466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20465_20466 : H12AffineEnvironment.transform 12 4380 env20465 = env20466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env20465 == env20466) = true)

theorem identity20466 : scanCanonicalize (H12AffineFastState.compose env20466 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound20466 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20467 : List Nat := [2,4,8,16,1,16,8,256,512,20,2048,2325,2057,261,1,2051,2064,0,20,0,2309,2308,2325,3,2057,17,261,276,2324,0,273,0,256,2309,260,512]

theorem envBound20467 : H12AffineFastState.Bounded env20467 := by
  intro p hp
  have h : env20467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20466_20467 : H12AffineEnvironment.transform 11 2325 env20466 = env20467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env20466 == env20467) = true)

def env20468 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4160,180272,400500,412006,8193,65,295285,395636,416100,56437,1364,272393,256,21792,46092,63069]

theorem envBound20468 : H12AffineFastState.Bounded env20468 := by
  intro p hp
  have h : env20468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20457_20468 : H12AffineEnvironment.transform 6 9 env20457 = env20468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env20457 == env20468) = true)

theorem identity20468 : scanCanonicalize (H12AffineFastState.compose env20468 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(17+1) ^^^ 182289) := by decide +kernel

theorem selectedBound20468 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env20469 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,182289,1024,32769,4160,180272,54373,33143,8193,65,149860,49509,37237,56437,1364,188440,256,21792,46092,63069]

theorem envBound20469 : H12AffineFastState.Bounded env20469 := by
  intro p hp
  have h : env20469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20468_20469 : H12AffineEnvironment.transform 17 182289 env20468 = env20469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182289 env20468 == env20469) = true)

theorem identity20469 : scanCanonicalize (H12AffineFastState.compose env20469 (packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound20469 : packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env20470 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,5393,56576,1024,32769,4160,54561,54373,33143,8193,65,23669,49509,37237,56437,1364,62729,256,21792,46092,63069]

theorem envBound20470 : H12AffineFastState.Bounded env20470 := by
  intro p hp
  have h : env20470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20469_20470 : H12AffineEnvironment.transform 16 5393 env20469 = env20470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env20469 == env20470) = true)

theorem identity20470 : scanCanonicalize (H12AffineFastState.compose env20470 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound20470 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env20471 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,32802,5393,35189,1024,32769,4160,33108,32784,33143,8193,65,2048,38160,37237,34816,1364,41340,256,341,46092,41512]

theorem envBound20471 : H12AffineFastState.Bounded env20471 := by
  intro p hp
  have h : env20471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20470_20471 : H12AffineEnvironment.transform 13 5237 env20470 = env20471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env20470 == env20471) = true)

theorem identity20471 : scanCanonicalize (H12AffineFastState.compose env20471 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound20471 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env20472 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5237,32768,32802,5173,34897,1024,32769,4160,32880,32784,32851,8193,65,2048,37940,36945,34816,1136,41048,36,113,46092,41512]

theorem envBound20472 : H12AffineFastState.Bounded env20472 := by
  intro p hp
  have h : env20472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20471_20472 : H12AffineEnvironment.transform 7 36 env20471 = env20472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env20471 == env20472) = true)

theorem identity20472 : scanCanonicalize (H12AffineFastState.compose env20472 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound20472 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env20473 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5237,8313,8283,5173,10280,1024,8312,4160,8201,8297,8234,8193,65,2048,13389,12328,10361,1136,33,36,113,5237,593]

theorem envBound20473 : H12AffineFastState.Bounded env20473 := by
  intro p hp
  have h : env20473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20472_20473 : H12AffineEnvironment.transform 14 8313 env20472 = env20473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env20472 == env20473) = true)

theorem identity20473 : scanCanonicalize (H12AffineFastState.compose env20473 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 6201) := by decide +kernel

theorem selectedBound20473 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env20474 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,6201,5237,6208,6242,5173,4113,1024,6209,4160,6192,6224,6163,6200,65,2048,3188,2065,4160,1136,33,36,113,5237,593]

theorem envBound20474 : H12AffineFastState.Bounded env20474 := by
  intro p hp
  have h : env20474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20473_20474 : H12AffineEnvironment.transform 12 6201 env20473 = env20474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6201 env20473 == env20474) = true)

theorem identity20474 : scanCanonicalize (H12AffineFastState.compose env20474 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound20474 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env20475 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3109,1052,2128,1125,1095,2064,3124,1024,1124,3173,1045,1141,1078,1053,65,2048,3188,2065,3173,1136,33,36,113,2128,593]

theorem envBound20475 : H12AffineFastState.Bounded env20475 := by
  intro p hp
  have h : env20475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20474_20475 : H12AffineEnvironment.transform 11 3109 env20474 = env20475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env20474 == env20475) = true)

theorem identity20475 : scanCanonicalize (H12AffineFastState.compose env20475 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound20475 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env20476 : List Nat := [2,4,8,16,32,64,9,36,512,1024,81,1140,1052,1,1125,1095,65,1125,1024,1124,1076,1045,1141,1078,1053,65,81,1061,64,1076,1136,33,36,113,1,593]

theorem envBound20476 : H12AffineFastState.Bounded env20476 := by
  intro p hp
  have h : env20476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20475_20476 : H12AffineEnvironment.transform 10 81 env20475 = env20476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env20475 == env20476) = true)

theorem identity20476 : scanCanonicalize (H12AffineFastState.compose env20476 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound20476 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env20477 : List Nat := [2,4,8,16,32,64,9,36,512,100,81,16,120,1,1,35,65,1,100,0,80,113,17,82,121,65,81,65,64,80,20,33,36,113,1,593]

theorem envBound20477 : H12AffineFastState.Bounded env20477 := by
  intro p hp
  have h : env20477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20476_20477 : H12AffineEnvironment.transform 9 100 env20476 = env20477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env20476 == env20477) = true)

theorem identity20477 : scanCanonicalize (H12AffineFastState.compose env20477 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound20477 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env20478 : List Nat := [2,4,8,16,32,17,9,36,512,53,0,16,41,1,1,35,16,1,53,0,1,32,17,3,40,16,0,16,17,1,20,33,36,32,1,512]

theorem envBound20478 : H12AffineFastState.Bounded env20478 := by
  intro p hp
  have h : env20478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20477_20478 : H12AffineEnvironment.transform 5 17 env20477 = env20478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env20477 == env20478) = true)

theorem identity20478 : scanCanonicalize (H12AffineFastState.compose env20478 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound20478 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env20479 : List Nat := [2,1,8,16,32,17,9,33,512,48,0,16,41,1,1,35,16,1,48,0,1,32,17,3,40,16,0,16,17,1,17,33,33,32,1,512]

theorem envBound20479 : H12AffineFastState.Bounded env20479 := by
  intro p hp
  have h : env20479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans20478_20479 : H12AffineEnvironment.transform 1 1 env20478 = env20479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env20478 == env20479) = true)

theorem identity20479 : scanCanonicalize (H12AffineFastState.compose env20479 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound20479 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env20480 : List Nat := [2,1,8,16,32,17,9,33,3,48,0,16,41,1,1,35,16,1,48,0,1,32,17,3,40,16,0,16,17,1,17,33,33,32,1,3]

theorem envBound20480 : H12AffineFastState.Bounded env20480 := by
  intro p hp
  have h : env20480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1