import H12CloudChart1Data062

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound15859 : H12AffineFastState.Bounded env15859 := by
  intro p hp
  have h : env15859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15858_15859 : H12AffineEnvironment.transform 20 82967 env15858 = env15859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82967 env15858 == env15859) = true)

theorem identity15859 : scanCanonicalize (H12AffineFastState.compose env15859 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15859 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env15860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5376,292,65536,5308,2420,1025,293,69911,261,65862,65785,121,64,67927,70727,4096,67755,66699,65754,257,32,5456,941]

theorem envBound15860 : H12AffineFastState.Bounded env15860 := by
  intro p hp
  have h : env15860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15859_15860 : H12AffineEnvironment.transform 13 5376 env15859 = env15860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15859 == env15860) = true)

theorem identity15860 : scanCanonicalize (H12AffineFastState.compose env15860 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound15860 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env15861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,241,5376,292,478,5308,2420,1025,293,4297,261,152,295,121,64,2185,5529,4096,2421,1365,260,257,32,5456,941]

theorem envBound15861 : H12AffineFastState.Bounded env15861 := by
  intro p hp
  have h : env15861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15860_15861 : H12AffineEnvironment.transform 15 478 env15860 = env15861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env15860 == env15861) = true)

theorem identity15861 : scanCanonicalize (H12AffineFastState.compose env15861 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15861 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5376,292,342,5172,2420,1025,293,4161,261,16,295,121,64,2049,5393,4096,2421,1365,260,257,32,5456,805]

theorem envBound15862 : H12AffineFastState.Bounded env15862 := by
  intro p hp
  have h : env15862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15861_15862 : H12AffineEnvironment.transform 6 8 env15861 = env15862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15861 == env15862) = true)

theorem identity15862 : scanCanonicalize (H12AffineFastState.compose env15862 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15862 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15863 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5376,292,262,5172,2340,1025,293,4113,261,16,295,41,16,2049,5393,4096,2341,1285,260,257,32,5376,805]

theorem envBound15863 : H12AffineFastState.Bounded env15863 := by
  intro p hp
  have h : env15863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15862_15863 : H12AffineEnvironment.transform 5 16 env15862 = env15863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15862 == env15863) = true)

theorem identity15863 : scanCanonicalize (H12AffineFastState.compose env15863 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15863 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env15864 : List Nat := [2,4,8,16,32,16,8,4,512,1024,2048,4096,41,5124,32,2,5172,2080,1025,33,4113,1,16,35,41,16,2049,5141,4096,2081,1025,0,5,32,5124,545]

theorem envBound15864 : H12AffineFastState.Bounded env15864 := by
  intro p hp
  have h : env15864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15863_15864 : H12AffineEnvironment.transform 7 4 env15863 = env15864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15863 == env15864) = true)

def env15865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2144660,2098512,17664,2363592,2102684,2411676,257,21792,46213,2175563]

theorem envBound15865 : H12AffineFastState.Bounded env15865 := by
  intro p hp
  have h : env15865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15846_15865 : H12AffineEnvironment.transform 21 272513 env15846 = env15865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15846 == env15865) = true)

theorem identity15865 : scanCanonicalize (H12AffineFastState.compose env15865 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58517) := by decide +kernel

theorem selectedBound15865 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,58517,272513,62660,98781,8328,64,23809,57797,17664,324701,61705,272393,257,21792,46213,120542]

theorem envBound15866 : H12AffineFastState.Bounded env15866 := by
  intro p hp
  have h : env15866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15865_15866 : H12AffineEnvironment.transform 20 58517 env15865 = env15866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58517 env15865 == env15866) = true)

def env15867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10280,1025,32769,58517,169,62660,98781,8328,64,23809,57797,17664,56437,61705,33,257,21792,46213,120542]

theorem envBound15867 : H12AffineFastState.Bounded env15867 := by
  intro p hp
  have h : env15867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15866_15867 : H12AffineEnvironment.transform 17 10280 env15866 = env15867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15866 == env15867) = true)

theorem identity15867 : scanCanonicalize (H12AffineFastState.compose env15867 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15867 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env15868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,25028,10280,1025,8541,17865,169,21912,73857,8328,64,23809,16537,17664,32041,20565,33,257,21792,5593,96130]

theorem envBound15868 : H12AffineFastState.Bounded env15868 := by
  intro p hp
  have h : env15868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15867_15868 : H12AffineEnvironment.transform 14 8540 env15867 = env15868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15867 == env15868) = true)

theorem identity15868 : scanCanonicalize (H12AffineFastState.compose env15868 (packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15868 : packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS < 2^1333 := by decide +kernel

def env15869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8203,25028,10280,1025,8541,17865,169,21912,138,8328,64,23809,16537,17664,32041,20565,33,257,21792,5593,22409]

theorem envBound15869 : H12AffineFastState.Bounded env15869 := by
  intro p hp
  have h : env15869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15868_15869 : H12AffineEnvironment.transform 15 8203 env15868 = env15869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15868 == env15869) = true)

theorem identity15869 : scanCanonicalize (H12AffineFastState.compose env15869 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound15869 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5236,8540,8203,13744,10280,1025,8541,4541,169,492,138,8328,64,2421,5357,4468,10589,1057,33,257,340,5593,1021]

theorem envBound15870 : H12AffineFastState.Bounded env15870 := by
  intro p hp
  have h : env15870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15869_15870 : H12AffineEnvironment.transform 13 5236 env15869 = env15870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env15869 == env15870) = true)

theorem identity15870 : scanCanonicalize (H12AffineFastState.compose env15870 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15870 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5236,373,34,5529,2049,1025,372,4541,169,492,138,161,64,2421,5357,4468,2420,1057,33,257,340,5593,1021]

theorem envBound15871 : H12AffineFastState.Bounded env15871 := by
  intro p hp
  have h : env15871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15870_15871 : H12AffineEnvironment.transform 12 41 env15870 = env15871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15870 == env15871) = true)

theorem identity15871 : scanCanonicalize (H12AffineFastState.compose env15871 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound15871 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15872 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,41,5236,136,34,5220,2049,1025,137,4160,169,17,138,161,64,2184,5357,4233,2185,1057,33,252,169,5156,512]

theorem envBound15872 : H12AffineFastState.Bounded env15872 := by
  intro p hp
  have h : env15872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15871_15872 : H12AffineEnvironment.transform 7 253 env15871 = env15872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env15871 == env15872) = true)

theorem identity15872 : scanCanonicalize (H12AffineFastState.compose env15872 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15872 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15873 : List Nat := [2,4,8,16,1,64,128,220,512,1024,2048,4096,8,5205,136,3,5189,2049,1025,137,4160,136,17,138,128,64,2184,5324,4233,2185,1024,0,221,136,5125,512]

theorem envBound15873 : H12AffineFastState.Bounded env15873 := by
  intro p hp
  have h : env15873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15872_15873 : H12AffineEnvironment.transform 4 1 env15872 = env15873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15872 == env15873) = true)

def env15874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,10281,1025,32769,58517,168,62660,98781,8328,64,23809,57797,17664,56436,61705,32,257,21792,46213,120542]

theorem envBound15874 : H12AffineFastState.Bounded env15874 := by
  intro p hp
  have h : env15874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15866_15874 : H12AffineEnvironment.transform 17 10281 env15866 = env15874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15866 == env15874) = true)

theorem identity15874 : scanCanonicalize (H12AffineFastState.compose env15874 (packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound15874 : packedSelected [0,1,2,3,4,6,9,15,20,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env15875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,32768,65536,49304,2128,1025,32769,50412,168,54461,98781,241,64,23809,49596,17664,56436,53616,32,257,21792,38140,120542]

theorem envBound15875 : H12AffineFastState.Bounded env15875 := by
  intro p hp
  have h : env15875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15874_15875 : H12AffineEnvironment.transform 12 121 env15874 = env15875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env15874 == env15875) = true)

theorem identity15875 : scanCanonicalize (H12AffineFastState.compose env15875 (packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,18,19,24,26,28] rootPS)) = affineNative (2^(14+1) ^^^ 429) := by decide +kernel

theorem selectedBound15875 : packedSelected [0,1,2,4,5,6,7,9,10,11,12,14,15,18,19,24,26,28] rootPS < 2^1333 := by decide +kernel

def env15876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,429,65536,16693,2128,1025,428,17729,168,21776,65648,241,64,23809,16401,17664,24025,20701,32,257,21792,5457,87923]

theorem envBound15876 : H12AffineFastState.Bounded env15876 := by
  intro p hp
  have h : env15876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15875_15876 : H12AffineEnvironment.transform 14 429 env15875 = env15876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 429 env15875 == env15876) = true)

theorem identity15876 : scanCanonicalize (H12AffineFastState.compose env15876 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(15+1) ^^^ 20807) := by decide +kernel

theorem selectedBound15876 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env15877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,16384,429,20807,16693,2128,1025,428,17729,168,21776,20791,241,64,23809,16401,17664,24025,20701,32,257,21792,5457,1588]

theorem envBound15877 : H12AffineFastState.Bounded env15877 := by
  intro p hp
  have h : env15877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15876_15877 : H12AffineEnvironment.transform 15 20807 env15876 = env15877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20807 env15876 == env15877) = true)

theorem identity15877 : scanCanonicalize (H12AffineFastState.compose env15877 (packedSelected [1,5,8,12,15,17,18,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound15877 : packedSelected [1,5,8,12,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env15878 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,121,16384,429,20807,16693,2128,273,428,16465,168,20480,20791,241,64,22545,16401,16400,22729,20701,32,257,20528,4161,804]

theorem envBound15878 : H12AffineFastState.Bounded env15878 := by
  intro p hp
  have h : env15878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15877_15878 : H12AffineEnvironment.transform 9 272 env15877 = env15878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env15877 == env15878) = true)

theorem identity15878 : scanCanonicalize (H12AffineFastState.compose env15878 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound15878 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env15879 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,121,16384,373,20807,16693,2128,273,372,16465,112,20480,20791,41,64,22545,16401,16400,22545,20485,32,257,20528,4161,804]

theorem envBound15879 : H12AffineFastState.Bounded env15879 := by
  intro p hp
  have h : env15879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15878_15879 : H12AffineEnvironment.transform 6 88 env15878 = env15879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env15878 == env15879) = true)

theorem identity15879 : scanCanonicalize (H12AffineFastState.compose env15879 (packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound15879 : packedSelected [0,2,3,4,5,6,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env15880 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,121,4453,373,34,4176,2128,273,372,4404,112,357,82,41,64,2420,4468,4469,2420,352,32,257,341,4161,804]

theorem envBound15880 : H12AffineFastState.Bounded env15880 := by
  intro p hp
  have h : env15880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15879_15880 : H12AffineEnvironment.transform 13 4453 env15879 = env15880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env15879 == env15880) = true)

theorem identity15880 : scanCanonicalize (H12AffineFastState.compose env15880 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15880 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15881 : List Nat := [2,4,8,16,32,64,88,36,512,52,2048,4096,121,4161,81,34,4176,2128,53,80,4112,112,65,82,41,64,2128,4176,4177,2128,68,32,37,113,4161,512]

theorem envBound15881 : H12AffineFastState.Bounded env15881 := by
  intro p hp
  have h : env15881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15880_15881 : H12AffineEnvironment.transform 7 36 env15880 = env15881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15880 == env15881) = true)

theorem identity15881 : scanCanonicalize (H12AffineFastState.compose env15881 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound15881 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env15882 : List Nat := [2,4,8,16,32,64,88,36,512,52,2048,0,121,65,81,34,80,2128,53,80,16,112,65,82,41,64,2128,80,81,2128,68,32,37,113,65,512]

theorem envBound15882 : H12AffineFastState.Bounded env15882 := by
  intro p hp
  have h : env15882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15881_15882 : H12AffineEnvironment.transform 11 0 env15881 = env15882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env15881 == env15882) = true)

theorem identity15882 : scanCanonicalize (H12AffineFastState.compose env15882 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15882 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15883 : List Nat := [2,4,8,16,32,48,40,36,512,52,2048,0,9,49,33,34,32,2080,53,32,16,0,49,34,41,48,2080,32,33,2080,52,32,37,1,49,512]

theorem envBound15883 : H12AffineFastState.Bounded env15883 := by
  intro p hp
  have h : env15883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15882_15883 : H12AffineEnvironment.transform 5 48 env15882 = env15883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15882 == env15883) = true)

theorem identity15883 : scanCanonicalize (H12AffineFastState.compose env15883 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound15883 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env15884 : List Nat := [2,4,8,16,32,48,40,36,512,52,49,0,9,49,33,34,32,17,53,32,16,0,49,34,41,48,17,32,33,17,52,32,37,1,49,512]

theorem envBound15884 : H12AffineFastState.Bounded env15884 := by
  intro p hp
  have h : env15884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15883_15884 : H12AffineEnvironment.transform 10 49 env15883 = env15884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env15883 == env15884) = true)

theorem identity15884 : scanCanonicalize (H12AffineFastState.compose env15884 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound15884 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15885 : List Nat := [2,4,8,16,17,1,25,21,512,5,0,0,9,0,16,19,17,17,4,17,16,0,0,19,24,1,17,17,16,17,5,17,20,1,0,512]

theorem envBound15885 : H12AffineFastState.Bounded env15885 := by
  intro p hp
  have h : env15885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15884_15885 : H12AffineEnvironment.transform 4 17 env15884 = env15885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env15884 == env15885) = true)

theorem identity15885 : scanCanonicalize (H12AffineFastState.compose env15885 (packedSelected [4,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15885 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15886 : List Nat := [2,4,8,1,0,1,8,4,512,5,0,0,9,0,1,2,0,0,4,0,1,0,0,2,9,1,0,0,1,0,5,0,5,1,0,512]

theorem envBound15886 : H12AffineFastState.Bounded env15886 := by
  intro p hp
  have h : env15886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15885_15886 : H12AffineEnvironment.transform 3 1 env15885 = env15886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15885 == env15886) = true)

theorem identity15886 : scanCanonicalize (H12AffineFastState.compose env15886 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound15886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15887 : List Nat := [2,1,8,1,0,1,8,1,512,0,0,0,9,0,1,2,0,0,1,0,1,0,0,2,9,1,0,0,1,0,0,0,0,1,0,512]

theorem envBound15887 : H12AffineFastState.Bounded env15887 := by
  intro p hp
  have h : env15887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15886_15887 : H12AffineEnvironment.transform 1 1 env15886 = env15887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env15886 == env15887) = true)

theorem identity15887 : scanCanonicalize (H12AffineFastState.compose env15887 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound15887 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15888 : List Nat := [2,1,8,1,0,1,8,1,9,0,0,0,9,0,1,2,0,0,1,0,1,0,0,2,9,1,0,0,1,0,0,0,0,1,0,9]

theorem envBound15888 : H12AffineFastState.Bounded env15888 := by
  intro p hp
  have h : env15888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15887_15888 : H12AffineEnvironment.transform 8 9 env15887 = env15888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env15887 == env15888) = true)

theorem identity15888 : scanCanonicalize (H12AffineFastState.compose env15888 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound15888 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15889 : List Nat := [2,1,2,1,0,1,2,1,3,0,0,0,3,0,1,2,0,0,1,0,1,0,0,2,3,1,0,0,1,0,0,0,0,1,0,3]

theorem envBound15889 : H12AffineFastState.Bounded env15889 := by
  intro p hp
  have h : env15889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15888_15889 : H12AffineEnvironment.transform 2 2 env15888 = env15889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env15888 == env15889) = true)

def env15890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6590740,2098513,17665,2363592,2102684,6349852,257,21792,46213,2175563]

theorem envBound15890 : H12AffineFastState.Bounded env15890 := by
  intro p hp
  have h : env15890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15845_15890 : H12AffineEnvironment.transform 16 49305 env15845 = env15890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env15845 == env15890) = true)

def env15891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2144660,2098513,17665,2363592,2102684,2411676,257,21792,46213,2175563]

theorem envBound15891 : H12AffineFastState.Bounded env15891 := by
  intro p hp
  have h : env15891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15890_15891 : H12AffineEnvironment.transform 21 272512 env15890 = env15891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15890 == env15891) = true)

def env15892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101328,98644,8192,64,2144540,2098513,17665,2363456,2102548,2411540,257,21792,46093,2175563]

theorem envBound15892 : H12AffineFastState.Bounded env15892 := by
  intro p hp
  have h : env15892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15891_15892 : H12AffineEnvironment.transform 6 8 env15891 = env15892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15891 == env15892) = true)

theorem identity15892 : scanCanonicalize (H12AffineFastState.compose env15892 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15892 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,65536,16400,262144,1025,0,2097152,272392,2101328,65877,8192,64,2111773,2098513,17665,2363456,2102548,2378773,257,21792,13324,2175563]

theorem envBound15893 : H12AffineFastState.Bounded env15893 := by
  intro p hp
  have h : env15893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15892_15893 : H12AffineEnvironment.transform 14 1 env15892 = env15893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15892 == env15893) = true)

theorem identity15893 : scanCanonicalize (H12AffineFastState.compose env15893 (packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound15893 : packedSelected [1,3,4,5,7,8,9,10,26,27] rootPS < 2^1333 := by decide +kernel

def env15894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,1,65536,13341,262144,1025,0,2097152,272392,2101328,65877,8192,64,2111773,2098513,12556,2363456,2102548,2373656,257,8493,13324,2175563]

theorem envBound15894 : H12AffineFastState.Bounded env15894 := by
  intro p hp
  have h : env15894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15893_15894 : H12AffineEnvironment.transform 13 13325 env15893 = env15894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env15893 == env15894) = true)

theorem identity15894 : scanCanonicalize (H12AffineFastState.compose env15894 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound15894 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env15895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,1,65536,13341,67618,1025,0,2097152,73770,2101328,65877,8192,64,2111773,2098513,12556,2168930,2102548,2175034,257,8493,13324,2175563]

theorem envBound15895 : H12AffineFastState.Bounded env15895 := by
  intro p hp
  have h : env15895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15894_15895 : H12AffineEnvironment.transform 17 67618 env15894 = env15895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env15894 == env15895) = true)

theorem identity15895 : scanCanonicalize (H12AffineFastState.compose env15895 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15895 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env15896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,1,8202,13341,10280,1025,0,2097152,32,2101328,8543,8192,64,2111773,2098513,12556,2111592,2102548,2101296,257,8493,13324,2101825]

theorem envBound15896 : H12AffineFastState.Bounded env15896 := by
  intro p hp
  have h : env15896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15895_15896 : H12AffineEnvironment.transform 15 8202 env15895 = env15896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15895 == env15896) = true)

theorem identity15896 : scanCanonicalize (H12AffineFastState.compose env15896 (packedSelected [0,2,4,11,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 12344) := by decide +kernel

theorem selectedBound15896 : packedSelected [0,2,4,11,14,16] rootPS < 2^1333 := by decide +kernel

def env15897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,1,8202,13341,10280,1025,0,12344,32,8296,8543,8192,64,2341,13673,12556,2128,9516,8200,257,8493,13324,8825]

theorem envBound15897 : H12AffineFastState.Bounded env15897 := by
  intro p hp
  have h : env15897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15896_15897 : H12AffineEnvironment.transform 20 12344 env15896 = env15897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12344 env15896 == env15897) = true)

theorem identity15897 : scanCanonicalize (H12AffineFastState.compose env15897 (packedSelected [2,4,6,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15897 : packedSelected [2,4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env15898 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,1,8202,13341,10280,1025,0,12344,32,8248,8463,8192,16,2341,13625,12556,2048,9516,8200,257,8493,13324,8745]

theorem envBound15898 : H12AffineFastState.Bounded env15898 := by
  intro p hp
  have h : env15898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15897_15898 : H12AffineEnvironment.transform 5 16 env15897 = env15898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15897 == env15898) = true)

theorem identity15898 : scanCanonicalize (H12AffineFastState.compose env15898 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15898 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env15899 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,5156,1,35,5172,2049,1025,0,4113,32,17,294,41,16,2341,5392,4389,2048,1285,33,257,260,5157,512]

theorem envBound15899 : H12AffineFastState.Bounded env15899 := by
  intro p hp
  have h : env15899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15898_15899 : H12AffineEnvironment.transform 12 41 env15898 = env15899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15898 == env15899) = true)

theorem identity15899 : scanCanonicalize (H12AffineFastState.compose env15899 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15899 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env15900 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,41,5156,1,35,5172,2049,1025,0,4113,32,17,35,41,16,2080,5141,4128,2048,1024,33,4,1,5157,512]

theorem envBound15900 : H12AffineFastState.Bounded env15900 := by
  intro p hp
  have h : env15900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15899_15900 : H12AffineEnvironment.transform 7 5 env15899 = env15900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15899 == env15900) = true)

theorem identity15900 : scanCanonicalize (H12AffineFastState.compose env15900 (packedSelected [1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound15900 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env15901 : List Nat := [2,4,8,16,32,16,8,5,512,1024,523,4096,41,5156,1,35,5172,522,1025,0,4113,32,17,35,41,16,555,5141,4128,523,1024,33,4,1,5157,512]

theorem envBound15901 : H12AffineFastState.Bounded env15901 := by
  intro p hp
  have h : env15901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15900_15901 : H12AffineEnvironment.transform 10 523 env15900 = env15901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env15900 == env15901) = true)

def env15902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101328,98645,8193,64,2144541,2098513,17665,2363457,2102549,2411541,257,21792,46092,2175563]

theorem envBound15902 : H12AffineFastState.Bounded env15902 := by
  intro p hp
  have h : env15902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15891_15902 : H12AffineEnvironment.transform 6 9 env15891 = env15902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15891 == env15902) = true)

theorem identity15902 : scanCanonicalize (H12AffineFastState.compose env15902 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound15902 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env15903 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,77898,272393,73754,98645,8193,64,100695,79131,17665,335883,75103,392287,257,21792,46092,513]

theorem envBound15903 : H12AffineFastState.Bounded env15903 := by
  intro p hp
  have h : env15903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15902_15903 : H12AffineEnvironment.transform 20 77898 env15902 = env15903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env15902 == env15903) = true)

theorem identity15903 : scanCanonicalize (H12AffineFastState.compose env15903 (packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound15903 : packedSelected [0,1,5,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env15904 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1025,32769,77898,41340,73754,98645,8193,64,100695,79131,17665,108926,75103,95530,257,21792,46092,513]

theorem envBound15904 : H12AffineFastState.Bounded env15904 := by
  intro p hp
  have h : env15904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15903_15904 : H12AffineEnvironment.transform 17 35189 env15903 = env15904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env15903 == env15904) = true)

theorem identity15904 : scanCanonicalize (H12AffineFastState.compose env15904 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15904 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env15905 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38161,35189,1025,32769,77898,41340,73754,98645,8193,64,100695,79131,4096,108926,75103,73771,257,33,46092,513]

theorem envBound15905 : H12AffineFastState.Bounded env15905 := by
  intro p hp
  have h : env15905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15904_15905 : H12AffineEnvironment.transform 13 5377 env15904 = env15905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15904 == env15905) = true)

theorem identity15905 : scanCanonicalize (H12AffineFastState.compose env15905 (packedSelected [0,3,5,7,10,12,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound15905 : packedSelected [0,3,5,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env15906 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33031,38161,35189,1025,32769,45389,41340,41245,82,8193,64,2128,46108,4096,10361,42072,41260,257,33,46092,513]

theorem envBound15906 : H12AffineFastState.Bounded env15906 := by
  intro p hp
  have h : env15906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15905_15906 : H12AffineEnvironment.transform 15 33031 env15905 = env15906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env15905 == env15906) = true)

theorem identity15906 : scanCanonicalize (H12AffineFastState.compose env15906 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15906 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env15907 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,32768,33031,38161,35189,1025,32769,36881,32800,32833,82,349,64,2128,38208,4096,2341,34052,32880,257,33,38224,513]

theorem envBound15907 : H12AffineFastState.Bounded env15907 := by
  intro p hp
  have h : env15907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15906_15907 : H12AffineEnvironment.transform 12 348 env15906 = env15907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15906 == env15907) = true)

theorem identity15907 : scanCanonicalize (H12AffineFastState.compose env15907 (packedSelected [0,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15907 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env15908 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,32768,33031,38161,35108,1025,32769,36881,32800,32784,3,268,17,2049,38161,4096,2341,34052,32801,257,33,38145,513]

theorem envBound15908 : H12AffineFastState.Bounded env15908 := by
  intro p hp
  have h : env15908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15907_15908 : H12AffineEnvironment.transform 5 17 env15907 = env15908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15907 == env15908) = true)

theorem identity15908 : scanCanonicalize (H12AffineFastState.compose env15908 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15908 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env15909 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1025,1,4113,32,16,3,268,17,2049,5393,4096,2341,1284,33,257,33,5377,513]

theorem envBound15909 : H12AffineFastState.Bounded env15909 := by
  intro p hp
  have h : env15909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15908_15909 : H12AffineEnvironment.transform 14 0 env15908 = env15909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15908 == env15909) = true)

theorem identity15909 : scanCanonicalize (H12AffineFastState.compose env15909 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15909 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15910 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4405,0,263,4389,2340,53,1,4113,32,16,3,268,17,2049,4389,4096,2341,304,33,257,33,4405,513]

theorem envBound15910 : H12AffineFastState.Bounded env15910 := by
  intro p hp
  have h : env15910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15909_15910 : H12AffineEnvironment.transform 9 52 env15909 = env15910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15909 == env15910) = true)

theorem identity15910 : scanCanonicalize (H12AffineFastState.compose env15910 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15910 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15911 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4112,0,34,4096,2049,53,1,4113,32,16,3,41,17,2049,4096,4096,2048,21,33,36,33,4112,513]

theorem envBound15911 : H12AffineFastState.Bounded env15911 := by
  intro p hp
  have h : env15911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15910_15911 : H12AffineEnvironment.transform 7 37 env15910 = env15911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15910 == env15911) = true)

theorem identity15911 : scanCanonicalize (H12AffineFastState.compose env15911 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2576) := by decide +kernel

theorem selectedBound15911 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15912 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2576,40,2560,0,34,2576,2049,53,1,2561,32,16,3,41,17,2049,2576,2576,2048,21,33,36,33,2560,513]

theorem envBound15912 : H12AffineFastState.Bounded env15912 := by
  intro p hp
  have h : env15912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15911_15912 : H12AffineEnvironment.transform 11 2576 env15911 = env15912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2576 env15911 == env15912) = true)

theorem identity15912 : scanCanonicalize (H12AffineFastState.compose env15912 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound15912 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15913 : List Nat := [2,4,8,16,32,17,9,37,512,52,58,554,40,570,0,34,554,59,53,1,571,32,16,3,41,17,59,554,554,58,21,33,36,33,570,513]

theorem envBound15913 : H12AffineFastState.Bounded env15913 := by
  intro p hp
  have h : env15913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15912_15913 : H12AffineEnvironment.transform 10 58 env15912 = env15913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env15912 == env15913) = true)

theorem identity15913 : scanCanonicalize (H12AffineFastState.compose env15913 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound15913 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15914 : List Nat := [2,4,8,16,26,17,9,31,512,14,0,528,18,512,0,24,528,1,15,1,513,26,16,3,19,17,1,528,528,0,21,27,30,27,512,513]

theorem envBound15914 : H12AffineFastState.Bounded env15914 := by
  intro p hp
  have h : env15914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15913_15914 : H12AffineEnvironment.transform 4 26 env15913 = env15914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env15913 == env15914) = true)

theorem identity15914 : scanCanonicalize (H12AffineFastState.compose env15914 (packedSelected [5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15914 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15915 : List Nat := [2,4,8,16,26,17,9,31,1,14,0,17,18,1,0,24,17,1,15,1,0,26,16,3,19,17,1,17,17,0,21,27,30,27,1,0]

theorem envBound15915 : H12AffineFastState.Bounded env15915 := by
  intro p hp
  have h : env15915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15914_15915 : H12AffineEnvironment.transform 8 1 env15914 = env15915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15914 == env15915) = true)

def env15916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2144661,2098513,17665,2363592,2102684,2411677,257,21792,46213,2175563]

theorem envBound15916 : H12AffineFastState.Bounded env15916 := by
  intro p hp
  have h : env15916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15890_15916 : H12AffineEnvironment.transform 21 272513 env15890 = env15916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env15890 == env15916) = true)

theorem identity15916 : scanCanonicalize (H12AffineFastState.compose env15916 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound15916 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,4161,272513,17,98780,8328,64,43476,5392,17665,262281,1501,318684,257,21792,46213,74250]

theorem envBound15917 : H12AffineFastState.Bounded env15917 := by
  intro p hp
  have h : env15917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15916_15917 : H12AffineEnvironment.transform 20 4161 env15916 = env15917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15916 == env15917) = true)

theorem identity15917 : scanCanonicalize (H12AffineFastState.compose env15917 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15917 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env15918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,4161,272513,17,41431,8328,64,43476,5392,17665,262281,1501,318684,257,21792,46213,513]

theorem envBound15918 : H12AffineFastState.Bounded env15918 := by
  intro p hp
  have h : env15918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15917_15918 : H12AffineEnvironment.transform 15 8203 env15917 = env15918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15917 == env15918) = true)

theorem identity15918 : scanCanonicalize (H12AffineFastState.compose env15918 (packedSelected [3,4,9,10,14,17,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15918 : packedSelected [3,4,9,10,14,17,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25028,262144,1025,8540,4161,272513,17,138,8328,64,2185,5392,17665,262281,1501,294273,257,21792,5592,513]

theorem envBound15919 : H12AffineFastState.Bounded env15919 := by
  intro p hp
  have h : env15919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15918_15919 : H12AffineEnvironment.transform 14 8541 env15918 = env15919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15918 == env15919) = true)

theorem identity15919 : scanCanonicalize (H12AffineFastState.compose env15919 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound15919 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,25028,10280,1025,8540,4161,169,17,138,8328,64,2185,5392,17665,10401,1501,21929,257,21792,5592,513]

theorem envBound15920 : H12AffineFastState.Bounded env15920 := by
  intro p hp
  have h : env15920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15919_15920 : H12AffineEnvironment.transform 17 10280 env15919 = env15920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15919 == env15920) = true)

theorem identity15920 : scanCanonicalize (H12AffineFastState.compose env15920 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound15920 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8203,13389,10280,1025,8540,4161,169,17,138,8328,64,2185,5392,4232,10401,1501,32,257,169,5592,513]

theorem envBound15921 : H12AffineFastState.Bounded env15921 := by
  intro p hp
  have h : env15921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15920_15921 : H12AffineEnvironment.transform 13 5513 env15920 = env15921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env15920 == env15921) = true)

theorem identity15921 : scanCanonicalize (H12AffineFastState.compose env15921 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound15921 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env15922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,161,5513,508,170,5356,2185,1025,509,4161,169,17,138,41,64,2185,5392,4232,2048,1501,32,257,169,5592,513]

theorem envBound15922 : H12AffineFastState.Bounded env15922 := by
  intro p hp
  have h : env15922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15921_15922 : H12AffineEnvironment.transform 12 161 env15921 = env15922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env15921 == env15922) = true)

theorem identity15922 : scanCanonicalize (H12AffineFastState.compose env15922 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15922 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15923 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,161,5372,137,170,5356,2185,1025,136,4161,169,17,138,41,64,2185,5221,4232,2048,1192,32,116,169,5293,513]

theorem envBound15923 : H12AffineFastState.Bounded env15923 := by
  intro p hp
  have h : env15923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15922_15923 : H12AffineEnvironment.transform 7 117 env15922 = env15923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15922 == env15923) = true)

theorem identity15923 : scanCanonicalize (H12AffineFastState.compose env15923 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1260) := by decide +kernel

theorem selectedBound15923 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15924 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,1260,161,16,137,170,0,2185,1025,136,1197,169,17,138,41,64,2185,137,1124,2048,1192,32,116,169,65,513]

theorem envBound15924 : H12AffineFastState.Bounded env15924 := by
  intro p hp
  have h : env15924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15923_15924 : H12AffineEnvironment.transform 11 1260 env15923 = env15924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1260 env15923 == env15924) = true)

theorem identity15924 : scanCanonicalize (H12AffineFastState.compose env15924 (packedSelected [2,5,8,14] rootPS)) = affineNative (2^(9+1) ^^^ 111) := by decide +kernel

theorem selectedBound15924 : packedSelected [2,5,8,14] rootPS < 2^1333 := by decide +kernel

def env15925 : List Nat := [2,4,8,16,32,64,128,117,512,111,2048,131,161,16,137,170,0,2185,110,136,194,169,17,138,41,64,2185,137,11,2048,199,32,116,169,65,513]

theorem envBound15925 : H12AffineFastState.Bounded env15925 := by
  intro p hp
  have h : env15925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15924_15925 : H12AffineEnvironment.transform 9 111 env15924 = env15925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 111 env15924 == env15925) = true)

def env15926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound15926 : H12AffineFastState.Bounded env15926 := by
  intro p hp
  have h : env15926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15681_15926 : H12AffineEnvironment.transform 26 30393345 env15681 = env15926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env15681 == env15926) = true)

def env15927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound15927 : H12AffineFastState.Bounded env15927 := by
  intro p hp
  have h : env15927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15926_15927 : H12AffineEnvironment.transform 18 1024 env15926 = env15927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15926 == env15927) = true)

theorem identity15927 : scanCanonicalize (H12AffineFastState.compose env15927 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10601476) := by decide +kernel

theorem selectedBound15927 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10601476,8328,64,6685701,8405128,10507601,8830977,2113556,12624325,256,168,57613,2189250]

theorem envBound15928 : H12AffineFastState.Bounded env15928 := by
  intro p hp
  have h : env15928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15927_15928 : H12AffineEnvironment.transform 23 10601476 env15927 = env15928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10601476 env15927 == env15928) = true)

def env15929 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6685701,8393984,10485977,8820105,2102684,12624325,256,168,46213,2175562]

theorem envBound15929 : H12AffineFastState.Bounded env15929 := by
  intro p hp
  have h : env15929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15928_15929 : H12AffineEnvironment.transform 13 5512 env15928 = env15929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env15928 == env15929) = true)

def env15930 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98644,8328,64,6685701,2098648,4097,2524497,2102684,6336797,256,168,46213,2175562]

theorem envBound15930 : H12AffineFastState.Bounded env15930 := by
  intro p hp
  have h : env15930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15929_15930 : H12AffineEnvironment.transform 22 2101464 env15929 = env15930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env15929 == env15930) = true)

def env15931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98644,8328,64,2491429,2098648,4097,2524497,2102684,2142525,256,168,46213,2175562]

theorem envBound15931 : H12AffineFastState.Bounded env15931 := by
  intro p hp
  have h : env15931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15930_15931 : H12AffineEnvironment.transform 21 32 env15930 = env15931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15930 == env15931) = true)

def env15932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,2097152,32,2101328,98644,8192,64,2491429,2098512,4097,2524497,2102548,2142525,256,32,46093,2175562]

theorem envBound15932 : H12AffineFastState.Bounded env15932 := by
  intro p hp
  have h : env15932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15931_15932 : H12AffineEnvironment.transform 6 8 env15931 = env15932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15931 == env15932) = true)

def env15933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,32,16,98644,8192,64,398437,5392,4097,431377,1364,41341,256,32,46093,74250]

theorem envBound15933 : H12AffineFastState.Bounded env15933 := by
  intro p hp
  have h : env15933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15932_15933 : H12AffineEnvironment.transform 20 4160 env15932 = env15933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15932 == env15933) = true)

theorem identity15933 : scanCanonicalize (H12AffineFastState.compose env15933 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound15933 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15934 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4160,32,16,2,8192,64,398437,5392,4097,431377,1364,41341,256,32,46093,41820]

theorem envBound15934 : H12AffineFastState.Bounded env15934 := by
  intro p hp
  have h : env15934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15933_15934 : H12AffineEnvironment.transform 15 33110 env15933 = env15934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env15933 == env15934) = true)

theorem identity15934 : scanCanonicalize (H12AffineFastState.compose env15934 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound15934 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15935 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5393,262144,1024,32769,4160,32,16,2,8192,64,262516,5392,4097,294912,1364,41341,256,32,46093,41820]

theorem envBound15935 : H12AffineFastState.Bounded env15935 := by
  intro p hp
  have h : env15935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15934_15935 : H12AffineEnvironment.transform 16 5393 env15934 = env15935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env15934 == env15935) = true)

theorem identity15935 : scanCanonicalize (H12AffineFastState.compose env15935 (packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound15935 : packedSelected [3,5,7,10,12,14,15,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env15936 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,5393,2049,1024,32769,4160,32,16,2,8192,64,2421,5392,4097,34817,1364,41341,256,32,46093,41820]

theorem envBound15936 : H12AffineFastState.Bounded env15936 := by
  intro p hp
  have h : env15936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15935_15936 : H12AffineEnvironment.transform 17 2049 env15935 = env15936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env15935 == env15936) = true)

theorem identity15936 : scanCanonicalize (H12AffineFastState.compose env15936 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound15936 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env15937 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,120,5376,32768,33110,5393,2049,1024,32769,4160,32,16,2,120,64,2421,5392,4097,34817,1364,33029,256,32,38005,33572]

theorem envBound15937 : H12AffineFastState.Bounded env15937 := by
  intro p hp
  have h : env15937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15936_15937 : H12AffineEnvironment.transform 12 120 env15936 = env15937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env15936 == env15937) = true)

theorem identity15937 : scanCanonicalize (H12AffineFastState.compose env15937 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15937 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15938 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,41,5376,32768,33031,5393,2049,1024,32769,4113,32,16,2,41,17,2340,5392,4097,34817,1285,33029,256,32,37924,33572]

theorem envBound15938 : H12AffineFastState.Bounded env15938 := by
  intro p hp
  have h : env15938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15937_15938 : H12AffineEnvironment.transform 5 17 env15937 = env15938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15937 == env15938) = true)

theorem identity15938 : scanCanonicalize (H12AffineFastState.compose env15938 (packedSelected [1,2,3,5,8,11,12,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15938 : packedSelected [1,2,3,5,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15939 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,9,5376,32768,33031,5393,2049,1024,32769,4113,0,16,2,9,17,2308,5392,4097,34817,1285,33029,256,0,37892,33540]

theorem envBound15939 : H12AffineFastState.Bounded env15939 := by
  intro p hp
  have h : env15939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15938_15939 : H12AffineEnvironment.transform 4 0 env15938 = env15939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15938 == env15939) = true)

theorem identity15939 : scanCanonicalize (H12AffineFastState.compose env15939 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound15939 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15940 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,9,5376,260,3,5393,2049,1024,261,4113,0,16,2,9,17,2308,5392,4097,2309,1285,1,256,0,5376,512]

theorem envBound15940 : H12AffineFastState.Bounded env15940 := by
  intro p hp
  have h : env15940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15939_15940 : H12AffineEnvironment.transform 14 260 env15939 = env15940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env15939 == env15940) = true)

theorem identity15940 : scanCanonicalize (H12AffineFastState.compose env15940 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15940 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15941 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,9,5125,1,3,5140,2049,1024,0,4113,0,16,2,9,17,2049,5141,4097,2048,1024,1,5,0,5125,512]

theorem envBound15941 : H12AffineFastState.Bounded env15941 := by
  intro p hp
  have h : env15941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15940_15941 : H12AffineEnvironment.transform 7 5 env15940 = env15941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15940 == env15941) = true)

def env15942 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,9,1045,1,3,1028,2049,1024,0,1,0,16,2,9,17,2049,1029,17,2048,1024,1,5,0,1045,512]

theorem envBound15942 : H12AffineFastState.Bounded env15942 := by
  intro p hp
  have h : env15942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15941_15942 : H12AffineEnvironment.transform 11 16 env15941 = env15942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15941 == env15942) = true)

theorem identity15942 : scanCanonicalize (H12AffineFastState.compose env15942 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound15942 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15943 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,16,9,1045,1,3,1028,1044,1024,0,1,0,16,2,9,17,1044,1029,17,1045,1024,1,5,0,1045,512]

theorem envBound15943 : H12AffineFastState.Bounded env15943 := by
  intro p hp
  have h : env15943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15942_15943 : H12AffineEnvironment.transform 10 1045 env15942 = env15943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env15942 == env15943) = true)

def env15944 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,16,9,1,1,3,16,0,20,0,1,0,16,2,9,17,0,17,17,1,20,1,5,0,1,512]

theorem envBound15944 : H12AffineFastState.Bounded env15944 := by
  intro p hp
  have h : env15944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15943_15944 : H12AffineEnvironment.transform 9 20 env15943 = env15944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env15943 == env15944) = true)

theorem identity15944 : scanCanonicalize (H12AffineFastState.compose env15944 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound15944 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15945 : List Nat := [2,4,8,5,0,4,8,5,512,1,1,5,9,1,1,3,5,0,1,0,1,0,5,2,9,4,0,4,4,1,1,1,5,0,1,512]

theorem envBound15945 : H12AffineFastState.Bounded env15945 := by
  intro p hp
  have h : env15945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15944_15945 : H12AffineEnvironment.transform 3 5 env15944 = env15945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env15944 == env15945) = true)

def leafEnv15945 : List Nat := [2,4,8,5,0,4,8,5,512,1,1,5,9,1,1,3,5,0,1,0,1,0,5,2,1,9,1,4,0,4,4,1,1,1,5,0,4,3,1,512,1,1,0]

def active15945 : List Nat := [0,1,2,8]

def tree15945 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15945 : H12WitnessSearch.Good tree15945 := H12GlobalWitnessIndex.good

theorem leafIdentity15945 : H12AffineFastState.composeSystem env15945 rootObs = leafEnv15945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15945 rootObs == leafEnv15945) = true)

theorem terminalChecked15945 : H12PackedTerminal.terminalCheckFast leafEnv15945 active15945 tree15945 = true := by decide +kernel

def env15946 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,0,1,3,17,1,21,0,1,0,16,2,9,17,1,16,17,0,21,1,5,0,0,512]

theorem envBound15946 : H12AffineFastState.Bounded env15946 := by
  intro p hp
  have h : env15946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15943_15946 : H12AffineEnvironment.transform 9 21 env15943 = env15946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15943 == env15946) = true)

theorem identity15946 : scanCanonicalize (H12AffineFastState.compose env15946 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound15946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15947 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,16,9,0,1,3,17,1,21,0,1,0,16,2,9,17,1,16,17,0,21,1,5,0,0,31]

theorem envBound15947 : H12AffineFastState.Bounded env15947 := by
  intro p hp
  have h : env15947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15946_15947 : H12AffineEnvironment.transform 8 31 env15946 = env15947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env15946 == env15947) = true)

def leafEnv15947 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,16,9,0,1,3,17,1,21,0,1,0,16,2,21,9,1,17,1,16,17,0,21,1,5,0,4,3,0,31,1,1,0]

def active15947 : List Nat := [0,1,2,3]

def tree15947 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15947 : H12WitnessSearch.Good tree15947 := H12GlobalWitnessIndex.good

theorem leafIdentity15947 : H12AffineFastState.composeSystem env15947 rootObs = leafEnv15947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15947 rootObs == leafEnv15947) = true)

theorem terminalChecked15947 : H12PackedTerminal.terminalCheckFast leafEnv15947 active15947 tree15947 = true := by decide +kernel

def env15948 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,9,1044,1,3,1029,2049,1024,0,0,0,16,2,9,17,2049,1028,16,2048,1024,1,5,0,1044,512]

theorem envBound15948 : H12AffineFastState.Bounded env15948 := by
  intro p hp
  have h : env15948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15941_15948 : H12AffineEnvironment.transform 11 17 env15941 = env15948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15941 == env15948) = true)

theorem identity15948 : scanCanonicalize (H12AffineFastState.compose env15948 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15948 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15949 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,17,9,1044,1,3,1029,1,1024,0,0,0,16,2,9,17,1,1028,16,0,1024,1,5,0,1044,512]

theorem envBound15949 : H12AffineFastState.Bounded env15949 := by
  intro p hp
  have h : env15949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15948_15949 : H12AffineEnvironment.transform 10 0 env15948 = env15949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15948 == env15949) = true)

def env15950 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,9,0,1,3,17,1,20,0,0,0,16,2,9,17,1,16,16,0,20,1,5,0,0,512]

theorem envBound15950 : H12AffineFastState.Bounded env15950 := by
  intro p hp
  have h : env15950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15949_15950 : H12AffineEnvironment.transform 9 20 env15949 = env15950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env15949 == env15950) = true)

theorem identity15950 : scanCanonicalize (H12AffineFastState.compose env15950 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound15950 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15951 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,1,3,4,1,1,0,0,0,5,2,9,4,1,5,5,0,1,1,5,0,0,512]

theorem envBound15951 : H12AffineFastState.Bounded env15951 := by
  intro p hp
  have h : env15951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15950_15951 : H12AffineEnvironment.transform 3 5 env15950 = env15951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env15950 == env15951) = true)

def leafEnv15951 : List Nat := [2,4,8,5,0,4,8,5,512,1,0,4,9,0,1,3,4,1,1,0,0,0,5,2,1,9,1,4,1,5,5,0,1,1,5,0,4,3,0,512,1,0,0]

def active15951 : List Nat := [0,1,2,8]

def tree15951 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15951 : H12WitnessSearch.Good tree15951 := H12GlobalWitnessIndex.good

theorem leafIdentity15951 : H12AffineFastState.composeSystem env15951 rootObs = leafEnv15951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15951 rootObs == leafEnv15951) = true)

theorem terminalChecked15951 : H12PackedTerminal.terminalCheckFast leafEnv15951 active15951 tree15951 = true := by decide +kernel

def env15952 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,1,3,16,1,21,0,0,0,16,2,9,17,1,17,16,0,21,1,5,0,1,512]

theorem envBound15952 : H12AffineFastState.Bounded env15952 := by
  intro p hp
  have h : env15952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15949_15952 : H12AffineEnvironment.transform 9 21 env15949 = env15952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15949 == env15952) = true)

theorem identity15952 : scanCanonicalize (H12AffineFastState.compose env15952 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound15952 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15953 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,9,1,1,3,16,1,21,0,0,0,16,2,9,17,1,17,16,0,21,1,5,0,1,31]

theorem envBound15953 : H12AffineFastState.Bounded env15953 := by
  intro p hp
  have h : env15953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15952_15953 : H12AffineEnvironment.transform 8 31 env15952 = env15953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env15952 == env15953) = true)

def leafEnv15953 : List Nat := [2,4,8,16,0,17,8,5,31,21,0,17,9,1,1,3,16,1,21,0,0,0,16,2,21,9,1,17,1,17,16,0,21,1,5,0,4,3,1,31,1,0,0]

def active15953 : List Nat := [0,1,2,3]

def tree15953 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15953 : H12WitnessSearch.Good tree15953 := H12GlobalWitnessIndex.good

theorem leafIdentity15953 : H12AffineFastState.composeSystem env15953 rootObs = leafEnv15953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15953 rootObs == leafEnv15953) = true)

theorem terminalChecked15953 : H12PackedTerminal.terminalCheckFast leafEnv15953 active15953 tree15953 = true := by decide +kernel

def env15954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,32,17,98644,8192,64,398436,5393,4097,431376,1365,41340,256,32,46093,74251]

theorem envBound15954 : H12AffineFastState.Bounded env15954 := by
  intro p hp
  have h : env15954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15932_15954 : H12AffineEnvironment.transform 20 4161 env15932 = env15954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15932 == env15954) = true)

theorem identity15954 : scanCanonicalize (H12AffineFastState.compose env15954 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound15954 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,4161,32,17,98644,8192,64,245018,5393,4097,212078,1365,41340,256,32,46093,74251]

theorem envBound15955 : H12AffineFastState.Bounded env15955 := by
  intro p hp
  have h : env15955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15954_15955 : H12AffineEnvironment.transform 17 108926 env15954 = env15955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env15954 == env15955) = true)

theorem identity15955 : scanCanonicalize (H12AffineFastState.compose env15955 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15955 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,131072,35188,1024,32769,4161,32,17,41310,8192,64,171280,5393,4097,138340,1365,41340,256,32,46093,513]

theorem envBound15956 : H12AffineFastState.Bounded env15956 := by
  intro p hp
  have h : env15956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15955_15956 : H12AffineEnvironment.transform 15 8202 env15955 = env15956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15955 == env15956) = true)

theorem identity15956 : scanCanonicalize (H12AffineFastState.compose env15956 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 12637) := by decide +kernel

theorem selectedBound15956 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,12637,35188,1024,32769,4161,32,17,41310,8192,64,44109,5393,4097,11577,1365,41340,256,32,46093,513]

theorem envBound15957 : H12AffineFastState.Bounded env15957 := by
  intro p hp
  have h : env15957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15956_15957 : H12AffineEnvironment.transform 16 12637 env15956 = env15957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12637 env15956 == env15957) = true)

theorem identity15957 : scanCanonicalize (H12AffineFastState.compose env15957 (packedSelected [0,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound15957 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env15958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,32768,1095,5392,35188,1024,32769,4161,32,17,34067,1101,64,34816,5393,4097,2420,1365,34097,256,32,36928,513]

theorem envBound15958 : H12AffineFastState.Bounded env15958 := by
  intro p hp
  have h : env15958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15957_15958 : H12AffineEnvironment.transform 12 1101 env15957 = env15958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env15957 == env15958) = true)

theorem identity15958 : scanCanonicalize (H12AffineFastState.compose env15958 (packedSelected [0,1,2,3,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 5685) := by decide +kernel

theorem selectedBound15958 : packedSelected [0,1,2,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,5685,1095,5392,8001,1024,5684,4161,32,17,4902,1101,64,7733,5393,4097,2420,1365,4868,256,32,1653,513]

theorem envBound15959 : H12AffineFastState.Bounded env15959 := by
  intro p hp
  have h : env15959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15958_15959 : H12AffineEnvironment.transform 14 5685 env15958 = env15959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5685 env15958 == env15959) = true)

def env15960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,2097152,32,2101329,98644,8193,64,2491429,2098513,4097,2524497,2102549,2142525,256,33,46092,2175562]

theorem envBound15960 : H12AffineFastState.Bounded env15960 := by
  intro p hp
  have h : env15960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15931_15960 : H12AffineEnvironment.transform 6 9 env15931 = env15960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15931 == env15960) = true)

def env15961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,32,17,98644,8193,64,398437,5393,4097,431377,1365,41341,256,33,46092,74250]

theorem envBound15961 : H12AffineFastState.Bounded env15961 := by
  intro p hp
  have h : env15961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15960_15961 : H12AffineEnvironment.transform 20 4160 env15960 = env15961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15960 == env15961) = true)

theorem identity15961 : scanCanonicalize (H12AffineFastState.compose env15961 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound15961 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,4160,32,17,98644,8193,64,203846,5393,4097,236850,1365,41341,256,33,46092,74250]

theorem envBound15962 : H12AffineFastState.Bounded env15962 := by
  intro p hp
  have h : env15962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15961_15962 : H12AffineEnvironment.transform 17 67619 env15961 = env15962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env15961 == env15962) = true)

theorem identity15962 : scanCanonicalize (H12AffineFastState.compose env15962 (packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15962 : packedSelected [1,3,8,9,12,18,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,10280,1024,32769,4160,32,17,41311,8193,64,146509,5393,4097,179513,1365,41341,256,33,46092,513]

theorem envBound15963 : H12AffineFastState.Bounded env15963 := by
  intro p hp
  have h : env15963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15962_15963 : H12AffineEnvironment.transform 15 8203 env15962 = env15963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15962 == env15963) = true)

theorem identity15963 : scanCanonicalize (H12AffineFastState.compose env15963 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15963 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,263,131072,2340,1024,32769,4160,32,17,32851,269,64,138561,5393,4097,171061,1365,32881,256,33,38144,513]

theorem envBound15964 : H12AffineFastState.Bounded env15964 := by
  intro p hp
  have h : env15964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15963_15964 : H12AffineEnvironment.transform 12 268 env15963 = env15964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15963 == env15964) = true)

theorem identity15964 : scanCanonicalize (H12AffineFastState.compose env15964 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound15964 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env15965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,32768,263,5441,2340,1024,32769,4160,32,17,32851,269,64,2048,5393,4097,35188,1365,32881,256,33,38144,513]

theorem envBound15965 : H12AffineFastState.Bounded env15965 := by
  intro p hp
  have h : env15965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15964_15965 : H12AffineEnvironment.transform 16 5441 env15964 = env15965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env15964 == env15965) = true)

def env15966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,32,16,98644,8193,64,398436,5392,4097,431376,1364,41340,256,33,46092,74251]

theorem envBound15966 : H12AffineFastState.Bounded env15966 := by
  intro p hp
  have h : env15966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15960_15966 : H12AffineEnvironment.transform 20 4161 env15960 = env15966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15960 == env15966) = true)

theorem identity15966 : scanCanonicalize (H12AffineFastState.compose env15966 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15966 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,32,16,41310,8193,64,398436,5392,4097,431376,1364,41340,256,33,46092,513]

theorem envBound15967 : H12AffineFastState.Bounded env15967 := by
  intro p hp
  have h : env15967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15966_15967 : H12AffineEnvironment.transform 15 8202 env15966 = env15967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15966 == env15967) = true)

theorem identity15967 : scanCanonicalize (H12AffineFastState.compose env15967 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15967 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,32,16,3,8193,64,398436,5392,4097,406605,1364,33,256,33,5457,513]

theorem envBound15968 : H12AffineFastState.Bounded env15968 := by
  intro p hp
  have h : env15968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15967_15968 : H12AffineEnvironment.transform 14 8541 env15967 = env15968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15967 == env15968) = true)

theorem identity15968 : scanCanonicalize (H12AffineFastState.compose env15968 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound15968 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,262144,1024,8540,4161,32,16,3,8193,64,262436,5392,4097,270605,1364,33,256,33,5457,513]

theorem envBound15969 : H12AffineFastState.Bounded env15969 := by
  intro p hp
  have h : env15969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15968_15969 : H12AffineEnvironment.transform 16 5440 env15968 = env15969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env15968 == env15969) = true)

theorem identity15969 : scanCanonicalize (H12AffineFastState.compose env15969 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound15969 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15970 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,10361,1024,8540,4161,32,16,3,8193,64,10589,5392,4097,2420,1364,33,256,33,5457,513]

theorem envBound15970 : H12AffineFastState.Bounded env15970 := by
  intro p hp
  have h : env15970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15969_15970 : H12AffineEnvironment.transform 17 10361 env15969 = env15970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env15969 == env15970) = true)

def env15971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98644,8328,64,2491428,2098648,4097,2524497,2102684,2142524,256,168,46213,2175562]

theorem envBound15971 : H12AffineFastState.Bounded env15971 := by
  intro p hp
  have h : env15971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15930_15971 : H12AffineEnvironment.transform 21 33 env15930 = env15971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env15930 == env15971) = true)

theorem identity15971 : scanCanonicalize (H12AffineFastState.compose env15971 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 4296) := by decide +kernel

theorem selectedBound15971 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,4296,33,16,98644,8328,64,398572,5392,4097,431513,1364,41460,256,168,46213,74370]

theorem envBound15972 : H12AffineFastState.Bounded env15972 := by
  intro p hp
  have h : env15972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15971_15972 : H12AffineEnvironment.transform 20 4296 env15971 = env15972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4296 env15971 == env15972) = true)

def env15973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,33,16,98644,8192,64,398436,5392,4097,431377,1364,41340,256,32,46093,74250]

theorem envBound15973 : H12AffineFastState.Bounded env15973 := by
  intro p hp
  have h : env15973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15972_15973 : H12AffineEnvironment.transform 6 8 env15972 = env15973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15972 == env15973) = true)

theorem identity15973 : scanCanonicalize (H12AffineFastState.compose env15973 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound15973 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4160,33,16,2,8192,64,398436,5392,4097,431377,1364,41340,256,32,46093,41820]

theorem envBound15974 : H12AffineFastState.Bounded env15974 := by
  intro p hp
  have h : env15974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15973_15974 : H12AffineEnvironment.transform 15 33110 env15973 = env15974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env15973 == env15974) = true)

theorem identity15974 : scanCanonicalize (H12AffineFastState.compose env15974 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound15974 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env15975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,46156,262144,1024,32769,4160,33,16,2,8192,64,303144,5392,4097,270685,1364,41340,256,32,46093,41820]

theorem envBound15975 : H12AffineFastState.Bounded env15975 := by
  intro p hp
  have h : env15975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15974_15975 : H12AffineEnvironment.transform 16 46156 env15974 = env15975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env15974 == env15975) = true)

theorem identity15975 : scanCanonicalize (H12AffineFastState.compose env15975 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15975 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env15976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,262144,1024,8540,4160,33,16,2,8192,64,262517,5392,4097,270685,1364,33,256,32,5456,513]

theorem envBound15976 : H12AffineFastState.Bounded env15976 := by
  intro p hp
  have h : env15976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15975_15976 : H12AffineEnvironment.transform 14 8541 env15975 = env15976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15975 == env15976) = true)

theorem identity15976 : scanCanonicalize (H12AffineFastState.compose env15976 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound15976 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10281,1024,8540,4160,33,16,2,8192,64,10588,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound15977 : H12AffineFastState.Bounded env15977 := by
  intro p hp
  have h : env15977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15976_15977 : H12AffineEnvironment.transform 17 10281 env15976 = env15977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15976 == env15977) = true)

theorem identity15977 : scanCanonicalize (H12AffineFastState.compose env15977 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound15977 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15978 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8,5376,341,3,5393,2081,1024,340,4160,33,16,2,8,64,2388,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound15978 : H12AffineFastState.Bounded env15978 := by
  intro p hp
  have h : env15978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15977_15978 : H12AffineEnvironment.transform 12 8 env15977 = env15978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env15977 == env15978) = true)

theorem identity15978 : scanCanonicalize (H12AffineFastState.compose env15978 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15978 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15979 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8,4113,341,3,4096,2081,273,340,4160,33,16,2,8,64,2388,4097,4097,2420,69,33,256,32,4161,513]

theorem envBound15979 : H12AffineFastState.Bounded env15979 := by
  intro p hp
  have h : env15979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15978_15979 : H12AffineEnvironment.transform 9 273 env15978 = env15979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15978 == env15979) = true)

theorem identity15979 : scanCanonicalize (H12AffineFastState.compose env15979 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound15979 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15980 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,4096,8,4113,48,3,4096,2081,116,49,4160,33,16,2,8,64,2097,4097,4097,2065,69,33,101,32,4161,513]

theorem envBound15980 : H12AffineFastState.Bounded env15980 := by
  intro p hp
  have h : env15980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15979_15980 : H12AffineEnvironment.transform 7 101 env15979 = env15980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env15979 == env15980) = true)

theorem identity15980 : scanCanonicalize (H12AffineFastState.compose env15980 (packedSelected [5] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound15980 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15981 : List Nat := [2,4,8,16,32,64,8,101,512,116,2048,528,8,513,48,3,528,2081,116,49,592,33,16,2,8,64,2097,529,529,2065,69,33,101,32,593,513]

theorem envBound15981 : H12AffineFastState.Bounded env15981 := by
  intro p hp
  have h : env15981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15980_15981 : H12AffineEnvironment.transform 11 528 env15980 = env15981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env15980 == env15981) = true)

theorem identity15981 : scanCanonicalize (H12AffineFastState.compose env15981 (packedSelected [0,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound15981 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env15982 : List Nat := [2,4,8,16,32,64,8,101,512,116,608,528,8,513,48,3,528,577,116,49,592,33,16,2,8,64,593,529,529,625,69,33,101,32,593,513]

theorem envBound15982 : H12AffineFastState.Bounded env15982 := by
  intro p hp
  have h : env15982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15981_15982 : H12AffineEnvironment.transform 10 608 env15981 = env15982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env15981 == env15982) = true)

theorem identity15982 : scanCanonicalize (H12AffineFastState.compose env15982 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15982 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env15983 : List Nat := [2,4,8,16,32,17,8,52,512,37,561,528,8,513,48,3,528,528,37,49,513,33,16,2,8,17,512,529,529,544,20,33,52,32,512,513]

theorem envBound15983 : H12AffineFastState.Bounded env15983 := by
  intro p hp
  have h : env15983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15982_15983 : H12AffineEnvironment.transform 5 17 env15982 = env15983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15982 == env15983) = true)

theorem identity15983 : scanCanonicalize (H12AffineFastState.compose env15983 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound15983 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15984 : List Nat := [2,4,8,16,32,17,8,52,1,37,48,17,8,0,48,3,17,17,37,49,0,33,16,2,8,17,1,16,16,33,20,33,52,32,1,0]

theorem envBound15984 : H12AffineFastState.Bounded env15984 := by
  intro p hp
  have h : env15984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15983_15984 : H12AffineEnvironment.transform 8 1 env15983 = env15984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env15983 == env15984) = true)

theorem identity15984 : scanCanonicalize (H12AffineFastState.compose env15984 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15984 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15985 : List Nat := [2,4,8,16,0,17,8,20,1,5,16,17,8,0,16,3,17,17,5,17,0,1,16,2,8,17,1,16,16,1,20,1,20,0,1,0]

theorem envBound15985 : H12AffineFastState.Bounded env15985 := by
  intro p hp
  have h : env15985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15984_15985 : H12AffineEnvironment.transform 4 0 env15984 = env15985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15984 == env15985) = true)

theorem identity15985 : scanCanonicalize (H12AffineFastState.compose env15985 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15985 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env15986 : List Nat := [2,4,8,0,0,1,8,4,1,5,0,1,8,0,0,3,1,1,5,1,0,1,0,2,8,1,1,0,0,1,4,1,4,0,1,0]

theorem envBound15986 : H12AffineFastState.Bounded env15986 := by
  intro p hp
  have h : env15986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15985_15986 : H12AffineEnvironment.transform 3 0 env15985 = env15986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15985 == env15986) = true)

def env15987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,33,16,98644,8193,64,398437,5392,4097,431376,1364,41341,256,33,46092,74251]

theorem envBound15987 : H12AffineFastState.Bounded env15987 := by
  intro p hp
  have h : env15987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15972_15987 : H12AffineEnvironment.transform 6 9 env15972 = env15987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15972 == env15987) = true)

theorem identity15987 : scanCanonicalize (H12AffineFastState.compose env15987 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15987 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8202,131072,262144,1024,32769,4161,33,16,41310,8193,64,398437,5392,4097,431376,1364,41341,256,33,46092,513]

theorem envBound15988 : H12AffineFastState.Bounded env15988 := by
  intro p hp
  have h : env15988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15987_15988 : H12AffineEnvironment.transform 15 8202 env15987 = env15988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15987 == env15988) = true)

theorem identity15988 : scanCanonicalize (H12AffineFastState.compose env15988 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15988 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env15989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,33,16,3,8193,64,398437,5392,4097,406605,1364,32,256,33,5457,513]

theorem envBound15989 : H12AffineFastState.Bounded env15989 := by
  intro p hp
  have h : env15989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15988_15989 : H12AffineEnvironment.transform 14 8541 env15988 = env15989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15988 == env15989) = true)

theorem identity15989 : scanCanonicalize (H12AffineFastState.compose env15989 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound15989 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,262144,1024,8540,4161,33,16,3,8193,64,262437,5392,4097,270605,1364,32,256,33,5457,513]

theorem envBound15990 : H12AffineFastState.Bounded env15990 := by
  intro p hp
  have h : env15990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15989_15990 : H12AffineEnvironment.transform 16 5440 env15989 = env15990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env15989 == env15990) = true)

theorem identity15990 : scanCanonicalize (H12AffineFastState.compose env15990 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound15990 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env15991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5440,2421,1024,8540,4161,33,16,3,8193,64,2128,5392,4097,10360,1364,32,256,33,5457,513]

theorem envBound15991 : H12AffineFastState.Bounded env15991 := by
  intro p hp
  have h : env15991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15990_15991 : H12AffineEnvironment.transform 17 2421 env15990 = env15991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env15990 == env15991) = true)

theorem identity15991 : scanCanonicalize (H12AffineFastState.compose env15991 (packedSelected [11,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15991 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env15992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5440,2421,1024,0,4161,33,16,3,349,64,2128,5392,4097,2340,1364,32,256,33,5457,513]

theorem envBound15992 : H12AffineFastState.Bounded env15992 := by
  intro p hp
  have h : env15992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15991_15992 : H12AffineEnvironment.transform 12 348 env15991 = env15992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15991 == env15992) = true)

theorem identity15992 : scanCanonicalize (H12AffineFastState.compose env15992 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound15992 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env15993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3077,348,2308,1,342,2373,2421,1024,0,3140,33,16,3,349,64,2128,2325,3076,2340,1364,32,256,33,2388,513]

theorem envBound15993 : H12AffineFastState.Bounded env15993 := by
  intro p hp
  have h : env15993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15992_15993 : H12AffineEnvironment.transform 11 3077 env15992 = env15993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env15992 == env15993) = true)

theorem identity15993 : scanCanonicalize (H12AffineFastState.compose env15993 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15993 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15994 : List Nat := [2,4,8,16,32,64,9,4,512,1024,2048,3077,88,2048,1,82,2113,2161,1024,0,3140,33,16,3,89,64,2128,2065,3076,2080,1104,32,4,33,2128,513]

theorem envBound15994 : H12AffineFastState.Bounded env15994 := by
  intro p hp
  have h : env15994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15993_15994 : H12AffineEnvironment.transform 7 4 env15993 = env15994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15993 == env15994) = true)

theorem identity15994 : scanCanonicalize (H12AffineFastState.compose env15994 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound15994 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env15995 : List Nat := [2,4,8,16,32,64,9,4,64,1024,2048,3077,88,2048,1,82,2113,2161,1024,0,3140,33,16,3,89,64,2128,2065,3076,2080,1104,32,4,33,2128,65]

theorem envBound15995 : H12AffineFastState.Bounded env15995 := by
  intro p hp
  have h : env15995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15994_15995 : H12AffineEnvironment.transform 8 64 env15994 = env15995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env15994 == env15995) = true)

theorem identity15995 : scanCanonicalize (H12AffineFastState.compose env15995 (packedSelected [0,4,10] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound15995 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env15996 : List Nat := [2,4,8,16,32,64,9,4,64,21,2048,2064,88,2048,1,82,2113,2161,21,0,2129,33,16,3,89,64,2128,2065,2065,2080,69,32,4,33,2128,65]

theorem envBound15996 : H12AffineFastState.Bounded env15996 := by
  intro p hp
  have h : env15996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15995_15996 : H12AffineEnvironment.transform 9 21 env15995 = env15996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env15995 == env15996) = true)

theorem identity15996 : scanCanonicalize (H12AffineFastState.compose env15996 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound15996 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env15997 : List Nat := [2,4,8,16,32,64,9,4,64,21,0,16,88,0,1,82,65,113,21,0,81,33,16,3,89,64,80,17,17,32,69,32,4,33,80,65]

theorem envBound15997 : H12AffineFastState.Bounded env15997 := by
  intro p hp
  have h : env15997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15996_15997 : H12AffineEnvironment.transform 10 0 env15996 = env15997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env15996 == env15997) = true)

theorem identity15997 : scanCanonicalize (H12AffineFastState.compose env15997 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound15997 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15998 : List Nat := [2,4,8,16,32,32,9,4,32,21,0,16,56,0,1,50,33,17,21,0,49,33,16,3,57,32,48,17,17,32,37,32,4,33,48,33]

theorem envBound15998 : H12AffineFastState.Bounded env15998 := by
  intro p hp
  have h : env15998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15997_15998 : H12AffineEnvironment.transform 5 32 env15997 = env15998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env15997 == env15998) = true)

theorem identity15998 : scanCanonicalize (H12AffineFastState.compose env15998 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound15998 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15999 : List Nat := [2,4,8,16,17,17,9,4,17,21,0,16,9,0,1,3,16,17,21,0,0,16,16,3,8,17,1,17,17,17,20,17,4,16,1,16]

theorem envBound15999 : H12AffineFastState.Bounded env15999 := by
  intro p hp
  have h : env15999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15998_15999 : H12AffineEnvironment.transform 4 17 env15998 = env15999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env15998 == env15999) = true)

theorem identity15999 : scanCanonicalize (H12AffineFastState.compose env15999 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15999 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16000 : List Nat := [2,4,8,0,1,1,9,4,1,5,0,0,9,0,1,3,0,1,5,0,0,0,0,3,8,1,1,1,1,1,4,1,4,0,1,0]

theorem envBound16000 : H12AffineFastState.Bounded env16000 := by
  intro p hp
  have h : env16000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15999_16000 : H12AffineEnvironment.transform 3 0 env15999 = env16000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15999 == env16000) = true)

def env16001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98645,8328,64,6685701,2098649,4096,2524496,2102684,6336796,256,168,46213,2175562]

theorem envBound16001 : H12AffineFastState.Bounded env16001 := by
  intro p hp
  have h : env16001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15929_16001 : H12AffineEnvironment.transform 22 2101465 env15929 = env16001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env15929 == env16001) = true)

def env16002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98645,8328,64,2491429,2098649,4096,2524496,2102684,2142524,256,168,46213,2175562]

theorem envBound16002 : H12AffineFastState.Bounded env16002 := by
  intro p hp
  have h : env16002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16001_16002 : H12AffineEnvironment.transform 21 32 env16001 = env16002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16001 == env16002) = true)

theorem identity16002 : scanCanonicalize (H12AffineFastState.compose env16002 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16002 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,262144,1024,8540,2097152,32,2101465,73736,8328,64,2491429,2098649,4096,2499597,2102684,2101345,256,168,5592,2175562]

theorem envBound16003 : H12AffineFastState.Bounded env16003 := by
  intro p hp
  have h : env16003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16002_16003 : H12AffineEnvironment.transform 14 8541 env16002 = env16003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16002 == env16003) = true)

def env16004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10400,1024,8540,2097152,32,2101465,73736,8328,64,2239621,2098649,4096,2231469,2102684,2101345,256,168,5592,2175562]

theorem envBound16004 : H12AffineFastState.Bounded env16004 := by
  intro p hp
  have h : env16004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16003_16004 : H12AffineEnvironment.transform 17 10400 env16003 = env16004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16003 == env16004) = true)

theorem identity16004 : scanCanonicalize (H12AffineFastState.compose env16004 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound16004 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8322,131072,10400,1024,8540,2097152,32,2101465,138,8328,64,2239621,2098649,4096,2231469,2102684,2101345,256,168,5592,2101960]

theorem envBound16005 : H12AffineFastState.Bounded env16005 := by
  intro p hp
  have h : env16005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16004_16005 : H12AffineEnvironment.transform 15 8322 env16004 = env16005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env16004 == env16005) = true)

theorem identity16005 : scanCanonicalize (H12AffineFastState.compose env16005 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound16005 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env16006 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8322,5392,10400,1024,8540,2097152,32,2101465,138,8328,64,2111893,2098649,4096,2103741,2102684,2101345,256,168,5592,2101960]

theorem envBound16006 : H12AffineFastState.Bounded env16006 := by
  intro p hp
  have h : env16006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16005_16006 : H12AffineEnvironment.transform 16 5392 env16005 = env16006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env16005 == env16006) = true)

theorem identity16006 : scanCanonicalize (H12AffineFastState.compose env16006 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16006 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env16007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,80,399,5392,2477,1024,81,2097152,32,2101465,138,389,64,2103448,2098649,4096,2103741,2102684,2101345,256,168,5592,2101960]

theorem envBound16007 : H12AffineFastState.Bounded env16007 := by
  intro p hp
  have h : env16007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16006_16007 : H12AffineEnvironment.transform 12 269 env16006 = env16007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16006 == env16007) = true)

theorem identity16007 : scanCanonicalize (H12AffineFastState.compose env16007 (packedSelected [10,11,12,14,15,16,18,19] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound16007 : packedSelected [10,11,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env16008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,80,399,5392,2477,1024,81,4161,32,152,138,389,64,2265,5528,4096,2556,1501,32,256,168,5592,649]

theorem envBound16008 : H12AffineFastState.Bounded env16008 := by
  intro p hp
  have h : env16008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16007_16008 : H12AffineEnvironment.transform 20 4161 env16007 = env16008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env16007 == env16008) = true)

theorem identity16008 : scanCanonicalize (H12AffineFastState.compose env16008 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound16008 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16009 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,4096,269,4404,80,399,4524,2477,188,81,4161,32,152,138,389,64,2265,4388,4096,2556,353,32,256,168,4452,649]

theorem envBound16009 : H12AffineFastState.Bounded env16009 := by
  intro p hp
  have h : env16009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16008_16009 : H12AffineEnvironment.transform 9 188 env16008 = env16009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env16008 == env16009) = true)

theorem identity16009 : scanCanonicalize (H12AffineFastState.compose env16009 (packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2248) := by decide +kernel

theorem selectedBound16009 : packedSelected [0,1,3,4,5,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env16010 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,2248,269,2556,80,399,2404,2477,188,81,2185,32,152,138,389,64,2265,2540,2248,2556,353,32,256,168,2476,649]

theorem envBound16010 : H12AffineFastState.Bounded env16010 := by
  intro p hp
  have h : env16010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16009_16010 : H12AffineEnvironment.transform 11 2248 env16009 = env16010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2248 env16009 == env16010) = true)

theorem identity16010 : scanCanonicalize (H12AffineFastState.compose env16010 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16010 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env16011 : List Nat := [2,4,8,16,32,64,128,37,512,188,2048,2248,40,2265,80,170,2113,2184,188,81,2185,32,152,138,160,64,2265,2249,2248,2265,68,32,37,168,2185,649]

theorem envBound16011 : H12AffineFastState.Bounded env16011 := by
  intro p hp
  have h : env16011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16010_16011 : H12AffineEnvironment.transform 7 37 env16010 = env16011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16010 == env16011) = true)

theorem identity16011 : scanCanonicalize (H12AffineFastState.compose env16011 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16011 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16012 : List Nat := [2,4,8,16,32,64,8,37,512,52,2048,2112,40,2129,80,34,2113,2048,52,81,2049,32,16,2,40,64,2129,2113,2112,2129,68,32,37,32,2049,513]

theorem envBound16012 : H12AffineFastState.Bounded env16012 := by
  intro p hp
  have h : env16012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16011_16012 : H12AffineEnvironment.transform 6 8 env16011 = env16012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16011 == env16012) = true)

theorem identity16012 : scanCanonicalize (H12AffineFastState.compose env16012 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16012 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16013 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2064,40,2049,0,34,2065,2048,52,1,2049,32,16,2,40,16,2049,2065,2064,2049,20,32,37,32,2049,513]

theorem envBound16013 : H12AffineFastState.Bounded env16013 := by
  intro p hp
  have h : env16013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16012_16013 : H12AffineEnvironment.transform 5 16 env16012 = env16013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16012 == env16013) = true)

theorem identity16013 : scanCanonicalize (H12AffineFastState.compose env16013 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound16013 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16014 : List Nat := [2,4,8,16,32,16,8,37,512,52,528,512,40,529,0,34,513,528,52,1,529,32,16,2,40,16,529,513,512,529,20,32,37,32,529,513]

theorem envBound16014 : H12AffineFastState.Bounded env16014 := by
  intro p hp
  have h : env16014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16013_16014 : H12AffineEnvironment.transform 10 528 env16013 = env16014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env16013 == env16014) = true)

theorem identity16014 : scanCanonicalize (H12AffineFastState.compose env16014 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound16014 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16015 : List Nat := [2,4,8,16,32,16,8,37,26,52,10,26,40,11,0,34,27,10,52,1,11,32,16,2,40,16,11,27,26,11,20,32,37,32,11,27]

theorem envBound16015 : H12AffineFastState.Bounded env16015 := by
  intro p hp
  have h : env16015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16014_16015 : H12AffineEnvironment.transform 8 26 env16014 = env16015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env16014 == env16015) = true)

def env16016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1024,8540,2097152,32,2101465,73736,8328,64,2239620,2098649,4096,2231468,2102684,2101345,256,168,5592,2175562]

theorem envBound16016 : H12AffineFastState.Bounded env16016 := by
  intro p hp
  have h : env16016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16003_16016 : H12AffineEnvironment.transform 17 10401 env16003 = env16016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16003 == env16016) = true)

theorem identity16016 : scanCanonicalize (H12AffineFastState.compose env16016 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound16016 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,131072,10401,1024,8540,77899,32,73874,73736,8328,64,203983,79250,4096,212199,75223,73770,256,168,5592,513]

theorem envBound16017 : H12AffineFastState.Bounded env16017 := by
  intro p hp
  have h : env16017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16016_16017 : H12AffineEnvironment.transform 20 77899 env16016 = env16017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env16016 == env16017) = true)

theorem identity16017 : scanCanonicalize (H12AffineFastState.compose env16017 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound16017 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env16018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,65536,13509,10401,1024,8540,77899,32,73874,73736,8328,64,75786,79250,4096,67618,75223,73770,256,168,5592,513]

theorem envBound16018 : H12AffineFastState.Bounded env16018 := by
  intro p hp
  have h : env16018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16017_16018 : H12AffineEnvironment.transform 16 13509 env16017 = env16018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env16017 == env16018) = true)

theorem identity16018 : scanCanonicalize (H12AffineFastState.compose env16018 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound16018 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env16019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,65536,5393,2421,1024,136,70047,32,65862,66012,348,64,68062,70726,4096,67618,66563,66046,256,168,5592,513]

theorem envBound16019 : H12AffineFastState.Bounded env16019 := by
  intro p hp
  have h : env16019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16018_16019 : H12AffineEnvironment.transform 12 468 env16018 = env16019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env16018 == env16019) = true)

theorem identity16019 : scanCanonicalize (H12AffineFastState.compose env16019 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound16019 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env16020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,137,478,5393,2421,1024,136,4161,32,152,2,348,64,2048,5528,4096,2556,1501,32,256,168,5592,513]

theorem envBound16020 : H12AffineFastState.Bounded env16020 := by
  intro p hp
  have h : env16020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16019_16020 : H12AffineEnvironment.transform 15 478 env16019 = env16020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env16019 == env16020) = true)

theorem identity16020 : scanCanonicalize (H12AffineFastState.compose env16020 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound16020 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env16021 : List Nat := [2,4,8,16,32,48,128,256,512,1024,2048,4096,420,5512,137,430,5393,2309,1024,136,4145,32,152,2,300,48,2048,5528,4096,2444,1453,32,256,168,5544,513]

theorem envBound16021 : H12AffineFastState.Bounded env16021 := by
  intro p hp
  have h : env16021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16020_16021 : H12AffineEnvironment.transform 5 48 env16020 = env16021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env16020 == env16021) = true)

theorem identity16021 : scanCanonicalize (H12AffineFastState.compose env16021 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16021 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env16022 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,301,5377,0,295,5393,2309,1024,1,4145,32,17,2,300,48,2048,5393,4096,2309,1316,32,256,33,5409,513]

theorem envBound16022 : H12AffineFastState.Bounded env16022 := by
  intro p hp
  have h : env16022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16021_16022 : H12AffineEnvironment.transform 6 9 env16021 = env16022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16021 == env16022) = true)

theorem identity16022 : scanCanonicalize (H12AffineFastState.compose env16022 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound16022 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16023 : List Nat := [2,4,8,16,32,48,9,256,260,1024,2048,4096,301,5377,0,295,5393,2309,1024,1,4145,32,17,2,300,48,2048,5393,4096,2309,1316,32,256,33,5409,261]

theorem envBound16023 : H12AffineFastState.Bounded env16023 := by
  intro p hp
  have h : env16023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16022_16023 : H12AffineEnvironment.transform 8 260 env16022 = env16023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env16022 == env16023) = true)

def env16024 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98645,8328,64,2491428,2098649,4096,2524496,2102684,2142525,256,168,46213,2175562]

theorem envBound16024 : H12AffineFastState.Bounded env16024 := by
  intro p hp
  have h : env16024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16001_16024 : H12AffineEnvironment.transform 21 33 env16001 = env16024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env16001 == env16024) = true)

theorem identity16024 : scanCanonicalize (H12AffineFastState.compose env16024 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 45460) := by decide +kernel

theorem selectedBound16024 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,45460,33,41293,98645,8328,64,439728,46157,4096,406724,41992,169,256,168,46213,99294]

theorem envBound16025 : H12AffineFastState.Bounded env16025 := by
  intro p hp
  have h : env16025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16024_16025 : H12AffineEnvironment.transform 20 45460 env16024 = env16025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 45460 env16024 == env16025) = true)

theorem identity16025 : scanCanonicalize (H12AffineFastState.compose env16025 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound16025 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,108926,1024,32769,45460,33,41293,98645,8328,64,203982,46157,4096,236986,41992,169,256,168,46213,99294]

theorem envBound16026 : H12AffineFastState.Bounded env16026 := by
  intro p hp
  have h : env16026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16025_16026 : H12AffineEnvironment.transform 17 108926 env16025 = env16026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env16025 == env16026) = true)

theorem identity16026 : scanCanonicalize (H12AffineFastState.compose env16026 (packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound16026 : packedSelected [1,3,4,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env16027 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,131072,10401,1024,32769,45460,33,41293,138,8328,64,171281,46157,4096,138341,41992,169,256,168,46213,513]

theorem envBound16027 : H12AffineFastState.Bounded env16027 := by
  intro p hp
  have h : env16027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16026_16027 : H12AffineEnvironment.transform 15 33247 env16026 = env16027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env16026 == env16027) = true)

theorem identity16027 : scanCanonicalize (H12AffineFastState.compose env16027 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound16027 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env16028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,13340,10401,1024,32769,45460,33,41293,138,8328,64,43277,46157,4096,10361,41992,169,256,168,46213,513]

theorem envBound16028 : H12AffineFastState.Bounded env16028 := by
  intro p hp
  have h : env16028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16027_16028 : H12AffineEnvironment.transform 16 13340 env16027 = env16028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env16027 == env16028) = true)

theorem identity16028 : scanCanonicalize (H12AffineFastState.compose env16028 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16028 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env16029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5512,32768,33247,5392,2477,1024,32769,37016,33,32833,138,388,64,34817,38209,4096,2421,34052,169,256,168,38281,513]

theorem envBound16029 : H12AffineFastState.Bounded env16029 := by
  intro p hp
  have h : env16029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16028_16029 : H12AffineEnvironment.transform 12 268 env16028 = env16029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16028 == env16029) = true)

def env16030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588557,8328,64,6685701,8393985,10485976,8820104,2102685,12624325,256,168,46212,2175563]

theorem envBound16030 : H12AffineFastState.Bounded env16030 := by
  intro p hp
  have h : env16030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15928_16030 : H12AffineEnvironment.transform 13 5513 env15928 = env16030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env15928 == env16030) = true)

def env16031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101464,98645,8328,64,6685701,2098649,4096,2524496,2102685,6336797,256,168,46212,2175563]

theorem envBound16031 : H12AffineFastState.Bounded env16031 := by
  intro p hp
  have h : env16031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16030_16031 : H12AffineEnvironment.transform 22 2101464 env16030 = env16031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101464 env16030 == env16031) = true)

def env16032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101464,98645,8328,64,2491429,2098649,4096,2524496,2102685,2142525,256,168,46212,2175563]

theorem envBound16032 : H12AffineFastState.Bounded env16032 := by
  intro p hp
  have h : env16032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16031_16032 : H12AffineEnvironment.transform 21 32 env16031 = env16032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16031 == env16032) = true)

theorem identity16032 : scanCanonicalize (H12AffineFastState.compose env16032 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 102679) := by decide +kernel

theorem selectedBound16032 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,102679,32,98767,98645,8328,64,496946,103630,4096,463943,99466,73770,256,168,46212,41820]

theorem envBound16033 : H12AffineFastState.Bounded env16033 := by
  intro p hp
  have h : env16033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16032_16033 : H12AffineEnvironment.transform 20 102679 env16032 = env16033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 102679 env16032 == env16033) = true)

theorem identity16033 : scanCanonicalize (H12AffineFastState.compose env16033 (packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16033 : packedSelected [1,3,4,7,9,10,11,12,14,15,16,18,19,20,21,23,24,26,27,28,31,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env16034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,262144,1024,8540,77898,32,73874,73736,8328,64,472175,79251,4096,463943,75223,73770,256,168,5593,513]

theorem envBound16034 : H12AffineFastState.Bounded env16034 := by
  intro p hp
  have h : env16034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16033_16034 : H12AffineEnvironment.transform 14 8541 env16033 = env16034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16033 == env16034) = true)

def env16035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10400,1024,8540,77898,32,73874,73736,8328,64,203983,79251,4096,212199,75223,73770,256,168,5593,513]

theorem envBound16035 : H12AffineFastState.Bounded env16035 := by
  intro p hp
  have h : env16035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16034_16035 : H12AffineEnvironment.transform 17 10400 env16034 = env16035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env16034 == env16035) = true)

theorem identity16035 : scanCanonicalize (H12AffineFastState.compose env16035 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound16035 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8322,131072,10400,1024,8540,4296,32,16,138,8328,64,146509,5393,4096,138341,1365,168,256,168,5593,513]

theorem envBound16036 : H12AffineFastState.Bounded env16036 := by
  intro p hp
  have h : env16036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16035_16036 : H12AffineEnvironment.transform 15 8322 env16035 = env16036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env16035 == env16036) = true)

theorem identity16036 : scanCanonicalize (H12AffineFastState.compose env16036 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound16036 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env16037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,5513,1124,1467,131072,3481,1024,1125,4296,32,16,138,1457,64,137588,5393,4096,138341,1365,168,256,168,5593,513]

theorem envBound16037 : H12AffineFastState.Bounded env16037 := by
  intro p hp
  have h : env16037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16036_16037 : H12AffineEnvironment.transform 12 1337 env16036 = env16037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env16036 == env16037) = true)

theorem identity16037 : scanCanonicalize (H12AffineFastState.compose env16037 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound16037 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env16038 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4112,509,34,131072,2048,409,508,4296,32,16,138,40,64,137588,4232,4096,137724,204,168,256,168,4160,513]

theorem envBound16038 : H12AffineFastState.Bounded env16038 := by
  intro p hp
  have h : env16038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16037_16038 : H12AffineEnvironment.transform 9 409 env16037 = env16038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env16037 == env16038) = true)

theorem identity16038 : scanCanonicalize (H12AffineFastState.compose env16038 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(16+1) ^^^ 4389) := by decide +kernel

theorem selectedBound16038 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16039 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,160,4112,509,34,4389,2048,409,508,4296,32,16,138,40,64,2129,4232,4096,2265,204,168,256,168,4160,513]

theorem envBound16039 : H12AffineFastState.Bounded env16039 := by
  intro p hp
  have h : env16039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16038_16039 : H12AffineEnvironment.transform 16 4389 env16038 = env16039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 4389 env16038 == env16039) = true)

theorem identity16039 : scanCanonicalize (H12AffineFastState.compose env16039 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound16039 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16040 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,17,160,1,509,34,308,2048,409,508,217,32,16,138,40,64,2129,153,17,2265,204,168,256,168,81,513]

theorem envBound16040 : H12AffineFastState.Bounded env16040 := by
  intro p hp
  have h : env16040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16039_16040 : H12AffineEnvironment.transform 11 17 env16039 = env16040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env16039 == env16040) = true)

theorem identity16040 : scanCanonicalize (H12AffineFastState.compose env16040 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound16040 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env16041 : List Nat := [2,4,8,16,32,64,128,173,512,52,2048,17,160,1,80,34,153,2048,52,81,217,32,16,138,40,64,2129,153,17,2265,204,168,173,168,81,513]

theorem envBound16041 : H12AffineFastState.Bounded env16041 := by
  intro p hp
  have h : env16041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16040_16041 : H12AffineEnvironment.transform 7 173 env16040 = env16041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env16040 == env16041) = true)

theorem identity16041 : scanCanonicalize (H12AffineFastState.compose env16041 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound16041 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env16042 : List Nat := [2,4,8,16,32,64,128,173,512,52,1,17,160,1,80,34,153,1,52,81,217,32,16,138,40,64,80,153,17,216,204,168,173,168,81,513]

theorem envBound16042 : H12AffineFastState.Bounded env16042 := by
  intro p hp
  have h : env16042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16041_16042 : H12AffineEnvironment.transform 10 1 env16041 = env16042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env16041 == env16042) = true)

theorem identity16042 : scanCanonicalize (H12AffineFastState.compose env16042 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16042 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env16043 : List Nat := [2,4,8,16,32,64,8,37,512,52,1,17,40,1,80,34,17,1,52,81,81,32,16,2,40,64,80,17,17,80,68,32,37,32,81,513]

theorem envBound16043 : H12AffineFastState.Bounded env16043 := by
  intro p hp
  have h : env16043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16042_16043 : H12AffineEnvironment.transform 6 8 env16042 = env16043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16042 == env16043) = true)

theorem identity16043 : scanCanonicalize (H12AffineFastState.compose env16043 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16043 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16044 : List Nat := [2,4,8,16,32,16,8,37,512,52,1,17,40,1,0,34,17,1,52,1,1,32,16,2,40,16,0,17,17,0,20,32,37,32,1,513]

theorem envBound16044 : H12AffineFastState.Bounded env16044 := by
  intro p hp
  have h : env16044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16043_16044 : H12AffineEnvironment.transform 5 16 env16043 = env16044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16043 == env16044) = true)

theorem identity16044 : scanCanonicalize (H12AffineFastState.compose env16044 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16044 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16045 : List Nat := [2,4,8,16,32,16,8,37,32,52,1,17,40,1,0,34,17,1,52,1,1,32,16,2,40,16,0,17,17,0,20,32,37,32,1,33]

theorem envBound16045 : H12AffineFastState.Bounded env16045 := by
  intro p hp
  have h : env16045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16044_16045 : H12AffineEnvironment.transform 8 32 env16044 = env16045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16044 == env16045) = true)

theorem identity16045 : scanCanonicalize (H12AffineFastState.compose env16045 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16045 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16046 : List Nat := [2,4,8,16,1,16,8,4,1,21,1,17,9,1,0,3,17,1,21,1,1,1,16,2,9,16,0,17,17,0,20,1,4,1,1,0]

theorem envBound16046 : H12AffineFastState.Bounded env16046 := by
  intro p hp
  have h : env16046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16045_16046 : H12AffineEnvironment.transform 4 1 env16045 = env16046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16045 == env16046) = true)

def env16047 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10401,1024,8540,77898,32,73874,73736,8328,64,203982,79251,4096,212198,75223,73770,256,168,5593,513]

theorem envBound16047 : H12AffineFastState.Bounded env16047 := by
  intro p hp
  have h : env16047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16034_16047 : H12AffineEnvironment.transform 17 10401 env16034 = env16047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16034 == env16047) = true)

theorem identity16047 : scanCanonicalize (H12AffineFastState.compose env16047 (packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound16047 : packedSelected [0,1,7,8,10,12,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env16048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,13508,10401,1024,8540,77898,32,73874,73736,8328,64,75786,79251,4096,67618,75223,73770,256,168,5593,513]

theorem envBound16048 : H12AffineFastState.Bounded env16048 := by
  intro p hp
  have h : env16048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16047_16048 : H12AffineEnvironment.transform 16 13508 env16047 = env16048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env16047 == env16048) = true)

theorem identity16048 : scanCanonicalize (H12AffineFastState.compose env16048 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound16048 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env16049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,65536,5392,2421,1024,136,70046,32,65862,66012,348,64,68062,70727,4096,67618,66563,66046,256,168,5593,513]

theorem envBound16049 : H12AffineFastState.Bounded env16049 := by
  intro p hp
  have h : env16049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16048_16049 : H12AffineEnvironment.transform 12 468 env16048 = env16049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env16048 == env16049) = true)

theorem identity16049 : scanCanonicalize (H12AffineFastState.compose env16049 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound16049 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env16050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,478,5392,2421,1024,136,4160,32,152,2,348,64,2048,5529,4096,2556,1501,32,256,168,5593,513]

theorem envBound16050 : H12AffineFastState.Bounded env16050 := by
  intro p hp
  have h : env16050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16049_16050 : H12AffineEnvironment.transform 15 478 env16049 = env16050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env16049 == env16050) = true)

theorem identity16050 : scanCanonicalize (H12AffineFastState.compose env16050 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound16050 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env16051 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,300,5489,113,294,5392,2421,1024,112,4160,32,96,2,348,64,2048,5473,4096,2308,1317,32,256,80,5409,513]

theorem envBound16051 : H12AffineFastState.Bounded env16051 := by
  intro p hp
  have h : env16051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16050_16051 : H12AffineEnvironment.transform 6 120 env16050 = env16051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env16050 == env16051) = true)

theorem identity16051 : scanCanonicalize (H12AffineFastState.compose env16051 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound16051 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env16052 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,300,5376,0,294,5392,2308,1024,1,4145,32,17,2,301,49,2048,5392,4096,2308,1317,32,256,33,5409,513]

theorem envBound16052 : H12AffineFastState.Bounded env16052 := by
  intro p hp
  have h : env16052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16051_16052 : H12AffineEnvironment.transform 5 49 env16051 = env16052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env16051 == env16052) = true)

theorem identity16052 : scanCanonicalize (H12AffineFastState.compose env16052 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound16052 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16053 : List Nat := [2,4,8,16,32,49,9,256,260,1024,2048,4096,300,5376,0,294,5392,2308,1024,1,4145,32,17,2,301,49,2048,5392,4096,2308,1317,32,256,33,5409,261]

theorem envBound16053 : H12AffineFastState.Bounded env16053 := by
  intro p hp
  have h : env16053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16052_16053 : H12AffineEnvironment.transform 8 260 env16052 = env16053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env16052 == env16053) = true)

def env16054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101464,98645,8328,64,2491428,2098649,4096,2524496,2102685,2142524,256,168,46212,2175563]

theorem envBound16054 : H12AffineFastState.Bounded env16054 := by
  intro p hp
  have h : env16054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16031_16054 : H12AffineEnvironment.transform 21 33 env16031 = env16054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env16031 == env16054) = true)

theorem identity16054 : scanCanonicalize (H12AffineFastState.compose env16054 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound16054 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,262144,1024,32769,2097152,33,2101464,138,8328,64,2491428,2098649,4096,2524496,2102685,2142524,256,168,46212,2143124]

theorem envBound16055 : H12AffineFastState.Bounded env16055 := by
  intro p hp
  have h : env16055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16054_16055 : H12AffineEnvironment.transform 15 33247 env16054 = env16055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env16054 == env16055) = true)

theorem identity16055 : scanCanonicalize (H12AffineFastState.compose env16055 (packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 301364) := by decide +kernel

theorem selectedBound16055 : packedSelected [3,4,7,9,10,11,12,14,15,16,18,20,23,24,26,27,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env16056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,262144,1024,32769,301364,33,297452,138,8328,64,171280,302317,4096,138340,298153,272392,256,168,46212,273056]

theorem envBound16056 : H12AffineFastState.Bounded env16056 := by
  intro p hp
  have h : env16056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16055_16056 : H12AffineEnvironment.transform 20 301364 env16055 = env16056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301364 env16055 == env16056) = true)

theorem identity16056 : scanCanonicalize (H12AffineFastState.compose env16056 (packedSelected [0,3,5,8,9,12,15,16,19,20,22,23,26,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound16056 : packedSelected [0,3,5,8,9,12,15,16,19,20,22,23,26,27,28,32] rootPS < 2^1333 := by decide +kernel

def env16057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,10401,1024,32769,45461,33,41293,138,8328,64,171280,46156,4096,138340,41992,169,256,168,46212,513]

theorem envBound16057 : H12AffineFastState.Bounded env16057 := by
  intro p hp
  have h : env16057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16056_16057 : H12AffineEnvironment.transform 17 10401 env16056 = env16057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16056 == env16057) = true)

theorem identity16057 : scanCanonicalize (H12AffineFastState.compose env16057 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound16057 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env16058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,13341,10401,1024,32769,45461,33,41293,138,8328,64,43277,46156,4096,10361,41992,169,256,168,46212,513]

theorem envBound16058 : H12AffineFastState.Bounded env16058 := by
  intro p hp
  have h : env16058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16057_16058 : H12AffineEnvironment.transform 16 13341 env16057 = env16058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env16057 == env16058) = true)

theorem identity16058 : scanCanonicalize (H12AffineFastState.compose env16058 (packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16058 : packedSelected [0,1,7,8,10,11,14,15,16,20] rootPS < 2^1333 := by decide +kernel

def env16059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5513,32768,33247,5393,2477,1024,32769,37017,33,32833,138,388,64,34817,38208,4096,2421,34052,169,256,168,38280,513]

theorem envBound16059 : H12AffineFastState.Bounded env16059 := by
  intro p hp
  have h : env16059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16058_16059 : H12AffineEnvironment.transform 12 268 env16058 = env16059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16058 == env16059) = true)

def env16060 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,4194304,2101465,98644,8328,64,6685701,2098648,4097,2524497,2102685,6336796,256,168,46212,2175563]

theorem envBound16060 : H12AffineFastState.Bounded env16060 := by
  intro p hp
  have h : env16060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16030_16060 : H12AffineEnvironment.transform 22 2101465 env16030 = env16060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101465 env16030 == env16060) = true)

def env16061 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,32,2101465,98644,8328,64,2491429,2098648,4097,2524497,2102685,2142524,256,168,46212,2175563]

theorem envBound16061 : H12AffineFastState.Bounded env16061 := by
  intro p hp
  have h : env16061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16060_16061 : H12AffineEnvironment.transform 21 32 env16060 = env16061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env16060 == env16061) = true)

theorem identity16061 : scanCanonicalize (H12AffineFastState.compose env16061 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound16061 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16062 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,77898,32,73875,98644,8328,64,472175,79250,4097,505115,75223,98678,256,168,46212,513]

theorem envBound16062 : H12AffineFastState.Bounded env16062 := by
  intro p hp
  have h : env16062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16061_16062 : H12AffineEnvironment.transform 20 77898 env16061 = env16062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env16061 == env16062) = true)

def env16063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,32,73755,98644,8192,64,472175,79130,4097,505115,75103,98678,256,32,46092,513]

theorem envBound16063 : H12AffineFastState.Bounded env16063 := by
  intro p hp
  have h : env16063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16062_16063 : H12AffineEnvironment.transform 6 8 env16062 = env16063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16062 == env16063) = true)

theorem identity16063 : scanCanonicalize (H12AffineFastState.compose env16063 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound16063 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env16064 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,79131,262144,1024,32769,77898,32,73755,98644,8192,64,262516,79130,4097,294912,75103,98678,256,32,46092,513]

theorem envBound16064 : H12AffineFastState.Bounded env16064 := by
  intro p hp
  have h : env16064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16063_16064 : H12AffineEnvironment.transform 16 79131 env16063 = env16064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env16063 == env16064) = true)

theorem identity16064 : scanCanonicalize (H12AffineFastState.compose env16064 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound16064 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env16065 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,9293,65536,79131,262144,1024,9292,77898,32,73755,75033,8192,64,262516,79130,4097,271437,75103,75067,256,32,4161,513]

theorem envBound16065 : H12AffineFastState.Bounded env16065 := by
  intro p hp
  have h : env16065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16064_16065 : H12AffineEnvironment.transform 14 9293 env16064 = env16065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env16064 == env16065) = true)

theorem identity16065 : scanCanonicalize (H12AffineFastState.compose env16065 (packedSelected [3,5,10,12,21,38] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound16065 : packedSelected [3,5,10,12,21,38] rootPS < 2^1333 := by decide +kernel

def env16066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,373,65536,69667,262144,1024,372,71026,32,66851,65569,1336,64,262516,69666,4097,262517,65639,65539,256,32,4161,513]

theorem envBound16066 : H12AffineFastState.Bounded env16066 := by
  intro p hp
  have h : env16066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16065_16066 : H12AffineEnvironment.transform 12 1336 env16065 = env16066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env16065 == env16066) = true)

theorem identity16066 : scanCanonicalize (H12AffineFastState.compose env16066 (packedSelected [3,5,10,18,21,32] rootPS)) = affineNative (2^(17+1) ^^^ 3124) := by decide +kernel

theorem selectedBound16066 : packedSelected [3,5,10,18,21,32] rootPS < 2^1333 := by decide +kernel

def env16067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,373,65536,69667,3124,1024,372,71026,32,66851,65569,1336,64,3392,69666,4097,3393,65639,65539,256,32,4161,513]

theorem envBound16067 : H12AffineFastState.Bounded env16067 := by
  intro p hp
  have h : env16067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16066_16067 : H12AffineEnvironment.transform 17 3124 env16066 = env16067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3124 env16066 == env16067) = true)

theorem identity16067 : scanCanonicalize (H12AffineFastState.compose env16067 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound16067 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env16068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,5377,373,263,4388,3124,1024,372,5237,32,1060,294,1336,64,3392,4389,4097,3393,352,260,256,32,4161,513]

theorem envBound16068 : H12AffineFastState.Bounded env16068 := by
  intro p hp
  have h : env16068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16067_16068 : H12AffineEnvironment.transform 15 263 env16067 = env16068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env16067 == env16068) = true)

theorem identity16068 : scanCanonicalize (H12AffineFastState.compose env16068 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 884) := by decide +kernel

theorem selectedBound16068 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env16069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,884,1336,1653,373,263,592,3124,1024,372,1793,32,1060,294,1336,64,3392,593,885,3393,352,260,256,32,821,513]

theorem envBound16069 : H12AffineFastState.Bounded env16069 := by
  intro p hp
  have h : env16069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16068_16069 : H12AffineEnvironment.transform 11 884 env16068 = env16069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 884 env16068 == env16069) = true)

theorem identity16069 : scanCanonicalize (H12AffineFastState.compose env16069 (packedSelected [0,1,2,4,5,6,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound16069 : packedSelected [0,1,2,4,5,6,14] rootPS < 2^1333 := by decide +kernel

def env16070 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,884,348,529,373,263,592,2128,100,372,869,32,64,294,348,64,2340,593,885,2341,352,260,256,32,821,513]

theorem envBound16070 : H12AffineFastState.Bounded env16070 := by
  intro p hp
  have h : env16070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16069_16070 : H12AffineEnvironment.transform 9 100 env16069 = env16070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env16069 == env16070) = true)

theorem identity16070 : scanCanonicalize (H12AffineFastState.compose env16070 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16070 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env16071 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,592,120,529,81,35,592,2128,100,80,577,32,64,2,120,64,2048,593,593,2049,68,32,36,32,529,513]

theorem envBound16071 : H12AffineFastState.Bounded env16071 := by
  intro p hp
  have h : env16071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16070_16071 : H12AffineEnvironment.transform 7 36 env16070 = env16071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16070 == env16071) = true)

theorem identity16071 : scanCanonicalize (H12AffineFastState.compose env16071 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16071 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16072 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,512,40,529,1,35,512,2048,52,0,529,32,16,2,40,16,2048,513,513,2049,20,32,36,32,529,513]

theorem envBound16072 : H12AffineFastState.Bounded env16072 := by
  intro p hp
  have h : env16072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16071_16072 : H12AffineEnvironment.transform 5 16 env16071 = env16072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16071 == env16072) = true)

theorem identity16072 : scanCanonicalize (H12AffineFastState.compose env16072 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound16072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16073 : List Nat := [2,4,8,16,17,16,8,21,512,5,2048,512,25,529,1,18,512,2048,5,0,529,17,16,2,25,16,2048,513,513,2049,20,17,21,17,529,513]

theorem envBound16073 : H12AffineFastState.Bounded env16073 := by
  intro p hp
  have h : env16073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16072_16073 : H12AffineEnvironment.transform 4 17 env16072 = env16073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env16072 == env16073) = true)

theorem identity16073 : scanCanonicalize (H12AffineFastState.compose env16073 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16074 : List Nat := [2,4,8,0,1,0,8,5,512,5,2048,512,9,513,1,2,512,2048,5,0,513,1,0,2,9,0,2048,513,513,2049,4,1,5,1,513,513]

theorem envBound16074 : H12AffineFastState.Bounded env16074 := by
  intro p hp
  have h : env16074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16073_16074 : H12AffineEnvironment.transform 3 0 env16073 = env16074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16073 == env16074) = true)

theorem identity16074 : scanCanonicalize (H12AffineFastState.compose env16074 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound16074 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16075 : List Nat := [2,4,8,0,1,0,8,5,512,5,513,512,9,513,1,2,512,513,5,0,513,1,0,2,9,0,513,513,513,512,4,1,5,1,513,513]

theorem envBound16075 : H12AffineFastState.Bounded env16075 := by
  intro p hp
  have h : env16075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16074_16075 : H12AffineEnvironment.transform 10 513 env16074 = env16075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env16074 == env16075) = true)

def env16076 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77898,32,73754,98644,8193,64,472175,79131,4097,505115,75102,98678,256,33,46093,513]

theorem envBound16076 : H12AffineFastState.Bounded env16076 := by
  intro p hp
  have h : env16076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16062_16076 : H12AffineEnvironment.transform 6 9 env16062 = env16076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16062 == env16076) = true)

theorem identity16076 : scanCanonicalize (H12AffineFastState.compose env16076 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound16076 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env16077 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,131072,262144,1024,32769,45341,32,41293,3,8193,64,439608,46156,4097,406604,41993,33,256,33,46093,513]

theorem envBound16077 : H12AffineFastState.Bounded env16077 := by
  intro p hp
  have h : env16077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16076_16077 : H12AffineEnvironment.transform 15 33111 env16076 = env16077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env16076 == env16077) = true)

theorem identity16077 : scanCanonicalize (H12AffineFastState.compose env16077 (packedSelected [2,6,21] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound16077 : packedSelected [2,6,21] rootPS < 2^1333 := by decide +kernel

def env16078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,33111,46108,262144,1024,32769,45341,32,41293,3,8193,64,262436,46156,4097,294992,41993,33,256,33,46093,513]

theorem envBound16078 : H12AffineFastState.Bounded env16078 := by
  intro p hp
  have h : env16078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16077_16078 : H12AffineEnvironment.transform 16 46108 env16077 = env16078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env16077 == env16078) = true)

theorem identity16078 : scanCanonicalize (H12AffineFastState.compose env16078 (packedSelected [3,10,18,19,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound16078 : packedSelected [3,10,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env16079 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,343,13340,262144,1024,1,12573,32,8525,3,8193,64,262436,13388,4097,262224,9225,33,256,33,13325,513]

theorem envBound16079 : H12AffineFastState.Bounded env16079 := by
  intro p hp
  have h : env16079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16078_16079 : H12AffineEnvironment.transform 14 0 env16078 = env16079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env16078 == env16079) = true)

theorem identity16079 : scanCanonicalize (H12AffineFastState.compose env16079 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16079 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5440,262144,1024,1,4161,32,17,3,349,64,262436,5392,4097,262224,1365,33,256,33,5457,513]

theorem envBound16080 : H12AffineFastState.Bounded env16080 := by
  intro p hp
  have h : env16080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16079_16080 : H12AffineEnvironment.transform 12 348 env16079 = env16080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16079 == env16080) = true)

theorem identity16080 : scanCanonicalize (H12AffineFastState.compose env16080 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound16080 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16081 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5440,2420,1024,1,4161,32,17,3,349,64,2128,5392,4097,2340,1365,33,256,33,5457,513]

theorem envBound16081 : H12AffineFastState.Bounded env16081 := by
  intro p hp
  have h : env16081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16080_16081 : H12AffineEnvironment.transform 17 2420 env16080 = env16081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env16080 == env16081) = true)

theorem identity16081 : scanCanonicalize (H12AffineFastState.compose env16081 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound16081 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3328,348,2048,0,343,2112,2420,1024,1,3393,32,17,3,349,64,2128,2064,3329,2340,1365,33,256,33,2129,513]

theorem envBound16082 : H12AffineFastState.Bounded env16082 := by
  intro p hp
  have h : env16082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16081_16082 : H12AffineEnvironment.transform 11 3328 env16081 = env16082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env16081 == env16082) = true)

theorem identity16082 : scanCanonicalize (H12AffineFastState.compose env16082 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound16082 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env16083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1345,65,348,1345,0,343,1281,1077,1024,1,0,32,17,3,349,64,1297,1361,64,1125,1365,33,256,33,1296,513]

theorem envBound16083 : H12AffineFastState.Bounded env16083 := by
  intro p hp
  have h : env16083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16082_16083 : H12AffineEnvironment.transform 10 1345 env16082 = env16083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env16082 == env16083) = true)

theorem identity16083 : scanCanonicalize (H12AffineFastState.compose env16083 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound16083 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16084 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1077,65,40,1077,0,35,1141,1077,1024,1,0,32,17,3,41,64,1125,1061,64,1125,1057,33,116,33,1124,513]

theorem envBound16084 : H12AffineFastState.Bounded env16084 := by
  intro p hp
  have h : env16084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16083_16084 : H12AffineEnvironment.transform 7 116 env16083 = env16084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env16083 == env16084) = true)

def env16085 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,2097152,33,2101465,98644,8328,64,2491428,2098648,4097,2524497,2102685,2142525,256,168,46212,2175563]

theorem envBound16085 : H12AffineFastState.Bounded env16085 := by
  intro p hp
  have h : env16085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16060_16085 : H12AffineEnvironment.transform 21 33 env16060 = env16085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env16060 == env16085) = true)

theorem identity16085 : scanCanonicalize (H12AffineFastState.compose env16085 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound16085 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101465,41431,8328,64,2491428,2098648,4097,2524497,2102685,2142525,256,168,46212,2101960]

theorem envBound16086 : H12AffineFastState.Bounded env16086 := by
  intro p hp
  have h : env16086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16085_16086 : H12AffineEnvironment.transform 15 8323 env16085 = env16086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env16085 == env16086) = true)

def env16087 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101385,41351,8328,16,2491428,2098568,4097,2524417,2102685,2142525,256,168,46212,2101912]

theorem envBound16087 : H12AffineFastState.Bounded env16087 := by
  intro p hp
  have h : env16087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16086_16087 : H12AffineEnvironment.transform 5 16 env16086 = env16087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16086 == env16087) = true)

theorem identity16087 : scanCanonicalize (H12AffineFastState.compose env16087 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35244) := by decide +kernel

theorem selectedBound16087 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env16088 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35244,1024,32769,2097152,33,2101385,41351,8328,16,2264456,2098568,4097,2231469,2102685,2142525,256,168,46212,2101912]

theorem envBound16088 : H12AffineFastState.Bounded env16088 := by
  intro p hp
  have h : env16088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16087_16088 : H12AffineEnvironment.transform 17 35244 env16087 = env16088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35244 env16087 == env16088) = true)

theorem identity16088 : scanCanonicalize (H12AffineFastState.compose env16088 (packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 4249) := by decide +kernel

theorem selectedBound16088 : packedSelected [3,4,5,7,8,9,10,16,20,21,27,28,31] rootPS < 2^1333 := by decide +kernel

def env16089 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35244,1024,32769,4249,33,16,41351,8328,16,171281,5393,4097,138292,1284,41380,256,168,46212,513]

theorem envBound16089 : H12AffineFastState.Bounded env16089 := by
  intro p hp
  have h : env16089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16088_16089 : H12AffineEnvironment.transform 20 4249 env16088 = env16089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4249 env16088 == env16089) = true)

theorem identity16089 : scanCanonicalize (H12AffineFastState.compose env16089 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound16089 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env16090 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,32768,263,131072,35244,1024,32769,4249,33,16,32771,268,16,171281,5393,4097,138292,1284,32800,256,168,38144,513]

theorem envBound16090 : H12AffineFastState.Bounded env16090 := by
  intro p hp
  have h : env16090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16089_16090 : H12AffineEnvironment.transform 12 388 env16089 = env16090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env16089 == env16090) = true)

theorem identity16090 : scanCanonicalize (H12AffineFastState.compose env16090 (packedSelected [2,4,6,9,14,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound16090 : packedSelected [2,4,6,9,14,20,21] rootPS < 2^1333 := by decide +kernel

def env16091 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,137,263,131072,2341,1024,136,4249,33,16,138,268,16,138648,5393,4097,138292,1284,169,256,168,5513,513]

theorem envBound16091 : H12AffineFastState.Bounded env16091 := by
  intro p hp
  have h : env16091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16090_16091 : H12AffineEnvironment.transform 14 137 env16090 = env16091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env16090 == env16091) = true)

theorem identity16091 : scanCanonicalize (H12AffineFastState.compose env16091 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound16091 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16092 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5513,137,263,5528,2341,1024,136,4249,33,16,138,268,16,2048,5393,4097,2476,1284,169,256,168,5513,513]

theorem envBound16092 : H12AffineFastState.Bounded env16092 := by
  intro p hp
  have h : env16092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16091_16092 : H12AffineEnvironment.transform 16 5528 env16091 = env16092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env16091 == env16092) = true)

theorem identity16092 : scanCanonicalize (H12AffineFastState.compose env16092 (packedSelected [11] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16092 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env16093 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,0,263,5393,2341,1024,1,4112,33,16,3,268,16,2048,5393,4097,2341,1284,32,256,33,5376,513]

theorem envBound16093 : H12AffineFastState.Bounded env16093 := by
  intro p hp
  have h : env16093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16092_16093 : H12AffineEnvironment.transform 6 9 env16092 = env16093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16092 == env16093) = true)

theorem identity16093 : scanCanonicalize (H12AffineFastState.compose env16093 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound16093 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16094 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1077,269,309,0,263,292,2341,1024,1,1061,33,16,3,268,16,2048,292,1076,2341,1284,32,256,33,309,513]

theorem envBound16094 : H12AffineFastState.Bounded env16094 := by
  intro p hp
  have h : env16094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16093_16094 : H12AffineEnvironment.transform 11 1077 env16093 = env16094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env16093 == env16094) = true)

theorem identity16094 : scanCanonicalize (H12AffineFastState.compose env16094 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound16094 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16095 : List Nat := [2,4,8,16,32,16,9,256,512,1024,303,1077,269,309,0,263,292,10,1024,1,1061,33,16,3,268,16,303,292,1076,10,1284,32,256,33,309,513]

theorem envBound16095 : H12AffineFastState.Bounded env16095 := by
  intro p hp
  have h : env16095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16094_16095 : H12AffineEnvironment.transform 10 303 env16094 = env16095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env16094 == env16095) = true)

theorem identity16095 : scanCanonicalize (H12AffineFastState.compose env16095 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound16095 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16096 : List Nat := [2,4,8,16,32,16,9,256,512,5,303,48,269,309,0,263,292,10,5,1,32,33,16,3,268,16,303,292,49,10,257,32,256,33,309,513]

theorem envBound16096 : H12AffineFastState.Bounded env16096 := by
  intro p hp
  have h : env16096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16095_16096 : H12AffineEnvironment.transform 9 5 env16095 = env16096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env16095 == env16096) = true)

theorem identity16096 : scanCanonicalize (H12AffineFastState.compose env16096 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound16096 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16097 : List Nat := [2,4,8,16,32,16,9,14,512,5,33,48,3,59,0,9,42,10,5,1,32,33,16,3,2,16,33,42,49,10,15,32,14,33,59,513]

theorem envBound16097 : H12AffineFastState.Bounded env16097 := by
  intro p hp
  have h : env16097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16096_16097 : H12AffineEnvironment.transform 7 14 env16096 = env16097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env16096 == env16097) = true)

def env16098 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,262144,1024,32769,2097152,33,2101384,41350,8328,17,2491428,2098569,4097,2524416,2102685,2142525,256,168,46212,2101913]

theorem envBound16098 : H12AffineFastState.Bounded env16098 := by
  intro p hp
  have h : env16098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16086_16098 : H12AffineEnvironment.transform 5 17 env16086 = env16098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16086 == env16098) = true)

theorem identity16098 : scanCanonicalize (H12AffineFastState.compose env16098 (packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 35109) := by decide +kernel

theorem selectedBound16098 : packedSelected [0,1,9,12,15,19,22,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env16099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35109,1024,32769,2097152,33,2101384,41350,8328,17,2264321,2098569,4097,2231333,2102685,2142525,256,168,46212,2101913]

theorem envBound16099 : H12AffineFastState.Bounded env16099 := by
  intro p hp
  have h : env16099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16098_16099 : H12AffineEnvironment.transform 17 35109 env16098 = env16099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35109 env16098 == env16099) = true)

theorem identity16099 : scanCanonicalize (H12AffineFastState.compose env16099 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(20+1) ^^^ 132488) := by decide +kernel

theorem selectedBound16099 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16100 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,131072,35109,1024,32769,132488,33,136448,41350,8328,17,34953,131073,4097,2477,135189,177333,256,168,46212,136977]

theorem envBound16100 : H12AffineFastState.Bounded env16100 := by
  intro p hp
  have h : env16100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16099_16100 : H12AffineEnvironment.transform 20 132488 env16099 = env16100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 132488 env16099 == env16100) = true)

theorem identity16100 : scanCanonicalize (H12AffineFastState.compose env16100 (packedSelected [16,20] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound16100 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env16101 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,8323,5528,35109,1024,32769,4112,33,152,41350,8328,17,34953,5529,4097,2477,1421,41261,256,168,46212,649]

theorem envBound16101 : H12AffineFastState.Bounded env16101 := by
  intro p hp
  have h : env16101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16100_16101 : H12AffineEnvironment.transform 16 5528 env16100 = env16101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env16100 == env16101) = true)

theorem identity16101 : scanCanonicalize (H12AffineFastState.compose env16101 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound16101 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16102 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8460,8323,5528,10281,1024,8461,4112,33,152,138,8328,17,10629,5529,4097,2477,1421,33,256,168,5512,649]

theorem envBound16102 : H12AffineFastState.Bounded env16102 := by
  intro p hp
  have h : env16102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16101_16102 : H12AffineEnvironment.transform 14 8460 env16101 = env16102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env16101 == env16102) = true)

theorem identity16102 : scanCanonicalize (H12AffineFastState.compose env16102 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound16102 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16103 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,8192,4113,8460,8323,4096,10281,408,8461,4112,33,152,138,8328,17,10629,4097,4097,2477,21,33,256,168,4112,649]

theorem envBound16103 : H12AffineFastState.Bounded env16103 := by
  intro p hp
  have h : env16103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16102_16103 : H12AffineEnvironment.transform 9 408 env16102 = env16103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env16102 == env16103) = true)

theorem identity16103 : scanCanonicalize (H12AffineFastState.compose env16103 (packedSelected [1,3,4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound16103 : packedSelected [1,3,4,9,11] rootPS < 2^1333 := by decide +kernel

def env16104 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,4096,2721,4113,2989,2594,4096,648,408,2988,4112,33,152,138,2601,17,804,4097,4097,2477,21,33,256,168,4112,649]

theorem envBound16104 : H12AffineFastState.Bounded env16104 := by
  intro p hp
  have h : env16104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16103_16104 : H12AffineEnvironment.transform 12 2721 env16103 = env16104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env16103 == env16104) = true)

theorem identity16104 : scanCanonicalize (H12AffineFastState.compose env16104 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound16104 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env16105 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,529,2721,512,2989,2594,529,648,408,2988,513,33,152,138,2601,17,804,528,528,2477,21,33,256,168,513,649]

theorem envBound16105 : H12AffineFastState.Bounded env16105 := by
  intro p hp
  have h : env16105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16104_16105 : H12AffineEnvironment.transform 11 529 env16104 = env16105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env16104 == env16105) = true)

theorem identity16105 : scanCanonicalize (H12AffineFastState.compose env16105 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16105 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env16106 : List Nat := [2,4,8,16,16,17,128,256,512,408,2048,529,2705,512,2973,2578,529,648,408,2972,513,17,152,138,2585,17,788,528,528,2461,21,17,256,152,513,649]

theorem envBound16106 : H12AffineFastState.Bounded env16106 := by
  intro p hp
  have h : env16106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16105_16106 : H12AffineEnvironment.transform 4 16 env16105 = env16106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16105 == env16106) = true)

theorem identity16106 : scanCanonicalize (H12AffineFastState.compose env16106 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound16106 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16107 : List Nat := [2,4,8,16,16,17,128,256,512,408,276,529,901,512,649,774,529,648,408,648,513,17,152,138,781,17,788,528,528,137,21,17,256,152,513,649]

theorem envBound16107 : H12AffineFastState.Bounded env16107 := by
  intro p hp
  have h : env16107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16106_16107 : H12AffineEnvironment.transform 10 276 env16106 = env16107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env16106 == env16107) = true)

theorem identity16107 : scanCanonicalize (H12AffineFastState.compose env16107 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound16107 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env16108 : List Nat := [2,4,8,16,16,17,128,256,276,408,276,261,145,276,413,18,261,412,408,412,277,17,152,138,25,17,0,260,260,137,21,17,256,152,277,413]

theorem envBound16108 : H12AffineFastState.Bounded env16108 := by
  intro p hp
  have h : env16108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16107_16108 : H12AffineEnvironment.transform 8 276 env16107 = env16108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env16107 == env16108) = true)

theorem identity16108 : scanCanonicalize (H12AffineFastState.compose env16108 (packedSelected [1,2,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16108 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env16109 : List Nat := [2,4,8,1,1,0,128,256,261,393,261,261,128,261,396,3,261,397,393,397,260,0,137,138,8,0,0,260,260,137,4,0,256,137,260,396]

theorem envBound16109 : H12AffineFastState.Bounded env16109 := by
  intro p hp
  have h : env16109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16108_16109 : H12AffineEnvironment.transform 3 1 env16108 = env16109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16108 == env16109) = true)

theorem identity16109 : scanCanonicalize (H12AffineFastState.compose env16109 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 140) := by decide +kernel

theorem selectedBound16109 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env16110 : List Nat := [2,4,8,1,1,0,128,140,137,5,137,137,128,137,0,3,137,1,5,1,136,0,137,138,8,0,0,136,136,137,4,0,140,137,136,0]

theorem envBound16110 : H12AffineFastState.Bounded env16110 := by
  intro p hp
  have h : env16110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16109_16110 : H12AffineEnvironment.transform 7 140 env16109 = env16110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 140 env16109 == env16110) = true)

theorem identity16110 : scanCanonicalize (H12AffineFastState.compose env16110 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound16110 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16111 : List Nat := [2,4,8,1,1,0,8,4,1,5,1,1,8,1,0,3,1,1,5,1,0,0,1,2,8,0,0,0,0,1,4,0,4,1,0,0]

theorem envBound16111 : H12AffineFastState.Bounded env16111 := by
  intro p hp
  have h : env16111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16110_16111 : H12AffineEnvironment.transform 6 8 env16110 = env16111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16110 == env16111) = true)

def env16112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound16112 : H12AffineFastState.Bounded env16112 := by
  intro p hp
  have h : env16112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15926_16112 : H12AffineEnvironment.transform 18 1025 env15926 = env16112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env15926 == env16112) = true)

theorem identity16112 : scanCanonicalize (H12AffineFastState.compose env16112 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 140421) := by decide +kernel

theorem selectedBound16112 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env16113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,140421,4194304,8388608,16777216,8328,64,29868032,17014792,8548820,8830976,25265168,21184836,257,25419816,25362828,25207751]

end H12CloudChart1