import H12CloudChart1Data215

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env54696 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1055,4096,8,5124,1,2,5140,1054,1024,0,4113,1,17,3,8,16,1054,5140,4097,1054,1024,1,4,1,5125,512]

theorem envBound54696 : H12AffineFastState.Bounded env54696 := by
  intro p hp
  have h : env54696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54695_54696 : H12AffineEnvironment.transform 13 5124 env54695 = env54696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env54695 == env54696) = true)

theorem identity54696 : scanCanonicalize (H12AffineFastState.compose env54696 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound54696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54697 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1055,1045,8,17,1,2,1,1054,1024,0,1028,1,17,3,8,16,1054,1,1044,1054,1024,1,4,1,16,512]

theorem envBound54697 : H12AffineFastState.Bounded env54697 := by
  intro p hp
  have h : env54697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54696_54697 : H12AffineEnvironment.transform 11 1045 env54696 = env54697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env54696 == env54697) = true)

theorem identity54697 : scanCanonicalize (H12AffineFastState.compose env54697 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound54697 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54698 : List Nat := [2,4,8,16,1,17,8,4,512,5,26,16,8,17,1,2,1,27,5,0,1,1,17,3,8,16,27,1,17,27,5,1,4,1,16,512]

theorem envBound54698 : H12AffineFastState.Bounded env54698 := by
  intro p hp
  have h : env54698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54697_54698 : H12AffineEnvironment.transform 9 5 env54697 = env54698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env54697 == env54698) = true)

theorem identity54698 : scanCanonicalize (H12AffineFastState.compose env54698 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound54698 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54699 : List Nat := [2,1,8,16,1,17,8,1,512,0,26,16,8,17,1,2,1,27,0,0,1,1,17,3,8,16,27,1,17,27,0,1,1,1,16,512]

theorem envBound54699 : H12AffineFastState.Bounded env54699 := by
  intro p hp
  have h : env54699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54698_54699 : H12AffineEnvironment.transform 1 1 env54698 = env54699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env54698 == env54699) = true)

theorem identity54699 : scanCanonicalize (H12AffineFastState.compose env54699 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54699 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54700 : List Nat := [2,1,8,11,1,10,8,1,512,0,1,11,8,10,1,2,1,0,0,0,1,1,10,3,8,11,0,1,10,0,0,1,1,1,11,512]

theorem envBound54700 : H12AffineFastState.Bounded env54700 := by
  intro p hp
  have h : env54700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54699_54700 : H12AffineEnvironment.transform 3 11 env54699 = env54700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54699 == env54700) = true)

theorem identity54700 : scanCanonicalize (H12AffineFastState.compose env54700 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54700 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env54701 : List Nat := [2,1,3,0,1,1,3,1,512,0,1,0,3,1,1,2,1,0,0,0,1,1,1,3,3,0,0,1,1,0,0,1,1,1,0,512]

theorem envBound54701 : H12AffineFastState.Bounded env54701 := by
  intro p hp
  have h : env54701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54700_54701 : H12AffineEnvironment.transform 2 3 env54700 = env54701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54700 == env54701) = true)

theorem identity54701 : scanCanonicalize (H12AffineFastState.compose env54701 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound54701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54702 : List Nat := [2,1,3,0,1,1,3,1,2,0,1,0,3,1,1,2,1,0,0,0,1,1,1,3,3,0,0,1,1,0,0,1,1,1,0,2]

theorem envBound54702 : H12AffineFastState.Bounded env54702 := by
  intro p hp
  have h : env54702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54701_54702 : H12AffineEnvironment.transform 8 2 env54701 = env54702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env54701 == env54702) = true)

def env54703 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,169264,17,98644,8193,65,245019,5392,17665,108927,1364,156012,256,21792,46093,74250]

theorem envBound54703 : H12AffineFastState.Bounded env54703 := by
  intro p hp
  have h : env54703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54686_54703 : H12AffineEnvironment.transform 6 9 env54686 = env54703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54686 == env54703) = true)

theorem identity54703 : scanCanonicalize (H12AffineFastState.compose env54703 (packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS)) = affineNative (2^(16+1) ^^^ 103495) := by decide +kernel

theorem selectedBound54703 : packedSelected [1,3,7,8,10,11,12,16,19,24,26,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env54704 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,103495,64809,1024,32769,4160,65911,17,98644,8193,65,10588,5392,17665,108927,1364,128299,256,21792,46093,74250]

theorem envBound54704 : H12AffineFastState.Bounded env54704 := by
  intro p hp
  have h : env54704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54703_54704 : H12AffineEnvironment.transform 16 103495 env54703 = env54704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103495 env54703 == env54704) = true)

theorem identity54704 : scanCanonicalize (H12AffineFastState.compose env54704 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound54704 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env54705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90138,2420,1024,29788,4160,65911,17,95497,8193,65,10588,5392,17665,89378,1364,65910,256,21792,16464,74250]

theorem envBound54705 : H12AffineFastState.Bounded env54705 := by
  intro p hp
  have h : env54705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54704_54705 : H12AffineEnvironment.transform 14 29789 env54704 = env54705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env54704 == env54705) = true)

theorem identity54705 : scanCanonicalize (H12AffineFastState.compose env54705 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound54705 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env54706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16401,2420,1024,29788,4160,8572,17,21762,8193,65,10588,5392,17665,32041,1364,8573,256,21792,16464,513]

theorem envBound54706 : H12AffineFastState.Bounded env54706 := by
  intro p hp
  have h : env54706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54705_54706 : H12AffineEnvironment.transform 15 8203 env54705 = env54706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env54705 == env54706) = true)

theorem identity54706 : scanCanonicalize (H12AffineFastState.compose env54706 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound54706 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54707 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8461,8203,5441,2420,1024,8460,4160,8572,17,82,8193,65,10588,5392,4177,10361,1364,8573,256,112,5376,513]

theorem envBound54707 : H12AffineFastState.Bounded env54707 := by
  intro p hp
  have h : env54707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54706_54707 : H12AffineEnvironment.transform 13 5456 env54706 = env54707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env54706 == env54707) = true)

theorem identity54707 : scanCanonicalize (H12AffineFastState.compose env54707 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 57) := by decide +kernel

theorem selectedBound54707 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54708 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,57,5456,308,50,5441,2420,1024,309,4160,325,17,82,56,65,2405,5392,4177,2112,1364,324,256,112,5376,513]

theorem envBound54708 : H12AffineFastState.Bounded env54708 := by
  intro p hp
  have h : env54708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54707_54708 : H12AffineEnvironment.transform 12 57 env54707 = env54708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 57 env54707 == env54708) = true)

theorem identity54708 : scanCanonicalize (H12AffineFastState.compose env54708 (packedSelected [0,1,4,5,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 848) := by decide +kernel

theorem selectedBound54708 : packedSelected [0,1,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env54709 : List Nat := [2,4,8,16,32,64,9,256,512,848,2048,4096,57,4608,308,50,4625,2420,848,309,4160,325,17,82,56,65,2405,4672,4177,2112,516,324,256,112,4688,513]

theorem envBound54709 : H12AffineFastState.Bounded env54709 := by
  intro p hp
  have h : env54709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54708_54709 : H12AffineEnvironment.transform 9 848 env54708 = env54709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 848 env54708 == env54709) = true)

def env54710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223719,1024,32769,4161,4194304,16,98780,8328,65,4270123,5392,17665,109047,1501,4256860,256,21793,46213,74250]

theorem envBound54710 : H12AffineFastState.Bounded env54710 := by
  intro p hp
  have h : env54710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54684_54710 : H12AffineEnvironment.transform 20 4161 env54684 = env54710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54684 == env54710) = true)

def env54711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,4194304,16,98644,8192,65,4270123,5392,17665,108927,1365,4256860,256,21793,46093,74250]

theorem envBound54711 : H12AffineFastState.Bounded env54711 := by
  intro p hp
  have h : env54711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54710_54711 : H12AffineEnvironment.transform 6 8 env54710 = env54711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54710 == env54711) = true)

theorem identity54711 : scanCanonicalize (H12AffineFastState.compose env54711 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound54711 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35189,1024,32769,4161,4194304,16,98644,8192,65,4270123,5392,17665,108927,1365,4256860,256,21793,46093,74250]

theorem envBound54712 : H12AffineFastState.Bounded env54712 := by
  intro p hp
  have h : env54712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54711_54712 : H12AffineEnvironment.transform 16 122906 env54711 = env54712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env54711 == env54712) = true)

theorem identity54712 : scanCanonicalize (H12AffineFastState.compose env54712 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound54712 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,38208,35189,1024,32769,4161,4194304,16,62478,8192,65,4218225,5392,17665,56357,1365,4256860,256,21793,46093,22352]

theorem envBound54713 : H12AffineFastState.Bounded env54713 := by
  intro p hp
  have h : env54713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54712_54713 : H12AffineEnvironment.transform 15 30042 env54712 = env54713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env54712 == env54713) = true)

theorem identity54713 : scanCanonicalize (H12AffineFastState.compose env54713 (packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound54713 : packedSelected [0,3,9,10,18,22,23,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,38208,35189,1024,32769,4161,8573,16,62478,8192,65,31756,5392,17665,56357,1365,54561,256,21793,46093,22352]

theorem envBound54714 : H12AffineFastState.Bounded env54714 := by
  intro p hp
  have h : env54714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54713_54714 : H12AffineEnvironment.transform 21 8573 env54713 = env54714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env54713 == env54714) = true)

theorem identity54714 : scanCanonicalize (H12AffineFastState.compose env54714 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound54714 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21841,30042,16401,23588,1024,21840,4161,8573,16,8543,8192,65,31756,5392,17665,2420,1365,112,256,21793,24924,22352]

theorem envBound54715 : H12AffineFastState.Bounded env54715 := by
  intro p hp
  have h : env54715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54714_54715 : H12AffineEnvironment.transform 14 21841 env54714 = env54715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env54714 == env54715) = true)

theorem identity54715 : scanCanonicalize (H12AffineFastState.compose env54715 (packedSelected [3,4,5,6,7,12,14,15,16,18,19] rootPS)) = affineNative (2^(10+1) ^^^ 1556) := by decide +kernel

theorem selectedBound54715 : packedSelected [3,4,5,6,7,12,14,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env54716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1556,4096,8192,16384,21841,30042,16401,21040,1024,21840,4161,8573,16,8543,8192,65,29208,5392,17665,1888,1365,112,256,21793,24924,22352]

theorem envBound54716 : H12AffineFastState.Bounded env54716 := by
  intro p hp
  have h : env54716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54715_54716 : H12AffineEnvironment.transform 10 1556 env54715 = env54716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1556 env54715 == env54716) = true)

theorem identity54716 : scanCanonicalize (H12AffineFastState.compose env54716 (packedSelected [0,4,5,8,10,11,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13852) := by decide +kernel

theorem selectedBound54716 : packedSelected [0,4,5,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env54717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1556,4096,8192,13852,9037,838,13837,9260,1024,9036,4161,8573,16,8543,8192,65,1028,5392,13085,1888,1365,112,256,9021,5952,8524]

theorem envBound54717 : H12AffineFastState.Bounded env54717 := by
  intro p hp
  have h : env54717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54716_54717 : H12AffineEnvironment.transform 13 13852 env54716 = env54717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13852 env54716 == env54717) = true)

theorem identity54717 : scanCanonicalize (H12AffineFastState.compose env54717 (packedSelected [0,2,5,6,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(11+1) ^^^ 341) := by decide +kernel

theorem selectedBound54717 : packedSelected [0,2,5,6,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env54718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1556,341,8192,10057,9037,838,10072,9260,1024,9036,276,8573,16,8543,8192,65,1028,1093,8776,1888,1365,112,256,9021,1557,8524]

theorem envBound54718 : H12AffineFastState.Bounded env54718 := by
  intro p hp
  have h : env54718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54717_54718 : H12AffineEnvironment.transform 11 341 env54717 = env54718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 341 env54717 == env54718) = true)

theorem identity54718 : scanCanonicalize (H12AffineFastState.compose env54718 (packedSelected [4,5,6,7,8,10,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound54718 : packedSelected [4,5,6,7,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env54719 : List Nat := [2,4,8,16,32,64,8,256,512,68,592,341,8192,8973,9037,838,8988,8296,68,9036,276,8573,16,8543,8192,65,64,1,8776,804,273,112,256,9021,593,8524]

theorem envBound54719 : H12AffineFastState.Bounded env54719 := by
  intro p hp
  have h : env54719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54718_54719 : H12AffineEnvironment.transform 9 68 env54718 = env54719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env54718 == env54719) = true)

theorem identity54719 : scanCanonicalize (H12AffineFastState.compose env54719 (packedSelected [1,2,3,4,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound54719 : packedSelected [1,2,3,4,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54720 : List Nat := [2,4,8,16,32,64,8,256,512,68,592,341,381,624,560,838,609,277,68,561,276,0,16,34,381,65,64,1,821,804,273,112,256,576,593,49]

theorem envBound54720 : H12AffineFastState.Bounded env54720 := by
  intro p hp
  have h : env54720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54719_54720 : H12AffineEnvironment.transform 12 381 env54719 = env54720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env54719 == env54720) = true)

theorem identity54720 : scanCanonicalize (H12AffineFastState.compose env54720 (packedSelected [0,1,4,6,8,10] rootPS)) = affineNative (2^(8+1) ^^^ 357) := by decide +kernel

theorem selectedBound54720 : packedSelected [0,1,4,6,8,10] rootPS < 2^1333 := by decide +kernel

def env54721 : List Nat := [2,4,8,16,32,64,8,256,357,68,309,341,381,277,341,35,260,277,68,340,276,0,16,34,381,65,64,1,80,65,273,112,256,293,308,49]

theorem envBound54721 : H12AffineFastState.Bounded env54721 := by
  intro p hp
  have h : env54721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54720_54721 : H12AffineEnvironment.transform 8 357 env54720 = env54721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 357 env54720 == env54721) = true)

def env54722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,4194304,16,98645,8193,65,4270123,5392,17665,108926,1364,4256860,256,21793,46092,74250]

theorem envBound54722 : H12AffineFastState.Bounded env54722 := by
  intro p hp
  have h : env54722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54710_54722 : H12AffineEnvironment.transform 6 9 env54710 = env54722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54710 == env54722) = true)

theorem identity54722 : scanCanonicalize (H12AffineFastState.compose env54722 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound54722 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4161,4194304,16,98645,8193,65,4270123,5392,17665,108926,1364,4256860,256,21793,46092,74250]

theorem envBound54723 : H12AffineFastState.Bounded env54723 := by
  intro p hp
  have h : env54723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54722_54723 : H12AffineEnvironment.transform 16 82246 env54722 = env54723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env54722 == env54723) = true)

theorem identity54723 : scanCanonicalize (H12AffineFastState.compose env54723 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound54723 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env54724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1024,32769,4161,8573,16,98645,8193,65,67926,5392,17665,108926,1364,54561,256,21793,46092,74250]

theorem envBound54724 : H12AffineFastState.Bounded env54724 := by
  intro p hp
  have h : env54724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54723_54724 : H12AffineEnvironment.transform 21 8573 env54723 = env54724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env54723 == env54724) = true)

theorem identity54724 : scanCanonicalize (H12AffineFastState.compose env54724 (packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound54724 : packedSelected [1,2,6,7,8,9,11,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env54725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,5392,10280,1024,32769,4161,8573,16,54531,8193,65,23808,5392,17665,64808,1364,54561,256,21793,46092,30300]

theorem envBound54725 : H12AffineFastState.Bounded env54725 := by
  intro p hp
  have h : env54725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54724_54725 : H12AffineEnvironment.transform 15 21590 env54724 = env54725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env54724 == env54725) = true)

theorem identity54725 : scanCanonicalize (H12AffineFastState.compose env54725 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound54725 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env54726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,21590,5392,10280,1024,29788,4161,8573,16,8542,8193,65,23808,5392,17665,2421,1364,8572,256,21793,16465,30300]

theorem envBound54726 : H12AffineFastState.Bounded env54726 := by
  intro p hp
  have h : env54726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54725_54726 : H12AffineEnvironment.transform 14 29789 env54725 = env54726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env54725 == env54726) = true)

theorem identity54726 : scanCanonicalize (H12AffineFastState.compose env54726 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound54726 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,8203,5392,10280,1024,1,4161,8573,16,8542,8193,65,10589,5392,12636,2421,1364,8572,256,8572,13324,513]

theorem envBound54727 : H12AffineFastState.Bounded env54727 := by
  intro p hp
  have h : env54727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54726_54727 : H12AffineEnvironment.transform 13 13405 env54726 = env54727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env54726 == env54727) = true)

theorem identity54727 : scanCanonicalize (H12AffineFastState.compose env54727 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54727 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env54728 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13324,0,8203,5392,10280,1024,1,4112,8492,16,8463,8193,16,10508,5392,12557,2340,1285,8493,256,8493,13324,513]

theorem envBound54728 : H12AffineFastState.Bounded env54728 := by
  intro p hp
  have h : env54728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54727_54728 : H12AffineEnvironment.transform 5 17 env54727 = env54728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54727 == env54728) = true)

theorem identity54728 : scanCanonicalize (H12AffineFastState.compose env54728 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound54728 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54729 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,2316,7424,0,2311,5392,292,1024,1,4112,2080,16,2051,2317,16,0,5392,6145,2340,1285,2081,256,2081,7424,513]

theorem envBound54729 : H12AffineFastState.Bounded env54729 := by
  intro p hp
  have h : env54729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54728_54729 : H12AffineEnvironment.transform 12 2316 env54728 = env54729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env54728 == env54729) = true)

theorem identity54729 : scanCanonicalize (H12AffineFastState.compose env54729 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound54729 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54730 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,4096,269,5377,0,262,5392,292,1024,1,4112,33,16,2,268,16,0,5392,4096,293,1285,32,256,32,5377,513]

theorem envBound54730 : H12AffineFastState.Bounded env54730 := by
  intro p hp
  have h : env54730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54729_54730 : H12AffineEnvironment.transform 10 1 env54729 = env54730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env54729 == env54730) = true)

theorem identity54730 : scanCanonicalize (H12AffineFastState.compose env54730 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound54730 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54731 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1,1313,269,32,0,262,49,292,1024,1,1329,33,16,2,268,16,0,49,1313,293,1285,32,256,32,32,513]

theorem envBound54731 : H12AffineFastState.Bounded env54731 := by
  intro p hp
  have h : env54731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54730_54731 : H12AffineEnvironment.transform 11 1313 env54730 = env54731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env54730 == env54731) = true)

theorem identity54731 : scanCanonicalize (H12AffineFastState.compose env54731 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54731 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54732 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1,1029,41,32,0,34,49,0,1024,1,1045,33,16,2,40,16,0,49,1029,1,1057,32,36,32,32,513]

theorem envBound54732 : H12AffineFastState.Bounded env54732 := by
  intro p hp
  have h : env54732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54731_54732 : H12AffineEnvironment.transform 7 36 env54731 = env54732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54731 == env54732) = true)

theorem identity54732 : scanCanonicalize (H12AffineFastState.compose env54732 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54732 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54733 : List Nat := [2,4,8,16,32,17,9,36,48,1024,1,1029,41,32,0,34,49,0,1024,1,1045,33,16,2,40,16,0,49,1029,1,1057,32,36,32,32,49]

theorem envBound54733 : H12AffineFastState.Bounded env54733 := by
  intro p hp
  have h : env54733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54732_54733 : H12AffineEnvironment.transform 8 48 env54732 = env54733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54732 == env54733) = true)

theorem identity54733 : scanCanonicalize (H12AffineFastState.compose env54733 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54733 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54734 : List Nat := [2,4,8,16,16,17,9,20,0,1024,1,1029,25,16,0,18,1,0,1024,1,1045,17,16,2,24,16,0,1,1029,1,1041,16,20,16,16,1]

theorem envBound54734 : H12AffineFastState.Bounded env54734 := by
  intro p hp
  have h : env54734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54733_54734 : H12AffineEnvironment.transform 4 16 env54733 = env54734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54733 == env54734) = true)

theorem identity54734 : scanCanonicalize (H12AffineFastState.compose env54734 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound54734 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54735 : List Nat := [2,4,8,16,16,17,9,20,0,21,1,16,25,16,0,18,1,0,21,1,0,17,16,2,24,16,0,1,16,1,4,16,20,16,16,1]

theorem envBound54735 : H12AffineFastState.Bounded env54735 := by
  intro p hp
  have h : env54735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54734_54735 : H12AffineEnvironment.transform 9 21 env54734 = env54735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env54734 == env54735) = true)

theorem identity54735 : scanCanonicalize (H12AffineFastState.compose env54735 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54735 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env54736 : List Nat := [2,4,8,1,1,0,9,5,0,4,1,1,8,1,0,3,1,0,4,1,0,0,1,2,9,1,0,1,1,1,4,1,5,1,1,1]

theorem envBound54736 : H12AffineFastState.Bounded env54736 := by
  intro p hp
  have h : env54736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54735_54736 : H12AffineEnvironment.transform 3 1 env54735 = env54736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54735 == env54736) = true)

def env54737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound54737 : H12AffineFastState.Bounded env54737 := by
  intro p hp
  have h : env54737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54558_54737 : H12AffineEnvironment.transform 18 1025 env54558 = env54737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env54558 == env54737) = true)

theorem identity54737 : scanCanonicalize (H12AffineFastState.compose env54737 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8685926) := by decide +kernel

theorem selectedBound54737 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8328,65,4409703,10817002,10507600,8830977,331127,15068327,257,2444747,2468974,273057]

theorem envBound54738 : H12AffineFastState.Bounded env54738 := by
  intro p hp
  have h : env54738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54737_54738 : H12AffineEnvironment.transform 23 8685926 env54737 = env54738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8685926 env54737 == env54738) = true)

def env54739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4409703,10816866,10507600,8830977,331127,15068207,257,2444611,2468974,272937]

theorem envBound54739 : H12AffineFastState.Bounded env54739 := by
  intro p hp
  have h : env54739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54738_54739 : H12AffineEnvironment.transform 6 8 env54738 = env54739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54738 == env54739) = true)

def env54740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4262263,10816866,10507600,8683537,331127,15068207,257,2444611,2468974,272937]

theorem envBound54740 : H12AffineFastState.Bounded env54740 := by
  intro p hp
  have h : env54740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54739_54740 : H12AffineEnvironment.transform 16 16400 env54739 = env54740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env54739 == env54740) = true)

def env54741 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685878,8192,17,4262183,10816818,10507520,8683537,331047,15068207,257,2444563,2468926,272937]

theorem envBound54741 : H12AffineFastState.Bounded env54741 := by
  intro p hp
  have h : env54741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54740_54741 : H12AffineEnvironment.transform 5 16 env54740 = env54741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54740 == env54741) = true)

def env54742 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685878,8192,17,4262183,10815490,10506288,8683537,329751,15067423,257,2443299,2468110,272937]

theorem envBound54742 : H12AffineFastState.Bounded env54742 := by
  intro p hp
  have h : env54742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54741_54742 : H12AffineEnvironment.transform 9 304 env54741 = env54742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env54741 == env54742) = true)

theorem identity54742 : scanCanonicalize (H12AffineFastState.compose env54742 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4491541) := by decide +kernel

theorem selectedBound54742 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54743 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4491541,4194339,8192,17,4262183,6390039,6609189,4196612,329751,2187274,257,2443299,2468110,272937]

theorem envBound54743 : H12AffineFastState.Bounded env54743 := by
  intro p hp
  have h : env54743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54742_54743 : H12AffineEnvironment.transform 22 4491541 env54742 = env54743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4491541 env54742 == env54743) = true)

theorem identity54743 : scanCanonicalize (H12AffineFastState.compose env54743 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54743 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env54744 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4235581,4194339,8192,17,4262183,6390039,6353165,4196612,73791,2187274,257,2187275,2195750,513]

theorem envBound54744 : H12AffineFastState.Bounded env54744 := by
  intro p hp
  have h : env54744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54743_54744 : H12AffineEnvironment.transform 17 10280 env54743 = env54744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54743 == env54744) = true)

theorem identity54744 : scanCanonicalize (H12AffineFastState.compose env54744 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound54744 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env54745 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,33030,16400,10280,305,32769,2097152,4194304,4235581,4194339,8192,17,4229153,6291473,6353165,4196612,41273,2154764,257,2154765,2097184,513]

theorem envBound54745 : H12AffineFastState.Bounded env54745 := by
  intro p hp
  have h : env54745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54744_54745 : H12AffineEnvironment.transform 15 33030 env54744 = env54745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env54744 == env54745) = true)

theorem identity54745 : scanCanonicalize (H12AffineFastState.compose env54745 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound54745 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54746 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,33030,16400,10280,305,32769,2097152,32,41245,3,8192,17,34817,2097201,2158893,2340,41273,2154764,257,2154765,2097184,513]

theorem envBound54746 : H12AffineFastState.Bounded env54746 := by
  intro p hp
  have h : env54746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54745_54746 : H12AffineEnvironment.transform 21 32 env54745 = env54746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env54745 == env54746) = true)

theorem identity54746 : scanCanonicalize (H12AffineFastState.compose env54746 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54746 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54747 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,32768,33030,16400,2341,305,32769,2097152,32,32784,3,269,17,34817,2097201,2150432,2340,32820,2146305,257,2146304,2097184,513]

theorem envBound54747 : H12AffineFastState.Bounded env54747 := by
  intro p hp
  have h : env54747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54746_54747 : H12AffineEnvironment.transform 12 269 env54746 = env54747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54746 == env54747) = true)

theorem identity54747 : scanCanonicalize (H12AffineFastState.compose env54747 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54747 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54748 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,1,263,16400,2341,305,0,2097152,32,17,3,269,17,2048,2097201,2117665,2340,53,2113536,257,2113537,2097184,513]

theorem envBound54748 : H12AffineFastState.Bounded env54748 := by
  intro p hp
  have h : env54748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54747_54748 : H12AffineEnvironment.transform 14 1 env54747 = env54748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54747 == env54748) = true)

theorem identity54748 : scanCanonicalize (H12AffineFastState.compose env54748 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6965) := by decide +kernel

theorem selectedBound54748 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54749 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,16384,1,263,16400,2341,305,0,6965,32,17,3,269,17,2048,6916,19220,2340,53,23349,257,23348,6933,513]

theorem envBound54749 : H12AffineFastState.Bounded env54749 := by
  intro p hp
  have h : env54749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54748_54749 : H12AffineEnvironment.transform 20 6965 env54748 = env54749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6965 env54748 == env54749) = true)

theorem identity54749 : scanCanonicalize (H12AffineFastState.compose env54749 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6933) := by decide +kernel

theorem selectedBound54749 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54750 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,269,6933,1,263,6917,2341,305,0,6965,32,17,3,269,17,2048,6916,4097,2340,53,32,257,33,6933,513]

theorem envBound54750 : H12AffineFastState.Bounded env54750 := by
  intro p hp
  have h : env54750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54749_54750 : H12AffineEnvironment.transform 13 6933 env54749 = env54750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6933 env54749 == env54750) = true)

theorem identity54750 : scanCanonicalize (H12AffineFastState.compose env54750 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound54750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54751 : List Nat := [2,4,8,16,32,16,8,256,512,304,528,4096,269,4357,1,263,4373,821,305,0,4389,32,17,3,269,17,528,4372,4097,820,53,32,257,33,4357,513]

theorem envBound54751 : H12AffineFastState.Bounded env54751 := by
  intro p hp
  have h : env54751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54750_54751 : H12AffineEnvironment.transform 10 528 env54750 = env54751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env54750 == env54751) = true)

theorem identity54751 : scanCanonicalize (H12AffineFastState.compose env54751 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound54751 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54752 : List Nat := [2,4,8,16,32,16,8,256,512,304,528,513,269,772,1,263,788,821,305,0,804,32,17,3,269,17,528,789,512,820,53,32,257,33,772,513]

theorem envBound54752 : H12AffineFastState.Bounded env54752 := by
  intro p hp
  have h : env54752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54751_54752 : H12AffineEnvironment.transform 11 513 env54751 = env54752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env54751 == env54752) = true)

theorem identity54752 : scanCanonicalize (H12AffineFastState.compose env54752 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54752 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54753 : List Nat := [2,4,8,16,32,16,8,256,16,304,0,17,269,276,1,263,260,293,305,0,308,32,17,3,269,17,0,261,16,292,53,32,257,33,276,17]

theorem envBound54753 : H12AffineFastState.Bounded env54753 := by
  intro p hp
  have h : env54753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54752_54753 : H12AffineEnvironment.transform 8 16 env54752 = env54753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54752 == env54753) = true)

theorem identity54753 : scanCanonicalize (H12AffineFastState.compose env54753 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound54753 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54754 : List Nat := [2,4,8,16,32,16,8,21,16,37,0,17,24,1,1,18,17,48,36,0,33,32,17,3,24,17,0,16,16,49,53,32,20,33,1,17]

theorem envBound54754 : H12AffineFastState.Bounded env54754 := by
  intro p hp
  have h : env54754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54753_54754 : H12AffineEnvironment.transform 7 21 env54753 = env54754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env54753 == env54754) = true)

theorem identity54754 : scanCanonicalize (H12AffineFastState.compose env54754 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54754 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54755 : List Nat := [2,4,8,1,32,1,8,4,1,37,0,0,9,1,1,3,0,33,36,0,33,32,0,3,9,0,0,1,1,32,36,32,5,33,1,0]

theorem envBound54755 : H12AffineFastState.Bounded env54755 := by
  intro p hp
  have h : env54755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54754_54755 : H12AffineEnvironment.transform 3 1 env54754 = env54755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54754 == env54755) = true)

theorem identity54755 : scanCanonicalize (H12AffineFastState.compose env54755 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54756 : List Nat := [2,4,8,1,0,1,8,4,1,5,0,0,9,1,1,3,0,1,4,0,1,0,0,3,9,0,0,1,1,0,4,0,5,1,1,0]

theorem envBound54756 : H12AffineFastState.Bounded env54756 := by
  intro p hp
  have h : env54756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54755_54756 : H12AffineEnvironment.transform 4 0 env54755 = env54756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54755 == env54756) = true)

def env54757 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685878,8192,17,4262183,10815491,10506289,8683537,329750,15067422,257,2443298,2468111,272937]

theorem envBound54757 : H12AffineFastState.Bounded env54757 := by
  intro p hp
  have h : env54757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54741_54757 : H12AffineEnvironment.transform 9 305 env54741 = env54757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env54741 == env54757) = true)

theorem identity54757 : scanCanonicalize (H12AffineFastState.compose env54757 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4235581) := by decide +kernel

theorem selectedBound54757 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54758 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4235581,4466699,8192,17,4262183,6662462,6353164,4464940,329750,2443299,257,2443298,2468111,272937]

theorem envBound54758 : H12AffineFastState.Bounded env54758 := by
  intro p hp
  have h : env54758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54757_54758 : H12AffineEnvironment.transform 22 4235581 env54757 = env54758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4235581 env54757 == env54758) = true)

def env54759 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,4194304,4235581,4194339,8192,17,4262183,6390038,6353164,4196612,73790,2187275,257,2187274,2195751,513]

theorem envBound54759 : H12AffineFastState.Bounded env54759 := by
  intro p hp
  have h : env54759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54758_54759 : H12AffineEnvironment.transform 17 10280 env54758 = env54759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54758 == env54759) = true)

theorem identity54759 : scanCanonicalize (H12AffineFastState.compose env54759 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound54759 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env54760 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,33030,16400,10280,304,32769,2097152,4194304,4235581,4194339,8192,17,4229153,6291472,6353164,4196612,41272,2154765,257,2154764,2097185,513]

theorem envBound54760 : H12AffineFastState.Bounded env54760 := by
  intro p hp
  have h : env54760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54759_54760 : H12AffineEnvironment.transform 15 33030 env54759 = env54760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env54759 == env54760) = true)

theorem identity54760 : scanCanonicalize (H12AffineFastState.compose env54760 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound54760 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54761 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,33030,16400,10280,304,32769,2097152,32,41245,3,8192,17,34817,2097200,2158892,2340,41272,2154765,257,2154764,2097185,513]

theorem envBound54761 : H12AffineFastState.Bounded env54761 := by
  intro p hp
  have h : env54761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54760_54761 : H12AffineEnvironment.transform 21 32 env54760 = env54761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env54760 == env54761) = true)

theorem identity54761 : scanCanonicalize (H12AffineFastState.compose env54761 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound54761 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54762 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,16384,32768,33030,16400,2341,304,32769,2097152,32,32784,3,269,17,34817,2097200,2150433,2340,32821,2146304,257,2146305,2097185,513]

theorem envBound54762 : H12AffineFastState.Bounded env54762 := by
  intro p hp
  have h : env54762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54761_54762 : H12AffineEnvironment.transform 12 269 env54761 = env54762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env54761 == env54762) = true)

theorem identity54762 : scanCanonicalize (H12AffineFastState.compose env54762 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54762 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54763 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,16384,1,263,16400,2341,304,0,2097152,32,17,3,269,17,2048,2097200,2117664,2340,52,2113537,257,2113536,2097185,513]

theorem envBound54763 : H12AffineFastState.Bounded env54763 := by
  intro p hp
  have h : env54763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54762_54763 : H12AffineEnvironment.transform 14 1 env54762 = env54763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54762 == env54763) = true)

theorem identity54763 : scanCanonicalize (H12AffineFastState.compose env54763 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6965) := by decide +kernel

theorem selectedBound54763 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54764 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,16384,1,263,16400,2341,304,0,6965,32,17,3,269,17,2048,6917,19221,2340,52,23348,257,23349,6932,513]

theorem envBound54764 : H12AffineFastState.Bounded env54764 := by
  intro p hp
  have h : env54764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54763_54764 : H12AffineEnvironment.transform 20 6965 env54763 = env54764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6965 env54763 == env54764) = true)

theorem identity54764 : scanCanonicalize (H12AffineFastState.compose env54764 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6932) := by decide +kernel

theorem selectedBound54764 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54765 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,269,6932,1,263,6916,2341,304,0,6965,32,17,3,269,17,2048,6917,4097,2340,52,32,257,33,6932,513]

theorem envBound54765 : H12AffineFastState.Bounded env54765 := by
  intro p hp
  have h : env54765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54764_54765 : H12AffineEnvironment.transform 13 6932 env54764 = env54765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6932 env54764 == env54765) = true)

theorem identity54765 : scanCanonicalize (H12AffineFastState.compose env54765 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound54765 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54766 : List Nat := [2,4,8,16,32,16,8,256,512,305,528,4096,269,4356,1,263,4372,821,304,0,4389,32,17,3,269,17,528,4373,4097,820,52,32,257,33,4356,513]

theorem envBound54766 : H12AffineFastState.Bounded env54766 := by
  intro p hp
  have h : env54766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54765_54766 : H12AffineEnvironment.transform 10 528 env54765 = env54766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env54765 == env54766) = true)

theorem identity54766 : scanCanonicalize (H12AffineFastState.compose env54766 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound54766 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54767 : List Nat := [2,4,8,16,32,16,8,256,512,305,528,513,269,773,1,263,789,821,304,0,804,32,17,3,269,17,528,788,512,820,52,32,257,33,773,513]

theorem envBound54767 : H12AffineFastState.Bounded env54767 := by
  intro p hp
  have h : env54767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54766_54767 : H12AffineEnvironment.transform 11 513 env54766 = env54767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env54766 == env54767) = true)

theorem identity54767 : scanCanonicalize (H12AffineFastState.compose env54767 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound54767 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54768 : List Nat := [2,4,8,16,32,16,8,256,16,305,0,17,269,277,1,263,261,293,304,0,308,32,17,3,269,17,0,260,16,292,52,32,257,33,277,17]

theorem envBound54768 : H12AffineFastState.Bounded env54768 := by
  intro p hp
  have h : env54768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54767_54768 : H12AffineEnvironment.transform 8 16 env54767 = env54768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env54767 == env54768) = true)

theorem identity54768 : scanCanonicalize (H12AffineFastState.compose env54768 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound54768 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54769 : List Nat := [2,4,8,16,32,16,8,20,16,37,0,17,25,1,1,19,17,49,36,0,32,32,17,3,25,17,0,16,16,48,52,32,21,33,1,17]

theorem envBound54769 : H12AffineFastState.Bounded env54769 := by
  intro p hp
  have h : env54769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54768_54769 : H12AffineEnvironment.transform 7 20 env54768 = env54769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env54768 == env54769) = true)

theorem identity54769 : scanCanonicalize (H12AffineFastState.compose env54769 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound54769 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54770 : List Nat := [2,4,8,0,32,0,8,4,0,37,0,1,9,1,1,3,1,33,36,0,32,32,1,3,9,1,0,0,0,32,36,32,5,33,1,1]

theorem envBound54770 : H12AffineFastState.Bounded env54770 := by
  intro p hp
  have h : env54770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54769_54770 : H12AffineEnvironment.transform 3 0 env54769 = env54770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env54769 == env54770) = true)

theorem identity54770 : scanCanonicalize (H12AffineFastState.compose env54770 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54770 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54771 : List Nat := [2,4,8,0,0,0,8,4,0,5,0,1,9,1,1,3,1,1,4,0,0,0,1,3,9,1,0,0,0,0,4,0,5,1,1,1]

theorem envBound54771 : H12AffineFastState.Bounded env54771 := by
  intro p hp
  have h : env54771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54770_54771 : H12AffineEnvironment.transform 4 0 env54770 = env54771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54770 == env54771) = true)

def env54772 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,2097152,4194304,4235581,4194338,8192,17,4262183,6390039,6353164,4196613,73791,2187274,257,2187275,2195750,512]

theorem envBound54772 : H12AffineFastState.Bounded env54772 := by
  intro p hp
  have h : env54772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54758_54772 : H12AffineEnvironment.transform 17 10281 env54758 = env54772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54758 == env54772) = true)

theorem identity54772 : scanCanonicalize (H12AffineFastState.compose env54772 (packedSelected [2,3,5,6,10,11,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 100387) := by decide +kernel

theorem selectedBound54772 : packedSelected [2,3,5,6,10,11,14,16] rootPS < 2^1333 := by decide +kernel

def env54773 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,100387,4194304,4235581,4194338,8192,17,4262183,4196660,4290863,4196613,73791,59433,257,59432,2309,512]

theorem envBound54773 : H12AffineFastState.Bounded env54773 := by
  intro p hp
  have h : env54773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54772_54773 : H12AffineEnvironment.transform 20 100387 env54772 = env54773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 100387 env54772 == env54773) = true)

theorem identity54773 : scanCanonicalize (H12AffineFastState.compose env54773 (packedSelected [1,3,4,5,8,9,11,15,17] rootPS)) = affineNative (2^(21+1) ^^^ 80190) := by decide +kernel

theorem selectedBound54773 : packedSelected [1,3,4,5,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env54774 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10281,304,32769,100387,80190,104451,80156,8192,17,12313,77834,16401,77883,73791,59433,257,59432,2309,512]

theorem envBound54774 : H12AffineFastState.Bounded env54774 := by
  intro p hp
  have h : env54774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54773_54774 : H12AffineEnvironment.transform 21 80190 env54773 = env54774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 80190 env54773 == env54774) = true)

theorem identity54774 : scanCanonicalize (H12AffineFastState.compose env54774 (packedSelected [1,3,4,5,8,9,11,15,21] rootPS)) = affineNative (2^(15+1) ^^^ 38930) := by decide +kernel

theorem selectedBound54774 : packedSelected [1,3,4,5,8,9,11,15,21] rootPS < 2^1333 := by decide +kernel

def env54775 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,38930,16400,10281,304,32769,4145,41260,17,41230,8192,17,12313,43032,16401,43049,47149,59433,257,59432,2309,512]

theorem envBound54775 : H12AffineFastState.Bounded env54775 := by
  intro p hp
  have h : env54775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54774_54775 : H12AffineEnvironment.transform 15 38930 env54774 = env54775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38930 env54774 == env54775) = true)

theorem identity54775 : scanCanonicalize (H12AffineFastState.compose env54775 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 2081) := by decide +kernel

theorem selectedBound54775 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env54776 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,2081,32768,38930,2097,10281,304,32769,4145,41260,17,41230,8192,17,12313,43032,2096,43049,47149,40968,257,40969,2309,512]

theorem envBound54776 : H12AffineFastState.Bounded env54776 := by
  intro p hp
  have h : env54776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54775_54776 : H12AffineEnvironment.transform 13 2081 env54775 = env54776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2081 env54775 == env54776) = true)

theorem identity54776 : scanCanonicalize (H12AffineFastState.compose env54776 (packedSelected [0,2,3,5,6,7,10,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound54776 : packedSelected [0,2,3,5,6,7,10,14,18] rootPS < 2^1333 := by decide +kernel

def env54777 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,2081,293,6455,2097,10281,304,292,4145,8201,17,8235,8192,17,12313,10557,2096,10508,14600,8493,257,8492,2309,512]

theorem envBound54777 : H12AffineFastState.Bounded env54777 := by
  intro p hp
  have h : env54777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54776_54777 : H12AffineEnvironment.transform 14 293 env54776 = env54777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env54776 == env54777) = true)

theorem identity54777 : scanCanonicalize (H12AffineFastState.compose env54777 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 6428) := by decide +kernel

theorem selectedBound54777 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54778 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,6428,2081,293,6455,2097,4405,304,292,4145,6421,17,6455,6428,17,2309,4129,2096,4112,20,6193,257,6192,2309,512]

theorem envBound54778 : H12AffineFastState.Bounded env54778 := by
  intro p hp
  have h : env54778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54777_54778 : H12AffineEnvironment.transform 12 6428 env54777 = env54778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6428 env54777 == env54778) = true)

theorem identity54778 : scanCanonicalize (H12AffineFastState.compose env54778 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound54778 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env54779 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,2064,268,2081,293,295,2097,2341,304,292,2081,261,17,295,268,17,2309,2097,2096,2048,20,33,257,32,2309,512]

theorem envBound54779 : H12AffineFastState.Bounded env54779 := by
  intro p hp
  have h : env54779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54778_54779 : H12AffineEnvironment.transform 11 2064 env54778 = env54779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env54778 == env54779) = true)

theorem identity54779 : scanCanonicalize (H12AffineFastState.compose env54779 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54779 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54780 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,2064,8,2081,33,35,2097,2081,52,32,2081,1,17,35,8,17,2049,2097,2096,2048,20,33,5,32,2049,512]

theorem envBound54780 : H12AffineFastState.Bounded env54780 := by
  intro p hp
  have h : env54780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54779_54780 : H12AffineEnvironment.transform 7 4 env54779 = env54780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54779 == env54780) = true)

theorem identity54780 : scanCanonicalize (H12AffineFastState.compose env54780 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound54780 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env54781 : List Nat := [2,4,8,16,32,16,8,4,33,53,2048,2064,8,2081,33,35,2097,2081,52,32,2081,1,17,35,8,17,2049,2097,2096,2048,20,33,5,32,2049,33]

theorem envBound54781 : H12AffineFastState.Bounded env54781 := by
  intro p hp
  have h : env54781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54780_54781 : H12AffineEnvironment.transform 8 33 env54780 = env54781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env54780 == env54781) = true)

theorem identity54781 : scanCanonicalize (H12AffineFastState.compose env54781 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound54781 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env54782 : List Nat := [2,4,8,16,32,16,8,4,33,53,16,0,8,49,33,35,33,49,52,32,49,1,17,35,8,17,17,33,32,16,20,33,5,32,17,33]

theorem envBound54782 : H12AffineFastState.Bounded env54782 := by
  intro p hp
  have h : env54782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54781_54782 : H12AffineEnvironment.transform 10 16 env54781 = env54782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env54781 == env54782) = true)

theorem identity54782 : scanCanonicalize (H12AffineFastState.compose env54782 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54782 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54783 : List Nat := [2,4,8,16,1,16,8,4,0,20,16,0,8,16,0,2,0,16,21,1,16,1,17,2,8,17,17,0,1,16,20,0,5,1,17,0]

theorem envBound54783 : H12AffineFastState.Bounded env54783 := by
  intro p hp
  have h : env54783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54782_54783 : H12AffineEnvironment.transform 4 1 env54782 = env54783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54782 == env54783) = true)

theorem identity54783 : scanCanonicalize (H12AffineFastState.compose env54783 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound54783 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54784 : List Nat := [2,0,8,16,1,16,8,0,0,16,16,0,8,16,0,2,0,16,17,1,16,1,17,2,8,17,17,0,1,16,16,0,1,1,17,0]

theorem envBound54784 : H12AffineFastState.Bounded env54784 := by
  intro p hp
  have h : env54784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54783_54784 : H12AffineEnvironment.transform 1 0 env54783 = env54784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env54783 == env54784) = true)

theorem identity54784 : scanCanonicalize (H12AffineFastState.compose env54784 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound54784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54785 : List Nat := [2,0,0,16,1,16,0,0,0,16,16,0,0,16,0,2,0,16,17,1,16,1,17,2,0,17,17,0,1,16,16,0,1,1,17,0]

theorem envBound54785 : H12AffineFastState.Bounded env54785 := by
  intro p hp
  have h : env54785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54784_54785 : H12AffineEnvironment.transform 2 0 env54784 = env54785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env54784 == env54785) = true)

theorem identity54785 : scanCanonicalize (H12AffineFastState.compose env54785 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54785 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54786 : List Nat := [2,0,0,1,1,1,0,0,0,1,1,0,0,1,0,2,0,1,0,1,1,1,0,2,0,0,0,0,1,1,1,0,1,1,0,0]

theorem envBound54786 : H12AffineFastState.Bounded env54786 := by
  intro p hp
  have h : env54786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54785_54786 : H12AffineEnvironment.transform 3 1 env54785 = env54786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54785 == env54786) = true)

theorem identity54786 : scanCanonicalize (H12AffineFastState.compose env54786 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound54786 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54787 : List Nat := [0,0,0,1,1,1,0,0,0,1,1,0,0,1,0,0,0,1,0,1,1,1,0,0,0,0,0,0,1,1,1,0,1,1,0,0]

theorem envBound54787 : H12AffineFastState.Bounded env54787 := by
  intro p hp
  have h : env54787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54786_54787 : H12AffineEnvironment.transform 0 0 env54786 = env54787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env54786 == env54787) = true)

def env54788 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,8388608,8685879,8192,16,4262182,10816819,10507521,8683537,331046,15068207,257,2444562,2468927,272937]

theorem envBound54788 : H12AffineFastState.Bounded env54788 := by
  intro p hp
  have h : env54788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54740_54788 : H12AffineEnvironment.transform 5 17 env54740 = env54788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54740 == env54788) = true)

def env54789 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,8388608,8685879,8192,16,4262182,10815491,10506289,8683537,329750,15067423,257,2443298,2468111,272937]

theorem envBound54789 : H12AffineFastState.Bounded env54789 := by
  intro p hp
  have h : env54789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54788_54789 : H12AffineEnvironment.transform 9 304 env54788 = env54789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env54788 == env54789) = true)

theorem identity54789 : scanCanonicalize (H12AffineFastState.compose env54789 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4565278) := by decide +kernel

theorem selectedBound54789 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54790 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,262144,305,32769,2097152,4194304,4565278,4268073,8192,16,4262182,6332701,6682927,4270351,329750,2113537,257,2443298,2468111,272937]

theorem envBound54790 : H12AffineFastState.Bounded env54790 := by
  intro p hp
  have h : env54790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54789_54790 : H12AffineEnvironment.transform 22 4565278 env54789 = env54790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4565278 env54789 == env54790) = true)

def env54791 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,4194304,4292918,4268073,8192,16,4262182,6332701,6410503,4270351,73790,2113537,257,2187274,2195751,513]

theorem envBound54791 : H12AffineFastState.Bounded env54791 := by
  intro p hp
  have h : env54791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54790_54791 : H12AffineEnvironment.transform 17 10280 env54790 = env54791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54790 == env54791) = true)

theorem identity54791 : scanCanonicalize (H12AffineFastState.compose env54791 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound54791 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env54792 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10280,305,32769,2097152,41261,73755,98564,8192,16,108555,2097200,2191402,100386,73790,2113537,257,2187274,2195751,513]

theorem envBound54792 : H12AffineFastState.Bounded env54792 := by
  intro p hp
  have h : env54792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54791_54792 : H12AffineEnvironment.transform 21 41261 env54791 = env54792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env54791 == env54792) = true)

theorem identity54792 : scanCanonicalize (H12AffineFastState.compose env54792 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54792 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54793 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,8202,16400,10280,305,32769,2097152,41261,17,41230,8192,16,34817,2097200,2117664,43048,52,2113537,257,2113536,2138413,513]

theorem envBound54793 : H12AffineFastState.Bounded env54793 := by
  intro p hp
  have h : env54793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54792_54793 : H12AffineEnvironment.transform 15 8202 env54792 = env54793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54792 == env54793) = true)

theorem identity54793 : scanCanonicalize (H12AffineFastState.compose env54793 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54793 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54794 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,1,8202,16400,10280,305,0,2097152,8492,17,8463,8192,16,2048,2097200,2117664,10281,52,2113537,257,2113536,2105644,513]

theorem envBound54794 : H12AffineFastState.Bounded env54794 := by
  intro p hp
  have h : env54794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54793_54794 : H12AffineEnvironment.transform 14 1 env54793 = env54794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54793 == env54794) = true)

theorem identity54794 : scanCanonicalize (H12AffineFastState.compose env54794 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54794 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54795 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,1,262,16400,2340,305,0,2097152,32,17,3,268,16,2048,2097200,2117664,2341,52,2113537,257,2113536,2097184,513]

theorem envBound54795 : H12AffineFastState.Bounded env54795 := by
  intro p hp
  have h : env54795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54794_54795 : H12AffineEnvironment.transform 12 268 env54794 = env54795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54794 == env54795) = true)

theorem identity54795 : scanCanonicalize (H12AffineFastState.compose env54795 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6672) := by decide +kernel

theorem selectedBound54795 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54796 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,1,262,16400,2340,305,0,6672,32,17,3,268,16,2048,6688,18992,2341,52,23057,257,23056,6704,513]

theorem envBound54796 : H12AffineFastState.Bounded env54796 := by
  intro p hp
  have h : env54796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54795_54796 : H12AffineEnvironment.transform 20 6672 env54795 = env54796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6672 env54795 == env54796) = true)

theorem identity54796 : scanCanonicalize (H12AffineFastState.compose env54796 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6705) := by decide +kernel

theorem selectedBound54796 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54797 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,6705,1,262,6689,2340,305,0,6672,32,17,3,268,16,2048,6688,4097,2341,52,32,257,33,6704,513]

theorem envBound54797 : H12AffineFastState.Bounded env54797 := by
  intro p hp
  have h : env54797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54796_54797 : H12AffineEnvironment.transform 13 6705 env54796 = env54797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6705 env54796 == env54797) = true)

theorem identity54797 : scanCanonicalize (H12AffineFastState.compose env54797 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound54797 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54798 : List Nat := [2,4,8,16,32,17,8,256,512,304,788,4096,268,4389,1,262,4405,560,305,0,4356,32,17,3,268,16,788,4404,4097,561,52,32,257,33,4388,513]

theorem envBound54798 : H12AffineFastState.Bounded env54798 := by
  intro p hp
  have h : env54798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54797_54798 : H12AffineEnvironment.transform 10 788 env54797 = env54798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env54797 == env54798) = true)

theorem identity54798 : scanCanonicalize (H12AffineFastState.compose env54798 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound54798 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54799 : List Nat := [2,4,8,16,32,17,8,256,512,304,788,544,268,773,1,262,789,560,305,0,804,32,17,3,268,16,788,788,545,561,52,32,257,33,772,513]

theorem envBound54799 : H12AffineFastState.Bounded env54799 := by
  intro p hp
  have h : env54799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54798_54799 : H12AffineEnvironment.transform 11 544 env54798 = env54799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env54798 == env54799) = true)

theorem identity54799 : scanCanonicalize (H12AffineFastState.compose env54799 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54799 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54800 : List Nat := [2,4,8,16,32,17,8,5,512,53,529,544,9,512,1,3,528,560,52,0,545,32,17,3,9,16,529,529,545,561,52,32,4,33,513,513]

theorem envBound54800 : H12AffineFastState.Bounded env54800 := by
  intro p hp
  have h : env54800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54799_54800 : H12AffineEnvironment.transform 7 5 env54799 = env54800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54799 == env54800) = true)

theorem identity54800 : scanCanonicalize (H12AffineFastState.compose env54800 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound54800 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54801 : List Nat := [2,4,8,16,17,17,8,5,512,4,529,529,9,512,1,3,528,513,5,0,528,17,17,3,9,16,529,529,528,512,5,17,4,16,513,513]

theorem envBound54801 : H12AffineFastState.Bounded env54801 := by
  intro p hp
  have h : env54801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54800_54801 : H12AffineEnvironment.transform 4 17 env54800 = env54801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env54800 == env54801) = true)

theorem identity54801 : scanCanonicalize (H12AffineFastState.compose env54801 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound54801 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54802 : List Nat := [2,4,8,16,17,17,8,5,17,4,0,0,9,17,1,3,1,16,5,0,1,17,17,3,9,16,0,0,1,17,5,17,4,16,16,16]

theorem envBound54802 : H12AffineFastState.Bounded env54802 := by
  intro p hp
  have h : env54802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54801_54802 : H12AffineEnvironment.transform 8 17 env54801 = env54802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env54801 == env54802) = true)

theorem identity54802 : scanCanonicalize (H12AffineFastState.compose env54802 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound54802 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54803 : List Nat := [2,4,2,16,17,17,2,5,17,4,0,0,3,17,1,3,1,16,5,0,1,17,17,3,3,16,0,0,1,17,5,17,4,16,16,16]

theorem envBound54803 : H12AffineFastState.Bounded env54803 := by
  intro p hp
  have h : env54803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54802_54803 : H12AffineEnvironment.transform 2 2 env54802 = env54803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env54802 == env54803) = true)

def env54804 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10281,305,32769,2097152,4194304,4292919,4268073,8192,16,4262182,6332701,6410502,4270351,73791,2113537,257,2187275,2195750,512]

theorem envBound54804 : H12AffineFastState.Bounded env54804 := by
  intro p hp
  have h : env54804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54790_54804 : H12AffineEnvironment.transform 17 10281 env54790 = env54804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env54790 == env54804) = true)

theorem identity54804 : scanCanonicalize (H12AffineFastState.compose env54804 (packedSelected [0,7,16] rootPS)) = affineNative (2^(20+1) ^^^ 110619) := by decide +kernel

theorem selectedBound54804 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env54805 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,16400,10281,305,32769,110619,4194304,4292919,4268073,8192,16,4262182,4264198,4219165,4270351,73791,127002,257,53264,12605,512]

theorem envBound54805 : H12AffineFastState.Bounded env54805 := by
  intro p hp
  have h : env54805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54804_54805 : H12AffineEnvironment.transform 20 110619 env54804 = env54805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 110619 env54804 == env54805) = true)

theorem identity54805 : scanCanonicalize (H12AffineFastState.compose env54805 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(14+1) ^^^ 14621) := by decide +kernel

theorem selectedBound54805 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env54806 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,14621,65536,16400,10281,305,14620,67846,4194304,4274218,4268073,8192,16,4262182,4264198,4219165,4270351,73791,84231,257,26893,12605,512]

theorem envBound54806 : H12AffineFastState.Bounded env54806 := by
  intro p hp
  have h : env54806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54805_54806 : H12AffineEnvironment.transform 14 14621 env54805 = env54806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14621 env54805 == env54806) = true)

theorem identity54806 : scanCanonicalize (H12AffineFastState.compose env54806 (packedSelected [1,3,5,8,11,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound54806 : packedSelected [1,3,5,8,11,14,15,20] rootPS < 2^1333 := by decide +kernel

def env54807 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,2341,14621,65536,2357,10281,305,14620,67846,4194304,4274218,4268073,8192,16,4262182,4264198,4204600,4270351,73791,65570,257,8232,12605,512]

theorem envBound54807 : H12AffineFastState.Bounded env54807 := by
  intro p hp
  have h : env54807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54806_54807 : H12AffineEnvironment.transform 13 2341 env54806 = env54807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env54806 == env54807) = true)

theorem identity54807 : scanCanonicalize (H12AffineFastState.compose env54807 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 79931) := by decide +kernel

theorem selectedBound54807 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env54808 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,2341,14621,65536,2357,10281,305,14620,67846,79931,17,6162,8192,16,12573,10557,69635,4404,73791,65570,257,8232,12605,512]

theorem envBound54808 : H12AffineFastState.Bounded env54808 := by
  intro p hp
  have h : env54808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54807_54808 : H12AffineEnvironment.transform 21 79931 env54807 = env54808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 79931 env54807 == env54808) = true)

theorem identity54808 : scanCanonicalize (H12AffineFastState.compose env54808 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 6460) := by decide +kernel

theorem selectedBound54808 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54809 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,6460,2341,33,65536,2357,4373,305,32,67846,65799,17,6162,6460,16,2081,4097,69635,4404,71939,65570,257,6420,2049,512]

theorem envBound54809 : H12AffineFastState.Bounded env54809 := by
  intro p hp
  have h : env54809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54808_54809 : H12AffineEnvironment.transform 12 6460 env54808 = env54809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6460 env54808 == env54809) = true)

theorem identity54809 : scanCanonicalize (H12AffineFastState.compose env54809 (packedSelected [0,7] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound54809 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54810 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,6460,2341,33,262,2357,4373,305,32,2048,1,17,6162,6460,16,2081,4097,4357,4404,6149,292,257,6420,2049,512]

theorem envBound54810 : H12AffineFastState.Bounded env54810 := by
  intro p hp
  have h : env54810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54809_54810 : H12AffineEnvironment.transform 15 262 env54809 = env54810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env54809 == env54810) = true)

theorem identity54810 : scanCanonicalize (H12AffineFastState.compose env54810 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54810 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env54811 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,4096,6200,2081,33,2,2097,4113,53,32,2048,1,17,6162,6200,16,2081,4097,4097,4144,6149,32,5,6160,2049,512]

theorem envBound54811 : H12AffineFastState.Bounded env54811 := by
  intro p hp
  have h : env54811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54810_54811 : H12AffineEnvironment.transform 7 4 env54810 = env54811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54810 == env54811) = true)

theorem identity54811 : scanCanonicalize (H12AffineFastState.compose env54811 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54811 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env54812 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,4096,6169,2048,0,2,2064,4113,20,1,2048,1,17,6162,6169,16,2048,4097,4097,4113,6149,1,5,6160,2049,512]

theorem envBound54812 : H12AffineFastState.Bounded env54812 := by
  intro p hp
  have h : env54812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54811_54812 : H12AffineEnvironment.transform 4 1 env54811 = env54812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54811 == env54812) = true)

theorem identity54812 : scanCanonicalize (H12AffineFastState.compose env54812 (packedSelected [1,2,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound54812 : packedSelected [1,2,3,5,8] rootPS < 2^1333 := by decide +kernel

def env54813 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,9,2048,0,2,2064,2049,20,1,2048,1,17,2,9,16,2048,2065,2065,2049,21,1,5,0,2049,512]

theorem envBound54813 : H12AffineFastState.Bounded env54813 := by
  intro p hp
  have h : env54813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54812_54813 : H12AffineEnvironment.transform 11 2064 env54812 = env54813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env54812 == env54813) = true)

theorem identity54813 : scanCanonicalize (H12AffineFastState.compose env54813 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound54813 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54814 : List Nat := [2,4,8,16,1,17,8,4,1,21,2048,2064,9,2048,0,2,2064,2049,20,1,2048,1,17,2,9,16,2048,2065,2065,2049,21,1,5,0,2049,1]

theorem envBound54814 : H12AffineFastState.Bounded env54814 := by
  intro p hp
  have h : env54814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54813_54814 : H12AffineEnvironment.transform 8 1 env54813 = env54814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env54813 == env54814) = true)

theorem identity54814 : scanCanonicalize (H12AffineFastState.compose env54814 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound54814 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54815 : List Nat := [2,4,8,4,1,5,8,4,1,1,2048,2052,9,2048,0,2,2052,2049,0,1,2048,1,5,2,9,4,2048,2053,2053,2049,1,1,5,0,2049,1]

theorem envBound54815 : H12AffineFastState.Bounded env54815 := by
  intro p hp
  have h : env54815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54814_54815 : H12AffineEnvironment.transform 3 4 env54814 = env54815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env54814 == env54815) = true)

def leafEnv54815 : List Nat := [2,4,8,4,1,5,8,4,1,1,2048,2052,9,2048,0,2,2052,2049,0,1,2048,1,5,2,0,9,1,4,2048,2053,2053,2049,1,1,5,0,5,2,2049,1,1,2049,0]

def active54815 : List Nat := [0,1,2,10]

def tree54815 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54815 : H12WitnessSearch.Good tree54815 := H12GlobalWitnessIndex.good

theorem leafIdentity54815 : H12AffineFastState.composeSystem env54815 rootObs = leafEnv54815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54815 rootObs == leafEnv54815) = true)

theorem terminalChecked54815 : H12PackedTerminal.terminalCheckFast leafEnv54815 active54815 tree54815 = true := by decide +kernel

def env54816 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,8388608,8685879,8192,16,4262182,10815490,10506288,8683537,329751,15067422,257,2443299,2468110,272937]

theorem envBound54816 : H12AffineFastState.Bounded env54816 := by
  intro p hp
  have h : env54816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54788_54816 : H12AffineEnvironment.transform 9 305 env54788 = env54816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env54788 == env54816) = true)

theorem identity54816 : scanCanonicalize (H12AffineFastState.compose env54816 (packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS)) = affineNative (2^(22+1) ^^^ 4292918) := by decide +kernel

theorem selectedBound54816 : packedSelected [3,7,9,10,17,20,21,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env54817 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,262144,304,32769,2097152,4194304,4292918,4524033,8192,16,4262182,6588724,6410502,4522279,329751,2385960,257,2443299,2468110,272937]

theorem envBound54817 : H12AffineFastState.Bounded env54817 := by
  intro p hp
  have h : env54817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54816_54817 : H12AffineEnvironment.transform 22 4292918 env54816 = env54817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4292918 env54816 == env54817) = true)

theorem identity54817 : scanCanonicalize (H12AffineFastState.compose env54817 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54817 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54818 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,4194304,4292918,4268073,8192,16,4262182,6332700,6410502,4270351,73791,2113536,257,2187275,2195750,513]

theorem envBound54818 : H12AffineFastState.Bounded env54818 := by
  intro p hp
  have h : env54818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54817_54818 : H12AffineEnvironment.transform 17 10280 env54817 = env54818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54817 == env54818) = true)

theorem identity54818 : scanCanonicalize (H12AffineFastState.compose env54818 (packedSelected [1,2,4,6,8,9,11,19] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound54818 : packedSelected [1,2,4,6,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env54819 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,16400,10280,304,32769,2097152,41261,73755,98564,8192,16,108555,2097201,2191403,100386,73791,2113536,257,2187275,2195750,513]

theorem envBound54819 : H12AffineFastState.Bounded env54819 := by
  intro p hp
  have h : env54819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54818_54819 : H12AffineEnvironment.transform 21 41261 env54818 = env54819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env54818 == env54819) = true)

theorem identity54819 : scanCanonicalize (H12AffineFastState.compose env54819 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54819 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env54820 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,8202,16400,10280,304,32769,2097152,41261,17,41230,8192,16,34817,2097201,2117665,43048,53,2113536,257,2113537,2138412,513]

theorem envBound54820 : H12AffineFastState.Bounded env54820 := by
  intro p hp
  have h : env54820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54819_54820 : H12AffineEnvironment.transform 15 8202 env54819 = env54820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54819 == env54820) = true)

theorem identity54820 : scanCanonicalize (H12AffineFastState.compose env54820 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54820 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env54821 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,1,8202,16400,10280,304,0,2097152,8492,17,8463,8192,16,2048,2097201,2117665,10281,53,2113536,257,2113537,2105645,513]

theorem envBound54821 : H12AffineFastState.Bounded env54821 := by
  intro p hp
  have h : env54821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54820_54821 : H12AffineEnvironment.transform 14 1 env54820 = env54821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54820 == env54821) = true)

theorem identity54821 : scanCanonicalize (H12AffineFastState.compose env54821 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54821 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54822 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,268,16384,1,262,16400,2340,304,0,2097152,32,17,3,268,16,2048,2097201,2117665,2341,53,2113536,257,2113537,2097185,513]

theorem envBound54822 : H12AffineFastState.Bounded env54822 := by
  intro p hp
  have h : env54822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54821_54822 : H12AffineEnvironment.transform 12 268 env54821 = env54822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54821 == env54822) = true)

theorem identity54822 : scanCanonicalize (H12AffineFastState.compose env54822 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 6672) := by decide +kernel

theorem selectedBound54822 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54823 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,268,16384,1,262,16400,2340,304,0,6672,32,17,3,268,16,2048,6689,18993,2341,53,23056,257,23057,6705,513]

theorem envBound54823 : H12AffineFastState.Bounded env54823 := by
  intro p hp
  have h : env54823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54822_54823 : H12AffineEnvironment.transform 20 6672 env54822 = env54823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6672 env54822 == env54823) = true)

theorem identity54823 : scanCanonicalize (H12AffineFastState.compose env54823 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 6704) := by decide +kernel

theorem selectedBound54823 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54824 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,268,6704,1,262,6688,2340,304,0,6672,32,17,3,268,16,2048,6689,4097,2341,53,32,257,33,6705,513]

theorem envBound54824 : H12AffineFastState.Bounded env54824 := by
  intro p hp
  have h : env54824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54823_54824 : H12AffineEnvironment.transform 13 6704 env54823 = env54824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6704 env54823 == env54824) = true)

theorem identity54824 : scanCanonicalize (H12AffineFastState.compose env54824 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound54824 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54825 : List Nat := [2,4,8,16,32,17,8,256,512,305,789,4096,268,4389,1,262,4405,561,304,0,4357,32,17,3,268,16,789,4404,4097,560,53,32,257,33,4388,513]

theorem envBound54825 : H12AffineFastState.Bounded env54825 := by
  intro p hp
  have h : env54825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54824_54825 : H12AffineEnvironment.transform 10 789 env54824 = env54825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env54824 == env54825) = true)

theorem identity54825 : scanCanonicalize (H12AffineFastState.compose env54825 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound54825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54826 : List Nat := [2,4,8,16,32,17,8,256,512,305,789,545,268,772,1,262,788,561,304,0,804,32,17,3,268,16,789,789,544,560,53,32,257,33,773,513]

theorem envBound54826 : H12AffineFastState.Bounded env54826 := by
  intro p hp
  have h : env54826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54825_54826 : H12AffineEnvironment.transform 11 545 env54825 = env54826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env54825 == env54826) = true)

theorem identity54826 : scanCanonicalize (H12AffineFastState.compose env54826 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54826 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54827 : List Nat := [2,4,8,16,32,17,8,4,512,53,529,545,8,512,1,2,528,561,52,0,544,32,17,3,8,16,529,529,544,560,53,32,5,33,513,513]

theorem envBound54827 : H12AffineFastState.Bounded env54827 := by
  intro p hp
  have h : env54827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54826_54827 : H12AffineEnvironment.transform 7 4 env54826 = env54827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54826 == env54827) = true)

theorem identity54827 : scanCanonicalize (H12AffineFastState.compose env54827 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound54827 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54828 : List Nat := [2,4,8,16,16,17,8,4,512,5,529,529,8,512,1,2,528,513,4,0,528,16,17,3,8,16,529,529,528,512,5,16,5,17,513,513]

theorem envBound54828 : H12AffineFastState.Bounded env54828 := by
  intro p hp
  have h : env54828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54827_54828 : H12AffineEnvironment.transform 4 16 env54827 = env54828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env54827 == env54828) = true)

theorem identity54828 : scanCanonicalize (H12AffineFastState.compose env54828 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound54828 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54829 : List Nat := [2,4,8,16,16,17,8,4,17,5,0,0,8,17,1,2,1,16,4,0,1,16,17,3,8,16,0,0,1,17,5,16,5,17,16,16]

theorem envBound54829 : H12AffineFastState.Bounded env54829 := by
  intro p hp
  have h : env54829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54828_54829 : H12AffineEnvironment.transform 8 17 env54828 = env54829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env54828 == env54829) = true)

theorem identity54829 : scanCanonicalize (H12AffineFastState.compose env54829 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound54829 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54830 : List Nat := [2,4,3,16,16,17,3,4,17,5,0,0,3,17,1,2,1,16,4,0,1,16,17,3,3,16,0,0,1,17,5,16,5,17,16,16]

theorem envBound54830 : H12AffineFastState.Bounded env54830 := by
  intro p hp
  have h : env54830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54829_54830 : H12AffineEnvironment.transform 2 3 env54829 = env54830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env54829 == env54830) = true)

def env54831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,8388608,8685926,8192,65,4262262,10816866,10507600,8683536,331127,15068207,257,2444611,2468974,272937]

theorem envBound54831 : H12AffineFastState.Bounded env54831 := by
  intro p hp
  have h : env54831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54739_54831 : H12AffineEnvironment.transform 16 16401 env54739 = env54831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env54739 == env54831) = true)

theorem identity54831 : scanCanonicalize (H12AffineFastState.compose env54831 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound54831 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429902,8192,65,4262262,10560842,10507600,8431672,75103,14795783,257,2188651,2196550,513]

theorem envBound54832 : H12AffineFastState.Bounded env54832 := by
  intro p hp
  have h : env54832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54831_54832 : H12AffineEnvironment.transform 17 10280 env54831 = env54832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env54831 == env54832) = true)

def env54833 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429854,8192,17,4262182,10560794,10507520,8431672,75023,14795783,257,2188603,2196502,513]

theorem envBound54833 : H12AffineFastState.Bounded env54833 := by
  intro p hp
  have h : env54833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54832_54833 : H12AffineEnvironment.transform 5 16 env54832 = env54833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54832 == env54833) = true)

theorem identity54833 : scanCanonicalize (H12AffineFastState.compose env54833 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4268091) := by decide +kernel

theorem selectedBound54833 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54834 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4268091,4292901,8192,17,4262182,6292769,6387003,4294659,75023,2155580,257,2188603,2196502,513]

theorem envBound54834 : H12AffineFastState.Bounded env54834 := by
  intro p hp
  have h : env54834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54833_54834 : H12AffineEnvironment.transform 22 4268091 env54833 = env54834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4268091 env54833 == env54834) = true)

theorem identity54834 : scanCanonicalize (H12AffineFastState.compose env54834 (packedSelected [0,3,4,5,7,9,12,14,19] rootPS)) = affineNative (2^(20+1) ^^^ 91419) := by decide +kernel

theorem selectedBound54834 : packedSelected [0,3,4,5,7,9,12,14,19] rootPS < 2^1333 := by decide +kernel

def env54835 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,91419,4194304,4268091,4292901,8192,17,4262182,4284474,4198432,4294659,75023,98599,257,32,57613,513]

theorem envBound54835 : H12AffineFastState.Bounded env54835 := by
  intro p hp
  have h : env54835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54834_54835 : H12AffineEnvironment.transform 20 91419 env54834 = env54835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91419 env54834 == env54835) = true)

theorem identity54835 : scanCanonicalize (H12AffineFastState.compose env54835 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound54835 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54836 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,16401,10280,1025,32769,25628,4194304,4202812,4227106,8192,17,4196385,4219197,4198432,4229380,9224,32800,257,32,57613,513]

theorem envBound54836 : H12AffineFastState.Bounded env54836 := by
  intro p hp
  have h : env54836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54835_54836 : H12AffineEnvironment.transform 15 263 env54835 = env54836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env54835 == env54836) = true)

theorem identity54836 : scanCanonicalize (H12AffineFastState.compose env54836 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(21+1) ^^^ 41260) := by decide +kernel

theorem selectedBound54836 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env54837 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,263,16401,10280,1025,32769,25628,41260,32784,8462,8192,17,43277,49169,45324,10280,9224,32800,257,32,57613,513]

theorem envBound54837 : H12AffineFastState.Bounded env54837 := by
  intro p hp
  have h : env54837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54836_54837 : H12AffineEnvironment.transform 21 41260 env54836 = env54837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41260 env54836 == env54837) = true)

theorem identity54837 : scanCanonicalize (H12AffineFastState.compose env54837 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54837 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54838 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16401,2340,1025,32769,17680,32800,32784,2,268,17,34817,49169,36864,2340,1284,32800,257,32,49153,513]

theorem envBound54838 : H12AffineFastState.Bounded env54838 := by
  intro p hp
  have h : env54838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54837_54838 : H12AffineEnvironment.transform 12 268 env54837 = env54838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54837 == env54838) = true)

theorem identity54838 : scanCanonicalize (H12AffineFastState.compose env54838 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54838 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env54839 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,16401,2340,1025,0,17680,33,17,2,268,17,2048,16400,4097,2340,1284,33,257,32,16384,513]

theorem envBound54839 : H12AffineFastState.Bounded env54839 := by
  intro p hp
  have h : env54839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54838_54839 : H12AffineEnvironment.transform 14 1 env54838 = env54839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54838 == env54839) = true)

theorem identity54839 : scanCanonicalize (H12AffineFastState.compose env54839 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound54839 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54840 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5156,1,263,5173,2340,1025,0,4404,33,17,2,268,17,2048,5172,4097,2340,1284,33,257,32,5156,513]

theorem envBound54840 : H12AffineFastState.Bounded env54840 := by
  intro p hp
  have h : env54840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54839_54840 : H12AffineEnvironment.transform 13 5156 env54839 = env54840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env54839 == env54840) = true)

def env54841 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3888,268,2836,1,263,2821,2340,1025,0,3588,33,17,2,268,17,2048,2820,3889,2340,1284,33,257,32,2836,513]

theorem envBound54841 : H12AffineFastState.Bounded env54841 := by
  intro p hp
  have h : env54841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54840_54841 : H12AffineEnvironment.transform 11 3888 env54840 = env54841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env54840 == env54841) = true)

def env54842 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,48,268,1044,1,263,1029,1572,1025,0,260,33,17,2,268,17,1792,1028,49,1572,1284,33,257,32,1044,513]

theorem envBound54842 : H12AffineFastState.Bounded env54842 := by
  intro p hp
  have h : env54842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54841_54842 : H12AffineEnvironment.transform 10 1792 env54841 = env54842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env54841 == env54842) = true)

theorem identity54842 : scanCanonicalize (H12AffineFastState.compose env54842 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound54842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54843 : List Nat := [2,4,8,16,32,16,8,256,512,517,261,48,268,529,1,263,512,33,516,0,260,33,17,2,268,17,261,513,49,33,769,33,257,32,529,513]

theorem envBound54843 : H12AffineFastState.Bounded env54843 := by
  intro p hp
  have h : env54843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54842_54843 : H12AffineEnvironment.transform 9 517 env54842 = env54843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env54842 == env54843) = true)

def env54844 : List Nat := [2,4,8,16,32,16,8,256,48,53,261,48,268,33,1,263,48,33,52,0,260,33,17,2,268,17,261,49,49,33,305,33,257,32,33,49]

theorem envBound54844 : H12AffineFastState.Bounded env54844 := by
  intro p hp
  have h : env54844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54843_54844 : H12AffineEnvironment.transform 8 48 env54843 = env54844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54843 == env54844) = true)

def env54845 : List Nat := [2,4,8,16,32,16,8,256,49,52,261,48,268,32,1,263,49,33,53,0,260,33,17,2,268,17,261,48,49,33,304,33,257,32,32,48]

theorem envBound54845 : H12AffineFastState.Bounded env54845 := by
  intro p hp
  have h : env54845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54843_54845 : H12AffineEnvironment.transform 8 49 env54843 = env54845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54843 == env54845) = true)

theorem identity54845 : scanCanonicalize (H12AffineFastState.compose env54845 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound54845 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54846 : List Nat := [2,4,8,16,32,16,8,62,49,52,59,48,50,32,1,57,49,33,53,0,58,33,17,2,50,17,59,48,49,33,14,33,63,32,32,48]

theorem envBound54846 : H12AffineFastState.Bounded env54846 := by
  intro p hp
  have h : env54846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54845_54846 : H12AffineEnvironment.transform 7 62 env54845 = env54846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env54845 == env54846) = true)

def leafEnv54846 : List Nat := [2,4,8,16,32,16,8,62,49,52,59,48,50,32,1,57,49,33,53,0,58,33,17,2,15,50,1,17,59,48,49,33,14,33,63,32,5,57,32,48,1,58,0]

def active54846 : List Nat := [0,1,2,3,4]

def tree54846 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54846 : H12WitnessSearch.Good tree54846 := H12GlobalWitnessIndex.good

theorem leafIdentity54846 : H12AffineFastState.composeSystem env54846 rootObs = leafEnv54846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54846 rootObs == leafEnv54846) = true)

theorem terminalChecked54846 : H12PackedTerminal.terminalCheckFast leafEnv54846 active54846 tree54846 = true := by decide +kernel

def env54847 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,49,268,1045,1,263,1028,1573,1025,0,261,33,17,2,268,17,1793,1029,48,1573,1284,33,257,32,1045,513]

theorem envBound54847 : H12AffineFastState.Bounded env54847 := by
  intro p hp
  have h : env54847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54841_54847 : H12AffineEnvironment.transform 10 1793 env54841 = env54847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env54841 == env54847) = true)

theorem identity54847 : scanCanonicalize (H12AffineFastState.compose env54847 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound54847 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54848 : List Nat := [2,4,8,16,32,16,8,256,277,1024,1044,49,268,1045,1,263,1028,1328,1025,0,261,33,17,2,268,17,1044,1029,48,1328,1284,33,257,32,1045,276]

theorem envBound54848 : H12AffineFastState.Bounded env54848 := by
  intro p hp
  have h : env54848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54847_54848 : H12AffineEnvironment.transform 8 277 env54847 = env54848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env54847 == env54848) = true)

def env54849 : List Nat := [2,4,8,16,32,16,8,256,277,52,32,49,268,33,1,263,48,260,53,0,261,33,17,2,268,17,32,49,48,260,304,33,257,32,33,276]

theorem envBound54849 : H12AffineFastState.Bounded env54849 := by
  intro p hp
  have h : env54849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54848_54849 : H12AffineEnvironment.transform 9 52 env54848 = env54849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54848 == env54849) = true)

theorem identity54849 : scanCanonicalize (H12AffineFastState.compose env54849 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54849 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54850 : List Nat := [2,4,8,11,32,11,8,256,270,47,32,42,268,33,1,263,43,260,46,0,261,33,10,2,268,10,32,42,43,260,299,33,257,32,33,271]

theorem envBound54850 : H12AffineFastState.Bounded env54850 := by
  intro p hp
  have h : env54850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54849_54850 : H12AffineEnvironment.transform 3 11 env54849 = env54850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54849 == env54850) = true)

def leafEnv54850 : List Nat := [2,4,8,11,32,11,8,256,270,47,32,42,268,33,1,263,43,260,46,0,261,33,10,2,298,268,1,10,32,42,43,260,299,33,257,32,5,263,33,271,1,261,0]

def active54850 : List Nat := [0,1,2,4,7]

def tree54850 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54850 : H12WitnessSearch.Good tree54850 := H12GlobalWitnessIndex.good

theorem leafIdentity54850 : H12AffineFastState.composeSystem env54850 rootObs = leafEnv54850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54850 rootObs == leafEnv54850) = true)

theorem terminalChecked54850 : H12PackedTerminal.terminalCheckFast leafEnv54850 active54850 tree54850 = true := by decide +kernel

def env54851 : List Nat := [2,4,8,16,32,16,8,256,277,53,33,49,268,32,1,263,49,261,52,0,261,33,17,2,268,17,33,48,48,261,305,33,257,32,32,276]

theorem envBound54851 : H12AffineFastState.Bounded env54851 := by
  intro p hp
  have h : env54851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54848_54851 : H12AffineEnvironment.transform 9 53 env54848 = env54851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54848 == env54851) = true)

def env54852 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3889,268,2837,1,263,2820,2340,1025,0,3589,33,17,2,268,17,2048,2821,3888,2340,1284,33,257,32,2837,513]

theorem envBound54852 : H12AffineFastState.Bounded env54852 := by
  intro p hp
  have h : env54852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54840_54852 : H12AffineEnvironment.transform 11 3889 env54840 = env54852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env54840 == env54852) = true)

def env54853 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1792,49,268,1045,1,263,1028,1572,1025,0,261,33,17,2,268,17,1792,1029,48,1572,1284,33,257,32,1045,513]

theorem envBound54853 : H12AffineFastState.Bounded env54853 := by
  intro p hp
  have h : env54853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54852_54853 : H12AffineEnvironment.transform 10 1792 env54852 = env54853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env54852 == env54853) = true)

theorem identity54853 : scanCanonicalize (H12AffineFastState.compose env54853 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound54853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54854 : List Nat := [2,4,8,16,32,16,8,256,48,1024,1328,49,268,1045,1,263,1028,1044,1025,0,261,33,17,2,268,17,1328,1029,48,1044,1284,33,257,32,1045,49]

theorem envBound54854 : H12AffineFastState.Bounded env54854 := by
  intro p hp
  have h : env54854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54853_54854 : H12AffineEnvironment.transform 8 48 env54853 = env54854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54853 == env54854) = true)

def env54855 : List Nat := [2,4,8,16,32,16,8,256,48,52,260,49,268,33,1,263,48,32,53,0,261,33,17,2,268,17,260,49,48,32,304,33,257,32,33,49]

theorem envBound54855 : H12AffineFastState.Bounded env54855 := by
  intro p hp
  have h : env54855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54854_54855 : H12AffineEnvironment.transform 9 52 env54854 = env54855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54854 == env54855) = true)

theorem identity54855 : scanCanonicalize (H12AffineFastState.compose env54855 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound54855 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54856 : List Nat := [2,4,8,16,32,16,8,62,48,52,58,49,50,33,1,57,48,32,53,0,59,33,17,2,50,17,58,49,48,32,14,33,63,32,33,49]

theorem envBound54856 : H12AffineFastState.Bounded env54856 := by
  intro p hp
  have h : env54856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54855_54856 : H12AffineEnvironment.transform 7 62 env54855 = env54856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env54855 == env54856) = true)

def leafEnv54856 : List Nat := [2,4,8,16,32,16,8,62,48,52,58,49,50,33,1,57,48,32,53,0,59,33,17,2,15,50,1,17,58,49,48,32,14,33,63,32,5,57,33,49,1,59,0]

def active54856 : List Nat := [0,1,2,3,4]

def tree54856 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54856 : H12WitnessSearch.Good tree54856 := H12GlobalWitnessIndex.good

theorem leafIdentity54856 : H12AffineFastState.composeSystem env54856 rootObs = leafEnv54856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54856 rootObs == leafEnv54856) = true)

theorem terminalChecked54856 : H12PackedTerminal.terminalCheckFast leafEnv54856 active54856 tree54856 = true := by decide +kernel

def env54857 : List Nat := [2,4,8,16,32,16,8,256,48,53,261,49,268,32,1,263,49,33,52,0,261,33,17,2,268,17,261,48,48,33,305,33,257,32,32,49]

theorem envBound54857 : H12AffineFastState.Bounded env54857 := by
  intro p hp
  have h : env54857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54854_54857 : H12AffineEnvironment.transform 9 53 env54854 = env54857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54854 == env54857) = true)

def env54858 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1793,48,268,1044,1,263,1029,1573,1025,0,260,33,17,2,268,17,1793,1028,49,1573,1284,33,257,32,1044,513]

theorem envBound54858 : H12AffineFastState.Bounded env54858 := by
  intro p hp
  have h : env54858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54852_54858 : H12AffineEnvironment.transform 10 1793 env54852 = env54858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env54852 == env54858) = true)

theorem identity54858 : scanCanonicalize (H12AffineFastState.compose env54858 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound54858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54859 : List Nat := [2,4,8,16,32,16,8,256,512,800,33,48,268,820,1,263,805,261,801,0,260,33,17,2,268,17,33,804,49,261,548,33,257,32,820,513]

theorem envBound54859 : H12AffineFastState.Bounded env54859 := by
  intro p hp
  have h : env54859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54858_54859 : H12AffineEnvironment.transform 9 800 env54858 = env54859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env54858 == env54859) = true)

def env54860 : List Nat := [2,4,8,16,32,16,8,256,276,52,33,48,268,32,1,263,49,261,53,0,260,33,17,2,268,17,33,48,49,261,304,33,257,32,32,277]

theorem envBound54860 : H12AffineFastState.Bounded env54860 := by
  intro p hp
  have h : env54860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54859_54860 : H12AffineEnvironment.transform 8 276 env54859 = env54860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env54859 == env54860) = true)

theorem identity54860 : scanCanonicalize (H12AffineFastState.compose env54860 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound54860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54861 : List Nat := [2,4,8,11,32,11,8,256,271,47,33,43,268,32,1,263,42,261,46,0,260,33,10,2,268,10,33,43,42,261,299,33,257,32,32,270]

theorem envBound54861 : H12AffineFastState.Bounded env54861 := by
  intro p hp
  have h : env54861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54860_54861 : H12AffineEnvironment.transform 3 11 env54860 = env54861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env54860 == env54861) = true)

def leafEnv54861 : List Nat := [2,4,8,11,32,11,8,256,271,47,33,43,268,32,1,263,42,261,46,0,260,33,10,2,298,268,1,10,33,43,42,261,299,33,257,32,5,263,32,270,1,260,0]

def active54861 : List Nat := [0,1,2,4,7]

def tree54861 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54861 : H12WitnessSearch.Good tree54861 := H12GlobalWitnessIndex.good

theorem leafIdentity54861 : H12AffineFastState.composeSystem env54861 rootObs = leafEnv54861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54861 rootObs == leafEnv54861) = true)

theorem terminalChecked54861 : H12PackedTerminal.terminalCheckFast leafEnv54861 active54861 tree54861 = true := by decide +kernel

def env54862 : List Nat := [2,4,8,16,32,16,8,256,277,53,33,48,268,33,1,263,48,261,52,0,260,33,17,2,268,17,33,49,49,261,305,33,257,32,33,276]

theorem envBound54862 : H12AffineFastState.Bounded env54862 := by
  intro p hp
  have h : env54862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54859_54862 : H12AffineEnvironment.transform 8 277 env54859 = env54862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env54859 == env54862) = true)

def env54863 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,8388608,8429855,8192,16,4262183,10560795,10507521,8431672,75022,14795783,257,2188602,2196503,513]

theorem envBound54863 : H12AffineFastState.Bounded env54863 := by
  intro p hp
  have h : env54863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54832_54863 : H12AffineEnvironment.transform 5 17 env54832 = env54863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54832 == env54863) = true)

theorem identity54863 : scanCanonicalize (H12AffineFastState.compose env54863 (packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS)) = affineNative (2^(22+1) ^^^ 4194353) := by decide +kernel

theorem selectedBound54863 : packedSelected [0,1,3,5,7,8,10,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env54864 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,4194304,4194353,4235566,8192,16,4262183,6366506,6313264,4237321,75022,2212918,257,2188602,2196503,513]

theorem envBound54864 : H12AffineFastState.Bounded env54864 := by
  intro p hp
  have h : env54864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54863_54864 : H12AffineEnvironment.transform 22 4194353 env54863 = env54864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4194353 env54863 == env54864) = true)

theorem identity54864 : scanCanonicalize (H12AffineFastState.compose env54864 (packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS)) = affineNative (2^(21+1) ^^^ 2122812) := by decide +kernel

theorem selectedBound54864 : packedSelected [1,2,4,6,8,9,10,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env54865 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,2097152,2122812,2122765,2147602,8192,16,2190619,82198,12556,2149429,75022,2212918,257,2188602,2196503,513]

theorem envBound54865 : H12AffineFastState.Bounded env54865 := by
  intro p hp
  have h : env54865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54864_54865 : H12AffineEnvironment.transform 21 2122812 env54864 = env54865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2122812 env54864 == env54865) = true)

theorem identity54865 : scanCanonicalize (H12AffineFastState.compose env54865 (packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound54865 : packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env54866 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,32768,65536,16401,2340,1025,32769,2097152,2114864,2114817,2147602,268,16,2182167,82198,4096,2149429,66562,2212918,257,2180150,2196503,513]

theorem envBound54866 : H12AffineFastState.Bounded env54866 := by
  intro p hp
  have h : env54866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54865_54866 : H12AffineEnvironment.transform 12 268 env54865 = env54866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env54865 == env54866) = true)

theorem identity54866 : scanCanonicalize (H12AffineFastState.compose env54866 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54866 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env54867 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,65536,16401,2340,1025,0,2097152,2114864,2114817,2114835,268,16,2182167,82198,4096,2116660,66562,2180151,257,2180150,2163734,513]

theorem envBound54867 : H12AffineFastState.Bounded env54867 := by
  intro p hp
  have h : env54867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54866_54867 : H12AffineEnvironment.transform 14 1 env54866 = env54867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54866 == env54867) = true)

theorem identity54867 : scanCanonicalize (H12AffineFastState.compose env54867 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound54867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env54868 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,1,263,16401,2340,1025,0,2097152,2114864,2114817,2114835,268,16,2116880,16401,4096,2116660,1285,2114864,257,2114865,2098449,513]

theorem envBound54868 : H12AffineFastState.Bounded env54868 := by
  intro p hp
  have h : env54868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54867_54868 : H12AffineEnvironment.transform 15 263 env54867 = env54868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env54867 == env54868) = true)

theorem identity54868 : scanCanonicalize (H12AffineFastState.compose env54868 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound54868 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env54869 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1573,4096,268,16384,1,263,16401,1793,1025,0,2097152,2114864,2114817,2114835,268,16,2114357,16401,4096,2114065,1285,2114864,257,2114865,2098449,513]

theorem envBound54869 : H12AffineFastState.Bounded env54869 := by
  intro p hp
  have h : env54869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54868_54869 : H12AffineEnvironment.transform 10 1573 env54868 = env54869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env54868 == env54869) = true)

theorem identity54869 : scanCanonicalize (H12AffineFastState.compose env54869 (packedSelected [4,7] rootPS)) = affineNative (2^(20+1) ^^^ 21008) := by decide +kernel

theorem selectedBound54869 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env54870 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1573,4096,268,16384,1,263,16401,1793,1025,0,21008,5920,5905,5891,268,16,4389,16401,4096,4097,1285,5920,257,5921,22273,513]

theorem envBound54870 : H12AffineFastState.Bounded env54870 := by
  intro p hp
  have h : env54870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54869_54870 : H12AffineEnvironment.transform 20 21008 env54869 = env54870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 21008 env54869 == env54870) = true)

theorem identity54870 : scanCanonicalize (H12AffineFastState.compose env54870 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54870 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env54871 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1573,4096,268,5157,1,263,5172,1793,1025,0,1589,5920,5905,5891,268,16,4389,5172,4096,4097,1285,5920,257,5921,804,513]

theorem envBound54871 : H12AffineFastState.Bounded env54871 := by
  intro p hp
  have h : env54871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54870_54871 : H12AffineEnvironment.transform 13 5157 env54870 = env54871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54870 == env54871) = true)

theorem identity54871 : scanCanonicalize (H12AffineFastState.compose env54871 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54871 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env54872 : List Nat := [2,4,8,16,32,17,8,256,512,272,821,4096,268,4405,1,263,4388,529,273,0,805,4656,4609,4627,268,16,4389,4388,4096,4097,21,4656,257,4657,804,513]

theorem envBound54872 : H12AffineFastState.Bounded env54872 := by
  intro p hp
  have h : env54872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54871_54872 : H12AffineEnvironment.transform 9 272 env54871 = env54872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54871 == env54872) = true)

theorem identity54872 : scanCanonicalize (H12AffineFastState.compose env54872 (packedSelected [1,3,10] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound54872 : packedSelected [1,3,10] rootPS < 2^1333 := by decide +kernel

def env54873 : List Nat := [2,4,8,16,32,17,8,256,512,272,821,528,268,805,1,263,820,529,273,0,805,32,17,3,268,16,821,820,528,529,21,32,257,33,804,513]

theorem envBound54873 : H12AffineFastState.Bounded env54873 := by
  intro p hp
  have h : env54873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54872_54873 : H12AffineEnvironment.transform 11 528 env54872 = env54873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env54872 == env54873) = true)

theorem identity54873 : scanCanonicalize (H12AffineFastState.compose env54873 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound54873 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54874 : List Nat := [2,4,8,16,32,17,8,5,512,21,560,528,9,544,1,2,561,529,20,0,544,32,17,3,9,16,560,561,528,529,21,32,4,33,545,513]

theorem envBound54874 : H12AffineFastState.Bounded env54874 := by
  intro p hp
  have h : env54874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54873_54874 : H12AffineEnvironment.transform 7 5 env54873 = env54874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env54873 == env54874) = true)

theorem identity54874 : scanCanonicalize (H12AffineFastState.compose env54874 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound54874 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54875 : List Nat := [2,4,8,16,0,17,8,5,512,21,528,528,9,512,1,2,529,529,20,0,512,0,17,3,9,16,528,529,528,529,21,0,4,1,513,513]

theorem envBound54875 : H12AffineFastState.Bounded env54875 := by
  intro p hp
  have h : env54875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54874_54875 : H12AffineEnvironment.transform 4 0 env54874 = env54875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env54874 == env54875) = true)

theorem identity54875 : scanCanonicalize (H12AffineFastState.compose env54875 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound54875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54876 : List Nat := [2,4,8,16,0,17,8,5,10,21,26,26,9,10,1,2,27,27,20,0,10,0,17,3,9,16,26,27,26,27,21,0,4,1,11,11]

theorem envBound54876 : H12AffineFastState.Bounded env54876 := by
  intro p hp
  have h : env54876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54875_54876 : H12AffineEnvironment.transform 8 10 env54875 = env54876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env54875 == env54876) = true)

def env54877 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8685926,8193,65,4409703,10816867,10507600,8830977,331127,15068206,257,2444610,2468974,272936]

theorem envBound54877 : H12AffineFastState.Bounded env54877 := by
  intro p hp
  have h : env54877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54738_54877 : H12AffineEnvironment.transform 6 9 env54738 = env54877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env54738 == env54877) = true)

theorem identity54877 : scanCanonicalize (H12AffineFastState.compose env54877 (packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS)) = affineNative (2^(22+1) ^^^ 4415530) := by decide +kernel

theorem selectedBound54877 : packedSelected [1,4,5,7,8,9,11,14,16,17,18,19,20,21,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env54878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,4415530,4712780,8193,65,4409703,6712649,6501754,4562987,331127,2526212,257,2444610,2468974,272936]

theorem envBound54878 : H12AffineFastState.Bounded env54878 := by
  intro p hp
  have h : env54878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54877_54878 : H12AffineEnvironment.transform 22 4415530 env54877 = env54878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4415530 env54877 == env54878) = true)

def env54879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,4268090,4565340,8193,65,4262263,6565209,6387050,4562987,331127,2411540,257,2444610,2468974,272936]

theorem envBound54879 : H12AffineFastState.Bounded env54879 := by
  intro p hp
  have h : env54879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54878_54879 : H12AffineEnvironment.transform 16 16400 env54878 = env54879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env54878 == env54879) = true)

theorem identity54879 : scanCanonicalize (H12AffineFastState.compose env54879 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound54879 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1025,8540,2097152,4194304,4268090,4524033,8193,65,4262263,6565209,6387050,4522358,331127,2387273,257,2444610,2428211,272936]

theorem envBound54880 : H12AffineFastState.Bounded env54880 := by
  intro p hp
  have h : env54880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54879_54880 : H12AffineEnvironment.transform 14 8541 env54879 = env54880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env54879 == env54880) = true)

theorem identity54880 : scanCanonicalize (H12AffineFastState.compose env54880 (packedSelected [1,3,5,8,10,16,19,20,21] rootPS)) = affineNative (2^(21+1) ^^^ 272392) := by decide +kernel

theorem selectedBound54880 : packedSelected [1,3,5,8,10,16,19,20,21] rootPS < 2^1333 := by decide +kernel

def env54881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1025,8540,2097152,272392,329778,73737,8193,65,336255,2098513,2448738,76158,331127,2387273,257,2444610,2428211,272936]

theorem envBound54881 : H12AffineFastState.Bounded env54881 := by
  intro p hp
  have h : env54881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54880_54881 : H12AffineEnvironment.transform 21 272392 env54880 = env54881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272392 env54880 == env54881) = true)

theorem identity54881 : scanCanonicalize (H12AffineFastState.compose env54881 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound54881 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,17,19] rootPS < 2^1333 := by decide +kernel

def env54882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,23809,1025,8540,2097152,29961,87347,73737,8193,65,97406,2098513,2162787,76158,86134,2109512,257,2166851,2183218,30505]

theorem envBound54882 : H12AffineFastState.Bounded env54882 := by
  intro p hp
  have h : env54882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54881_54882 : H12AffineEnvironment.transform 17 23809 env54881 = env54882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env54881 == env54882) = true)

theorem identity54882 : scanCanonicalize (H12AffineFastState.compose env54882 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54882 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,23809,1025,8540,2097152,29961,30009,3,8193,65,23668,2098513,2105449,2420,28796,2109512,257,2109513,2125880,30505]

theorem envBound54883 : H12AffineFastState.Bounded env54883 := by
  intro p hp
  have h : env54883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54882_54883 : H12AffineEnvironment.transform 15 8202 env54882 = env54883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54882 == env54883) = true)

theorem identity54883 : scanCanonicalize (H12AffineFastState.compose env54883 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound54883 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,23809,1025,8540,17728,29961,30009,3,8193,65,23668,16401,25897,2420,28796,29960,257,29961,13688,30505]

theorem envBound54884 : H12AffineFastState.Bounded env54884 := by
  intro p hp
  have h : env54884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54883_54884 : H12AffineEnvironment.transform 20 17728 env54883 = env54884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env54883 == env54884) = true)

theorem identity54884 : scanCanonicalize (H12AffineFastState.compose env54884 (packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound54884 : packedSelected [1,3,4,5,6,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env54885 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,16384,8493,8202,16400,23809,1025,8492,17712,29961,30009,3,8193,49,23556,16401,25897,2308,28684,29960,257,29961,13576,30505]

theorem envBound54885 : H12AffineFastState.Bounded env54885 := by
  intro p hp
  have h : env54885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54884_54885 : H12AffineEnvironment.transform 5 48 env54884 = env54885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env54884 == env54885) = true)

theorem identity54885 : scanCanonicalize (H12AffineFastState.compose env54885 (packedSelected [0,1,3,4,5,7,8,9,11,12,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13577) := by decide +kernel

theorem selectedBound54885 : packedSelected [0,1,3,4,5,7,8,9,11,12,16,17] rootPS < 2^1333 := by decide +kernel

def env54886 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,13577,8493,8202,13593,10248,1025,8492,12345,0,48,3,8193,49,10509,13592,4128,2308,1285,1,257,0,13576,544]

theorem envBound54886 : H12AffineFastState.Bounded env54886 := by
  intro p hp
  have h : env54886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54885_54886 : H12AffineEnvironment.transform 13 13577 env54885 = env54886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13577 env54885 == env54886) = true)

theorem identity54886 : scanCanonicalize (H12AffineFastState.compose env54886 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound54886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54887 : List Nat := [2,4,8,16,32,48,9,53,512,1024,2048,4096,8192,13372,8216,8202,13356,10248,1025,8217,12345,0,48,3,8193,49,10296,13357,4128,2097,1072,1,52,0,13373,544]

theorem envBound54887 : H12AffineFastState.Bounded env54887 := by
  intro p hp
  have h : env54887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54886_54887 : H12AffineEnvironment.transform 7 53 env54886 = env54887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env54886 == env54887) = true)

theorem identity54887 : scanCanonicalize (H12AffineFastState.compose env54887 (packedSelected [0,1,7,8,10,11,12] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54887 : packedSelected [0,1,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54888 : List Nat := [2,4,8,16,1,17,9,20,512,1024,2048,4096,8192,13341,8216,8202,13325,10248,1025,8217,12312,0,17,3,8193,16,10265,13324,4097,2064,1041,1,21,0,13340,513]

theorem envBound54888 : H12AffineFastState.Bounded env54888 := by
  intro p hp
  have h : env54888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54887_54888 : H12AffineEnvironment.transform 4 1 env54887 = env54888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54887 == env54888) = true)

theorem identity54888 : scanCanonicalize (H12AffineFastState.compose env54888 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound54888 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env54889 : List Nat := [2,4,8,16,1,17,9,20,512,1024,528,4096,8192,13341,8216,8202,13325,8728,1025,8217,12312,0,17,3,8193,16,8713,13324,4097,512,1041,1,21,0,13340,513]

theorem envBound54889 : H12AffineFastState.Bounded env54889 := by
  intro p hp
  have h : env54889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54888_54889 : H12AffineEnvironment.transform 10 528 env54888 = env54889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env54888 == env54889) = true)

theorem identity54889 : scanCanonicalize (H12AffineFastState.compose env54889 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1037) := by decide +kernel

theorem selectedBound54889 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54890 : List Nat := [2,4,8,16,1,17,9,20,512,1024,528,4096,1037,4112,1045,1031,4096,1557,1025,1044,5141,0,17,3,1036,16,1540,4097,4097,512,1041,1,21,0,4113,513]

theorem envBound54890 : H12AffineFastState.Bounded env54890 := by
  intro p hp
  have h : env54890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54889_54890 : H12AffineEnvironment.transform 12 1037 env54889 = env54890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1037 env54889 == env54890) = true)

theorem identity54890 : scanCanonicalize (H12AffineFastState.compose env54890 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound54890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54891 : List Nat := [2,4,8,16,1,17,9,20,512,1024,528,529,1037,513,1045,1031,529,1557,1025,1044,1540,0,17,3,1036,16,1540,528,528,512,1041,1,21,0,512,513]

theorem envBound54891 : H12AffineFastState.Bounded env54891 := by
  intro p hp
  have h : env54891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54890_54891 : H12AffineEnvironment.transform 11 529 env54890 = env54891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env54890 == env54891) = true)

theorem identity54891 : scanCanonicalize (H12AffineFastState.compose env54891 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound54891 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env54892 : List Nat := [2,4,8,1,1,0,9,5,512,1024,513,512,1037,513,1028,1031,512,1540,1025,1029,1540,0,0,3,1036,1,1540,513,513,512,1024,1,4,0,512,513]

theorem envBound54892 : H12AffineFastState.Bounded env54892 := by
  intro p hp
  have h : env54892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54891_54892 : H12AffineEnvironment.transform 3 1 env54891 = env54892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env54891 == env54892) = true)

theorem identity54892 : scanCanonicalize (H12AffineFastState.compose env54892 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound54892 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env54893 : List Nat := [2,4,8,1,1,0,9,5,512,5,513,512,8,513,1,2,512,513,4,0,513,0,0,3,9,1,513,513,513,512,5,1,4,0,512,513]

theorem envBound54893 : H12AffineFastState.Bounded env54893 := by
  intro p hp
  have h : env54893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54892_54893 : H12AffineEnvironment.transform 9 5 env54892 = env54893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env54892 == env54893) = true)

theorem identity54893 : scanCanonicalize (H12AffineFastState.compose env54893 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound54893 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54894 : List Nat := [2,4,8,1,1,0,9,5,1,5,0,1,8,0,1,2,1,0,4,0,0,0,0,3,9,1,0,0,0,1,5,1,4,0,1,0]

theorem envBound54894 : H12AffineFastState.Bounded env54894 := by
  intro p hp
  have h : env54894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54893_54894 : H12AffineEnvironment.transform 8 1 env54893 = env54894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env54893 == env54894) = true)

def env54895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,4268091,4565341,8193,65,4262262,6565208,6387051,4562987,331127,2411541,257,2444610,2468974,272936]

theorem envBound54895 : H12AffineFastState.Bounded env54895 := by
  intro p hp
  have h : env54895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54878_54895 : H12AffineEnvironment.transform 16 16401 env54878 = env54895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env54878 == env54895) = true)

theorem identity54895 : scanCanonicalize (H12AffineFastState.compose env54895 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound54895 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35188,1025,32769,2097152,4194304,4268091,4268073,8193,65,4262262,6333484,6387051,4270431,99331,2114913,257,2212918,2172186,41820]

theorem envBound54896 : H12AffineFastState.Bounded env54896 := by
  intro p hp
  have h : env54896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54895_54896 : H12AffineEnvironment.transform 17 35188 env54895 = env54896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env54895 == env54896) = true)

theorem identity54896 : scanCanonicalize (H12AffineFastState.compose env54896 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound54896 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env54897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35188,1025,32769,2097152,4194304,4235629,4235647,8193,65,4229152,6333484,6353981,4237321,1365,2114913,257,2114912,2139212,41820]

theorem envBound54897 : H12AffineFastState.Bounded env54897 := by
  intro p hp
  have h : env54897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54896_54897 : H12AffineEnvironment.transform 15 33110 env54896 = env54897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env54896 == env54897) = true)

theorem identity54897 : scanCanonicalize (H12AffineFastState.compose env54897 (packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,17,18,21,27] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound54897 : packedSelected [0,2,3,4,5,6,9,10,11,12,15,16,17,18,21,27] rootPS < 2^1333 := by decide +kernel

def env54898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35188,1025,32769,50448,4194304,4235629,4235647,8193,65,4229152,4219196,4206893,4237321,1365,32881,257,32880,24924,41820]

theorem envBound54898 : H12AffineFastState.Bounded env54898 := by
  intro p hp
  have h : env54898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54897_54898 : H12AffineEnvironment.transform 20 50448 env54897 = env54898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env54897 == env54898) = true)

theorem identity54898 : scanCanonicalize (H12AffineFastState.compose env54898 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound54898 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env54899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,35188,1025,32769,50448,33,41292,41310,8193,65,34817,24861,12556,43048,1365,32881,257,32880,24924,41820]

theorem envBound54899 : H12AffineFastState.Bounded env54899 := by
  intro p hp
  have h : env54899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54898_54899 : H12AffineEnvironment.transform 21 33 env54898 = env54899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env54898 == env54899) = true)

theorem identity54899 : scanCanonicalize (H12AffineFastState.compose env54899 (packedSelected [0,2,5,8,9,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound54899 : packedSelected [0,2,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env54900 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,16401,32040,1025,29789,12620,33,21776,21762,8193,65,31837,24861,12556,23668,1365,29741,257,29740,24924,22272]

theorem envBound54900 : H12AffineFastState.Bounded env54900 := by
  intro p hp
  have h : env54900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54899_54900 : H12AffineEnvironment.transform 14 29788 env54899 = env54900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env54899 == env54900) = true)

theorem identity54900 : scanCanonicalize (H12AffineFastState.compose env54900 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound54900 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env54901 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,21540,21874,16401,23888,1025,21541,4404,33,21776,21762,121,65,23589,16741,4468,23668,1365,21589,257,21588,16676,22272]

theorem envBound54901 : H12AffineFastState.Bounded env54901 := by
  intro p hp
  have h : env54901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54900_54901 : H12AffineEnvironment.transform 12 120 env54900 = env54901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env54900 == env54901) = true)

theorem identity54901 : scanCanonicalize (H12AffineFastState.compose env54901 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound54901 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env54902 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,293,115,5392,2129,1025,292,4404,33,17,3,121,65,2340,5220,4468,2421,1365,340,257,341,5157,513]

theorem envBound54902 : H12AffineFastState.Bounded env54902 := by
  intro p hp
  have h : env54902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54901_54902 : H12AffineEnvironment.transform 13 5377 env54901 = env54902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env54901 == env54902) = true)

theorem identity54902 : scanCanonicalize (H12AffineFastState.compose env54902 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound54902 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env54903 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,120,4113,293,115,4096,2129,273,292,4404,33,17,3,121,65,2340,4468,4468,2421,69,340,257,341,4405,513]

theorem envBound54903 : H12AffineFastState.Bounded env54903 := by
  intro p hp
  have h : env54903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54902_54903 : H12AffineEnvironment.transform 9 272 env54902 = env54903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env54902 == env54903) = true)

theorem identity54903 : scanCanonicalize (H12AffineFastState.compose env54903 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54903 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env54904 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,41,4113,293,34,4096,2048,273,292,4404,33,17,3,40,16,2340,4389,4389,2340,20,261,257,260,4405,513]

theorem envBound54904 : H12AffineFastState.Bounded env54904 := by
  intro p hp
  have h : env54904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54903_54904 : H12AffineEnvironment.transform 5 17 env54903 = env54904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54903 == env54904) = true)

theorem identity54904 : scanCanonicalize (H12AffineFastState.compose env54904 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound54904 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env54905 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,4096,41,4113,0,34,4096,2048,52,1,4113,33,17,3,40,16,2049,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound54905 : H12AffineFastState.Bounded env54905 := by
  intro p hp
  have h : env54905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54904_54905 : H12AffineEnvironment.transform 7 37 env54904 = env54905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env54904 == env54905) = true)

theorem identity54905 : scanCanonicalize (H12AffineFastState.compose env54905 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound54905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54906 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,32,41,49,0,34,32,2048,52,1,49,33,17,3,40,16,2049,32,32,2049,20,32,36,33,48,513]

theorem envBound54906 : H12AffineFastState.Bounded env54906 := by
  intro p hp
  have h : env54906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54905_54906 : H12AffineEnvironment.transform 11 32 env54905 = env54906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env54905 == env54906) = true)

theorem identity54906 : scanCanonicalize (H12AffineFastState.compose env54906 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound54906 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54907 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,41,49,0,34,32,48,52,1,49,33,17,3,40,16,49,32,32,49,20,32,36,33,48,513]

theorem envBound54907 : H12AffineFastState.Bounded env54907 := by
  intro p hp
  have h : env54907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54906_54907 : H12AffineEnvironment.transform 10 48 env54906 = env54907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env54906 == env54907) = true)

def leafEnv54907 : List Nat := [2,4,8,16,32,17,9,37,512,53,48,32,41,49,0,34,32,48,52,1,49,33,17,3,21,40,1,16,49,32,32,49,20,32,36,33,5,35,48,513,1,48,0]

def active54907 : List Nat := [0,1,2,3,4,8]

def tree54907 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54907 : H12WitnessSearch.Good tree54907 := H12GlobalWitnessIndex.good

theorem leafIdentity54907 : H12AffineFastState.composeSystem env54907 rootObs = leafEnv54907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54907 rootObs == leafEnv54907) = true)

theorem terminalChecked54907 : H12PackedTerminal.terminalCheckFast leafEnv54907 active54907 tree54907 = true := by decide +kernel

def env54908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497101,10507600,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound54908 : H12AffineFastState.Bounded env54908 := by
  intro p hp
  have h : env54908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54557_54908 : H12AffineEnvironment.transform 26 30393345 env54557 = env54908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env54557 == env54908) = true)

def env54909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound54909 : H12AffineFastState.Bounded env54909 := by
  intro p hp
  have h : env54909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54908_54909 : H12AffineEnvironment.transform 18 1024 env54908 = env54909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env54908 == env54909) = true)

theorem identity54909 : scanCanonicalize (H12AffineFastState.compose env54909 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2493478) := by decide +kernel

theorem selectedBound54909 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env54910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2493478,8328,65,14797863,493739,10507600,8830977,10979383,4680166,256,8898699,8857902,10924000]

theorem envBound54910 : H12AffineFastState.Bounded env54910 := by
  intro p hp
  have h : env54910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54909_54910 : H12AffineEnvironment.transform 23 2493478 env54909 = env54910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2493478 env54909 == env54910) = true)

def env54911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,2097152,4194304,8388608,2114882,8328,65,14797863,115151,10507600,8423781,10600787,4268162,256,8487407,8478794,10544772]

theorem envBound54911 : H12AffineFastState.Bounded env54911 := by
  intro p hp
  have h : env54911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54910_54911 : H12AffineEnvironment.transform 17 149860 env54910 = env54911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149860 env54910 == env54911) = true)

def env54912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,8388608,21762,8328,65,12704871,115151,8406288,8423781,8507667,4268162,256,8487407,8478794,8451780]

theorem envBound54912 : H12AffineFastState.Bounded env54912 := by
  intro p hp
  have h : env54912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54911_54912 : H12AffineEnvironment.transform 20 4160 env54911 = env54912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env54911 == env54912) = true)

def env54913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363552,21762,8328,65,215367,115151,4378672,4332613,4408371,4268162,256,4396239,4453738,4350948]

theorem envBound54913 : H12AffineFastState.Bounded env54913 := by
  intro p hp
  have h : env54913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54912_54913 : H12AffineEnvironment.transform 22 4363552 env54912 = env54913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env54912 == env54913) = true)

theorem identity54913 : scanCanonicalize (H12AffineFastState.compose env54913 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243002) := by decide +kernel

theorem selectedBound54913 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,243002,73754,21762,8328,65,215367,115151,91402,108927,61705,169400,256,41461,16464,120542]

theorem envBound54914 : H12AffineFastState.Bounded env54914 := by
  intro p hp
  have h : env54914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54913_54914 : H12AffineEnvironment.transform 21 243002 env54913 = env54914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243002 env54913 == env54914) = true)

def env54915 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,243002,73754,21762,8272,65,215367,114967,91402,108927,61705,169312,256,41261,16464,120326]

theorem envBound54915 : H12AffineFastState.Bounded env54915 := by
  intro p hp
  have h : env54915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54914_54915 : H12AffineEnvironment.transform 6 88 env54914 = env54915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env54914 == env54915) = true)

theorem identity54915 : scanCanonicalize (H12AffineFastState.compose env54915 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound54915 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env54916 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,46109,64889,1024,32769,4160,65831,73754,21762,8272,65,130394,114967,91402,108927,61705,8573,256,41261,16464,120326]

theorem envBound54916 : H12AffineFastState.Bounded env54916 := by
  intro p hp
  have h : env54916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54915_54916 : H12AffineEnvironment.transform 16 46109 env54915 = env54916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env54915 == env54916) = true)

theorem identity54916 : scanCanonicalize (H12AffineFastState.compose env54916 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound54916 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env54917 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,54279,46109,64889,1024,32769,4160,54560,62493,21762,8272,65,10589,5392,45325,32120,61705,8573,256,41261,16464,513]

theorem envBound54917 : H12AffineFastState.Bounded env54917 := by
  intro p hp
  have h : env54917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54916_54917 : H12AffineEnvironment.transform 15 54279 env54916 = env54917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env54916 == env54917) = true)

theorem identity54917 : scanCanonicalize (H12AffineFastState.compose env54917 (packedSelected [15,17,38] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound54917 : packedSelected [15,17,38] rootPS < 2^1333 := by decide +kernel

def env54918 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,29708,8203,16401,2421,1024,29709,4160,8492,17,21762,8272,65,10589,5392,17665,32120,1285,8573,256,21793,16464,513]

theorem envBound54918 : H12AffineFastState.Bounded env54918 := by
  intro p hp
  have h : env54918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54917_54918 : H12AffineEnvironment.transform 14 29708 env54917 = env54918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env54917 == env54918) = true)

theorem identity54918 : scanCanonicalize (H12AffineFastState.compose env54918 (packedSelected [1,6,8,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound54918 : packedSelected [1,6,8,12,14] rootPS < 2^1333 := by decide +kernel

def env54919 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,120,16384,21620,115,16401,2421,1024,21621,4160,340,17,21762,40,65,2341,5392,17665,23808,1285,261,256,21793,16464,513]

theorem envBound54919 : H12AffineFastState.Bounded env54919 := by
  intro p hp
  have h : env54919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54918_54919 : H12AffineEnvironment.transform 12 120 env54918 = env54919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env54918 == env54919) = true)

theorem identity54919 : scanCanonicalize (H12AffineFastState.compose env54919 (packedSelected [5,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound54919 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env54920 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,120,5157,81,115,5172,2421,1024,80,4160,340,17,295,40,65,2341,5392,4388,2341,1285,261,256,260,5237,513]

theorem envBound54920 : H12AffineFastState.Bounded env54920 := by
  intro p hp
  have h : env54920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54919_54920 : H12AffineEnvironment.transform 13 5157 env54919 = env54920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env54919 == env54920) = true)

theorem identity54920 : scanCanonicalize (H12AffineFastState.compose env54920 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound54920 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env54921 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,120,5157,81,115,5172,2048,1024,80,4160,33,17,82,40,65,2128,5221,4177,2128,1136,112,117,113,5237,513]

theorem envBound54921 : H12AffineFastState.Bounded env54921 := by
  intro p hp
  have h : env54921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54920_54921 : H12AffineEnvironment.transform 7 117 env54920 = env54921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env54920 == env54921) = true)

def env54922 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5157,1,35,5172,2048,1024,0,4112,33,17,2,40,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound54922 : H12AffineFastState.Bounded env54922 := by
  intro p hp
  have h : env54922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54921_54922 : H12AffineEnvironment.transform 5 16 env54921 = env54922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54921 == env54922) = true)

def env54923 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,40,1045,1,35,1028,2048,1024,0,32,33,17,2,40,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound54923 : H12AffineFastState.Bounded env54923 := by
  intro p hp
  have h : env54923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54922_54923 : H12AffineEnvironment.transform 11 48 env54922 = env54923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54922 == env54923) = true)

theorem identity54923 : scanCanonicalize (H12AffineFastState.compose env54923 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound54923 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54924 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,48,40,1045,1,35,1028,33,1024,0,32,33,17,2,40,17,33,1029,49,33,1056,32,37,33,1045,513]

theorem envBound54924 : H12AffineFastState.Bounded env54924 := by
  intro p hp
  have h : env54924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54923_54924 : H12AffineEnvironment.transform 10 33 env54923 = env54924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env54923 == env54924) = true)

def env54925 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,40,33,1,35,48,33,52,0,32,33,17,2,40,17,33,49,49,33,20,32,37,33,33,513]

theorem envBound54925 : H12AffineFastState.Bounded env54925 := by
  intro p hp
  have h : env54925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54924_54925 : H12AffineEnvironment.transform 9 52 env54924 = env54925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54924 == env54925) = true)

theorem identity54925 : scanCanonicalize (H12AffineFastState.compose env54925 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound54925 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54926 : List Nat := [2,4,8,16,32,16,8,37,43,52,33,48,40,33,1,35,48,33,52,0,32,33,17,2,40,17,33,49,49,33,20,32,37,33,33,42]

theorem envBound54926 : H12AffineFastState.Bounded env54926 := by
  intro p hp
  have h : env54926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54925_54926 : H12AffineEnvironment.transform 8 43 env54925 = env54926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env54925 == env54926) = true)

def leafEnv54926 : List Nat := [2,4,8,16,32,16,8,37,43,52,33,48,40,33,1,35,48,33,52,0,32,33,17,2,20,40,1,17,33,49,49,33,20,32,37,33,4,35,33,42,1,32,0]

def active54926 : List Nat := [0,1,2,3,4]

def tree54926 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54926 : H12WitnessSearch.Good tree54926 := H12GlobalWitnessIndex.good

theorem leafIdentity54926 : H12AffineFastState.composeSystem env54926 rootObs = leafEnv54926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54926 rootObs == leafEnv54926) = true)

theorem terminalChecked54926 : H12PackedTerminal.terminalCheckFast leafEnv54926 active54926 tree54926 = true := by decide +kernel

def env54927 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,48,40,32,1,35,49,33,53,0,32,33,17,2,40,17,33,48,49,33,21,32,37,33,32,513]

theorem envBound54927 : H12AffineFastState.Bounded env54927 := by
  intro p hp
  have h : env54927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54924_54927 : H12AffineEnvironment.transform 9 53 env54924 = env54927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54924 == env54927) = true)

def env54928 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,40,1044,1,35,1029,2048,1024,0,33,33,17,2,40,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound54928 : H12AffineFastState.Bounded env54928 := by
  intro p hp
  have h : env54928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54922_54928 : H12AffineEnvironment.transform 11 49 env54922 = env54928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54922 == env54928) = true)

theorem identity54928 : scanCanonicalize (H12AffineFastState.compose env54928 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound54928 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54929 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1044,49,40,1044,1,35,1029,1044,1024,0,33,33,17,2,40,17,1044,1028,48,1044,1056,32,37,33,1044,513]

theorem envBound54929 : H12AffineFastState.Bounded env54929 := by
  intro p hp
  have h : env54929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54928_54929 : H12AffineEnvironment.transform 10 1044 env54928 = env54929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env54928 == env54929) = true)

def env54930 : List Nat := [2,4,8,16,32,16,8,37,512,52,32,49,40,32,1,35,49,32,52,0,33,33,17,2,40,17,32,48,48,32,20,32,37,33,32,513]

theorem envBound54930 : H12AffineFastState.Bounded env54930 := by
  intro p hp
  have h : env54930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54929_54930 : H12AffineEnvironment.transform 9 52 env54929 = env54930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54929 == env54930) = true)

theorem identity54930 : scanCanonicalize (H12AffineFastState.compose env54930 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound54930 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54931 : List Nat := [2,4,8,16,32,16,8,37,42,52,32,49,40,32,1,35,49,32,52,0,33,33,17,2,40,17,32,48,48,32,20,32,37,33,32,43]

theorem envBound54931 : H12AffineFastState.Bounded env54931 := by
  intro p hp
  have h : env54931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54930_54931 : H12AffineEnvironment.transform 8 42 env54930 = env54931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env54930 == env54931) = true)

def leafEnv54931 : List Nat := [2,4,8,16,32,16,8,37,42,52,32,49,40,32,1,35,49,32,52,0,33,33,17,2,20,40,1,17,32,48,48,32,20,32,37,33,4,35,32,43,1,33,0]

def active54931 : List Nat := [0,1,2,3,4]

def tree54931 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54931 : H12WitnessSearch.Good tree54931 := H12GlobalWitnessIndex.good

theorem leafIdentity54931 : H12AffineFastState.composeSystem env54931 rootObs = leafEnv54931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54931 rootObs == leafEnv54931) = true)

theorem terminalChecked54931 : H12PackedTerminal.terminalCheckFast leafEnv54931 active54931 tree54931 = true := by decide +kernel

def env54932 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,40,33,1,35,48,33,53,0,33,33,17,2,40,17,33,49,48,33,21,32,37,33,33,513]

theorem envBound54932 : H12AffineFastState.Bounded env54932 := by
  intro p hp
  have h : env54932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54929_54932 : H12AffineEnvironment.transform 9 53 env54929 = env54932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54929 == env54932) = true)

def env54933 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,34,5172,2048,1024,1,4113,33,17,3,40,16,2049,5172,4096,2049,1057,33,36,32,5156,513]

theorem envBound54933 : H12AffineFastState.Bounded env54933 := by
  intro p hp
  have h : env54933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54921_54933 : H12AffineEnvironment.transform 5 17 env54921 = env54933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54921 == env54933) = true)

theorem identity54933 : scanCanonicalize (H12AffineFastState.compose env54933 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound54933 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54934 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,0,34,4097,2048,53,1,4113,33,17,3,40,16,2049,4097,4096,2049,20,33,36,32,4113,513]

theorem envBound54934 : H12AffineFastState.Bounded env54934 := by
  intro p hp
  have h : env54934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54933_54934 : H12AffineEnvironment.transform 9 53 env54933 = env54934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env54933 == env54934) = true)

theorem identity54934 : scanCanonicalize (H12AffineFastState.compose env54934 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound54934 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54935 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,33,41,49,0,34,32,2048,53,1,48,33,17,3,40,16,2049,32,33,2049,20,33,36,32,48,513]

theorem envBound54935 : H12AffineFastState.Bounded env54935 := by
  intro p hp
  have h : env54935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54934_54935 : H12AffineEnvironment.transform 11 33 env54934 = env54935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env54934 == env54935) = true)

theorem identity54935 : scanCanonicalize (H12AffineFastState.compose env54935 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound54935 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env54936 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,41,49,0,34,32,49,53,1,48,33,17,3,40,16,48,32,33,48,20,33,36,32,48,513]

theorem envBound54936 : H12AffineFastState.Bounded env54936 := by
  intro p hp
  have h : env54936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54935_54936 : H12AffineEnvironment.transform 10 49 env54935 = env54936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env54935 == env54936) = true)

def leafEnv54936 : List Nat := [2,4,8,16,32,17,9,36,512,53,49,33,41,49,0,34,32,49,53,1,48,33,17,3,20,40,1,16,48,32,33,48,20,33,36,32,4,35,48,513,1,49,0]

def active54936 : List Nat := [0,1,2,3,4,8]

def tree54936 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood54936 : H12WitnessSearch.Good tree54936 := H12GlobalWitnessIndex.good

theorem leafIdentity54936 : H12AffineFastState.composeSystem env54936 rootObs = leafEnv54936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env54936 rootObs == leafEnv54936) = true)

theorem terminalChecked54936 : H12PackedTerminal.terminalCheckFast leafEnv54936 active54936 tree54936 = true := by decide +kernel

def env54937 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,243002,73754,21762,8273,65,215367,114966,91402,108927,61705,169313,256,41260,16464,120327]

theorem envBound54937 : H12AffineFastState.Bounded env54937 := by
  intro p hp
  have h : env54937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54914_54937 : H12AffineEnvironment.transform 6 89 env54914 = env54937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env54914 == env54937) = true)

theorem identity54937 : scanCanonicalize (H12AffineFastState.compose env54937 (packedSelected [0,4,7,16,19,20,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound54937 : packedSelected [0,4,7,16,19,20,22,26] rootPS < 2^1333 := by decide +kernel

def env54938 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,1,65536,131072,149860,1024,0,4160,210235,73754,21762,8273,65,215367,82199,91402,76158,28936,136544,256,8493,16464,87558]

theorem envBound54938 : H12AffineFastState.Bounded env54938 := by
  intro p hp
  have h : env54938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54937_54938 : H12AffineEnvironment.transform 14 1 env54937 = env54938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env54937 == env54938) = true)

theorem identity54938 : scanCanonicalize (H12AffineFastState.compose env54938 (packedSelected [0,9,10,16,17,18,20,22,23,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound54938 : packedSelected [0,9,10,16,17,18,20,22,23,27,31] rootPS < 2^1333 := by decide +kernel

def env54939 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,1,21590,131072,149860,1024,0,4160,156013,29772,21762,8273,65,138513,5441,12636,32040,28936,136544,256,8493,16464,592]

theorem envBound54939 : H12AffineFastState.Bounded env54939 := by
  intro p hp
  have h : env54939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54938_54939 : H12AffineEnvironment.transform 15 21590 env54938 = env54939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env54938 == env54939) = true)

theorem identity54939 : scanCanonicalize (H12AffineFastState.compose env54939 (packedSelected [0,1,2,6,7,8,12,15,18,19,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound54939 : packedSelected [0,1,2,6,7,8,12,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env54940 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,1,21590,13340,32120,1024,0,4160,21873,29772,21762,8273,65,10509,5441,12636,32040,28936,8572,256,8493,16464,592]

theorem envBound54940 : H12AffineFastState.Bounded env54940 := by
  intro p hp
  have h : env54940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54939_54940 : H12AffineEnvironment.transform 16 13340 env54939 = env54940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env54939 == env54940) = true)

theorem identity54940 : scanCanonicalize (H12AffineFastState.compose env54940 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound54940 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env54941 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,13325,1,8283,13340,2421,1024,0,4160,8572,65,8463,8273,65,10509,5441,12636,2341,1285,8572,256,8493,13405,592]

theorem envBound54941 : H12AffineFastState.Bounded env54941 := by
  intro p hp
  have h : env54941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54940_54941 : H12AffineEnvironment.transform 13 13325 env54940 = env54941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env54940 == env54941) = true)

theorem identity54941 : scanCanonicalize (H12AffineFastState.compose env54941 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 298) := by decide +kernel

theorem selectedBound54941 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env54942 : List Nat := [2,4,8,16,32,64,89,256,512,298,2048,4096,8192,12583,1,8283,12598,2421,298,0,4160,8572,65,8463,8273,65,10509,4203,12636,2341,47,8572,256,8493,12663,592]

theorem envBound54942 : H12AffineFastState.Bounded env54942 := by
  intro p hp
  have h : env54942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54941_54942 : H12AffineEnvironment.transform 9 298 env54941 = env54942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 298 env54941 == env54942) = true)

theorem identity54942 : scanCanonicalize (H12AffineFastState.compose env54942 (packedSelected [0,2,3,4,5,10,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2602) := by decide +kernel

theorem selectedBound54942 : packedSelected [0,2,3,4,5,10,11,14] rootPS < 2^1333 := by decide +kernel

def env54943 : List Nat := [2,4,8,16,32,64,89,256,512,298,2048,2602,8192,11021,1,8283,11036,2421,298,0,2666,8572,65,8463,8273,65,10509,2625,11126,2341,47,8572,256,8493,11101,592]

theorem envBound54943 : H12AffineFastState.Bounded env54943 := by
  intro p hp
  have h : env54943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54942_54943 : H12AffineEnvironment.transform 11 2602 env54942 = env54943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2602 env54942 == env54943) = true)

theorem identity54943 : scanCanonicalize (H12AffineFastState.compose env54943 (packedSelected [0,1,2,3,4,5,8,10,15] rootPS)) = affineNative (2^(8+1) ^^^ 74) := by decide +kernel

theorem selectedBound54943 : packedSelected [0,1,2,3,4,5,8,10,15] rootPS < 2^1333 := by decide +kernel

def env54944 : List Nat := [2,4,8,16,32,64,89,256,74,298,2048,2144,8192,10567,1,8283,10582,2421,298,0,2080,8572,65,8463,8273,65,10509,2059,10556,2341,47,8572,256,8493,10519,26]

theorem envBound54944 : H12AffineFastState.Bounded env54944 := by
  intro p hp
  have h : env54944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54943_54944 : H12AffineEnvironment.transform 8 74 env54943 = env54944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 74 env54943 == env54944) = true)

theorem identity54944 : scanCanonicalize (H12AffineFastState.compose env54944 (packedSelected [0,1,4,5,7,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 2333) := by decide +kernel

theorem selectedBound54944 : packedSelected [0,1,4,5,7,9,12] rootPS < 2^1333 := by decide +kernel

def env54945 : List Nat := [2,4,8,16,32,64,89,256,74,298,2048,2144,2333,90,1,2374,75,2421,298,0,2080,2145,65,2066,2380,65,16,2059,33,2341,47,2145,256,2096,10,26]

theorem envBound54945 : H12AffineFastState.Bounded env54945 := by
  intro p hp
  have h : env54945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54944_54945 : H12AffineEnvironment.transform 12 2333 env54944 = env54945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2333 env54944 == env54945) = true)

theorem identity54945 : scanCanonicalize (H12AffineFastState.compose env54945 (packedSelected [17] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound54945 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1