import H12CloudChart1Data199

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env50664 : List Nat := [2,4,8,16,32,16,9,36,512,1024,522,4096,41,5157,0,35,5173,522,1024,1,4112,33,16,3,40,17,522,5172,4096,522,1057,32,36,33,5156,513]

theorem envBound50664 : H12AffineFastState.Bounded env50664 := by
  intro p hp
  have h : env50664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50663_50664 : H12AffineEnvironment.transform 10 522 env50663 = env50664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env50663 == env50664) = true)

theorem identity50664 : scanCanonicalize (H12AffineFastState.compose env50664 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50664 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50665 : List Nat := [2,4,8,16,1,16,9,5,512,1024,522,4096,8,5124,0,2,5140,522,1024,1,4112,0,16,3,9,17,522,5141,4096,522,1024,1,5,0,5125,513]

theorem envBound50665 : H12AffineFastState.Bounded env50665 := by
  intro p hp
  have h : env50665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50664_50665 : H12AffineEnvironment.transform 4 1 env50664 = env50665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50664 == env50665) = true)

def env50666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,138341,1024,32769,4160,180409,152,21762,8328,65,171416,5392,17801,56573,1364,144612,256,21928,46092,63068]

theorem envBound50666 : H12AffineFastState.Bounded env50666 := by
  intro p hp
  have h : env50666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50655_50666 : H12AffineEnvironment.transform 21 180409 env50655 = env50666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env50655 == env50666) = true)

theorem identity50666 : scanCanonicalize (H12AffineFastState.compose env50666 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound50666 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env50667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,131072,138341,1024,32769,4160,169400,152,3,8328,65,171416,5392,4232,35324,1364,144612,256,169,46092,41821]

theorem envBound50667 : H12AffineFastState.Bounded env50667 := by
  intro p hp
  have h : env50667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50666_50667 : H12AffineEnvironment.transform 13 5377 env50666 = env50667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env50666 == env50667) = true)

theorem identity50667 : scanCanonicalize (H12AffineFastState.compose env50667 (packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound50667 : packedSelected [0,1,4,7,10,18,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env50668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33246,13341,10360,1024,32769,4160,41381,152,3,8328,65,43397,5392,4232,35324,1364,249,256,169,46092,41821]

theorem envBound50668 : H12AffineFastState.Bounded env50668 := by
  intro p hp
  have h : env50668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50667_50668 : H12AffineEnvironment.transform 16 13341 env50667 = env50668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env50667 == env50668) = true)

theorem identity50668 : scanCanonicalize (H12AffineFastState.compose env50668 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound50668 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env50669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,32768,33246,5440,2341,1024,32769,4160,33016,152,3,469,65,35032,5392,4232,35324,1364,249,256,169,38225,33280]

theorem envBound50669 : H12AffineFastState.Bounded env50669 := by
  intro p hp
  have h : env50669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50668_50669 : H12AffineEnvironment.transform 12 349 env50668 = env50669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env50668 == env50669) = true)

theorem identity50669 : scanCanonicalize (H12AffineFastState.compose env50669 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 216) := by decide +kernel

theorem selectedBound50669 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env50670 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,216,262,5440,2341,1024,217,4160,32,152,3,469,65,2048,5392,4232,2340,1364,249,256,169,5513,728]

theorem envBound50670 : H12AffineFastState.Bounded env50670 := by
  intro p hp
  have h : env50670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50669_50670 : H12AffineEnvironment.transform 14 216 env50669 = env50670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 216 env50669 == env50670) = true)

theorem identity50670 : scanCanonicalize (H12AffineFastState.compose env50670 (packedSelected [4,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound50670 : packedSelected [4,9,12] rootPS < 2^1333 := by decide +kernel

def env50671 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1196,349,429,216,262,492,2341,1024,217,1260,32,152,3,469,65,2048,444,1060,2340,1364,249,256,169,293,728]

theorem envBound50671 : H12AffineFastState.Bounded env50671 := by
  intro p hp
  have h : env50671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50670_50671 : H12AffineEnvironment.transform 11 1196 env50670 = env50671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env50670 == env50671) = true)

theorem identity50671 : scanCanonicalize (H12AffineFastState.compose env50671 (packedSelected [1,8,10,11,14] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound50671 : packedSelected [1,8,10,11,14] rootPS < 2^1333 := by decide +kernel

def env50672 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1125,1196,349,429,216,262,492,1344,1024,217,1260,32,152,3,469,65,1125,444,1060,1345,1364,249,256,169,293,728]

theorem envBound50672 : H12AffineFastState.Bounded env50672 := by
  intro p hp
  have h : env50672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50671_50672 : H12AffineEnvironment.transform 10 1125 env50671 = env50672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env50671 == env50672) = true)

theorem identity50672 : scanCanonicalize (H12AffineFastState.compose env50672 (packedSelected [0,2,4,6,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50672 : packedSelected [0,2,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env50673 : List Nat := [2,4,8,16,32,64,128,37,512,1024,1125,1196,120,136,216,35,201,1125,1024,217,1260,32,152,3,240,65,1125,153,1060,1124,1137,249,37,169,0,728]

theorem envBound50673 : H12AffineFastState.Bounded env50673 := by
  intro p hp
  have h : env50673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50672_50673 : H12AffineEnvironment.transform 7 37 env50672 = env50673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50672 == env50673) = true)

theorem identity50673 : scanCanonicalize (H12AffineFastState.compose env50673 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound50673 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env50674 : List Nat := [2,4,8,16,32,64,128,37,512,236,137,64,120,136,216,35,201,137,236,217,0,32,152,3,240,65,137,153,200,136,157,249,37,169,0,728]

theorem envBound50674 : H12AffineFastState.Bounded env50674 := by
  intro p hp
  have h : env50674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50673_50674 : H12AffineEnvironment.transform 9 236 env50673 = env50674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env50673 == env50674) = true)

theorem identity50674 : scanCanonicalize (H12AffineFastState.compose env50674 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound50674 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50675 : List Nat := [2,4,8,16,32,64,8,37,512,100,1,64,120,0,80,35,65,1,100,81,0,32,16,3,120,65,1,17,64,0,21,113,37,33,0,592]

theorem envBound50675 : H12AffineFastState.Bounded env50675 := by
  intro p hp
  have h : env50675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50674_50675 : H12AffineEnvironment.transform 6 8 env50674 = env50675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50674 == env50675) = true)

theorem identity50675 : scanCanonicalize (H12AffineFastState.compose env50675 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50675 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50676 : List Nat := [2,4,8,16,1,64,8,4,512,69,1,64,89,0,80,2,65,1,69,81,0,1,16,3,89,65,1,17,64,0,21,80,4,0,0,592]

theorem envBound50676 : H12AffineFastState.Bounded env50676 := by
  intro p hp
  have h : env50676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50675_50676 : H12AffineEnvironment.transform 4 1 env50675 = env50676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50675 == env50676) = true)

def env50677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,8388608,98780,8328,65,12683623,5392,8406288,8456378,8390093,4256861,256,8410416,8434836,8462874]

theorem envBound50677 : H12AffineFastState.Bounded env50677 := by
  intro p hp
  have h : env50677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50625_50677 : H12AffineEnvironment.transform 20 4161 env50625 = env50677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50625 == env50677) = true)

def env50678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374560,98780,8328,65,215367,5392,4359472,4442266,4376045,4256861,256,4363536,4355252,4448826]

theorem envBound50678 : H12AffineFastState.Bounded env50678 := by
  intro p hp
  have h : env50678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50677_50678 : H12AffineEnvironment.transform 22 4374560 env50677 = env50678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env50677 == env50678) = true)

theorem identity50678 : scanCanonicalize (H12AffineFastState.compose env50678 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254011) := by decide +kernel

theorem selectedBound50678 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50679 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,254011,73755,98780,8328,65,215367,5392,91403,10401,75222,201830,256,95531,103567,513]

theorem envBound50679 : H12AffineFastState.Bounded env50679 := by
  intro p hp
  have h : env50679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50678_50679 : H12AffineEnvironment.transform 21 254011 env50678 = env50679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254011 env50678 == env50679) = true)

def env50680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,254011,73755,98644,8192,65,215367,5392,91403,10281,75102,201830,256,95531,103431,513]

theorem envBound50680 : H12AffineFastState.Bounded env50680 := by
  intro p hp
  have h : env50680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50679_50680 : H12AffineEnvironment.transform 6 8 env50679 = env50680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50679 == env50680) = true)

theorem identity50680 : scanCanonicalize (H12AffineFastState.compose env50680 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50680 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,43049,1024,32769,4161,32800,73755,98644,8192,65,10588,5392,91403,10281,75102,29821,256,95531,103431,513]

theorem envBound50681 : H12AffineFastState.Bounded env50681 := by
  intro p hp
  have h : env50681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50680_50681 : H12AffineEnvironment.transform 16 90139 env50680 = env50681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50680 == env50681) = true)

theorem identity50681 : scanCanonicalize (H12AffineFastState.compose env50681 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound50681 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env50682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29708,65536,90139,23589,1024,29709,4161,29740,73755,95576,8192,65,10588,5392,91403,10281,75102,29821,256,95531,90123,513]

theorem envBound50682 : H12AffineFastState.Bounded env50682 := by
  intro p hp
  have h : env50682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50681_50682 : H12AffineEnvironment.transform 14 29708 env50681 = env50682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env50681 == env50682) = true)

theorem identity50682 : scanCanonicalize (H12AffineFastState.compose env50682 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound50682 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50683 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,16384,28777,65536,90139,22592,101,28776,4161,28745,73755,94525,8192,65,10588,4469,90478,10281,74043,28696,256,94542,90123,513]

theorem envBound50683 : H12AffineFastState.Bounded env50683 := by
  intro p hp
  have h : env50683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50682_50683 : H12AffineEnvironment.transform 9 101 env50682 = env50683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env50682 == env50683) = true)

theorem identity50683 : scanCanonicalize (H12AffineFastState.compose env50683 (packedSelected [2,3,5,6,10,11,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound50683 : packedSelected [2,3,5,6,10,11,17,18] rootPS < 2^1333 := by decide +kernel

def env50684 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,12620,293,65536,69975,10508,101,292,4161,261,73755,65649,8192,65,10588,4469,69666,10281,74043,340,256,65538,69959,513]

theorem envBound50684 : H12AffineFastState.Bounded env50684 := by
  intro p hp
  have h : env50684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50683_50684 : H12AffineEnvironment.transform 13 12620 env50683 = env50684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env50683 == env50684) = true)

theorem identity50684 : scanCanonicalize (H12AffineFastState.compose env50684 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50684 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env50685 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,8192,12620,293,8202,12637,10508,101,292,4161,261,17,8315,8192,65,10588,4469,12328,10281,305,340,256,8200,12621,513]

theorem envBound50685 : H12AffineFastState.Bounded env50685 := by
  intro p hp
  have h : env50685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50684_50685 : H12AffineEnvironment.transform 15 8202 env50684 = env50685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50684 == env50685) = true)

theorem identity50685 : scanCanonicalize (H12AffineFastState.compose env50685 (packedSelected [0,4,5,6,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50685 : packedSelected [0,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env50686 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,41,4453,293,35,4468,2341,101,292,4161,261,17,82,41,65,2421,4469,4097,2048,305,340,256,33,4452,513]

theorem envBound50686 : H12AffineFastState.Bounded env50686 := by
  intro p hp
  have h : env50686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50685_50686 : H12AffineEnvironment.transform 12 41 env50685 = env50686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50685 == env50686) = true)

theorem identity50686 : scanCanonicalize (H12AffineFastState.compose env50686 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50686 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50687 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,41,4405,293,35,4388,2341,53,292,4113,261,17,2,41,17,2341,4389,4097,2048,305,260,256,33,4404,513]

theorem envBound50687 : H12AffineFastState.Bounded env50687 := by
  intro p hp
  have h : env50687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50686_50687 : H12AffineEnvironment.transform 5 16 env50686 = env50687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50686 == env50687) = true)

def env50688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,254011,73755,98645,8193,65,215367,5392,91403,10280,75103,201830,256,95531,103430,513]

theorem envBound50688 : H12AffineFastState.Bounded env50688 := by
  intro p hp
  have h : env50688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50679_50688 : H12AffineEnvironment.transform 6 9 env50679 = env50688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50679 == env50688) = true)

theorem identity50688 : scanCanonicalize (H12AffineFastState.compose env50688 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound50688 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env50689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,4161,33,73755,98645,8193,65,43357,5392,91403,10280,75103,62588,256,95531,103430,513]

theorem envBound50689 : H12AffineFastState.Bounded env50689 := by
  intro p hp
  have h : env50689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50688_50689 : H12AffineEnvironment.transform 16 122906 env50688 = env50689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env50688 == env50689) = true)

theorem identity50689 : scanCanonicalize (H12AffineFastState.compose env50689 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50689 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env50690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1024,32769,4161,33,16,41310,8193,65,43357,5392,17664,10280,1364,62588,256,21792,46093,513]

theorem envBound50690 : H12AffineFastState.Bounded env50690 := by
  intro p hp
  have h : env50690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50689_50690 : H12AffineEnvironment.transform 15 8203 env50689 = env50690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50689 == env50690) = true)

theorem identity50690 : scanCanonicalize (H12AffineFastState.compose env50690 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50690 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49169,2340,1024,32769,4161,33,16,32851,268,65,34896,5392,17664,2341,1364,54641,256,21792,38144,513]

theorem envBound50691 : H12AffineFastState.Bounded env50691 := by
  intro p hp
  have h : env50691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50690_50691 : H12AffineEnvironment.transform 12 269 env50690 = env50691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50690 == env50691) = true)

theorem identity50691 : scanCanonicalize (H12AffineFastState.compose env50691 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound50691 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env50692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,1,262,16400,2340,1024,0,4161,33,16,82,268,65,2129,5392,17664,2341,1364,21872,256,21792,5377,513]

theorem envBound50692 : H12AffineFastState.Bounded env50692 := by
  intro p hp
  have h : env50692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50691_50692 : H12AffineEnvironment.transform 14 1 env50691 = env50692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env50691 == env50692) = true)

theorem identity50692 : scanCanonicalize (H12AffineFastState.compose env50692 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50692 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env50693 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,1,262,16400,2340,1024,0,4113,33,16,2,268,17,2049,5392,17664,2341,1284,21792,256,21792,5377,513]

theorem envBound50693 : H12AffineFastState.Bounded env50693 := by
  intro p hp
  have h : env50693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50692_50693 : H12AffineEnvironment.transform 5 16 env50692 = env50693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50692 == env50693) = true)

theorem identity50693 : scanCanonicalize (H12AffineFastState.compose env50693 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50693 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50694 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,16384,1,262,16400,2340,272,0,4113,33,16,2,268,17,2049,4096,16400,2341,20,20528,256,20528,4113,513]

theorem envBound50694 : H12AffineFastState.Bounded env50694 := by
  intro p hp
  have h : env50694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50693_50694 : H12AffineEnvironment.transform 9 272 env50693 = env50694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50693 == env50694) = true)

theorem identity50694 : scanCanonicalize (H12AffineFastState.compose env50694 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 33) := by decide +kernel

theorem selectedBound50694 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50695 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,269,33,1,262,49,2340,272,0,4113,33,16,2,268,17,2049,4096,49,2341,20,4113,256,4113,4113,513]

theorem envBound50695 : H12AffineFastState.Bounded env50695 := by
  intro p hp
  have h : env50695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50694_50695 : H12AffineEnvironment.transform 13 33 env50694 = env50695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 33 env50694 == env50695) = true)

theorem identity50695 : scanCanonicalize (H12AffineFastState.compose env50695 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50695 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50696 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,4096,269,33,1,262,49,293,272,0,4113,33,16,2,268,17,0,4096,49,292,20,4113,256,4113,4113,513]

theorem envBound50696 : H12AffineFastState.Bounded env50696 := by
  intro p hp
  have h : env50696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50695_50696 : H12AffineEnvironment.transform 10 1 env50695 = env50696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50695 == env50696) = true)

theorem identity50696 : scanCanonicalize (H12AffineFastState.compose env50696 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound50696 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env50697 : List Nat := [2,4,8,16,32,16,9,52,512,36,1,4096,57,33,1,50,49,17,36,0,4113,33,16,2,56,17,0,4096,49,16,20,4113,52,4113,4113,513]

theorem envBound50697 : H12AffineFastState.Bounded env50697 := by
  intro p hp
  have h : env50697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50696_50697 : H12AffineEnvironment.transform 7 52 env50696 = env50697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env50696 == env50697) = true)

theorem identity50697 : scanCanonicalize (H12AffineFastState.compose env50697 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound50697 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env50698 : List Nat := [2,4,8,16,16,16,9,4,512,20,1,4096,9,17,1,2,1,17,20,0,4113,17,16,2,8,17,0,4096,1,16,20,4113,4,4113,4113,513]

theorem envBound50698 : H12AffineFastState.Bounded env50698 := by
  intro p hp
  have h : env50698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50697_50698 : H12AffineEnvironment.transform 4 16 env50697 = env50698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env50697 == env50698) = true)

theorem identity50698 : scanCanonicalize (H12AffineFastState.compose env50698 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound50698 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50699 : List Nat := [2,4,8,16,16,16,9,4,17,20,1,4096,9,17,1,2,1,17,20,0,4113,17,16,2,8,17,0,4096,1,16,20,4113,4,4113,4113,16]

theorem envBound50699 : H12AffineFastState.Bounded env50699 := by
  intro p hp
  have h : env50699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50698_50699 : H12AffineEnvironment.transform 8 17 env50698 = env50699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50698 == env50699) = true)

theorem identity50699 : scanCanonicalize (H12AffineFastState.compose env50699 (packedSelected [14] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound50699 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env50700 : List Nat := [2,4,8,16,16,16,9,4,17,20,1,1,9,17,1,2,1,17,20,0,16,17,16,2,8,17,0,1,1,16,20,16,4,16,16,16]

theorem envBound50700 : H12AffineFastState.Bounded env50700 := by
  intro p hp
  have h : env50700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50699_50700 : H12AffineEnvironment.transform 11 1 env50699 = env50700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env50699 == env50700) = true)

theorem identity50700 : scanCanonicalize (H12AffineFastState.compose env50700 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50700 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50701 : List Nat := [2,4,8,1,1,1,9,4,0,5,1,1,9,0,1,2,1,0,5,0,1,0,1,2,8,0,0,1,1,1,5,1,4,1,1,1]

theorem envBound50701 : H12AffineFastState.Bounded env50701 := by
  intro p hp
  have h : env50701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50700_50701 : H12AffineEnvironment.transform 3 1 env50700 = env50701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50700 == env50701) = true)

def env50702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,4161,4194304,4374561,98780,8328,65,215366,5392,4359473,4442267,4376044,4256861,256,4363537,4355253,4448827]

theorem envBound50702 : H12AffineFastState.Bounded env50702 := by
  intro p hp
  have h : env50702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50677_50702 : H12AffineEnvironment.transform 22 4374561 env50677 = env50702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env50677 == env50702) = true)

theorem identity50702 : scanCanonicalize (H12AffineFastState.compose env50702 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50702 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4161,4194304,4374561,41431,8328,65,158029,5392,4359473,4384912,4376044,4256861,256,4363537,4355253,4375088]

theorem envBound50703 : H12AffineFastState.Bounded env50703 := by
  intro p hp
  have h : env50703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50702_50703 : H12AffineEnvironment.transform 15 8203 env50702 = env50703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50702 == env50703) = true)

theorem identity50703 : scanCanonicalize (H12AffineFastState.compose env50703 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound50703 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env50704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4161,180273,16,41431,8328,65,158029,5392,17664,10401,1501,144492,256,21792,46212,513]

theorem envBound50704 : H12AffineFastState.Bounded env50704 := by
  intro p hp
  have h : env50704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50703_50704 : H12AffineEnvironment.transform 21 180273 env50703 = env50704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env50703 == env50704) = true)

theorem identity50704 : scanCanonicalize (H12AffineFastState.compose env50704 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound50704 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env50705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,43168,1024,32769,4161,32800,16,41431,8328,65,10588,5392,17664,10401,1501,29821,256,21792,46212,513]

theorem envBound50705 : H12AffineFastState.Bounded env50705 := by
  intro p hp
  have h : env50705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50704_50705 : H12AffineEnvironment.transform 16 16401 env50704 = env50705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env50704 == env50705) = true)

theorem identity50705 : scanCanonicalize (H12AffineFastState.compose env50705 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound50705 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8203,13389,43168,1024,32769,4161,32800,16,41431,8328,65,10588,5392,12636,10401,1501,33,256,8572,46212,513]

theorem envBound50706 : H12AffineFastState.Bounded env50706 := by
  intro p hp
  have h : env50706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50705_50706 : H12AffineEnvironment.transform 13 13404 env50705 = env50706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env50705 == env50706) = true)

theorem identity50706 : scanCanonicalize (H12AffineFastState.compose env50706 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50706 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8540,8203,13389,2556,1024,8541,4161,8572,16,139,8328,65,10588,5392,12636,10401,1501,33,256,8572,5592,513]

theorem envBound50707 : H12AffineFastState.Bounded env50707 := by
  intro p hp
  have h : env50707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50706_50707 : H12AffineEnvironment.transform 14 8540 env50706 = env50707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50706 == env50707) = true)

theorem identity50707 : scanCanonicalize (H12AffineFastState.compose env50707 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50707 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5376,0,343,5393,2556,1024,1,4161,32,16,139,468,65,2048,5392,4096,2557,1501,33,256,32,5592,513]

theorem envBound50708 : H12AffineFastState.Bounded env50708 := by
  intro p hp
  have h : env50708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50707_50708 : H12AffineEnvironment.transform 12 348 env50707 = env50708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50707 == env50708) = true)

theorem identity50708 : scanCanonicalize (H12AffineFastState.compose env50708 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 3309) := by decide +kernel

theorem selectedBound50708 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3309,348,2541,0,343,2556,2556,1024,1,3244,32,16,139,468,65,2048,2557,3309,2557,1501,33,256,32,2357,513]

theorem envBound50709 : H12AffineFastState.Bounded env50709 := by
  intro p hp
  have h : env50709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50708_50709 : H12AffineEnvironment.transform 11 3309 env50708 = env50709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3309 env50708 == env50709) = true)

theorem identity50709 : scanCanonicalize (H12AffineFastState.compose env50709 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound50709 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env50710 : List Nat := [2,4,8,16,32,64,128,256,512,266,2048,2535,348,2541,0,343,2556,2556,266,1,2470,32,16,139,468,65,2048,2557,2535,2557,215,33,256,32,2357,513]

theorem envBound50710 : H12AffineFastState.Bounded env50710 := by
  intro p hp
  have h : env50710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50709_50710 : H12AffineEnvironment.transform 9 266 env50709 = env50710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env50709 == env50710) = true)

def env50711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound50711 : H12AffineFastState.Bounded env50711 := by
  intro p hp
  have h : env50711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50525_50711 : H12AffineEnvironment.transform 18 1025 env50525 = env50711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env50525 == env50711) = true)

theorem identity50711 : scanCanonicalize (H12AffineFastState.compose env50711 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661050) := by decide +kernel

theorem selectedBound50711 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50712 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8328,65,4450362,10857654,10507601,8830977,371755,15027706,257,2485398,2428211,297981]

theorem envBound50712 : H12AffineFastState.Bounded env50712 := by
  intro p hp
  have h : env50712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50711_50712 : H12AffineEnvironment.transform 23 8661050 env50711 = env50712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661050 env50711 == env50712) = true)

def env50713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450362,10857534,10507601,8830977,371755,15027570,257,2485278,2428211,297845]

theorem envBound50713 : H12AffineFastState.Bounded env50713 := by
  intro p hp
  have h : env50713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50712_50713 : H12AffineEnvironment.transform 6 8 env50712 = env50713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50712 == env50713) = true)

theorem identity50713 : scanCanonicalize (H12AffineFastState.compose env50713 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound50713 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,8429902,8192,65,4450362,10560842,10507601,8538485,75103,14795782,257,2188650,2196551,513]

theorem envBound50714 : H12AffineFastState.Bounded env50714 := by
  intro p hp
  have h : env50714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50713_50714 : H12AffineEnvironment.transform 17 35188 env50713 = env50714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env50713 == env50714) = true)

def env50715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,16,41310,8192,65,4450362,2172250,2118977,149861,75103,6407190,257,2188650,2196551,513]

theorem envBound50715 : H12AffineFastState.Bounded env50715 := by
  intro p hp
  have h : env50715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50714_50715 : H12AffineEnvironment.transform 22 16 env50714 = env50715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env50714 == env50715) = true)

theorem identity50715 : scanCanonicalize (H12AffineFastState.compose env50715 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50715 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229153,2172250,2118977,76158,75103,6407190,257,2188650,2196551,513]

theorem envBound50716 : H12AffineFastState.Bounded env50716 := by
  intro p hp
  have h : env50716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50715_50716 : H12AffineEnvironment.transform 16 90139 env50715 = env50716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50715 == env50716) = true)

theorem identity50716 : scanCanonicalize (H12AffineFastState.compose env50716 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound50716 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229153,2139148,2118977,43048,41993,6309184,257,2155580,2098449,513]

theorem envBound50717 : H12AffineFastState.Bounded env50717 := by
  intro p hp
  have h : env50717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50716_50717 : H12AffineEnvironment.transform 15 33110 env50716 = env50717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env50716 == env50717) = true)

theorem identity50717 : scanCanonicalize (H12AffineFastState.compose env50717 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50717 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env50718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10281,1025,8540,2097152,4194304,16,3,8192,65,4204924,2098513,2118977,2421,1364,6309184,257,2114913,2098449,513]

theorem envBound50718 : H12AffineFastState.Bounded env50718 := by
  intro p hp
  have h : env50718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50717_50718 : H12AffineEnvironment.transform 14 8541 env50717 = env50718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50717 == env50718) = true)

theorem identity50718 : scanCanonicalize (H12AffineFastState.compose env50718 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound50718 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10281,1025,8540,2097152,32,16,3,8192,65,10588,2098513,2118977,2421,1364,2114912,257,2114913,2098449,513]

theorem envBound50719 : H12AffineFastState.Bounded env50719 := by
  intro p hp
  have h : env50719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50718_50719 : H12AffineEnvironment.transform 21 32 env50718 = env50719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env50718 == env50719) = true)

theorem identity50719 : scanCanonicalize (H12AffineFastState.compose env50719 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound50719 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50720 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10281,1025,8540,25628,32,16,3,8192,65,10588,24909,12637,2421,1364,8572,257,8573,24845,513]

theorem envBound50720 : H12AffineFastState.Bounded env50720 := by
  intro p hp
  have h : env50720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50719_50720 : H12AffineEnvironment.transform 20 25628 env50719 = env50720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env50719 == env50720) = true)

theorem identity50720 : scanCanonicalize (H12AffineFastState.compose env50720 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound50720 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,301,16384,112,294,16400,2308,1025,113,17713,32,16,3,301,65,2161,16480,4208,2421,1364,81,257,80,16416,513]

theorem envBound50721 : H12AffineFastState.Bounded env50721 := by
  intro p hp
  have h : env50721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50720_50721 : H12AffineEnvironment.transform 12 301 env50720 = env50721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env50720 == env50721) = true)

theorem identity50721 : scanCanonicalize (H12AffineFastState.compose env50721 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50721 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env50722 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,301,16384,33,294,16400,2308,1025,32,17713,32,16,3,301,16,2080,16433,4129,2340,1285,0,257,1,16416,513]

theorem envBound50722 : H12AffineFastState.Bounded env50722 := by
  intro p hp
  have h : env50722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50721_50722 : H12AffineEnvironment.transform 5 17 env50721 = env50722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50721 == env50722) = true)

theorem identity50722 : scanCanonicalize (H12AffineFastState.compose env50722 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50722 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50723 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,16384,1,262,16400,2308,1025,0,17681,0,16,3,269,16,2048,16401,4097,2308,1285,0,257,1,16384,513]

theorem envBound50723 : H12AffineFastState.Bounded env50723 := by
  intro p hp
  have h : env50723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50722_50723 : H12AffineEnvironment.transform 4 0 env50722 = env50723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50722 == env50723) = true)

theorem identity50723 : scanCanonicalize (H12AffineFastState.compose env50723 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound50723 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50724 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,261,269,16384,1,262,16400,2308,1025,0,17681,0,16,3,269,16,2048,16401,260,2308,1285,0,257,1,16384,513]

theorem envBound50724 : H12AffineFastState.Bounded env50724 := by
  intro p hp
  have h : env50724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50723_50724 : H12AffineEnvironment.transform 11 261 env50723 = env50724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env50723 == env50724) = true)

theorem identity50724 : scanCanonicalize (H12AffineFastState.compose env50724 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 1541) := by decide +kernel

theorem selectedBound50724 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50725 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,261,269,1541,1,262,1557,2308,1025,0,788,0,16,3,269,16,2048,1556,260,2308,1285,0,257,1,1541,513]

theorem envBound50725 : H12AffineFastState.Bounded env50725 := by
  intro p hp
  have h : env50725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50724_50725 : H12AffineEnvironment.transform 13 1541 env50724 = env50725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1541 env50724 == env50725) = true)

theorem identity50725 : scanCanonicalize (H12AffineFastState.compose env50725 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound50725 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env50726 : List Nat := [2,4,8,16,0,17,8,256,512,21,2048,261,269,528,1,262,512,2308,20,0,788,0,16,3,269,16,2048,513,260,2308,272,0,257,1,528,513]

theorem envBound50726 : H12AffineFastState.Bounded env50726 := by
  intro p hp
  have h : env50726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50725_50726 : H12AffineEnvironment.transform 9 21 env50725 = env50726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env50725 == env50726) = true)

theorem identity50726 : scanCanonicalize (H12AffineFastState.compose env50726 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound50726 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env50727 : List Nat := [2,4,8,16,0,17,8,256,260,21,2048,261,269,276,1,262,260,2308,20,0,16,0,16,3,269,16,2048,261,260,2308,272,0,257,1,276,261]

theorem envBound50727 : H12AffineFastState.Bounded env50727 := by
  intro p hp
  have h : env50727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50726_50727 : H12AffineEnvironment.transform 8 260 env50726 = env50727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env50726 == env50727) = true)

theorem identity50727 : scanCanonicalize (H12AffineFastState.compose env50727 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50727 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env50728 : List Nat := [2,4,8,16,0,17,8,4,0,21,2048,1,9,16,1,2,0,2048,20,0,16,0,16,3,9,16,2048,1,0,2048,20,0,5,1,16,1]

theorem envBound50728 : H12AffineFastState.Bounded env50728 := by
  intro p hp
  have h : env50728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50727_50728 : H12AffineEnvironment.transform 7 4 env50727 = env50728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50727 == env50728) = true)

theorem identity50728 : scanCanonicalize (H12AffineFastState.compose env50728 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound50728 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50729 : List Nat := [2,4,8,16,0,17,8,4,0,21,1,1,9,16,1,2,0,1,20,0,16,0,16,3,9,16,1,1,0,1,20,0,5,1,16,1]

theorem envBound50729 : H12AffineFastState.Bounded env50729 := by
  intro p hp
  have h : env50729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50728_50729 : H12AffineEnvironment.transform 10 1 env50728 = env50729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env50728 == env50729) = true)

def env50730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,17,41311,8192,65,4450362,2172251,2118976,149860,75103,6407191,257,2188650,2196551,513]

theorem envBound50730 : H12AffineFastState.Bounded env50730 := by
  intro p hp
  have h : env50730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50714_50730 : H12AffineEnvironment.transform 22 17 env50714 = env50730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env50714 == env50730) = true)

theorem identity50730 : scanCanonicalize (H12AffineFastState.compose env50730 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound50730 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env50731 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,115735,4194304,17,41311,8192,65,4450362,57676,102743,149860,75103,4194304,257,41341,16464,513]

theorem envBound50731 : H12AffineFastState.Bounded env50731 := by
  intro p hp
  have h : env50731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50730_50731 : H12AffineEnvironment.transform 20 115735 env50730 = env50731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env50730 == env50731) = true)

def env50732 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9292,1025,11577,92463,4194304,17,3175,8192,65,4408578,19572,81007,149860,75103,4194304,257,3141,16464,513]

theorem envBound50732 : H12AffineFastState.Bounded env50732 := by
  intro p hp
  have h : env50732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50731_50732 : H12AffineEnvironment.transform 14 11576 env50731 = env50732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env50731 == env50732) = true)

theorem identity50732 : scanCanonicalize (H12AffineFastState.compose env50732 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound50732 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env50733 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,82246,9292,1025,11577,92463,4194304,17,3175,8192,65,4195396,19572,81007,67618,75103,4194304,257,3141,16464,513]

theorem envBound50733 : H12AffineFastState.Bounded env50733 := by
  intro p hp
  have h : env50733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50732_50733 : H12AffineEnvironment.transform 16 82246 env50732 = env50733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env50732 == env50733) = true)

def env50734 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8540,65536,82246,9292,1025,8541,91467,4194304,17,3,8192,65,4195396,16400,77835,66630,75103,4194304,257,33,16464,513]

theorem envBound50734 : H12AffineFastState.Bounded env50734 := by
  intro p hp
  have h : env50734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50733_50734 : H12AffineEnvironment.transform 10 1124 env50733 = env50734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env50733 == env50734) = true)

theorem identity50734 : scanCanonicalize (H12AffineFastState.compose env50734 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound50734 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50735 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8540,28699,12637,9292,1025,8541,5456,4194304,17,3,8192,65,4195396,16400,16400,29789,21828,4194304,257,33,16464,513]

theorem envBound50735 : H12AffineFastState.Bounded env50735 := by
  intro p hp
  have h : env50735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50734_50735 : H12AffineEnvironment.transform 15 28699 env50734 = env50735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env50734 == env50735) = true)

theorem identity50735 : scanCanonicalize (H12AffineFastState.compose env50735 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound50735 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env50736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,41,16384,373,20530,4468,1125,1025,372,5456,4194304,17,3,41,65,4195396,16400,16400,21620,21828,4194304,257,33,16464,513]

theorem envBound50736 : H12AffineFastState.Bounded env50736 := by
  intro p hp
  have h : env50736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50735_50736 : H12AffineEnvironment.transform 12 41 env50735 = env50736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env50735 == env50736) = true)

theorem identity50736 : scanCanonicalize (H12AffineFastState.compose env50736 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound50736 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env50737 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,1,20530,4096,1125,1025,0,5156,4194304,17,3,41,65,4195396,16400,16400,21620,21552,4194304,117,33,16464,513]

theorem envBound50737 : H12AffineFastState.Bounded env50737 := by
  intro p hp
  have h : env50737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50736_50737 : H12AffineEnvironment.transform 7 116 env50736 = env50737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env50736 == env50737) = true)

theorem identity50737 : scanCanonicalize (H12AffineFastState.compose env50737 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1045) := by decide +kernel

theorem selectedBound50737 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env50738 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,1,20530,4096,1125,1025,0,5156,1045,17,3,41,65,81,16400,16400,21620,21552,1045,117,33,16464,513]

theorem envBound50738 : H12AffineFastState.Bounded env50738 := by
  intro p hp
  have h : env50738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50737_50738 : H12AffineEnvironment.transform 21 1045 env50737 = env50738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1045 env50737 == env50738) = true)

theorem identity50738 : scanCanonicalize (H12AffineFastState.compose env50738 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound50738 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env50739 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,1076,1,5126,4096,1125,1025,0,5156,1045,17,3,41,65,81,1060,1060,4160,4100,1045,117,33,1124,513]

theorem envBound50739 : H12AffineFastState.Bounded env50739 := by
  intro p hp
  have h : env50739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50738_50739 : H12AffineEnvironment.transform 13 1076 env50738 = env50739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env50738 == env50739) = true)

theorem identity50739 : scanCanonicalize (H12AffineFastState.compose env50739 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50739 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env50740 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,4096,41,0,1,4146,4096,81,53,0,4112,33,17,3,41,65,81,16,16,4160,4100,33,117,33,80,513]

theorem envBound50740 : H12AffineFastState.Bounded env50740 := by
  intro p hp
  have h : env50740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50739_50740 : H12AffineEnvironment.transform 9 52 env50739 = env50740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50739 == env50740) = true)

theorem identity50740 : scanCanonicalize (H12AffineFastState.compose env50740 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50740 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env50741 : List Nat := [2,4,8,16,32,64,8,116,1,52,80,4096,41,0,1,4146,4096,81,53,0,4112,33,17,3,41,65,81,16,16,4160,4100,33,117,33,80,0]

theorem envBound50741 : H12AffineFastState.Bounded env50741 := by
  intro p hp
  have h : env50741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50740_50741 : H12AffineEnvironment.transform 8 1 env50740 = env50741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50740 == env50741) = true)

theorem identity50741 : scanCanonicalize (H12AffineFastState.compose env50741 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound50741 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env50742 : List Nat := [2,4,8,16,32,64,8,116,1,52,80,64,41,0,1,114,64,81,53,0,80,33,17,3,41,65,81,16,16,0,68,33,117,33,80,0]

theorem envBound50742 : H12AffineFastState.Bounded env50742 := by
  intro p hp
  have h : env50742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50741_50742 : H12AffineEnvironment.transform 11 64 env50741 = env50742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env50741 == env50742) = true)

def env50743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1125,4096,8192,16384,8541,65536,82246,9292,1025,8540,91466,4194304,17,2,8192,65,4195396,16401,77834,66631,75103,4194304,257,32,16464,513]

theorem envBound50743 : H12AffineFastState.Bounded env50743 := by
  intro p hp
  have h : env50743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50733_50743 : H12AffineEnvironment.transform 10 1125 env50733 = env50743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env50733 == env50743) = true)

def env50744 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,16384,8461,65536,82198,9244,1025,8460,91418,4194304,17,2,8192,17,4195348,16401,77834,66583,75023,4194304,257,32,16384,513]

theorem envBound50744 : H12AffineFastState.Bounded env50744 := by
  intro p hp
  have h : env50744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50743_50744 : H12AffineEnvironment.transform 5 16 env50743 = env50744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50743 == env50744) = true)

theorem identity50744 : scanCanonicalize (H12AffineFastState.compose env50744 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50744 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50745 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,8192,16384,8461,8203,24861,9244,1025,8460,17681,4194304,17,2,8192,17,4195348,16401,4097,9244,1284,4194304,257,32,16384,513]

theorem envBound50745 : H12AffineFastState.Bounded env50745 := by
  intro p hp
  have h : env50745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50744_50745 : H12AffineEnvironment.transform 15 8203 env50744 = env50745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50744 == env50745) = true)

theorem identity50745 : scanCanonicalize (H12AffineFastState.compose env50745 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50745 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50746 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,16384,0,262,16400,1297,1025,1,17681,4194304,17,2,269,17,4195348,16401,4097,1297,1284,4194304,257,32,16384,513]

theorem envBound50746 : H12AffineFastState.Bounded env50746 := by
  intro p hp
  have h : env50746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50745_50746 : H12AffineEnvironment.transform 12 269 env50745 = env50746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50745 == env50746) = true)

theorem identity50746 : scanCanonicalize (H12AffineFastState.compose env50746 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound50746 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50747 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,16384,0,262,16400,1297,1025,1,17681,21509,17,2,269,17,20497,16401,4097,1297,1284,21509,257,32,16384,513]

theorem envBound50747 : H12AffineFastState.Bounded env50747 := by
  intro p hp
  have h : env50747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50746_50747 : H12AffineEnvironment.transform 21 21509 env50746 = env50747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env50746 == env50747) = true)

theorem identity50747 : scanCanonicalize (H12AffineFastState.compose env50747 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound50747 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50748 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,4096,269,5156,0,262,5172,1297,1025,1,4405,33,17,2,269,17,1077,5173,4097,1297,1284,33,257,32,5156,513]

theorem envBound50748 : H12AffineFastState.Bounded env50748 := by
  intro p hp
  have h : env50748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50747_50748 : H12AffineEnvironment.transform 13 5156 env50747 = env50748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env50747 == env50748) = true)

def env50749 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,544,269,1540,0,262,1556,1297,1025,1,789,33,17,2,269,17,1077,1557,545,1297,1284,33,257,32,1540,513]

theorem envBound50749 : H12AffineFastState.Bounded env50749 := by
  intro p hp
  have h : env50749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50748_50749 : H12AffineEnvironment.transform 11 544 env50748 = env50749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env50748 == env50749) = true)

def env50750 : List Nat := [2,4,8,16,32,16,8,256,512,768,821,544,269,260,0,262,276,529,769,1,789,33,17,2,269,17,821,277,545,529,516,33,257,32,260,513]

theorem envBound50750 : H12AffineFastState.Bounded env50750 := by
  intro p hp
  have h : env50750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50749_50750 : H12AffineEnvironment.transform 9 768 env50749 = env50750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env50749 == env50750) = true)

theorem identity50750 : scanCanonicalize (H12AffineFastState.compose env50750 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound50750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50751 : List Nat := [2,4,8,16,32,16,8,256,49,305,260,17,269,260,0,262,276,32,304,1,292,33,17,2,269,17,260,277,16,32,53,33,257,32,260,48]

theorem envBound50751 : H12AffineFastState.Bounded env50751 := by
  intro p hp
  have h : env50751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50750_50751 : H12AffineEnvironment.transform 8 49 env50750 = env50751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env50750 == env50751) = true)

def env50752 : List Nat := [2,4,8,16,32,16,8,4,49,53,0,17,9,0,0,2,16,32,52,1,32,33,17,2,9,17,0,17,16,32,53,33,5,32,0,48]

theorem envBound50752 : H12AffineFastState.Bounded env50752 := by
  intro p hp
  have h : env50752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50751_50752 : H12AffineEnvironment.transform 7 4 env50751 = env50752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50751 == env50752) = true)

theorem identity50752 : scanCanonicalize (H12AffineFastState.compose env50752 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50753 : List Nat := [2,4,8,10,32,10,8,4,43,47,0,11,9,0,0,2,10,32,46,1,32,33,11,2,9,11,0,11,10,32,47,33,5,32,0,42]

theorem envBound50753 : H12AffineFastState.Bounded env50753 := by
  intro p hp
  have h : env50753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50752_50753 : H12AffineEnvironment.transform 3 10 env50752 = env50753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50752 == env50753) = true)

def leafEnv50753 : List Nat := [2,4,8,10,32,10,8,4,43,47,0,11,9,0,0,2,10,32,46,1,32,33,11,2,46,9,1,11,0,11,10,32,47,33,5,32,5,2,0,42,1,32,0]

def active50753 : List Nat := [0,1,2,4]

def tree50753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50753 : H12WitnessSearch.Good tree50753 := H12GlobalWitnessIndex.good

theorem leafIdentity50753 : H12AffineFastState.composeSystem env50753 rootObs = leafEnv50753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50753 rootObs == leafEnv50753) = true)

theorem terminalChecked50753 : H12PackedTerminal.terminalCheckFast leafEnv50753 active50753 tree50753 = true := by decide +kernel

def env50754 : List Nat := [2,4,8,16,32,16,8,5,49,52,1,17,8,1,0,3,17,32,53,1,33,33,17,2,8,17,1,16,16,32,53,33,4,32,1,48]

theorem envBound50754 : H12AffineFastState.Bounded env50754 := by
  intro p hp
  have h : env50754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50751_50754 : H12AffineEnvironment.transform 7 5 env50751 = env50754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50751 == env50754) = true)

def env50755 : List Nat := [2,4,8,16,32,16,8,256,512,769,820,544,269,261,0,262,277,528,768,1,789,33,17,2,269,17,820,276,545,528,517,33,257,32,261,513]

theorem envBound50755 : H12AffineFastState.Bounded env50755 := by
  intro p hp
  have h : env50755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50749_50755 : H12AffineEnvironment.transform 9 769 env50749 = env50755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env50749 == env50755) = true)

theorem identity50755 : scanCanonicalize (H12AffineFastState.compose env50755 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50755 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50756 : List Nat := [2,4,8,16,1,16,8,256,512,769,789,513,269,261,0,262,277,528,768,1,789,0,17,2,269,17,789,276,512,528,517,0,257,1,261,513]

theorem envBound50756 : H12AffineFastState.Bounded env50756 := by
  intro p hp
  have h : env50756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50755_50756 : H12AffineEnvironment.transform 4 1 env50755 = env50756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50755 == env50756) = true)

def env50757 : List Nat := [2,4,8,16,1,16,8,256,276,21,1,277,269,261,0,262,277,260,20,1,1,0,17,2,269,17,1,276,276,260,273,0,257,1,261,277]

theorem envBound50757 : H12AffineFastState.Bounded env50757 := by
  intro p hp
  have h : env50757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50756_50757 : H12AffineEnvironment.transform 8 276 env50756 = env50757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env50756 == env50757) = true)

def env50758 : List Nat := [2,4,8,16,1,16,8,256,277,20,0,276,269,261,0,262,277,261,21,1,0,0,17,2,269,17,0,276,277,261,272,0,257,1,261,276]

theorem envBound50758 : H12AffineFastState.Bounded env50758 := by
  intro p hp
  have h : env50758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50756_50758 : H12AffineEnvironment.transform 8 277 env50756 = env50758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env50756 == env50758) = true)

theorem identity50758 : scanCanonicalize (H12AffineFastState.compose env50758 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound50758 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50759 : List Nat := [2,4,8,16,1,16,8,30,11,20,0,10,19,27,0,24,11,27,21,1,0,0,17,2,19,17,0,10,11,27,14,0,31,1,27,10]

theorem envBound50759 : H12AffineFastState.Bounded env50759 := by
  intro p hp
  have h : env50759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50758_50759 : H12AffineEnvironment.transform 7 30 env50758 = env50759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env50758 == env50759) = true)

def leafEnv50759 : List Nat := [2,4,8,16,1,16,8,30,11,20,0,10,19,27,0,24,11,27,21,1,0,0,17,2,15,19,1,17,0,10,11,27,14,0,31,1,5,24,27,10,1,0,0]

def active50759 : List Nat := [0,1,2,3]

def tree50759 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50759 : H12WitnessSearch.Good tree50759 := H12GlobalWitnessIndex.good

theorem leafIdentity50759 : H12AffineFastState.composeSystem env50759 rootObs = leafEnv50759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50759 rootObs == leafEnv50759) = true)

theorem terminalChecked50759 : H12PackedTerminal.terminalCheckFast leafEnv50759 active50759 tree50759 = true := by decide +kernel

def env50760 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1077,545,269,1541,0,262,1557,1297,1025,1,788,33,17,2,269,17,1077,1556,544,1297,1284,33,257,32,1541,513]

theorem envBound50760 : H12AffineFastState.Bounded env50760 := by
  intro p hp
  have h : env50760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50748_50760 : H12AffineEnvironment.transform 11 545 env50748 = env50760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env50748 == env50760) = true)

def env50761 : List Nat := [2,4,8,16,32,16,8,256,512,768,821,545,269,261,0,262,277,529,769,1,788,33,17,2,269,17,821,276,544,529,516,33,257,32,261,513]

theorem envBound50761 : H12AffineFastState.Bounded env50761 := by
  intro p hp
  have h : env50761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50760_50761 : H12AffineEnvironment.transform 9 768 env50760 = env50761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env50760 == env50761) = true)

theorem identity50761 : scanCanonicalize (H12AffineFastState.compose env50761 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound50761 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50762 : List Nat := [2,4,8,16,32,16,8,5,512,517,560,545,8,0,0,3,16,529,516,1,529,33,17,2,8,17,560,17,544,529,516,33,4,32,0,513]

theorem envBound50762 : H12AffineFastState.Bounded env50762 := by
  intro p hp
  have h : env50762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50761_50762 : H12AffineEnvironment.transform 7 5 env50761 = env50762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50761 == env50762) = true)

def env50763 : List Nat := [2,4,8,16,32,16,8,5,48,53,0,17,8,0,0,3,16,33,52,1,33,33,17,2,8,17,0,17,16,33,52,33,4,32,0,49]

theorem envBound50763 : H12AffineFastState.Bounded env50763 := by
  intro p hp
  have h : env50763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50762_50763 : H12AffineEnvironment.transform 8 48 env50762 = env50763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50762 == env50763) = true)

theorem identity50763 : scanCanonicalize (H12AffineFastState.compose env50763 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50763 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50764 : List Nat := [2,4,8,10,32,10,8,5,42,47,0,11,8,0,0,3,10,33,46,1,33,33,11,2,8,11,0,11,10,33,46,33,4,32,0,43]

theorem envBound50764 : H12AffineFastState.Bounded env50764 := by
  intro p hp
  have h : env50764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50763_50764 : H12AffineEnvironment.transform 3 10 env50763 = env50764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50763 == env50764) = true)

def leafEnv50764 : List Nat := [2,4,8,10,32,10,8,5,42,47,0,11,8,0,0,3,10,33,46,1,33,33,11,2,47,8,1,11,0,11,10,33,46,33,4,32,5,3,0,43,1,33,0]

def active50764 : List Nat := [0,1,2,4]

def tree50764 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50764 : H12WitnessSearch.Good tree50764 := H12GlobalWitnessIndex.good

theorem leafIdentity50764 : H12AffineFastState.composeSystem env50764 rootObs = leafEnv50764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50764 rootObs == leafEnv50764) = true)

theorem terminalChecked50764 : H12PackedTerminal.terminalCheckFast leafEnv50764 active50764 tree50764 = true := by decide +kernel

def env50765 : List Nat := [2,4,8,16,32,16,8,5,49,52,1,16,8,0,0,3,16,32,53,1,32,33,17,2,8,17,1,17,17,32,53,33,4,32,0,48]

theorem envBound50765 : H12AffineFastState.Bounded env50765 := by
  intro p hp
  have h : env50765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50762_50765 : H12AffineEnvironment.transform 8 49 env50762 = env50765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env50762 == env50765) = true)

def env50766 : List Nat := [2,4,8,16,32,16,8,256,512,769,820,545,269,260,0,262,276,528,768,1,788,33,17,2,269,17,820,277,544,528,517,33,257,32,260,513]

theorem envBound50766 : H12AffineFastState.Bounded env50766 := by
  intro p hp
  have h : env50766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50760_50766 : H12AffineEnvironment.transform 9 769 env50760 = env50766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env50760 == env50766) = true)

theorem identity50766 : scanCanonicalize (H12AffineFastState.compose env50766 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound50766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50767 : List Nat := [2,4,8,16,32,16,8,256,276,21,32,309,269,260,0,262,276,260,20,1,0,33,17,2,269,17,32,277,308,260,273,33,257,32,260,277]

theorem envBound50767 : H12AffineFastState.Bounded env50767 := by
  intro p hp
  have h : env50767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50766_50767 : H12AffineEnvironment.transform 8 276 env50766 = env50767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env50766 == env50767) = true)

def env50768 : List Nat := [2,4,8,16,0,16,8,256,276,21,0,277,269,260,0,262,276,260,20,1,0,1,17,2,269,17,0,277,276,260,273,1,257,0,260,277]

theorem envBound50768 : H12AffineFastState.Bounded env50768 := by
  intro p hp
  have h : env50768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50767_50768 : H12AffineEnvironment.transform 4 0 env50767 = env50768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50767 == env50768) = true)

theorem identity50768 : scanCanonicalize (H12AffineFastState.compose env50768 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound50768 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50769 : List Nat := [2,4,8,16,0,16,8,31,11,21,0,10,18,27,0,25,11,27,20,1,0,1,17,2,18,17,0,10,11,27,14,1,30,0,27,10]

theorem envBound50769 : H12AffineFastState.Bounded env50769 := by
  intro p hp
  have h : env50769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50768_50769 : H12AffineEnvironment.transform 7 31 env50768 = env50769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env50768 == env50769) = true)

def leafEnv50769 : List Nat := [2,4,8,16,0,16,8,31,11,21,0,10,18,27,0,25,11,27,20,1,0,1,17,2,15,18,1,17,0,10,11,27,14,1,30,0,5,25,27,10,1,0,0]

def active50769 : List Nat := [0,1,2,3]

def tree50769 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50769 : H12WitnessSearch.Good tree50769 := H12GlobalWitnessIndex.good

theorem leafIdentity50769 : H12AffineFastState.composeSystem env50769 rootObs = leafEnv50769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50769 rootObs == leafEnv50769) = true)

theorem terminalChecked50769 : H12PackedTerminal.terminalCheckFast leafEnv50769 active50769 tree50769 = true := by decide +kernel

def env50770 : List Nat := [2,4,8,16,1,16,8,256,276,21,1,276,269,260,0,262,276,260,20,1,0,0,17,2,269,17,1,277,277,260,273,0,257,1,260,277]

theorem envBound50770 : H12AffineFastState.Bounded env50770 := by
  intro p hp
  have h : env50770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50767_50770 : H12AffineEnvironment.transform 4 1 env50767 = env50770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50767 == env50770) = true)

def env50771 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,4096,8192,16384,8460,65536,82199,9245,1025,8461,91419,4194304,17,2,8192,16,4195349,16401,77834,66582,75022,4194304,257,32,16385,513]

theorem envBound50771 : H12AffineFastState.Bounded env50771 := by
  intro p hp
  have h : env50771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50743_50771 : H12AffineEnvironment.transform 5 17 env50743 = env50771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50743 == env50771) = true)

def env50772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,131072,9293,1025,11576,92462,4194304,17,3174,8192,65,4408579,19573,81006,149860,75103,4194304,257,3140,16464,513]

theorem envBound50772 : H12AffineFastState.Bounded env50772 := by
  intro p hp
  have h : env50772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50731_50772 : H12AffineEnvironment.transform 14 11577 env50731 = env50772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11577 env50731 == env50772) = true)

theorem identity50772 : scanCanonicalize (H12AffineFastState.compose env50772 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 85282) := by decide +kernel

theorem selectedBound50772 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env50773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11577,65536,85282,9293,1025,11576,92462,4194304,17,3174,8192,65,4196385,19573,81006,66630,75103,4194304,257,3140,16464,513]

theorem envBound50773 : H12AffineFastState.Bounded env50773 := by
  intro p hp
  have h : env50773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50772_50773 : H12AffineEnvironment.transform 16 85282 env50772 = env50773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 85282 env50772 == env50773) = true)

theorem identity50773 : scanCanonicalize (H12AffineFastState.compose env50773 (packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound50773 : packedSelected [4,7,9,12,15,18,23,27,38,41] rootPS < 2^1333 := by decide +kernel

def env50774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8541,65536,82246,9293,1025,8540,91466,4194304,17,2,8192,65,4195397,16401,77834,66630,75103,4194304,257,32,16464,513]

theorem envBound50774 : H12AffineFastState.Bounded env50774 := by
  intro p hp
  have h : env50774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50773_50774 : H12AffineEnvironment.transform 10 1124 env50773 = env50774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env50773 == env50774) = true)

def env50775 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,8192,16384,8461,65536,82198,9245,1025,8460,91418,4194304,17,2,8192,17,4195349,16401,77834,66582,75023,4194304,257,32,16384,513]

theorem envBound50775 : H12AffineFastState.Bounded env50775 := by
  intro p hp
  have h : env50775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50774_50775 : H12AffineEnvironment.transform 5 16 env50774 = env50775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50774 == env50775) = true)

theorem identity50775 : scanCanonicalize (H12AffineFastState.compose env50775 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50775 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50776 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,8192,16384,8461,8203,24861,9245,1025,8460,17681,4194304,17,2,8192,17,4195349,16401,4097,9245,1284,4194304,257,32,16384,513]

theorem envBound50776 : H12AffineFastState.Bounded env50776 := by
  intro p hp
  have h : env50776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50775_50776 : H12AffineEnvironment.transform 15 8203 env50775 = env50776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50775 == env50776) = true)

theorem identity50776 : scanCanonicalize (H12AffineFastState.compose env50776 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound50776 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50777 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,269,16384,0,262,16400,1296,1025,1,17681,4194304,17,2,269,17,4195349,16401,4097,1296,1284,4194304,257,32,16384,513]

theorem envBound50777 : H12AffineFastState.Bounded env50777 := by
  intro p hp
  have h : env50777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50776_50777 : H12AffineEnvironment.transform 12 269 env50776 = env50777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env50776 == env50777) = true)

theorem identity50777 : scanCanonicalize (H12AffineFastState.compose env50777 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound50777 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env50778 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,269,16384,0,262,16400,1296,1025,1,17681,21509,17,2,269,17,20496,16401,4097,1296,1284,21509,257,32,16384,513]

theorem envBound50778 : H12AffineFastState.Bounded env50778 := by
  intro p hp
  have h : env50778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50777_50778 : H12AffineEnvironment.transform 21 21509 env50777 = env50778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env50777 == env50778) = true)

theorem identity50778 : scanCanonicalize (H12AffineFastState.compose env50778 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound50778 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50779 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,4096,269,5156,0,262,5172,1296,1025,1,4405,33,17,2,269,17,1076,5173,4097,1296,1284,33,257,32,5156,513]

theorem envBound50779 : H12AffineFastState.Bounded env50779 := by
  intro p hp
  have h : env50779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50778_50779 : H12AffineEnvironment.transform 13 5156 env50778 = env50779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env50778 == env50779) = true)

def env50780 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,544,269,1540,0,262,1556,1296,1025,1,789,33,17,2,269,17,1076,1557,545,1296,1284,33,257,32,1540,513]

theorem envBound50780 : H12AffineFastState.Bounded env50780 := by
  intro p hp
  have h : env50780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50779_50780 : H12AffineEnvironment.transform 11 544 env50779 = env50780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env50779 == env50780) = true)

def env50781 : List Nat := [2,4,8,16,32,16,8,256,512,768,820,544,269,260,0,262,276,528,769,1,789,33,17,2,269,17,820,277,545,528,516,33,257,32,260,513]

theorem envBound50781 : H12AffineFastState.Bounded env50781 := by
  intro p hp
  have h : env50781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50780_50781 : H12AffineEnvironment.transform 9 768 env50780 = env50781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env50780 == env50781) = true)

theorem identity50781 : scanCanonicalize (H12AffineFastState.compose env50781 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound50781 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50782 : List Nat := [2,4,8,16,32,16,8,256,276,20,32,308,269,260,0,262,276,260,21,1,1,33,17,2,269,17,32,277,309,260,272,33,257,32,260,277]

theorem envBound50782 : H12AffineFastState.Bounded env50782 := by
  intro p hp
  have h : env50782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50781_50782 : H12AffineEnvironment.transform 8 276 env50781 = env50782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env50781 == env50782) = true)

def env50783 : List Nat := [2,4,8,16,0,16,8,256,276,20,0,276,269,260,0,262,276,260,21,1,1,1,17,2,269,17,0,277,277,260,272,1,257,0,260,277]

theorem envBound50783 : H12AffineFastState.Bounded env50783 := by
  intro p hp
  have h : env50783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50782_50783 : H12AffineEnvironment.transform 4 0 env50782 = env50783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50782 == env50783) = true)

def env50784 : List Nat := [2,4,8,16,1,16,8,256,276,20,1,277,269,260,0,262,276,260,21,1,1,0,17,2,269,17,1,277,276,260,272,0,257,1,260,277]

theorem envBound50784 : H12AffineFastState.Bounded env50784 := by
  intro p hp
  have h : env50784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50782_50784 : H12AffineEnvironment.transform 4 1 env50782 = env50784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50782 == env50784) = true)

theorem identity50784 : scanCanonicalize (H12AffineFastState.compose env50784 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound50784 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50785 : List Nat := [2,4,8,16,1,16,8,30,10,20,1,11,19,26,0,24,10,26,21,1,1,0,17,2,19,17,1,11,10,26,14,0,31,1,26,11]

theorem envBound50785 : H12AffineFastState.Bounded env50785 := by
  intro p hp
  have h : env50785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50784_50785 : H12AffineEnvironment.transform 7 30 env50784 = env50785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env50784 == env50785) = true)

def leafEnv50785 : List Nat := [2,4,8,16,1,16,8,30,10,20,1,11,19,26,0,24,10,26,21,1,1,0,17,2,15,19,1,17,1,11,10,26,14,0,31,1,5,24,26,11,1,1,0]

def active50785 : List Nat := [0,1,2,3]

def tree50785 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50785 : H12WitnessSearch.Good tree50785 := H12GlobalWitnessIndex.good

theorem leafIdentity50785 : H12AffineFastState.composeSystem env50785 rootObs = leafEnv50785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50785 rootObs == leafEnv50785) = true)

theorem terminalChecked50785 : H12PackedTerminal.terminalCheckFast leafEnv50785 active50785 tree50785 = true := by decide +kernel

def env50786 : List Nat := [2,4,8,16,32,16,8,256,512,769,821,544,269,261,0,262,277,529,768,1,789,33,17,2,269,17,821,276,545,529,517,33,257,32,261,513]

theorem envBound50786 : H12AffineFastState.Bounded env50786 := by
  intro p hp
  have h : env50786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50780_50786 : H12AffineEnvironment.transform 9 769 env50780 = env50786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env50780 == env50786) = true)

theorem identity50786 : scanCanonicalize (H12AffineFastState.compose env50786 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50787 : List Nat := [2,4,8,16,32,16,8,4,512,517,561,544,9,1,0,2,17,529,516,1,529,33,17,2,9,17,561,16,545,529,517,33,5,32,1,513]

theorem envBound50787 : H12AffineFastState.Bounded env50787 := by
  intro p hp
  have h : env50787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50786_50787 : H12AffineEnvironment.transform 7 4 env50786 = env50787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50786 == env50787) = true)

def env50788 : List Nat := [2,4,8,16,32,16,8,4,48,53,1,16,9,1,0,2,17,33,52,1,33,33,17,2,9,17,1,16,17,33,53,33,5,32,1,49]

theorem envBound50788 : H12AffineFastState.Bounded env50788 := by
  intro p hp
  have h : env50788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50787_50788 : H12AffineEnvironment.transform 8 48 env50787 = env50788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env50787 == env50788) = true)

theorem identity50788 : scanCanonicalize (H12AffineFastState.compose env50788 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50789 : List Nat := [2,4,8,10,32,10,8,4,42,47,1,10,9,1,0,2,11,33,46,1,33,33,11,2,9,11,1,10,11,33,47,33,5,32,1,43]

theorem envBound50789 : H12AffineFastState.Bounded env50789 := by
  intro p hp
  have h : env50789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50788_50789 : H12AffineEnvironment.transform 3 10 env50788 = env50789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50788 == env50789) = true)

def leafEnv50789 : List Nat := [2,4,8,10,32,10,8,4,42,47,1,10,9,1,0,2,11,33,46,1,33,33,11,2,46,9,1,11,1,10,11,33,47,33,5,32,5,2,1,43,1,33,0]

def active50789 : List Nat := [0,1,2,4]

def tree50789 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50789 : H12WitnessSearch.Good tree50789 := H12GlobalWitnessIndex.good

theorem leafIdentity50789 : H12AffineFastState.composeSystem env50789 rootObs = leafEnv50789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50789 rootObs == leafEnv50789) = true)

theorem terminalChecked50789 : H12PackedTerminal.terminalCheckFast leafEnv50789 active50789 tree50789 = true := by decide +kernel

def env50790 : List Nat := [2,4,8,16,32,16,8,4,49,52,0,17,9,1,0,2,17,32,53,1,32,33,17,2,9,17,0,16,16,32,52,33,5,32,1,48]

theorem envBound50790 : H12AffineFastState.Bounded env50790 := by
  intro p hp
  have h : env50790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50787_50790 : H12AffineEnvironment.transform 8 49 env50787 = env50790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env50787 == env50790) = true)

def env50791 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1076,545,269,1541,0,262,1557,1296,1025,1,788,33,17,2,269,17,1076,1556,544,1296,1284,33,257,32,1541,513]

theorem envBound50791 : H12AffineFastState.Bounded env50791 := by
  intro p hp
  have h : env50791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50779_50791 : H12AffineEnvironment.transform 11 545 env50779 = env50791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env50779 == env50791) = true)

def env50792 : List Nat := [2,4,8,16,32,16,8,256,512,768,820,545,269,261,0,262,277,528,769,1,788,33,17,2,269,17,820,276,544,528,516,33,257,32,261,513]

theorem envBound50792 : H12AffineFastState.Bounded env50792 := by
  intro p hp
  have h : env50792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50791_50792 : H12AffineEnvironment.transform 9 768 env50791 = env50792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env50791 == env50792) = true)

theorem identity50792 : scanCanonicalize (H12AffineFastState.compose env50792 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50792 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50793 : List Nat := [2,4,8,16,0,16,8,256,512,768,788,513,269,261,0,262,277,528,769,1,788,1,17,2,269,17,788,276,512,528,516,1,257,0,261,513]

theorem envBound50793 : H12AffineFastState.Bounded env50793 := by
  intro p hp
  have h : env50793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50792_50793 : H12AffineEnvironment.transform 4 0 env50792 = env50793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50792 == env50793) = true)

def env50794 : List Nat := [2,4,8,16,0,16,8,256,276,20,0,277,269,261,0,262,277,260,21,1,0,1,17,2,269,17,0,276,276,260,272,1,257,0,261,277]

theorem envBound50794 : H12AffineFastState.Bounded env50794 := by
  intro p hp
  have h : env50794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50793_50794 : H12AffineEnvironment.transform 8 276 env50793 = env50794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env50793 == env50794) = true)

def env50795 : List Nat := [2,4,8,16,0,16,8,256,277,21,1,276,269,261,0,262,277,261,20,1,1,1,17,2,269,17,1,276,277,261,273,1,257,0,261,276]

theorem envBound50795 : H12AffineFastState.Bounded env50795 := by
  intro p hp
  have h : env50795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50793_50795 : H12AffineEnvironment.transform 8 277 env50793 = env50795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env50793 == env50795) = true)

theorem identity50795 : scanCanonicalize (H12AffineFastState.compose env50795 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound50795 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50796 : List Nat := [2,4,8,16,0,16,8,31,10,21,1,11,18,26,0,25,10,26,20,1,1,1,17,2,18,17,1,11,10,26,14,1,30,0,26,11]

theorem envBound50796 : H12AffineFastState.Bounded env50796 := by
  intro p hp
  have h : env50796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50795_50796 : H12AffineEnvironment.transform 7 31 env50795 = env50796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env50795 == env50796) = true)

def leafEnv50796 : List Nat := [2,4,8,16,0,16,8,31,10,21,1,11,18,26,0,25,10,26,20,1,1,1,17,2,15,18,1,17,1,11,10,26,14,1,30,0,5,25,26,11,1,1,0]

def active50796 : List Nat := [0,1,2,3]

def tree50796 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50796 : H12WitnessSearch.Good tree50796 := H12GlobalWitnessIndex.good

theorem leafIdentity50796 : H12AffineFastState.composeSystem env50796 rootObs = leafEnv50796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50796 rootObs == leafEnv50796) = true)

theorem terminalChecked50796 : H12PackedTerminal.terminalCheckFast leafEnv50796 active50796 tree50796 = true := by decide +kernel

def env50797 : List Nat := [2,4,8,16,32,16,8,256,512,769,821,545,269,260,0,262,276,529,768,1,788,33,17,2,269,17,821,277,544,529,517,33,257,32,260,513]

theorem envBound50797 : H12AffineFastState.Bounded env50797 := by
  intro p hp
  have h : env50797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50791_50797 : H12AffineEnvironment.transform 9 769 env50791 = env50797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env50791 == env50797) = true)

theorem identity50797 : scanCanonicalize (H12AffineFastState.compose env50797 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound50797 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50798 : List Nat := [2,4,8,16,32,16,8,256,49,304,260,16,269,260,0,262,276,32,305,1,293,33,17,2,269,17,260,277,17,32,52,33,257,32,260,48]

theorem envBound50798 : H12AffineFastState.Bounded env50798 := by
  intro p hp
  have h : env50798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50797_50798 : H12AffineEnvironment.transform 8 49 env50797 = env50798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env50797 == env50798) = true)

def env50799 : List Nat := [2,4,8,16,32,16,8,4,49,52,0,16,9,0,0,2,16,32,53,1,33,33,17,2,9,17,0,17,17,32,52,33,5,32,0,48]

theorem envBound50799 : H12AffineFastState.Bounded env50799 := by
  intro p hp
  have h : env50799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50798_50799 : H12AffineEnvironment.transform 7 4 env50798 = env50799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50798 == env50799) = true)

def env50800 : List Nat := [2,4,8,16,32,16,8,5,49,53,1,16,8,1,0,3,17,32,52,1,32,33,17,2,8,17,1,16,17,32,52,33,4,32,1,48]

theorem envBound50800 : H12AffineFastState.Bounded env50800 := by
  intro p hp
  have h : env50800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50798_50800 : H12AffineEnvironment.transform 7 5 env50798 = env50800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env50798 == env50800) = true)

theorem identity50800 : scanCanonicalize (H12AffineFastState.compose env50800 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound50800 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50801 : List Nat := [2,4,8,10,32,10,8,5,43,47,1,10,8,1,0,3,11,32,46,1,32,33,11,2,8,11,1,10,11,32,46,33,4,32,1,42]

theorem envBound50801 : H12AffineFastState.Bounded env50801 := by
  intro p hp
  have h : env50801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50800_50801 : H12AffineEnvironment.transform 3 10 env50800 = env50801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env50800 == env50801) = true)

def leafEnv50801 : List Nat := [2,4,8,10,32,10,8,5,43,47,1,10,8,1,0,3,11,32,46,1,32,33,11,2,47,8,1,11,1,10,11,32,46,33,4,32,5,3,1,42,1,32,0]

def active50801 : List Nat := [0,1,2,4]

def tree50801 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50801 : H12WitnessSearch.Good tree50801 := H12GlobalWitnessIndex.good

theorem leafIdentity50801 : H12AffineFastState.composeSystem env50801 rootObs = leafEnv50801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50801 rootObs == leafEnv50801) = true)

theorem terminalChecked50801 : H12PackedTerminal.terminalCheckFast leafEnv50801 active50801 tree50801 = true := by decide +kernel

def env50802 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,4096,8192,16384,8460,65536,82199,9244,1025,8461,91419,4194304,17,2,8192,16,4195348,16401,77834,66583,75022,4194304,257,32,16385,513]

theorem envBound50802 : H12AffineFastState.Bounded env50802 := by
  intro p hp
  have h : env50802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50774_50802 : H12AffineEnvironment.transform 5 17 env50774 = env50802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50774 == env50802) = true)

def env50803 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4450362,10857535,10507601,8830977,371755,15027571,257,2485279,2428211,297844]

theorem envBound50803 : H12AffineFastState.Bounded env50803 := by
  intro p hp
  have h : env50803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50712_50803 : H12AffineEnvironment.transform 6 9 env50712 = env50803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50712 == env50803) = true)

theorem identity50803 : scanCanonicalize (H12AffineFastState.compose env50803 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50803 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env50804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1025,32769,2097152,4194304,8388608,8661050,8193,65,4229153,10857535,10507601,8757274,371755,15027571,257,2485279,2428211,297844]

theorem envBound50804 : H12AffineFastState.Bounded env50804 := by
  intro p hp
  have h : env50804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50803_50804 : H12AffineEnvironment.transform 16 90139 env50803 = env50804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50803 == env50804) = true)

def env50805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,8388608,8429902,8193,65,4229153,10560843,10507601,8464750,75103,14795783,257,2188651,2196551,512]

theorem envBound50805 : H12AffineFastState.Bounded env50805 := by
  intro p hp
  have h : env50805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50804_50805 : H12AffineEnvironment.transform 17 35188 env50804 = env50805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env50804 == env50805) = true)

theorem identity50805 : scanCanonicalize (H12AffineFastState.compose env50805 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17460) := by decide +kernel

theorem selectedBound50805 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env50806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,17460,4194304,8388608,8429902,8193,65,4229153,8479103,8393061,8464750,75103,12681267,257,74079,114803,512]

theorem envBound50806 : H12AffineFastState.Bounded env50806 := by
  intro p hp
  have h : env50806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50805_50806 : H12AffineEnvironment.transform 20 17460 env50805 = env50806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17460 env50805 == env50806) = true)

theorem identity50806 : scanCanonicalize (H12AffineFastState.compose env50806 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 21604) := by decide +kernel

theorem selectedBound50806 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,17460,4194304,21604,62762,8193,65,4229153,79131,17665,97546,75103,4314199,257,74079,114803,512]

theorem envBound50807 : H12AffineFastState.Bounded env50807 := by
  intro p hp
  have h : env50807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50806_50807 : H12AffineEnvironment.transform 22 21604 env50806 = env50807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21604 env50806 == env50807) = true)

theorem identity50807 : scanCanonicalize (H12AffineFastState.compose env50807 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 62729) := by decide +kernel

theorem selectedBound50807 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env50808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,17460,62729,21604,62762,8193,65,32040,79131,17665,97546,75103,74078,257,74079,114803,512]

theorem envBound50808 : H12AffineFastState.Bounded env50808 := by
  intro p hp
  have h : env50808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50807_50808 : H12AffineEnvironment.transform 21 62729 env50807 = env50808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62729 env50807 == env50808) = true)

theorem identity50808 : scanCanonicalize (H12AffineFastState.compose env50808 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50808 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env50809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35188,1025,32769,17460,62729,21604,62762,8193,65,32040,5393,17665,23808,1365,340,257,341,57465,512]

theorem envBound50809 : H12AffineFastState.Bounded env50809 := by
  intro p hp
  have h : env50809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50808_50809 : H12AffineEnvironment.transform 15 8202 env50808 = env50809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50808 == env50809) = true)

theorem identity50809 : scanCanonicalize (H12AffineFastState.compose env50809 (packedSelected [0,7,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound50809 : packedSelected [0,7,17,20] rootPS < 2^1333 := by decide +kernel

def env50810 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,8192,16384,32768,8202,16401,34849,1025,32769,17460,62556,21604,62591,8193,65,31869,5188,17492,23637,1024,1,84,0,57465,512]

theorem envBound50810 : H12AffineFastState.Bounded env50810 := by
  intro p hp
  have h : env50810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50809_50810 : H12AffineEnvironment.transform 7 85 env50809 = env50810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env50809 == env50810) = true)

theorem identity50810 : scanCanonicalize (H12AffineFastState.compose env50810 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound50810 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env50811 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,88,16384,32768,82,16401,34849,1025,32769,17460,54276,21604,54311,89,65,23589,5188,17492,23637,1024,1,84,0,49185,512]

theorem envBound50811 : H12AffineFastState.Bounded env50811 := by
  intro p hp
  have h : env50811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50810_50811 : H12AffineEnvironment.transform 12 88 env50810 = env50811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env50810 == env50811) = true)

theorem identity50811 : scanCanonicalize (H12AffineFastState.compose env50811 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound50811 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env50812 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,88,16384,0,82,16401,2081,1025,1,17460,21508,21604,21543,89,65,23589,5188,17492,23637,1024,1,84,0,16417,512]

theorem envBound50812 : H12AffineFastState.Bounded env50812 := by
  intro p hp
  have h : env50812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50811_50812 : H12AffineEnvironment.transform 14 0 env50811 = env50812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env50811 == env50812) = true)

theorem identity50812 : scanCanonicalize (H12AffineFastState.compose env50812 (packedSelected [6,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound50812 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env50813 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,41,16384,0,35,16401,2081,1025,1,17460,21508,21525,21543,40,48,23589,5173,17445,23588,1024,1,37,0,16417,512]

theorem envBound50813 : H12AffineFastState.Bounded env50813 := by
  intro p hp
  have h : env50813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50812_50813 : H12AffineEnvironment.transform 5 49 env50812 = env50813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env50812 == env50813) = true)

theorem identity50813 : scanCanonicalize (H12AffineFastState.compose env50813 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound50813 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env50814 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,4096,41,5156,0,35,5173,2081,1025,1,4112,32,49,3,40,48,2049,5173,4097,2048,1024,1,37,0,5125,512]

theorem envBound50814 : H12AffineFastState.Bounded env50814 := by
  intro p hp
  have h : env50814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50813_50814 : H12AffineEnvironment.transform 13 5156 env50813 = env50814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env50813 == env50814) = true)

theorem identity50814 : scanCanonicalize (H12AffineFastState.compose env50814 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound50814 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env50815 : List Nat := [2,4,8,16,32,49,9,36,512,1024,2048,571,41,1567,0,35,1550,2081,1025,1,555,32,49,3,40,48,2049,1550,570,2048,1024,1,37,0,1598,512]

theorem envBound50815 : H12AffineFastState.Bounded env50815 := by
  intro p hp
  have h : env50815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50814_50815 : H12AffineEnvironment.transform 11 571 env50814 = env50815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env50814 == env50815) = true)

theorem identity50815 : scanCanonicalize (H12AffineFastState.compose env50815 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound50815 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env50816 : List Nat := [2,4,8,16,32,49,9,36,512,1024,1044,571,41,1567,0,35,1550,1077,1025,1,555,32,49,3,40,48,1045,1550,570,1044,1024,1,37,0,1598,512]

theorem envBound50816 : H12AffineFastState.Bounded env50816 := by
  intro p hp
  have h : env50816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50815_50816 : H12AffineEnvironment.transform 10 1044 env50815 = env50816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env50815 == env50816) = true)

theorem identity50816 : scanCanonicalize (H12AffineFastState.compose env50816 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound50816 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env50817 : List Nat := [2,4,8,16,32,49,9,36,40,1024,1044,19,41,1079,0,35,1062,1077,1025,1,3,32,49,3,40,48,1045,1062,18,1044,1024,1,37,0,1046,40]

theorem envBound50817 : H12AffineFastState.Bounded env50817 := by
  intro p hp
  have h : env50817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50816_50817 : H12AffineEnvironment.transform 8 40 env50816 = env50817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env50816 == env50817) = true)

def env50818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,8388608,8429903,8193,65,4229153,10560842,10507601,8464751,75102,14795782,257,2188650,2196550,513]

theorem envBound50818 : H12AffineFastState.Bounded env50818 := by
  intro p hp
  have h : env50818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50804_50818 : H12AffineEnvironment.transform 17 35189 env50804 = env50818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env50804 == env50818) = true)

def env50819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2172250,2118977,76159,75102,6407190,257,2188650,2196550,513]

theorem envBound50819 : H12AffineFastState.Bounded env50819 := by
  intro p hp
  have h : env50819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50818_50819 : H12AffineEnvironment.transform 22 16 env50818 = env50819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env50818 == env50819) = true)

theorem identity50819 : scanCanonicalize (H12AffineFastState.compose env50819 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound50819 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1025,29005,2097152,4194304,16,20499,8193,65,4225389,2172250,2118977,76159,75102,6370650,257,2188650,2192650,513]

theorem envBound50820 : H12AffineFastState.Bounded env50820 := by
  intro p hp
  have h : env50820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50819_50820 : H12AffineEnvironment.transform 14 29004 env50819 = env50820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env50819 == env50820) = true)

def env50821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1025,29005,5456,4194304,16,20499,8193,65,4225389,77834,16401,76159,75102,4268042,257,94266,90202,513]

theorem envBound50821 : H12AffineFastState.Bounded env50821 := by
  intro p hp
  have h : env50821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50820_50821 : H12AffineEnvironment.transform 20 5456 env50820 = env50821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env50820 == env50821) = true)

theorem identity50821 : scanCanonicalize (H12AffineFastState.compose env50821 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20529) := by decide +kernel

theorem selectedBound50821 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1025,29005,5456,20529,16,20499,8193,65,10588,77834,16401,76159,75102,94267,257,94266,90202,513]

theorem envBound50822 : H12AffineFastState.Bounded env50822 := by
  intro p hp
  have h : env50822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50821_50822 : H12AffineEnvironment.transform 21 20529 env50821 = env50822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20529 env50821 == env50822) = true)

theorem identity50822 : scanCanonicalize (H12AffineFastState.compose env50822 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound50822 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,8202,16401,30777,1025,29005,5456,20529,16,20499,8193,65,10588,4096,16401,2421,1364,20529,257,20528,16464,513]

theorem envBound50823 : H12AffineFastState.Bounded env50823 := by
  intro p hp
  have h : env50823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50822_50823 : H12AffineEnvironment.transform 15 8202 env50822 = env50823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env50822 == env50823) = true)

theorem identity50823 : scanCanonicalize (H12AffineFastState.compose env50823 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound50823 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12573,81,8202,12556,2340,1025,80,5456,8492,16,8462,8193,65,10588,4096,12556,2421,1364,8492,257,8493,12621,513]

theorem envBound50824 : H12AffineFastState.Bounded env50824 := by
  intro p hp
  have h : env50824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50823_50824 : H12AffineEnvironment.transform 13 12573 env50823 = env50824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env50823 == env50824) = true)

theorem identity50824 : scanCanonicalize (H12AffineFastState.compose env50824 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound50824 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env50825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4161,81,342,4176,2340,1025,80,5456,112,16,82,349,65,2048,4096,4176,2421,1364,112,257,113,4113,513]

theorem envBound50825 : H12AffineFastState.Bounded env50825 := by
  intro p hp
  have h : env50825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50824_50825 : H12AffineEnvironment.transform 12 348 env50824 = env50825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env50824 == env50825) = true)

theorem identity50825 : scanCanonicalize (H12AffineFastState.compose env50825 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound50825 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env50826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1060,348,1125,81,342,1140,2340,1025,80,372,112,16,82,349,65,2048,1060,1140,2421,1364,112,257,113,1077,513]

theorem envBound50826 : H12AffineFastState.Bounded env50826 := by
  intro p hp
  have h : env50826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50825_50826 : H12AffineEnvironment.transform 11 1060 env50825 = env50826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env50825 == env50826) = true)

def env50827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1025,29005,5457,4194304,16,20499,8193,65,4225389,77835,16400,76159,75102,4268043,257,94267,90203,513]

theorem envBound50827 : H12AffineFastState.Bounded env50827 := by
  intro p hp
  have h : env50827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50820_50827 : H12AffineEnvironment.transform 20 5457 env50820 = env50827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env50820 == env50827) = true)

theorem identity50827 : scanCanonicalize (H12AffineFastState.compose env50827 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound50827 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29004,65536,90139,30777,1025,29005,5457,32,16,20499,8193,65,31053,77835,16400,76159,75102,73771,257,94267,90203,513]

theorem envBound50828 : H12AffineFastState.Bounded env50828 := by
  intro p hp
  have h : env50828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50827_50828 : H12AffineEnvironment.transform 21 32 env50827 = env50828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env50827 == env50828) = true)

theorem identity50828 : scanCanonicalize (H12AffineFastState.compose env50828 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound50828 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,65536,77834,10280,1025,8540,5457,32,16,2,8193,65,10588,77835,4097,76159,75102,73771,257,73770,77898,513]

theorem envBound50829 : H12AffineFastState.Bounded env50829 := by
  intro p hp
  have h : env50829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50828_50829 : H12AffineEnvironment.transform 13 4113 env50828 = env50829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env50828 == env50829) = true)

theorem identity50829 : scanCanonicalize (H12AffineFastState.compose env50829 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(15+1) ^^^ 15486) := by decide +kernel

theorem selectedBound50829 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,15486,3188,10280,1025,8540,5457,32,16,2,8193,65,10588,3189,4097,5377,6432,7253,257,7252,3124,513]

theorem envBound50830 : H12AffineFastState.Bounded env50830 := by
  intro p hp
  have h : env50830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50829_50830 : H12AffineEnvironment.transform 15 15486 env50829 = env50830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 15486 env50829 == env50830) = true)

theorem identity50830 : scanCanonicalize (H12AffineFastState.compose env50830 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound50830 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env50831 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,8192,4113,8541,14363,2065,10280,100,8540,4404,32,16,2,8193,65,10588,2064,4097,4452,6432,6192,257,6193,2129,513]

theorem envBound50831 : H12AffineFastState.Bounded env50831 := by
  intro p hp
  have h : env50831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50830_50831 : H12AffineEnvironment.transform 9 101 env50830 = env50831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env50830 == env50831) = true)

theorem identity50831 : scanCanonicalize (H12AffineFastState.compose env50831 (packedSelected [1,2,4,5,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound50831 : packedSelected [1,2,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env50832 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,6429,4113,6208,262,2065,4405,100,6209,4404,32,16,2,6428,65,4161,2064,4097,4452,6432,6192,257,6193,2129,513]

theorem envBound50832 : H12AffineFastState.Bounded env50832 := by
  intro p hp
  have h : env50832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50831_50832 : H12AffineEnvironment.transform 12 6429 env50831 = env50832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env50831 == env50832) = true)

theorem identity50832 : scanCanonicalize (H12AffineFastState.compose env50832 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound50832 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env50833 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,4096,4200,4113,4405,262,356,4405,100,4404,4404,32,16,2,4201,65,4161,357,4097,4452,4181,4421,257,4420,292,513]

theorem envBound50833 : H12AffineFastState.Bounded env50833 := by
  intro p hp
  have h : env50833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50832_50833 : H12AffineEnvironment.transform 10 373 env50832 = env50833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env50832 == env50833) = true)

theorem identity50833 : scanCanonicalize (H12AffineFastState.compose env50833 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound50833 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env50834 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,16,120,1,293,262,356,293,100,292,292,32,16,2,121,65,81,357,17,372,69,341,257,340,292,513]

theorem envBound50834 : H12AffineFastState.Bounded env50834 := by
  intro p hp
  have h : env50834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50833_50834 : H12AffineEnvironment.transform 11 16 env50833 = env50834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50833 == env50834) = true)

theorem identity50834 : scanCanonicalize (H12AffineFastState.compose env50834 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound50834 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env50835 : List Nat := [2,4,8,16,32,64,9,256,65,101,373,16,120,1,293,262,356,293,100,292,292,32,16,2,121,65,81,357,17,372,69,341,257,340,292,64]

theorem envBound50835 : H12AffineFastState.Bounded env50835 := by
  intro p hp
  have h : env50835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50834_50835 : H12AffineEnvironment.transform 8 65 env50834 = env50835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env50834 == env50835) = true)

theorem identity50835 : scanCanonicalize (H12AffineFastState.compose env50835 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound50835 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env50836 : List Nat := [2,4,8,16,32,64,9,36,65,101,81,16,120,1,1,34,64,1,100,0,0,32,16,2,121,65,81,65,17,80,69,113,37,112,0,64]

theorem envBound50836 : H12AffineFastState.Bounded env50836 := by
  intro p hp
  have h : env50836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50835_50836 : H12AffineEnvironment.transform 7 36 env50835 = env50836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env50835 == env50836) = true)

def env50837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,2097152,4194304,17,41310,8193,65,4229153,2172251,2118976,76158,75102,6407191,257,2188650,2196550,513]

theorem envBound50837 : H12AffineFastState.Bounded env50837 := by
  intro p hp
  have h : env50837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50818_50837 : H12AffineEnvironment.transform 22 17 env50818 = env50837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env50818 == env50837) = true)

theorem identity50837 : scanCanonicalize (H12AffineFastState.compose env50837 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 46093) := by decide +kernel

theorem selectedBound50837 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env50838 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35189,1025,32769,46093,4194304,17,41310,8193,65,4229153,102742,57677,76158,75102,4288538,257,119143,77899,513]

theorem envBound50838 : H12AffineFastState.Bounded env50838 := by
  intro p hp
  have h : env50838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50837_50838 : H12AffineEnvironment.transform 20 46093 env50837 = env50838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 46093 env50837 == env50838) = true)

theorem identity50838 : scanCanonicalize (H12AffineFastState.compose env50838 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound50838 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,28699,4096,35189,1025,32769,46093,4194304,17,41310,8193,65,4229153,57677,57677,22885,21829,4194305,257,41340,16464,513]

theorem envBound50839 : H12AffineFastState.Bounded env50839 := by
  intro p hp
  have h : env50839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50838_50839 : H12AffineEnvironment.transform 15 28699 env50838 = env50839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env50838 == env50839) = true)

theorem identity50839 : scanCanonicalize (H12AffineFastState.compose env50839 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50839 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28699,4096,10280,1025,8540,5456,4194304,17,3,8193,65,4204924,16400,16400,22885,21829,4194305,257,33,16464,513]

theorem envBound50840 : H12AffineFastState.Bounded env50840 := by
  intro p hp
  have h : env50840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50839_50840 : H12AffineEnvironment.transform 14 8541 env50839 = env50840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50839 == env50840) = true)

theorem identity50840 : scanCanonicalize (H12AffineFastState.compose env50840 (packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS)) = affineNative (2^(21+1) ^^^ 27929) := by decide +kernel

theorem selectedBound50840 : packedSelected [0,1,2,3,4,5,6,7,8,9,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env50841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28699,4096,10280,1025,8540,5456,27929,17,3,8193,65,17509,16400,16400,22885,21829,27928,257,33,16464,513]

theorem envBound50841 : H12AffineFastState.Bounded env50841 := by
  intro p hp
  have h : env50841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50840_50841 : H12AffineEnvironment.transform 21 27929 env50840 = env50841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 27929 env50840 == env50841) = true)

theorem identity50841 : scanCanonicalize (H12AffineFastState.compose env50841 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(13+1) ^^^ 10508) := by decide +kernel

theorem selectedBound50841 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env50842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,10508,8541,6423,4096,10280,1025,8540,5456,1045,17,3,8193,65,11625,10524,10524,12393,15433,1044,257,33,10588,513]

theorem envBound50842 : H12AffineFastState.Bounded env50842 := by
  intro p hp
  have h : env50842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50841_50842 : H12AffineEnvironment.transform 13 10508 env50841 = env50842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10508 env50841 == env50842) = true)

theorem identity50842 : scanCanonicalize (H12AffineFastState.compose env50842 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound50842 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env50843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,3125,1124,6423,4096,3345,1025,1125,5456,1045,17,3,1336,65,2128,3109,3109,5456,6512,1044,257,33,3173,513]

theorem envBound50843 : H12AffineFastState.Bounded env50843 := by
  intro p hp
  have h : env50843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50842_50843 : H12AffineEnvironment.transform 12 1337 env50842 = env50843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env50842 == env50843) = true)

theorem identity50843 : scanCanonicalize (H12AffineFastState.compose env50843 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound50843 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env50844 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,1337,3125,1077,6423,4096,3345,1025,1076,5377,1045,17,3,1336,16,2049,3109,3109,5377,6433,1044,257,33,3124,513]

theorem envBound50844 : H12AffineFastState.Bounded env50844 := by
  intro p hp
  have h : env50844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50843_50844 : H12AffineEnvironment.transform 5 17 env50843 = env50844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env50843 == env50844) = true)

theorem identity50844 : scanCanonicalize (H12AffineFastState.compose env50844 (packedSelected [1,3,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound50844 : packedSelected [1,3,5,7] rootPS < 2^1333 := by decide +kernel

def env50845 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,1052,3125,1077,6194,4096,3124,1025,1076,5156,1045,17,3,1053,16,2049,3109,3109,5156,6148,1044,36,33,3124,513]

theorem envBound50845 : H12AffineFastState.Bounded env50845 := by
  intro p hp
  have h : env50845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50844_50845 : H12AffineEnvironment.transform 7 37 env50844 = env50845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env50844 == env50845) = true)

theorem identity50845 : scanCanonicalize (H12AffineFastState.compose env50845 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound50845 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50846 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,3109,1052,3125,1077,1047,3109,3124,1025,1076,2049,1045,17,3,1053,16,2049,3109,3109,2049,1057,1044,36,33,3124,513]

theorem envBound50846 : H12AffineFastState.Bounded env50846 := by
  intro p hp
  have h : env50846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50845_50846 : H12AffineEnvironment.transform 11 3109 env50845 = env50846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env50845 == env50846) = true)

theorem identity50846 : scanCanonicalize (H12AffineFastState.compose env50846 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound50846 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env50847 : List Nat := [2,4,8,16,32,17,9,37,512,1024,48,1045,1052,1029,1077,1047,1045,1028,1025,1076,49,1045,17,3,1053,16,49,1045,1045,49,1057,1044,36,33,1028,513]

theorem envBound50847 : H12AffineFastState.Bounded env50847 := by
  intro p hp
  have h : env50847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50846_50847 : H12AffineEnvironment.transform 10 48 env50846 = env50847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env50846 == env50847) = true)

theorem identity50847 : scanCanonicalize (H12AffineFastState.compose env50847 (packedSelected [0,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound50847 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env50848 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,40,49,1,35,33,48,53,0,49,33,17,3,41,16,49,33,33,49,21,32,36,33,48,513]

theorem envBound50848 : H12AffineFastState.Bounded env50848 := by
  intro p hp
  have h : env50848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50847_50848 : H12AffineEnvironment.transform 9 52 env50847 = env50848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env50847 == env50848) = true)

def leafEnv50848 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,40,49,1,35,33,48,53,0,49,33,17,3,20,41,1,16,49,33,33,49,21,32,36,33,5,34,48,513,1,48,0]

def active50848 : List Nat := [0,1,2,3,4,8]

def tree50848 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood50848 : H12WitnessSearch.Good tree50848 := H12GlobalWitnessIndex.good

theorem leafIdentity50848 : H12AffineFastState.composeSystem env50848 rootObs = leafEnv50848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env50848 rootObs == leafEnv50848) = true)

theorem terminalChecked50848 : H12PackedTerminal.terminalCheckFast leafEnv50848 active50848 tree50848 = true := by decide +kernel

def env50849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374096,4294967296,525568,4308116845,27337992,25733062]

theorem envBound50849 : H12AffineFastState.Bounded env50849 := by
  intro p hp
  have h : env50849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44618_50849 : H12AffineEnvironment.transform 28 77616401 env44618 = env50849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616401 env44618 == env50849) = true)

def env50850 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,1073741824,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound50850 : H12AffineFastState.Bounded env50850 := by
  intro p hp
  have h : env50850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50849_50850 : H12AffineEnvironment.transform 31 145662400 env50849 = env50850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env50849 == env50850) = true)

def env50851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616401,155254784,92374096,145662400,525568,140903597,27337992,25733062]

theorem envBound50851 : H12AffineFastState.Bounded env50851 := by
  intro p hp
  have h : env50851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50850_50851 : H12AffineEnvironment.transform 29 155254784 env50850 = env50851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env50850 == env50851) = true)

def env50852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507601,155254784,25265168,145662400,525568,140903597,27337992,25733062]

theorem envBound50852 : H12AffineFastState.Bounded env50852 := by
  intro p hp
  have h : env50852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50851_50852 : H12AffineEnvironment.transform 25 64 env50851 = env50852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env50851 == env50852) = true)

def env50853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507601,9356288,25265168,23160256,525568,27902125,27337992,25733062]

theorem envBound50853 : H12AffineFastState.Bounded env50853 := by
  intro p hp
  have h : env50853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50852_50853 : H12AffineEnvironment.transform 26 30393344 env50852 = env50853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env50852 == env50853) = true)

def env50854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160256,256,27378861,27337992,25207750]

theorem envBound50854 : H12AffineFastState.Bounded env50854 := by
  intro p hp
  have h : env50854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50853_50854 : H12AffineEnvironment.transform 18 1024 env50853 = env50854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env50853 == env50854) = true)

theorem identity50854 : scanCanonicalize (H12AffineFastState.compose env50854 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2213007) := by decide +kernel

theorem selectedBound50854 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env50855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2213007,16777216,8328,64,23463055,18973837,102878,2557071,18890911,23160256,256,16777250,16834951,18966345]

theorem envBound50855 : H12AffineFastState.Bounded env50855 := by
  intro p hp
  have h : env50855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50854_50855 : H12AffineEnvironment.transform 22 2213007 env50854 = env50855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2213007 env50854 == env50855) = true)

def env50856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2411540,2213007,16777216,8328,64,16959643,18973837,102878,2557071,18890911,17148372,256,16777250,16834951,18966345]

theorem envBound50856 : H12AffineFastState.Bounded env50856 := by
  intro p hp
  have h : env50856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50855_50856 : H12AffineEnvironment.transform 21 2411540 env50855 = env50856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2411540 env50855 == env50856) = true)

def env50857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318548,120015,16777216,8328,64,16959643,16880845,102878,464079,16797919,17148372,256,16777250,16834951,16873225]

theorem envBound50857 : H12AffineFastState.Bounded env50857 := by
  intro p hp
  have h : env50857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50856_50857 : H12AffineEnvironment.transform 20 4160 env50856 = env50857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env50856 == env50857) = true)

theorem identity50857 : scanCanonicalize (H12AffineFastState.compose env50857 (packedSelected [21] rootPS)) = affineNative (2^(23+1) ^^^ 95496) := by decide +kernel

theorem selectedBound50857 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env50858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318548,120015,95496,8328,64,245139,57797,102878,464079,75223,318684,256,95530,103567,513]

theorem envBound50858 : H12AffineFastState.Bounded env50858 := by
  intro p hp
  have h : env50858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50857_50858 : H12AffineEnvironment.transform 23 95496 env50857 = env50858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env50857 == env50858) = true)

def env50859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318548,119879,95496,8192,64,245019,57677,102742,463943,75103,318548,256,95530,103431,513]

theorem envBound50859 : H12AffineFastState.Bounded env50859 := by
  intro p hp
  have h : env50859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50858_50859 : H12AffineEnvironment.transform 6 8 env50858 = env50859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50858 == env50859) = true)

theorem identity50859 : scanCanonicalize (H12AffineFastState.compose env50859 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound50859 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env50860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,262144,1024,32769,4160,318548,119879,95496,8192,64,56576,57677,102742,291932,75103,318548,256,95530,103431,513]

theorem envBound50860 : H12AffineFastState.Bounded env50860 := by
  intro p hp
  have h : env50860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50859_50860 : H12AffineEnvironment.transform 16 90139 env50859 = env50860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env50859 == env50860) = true)

def env50861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,4160,62588,119879,95496,8192,64,56576,57677,102742,23668,75103,62588,256,95530,103431,513]

theorem envBound50861 : H12AffineFastState.Bounded env50861 := by
  intro p hp
  have h : env50861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50860_50861 : H12AffineEnvironment.transform 17 10280 env50860 = env50861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50860 == env50861) = true)

theorem identity50861 : scanCanonicalize (H12AffineFastState.compose env50861 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound50861 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10280,1024,32769,4160,62588,16,41311,8192,64,56576,57677,17665,23668,61704,62588,256,41341,16464,513]

theorem envBound50862 : H12AffineFastState.Bounded env50862 := by
  intro p hp
  have h : env50862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50861_50862 : H12AffineEnvironment.transform 15 54359 env50861 = env50862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env50861 == env50862) = true)

theorem identity50862 : scanCanonicalize (H12AffineFastState.compose env50862 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7284) := by decide +kernel

theorem selectedBound50862 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7284,32768,34851,46156,10280,1024,32769,4160,43016,16,41311,8192,64,33140,48441,6517,0,44412,43016,256,41341,7204,513]

theorem envBound50863 : H12AffineFastState.Bounded env50863 := by
  intro p hp
  have h : env50863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50862_50863 : H12AffineEnvironment.transform 13 7284 env50862 = env50863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7284 env50862 == env50863) = true)

theorem identity50863 : scanCanonicalize (H12AffineFastState.compose env50863 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50863 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7284,8541,10622,5393,10280,1024,8540,4160,2389,16,2,8192,64,8233,7268,6517,0,3105,2389,256,32,7204,513]

theorem envBound50864 : H12AffineFastState.Bounded env50864 := by
  intro p hp
  have h : env50864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50863_50864 : H12AffineEnvironment.transform 14 8541 env50863 = env50864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50863 == env50864) = true)

theorem identity50864 : scanCanonicalize (H12AffineFastState.compose env50864 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound50864 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50865 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,6501,8541,10622,4096,10280,273,8540,4160,2389,16,2,8192,64,8233,6517,6517,0,2352,2389,256,32,6453,513]

theorem envBound50865 : H12AffineFastState.Bounded env50865 := by
  intro p hp
  have h : env50865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50864_50865 : H12AffineEnvironment.transform 9 273 env50864 = env50865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env50864 == env50865) = true)

theorem identity50865 : scanCanonicalize (H12AffineFastState.compose env50865 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound50865 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env50866 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,121,6501,292,2311,4096,2129,273,293,4160,2389,16,2,121,64,80,6517,6517,0,2352,2389,256,32,6453,513]

theorem envBound50866 : H12AffineFastState.Bounded env50866 := by
  intro p hp
  have h : env50866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50865_50866 : H12AffineEnvironment.transform 12 121 env50865 = env50866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env50865 == env50866) = true)

theorem identity50866 : scanCanonicalize (H12AffineFastState.compose env50866 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound50866 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env50867 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,2112,121,293,292,2311,2112,2129,273,293,2048,2389,16,2,121,64,80,309,309,0,2352,2389,256,32,373,513]

theorem envBound50867 : H12AffineFastState.Bounded env50867 := by
  intro p hp
  have h : env50867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50866_50867 : H12AffineEnvironment.transform 11 2112 env50866 = env50867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env50866 == env50867) = true)

theorem identity50867 : scanCanonicalize (H12AffineFastState.compose env50867 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound50867 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env50868 : List Nat := [2,4,8,16,32,64,8,256,16,273,2048,2112,121,293,292,2311,2112,2129,273,293,2048,2389,16,2,121,64,80,309,309,0,2352,2389,256,32,373,17]

theorem envBound50868 : H12AffineFastState.Bounded env50868 := by
  intro p hp
  have h : env50868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50867_50868 : H12AffineEnvironment.transform 8 16 env50867 = env50868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env50867 == env50868) = true)

theorem identity50868 : scanCanonicalize (H12AffineFastState.compose env50868 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound50868 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env50869 : List Nat := [2,4,8,16,32,64,8,256,16,273,17,81,121,293,292,278,81,64,273,293,17,324,16,2,121,64,80,309,309,0,289,324,256,32,373,17]

theorem envBound50869 : H12AffineFastState.Bounded env50869 := by
  intro p hp
  have h : env50869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50868_50869 : H12AffineEnvironment.transform 10 17 env50868 = env50869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env50868 == env50869) = true)

theorem identity50869 : scanCanonicalize (H12AffineFastState.compose env50869 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound50869 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env50870 : List Nat := [2,4,8,16,0,64,8,256,16,273,17,81,89,261,260,278,81,64,273,261,17,324,16,2,89,64,80,277,277,0,257,324,256,0,341,17]

theorem envBound50870 : H12AffineFastState.Bounded env50870 := by
  intro p hp
  have h : env50870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50869_50870 : H12AffineEnvironment.transform 4 0 env50869 = env50870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env50869 == env50870) = true)

theorem identity50870 : scanCanonicalize (H12AffineFastState.compose env50870 (packedSelected [0,1,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound50870 : packedSelected [0,1,2,7] rootPS < 2^1333 := by decide +kernel

def env50871 : List Nat := [2,4,8,16,0,64,8,68,16,85,17,81,89,65,64,82,81,64,85,65,17,0,16,2,89,64,80,81,81,0,69,0,68,0,17,17]

theorem envBound50871 : H12AffineFastState.Bounded env50871 := by
  intro p hp
  have h : env50871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50870_50871 : H12AffineEnvironment.transform 7 68 env50870 = env50871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env50870 == env50871) = true)

theorem identity50871 : scanCanonicalize (H12AffineFastState.compose env50871 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50872 : List Nat := [2,4,8,16,0,16,8,20,16,5,17,1,9,17,16,2,1,16,5,17,17,0,16,2,9,16,0,1,1,0,21,0,20,0,17,17]

theorem envBound50872 : H12AffineFastState.Bounded env50872 := by
  intro p hp
  have h : env50872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50871_50872 : H12AffineEnvironment.transform 5 16 env50871 = env50872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50871 == env50872) = true)

theorem identity50872 : scanCanonicalize (H12AffineFastState.compose env50872 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound50872 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50873 : List Nat := [2,4,8,1,0,1,8,5,1,5,0,1,9,0,1,2,1,1,5,0,0,0,1,2,9,1,0,1,1,0,4,0,5,0,0,0]

theorem envBound50873 : H12AffineFastState.Bounded env50873 := by
  intro p hp
  have h : env50873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50872_50873 : H12AffineEnvironment.transform 3 1 env50872 = env50873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env50872 == env50873) = true)

def env50874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10281,1024,32769,4160,62589,119879,95496,8192,64,56576,57677,102742,23669,75103,62589,256,95530,103431,513]

theorem envBound50874 : H12AffineFastState.Bounded env50874 := by
  intro p hp
  have h : env50874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50860_50874 : H12AffineEnvironment.transform 17 10281 env50860 = env50874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50860 == env50874) = true)

theorem identity50874 : scanCanonicalize (H12AffineFastState.compose env50874 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28699) := by decide +kernel

theorem selectedBound50874 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28699,4096,10281,1024,32769,4160,62589,42076,1299,8192,64,56576,57677,57677,23669,21828,62589,256,1329,58396,513]

theorem envBound50875 : H12AffineFastState.Bounded env50875 := by
  intro p hp
  have h : env50875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50874_50875 : H12AffineEnvironment.transform 15 28699 env50874 = env50875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28699 env50874 == env50875) = true)

theorem identity50875 : scanCanonicalize (H12AffineFastState.compose env50875 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50875 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28699,4096,10281,1024,8540,4160,21792,1281,1299,8192,64,31837,16400,16400,23669,21828,21792,256,1329,17729,513]

theorem envBound50876 : H12AffineFastState.Bounded env50876 := by
  intro p hp
  have h : env50876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50875_50876 : H12AffineEnvironment.transform 14 8541 env50875 = env50876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50875 == env50876) = true)

theorem identity50876 : scanCanonicalize (H12AffineFastState.compose env50876 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 10509) := by decide +kernel

theorem selectedBound50876 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env50877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10509,8541,6422,4096,10281,1024,8540,4160,15405,1281,1299,8192,64,5456,10525,10525,13688,15433,15405,256,1329,11340,513]

theorem envBound50877 : H12AffineFastState.Bounded env50877 := by
  intro p hp
  have h : env50877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50876_50877 : H12AffineEnvironment.transform 13 10509 env50876 = env50877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10509 env50876 == env50877) = true)

def env50878 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,318548,119878,95496,8193,64,245018,57676,102743,463942,75102,318549,256,95530,103430,513]

theorem envBound50878 : H12AffineFastState.Bounded env50878 := by
  intro p hp
  have h : env50878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50858_50878 : H12AffineEnvironment.transform 6 9 env50858 = env50878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50858 == env50878) = true)

def env50879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,62588,119878,95496,8193,64,245018,57676,102743,212078,75102,62589,256,95530,103430,513]

theorem envBound50879 : H12AffineFastState.Bounded env50879 := by
  intro p hp
  have h : env50879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50878_50879 : H12AffineEnvironment.transform 17 10280 env50878 = env50879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env50878 == env50879) = true)

theorem identity50879 : scanCanonicalize (H12AffineFastState.compose env50879 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound50879 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env50880 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1024,8541,4160,21792,95514,95496,8193,64,203846,16400,77835,212078,75102,21793,256,95530,79194,513]

theorem envBound50880 : H12AffineFastState.Bounded env50880 := by
  intro p hp
  have h : env50880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50879_50880 : H12AffineEnvironment.transform 14 8540 env50879 = env50880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env50879 == env50880) = true)

theorem identity50880 : scanCanonicalize (H12AffineFastState.compose env50880 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound50880 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env50881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8540,65536,131072,10280,1024,8541,4160,113,73803,73817,8193,64,203846,5441,77835,212078,75102,112,256,73851,79194,513]

theorem envBound50881 : H12AffineFastState.Bounded env50881 := by
  intro p hp
  have h : env50881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50880_50881 : H12AffineEnvironment.transform 13 5457 env50880 = env50881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env50880 == env50881) = true)

theorem identity50881 : scanCanonicalize (H12AffineFastState.compose env50881 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50881 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env50882 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,65536,131072,10280,1024,8461,4112,33,73755,73737,8193,16,203798,5393,77835,212030,75022,32,256,73771,79114,513]

theorem envBound50882 : H12AffineFastState.Bounded env50882 := by
  intro p hp
  have h : env50882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50881_50882 : H12AffineEnvironment.transform 5 16 env50881 = env50882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50881 == env50882) = true)

theorem identity50882 : scanCanonicalize (H12AffineFastState.compose env50882 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound50882 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env50883 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,65536,70679,10280,1024,8461,4112,33,73755,73737,8193,16,2049,5393,77835,10281,75022,32,256,73771,79114,513]

theorem envBound50883 : H12AffineFastState.Bounded env50883 := by
  intro p hp
  have h : env50883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50882_50883 : H12AffineEnvironment.transform 16 70679 env50882 = env50883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env50882 == env50883) = true)

theorem identity50883 : scanCanonicalize (H12AffineFastState.compose env50883 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound50883 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50884 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,8203,13340,10280,1024,8461,4112,33,16,2,8193,16,2049,5393,4096,10281,1285,32,256,32,5377,513]

theorem envBound50884 : H12AffineFastState.Bounded env50884 := by
  intro p hp
  have h : env50884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50883_50884 : H12AffineEnvironment.transform 15 8203 env50883 = env50884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env50883 == env50884) = true)

def env50885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,62589,119878,95496,8193,64,245018,57676,102743,212079,75102,62588,256,95530,103430,513]

theorem envBound50885 : H12AffineFastState.Bounded env50885 := by
  intro p hp
  have h : env50885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50878_50885 : H12AffineEnvironment.transform 17 10281 env50878 = env50885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env50878 == env50885) = true)

theorem identity50885 : scanCanonicalize (H12AffineFastState.compose env50885 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound50885 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1024,32769,4160,62589,16,41310,8193,64,158028,57676,17665,190521,61704,62588,256,41340,16464,513]

theorem envBound50886 : H12AffineFastState.Bounded env50886 := by
  intro p hp
  have h : env50886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50885_50886 : H12AffineEnvironment.transform 15 54358 env50885 = env50886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env50885 == env50886) = true)

theorem identity50886 : scanCanonicalize (H12AffineFastState.compose env50886 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound50886 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env50887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,46157,10281,1024,32769,4160,62589,16,41310,8193,64,56577,57676,17665,23668,61704,62588,256,41340,16464,513]

theorem envBound50887 : H12AffineFastState.Bounded env50887 := by
  intro p hp
  have h : env50887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50886_50887 : H12AffineEnvironment.transform 16 46157 env50886 = env50887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env50886 == env50887) = true)

theorem identity50887 : scanCanonicalize (H12AffineFastState.compose env50887 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound50887 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50888 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,28699,4096,10281,1024,9292,4160,20528,16,1299,8193,64,31052,17665,17665,23668,21829,20529,256,1329,16464,513]

theorem envBound50888 : H12AffineFastState.Bounded env50888 := by
  intro p hp
  have h : env50888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50887_50888 : H12AffineEnvironment.transform 14 9293 env50887 = env50888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env50887 == env50888) = true)

theorem identity50888 : scanCanonicalize (H12AffineFastState.compose env50888 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5212) := by decide +kernel

theorem selectedBound50888 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50889 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5212,16384,4113,17479,4096,7285,1024,4112,4160,20528,16,1299,5213,64,19728,17665,17665,23668,21829,20529,256,1329,16464,513]

theorem envBound50889 : H12AffineFastState.Bounded env50889 := by
  intro p hp
  have h : env50889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50888_50889 : H12AffineEnvironment.transform 12 5212 env50888 = env50889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5212 env50888 == env50889) = true)

theorem identity50889 : scanCanonicalize (H12AffineFastState.compose env50889 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound50889 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env50890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5212,5237,4113,4146,4096,7285,1024,4112,4160,1093,16,1299,5213,64,6501,4468,4468,2049,304,1092,256,1329,5157,513]

theorem envBound50890 : H12AffineFastState.Bounded env50890 := by
  intro p hp
  have h : env50890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50889_50890 : H12AffineEnvironment.transform 13 5237 env50889 = env50890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env50889 == env50890) = true)

theorem identity50890 : scanCanonicalize (H12AffineFastState.compose env50890 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound50890 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env50891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1313,381,340,1328,1299,1313,2388,1024,1329,1377,1093,16,1299,380,64,3140,1109,1109,2049,304,1092,256,1329,260,513]

theorem envBound50891 : H12AffineFastState.Bounded env50891 := by
  intro p hp
  have h : env50891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50890_50891 : H12AffineEnvironment.transform 11 1313 env50890 = env50891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env50890 == env50891) = true)

theorem identity50891 : scanCanonicalize (H12AffineFastState.compose env50891 (packedSelected [0,2,3,7,8,11,14,24] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound50891 : packedSelected [0,2,3,7,8,11,14,24] rootPS < 2^1333 := by decide +kernel

def env50892 : List Nat := [2,4,8,16,32,64,9,256,512,548,2048,773,381,340,788,823,773,2388,548,789,837,609,16,823,380,64,2656,625,625,2049,304,608,256,789,260,513]

theorem envBound50892 : H12AffineFastState.Bounded env50892 := by
  intro p hp
  have h : env50892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50891_50892 : H12AffineEnvironment.transform 9 548 env50891 = env50892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env50891 == env50892) = true)

theorem identity50892 : scanCanonicalize (H12AffineFastState.compose env50892 (packedSelected [0,1,2,3,6,7,8,11,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound50892 : packedSelected [0,1,2,3,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env50893 : List Nat := [2,4,8,16,32,16,9,256,512,548,2048,773,301,260,788,823,773,2308,548,789,789,561,16,823,300,16,2608,545,545,2049,304,560,256,789,260,513]

theorem envBound50893 : H12AffineFastState.Bounded env50893 := by
  intro p hp
  have h : env50893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50892_50893 : H12AffineEnvironment.transform 5 16 env50892 = env50893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env50892 == env50893) = true)

theorem identity50893 : scanCanonicalize (H12AffineFastState.compose env50893 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound50893 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50894 : List Nat := [2,4,8,16,32,16,9,4,512,548,2048,513,41,0,528,563,513,2048,548,529,529,561,16,563,40,16,2608,545,545,2049,52,560,4,529,0,513]

theorem envBound50894 : H12AffineFastState.Bounded env50894 := by
  intro p hp
  have h : env50894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50893_50894 : H12AffineEnvironment.transform 7 4 env50893 = env50894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env50893 == env50894) = true)

theorem identity50894 : scanCanonicalize (H12AffineFastState.compose env50894 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound50894 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50895 : List Nat := [2,4,8,16,32,16,9,4,512,548,49,513,41,0,528,563,513,49,548,529,529,561,16,563,40,16,513,545,545,48,52,560,4,529,0,513]

theorem envBound50895 : H12AffineFastState.Bounded env50895 := by
  intro p hp
  have h : env50895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50894_50895 : H12AffineEnvironment.transform 10 49 env50894 = env50895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env50894 == env50895) = true)

theorem identity50895 : scanCanonicalize (H12AffineFastState.compose env50895 (packedSelected [2,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound50895 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env50896 : List Nat := [2,4,8,16,32,16,9,4,17,53,49,16,41,0,1,34,16,49,53,0,0,32,16,34,40,16,16,48,48,48,52,33,4,0,0,16]

theorem envBound50896 : H12AffineFastState.Bounded env50896 := by
  intro p hp
  have h : env50896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50895_50896 : H12AffineEnvironment.transform 8 17 env50895 = env50896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env50895 == env50896) = true)

theorem identity50896 : scanCanonicalize (H12AffineFastState.compose env50896 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound50896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50897 : List Nat := [2,4,8,16,1,16,9,4,17,20,16,16,8,0,1,3,16,16,20,0,0,1,16,3,9,16,16,17,17,17,21,0,4,0,0,16]

theorem envBound50897 : H12AffineFastState.Bounded env50897 := by
  intro p hp
  have h : env50897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50896_50897 : H12AffineEnvironment.transform 4 1 env50896 = env50897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env50896 == env50897) = true)

theorem identity50897 : scanCanonicalize (H12AffineFastState.compose env50897 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50897 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50898 : List Nat := [2,4,8,0,1,0,9,4,1,4,0,0,8,0,1,3,0,0,4,0,0,1,0,3,9,0,0,1,1,1,5,0,4,0,0,0]

theorem envBound50898 : H12AffineFastState.Bounded env50898 := by
  intro p hp
  have h : env50898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50897_50898 : H12AffineEnvironment.transform 3 0 env50897 = env50898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50897 == env50898) = true)

def env50899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,318549,120014,16777216,8328,64,16959643,16880844,102878,464078,16797918,17148372,256,16777250,16834951,16873224]

theorem envBound50899 : H12AffineFastState.Bounded env50899 := by
  intro p hp
  have h : env50899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50856_50899 : H12AffineEnvironment.transform 20 4161 env50856 = env50899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env50856 == env50899) = true)

def env50900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,4161,62709,120014,16777216,8328,64,16959643,16880844,102878,212078,16797918,16875892,256,16777250,16834951,16873224]

theorem envBound50900 : H12AffineFastState.Bounded env50900 := by
  intro p hp
  have h : env50900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50899_50900 : H12AffineEnvironment.transform 17 10400 env50899 = env50900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env50899 == env50900) = true)

def env50901 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,62589,119878,16777216,8192,64,16959507,16880708,102742,212078,16797782,16875892,256,16777250,16834831,16873224]

theorem envBound50901 : H12AffineFastState.Bounded env50901 := by
  intro p hp
  have h : env50901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50900_50901 : H12AffineEnvironment.transform 6 8 env50900 = env50901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env50900 == env50901) = true)

theorem identity50901 : scanCanonicalize (H12AffineFastState.compose env50901 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound50901 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4161,62589,41293,16777216,8192,64,16959507,16834895,58461,149861,16797782,16839807,256,16777250,16834831,16777731]

theorem envBound50902 : H12AffineFastState.Bounded env50902 := by
  intro p hp
  have h : env50902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50901_50902 : H12AffineEnvironment.transform 15 29963 env50901 = env50902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env50901 == env50902) = true)

theorem identity50902 : scanCanonicalize (H12AffineFastState.compose env50902 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 136466) := by decide +kernel

theorem selectedBound50902 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env50903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,131072,10280,1024,32769,4161,62589,41293,136466,8192,64,56577,193629,58461,149861,148804,188781,256,136496,193565,136977]

theorem envBound50903 : H12AffineFastState.Bounded env50903 := by
  intro p hp
  have h : env50903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50902_50903 : H12AffineEnvironment.transform 23 136466 env50902 = env50903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 136466 env50902 == env50903) = true)

theorem identity50903 : scanCanonicalize (H12AffineFastState.compose env50903 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound50903 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env50904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,46157,10280,1024,32769,4161,62589,41293,41311,8192,64,56577,16400,58461,64808,61705,21792,256,41341,16464,41820]

theorem envBound50904 : H12AffineFastState.Bounded env50904 := by
  intro p hp
  have h : env50904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50903_50904 : H12AffineEnvironment.transform 16 46157 env50903 = env50904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env50903 == env50904) = true)

theorem identity50904 : scanCanonicalize (H12AffineFastState.compose env50904 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound50904 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env50905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,5392,10280,1024,8540,4161,21792,16,2,8192,64,31836,16400,17664,23669,20564,21792,256,32,16464,513]

theorem envBound50905 : H12AffineFastState.Bounded env50905 := by
  intro p hp
  have h : env50905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50904_50905 : H12AffineEnvironment.transform 14 8541 env50904 = env50905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env50904 == env50905) = true)

theorem identity50905 : scanCanonicalize (H12AffineFastState.compose env50905 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7285) := by decide +kernel

theorem selectedBound50905 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env50906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,7285,8541,10622,5392,10280,1024,8540,4161,2389,16,2,8192,64,8233,7269,6517,0,3105,2389,256,32,7205,513]

theorem envBound50906 : H12AffineFastState.Bounded env50906 := by
  intro p hp
  have h : env50906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50905_50906 : H12AffineEnvironment.transform 13 7285 env50905 = env50906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7285 env50905 == env50906) = true)

theorem identity50906 : scanCanonicalize (H12AffineFastState.compose env50906 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound50906 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env50907 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,6501,8541,10622,4096,10280,272,8540,4161,2389,16,2,8192,64,8233,6517,6517,0,2353,2389,256,32,6453,513]

theorem envBound50907 : H12AffineFastState.Bounded env50907 := by
  intro p hp
  have h : env50907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50906_50907 : H12AffineEnvironment.transform 9 272 env50906 = env50907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env50906 == env50907) = true)

theorem identity50907 : scanCanonicalize (H12AffineFastState.compose env50907 (packedSelected [1,2,3,5,6,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound50907 : packedSelected [1,2,3,5,6,8,15] rootPS < 2^1333 := by decide +kernel

def env50908 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,121,6501,292,2311,4096,2129,272,293,4161,2389,16,2,121,64,80,6517,6517,0,2353,2389,256,32,6453,513]

theorem envBound50908 : H12AffineFastState.Bounded env50908 := by
  intro p hp
  have h : env50908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50907_50908 : H12AffineEnvironment.transform 12 121 env50907 = env50908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env50907 == env50908) = true)

theorem identity50908 : scanCanonicalize (H12AffineFastState.compose env50908 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound50908 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env50909 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,16,121,2421,292,2311,16,2129,272,293,81,2389,16,2,121,64,80,2405,2405,0,2353,2389,256,32,2341,513]

theorem envBound50909 : H12AffineFastState.Bounded env50909 := by
  intro p hp
  have h : env50909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50908_50909 : H12AffineEnvironment.transform 11 16 env50908 = env50909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env50908 == env50909) = true)

theorem identity50909 : scanCanonicalize (H12AffineFastState.compose env50909 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound50909 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env50910 : List Nat := [2,4,8,16,32,1,8,256,512,272,2048,16,56,2356,292,2311,16,2064,272,293,16,2324,16,2,56,1,17,2340,2340,0,2353,2324,256,32,2341,513]

theorem envBound50910 : H12AffineFastState.Bounded env50910 := by
  intro p hp
  have h : env50910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50909_50910 : H12AffineEnvironment.transform 5 1 env50909 = env50910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env50909 == env50910) = true)

theorem identity50910 : scanCanonicalize (H12AffineFastState.compose env50910 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound50910 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env50911 : List Nat := [2,4,8,16,32,1,8,256,512,272,0,16,56,308,292,263,16,16,272,293,16,276,16,2,56,1,17,292,292,0,305,276,256,32,293,513]

theorem envBound50911 : H12AffineFastState.Bounded env50911 := by
  intro p hp
  have h : env50911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50910_50911 : H12AffineEnvironment.transform 10 0 env50910 = env50911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env50910 == env50911) = true)

theorem identity50911 : scanCanonicalize (H12AffineFastState.compose env50911 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound50911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env50912 : List Nat := [2,4,8,16,32,1,8,21,512,5,0,16,56,33,49,18,16,16,5,48,16,1,16,2,56,1,17,49,49,0,36,1,21,32,48,513]

theorem envBound50912 : H12AffineFastState.Bounded env50912 := by
  intro p hp
  have h : env50912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50911_50912 : H12AffineEnvironment.transform 7 21 env50911 = env50912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env50911 == env50912) = true)

theorem identity50912 : scanCanonicalize (H12AffineFastState.compose env50912 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound50912 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env50913 : List Nat := [2,4,8,0,32,1,8,5,512,5,0,0,40,33,33,2,0,0,5,32,0,1,0,2,40,1,1,33,33,0,36,1,5,32,32,513]

theorem envBound50913 : H12AffineFastState.Bounded env50913 := by
  intro p hp
  have h : env50913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50912_50913 : H12AffineEnvironment.transform 3 0 env50912 = env50913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env50912 == env50913) = true)

theorem identity50913 : scanCanonicalize (H12AffineFastState.compose env50913 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound50913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env50914 : List Nat := [2,4,8,0,32,1,8,5,1,5,0,0,40,33,33,2,0,0,5,32,0,1,0,2,40,1,1,33,33,0,36,1,5,32,32,0]

theorem envBound50914 : H12AffineFastState.Bounded env50914 := by
  intro p hp
  have h : env50914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50913_50914 : H12AffineEnvironment.transform 8 1 env50913 = env50914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env50913 == env50914) = true)

def env50915 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,62588,119879,16777216,8193,64,16959506,16880709,102743,212078,16797783,16875892,256,16777250,16834830,16873224]

theorem envBound50915 : H12AffineFastState.Bounded env50915 := by
  intro p hp
  have h : env50915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50900_50915 : H12AffineEnvironment.transform 6 9 env50900 = env50915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env50900 == env50915) = true)

theorem identity50915 : scanCanonicalize (H12AffineFastState.compose env50915 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound50915 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env50916 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10281,1024,32769,4161,62588,16,16777216,8193,64,16959506,16793618,17664,190521,16797783,16799011,256,16777250,16834830,16819039]

theorem envBound50916 : H12AffineFastState.Bounded env50916 := by
  intro p hp
  have h : env50916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50915_50916 : H12AffineEnvironment.transform 15 54359 env50915 = env50916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env50915 == env50916) = true)

theorem identity50916 : scanCanonicalize (H12AffineFastState.compose env50916 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound50916 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env50917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10281,1024,32769,4161,62588,16,16777216,8193,64,16809054,16793618,17664,23669,16797783,16799011,256,16777250,16834830,16819039]

theorem envBound50917 : H12AffineFastState.Bounded env50917 := by
  intro p hp
  have h : env50917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50916_50917 : H12AffineEnvironment.transform 16 46156 env50916 = env50917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env50916 == env50917) = true)

theorem identity50917 : scanCanonicalize (H12AffineFastState.compose env50917 (packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS)) = affineNative (2^(23+1) ^^^ 33143) := by decide +kernel

theorem selectedBound50917 : packedSelected [1,2,3,5,6,7,8,9,10,11,18,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env50918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46156,10281,1024,32769,4161,62588,16,33143,8193,64,64809,49509,17664,23669,53536,54356,256,33109,24697,8744]

theorem envBound50918 : H12AffineFastState.Bounded env50918 := by
  intro p hp
  have h : env50918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50917_50918 : H12AffineEnvironment.transform 23 33143 env50917 = env50918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 33143 env50917 == env50918) = true)

theorem identity50918 : scanCanonicalize (H12AffineFastState.compose env50918 (packedSelected [0,1,7,8,9,14,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 9292) := by decide +kernel

theorem selectedBound50918 : packedSelected [0,1,7,8,9,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env50919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9292,28699,4096,10281,1024,9293,4161,20528,16,9531,8193,64,22885,25897,17664,23669,30060,28696,256,9497,24697,8744]

theorem envBound50919 : H12AffineFastState.Bounded env50919 := by
  intro p hp
  have h : env50919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50918_50919 : H12AffineEnvironment.transform 14 9292 env50918 = env50919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9292 env50918 == env50919) = true)

theorem identity50919 : scanCanonicalize (H12AffineFastState.compose env50919 (packedSelected [2,3,4,8,9,12,15,16,19,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 13657) := by decide +kernel

theorem selectedBound50919 : packedSelected [2,3,4,8,9,12,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env50920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13657,9292,1346,4096,10281,1024,9293,4161,9577,16,9531,8193,64,11324,4208,12377,10540,53,1345,256,9497,5408,8744]

theorem envBound50920 : H12AffineFastState.Bounded env50920 := by
  intro p hp
  have h : env50920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50919_50920 : H12AffineEnvironment.transform 13 13657 env50919 = env50920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13657 env50919 == env50920) = true)

theorem identity50920 : scanCanonicalize (H12AffineFastState.compose env50920 (packedSelected [1,2,4,6,8,9,11,14,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound50920 : packedSelected [1,2,4,6,8,9,11,14,19,20,23] rootPS < 2^1333 := by decide +kernel

def env50921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5236,1377,1346,4096,2308,1024,1376,4161,1092,16,1046,300,64,3345,4208,4468,2049,53,1345,256,1076,5408,773]

theorem envBound50921 : H12AffineFastState.Bounded env50921 := by
  intro p hp
  have h : env50921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans50920_50921 : H12AffineEnvironment.transform 12 301 env50920 = env50921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env50920 == env50921) = true)

end H12CloudChart1