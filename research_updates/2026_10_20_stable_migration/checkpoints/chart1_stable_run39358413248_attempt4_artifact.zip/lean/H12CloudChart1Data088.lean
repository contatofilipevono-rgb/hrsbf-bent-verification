import H12CloudChart1Data087

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound22271 : H12AffineFastState.Bounded env22271 := by
  intro p hp
  have h : env22271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22193_22271 : H12AffineEnvironment.transform 23 95617 env22193 = env22271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95617 env22193 == env22271) = true)

def env22272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,4194304,8388608,73857,8328,64,13022593,79131,8491335,8819969,8430737,4292950,256,8462395,8492190,8487751]

theorem envBound22272 : H12AffineFastState.Bounded env22272 := by
  intro p hp
  have h : env22272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22271_22272 : H12AffineEnvironment.transform 13 5376 env22271 = env22272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22271 == env22272) = true)

def env22273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73857,8328,64,8828321,79131,8491335,8819969,8430737,98678,256,8462395,8492190,8487751]

theorem envBound22273 : H12AffineFastState.Bounded env22273 := by
  intro p hp
  have h : env22273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22272_22273 : H12AffineEnvironment.transform 21 32 env22272 = env22273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22272 == env22273) = true)

def env22274 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73737,8192,64,8828201,79131,8491335,8819969,8430617,98678,256,8462395,8492054,8487751]

theorem envBound22274 : H12AffineFastState.Bounded env22274 := by
  intro p hp
  have h : env22274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22273_22274 : H12AffineEnvironment.transform 6 8 env22273 = env22274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22273 == env22274) = true)

def env22275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,16,73737,8192,64,439609,79131,102743,431377,41993,98678,256,73771,103430,99159]

theorem envBound22275 : H12AffineFastState.Bounded env22275 := by
  intro p hp
  have h : env22275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22274_22275 : H12AffineEnvironment.transform 22 16 env22274 = env22275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22274 == env22275) = true)

theorem identity22275 : scanCanonicalize (H12AffineFastState.compose env22275 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound22275 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4161,32,16,41311,8192,64,439609,46157,4097,431377,41993,32,256,41341,5456,513]

theorem envBound22276 : H12AffineFastState.Bounded env22276 := by
  intro p hp
  have h : env22276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22275_22276 : H12AffineEnvironment.transform 15 33110 env22275 = env22276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env22275 == env22276) = true)

theorem identity22276 : scanCanonicalize (H12AffineFastState.compose env22276 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound22276 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env22277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,46156,262144,1024,32769,4161,32,16,41311,8192,64,262517,46157,4097,270685,41993,32,256,41341,5456,513]

theorem envBound22277 : H12AffineFastState.Bounded env22277 := by
  intro p hp
  have h : env22277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22276_22277 : H12AffineEnvironment.transform 16 46156 env22276 = env22277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env22276 == env22277) = true)

theorem identity22277 : scanCanonicalize (H12AffineFastState.compose env22277 (packedSelected [2,3,5,6,10,12,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound22277 : packedSelected [2,3,5,6,10,12,18,23,38] rootPS < 2^1333 := by decide +kernel

def env22278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,46156,35189,1024,32769,4161,32,16,41311,8192,64,34816,46157,4097,43048,41993,32,256,41341,5456,513]

theorem envBound22278 : H12AffineFastState.Bounded env22278 := by
  intro p hp
  have h : env22278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22277_22278 : H12AffineEnvironment.transform 17 35189 env22277 = env22278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env22277 == env22278) = true)

theorem identity22278 : scanCanonicalize (H12AffineFastState.compose env22278 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22278 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,342,13388,2421,1024,1,4161,32,16,8543,8192,64,2048,13389,4097,10280,9225,32,256,8573,5456,513]

theorem envBound22279 : H12AffineFastState.Bounded env22279 := by
  intro p hp
  have h : env22279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22278_22279 : H12AffineEnvironment.transform 14 0 env22278 = env22279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22278 == env22279) = true)

theorem identity22279 : scanCanonicalize (H12AffineFastState.compose env22279 (packedSelected [2,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22279 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env22280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,0,342,5392,2421,1024,1,4161,32,16,3,348,64,2048,5393,4097,2420,1365,32,256,33,5456,513]

theorem envBound22280 : H12AffineFastState.Bounded env22280 := by
  intro p hp
  have h : env22280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22279_22280 : H12AffineEnvironment.transform 12 348 env22279 = env22280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22279 == env22280) = true)

theorem identity22280 : scanCanonicalize (H12AffineFastState.compose env22280 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 868) := by decide +kernel

theorem selectedBound22280 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,868,348,1636,0,342,1652,2421,1024,1,805,32,16,3,348,64,2048,1653,869,2420,1365,32,256,33,1588,513]

theorem envBound22281 : H12AffineFastState.Bounded env22281 := by
  intro p hp
  have h : env22281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22280_22281 : H12AffineEnvironment.transform 11 868 env22280 = env22281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 868 env22280 == env22281) = true)

def env22282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,17,73737,8192,64,439608,79131,102742,431376,41992,98678,256,73770,103431,99158]

theorem envBound22282 : H12AffineFastState.Bounded env22282 := by
  intro p hp
  have h : env22282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22274_22282 : H12AffineEnvironment.transform 22 17 env22274 = env22282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env22274 == env22282) = true)

theorem identity22282 : scanCanonicalize (H12AffineFastState.compose env22282 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound22282 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22283 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,102679,32,17,73737,8192,64,203846,79131,102742,212078,41992,98678,256,73770,103431,99158]

theorem envBound22283 : H12AffineFastState.Bounded env22283 := by
  intro p hp
  have h : env22283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22282_22283 : H12AffineEnvironment.transform 17 108926 env22282 = env22283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env22282 == env22283) = true)

theorem identity22283 : scanCanonicalize (H12AffineFastState.compose env22283 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound22283 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env22284 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,46157,108926,1024,32769,102679,32,17,73737,8192,64,108555,79131,102742,100387,41992,98678,256,73770,103431,99158]

theorem envBound22284 : H12AffineFastState.Bounded env22284 := by
  intro p hp
  have h : env22284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22283_22284 : H12AffineEnvironment.transform 16 46157 env22283 = env22284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env22283 == env22284) = true)

theorem identity22284 : scanCanonicalize (H12AffineFastState.compose env22284 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22284 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env22285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8202,46157,35188,1024,32769,45341,32,17,3,8192,64,34817,5393,45404,43049,41992,41340,256,32,46093,41820]

theorem envBound22285 : H12AffineFastState.Bounded env22285 := by
  intro p hp
  have h : env22285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22284_22285 : H12AffineEnvironment.transform 15 8202 env22284 = env22285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22284 == env22285) = true)

theorem identity22285 : scanCanonicalize (H12AffineFastState.compose env22285 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22285 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,263,38208,35188,1024,32769,36880,32,17,3,269,64,34817,5393,36945,35108,34053,32881,256,32,38144,33361]

theorem envBound22286 : H12AffineFastState.Bounded env22286 := by
  intro p hp
  have h : env22286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22285_22286 : H12AffineEnvironment.transform 12 269 env22285 = env22286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22285 == env22286) = true)

theorem identity22286 : scanCanonicalize (H12AffineFastState.compose env22286 (packedSelected [0,2,7,12] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound22286 : packedSelected [0,2,7,12] rootPS < 2^1333 := by decide +kernel

def env22287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,1077,263,4469,3393,1024,1076,5157,32,17,3,269,64,3124,5393,5220,3345,304,1092,256,32,4405,1636]

theorem envBound22287 : H12AffineFastState.Bounded env22287 := by
  intro p hp
  have h : env22287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22286_22287 : H12AffineEnvironment.transform 14 1077 env22286 = env22287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env22286 == env22287) = true)

def env22288 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73736,8193,64,8828200,79131,8491335,8819969,8430616,98678,256,8462395,8492055,8487751]

theorem envBound22288 : H12AffineFastState.Bounded env22288 := by
  intro p hp
  have h : env22288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22273_22288 : H12AffineEnvironment.transform 6 9 env22273 = env22288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22273 == env22288) = true)

def env22289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,16,73736,8193,64,439608,79131,102743,431377,41992,98678,256,73771,103431,99159]

theorem envBound22289 : H12AffineFastState.Bounded env22289 := by
  intro p hp
  have h : env22289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22288_22289 : H12AffineEnvironment.transform 22 16 env22288 = env22289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22288 == env22289) = true)

theorem identity22289 : scanCanonicalize (H12AffineFastState.compose env22289 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22289 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,45340,32,16,3,8193,64,439608,5392,45404,431377,41992,41341,256,32,46092,41820]

theorem envBound22290 : H12AffineFastState.Bounded env22290 := by
  intro p hp
  have h : env22290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22289_22290 : H12AffineEnvironment.transform 15 8203 env22289 = env22290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22289 == env22290) = true)

theorem identity22290 : scanCanonicalize (H12AffineFastState.compose env22290 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound22290 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env22291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,46156,262144,1024,32769,45340,32,16,3,8193,64,262516,5392,45404,270685,41992,41341,256,32,46092,41820]

theorem envBound22291 : H12AffineFastState.Bounded env22291 := by
  intro p hp
  have h : env22291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22290_22291 : H12AffineEnvironment.transform 16 46156 env22290 = env22291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env22290 == env22291) = true)

theorem identity22291 : scanCanonicalize (H12AffineFastState.compose env22291 (packedSelected [11,18,23,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound22291 : packedSelected [11,18,23,32] rootPS < 2^1333 := by decide +kernel

def env22292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,46156,10281,1024,32769,45340,32,16,3,8193,64,10589,5392,45404,2420,41992,41341,256,32,46092,41820]

theorem envBound22292 : H12AffineFastState.Bounded env22292 := by
  intro p hp
  have h : env22292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22291_22292 : H12AffineEnvironment.transform 17 10281 env22291 = env22292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22291 == env22292) = true)

theorem identity22292 : scanCanonicalize (H12AffineFastState.compose env22292 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound22292 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env22293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,32768,114,37941,2128,1024,32769,37221,32,16,3,120,64,2340,5392,37157,2420,33905,33028,256,32,38005,33573]

theorem envBound22293 : H12AffineFastState.Bounded env22293 := by
  intro p hp
  have h : env22293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22292_22293 : H12AffineEnvironment.transform 12 121 env22292 = env22293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env22292 == env22293) = true)

theorem identity22293 : scanCanonicalize (H12AffineFastState.compose env22293 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22293 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env22294 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,32768,114,37941,2128,1024,32769,36880,32,16,3,120,64,2129,5221,36944,2049,33905,32881,117,32,38005,33360]

theorem envBound22294 : H12AffineFastState.Bounded env22294 := by
  intro p hp
  have h : env22294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22293_22294 : H12AffineEnvironment.transform 7 117 env22293 = env22294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22293 == env22294) = true)

theorem identity22294 : scanCanonicalize (H12AffineFastState.compose env22294 (packedSelected [1,2,3] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound22294 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22295 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5237,80,114,5221,2128,1024,81,4160,32,16,3,120,64,2129,5221,4096,2049,1057,33,117,32,5157,512]

theorem envBound22295 : H12AffineFastState.Bounded env22295 := by
  intro p hp
  have h : env22295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22294_22295 : H12AffineEnvironment.transform 14 80 env22294 = env22295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env22294 == env22295) = true)

theorem identity22295 : scanCanonicalize (H12AffineFastState.compose env22295 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22295 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22296 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,89,5205,80,82,5189,2128,1024,81,4160,0,16,3,88,64,2129,5189,4096,2049,1025,1,85,0,5125,512]

theorem envBound22296 : H12AffineFastState.Bounded env22296 := by
  intro p hp
  have h : env22296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22295_22296 : H12AffineEnvironment.transform 4 0 env22295 = env22296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22295 == env22296) = true)

theorem identity22296 : scanCanonicalize (H12AffineFastState.compose env22296 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22296 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22297 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5125,0,2,5141,2048,1024,1,4112,0,16,3,8,16,2049,5141,4096,2049,1025,1,5,0,5125,512]

theorem envBound22297 : H12AffineFastState.Bounded env22297 := by
  intro p hp
  have h : env22297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22296_22297 : H12AffineEnvironment.transform 5 16 env22296 = env22297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22296 == env22297) = true)

def env22298 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,17,73736,8193,64,439609,79131,102742,431376,41993,98678,256,73770,103430,99158]

theorem envBound22298 : H12AffineFastState.Bounded env22298 := by
  intro p hp
  have h : env22298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22288_22298 : H12AffineEnvironment.transform 22 17 env22288 = env22298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env22288 == env22298) = true)

theorem identity22298 : scanCanonicalize (H12AffineFastState.compose env22298 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound22298 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22299 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,102679,32,17,73736,8193,64,245019,79131,102742,236850,41993,98678,256,73770,103430,99158]

theorem envBound22299 : H12AffineFastState.Bounded env22299 := by
  intro p hp
  have h : env22299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22298_22299 : H12AffineEnvironment.transform 17 67618 env22298 = env22299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env22298 == env22299) = true)

theorem identity22299 : scanCanonicalize (H12AffineFastState.compose env22299 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound22299 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22300 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,79130,67618,1024,32769,102679,32,17,73736,8193,64,34817,79131,102742,43048,41993,98678,256,73770,103430,99158]

theorem envBound22300 : H12AffineFastState.Bounded env22300 := by
  intro p hp
  have h : env22300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22299_22300 : H12AffineEnvironment.transform 16 79130 env22299 = env22300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env22299 == env22300) = true)

theorem identity22300 : scanCanonicalize (H12AffineFastState.compose env22300 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound22300 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env22301 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8574,5220,10588,1024,32769,45161,32,17,374,8193,64,34817,5221,45096,43048,41993,40968,256,340,46456,41512]

theorem envBound22301 : H12AffineFastState.Bounded env22301 := by
  intro p hp
  have h : env22301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22300_22301 : H12AffineEnvironment.transform 15 8574 env22300 = env22301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env22300 == env22301) = true)

theorem identity22301 : scanCanonicalize (H12AffineFastState.compose env22301 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound22301 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env22302 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8233,8574,5220,10588,1024,8232,4160,32,17,374,8193,64,10280,5221,4097,2049,1056,33,256,340,5457,513]

theorem envBound22302 : H12AffineFastState.Bounded env22302 := by
  intro p hp
  have h : env22302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22301_22302 : H12AffineEnvironment.transform 14 8233 env22301 = env22302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env22301 == env22302) = true)

theorem identity22302 : scanCanonicalize (H12AffineFastState.compose env22302 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound22302 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22303 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,81,262,5220,2340,1024,80,4160,32,17,374,121,64,2128,5221,4097,2049,1056,33,256,340,5457,513]

theorem envBound22303 : H12AffineFastState.Bounded env22303 := by
  intro p hp
  have h : env22303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22302_22303 : H12AffineEnvironment.transform 12 120 env22302 = env22303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env22302 == env22303) = true)

theorem identity22303 : scanCanonicalize (H12AffineFastState.compose env22303 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound22303 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22304 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2357,120,3125,81,262,3409,2340,1024,80,2421,32,17,374,121,64,2128,3408,2356,2049,1056,33,256,340,3172,513]

theorem envBound22304 : H12AffineFastState.Bounded env22304 := by
  intro p hp
  have h : env22304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22303_22304 : H12AffineEnvironment.transform 11 2357 env22303 = env22304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env22303 == env22304) = true)

theorem identity22304 : scanCanonicalize (H12AffineFastState.compose env22304 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22304 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22305 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2113,120,3125,81,114,3109,2128,1024,80,2049,32,17,2,121,64,2128,3108,2112,2049,1056,33,116,32,3172,513]

theorem envBound22305 : H12AffineFastState.Bounded env22305 := by
  intro p hp
  have h : env22305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22304_22305 : H12AffineEnvironment.transform 7 116 env22304 = env22305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22304 == env22305) = true)

theorem identity22305 : scanCanonicalize (H12AffineFastState.compose env22305 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22305 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22306 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,2065,40,3125,1,34,3109,2048,1024,0,2049,32,17,2,41,16,2048,3108,2064,2049,1056,33,36,32,3124,513]

theorem envBound22306 : H12AffineFastState.Bounded env22306 := by
  intro p hp
  have h : env22306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22305_22306 : H12AffineEnvironment.transform 5 16 env22305 = env22306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22305 == env22306) = true)

theorem identity22306 : scanCanonicalize (H12AffineFastState.compose env22306 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound22306 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22307 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1077,1060,40,0,1,34,16,1077,1024,0,1076,32,17,2,41,16,1077,17,1061,1076,1056,33,36,32,1,513]

theorem envBound22307 : H12AffineFastState.Bounded env22307 := by
  intro p hp
  have h : env22307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22306_22307 : H12AffineEnvironment.transform 10 1077 env22306 = env22307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env22306 == env22307) = true)

theorem identity22307 : scanCanonicalize (H12AffineFastState.compose env22307 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22307 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22308 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,17,40,0,1,34,16,0,53,0,1,32,17,2,41,16,0,17,16,1,21,33,36,32,1,513]

theorem envBound22308 : H12AffineFastState.Bounded env22308 := by
  intro p hp
  have h : env22308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22307_22308 : H12AffineEnvironment.transform 9 53 env22307 = env22308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22307 == env22308) = true)

theorem identity22308 : scanCanonicalize (H12AffineFastState.compose env22308 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound22308 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22309 : List Nat := [2,4,8,16,32,16,9,36,33,53,0,17,40,0,1,34,16,0,53,0,1,32,17,2,41,16,0,17,16,1,21,33,36,32,1,32]

theorem envBound22309 : H12AffineFastState.Bounded env22309 := by
  intro p hp
  have h : env22309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22308_22309 : H12AffineEnvironment.transform 8 33 env22308 = env22309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env22308 == env22309) = true)

def env22310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,8388608,73857,8328,64,8828320,79131,8491335,8819969,8430737,98679,256,8462395,8492190,8487751]

theorem envBound22310 : H12AffineFastState.Bounded env22310 := by
  intro p hp
  have h : env22310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22272_22310 : H12AffineEnvironment.transform 21 33 env22272 = env22310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22272 == env22310) = true)

theorem identity22310 : scanCanonicalize (H12AffineFastState.compose env22310 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound22310 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,16,73857,8328,64,439728,79131,102743,431377,42113,98679,256,73771,103566,99159]

theorem envBound22311 : H12AffineFastState.Bounded env22311 := by
  intro p hp
  have h : env22311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22310_22311 : H12AffineEnvironment.transform 22 16 env22310 = env22311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22310 == env22311) = true)

def env22312 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,16,73737,8192,64,439608,79131,102743,431377,41993,98679,256,73771,103430,99159]

theorem envBound22312 : H12AffineFastState.Bounded env22312 := by
  intro p hp
  have h : env22312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22311_22312 : H12AffineEnvironment.transform 6 8 env22311 = env22312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22311 == env22312) = true)

theorem identity22312 : scanCanonicalize (H12AffineFastState.compose env22312 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound22312 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22313 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4161,33,16,41311,8192,64,439608,46157,4097,431377,41993,33,256,41341,5456,513]

theorem envBound22313 : H12AffineFastState.Bounded env22313 := by
  intro p hp
  have h : env22313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22312_22313 : H12AffineEnvironment.transform 15 33110 env22312 = env22313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env22312 == env22313) = true)

theorem identity22313 : scanCanonicalize (H12AffineFastState.compose env22313 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22313 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env22314 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33110,131072,262144,1024,32769,4161,33,16,32770,349,64,431205,38160,4097,431377,34132,33,256,32800,5456,513]

theorem envBound22314 : H12AffineFastState.Bounded env22314 := by
  intro p hp
  have h : env22314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22313_22314 : H12AffineEnvironment.transform 12 349 env22313 = env22314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22313 == env22314) = true)

theorem identity22314 : scanCanonicalize (H12AffineFastState.compose env22314 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound22314 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env22315 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33110,131072,2420,1024,32769,4161,33,16,32770,349,64,171281,38160,4097,171109,34132,33,256,32800,5456,513]

theorem envBound22315 : H12AffineFastState.Bounded env22315 := by
  intro p hp
  have h : env22315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22314_22315 : H12AffineEnvironment.transform 17 2420 env22314 = env22315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env22314 == env22315) = true)

theorem identity22315 : scanCanonicalize (H12AffineFastState.compose env22315 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound22315 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22316 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33110,38161,2420,1024,32769,4161,33,16,32770,349,64,2048,38160,4097,2420,34132,33,256,32800,5456,513]

theorem envBound22316 : H12AffineFastState.Bounded env22316 := by
  intro p hp
  have h : env22316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22315_22316 : H12AffineEnvironment.transform 16 38161 env22315 = env22316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env22315 == env22316) = true)

theorem identity22316 : scanCanonicalize (H12AffineFastState.compose env22316 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22316 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env22317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5393,2420,1024,1,4161,33,16,2,349,64,2048,5392,4097,2420,1364,33,256,32,5456,513]

theorem envBound22317 : H12AffineFastState.Bounded env22317 := by
  intro p hp
  have h : env22317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22316_22317 : H12AffineEnvironment.transform 14 0 env22316 = env22317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22316 == env22317) = true)

theorem identity22317 : scanCanonicalize (H12AffineFastState.compose env22317 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22317 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22318 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,40,5237,0,35,5220,2049,1024,1,4161,33,16,2,40,64,2048,5221,4097,2049,1057,33,117,32,5157,513]

theorem envBound22318 : H12AffineFastState.Bounded env22318 := by
  intro p hp
  have h : env22318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22317_22318 : H12AffineEnvironment.transform 7 117 env22317 = env22318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22317 == env22318) = true)

theorem identity22318 : scanCanonicalize (H12AffineFastState.compose env22318 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22318 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22319 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5156,0,35,5173,2049,1024,1,4112,33,16,2,40,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound22319 : H12AffineFastState.Bounded env22319 := by
  intro p hp
  have h : env22319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22318_22319 : H12AffineEnvironment.transform 5 17 env22318 = env22319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22318 == env22319) = true)

def env22320 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,16,73736,8193,64,439609,79131,102743,431377,41992,98679,256,73771,103431,99159]

theorem envBound22320 : H12AffineFastState.Bounded env22320 := by
  intro p hp
  have h : env22320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22311_22320 : H12AffineEnvironment.transform 6 9 env22311 = env22320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22311 == env22320) = true)

theorem identity22320 : scanCanonicalize (H12AffineFastState.compose env22320 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22320 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22321 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,45340,33,16,3,8193,64,439609,5392,45404,431377,41992,41340,256,32,46092,41820]

theorem envBound22321 : H12AffineFastState.Bounded env22321 := by
  intro p hp
  have h : env22321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22320_22321 : H12AffineEnvironment.transform 15 8203 env22320 = env22321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22320 == env22321) = true)

theorem identity22321 : scanCanonicalize (H12AffineFastState.compose env22321 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22321 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22322 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4161,33,16,3,8193,64,398436,5392,4097,406604,1365,33,256,32,5457,513]

theorem envBound22322 : H12AffineFastState.Bounded env22322 := by
  intro p hp
  have h : env22322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22321_22322 : H12AffineEnvironment.transform 14 8541 env22321 = env22322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22321 == env22322) = true)

theorem identity22322 : scanCanonicalize (H12AffineFastState.compose env22322 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound22322 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22323 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8203,131072,146792,1024,8540,4161,33,16,3,8193,64,10508,5392,4097,2340,1365,33,256,32,5457,513]

theorem envBound22323 : H12AffineFastState.Bounded env22323 := by
  intro p hp
  have h : env22323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22322_22323 : H12AffineEnvironment.transform 17 146792 env22322 = env22323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env22322 == env22323) = true)

theorem identity22323 : scanCanonicalize (H12AffineFastState.compose env22323 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22323 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22324 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4112,8541,8203,131072,145528,272,8540,4161,33,16,3,8193,64,10508,4096,4097,2340,69,33,256,32,4161,513]

theorem envBound22324 : H12AffineFastState.Bounded env22324 := by
  intro p hp
  have h : env22324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22323_22324 : H12AffineEnvironment.transform 9 272 env22323 = env22324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22323 == env22324) = true)

theorem identity22324 : scanCanonicalize (H12AffineFastState.compose env22324 (packedSelected [12,15] rootPS)) = affineNative (2^(16+1) ^^^ 12408) := by decide +kernel

theorem selectedBound22324 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env22325 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4112,8541,8203,12408,2048,272,8540,4161,33,16,3,8193,64,10508,4096,4097,2340,69,33,256,32,4161,513]

theorem envBound22325 : H12AffineFastState.Bounded env22325 := by
  intro p hp
  have h : env22325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22324_22325 : H12AffineEnvironment.transform 16 12408 env22324 = env22325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12408 env22324 == env22325) = true)

theorem identity22325 : scanCanonicalize (H12AffineFastState.compose env22325 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound22325 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env22326 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2404,8192,2420,8541,8203,10524,2048,272,8540,2341,33,16,3,8193,64,10508,2404,2405,2340,69,33,256,32,2341,513]

theorem envBound22326 : H12AffineFastState.Bounded env22326 := by
  intro p hp
  have h : env22326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22325_22326 : H12AffineEnvironment.transform 11 2404 env22325 = env22326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env22325 == env22326) = true)

theorem identity22326 : scanCanonicalize (H12AffineFastState.compose env22326 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22326 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env22327 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,2112,8192,2128,8313,8203,10296,2048,52,8312,2049,33,16,3,8193,64,10280,2112,2113,2048,69,33,36,32,2049,513]

theorem envBound22327 : H12AffineFastState.Bounded env22327 := by
  intro p hp
  have h : env22327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22326_22327 : H12AffineEnvironment.transform 7 36 env22326 = env22327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22326 == env22327) = true)

theorem identity22327 : scanCanonicalize (H12AffineFastState.compose env22327 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22327 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22328 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2064,8192,2048,8233,8203,10296,2048,52,8232,2049,33,16,3,8193,16,10280,2064,2065,2048,21,33,36,32,2049,513]

theorem envBound22328 : H12AffineFastState.Bounded env22328 := by
  intro p hp
  have h : env22328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22327_22328 : H12AffineEnvironment.transform 5 16 env22327 = env22328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22327 == env22328) = true)

theorem identity22328 : scanCanonicalize (H12AffineFastState.compose env22328 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 2073) := by decide +kernel

theorem selectedBound22328 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env22329 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,2064,2073,2048,2096,2066,33,2048,52,2097,2049,33,16,3,2072,16,49,2064,2065,2048,21,33,36,32,2049,513]

theorem envBound22329 : H12AffineFastState.Bounded env22329 := by
  intro p hp
  have h : env22329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22328_22329 : H12AffineEnvironment.transform 12 2073 env22328 = env22329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2073 env22328 == env22329) = true)

theorem identity22329 : scanCanonicalize (H12AffineFastState.compose env22329 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound22329 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22330 : List Nat := [2,4,8,16,32,16,9,36,512,52,17,1,8,17,33,3,33,17,52,32,16,33,16,3,9,16,49,1,0,17,21,33,36,32,16,513]

theorem envBound22330 : H12AffineFastState.Bounded env22330 := by
  intro p hp
  have h : env22330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22329_22330 : H12AffineEnvironment.transform 10 17 env22329 = env22330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env22329 == env22330) = true)

def env22331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73856,8328,64,13022593,79131,8491335,8819968,8430736,4292951,256,8462394,8492190,8487750]

theorem envBound22331 : H12AffineFastState.Bounded env22331 := by
  intro p hp
  have h : env22331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22271_22331 : H12AffineEnvironment.transform 13 5377 env22271 = env22331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22271 == env22331) = true)

def env22332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,8388608,73856,8328,64,8828321,79131,8491335,8819968,8430736,98679,256,8462394,8492190,8487750]

theorem envBound22332 : H12AffineFastState.Bounded env22332 := by
  intro p hp
  have h : env22332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22331_22332 : H12AffineEnvironment.transform 21 32 env22331 = env22332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env22331 == env22332) = true)

theorem identity22332 : scanCanonicalize (H12AffineFastState.compose env22332 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22332 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,8388608,73736,8192,64,8828201,79131,8491335,8819968,8430616,98679,256,8462394,8492054,8487750]

theorem envBound22333 : H12AffineFastState.Bounded env22333 := by
  intro p hp
  have h : env22333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22332_22333 : H12AffineEnvironment.transform 6 8 env22332 = env22333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22332 == env22333) = true)

def env22334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,16,73736,8192,64,439609,79131,102743,431376,41992,98679,256,73770,103430,99158]

theorem envBound22334 : H12AffineFastState.Bounded env22334 := by
  intro p hp
  have h : env22334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22333_22334 : H12AffineEnvironment.transform 22 16 env22333 = env22334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env22333 == env22334) = true)

theorem identity22334 : scanCanonicalize (H12AffineFastState.compose env22334 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound22334 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4161,32,16,41311,8192,64,439609,46156,4096,431376,41992,32,256,41341,5457,513]

theorem envBound22335 : H12AffineFastState.Bounded env22335 := by
  intro p hp
  have h : env22335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22334_22335 : H12AffineEnvironment.transform 15 33111 env22334 = env22335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env22334 == env22335) = true)

theorem identity22335 : scanCanonicalize (H12AffineFastState.compose env22335 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound22335 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env22336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,13389,262144,1024,32769,4161,32,16,41311,8192,64,295284,46156,4096,303453,41992,32,256,41341,5457,513]

theorem envBound22336 : H12AffineFastState.Bounded env22336 := by
  intro p hp
  have h : env22336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22335_22336 : H12AffineEnvironment.transform 16 13389 env22335 = env22336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env22335 == env22336) = true)

theorem identity22336 : scanCanonicalize (H12AffineFastState.compose env22336 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22336 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env22337 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,33111,5392,262144,1024,32769,4161,32,16,32770,349,64,295284,38161,4096,294912,34133,32,256,32800,5457,513]

theorem envBound22337 : H12AffineFastState.Bounded env22337 := by
  intro p hp
  have h : env22337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22336_22337 : H12AffineEnvironment.transform 12 349 env22336 = env22337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22336 == env22337) = true)

theorem identity22337 : scanCanonicalize (H12AffineFastState.compose env22337 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22337 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22338 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,342,5392,262144,1024,0,4161,32,16,3,349,64,262517,5392,4096,262145,1364,32,256,33,5457,513]

theorem envBound22338 : H12AffineFastState.Bounded env22338 := by
  intro p hp
  have h : env22338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22337_22338 : H12AffineEnvironment.transform 14 1 env22337 = env22338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22337 == env22338) = true)

theorem identity22338 : scanCanonicalize (H12AffineFastState.compose env22338 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22338 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22339 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,262,5392,262144,1024,0,4113,32,16,3,269,16,262437,5392,4096,262145,1284,32,256,33,5377,513]

theorem envBound22339 : H12AffineFastState.Bounded env22339 := by
  intro p hp
  have h : env22339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22338_22339 : H12AffineEnvironment.transform 5 16 env22338 = env22339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22338 == env22339) = true)

theorem identity22339 : scanCanonicalize (H12AffineFastState.compose env22339 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22339 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22340 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4113,1,262,4096,262144,272,0,4113,32,16,3,269,16,262437,4096,4096,262145,20,32,256,33,4113,513]

theorem envBound22340 : H12AffineFastState.Bounded env22340 := by
  intro p hp
  have h : env22340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22339_22340 : H12AffineEnvironment.transform 9 272 env22339 = env22340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22339 == env22340) = true)

theorem identity22340 : scanCanonicalize (H12AffineFastState.compose env22340 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound22340 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22341 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4113,1,262,4096,2048,272,0,4113,32,16,3,269,16,2341,4096,4096,2049,20,32,256,33,4113,513]

theorem envBound22341 : H12AffineFastState.Bounded env22341 := by
  intro p hp
  have h : env22341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22340_22341 : H12AffineEnvironment.transform 17 2048 env22340 = env22341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env22340 == env22341) = true)

theorem identity22341 : scanCanonicalize (H12AffineFastState.compose env22341 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound22341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22342 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,1,269,16,1,262,1,2048,272,0,16,32,16,3,269,16,2341,1,1,2049,20,32,256,33,16,513]

theorem envBound22342 : H12AffineFastState.Bounded env22342 := by
  intro p hp
  have h : env22342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22341_22342 : H12AffineEnvironment.transform 11 1 env22341 = env22342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env22341 == env22342) = true)

theorem identity22342 : scanCanonicalize (H12AffineFastState.compose env22342 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound22342 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22343 : List Nat := [2,4,8,16,32,16,8,256,512,272,277,1,269,16,1,262,1,277,272,0,16,32,16,3,269,16,48,1,1,276,20,32,256,33,16,513]

theorem envBound22343 : H12AffineFastState.Bounded env22343 := by
  intro p hp
  have h : env22343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22342_22343 : H12AffineEnvironment.transform 10 277 env22342 = env22343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env22342 == env22343) = true)

theorem identity22343 : scanCanonicalize (H12AffineFastState.compose env22343 (packedSelected [5] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound22343 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env22344 : List Nat := [2,4,8,16,32,16,8,53,512,37,32,1,56,16,1,51,1,32,37,0,16,32,16,3,56,16,48,1,1,33,20,32,53,33,16,513]

theorem envBound22344 : H12AffineFastState.Bounded env22344 := by
  intro p hp
  have h : env22344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22343_22344 : H12AffineEnvironment.transform 7 53 env22343 = env22344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env22343 == env22344) = true)

theorem identity22344 : scanCanonicalize (H12AffineFastState.compose env22344 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22344 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env22345 : List Nat := [2,4,8,16,17,16,8,4,512,20,17,1,9,16,1,2,1,17,20,0,16,17,16,3,9,16,1,1,1,16,20,17,4,16,16,513]

theorem envBound22345 : H12AffineFastState.Bounded env22345 := by
  intro p hp
  have h : env22345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22344_22345 : H12AffineEnvironment.transform 4 17 env22344 = env22345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22344 == env22345) = true)

theorem identity22345 : scanCanonicalize (H12AffineFastState.compose env22345 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22345 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22346 : List Nat := [2,4,8,0,1,0,8,4,512,4,1,1,9,0,1,2,1,1,4,0,0,1,0,3,9,0,1,1,1,0,4,1,4,0,0,513]

theorem envBound22346 : H12AffineFastState.Bounded env22346 := by
  intro p hp
  have h : env22346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22345_22346 : H12AffineEnvironment.transform 3 0 env22345 = env22346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22345 == env22346) = true)

def env22347 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,17,73736,8192,64,439608,79131,102742,431377,41993,98679,256,73771,103431,99159]

theorem envBound22347 : H12AffineFastState.Bounded env22347 := by
  intro p hp
  have h : env22347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22333_22347 : H12AffineEnvironment.transform 22 17 env22333 = env22347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env22333 == env22347) = true)

theorem identity22347 : scanCanonicalize (H12AffineFastState.compose env22347 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound22347 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1024,32769,102678,32,17,73736,8192,64,203847,79131,102742,212078,41993,98679,256,73771,103431,99159]

theorem envBound22348 : H12AffineFastState.Bounded env22348 := by
  intro p hp
  have h : env22348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22347_22348 : H12AffineEnvironment.transform 17 108927 env22347 = env22348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env22347 == env22348) = true)

theorem identity22348 : scanCanonicalize (H12AffineFastState.compose env22348 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound22348 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env22349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,46157,108927,1024,32769,102678,32,17,73736,8192,64,108554,79131,102742,100387,41993,98679,256,73771,103431,99159]

theorem envBound22349 : H12AffineFastState.Bounded env22349 := by
  intro p hp
  have h : env22349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22348_22349 : H12AffineEnvironment.transform 16 46157 env22348 = env22349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env22348 == env22349) = true)

theorem identity22349 : scanCanonicalize (H12AffineFastState.compose env22349 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound22349 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env22350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,81,65536,13340,76078,1024,80,69959,32,17,73736,8192,64,75867,79131,69895,67698,9304,65830,256,73771,70742,66310]

theorem envBound22350 : H12AffineFastState.Bounded env22350 := by
  intro p hp
  have h : env22350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22349_22350 : H12AffineEnvironment.transform 14 81 env22349 = env22350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env22349 == env22350) = true)

theorem identity22350 : scanCanonicalize (H12AffineFastState.compose env22350 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound22350 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env22351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,81,8282,13340,2420,1024,80,12573,32,17,82,8192,64,2049,5441,12637,10280,9304,8572,256,113,13324,9052]

theorem envBound22351 : H12AffineFastState.Bounded env22351 := by
  intro p hp
  have h : env22351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22350_22351 : H12AffineEnvironment.transform 15 8282 env22350 = env22351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env22350 == env22351) = true)

theorem identity22351 : scanCanonicalize (H12AffineFastState.compose env22351 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22351 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,343,5393,2420,1024,80,4112,32,17,82,269,64,2049,5441,4176,2341,1365,113,256,113,5377,593]

theorem envBound22352 : H12AffineFastState.Bounded env22352 := by
  intro p hp
  have h : env22352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22351_22352 : H12AffineEnvironment.transform 12 269 env22351 = env22352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22351 == env22352) = true)

theorem identity22352 : scanCanonicalize (H12AffineFastState.compose env22352 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound22352 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env22353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,4096,269,5377,81,343,5393,80,1024,80,4112,32,17,82,269,64,293,5441,4176,1,1365,113,256,113,5377,593]

theorem envBound22353 : H12AffineFastState.Bounded env22353 := by
  intro p hp
  have h : env22353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22352_22353 : H12AffineEnvironment.transform 10 292 env22352 = env22353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env22352 == env22353) = true)

theorem identity22353 : scanCanonicalize (H12AffineFastState.compose env22353 (packedSelected [1,2,3,4,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound22353 : packedSelected [1,2,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1060,269,293,81,343,309,80,1024,80,1076,32,17,82,269,64,293,357,1140,1,1365,113,256,113,293,593]

theorem envBound22354 : H12AffineFastState.Bounded env22354 := by
  intro p hp
  have h : env22354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22353_22354 : H12AffineEnvironment.transform 11 1060 env22353 = env22354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env22353 == env22354) = true)

theorem identity22354 : scanCanonicalize (H12AffineFastState.compose env22354 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22354 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env22355 : List Nat := [2,4,8,16,32,64,8,256,512,53,292,17,269,293,81,343,309,80,53,80,1,32,17,82,269,64,293,357,65,1,352,113,256,113,293,593]

theorem envBound22355 : H12AffineFastState.Bounded env22355 := by
  intro p hp
  have h : env22355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22354_22355 : H12AffineEnvironment.transform 9 53 env22354 = env22355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22354 == env22355) = true)

theorem identity22355 : scanCanonicalize (H12AffineFastState.compose env22355 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22355 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env22356 : List Nat := [2,4,8,16,32,64,8,116,512,53,80,17,121,81,81,35,65,80,53,80,1,32,17,82,121,64,81,17,65,1,20,113,116,113,81,593]

theorem envBound22356 : H12AffineFastState.Bounded env22356 := by
  intro p hp
  have h : env22356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22355_22356 : H12AffineEnvironment.transform 7 116 env22355 = env22356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22355 == env22356) = true)

theorem identity22356 : scanCanonicalize (H12AffineFastState.compose env22356 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound22356 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22357 : List Nat := [2,4,8,16,32,64,8,116,65,53,80,17,121,81,81,35,65,80,53,80,1,32,17,82,121,64,81,17,65,1,20,113,116,113,81,16]

theorem envBound22357 : H12AffineFastState.Bounded env22357 := by
  intro p hp
  have h : env22357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22356_22357 : H12AffineEnvironment.transform 8 65 env22356 = env22357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env22356 == env22357) = true)

theorem identity22357 : scanCanonicalize (H12AffineFastState.compose env22357 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22357 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22358 : List Nat := [2,4,8,16,32,16,8,36,17,53,0,17,41,1,1,35,17,0,53,0,1,32,17,2,41,16,1,17,17,1,20,33,36,33,1,16]

theorem envBound22358 : H12AffineFastState.Bounded env22358 := by
  intro p hp
  have h : env22358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22357_22358 : H12AffineEnvironment.transform 5 16 env22357 = env22358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22357 == env22358) = true)

theorem identity22358 : scanCanonicalize (H12AffineFastState.compose env22358 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound22358 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22359 : List Nat := [2,4,8,11,32,11,8,36,10,46,0,10,41,1,1,35,10,0,46,0,1,32,10,2,41,11,1,10,10,1,15,33,36,33,1,11]

theorem envBound22359 : H12AffineFastState.Bounded env22359 := by
  intro p hp
  have h : env22359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22358_22359 : H12AffineEnvironment.transform 3 11 env22358 = env22359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env22358 == env22359) = true)

def env22360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,8388608,73856,8328,64,8828320,79131,8491335,8819968,8430736,98678,256,8462394,8492190,8487750]

theorem envBound22360 : H12AffineFastState.Bounded env22360 := by
  intro p hp
  have h : env22360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22331_22360 : H12AffineEnvironment.transform 21 33 env22331 = env22360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env22331 == env22360) = true)

theorem identity22360 : scanCanonicalize (H12AffineFastState.compose env22360 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound22360 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,152,73856,8328,64,439608,79131,102879,431512,41992,98678,256,73890,103430,99294]

theorem envBound22361 : H12AffineFastState.Bounded env22361 := by
  intro p hp
  have h : env22361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22360_22361 : H12AffineEnvironment.transform 22 152 env22360 = env22361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env22360 == env22361) = true)

def env22362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,16,73736,8192,64,439608,79131,102743,431376,41992,98678,256,73770,103430,99158]

theorem envBound22362 : H12AffineFastState.Bounded env22362 := by
  intro p hp
  have h : env22362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22361_22362 : H12AffineEnvironment.transform 6 8 env22361 = env22362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22361 == env22362) = true)

theorem identity22362 : scanCanonicalize (H12AffineFastState.compose env22362 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound22362 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4161,33,16,41311,8192,64,439608,46156,4096,431376,41992,33,256,41341,5457,513]

theorem envBound22363 : H12AffineFastState.Bounded env22363 := by
  intro p hp
  have h : env22363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22362_22363 : H12AffineEnvironment.transform 15 33111 env22362 = env22363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env22362 == env22363) = true)

theorem identity22363 : scanCanonicalize (H12AffineFastState.compose env22363 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound22363 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env22364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4161,33,16,2,8192,64,398437,5393,4096,406605,1365,33,256,32,5457,513]

theorem envBound22364 : H12AffineFastState.Bounded env22364 := by
  intro p hp
  have h : env22364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22363_22364 : H12AffineEnvironment.transform 14 8541 env22363 = env22364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env22363 == env22364) = true)

def env22365 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,17,73737,8193,64,439608,79131,102742,431377,41992,98678,256,73771,103430,99159]

theorem envBound22365 : H12AffineFastState.Bounded env22365 := by
  intro p hp
  have h : env22365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22361_22365 : H12AffineEnvironment.transform 6 9 env22361 = env22365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22361 == env22365) = true)

theorem identity22365 : scanCanonicalize (H12AffineFastState.compose env22365 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound22365 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22366 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67619,1024,32769,102678,33,17,73737,8193,64,245019,79131,102742,236850,41992,98678,256,73771,103430,99159]

theorem envBound22366 : H12AffineFastState.Bounded env22366 := by
  intro p hp
  have h : env22366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22365_22366 : H12AffineEnvironment.transform 17 67619 env22365 = env22366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env22365 == env22366) = true)

theorem identity22366 : scanCanonicalize (H12AffineFastState.compose env22366 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound22366 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22367 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79131,67619,1024,32769,102678,33,17,73737,8193,64,34816,79131,102742,43049,41992,98678,256,73771,103430,99159]

theorem envBound22367 : H12AffineFastState.Bounded env22367 := by
  intro p hp
  have h : env22367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22366_22367 : H12AffineEnvironment.transform 16 79131 env22366 = env22367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env22366 == env22367) = true)

theorem identity22367 : scanCanonicalize (H12AffineFastState.compose env22367 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22367 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env22368 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,65536,78959,67619,1024,32769,102498,33,17,73737,8193,64,34816,78959,102434,43049,41992,98306,116,73771,103430,98851]

theorem envBound22368 : H12AffineFastState.Bounded env22368 := by
  intro p hp
  have h : env22368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22367_22368 : H12AffineEnvironment.transform 7 116 env22367 = env22368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22367 == env22368) = true)

def env22369 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound22369 : H12AffineFastState.Bounded env22369 := by
  intro p hp
  have h : env22369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22191_22369 : H12AffineEnvironment.transform 18 1025 env22191 = env22369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env22191 == env22369) = true)

theorem identity22369 : scanCanonicalize (H12AffineFastState.compose env22369 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626198) := by decide +kernel

theorem selectedBound22369 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22370 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626198,8328,64,6677655,8626202,10507600,8830976,2334854,12796246,257,254010,197022,2262865]

theorem envBound22370 : H12AffineFastState.Bounded env22370 := by
  intro p hp
  have h : env22370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22369_22370 : H12AffineEnvironment.transform 23 10626198 env22369 = env22370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626198 env22369 == env22370) = true)

def env22371 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156116,2114882,8328,64,6677655,115150,2241668,303572,2334854,4268162,257,254010,197022,2262865]

theorem envBound22371 : H12AffineFastState.Bounded env22371 := by
  intro p hp
  have h : env22371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22370_22371 : H12AffineEnvironment.transform 22 156116 env22370 = env22371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156116 env22370 == env22371) = true)

def env22372 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156116,2114882,8328,64,215367,115150,2241668,303572,2334854,2592082,257,254010,197022,2262865]

theorem envBound22372 : H12AffineFastState.Bounded env22372 := by
  intro p hp
  have h : env22372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22371_22372 : H12AffineEnvironment.transform 21 2534864 env22371 = env22372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env22371 == env22372) = true)

def env22373 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,21762,8328,64,215367,115150,140484,303572,241862,498962,257,254010,197022,169745]

theorem envBound22373 : H12AffineFastState.Bounded env22373 := by
  intro p hp
  have h : env22373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22372_22373 : H12AffineEnvironment.transform 20 4160 env22372 = env22373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22372 == env22373) = true)

theorem identity22373 : scanCanonicalize (H12AffineFastState.compose env22373 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound22373 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22374 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,4160,318549,17,21762,8328,64,75906,115150,17665,303572,119043,392407,257,98815,90203,63188]

theorem envBound22374 : H12AffineFastState.Bounded env22374 := by
  intro p hp
  have h : env22374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22373_22374 : H12AffineEnvironment.transform 16 25029 env22373 = env22374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env22373 == env22374) = true)

def env22375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4160,318549,17,21762,8192,64,75786,115014,17665,303452,119043,392287,257,98679,90203,63068]

theorem envBound22375 : H12AffineFastState.Bounded env22375 := by
  intro p hp
  have h : env22375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22374_22375 : H12AffineEnvironment.transform 6 8 env22374 = env22375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22374 == env22375) = true)

theorem identity22375 : scanCanonicalize (H12AffineFastState.compose env22375 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound22375 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,32041,1025,32769,4160,41340,17,21762,8192,64,75786,115014,17665,56437,119043,98678,257,98679,90203,63068]

theorem envBound22376 : H12AffineFastState.Bounded env22376 := by
  intro p hp
  have h : env22376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22375_22376 : H12AffineEnvironment.transform 17 32041 env22375 = env22376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env22375 == env22376) = true)

theorem identity22376 : scanCanonicalize (H12AffineFastState.compose env22376 (packedSelected [1,3,4,8,9,10,11,12,14,15,16,19,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound22376 : packedSelected [1,3,4,8,9,10,11,12,14,15,16,19,24,26,32] rootPS < 2^1333 := by decide +kernel

def env22377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,65536,24909,32041,1025,30073,4160,21508,17,21762,8192,64,75786,78910,17665,10509,74875,95246,257,95247,90203,804]

theorem envBound22377 : H12AffineFastState.Bounded env22377 := by
  intro p hp
  have h : env22377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22376_22377 : H12AffineEnvironment.transform 14 30072 env22376 = env22377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env22376 == env22377) = true)

theorem identity22377 : scanCanonicalize (H12AffineFastState.compose env22377 (packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound22377 : packedSelected [0,2,4,6,7,9,11,14,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env22378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30072,29962,24909,32041,1025,30073,4160,21508,17,21762,8192,64,23808,16692,17665,10509,20849,260,257,261,5457,804]

theorem envBound22378 : H12AffineFastState.Bounded env22378 := by
  intro p hp
  have h : env22378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22377_22378 : H12AffineEnvironment.transform 15 29962 env22377 = env22378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env22377 == env22378) = true)

def env22379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4160,318549,17,21762,8193,64,75787,115015,17665,303453,119043,392286,257,98678,90203,63069]

theorem envBound22379 : H12AffineFastState.Bounded env22379 := by
  intro p hp
  have h : env22379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22374_22379 : H12AffineEnvironment.transform 6 9 env22374 = env22379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22374 == env22379) = true)

theorem identity22379 : scanCanonicalize (H12AffineFastState.compose env22379 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound22379 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,56437,1025,32769,4160,32,17,21762,8193,64,75787,115015,17665,32040,119043,73771,257,98678,90203,63069]

theorem envBound22380 : H12AffineFastState.Bounded env22380 := by
  intro p hp
  have h : env22380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22379_22380 : H12AffineEnvironment.transform 17 56437 env22379 = env22380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env22379 == env22380) = true)

theorem identity22380 : scanCanonicalize (H12AffineFastState.compose env22380 (packedSelected [0,3,7,11,12,14,16,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22380 : packedSelected [0,3,7,11,12,14,16,20,24] rootPS < 2^1333 := by decide +kernel

def env22381 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,24860,56357,1025,32769,4112,32,17,21762,8193,16,75787,114967,17665,32040,119043,73771,257,98598,90123,62989]

theorem envBound22381 : H12AffineFastState.Bounded env22381 := by
  intro p hp
  have h : env22381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22380_22381 : H12AffineEnvironment.transform 5 16 env22380 = env22381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22380 == env22381) = true)

theorem identity22381 : scanCanonicalize (H12AffineFastState.compose env22381 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound22381 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env22382 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,65536,24860,2340,1025,21760,4112,32,17,21762,8193,16,75787,70678,17665,32040,66562,73771,257,87079,90123,8972]

theorem envBound22382 : H12AffineFastState.Bounded env22382 := by
  intro p hp
  have h : env22382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22381_22382 : H12AffineEnvironment.transform 14 21761 env22381 = env22382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22381 == env22382) = true)

theorem identity22382 : scanCanonicalize (H12AffineFastState.compose env22382 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound22382 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22383 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21761,29963,24860,2340,1025,21760,4112,32,17,21762,8193,16,23808,24861,17665,32040,28937,21792,257,8492,5376,8972]

theorem envBound22383 : H12AffineFastState.Bounded env22383 := by
  intro p hp
  have h : env22383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22382_22383 : H12AffineEnvironment.transform 15 29963 env22382 = env22383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env22382 == env22383) = true)

theorem identity22383 : scanCanonicalize (H12AffineFastState.compose env22383 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound22383 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22384 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,8460,262,5393,2340,1025,8461,4112,32,17,8463,8193,16,10509,5392,12556,2341,1284,8493,257,8492,5376,8972]

theorem envBound22384 : H12AffineFastState.Bounded env22384 := by
  intro p hp
  have h : env22384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22383_22384 : H12AffineEnvironment.transform 13 13325 env22383 = env22384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env22383 == env22384) = true)

theorem identity22384 : scanCanonicalize (H12AffineFastState.compose env22384 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22384 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env22385 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,8192,12344,8460,262,4388,2340,52,8461,4112,32,17,8463,8193,16,10509,4389,12556,2341,305,8493,257,8492,4405,8972]

theorem envBound22385 : H12AffineFastState.Bounded env22385 := by
  intro p hp
  have h : env22385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22384_22385 : H12AffineEnvironment.transform 9 53 env22384 = env22385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22384 == env22385) = true)

theorem identity22385 : scanCanonicalize (H12AffineFastState.compose env22385 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22385 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env22386 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8192,12344,8233,35,4097,2049,52,8232,4112,32,17,8234,8193,16,10280,4096,12329,2048,20,8200,36,8201,4112,8745]

theorem envBound22386 : H12AffineFastState.Bounded env22386 := by
  intro p hp
  have h : env22386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22385_22386 : H12AffineEnvironment.transform 7 37 env22385 = env22386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22385 == env22386) = true)

theorem identity22386 : scanCanonicalize (H12AffineFastState.compose env22386 (packedSelected [1,2,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22386 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env22387 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4112,1,35,4097,2049,52,0,4112,32,17,2,41,16,2048,4096,4097,2048,20,32,36,33,4112,513]

theorem envBound22387 : H12AffineFastState.Bounded env22387 := by
  intro p hp
  have h : env22387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22386_22387 : H12AffineEnvironment.transform 12 40 env22386 = env22387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22386 == env22387) = true)

theorem identity22387 : scanCanonicalize (H12AffineFastState.compose env22387 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound22387 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22388 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2048,40,2064,1,35,2049,2049,52,0,2064,32,17,2,41,16,2048,2048,2049,2048,20,32,36,33,2064,513]

theorem envBound22388 : H12AffineFastState.Bounded env22388 := by
  intro p hp
  have h : env22388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22387_22388 : H12AffineEnvironment.transform 11 2048 env22387 = env22388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env22387 == env22388) = true)

theorem identity22388 : scanCanonicalize (H12AffineFastState.compose env22388 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound22388 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22389 : List Nat := [2,4,8,16,27,16,9,30,512,14,2048,2048,19,2064,1,24,2049,2049,15,0,2064,27,17,2,18,16,2048,2048,2049,2048,20,27,31,26,2064,513]

theorem envBound22389 : H12AffineFastState.Bounded env22389 := by
  intro p hp
  have h : env22389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22388_22389 : H12AffineEnvironment.transform 4 27 env22388 = env22389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env22388 == env22389) = true)

theorem identity22389 : scanCanonicalize (H12AffineFastState.compose env22389 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound22389 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22390 : List Nat := [2,4,8,16,27,16,9,30,512,14,17,17,19,1,1,24,16,16,15,0,1,27,17,2,18,16,17,17,16,17,20,27,31,26,1,513]

theorem envBound22390 : H12AffineFastState.Bounded env22390 := by
  intro p hp
  have h : env22390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22389_22390 : H12AffineEnvironment.transform 10 17 env22389 = env22390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env22389 == env22390) = true)

theorem identity22390 : scanCanonicalize (H12AffineFastState.compose env22390 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22390 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22391 : List Nat := [2,4,8,1,10,1,9,15,512,14,0,0,2,1,1,9,1,1,15,0,1,10,0,2,3,1,0,0,1,0,5,10,14,11,1,513]

theorem envBound22391 : H12AffineFastState.Bounded env22391 := by
  intro p hp
  have h : env22391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22390_22391 : H12AffineEnvironment.transform 3 1 env22390 = env22391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22390 == env22391) = true)

def env22392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,21763,8328,64,215367,115150,140485,303572,241863,498963,257,254010,197022,169744]

theorem envBound22392 : H12AffineFastState.Bounded env22392 := by
  intro p hp
  have h : env22392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22372_22392 : H12AffineEnvironment.transform 20 4161 env22372 = env22392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22372 == env22392) = true)

theorem identity22392 : scanCanonicalize (H12AffineFastState.compose env22392 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound22392 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4161,411973,156116,21763,8328,64,215367,79130,140485,283904,214035,485831,257,201966,197022,156612]

theorem envBound22393 : H12AffineFastState.Bounded env22393 := by
  intro p hp
  have h : env22393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22392_22393 : H12AffineEnvironment.transform 14 29908 env22392 = env22393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env22392 == env22393) = true)

def env22394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4113,411925,156036,21763,8328,16,215319,79130,140437,283904,214035,485783,257,201918,197022,156564]

theorem envBound22394 : H12AffineFastState.Bounded env22394 := by
  intro p hp
  have h : env22394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22393_22394 : H12AffineEnvironment.transform 5 16 env22393 = env22394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22393 == env22394) = true)

theorem identity22394 : scanCanonicalize (H12AffineFastState.compose env22394 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound22394 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env22395 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,24860,262144,1025,29829,4113,272393,152,21763,8328,16,75787,79130,17801,283904,75023,329867,257,95650,90242,648]

theorem envBound22395 : H12AffineFastState.Bounded env22395 := by
  intro p hp
  have h : env22395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22394_22395 : H12AffineEnvironment.transform 16 24860 env22394 = env22395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env22394 == env22395) = true)

theorem identity22395 : scanCanonicalize (H12AffineFastState.compose env22395 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound22395 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env22396 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,29963,24860,262144,1025,29829,4113,272393,152,21763,8328,16,23808,16401,17801,283904,20484,294272,257,169,5513,648]

theorem envBound22396 : H12AffineFastState.Bounded env22396 := by
  intro p hp
  have h : env22396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22395_22396 : H12AffineEnvironment.transform 15 29963 env22395 = env22396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env22395 == env22396) = true)

theorem identity22396 : scanCanonicalize (H12AffineFastState.compose env22396 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound22396 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env22397 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,29963,24860,10281,1025,29829,4113,32,152,21763,8328,16,23808,16401,17801,32041,20484,21929,257,169,5513,648]

theorem envBound22397 : H12AffineFastState.Bounded env22397 := by
  intro p hp
  have h : env22397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22396_22397 : H12AffineEnvironment.transform 17 10281 env22396 = env22397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22396 == env22397) = true)

theorem identity22397 : scanCanonicalize (H12AffineFastState.compose env22397 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound22397 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env22398 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,0,399,5528,10281,1025,1,4113,32,152,8583,8328,16,10628,13461,12557,2477,9344,8493,257,169,5513,648]

theorem envBound22398 : H12AffineFastState.Bounded env22398 := by
  intro p hp
  have h : env22398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22397_22398 : H12AffineEnvironment.transform 13 13444 env22397 = env22398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env22397 == env22398) = true)

theorem identity22398 : scanCanonicalize (H12AffineFastState.compose env22398 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound22398 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22399 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5377,0,399,5528,2476,1025,1,4113,32,152,2,269,16,2049,5392,4232,2477,1285,168,257,169,5513,648]

theorem envBound22399 : H12AffineFastState.Bounded env22399 := by
  intro p hp
  have h : env22399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22398_22399 : H12AffineEnvironment.transform 12 389 env22398 = env22399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env22398 == env22399) = true)

theorem identity22399 : scanCanonicalize (H12AffineFastState.compose env22399 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound22399 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22400 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,300,5377,0,294,5425,2309,1025,1,4113,32,49,2,269,16,2049,5392,4129,2308,1285,1,257,0,5408,545]

theorem envBound22400 : H12AffineFastState.Bounded env22400 := by
  intro p hp
  have h : env22400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22399_22400 : H12AffineEnvironment.transform 6 41 env22399 = env22400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env22399 == env22400) = true)

theorem identity22400 : scanCanonicalize (H12AffineFastState.compose env22400 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22400 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22401 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,5377,0,263,5392,2309,1025,1,4113,1,16,2,269,16,2049,5392,4096,2308,1285,1,257,0,5377,512]

theorem envBound22401 : H12AffineFastState.Bounded env22401 := by
  intro p hp
  have h : env22401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22400_22401 : H12AffineEnvironment.transform 4 1 env22400 = env22401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22400 == env22401) = true)

theorem identity22401 : scanCanonicalize (H12AffineFastState.compose env22401 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22401 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22402 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,8,5124,0,2,5141,2048,1025,1,4113,1,16,2,8,16,2049,5141,4096,2049,1024,1,4,0,5124,512]

theorem envBound22402 : H12AffineFastState.Bounded env22402 := by
  intro p hp
  have h : env22402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22401_22402 : H12AffineEnvironment.transform 7 5 env22401 = env22402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22401 == env22402) = true)

def env22403 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4112,411924,156037,21763,8328,17,215318,79130,140436,283904,214035,485782,257,201919,197022,156565]

theorem envBound22403 : H12AffineFastState.Bounded env22403 := by
  intro p hp
  have h : env22403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22393_22403 : H12AffineEnvironment.transform 5 17 env22393 = env22403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22393 == env22403) = true)

theorem identity22403 : scanCanonicalize (H12AffineFastState.compose env22403 (packedSelected [1,3,12,17,24,28,41] rootPS)) = affineNative (2^(17+1) ^^^ 149812) := by decide +kernel

theorem selectedBound22403 : packedSelected [1,3,12,17,24,28,41] rootPS < 2^1333 := by decide +kernel

def env22404 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,149812,1025,29828,4112,32,156037,21763,8328,17,215318,79130,140436,138292,214035,73890,257,201919,197022,156565]

theorem envBound22404 : H12AffineFastState.Bounded env22404 := by
  intro p hp
  have h : env22404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22403_22404 : H12AffineEnvironment.transform 17 149812 env22403 = env22404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149812 env22403 == env22404) = true)

theorem identity22404 : scanCanonicalize (H12AffineFastState.compose env22404 (packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound22404 : packedSelected [0,3,4,5,7,9,12,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env22405 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,82199,67619,1025,29828,4112,32,73874,21763,8328,17,2049,79130,91523,89379,1284,73890,257,21928,16521,74370]

theorem envBound22405 : H12AffineFastState.Bounded env22405 := by
  intro p hp
  have h : env22405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22404_22405 : H12AffineEnvironment.transform 16 82199 env22404 = env22405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env22404 == env22405) = true)

theorem identity22405 : scanCanonicalize (H12AffineFastState.compose env22405 (packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound22405 : packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS < 2^1333 := by decide +kernel

def env22406 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21761,65536,82199,67619,1025,21760,4112,32,65814,21763,268,17,2049,70814,82951,89379,1284,65830,257,21928,16521,66310]

theorem envBound22406 : H12AffineFastState.Bounded env22406 := by
  intro p hp
  have h : env22406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22405_22406 : H12AffineEnvironment.transform 12 388 env22405 = env22406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env22405 == env22406) = true)

theorem identity22406 : scanCanonicalize (H12AffineFastState.compose env22406 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound22406 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env22407 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,16384,21761,21647,5528,23724,1025,21760,4112,32,21913,21763,268,17,2049,16401,4232,2476,1284,21929,257,21928,16521,22409]

theorem envBound22407 : H12AffineFastState.Bounded env22407 := by
  intro p hp
  have h : env22407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22406_22407 : H12AffineEnvironment.transform 15 21647 env22406 = env22407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env22406 == env22407) = true)

theorem identity22407 : scanCanonicalize (H12AffineFastState.compose env22407 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound22407 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env22408 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,16384,20925,20531,4388,22544,189,20924,4112,32,20773,20927,268,17,2049,16401,4232,2476,440,20757,257,20756,16521,21301]

theorem envBound22408 : H12AffineFastState.Bounded env22408 := by
  intro p hp
  have h : env22408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22407_22408 : H12AffineEnvironment.transform 9 188 env22407 = env22408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env22407 == env22408) = true)

theorem identity22408 : scanCanonicalize (H12AffineFastState.compose env22408 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound22408 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env22409 : List Nat := [2,4,8,16,32,17,128,256,512,188,2048,4096,388,4404,137,263,4388,2340,189,136,4112,32,17,139,268,17,2049,4389,4232,2476,440,33,257,32,4541,513]

theorem envBound22409 : H12AffineFastState.Bounded env22409 := by
  intro p hp
  have h : env22409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22408_22409 : H12AffineEnvironment.transform 13 4404 env22408 = env22409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env22408 == env22409) = true)

theorem identity22409 : scanCanonicalize (H12AffineFastState.compose env22409 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22409 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env22410 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,4096,269,4404,0,263,4388,2340,52,1,4112,32,17,2,268,17,2049,4389,4097,2341,305,33,257,32,4404,513]

theorem envBound22410 : H12AffineFastState.Bounded env22410 := by
  intro p hp
  have h : env22410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22409_22410 : H12AffineEnvironment.transform 6 9 env22409 = env22410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22409 == env22410) = true)

theorem identity22410 : scanCanonicalize (H12AffineFastState.compose env22410 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound22410 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22411 : List Nat := [2,4,8,16,32,17,9,256,512,53,2048,32,269,276,0,263,260,2340,52,1,48,32,17,2,268,17,2049,261,33,2341,305,33,257,32,276,513]

theorem envBound22411 : H12AffineFastState.Bounded env22411 := by
  intro p hp
  have h : env22411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22410_22411 : H12AffineEnvironment.transform 11 32 env22410 = env22411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env22410 == env22411) = true)

theorem identity22411 : scanCanonicalize (H12AffineFastState.compose env22411 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound22411 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22412 : List Nat := [2,4,8,16,32,17,9,256,293,53,2048,32,269,276,0,263,260,2340,52,1,48,32,17,2,268,17,2049,261,33,2341,305,33,257,32,276,292]

theorem envBound22412 : H12AffineFastState.Bounded env22412 := by
  intro p hp
  have h : env22412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22411_22412 : H12AffineEnvironment.transform 8 293 env22411 = env22412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env22411 == env22412) = true)

theorem identity22412 : scanCanonicalize (H12AffineFastState.compose env22412 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22412 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22413 : List Nat := [2,4,8,16,32,17,9,256,293,53,1,32,269,276,0,263,260,293,52,1,48,32,17,2,268,17,0,261,33,292,305,33,257,32,276,292]

theorem envBound22413 : H12AffineFastState.Bounded env22413 := by
  intro p hp
  have h : env22413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22412_22413 : H12AffineEnvironment.transform 10 1 env22412 = env22413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22412 == env22413) = true)

theorem identity22413 : scanCanonicalize (H12AffineFastState.compose env22413 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22413 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22414 : List Nat := [2,4,8,1,32,0,9,256,293,36,1,32,269,261,0,263,260,293,37,1,33,32,0,2,268,0,0,261,33,292,288,33,257,32,261,292]

theorem envBound22414 : H12AffineFastState.Bounded env22414 := by
  intro p hp
  have h : env22414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22413_22414 : H12AffineEnvironment.transform 3 1 env22413 = env22414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22413 == env22414) = true)

theorem identity22414 : scanCanonicalize (H12AffineFastState.compose env22414 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22414 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22415 : List Nat := [2,4,8,1,1,0,9,256,260,5,1,1,269,261,0,263,260,260,4,1,0,1,0,2,268,0,0,261,0,261,257,0,257,1,261,261]

theorem envBound22415 : H12AffineFastState.Bounded env22415 := by
  intro p hp
  have h : env22415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22414_22415 : H12AffineEnvironment.transform 4 1 env22414 = env22415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22414 == env22415) = true)

def env22416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156116,2114882,8328,64,215366,115150,2241668,303572,2334854,2592083,257,254010,197022,2262865]

theorem envBound22416 : H12AffineFastState.Bounded env22416 := by
  intro p hp
  have h : env22416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22371_22416 : H12AffineEnvironment.transform 21 2534865 env22371 = env22416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env22371 == env22416) = true)

def env22417 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,21762,8328,64,215366,115150,140484,303572,241862,498963,257,254010,197022,169745]

theorem envBound22417 : H12AffineFastState.Bounded env22417 := by
  intro p hp
  have h : env22417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22416_22417 : H12AffineEnvironment.transform 20 4160 env22416 = env22417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22416 == env22417) = true)

def env22418 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,169401,156116,21762,8328,64,215366,115150,140484,35324,241862,243003,257,254010,197022,169745]

theorem envBound22418 : H12AffineFastState.Bounded env22418 := by
  intro p hp
  have h : env22418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22417_22418 : H12AffineEnvironment.transform 17 10280 env22417 = env22418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22417 == env22418) = true)

def env22419 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4160,21929,41412,21762,8328,64,100694,115150,58580,35324,94422,95531,257,73770,115086,22273]

theorem envBound22419 : H12AffineFastState.Bounded env22419 := by
  intro p hp
  have h : env22419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22418_22419 : H12AffineEnvironment.transform 16 49168 env22418 = env22419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env22418 == env22419) = true)

theorem identity22419 : scanCanonicalize (H12AffineFastState.compose env22419 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound22419 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22420 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13508,10280,1025,29909,4160,21929,21776,21762,8328,64,97666,79130,4096,32040,94422,95531,257,73770,79194,22273]

theorem envBound22420 : H12AffineFastState.Bounded env22420 := by
  intro p hp
  have h : env22420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22419_22420 : H12AffineEnvironment.transform 14 29908 env22419 = env22420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env22419 == env22420) = true)

theorem identity22420 : scanCanonicalize (H12AffineFastState.compose env22420 (packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22420 : packedSelected [0,1,2,4,5,6,8,9,11,18,20,24,27] rootPS < 2^1333 := by decide +kernel

def env22421 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29908,65536,13508,10280,1025,29909,4160,21725,21604,21622,8328,64,97526,78958,4096,31836,94422,95327,117,73770,78894,22133]

theorem envBound22421 : H12AffineFastState.Bounded env22421 := by
  intro p hp
  have h : env22421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22420_22421 : H12AffineEnvironment.transform 7 116 env22420 = env22421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22420 == env22421) = true)

theorem identity22421 : scanCanonicalize (H12AffineFastState.compose env22421 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound22421 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env22422 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,29908,21591,13508,10280,1025,29909,4160,21725,21604,21622,8328,64,10401,24633,4096,31836,9345,8200,117,29821,24697,22133]

theorem envBound22422 : H12AffineFastState.Bounded env22422 := by
  intro p hp
  have h : env22422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22421_22422 : H12AffineEnvironment.transform 15 21591 env22421 = env22422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env22421 == env22422) = true)

theorem identity22422 : scanCanonicalize (H12AffineFastState.compose env22422 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound22422 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env22423 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,1101,16384,20633,21591,4233,3173,1025,20632,4160,21725,21604,21622,1221,64,3308,17524,4096,22545,204,1093,117,20528,17460,22133]

theorem envBound22423 : H12AffineFastState.Bounded env22423 := by
  intro p hp
  have h : env22423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22422_22423 : H12AffineEnvironment.transform 12 1101 env22422 = env22423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env22422 == env22423) = true)

theorem identity22423 : scanCanonicalize (H12AffineFastState.compose env22423 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22423 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env22424 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1101,16384,20496,21591,4096,3173,1025,20497,4160,21588,21604,21622,1100,64,3173,17524,4096,22545,69,1093,117,20528,17460,22133]

theorem envBound22424 : H12AffineFastState.Bounded env22424 := by
  intro p hp
  have h : env22424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22423_22424 : H12AffineEnvironment.transform 6 9 env22423 = env22424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22423 == env22424) = true)

theorem identity22424 : scanCanonicalize (H12AffineFastState.compose env22424 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound22424 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22425 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1101,5236,1124,35,4096,3173,1025,1125,4160,32,16,2,1100,64,3173,4096,4096,3173,69,1093,117,1092,4160,513]

theorem envBound22425 : H12AffineFastState.Bounded env22425 := by
  intro p hp
  have h : env22425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22424_22425 : H12AffineEnvironment.transform 13 5236 env22424 = env22425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env22424 == env22425) = true)

theorem identity22425 : scanCanonicalize (H12AffineFastState.compose env22425 (packedSelected [0,1,2,3,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3701) := by decide +kernel

theorem selectedBound22425 : packedSelected [0,1,2,3,4,6,7] rootPS < 2^1333 := by decide +kernel

def env22426 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3701,1101,2561,1124,35,3701,3173,1025,1125,3637,32,16,2,1100,64,3173,3701,3701,3173,69,1093,117,1092,3637,513]

theorem envBound22426 : H12AffineFastState.Bounded env22426 := by
  intro p hp
  have h : env22426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22425_22426 : H12AffineEnvironment.transform 11 3701 env22425 = env22426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3701 env22425 == env22426) = true)

theorem identity22426 : scanCanonicalize (H12AffineFastState.compose env22426 (packedSelected [1,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 590) := by decide +kernel

theorem selectedBound22426 : packedSelected [1,3,5,6] rootPS < 2^1333 := by decide +kernel

def env22427 : List Nat := [2,4,8,16,32,64,9,116,512,590,2048,2107,515,2561,554,35,2107,2603,591,555,2171,32,16,2,514,64,2603,2107,2107,2603,69,523,117,522,2171,513]

theorem envBound22427 : H12AffineFastState.Bounded env22427 := by
  intro p hp
  have h : env22427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22426_22427 : H12AffineEnvironment.transform 9 590 env22426 = env22427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 590 env22426 == env22427) = true)

theorem identity22427 : scanCanonicalize (H12AffineFastState.compose env22427 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound22427 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env22428 : List Nat := [2,4,8,16,32,59,9,15,512,565,2048,2107,515,2561,554,35,2107,2603,564,555,2048,32,16,2,514,59,2603,2107,2107,2603,62,523,14,522,2048,513]

theorem envBound22428 : H12AffineFastState.Bounded env22428 := by
  intro p hp
  have h : env22428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22427_22428 : H12AffineEnvironment.transform 5 59 env22427 = env22428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env22427 == env22428) = true)

theorem identity22428 : scanCanonicalize (H12AffineFastState.compose env22428 (packedSelected [0,1,2] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound22428 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env22429 : List Nat := [2,4,8,16,32,59,9,15,512,565,513,570,515,0,554,35,570,42,564,555,513,32,16,2,514,59,42,570,570,42,62,523,14,522,513,513]

theorem envBound22429 : H12AffineFastState.Bounded env22429 := by
  intro p hp
  have h : env22429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22428_22429 : H12AffineEnvironment.transform 10 513 env22428 = env22429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env22428 == env22429) = true)

theorem identity22429 : scanCanonicalize (H12AffineFastState.compose env22429 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound22429 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22430 : List Nat := [2,4,8,16,10,17,9,15,512,543,513,528,515,0,512,9,528,0,542,513,513,10,16,2,514,17,0,528,528,0,20,523,14,522,513,513]

theorem envBound22430 : H12AffineFastState.Bounded env22430 := by
  intro p hp
  have h : env22430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22429_22430 : H12AffineEnvironment.transform 4 10 env22429 = env22430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env22429 == env22430) = true)

theorem identity22430 : scanCanonicalize (H12AffineFastState.compose env22430 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22430 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22431 : List Nat := [2,4,8,16,10,17,9,15,1,30,0,17,2,0,1,9,17,0,31,0,0,10,16,2,3,17,0,17,17,0,20,10,14,11,0,0]

theorem envBound22431 : H12AffineFastState.Bounded env22431 := by
  intro p hp
  have h : env22431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22430_22431 : H12AffineEnvironment.transform 8 1 env22430 = env22431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22430 == env22431) = true)

theorem identity22431 : scanCanonicalize (H12AffineFastState.compose env22431 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22431 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22432 : List Nat := [2,4,8,1,10,0,9,15,1,15,0,0,2,0,1,9,0,0,14,0,0,10,1,2,3,0,0,0,0,0,5,10,14,11,0,0]

theorem envBound22432 : H12AffineFastState.Bounded env22432 := by
  intro p hp
  have h : env22432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22431_22432 : H12AffineEnvironment.transform 3 1 env22431 = env22432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22431 == env22432) = true)

theorem identity22432 : scanCanonicalize (H12AffineFastState.compose env22432 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22432 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22433 : List Nat := [2,4,2,1,0,0,3,5,1,5,0,0,2,0,1,3,0,0,4,0,0,0,1,2,3,0,0,0,0,0,5,0,4,1,0,0]

theorem envBound22433 : H12AffineFastState.Bounded env22433 := by
  intro p hp
  have h : env22433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22432_22433 : H12AffineEnvironment.transform 2 2 env22432 = env22433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22432 == env22433) = true)

def env22434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4160,21928,41413,21762,8328,64,100695,115150,58581,35324,94423,95530,257,73771,115087,22272]

theorem envBound22434 : H12AffineFastState.Bounded env22434 := by
  intro p hp
  have h : env22434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22418_22434 : H12AffineEnvironment.transform 16 49169 env22418 = env22434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env22418 == env22434) = true)

theorem identity22434 : scanCanonicalize (H12AffineFastState.compose env22434 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound22434 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22435 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10280,1025,29788,4160,21928,21912,21762,8328,64,97546,79251,4232,32161,94423,95530,257,73771,79314,22272]

theorem envBound22435 : H12AffineFastState.Bounded env22435 := by
  intro p hp
  have h : env22435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22434_22435 : H12AffineEnvironment.transform 14 29789 env22434 = env22435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env22434 == env22435) = true)

theorem identity22435 : scanCanonicalize (H12AffineFastState.compose env22435 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound22435 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env22436 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,29004,65536,12637,10280,272,29005,4160,20665,20617,20499,8328,64,96283,77954,4232,30896,94423,94267,257,73771,78019,21009]

theorem envBound22436 : H12AffineFastState.Bounded env22436 := by
  intro p hp
  have h : env22436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22435_22436 : H12AffineEnvironment.transform 9 273 env22435 = env22436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22435 == env22436) = true)

theorem identity22436 : scanCanonicalize (H12AffineFastState.compose env22436 (packedSelected [1,4,7,8,9,11,19,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 8615) := by decide +kernel

theorem selectedBound22436 : packedSelected [1,4,7,8,9,11,19,23,27] rootPS < 2^1333 := by decide +kernel

def env22437 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,29004,8615,12637,10280,272,29005,4160,20665,20617,20499,8328,64,22972,4389,4232,30896,20848,20892,257,396,4452,21009]

theorem envBound22437 : H12AffineFastState.Bounded env22437 := by
  intro p hp
  have h : env22437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22436_22437 : H12AffineEnvironment.transform 15 8615 env22436 = env22437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8615 env22436 == env22437) = true)

theorem identity22437 : scanCanonicalize (H12AffineFastState.compose env22437 (packedSelected [1,4,8,9,11,14,18,20,26] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22437 : packedSelected [1,4,8,9,11,14,18,20,26] rootPS < 2^1333 := by decide +kernel

def env22438 : List Nat := [2,4,8,16,32,64,128,116,512,101,2048,4096,8192,16384,28728,8403,12329,10280,100,28729,4160,20665,20617,20499,8328,64,22728,4177,4232,30896,20484,20712,117,248,4112,21009]

theorem envBound22438 : H12AffineFastState.Bounded env22438 := by
  intro p hp
  have h : env22438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22437_22438 : H12AffineEnvironment.transform 7 116 env22437 = env22438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22437 == env22438) = true)

theorem identity22438 : scanCanonicalize (H12AffineFastState.compose env22438 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22438 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22439 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,4096,8192,16384,28728,8322,12329,10280,53,28729,4113,20665,20617,20499,8328,17,22681,4096,4232,30896,20484,20665,36,169,4112,21009]

theorem envBound22439 : H12AffineFastState.Bounded env22439 := by
  intro p hp
  have h : env22439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22438_22439 : H12AffineEnvironment.transform 5 17 env22438 = env22439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22438 == env22439) = true)

theorem identity22439 : scanCanonicalize (H12AffineFastState.compose env22439 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound22439 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22440 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,4096,8192,4112,8232,8322,12329,10280,53,8233,4113,169,153,3,8328,17,2185,4096,4232,10400,20,169,36,169,4112,513]

theorem envBound22440 : H12AffineFastState.Bounded env22440 := by
  intro p hp
  have h : env22440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22439_22440 : H12AffineEnvironment.transform 13 4112 env22439 = env22440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env22439 == env22440) = true)

theorem identity22440 : scanCanonicalize (H12AffineFastState.compose env22440 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound22440 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env22441 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,152,8192,136,8232,8322,8369,10280,53,8233,137,169,153,3,8328,17,2185,152,16,10400,20,169,36,169,136,513]

theorem envBound22441 : H12AffineFastState.Bounded env22441 := by
  intro p hp
  have h : env22441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22440_22441 : H12AffineEnvironment.transform 11 152 env22440 = env22441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env22440 == env22441) = true)

theorem identity22441 : scanCanonicalize (H12AffineFastState.compose env22441 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 2088) := by decide +kernel

theorem selectedBound22441 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env22442 : List Nat := [2,4,8,16,32,17,128,37,512,52,2048,152,2088,136,2048,2218,2201,0,53,2049,137,169,153,3,2208,17,2185,152,16,136,20,169,36,169,136,513]

theorem envBound22442 : H12AffineFastState.Bounded env22442 := by
  intro p hp
  have h : env22442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22441_22442 : H12AffineEnvironment.transform 12 2088 env22441 = env22442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2088 env22441 == env22442) = true)

theorem identity22442 : scanCanonicalize (H12AffineFastState.compose env22442 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22442 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env22443 : List Nat := [2,4,8,16,32,17,128,37,512,52,1,152,41,136,1,171,152,0,53,0,137,169,153,3,161,17,136,152,16,136,20,169,36,169,136,513]

theorem envBound22443 : H12AffineFastState.Bounded env22443 := by
  intro p hp
  have h : env22443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22442_22443 : H12AffineEnvironment.transform 10 1 env22442 = env22443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22442 == env22443) = true)

theorem identity22443 : scanCanonicalize (H12AffineFastState.compose env22443 (packedSelected [2,3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22443 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env22444 : List Nat := [2,4,8,1,32,0,128,37,512,37,1,137,41,136,1,171,137,0,36,0,137,169,136,3,161,0,136,137,1,136,5,169,36,169,136,513]

theorem envBound22444 : H12AffineFastState.Bounded env22444 := by
  intro p hp
  have h : env22444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22443_22444 : H12AffineEnvironment.transform 3 1 env22443 = env22444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22443 == env22444) = true)

theorem identity22444 : scanCanonicalize (H12AffineFastState.compose env22444 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22444 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22445 : List Nat := [2,4,8,1,32,0,9,37,512,37,1,0,41,1,1,34,0,0,36,0,0,32,1,3,40,0,1,0,1,1,5,32,36,32,1,513]

theorem envBound22445 : H12AffineFastState.Bounded env22445 := by
  intro p hp
  have h : env22445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22444_22445 : H12AffineEnvironment.transform 6 9 env22444 = env22445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22444 == env22445) = true)

theorem identity22445 : scanCanonicalize (H12AffineFastState.compose env22445 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound22445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22446 : List Nat := [2,1,8,1,32,0,9,32,512,32,1,0,41,1,1,34,0,0,33,0,0,32,1,3,40,0,1,0,1,1,0,32,33,32,1,513]

theorem envBound22446 : H12AffineFastState.Bounded env22446 := by
  intro p hp
  have h : env22446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22445_22446 : H12AffineEnvironment.transform 1 1 env22445 = env22446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env22445 == env22446) = true)

theorem identity22446 : scanCanonicalize (H12AffineFastState.compose env22446 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound22446 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22447 : List Nat := [2,1,8,1,32,0,9,32,34,32,1,0,41,1,1,34,0,0,33,0,0,32,1,3,40,0,1,0,1,1,0,32,33,32,1,35]

theorem envBound22447 : H12AffineFastState.Bounded env22447 := by
  intro p hp
  have h : env22447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22446_22447 : H12AffineEnvironment.transform 8 34 env22446 = env22447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env22446 == env22447) = true)

theorem identity22447 : scanCanonicalize (H12AffineFastState.compose env22447 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22447 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22448 : List Nat := [2,1,8,1,1,0,9,1,3,1,1,0,8,1,1,3,0,0,0,0,0,1,1,3,9,0,1,0,1,1,0,1,0,1,1,2]

theorem envBound22448 : H12AffineFastState.Bounded env22448 := by
  intro p hp
  have h : env22448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22447_22448 : H12AffineEnvironment.transform 4 1 env22447 = env22448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22447 == env22448) = true)

theorem identity22448 : scanCanonicalize (H12AffineFastState.compose env22448 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound22448 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22449 : List Nat := [2,1,1,1,1,0,0,1,3,1,1,0,1,1,1,3,0,0,0,0,0,1,1,3,0,0,1,0,1,1,0,1,0,1,1,2]

theorem envBound22449 : H12AffineFastState.Bounded env22449 := by
  intro p hp
  have h : env22449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22448_22449 : H12AffineEnvironment.transform 2 1 env22448 = env22449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env22448 == env22449) = true)

theorem identity22449 : scanCanonicalize (H12AffineFastState.compose env22449 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound22449 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22450 : List Nat := [0,1,1,1,1,0,0,1,1,1,1,0,1,1,1,1,0,0,0,0,0,1,1,1,0,0,1,0,1,1,0,1,0,1,1,0]

theorem envBound22450 : H12AffineFastState.Bounded env22450 := by
  intro p hp
  have h : env22450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22449_22450 : H12AffineEnvironment.transform 0 0 env22449 = env22450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env22449 == env22450) = true)

def env22451 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,169400,156116,21762,8328,64,215366,115150,140484,35325,241862,243002,257,254010,197022,169745]

theorem envBound22451 : H12AffineFastState.Bounded env22451 := by
  intro p hp
  have h : env22451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22417_22451 : H12AffineEnvironment.transform 17 10281 env22417 = env22451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22417 == env22451) = true)

def env22452 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4160,21928,41412,21762,8328,64,100694,115150,58580,35325,94422,95530,257,73770,115086,22273]

theorem envBound22452 : H12AffineFastState.Bounded env22452 := by
  intro p hp
  have h : env22452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22451_22452 : H12AffineEnvironment.transform 16 49168 env22451 = env22452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env22451 == env22452) = true)

theorem identity22452 : scanCanonicalize (H12AffineFastState.compose env22452 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound22452 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22453 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10281,1025,32769,4160,168,41412,2,8328,64,100694,103630,45524,35325,75222,73770,257,73770,103566,513]

theorem envBound22453 : H12AffineFastState.Bounded env22453 := by
  intro p hp
  have h : env22453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22452_22453 : H12AffineEnvironment.transform 13 5376 env22452 = env22453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22452 == env22453) = true)

theorem identity22453 : scanCanonicalize (H12AffineFastState.compose env22453 (packedSelected [0,1,5,7,8,11,16,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound22453 : packedSelected [0,1,5,7,8,11,16,18,24] rootPS < 2^1333 := by decide +kernel

def env22454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,398,38160,10281,1025,32769,4160,168,41412,2,8328,64,35032,38208,45524,35325,9304,8612,257,8612,38144,513]

theorem envBound22454 : H12AffineFastState.Bounded env22454 := by
  intro p hp
  have h : env22454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22453_22454 : H12AffineEnvironment.transform 15 398 env22453 = env22454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env22453 == env22454) = true)

theorem identity22454 : scanCanonicalize (H12AffineFastState.compose env22454 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound22454 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env22455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,80,398,5440,10281,1025,81,4160,168,8596,2,8328,64,2184,5392,12676,2477,9304,8612,257,8612,5456,513]

theorem envBound22455 : H12AffineFastState.Bounded env22455 := by
  intro p hp
  have h : env22455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22454_22455 : H12AffineEnvironment.transform 14 80 env22454 = env22455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env22454 == env22455) = true)

theorem identity22455 : scanCanonicalize (H12AffineFastState.compose env22455 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound22455 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,80,398,5440,2557,1025,81,4160,168,64,2,348,64,2184,5392,4176,2477,1420,112,257,112,5456,513]

theorem envBound22456 : H12AffineFastState.Bounded env22456 := by
  intro p hp
  have h : env22456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22455_22456 : H12AffineEnvironment.transform 12 468 env22455 = env22456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env22455 == env22456) = true)

theorem identity22456 : scanCanonicalize (H12AffineFastState.compose env22456 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22456 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env22457 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5376,0,398,5392,2477,1025,1,4112,168,16,2,268,16,2184,5392,4096,2477,1420,32,257,32,5376,513]

theorem envBound22457 : H12AffineFastState.Bounded env22457 := by
  intro p hp
  have h : env22457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22456_22457 : H12AffineEnvironment.transform 5 16 env22456 = env22457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22456 == env22457) = true)

theorem identity22457 : scanCanonicalize (H12AffineFastState.compose env22457 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound22457 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env22458 : List Nat := [2,4,8,16,32,16,128,256,512,273,2048,4096,388,4113,0,398,4097,2477,272,1,4112,168,16,2,268,16,2184,4097,4096,2477,157,32,257,32,4113,513]

theorem envBound22458 : H12AffineFastState.Bounded env22458 := by
  intro p hp
  have h : env22458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22457_22458 : H12AffineEnvironment.transform 9 273 env22457 = env22458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env22457 == env22458) = true)

theorem identity22458 : scanCanonicalize (H12AffineFastState.compose env22458 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22459 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,4096,269,4113,0,263,4097,2340,272,1,4112,33,16,2,268,16,2049,4097,4096,2340,20,32,257,32,4113,513]

theorem envBound22459 : H12AffineFastState.Bounded env22459 := by
  intro p hp
  have h : env22459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22458_22459 : H12AffineEnvironment.transform 6 9 env22458 = env22459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22458 == env22459) = true)

theorem identity22459 : scanCanonicalize (H12AffineFastState.compose env22459 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound22459 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22460 : List Nat := [2,4,8,16,32,16,9,256,512,273,2048,16,269,1,0,263,17,2340,272,1,0,33,16,2,268,16,2049,17,16,2340,20,32,257,32,1,513]

theorem envBound22460 : H12AffineFastState.Bounded env22460 := by
  intro p hp
  have h : env22460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22459_22460 : H12AffineEnvironment.transform 11 16 env22459 = env22460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22459 == env22460) = true)

def env22461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,21929,41413,21762,8328,64,100695,115150,58581,35325,94423,95531,257,73771,115087,22272]

theorem envBound22461 : H12AffineFastState.Bounded env22461 := by
  intro p hp
  have h : env22461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22451_22461 : H12AffineEnvironment.transform 16 49169 env22451 = env22461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env22451 == env22461) = true)

theorem identity22461 : scanCanonicalize (H12AffineFastState.compose env22461 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound22461 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,38297,10281,1025,32769,4160,33,41413,138,8328,64,100695,103494,45405,35325,75103,73891,257,73771,103431,648]

theorem envBound22462 : H12AffineFastState.Bounded env22462 := by
  intro p hp
  have h : env22462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22461_22462 : H12AffineEnvironment.transform 13 5512 env22461 = env22462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env22461 == env22462) = true)

theorem identity22462 : scanCanonicalize (H12AffineFastState.compose env22462 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22462 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22463 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10281,1025,32769,4160,33,41292,3,8193,64,100695,103494,45405,35188,75103,73770,257,73771,103431,513]

theorem envBound22463 : H12AffineFastState.Bounded env22463 := by
  intro p hp
  have h : env22463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22462_22463 : H12AffineEnvironment.transform 6 9 env22462 = env22463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22462 == env22463) = true)

theorem identity22463 : scanCanonicalize (H12AffineFastState.compose env22463 (packedSelected [0,2,6,7,11,14] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound22463 : packedSelected [0,2,6,7,11,14] rootPS < 2^1333 := by decide +kernel

def env22464 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8282,38160,10281,1025,32769,4160,33,41292,3,8193,64,43277,46108,45405,35188,1285,112,257,113,46173,513]

theorem envBound22464 : H12AffineFastState.Bounded env22464 := by
  intro p hp
  have h : env22464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22463_22464 : H12AffineEnvironment.transform 15 8282 env22463 = env22464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env22463 == env22464) = true)

theorem identity22464 : scanCanonicalize (H12AffineFastState.compose env22464 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22464 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env22465 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1,8282,5393,10281,1025,0,4160,33,8525,3,8193,64,10508,13341,12636,2421,1285,112,257,113,13404,513]

theorem envBound22465 : H12AffineFastState.Bounded env22465 := by
  intro p hp
  have h : env22465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22464_22465 : H12AffineEnvironment.transform 14 1 env22464 = env22465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22464 == env22465) = true)

theorem identity22465 : scanCanonicalize (H12AffineFastState.compose env22465 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22465 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22466 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1,343,5393,2340,1025,0,4160,33,64,3,268,64,2049,5392,4177,2421,1285,112,257,113,5457,513]

theorem envBound22466 : H12AffineFastState.Bounded env22466 := by
  intro p hp
  have h : env22466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22465_22466 : H12AffineEnvironment.transform 12 269 env22465 = env22466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22465 == env22466) = true)

theorem identity22466 : scanCanonicalize (H12AffineFastState.compose env22466 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22466 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22467 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,262,5393,2340,1025,0,4113,33,17,3,268,17,2049,5392,4096,2340,1285,33,257,32,5376,513]

theorem envBound22467 : H12AffineFastState.Bounded env22467 := by
  intro p hp
  have h : env22467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22466_22467 : H12AffineEnvironment.transform 5 17 env22466 = env22467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22466 == env22467) = true)

theorem identity22467 : scanCanonicalize (H12AffineFastState.compose env22467 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound22467 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22468 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,4096,25,5141,1,18,5125,2096,1025,0,4113,33,17,3,24,17,2049,5124,4096,2096,1041,33,21,32,5140,513]

theorem envBound22468 : H12AffineFastState.Bounded env22468 := by
  intro p hp
  have h : env22468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22467_22468 : H12AffineEnvironment.transform 7 20 env22467 = env22468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env22467 == env22468) = true)

theorem identity22468 : scanCanonicalize (H12AffineFastState.compose env22468 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound22468 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22469 : List Nat := [2,4,8,16,32,17,9,20,512,1024,2048,3119,25,2106,1,18,2090,2096,1025,0,3134,33,17,3,24,17,2049,2091,3119,2096,1041,33,21,32,2107,513]

theorem envBound22469 : H12AffineFastState.Bounded env22469 := by
  intro p hp
  have h : env22469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22468_22469 : H12AffineEnvironment.transform 11 3119 env22468 = env22469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env22468 == env22469) = true)

theorem identity22469 : scanCanonicalize (H12AffineFastState.compose env22469 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound22469 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22470 : List Nat := [2,4,8,16,32,17,9,20,16,1024,2048,3119,25,2106,1,18,2090,2096,1025,0,3134,33,17,3,24,17,2049,2091,3119,2096,1041,33,21,32,2107,17]

theorem envBound22470 : H12AffineFastState.Bounded env22470 := by
  intro p hp
  have h : env22470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22469_22470 : H12AffineEnvironment.transform 8 16 env22469 = env22470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env22469 == env22470) = true)

theorem identity22470 : scanCanonicalize (H12AffineFastState.compose env22470 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1029) := by decide +kernel

theorem selectedBound22470 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22471 : List Nat := [2,4,8,16,32,17,9,20,16,1024,1029,42,25,1087,1,18,1071,1077,1025,0,59,33,17,3,24,17,1028,1070,42,1077,1041,33,21,32,1086,17]

theorem envBound22471 : H12AffineFastState.Bounded env22471 := by
  intro p hp
  have h : env22471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22470_22471 : H12AffineEnvironment.transform 10 1029 env22470 = env22471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1029 env22470 == env22471) = true)

theorem identity22471 : scanCanonicalize (H12AffineFastState.compose env22471 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound22471 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22472 : List Nat := [2,4,8,16,10,17,9,20,16,1024,1029,0,25,1045,1,18,1029,1055,1025,0,17,11,17,3,24,17,1028,1028,0,1055,1041,11,21,10,1044,17]

theorem envBound22472 : H12AffineFastState.Bounded env22472 := by
  intro p hp
  have h : env22472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22471_22472 : H12AffineEnvironment.transform 4 10 env22471 = env22472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env22471 == env22472) = true)

theorem identity22472 : scanCanonicalize (H12AffineFastState.compose env22472 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound22472 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22473 : List Nat := [2,4,8,16,10,17,9,20,16,14,11,0,25,27,1,18,11,17,15,0,17,11,17,3,24,17,10,10,0,17,31,11,21,10,26,17]

theorem envBound22473 : H12AffineFastState.Bounded env22473 := by
  intro p hp
  have h : env22473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22472_22473 : H12AffineEnvironment.transform 9 14 env22472 = env22473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env22472 == env22473) = true)

theorem identity22473 : scanCanonicalize (H12AffineFastState.compose env22473 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound22473 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22474 : List Nat := [2,4,8,15,10,14,9,11,15,14,11,0,6,4,1,13,11,14,15,0,14,11,14,3,7,14,10,10,0,14,0,11,10,10,5,14]

theorem envBound22474 : H12AffineFastState.Bounded env22474 := by
  intro p hp
  have h : env22474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22473_22474 : H12AffineEnvironment.transform 3 15 env22473 = env22474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env22473 == env22474) = true)

theorem identity22474 : scanCanonicalize (H12AffineFastState.compose env22474 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound22474 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22475 : List Nat := [0,4,8,13,8,12,9,9,13,12,9,0,4,4,1,13,9,12,13,0,12,9,12,1,5,12,8,8,0,12,0,9,8,8,5,12]

theorem envBound22475 : H12AffineFastState.Bounded env22475 := by
  intro p hp
  have h : env22475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22474_22475 : H12AffineEnvironment.transform 0 0 env22474 = env22475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env22474 == env22475) = true)

theorem identity22475 : scanCanonicalize (H12AffineFastState.compose env22475 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound22475 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env22476 : List Nat := [0,4,0,5,0,4,1,1,5,4,1,0,4,4,1,5,1,4,5,0,4,1,4,1,5,4,0,0,0,4,0,1,0,0,5,4]

theorem envBound22476 : H12AffineFastState.Bounded env22476 := by
  intro p hp
  have h : env22476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22475_22476 : H12AffineEnvironment.transform 2 0 env22475 = env22476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env22475 == env22476) = true)

def env22477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,21763,8328,64,215366,115150,140485,303572,241863,498962,257,254010,197022,169744]

theorem envBound22477 : H12AffineFastState.Bounded env22477 := by
  intro p hp
  have h : env22477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22416_22477 : H12AffineEnvironment.transform 20 4161 env22416 = env22477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22416 == env22477) = true)

theorem identity22477 : scanCanonicalize (H12AffineFastState.compose env22477 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound22477 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272513,62661,21763,8328,64,121943,115150,45524,303572,75222,329731,257,95531,103567,513]

theorem envBound22478 : H12AffineFastState.Bounded env22478 := by
  intro p hp
  have h : env22478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22477_22478 : H12AffineEnvironment.transform 16 38161 env22477 = env22478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env22477 == env22478) = true)

def env22479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4161,169,62661,21763,8328,64,121943,115150,45524,35324,75222,73771,257,95531,103567,513]

theorem envBound22479 : H12AffineFastState.Bounded env22479 := by
  intro p hp
  have h : env22479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22478_22479 : H12AffineEnvironment.transform 17 10280 env22478 = env22479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env22478 == env22479) = true)

theorem identity22479 : scanCanonicalize (H12AffineFastState.compose env22479 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound22479 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env22480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,38161,10280,1025,32769,4161,169,62661,21763,8328,64,10588,13509,45524,35324,53469,54560,257,32800,24964,513]

theorem envBound22480 : H12AffineFastState.Bounded env22480 := by
  intro p hp
  have h : env22480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22479_22480 : H12AffineEnvironment.transform 15 62731 env22479 = env22480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env22479 == env22480) = true)

theorem identity22480 : scanCanonicalize (H12AffineFastState.compose env22480 (packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound22480 : packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS < 2^1333 := by decide +kernel

def env22481 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,16384,32768,61514,36944,10280,320,32769,4161,169,61828,20546,8328,64,10588,12676,45524,35324,53469,53345,257,32800,24964,513]

theorem envBound22481 : H12AffineFastState.Bounded env22481 := by
  intro p hp
  have h : env22481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22480_22481 : H12AffineEnvironment.transform 9 321 env22480 = env22481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env22480 == env22481) = true)

theorem identity22481 : scanCanonicalize (H12AffineFastState.compose env22481 (packedSelected [7,8,10,11,14,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound22481 : packedSelected [7,8,10,11,14,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env22482 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,4541,32768,41463,36944,10280,320,32769,4161,169,41017,511,8328,64,10588,12676,45524,35324,33120,33244,257,32800,12345,513]

theorem envBound22482 : H12AffineFastState.Bounded env22482 := by
  intro p hp
  have h : env22482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22481_22482 : H12AffineEnvironment.transform 13 4541 env22481 = env22482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env22481 == env22482) = true)

theorem identity22482 : scanCanonicalize (H12AffineFastState.compose env22482 (packedSelected [0,1,5,7,8,11,12,15,17,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound22482 : packedSelected [0,1,5,7,8,11,12,15,17,20,23,24] rootPS < 2^1333 := by decide +kernel

def env22483 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,8192,4541,217,8494,4233,10280,320,216,4161,169,8416,511,8328,64,10588,12676,12557,2341,441,261,257,249,12345,513]

theorem envBound22483 : H12AffineFastState.Bounded env22483 := by
  intro p hp
  have h : env22483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22482_22483 : H12AffineEnvironment.transform 14 217 env22482 = env22483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env22482 == env22483) = true)

theorem identity22483 : scanCanonicalize (H12AffineFastState.compose env22483 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound22483 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env22484 : List Nat := [2,4,8,16,32,64,128,256,512,321,2048,4096,469,4541,217,251,4233,2557,320,216,4161,169,309,511,349,64,2185,4177,4312,2341,441,261,257,249,4588,513]

theorem envBound22484 : H12AffineFastState.Bounded env22484 := by
  intro p hp
  have h : env22484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22483_22484 : H12AffineEnvironment.transform 12 469 env22483 = env22484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env22483 == env22484) = true)

theorem identity22484 : scanCanonicalize (H12AffineFastState.compose env22484 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22484 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env22485 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,348,4404,80,114,4096,2420,320,81,4161,32,309,374,349,64,2048,4177,4177,2341,304,261,257,112,4453,513]

theorem envBound22485 : H12AffineFastState.Bounded env22485 := by
  intro p hp
  have h : env22485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22484_22485 : H12AffineEnvironment.transform 6 9 env22484 = env22485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22484 == env22485) = true)

theorem identity22485 : scanCanonicalize (H12AffineFastState.compose env22485 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22485 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env22486 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,4096,120,4112,80,114,4096,2128,100,81,4161,32,17,82,121,64,2048,4177,4177,2049,20,33,37,112,4161,513]

theorem envBound22486 : H12AffineFastState.Bounded env22486 := by
  intro p hp
  have h : env22486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22485_22486 : H12AffineEnvironment.transform 7 36 env22485 = env22486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22485 == env22486) = true)

theorem identity22486 : scanCanonicalize (H12AffineFastState.compose env22486 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound22486 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22487 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,81,120,65,80,114,81,2128,100,81,16,32,17,82,121,64,2048,0,0,2049,20,33,37,112,16,513]

theorem envBound22487 : H12AffineFastState.Bounded env22487 := by
  intro p hp
  have h : env22487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22486_22487 : H12AffineEnvironment.transform 11 81 env22486 = env22487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env22486 == env22487) = true)

theorem identity22487 : scanCanonicalize (H12AffineFastState.compose env22487 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22487 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env22488 : List Nat := [2,4,8,16,32,64,9,36,1,101,2048,81,120,65,80,114,81,2128,100,81,16,32,17,82,121,64,2048,0,0,2049,20,33,37,112,16,0]

theorem envBound22488 : H12AffineFastState.Bounded env22488 := by
  intro p hp
  have h : env22488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22487_22488 : H12AffineEnvironment.transform 8 1 env22487 = env22488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22487 == env22488) = true)

theorem identity22488 : scanCanonicalize (H12AffineFastState.compose env22488 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound22488 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env22489 : List Nat := [2,4,8,16,17,64,9,21,1,84,2048,81,73,65,80,67,81,2128,85,81,16,17,17,82,72,64,2048,0,0,2049,20,16,20,65,16,0]

theorem envBound22489 : H12AffineFastState.Bounded env22489 := by
  intro p hp
  have h : env22489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22488_22489 : H12AffineEnvironment.transform 4 17 env22488 = env22489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env22488 == env22489) = true)

theorem identity22489 : scanCanonicalize (H12AffineFastState.compose env22489 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22489 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env22490 : List Nat := [2,4,8,0,1,64,9,5,1,68,2048,65,73,65,64,67,65,2112,69,65,0,1,1,66,72,64,2048,0,0,2049,4,0,4,65,0,0]

theorem envBound22490 : H12AffineFastState.Bounded env22490 := by
  intro p hp
  have h : env22490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22489_22490 : H12AffineEnvironment.transform 3 0 env22489 = env22490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22489 == env22490) = true)

theorem identity22490 : scanCanonicalize (H12AffineFastState.compose env22490 (packedSelected [1,7] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound22490 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env22491 : List Nat := [2,4,8,0,1,0,9,5,1,4,2048,1,9,1,0,3,1,2048,5,1,0,1,1,2,8,0,2048,0,0,2049,4,0,4,1,0,0]

theorem envBound22491 : H12AffineFastState.Bounded env22491 := by
  intro p hp
  have h : env22491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22490_22491 : H12AffineEnvironment.transform 5 0 env22490 = env22491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env22490 == env22491) = true)

theorem identity22491 : scanCanonicalize (H12AffineFastState.compose env22491 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound22491 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22492 : List Nat := [2,4,8,0,1,0,9,5,1,4,1,1,9,1,0,3,1,1,5,1,0,1,1,2,8,0,1,0,0,0,4,0,4,1,0,0]

theorem envBound22492 : H12AffineFastState.Bounded env22492 := by
  intro p hp
  have h : env22492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22491_22492 : H12AffineEnvironment.transform 10 1 env22491 = env22492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env22491 == env22492) = true)

def env22493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4161,168,62661,21763,8328,64,121943,115150,45524,35325,75222,73770,257,95531,103567,513]

theorem envBound22493 : H12AffineFastState.Bounded env22493 := by
  intro p hp
  have h : env22493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22478_22493 : H12AffineEnvironment.transform 17 10281 env22478 = env22493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22478 == env22493) = true)

theorem identity22493 : scanCanonicalize (H12AffineFastState.compose env22493 (packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 41170) := by decide +kernel

theorem selectedBound22493 : packedSelected [0,1,2,3,4,5,6,11,14,17,19,20,22,27,28,32] rootPS < 2^1333 := by decide +kernel

def env22494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41170,38161,10281,1025,32769,4161,168,62661,21763,8328,64,31877,24860,45524,35325,34052,33016,257,54777,13405,513]

theorem envBound22494 : H12AffineFastState.Bounded env22494 := by
  intro p hp
  have h : env22494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22493_22494 : H12AffineEnvironment.transform 15 41170 env22493 = env22494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41170 env22493 == env22494) = true)

theorem identity22494 : scanCanonicalize (H12AffineFastState.compose env22494 (packedSelected [1,3,4,8,10,11,17,20,22,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound22494 : packedSelected [1,3,4,8,10,11,17,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env22495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,32768,41170,38161,10281,1025,32769,4161,168,32968,8462,8328,64,2184,5393,45524,35325,34052,33016,257,41460,13405,513]

theorem envBound22495 : H12AffineFastState.Bounded env22495 := by
  intro p hp
  have h : env22495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22494_22495 : H12AffineEnvironment.transform 13 13325 env22494 = env22495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env22494 == env22495) = true)

theorem identity22495 : scanCanonicalize (H12AffineFastState.compose env22495 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound22495 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env22496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5593,32768,33030,38161,2557,1025,32769,4161,168,32968,218,348,64,2184,5393,36864,35325,34052,33016,257,32800,5513,513]

theorem envBound22496 : H12AffineFastState.Bounded env22496 := by
  intro p hp
  have h : env22496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22495_22496 : H12AffineEnvironment.transform 12 468 env22495 = env22496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env22495 == env22496) = true)

theorem identity22496 : scanCanonicalize (H12AffineFastState.compose env22496 (packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound22496 : packedSelected [0,3,4,5,7,9,10,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env22497 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5593,0,262,5393,2557,1025,1,4161,168,200,218,348,64,2184,5393,4096,2557,1284,248,257,32,5513,513]

theorem envBound22497 : H12AffineFastState.Bounded env22497 := by
  intro p hp
  have h : env22497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22496_22497 : H12AffineEnvironment.transform 14 0 env22496 = env22497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env22496 == env22497) = true)

def env22498 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156117,2114883,8328,64,6677655,115151,2241669,303573,2334854,4268163,257,254010,197022,2262865]

theorem envBound22498 : H12AffineFastState.Bounded env22498 := by
  intro p hp
  have h : env22498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22370_22498 : H12AffineEnvironment.transform 22 156117 env22370 = env22498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156117 env22370 == env22498) = true)

def env22499 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156117,2114883,8328,64,215367,115151,2241669,303573,2334854,2592083,257,254010,197022,2262865]

theorem envBound22499 : H12AffineFastState.Bounded env22499 := by
  intro p hp
  have h : env22499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22498_22499 : H12AffineEnvironment.transform 21 2534864 env22498 = env22499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env22498 == env22499) = true)

def env22500 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,21763,8328,64,215367,115151,140485,303573,241862,498963,257,254010,197022,169745]

theorem envBound22500 : H12AffineFastState.Bounded env22500 := by
  intro p hp
  have h : env22500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22499_22500 : H12AffineEnvironment.transform 20 4160 env22499 = env22500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22499 == env22500) = true)

theorem identity22500 : scanCanonicalize (H12AffineFastState.compose env22500 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound22500 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22501 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,4160,329867,120014,21763,8328,64,64604,115151,102878,303573,1501,272392,257,21793,46213,74250]

theorem envBound22501 : H12AffineFastState.Bounded env22501 := by
  intro p hp
  have h : env22501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22500_22501 : H12AffineEnvironment.transform 16 111899 env22500 = env22501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env22500 == env22501) = true)

def env22502 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10400,1025,32769,4160,73771,120014,21763,8328,64,64604,115151,102878,35189,1501,168,257,21793,46213,74250]

theorem envBound22502 : H12AffineFastState.Bounded env22502 := by
  intro p hp
  have h : env22502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22501_22502 : H12AffineEnvironment.transform 17 10400 env22501 = env22502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env22501 == env22502) = true)

def env22503 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4160,73771,119878,21763,8192,64,64604,115015,102742,35189,1365,32,257,21793,46093,74250]

theorem envBound22503 : H12AffineFastState.Bounded env22503 := by
  intro p hp
  have h : env22503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22502_22503 : H12AffineEnvironment.transform 6 8 env22502 = env22503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22502 == env22503) = true)

theorem identity22503 : scanCanonicalize (H12AffineFastState.compose env22503 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound22503 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22504 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,13388,10280,1025,32769,4160,41340,21777,21763,8192,64,64604,16400,4097,35189,1365,32,257,21793,46093,41821]

theorem envBound22504 : H12AffineFastState.Bounded env22504 := by
  intro p hp
  have h : env22504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22503_22504 : H12AffineEnvironment.transform 15 33111 env22503 = env22504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env22503 == env22504) = true)

def env22505 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4160,73771,119879,21763,8193,64,64604,115014,102743,35189,1364,33,257,21793,46092,74250]

theorem envBound22505 : H12AffineFastState.Bounded env22505 := by
  intro p hp
  have h : env22505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22502_22505 : H12AffineEnvironment.transform 6 9 env22502 = env22505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22502 == env22505) = true)

theorem identity22505 : scanCanonicalize (H12AffineFastState.compose env22505 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound22505 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22506 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1025,32769,4160,32,62540,21763,8193,64,64604,57677,45404,35189,1364,33,257,21793,46092,513]

theorem envBound22506 : H12AffineFastState.Bounded env22506 := by
  intro p hp
  have h : env22506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22505_22506 : H12AffineEnvironment.transform 15 8203 env22505 = env22506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env22505 == env22506) = true)

theorem identity22506 : scanCanonicalize (H12AffineFastState.compose env22506 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22506 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env22507 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,32768,263,38160,2341,1025,32769,4160,32,54592,21763,269,64,56656,49217,36944,35189,1364,33,257,21793,38144,513]

theorem envBound22507 : H12AffineFastState.Bounded env22507 := by
  intro p hp
  have h : env22507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22506_22507 : H12AffineEnvironment.transform 12 268 env22506 = env22507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22506 == env22507) = true)

theorem identity22507 : scanCanonicalize (H12AffineFastState.compose env22507 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22507 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22508 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,263,38160,2341,1025,32769,4113,32,54545,21763,269,17,56577,49168,36865,35108,1285,33,257,21793,38144,513]

theorem envBound22508 : H12AffineFastState.Bounded env22508 := by
  intro p hp
  have h : env22508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22507_22508 : H12AffineEnvironment.transform 5 17 env22507 = env22508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22507 == env22508) = true)

theorem identity22508 : scanCanonicalize (H12AffineFastState.compose env22508 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound22508 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22509 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21760,263,16400,2341,1025,21761,4113,32,17,21763,269,17,2049,5392,17665,23588,1285,33,257,21793,16384,513]

theorem envBound22509 : H12AffineFastState.Bounded env22509 := by
  intro p hp
  have h : env22509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22508_22509 : H12AffineEnvironment.transform 14 21760 env22508 = env22509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env22508 == env22509) = true)

def env22510 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10401,1025,32769,4160,73770,120014,21763,8328,64,64604,115151,102878,35188,1501,169,257,21793,46213,74250]

theorem envBound22510 : H12AffineFastState.Bounded env22510 := by
  intro p hp
  have h : env22510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22501_22510 : H12AffineEnvironment.transform 17 10401 env22501 = env22510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env22501 == env22510) = true)

def env22511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4160,73770,119878,21763,8192,64,64604,115015,102742,35188,1365,33,257,21793,46093,74250]

theorem envBound22511 : H12AffineFastState.Bounded env22511 := by
  intro p hp
  have h : env22511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22510_22511 : H12AffineEnvironment.transform 6 8 env22510 = env22511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22510 == env22511) = true)

theorem identity22511 : scanCanonicalize (H12AffineFastState.compose env22511 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound22511 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,111899,10281,1025,32769,4160,73770,98631,2,8192,64,43357,103494,102742,35188,1365,33,257,32,46093,74250]

theorem envBound22512 : H12AffineFastState.Bounded env22512 := by
  intro p hp
  have h : env22512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22511_22512 : H12AffineEnvironment.transform 13 5377 env22511 = env22512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22511 == env22512) = true)

theorem identity22512 : scanCanonicalize (H12AffineFastState.compose env22512 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound22512 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,13389,10281,1025,32769,4160,41340,17,2,8192,64,43357,5392,4096,35188,1365,33,257,32,46093,41820]

theorem envBound22513 : H12AffineFastState.Bounded env22513 := by
  intro p hp
  have h : env22513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22512_22513 : H12AffineEnvironment.transform 15 33110 env22512 = env22513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env22512 == env22513) = true)

theorem identity22513 : scanCanonicalize (H12AffineFastState.compose env22513 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22513 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env22514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,32768,33110,5393,2421,1025,32769,4160,32800,17,2,348,64,34817,5392,4096,35188,1365,33,257,32,38225,33280]

theorem envBound22514 : H12AffineFastState.Bounded env22514 := by
  intro p hp
  have h : env22514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22513_22514 : H12AffineEnvironment.transform 12 348 env22513 = env22514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22513 == env22514) = true)

theorem identity22514 : scanCanonicalize (H12AffineFastState.compose env22514 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound22514 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22515 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,372,34,5393,2421,1025,373,4160,340,17,2,348,64,2421,5392,4096,2048,1365,33,257,32,5157,884]

theorem envBound22515 : H12AffineFastState.Bounded env22515 := by
  intro p hp
  have h : env22515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22514_22515 : H12AffineEnvironment.transform 14 372 env22514 = env22515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env22514 == env22515) = true)

theorem identity22515 : scanCanonicalize (H12AffineFastState.compose env22515 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22515 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env22516 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5237,0,34,5221,2049,1025,1,4160,32,17,2,40,64,2049,5220,4096,2048,1057,33,117,32,5157,512]

theorem envBound22516 : H12AffineFastState.Bounded env22516 := by
  intro p hp
  have h : env22516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22515_22516 : H12AffineEnvironment.transform 7 116 env22515 = env22516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22515 == env22516) = true)

theorem identity22516 : scanCanonicalize (H12AffineFastState.compose env22516 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 554) := by decide +kernel

theorem selectedBound22516 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22517 : List Nat := [2,4,8,16,32,64,8,116,512,1024,554,4096,40,5237,0,34,5221,555,1025,1,4160,32,17,2,40,64,555,5220,4096,554,1057,33,117,32,5157,512]

theorem envBound22517 : H12AffineFastState.Bounded env22517 := by
  intro p hp
  have h : env22517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22516_22517 : H12AffineEnvironment.transform 10 554 env22516 = env22517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 554 env22516 == env22517) = true)

theorem identity22517 : scanCanonicalize (H12AffineFastState.compose env22517 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound22517 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22518 : List Nat := [2,4,8,16,32,49,8,5,512,1024,554,4096,40,5124,0,34,5140,555,1025,1,4145,32,17,2,40,49,555,5141,4096,554,1057,33,4,32,5157,512]

theorem envBound22518 : H12AffineFastState.Bounded env22518 := by
  intro p hp
  have h : env22518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22517_22518 : H12AffineEnvironment.transform 5 49 env22517 = env22518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env22517 == env22518) = true)

theorem identity22518 : scanCanonicalize (H12AffineFastState.compose env22518 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22518 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env22519 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,4096,8,5124,0,2,5140,523,1025,1,4113,0,17,2,8,17,523,5141,4096,522,1025,1,4,0,5125,512]

theorem envBound22519 : H12AffineFastState.Bounded env22519 := by
  intro p hp
  have h : env22519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22518_22519 : H12AffineEnvironment.transform 4 0 env22518 = env22519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22518 == env22519) = true)

def env22520 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,16,8,1044,0,2,1028,523,1025,1,1,0,17,2,8,17,523,1029,16,522,1025,1,4,0,1045,512]

theorem envBound22520 : H12AffineFastState.Bounded env22520 := by
  intro p hp
  have h : env22520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22519_22520 : H12AffineEnvironment.transform 11 16 env22519 = env22520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22519 == env22520) = true)

theorem identity22520 : scanCanonicalize (H12AffineFastState.compose env22520 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 523) := by decide +kernel

theorem selectedBound22520 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22521 : List Nat := [2,4,8,16,0,17,8,5,512,523,522,16,8,543,0,2,527,523,522,1,1,0,17,2,8,17,523,526,16,522,522,1,4,0,542,512]

theorem envBound22521 : H12AffineFastState.Bounded env22521 := by
  intro p hp
  have h : env22521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22520_22521 : H12AffineEnvironment.transform 9 523 env22520 = env22521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 523 env22520 == env22521) = true)

def env22522 : List Nat := [2,4,8,4,0,5,8,5,512,523,522,4,8,523,0,2,527,523,522,1,1,0,5,2,8,5,523,526,4,522,522,1,4,0,522,512]

theorem envBound22522 : H12AffineFastState.Bounded env22522 := by
  intro p hp
  have h : env22522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22521_22522 : H12AffineEnvironment.transform 3 4 env22521 = env22522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22521 == env22522) = true)

theorem identity22522 : scanCanonicalize (H12AffineFastState.compose env22522 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound22522 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22523 : List Nat := [0,4,8,4,0,5,8,5,512,521,520,4,8,521,0,0,525,521,520,1,1,0,5,0,8,5,521,524,4,520,520,1,4,0,520,512]

theorem envBound22523 : H12AffineFastState.Bounded env22523 := by
  intro p hp
  have h : env22523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22522_22523 : H12AffineEnvironment.transform 0 0 env22522 = env22523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env22522 == env22523) = true)

def leafEnv22523 : List Nat := [0,4,8,4,0,5,8,5,512,521,520,4,8,521,0,0,525,521,520,1,1,0,5,0,520,8,1,5,521,524,4,520,520,1,4,0,4,0,520,512,1,0,0]

def active22523 : List Nat := [1,2,8]

def tree22523 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22523 : H12WitnessSearch.Good tree22523 := H12GlobalWitnessIndex.good

theorem leafIdentity22523 : H12AffineFastState.composeSystem env22523 rootObs = leafEnv22523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22523 rootObs == leafEnv22523) = true)

theorem terminalChecked22523 : H12PackedTerminal.terminalCheckFast leafEnv22523 active22523 tree22523 = true := by decide +kernel

def env22524 : List Nat := [2,4,8,5,0,4,8,5,512,523,522,5,8,522,0,2,527,523,522,1,1,0,4,2,8,4,523,526,5,522,522,1,4,0,523,512]

theorem envBound22524 : H12AffineFastState.Bounded env22524 := by
  intro p hp
  have h : env22524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22521_22524 : H12AffineEnvironment.transform 3 5 env22521 = env22524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env22521 == env22524) = true)

theorem identity22524 : scanCanonicalize (H12AffineFastState.compose env22524 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound22524 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22525 : List Nat := [2,4,8,5,0,4,8,5,9,2,3,5,8,3,0,2,6,2,3,1,1,0,4,2,8,4,2,7,5,3,3,1,4,0,2,9]

theorem envBound22525 : H12AffineFastState.Bounded env22525 := by
  intro p hp
  have h : env22525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22524_22525 : H12AffineEnvironment.transform 8 9 env22524 = env22525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env22524 == env22525) = true)

def leafEnv22525 : List Nat := [2,4,8,5,0,4,8,5,9,2,3,5,8,3,0,2,6,2,3,1,1,0,4,2,3,8,1,4,2,7,5,3,3,1,4,0,4,2,2,9,1,0,0]

def active22525 : List Nat := [0,1,2]

def tree22525 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22525 : H12WitnessSearch.Good tree22525 := H12GlobalWitnessIndex.good

theorem leafIdentity22525 : H12AffineFastState.composeSystem env22525 rootObs = leafEnv22525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22525 rootObs == leafEnv22525) = true)

theorem terminalChecked22525 : H12PackedTerminal.terminalCheckFast leafEnv22525 active22525 tree22525 = true := by decide +kernel

def env22526 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,17,8,1045,0,2,1029,523,1025,1,0,0,17,2,8,17,523,1028,17,522,1025,1,4,0,1044,512]

theorem envBound22526 : H12AffineFastState.Bounded env22526 := by
  intro p hp
  have h : env22526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22519_22526 : H12AffineEnvironment.transform 11 17 env22519 = env22526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22519 == env22526) = true)

theorem identity22526 : scanCanonicalize (H12AffineFastState.compose env22526 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound22526 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22527 : List Nat := [2,4,8,16,0,17,8,5,30,1024,20,17,8,1045,0,2,1029,21,1025,1,0,0,17,2,8,17,21,1028,17,20,1025,1,4,0,1044,30]

theorem envBound22527 : H12AffineFastState.Bounded env22527 := by
  intro p hp
  have h : env22527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22526_22527 : H12AffineEnvironment.transform 8 30 env22526 = env22527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env22526 == env22527) = true)

def env22528 : List Nat := [2,4,8,16,0,17,8,5,30,0,20,17,8,21,0,2,5,21,1,1,0,0,17,2,8,17,21,4,17,20,1,1,4,0,20,30]

theorem envBound22528 : H12AffineFastState.Bounded env22528 := by
  intro p hp
  have h : env22528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22527_22528 : H12AffineEnvironment.transform 9 0 env22527 = env22528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env22527 == env22528) = true)

theorem identity22528 : scanCanonicalize (H12AffineFastState.compose env22528 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound22528 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22529 : List Nat := [0,4,8,16,0,17,8,5,28,0,20,17,8,21,0,0,5,21,1,1,0,0,17,0,8,17,21,4,17,20,1,1,4,0,20,28]

end H12CloudChart1