import H12CloudChart1Data023

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity5943 : scanCanonicalize (H12AffineFastState.compose env5943 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5943 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env5944 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,8192,4097,13884,8235,4096,2080,1025,13884,4097,5652,17,5655,8225,17,7732,4096,4097,2081,1025,1,5,0,4096,512]

theorem envBound5944 : H12AffineFastState.Bounded env5944 := by
  intro p hp
  have h : env5944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5943_5944 : H12AffineEnvironment.transform 7 4 env5943 = env5944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5943 == env5944) = true)

theorem identity5944 : scanCanonicalize (H12AffineFastState.compose env5944 (packedSelected [1,5] rootPS)) = affineNative (2^(12+1) ^^^ 7741) := by decide +kernel

theorem selectedBound5944 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env5945 : List Nat := [2,4,8,16,32,17,40,4,512,1024,2048,4096,7741,4097,2049,7702,4096,2080,1025,2049,4097,5652,17,5655,7708,17,7732,4096,4097,2081,1025,1,5,0,4096,512]

theorem envBound5945 : H12AffineFastState.Bounded env5945 := by
  intro p hp
  have h : env5945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5944_5945 : H12AffineEnvironment.transform 12 7741 env5944 = env5945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7741 env5944 == env5945) = true)

theorem identity5945 : scanCanonicalize (H12AffineFastState.compose env5945 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound5945 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5946 : List Nat := [2,4,8,16,32,17,40,4,512,1024,1550,4096,4147,4097,1551,4120,4096,1582,1025,1551,4097,5652,17,5655,4114,17,4154,4096,4097,1583,1025,1,5,0,4096,512]

theorem envBound5946 : H12AffineFastState.Bounded env5946 := by
  intro p hp
  have h : env5946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5945_5946 : H12AffineEnvironment.transform 10 1550 env5945 = env5946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env5945 == env5946) = true)

theorem identity5946 : scanCanonicalize (H12AffineFastState.compose env5946 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound5946 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env5947 : List Nat := [2,4,8,16,32,17,40,4,32,1024,1070,4096,4147,4097,1071,4120,4096,1038,1025,1071,4097,5172,17,5175,4114,17,4154,4096,4097,1039,1025,1,5,0,4096,32]

theorem envBound5947 : H12AffineFastState.Bounded env5947 := by
  intro p hp
  have h : env5947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5946_5947 : H12AffineEnvironment.transform 8 32 env5946 = env5947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5946 == env5947) = true)

theorem identity5947 : scanCanonicalize (H12AffineFastState.compose env5947 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound5947 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env5948 : List Nat := [2,4,8,16,32,17,40,4,32,14,32,4096,4147,4097,33,4120,4096,0,15,33,4097,4154,17,4153,4114,17,4154,4096,4097,1,15,1,5,0,4096,32]

theorem envBound5948 : H12AffineFastState.Bounded env5948 := by
  intro p hp
  have h : env5948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5947_5948 : H12AffineEnvironment.transform 9 14 env5947 = env5948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env5947 == env5948) = true)

theorem identity5948 : scanCanonicalize (H12AffineFastState.compose env5948 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound5948 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5949 : List Nat := [2,4,8,16,32,17,40,4,32,14,32,32,19,33,33,56,32,0,15,33,33,26,17,25,50,17,26,32,33,1,15,1,5,0,32,32]

theorem envBound5949 : H12AffineFastState.Bounded env5949 := by
  intro p hp
  have h : env5949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5948_5949 : H12AffineEnvironment.transform 11 32 env5948 = env5949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env5948 == env5949) = true)

theorem identity5949 : scanCanonicalize (H12AffineFastState.compose env5949 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5949 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5950 : List Nat := [2,4,8,16,1,17,9,4,1,14,1,1,19,0,0,25,1,0,15,0,0,26,17,25,19,17,26,1,0,1,15,1,5,0,1,1]

theorem envBound5950 : H12AffineFastState.Bounded env5950 := by
  intro p hp
  have h : env5950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5949_5950 : H12AffineEnvironment.transform 4 1 env5949 = env5950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5949 == env5950) = true)

def env5951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914001,2942161,16384,16892,2641008,598058,14737725,525568,2638929,6332544,8914925]

theorem envBound5951 : H12AffineFastState.Bounded env5951 := by
  intro p hp
  have h : env5951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5744_5951 : H12AffineEnvironment.transform 25 8914001 env5744 = env5951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914001 env5744 == env5951) = true)

def env5952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914001,849105,16384,16892,547952,598058,12644669,525568,545873,4239488,8914925]

theorem envBound5952 : H12AffineFastState.Bounded env5952 := by
  intro p hp
  have h : env5952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5951_5952 : H12AffineEnvironment.transform 20 4096 env5951 = env5952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env5951 == env5952) = true)

def env5953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323793,16384,16892,22640,74794,12644669,256,20561,4239488,8389613]

theorem envBound5953 : H12AffineFastState.Bounded env5953 := by
  intro p hp
  have h : env5953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5952_5953 : H12AffineEnvironment.transform 18 1024 env5952 = env5953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env5952 == env5953) = true)

theorem identity5953 : scanCanonicalize (H12AffineFastState.compose env5953 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound5953 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env5954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8495,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388689,323793,16384,16892,22640,1285,12644669,256,20561,4239488,8389613]

theorem envBound5954 : H12AffineFastState.Bounded env5954 := by
  intro p hp
  have h : env5954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5953_5954 : H12AffineEnvironment.transform 15 8495 env5953 = env5954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env5953 == env5954) = true)

def env5955 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,4194304,8388608,41003,8329,8388609,323713,16384,16812,22560,1285,12644669,256,20481,4239488,8389565]

theorem envBound5955 : H12AffineFastState.Bounded env5955 := by
  intro p hp
  have h : env5955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5954_5955 : H12AffineEnvironment.transform 5 16 env5954 = env5955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env5954 == env5955) = true)

def env5956 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,136,8388608,41003,8329,8388609,323713,16384,16812,22560,1285,8450485,256,20481,45064,8389565]

theorem envBound5956 : H12AffineFastState.Bounded env5956 := by
  intro p hp
  have h : env5956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5955_5956 : H12AffineEnvironment.transform 21 136 env5955 = env5956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136 env5955 == env5956) = true)

theorem identity5956 : scanCanonicalize (H12AffineFastState.compose env5956 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 323084) := by decide +kernel

theorem selectedBound5956 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env5957 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,136,323084,41003,8329,323085,323713,16384,16812,22560,1285,270265,256,20481,45064,322993]

theorem envBound5957 : H12AffineFastState.Bounded env5957 := by
  intro p hp
  have h : env5957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5956_5957 : H12AffineEnvironment.transform 22 323084 env5956 = env5957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 323084 env5956 == env5957) = true)

def env5958 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,8120,1024,32768,4096,136,61876,41003,8329,61877,61241,16384,16812,22560,1285,1,256,20481,45064,61961]

theorem envBound5958 : H12AffineFastState.Bounded env5958 := by
  intro p hp
  have h : env5958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5957_5958 : H12AffineEnvironment.transform 17 8120 env5957 = env5958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8120 env5957 == env5958) = true)

theorem identity5958 : scanCanonicalize (H12AffineFastState.compose env5958 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound5958 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env5959 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,8235,4265,7868,1024,32768,4096,136,61616,41003,8329,61617,60989,16384,16552,22560,1025,1,4,20481,45064,61961]

theorem envBound5959 : H12AffineFastState.Bounded env5959 := by
  intro p hp
  have h : env5959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5958_5959 : H12AffineEnvironment.transform 7 4 env5958 = env5959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env5958 == env5959) = true)

theorem identity5959 : scanCanonicalize (H12AffineFastState.compose env5959 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2106) := by decide +kernel

theorem selectedBound5959 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env5960 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,2106,32768,8235,4265,7868,1024,32768,4096,136,47242,41003,8329,47243,42503,2106,2194,4122,1025,1,4,6203,45064,47667]

theorem envBound5960 : H12AffineFastState.Bounded env5960 := by
  intro p hp
  have h : env5960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5959_5960 : H12AffineEnvironment.transform 13 2106 env5959 = env5960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2106 env5959 == env5960) = true)

theorem identity5960 : scanCanonicalize (H12AffineFastState.compose env5960 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound5960 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5961 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1588,8192,2106,32768,8235,1693,2184,1024,32768,1588,136,44734,41003,8329,44735,42503,2106,2194,1582,1025,1,4,3599,42556,44039]

theorem envBound5961 : H12AffineFastState.Bounded env5961 := by
  intro p hp
  have h : env5961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5960_5961 : H12AffineEnvironment.transform 11 1588 env5960 = env5961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env5960 == env5961) = true)

theorem identity5961 : scanCanonicalize (H12AffineFastState.compose env5961 (packedSelected [0,4,6,7,9,13,21] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound5961 : packedSelected [0,4,6,7,9,13,21] rootPS < 2^1333 := by decide +kernel

def env5962 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1702,1588,8192,1692,32768,8235,1693,1582,1024,32768,1588,136,40984,41003,8329,40985,42503,1692,1588,1582,1025,1,4,169,42556,41633]

theorem envBound5962 : H12AffineFastState.Bounded env5962 := by
  intro p hp
  have h : env5962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5961_5962 : H12AffineEnvironment.transform 10 1702 env5961 = env5962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env5961 == env5962) = true)

theorem identity5962 : scanCanonicalize (H12AffineFastState.compose env5962 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound5962 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env5963 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1702,1588,8192,1692,8200,8235,1693,1582,1024,8200,1588,136,16,35,8329,17,1551,1692,1588,1582,1025,1,4,169,1588,681]

theorem envBound5963 : H12AffineFastState.Bounded env5963 := by
  intro p hp
  have h : env5963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5962_5963 : H12AffineEnvironment.transform 14 8200 env5962 = env5963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env5962 == env5963) = true)

theorem identity5963 : scanCanonicalize (H12AffineFastState.compose env5963 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound5963 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env5964 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1551,1588,8192,1589,8200,8235,1588,1582,1024,8200,1588,33,16,35,8224,17,1551,1589,1588,1582,1025,1,4,0,1588,512]

theorem envBound5964 : H12AffineFastState.Bounded env5964 := by
  intro p hp
  have h : env5964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5963_5964 : H12AffineEnvironment.transform 6 41 env5963 = env5964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env5963 == env5964) = true)

theorem identity5964 : scanCanonicalize (H12AffineFastState.compose env5964 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound5964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5965 : List Nat := [2,4,8,10,32,10,41,4,512,1024,1551,1582,8192,1583,8200,8235,1582,1582,1024,8200,1582,33,10,35,8224,11,1551,1583,1582,1582,1025,1,4,0,1582,512]

theorem envBound5965 : H12AffineFastState.Bounded env5965 := by
  intro p hp
  have h : env5965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5964_5965 : H12AffineEnvironment.transform 3 10 env5964 = env5965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env5964 == env5965) = true)

theorem identity5965 : scanCanonicalize (H12AffineFastState.compose env5965 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound5965 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env5966 : List Nat := [2,4,8,10,1,10,8,4,512,1024,1551,1551,8192,1550,8200,8202,1551,1551,1024,8200,1551,0,10,2,8193,11,1551,1550,1551,1551,1025,1,4,0,1551,512]

theorem envBound5966 : H12AffineFastState.Bounded env5966 := by
  intro p hp
  have h : env5966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5965_5966 : H12AffineEnvironment.transform 4 1 env5965 = env5966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5965 == env5966) = true)

theorem identity5966 : scanCanonicalize (H12AffineFastState.compose env5966 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 526) := by decide +kernel

theorem selectedBound5966 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5967 : List Nat := [2,4,8,10,1,10,8,4,512,526,1,1,8192,0,8200,8202,1,1,526,8200,1,0,10,2,8193,11,1,0,1,1,527,1,4,0,1,512]

theorem envBound5967 : H12AffineFastState.Bounded env5967 := by
  intro p hp
  have h : env5967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5966_5967 : H12AffineEnvironment.transform 9 526 env5966 = env5967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 526 env5966 == env5967) = true)

def env5968 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,8121,1024,32768,4096,136,61877,41003,8329,61876,61240,16384,16812,22560,1285,0,256,20481,45064,61960]

theorem envBound5968 : H12AffineFastState.Bounded env5968 := by
  intro p hp
  have h : env5968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5957_5968 : H12AffineEnvironment.transform 17 8121 env5957 = env5968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8121 env5957 == env5968) = true)

theorem identity5968 : scanCanonicalize (H12AffineFastState.compose env5968 (packedSelected [0,1,3,4,7,9,11,17,21,24,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 28832) := by decide +kernel

theorem selectedBound5968 : packedSelected [0,1,3,4,7,9,11,17,21,24,28,32] rootPS < 2^1333 := by decide +kernel

def env5969 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,28832,8495,4525,8121,1024,28832,4096,136,277,20619,8329,276,8088,16384,16812,22560,1285,0,256,20481,16552,680]

theorem envBound5969 : H12AffineFastState.Bounded env5969 := by
  intro p hp
  have h : env5969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5968_5969 : H12AffineEnvironment.transform 14 28832 env5968 = env5969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28832 env5968 == env5969) = true)

theorem identity5969 : scanCanonicalize (H12AffineFastState.compose env5969 (packedSelected [1,3,4,9,13,18,20,21,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 1944) := by decide +kernel

theorem selectedBound5969 : packedSelected [1,3,4,9,13,18,20,21,23,24,28] rootPS < 2^1333 := by decide +kernel

def env5970 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,1944,14136,8495,4525,8121,1024,14136,4096,136,277,5907,8329,276,8088,1944,1588,8120,1285,0,256,6041,1840,680]

theorem envBound5970 : H12AffineFastState.Bounded env5970 := by
  intro p hp
  have h : env5970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5969_5970 : H12AffineEnvironment.transform 13 1944 env5969 = env5970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1944 env5969 == env5970) = true)

theorem identity5970 : scanCanonicalize (H12AffineFastState.compose env5970 (packedSelected [0,1,5,7,8,13,17,20,24] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound5970 : packedSelected [0,1,5,7,8,13,17,20,24] rootPS < 2^1333 := by decide +kernel

def env5971 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1692,8192,1944,8612,8495,1841,2341,1024,8612,1692,136,277,399,8329,276,2308,1944,1588,2340,1285,0,256,261,1840,680]

theorem envBound5971 : H12AffineFastState.Bounded env5971 := by
  intro p hp
  have h : env5971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5970_5971 : H12AffineEnvironment.transform 11 1692 env5970 = env5971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env5970 == env5971) = true)

theorem identity5971 : scanCanonicalize (H12AffineFastState.compose env5971 (packedSelected [0,2,3,6,7,8,10,13] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound5971 : packedSelected [0,2,3,6,7,8,10,13] rootPS < 2^1333 := by decide +kernel

def env5972 : List Nat := [2,4,8,16,32,16,128,62,512,1024,2048,1692,8192,1702,8346,8209,1551,2075,1024,8346,1692,136,43,177,8329,42,2106,1702,1588,2074,1083,0,62,59,1550,680]

theorem envBound5972 : H12AffineFastState.Bounded env5972 := by
  intro p hp
  have h : env5972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5971_5972 : H12AffineEnvironment.transform 7 62 env5971 = env5972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env5971 == env5972) = true)

theorem identity5972 : scanCanonicalize (H12AffineFastState.compose env5972 (packedSelected [0,2,3,4,5,6,11,12,17] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound5972 : packedSelected [0,2,3,4,5,6,11,12,17] rootPS < 2^1333 := by decide +kernel

def env5973 : List Nat := [2,4,8,16,32,16,18,62,512,1024,2048,1550,8192,1588,8200,8209,1551,2075,1024,8200,1550,26,43,35,8219,42,2106,1588,1588,2074,1083,0,62,59,1550,570]

theorem envBound5973 : H12AffineFastState.Bounded env5973 := by
  intro p hp
  have h : env5973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5972_5973 : H12AffineEnvironment.transform 6 18 env5972 = env5973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env5972 == env5973) = true)

theorem identity5973 : scanCanonicalize (H12AffineFastState.compose env5973 (packedSelected [1,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 2568) := by decide +kernel

theorem selectedBound5973 : packedSelected [1,4,5,7] rootPS < 2^1333 := by decide +kernel

def env5974 : List Nat := [2,4,8,16,32,16,18,62,512,1024,2048,1550,2568,1588,2560,2585,1551,2075,1024,2560,1550,26,43,35,2579,42,2106,1588,1588,2074,1083,0,62,59,1550,570]

theorem envBound5974 : H12AffineFastState.Bounded env5974 := by
  intro p hp
  have h : env5974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5973_5974 : H12AffineEnvironment.transform 12 2568 env5973 = env5974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2568 env5973 == env5974) = true)

theorem identity5974 : scanCanonicalize (H12AffineFastState.compose env5974 (packedSelected [0,1,2,3,4,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound5974 : packedSelected [0,1,2,3,4,10] rootPS < 2^1333 := by decide +kernel

def env5975 : List Nat := [2,4,8,1,32,1,3,47,512,1024,2048,1550,2568,1573,2560,2568,1551,2058,1024,2560,1550,11,43,35,2562,42,2091,1573,1573,2059,1066,0,47,42,1550,555]

theorem envBound5975 : H12AffineFastState.Bounded env5975 := by
  intro p hp
  have h : env5975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5974_5975 : H12AffineEnvironment.transform 3 1 env5974 = env5975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env5974 == env5975) = true)

def env5976 : List Nat := [2,4,8,1,32,1,3,47,512,1024,1572,1550,1068,1573,1060,1068,1551,1582,1024,1060,1550,11,43,35,1062,42,1551,1573,1573,1583,1066,0,47,42,1550,555]

theorem envBound5976 : H12AffineFastState.Bounded env5976 := by
  intro p hp
  have h : env5976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5975_5976 : H12AffineEnvironment.transform 10 1572 env5975 = env5976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env5975 == env5976) = true)

theorem identity5976 : scanCanonicalize (H12AffineFastState.compose env5976 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound5976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5977 : List Nat := [2,4,8,1,11,1,3,4,512,1024,1551,1550,1031,1550,1039,1031,1551,1541,1024,1039,1550,11,0,8,1037,1,1551,1550,1550,1540,1025,0,4,1,1550,512]

theorem envBound5977 : H12AffineFastState.Bounded env5977 := by
  intro p hp
  have h : env5977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5976_5977 : H12AffineEnvironment.transform 4 11 env5976 = env5977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env5976 == env5977) = true)

theorem identity5977 : scanCanonicalize (H12AffineFastState.compose env5977 (packedSelected [0,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5977 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env5978 : List Nat := [2,4,3,1,0,1,3,4,512,1024,1540,1541,1031,1541,1028,1031,1540,1541,1024,1028,1541,0,0,3,1030,1,1540,1541,1541,1540,1025,0,4,1,1541,512]

theorem envBound5978 : H12AffineFastState.Bounded env5978 := by
  intro p hp
  have h : env5978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5977_5978 : H12AffineEnvironment.transform 2 3 env5977 = env5978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5977 == env5978) = true)

theorem identity5978 : scanCanonicalize (H12AffineFastState.compose env5978 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound5978 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env5979 : List Nat := [2,4,3,1,0,1,3,4,0,1024,1028,1029,1031,1029,1028,1031,1028,1029,1024,1028,1029,0,0,3,1030,1,1028,1029,1029,1028,1025,0,4,1,1029,0]

theorem envBound5979 : H12AffineFastState.Bounded env5979 := by
  intro p hp
  have h : env5979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5978_5979 : H12AffineEnvironment.transform 8 0 env5978 = env5979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env5978 == env5979) = true)

theorem identity5979 : scanCanonicalize (H12AffineFastState.compose env5979 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound5979 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5980 : List Nat := [2,4,3,1,0,1,3,4,0,5,1,0,2,0,1,2,1,0,5,1,0,0,0,3,3,1,1,0,0,1,4,0,4,1,0,0]

theorem envBound5980 : H12AffineFastState.Bounded env5980 := by
  intro p hp
  have h : env5980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5979_5980 : H12AffineEnvironment.transform 9 5 env5979 = env5980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env5979 == env5980) = true)

def leafEnv5980 : List Nat := [2,4,3,1,0,1,3,4,0,5,1,0,2,0,1,2,1,0,5,1,0,0,0,3,4,3,1,1,1,0,0,1,4,0,4,1,4,2,0,0,1,1,0]

def active5980 : List Nat := [0,1]

def tree5980 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5980 : H12WitnessSearch.Good tree5980 := H12GlobalWitnessIndex.good

theorem leafIdentity5980 : H12AffineFastState.composeSystem env5980 rootObs = leafEnv5980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5980 rootObs == leafEnv5980) = true)

theorem terminalChecked5980 : H12PackedTerminal.terminalCheckFast leafEnv5980 active5980 tree5980 = true := by decide +kernel

def env5981 : List Nat := [2,4,8,1,32,1,3,47,512,1024,1573,1550,1069,1573,1061,1069,1551,1583,1024,1061,1550,11,43,35,1063,42,1550,1573,1573,1582,1066,0,47,42,1550,555]

theorem envBound5981 : H12AffineFastState.Bounded env5981 := by
  intro p hp
  have h : env5981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5975_5981 : H12AffineEnvironment.transform 10 1573 env5975 = env5981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env5975 == env5981) = true)

def env5982 : List Nat := [2,4,8,1,32,1,3,47,32,1024,1029,1070,1069,1029,1061,1069,1071,1039,1024,1061,1070,11,43,35,1063,42,1070,1029,1029,1038,1066,0,47,42,1070,11]

theorem envBound5982 : H12AffineFastState.Bounded env5982 := by
  intro p hp
  have h : env5982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5981_5982 : H12AffineEnvironment.transform 8 32 env5981 = env5982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env5981 == env5982) = true)

theorem identity5982 : scanCanonicalize (H12AffineFastState.compose env5982 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound5982 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5983 : List Nat := [2,4,8,1,32,1,3,47,32,15,10,33,34,10,42,34,32,0,15,42,33,11,43,35,40,42,33,10,10,1,37,0,47,42,33,11]

theorem envBound5983 : H12AffineFastState.Bounded env5983 := by
  intro p hp
  have h : env5983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5982_5983 : H12AffineEnvironment.transform 9 15 env5982 = env5983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env5982 == env5983) = true)

theorem identity5983 : scanCanonicalize (H12AffineFastState.compose env5983 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound5983 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5984 : List Nat := [2,4,3,1,32,1,3,36,32,4,1,33,34,1,33,34,32,0,4,33,33,0,32,35,35,33,33,1,1,1,37,0,36,33,33,0]

theorem envBound5984 : H12AffineFastState.Bounded env5984 := by
  intro p hp
  have h : env5984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5983_5984 : H12AffineEnvironment.transform 2 3 env5983 = env5984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env5983 == env5984) = true)

def env5985 : List Nat := [2,4,3,1,0,1,3,4,0,4,1,1,2,1,1,2,0,0,4,1,1,0,0,3,3,1,1,1,1,1,5,0,4,1,1,0]

theorem envBound5985 : H12AffineFastState.Bounded env5985 := by
  intro p hp
  have h : env5985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5984_5985 : H12AffineEnvironment.transform 4 0 env5984 = env5985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env5984 == env5985) = true)

def leafEnv5985 : List Nat := [2,4,3,1,0,1,3,4,0,4,1,1,2,1,1,2,0,0,4,1,1,0,0,3,5,3,1,1,1,1,1,1,5,0,4,1,4,2,1,0,1,0,0]

def active5985 : List Nat := [0,1]

def tree5985 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5985 : H12WitnessSearch.Good tree5985 := H12GlobalWitnessIndex.good

theorem leafIdentity5985 : H12AffineFastState.composeSystem env5985 rootObs = leafEnv5985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5985 rootObs == leafEnv5985) = true)

theorem terminalChecked5985 : H12PackedTerminal.terminalCheckFast leafEnv5985 active5985 tree5985 = true := by decide +kernel

def env5986 : List Nat := [2,4,3,1,1,1,3,5,1,4,1,0,3,1,0,3,1,0,4,0,0,0,1,2,2,0,0,1,1,1,4,0,5,0,0,0]

theorem envBound5986 : H12AffineFastState.Bounded env5986 := by
  intro p hp
  have h : env5986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5984_5986 : H12AffineEnvironment.transform 4 1 env5984 = env5986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env5984 == env5986) = true)

theorem identity5986 : scanCanonicalize (H12AffineFastState.compose env5986 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5987 : List Nat := [2,1,3,1,1,1,3,0,1,1,1,0,3,1,0,3,1,0,1,0,0,0,1,2,2,0,0,1,1,1,1,0,0,0,0,0]

theorem envBound5987 : H12AffineFastState.Bounded env5987 := by
  intro p hp
  have h : env5987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5986_5987 : H12AffineEnvironment.transform 1 1 env5986 = env5987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5986 == env5987) = true)

def leafEnv5987 : List Nat := [2,1,3,1,1,1,3,0,1,1,1,0,3,1,0,3,1,0,1,0,0,0,1,2,1,2,1,0,0,1,1,1,1,0,0,0,1,2,0,0,1,1,0]

def active5987 : List Nat := [0]

def tree5987 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5987 : H12WitnessSearch.Good tree5987 := H12GlobalWitnessIndex.good

theorem leafIdentity5987 : H12AffineFastState.composeSystem env5987 rootObs = leafEnv5987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5987 rootObs == leafEnv5987) = true)

theorem terminalChecked5987 : H12PackedTerminal.terminalCheckFast leafEnv5987 active5987 tree5987 = true := by decide +kernel

def env5988 : List Nat := [2,4,8,1,32,1,3,47,33,1024,1028,1071,1069,1028,1061,1069,1070,1038,1024,1061,1071,11,43,35,1063,42,1071,1028,1028,1039,1066,0,47,42,1071,10]

theorem envBound5988 : H12AffineFastState.Bounded env5988 := by
  intro p hp
  have h : env5988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5981_5988 : H12AffineEnvironment.transform 8 33 env5981 = env5988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env5981 == env5988) = true)

theorem identity5988 : scanCanonicalize (H12AffineFastState.compose env5988 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound5988 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env5989 : List Nat := [2,4,8,1,32,1,3,47,33,5,1,42,40,1,32,40,43,11,5,32,42,11,43,35,34,42,42,1,1,10,47,0,47,42,42,10]

theorem envBound5989 : H12AffineFastState.Bounded env5989 := by
  intro p hp
  have h : env5989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5988_5989 : H12AffineEnvironment.transform 9 5 env5988 = env5989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env5988 == env5989) = true)

theorem identity5989 : scanCanonicalize (H12AffineFastState.compose env5989 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound5989 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env5990 : List Nat := [2,4,8,1,10,1,3,5,11,5,1,0,2,1,10,2,1,11,5,10,0,11,1,9,8,0,0,1,1,10,5,0,5,0,0,10]

theorem envBound5990 : H12AffineFastState.Bounded env5990 := by
  intro p hp
  have h : env5990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5989_5990 : H12AffineEnvironment.transform 4 10 env5989 = env5990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env5989 == env5990) = true)

theorem identity5990 : scanCanonicalize (H12AffineFastState.compose env5990 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound5990 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env5991 : List Nat := [2,1,8,1,10,1,3,0,11,0,1,0,2,1,10,2,1,11,0,10,0,11,1,9,8,0,0,1,1,10,0,0,0,0,0,10]

theorem envBound5991 : H12AffineFastState.Bounded env5991 := by
  intro p hp
  have h : env5991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5990_5991 : H12AffineEnvironment.transform 1 1 env5990 = env5991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env5990 == env5991) = true)

theorem identity5991 : scanCanonicalize (H12AffineFastState.compose env5991 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound5991 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env5992 : List Nat := [2,1,2,1,0,1,3,0,1,0,1,0,2,1,0,2,1,1,0,0,0,1,1,3,2,0,0,1,1,0,0,0,0,0,0,0]

theorem envBound5992 : H12AffineFastState.Bounded env5992 := by
  intro p hp
  have h : env5992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5991_5992 : H12AffineEnvironment.transform 2 2 env5991 = env5992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env5991 == env5992) = true)

def leafEnv5992 : List Nat := [2,1,2,1,0,1,3,0,1,0,1,0,2,1,0,2,1,1,0,0,0,1,1,3,0,2,1,0,0,1,1,0,0,0,0,0,1,2,0,0,1,1,0]

def active5992 : List Nat := [0]

def tree5992 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood5992 : H12WitnessSearch.Good tree5992 := H12GlobalWitnessIndex.good

theorem leafIdentity5992 : H12AffineFastState.composeSystem env5992 rootObs = leafEnv5992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env5992 rootObs == leafEnv5992) = true)

theorem terminalChecked5992 : H12PackedTerminal.terminalCheckFast leafEnv5992 active5992 tree5992 = true := by decide +kernel

def env5993 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,137,8388608,41003,8329,8388609,323713,16384,16812,22560,1285,8450484,256,20481,45065,8389565]

theorem envBound5993 : H12AffineFastState.Bounded env5993 := by
  intro p hp
  have h : env5993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5955_5993 : H12AffineEnvironment.transform 21 137 env5955 = env5993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 137 env5955 == env5993) = true)

theorem identity5993 : scanCanonicalize (H12AffineFastState.compose env5993 (packedSelected [7,9,13,17,20,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 323488) := by decide +kernel

theorem selectedBound5993 : packedSelected [7,9,13,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env5994 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,262144,1024,32768,4096,137,323488,41003,8329,323489,323713,16384,16812,22560,1285,269844,256,20481,45065,322589]

theorem envBound5994 : H12AffineFastState.Bounded env5994 := by
  intro p hp
  have h : env5994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5993_5994 : H12AffineEnvironment.transform 22 323488 env5993 = env5994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 323488 env5993 == env5994) = true)

def env5995 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,7952,1024,32768,4096,137,61616,41003,8329,61617,61329,16384,16812,22560,1285,260,256,20481,45065,62221]

theorem envBound5995 : H12AffineFastState.Bounded env5995 := by
  intro p hp
  have h : env5995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5994_5995 : H12AffineEnvironment.transform 17 7952 env5994 = env5995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7952 env5994 == env5995) = true)

theorem identity5995 : scanCanonicalize (H12AffineFastState.compose env5995 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 8613) := by decide +kernel

theorem selectedBound5995 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env5996 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8613,8495,4525,7952,1024,8613,4096,137,20757,398,8329,20756,20020,16384,16812,22560,1285,260,256,20481,4524,21160]

theorem envBound5996 : H12AffineFastState.Bounded env5996 := by
  intro p hp
  have h : env5996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5995_5996 : H12AffineEnvironment.transform 14 8613 env5995 = env5996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8613 env5995 == env5996) = true)

theorem identity5996 : scanCanonicalize (H12AffineFastState.compose env5996 (packedSelected [2,11,18] rootPS)) = affineNative (2^(11+1) ^^^ 1676) := by decide +kernel

theorem selectedBound5996 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env5997 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1676,8192,16384,8613,8495,1825,2460,1024,8613,1676,137,18329,398,8329,18328,20020,16384,16812,20140,1285,260,256,18061,1824,17444]

theorem envBound5997 : H12AffineFastState.Bounded env5997 := by
  intro p hp
  have h : env5997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5996_5997 : H12AffineEnvironment.transform 11 1676 env5996 = env5997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1676 env5996 == env5997) = true)

theorem identity5997 : scanCanonicalize (H12AffineFastState.compose env5997 (packedSelected [9,17,21,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound5997 : packedSelected [9,17,21,22] rootPS < 2^1333 := by decide +kernel

def env5998 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1676,8192,16384,8352,8234,1572,2201,1024,8352,1676,137,18076,139,8329,18077,20020,16384,16553,20140,1024,1,5,18061,1573,17444]

theorem envBound5998 : H12AffineFastState.Bounded env5998 := by
  intro p hp
  have h : env5998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5997_5998 : H12AffineEnvironment.transform 7 5 env5997 = env5998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env5997 == env5998) = true)

theorem identity5998 : scanCanonicalize (H12AffineFastState.compose env5998 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 11397) := by decide +kernel

theorem selectedBound5998 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env5999 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1676,8192,11397,8352,8234,1572,2201,1024,8352,1676,137,10777,139,8329,10776,8881,11397,11308,8745,1024,1,5,10760,1573,10401]

theorem envBound5999 : H12AffineFastState.Bounded env5999 := by
  intro p hp
  have h : env5999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5998_5999 : H12AffineEnvironment.transform 13 11397 env5998 = env5999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11397 env5998 == env5999) = true)

theorem identity5999 : scanCanonicalize (H12AffineFastState.compose env5999 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 171) := by decide +kernel

theorem selectedBound5999 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6000 : List Nat := [2,4,8,16,32,16,128,5,512,1024,2048,1676,171,3118,11,129,1572,2201,1024,11,1676,137,2738,139,34,2739,538,3118,3207,642,1024,1,5,2723,1573,2058]

theorem envBound6000 : H12AffineFastState.Bounded env6000 := by
  intro p hp
  have h : env6000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5999_6000 : H12AffineEnvironment.transform 12 171 env5999 = env6000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 171 env5999 == env6000) = true)

theorem identity6000 : scanCanonicalize (H12AffineFastState.compose env6000 (packedSelected [1,3,7,9,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound6000 : packedSelected [1,3,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env6001 : List Nat := [2,4,8,16,32,16,128,5,512,1024,528,1676,171,1598,11,129,1572,649,1024,11,1676,137,162,139,34,163,538,1598,1687,642,1024,1,5,179,1573,538]

theorem envBound6001 : H12AffineFastState.Bounded env6001 := by
  intro p hp
  have h : env6001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6000_6001 : H12AffineEnvironment.transform 10 528 env6000 = env6001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env6000 == env6001) = true)

theorem identity6001 : scanCanonicalize (H12AffineFastState.compose env6001 (packedSelected [1,5,10,13] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound6001 : packedSelected [1,5,10,13] rootPS < 2^1333 := by decide +kernel

def env6002 : List Nat := [2,4,8,16,32,16,51,5,512,1024,528,1599,24,1598,11,50,1572,570,1024,11,1599,58,17,56,34,16,538,1598,1572,561,1024,1,5,0,1573,538]

theorem envBound6002 : H12AffineFastState.Bounded env6002 := by
  intro p hp
  have h : env6002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6001_6002 : H12AffineEnvironment.transform 6 51 env6001 = env6002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env6001 == env6002) = true)

theorem identity6002 : scanCanonicalize (H12AffineFastState.compose env6002 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound6002 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6003 : List Nat := [2,4,8,16,17,16,2,5,512,1024,528,1550,24,1551,11,3,1557,523,1024,11,1550,11,17,9,19,16,538,1551,1557,512,1024,1,5,0,1556,538]

theorem envBound6003 : H12AffineFastState.Bounded env6003 := by
  intro p hp
  have h : env6003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6002_6003 : H12AffineEnvironment.transform 4 17 env6002 = env6003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env6002 == env6003) = true)

theorem identity6003 : scanCanonicalize (H12AffineFastState.compose env6003 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound6003 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6004 : List Nat := [2,4,8,0,1,0,2,5,512,1024,512,1550,8,1551,11,3,1541,523,1024,11,1550,11,1,9,3,0,522,1551,1541,512,1024,1,5,0,1540,522]

theorem envBound6004 : H12AffineFastState.Bounded env6004 := by
  intro p hp
  have h : env6004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6003_6004 : H12AffineEnvironment.transform 3 0 env6003 = env6004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6003 == env6004) = true)

theorem identity6004 : scanCanonicalize (H12AffineFastState.compose env6004 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6004 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env6005 : List Nat := [2,4,8,0,1,0,2,5,1,1024,1,1039,8,1038,11,3,1028,10,1024,11,1039,11,1,9,3,0,11,1038,1028,1,1024,1,5,0,1029,11]

theorem envBound6005 : H12AffineFastState.Bounded env6005 := by
  intro p hp
  have h : env6005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6004_6005 : H12AffineEnvironment.transform 8 1 env6004 = env6005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6004 == env6005) = true)

theorem identity6005 : scanCanonicalize (H12AffineFastState.compose env6005 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6005 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6006 : List Nat := [2,4,3,0,1,0,2,5,1,1024,1,1028,3,1029,0,3,1028,1,1024,0,1028,0,1,2,3,0,0,1029,1028,1,1024,1,5,0,1029,0]

theorem envBound6006 : H12AffineFastState.Bounded env6006 := by
  intro p hp
  have h : env6006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6005_6006 : H12AffineEnvironment.transform 2 3 env6005 = env6006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6005 == env6006) = true)

theorem identity6006 : scanCanonicalize (H12AffineFastState.compose env6006 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound6006 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6007 : List Nat := [2,4,3,0,1,0,2,5,1,1,1,5,3,4,0,3,5,1,1,0,5,0,1,2,3,0,0,4,5,1,1,1,5,0,4,0]

theorem envBound6007 : H12AffineFastState.Bounded env6007 := by
  intro p hp
  have h : env6007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6006_6007 : H12AffineEnvironment.transform 9 1 env6006 = env6007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env6006 == env6007) = true)

def env6008 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8495,4525,7953,1024,32768,4096,137,61617,41003,8329,61616,61328,16384,16812,22560,1285,261,256,20481,45065,62220]

theorem envBound6008 : H12AffineFastState.Bounded env6008 := by
  intro p hp
  have h : env6008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5994_6008 : H12AffineEnvironment.transform 17 7953 env5994 = env6008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7953 env5994 == env6008) = true)

theorem identity6008 : scanCanonicalize (H12AffineFastState.compose env6008 (packedSelected [2,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 28681) := by decide +kernel

theorem selectedBound6008 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env6009 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,28681,8495,4525,7953,1024,28681,4096,137,184,20514,8329,185,8089,16384,16812,22560,1285,261,256,20481,16384,773]

theorem envBound6009 : H12AffineFastState.Bounded env6009 := by
  intro p hp
  have h : env6009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6008_6009 : H12AffineEnvironment.transform 14 28681 env6008 = env6009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28681 env6008 == env6009) = true)

theorem identity6009 : scanCanonicalize (H12AffineFastState.compose env6009 (packedSelected [6,17,21] rootPS)) = affineNative (2^(11+1) ^^^ 2194) := by decide +kernel

theorem selectedBound6009 : packedSelected [6,17,21] rootPS < 2^1333 := by decide +kernel

def env6010 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2194,8192,16384,26779,8495,2367,1923,1024,26779,2194,137,184,18608,8329,185,1803,16384,16812,16562,1285,261,256,18579,16384,773]

theorem envBound6010 : H12AffineFastState.Bounded env6010 := by
  intro p hp
  have h : env6010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6009_6010 : H12AffineEnvironment.transform 11 2194 env6009 = env6010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2194 env6009 == env6010) = true)

theorem identity6010 : scanCanonicalize (H12AffineFastState.compose env6010 (packedSelected [1,2,5,6,8,11,18,24] rootPS)) = affineNative (2^(13+1) ^^^ 1840) := by decide +kernel

theorem selectedBound6010 : packedSelected [1,2,5,6,8,11,18,24] rootPS < 2^1333 := by decide +kernel

def env6011 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2194,8192,1840,12203,8495,2367,1923,1024,12203,2194,137,184,3968,8329,185,1803,1840,1692,1922,1285,261,256,4003,1840,773]

theorem envBound6011 : H12AffineFastState.Bounded env6011 := by
  intro p hp
  have h : env6011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6010_6011 : H12AffineEnvironment.transform 13 1840 env6010 = env6011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1840 env6010 == env6011) = true)

theorem identity6011 : scanCanonicalize (H12AffineFastState.compose env6011 (packedSelected [3,5,6,10,12,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound6011 : packedSelected [3,5,6,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env6012 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1702,1588,8192,1840,8461,8495,1945,1923,1024,8461,1588,137,184,294,8329,185,1803,1840,1692,1922,1285,261,256,261,1840,773]

theorem envBound6012 : H12AffineFastState.Bounded env6012 := by
  intro p hp
  have h : env6012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6011_6012 : H12AffineEnvironment.transform 10 1702 env6011 = env6012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env6011 == env6012) = true)

theorem identity6012 : scanCanonicalize (H12AffineFastState.compose env6012 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6012 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6013 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1551,1588,8192,1840,8461,8495,1840,1834,1024,8461,1588,32,17,294,8224,16,1803,1840,1589,1835,1285,261,256,261,1840,773]

theorem envBound6013 : H12AffineFastState.Bounded env6013 := by
  intro p hp
  have h : env6013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6012_6013 : H12AffineEnvironment.transform 6 41 env6012 = env6013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6012 == env6013) = true)

theorem identity6013 : scanCanonicalize (H12AffineFastState.compose env6013 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 1030) := by decide +kernel

theorem selectedBound6013 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env6014 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1551,1588,1030,1840,1291,1321,1840,1834,1024,1291,1588,32,17,294,1062,16,1803,1840,1589,1835,1285,261,256,261,1840,773]

theorem envBound6014 : H12AffineFastState.Bounded env6014 := by
  intro p hp
  have h : env6014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6013_6014 : H12AffineEnvironment.transform 12 1030 env6013 = env6014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1030 env6013 == env6014) = true)

theorem identity6014 : scanCanonicalize (H12AffineFastState.compose env6014 (packedSelected [3,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6014 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env6015 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1551,1588,1030,1589,1038,1068,1589,1583,1024,1038,1588,32,17,35,1062,16,1550,1589,1589,1582,1024,0,5,0,1589,512]

theorem envBound6015 : H12AffineFastState.Bounded env6015 := by
  intro p hp
  have h : env6015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6014_6015 : H12AffineEnvironment.transform 7 5 env6014 = env6015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6014 == env6015) = true)

theorem identity6015 : scanCanonicalize (H12AffineFastState.compose env6015 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound6015 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6016 : List Nat := [2,4,8,16,32,16,41,5,0,1024,1039,1076,1030,1077,1038,1068,1077,1071,1024,1038,1076,32,17,35,1062,16,1038,1077,1077,1070,1024,0,5,0,1077,0]

theorem envBound6016 : H12AffineFastState.Bounded env6016 := by
  intro p hp
  have h : env6016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6015_6016 : H12AffineEnvironment.transform 8 0 env6015 = env6016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6015 == env6016) = true)

theorem identity6016 : scanCanonicalize (H12AffineFastState.compose env6016 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound6016 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6017 : List Nat := [2,4,8,16,32,16,41,5,0,21,26,33,19,32,27,57,32,58,21,27,33,32,17,35,51,16,27,32,32,59,21,0,5,0,32,0]

theorem envBound6017 : H12AffineFastState.Bounded env6017 := by
  intro p hp
  have h : env6017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6016_6017 : H12AffineEnvironment.transform 9 21 env6016 = env6017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env6016 == env6017) = true)

theorem identity6017 : scanCanonicalize (H12AffineFastState.compose env6017 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6017 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6018 : List Nat := [2,4,8,11,32,11,41,5,0,14,1,33,8,32,0,34,32,33,14,0,33,32,10,35,40,11,0,32,32,32,14,0,5,0,32,0]

theorem envBound6018 : H12AffineFastState.Bounded env6018 := by
  intro p hp
  have h : env6018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6017_6018 : H12AffineEnvironment.transform 3 11 env6017 = env6018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6017 == env6018) = true)

def env6019 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,4194304,8388608,41003,8329,8388608,323712,16384,16813,22561,1285,12644669,256,20480,4239488,8389564]

theorem envBound6019 : H12AffineFastState.Bounded env6019 := by
  intro p hp
  have h : env6019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5954_6019 : H12AffineEnvironment.transform 5 17 env5954 = env6019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env5954 == env6019) = true)

theorem identity6019 : scanCanonicalize (H12AffineFastState.compose env6019 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound6019 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6020 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,4194304,444,41003,8329,444,323712,16384,16813,22561,1285,4255873,256,20480,4239488,512]

theorem envBound6020 : H12AffineFastState.Bounded env6020 := by
  intro p hp
  have h : env6020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6019_6020 : H12AffineEnvironment.transform 22 444 env6019 = env6020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env6019 == env6020) = true)

theorem identity6020 : scanCanonicalize (H12AffineFastState.compose env6020 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound6020 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6021 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,41348,444,41003,8329,444,323712,16384,16813,22561,1285,20741,256,20480,4356,512]

theorem envBound6021 : H12AffineFastState.Bounded env6021 := by
  intro p hp
  have h : env6021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6020_6021 : H12AffineEnvironment.transform 21 41348 env6020 = env6021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env6020 == env6021) = true)

theorem identity6021 : scanCanonicalize (H12AffineFastState.compose env6021 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6021 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6022 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1024,26261,4096,18193,444,18110,8329,444,267797,16384,16813,22561,1285,20741,256,20480,4356,512]

theorem envBound6022 : H12AffineFastState.Bounded env6022 := by
  intro p hp
  have h : env6022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6021_6022 : H12AffineEnvironment.transform 14 26261 env6021 = env6022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6021 == env6022) = true)

theorem identity6022 : scanCanonicalize (H12AffineFastState.compose env6022 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound6022 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6023 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,262144,1024,14137,4096,5821,444,5906,8329,444,267797,4524,4097,2445,1285,169,256,428,4356,512]

theorem envBound6023 : H12AffineFastState.Bounded env6023 := by
  intro p hp
  have h : env6023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6022_6023 : H12AffineEnvironment.transform 13 4524 env6022 = env6023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env6022 == env6023) = true)

theorem identity6023 : scanCanonicalize (H12AffineFastState.compose env6023 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6023 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6024 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,2185,1024,14137,4096,5821,444,5906,8329,444,7836,4524,4097,2445,1285,169,256,428,4356,512]

theorem envBound6024 : H12AffineFastState.Bounded env6024 := by
  intro p hp
  have h : env6024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6023_6024 : H12AffineEnvironment.transform 17 2185 env6023 = env6024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6023 == env6024) = true)

theorem identity6024 : scanCanonicalize (H12AffineFastState.compose env6024 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6024 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env6025 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,13972,8322,4097,2185,1024,13972,4096,5821,17,5823,8329,17,7836,4097,4097,2080,1192,169,173,1,4265,512]

theorem envBound6025 : H12AffineFastState.Bounded env6025 := by
  intro p hp
  have h : env6025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6024_6025 : H12AffineEnvironment.transform 7 173 env6024 = env6025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6024 == env6025) = true)

theorem identity6025 : scanCanonicalize (H12AffineFastState.compose env6025 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 675) := by decide +kernel

theorem selectedBound6025 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6026 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,4096,8192,4097,13972,8322,4097,554,1024,13972,4096,5821,17,5823,8329,17,5183,4097,4097,643,1192,169,173,1,4265,512]

theorem envBound6026 : H12AffineFastState.Bounded env6026 := by
  intro p hp
  have h : env6026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6025_6026 : H12AffineEnvironment.transform 10 675 env6025 = env6026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 675 env6025 == env6026) = true)

theorem identity6026 : scanCanonicalize (H12AffineFastState.compose env6026 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound6026 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6027 : List Nat := [2,4,8,16,32,17,128,173,512,1024,675,1693,8192,1692,8201,8322,1692,554,1024,8201,1693,32,17,34,8329,17,674,1692,1692,643,1192,169,173,1,1588,512]

theorem envBound6027 : H12AffineFastState.Bounded env6027 := by
  intro p hp
  have h : env6027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6026_6027 : H12AffineEnvironment.transform 11 1693 env6026 = env6027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env6026 == env6027) = true)

theorem identity6027 : scanCanonicalize (H12AffineFastState.compose env6027 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6027 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6028 : List Nat := [2,4,8,16,32,17,41,4,512,1024,522,1588,8192,1589,8201,8235,1589,554,1024,8201,1588,32,17,34,8224,17,523,1589,1589,554,1025,0,4,1,1588,512]

theorem envBound6028 : H12AffineFastState.Bounded env6028 := by
  intro p hp
  have h : env6028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6027_6028 : H12AffineEnvironment.transform 6 41 env6027 = env6028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6027 == env6028) = true)

theorem identity6028 : scanCanonicalize (H12AffineFastState.compose env6028 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound6028 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6029 : List Nat := [2,4,8,16,32,17,41,4,512,1024,522,1588,51,1589,58,24,1589,554,1024,58,1588,32,17,34,19,17,523,1589,1589,554,1025,0,4,1,1588,512]

theorem envBound6029 : H12AffineFastState.Bounded env6029 := by
  intro p hp
  have h : env6029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6028_6029 : H12AffineEnvironment.transform 12 51 env6028 = env6029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env6028 == env6029) = true)

theorem identity6029 : scanCanonicalize (H12AffineFastState.compose env6029 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound6029 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6030 : List Nat := [2,4,8,16,17,17,24,4,512,1024,522,1541,2,1540,11,24,1540,539,1024,11,1541,17,17,19,19,17,523,1540,1540,539,1025,0,4,1,1541,512]

theorem envBound6030 : H12AffineFastState.Bounded env6030 := by
  intro p hp
  have h : env6030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6029_6030 : H12AffineEnvironment.transform 4 17 env6029 = env6030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env6029 == env6030) = true)

theorem identity6030 : scanCanonicalize (H12AffineFastState.compose env6030 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6030 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6031 : List Nat := [2,4,8,1,0,0,9,4,512,1024,522,1541,2,1540,11,9,1540,522,1024,11,1541,0,0,2,2,0,523,1540,1540,522,1025,0,4,1,1541,512]

theorem envBound6031 : H12AffineFastState.Bounded env6031 := by
  intro p hp
  have h : env6031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6030_6031 : H12AffineEnvironment.transform 3 1 env6030 = env6031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6030 == env6031) = true)

theorem identity6031 : scanCanonicalize (H12AffineFastState.compose env6031 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound6031 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6032 : List Nat := [2,4,8,1,0,0,9,4,10,1024,0,1039,2,1038,11,9,1038,0,1024,11,1039,0,0,2,2,0,1,1038,1038,0,1025,0,4,1,1039,10]

theorem envBound6032 : H12AffineFastState.Bounded env6032 := by
  intro p hp
  have h : env6032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6031_6032 : H12AffineEnvironment.transform 8 10 env6031 = env6032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env6031 == env6032) = true)

theorem identity6032 : scanCanonicalize (H12AffineFastState.compose env6032 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6032 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6033 : List Nat := [2,4,2,1,0,0,3,4,0,1024,0,1029,2,1028,1,3,1028,0,1024,1,1029,0,0,2,2,0,1,1028,1028,0,1025,0,4,1,1029,0]

theorem envBound6033 : H12AffineFastState.Bounded env6033 := by
  intro p hp
  have h : env6033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6032_6033 : H12AffineEnvironment.transform 2 2 env6032 = env6033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6032 == env6033) = true)

def leafEnv6033 : List Nat := [2,4,2,1,0,0,3,4,0,1024,0,1029,2,1028,1,3,1028,0,1024,1,1029,0,0,2,1025,2,1,0,1,1028,1028,0,1025,0,4,1,4,2,1029,0,1,1029,0]

def active6033 : List Nat := [0,1,9]

def tree6033 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6033 : H12WitnessSearch.Good tree6033 := H12GlobalWitnessIndex.good

theorem leafIdentity6033 : H12AffineFastState.composeSystem env6033 rootObs = leafEnv6033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6033 rootObs == leafEnv6033) = true)

theorem terminalChecked6033 : H12PackedTerminal.terminalCheckFast leafEnv6033 active6033 tree6033 = true := by decide +kernel

def env6034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323792,16384,16892,22641,74795,12644669,257,20560,4239488,8389612]

theorem envBound6034 : H12AffineFastState.Bounded env6034 := by
  intro p hp
  have h : env6034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5952_6034 : H12AffineEnvironment.transform 18 1025 env5952 = env6034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env5952 == env6034) = true)

theorem identity6034 : scanCanonicalize (H12AffineFastState.compose env6034 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 91183) := by decide +kernel

theorem selectedBound6034 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,91183,41003,8329,91263,323792,16384,16892,22641,74795,4298002,257,20560,4239488,92099]

theorem envBound6035 : H12AffineFastState.Bounded env6035 := by
  intro p hp
  have h : env6035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6034_6035 : H12AffineEnvironment.transform 22 91183 env6034 = env6035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 91183 env6034 == env6035) = true)

def env6036 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,91183,41003,8329,91183,323712,16384,16812,22561,74795,4298002,257,20480,4239488,92051]

theorem envBound6036 : H12AffineFastState.Bounded env6036 := by
  intro p hp
  have h : env6036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6035_6036 : H12AffineEnvironment.transform 5 16 env6035 = env6036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6035 == env6036) = true)

theorem identity6036 : scanCanonicalize (H12AffineFastState.compose env6036 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 26003) := by decide +kernel

theorem selectedBound6036 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6037 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,4194304,444,41003,8329,444,323712,16384,16812,22561,16824,4255873,257,20480,4239488,512]

theorem envBound6037 : H12AffineFastState.Bounded env6037 := by
  intro p hp
  have h : env6037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6036_6037 : H12AffineEnvironment.transform 15 26003 env6036 = env6037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26003 env6036 == env6037) = true)

theorem identity6037 : scanCanonicalize (H12AffineFastState.compose env6037 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound6037 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6038 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,41349,444,41003,8329,444,323712,16384,16812,22561,16824,20740,257,20480,4357,512]

theorem envBound6038 : H12AffineFastState.Bounded env6038 := by
  intro p hp
  have h : env6038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6037_6038 : H12AffineEnvironment.transform 21 41349 env6037 = env6038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env6037 == env6038) = true)

theorem identity6038 : scanCanonicalize (H12AffineFastState.compose env6038 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6038 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6039 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26003,4525,262144,1025,26260,4096,18193,444,18111,8329,444,267796,16384,16812,22561,16824,20740,257,20480,4357,512]

theorem envBound6039 : H12AffineFastState.Bounded env6039 := by
  intro p hp
  have h : env6039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6038_6039 : H12AffineEnvironment.transform 14 26260 env6038 = env6039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6038 == env6039) = true)

theorem identity6039 : scanCanonicalize (H12AffineFastState.compose env6039 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound6039 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6040 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,262144,1025,26260,1296,18193,444,18111,8329,444,262916,16384,16812,19761,16824,17428,257,17680,1045,512]

theorem envBound6040 : H12AffineFastState.Bounded env6040 := by
  intro p hp
  have h : env6040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6039_6040 : H12AffineEnvironment.transform 11 1296 env6039 = env6040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env6039 == env6040) = true)

theorem identity6040 : scanCanonicalize (H12AffineFastState.compose env6040 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6040 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env6041 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,2341,1025,26260,1296,18193,444,18111,8329,444,2593,16384,16812,19761,16824,17428,257,17680,1045,512]

theorem envBound6041 : H12AffineFastState.Bounded env6041 := by
  intro p hp
  have h : env6041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6040_6041 : H12AffineEnvironment.transform 17 2341 env6040 = env6041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6040 == env6041) = true)

def env6042 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,91183,41003,8329,91182,323713,16384,16813,22560,74795,4298002,257,20481,4239488,92050]

theorem envBound6042 : H12AffineFastState.Bounded env6042 := by
  intro p hp
  have h : env6042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6035_6042 : H12AffineEnvironment.transform 5 17 env6035 = env6042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6035 == env6042) = true)

def env6043 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,46392,91183,41003,8329,91182,323713,16384,16813,22560,74795,73770,257,20481,1464,92050]

theorem envBound6043 : H12AffineFastState.Bounded env6043 := by
  intro p hp
  have h : env6043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6042_6043 : H12AffineEnvironment.transform 21 46392 env6042 = env6043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46392 env6042 == env6043) = true)

theorem identity6043 : scanCanonicalize (H12AffineFastState.compose env6043 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6043 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6044 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4096,46392,91183,41003,8225,91182,323625,16384,16645,22560,74795,73770,257,20481,1296,91962]

theorem envBound6044 : H12AffineFastState.Bounded env6044 := by
  intro p hp
  have h : env6044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6043_6044 : H12AffineEnvironment.transform 6 40 env6043 = env6044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6043 == env6044) = true)

theorem identity6044 : scanCanonicalize (H12AffineFastState.compose env6044 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6044 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6045 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8200,65536,4356,262144,1025,8200,4096,5424,91183,35,8225,91182,282657,16384,16645,22560,74795,73770,257,20481,1296,91962]

theorem envBound6045 : H12AffineFastState.Bounded env6045 := by
  intro p hp
  have h : env6045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6044_6045 : H12AffineEnvironment.transform 14 8200 env6044 = env6045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6044 == env6045) = true)

theorem identity6045 : scanCanonicalize (H12AffineFastState.compose env6045 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound6045 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6046 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8200,65536,4356,2081,1025,8200,4096,5424,91183,35,8225,91182,22528,16384,16645,22560,74795,73770,257,20481,1296,91962]

theorem envBound6046 : H12AffineFastState.Bounded env6046 := by
  intro p hp
  have h : env6046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6045_6046 : H12AffineEnvironment.transform 17 2081 env6045 = env6046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env6045 == env6046) = true)

theorem identity6046 : scanCanonicalize (H12AffineFastState.compose env6046 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound6046 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env6047 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,4129,8200,65536,4356,2081,1025,8200,4096,5424,78862,35,8225,78863,2081,4129,4388,2049,74795,73770,257,32,1296,79643]

theorem envBound6047 : H12AffineFastState.Bounded env6047 := by
  intro p hp
  have h : env6047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6046_6047 : H12AffineEnvironment.transform 13 4129 env6046 = env6047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env6046 == env6047) = true)

theorem identity6047 : scanCanonicalize (H12AffineFastState.compose env6047 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound6047 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6048 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,2089,4129,2081,65536,4356,2081,1025,2081,4096,5424,72743,35,2056,72742,2081,4129,4388,2049,68610,67587,257,32,1296,73522]

theorem envBound6048 : H12AffineFastState.Bounded env6048 := by
  intro p hp
  have h : env6048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6047_6048 : H12AffineEnvironment.transform 12 2089 env6047 = env6048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env6047 == env6048) = true)

theorem identity6048 : scanCanonicalize (H12AffineFastState.compose env6048 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1808) := by decide +kernel

theorem selectedBound6048 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env6049 : List Nat := [2,4,8,16,32,17,40,256,512,1024,1808,4096,1849,4129,1841,65536,4356,1841,1025,1841,4096,5424,70455,35,1816,70454,1841,4129,4388,1809,66322,67347,257,32,1296,69666]

theorem envBound6049 : H12AffineFastState.Bounded env6049 := by
  intro p hp
  have h : env6049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6048_6049 : H12AffineEnvironment.transform 10 1808 env6048 = env6049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1808 env6048 == env6049) = true)

theorem identity6049 : scanCanonicalize (H12AffineFastState.compose env6049 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6049 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env6050 : List Nat := [2,4,8,16,32,17,40,5,512,1024,1557,4096,1596,4129,1588,65536,4097,1588,1025,1588,4096,5173,70194,35,1565,70195,1588,4129,4129,1556,66071,67094,4,32,1045,69666]

theorem envBound6050 : H12AffineFastState.Bounded env6050 := by
  intro p hp
  have h : env6050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6049_6050 : H12AffineEnvironment.transform 7 5 env6049 = env6050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6049 == env6050) = true)

theorem identity6050 : scanCanonicalize (H12AffineFastState.compose env6050 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6050 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6051 : List Nat := [2,4,8,16,26,17,18,5,512,1024,1557,4096,1542,4123,1550,65536,4097,1550,1025,1550,4096,5135,70152,25,1565,70153,1550,4123,4123,1556,66071,67094,4,26,1045,69656]

theorem envBound6051 : H12AffineFastState.Bounded env6051 := by
  intro p hp
  have h : env6051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6050_6051 : H12AffineEnvironment.transform 4 26 env6050 = env6051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6050 == env6051) = true)

theorem identity6051 : scanCanonicalize (H12AffineFastState.compose env6051 (packedSelected [10,15] rootPS)) = affineNative (2^(15+1) ^^^ 1548) := by decide +kernel

theorem selectedBound6051 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env6052 : List Nat := [2,4,8,16,26,17,18,5,512,1024,1557,4096,1542,4123,1550,1548,4097,1550,1025,1550,4096,5135,5124,25,1565,5125,1550,4123,4123,1556,1051,26,4,26,1045,5652]

theorem envBound6052 : H12AffineFastState.Bounded env6052 := by
  intro p hp
  have h : env6052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6051_6052 : H12AffineEnvironment.transform 15 1548 env6051 = env6052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1548 env6051 == env6052) = true)

def env6053 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,46393,91183,41003,8329,91182,323713,16384,16813,22560,74795,73771,257,20481,1465,92050]

theorem envBound6053 : H12AffineFastState.Bounded env6053 := by
  intro p hp
  have h : env6053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6042_6053 : H12AffineEnvironment.transform 21 46393 env6042 = env6053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 46393 env6042 == env6053) = true)

theorem identity6053 : scanCanonicalize (H12AffineFastState.compose env6053 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(15+1) ^^^ 38298) := by decide +kernel

theorem selectedBound6053 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6054 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,38298,4524,262144,1025,32768,4096,46393,61877,41003,8329,61876,323713,16384,16813,22560,45489,46513,257,20481,1465,61960]

theorem envBound6054 : H12AffineFastState.Bounded env6054 := by
  intro p hp
  have h : env6054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6053_6054 : H12AffineEnvironment.transform 15 38298 env6053 = env6054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38298 env6053 == env6054) = true)

theorem identity6054 : scanCanonicalize (H12AffineFastState.compose env6054 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 63545) := by decide +kernel

theorem selectedBound6054 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6055 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,38298,4524,63545,1025,32768,4096,46393,61877,41003,8329,61876,2232,16384,16813,22560,45489,46513,257,20481,1465,61960]

theorem envBound6055 : H12AffineFastState.Bounded env6055 := by
  intro p hp
  have h : env6055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6054_6055 : H12AffineEnvironment.transform 17 63545 env6054 = env6055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 63545 env6054 == env6055) = true)

theorem identity6055 : scanCanonicalize (H12AffineFastState.compose env6055 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(11+1) ^^^ 1213) := by decide +kernel

theorem selectedBound6055 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6056 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,32768,33063,1297,60548,1025,32768,1213,41348,58632,41003,8329,58633,2232,16384,16813,19613,42252,41228,257,17596,1465,59061]

theorem envBound6056 : H12AffineFastState.Bounded env6056 := by
  intro p hp
  have h : env6056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6055_6056 : H12AffineEnvironment.transform 11 1213 env6055 = env6056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1213 env6055 == env6056) = true)

theorem identity6056 : scanCanonicalize (H12AffineFastState.compose env6056 (packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 28351) := by decide +kernel

theorem selectedBound6056 : packedSelected [0,1,3,6,7,13,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env6057 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1213,8192,16384,28351,28568,1297,571,1025,28351,1213,20283,2999,20116,8329,2998,2232,16384,16813,19613,19379,20403,257,17596,1465,2058]

theorem envBound6057 : H12AffineFastState.Bounded env6057 := by
  intro p hp
  have h : env6057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6056_6057 : H12AffineEnvironment.transform 14 28351 env6056 = env6057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28351 env6056 == env6057) = true)

theorem identity6057 : scanCanonicalize (H12AffineFastState.compose env6057 (packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound6057 : packedSelected [0,1,5,6,7,8,10,17,20,21,24,31] rootPS < 2^1333 := by decide +kernel

def env6058 : List Nat := [2,4,8,16,32,17,128,256,512,1024,522,1213,8192,16384,25781,26002,1297,571,1025,25781,1213,17713,445,17566,8329,444,690,16384,16813,18071,16825,17849,257,17596,1465,512]

theorem envBound6058 : H12AffineFastState.Bounded env6058 := by
  intro p hp
  have h : env6058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6057_6058 : H12AffineEnvironment.transform 10 522 env6057 = env6058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env6057 == env6058) = true)

theorem identity6058 : scanCanonicalize (H12AffineFastState.compose env6058 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6058 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6059 : List Nat := [2,4,8,16,32,17,128,173,512,1024,522,1213,8192,16384,25781,25663,1212,571,1025,25781,1213,17564,16,17566,8329,17,690,16384,16384,18071,16404,17428,172,17596,1044,512]

theorem envBound6059 : H12AffineFastState.Bounded env6059 := by
  intro p hp
  have h : env6059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6058_6059 : H12AffineEnvironment.transform 7 173 env6058 = env6059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6058 == env6059) = true)

theorem identity6059 : scanCanonicalize (H12AffineFastState.compose env6059 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound6059 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env6060 : List Nat := [2,4,8,16,32,17,128,173,137,1024,131,1213,8192,16384,25781,25663,1212,178,1025,25781,1213,17564,16,17566,8329,17,59,16384,16384,17438,16404,17428,172,17596,1044,137]

theorem envBound6060 : H12AffineFastState.Bounded env6060 := by
  intro p hp
  have h : env6060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6059_6060 : H12AffineEnvironment.transform 8 137 env6059 = env6060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env6059 == env6060) = true)

theorem identity6060 : scanCanonicalize (H12AffineFastState.compose env6060 (packedSelected [0,7,20] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6060 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6061 : List Nat := [2,4,8,16,32,17,40,5,33,1024,43,1045,8192,16384,25629,25663,1044,26,1025,25629,1045,17460,16,17462,8225,17,59,16384,16384,17438,16404,17428,4,17428,1044,33]

theorem envBound6061 : H12AffineFastState.Bounded env6061 := by
  intro p hp
  have h : env6061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6060_6061 : H12AffineEnvironment.transform 6 40 env6060 = env6061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6060 == env6061) = true)

theorem identity6061 : scanCanonicalize (H12AffineFastState.compose env6061 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound6061 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6062 : List Nat := [2,4,8,16,32,17,40,5,33,1024,43,1045,8192,1029,8216,8250,1044,26,1025,8216,1045,49,16,51,8225,17,59,1029,1029,27,1041,17,4,17,1044,33]

theorem envBound6062 : H12AffineFastState.Bounded env6062 := by
  intro p hp
  have h : env6062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6061_6062 : H12AffineEnvironment.transform 13 1029 env6061 = env6062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env6061 == env6062) = true)

theorem identity6062 : scanCanonicalize (H12AffineFastState.compose env6062 (packedSelected [0,1,2,3,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6062 : packedSelected [0,1,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6063 : List Nat := [2,4,3,16,32,17,35,5,33,1024,32,1045,8192,1029,8211,8241,1044,17,1025,8211,1045,49,16,51,8225,17,48,1029,1029,16,1041,17,4,17,1044,33]

theorem envBound6063 : H12AffineFastState.Bounded env6063 := by
  intro p hp
  have h : env6063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6062_6063 : H12AffineEnvironment.transform 2 3 env6062 = env6063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6062 == env6063) = true)

theorem identity6063 : scanCanonicalize (H12AffineFastState.compose env6063 (packedSelected [0,1,4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound6063 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env6064 : List Nat := [2,4,3,16,32,17,35,5,33,20,32,1,8192,17,8211,8241,0,17,21,8211,1,49,16,51,8225,17,48,17,17,16,5,17,4,17,0,33]

theorem envBound6064 : H12AffineFastState.Bounded env6064 := by
  intro p hp
  have h : env6064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6063_6064 : H12AffineEnvironment.transform 9 20 env6063 = env6064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env6063 == env6064) = true)

theorem identity6064 : scanCanonicalize (H12AffineFastState.compose env6064 (packedSelected [2,3] rootPS)) = affineNative (2^(12+1) ^^^ 18) := by decide +kernel

theorem selectedBound6064 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env6065 : List Nat := [2,4,3,16,32,17,35,5,33,20,32,1,18,17,1,35,0,17,21,1,1,49,16,51,51,17,48,17,17,16,5,17,4,17,0,33]

theorem envBound6065 : H12AffineFastState.Bounded env6065 := by
  intro p hp
  have h : env6065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6064_6065 : H12AffineEnvironment.transform 12 18 env6064 = env6065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 18 env6064 == env6065) = true)

theorem identity6065 : scanCanonicalize (H12AffineFastState.compose env6065 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6065 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6066 : List Nat := [2,4,3,1,32,0,35,5,33,5,32,1,3,0,1,35,0,0,4,1,1,32,1,34,34,0,33,0,0,1,5,0,4,0,0,33]

theorem envBound6066 : H12AffineFastState.Bounded env6066 := by
  intro p hp
  have h : env6066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6065_6066 : H12AffineEnvironment.transform 3 1 env6065 = env6066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6065 == env6066) = true)

def env6067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849104,16384,16892,547953,598058,12644668,525568,545872,4239489,8914925]

theorem envBound6067 : H12AffineFastState.Bounded env6067 := by
  intro p hp
  have h : env6067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5951_6067 : H12AffineEnvironment.transform 20 4097 env5951 = env6067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env5951 == env6067) = true)

def env6068 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323792,16384,16892,22641,74794,12644668,256,20560,4239489,8389613]

theorem envBound6068 : H12AffineFastState.Bounded env6068 := by
  intro p hp
  have h : env6068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6067_6068 : H12AffineEnvironment.transform 18 1024 env6067 = env6068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6067 == env6068) = true)

theorem identity6068 : scanCanonicalize (H12AffineFastState.compose env6068 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4293054) := by decide +kernel

theorem selectedBound6068 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6069 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,4293054,41003,8329,4293103,323792,16384,16892,22641,74794,94338,256,20560,4239489,4293203]

theorem envBound6069 : H12AffineFastState.Bounded env6069 := by
  intro p hp
  have h : env6069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6068_6069 : H12AffineEnvironment.transform 22 4293054 env6068 = env6069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4293054 env6068 == env6069) = true)

def env6070 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,4194304,4293054,41003,8329,4293055,323712,16384,16812,22561,74794,94338,256,20480,4239489,4293123]

theorem envBound6070 : H12AffineFastState.Bounded env6070 := by
  intro p hp
  have h : env6070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6069_6070 : H12AffineEnvironment.transform 5 16 env6069 = env6070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6069 == env6070) = true)

theorem identity6070 : scanCanonicalize (H12AffineFastState.compose env6070 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 98307) := by decide +kernel

theorem selectedBound6070 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6071 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,98307,445,41003,8329,444,323712,16384,16812,22561,74794,94338,256,20480,77954,512]

theorem envBound6071 : H12AffineFastState.Bounded env6071 := by
  intro p hp
  have h : env6071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6070_6071 : H12AffineEnvironment.transform 21 98307 env6070 = env6071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98307 env6070 == env6071) = true)

theorem identity6071 : scanCanonicalize (H12AffineFastState.compose env6071 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound6071 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6072 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4525,262144,1024,32768,4097,41349,445,41003,8329,444,323712,16384,16812,22561,1452,20740,256,20480,4356,512]

theorem envBound6072 : H12AffineFastState.Bounded env6072 := by
  intro p hp
  have h : env6072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6071_6072 : H12AffineEnvironment.transform 15 8582 env6071 = env6072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env6071 == env6072) = true)

theorem identity6072 : scanCanonicalize (H12AffineFastState.compose env6072 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6072 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6073 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8582,4525,262144,1024,26260,4097,18193,445,18111,8329,444,267796,16384,16812,22561,1452,20740,256,20480,4356,512]

theorem envBound6073 : H12AffineFastState.Bounded env6073 := by
  intro p hp
  have h : env6073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6072_6073 : H12AffineEnvironment.transform 14 26260 env6072 = env6073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6072 == env6073) = true)

theorem identity6073 : scanCanonicalize (H12AffineFastState.compose env6073 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound6073 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6074 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,14225,8582,4525,262144,1024,14225,4097,5652,445,6074,8329,444,267796,4357,4265,2340,1452,1,256,261,4356,512]

theorem envBound6074 : H12AffineFastState.Bounded env6074 := by
  intro p hp
  have h : env6074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6073_6074 : H12AffineEnvironment.transform 13 4357 env6073 = env6074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env6073 == env6074) = true)

def env6075 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,4194304,4293054,41003,8329,4293054,323713,16384,16813,22560,74794,94338,256,20481,4239489,4293122]

theorem envBound6075 : H12AffineFastState.Bounded env6075 := by
  intro p hp
  have h : env6075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6069_6075 : H12AffineEnvironment.transform 5 17 env6069 = env6075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6069 == env6075) = true)

def env6076 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,65536,4524,262144,1024,32768,4097,4194304,4293054,41003,8329,4293054,303145,4264,4357,2184,74794,73770,256,169,4239489,4293122]

theorem envBound6076 : H12AffineFastState.Bounded env6076 := by
  intro p hp
  have h : env6076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6075_6076 : H12AffineEnvironment.transform 13 4264 env6075 = env6076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4264 env6075 == env6076) = true)

theorem identity6076 : scanCanonicalize (H12AffineFastState.compose env6076 (packedSelected [2,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 33167) := by decide +kernel

theorem selectedBound6076 : packedSelected [2,23,32] rootPS < 2^1333 := by decide +kernel

def env6077 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33167,4524,262144,1024,32768,4097,4194304,4194353,41003,8329,4194353,303145,4264,4357,2184,42405,41381,256,169,4239489,4195213]

theorem envBound6077 : H12AffineFastState.Bounded env6077 := by
  intro p hp
  have h : env6077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6076_6077 : H12AffineEnvironment.transform 15 33167 env6076 = env6077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33167 env6076 == env6077) = true)

theorem identity6077 : scanCanonicalize (H12AffineFastState.compose env6077 (packedSelected [0,2,6,7,11,17,18,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 1923) := by decide +kernel

theorem selectedBound6077 : packedSelected [0,2,6,7,11,17,18,20,21] rootPS < 2^1333 := by decide +kernel

def env6078 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33167,4524,1923,1024,32768,4097,4194304,4194353,41003,8329,4194353,42922,4264,4357,2184,42405,41381,256,169,4239489,4195213]

theorem envBound6078 : H12AffineFastState.Bounded env6078 := by
  intro p hp
  have h : env6078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6077_6078 : H12AffineEnvironment.transform 17 1923 env6077 = env6078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1923 env6077 == env6078) = true)

def env6079 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33167,4524,1923,1024,32768,4097,41088,41137,41003,8329,41137,42922,4264,4357,2184,42405,41381,256,169,4097,41741]

theorem envBound6079 : H12AffineFastState.Bounded env6079 := by
  intro p hp
  have h : env6079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6078_6079 : H12AffineEnvironment.transform 21 41088 env6078 = env6079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env6078 == env6079) = true)

theorem identity6079 : scanCanonicalize (H12AffineFastState.compose env6079 (packedSelected [13,17] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound6079 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6080 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1551,4096,8192,4264,32768,33167,4524,1923,1024,32768,4097,41088,41137,41003,8329,41137,42922,4264,4357,1671,42405,41381,256,169,4097,41741]

theorem envBound6080 : H12AffineFastState.Bounded env6080 := by
  intro p hp
  have h : env6080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6079_6080 : H12AffineEnvironment.transform 10 1551 env6079 = env6080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env6079 == env6080) = true)

theorem identity6080 : scanCanonicalize (H12AffineFastState.compose env6080 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 14225) := by decide +kernel

theorem selectedBound6080 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env6081 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1551,4096,8192,4264,14225,13854,4524,1923,1024,14225,4097,5905,5920,6074,8329,5920,4155,4264,4357,1671,4660,5684,256,169,4097,5276]

theorem envBound6081 : H12AffineFastState.Bounded env6081 := by
  intro p hp
  have h : env6081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6080_6081 : H12AffineEnvironment.transform 14 14225 env6080 = env6081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 14225 env6080 == env6081) = true)

theorem identity6081 : scanCanonicalize (H12AffineFastState.compose env6081 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 1945) := by decide +kernel

theorem selectedBound6081 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env6082 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1551,1945,8192,1841,8200,8583,1589,1923,1024,8200,1944,136,185,35,8329,185,1954,1841,1692,1671,1453,429,256,169,1944,773]

theorem envBound6082 : H12AffineFastState.Bounded env6082 := by
  intro p hp
  have h : env6082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6081_6082 : H12AffineEnvironment.transform 11 1945 env6081 = env6082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1945 env6081 == env6082) = true)

theorem identity6082 : scanCanonicalize (H12AffineFastState.compose env6082 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6082 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6083 : List Nat := [2,4,8,16,32,17,41,256,512,1024,1551,1840,8192,1841,8200,8494,1589,1834,1024,8200,1841,33,16,35,8224,16,1803,1841,1589,1582,1284,260,256,0,1841,773]

theorem envBound6083 : H12AffineFastState.Bounded env6083 := by
  intro p hp
  have h : env6083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6082_6083 : H12AffineEnvironment.transform 6 41 env6082 = env6083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6082 == env6083) = true)

theorem identity6083 : scanCanonicalize (H12AffineFastState.compose env6083 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6083 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6084 : List Nat := [2,4,8,16,27,17,18,256,512,1024,1551,1803,8192,1802,8200,8469,1550,1809,1024,8200,1802,26,16,24,8219,16,1803,1802,1550,1557,1284,260,256,0,1802,773]

theorem envBound6084 : H12AffineFastState.Bounded env6084 := by
  intro p hp
  have h : env6084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6083_6084 : H12AffineEnvironment.transform 4 27 env6083 = env6084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6083 == env6084) = true)

theorem identity6084 : scanCanonicalize (H12AffineFastState.compose env6084 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound6084 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6085 : List Nat := [2,4,8,16,27,17,18,256,512,1024,1551,1803,1053,1802,1045,1288,1550,1809,1024,1045,1802,26,16,24,1030,16,1803,1802,1550,1557,1284,260,256,0,1802,773]

theorem envBound6085 : H12AffineFastState.Bounded env6085 := by
  intro p hp
  have h : env6085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6084_6085 : H12AffineEnvironment.transform 12 1053 env6084 = env6085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env6084 == env6085) = true)

theorem identity6085 : scanCanonicalize (H12AffineFastState.compose env6085 (packedSelected [2,11,23] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6085 : packedSelected [2,11,23] rootPS < 2^1333 := by decide +kernel

def env6086 : List Nat := [2,4,8,16,27,17,18,4,512,1024,1551,1551,1053,1550,1045,1036,1550,1557,1024,1045,1550,26,16,24,1030,16,1551,1550,1550,1557,1024,0,4,0,1550,513]

theorem envBound6086 : H12AffineFastState.Bounded env6086 := by
  intro p hp
  have h : env6086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6085_6086 : H12AffineEnvironment.transform 7 4 env6085 = env6086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6085 == env6086) = true)

theorem identity6086 : scanCanonicalize (H12AffineFastState.compose env6086 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound6086 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6087 : List Nat := [2,4,8,16,27,17,18,4,20,1024,1051,1051,1053,1050,1045,1036,1050,1025,1024,1045,1050,26,16,24,1030,16,1051,1050,1050,1025,1024,0,4,0,1050,21]

theorem envBound6087 : H12AffineFastState.Bounded env6087 := by
  intro p hp
  have h : env6087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6086_6087 : H12AffineEnvironment.transform 8 20 env6086 = env6087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env6086 == env6087) = true)

theorem identity6087 : scanCanonicalize (H12AffineFastState.compose env6087 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6087 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6088 : List Nat := [2,4,8,1,10,0,3,4,5,1024,1034,1034,1036,1035,1028,1036,1035,1025,1024,1028,1035,11,1,9,1030,1,1034,1035,1035,1025,1024,0,4,0,1035,4]

theorem envBound6088 : H12AffineFastState.Bounded env6088 := by
  intro p hp
  have h : env6088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6087_6088 : H12AffineEnvironment.transform 3 1 env6087 = env6088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6087 == env6088) = true)

theorem identity6088 : scanCanonicalize (H12AffineFastState.compose env6088 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6088 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6089 : List Nat := [2,0,8,1,10,0,3,0,1,1024,1034,1034,1032,1035,1024,1032,1035,1025,1024,1024,1035,11,1,9,1026,1,1034,1035,1035,1025,1024,0,0,0,1035,0]

theorem envBound6089 : H12AffineFastState.Bounded env6089 := by
  intro p hp
  have h : env6089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6088_6089 : H12AffineEnvironment.transform 1 0 env6088 = env6089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6088 == env6089) = true)

theorem identity6089 : scanCanonicalize (H12AffineFastState.compose env6089 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound6089 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6090 : List Nat := [2,0,8,1,10,0,3,0,1,10,0,0,2,1,10,2,1,11,10,10,1,11,1,9,8,1,0,1,1,11,10,0,0,0,1,0]

theorem envBound6090 : H12AffineFastState.Bounded env6090 := by
  intro p hp
  have h : env6090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6089_6090 : H12AffineEnvironment.transform 9 10 env6089 = env6090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env6089 == env6090) = true)

def leafEnv6090 : List Nat := [2,0,8,1,10,0,3,0,1,10,0,0,2,1,10,2,1,11,10,10,1,11,1,9,10,8,1,1,0,1,1,11,10,0,0,0,0,8,1,0,1,1,0]

def active6090 : List Nat := [0,2]

def tree6090 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6090 : H12WitnessSearch.Good tree6090 := H12GlobalWitnessIndex.good

theorem leafIdentity6090 : H12AffineFastState.composeSystem env6090 rootObs = leafEnv6090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6090 rootObs == leafEnv6090) = true)

theorem terminalChecked6090 : H12PackedTerminal.terminalCheckFast leafEnv6090 active6090 tree6090 = true := by decide +kernel

def env6091 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,32768,33167,4524,1923,1024,32768,4097,41089,41136,41003,8329,41136,42922,4264,4357,2184,42405,41381,256,169,4096,41740]

theorem envBound6091 : H12AffineFastState.Bounded env6091 := by
  intro p hp
  have h : env6091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6078_6091 : H12AffineEnvironment.transform 21 41089 env6078 = env6091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env6078 == env6091) = true)

theorem identity6091 : scanCanonicalize (H12AffineFastState.compose env6091 (packedSelected [13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11950) := by decide +kernel

theorem selectedBound6091 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6092 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4264,11950,12065,4524,1923,1024,11950,4097,3631,3614,3717,8329,3614,2308,4264,4357,2184,2827,3851,256,169,4096,3490]

theorem envBound6092 : H12AffineFastState.Bounded env6092 := by
  intro p hp
  have h : env6092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6091_6092 : H12AffineEnvironment.transform 14 11950 env6091 = env6092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11950 env6091 == env6092) = true)

theorem identity6092 : scanCanonicalize (H12AffineFastState.compose env6092 (packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound6092 : packedSelected [0,2,3,4,5,7,9,10,11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env6093 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1692,8192,1588,11950,12065,1840,1923,1024,11950,1693,3631,3614,3717,8329,3614,2308,1588,1945,2184,2827,3851,256,169,1692,3490]

theorem envBound6093 : H12AffineFastState.Bounded env6093 := by
  intro p hp
  have h : env6093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6092_6093 : H12AffineEnvironment.transform 11 1692 env6092 = env6093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env6092 == env6093) = true)

theorem identity6093 : scanCanonicalize (H12AffineFastState.compose env6093 (packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6093 : packedSelected [3,4,5,6,9,10,12,13,15,20] rootPS < 2^1333 := by decide +kernel

def env6094 : List Nat := [2,4,8,16,32,17,128,4,512,1024,2048,1692,8192,1588,11950,11813,1588,1671,1024,11950,1693,3631,3614,3717,8329,3614,2048,1588,1693,2184,2575,3599,4,169,1692,3238]

theorem envBound6094 : H12AffineFastState.Bounded env6094 := by
  intro p hp
  have h : env6094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6093_6094 : H12AffineEnvironment.transform 7 4 env6093 = env6094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6093 == env6094) = true)

theorem identity6094 : scanCanonicalize (H12AffineFastState.compose env6094 (packedSelected [3,5,10,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound6094 : packedSelected [3,5,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6095 : List Nat := [2,4,8,16,32,17,128,4,512,1024,1551,1692,8192,1588,8353,8234,1588,1671,1024,8353,1693,32,17,138,8329,17,1551,1588,1693,1671,1024,0,4,169,1692,681]

theorem envBound6095 : H12AffineFastState.Bounded env6095 := by
  intro p hp
  have h : env6095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6094_6095 : H12AffineEnvironment.transform 10 1551 env6094 = env6095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env6094 == env6095) = true)

theorem identity6095 : scanCanonicalize (H12AffineFastState.compose env6095 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6095 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6096 : List Nat := [2,4,8,10,32,11,128,4,512,1024,1551,1670,8192,1582,8353,8234,1582,1671,1024,8353,1671,32,11,138,8329,11,1551,1582,1671,1671,1024,0,4,169,1670,681]

theorem envBound6096 : H12AffineFastState.Bounded env6096 := by
  intro p hp
  have h : env6096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6095_6096 : H12AffineEnvironment.transform 3 10 env6095 = env6096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6095 == env6096) = true)

theorem identity6096 : scanCanonicalize (H12AffineFastState.compose env6096 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1166) := by decide +kernel

theorem selectedBound6096 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env6097 : List Nat := [2,4,8,10,32,11,128,4,512,1024,1551,1670,1166,1582,1071,1188,1582,1671,1024,1071,1671,32,11,138,1031,11,1551,1582,1671,1671,1024,0,4,169,1670,681]

theorem envBound6097 : H12AffineFastState.Bounded env6097 := by
  intro p hp
  have h : env6097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6096_6097 : H12AffineEnvironment.transform 12 1166 env6096 = env6097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1166 env6096 == env6097) = true)

theorem identity6097 : scanCanonicalize (H12AffineFastState.compose env6097 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6097 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6098 : List Nat := [2,4,8,10,32,11,41,4,512,1024,1551,1583,1063,1582,1071,1037,1582,1582,1024,1071,1582,32,11,35,1031,11,1551,1582,1582,1582,1024,0,4,0,1583,512]

theorem envBound6098 : H12AffineFastState.Bounded env6098 := by
  intro p hp
  have h : env6098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6097_6098 : H12AffineEnvironment.transform 6 41 env6097 = env6098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6097 == env6098) = true)

def env6099 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,4194304,4293054,41003,8329,4293054,303144,4265,4356,2185,74794,73771,256,168,4239489,4293122]

theorem envBound6099 : H12AffineFastState.Bounded env6099 := by
  intro p hp
  have h : env6099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6075_6099 : H12AffineEnvironment.transform 13 4265 env6075 = env6099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env6075 == env6099) = true)

theorem identity6099 : scanCanonicalize (H12AffineFastState.compose env6099 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 73891) := by decide +kernel

theorem selectedBound6099 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6100 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,262144,1024,32768,4097,73891,41245,41003,8329,41245,303144,4265,4356,2185,74794,73771,256,168,102434,41633]

theorem envBound6100 : H12AffineFastState.Bounded env6100 := by
  intro p hp
  have h : env6100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6099_6100 : H12AffineEnvironment.transform 21 73891 env6099 = env6100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73891 env6099 == env6100) = true)

theorem identity6100 : scanCanonicalize (H12AffineFastState.compose env6100 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 75954) := by decide +kernel

theorem selectedBound6100 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6101 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,65536,4524,75954,1024,32768,4097,73891,41245,41003,8329,41245,100506,4265,4356,2185,74794,73771,256,168,102434,41633]

theorem envBound6101 : H12AffineFastState.Bounded env6101 := by
  intro p hp
  have h : env6101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6100_6101 : H12AffineEnvironment.transform 17 75954 env6100 = env6101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 75954 env6100 == env6101) = true)

theorem identity6101 : scanCanonicalize (H12AffineFastState.compose env6101 (packedSelected [3,4,5,9,10,13,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound6101 : packedSelected [3,4,5,9,10,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6102 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,32768,8495,4524,2461,1024,32768,4097,396,41245,41003,8329,41245,43445,4265,4356,2185,1285,260,256,168,45325,41633]

theorem envBound6102 : H12AffineFastState.Bounded env6102 := by
  intro p hp
  have h : env6102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6101_6102 : H12AffineEnvironment.transform 15 8495 env6101 = env6102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env6101 == env6102) = true)

theorem identity6102 : scanCanonicalize (H12AffineFastState.compose env6102 (packedSelected [0,3,4,5,6,7,9,10,13,17] rootPS)) = affineNative (2^(14+1) ^^^ 11030) := by decide +kernel

theorem selectedBound6102 : packedSelected [0,3,4,5,6,7,9,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6103 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4265,11030,8495,4524,2461,1024,11030,4097,396,2571,2877,8329,2571,675,4265,4356,2185,1285,260,256,168,6683,2487]

theorem envBound6103 : H12AffineFastState.Bounded env6103 := by
  intro p hp
  have h : env6103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6102_6103 : H12AffineEnvironment.transform 14 11030 env6102 = env6103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11030 env6102 == env6103) = true)

theorem identity6103 : scanCanonicalize (H12AffineFastState.compose env6103 (packedSelected [0,3,4,5,6,7,9,10,13,21] rootPS)) = affineNative (2^(10+1) ^^^ 782) := by decide +kernel

theorem selectedBound6103 : packedSelected [0,3,4,5,6,7,9,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6104 : List Nat := [2,4,8,16,32,17,128,256,512,1024,782,4096,8192,4265,8216,8495,4524,659,1024,8216,4097,396,261,51,8329,261,675,4265,4356,903,1285,260,256,168,4373,697]

theorem envBound6104 : H12AffineFastState.Bounded env6104 := by
  intro p hp
  have h : env6104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6103_6104 : H12AffineEnvironment.transform 10 782 env6103 = env6104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 782 env6103 == env6104) = true)

theorem identity6104 : scanCanonicalize (H12AffineFastState.compose env6104 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound6104 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6105 : List Nat := [2,4,8,16,32,17,128,188,512,1024,690,4096,8192,4265,8216,8339,4112,659,1024,8216,4097,48,185,51,8329,185,675,4265,4280,571,1209,184,188,168,4265,697]

theorem envBound6105 : H12AffineFastState.Bounded env6105 := by
  intro p hp
  have h : env6105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6104_6105 : H12AffineEnvironment.transform 7 188 env6104 = env6105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env6104 == env6105) = true)

theorem identity6105 : scanCanonicalize (H12AffineFastState.compose env6105 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 1693) := by decide +kernel

theorem selectedBound6105 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6106 : List Nat := [2,4,8,16,32,17,128,188,512,1024,690,1693,8192,1588,8216,8339,1677,659,1024,8216,1692,48,185,51,8329,185,675,1588,1573,571,1209,184,188,168,1588,697]

theorem envBound6106 : H12AffineFastState.Bounded env6106 := by
  intro p hp
  have h : env6106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6105_6106 : H12AffineEnvironment.transform 11 1693 env6105 = env6106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1693 env6105 == env6106) = true)

theorem identity6106 : scanCanonicalize (H12AffineFastState.compose env6106 (packedSelected [0,3,5,7,11,13] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound6106 : packedSelected [0,3,5,7,11,13] rootPS < 2^1333 := by decide +kernel

def env6107 : List Nat := [2,4,8,16,32,17,128,188,512,542,690,131,8192,42,8216,8339,147,659,542,8216,130,48,185,51,8329,185,675,42,59,571,679,184,188,168,42,697]

theorem envBound6107 : H12AffineFastState.Bounded env6107 := by
  intro p hp
  have h : env6107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6106_6107 : H12AffineEnvironment.transform 9 542 env6106 = env6107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env6106 == env6107) = true)

theorem identity6107 : scanCanonicalize (H12AffineFastState.compose env6107 (packedSelected [3,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 177) := by decide +kernel

theorem selectedBound6107 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env6108 : List Nat := [2,4,8,16,32,17,128,188,512,542,690,131,177,42,169,34,147,659,542,169,130,48,185,51,56,185,675,42,59,571,679,184,188,168,42,697]

theorem envBound6108 : H12AffineFastState.Bounded env6108 := by
  intro p hp
  have h : env6108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6107_6108 : H12AffineEnvironment.transform 12 177 env6107 = env6108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 177 env6107 == env6108) = true)

theorem identity6108 : scanCanonicalize (H12AffineFastState.compose env6108 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound6108 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6109 : List Nat := [2,4,8,16,32,17,51,15,512,542,513,48,2,42,26,34,32,544,542,26,49,48,10,51,56,10,528,42,59,571,532,11,15,27,42,522]

theorem envBound6109 : H12AffineFastState.Bounded env6109 := by
  intro p hp
  have h : env6109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6108_6109 : H12AffineEnvironment.transform 6 51 env6108 = env6109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env6108 == env6109) = true)

theorem identity6109 : scanCanonicalize (H12AffineFastState.compose env6109 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound6109 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env6110 : List Nat := [2,4,8,16,32,17,51,15,49,47,48,48,2,42,26,34,32,17,47,26,49,48,10,51,56,10,33,42,59,10,37,11,15,27,42,59]

theorem envBound6110 : H12AffineFastState.Bounded env6110 := by
  intro p hp
  have h : env6110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6109_6110 : H12AffineEnvironment.transform 8 49 env6109 = env6110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env6109 == env6110) = true)

theorem identity6110 : scanCanonicalize (H12AffineFastState.compose env6110 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6110 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env6111 : List Nat := [2,4,8,16,27,17,8,15,10,20,11,11,2,17,26,25,27,17,20,26,10,11,10,8,3,10,26,17,0,10,30,11,15,27,17,0]

theorem envBound6111 : H12AffineFastState.Bounded env6111 := by
  intro p hp
  have h : env6111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6110_6111 : H12AffineEnvironment.transform 4 27 env6110 = env6111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6110 == env6111) = true)

theorem identity6111 : scanCanonicalize (H12AffineFastState.compose env6111 (packedSelected [0,1,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6111 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env6112 : List Nat := [2,4,2,16,17,17,2,5,0,20,1,1,2,17,16,19,17,17,20,16,0,1,0,2,3,0,16,17,0,0,20,1,5,17,17,0]

theorem envBound6112 : H12AffineFastState.Bounded env6112 := by
  intro p hp
  have h : env6112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6111_6112 : H12AffineEnvironment.transform 2 2 env6111 = env6112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6111 == env6112) = true)

theorem identity6112 : scanCanonicalize (H12AffineFastState.compose env6112 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6112 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6113 : List Nat := [2,4,2,1,0,0,2,5,0,5,1,1,2,0,1,2,0,0,5,1,0,1,0,2,3,0,1,0,0,0,5,1,5,0,0,0]

theorem envBound6113 : H12AffineFastState.Bounded env6113 := by
  intro p hp
  have h : env6113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6112_6113 : H12AffineEnvironment.transform 3 1 env6112 = env6113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6112 == env6113) = true)

def env6114 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323793,16384,16892,22640,74795,12644668,257,20561,4239489,8389612]

theorem envBound6114 : H12AffineFastState.Bounded env6114 := by
  intro p hp
  have h : env6114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6067_6114 : H12AffineEnvironment.transform 18 1025 env6067 = env6114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6067 == env6114) = true)

theorem identity6114 : scanCanonicalize (H12AffineFastState.compose env6114 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 115903) := by decide +kernel

theorem selectedBound6114 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6115 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,115903,8388608,41003,8329,8388688,323793,16384,16892,22640,74795,8467843,257,20561,95294,8389612]

theorem envBound6115 : H12AffineFastState.Bounded env6115 := by
  intro p hp
  have h : env6115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6114_6115 : H12AffineEnvironment.transform 21 115903 env6114 = env6115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115903 env6114 == env6115) = true)

def env6116 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,115903,8388608,41003,8329,8388608,323713,16384,16812,22560,74795,8467843,257,20481,95294,8389564]

theorem envBound6116 : H12AffineFastState.Bounded env6116 := by
  intro p hp
  have h : env6116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6115_6116 : H12AffineEnvironment.transform 5 16 env6115 = env6116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6115 == env6116) = true)

def env6117 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,115903,5544,41003,8329,5544,323713,16384,16812,22560,74795,73771,257,20481,95294,5652]

theorem envBound6117 : H12AffineFastState.Bounded env6117 := by
  intro p hp
  have h : env6117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6116_6117 : H12AffineEnvironment.transform 22 5544 env6116 = env6117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5544 env6116 == env6117) = true)

theorem identity6117 : scanCanonicalize (H12AffineFastState.compose env6117 (packedSelected [0,7,9,13,20,21,22] rootPS)) = affineNative (2^(14+1) ^^^ 25628) := by decide +kernel

theorem selectedBound6117 : packedSelected [0,7,9,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env6118 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25628,65536,4525,262144,1025,25628,4097,73891,5544,17463,8329,5544,267421,16384,16812,22560,74795,73771,257,20481,95294,5652]

theorem envBound6118 : H12AffineFastState.Bounded env6118 := by
  intro p hp
  have h : env6118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6117_6118 : H12AffineEnvironment.transform 14 25628 env6117 = env6118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 25628 env6117 == env6118) = true)

theorem identity6118 : scanCanonicalize (H12AffineFastState.compose env6118 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 7204) := by decide +kernel

theorem selectedBound6118 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6119 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25628,65536,4525,7204,1025,25628,4097,73891,5544,17463,8329,5544,2233,16384,16812,22560,74795,73771,257,20481,95294,5652]

theorem envBound6119 : H12AffineFastState.Bounded env6119 := by
  intro p hp
  have h : env6119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6118_6119 : H12AffineEnvironment.transform 17 7204 env6118 = env6119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 7204 env6118 == env6119) = true)

theorem identity6119 : scanCanonicalize (H12AffineFastState.compose env6119 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound6119 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6120 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,25628,25914,4525,7204,1025,25628,4097,17817,5544,17463,8329,5544,2233,16384,16812,22560,16657,17681,257,20481,4356,5652]

theorem envBound6120 : H12AffineFastState.Bounded env6120 := by
  intro p hp
  have h : env6120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6119_6120 : H12AffineEnvironment.transform 15 25914 env6119 = env6120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env6119 == env6120) = true)

theorem identity6120 : scanCanonicalize (H12AffineFastState.compose env6120 (packedSelected [0,1,5,7,10,12,15,17,20,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound6120 : packedSelected [0,1,5,7,10,12,15,17,20,21] rootPS < 2^1333 := by decide +kernel

def env6121 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1465,8192,16384,25628,25914,1044,2461,1025,25628,1464,17817,17,17463,8329,17,2233,16384,16812,19865,16657,17681,257,17848,1213,941]

theorem envBound6121 : H12AffineFastState.Bounded env6121 := by
  intro p hp
  have h : env6121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6120_6121 : H12AffineEnvironment.transform 11 1465 env6120 = env6121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env6120 == env6121) = true)

theorem identity6121 : scanCanonicalize (H12AffineFastState.compose env6121 (packedSelected [1,5,10,12,13,15,17] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound6121 : packedSelected [1,5,10,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env6122 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1465,8192,16384,25628,25914,1044,2461,1025,25628,1464,17817,17,17463,8329,17,2233,16384,16812,19865,16657,17681,257,17848,1213,137]

theorem envBound6122 : H12AffineFastState.Bounded env6122 := by
  intro p hp
  have h : env6122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6121_6122 : H12AffineEnvironment.transform 8 292 env6121 = env6122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env6121 == env6122) = true)

theorem identity6122 : scanCanonicalize (H12AffineFastState.compose env6122 (packedSelected [0,1,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 3222) := by decide +kernel

theorem selectedBound6122 : packedSelected [0,1,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env6123 : List Nat := [2,4,8,16,32,16,128,256,292,1024,2048,1465,8192,3222,10378,10668,1044,2461,1025,10378,1464,2319,17,2209,8329,17,2233,3222,3386,271,3463,2439,257,2350,1213,137]

theorem envBound6123 : H12AffineFastState.Bounded env6123 := by
  intro p hp
  have h : env6123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6122_6123 : H12AffineEnvironment.transform 13 3222 env6122 = env6123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3222 env6122 == env6123) = true)

theorem identity6123 : scanCanonicalize (H12AffineFastState.compose env6123 (packedSelected [0,2,4,6,7,9,11,23] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6123 : packedSelected [0,2,4,6,7,9,11,23] rootPS < 2^1333 := by decide +kernel

def env6124 : List Nat := [2,4,8,1,32,1,128,256,292,1024,2048,1448,8192,3207,10378,10668,1029,2444,1025,10378,1449,2319,0,2209,8329,0,2216,3207,3371,271,3463,2439,257,2350,1196,137]

theorem envBound6124 : H12AffineFastState.Bounded env6124 := by
  intro p hp
  have h : env6124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6123_6124 : H12AffineEnvironment.transform 3 1 env6123 = env6124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6123 == env6124) = true)

theorem identity6124 : scanCanonicalize (H12AffineFastState.compose env6124 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6124 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6125 : List Nat := [2,4,8,1,32,1,128,172,136,1024,2048,1028,8192,3207,10378,10240,1029,2080,1025,10378,1029,2211,0,2209,8329,0,2216,3207,3207,163,3115,2091,173,2178,1196,137]

theorem envBound6125 : H12AffineFastState.Bounded env6125 := by
  intro p hp
  have h : env6125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6124_6125 : H12AffineEnvironment.transform 7 172 env6124 = env6125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6124 == env6125) = true)

theorem identity6125 : scanCanonicalize (H12AffineFastState.compose env6125 (packedSelected [0,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 166) := by decide +kernel

theorem selectedBound6125 : packedSelected [0,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env6126 : List Nat := [2,4,8,1,32,1,128,172,136,1024,166,1028,8192,1057,8236,8358,1029,134,1025,8236,1029,5,0,7,8329,0,14,1057,1057,163,1165,141,173,36,1196,137]

theorem envBound6126 : H12AffineFastState.Bounded env6126 := by
  intro p hp
  have h : env6126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6125_6126 : H12AffineEnvironment.transform 10 166 env6125 = env6126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 166 env6125 == env6126) = true)

theorem identity6126 : scanCanonicalize (H12AffineFastState.compose env6126 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound6126 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6127 : List Nat := [2,4,8,1,5,1,128,137,136,1024,131,1028,8192,1028,8201,8323,1029,134,1025,8201,1029,5,0,7,8329,0,14,1028,1028,134,1165,141,136,1,1161,137]

theorem envBound6127 : H12AffineFastState.Bounded env6127 := by
  intro p hp
  have h : env6127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6126_6127 : H12AffineEnvironment.transform 4 5 env6126 = env6127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env6126 == env6127) = true)

theorem identity6127 : scanCanonicalize (H12AffineFastState.compose env6127 (packedSelected [1,2] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound6127 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env6128 : List Nat := [2,4,8,1,5,1,7,14,15,1024,4,1028,8192,1028,8201,8196,1029,1,1025,8201,1029,5,0,7,8206,0,14,1028,1028,1,1034,10,15,1,1038,14]

theorem envBound6128 : H12AffineFastState.Bounded env6128 := by
  intro p hp
  have h : env6128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6127_6128 : H12AffineEnvironment.transform 6 7 env6127 = env6128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env6127 == env6128) = true)

theorem identity6128 : scanCanonicalize (H12AffineFastState.compose env6128 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6128 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6129 : List Nat := [2,4,2,1,5,1,7,4,5,1024,4,1028,8192,1028,8195,8196,1029,1,1025,8195,1029,5,0,7,8196,0,4,1028,1028,1,1024,0,5,1,1028,4]

theorem envBound6129 : H12AffineFastState.Bounded env6129 := by
  intro p hp
  have h : env6129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6128_6129 : H12AffineEnvironment.transform 2 2 env6128 = env6129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6128 == env6129) = true)

theorem identity6129 : scanCanonicalize (H12AffineFastState.compose env6129 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound6129 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6130 : List Nat := [2,4,2,1,5,1,7,4,5,5,4,1,8192,1,8195,8196,0,1,4,8195,0,5,0,7,8196,0,4,1,1,1,5,0,5,1,1,4]

theorem envBound6130 : H12AffineFastState.Bounded env6130 := by
  intro p hp
  have h : env6130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6129_6130 : H12AffineEnvironment.transform 9 5 env6129 = env6130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env6129 == env6130) = true)

theorem identity6130 : scanCanonicalize (H12AffineFastState.compose env6130 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6130 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6131 : List Nat := [2,0,2,1,1,1,3,0,1,1,0,1,8192,1,8195,8192,0,1,0,8195,0,1,0,3,8192,0,0,1,1,1,1,0,1,1,1,0]

theorem envBound6131 : H12AffineFastState.Bounded env6131 := by
  intro p hp
  have h : env6131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6130_6131 : H12AffineEnvironment.transform 1 0 env6130 = env6131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6130 == env6131) = true)

theorem identity6131 : scanCanonicalize (H12AffineFastState.compose env6131 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 2) := by decide +kernel

theorem selectedBound6131 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6132 : List Nat := [2,0,2,1,1,1,3,0,1,1,0,1,2,1,1,2,0,1,0,1,0,1,0,3,2,0,0,1,1,1,1,0,1,1,1,0]

theorem envBound6132 : H12AffineFastState.Bounded env6132 := by
  intro p hp
  have h : env6132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6131_6132 : H12AffineEnvironment.transform 12 2 env6131 = env6132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2 env6131 == env6132) = true)

def env6133 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,115903,5545,41003,8329,5545,323713,16384,16812,22560,74795,73770,257,20481,95294,5653]

theorem envBound6133 : H12AffineFastState.Bounded env6133 := by
  intro p hp
  have h : env6133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6116_6133 : H12AffineEnvironment.transform 22 5545 env6116 = env6133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 5545 env6116 == env6133) = true)

theorem identity6133 : scanCanonicalize (H12AffineFastState.compose env6133 (packedSelected [7,13,20,21,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6133 : packedSelected [7,13,20,21,27] rootPS < 2^1333 := by decide +kernel

def env6134 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1025,32768,4097,115734,5376,41003,8224,5376,323624,16384,16645,22560,74795,73770,257,20481,95294,5653]

theorem envBound6134 : H12AffineFastState.Bounded env6134 := by
  intro p hp
  have h : env6134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6133_6134 : H12AffineEnvironment.transform 6 41 env6133 = env6134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6133 == env6134) = true)

theorem identity6134 : scanCanonicalize (H12AffineFastState.compose env6134 (packedSelected [1,3,13,17,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6134 : packedSelected [1,3,13,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6135 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,8201,65536,4356,262144,1025,8201,4097,91167,5376,34,8224,5376,282657,16384,16645,22560,74795,73770,257,20481,95294,5653]

theorem envBound6135 : H12AffineFastState.Bounded env6135 := by
  intro p hp
  have h : env6135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6134_6135 : H12AffineEnvironment.transform 14 8201 env6134 = env6135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6134 == env6135) = true)

theorem identity6135 : scanCanonicalize (H12AffineFastState.compose env6135 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound6135 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6136 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,16384,8201,65536,4356,2080,1025,8201,4097,91167,5376,34,8224,5376,22529,16384,16645,22560,74795,73770,257,20481,95294,5653]

theorem envBound6136 : H12AffineFastState.Bounded env6136 := by
  intro p hp
  have h : env6136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6135_6136 : H12AffineEnvironment.transform 17 2080 env6135 = env6136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env6135 == env6136) = true)

theorem identity6136 : scanCanonicalize (H12AffineFastState.compose env6136 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 4129) := by decide +kernel

theorem selectedBound6136 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env6137 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,4129,8201,65536,4356,2080,1025,8201,4097,78910,5376,34,8224,5376,2080,4129,4388,2049,74795,73770,257,32,74783,5653]

theorem envBound6137 : H12AffineFastState.Bounded env6137 := by
  intro p hp
  have h : env6137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6136_6137 : H12AffineEnvironment.transform 13 4129 env6136 = env6137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4129 env6136 == env6137) = true)

theorem identity6137 : scanCanonicalize (H12AffineFastState.compose env6137 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(15+1) ^^^ 2342) := by decide +kernel

theorem selectedBound6137 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6138 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,4129,8201,2342,4356,2080,1025,8201,4097,15640,5376,34,8224,5376,2080,4129,4388,2049,11533,10508,257,32,11577,5653]

theorem envBound6138 : H12AffineFastState.Bounded env6138 := by
  intro p hp
  have h : env6138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6137_6138 : H12AffineEnvironment.transform 15 2342 env6137 = env6138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2342 env6137 == env6138) = true)

theorem identity6138 : scanCanonicalize (H12AffineFastState.compose env6138 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1809) := by decide +kernel

theorem selectedBound6138 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env6139 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1809,4096,8192,4129,8201,1591,4356,1841,1025,8201,4097,12809,5376,34,8224,5376,1841,4129,4388,1808,8732,9757,257,32,8744,5653]

theorem envBound6139 : H12AffineFastState.Bounded env6139 := by
  intro p hp
  have h : env6139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6138_6139 : H12AffineEnvironment.transform 10 1809 env6138 = env6139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1809 env6138 == env6139) = true)

theorem identity6139 : scanCanonicalize (H12AffineFastState.compose env6139 (packedSelected [2,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6139 : packedSelected [2,10,12] rootPS < 2^1333 := by decide +kernel

def env6140 : List Nat := [2,4,8,16,32,16,41,5,512,1024,1556,4096,8192,4129,8201,1591,4097,1588,1025,8201,4097,12809,5125,34,8224,5125,1588,4129,4129,1557,8732,9757,4,32,8744,5653]

theorem envBound6140 : H12AffineFastState.Bounded env6140 := by
  intro p hp
  have h : env6140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6139_6140 : H12AffineEnvironment.transform 7 5 env6139 = env6140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6139 == env6140) = true)

theorem identity6140 : scanCanonicalize (H12AffineFastState.compose env6140 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound6140 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6141 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1556,4096,8192,4123,8201,1549,4097,1550,1025,8201,4097,12809,5125,24,8218,5125,1550,4123,4123,1557,8732,9757,4,26,8722,5653]

theorem envBound6141 : H12AffineFastState.Bounded env6141 := by
  intro p hp
  have h : env6141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6140_6141 : H12AffineEnvironment.transform 4 26 env6140 = env6141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env6140 == env6141) = true)

theorem identity6141 : scanCanonicalize (H12AffineFastState.compose env6141 (packedSelected [10,15] rootPS)) = affineNative (2^(12+1) ^^^ 1543) := by decide +kernel

theorem selectedBound6141 : packedSelected [10,15] rootPS < 2^1333 := by decide +kernel

def env6142 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1556,4096,1543,4123,1550,1549,4097,1550,1025,1550,4097,5134,5125,24,1565,5125,1550,4123,4123,1557,1051,26,4,26,1045,5653]

theorem envBound6142 : H12AffineFastState.Bounded env6142 := by
  intro p hp
  have h : env6142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6141_6142 : H12AffineEnvironment.transform 12 1543 env6141 = env6142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1543 env6141 == env6142) = true)

def env6143 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1556,1556,1543,1551,1550,1549,1557,1550,1025,1550,1557,538,529,24,1565,529,1550,1551,1551,1557,1051,26,4,26,1045,1]

theorem envBound6143 : H12AffineFastState.Bounded env6143 := by
  intro p hp
  have h : env6143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6142_6143 : H12AffineEnvironment.transform 11 1556 env6142 = env6143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1556 env6142 == env6143) = true)

theorem identity6143 : scanCanonicalize (H12AffineFastState.compose env6143 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound6143 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6144 : List Nat := [2,4,8,16,26,16,19,5,512,15,539,539,520,512,513,514,538,513,14,513,538,538,529,24,530,529,513,512,512,538,20,26,4,26,26,1]

theorem envBound6144 : H12AffineFastState.Bounded env6144 := by
  intro p hp
  have h : env6144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6143_6144 : H12AffineEnvironment.transform 9 15 env6143 = env6144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env6143 == env6144) = true)

def env6145 : List Nat := [2,4,8,16,26,16,19,5,0,15,27,27,8,0,1,2,26,1,14,1,26,26,17,24,18,17,1,0,0,26,20,26,4,26,26,1]

theorem envBound6145 : H12AffineFastState.Bounded env6145 := by
  intro p hp
  have h : env6145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6144_6145 : H12AffineEnvironment.transform 8 0 env6144 = env6145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6144 == env6145) = true)

theorem identity6145 : scanCanonicalize (H12AffineFastState.compose env6145 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound6145 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6146 : List Nat := [2,4,8,5,15,5,6,5,0,15,14,14,8,0,1,2,15,1,14,1,15,15,4,13,7,4,1,0,0,15,1,15,4,15,15,1]

theorem envBound6146 : H12AffineFastState.Bounded env6146 := by
  intro p hp
  have h : env6146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6145_6146 : H12AffineEnvironment.transform 3 5 env6145 = env6146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6145 == env6146) = true)

theorem identity6146 : scanCanonicalize (H12AffineFastState.compose env6146 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound6146 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6147 : List Nat := [2,4,7,5,0,5,6,5,0,0,1,1,7,0,1,2,0,1,1,1,0,0,4,2,7,4,1,0,0,0,1,0,4,0,0,1]

theorem envBound6147 : H12AffineFastState.Bounded env6147 := by
  intro p hp
  have h : env6147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6146_6147 : H12AffineEnvironment.transform 2 7 env6146 = env6147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env6146 == env6147) = true)

theorem identity6147 : scanCanonicalize (H12AffineFastState.compose env6147 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6147 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6148 : List Nat := [2,1,2,0,0,0,3,0,0,0,1,1,2,0,1,2,0,1,1,1,0,0,1,2,2,1,1,0,0,0,1,0,1,0,0,1]

theorem envBound6148 : H12AffineFastState.Bounded env6148 := by
  intro p hp
  have h : env6148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6147_6148 : H12AffineEnvironment.transform 1 1 env6147 = env6148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6147 == env6148) = true)

def leafEnv6148 : List Nat := [2,1,2,0,0,0,3,0,0,0,1,1,2,0,1,2,0,1,1,1,0,0,1,2,1,2,1,1,1,0,0,0,1,0,1,0,1,3,0,1,1,1,0]

def active6148 : List Nat := [0]

def tree6148 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6148 : H12WitnessSearch.Good tree6148 := H12GlobalWitnessIndex.good

theorem leafIdentity6148 : H12AffineFastState.composeSystem env6148 rootObs = leafEnv6148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6148 rootObs == leafEnv6148) = true)

theorem terminalChecked6148 : H12PackedTerminal.terminalCheckFast leafEnv6148 active6148 tree6148 = true := by decide +kernel

def env6149 : List Nat := [2,4,8,16,26,16,19,5,1,15,26,26,9,1,0,3,27,0,14,0,27,27,16,24,19,16,0,1,1,27,20,26,4,26,26,1]

theorem envBound6149 : H12AffineFastState.Bounded env6149 := by
  intro p hp
  have h : env6149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6144_6149 : H12AffineEnvironment.transform 8 1 env6144 = env6149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6144 == env6149) = true)

def env6150 : List Nat := [2,4,8,16,26,16,19,5,512,1024,1556,1557,1543,1550,1550,1549,1556,1550,1025,1550,1556,539,528,24,1565,528,1550,1550,1550,1557,1051,26,4,26,1045,0]

theorem envBound6150 : H12AffineFastState.Bounded env6150 := by
  intro p hp
  have h : env6150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6142_6150 : H12AffineEnvironment.transform 11 1557 env6142 = env6150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1557 env6142 == env6150) = true)

theorem identity6150 : scanCanonicalize (H12AffineFastState.compose env6150 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound6150 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6151 : List Nat := [2,4,8,16,26,16,19,5,512,20,512,513,531,538,538,537,512,538,21,538,512,539,528,24,521,528,538,538,538,513,15,26,4,26,1,0]

theorem envBound6151 : H12AffineFastState.Bounded env6151 := by
  intro p hp
  have h : env6151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6150_6151 : H12AffineEnvironment.transform 9 20 env6150 = env6151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env6150 == env6151) = true)

def env6152 : List Nat := [2,4,8,16,26,16,19,5,0,20,0,1,19,26,26,25,0,26,21,26,0,27,16,24,9,16,26,26,26,1,15,26,4,26,1,0]

theorem envBound6152 : H12AffineFastState.Bounded env6152 := by
  intro p hp
  have h : env6152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6151_6152 : H12AffineEnvironment.transform 8 0 env6151 = env6152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env6151 == env6152) = true)

theorem identity6152 : scanCanonicalize (H12AffineFastState.compose env6152 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6152 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6153 : List Nat := [2,4,8,11,1,11,8,5,0,15,0,1,8,1,1,2,0,1,14,1,0,0,11,3,9,11,1,1,1,1,15,1,4,1,1,0]

theorem envBound6153 : H12AffineFastState.Bounded env6153 := by
  intro p hp
  have h : env6153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6152_6153 : H12AffineEnvironment.transform 3 11 env6152 = env6153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6152 == env6153) = true)

def env6154 : List Nat := [2,4,8,16,26,16,19,5,1,20,1,0,18,27,27,24,1,27,21,27,1,26,17,24,8,17,27,27,27,0,15,26,4,26,1,0]

theorem envBound6154 : H12AffineFastState.Bounded env6154 := by
  intro p hp
  have h : env6154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6151_6154 : H12AffineEnvironment.transform 8 1 env6151 = env6154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6151 == env6154) = true)

theorem identity6154 : scanCanonicalize (H12AffineFastState.compose env6154 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound6154 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6155 : List Nat := [2,4,7,16,21,16,19,5,1,20,1,0,18,20,20,23,1,20,21,20,1,21,17,23,7,17,20,20,20,0,0,21,4,21,1,0]

theorem envBound6155 : H12AffineFastState.Bounded env6155 := by
  intro p hp
  have h : env6155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6154_6155 : H12AffineEnvironment.transform 2 7 env6154 = env6155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env6154 == env6155) = true)

theorem identity6155 : scanCanonicalize (H12AffineFastState.compose env6155 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound6155 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6156 : List Nat := [2,4,7,4,1,4,7,5,1,0,1,0,6,0,0,3,1,0,1,0,1,1,5,3,7,5,0,0,0,0,0,1,4,1,1,0]

theorem envBound6156 : H12AffineFastState.Bounded env6156 := by
  intro p hp
  have h : env6156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6155_6156 : H12AffineEnvironment.transform 3 4 env6155 = env6156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6155 == env6156) = true)

theorem identity6156 : scanCanonicalize (H12AffineFastState.compose env6156 (packedSelected [10] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6156 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6157 : List Nat := [2,0,3,0,1,0,3,1,1,0,1,0,2,0,0,3,1,0,1,0,1,1,1,3,3,1,0,0,0,0,0,1,0,1,1,0]

theorem envBound6157 : H12AffineFastState.Bounded env6157 := by
  intro p hp
  have h : env6157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6156_6157 : H12AffineEnvironment.transform 1 0 env6156 = env6157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6156 == env6157) = true)

def leafEnv6157 : List Nat := [2,0,3,0,1,0,3,1,1,0,1,0,2,0,0,3,1,0,1,0,1,1,1,3,0,3,1,1,0,0,0,0,0,1,0,1,0,3,1,0,1,1,0]

def active6157 : List Nat := [0]

def tree6157 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6157 : H12WitnessSearch.Good tree6157 := H12GlobalWitnessIndex.good

theorem leafIdentity6157 : H12AffineFastState.composeSystem env6157 rootObs = leafEnv6157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6157 rootObs == leafEnv6157) = true)

theorem terminalChecked6157 : H12PackedTerminal.terminalCheckFast leafEnv6157 active6157 tree6157 = true := by decide +kernel

def env6158 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,115903,8388608,41003,8329,8388609,323712,16384,16813,22561,74795,8467843,257,20480,95294,8389565]

theorem envBound6158 : H12AffineFastState.Bounded env6158 := by
  intro p hp
  have h : env6158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6115_6158 : H12AffineEnvironment.transform 5 17 env6115 = env6158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6115 == env6158) = true)

theorem identity6158 : scanCanonicalize (H12AffineFastState.compose env6158 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound6158 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6159 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,115903,445,41003,8329,444,323712,16384,16813,22561,74795,78910,257,20480,95294,512]

theorem envBound6159 : H12AffineFastState.Bounded env6159 := by
  intro p hp
  have h : env6159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6158_6159 : H12AffineEnvironment.transform 22 445 env6158 = env6159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env6158 == env6159) = true)

theorem identity6159 : scanCanonicalize (H12AffineFastState.compose env6159 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25915) := by decide +kernel

theorem selectedBound6159 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6160 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25915,4524,262144,1025,32768,4097,41348,445,41003,8329,444,323712,16384,16813,22561,16656,20741,257,20480,4357,512]

theorem envBound6160 : H12AffineFastState.Bounded env6160 := by
  intro p hp
  have h : env6160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6159_6160 : H12AffineEnvironment.transform 15 25915 env6159 = env6160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25915 env6159 == env6160) = true)

theorem identity6160 : scanCanonicalize (H12AffineFastState.compose env6160 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6160 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6161 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25915,4524,262144,1025,26261,4097,18193,445,18110,8329,444,267797,16384,16813,22561,16656,20741,257,20480,4357,512]

theorem envBound6161 : H12AffineFastState.Bounded env6161 := by
  intro p hp
  have h : env6161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6160_6161 : H12AffineEnvironment.transform 14 26261 env6160 = env6161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6160 == env6161) = true)

theorem identity6161 : scanCanonicalize (H12AffineFastState.compose env6161 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound6161 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6162 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25915,1044,262144,1025,26261,1465,18193,445,18110,8329,444,263085,16384,16813,19865,16656,17597,257,17848,1213,512]

theorem envBound6162 : H12AffineFastState.Bounded env6162 := by
  intro p hp
  have h : env6162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6161_6162 : H12AffineEnvironment.transform 11 1464 env6161 = env6162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env6161 == env6162) = true)

theorem identity6162 : scanCanonicalize (H12AffineFastState.compose env6162 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6162 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6163 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26261,25915,1044,2341,1025,26261,1465,18193,445,18110,8329,444,2696,16384,16813,19865,16656,17597,257,17848,1213,512]

theorem envBound6163 : H12AffineFastState.Bounded env6163 := by
  intro p hp
  have h : env6163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6162_6163 : H12AffineEnvironment.transform 17 2341 env6162 = env6163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6162 == env6163) = true)

theorem identity6163 : scanCanonicalize (H12AffineFastState.compose env6163 (packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound6163 : packedSelected [0,4,7,8,9,10,12,13,15,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6164 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,1841,8612,8714,1044,2341,1025,8612,1465,32,445,399,8329,444,2696,1841,1692,2728,1569,908,257,649,1213,512]

theorem envBound6164 : H12AffineFastState.Bounded env6164 := by
  intro p hp
  have h : env6164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6163_6164 : H12AffineEnvironment.transform 13 1841 env6163 = env6164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env6163 == env6164) = true)

theorem identity6164 : scanCanonicalize (H12AffineFastState.compose env6164 (packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6164 : packedSelected [0,1,3,4,7,9,12,13,15,17] rootPS < 2^1333 := by decide +kernel

def env6165 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1044,8192,1693,8200,8714,1044,2185,1025,8200,1045,32,17,35,8329,16,2696,1693,1692,2728,1569,544,173,649,1213,512]

theorem envBound6165 : H12AffineFastState.Bounded env6165 := by
  intro p hp
  have h : env6165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6164_6165 : H12AffineEnvironment.transform 7 172 env6164 = env6165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6164 == env6165) = true)

theorem identity6165 : scanCanonicalize (H12AffineFastState.compose env6165 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1703) := by decide +kernel

theorem selectedBound6165 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6166 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1703,1044,8192,1693,8200,8714,1044,1582,1025,8200,1045,32,17,35,8329,16,1071,1693,1692,1039,1569,544,173,649,1213,512]

theorem envBound6166 : H12AffineFastState.Bounded env6166 := by
  intro p hp
  have h : env6166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6165_6166 : H12AffineEnvironment.transform 10 1703 env6165 = env6166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1703 env6165 == env6166) = true)

theorem identity6166 : scanCanonicalize (H12AffineFastState.compose env6166 (packedSelected [2,3,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 1711) := by decide +kernel

theorem selectedBound6166 : packedSelected [2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env6167 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1703,1044,1711,1693,1703,1189,1044,1582,1025,1703,1045,32,17,35,1574,16,1071,1693,1692,1039,1569,544,173,649,1213,512]

theorem envBound6167 : H12AffineFastState.Bounded env6167 := by
  intro p hp
  have h : env6167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6166_6167 : H12AffineEnvironment.transform 12 1711 env6166 = env6167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1711 env6166 == env6167) = true)

theorem identity6167 : scanCanonicalize (H12AffineFastState.compose env6167 (packedSelected [2,3] rootPS)) = affineNative (2^(9+1) ^^^ 646) := by decide +kernel

theorem selectedBound6167 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env6168 : List Nat := [2,4,8,16,32,17,128,172,512,646,33,658,41,27,33,547,658,168,647,33,659,32,17,35,160,16,681,27,26,649,167,544,173,649,571,512]

theorem envBound6168 : H12AffineFastState.Bounded env6168 := by
  intro p hp
  have h : env6168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6167_6168 : H12AffineEnvironment.transform 9 646 env6167 = env6168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 646 env6167 == env6168) = true)

theorem identity6168 : scanCanonicalize (H12AffineFastState.compose env6168 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(6+1) ^^^ 18) := by decide +kernel

theorem selectedBound6168 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env6169 : List Nat := [2,4,8,16,32,17,18,62,512,532,33,512,41,27,33,547,512,58,533,33,513,32,17,35,50,16,571,27,26,539,53,544,63,539,571,512]

theorem envBound6169 : H12AffineFastState.Bounded env6169 := by
  intro p hp
  have h : env6169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6168_6169 : H12AffineEnvironment.transform 6 18 env6168 = env6169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 18 env6168 == env6169) = true)

theorem identity6169 : scanCanonicalize (H12AffineFastState.compose env6169 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 59) := by decide +kernel

theorem selectedBound6169 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6170 : List Nat := [2,4,8,16,32,17,18,62,59,47,33,59,41,27,33,24,59,58,46,33,58,32,17,35,50,16,0,27,26,32,53,27,63,32,0,59]

theorem envBound6170 : H12AffineFastState.Bounded env6170 := by
  intro p hp
  have h : env6170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6169_6170 : H12AffineEnvironment.transform 8 59 env6169 = env6170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 59 env6169 == env6170) = true)

theorem identity6170 : scanCanonicalize (H12AffineFastState.compose env6170 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6170 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6171 : List Nat := [2,4,8,16,1,17,18,31,26,14,0,26,8,27,0,24,26,27,15,0,27,1,17,2,19,16,0,27,26,1,20,27,30,1,0,26]

theorem envBound6171 : H12AffineFastState.Bounded env6171 := by
  intro p hp
  have h : env6171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6170_6171 : H12AffineEnvironment.transform 4 1 env6170 = env6171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6170 == env6171) = true)

def env6172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,67108864,77914241,76039249,76039597,77613088,75572347,73983341,525568,77611009,82355409,8914925]

theorem envBound6172 : H12AffineFastState.Bounded env6172 := by
  intro p hp
  have h : env6172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans5743_6172 : H12AffineEnvironment.transform 26 77914241 env5743 = env6172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 77914241 env5743 == env6172) = true)

def env6173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,2097152,4194304,8388608,41003,8329,8914000,2942161,16385,16893,2641008,598059,14737725,525568,2638929,6332545,8914925]

theorem envBound6173 : H12AffineFastState.Bounded env6173 := by
  intro p hp
  have h : env6173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6172_6173 : H12AffineEnvironment.transform 25 8914000 env6172 = env6173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env6172 == env6173) = true)

def env6174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4096,4194304,8388608,41003,8329,8914000,849105,16385,16893,547952,598059,12644669,525568,545873,4239489,8914925]

theorem envBound6174 : H12AffineFastState.Bounded env6174 := by
  intro p hp
  have h : env6174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6173_6174 : H12AffineEnvironment.transform 20 4096 env6173 = env6174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4096 env6173 == env6174) = true)

def env6175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323793,16385,16893,22640,74795,12644669,256,20561,4239489,8389613]

theorem envBound6175 : H12AffineFastState.Bounded env6175 := by
  intro p hp
  have h : env6175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6174_6175 : H12AffineEnvironment.transform 18 1024 env6174 = env6175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6174 == env6175) = true)

theorem identity6175 : scanCanonicalize (H12AffineFastState.compose env6175 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound6175 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,25914,4605,262144,1024,32768,4096,4194304,8388608,41003,8329,8388688,323793,16385,16893,22640,16657,12644669,256,20561,4239489,8389613]

theorem envBound6176 : H12AffineFastState.Bounded env6176 := by
  intro p hp
  have h : env6176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6175_6176 : H12AffineEnvironment.transform 15 25914 env6175 = env6176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env6175 == env6176) = true)

def env6177 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4096,4194304,8388608,41003,8329,8388608,323713,16385,16813,22560,16657,12644669,256,20481,4239489,8389565]

theorem envBound6177 : H12AffineFastState.Bounded env6177 := by
  intro p hp
  have h : env6177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6176_6177 : H12AffineEnvironment.transform 5 16 env6176 = env6177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6176 == env6177) = true)

def env6178 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4096,4194304,4240784,41003,8329,4240784,323713,16385,16813,22560,16657,17581,256,20481,4239489,4240941]

theorem envBound6178 : H12AffineFastState.Bounded env6178 := by
  intro p hp
  have h : env6178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6177_6178 : H12AffineEnvironment.transform 22 4240784 env6177 = env6178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240784 env6177 == env6178) = true)

theorem identity6178 : scanCanonicalize (H12AffineFastState.compose env6178 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13728) := by decide +kernel

theorem selectedBound6178 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6179 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13728,25914,4525,262144,1024,13728,4096,4194304,4194352,5515,8329,4194352,279841,16385,16813,22560,16657,17581,256,20481,4195617,4195213]

theorem envBound6179 : H12AffineFastState.Bounded env6179 := by
  intro p hp
  have h : env6179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6178_6179 : H12AffineEnvironment.transform 14 13728 env6178 = env6179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13728 env6178 == env6179) = true)

def env6180 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,4096,8192,16384,13728,25898,4525,262144,1024,13728,4096,4194304,4194336,5515,8329,4194336,279841,16385,16813,22560,16641,17581,256,20481,4195617,4195213]

theorem envBound6180 : H12AffineFastState.Bounded env6180 := by
  intro p hp
  have h : env6180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6179_6180 : H12AffineEnvironment.transform 3 0 env6179 = env6180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6179 == env6180) = true)

def env6181 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1280,8192,16384,8352,25898,1197,262144,1024,8352,1280,4194304,4194336,139,8329,4194336,279841,16385,16813,19744,16641,17581,256,17665,4195617,4195213]

theorem envBound6181 : H12AffineFastState.Bounded env6181 := by
  intro p hp
  have h : env6181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6180_6181 : H12AffineEnvironment.transform 11 1280 env6180 = env6181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env6180 == env6181) = true)

theorem identity6181 : scanCanonicalize (H12AffineFastState.compose env6181 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 264453) := by decide +kernel

theorem selectedBound6181 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env6182 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1280,8192,16384,8352,25898,1197,262144,1024,8352,1280,264453,264485,139,8329,264485,279841,16385,16813,19744,16641,17581,256,17665,265252,264840]

theorem envBound6182 : H12AffineFastState.Bounded env6182 := by
  intro p hp
  have h : env6182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6181_6182 : H12AffineEnvironment.transform 21 264453 env6181 = env6182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 264453 env6181 == env6182) = true)

theorem identity6182 : scanCanonicalize (H12AffineFastState.compose env6182 (packedSelected [0,6,7,9,11,17,20,22,23] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound6182 : packedSelected [0,6,7,9,11,17,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6183 : List Nat := [2,4,8,0,32,0,128,256,512,1024,1038,1280,8192,16384,8352,25898,1197,262144,1024,8352,1280,263435,263467,139,8329,263467,279841,16385,16813,16686,16641,17581,256,17665,262186,263814]

theorem envBound6183 : H12AffineFastState.Bounded env6183 := by
  intro p hp
  have h : env6183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6182_6183 : H12AffineEnvironment.transform 10 1038 env6182 = env6183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env6182 == env6183) = true)

theorem identity6183 : scanCanonicalize (H12AffineFastState.compose env6183 (packedSelected [1,3,4,8,10,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 1929) := by decide +kernel

theorem selectedBound6183 : packedSelected [1,3,4,8,10,20,22,24] rootPS < 2^1333 := by decide +kernel

def env6184 : List Nat := [2,4,8,0,32,0,128,256,512,1024,1038,1280,8192,1929,8352,8867,1197,262144,1024,8352,1280,263435,263467,139,8329,263467,262824,1928,1572,1703,1672,804,256,648,262186,263814]

theorem envBound6184 : H12AffineFastState.Bounded env6184 := by
  intro p hp
  have h : env6184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6183_6184 : H12AffineEnvironment.transform 13 1929 env6183 = env6184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1929 env6183 == env6184) = true)

theorem identity6184 : scanCanonicalize (H12AffineFastState.compose env6184 (packedSelected [0,1,2,4,5,6,7,9,10,12,15,17] rootPS)) = affineNative (2^(17+1) ^^^ 1322) := by decide +kernel

theorem selectedBound6184 : packedSelected [0,1,2,4,5,6,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env6185 : List Nat := [2,4,8,0,32,0,128,256,512,1024,1038,1280,8192,1929,8352,8867,1197,1322,1024,8352,1280,33,1,139,8329,1,1922,1928,1572,1703,1672,804,256,648,1280,940]

theorem envBound6185 : H12AffineFastState.Bounded env6185 := by
  intro p hp
  have h : env6185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6184_6185 : H12AffineEnvironment.transform 17 1322 env6184 = env6185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1322 env6184 == env6185) = true)

theorem identity6185 : scanCanonicalize (H12AffineFastState.compose env6185 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound6185 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6186 : List Nat := [2,4,8,0,32,0,128,256,397,1024,1038,1280,8192,1028,8352,8494,1197,1322,1024,8352,1280,33,1,139,8329,1,1039,1029,1449,1322,1285,169,256,261,1280,33]

theorem envBound6186 : H12AffineFastState.Bounded env6186 := by
  intro p hp
  have h : env6186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6185_6186 : H12AffineEnvironment.transform 8 397 env6185 = env6186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env6185 == env6186) = true)

theorem identity6186 : scanCanonicalize (H12AffineFastState.compose env6186 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound6186 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env6187 : List Nat := [2,4,8,0,32,0,8,256,261,1024,1038,1280,8192,1028,8232,8494,1061,1322,1024,8232,1280,33,1,3,8193,1,1039,1029,1313,1322,1285,33,256,261,1280,33]

theorem envBound6187 : H12AffineFastState.Bounded env6187 := by
  intro p hp
  have h : env6187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6186_6187 : H12AffineEnvironment.transform 6 8 env6186 = env6187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env6186 == env6187) = true)

theorem identity6187 : scanCanonicalize (H12AffineFastState.compose env6187 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1062) := by decide +kernel

theorem selectedBound6187 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env6188 : List Nat := [2,4,8,0,32,0,8,256,261,1024,1038,1280,1062,1028,1038,1288,1061,1322,1024,1038,1280,33,1,3,1063,1,1039,1029,1313,1322,1285,33,256,261,1280,33]

theorem envBound6188 : H12AffineFastState.Bounded env6188 := by
  intro p hp
  have h : env6188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6187_6188 : H12AffineEnvironment.transform 12 1062 env6187 = env6188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1062 env6187 == env6188) = true)

theorem identity6188 : scanCanonicalize (H12AffineFastState.compose env6188 (packedSelected [0,2,6] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound6188 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env6189 : List Nat := [2,4,8,0,32,0,8,256,261,267,261,11,301,271,261,3,302,33,267,261,11,33,1,3,300,1,260,270,42,33,14,33,256,261,11,33]

theorem envBound6189 : H12AffineFastState.Bounded env6189 := by
  intro p hp
  have h : env6189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6188_6189 : H12AffineEnvironment.transform 9 267 env6188 = env6189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env6188 == env6189) = true)

theorem identity6189 : scanCanonicalize (H12AffineFastState.compose env6189 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6189 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env6190 : List Nat := [2,4,8,0,0,0,8,256,261,267,261,11,269,271,261,3,270,1,267,261,11,1,1,3,268,1,260,270,10,1,14,1,256,261,11,1]

theorem envBound6190 : H12AffineFastState.Bounded env6190 := by
  intro p hp
  have h : env6190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6189_6190 : H12AffineEnvironment.transform 4 0 env6189 = env6190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6189 == env6190) = true)

theorem identity6190 : scanCanonicalize (H12AffineFastState.compose env6190 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6190 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6191 : List Nat := [2,4,2,0,0,0,2,256,261,257,261,1,263,261,261,3,260,1,257,261,1,1,1,3,262,1,260,260,0,1,4,1,256,261,1,1]

theorem envBound6191 : H12AffineFastState.Bounded env6191 := by
  intro p hp
  have h : env6191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6190_6191 : H12AffineEnvironment.transform 2 2 env6190 = env6191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6190 == env6191) = true)

theorem identity6191 : scanCanonicalize (H12AffineFastState.compose env6191 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6191 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6192 : List Nat := [2,4,2,0,0,0,2,4,1,5,1,1,3,1,1,3,0,1,5,1,1,1,1,3,2,1,0,0,0,1,4,1,4,1,1,1]

theorem envBound6192 : H12AffineFastState.Bounded env6192 := by
  intro p hp
  have h : env6192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6191_6192 : H12AffineEnvironment.transform 7 4 env6191 = env6192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6191 == env6192) = true)

def env6193 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1281,8192,16384,8353,25898,1196,262144,1024,8353,1281,4194304,4194336,138,8329,4194336,279841,16385,16813,19745,16641,17581,256,17664,4195617,4195213]

theorem envBound6193 : H12AffineFastState.Bounded env6193 := by
  intro p hp
  have h : env6193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6180_6193 : H12AffineEnvironment.transform 11 1281 env6180 = env6193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env6180 == env6193) = true)

theorem identity6193 : scanCanonicalize (H12AffineFastState.compose env6193 (packedSelected [17,21] rootPS)) = affineNative (2^(21+1) ^^^ 281856) := by decide +kernel

theorem selectedBound6193 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1