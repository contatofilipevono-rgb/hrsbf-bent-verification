import H12CloudChart1Data025

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity6443 : scanCanonicalize (H12AffineFastState.compose env6443 (packedSelected [5,8] rootPS)) = affineNative (2^(14+1) ^^^ 1038) := by decide +kernel

theorem selectedBound6443 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6444 : List Nat := [2,4,8,16,32,16,40,4,512,1024,1551,4096,8192,4096,1038,8234,4097,4122,1024,1038,4096,9254,16,9253,8225,17,13372,4096,4096,1582,1024,0,4,0,4096,513]

theorem envBound6444 : H12AffineFastState.Bounded env6444 := by
  intro p hp
  have h : env6444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6443_6444 : H12AffineEnvironment.transform 14 1038 env6443 = env6444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1038 env6443 == env6444) = true)

theorem identity6444 : scanCanonicalize (H12AffineFastState.compose env6444 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6444 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6445 : List Nat := [2,4,8,1,32,1,40,4,512,1024,1551,4096,8192,4096,1038,8234,4097,4107,1024,1038,4096,9254,1,9253,8225,0,13357,4096,4096,1582,1024,0,4,0,4096,513]

theorem envBound6445 : H12AffineFastState.Bounded env6445 := by
  intro p hp
  have h : env6445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6444_6445 : H12AffineEnvironment.transform 3 1 env6444 = env6445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6444 == env6445) = true)

theorem identity6445 : scanCanonicalize (H12AffineFastState.compose env6445 (packedSelected [1,2,9,11,12,13] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound6445 : packedSelected [1,2,9,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6446 : List Nat := [2,4,8,1,32,1,40,4,14,1024,1025,4096,8192,4096,1038,8234,4097,4107,1024,1038,4096,9254,1,9253,8225,0,13357,4096,4096,1056,1024,0,4,0,4096,15]

theorem envBound6446 : H12AffineFastState.Bounded env6446 := by
  intro p hp
  have h : env6446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6445_6446 : H12AffineEnvironment.transform 8 14 env6445 = env6446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env6445 == env6446) = true)

theorem identity6446 : scanCanonicalize (H12AffineFastState.compose env6446 (packedSelected [1,2,9,11,12,17] rootPS)) = affineNative (2^(11+1) ^^^ 1067) := by decide +kernel

theorem selectedBound6446 : packedSelected [1,2,9,11,12,17] rootPS < 2^1333 := by decide +kernel

def env6447 : List Nat := [2,4,8,1,32,1,40,4,14,1024,1025,1067,8192,1067,1038,8234,1066,1056,1024,1038,1067,9254,1,9253,8225,0,8198,1067,1067,1056,1024,0,4,0,1067,15]

theorem envBound6447 : H12AffineFastState.Bounded env6447 := by
  intro p hp
  have h : env6447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6446_6447 : H12AffineEnvironment.transform 11 1067 env6446 = env6447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1067 env6446 == env6447) = true)

theorem identity6447 : scanCanonicalize (H12AffineFastState.compose env6447 (packedSelected [0,2,3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6447 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env6448 : List Nat := [2,4,2,1,32,1,34,4,4,1024,1025,1057,8192,1057,1028,8224,1056,1056,1024,1028,1057,9254,1,9253,8225,0,8198,1057,1057,1056,1024,0,4,0,1057,5]

theorem envBound6448 : H12AffineFastState.Bounded env6448 := by
  intro p hp
  have h : env6448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6447_6448 : H12AffineEnvironment.transform 2 2 env6447 = env6448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6447 == env6448) = true)

theorem identity6448 : scanCanonicalize (H12AffineFastState.compose env6448 (packedSelected [1,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound6448 : packedSelected [1,2,7] rootPS < 2^1333 := by decide +kernel

def env6449 : List Nat := [2,4,2,1,32,1,34,4,4,1024,1025,1057,1031,1057,1028,1063,1056,1056,1024,1028,1057,33,1,34,1062,0,1025,1057,1057,1056,1024,0,4,0,1057,5]

theorem envBound6449 : H12AffineFastState.Bounded env6449 := by
  intro p hp
  have h : env6449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6448_6449 : H12AffineEnvironment.transform 12 1031 env6448 = env6449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env6448 == env6449) = true)

theorem identity6449 : scanCanonicalize (H12AffineFastState.compose env6449 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6449 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6450 : List Nat := [2,0,2,1,32,1,34,0,0,1024,1025,1057,1027,1057,1024,1059,1056,1056,1024,1024,1057,33,1,34,1058,0,1025,1057,1057,1056,1024,0,0,0,1057,1]

theorem envBound6450 : H12AffineFastState.Bounded env6450 := by
  intro p hp
  have h : env6450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6449_6450 : H12AffineEnvironment.transform 1 0 env6449 = env6450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6449 == env6450) = true)

theorem identity6450 : scanCanonicalize (H12AffineFastState.compose env6450 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound6450 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6451 : List Nat := [2,0,2,1,32,1,34,0,0,32,33,1,35,1,32,3,0,0,32,32,1,33,1,34,2,0,33,1,1,0,32,0,0,0,1,1]

theorem envBound6451 : H12AffineFastState.Bounded env6451 := by
  intro p hp
  have h : env6451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6450_6451 : H12AffineEnvironment.transform 9 32 env6450 = env6451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env6450 == env6451) = true)

def leafEnv6451 : List Nat := [2,0,2,1,32,1,34,0,0,32,33,1,35,1,32,3,0,0,32,32,1,33,1,34,32,2,1,0,33,1,1,0,32,0,0,0,0,34,1,1,1,1,0]

def active6451 : List Nat := [0,4]

def tree6451 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6451 : H12WitnessSearch.Good tree6451 := H12GlobalWitnessIndex.good

theorem leafIdentity6451 : H12AffineFastState.composeSystem env6451 rootObs = leafEnv6451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6451 rootObs == leafEnv6451) = true)

theorem terminalChecked6451 : H12PackedTerminal.terminalCheckFast leafEnv6451 active6451 tree6451 = true := by decide +kernel

def env6452 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4265,32768,8234,4525,7869,1024,32768,4096,41088,184,41003,8329,185,48788,4265,4357,2184,1024,429,256,169,4096,773]

theorem envBound6452 : H12AffineFastState.Bounded env6452 := by
  intro p hp
  have h : env6452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6439_6452 : H12AffineEnvironment.transform 13 4265 env6439 = env6452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4265 env6439 == env6452) = true)

theorem identity6452 : scanCanonicalize (H12AffineFastState.compose env6452 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(11+1) ^^^ 1841) := by decide +kernel

theorem selectedBound6452 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env6453 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1841,8192,1944,32768,8234,1692,2444,1024,32768,1841,41088,184,41003,8329,185,43429,1944,1588,2184,1024,429,256,169,1841,773]

theorem envBound6453 : H12AffineFastState.Bounded env6453 := by
  intro p hp
  have h : env6453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6452_6453 : H12AffineEnvironment.transform 11 1841 env6452 = env6453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1841 env6452 == env6453) = true)

theorem identity6453 : scanCanonicalize (H12AffineFastState.compose env6453 (packedSelected [4,9,17,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound6453 : packedSelected [4,9,17,20,21] rootPS < 2^1333 := by decide +kernel

def env6454 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1841,8192,1944,8460,8234,1692,2444,1024,8460,1841,396,184,295,8329,185,2217,1944,1588,2184,1024,429,256,169,1841,773]

theorem envBound6454 : H12AffineFastState.Bounded env6454 := by
  intro p hp
  have h : env6454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6453_6454 : H12AffineEnvironment.transform 14 8460 env6453 = env6454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env6453 == env6454) = true)

theorem identity6454 : scanCanonicalize (H12AffineFastState.compose env6454 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6454 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6455 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1841,8192,1841,8460,8234,1589,2341,1024,8460,1841,293,17,295,8224,16,2048,1841,1588,2081,1024,260,256,0,1841,773]

theorem envBound6455 : H12AffineFastState.Bounded env6455 := by
  intro p hp
  have h : env6455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6454_6455 : H12AffineEnvironment.transform 6 41 env6454 = env6455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6454 == env6455) = true)

theorem identity6455 : scanCanonicalize (H12AffineFastState.compose env6455 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 2838) := by decide +kernel

theorem selectedBound6455 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env6456 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,1841,2838,1841,2586,2876,1589,2341,1024,2586,1841,293,17,295,2870,16,2048,1841,1588,2081,1024,260,256,0,1841,773]

theorem envBound6456 : H12AffineFastState.Bounded env6456 := by
  intro p hp
  have h : env6456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6455_6456 : H12AffineEnvironment.transform 12 2838 env6455 = env6456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2838 env6455 == env6456) = true)

theorem identity6456 : scanCanonicalize (H12AffineFastState.compose env6456 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound6456 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env6457 : List Nat := [2,4,8,16,32,16,41,20,512,1024,2048,1573,2562,1573,2586,2600,1589,2097,1024,2586,1573,49,17,51,2594,16,2048,1573,1588,2081,1024,16,20,0,1573,529]

theorem envBound6457 : H12AffineFastState.Bounded env6457 := by
  intro p hp
  have h : env6457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6456_6457 : H12AffineEnvironment.transform 7 20 env6456 = env6457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env6456 == env6457) = true)

theorem identity6457 : scanCanonicalize (H12AffineFastState.compose env6457 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6457 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env6458 : List Nat := [2,4,8,1,32,1,41,5,512,1024,2048,1573,2562,1573,2571,2600,1572,2080,1024,2571,1573,32,0,34,2594,1,2048,1573,1573,2081,1024,1,5,0,1573,512]

theorem envBound6458 : H12AffineFastState.Bounded env6458 := by
  intro p hp
  have h : env6458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6457_6458 : H12AffineEnvironment.transform 3 1 env6457 = env6458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6457 == env6458) = true)

theorem identity6458 : scanCanonicalize (H12AffineFastState.compose env6458 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6458 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6459 : List Nat := [2,4,3,1,32,1,34,5,512,1024,2048,1573,2562,1573,2560,2595,1572,2080,1024,2560,1573,32,0,34,2594,1,2048,1573,1573,2081,1024,1,5,0,1573,512]

theorem envBound6459 : H12AffineFastState.Bounded env6459 := by
  intro p hp
  have h : env6459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6458_6459 : H12AffineEnvironment.transform 2 3 env6458 = env6459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6458 == env6459) = true)

theorem identity6459 : scanCanonicalize (H12AffineFastState.compose env6459 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6459 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env6460 : List Nat := [2,4,3,1,1,1,3,5,512,1024,2048,1540,2562,1540,2560,2562,1541,2049,1024,2560,1540,1,0,3,2563,1,2048,1540,1540,2048,1024,1,5,0,1540,512]

theorem envBound6460 : H12AffineFastState.Bounded env6460 := by
  intro p hp
  have h : env6460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6459_6460 : H12AffineEnvironment.transform 4 1 env6459 = env6460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6459 == env6460) = true)

theorem identity6460 : scanCanonicalize (H12AffineFastState.compose env6460 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6461 : List Nat := [2,4,3,1,1,1,3,5,1,1024,2048,1029,2051,1029,2049,2051,1028,2049,1024,2049,1029,1,0,3,2050,1,2048,1029,1029,2048,1024,1,5,0,1029,1]

theorem envBound6461 : H12AffineFastState.Bounded env6461 := by
  intro p hp
  have h : env6461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6460_6461 : H12AffineEnvironment.transform 8 1 env6460 = env6461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6460 == env6461) = true)

theorem identity6461 : scanCanonicalize (H12AffineFastState.compose env6461 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound6461 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6462 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1029,3,1029,1,3,1028,1,1024,1,1029,1,0,3,2,1,0,1029,1029,0,1024,1,5,0,1029,1]

theorem envBound6462 : H12AffineFastState.Bounded env6462 := by
  intro p hp
  have h : env6462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6461_6462 : H12AffineEnvironment.transform 10 0 env6461 = env6462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env6461 == env6462) = true)

def leafEnv6462 : List Nat := [2,4,3,1,1,1,3,5,1,1024,0,1029,3,1029,1,3,1028,1,1024,1,1029,1,0,3,1024,2,1,1,0,1029,1029,0,1024,1,5,0,4,3,1029,1,1,1028,0]

def active6462 : List Nat := [0,1,9]

def tree6462 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6462 : H12WitnessSearch.Good tree6462 := H12GlobalWitnessIndex.good

theorem leafIdentity6462 : H12AffineFastState.composeSystem env6462 rootObs = leafEnv6462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6462 rootObs == leafEnv6462) = true)

theorem terminalChecked6462 : H12PackedTerminal.terminalCheckFast leafEnv6462 active6462 tree6462 = true := by decide +kernel

def env6463 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,41089,73874,41003,8329,73875,323712,16384,16812,22561,74794,94511,256,20480,4097,74543]

theorem envBound6463 : H12AffineFastState.Bounded env6463 := by
  intro p hp
  have h : env6463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6436_6463 : H12AffineEnvironment.transform 21 41089 env6436 = env6463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env6436 == env6463) = true)

theorem identity6463 : scanCanonicalize (H12AffineFastState.compose env6463 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6463 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6464 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,32768,65536,4265,262144,1024,32768,4096,41089,73874,41003,8329,73875,323712,16384,16552,22561,74794,94251,4,20480,4097,74283]

theorem envBound6464 : H12AffineFastState.Bounded env6464 := by
  intro p hp
  have h : env6464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6463_6464 : H12AffineEnvironment.transform 7 4 env6463 = env6464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6463 == env6464) = true)

theorem identity6464 : scanCanonicalize (H12AffineFastState.compose env6464 (packedSelected [0,3,5,7,8,10,11,13,17,18,20,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6464 : packedSelected [0,3,5,7,8,10,11,13,17,18,20,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6465 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,16384,26260,65536,4265,262144,1024,26260,4096,17941,73874,18111,8329,73875,267796,16384,16552,22561,74794,94251,4,20480,4097,74283]

theorem envBound6465 : H12AffineFastState.Bounded env6465 := by
  intro p hp
  have h : env6465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6464_6465 : H12AffineEnvironment.transform 14 26260 env6464 = env6465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6464 == env6465) = true)

def env6466 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,65536,4265,262144,1024,13972,4096,5653,73874,5823,8329,73875,267796,4096,4264,2081,74794,73771,4,0,4097,74283]

theorem envBound6466 : H12AffineFastState.Bounded env6466 := by
  intro p hp
  have h : env6466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6465_6466 : H12AffineEnvironment.transform 13 4096 env6465 = env6466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4096 env6465 == env6466) = true)

theorem identity6466 : scanCanonicalize (H12AffineFastState.compose env6466 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 13839) := by decide +kernel

theorem selectedBound6466 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env6467 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4096,13972,13839,4265,262144,1024,13972,4096,5653,5789,5823,8329,5788,267796,4096,4264,2081,4645,5668,4,0,4097,5156]

theorem envBound6467 : H12AffineFastState.Bounded env6467 := by
  intro p hp
  have h : env6467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6466_6467 : H12AffineEnvironment.transform 15 13839 env6466 = env6467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13839 env6466 == env6467) = true)

theorem identity6467 : scanCanonicalize (H12AffineFastState.compose env6467 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6467 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6468 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,4096,8192,4096,13957,13839,4265,262144,1024,13957,4096,5636,5772,5806,8329,5773,267781,4096,4264,2081,4645,5668,4,0,4097,5156]

theorem envBound6468 : H12AffineFastState.Bounded env6468 := by
  intro p hp
  have h : env6468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6467_6468 : H12AffineEnvironment.transform 3 1 env6467 = env6468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6467 == env6468) = true)

theorem identity6468 : scanCanonicalize (H12AffineFastState.compose env6468 (packedSelected [6,13,17] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound6468 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env6469 : List Nat := [2,4,8,1,32,1,128,4,512,1024,674,4096,8192,4096,13957,13839,4265,262144,1024,13957,4096,5636,5772,5806,8329,5773,267781,4096,4264,643,4645,5668,4,0,4097,5156]

theorem envBound6469 : H12AffineFastState.Bounded env6469 := by
  intro p hp
  have h : env6469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6468_6469 : H12AffineEnvironment.transform 10 674 env6468 = env6469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env6468 == env6469) = true)

theorem identity6469 : scanCanonicalize (H12AffineFastState.compose env6469 (packedSelected [13,21] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6469 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env6470 : List Nat := [2,4,8,1,32,1,40,4,512,1024,522,4096,8192,4096,13869,13839,4097,262144,1024,13869,4096,5636,5668,5638,8225,5669,267781,4096,4096,555,4645,5668,4,0,4097,5156]

theorem envBound6470 : H12AffineFastState.Bounded env6470 := by
  intro p hp
  have h : env6470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6469_6470 : H12AffineEnvironment.transform 6 40 env6469 = env6470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6469 == env6470) = true)

theorem identity6470 : scanCanonicalize (H12AffineFastState.compose env6470 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 5134) := by decide +kernel

theorem selectedBound6470 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6471 : List Nat := [2,4,8,1,32,1,40,4,512,1024,522,4096,8192,4096,13869,13839,4097,5134,1024,13869,4096,5636,5668,5638,8225,5669,523,4096,4096,555,4645,5668,4,0,4097,5156]

theorem envBound6471 : H12AffineFastState.Bounded env6471 := by
  intro p hp
  have h : env6471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6470_6471 : H12AffineEnvironment.transform 17 5134 env6470 = env6471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 5134 env6470 == env6471) = true)

theorem identity6471 : scanCanonicalize (H12AffineFastState.compose env6471 (packedSelected [5,8] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound6471 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6472 : List Nat := [2,4,8,1,32,1,40,4,512,1024,522,1541,8192,1541,8232,8202,1540,523,1024,8232,1541,1,33,3,8225,32,523,1541,1541,555,1056,33,4,0,1540,545]

theorem envBound6472 : H12AffineFastState.Bounded env6472 := by
  intro p hp
  have h : env6472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6471_6472 : H12AffineEnvironment.transform 11 1541 env6471 = env6472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env6471 == env6472) = true)

theorem identity6472 : scanCanonicalize (H12AffineFastState.compose env6472 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 1574) := by decide +kernel

theorem selectedBound6472 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env6473 : List Nat := [2,4,8,1,32,1,40,4,512,1024,522,1541,1574,1541,1550,1580,1540,523,1024,1550,1541,1,33,3,1543,32,523,1541,1541,555,1056,33,4,0,1540,545]

theorem envBound6473 : H12AffineFastState.Bounded env6473 := by
  intro p hp
  have h : env6473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6472_6473 : H12AffineEnvironment.transform 12 1574 env6472 = env6473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1574 env6472 == env6473) = true)

theorem identity6473 : scanCanonicalize (H12AffineFastState.compose env6473 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound6473 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env6474 : List Nat := [2,4,8,1,32,1,40,4,512,46,522,555,520,555,544,514,554,523,46,544,555,1,33,3,553,32,523,555,555,555,14,33,4,0,554,545]

theorem envBound6474 : H12AffineFastState.Bounded env6474 := by
  intro p hp
  have h : env6474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6473_6474 : H12AffineEnvironment.transform 9 46 env6473 = env6474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env6473 == env6474) = true)

theorem identity6474 : scanCanonicalize (H12AffineFastState.compose env6474 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound6474 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env6475 : List Nat := [2,4,8,1,32,1,40,4,32,46,42,11,40,11,0,34,10,43,46,0,11,1,33,3,9,32,43,11,11,11,14,33,4,0,10,1]

theorem envBound6475 : H12AffineFastState.Bounded env6475 := by
  intro p hp
  have h : env6475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6474_6475 : H12AffineEnvironment.transform 8 32 env6474 = env6475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env6474 == env6475) = true)

theorem identity6475 : scanCanonicalize (H12AffineFastState.compose env6475 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound6475 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6476 : List Nat := [2,4,8,1,11,1,3,4,11,5,1,11,3,11,0,9,10,0,5,0,11,1,10,3,9,11,0,11,11,11,14,10,4,0,10,1]

theorem envBound6476 : H12AffineFastState.Bounded env6476 := by
  intro p hp
  have h : env6476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6475_6476 : H12AffineEnvironment.transform 4 11 env6475 = env6476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env6475 == env6476) = true)

theorem identity6476 : scanCanonicalize (H12AffineFastState.compose env6476 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6476 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6477 : List Nat := [2,4,2,1,1,1,3,4,1,5,1,1,3,1,0,3,0,0,5,0,1,1,0,3,3,1,0,1,1,1,4,0,4,0,0,1]

theorem envBound6477 : H12AffineFastState.Bounded env6477 := by
  intro p hp
  have h : env6477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6476_6477 : H12AffineEnvironment.transform 2 2 env6476 = env6477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6476 == env6477) = true)

def env6478 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13973,65536,4265,262144,1024,13973,4096,5652,73874,5822,8329,73875,267796,4097,4265,2080,74794,73770,4,1,4097,74283]

theorem envBound6478 : H12AffineFastState.Bounded env6478 := by
  intro p hp
  have h : env6478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6465_6478 : H12AffineEnvironment.transform 13 4097 env6465 = env6478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env6465 == env6478) = true)

theorem identity6478 : scanCanonicalize (H12AffineFastState.compose env6478 (packedSelected [0,2,7,11,13,17,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 14007) := by decide +kernel

theorem selectedBound6478 : packedSelected [0,2,7,11,13,17,18,20] rootPS < 2^1333 := by decide +kernel

def env6479 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13973,14007,4265,262144,1024,13973,4096,5652,5669,5822,8329,5668,267796,4097,4265,2080,4765,5789,4,1,4097,5276]

theorem envBound6479 : H12AffineFastState.Bounded env6479 := by
  intro p hp
  have h : env6479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6478_6479 : H12AffineEnvironment.transform 15 14007 env6478 = env6479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14007 env6478 == env6479) = true)

theorem identity6479 : scanCanonicalize (H12AffineFastState.compose env6479 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1671) := by decide +kernel

theorem selectedBound6479 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6480 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13973,14007,4265,1671,1024,13973,4096,5652,5669,5822,8329,5668,4243,4097,4265,2080,4765,5789,4,1,4097,5276]

theorem envBound6480 : H12AffineFastState.Bounded env6480 := by
  intro p hp
  have h : env6480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6479_6480 : H12AffineEnvironment.transform 17 1671 env6479 = env6480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1671 env6479 == env6480) = true)

theorem identity6480 : scanCanonicalize (H12AffineFastState.compose env6480 (packedSelected [2,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound6480 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6481 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1550,4096,8192,4097,13973,14007,4265,1671,1024,13973,4096,5652,5669,5822,8329,5668,4243,4097,4265,1582,4765,5789,4,1,4097,5276]

theorem envBound6481 : H12AffineFastState.Bounded env6481 := by
  intro p hp
  have h : env6481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6480_6481 : H12AffineEnvironment.transform 10 1550 env6480 = env6481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env6480 == env6481) = true)

theorem identity6481 : scanCanonicalize (H12AffineFastState.compose env6481 (packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound6481 : packedSelected [0,3,4,5,7,9,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6482 : List Nat := [2,4,8,16,32,16,128,4,512,1024,1550,1588,8192,1589,8353,8323,1693,1671,1024,8353,1588,32,17,138,8329,16,1703,1589,1693,1582,1193,169,4,1,1589,680]

theorem envBound6482 : H12AffineFastState.Bounded env6482 := by
  intro p hp
  have h : env6482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6481_6482 : H12AffineEnvironment.transform 11 1588 env6481 = env6482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env6481 == env6482) = true)

theorem identity6482 : scanCanonicalize (H12AffineFastState.compose env6482 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound6482 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6483 : List Nat := [2,4,8,11,32,11,128,4,512,1024,1550,1583,8192,1582,8353,8323,1670,1671,1024,8353,1583,32,10,138,8329,11,1703,1582,1670,1582,1193,169,4,1,1582,680]

theorem envBound6483 : H12AffineFastState.Bounded env6483 := by
  intro p hp
  have h : env6483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6482_6483 : H12AffineEnvironment.transform 3 11 env6482 = env6483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env6482 == env6483) = true)

theorem identity6483 : scanCanonicalize (H12AffineFastState.compose env6483 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1198) := by decide +kernel

theorem selectedBound6483 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6484 : List Nat := [2,4,8,11,32,11,128,4,512,1024,1550,1583,1198,1582,1039,1069,1670,1671,1024,1039,1583,32,10,138,1063,11,1703,1582,1670,1582,1193,169,4,1,1582,680]

theorem envBound6484 : H12AffineFastState.Bounded env6484 := by
  intro p hp
  have h : env6484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6483_6484 : H12AffineEnvironment.transform 12 1198 env6483 = env6484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1198 env6483 == env6484) = true)

theorem identity6484 : scanCanonicalize (H12AffineFastState.compose env6484 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6484 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env6485 : List Nat := [2,4,8,11,32,11,40,4,512,1024,1550,1583,1030,1582,1039,1069,1582,1583,1024,1039,1583,32,10,34,1063,11,1551,1582,1582,1582,1025,1,4,1,1582,512]

theorem envBound6485 : H12AffineFastState.Bounded env6485 := by
  intro p hp
  have h : env6485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6484_6485 : H12AffineEnvironment.transform 6 40 env6484 = env6485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6484 == env6485) = true)

theorem identity6485 : scanCanonicalize (H12AffineFastState.compose env6485 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6485 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6486 : List Nat := [2,4,8,11,32,11,40,4,1,1024,1039,1070,1030,1071,1039,1069,1071,1070,1024,1039,1070,32,10,34,1063,11,1038,1071,1071,1071,1025,1,4,1,1071,1]

theorem envBound6486 : H12AffineFastState.Bounded env6486 := by
  intro p hp
  have h : env6486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6485_6486 : H12AffineEnvironment.transform 8 1 env6485 = env6486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6485 == env6486) = true)

theorem identity6486 : scanCanonicalize (H12AffineFastState.compose env6486 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound6486 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6487 : List Nat := [2,4,8,11,32,11,40,4,1,47,32,1,41,0,32,2,0,1,47,32,1,32,10,34,8,11,33,0,0,0,46,1,4,1,0,1]

theorem envBound6487 : H12AffineFastState.Bounded env6487 := by
  intro p hp
  have h : env6487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6486_6487 : H12AffineEnvironment.transform 9 47 env6486 = env6487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env6486 == env6487) = true)

def env6488 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,4194304,73875,41003,8329,73875,323713,16384,16813,22560,74794,4313519,256,20481,4239488,74543]

theorem envBound6488 : H12AffineFastState.Bounded env6488 := by
  intro p hp
  have h : env6488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6435_6488 : H12AffineEnvironment.transform 5 17 env6435 = env6488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6435 == env6488) = true)

theorem identity6488 : scanCanonicalize (H12AffineFastState.compose env6488 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound6488 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6489 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,4194304,444,41003,8329,444,323713,16384,16813,22560,1285,4255872,256,20481,4239488,512]

theorem envBound6489 : H12AffineFastState.Bounded env6489 := by
  intro p hp
  have h : env6489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6488_6489 : H12AffineEnvironment.transform 15 8495 env6488 = env6489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env6488 == env6489) = true)

theorem identity6489 : scanCanonicalize (H12AffineFastState.compose env6489 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound6489 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6490 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8495,4524,262144,1024,32768,4096,41349,444,41003,8329,444,323713,16384,16813,22560,1285,20741,256,20481,4357,512]

theorem envBound6490 : H12AffineFastState.Bounded env6490 := by
  intro p hp
  have h : env6490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6489_6490 : H12AffineEnvironment.transform 21 41349 env6489 = env6490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env6489 == env6490) = true)

theorem identity6490 : scanCanonicalize (H12AffineFastState.compose env6490 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6490 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6491 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,8495,4524,262144,1024,26261,4096,18192,444,18110,8329,444,267796,16384,16813,22560,1285,20741,256,20481,4357,512]

theorem envBound6491 : H12AffineFastState.Bounded env6491 := by
  intro p hp
  have h : env6491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6490_6491 : H12AffineEnvironment.transform 14 26261 env6490 = env6491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6490 == env6491) = true)

theorem identity6491 : scanCanonicalize (H12AffineFastState.compose env6491 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4524) := by decide +kernel

theorem selectedBound6491 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6492 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,262144,1024,14137,4096,5820,444,5906,8329,444,267796,4524,4097,2444,1285,169,256,429,4357,512]

theorem envBound6492 : H12AffineFastState.Bounded env6492 := by
  intro p hp
  have h : env6492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6491_6492 : H12AffineEnvironment.transform 13 4524 env6491 = env6492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4524 env6491 == env6492) = true)

theorem identity6492 : scanCanonicalize (H12AffineFastState.compose env6492 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6492 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6493 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,4524,14137,8495,4524,2185,1024,14137,4096,5820,444,5906,8329,444,7837,4524,4097,2444,1285,169,256,429,4357,512]

theorem envBound6493 : H12AffineFastState.Bounded env6493 := by
  intro p hp
  have h : env6493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6492_6493 : H12AffineEnvironment.transform 17 2185 env6492 = env6493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6492 == env6493) = true)

theorem identity6493 : scanCanonicalize (H12AffineFastState.compose env6493 (packedSelected [18,23] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound6493 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env6494 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,8192,4097,13972,8322,4097,2185,1024,13972,4096,5820,17,5823,8329,17,7837,4097,4097,2081,1192,169,173,0,4264,512]

theorem envBound6494 : H12AffineFastState.Bounded env6494 := by
  intro p hp
  have h : env6494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6493_6494 : H12AffineEnvironment.transform 7 173 env6493 = env6494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env6493 == env6494) = true)

theorem identity6494 : scanCanonicalize (H12AffineFastState.compose env6494 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound6494 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env6495 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,4096,8192,4097,13972,8322,4097,555,1024,13972,4096,5820,17,5823,8329,17,5183,4097,4097,643,1192,169,173,0,4264,512]

theorem envBound6495 : H12AffineFastState.Bounded env6495 := by
  intro p hp
  have h : env6495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6494_6495 : H12AffineEnvironment.transform 10 674 env6494 = env6495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env6494 == env6495) = true)

theorem identity6495 : scanCanonicalize (H12AffineFastState.compose env6495 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound6495 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6496 : List Nat := [2,4,8,16,32,17,128,173,512,1024,674,1692,8192,1693,8200,8322,1693,555,1024,8200,1692,32,17,35,8329,17,675,1693,1693,643,1192,169,173,0,1588,512]

theorem envBound6496 : H12AffineFastState.Bounded env6496 := by
  intro p hp
  have h : env6496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6495_6496 : H12AffineEnvironment.transform 11 1692 env6495 = env6496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env6495 == env6496) = true)

theorem identity6496 : scanCanonicalize (H12AffineFastState.compose env6496 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound6496 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6497 : List Nat := [2,4,8,16,32,17,40,5,512,1024,522,1588,8192,1589,8200,8234,1589,555,1024,8200,1588,32,17,35,8225,17,523,1589,1589,555,1024,1,5,0,1588,512]

theorem envBound6497 : H12AffineFastState.Bounded env6497 := by
  intro p hp
  have h : env6497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6496_6497 : H12AffineEnvironment.transform 6 40 env6496 = env6497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6496 == env6497) = true)

theorem identity6497 : scanCanonicalize (H12AffineFastState.compose env6497 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 51) := by decide +kernel

theorem selectedBound6497 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6498 : List Nat := [2,4,8,16,32,17,40,5,512,1024,522,1588,51,1589,59,25,1589,555,1024,59,1588,32,17,35,18,17,523,1589,1589,555,1024,1,5,0,1588,512]

theorem envBound6498 : H12AffineFastState.Bounded env6498 := by
  intro p hp
  have h : env6498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6497_6498 : H12AffineEnvironment.transform 12 51 env6497 = env6498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 51 env6497 == env6498) = true)

theorem identity6498 : scanCanonicalize (H12AffineFastState.compose env6498 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound6498 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6499 : List Nat := [2,4,8,16,16,17,24,5,512,1024,522,1540,3,1541,11,25,1541,539,1024,11,1540,16,17,19,18,17,523,1541,1541,539,1024,1,5,0,1540,512]

theorem envBound6499 : H12AffineFastState.Bounded env6499 := by
  intro p hp
  have h : env6499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6498_6499 : H12AffineEnvironment.transform 4 16 env6498 = env6499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env6498 == env6499) = true)

theorem identity6499 : scanCanonicalize (H12AffineFastState.compose env6499 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6499 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6500 : List Nat := [2,4,8,1,1,0,9,5,512,1024,522,1540,3,1541,11,8,1541,522,1024,11,1540,1,0,2,3,0,523,1541,1541,522,1024,1,5,0,1540,512]

theorem envBound6500 : H12AffineFastState.Bounded env6500 := by
  intro p hp
  have h : env6500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6499_6500 : H12AffineEnvironment.transform 3 1 env6499 = env6500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6499 == env6500) = true)

theorem identity6500 : scanCanonicalize (H12AffineFastState.compose env6500 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound6500 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6501 : List Nat := [2,4,8,1,1,0,9,5,11,1024,1,1039,3,1038,11,8,1038,1,1024,11,1039,1,0,2,3,0,0,1038,1038,1,1024,1,5,0,1039,11]

theorem envBound6501 : H12AffineFastState.Bounded env6501 := by
  intro p hp
  have h : env6501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6500_6501 : H12AffineEnvironment.transform 8 11 env6500 = env6501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env6500 == env6501) = true)

theorem identity6501 : scanCanonicalize (H12AffineFastState.compose env6501 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6501 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6502 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1,1029,3,1028,1,2,1028,1,1024,1,1029,1,0,2,3,0,0,1028,1028,1,1024,1,5,0,1029,1]

theorem envBound6502 : H12AffineFastState.Bounded env6502 := by
  intro p hp
  have h : env6502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6501_6502 : H12AffineEnvironment.transform 2 2 env6501 = env6502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6501 == env6502) = true)

def leafEnv6502 : List Nat := [2,4,2,1,1,0,3,5,1,1024,1,1029,3,1028,1,2,1028,1,1024,1,1029,1,0,2,1024,3,1,0,0,1028,1028,1,1024,1,5,0,4,3,1029,1,1,1029,0]

def active6502 : List Nat := [0,1,9]

def tree6502 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6502 : H12WitnessSearch.Good tree6502 := H12GlobalWitnessIndex.good

theorem leafIdentity6502 : H12AffineFastState.composeSystem env6502 rootObs = leafEnv6502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6502 rootObs == leafEnv6502) = true)

theorem terminalChecked6502 : H12PackedTerminal.terminalCheckFast leafEnv6502 active6502 tree6502 = true := by decide +kernel

def env6503 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323793,16384,16892,22640,74795,12644668,257,20561,4239488,8389612]

theorem envBound6503 : H12AffineFastState.Bounded env6503 := by
  intro p hp
  have h : env6503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6433_6503 : H12AffineEnvironment.transform 18 1025 env6433 = env6503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6433 == env6503) = true)

theorem identity6503 : scanCanonicalize (H12AffineFastState.compose env6503 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 26051) := by decide +kernel

theorem selectedBound6503 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,26051,4605,262144,1025,32768,4096,4194304,8388608,41003,8329,8388688,323793,16384,16892,22640,16872,12644668,257,20561,4239488,8389612]

theorem envBound6504 : H12AffineFastState.Bounded env6504 := by
  intro p hp
  have h : env6504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6503_6504 : H12AffineEnvironment.transform 15 26051 env6503 = env6504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 26051 env6503 == env6504) = true)

def env6505 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,4194304,8388608,41003,8329,8388608,323713,16384,16812,22560,16824,12644668,257,20481,4239488,8389564]

theorem envBound6505 : H12AffineFastState.Bounded env6505 := by
  intro p hp
  have h : env6505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6504_6505 : H12AffineEnvironment.transform 5 16 env6504 = env6505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6504 == env6505) = true)

theorem identity6505 : scanCanonicalize (H12AffineFastState.compose env6505 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound6505 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6506 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,4194304,444,41003,8329,444,323713,16384,16812,22560,16824,4255872,257,20481,4239488,512]

theorem envBound6506 : H12AffineFastState.Bounded env6506 := by
  intro p hp
  have h : env6506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6505_6506 : H12AffineEnvironment.transform 22 444 env6505 = env6506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env6505 == env6506) = true)

theorem identity6506 : scanCanonicalize (H12AffineFastState.compose env6506 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound6506 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6507 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,26003,4525,262144,1025,32768,4096,41348,444,41003,8329,444,323713,16384,16812,22560,16824,20740,257,20481,4356,512]

theorem envBound6507 : H12AffineFastState.Bounded env6507 := by
  intro p hp
  have h : env6507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6506_6507 : H12AffineEnvironment.transform 21 41348 env6506 = env6507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env6506 == env6507) = true)

theorem identity6507 : scanCanonicalize (H12AffineFastState.compose env6507 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6507 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6508 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,26003,4525,262144,1025,26260,4096,18192,444,18111,8329,444,267797,16384,16812,22560,16824,20740,257,20481,4356,512]

theorem envBound6508 : H12AffineFastState.Bounded env6508 := by
  intro p hp
  have h : env6508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6507_6508 : H12AffineEnvironment.transform 14 26260 env6507 = env6508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6507 == env6508) = true)

theorem identity6508 : scanCanonicalize (H12AffineFastState.compose env6508 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound6508 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6509 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,262144,1025,26260,1296,18192,444,18111,8329,444,262917,16384,16812,19760,16824,17428,257,17681,1044,512]

theorem envBound6509 : H12AffineFastState.Bounded env6509 := by
  intro p hp
  have h : env6509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6508_6509 : H12AffineEnvironment.transform 11 1296 env6508 = env6509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env6508 == env6509) = true)

theorem identity6509 : scanCanonicalize (H12AffineFastState.compose env6509 (packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6509 : packedSelected [0,1,3,8,10,11,12,15,27,28,32] rootPS < 2^1333 := by decide +kernel

def env6510 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1296,8192,16384,26260,26003,1213,2341,1025,26260,1296,18192,444,18111,8329,444,2592,16384,16812,19760,16824,17428,257,17681,1044,512]

theorem envBound6510 : H12AffineFastState.Bounded env6510 := by
  intro p hp
  have h : env6510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6509_6510 : H12AffineEnvironment.transform 17 2341 env6509 = env6510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env6509 == env6510) = true)

def env6511 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1025,32768,4096,4194304,8388608,41003,8329,8388609,323712,16384,16813,22561,16825,12644668,257,20480,4239488,8389565]

theorem envBound6511 : H12AffineFastState.Bounded env6511 := by
  intro p hp
  have h : env6511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6504_6511 : H12AffineEnvironment.transform 5 17 env6504 = env6511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6504 == env6511) = true)

def env6512 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1025,32768,4096,4194304,4240696,41003,8329,4240697,323712,16384,16813,22561,16825,17412,257,20480,4239488,4241029]

theorem envBound6512 : H12AffineFastState.Bounded env6512 := by
  intro p hp
  have h : env6512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6511_6512 : H12AffineEnvironment.transform 22 4240696 env6511 = env6512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240696 env6511 == env6512) = true)

theorem identity6512 : scanCanonicalize (H12AffineFastState.compose env6512 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13577) := by decide +kernel

theorem selectedBound6512 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6513 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13577,26002,4524,262144,1025,13577,4096,4194304,4194353,5410,8329,4194352,279945,16384,16813,22561,16825,17412,257,20480,4195721,4195212]

theorem envBound6513 : H12AffineFastState.Bounded env6513 := by
  intro p hp
  have h : env6513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6512_6513 : H12AffineEnvironment.transform 14 13577 env6512 = env6513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13577 env6512 == env6513) = true)

def env6514 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13577,25986,4524,262144,1025,13577,4096,4194304,4194337,5410,8329,4194336,279945,16384,16813,22561,16809,17412,257,20480,4195721,4195212]

theorem envBound6514 : H12AffineFastState.Bounded env6514 := by
  intro p hp
  have h : env6514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6513_6514 : H12AffineEnvironment.transform 3 0 env6513 = env6514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6513 == env6514) = true)

def env6515 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13577,25986,4524,262144,1025,13577,4096,32,1,5410,8329,0,279945,16384,16813,22561,16809,17412,257,20480,1449,940]

theorem envBound6515 : H12AffineFastState.Bounded env6515 := by
  intro p hp
  have h : env6515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6514_6515 : H12AffineEnvironment.transform 21 32 env6514 = env6515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env6514 == env6515) = true)

theorem identity6515 : scanCanonicalize (H12AffineFastState.compose env6515 (packedSelected [7,20,27] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound6515 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env6516 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1028,8192,16384,8461,25986,1448,262144,1025,8461,1028,32,1,294,8329,0,279945,16384,16813,19493,16809,17412,257,17412,1449,940]

theorem envBound6516 : H12AffineFastState.Bounded env6516 := by
  intro p hp
  have h : env6516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6515_6516 : H12AffineEnvironment.transform 11 1028 env6515 = env6516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env6515 == env6516) = true)

theorem identity6516 : scanCanonicalize (H12AffineFastState.compose env6516 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19597) := by decide +kernel

theorem selectedBound6516 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env6517 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,1028,8192,16384,8461,25986,1448,19597,1025,8461,1028,32,1,294,8329,0,2308,16384,16813,19493,16809,17412,257,17412,1449,940]

theorem envBound6517 : H12AffineFastState.Bounded env6517 := by
  intro p hp
  have h : env6517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6516_6517 : H12AffineEnvironment.transform 17 19597 env6516 = env6517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19597 env6516 == env6517) = true)

theorem identity6517 : scanCanonicalize (H12AffineFastState.compose env6517 (packedSelected [0,1,2,3,5,6,7,8,12,13,15] rootPS)) = affineNative (2^(10+1) ^^^ 674) := by decide +kernel

theorem selectedBound6517 : packedSelected [0,1,2,3,5,6,7,8,12,13,15] rootPS < 2^1333 := by decide +kernel

def env6518 : List Nat := [2,4,8,0,32,1,128,256,512,1024,674,1028,8192,16384,8461,25986,1448,17967,1025,8461,1028,32,1,294,8329,0,934,16384,16813,18055,16809,17412,257,17412,1449,940]

theorem envBound6518 : H12AffineFastState.Bounded env6518 := by
  intro p hp
  have h : env6518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6517_6518 : H12AffineEnvironment.transform 10 674 env6517 = env6518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 674 env6517 == env6518) = true)

theorem identity6518 : scanCanonicalize (H12AffineFastState.compose env6518 (packedSelected [0,1,3,4,5,6,7,8,9,13,20] rootPS)) = affineNative (2^(13+1) ^^^ 8493) := by decide +kernel

theorem selectedBound6518 : packedSelected [0,1,3,4,5,6,7,8,9,13,20] rootPS < 2^1333 := by decide +kernel

def env6519 : List Nat := [2,4,8,0,32,1,128,256,512,1024,674,1028,8192,8493,8461,1199,1448,9986,1025,8461,1028,32,1,294,8329,0,934,8493,8320,10154,8324,9513,257,9513,1449,940]

theorem envBound6519 : H12AffineFastState.Bounded env6519 := by
  intro p hp
  have h : env6519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6518_6519 : H12AffineEnvironment.transform 13 8493 env6518 = env6519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8493 env6518 == env6519) = true)

theorem identity6519 : scanCanonicalize (H12AffineFastState.compose env6519 (packedSelected [2,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound6519 : packedSelected [2,11,12] rootPS < 2^1333 := by decide +kernel

def env6520 : List Nat := [2,4,8,0,32,1,128,256,32,1024,130,1028,8192,8493,8461,1199,1448,9506,1025,8461,1028,32,1,294,8329,0,390,8493,8320,9610,8324,9513,257,9513,1449,396]

theorem envBound6520 : H12AffineFastState.Bounded env6520 := by
  intro p hp
  have h : env6520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6519_6520 : H12AffineEnvironment.transform 8 32 env6519 = env6520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env6519 == env6520) = true)

theorem identity6520 : scanCanonicalize (H12AffineFastState.compose env6520 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1408) := by decide +kernel

theorem selectedBound6520 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6521 : List Nat := [2,4,8,0,32,1,128,256,32,1024,130,1028,1408,1197,1165,1199,1448,162,1025,1165,1028,32,1,294,1289,0,390,1197,1280,10,1284,169,257,169,1449,396]

theorem envBound6521 : H12AffineFastState.Bounded env6521 := by
  intro p hp
  have h : env6521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6520_6521 : H12AffineEnvironment.transform 12 1408 env6520 = env6521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env6520 == env6521) = true)

theorem identity6521 : scanCanonicalize (H12AffineFastState.compose env6521 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6521 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6522 : List Nat := [2,4,8,0,32,1,41,256,32,1024,43,1028,1321,1028,1060,1030,1281,11,1025,1060,1028,32,1,294,1289,0,303,1028,1280,10,1284,0,257,0,1280,293]

theorem envBound6522 : H12AffineFastState.Bounded env6522 := by
  intro p hp
  have h : env6522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6521_6522 : H12AffineEnvironment.transform 6 41 env6521 = env6522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6521 == env6522) = true)

theorem identity6522 : scanCanonicalize (H12AffineFastState.compose env6522 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6522 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6523 : List Nat := [2,4,2,0,32,1,35,256,32,1024,33,1028,1315,1028,1060,1030,1281,1,1025,1060,1028,32,1,294,1283,0,293,1028,1280,0,1284,0,257,0,1280,293]

theorem envBound6523 : H12AffineFastState.Bounded env6523 := by
  intro p hp
  have h : env6523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6522_6523 : H12AffineEnvironment.transform 2 2 env6522 = env6523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6522 == env6523) = true)

theorem identity6523 : scanCanonicalize (H12AffineFastState.compose env6523 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6523 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6524 : List Nat := [2,4,2,0,32,1,35,4,32,1024,33,1028,1063,1028,1060,1030,1029,1,1025,1060,1028,32,1,34,1031,0,33,1028,1028,0,1024,0,5,0,1028,33]

theorem envBound6524 : H12AffineFastState.Bounded env6524 := by
  intro p hp
  have h : env6524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6523_6524 : H12AffineEnvironment.transform 7 4 env6523 = env6524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6523 == env6524) = true)

theorem identity6524 : scanCanonicalize (H12AffineFastState.compose env6524 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6524 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6525 : List Nat := [2,0,2,0,32,1,35,0,32,1024,33,1024,1059,1024,1056,1026,1025,1,1025,1056,1024,32,1,34,1027,0,33,1024,1024,0,1024,0,1,0,1024,33]

theorem envBound6525 : H12AffineFastState.Bounded env6525 := by
  intro p hp
  have h : env6525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6524_6525 : H12AffineEnvironment.transform 1 0 env6524 = env6525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6524 == env6525) = true)

theorem identity6525 : scanCanonicalize (H12AffineFastState.compose env6525 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6525 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6526 : List Nat := [2,0,2,0,0,1,3,0,0,1024,1,1024,1027,1024,1024,1026,1025,1,1025,1024,1024,0,1,2,1027,0,1,1024,1024,0,1024,0,1,0,1024,1]

theorem envBound6526 : H12AffineFastState.Bounded env6526 := by
  intro p hp
  have h : env6526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6525_6526 : H12AffineEnvironment.transform 4 0 env6525 = env6526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6525 == env6526) = true)

theorem identity6526 : scanCanonicalize (H12AffineFastState.compose env6526 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound6526 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6527 : List Nat := [2,0,2,0,0,1,3,0,0,1,1,1,2,1,1,3,0,1,0,1,1,0,1,2,2,0,1,1,1,0,1,0,1,0,1,1]

theorem envBound6527 : H12AffineFastState.Bounded env6527 := by
  intro p hp
  have h : env6527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6526_6527 : H12AffineEnvironment.transform 9 1 env6526 = env6527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env6526 == env6527) = true)

def env6528 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13577,25986,4524,262144,1025,13577,4096,33,0,5410,8329,1,279945,16384,16813,22561,16809,17412,257,20480,1448,941]

theorem envBound6528 : H12AffineFastState.Bounded env6528 := by
  intro p hp
  have h : env6528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6514_6528 : H12AffineEnvironment.transform 21 33 env6514 = env6528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env6514 == env6528) = true)

theorem identity6528 : scanCanonicalize (H12AffineFastState.compose env6528 (packedSelected [7,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6528 : packedSelected [7,20,27] rootPS < 2^1333 := by decide +kernel

def env6529 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,25646,4096,262144,1025,13477,4096,33,0,5262,8329,1,279589,16384,16385,22561,16389,17412,173,20480,1028,513]

theorem envBound6529 : H12AffineFastState.Bounded env6529 := by
  intro p hp
  have h : env6529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6528_6529 : H12AffineEnvironment.transform 7 172 env6528 = env6529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6528 == env6529) = true)

theorem identity6529 : scanCanonicalize (H12AffineFastState.compose env6529 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 1191) := by decide +kernel

theorem selectedBound6529 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6530 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,25646,4096,1191,1025,13477,4096,33,0,5262,8329,1,16514,16384,16385,22561,16389,17412,173,20480,1028,513]

theorem envBound6530 : H12AffineFastState.Bounded env6530 := by
  intro p hp
  have h : env6530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6529_6530 : H12AffineEnvironment.transform 17 1191 env6529 = env6530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1191 env6529 == env6530) = true)

theorem identity6530 : scanCanonicalize (H12AffineFastState.compose env6530 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound6530 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6531 : List Nat := [2,4,8,0,32,1,128,172,136,1024,2048,4096,8192,16384,13477,25646,4096,1191,1025,13477,4096,33,0,5262,8329,1,16514,16384,16385,22561,16389,17412,173,20480,1028,137]

theorem envBound6531 : H12AffineFastState.Bounded env6531 := by
  intro p hp
  have h : env6531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6530_6531 : H12AffineEnvironment.transform 8 136 env6530 = env6531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env6530 == env6531) = true)

theorem identity6531 : scanCanonicalize (H12AffineFastState.compose env6531 (packedSelected [13,21] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6531 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env6532 : List Nat := [2,4,8,0,32,1,41,5,33,1024,2048,4096,8192,16384,13324,25646,4096,1038,1025,13324,4096,33,0,5159,8224,1,16427,16384,16385,22561,16389,17412,4,20480,1028,32]

theorem envBound6532 : H12AffineFastState.Bounded env6532 := by
  intro p hp
  have h : env6532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6531_6532 : H12AffineEnvironment.transform 6 41 env6531 = env6532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6531 == env6532) = true)

theorem identity6532 : scanCanonicalize (H12AffineFastState.compose env6532 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound6532 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env6533 : List Nat := [2,4,8,0,32,1,41,5,33,1024,1038,4096,8192,16384,13324,25646,4096,1038,1025,13324,4096,33,0,5159,8224,1,16427,16384,16385,21551,16389,17412,4,20480,1028,32]

theorem envBound6533 : H12AffineFastState.Bounded env6533 := by
  intro p hp
  have h : env6533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6532_6533 : H12AffineEnvironment.transform 10 1038 env6532 = env6533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env6532 == env6533) = true)

theorem identity6533 : scanCanonicalize (H12AffineFastState.compose env6533 (packedSelected [0,1,3,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 4141) := by decide +kernel

theorem selectedBound6533 : packedSelected [0,1,3,7,8] rootPS < 2^1333 := by decide +kernel

def env6534 : List Nat := [2,4,8,0,32,1,41,5,33,1024,1038,4096,4141,16384,1057,21507,4096,1038,1025,1057,4096,33,0,5159,4109,1,16427,16384,16385,21551,16389,17412,4,20480,1028,32]

theorem envBound6534 : H12AffineFastState.Bounded env6534 := by
  intro p hp
  have h : env6534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6533_6534 : H12AffineEnvironment.transform 12 4141 env6533 = env6534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4141 env6533 == env6534) = true)

theorem identity6534 : scanCanonicalize (H12AffineFastState.compose env6534 (packedSelected [1,4,9,12,13] rootPS)) = affineNative (2^(13+1) ^^^ 1034) := by decide +kernel

theorem selectedBound6534 : packedSelected [1,4,9,12,13] rootPS < 2^1333 := by decide +kernel

def env6535 : List Nat := [2,4,8,0,32,1,41,5,33,1024,1038,4096,4141,1034,1057,4105,4096,1038,1025,1057,4096,33,0,5159,4109,1,1057,1034,1035,4133,1039,14,4,5130,1028,32]

theorem envBound6535 : H12AffineFastState.Bounded env6535 := by
  intro p hp
  have h : env6535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6534_6535 : H12AffineEnvironment.transform 13 1034 env6534 = env6535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1034 env6534 == env6535) = true)

theorem identity6535 : scanCanonicalize (H12AffineFastState.compose env6535 (packedSelected [0,2] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound6535 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6536 : List Nat := [2,4,8,0,32,1,41,5,33,1024,1038,42,7,1034,1057,35,42,1038,1025,1057,42,33,0,1037,39,1,1057,1034,1035,15,1039,14,4,1056,1028,32]

theorem envBound6536 : H12AffineFastState.Bounded env6536 := by
  intro p hp
  have h : env6536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6535_6536 : H12AffineEnvironment.transform 11 42 env6535 = env6536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env6535 == env6536) = true)

theorem identity6536 : scanCanonicalize (H12AffineFastState.compose env6536 (packedSelected [1,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 11) := by decide +kernel

theorem selectedBound6536 : packedSelected [1,3,4,5] rootPS < 2^1333 := by decide +kernel

def env6537 : List Nat := [2,4,8,0,32,1,41,5,33,11,5,42,7,1,42,35,42,5,10,42,42,33,0,6,39,1,42,1,0,15,4,14,4,43,15,32]

theorem envBound6537 : H12AffineFastState.Bounded env6537 := by
  intro p hp
  have h : env6537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6536_6537 : H12AffineEnvironment.transform 9 11 env6536 = env6537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 11 env6536 == env6537) = true)

theorem identity6537 : scanCanonicalize (H12AffineFastState.compose env6537 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound6537 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env6538 : List Nat := [2,4,6,0,32,1,39,5,33,5,5,36,7,1,36,35,36,5,4,36,36,33,0,6,39,1,36,1,0,1,4,0,4,37,1,32]

theorem envBound6538 : H12AffineFastState.Bounded env6538 := by
  intro p hp
  have h : env6538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6537_6538 : H12AffineEnvironment.transform 2 6 env6537 = env6538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env6537 == env6538) = true)

theorem identity6538 : scanCanonicalize (H12AffineFastState.compose env6538 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound6538 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6539 : List Nat := [2,0,2,0,32,1,35,1,33,1,1,32,3,1,32,35,32,1,0,32,32,33,0,2,35,1,32,1,0,1,0,0,0,33,1,32]

theorem envBound6539 : H12AffineFastState.Bounded env6539 := by
  intro p hp
  have h : env6539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6538_6539 : H12AffineEnvironment.transform 1 0 env6538 = env6539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6538 == env6539) = true)

def env6540 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,13577,25987,4524,262144,1025,13577,4096,4194304,4194336,5410,8329,4194337,279945,16384,16813,22561,16808,17412,257,20480,4195721,4195212]

theorem envBound6540 : H12AffineFastState.Bounded env6540 := by
  intro p hp
  have h : env6540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6513_6540 : H12AffineEnvironment.transform 3 1 env6513 = env6540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6513 == env6540) = true)

theorem identity6540 : scanCanonicalize (H12AffineFastState.compose env6540 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound6540 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6541 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1028,8192,16384,8461,25987,1448,262144,1025,8461,1028,4194304,4194336,294,8329,4194337,279945,16384,16813,19493,16808,17412,257,17412,4195721,4195212]

theorem envBound6541 : H12AffineFastState.Bounded env6541 := by
  intro p hp
  have h : env6541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6540_6541 : H12AffineEnvironment.transform 11 1028 env6540 = env6541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env6540 == env6541) = true)

theorem identity6541 : scanCanonicalize (H12AffineFastState.compose env6541 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6541 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6542 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8200,25734,1197,262144,1025,8200,1028,4194304,4194336,35,8329,4194337,279692,16384,16552,19493,16557,17412,4,17412,4195468,4194953]

theorem envBound6542 : H12AffineFastState.Bounded env6542 := by
  intro p hp
  have h : env6542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6541_6542 : H12AffineEnvironment.transform 7 5 env6541 = env6542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6541 == env6542) = true)

theorem identity6542 : scanCanonicalize (H12AffineFastState.compose env6542 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound6542 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6543 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1028,8192,16384,8200,25734,1197,2185,1025,8200,1028,4194304,4194336,35,8329,4194337,19461,16384,16552,19493,16557,17412,4,17412,4195468,4194953]

theorem envBound6543 : H12AffineFastState.Bounded env6543 := by
  intro p hp
  have h : env6543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6542_6543 : H12AffineEnvironment.transform 17 2185 env6542 = env6543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env6542 == env6543) = true)

theorem identity6543 : scanCanonicalize (H12AffineFastState.compose env6543 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6543 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6544 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8200,25734,1165,2185,1025,8200,1028,4194304,4194304,3,8329,4194305,19461,16384,16520,19461,16525,17412,4,17412,4195468,4194953]

theorem envBound6544 : H12AffineFastState.Bounded env6544 := by
  intro p hp
  have h : env6544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6543_6544 : H12AffineEnvironment.transform 4 0 env6543 = env6544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6543 == env6544) = true)

theorem identity6544 : scanCanonicalize (H12AffineFastState.compose env6544 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 27655) := by decide +kernel

theorem selectedBound6544 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env6545 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,16384,8200,25734,1165,2185,1025,8200,1028,27655,27655,3,8329,27654,19461,16384,16520,19461,16525,17412,4,17412,26763,28302]

theorem envBound6545 : H12AffineFastState.Bounded env6545 := by
  intro p hp
  have h : env6545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6544_6545 : H12AffineEnvironment.transform 21 27655 env6544 = env6545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 27655 env6544 == env6545) = true)

theorem identity6545 : scanCanonicalize (H12AffineFastState.compose env6545 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 11276) := by decide +kernel

theorem selectedBound6545 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6546 : List Nat := [2,4,8,1,0,0,128,5,512,1024,2048,1028,8192,11276,8200,2186,1165,2185,1025,8200,1028,11,11,3,8329,10,8201,11276,11396,8201,11393,10248,4,10248,1159,642]

theorem envBound6546 : H12AffineFastState.Bounded env6546 := by
  intro p hp
  have h : env6546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6545_6546 : H12AffineEnvironment.transform 13 11276 env6545 = env6546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11276 env6545 == env6546) = true)

theorem identity6546 : scanCanonicalize (H12AffineFastState.compose env6546 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound6546 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env6547 : List Nat := [2,4,8,1,0,0,128,5,512,1024,512,1028,8192,9740,8200,650,1165,649,1025,8200,1028,11,11,3,8329,10,8201,9740,9860,8201,9857,8712,4,8712,1159,642]

theorem envBound6547 : H12AffineFastState.Bounded env6547 := by
  intro p hp
  have h : env6547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6546_6547 : H12AffineEnvironment.transform 10 512 env6546 = env6547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env6546 == env6547) = true)

theorem identity6547 : scanCanonicalize (H12AffineFastState.compose env6547 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(12+1) ^^^ 641) := by decide +kernel

theorem selectedBound6547 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env6548 : List Nat := [2,4,8,1,0,0,128,5,512,1024,512,1028,641,1165,649,650,1165,649,1025,649,1028,11,11,3,520,10,648,1165,1029,648,1024,137,4,137,1159,642]

theorem envBound6548 : H12AffineFastState.Bounded env6548 := by
  intro p hp
  have h : env6548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6547_6548 : H12AffineEnvironment.transform 12 641 env6547 = env6548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 641 env6547 == env6548) = true)

theorem identity6548 : scanCanonicalize (H12AffineFastState.compose env6548 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6548 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env6549 : List Nat := [2,4,8,1,0,0,128,5,1,1024,1,1028,128,1165,136,139,1165,136,1025,136,1028,11,11,3,9,10,137,1165,1029,137,1024,137,4,137,1159,131]

theorem envBound6549 : H12AffineFastState.Bounded env6549 := by
  intro p hp
  have h : env6549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6548_6549 : H12AffineEnvironment.transform 8 1 env6548 = env6549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6548 == env6549) = true)

theorem identity6549 : scanCanonicalize (H12AffineFastState.compose env6549 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound6549 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env6550 : List Nat := [2,4,8,1,0,0,128,5,1,4,1,0,128,137,136,139,137,136,5,136,0,11,11,3,9,10,137,137,1,137,4,137,4,137,131,131]

theorem envBound6550 : H12AffineFastState.Bounded env6550 := by
  intro p hp
  have h : env6550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6549_6550 : H12AffineEnvironment.transform 9 4 env6549 = env6550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env6549 == env6550) = true)

theorem identity6550 : scanCanonicalize (H12AffineFastState.compose env6550 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound6550 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6551 : List Nat := [2,4,8,1,0,0,3,5,1,4,1,0,3,10,11,8,10,11,5,11,0,11,11,3,9,10,10,10,1,10,4,10,4,10,0,0]

theorem envBound6551 : H12AffineFastState.Bounded env6551 := by
  intro p hp
  have h : env6551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6550_6551 : H12AffineEnvironment.transform 6 3 env6550 = env6551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env6550 == env6551) = true)

def env6552 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4524,262144,1025,32768,4096,4194304,4240697,41003,8329,4240696,323712,16384,16813,22561,16825,17413,257,20480,4239488,4241028]

theorem envBound6552 : H12AffineFastState.Bounded env6552 := by
  intro p hp
  have h : env6552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6511_6552 : H12AffineEnvironment.transform 22 4240697 env6511 = env6552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240697 env6511 == env6552) = true)

theorem identity6552 : scanCanonicalize (H12AffineFastState.compose env6552 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 13493) := by decide +kernel

theorem selectedBound6552 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6553 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13493,26002,4524,262144,1025,13493,4096,4194304,4194700,5278,8329,4194701,279605,16384,16813,22561,16825,17413,257,20480,4195381,4194865]

theorem envBound6553 : H12AffineFastState.Bounded env6553 := by
  intro p hp
  have h : env6553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6552_6553 : H12AffineEnvironment.transform 14 13493 env6552 = env6553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13493 env6552 == env6553) = true)

def env6554 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1448,8192,16384,8477,26002,1028,262144,1025,8477,1448,4194304,4194700,310,8329,4194701,279605,16384,16813,19849,16825,17413,257,17832,4195381,4194865]

theorem envBound6554 : H12AffineFastState.Bounded env6554 := by
  intro p hp
  have h : env6554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6553_6554 : H12AffineEnvironment.transform 11 1448 env6553 = env6554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env6553 == env6554) = true)

theorem identity6554 : scanCanonicalize (H12AffineFastState.compose env6554 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2461) := by decide +kernel

theorem selectedBound6554 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env6555 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1448,8192,16384,8477,26002,1028,2461,1025,8477,1448,4194304,4194700,310,8329,4194701,19880,16384,16813,19849,16825,17413,257,17832,4195381,4194865]

theorem envBound6555 : H12AffineFastState.Bounded env6555 := by
  intro p hp
  have h : env6555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6554_6555 : H12AffineEnvironment.transform 17 2461 env6554 = env6555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2461 env6554 == env6555) = true)

theorem identity6555 : scanCanonicalize (H12AffineFastState.compose env6555 (packedSelected [0,4,7,13,17,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6555 : packedSelected [0,4,7,13,17,22] rootPS < 2^1333 := by decide +kernel

def env6556 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1281,8192,16384,8477,25915,1028,2356,1025,8477,1281,4194304,4194597,310,8224,4194596,19713,16384,16644,19744,16656,17413,257,17665,4195381,4194865]

theorem envBound6556 : H12AffineFastState.Bounded env6556 := by
  intro p hp
  have h : env6556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6555_6556 : H12AffineEnvironment.transform 6 41 env6555 = env6556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6555 == env6556) = true)

theorem identity6556 : scanCanonicalize (H12AffineFastState.compose env6556 (packedSelected [2,6,7,9,10,11,12,13] rootPS)) = affineNative (2^(21+1) ^^^ 17713) := by decide +kernel

theorem selectedBound6556 : packedSelected [2,6,7,9,10,11,12,13] rootPS < 2^1333 := by decide +kernel

def env6557 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1281,8192,16384,8477,25915,1028,2356,1025,8477,1281,17713,17428,310,8224,17429,19713,16384,16644,19744,16656,17413,257,17665,16644,18176]

theorem envBound6557 : H12AffineFastState.Bounded env6557 := by
  intro p hp
  have h : env6557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6556_6557 : H12AffineEnvironment.transform 21 17713 env6556 = env6557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17713 env6556 == env6557) = true)

theorem identity6557 : scanCanonicalize (H12AffineFastState.compose env6557 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1564) := by decide +kernel

theorem selectedBound6557 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env6558 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1281,1564,16384,1793,17191,1028,2356,1025,1793,1281,17713,17428,310,1596,17429,19713,16384,16644,19744,16656,17413,257,17665,16644,18176]

theorem envBound6558 : H12AffineFastState.Bounded env6558 := by
  intro p hp
  have h : env6558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6557_6558 : H12AffineEnvironment.transform 12 1564 env6557 = env6558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1564 env6557 == env6558) = true)

theorem identity6558 : scanCanonicalize (H12AffineFastState.compose env6558 (packedSelected [0,1,3,4,6,7,9,10,12] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound6558 : packedSelected [0,1,3,4,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env6559 : List Nat := [2,4,8,16,27,17,18,256,512,1024,2048,1281,1564,16384,1793,17180,1028,2319,1025,1793,1281,17674,17428,269,1543,17429,19713,16384,16644,19739,16656,17413,257,17665,16644,18176]

theorem envBound6559 : H12AffineFastState.Bounded env6559 := by
  intro p hp
  have h : env6559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6558_6559 : H12AffineEnvironment.transform 4 27 env6558 = env6559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env6558 == env6559) = true)

theorem identity6559 : scanCanonicalize (H12AffineFastState.compose env6559 (packedSelected [1,2,4,5,7,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 1818) := by decide +kernel

theorem selectedBound6559 : packedSelected [1,2,4,5,7,10,17] rootPS < 2^1333 := by decide +kernel

def env6560 : List Nat := [2,4,8,16,27,17,18,256,512,1024,2048,1281,1564,1818,1793,1030,1028,2319,1025,1793,1281,528,782,269,1543,783,2587,1818,1566,2561,1546,799,257,539,1566,26]

theorem envBound6560 : H12AffineFastState.Bounded env6560 := by
  intro p hp
  have h : env6560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6559_6560 : H12AffineEnvironment.transform 13 1818 env6559 = env6560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1818 env6559 == env6560) = true)

theorem identity6560 : scanCanonicalize (H12AffineFastState.compose env6560 (packedSelected [2,3,8,10,20] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound6560 : packedSelected [2,3,8,10,20] rootPS < 2^1333 := by decide +kernel

def env6561 : List Nat := [2,4,8,16,27,17,18,21,512,1024,2048,1044,1564,1551,1556,1030,1028,2074,1025,1556,1044,528,539,24,1543,538,2587,1551,1566,2561,1546,522,20,539,1566,26]

theorem envBound6561 : H12AffineFastState.Bounded env6561 := by
  intro p hp
  have h : env6561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6560_6561 : H12AffineEnvironment.transform 7 21 env6560 = env6561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env6560 == env6561) = true)

theorem identity6561 : scanCanonicalize (H12AffineFastState.compose env6561 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1055) := by decide +kernel

theorem selectedBound6561 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6562 : List Nat := [2,4,8,16,27,17,18,21,512,1024,1055,1044,1564,1551,1556,1030,1028,1029,1025,1556,1044,528,539,24,1543,538,1540,1551,1566,1566,1546,522,20,539,1566,26]

theorem envBound6562 : H12AffineFastState.Bounded env6562 := by
  intro p hp
  have h : env6562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6561_6562 : H12AffineEnvironment.transform 10 1055 env6561 = env6562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1055 env6561 == env6562) = true)

theorem identity6562 : scanCanonicalize (H12AffineFastState.compose env6562 (packedSelected [0,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound6562 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env6563 : List Nat := [2,4,8,16,27,17,18,21,1,1024,1055,1044,1053,1038,1045,1030,1028,1029,1025,1045,1044,17,26,24,1030,27,1029,1038,1055,1055,1035,11,20,26,1055,26]

theorem envBound6563 : H12AffineFastState.Bounded env6563 := by
  intro p hp
  have h : env6563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6562_6563 : H12AffineEnvironment.transform 8 1 env6562 = env6563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env6562 == env6563) = true)

theorem identity6563 : scanCanonicalize (H12AffineFastState.compose env6563 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6564 : List Nat := [2,4,8,10,1,11,8,15,1,1024,1029,1038,1031,1038,1039,1030,1028,1029,1025,1039,1038,11,0,2,1030,1,1029,1038,1029,1029,1035,11,14,0,1029,0]

theorem envBound6564 : H12AffineFastState.Bounded env6564 := by
  intro p hp
  have h : env6564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6563_6564 : H12AffineEnvironment.transform 3 10 env6563 = env6564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6563 == env6564) = true)

theorem identity6564 : scanCanonicalize (H12AffineFastState.compose env6564 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound6564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6565 : List Nat := [2,4,8,10,1,11,8,15,1,10,15,4,13,4,5,12,14,15,11,5,4,11,0,2,12,1,15,4,15,15,1,11,14,0,15,0]

theorem envBound6565 : H12AffineFastState.Bounded env6565 := by
  intro p hp
  have h : env6565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6564_6565 : H12AffineEnvironment.transform 9 10 env6564 = env6565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env6564 == env6565) = true)

theorem identity6565 : scanCanonicalize (H12AffineFastState.compose env6565 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6565 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6566 : List Nat := [2,4,3,1,1,0,3,4,1,1,4,4,6,4,5,7,5,4,0,5,4,0,0,2,7,1,4,4,4,4,1,0,5,0,4,0]

theorem envBound6566 : H12AffineFastState.Bounded env6566 := by
  intro p hp
  have h : env6566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6565_6566 : H12AffineEnvironment.transform 2 3 env6565 = env6566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6565 == env6566) = true)

theorem identity6566 : scanCanonicalize (H12AffineFastState.compose env6566 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound6566 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6567 : List Nat := [2,1,3,1,1,0,3,1,1,1,1,1,3,1,0,2,0,1,0,0,1,0,0,2,2,1,1,1,1,1,1,0,0,0,1,0]

theorem envBound6567 : H12AffineFastState.Bounded env6567 := by
  intro p hp
  have h : env6567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6566_6567 : H12AffineEnvironment.transform 1 1 env6566 = env6567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6566 == env6567) = true)

def env6568 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1449,8192,16384,8476,26002,1029,262144,1025,8476,1449,4194304,4194700,311,8329,4194701,279605,16384,16813,19848,16825,17413,257,17833,4195381,4194865]

theorem envBound6568 : H12AffineFastState.Bounded env6568 := by
  intro p hp
  have h : env6568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6553_6568 : H12AffineEnvironment.transform 11 1449 env6553 = env6568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env6553 == env6568) = true)

theorem identity6568 : scanCanonicalize (H12AffineFastState.compose env6568 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound6568 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6569 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1029,8192,16384,8368,25662,1029,262144,1025,8368,1029,4194304,4194336,155,8329,4194337,279605,16384,16385,19492,16405,17413,173,17413,4195381,4194865]

theorem envBound6569 : H12AffineFastState.Bounded env6569 := by
  intro p hp
  have h : env6569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6568_6569 : H12AffineEnvironment.transform 7 172 env6568 = env6569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env6568 == env6569) = true)

theorem identity6569 : scanCanonicalize (H12AffineFastState.compose env6569 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound6569 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6570 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,8192,16384,8217,25662,1029,262144,1025,8217,1029,4194304,4194336,50,8224,4194337,279605,16384,16385,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound6570 : H12AffineFastState.Bounded env6570 := by
  intro p hp
  have h : env6570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6569_6570 : H12AffineEnvironment.transform 6 41 env6569 = env6570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6569 == env6570) = true)

theorem identity6570 : scanCanonicalize (H12AffineFastState.compose env6570 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound6570 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6571 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,8192,16384,8217,25662,1029,19508,1025,8217,1029,4194304,4194336,50,8224,4194337,2049,16384,16385,19492,16405,17413,4,17413,4195381,4194865]

theorem envBound6571 : H12AffineFastState.Bounded env6571 := by
  intro p hp
  have h : env6571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6570_6571 : H12AffineEnvironment.transform 17 19508 env6570 = env6571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env6570 == env6571) = true)

theorem identity6571 : scanCanonicalize (H12AffineFastState.compose env6571 (packedSelected [2,3,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 24601) := by decide +kernel

theorem selectedBound6571 : packedSelected [2,3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env6572 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,8192,16384,8217,25662,1029,19508,1025,8217,1029,24601,24633,50,8224,24632,2049,16384,16385,19492,16405,17413,4,17413,25644,25128]

theorem envBound6572 : H12AffineFastState.Bounded env6572 := by
  intro p hp
  have h : env6572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6571_6572 : H12AffineEnvironment.transform 21 24601 env6571 = env6572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 24601 env6571 == env6572) = true)

theorem identity6572 : scanCanonicalize (H12AffineFastState.compose env6572 (packedSelected [3,5,6,11] rootPS)) = affineNative (2^(12+1) ^^^ 1591) := by decide +kernel

theorem selectedBound6572 : packedSelected [3,5,6,11] rootPS < 2^1333 := by decide +kernel

def env6573 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,1591,16384,1582,16905,1029,19508,1025,1582,1029,17966,17934,50,1559,17935,2049,16384,16385,19492,16405,17413,4,17413,16923,17439]

theorem envBound6573 : H12AffineFastState.Bounded env6573 := by
  intro p hp
  have h : env6573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6572_6573 : H12AffineEnvironment.transform 12 1591 env6572 = env6573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1591 env6572 == env6573) = true)

theorem identity6573 : scanCanonicalize (H12AffineFastState.compose env6573 (packedSelected [0,2,3,4,5,6,7,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 1029) := by decide +kernel

theorem selectedBound6573 : packedSelected [0,2,3,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env6574 : List Nat := [2,4,8,16,32,17,41,5,512,1024,2048,1029,1591,1029,1582,1548,1029,2097,1025,1582,1029,555,523,50,1559,522,2049,1029,1028,2081,1040,0,4,0,1566,26]

theorem envBound6574 : H12AffineFastState.Bounded env6574 := by
  intro p hp
  have h : env6574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6573_6574 : H12AffineEnvironment.transform 13 1029 env6573 = env6574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1029 env6573 == env6574) = true)

theorem identity6574 : scanCanonicalize (H12AffineFastState.compose env6574 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound6574 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env6575 : List Nat := [2,4,8,16,32,17,41,5,512,1024,1541,1029,1591,1029,1582,1548,1029,1588,1025,1582,1029,555,523,50,1559,522,1540,1029,1028,1572,1040,0,4,0,1566,26]

theorem envBound6575 : H12AffineFastState.Bounded env6575 := by
  intro p hp
  have h : env6575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6574_6575 : H12AffineEnvironment.transform 10 1541 env6574 = env6575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env6574 == env6575) = true)

theorem identity6575 : scanCanonicalize (H12AffineFastState.compose env6575 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound6575 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6576 : List Nat := [2,4,8,16,32,17,41,5,32,1024,1061,1029,1047,1029,1038,1068,1029,1044,1025,1038,1029,11,43,50,1079,42,1060,1029,1028,1028,1040,0,4,0,1086,26]

theorem envBound6576 : H12AffineFastState.Bounded env6576 := by
  intro p hp
  have h : env6576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6575_6576 : H12AffineEnvironment.transform 8 32 env6575 = env6576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env6575 == env6576) = true)

theorem identity6576 : scanCanonicalize (H12AffineFastState.compose env6576 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound6576 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6577 : List Nat := [2,4,8,1,32,0,41,5,32,1024,1061,1029,1030,1029,1038,1068,1029,1029,1025,1038,1029,11,43,35,1062,42,1060,1029,1028,1028,1025,0,4,0,1071,11]

theorem envBound6577 : H12AffineFastState.Bounded env6577 := by
  intro p hp
  have h : env6577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6576_6577 : H12AffineEnvironment.transform 3 1 env6576 = env6577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6576 == env6577) = true)

theorem identity6577 : scanCanonicalize (H12AffineFastState.compose env6577 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound6577 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6578 : List Nat := [2,4,8,1,0,0,9,5,0,1024,1029,1029,1030,1029,1038,1036,1029,1029,1025,1038,1029,11,11,3,1030,10,1028,1029,1028,1028,1025,0,4,0,1039,11]

theorem envBound6578 : H12AffineFastState.Bounded env6578 := by
  intro p hp
  have h : env6578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6577_6578 : H12AffineEnvironment.transform 4 0 env6577 = env6578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env6577 == env6578) = true)

theorem identity6578 : scanCanonicalize (H12AffineFastState.compose env6578 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound6578 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6579 : List Nat := [2,4,8,1,0,0,9,5,0,4,1,1,2,1,10,8,1,1,5,10,1,11,11,3,2,10,0,1,0,0,5,0,4,0,11,11]

theorem envBound6579 : H12AffineFastState.Bounded env6579 := by
  intro p hp
  have h : env6579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6578_6579 : H12AffineEnvironment.transform 9 4 env6578 = env6579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env6578 == env6579) = true)

theorem identity6579 : scanCanonicalize (H12AffineFastState.compose env6579 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6579 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6580 : List Nat := [2,4,3,1,0,0,2,5,0,4,1,1,2,1,1,3,1,1,5,1,1,0,0,3,2,1,0,1,0,0,5,0,4,0,0,0]

theorem envBound6580 : H12AffineFastState.Bounded env6580 := by
  intro p hp
  have h : env6580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6579_6580 : H12AffineEnvironment.transform 2 3 env6579 = env6580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6579 == env6580) = true)

def env6581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,524288,32768,4097,4194304,8388608,41003,8329,8914001,849105,16384,16892,547952,598058,12644669,525568,545873,4239489,8914925]

theorem envBound6581 : H12AffineFastState.Bounded env6581 := by
  intro p hp
  have h : env6581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6432_6581 : H12AffineEnvironment.transform 20 4097 env6432 = env6581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env6432 == env6581) = true)

def env6582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,4194304,8388608,41003,8329,8388689,323793,16384,16892,22640,74794,12644669,256,20561,4239489,8389613]

theorem envBound6582 : H12AffineFastState.Bounded env6582 := by
  intro p hp
  have h : env6582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6581_6582 : H12AffineEnvironment.transform 18 1024 env6581 = env6582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env6581 == env6582) = true)

theorem identity6582 : scanCanonicalize (H12AffineFastState.compose env6582 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98387) := by decide +kernel

theorem selectedBound6582 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1024,32768,4097,98387,8388608,41003,8329,8388689,323793,16384,16892,22640,74794,8483182,256,20561,78034,8389613]

theorem envBound6583 : H12AffineFastState.Bounded env6583 := by
  intro p hp
  have h : env6583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6582_6583 : H12AffineEnvironment.transform 21 98387 env6582 = env6583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98387 env6582 == env6583) = true)

def env6584 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,98307,8388608,41003,8329,8388609,323713,16384,16812,22560,74794,8483134,256,20481,77954,8389565]

theorem envBound6584 : H12AffineFastState.Bounded env6584 := by
  intro p hp
  have h : env6584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6583_6584 : H12AffineEnvironment.transform 5 16 env6583 = env6584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6583 == env6584) = true)

theorem identity6584 : scanCanonicalize (H12AffineFastState.compose env6584 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound6584 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6585 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4097,98307,445,41003,8329,444,323713,16384,16812,22560,74794,94339,256,20481,77954,512]

theorem envBound6585 : H12AffineFastState.Bounded env6585 := by
  intro p hp
  have h : env6585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6584_6585 : H12AffineEnvironment.transform 22 445 env6584 = env6585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env6584 == env6585) = true)

theorem identity6585 : scanCanonicalize (H12AffineFastState.compose env6585 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound6585 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6586 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4525,262144,1024,32768,4097,41348,445,41003,8329,444,323713,16384,16812,22560,1453,20740,256,20481,4357,512]

theorem envBound6586 : H12AffineFastState.Bounded env6586 := by
  intro p hp
  have h : env6586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6585_6586 : H12AffineEnvironment.transform 15 8583 env6585 = env6586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env6585 == env6586) = true)

theorem identity6586 : scanCanonicalize (H12AffineFastState.compose env6586 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26260) := by decide +kernel

theorem selectedBound6586 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6587 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,26260,8583,4525,262144,1024,26260,4097,18192,445,18111,8329,444,267797,16384,16812,22560,1453,20740,256,20481,4357,512]

theorem envBound6587 : H12AffineFastState.Bounded env6587 := by
  intro p hp
  have h : env6587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6586_6587 : H12AffineEnvironment.transform 14 26260 env6586 = env6587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26260 env6586 == env6587) = true)

theorem identity6587 : scanCanonicalize (H12AffineFastState.compose env6587 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4356) := by decide +kernel

theorem selectedBound6587 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6588 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4356,14224,8583,4525,262144,1024,14224,4097,5652,445,6075,8329,444,267797,4356,4264,2340,1453,0,256,261,4357,512]

theorem envBound6588 : H12AffineFastState.Bounded env6588 := by
  intro p hp
  have h : env6588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6587_6588 : H12AffineEnvironment.transform 13 4356 env6587 = env6588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4356 env6587 == env6588) = true)

def env6589 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4097,98306,8388608,41003,8329,8388608,323712,16384,16813,22561,74794,8483135,256,20480,77955,8389564]

theorem envBound6589 : H12AffineFastState.Bounded env6589 := by
  intro p hp
  have h : env6589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6583_6589 : H12AffineEnvironment.transform 5 17 env6583 = env6589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6583 == env6589) = true)

def env6590 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4097,98306,8388608,41003,8225,8388608,323624,16384,16645,22561,74794,8483135,256,20480,77867,8389396]

theorem envBound6590 : H12AffineFastState.Bounded env6590 := by
  intro p hp
  have h : env6590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6589_6590 : H12AffineEnvironment.transform 6 40 env6589 = env6590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env6589 == env6590) = true)

theorem identity6590 : scanCanonicalize (H12AffineFastState.compose env6590 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(22+1) ^^^ 284981) := by decide +kernel

theorem selectedBound6590 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6591 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4097,98306,284981,41003,8225,284981,323624,16384,16645,22561,74794,337930,256,20480,77867,285217]

theorem envBound6591 : H12AffineFastState.Bounded env6591 := by
  intro p hp
  have h : env6591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6590_6591 : H12AffineEnvironment.transform 22 284981 env6590 = env6591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284981 env6590 == env6591) = true)

theorem identity6591 : scanCanonicalize (H12AffineFastState.compose env6591 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound6591 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env6592 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,32768,65536,4356,2080,1024,32768,4097,98306,20757,41003,8225,20757,63496,16384,16645,22561,74794,73770,256,20480,77867,20993]

theorem envBound6592 : H12AffineFastState.Bounded env6592 := by
  intro p hp
  have h : env6592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6591_6592 : H12AffineEnvironment.transform 17 2080 env6591 = env6592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env6591 == env6592) = true)

theorem identity6592 : scanCanonicalize (H12AffineFastState.compose env6592 (packedSelected [2,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound6592 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env6593 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,16384,8460,65536,4356,2080,1024,8460,4097,73998,20757,295,8225,20757,22788,16384,16645,22561,74794,73770,256,20480,77867,20993]

theorem envBound6593 : H12AffineFastState.Bounded env6593 := by
  intro p hp
  have h : env6593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6592_6593 : H12AffineEnvironment.transform 14 8460 env6592 = env6593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env6592 == env6593) = true)

theorem identity6593 : scanCanonicalize (H12AffineFastState.compose env6593 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 11545) := by decide +kernel

theorem selectedBound6593 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env6594 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,8192,11545,8460,65536,4356,2080,1024,8460,4097,73998,15372,295,8225,15372,13341,11545,11292,13624,74794,73770,256,15641,77867,16152]

theorem envBound6594 : H12AffineFastState.Bounded env6594 := by
  intro p hp
  have h : env6594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6593_6594 : H12AffineEnvironment.transform 13 11545 env6593 = env6594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11545 env6593 == env6594) = true)

theorem identity6594 : scanCanonicalize (H12AffineFastState.compose env6594 (packedSelected [1,2,5,11] rootPS)) = affineNative (2^(12+1) ^^^ 7708) := by decide +kernel

theorem selectedBound6594 : packedSelected [1,2,5,11] rootPS < 2^1333 := by decide +kernel

def env6595 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,4096,7708,4869,7952,65536,4356,2080,1024,7952,4097,73490,528,295,7741,528,2561,4869,4608,2852,72246,73270,256,773,69175,260]

theorem envBound6595 : H12AffineFastState.Bounded env6595 := by
  intro p hp
  have h : env6595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6594_6595 : H12AffineEnvironment.transform 12 7708 env6594 = env6595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7708 env6594 == env6595) = true)

theorem identity6595 : scanCanonicalize (H12AffineFastState.compose env6595 (packedSelected [1,3,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1589) := by decide +kernel

theorem selectedBound6595 : packedSelected [1,3,10,12] rootPS < 2^1333 := by decide +kernel

def env6596 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1589,2089,1328,2341,65536,1841,2080,1024,2341,1588,67879,528,295,2056,528,2561,1328,1077,2852,68611,67587,256,773,69175,260]

theorem envBound6596 : H12AffineFastState.Bounded env6596 := by
  intro p hp
  have h : env6596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6595_6596 : H12AffineEnvironment.transform 11 1589 env6595 = env6596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1589 env6595 == env6596) = true)

theorem identity6596 : scanCanonicalize (H12AffineFastState.compose env6596 (packedSelected [0,1,2,5,6,9] rootPS)) = affineNative (2^(15+1) ^^^ 2563) := by decide +kernel

theorem selectedBound6596 : packedSelected [0,1,2,5,6,9] rootPS < 2^1333 := by decide +kernel

def env6597 : List Nat := [2,4,8,16,32,17,40,256,512,1024,2048,1589,2089,1328,2341,2563,1841,2080,1024,2341,1588,804,528,295,2056,528,2561,1328,1077,2852,1536,512,256,773,1076,260]

theorem envBound6597 : H12AffineFastState.Bounded env6597 := by
  intro p hp
  have h : env6597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6596_6597 : H12AffineEnvironment.transform 15 2563 env6596 = env6597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2563 env6596 == env6597) = true)

theorem identity6597 : scanCanonicalize (H12AffineFastState.compose env6597 (packedSelected [1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound6597 : packedSelected [1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6598 : List Nat := [2,4,8,16,32,17,40,256,512,1024,32,1589,9,1328,261,547,1841,0,1024,261,1588,804,528,295,40,528,545,1328,1077,772,1536,512,256,773,1076,260]

theorem envBound6598 : H12AffineFastState.Bounded env6598 := by
  intro p hp
  have h : env6598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6597_6598 : H12AffineEnvironment.transform 10 32 env6597 = env6598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env6597 == env6598) = true)

theorem identity6598 : scanCanonicalize (H12AffineFastState.compose env6598 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound6598 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6599 : List Nat := [2,4,8,16,32,17,40,256,27,1024,32,1070,9,1328,261,56,1322,0,1024,261,1071,319,11,295,40,11,58,1328,1077,287,1051,27,256,286,1076,260]

theorem envBound6599 : H12AffineFastState.Bounded env6599 := by
  intro p hp
  have h : env6599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6598_6599 : H12AffineEnvironment.transform 8 27 env6598 = env6599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env6598 == env6599) = true)

theorem identity6599 : scanCanonicalize (H12AffineFastState.compose env6599 (packedSelected [4,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6599 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env6600 : List Nat := [2,4,8,16,32,17,40,5,27,1024,32,1070,9,1077,0,56,1071,0,1024,0,1071,58,11,34,40,11,58,1077,1077,26,1051,27,5,27,1076,1]

theorem envBound6600 : H12AffineFastState.Bounded env6600 := by
  intro p hp
  have h : env6600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6599_6600 : H12AffineEnvironment.transform 7 5 env6599 = env6600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6599 == env6600) = true)

theorem identity6600 : scanCanonicalize (H12AffineFastState.compose env6600 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound6600 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6601 : List Nat := [2,4,8,16,32,17,40,5,27,47,32,1,9,26,0,56,0,0,47,0,0,58,11,34,40,11,58,26,26,26,52,27,5,27,27,1]

theorem envBound6601 : H12AffineFastState.Bounded env6601 := by
  intro p hp
  have h : env6601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6600_6601 : H12AffineEnvironment.transform 9 47 env6600 = env6601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env6600 == env6601) = true)

def env6602 : List Nat := [2,4,8,4,32,5,40,5,15,47,32,1,9,14,0,44,0,0,47,0,0,46,11,34,40,11,46,14,14,14,32,15,5,15,15,1]

theorem envBound6602 : H12AffineFastState.Bounded env6602 := by
  intro p hp
  have h : env6602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6601_6602 : H12AffineEnvironment.transform 3 4 env6601 = env6602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env6601 == env6602) = true)

def env6603 : List Nat := [2,0,8,0,32,1,40,1,11,43,32,1,9,10,0,40,0,0,43,0,0,42,11,34,40,11,42,10,10,10,32,11,1,11,11,1]

theorem envBound6603 : H12AffineFastState.Bounded env6603 := by
  intro p hp
  have h : env6603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6602_6603 : H12AffineEnvironment.transform 1 0 env6602 = env6603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env6602 == env6603) = true)

def env6604 : List Nat := [2,1,8,1,32,0,40,0,10,42,32,1,9,11,0,41,0,0,42,0,0,43,11,34,40,11,43,11,11,11,32,10,0,10,10,1]

theorem envBound6604 : H12AffineFastState.Bounded env6604 := by
  intro p hp
  have h : env6604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6602_6604 : H12AffineEnvironment.transform 1 1 env6602 = env6604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env6602 == env6604) = true)

theorem identity6604 : scanCanonicalize (H12AffineFastState.compose env6604 (packedSelected [10] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6604 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env6605 : List Nat := [2,1,2,1,32,0,34,0,0,32,32,1,3,1,0,35,0,0,32,0,0,33,1,34,34,1,33,1,1,1,32,0,0,0,0,1]

theorem envBound6605 : H12AffineFastState.Bounded env6605 := by
  intro p hp
  have h : env6605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6604_6605 : H12AffineEnvironment.transform 2 2 env6604 = env6605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6604 == env6605) = true)

def leafEnv6605 : List Nat := [2,1,2,1,32,0,34,0,0,32,32,1,3,1,0,35,0,0,32,0,0,33,1,34,32,34,1,1,33,1,1,1,32,0,0,0,1,2,0,1,1,1,0]

def active6605 : List Nat := [0,4]

def tree6605 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6605 : H12WitnessSearch.Good tree6605 := H12GlobalWitnessIndex.good

theorem leafIdentity6605 : H12AffineFastState.composeSystem env6605 rootObs = leafEnv6605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6605 rootObs == leafEnv6605) = true)

theorem terminalChecked6605 : H12PackedTerminal.terminalCheckFast leafEnv6605 active6605 tree6605 = true := by decide +kernel

def env6606 : List Nat := [2,4,8,5,32,4,40,5,14,47,32,1,9,15,0,45,0,0,47,0,0,47,11,34,40,11,47,15,15,15,33,14,5,14,14,1]

theorem envBound6606 : H12AffineFastState.Bounded env6606 := by
  intro p hp
  have h : env6606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6601_6606 : H12AffineEnvironment.transform 3 5 env6601 = env6606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env6601 == env6606) = true)

theorem identity6606 : scanCanonicalize (H12AffineFastState.compose env6606 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound6606 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6607 : List Nat := [2,4,7,5,32,4,39,5,1,32,32,1,6,0,0,34,0,0,32,0,0,32,4,34,39,4,32,0,0,0,33,1,5,1,1,1]

theorem envBound6607 : H12AffineFastState.Bounded env6607 := by
  intro p hp
  have h : env6607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6606_6607 : H12AffineEnvironment.transform 2 7 env6606 = env6607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env6606 == env6607) = true)

def env6608 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4097,98306,8388608,41003,8224,8388608,323625,16384,16644,22561,74794,8483135,256,20480,77866,8389397]

theorem envBound6608 : H12AffineFastState.Bounded env6608 := by
  intro p hp
  have h : env6608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6589_6608 : H12AffineEnvironment.transform 6 41 env6589 = env6608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env6589 == env6608) = true)

theorem identity6608 : scanCanonicalize (H12AffineFastState.compose env6608 (packedSelected [0,7,9,18,20,22,23] rootPS)) = affineNative (2^(17+1) ^^^ 96266) := by decide +kernel

theorem selectedBound6608 : packedSelected [0,7,9,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env6609 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,65536,4357,96266,1024,32768,4097,98306,8388608,41003,8224,8388608,100387,16384,16644,22561,74794,8483135,256,20480,77866,8389397]

theorem envBound6609 : H12AffineFastState.Bounded env6609 := by
  intro p hp
  have h : env6609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6608_6609 : H12AffineEnvironment.transform 17 96266 env6608 = env6609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 96266 env6608 == env6609) = true)

theorem identity6609 : scanCanonicalize (H12AffineFastState.compose env6609 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 53282) := by decide +kernel

theorem selectedBound6609 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env6610 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,16384,32768,53282,4357,43048,1024,32768,4097,20512,8388608,41003,8224,8388608,22529,16384,16644,22561,62472,8429853,256,20480,57352,8389397]

theorem envBound6610 : H12AffineFastState.Bounded env6610 := by
  intro p hp
  have h : env6610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6609_6610 : H12AffineEnvironment.transform 15 53282 env6609 = env6610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53282 env6609 == env6610) = true)

theorem identity6610 : scanCanonicalize (H12AffineFastState.compose env6610 (packedSelected [0,1,7,8,9,10,12,13,17,18,22] rootPS)) = affineNative (2^(11+1) ^^^ 1588) := by decide +kernel

theorem selectedBound6610 : packedSelected [0,1,7,8,9,10,12,13,17,18,22] rootPS < 2^1333 := by decide +kernel

def env6611 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1588,8192,16384,32768,50710,1841,43048,1024,32768,1589,17940,8388608,41003,8224,8388608,20021,16384,16644,19989,57916,8429853,256,17972,57352,8389397]

theorem envBound6611 : H12AffineFastState.Bounded env6611 := by
  intro p hp
  have h : env6611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6610_6611 : H12AffineEnvironment.transform 11 1588 env6610 = env6611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1588 env6610 == env6611) = true)

theorem identity6611 : scanCanonicalize (H12AffineFastState.compose env6611 (packedSelected [5,10,12,17,18,20,21,24] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6611 : packedSelected [5,10,12,17,18,20,21,24] rootPS < 2^1333 := by decide +kernel

def env6612 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1588,8192,16384,8200,26142,1841,2080,1024,8200,1589,17940,8388608,35,8224,8388608,20021,16384,16644,19989,16948,8388885,256,17972,16384,8389397]

theorem envBound6612 : H12AffineFastState.Bounded env6612 := by
  intro p hp
  have h : env6612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6611_6612 : H12AffineEnvironment.transform 14 8200 env6611 = env6612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6611 == env6612) = true)

theorem identity6612 : scanCanonicalize (H12AffineFastState.compose env6612 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(22+1) ^^^ 18209) := by decide +kernel

theorem selectedBound6612 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env6613 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1588,8192,16384,8200,26142,1841,2080,1024,8200,1589,17940,18209,35,8224,18209,20021,16384,16644,19989,16948,17972,256,17972,16384,17460]

theorem envBound6613 : H12AffineFastState.Bounded env6613 := by
  intro p hp
  have h : env6613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6612_6613 : H12AffineEnvironment.transform 22 18209 env6612 = env6613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 18209 env6612 == env6613) = true)

theorem identity6613 : scanCanonicalize (H12AffineFastState.compose env6613 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6613 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6614 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1588,8192,2341,8200,12091,1841,2080,1024,8200,1589,3889,3588,35,8224,3588,1808,2341,2081,1840,2833,3857,256,3857,2341,3345]

theorem envBound6614 : H12AffineFastState.Bounded env6614 := by
  intro p hp
  have h : env6614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6613_6614 : H12AffineEnvironment.transform 13 2341 env6613 = env6614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2341 env6613 == env6614) = true)

theorem identity6614 : scanCanonicalize (H12AffineFastState.compose env6614 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 2839) := by decide +kernel

theorem selectedBound6614 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env6615 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1588,2839,2341,2847,1068,1841,2080,1024,2847,1589,3889,3588,35,2871,3588,1808,2341,2081,1840,2833,3857,256,3857,2341,3345]

theorem envBound6615 : H12AffineFastState.Bounded env6615 := by
  intro p hp
  have h : env6615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6614_6615 : H12AffineEnvironment.transform 12 2839 env6614 = env6615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2839 env6614 == env6615) = true)

theorem identity6615 : scanCanonicalize (H12AffineFastState.compose env6615 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound6615 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env6616 : List Nat := [2,4,8,16,32,17,41,31,512,1024,2048,1588,2568,2106,2560,1068,1582,2080,1024,2560,1589,3630,3588,35,2600,3588,1551,2106,2081,1583,2574,3598,31,3598,2106,3086]

theorem envBound6616 : H12AffineFastState.Bounded env6616 := by
  intro p hp
  have h : env6616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6615_6616 : H12AffineEnvironment.transform 7 31 env6615 = env6616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env6615 == env6616) = true)

theorem identity6616 : scanCanonicalize (H12AffineFastState.compose env6616 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound6616 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env6617 : List Nat := [2,4,8,10,32,11,41,5,512,1024,2048,1582,2568,2080,2560,1068,1582,2080,1024,2560,1583,3630,3588,35,2600,3588,1551,2080,2081,1583,2574,3598,5,3598,2080,3086]

theorem envBound6617 : H12AffineFastState.Bounded env6617 := by
  intro p hp
  have h : env6617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6616_6617 : H12AffineEnvironment.transform 3 10 env6616 = env6617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env6616 == env6617) = true)

theorem identity6617 : scanCanonicalize (H12AffineFastState.compose env6617 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1551) := by decide +kernel

theorem selectedBound6617 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env6618 : List Nat := [2,4,8,10,32,11,41,5,512,1024,1551,1582,1031,1583,1039,1068,1582,1583,1024,1039,1583,33,11,35,1063,11,1551,1583,1582,1583,1025,1,5,1,1583,513]

theorem envBound6618 : H12AffineFastState.Bounded env6618 := by
  intro p hp
  have h : env6618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6617_6618 : H12AffineEnvironment.transform 10 1551 env6617 = env6618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1551 env6617 == env6618) = true)

theorem identity6618 : scanCanonicalize (H12AffineFastState.compose env6618 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 47) := by decide +kernel

theorem selectedBound6618 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env6619 : List Nat := [2,4,8,10,32,11,41,5,47,1024,1056,1025,1031,1024,1039,1068,1025,1024,1024,1039,1024,33,11,35,1063,11,1056,1024,1025,1024,1025,1,5,1,1024,46]

theorem envBound6619 : H12AffineFastState.Bounded env6619 := by
  intro p hp
  have h : env6619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6618_6619 : H12AffineEnvironment.transform 8 47 env6618 = env6619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 47 env6618 == env6619) = true)

def env6620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,8388608,41003,8329,8388688,323792,16384,16892,22641,74795,12644669,257,20560,4239489,8389612]

theorem envBound6620 : H12AffineFastState.Bounded env6620 := by
  intro p hp
  have h : env6620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6581_6620 : H12AffineEnvironment.transform 18 1025 env6581 = env6620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env6581 == env6620) = true)

theorem identity6620 : scanCanonicalize (H12AffineFastState.compose env6620 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310355) := by decide +kernel

theorem selectedBound6620 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env6621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4605,262144,1025,32768,4097,4194304,4310355,41003,8329,4310275,323792,16384,16892,22641,74795,78958,257,20560,4239489,4310719]

theorem envBound6621 : H12AffineFastState.Bounded env6621 := by
  intro p hp
  have h : env6621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6620_6621 : H12AffineEnvironment.transform 22 4310355 env6620 = env6621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310355 env6620 == env6621) = true)

def env6622 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4097,4194304,4310275,41003,8329,4310275,323712,16384,16812,22561,74795,78910,257,20480,4239489,4310719]

theorem envBound6622 : H12AffineFastState.Bounded env6622 := by
  intro p hp
  have h : env6622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6621_6622 : H12AffineEnvironment.transform 5 16 env6621 = env6622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env6621 == env6622) = true)

def env6623 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,65536,1029,262144,1025,32768,1449,4194304,4310275,41003,8329,4310275,320808,16384,16812,19849,74795,74134,257,17832,4236585,4310719]

theorem envBound6623 : H12AffineFastState.Bounded env6623 := by
  intro p hp
  have h : env6623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6622_6623 : H12AffineEnvironment.transform 11 1448 env6622 = env6623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env6622 == env6623) = true)

theorem identity6623 : scanCanonicalize (H12AffineFastState.compose env6623 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50318) := by decide +kernel

theorem selectedBound6623 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6624 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,50318,1029,262144,1025,32768,1449,4194304,4194701,41003,8329,4194701,320808,16384,16812,19849,57509,58648,257,17832,4236585,4194865]

theorem envBound6624 : H12AffineFastState.Bounded env6624 := by
  intro p hp
  have h : env6624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6623_6624 : H12AffineEnvironment.transform 15 50318 env6623 = env6624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50318 env6623 == env6624) = true)

def env6625 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,32768,50318,1029,262144,1025,32768,1449,4194304,4194701,41003,8329,4194701,320808,16384,16812,19849,57509,58632,257,17832,4236585,4194849]

theorem envBound6625 : H12AffineFastState.Bounded env6625 := by
  intro p hp
  have h : env6625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6624_6625 : H12AffineEnvironment.transform 3 0 env6624 = env6625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6624 == env6625) = true)

theorem identity6625 : scanCanonicalize (H12AffineFastState.compose env6625 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6625 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env6626 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,8200,25734,1029,262144,1025,8200,1449,4194304,4194701,35,8329,4194701,279840,16384,16812,19849,16557,17664,257,17832,4195617,4194849]

theorem envBound6626 : H12AffineFastState.Bounded env6626 := by
  intro p hp
  have h : env6626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6625_6626 : H12AffineEnvironment.transform 14 8200 env6625 = env6626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6625 == env6626) = true)

theorem identity6626 : scanCanonicalize (H12AffineFastState.compose env6626 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound6626 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6627 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,8200,25734,1029,262144,1025,8200,1449,32,429,35,8329,429,279840,16384,16812,19849,16557,17664,257,17832,1281,513]

theorem envBound6627 : H12AffineFastState.Bounded env6627 := by
  intro p hp
  have h : env6627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6626_6627 : H12AffineEnvironment.transform 21 32 env6626 = env6627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env6626 == env6627) = true)

theorem identity6627 : scanCanonicalize (H12AffineFastState.compose env6627 (packedSelected [0,7,20] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound6627 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6628 : List Nat := [2,4,8,0,32,0,128,256,397,1024,2048,1448,8192,16384,8200,25734,1029,262144,1025,8200,1449,32,429,35,8329,429,279840,16384,16812,19849,16557,17664,257,17832,1281,396]

theorem envBound6628 : H12AffineFastState.Bounded env6628 := by
  intro p hp
  have h : env6628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6627_6628 : H12AffineEnvironment.transform 8 397 env6627 = env6628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env6627 == env6628) = true)

theorem identity6628 : scanCanonicalize (H12AffineFastState.compose env6628 (packedSelected [1,3,12,13,15,21] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound6628 : packedSelected [1,3,12,13,15,21] rootPS < 2^1333 := by decide +kernel

def env6629 : List Nat := [2,4,8,0,32,0,128,256,397,1024,2048,1448,8192,16384,8200,25734,1029,2445,1025,8200,1449,32,429,35,8329,429,19629,16384,16812,19849,16557,17664,257,17832,1281,396]

theorem envBound6629 : H12AffineFastState.Bounded env6629 := by
  intro p hp
  have h : env6629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6628_6629 : H12AffineEnvironment.transform 17 2445 env6628 = env6629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env6628 == env6629) = true)

theorem identity6629 : scanCanonicalize (H12AffineFastState.compose env6629 (packedSelected [1,3,6,7,9,15] rootPS)) = affineNative (2^(12+1) ^^^ 2436) := by decide +kernel

theorem selectedBound6629 : packedSelected [1,3,6,7,9,15] rootPS < 2^1333 := by decide +kernel

def env6630 : List Nat := [2,4,8,0,32,0,128,256,397,1024,2048,1448,2436,16384,2444,19714,1029,2445,1025,2444,1449,32,429,35,2317,429,19629,16384,16812,19849,16557,17664,257,17832,1281,396]

theorem envBound6630 : H12AffineFastState.Bounded env6630 := by
  intro p hp
  have h : env6630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6629_6630 : H12AffineEnvironment.transform 12 2436 env6629 = env6630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2436 env6629 == env6630) = true)

theorem identity6630 : scanCanonicalize (H12AffineFastState.compose env6630 (packedSelected [0,2,7] rootPS)) = affineNative (2^(13+1) ^^^ 1060) := by decide +kernel

theorem selectedBound6630 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env6631 : List Nat := [2,4,8,0,32,0,128,256,397,1024,2048,1448,2436,1060,2444,2342,1029,2445,1025,2444,1449,32,429,35,2317,429,2185,1060,1416,2477,1161,292,257,396,1281,396]

theorem envBound6631 : H12AffineFastState.Bounded env6631 := by
  intro p hp
  have h : env6631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6630_6631 : H12AffineEnvironment.transform 13 1060 env6630 = env6631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1060 env6630 == env6631) = true)

theorem identity6631 : scanCanonicalize (H12AffineFastState.compose env6631 (packedSelected [0,2,6] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound6631 : packedSelected [0,2,6] rootPS < 2^1333 := by decide +kernel

def env6632 : List Nat := [2,4,8,0,32,0,128,256,397,1024,428,1448,40,1060,32,138,1029,33,1025,32,1449,32,429,35,161,429,293,1060,1416,1,1161,292,257,396,1281,396]

theorem envBound6632 : H12AffineFastState.Bounded env6632 := by
  intro p hp
  have h : env6632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6631_6632 : H12AffineEnvironment.transform 10 428 env6631 = env6632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env6631 == env6632) = true)

theorem identity6632 : scanCanonicalize (H12AffineFastState.compose env6632 (packedSelected [0,2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 39) := by decide +kernel

theorem selectedBound6632 : packedSelected [0,2,3,4] rootPS < 2^1333 := by decide +kernel

def env6633 : List Nat := [2,4,8,0,32,0,39,256,298,1024,267,1295,40,1060,32,45,1029,33,1025,32,1294,32,266,35,6,266,293,1060,1327,1,1070,292,257,299,1281,299]

theorem envBound6633 : H12AffineFastState.Bounded env6633 := by
  intro p hp
  have h : env6633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6632_6633 : H12AffineEnvironment.transform 6 39 env6632 = env6633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 39 env6632 == env6633) = true)

theorem identity6633 : scanCanonicalize (H12AffineFastState.compose env6633 (packedSelected [0,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 32) := by decide +kernel

theorem selectedBound6633 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env6634 : List Nat := [2,4,8,0,32,0,39,32,10,1024,43,1071,40,1060,32,45,1029,33,1025,32,1070,32,42,35,6,42,5,1060,1039,1,1070,4,33,11,1057,11]

theorem envBound6634 : H12AffineFastState.Bounded env6634 := by
  intro p hp
  have h : env6634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6633_6634 : H12AffineEnvironment.transform 7 32 env6633 = env6634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 32 env6633 == env6634) = true)

theorem identity6634 : scanCanonicalize (H12AffineFastState.compose env6634 (packedSelected [1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 43) := by decide +kernel

theorem selectedBound6634 : packedSelected [1,3,9] rootPS < 2^1333 := by decide +kernel

def env6635 : List Nat := [2,4,8,0,32,0,39,32,10,43,43,4,40,15,32,45,46,33,42,32,5,32,42,35,6,42,5,15,36,1,5,4,33,11,10,11]

theorem envBound6635 : H12AffineFastState.Bounded env6635 := by
  intro p hp
  have h : env6635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6634_6635 : H12AffineEnvironment.transform 9 43 env6634 = env6635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 43 env6634 == env6635) = true)

theorem identity6635 : scanCanonicalize (H12AffineFastState.compose env6635 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound6635 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6636 : List Nat := [2,4,7,0,32,0,39,32,5,36,36,4,39,0,32,34,33,33,37,32,5,32,37,35,6,37,5,0,36,1,5,4,33,4,5,4]

theorem envBound6636 : H12AffineFastState.Bounded env6636 := by
  intro p hp
  have h : env6636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6635_6636 : H12AffineEnvironment.transform 2 7 env6635 = env6636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env6635 == env6636) = true)

theorem identity6636 : scanCanonicalize (H12AffineFastState.compose env6636 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound6636 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env6637 : List Nat := [2,4,7,0,4,0,3,4,5,0,0,4,3,0,4,6,5,5,1,4,5,4,1,7,6,1,5,0,0,1,5,4,5,4,5,4]

theorem envBound6637 : H12AffineFastState.Bounded env6637 := by
  intro p hp
  have h : env6637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6636_6637 : H12AffineEnvironment.transform 4 4 env6636 = env6637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env6636 == env6637) = true)

def leafEnv6637 : List Nat := [2,4,7,0,4,0,3,4,5,0,0,4,3,0,4,6,5,5,1,4,5,4,1,7,5,6,1,1,5,0,0,1,5,4,5,4,4,2,5,4,1,1,0]

def active6637 : List Nat := [0,1]

def tree6637 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood6637 : H12WitnessSearch.Good tree6637 := H12GlobalWitnessIndex.good

theorem leafIdentity6637 : H12AffineFastState.composeSystem env6637 rootObs = leafEnv6637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env6637 rootObs == leafEnv6637) = true)

theorem terminalChecked6637 : H12PackedTerminal.terminalCheckFast leafEnv6637 active6637 tree6637 = true := by decide +kernel

def env6638 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50318,1029,262144,1025,32768,1449,4194304,4194701,41003,8329,4194701,320808,16384,16812,19849,57509,58633,257,17832,4236585,4194848]

theorem envBound6638 : H12AffineFastState.Bounded env6638 := by
  intro p hp
  have h : env6638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6624_6638 : H12AffineEnvironment.transform 3 1 env6624 = env6638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6624 == env6638) = true)

theorem identity6638 : scanCanonicalize (H12AffineFastState.compose env6638 (packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6638 : packedSelected [2,3,5,7,8,10,11,13,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env6639 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,32768,50318,1029,262144,1025,32768,1196,4194304,4194440,41003,8329,4194440,320557,16384,16553,19596,57509,58380,4,17581,4236332,4194848]

theorem envBound6639 : H12AffineFastState.Bounded env6639 := by
  intro p hp
  have h : env6639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6638_6639 : H12AffineEnvironment.transform 7 5 env6638 = env6639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6638 == env6639) = true)

theorem identity6639 : scanCanonicalize (H12AffineFastState.compose env6639 (packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound6639 : packedSelected [0,3,5,7,9,10,13,17,20,22] rootPS < 2^1333 := by decide +kernel

def env6640 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,32768,50318,1029,2081,1025,32768,1196,4194304,4194440,41003,8329,4194440,60428,16384,16553,19596,57509,58380,4,17581,4236332,4194848]

theorem envBound6640 : H12AffineFastState.Bounded env6640 := by
  intro p hp
  have h : env6640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6639_6640 : H12AffineEnvironment.transform 17 2081 env6639 = env6640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env6639 == env6640) = true)

theorem identity6640 : scanCanonicalize (H12AffineFastState.compose env6640 (packedSelected [1,4,6,8,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 59907) := by decide +kernel

theorem selectedBound6640 : packedSelected [1,4,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env6641 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,32768,50318,1029,2081,1025,32768,1196,59907,60043,41003,8329,60043,60428,16384,16553,19596,57509,58380,4,17581,20015,59427]

theorem envBound6641 : H12AffineFastState.Bounded env6641 := by
  intro p hp
  have h : env6641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6640_6641 : H12AffineEnvironment.transform 21 59907 env6640 = env6641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 59907 env6640 == env6641) = true)

theorem identity6641 : scanCanonicalize (H12AffineFastState.compose env6641 (packedSelected [13,18,21,23] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound6641 : packedSelected [13,18,21,23] rootPS < 2^1333 := by decide +kernel

def env6642 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1197,8192,16384,8201,25735,1029,2081,1025,8201,1196,18954,19074,34,8329,19074,19461,16384,16553,19596,16556,17413,4,17581,20015,18474]

theorem envBound6642 : H12AffineFastState.Bounded env6642 := by
  intro p hp
  have h : env6642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6641_6642 : H12AffineEnvironment.transform 14 8201 env6641 = env6642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env6641 == env6642) = true)

theorem identity6642 : scanCanonicalize (H12AffineFastState.compose env6642 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1671) := by decide +kernel

theorem selectedBound6642 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env6643 : List Nat := [2,4,8,1,32,1,128,5,512,1024,1671,1197,8192,16384,8201,25735,1029,1702,1025,8201,1196,17549,17413,34,8329,17413,17026,16384,16553,16907,16556,17413,4,17581,16552,18093]

theorem envBound6643 : H12AffineFastState.Bounded env6643 := by
  intro p hp
  have h : env6643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6642_6643 : H12AffineEnvironment.transform 10 1671 env6642 = env6643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1671 env6642 == env6643) = true)

theorem identity6643 : scanCanonicalize (H12AffineFastState.compose env6643 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 8842) := by decide +kernel

theorem selectedBound6643 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env6644 : List Nat := [2,4,8,1,32,1,128,5,512,1024,1671,1197,8192,8842,8201,1549,1029,1702,1025,8201,1196,9735,9871,34,8329,9871,8200,8842,8739,8321,8742,9871,4,9767,8738,9255]

theorem envBound6644 : H12AffineFastState.Bounded env6644 := by
  intro p hp
  have h : env6644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6643_6644 : H12AffineEnvironment.transform 13 8842 env6643 = env6644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 8842 env6643 == env6644) = true)

theorem identity6644 : scanCanonicalize (H12AffineFastState.compose env6644 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1701) := by decide +kernel

theorem selectedBound6644 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env6645 : List Nat := [2,4,8,1,32,1,128,5,512,1024,1671,1197,1701,1071,1708,1549,1029,1702,1025,1708,1196,162,42,34,1580,42,1709,1071,1158,1572,1155,42,4,130,1159,642]

theorem envBound6645 : H12AffineFastState.Bounded env6645 := by
  intro p hp
  have h : env6645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6644_6645 : H12AffineEnvironment.transform 12 1701 env6644 = env6645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1701 env6644 == env6645) = true)

theorem identity6645 : scanCanonicalize (H12AffineFastState.compose env6645 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 166) := by decide +kernel

theorem selectedBound6645 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env6646 : List Nat := [2,4,8,1,32,1,128,5,512,166,545,11,515,137,522,683,163,512,167,522,10,162,42,34,650,42,523,137,32,642,37,42,4,130,33,642]

theorem envBound6646 : H12AffineFastState.Bounded env6646 := by
  intro p hp
  have h : env6646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6645_6646 : H12AffineEnvironment.transform 9 166 env6645 = env6646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 166 env6645 == env6646) = true)

theorem identity6646 : scanCanonicalize (H12AffineFastState.compose env6646 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound6646 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env6647 : List Nat := [2,4,8,1,10,1,128,5,512,140,523,11,515,137,522,641,137,512,141,522,10,136,0,8,650,0,523,137,10,642,15,0,4,130,11,642]

theorem envBound6647 : H12AffineFastState.Bounded env6647 := by
  intro p hp
  have h : env6647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6646_6647 : H12AffineEnvironment.transform 4 10 env6646 = env6647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env6646 == env6647) = true)

theorem identity6647 : scanCanonicalize (H12AffineFastState.compose env6647 (packedSelected [0,1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound6647 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env6648 : List Nat := [2,4,8,1,10,1,8,5,512,4,523,11,515,1,522,521,1,512,5,522,10,0,0,8,514,0,523,1,10,522,15,0,4,10,11,522]

theorem envBound6648 : H12AffineFastState.Bounded env6648 := by
  intro p hp
  have h : env6648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6647_6648 : H12AffineEnvironment.transform 6 8 env6647 = env6648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env6647 == env6648) = true)

def env6649 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,65536,1028,262144,1025,32768,1448,4194304,4310275,41003,8329,4310275,320809,16384,16812,19848,74795,74135,257,17833,4236584,4310719]

theorem envBound6649 : H12AffineFastState.Bounded env6649 := by
  intro p hp
  have h : env6649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6622_6649 : H12AffineEnvironment.transform 11 1449 env6622 = env6649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env6622 == env6649) = true)

theorem identity6649 : scanCanonicalize (H12AffineFastState.compose env6649 (packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 50482) := by decide +kernel

theorem selectedBound6649 : packedSelected [0,2,3,5,7,8,9,10,20,22,23,28,31,32] rootPS < 2^1333 := by decide +kernel

def env6650 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,50482,1028,262144,1025,32768,1448,4194304,4194353,41003,8329,4194353,320809,16384,16812,19848,57625,58533,257,17833,4236584,4195213]

theorem envBound6650 : H12AffineFastState.Bounded env6650 := by
  intro p hp
  have h : env6650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6649_6650 : H12AffineEnvironment.transform 15 50482 env6649 = env6650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50482 env6649 == env6650) = true)

def env6651 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50466,1028,262144,1025,32768,1448,4194304,4194337,41003,8329,4194337,320809,16384,16812,19848,57609,58533,257,17833,4236584,4195213]

theorem envBound6651 : H12AffineFastState.Bounded env6651 := by
  intro p hp
  have h : env6651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6650_6651 : H12AffineEnvironment.transform 3 0 env6650 = env6651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env6650 == env6651) = true)

def env6652 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50466,1028,262144,1025,32768,1448,41088,41121,41003,8329,41121,320809,16384,16812,19848,57609,58533,257,17833,1448,41741]

theorem envBound6652 : H12AffineFastState.Bounded env6652 := by
  intro p hp
  have h : env6652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6651_6652 : H12AffineEnvironment.transform 21 41088 env6651 = env6652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env6651 == env6652) = true)

theorem identity6652 : scanCanonicalize (H12AffineFastState.compose env6652 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound6652 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6653 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,8200,25898,1028,262144,1025,8200,1448,136,169,35,8329,169,279841,16384,16812,19848,16641,17581,257,17833,1448,773]

theorem envBound6653 : H12AffineFastState.Bounded env6653 := by
  intro p hp
  have h : env6653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6652_6653 : H12AffineEnvironment.transform 14 8200 env6652 = env6653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env6652 == env6653) = true)

theorem identity6653 : scanCanonicalize (H12AffineFastState.compose env6653 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20141) := by decide +kernel

theorem selectedBound6653 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env6654 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,8200,25898,1028,20141,1025,8200,1448,136,169,35,8329,169,2956,16384,16812,19848,16641,17581,257,17833,1448,773]

theorem envBound6654 : H12AffineFastState.Bounded env6654 := by
  intro p hp
  have h : env6654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6653_6654 : H12AffineEnvironment.transform 17 20141 env6653 = env6654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20141 env6653 == env6654) = true)

theorem identity6654 : scanCanonicalize (H12AffineFastState.compose env6654 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound6654 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env6655 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,1572,8200,8974,1028,2185,1025,8200,1448,136,169,35,8329,169,2956,1572,1928,2988,1829,649,257,909,1448,773]

theorem envBound6655 : H12AffineFastState.Bounded env6655 := by
  intro p hp
  have h : env6655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6654_6655 : H12AffineEnvironment.transform 13 1572 env6654 = env6655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env6654 == env6655) = true)

theorem identity6655 : scanCanonicalize (H12AffineFastState.compose env6655 (packedSelected [1,2,4,8,9,10,11,12,13,17] rootPS)) = affineNative (2^(12+1) ^^^ 2348) := by decide +kernel

theorem selectedBound6655 : packedSelected [1,2,4,8,9,10,11,12,13,17] rootPS < 2^1333 := by decide +kernel

def env6656 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,2348,1572,2340,2594,1028,2185,1025,2340,1448,136,169,35,2469,169,2956,1572,1928,2988,1829,649,257,909,1448,773]

theorem envBound6656 : H12AffineFastState.Bounded env6656 := by
  intro p hp
  have h : env6656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6655_6656 : H12AffineEnvironment.transform 12 2348 env6655 = env6656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2348 env6655 == env6656) = true)

theorem identity6656 : scanCanonicalize (H12AffineFastState.compose env6656 (packedSelected [2,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound6656 : packedSelected [2,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6657 : List Nat := [2,4,8,0,32,0,128,5,512,1024,2048,1196,2089,1572,2081,2594,1028,2185,1025,2081,1197,136,169,35,2208,169,2697,1572,1677,2729,1568,649,4,648,1197,512]

theorem envBound6657 : H12AffineFastState.Bounded env6657 := by
  intro p hp
  have h : env6657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6656_6657 : H12AffineEnvironment.transform 7 5 env6656 = env6657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env6656 == env6657) = true)

theorem identity6657 : scanCanonicalize (H12AffineFastState.compose env6657 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound6657 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6658 : List Nat := [2,4,8,0,32,0,128,5,169,1024,2048,1196,2089,1165,2081,2187,1028,2185,1025,2081,1197,136,169,35,2208,169,2080,1165,1060,2048,1161,32,4,33,1197,169]

theorem envBound6658 : H12AffineFastState.Bounded env6658 := by
  intro p hp
  have h : env6658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6657_6658 : H12AffineEnvironment.transform 8 169 env6657 = env6658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env6657 == env6658) = true)

theorem identity6658 : scanCanonicalize (H12AffineFastState.compose env6658 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound6658 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env6659 : List Nat := [2,4,8,0,32,0,128,5,169,140,2048,32,2089,1,2081,2187,136,2185,141,2081,33,136,169,35,2208,169,2080,1,168,2048,5,32,4,33,33,169]

theorem envBound6659 : H12AffineFastState.Bounded env6659 := by
  intro p hp
  have h : env6659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6658_6659 : H12AffineEnvironment.transform 9 140 env6658 = env6659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env6658 == env6659) = true)

theorem identity6659 : scanCanonicalize (H12AffineFastState.compose env6659 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound6659 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env6660 : List Nat := [2,4,8,0,32,0,34,5,11,46,2048,32,2089,1,2081,2089,42,2091,47,2081,33,42,11,35,2050,11,2080,1,10,2048,5,32,4,33,33,11]

theorem envBound6660 : H12AffineFastState.Bounded env6660 := by
  intro p hp
  have h : env6660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6659_6660 : H12AffineEnvironment.transform 6 34 env6659 = env6660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env6659 == env6660) = true)

theorem identity6660 : scanCanonicalize (H12AffineFastState.compose env6660 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound6660 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env6661 : List Nat := [2,4,8,0,32,0,34,5,11,46,0,32,41,1,33,41,42,43,47,33,33,42,11,35,2,11,32,1,10,0,5,32,4,33,33,11]

theorem envBound6661 : H12AffineFastState.Bounded env6661 := by
  intro p hp
  have h : env6661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6660_6661 : H12AffineEnvironment.transform 10 0 env6660 = env6661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env6660 == env6661) = true)

def env6662 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50466,1028,262144,1025,32768,1448,41089,41120,41003,8329,41120,320809,16384,16812,19848,57609,58533,257,17833,1449,41740]

theorem envBound6662 : H12AffineFastState.Bounded env6662 := by
  intro p hp
  have h : env6662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6651_6662 : H12AffineEnvironment.transform 21 41089 env6651 = env6662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env6651 == env6662) = true)

theorem identity6662 : scanCanonicalize (H12AffineFastState.compose env6662 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6662 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6663 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,16384,32768,50214,1028,262144,1025,32768,1196,41089,41120,41003,8329,41120,320557,16384,16552,19596,57357,58533,5,17581,1197,41480]

theorem envBound6663 : H12AffineFastState.Bounded env6663 := by
  intro p hp
  have h : env6663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6662_6663 : H12AffineEnvironment.transform 7 4 env6662 = env6663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6662 == env6663) = true)

theorem identity6663 : scanCanonicalize (H12AffineFastState.compose env6663 (packedSelected [0,3,5,7,10,13,20,21] rootPS)) = affineNative (2^(13+1) ^^^ 1676) := by decide +kernel

theorem selectedBound6663 : packedSelected [0,3,5,7,10,13,20,21] rootPS < 2^1333 := by decide +kernel

def env6664 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,1676,32768,33450,1028,262144,1025,32768,1196,41089,41120,41003,8329,41120,303777,1676,1572,2560,42625,41513,5,545,1197,41480]

theorem envBound6664 : H12AffineFastState.Bounded env6664 := by
  intro p hp
  have h : env6664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6663_6664 : H12AffineEnvironment.transform 13 1676 env6663 = env6664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1676 env6663 == env6664) = true)

theorem identity6664 : scanCanonicalize (H12AffineFastState.compose env6664 (packedSelected [0,1,3,4,7,9,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8832) := by decide +kernel

theorem selectedBound6664 : packedSelected [0,1,3,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env6665 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,1676,8832,8234,1028,262144,1025,8832,1196,513,544,683,8329,544,262177,1676,1572,2560,1025,169,5,545,1197,136]

theorem envBound6665 : H12AffineFastState.Bounded env6665 := by
  intro p hp
  have h : env6665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6664_6665 : H12AffineEnvironment.transform 14 8832 env6664 = env6665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8832 env6664 == env6665) = true)

theorem identity6665 : scanCanonicalize (H12AffineFastState.compose env6665 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2729) := by decide +kernel

theorem selectedBound6665 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env6666 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,1676,8832,8234,1028,2729,1025,8832,1196,513,544,683,8329,544,2696,1676,1572,2560,1025,169,5,545,1197,136]

theorem envBound6666 : H12AffineFastState.Bounded env6666 := by
  intro p hp
  have h : env6666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6665_6666 : H12AffineEnvironment.transform 17 2729 env6665 = env6666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2729 env6665 == env6666) = true)

theorem identity6666 : scanCanonicalize (H12AffineFastState.compose env6666 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound6666 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env6667 : List Nat := [2,4,8,0,32,0,128,4,136,1024,2048,1197,8192,1028,8200,8234,1028,2081,1025,8200,1196,137,168,35,8329,168,2048,1028,1196,2184,1025,169,5,169,1197,136]

theorem envBound6667 : H12AffineFastState.Bounded env6667 := by
  intro p hp
  have h : env6667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6666_6667 : H12AffineEnvironment.transform 8 136 env6666 = env6667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env6666 == env6667) = true)

theorem identity6667 : scanCanonicalize (H12AffineFastState.compose env6667 (packedSelected [1,2] rootPS)) = affineNative (2^(9+1) ^^^ 134) := by decide +kernel

theorem selectedBound6667 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env6668 : List Nat := [2,4,8,0,32,0,128,4,136,134,2048,43,8192,130,8200,8234,130,2081,135,8200,42,137,168,35,8329,168,2048,130,42,2184,135,169,5,169,43,136]

theorem envBound6668 : H12AffineFastState.Bounded env6668 := by
  intro p hp
  have h : env6668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6667_6668 : H12AffineEnvironment.transform 9 134 env6667 = env6668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 134 env6667 == env6668) = true)

theorem identity6668 : scanCanonicalize (H12AffineFastState.compose env6668 (packedSelected [3] rootPS)) = affineNative (2^(12+1) ^^^ 171) := by decide +kernel

theorem selectedBound6668 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env6669 : List Nat := [2,4,8,0,32,0,128,4,136,134,2048,43,171,130,163,129,130,2081,135,163,42,137,168,35,34,168,2048,130,42,2184,135,169,5,169,43,136]

theorem envBound6669 : H12AffineFastState.Bounded env6669 := by
  intro p hp
  have h : env6669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6668_6669 : H12AffineEnvironment.transform 12 171 env6668 = env6669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 171 env6668 == env6669) = true)

theorem identity6669 : scanCanonicalize (H12AffineFastState.compose env6669 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound6669 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env6670 : List Nat := [2,4,8,0,32,0,35,4,43,37,2048,43,8,33,0,34,33,2081,36,0,42,42,11,35,34,11,2048,33,42,2091,36,10,5,10,43,43]

theorem envBound6670 : H12AffineFastState.Bounded env6670 := by
  intro p hp
  have h : env6670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6669_6670 : H12AffineEnvironment.transform 6 35 env6669 = env6670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env6669 == env6670) = true)

theorem identity6670 : scanCanonicalize (H12AffineFastState.compose env6670 (packedSelected [1,6] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound6670 : packedSelected [1,6] rootPS < 2^1333 := by decide +kernel

def env6671 : List Nat := [2,4,8,0,11,0,8,4,0,14,2048,0,8,10,0,9,10,2058,15,0,1,1,11,8,9,11,2048,10,1,2048,15,10,5,10,0,0]

theorem envBound6671 : H12AffineFastState.Bounded env6671 := by
  intro p hp
  have h : env6671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6670_6671 : H12AffineEnvironment.transform 4 11 env6670 = env6671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env6670 == env6671) = true)

theorem identity6671 : scanCanonicalize (H12AffineFastState.compose env6671 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound6671 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6672 : List Nat := [2,4,8,0,11,0,8,4,0,14,0,0,8,10,0,9,10,10,15,0,1,1,11,8,9,11,0,10,1,0,15,10,5,10,0,0]

theorem envBound6672 : H12AffineFastState.Bounded env6672 := by
  intro p hp
  have h : env6672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6671_6672 : H12AffineEnvironment.transform 10 0 env6671 = env6672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env6671 == env6672) = true)

theorem identity6672 : scanCanonicalize (H12AffineFastState.compose env6672 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound6672 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env6673 : List Nat := [2,4,2,0,1,0,2,4,0,4,0,0,2,0,0,3,0,0,5,0,1,1,1,2,3,1,0,0,1,0,5,0,5,0,0,0]

theorem envBound6673 : H12AffineFastState.Bounded env6673 := by
  intro p hp
  have h : env6673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6672_6673 : H12AffineEnvironment.transform 2 2 env6672 = env6673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env6672 == env6673) = true)

def env6674 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,32768,50467,1028,262144,1025,32768,1448,4194304,4194336,41003,8329,4194336,320809,16384,16812,19848,57608,58533,257,17833,4236584,4195213]

theorem envBound6674 : H12AffineFastState.Bounded env6674 := by
  intro p hp
  have h : env6674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6650_6674 : H12AffineEnvironment.transform 3 1 env6650 = env6674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env6650 == env6674) = true)

theorem identity6674 : scanCanonicalize (H12AffineFastState.compose env6674 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound6674 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env6675 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8460,25647,1028,262144,1025,8460,1448,4194304,4194336,295,8329,4194336,279589,16384,16812,19848,16388,17833,257,17833,4195364,4195213]

theorem envBound6675 : H12AffineFastState.Bounded env6675 := by
  intro p hp
  have h : env6675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6674_6675 : H12AffineEnvironment.transform 14 8460 env6674 = env6675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env6674 == env6675) = true)

theorem identity6675 : scanCanonicalize (H12AffineFastState.compose env6675 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound6675 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6676 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1197,8192,16384,8200,25647,1028,262144,1025,8200,1196,4194304,4194336,35,8329,4194336,279589,16384,16552,19596,16388,17581,5,17581,4195364,4194953]

theorem envBound6676 : H12AffineFastState.Bounded env6676 := by
  intro p hp
  have h : env6676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6675_6676 : H12AffineEnvironment.transform 7 4 env6675 = env6676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env6675 == env6676) = true)

theorem identity6676 : scanCanonicalize (H12AffineFastState.compose env6676 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound6676 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env6677 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1197,8192,16384,8200,25647,1028,2184,1025,8200,1196,4194304,4194336,35,8329,4194336,19629,16384,16552,19596,16388,17581,5,17581,4195364,4194953]

theorem envBound6677 : H12AffineFastState.Bounded env6677 := by
  intro p hp
  have h : env6677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6676_6677 : H12AffineEnvironment.transform 17 2184 env6676 = env6677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env6676 == env6677) = true)

theorem identity6677 : scanCanonicalize (H12AffineFastState.compose env6677 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound6677 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env6678 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1164,8192,16384,8200,25614,1028,2184,1025,8200,1165,4194304,4194305,2,8329,4194305,19596,16384,16521,19596,16388,17548,5,17548,4195333,4194953]

theorem envBound6678 : H12AffineFastState.Bounded env6678 := by
  intro p hp
  have h : env6678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6677_6678 : H12AffineEnvironment.transform 4 1 env6677 = env6678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env6677 == env6678) = true)

theorem identity6678 : scanCanonicalize (H12AffineFastState.compose env6678 (packedSelected [0,4,10] rootPS)) = affineNative (2^(21+1) ^^^ 10243) := by decide +kernel

theorem selectedBound6678 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env6679 : List Nat := [2,4,8,1,1,1,128,4,512,1024,2048,1164,8192,16384,8200,25614,1028,2184,1025,8200,1165,10243,10242,2,8329,10242,19596,16384,16521,19596,16388,17548,5,17548,11270,10890]

theorem envBound6679 : H12AffineFastState.Bounded env6679 := by
  intro p hp
  have h : env6679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6678_6679 : H12AffineEnvironment.transform 21 10243 env6678 = env6679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10243 env6678 == env6679) = true)

theorem identity6679 : scanCanonicalize (H12AffineFastState.compose env6679 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound6679 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env6680 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1028,8192,16384,8200,25614,1028,2048,1025,8200,1029,10243,10242,2,8193,10242,19460,16384,16385,19460,16388,17412,5,17412,11270,10754]

theorem envBound6680 : H12AffineFastState.Bounded env6680 := by
  intro p hp
  have h : env6680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6679_6680 : H12AffineEnvironment.transform 6 8 env6679 = env6680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env6679 == env6680) = true)

theorem identity6680 : scanCanonicalize (H12AffineFastState.compose env6680 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 2562) := by decide +kernel

theorem selectedBound6680 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env6681 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1028,2562,16384,2570,19980,1028,2048,1025,2570,1029,513,512,2,2563,512,19460,16384,16385,19460,16388,17412,5,17412,1540,0]

theorem envBound6681 : H12AffineFastState.Bounded env6681 := by
  intro p hp
  have h : env6681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6680_6681 : H12AffineEnvironment.transform 12 2562 env6680 = env6681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2562 env6680 == env6681) = true)

theorem identity6681 : scanCanonicalize (H12AffineFastState.compose env6681 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound6681 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env6682 : List Nat := [2,4,8,1,1,1,8,4,512,1024,2048,1028,2562,1028,2570,2568,1028,2048,1025,2570,1029,513,512,2,2563,512,2048,1028,1029,2048,1024,0,5,0,1540,0]

theorem envBound6682 : H12AffineFastState.Bounded env6682 := by
  intro p hp
  have h : env6682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6681_6682 : H12AffineEnvironment.transform 13 1028 env6681 = env6682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env6681 == env6682) = true)

theorem identity6682 : scanCanonicalize (H12AffineFastState.compose env6682 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound6682 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env6683 : List Nat := [2,4,8,1,1,1,8,4,512,1024,1038,1028,1548,1028,1540,1542,1028,1038,1025,1540,1029,513,512,2,1549,512,1038,1028,1029,1038,1024,0,5,0,1540,0]

theorem envBound6683 : H12AffineFastState.Bounded env6683 := by
  intro p hp
  have h : env6683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6682_6683 : H12AffineEnvironment.transform 10 1038 env6682 = env6683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env6682 == env6683) = true)

theorem identity6683 : scanCanonicalize (H12AffineFastState.compose env6683 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound6683 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env6684 : List Nat := [2,4,8,1,1,1,8,4,11,1024,1038,1028,1031,1028,1039,1037,1028,1038,1025,1039,1029,10,11,2,1030,11,1038,1028,1029,1038,1024,0,5,0,1039,0]

theorem envBound6684 : H12AffineFastState.Bounded env6684 := by
  intro p hp
  have h : env6684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6683_6684 : H12AffineEnvironment.transform 8 11 env6683 = env6684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env6683 == env6684) = true)

theorem identity6684 : scanCanonicalize (H12AffineFastState.compose env6684 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound6684 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env6685 : List Nat := [2,4,8,1,1,1,8,4,11,4,10,0,3,0,11,9,0,10,5,11,1,10,11,2,2,11,10,0,1,10,4,0,5,0,11,0]

theorem envBound6685 : H12AffineFastState.Bounded env6685 := by
  intro p hp
  have h : env6685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6684_6685 : H12AffineEnvironment.transform 9 4 env6684 = env6685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env6684 == env6685) = true)

theorem identity6685 : scanCanonicalize (H12AffineFastState.compose env6685 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound6685 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env6686 : List Nat := [2,4,3,1,1,1,3,4,0,4,1,0,3,0,0,2,0,1,5,0,1,1,0,2,2,0,1,0,1,1,4,0,5,0,0,0]

theorem envBound6686 : H12AffineFastState.Bounded env6686 := by
  intro p hp
  have h : env6686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6685_6686 : H12AffineEnvironment.transform 2 3 env6685 = env6686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env6685 == env6686) = true)

def env6687 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,4310274,41003,8329,4310275,323713,16384,16813,22560,74795,78911,257,20481,4239489,4310719]

theorem envBound6687 : H12AffineFastState.Bounded env6687 := by
  intro p hp
  have h : env6687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6621_6687 : H12AffineEnvironment.transform 5 17 env6621 = env6687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env6621 == env6687) = true)

theorem identity6687 : scanCanonicalize (H12AffineFastState.compose env6687 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115903) := by decide +kernel

theorem selectedBound6687 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env6688 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,115903,445,41003,8329,444,323713,16384,16813,22560,74795,78911,257,20481,95294,512]

theorem envBound6688 : H12AffineFastState.Bounded env6688 := by
  intro p hp
  have h : env6688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6687_6688 : H12AffineEnvironment.transform 21 115903 env6687 = env6688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115903 env6687 == env6688) = true)

theorem identity6688 : scanCanonicalize (H12AffineFastState.compose env6688 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound6688 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env6689 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1025,32768,4097,41349,445,41003,8329,444,323713,16384,16813,22560,16657,20741,257,20481,4356,512]

theorem envBound6689 : H12AffineFastState.Bounded env6689 := by
  intro p hp
  have h : env6689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6688_6689 : H12AffineEnvironment.transform 15 25914 env6688 = env6689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env6688 == env6689) = true)

theorem identity6689 : scanCanonicalize (H12AffineFastState.compose env6689 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 26261) := by decide +kernel

theorem selectedBound6689 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env6690 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,26261,25914,4524,262144,1025,26261,4097,18192,445,18110,8329,444,267796,16384,16813,22560,16657,20741,257,20481,4356,512]

theorem envBound6690 : H12AffineFastState.Bounded env6690 := by
  intro p hp
  have h : env6690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6689_6690 : H12AffineEnvironment.transform 14 26261 env6689 = env6690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26261 env6689 == env6690) = true)

theorem identity6690 : scanCanonicalize (H12AffineFastState.compose env6690 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound6690 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env6691 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25914,1045,262144,1025,26261,1464,18192,445,18110,8329,444,263085,16384,16813,19865,16657,17596,257,17848,1213,512]

theorem envBound6691 : H12AffineFastState.Bounded env6691 := by
  intro p hp
  have h : env6691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans6690_6691 : H12AffineEnvironment.transform 11 1465 env6690 = env6691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env6690 == env6691) = true)

theorem identity6691 : scanCanonicalize (H12AffineFastState.compose env6691 (packedSelected [12,13,15,17,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound6691 : packedSelected [12,13,15,17,24,28] rootPS < 2^1333 := by decide +kernel

def env6692 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26261,25914,1045,2341,1025,26261,1464,18192,445,18110,8329,444,2696,16384,16813,19865,16657,17596,257,17848,1213,512]

theorem envBound6692 : H12AffineFastState.Bounded env6692 := by
  intro p hp
  have h : env6692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1