import H12CloudChart1Data135

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans34507_34508 : H12AffineEnvironment.transform 12 1384 env34507 = env34508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env34507 == env34508) = true)

theorem identity34508 : scanCanonicalize (H12AffineFastState.compose env34508 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34508 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env34509 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,4096,269,2049,80,6422,4096,2341,100,81,2340,6193,6145,6163,268,65,4160,2064,2064,2421,6432,6192,257,6193,4161,513]

theorem envBound34509 : H12AffineFastState.Bounded env34509 := by
  intro p hp
  have h : env34509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34508_34509 : H12AffineEnvironment.transform 9 101 env34508 = env34509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34508 == env34509) = true)

theorem identity34509 : scanCanonicalize (H12AffineFastState.compose env34509 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound34509 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34510 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2064,269,2049,80,262,2064,2341,100,81,2340,33,17,3,268,65,2128,2064,2064,2421,304,32,257,33,2129,513]

theorem envBound34510 : H12AffineFastState.Bounded env34510 := by
  intro p hp
  have h : env34510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34509_34510 : H12AffineEnvironment.transform 11 2064 env34509 = env34510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env34509 == env34510) = true)

theorem identity34510 : scanCanonicalize (H12AffineFastState.compose env34510 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34510 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34511 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2064,121,2049,80,114,2064,2129,100,81,2128,33,17,3,120,65,2128,2064,2064,2049,68,32,117,33,2129,513]

theorem envBound34511 : H12AffineFastState.Bounded env34511 := by
  intro p hp
  have h : env34511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34510_34511 : H12AffineEnvironment.transform 7 116 env34510 = env34511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34510 == env34511) = true)

theorem identity34511 : scanCanonicalize (H12AffineFastState.compose env34511 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound34511 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34512 : List Nat := [2,4,8,16,32,64,9,116,512,101,97,113,121,96,80,114,113,48,100,81,49,33,17,3,120,65,49,113,113,96,68,32,117,33,48,513]

theorem envBound34512 : H12AffineFastState.Bounded env34512 := by
  intro p hp
  have h : env34512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34511_34512 : H12AffineEnvironment.transform 10 97 env34511 = env34512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env34511 == env34512) = true)

theorem identity34512 : scanCanonicalize (H12AffineFastState.compose env34512 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34512 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34513 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,40,49,1,35,32,48,53,0,49,33,17,3,41,16,49,32,32,49,21,32,36,33,48,513]

theorem envBound34513 : H12AffineFastState.Bounded env34513 := by
  intro p hp
  have h : env34513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34512_34513 : H12AffineEnvironment.transform 5 17 env34512 = env34513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34512 == env34513) = true)

def leafEnv34513 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,40,49,1,35,32,48,53,0,49,33,17,3,20,41,1,16,49,32,32,49,21,32,36,33,5,34,48,513,1,48,0]

def active34513 : List Nat := [0,1,2,3,4,8]

def tree34513 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34513 : H12WitnessSearch.Good tree34513 := H12GlobalWitnessIndex.good

theorem leafIdentity34513 : H12AffineFastState.composeSystem env34513 rootObs = leafEnv34513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34513 rootObs == leafEnv34513) = true)

theorem terminalChecked34513 : H12PackedTerminal.terminalCheckFast leafEnv34513 active34513 tree34513 = true := by decide +kernel

def env34514 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1025,32769,2097152,4194304,147457,98644,8193,65,4229153,2098512,2233680,2420,148804,6349853,257,2229616,2286684,221723]

theorem envBound34514 : H12AffineFastState.Bounded env34514 := by
  intro p hp
  have h : env34514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34500_34514 : H12AffineEnvironment.transform 22 147457 env34500 = env34514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env34500 == env34514) = true)

def env34515 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,98644,8193,65,4229153,2098512,2118976,2420,1364,6349853,257,2114912,2139212,74251]

theorem envBound34515 : H12AffineFastState.Bounded env34515 := by
  intro p hp
  have h : env34515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34514_34515 : H12AffineEnvironment.transform 16 16400 env34514 = env34515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34514 == env34515) = true)

theorem identity34515 : scanCanonicalize (H12AffineFastState.compose env34515 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound34515 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env34516 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1025,8540,2097152,4194304,17,73737,8193,65,4204924,2098512,2118976,2420,1364,6309184,257,2114912,2098449,74251]

theorem envBound34516 : H12AffineFastState.Bounded env34516 := by
  intro p hp
  have h : env34516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34515_34516 : H12AffineEnvironment.transform 14 8541 env34515 = env34516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env34515 == env34516) = true)

theorem identity34516 : scanCanonicalize (H12AffineFastState.compose env34516 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound34516 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env34517 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28698,16400,10280,1025,8540,2097152,4194304,17,20499,8193,65,4204924,2098512,2118976,2420,1364,6309184,257,2114912,2098449,21009]

theorem envBound34517 : H12AffineFastState.Bounded env34517 := by
  intro p hp
  have h : env34517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34516_34517 : H12AffineEnvironment.transform 15 28698 env34516 = env34517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env34516 == env34517) = true)

theorem identity34517 : scanCanonicalize (H12AffineFastState.compose env34517 (packedSelected [0,4,7,11,17,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound34517 : packedSelected [0,4,7,11,17,18,22] rootPS < 2^1333 := by decide +kernel

def env34518 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1124,21795,16400,3345,1025,1125,2097152,4194304,17,20499,1336,65,4197445,2098512,2118976,2420,1364,6309184,257,2114912,2098449,21009]

theorem envBound34518 : H12AffineFastState.Bounded env34518 := by
  intro p hp
  have h : env34518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34517_34518 : H12AffineEnvironment.transform 12 1337 env34517 = env34518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env34517 == env34518) = true)

theorem identity34518 : scanCanonicalize (H12AffineFastState.compose env34518 (packedSelected [3,5,10,11,23] rootPS)) = affineNative (2^(21+1) ^^^ 2101572) := by decide +kernel

theorem selectedBound34518 : packedSelected [3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env34519 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1124,21795,16400,3345,1025,1125,2097152,2101572,17,20499,1336,65,2104577,2098512,2118976,2420,1364,21508,257,2114912,2098449,21009]

theorem envBound34519 : H12AffineFastState.Bounded env34519 := by
  intro p hp
  have h : env34519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34518_34519 : H12AffineEnvironment.transform 21 2101572 env34518 = env34519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2101572 env34518 == env34519) = true)

theorem identity34519 : scanCanonicalize (H12AffineFastState.compose env34519 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(20+1) ^^^ 16756) := by decide +kernel

theorem selectedBound34519 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env34520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,16384,1124,21795,16400,3345,1025,1125,16756,20528,17,20499,1336,65,23669,17444,5172,2420,1364,21508,257,1044,17509,21009]

theorem envBound34520 : H12AffineFastState.Bounded env34520 := by
  intro p hp
  have h : env34520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34519_34520 : H12AffineEnvironment.transform 20 16756 env34519 = env34520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16756 env34519 == env34520) = true)

theorem identity34520 : scanCanonicalize (H12AffineFastState.compose env34520 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound34520 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1337,2048,1124,7459,2064,3345,1025,1125,2420,6192,17,6163,1336,65,5237,3108,5172,2420,1364,7172,257,1044,3173,6673]

theorem envBound34521 : H12AffineFastState.Bounded env34521 := by
  intro p hp
  have h : env34521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34520_34521 : H12AffineEnvironment.transform 13 2048 env34520 = env34521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env34520 == env34521) = true)

theorem identity34521 : scanCanonicalize (H12AffineFastState.compose env34521 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound34521 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env34522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,16,1337,2048,1124,3379,2064,3345,1025,1125,2420,2080,17,2051,1336,65,1125,3108,1060,2420,1364,3092,257,1044,3173,2561]

theorem envBound34522 : H12AffineFastState.Bounded env34522 := by
  intro p hp
  have h : env34522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34521_34522 : H12AffineEnvironment.transform 11 16 env34521 = env34522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env34521 == env34522) = true)

theorem identity34522 : scanCanonicalize (H12AffineFastState.compose env34522 (packedSelected [0,3,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound34522 : packedSelected [0,3,4,5,11] rootPS < 2^1333 := by decide +kernel

def env34523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1076,16,1337,1076,1124,263,1060,293,1025,1125,1344,1044,17,1079,1336,65,1125,16,1060,1344,1364,32,257,1044,81,1589]

theorem envBound34523 : H12AffineFastState.Bounded env34523 := by
  intro p hp
  have h : env34523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34522_34523 : H12AffineEnvironment.transform 10 1076 env34522 = env34523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env34522 == env34523) = true)

theorem identity34523 : scanCanonicalize (H12AffineFastState.compose env34523 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34523 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env34524 : List Nat := [2,4,8,16,32,64,9,37,512,1024,1076,16,1052,1076,1124,34,1060,0,1025,1125,1125,1044,17,1079,1053,65,1125,16,1060,1125,1137,32,36,1044,81,1589]

theorem envBound34524 : H12AffineFastState.Bounded env34524 := by
  intro p hp
  have h : env34524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34523_34524 : H12AffineEnvironment.transform 7 37 env34523 = env34524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34523 == env34524) = true)

def env34525 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,16,98644,8193,65,4229153,2098512,2118977,2420,1365,6349853,257,2114913,2139213,74250]

theorem envBound34525 : H12AffineFastState.Bounded env34525 := by
  intro p hp
  have h : env34525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34514_34525 : H12AffineEnvironment.transform 16 16401 env34514 = env34525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34514 == env34525) = true)

theorem identity34525 : scanCanonicalize (H12AffineFastState.compose env34525 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound34525 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env34526 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,73771,16,98644,8193,65,108554,2098512,2118977,2420,1365,2212918,257,2114913,2139213,74250]

theorem envBound34526 : H12AffineFastState.Bounded env34526 := by
  intro p hp
  have h : env34526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34525_34526 : H12AffineEnvironment.transform 21 73771 env34525 = env34526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env34525 == env34526) = true)

theorem identity34526 : scanCanonicalize (H12AffineFastState.compose env34526 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 124186) := by decide +kernel

theorem selectedBound34526 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env34527 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,124186,73771,16,98644,8193,65,108554,122954,110683,2420,1365,8492,257,106619,82263,74250]

theorem envBound34527 : H12AffineFastState.Bounded env34527 := by
  intro p hp
  have h : env34527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34526_34527 : H12AffineEnvironment.transform 20 124186 env34526 = env34527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124186 env34526 == env34527) = true)

theorem identity34527 : scanCanonicalize (H12AffineFastState.compose env34527 (packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound34527 : packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env34528 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,262,16401,35189,1025,32769,58396,8493,16,32850,8193,65,43276,57676,45405,2420,1365,8492,257,41341,16465,8972]

theorem envBound34528 : H12AffineFastState.Bounded env34528 := by
  intro p hp
  have h : env34528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34527_34528 : H12AffineEnvironment.transform 15 262 env34527 = env34528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env34527 == env34528) = true)

theorem identity34528 : scanCanonicalize (H12AffineFastState.compose env34528 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34528 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env34529 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,262,16401,10281,1025,8541,17728,8493,16,8462,8193,65,2128,16400,4097,2420,1365,8492,257,33,16465,8972]

theorem envBound34529 : H12AffineFastState.Bounded env34529 := by
  intro p hp
  have h : env34529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34528_34529 : H12AffineEnvironment.transform 14 8540 env34528 = env34529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34528 == env34529) = true)

theorem identity34529 : scanCanonicalize (H12AffineFastState.compose env34529 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound34529 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34530 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8540,262,13673,10281,1025,8541,12344,8493,16,8462,8193,65,2128,13672,4097,2420,1365,8492,257,33,13609,8972]

theorem envBound34530 : H12AffineFastState.Bounded env34530 := by
  intro p hp
  have h : env34530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34529_34530 : H12AffineEnvironment.transform 13 13688 env34529 = env34530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env34529 == env34530) = true)

theorem identity34530 : scanCanonicalize (H12AffineFastState.compose env34530 (packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34530 : packedSelected [1,3,4,5,6,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env34531 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13324,8232,114,13341,10281,1025,8233,12344,8281,16,8314,8193,65,2128,13340,4097,2048,1057,8280,117,33,13405,8824]

theorem envBound34531 : H12AffineFastState.Bounded env34531 := by
  intro p hp
  have h : env34531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34530_34531 : H12AffineEnvironment.transform 7 116 env34530 = env34531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34530 == env34531) = true)

theorem identity34531 : scanCanonicalize (H12AffineFastState.compose env34531 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound34531 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34532 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,120,5236,80,114,5221,2129,1025,81,4160,33,16,2,121,65,2128,5220,4097,2048,1057,32,117,33,5157,512]

theorem envBound34532 : H12AffineFastState.Bounded env34532 := by
  intro p hp
  have h : env34532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34531_34532 : H12AffineEnvironment.transform 12 120 env34531 = env34532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env34531 == env34532) = true)

def env34533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265169,23160257,525568,27902124,27337993,25733062]

theorem envBound34533 : H12AffineFastState.Bounded env34533 := by
  intro p hp
  have h : env34533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34180_34533 : H12AffineEnvironment.transform 26 30393345 env34180 = env34533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env34180 == env34533) = true)

def env34534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160257,256,27378860,27337993,25207750]

theorem envBound34534 : H12AffineFastState.Bounded env34534 := by
  intro p hp
  have h : env34534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34533_34534 : H12AffineEnvironment.transform 18 1024 env34533 = env34534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env34533 == env34534) = true)

theorem identity34534 : scanCanonicalize (H12AffineFastState.compose env34534 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2493628) := by decide +kernel

theorem selectedBound34534 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env34535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493628,16777216,8328,65,23186621,18973836,416237,2149564,19368109,23160257,256,17287184,17246645,19312506]

theorem envBound34535 : H12AffineFastState.Bounded env34535 := by
  intro p hp
  have h : env34535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34534_34535 : H12AffineEnvironment.transform 22 2493628 env34534 = env34535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2493628 env34534 == env34535) = true)

def env34536 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493628,498992,8328,65,6705549,2496956,416237,2149564,2102685,6748401,256,21792,46213,2175562]

theorem envBound34536 : H12AffineFastState.Bounded env34536 := by
  intro p hp
  have h : env34536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34535_34536 : H12AffineEnvironment.transform 23 498992 env34535 = env34536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498992 env34535 == env34536) = true)

def env34537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493628,498992,8328,65,2396469,2496956,416237,2149564,2102685,2373705,256,21792,46213,2175562]

theorem envBound34537 : H12AffineFastState.Bounded env34537 := by
  intro p hp
  have h : env34537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34536_34537 : H12AffineEnvironment.transform 21 180408 env34536 = env34537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env34536 == env34537) = true)

def env34538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400636,498992,8328,65,295285,395772,416237,56572,1501,272393,256,21792,46213,74250]

theorem envBound34538 : H12AffineFastState.Bounded env34538 := by
  intro p hp
  have h : env34538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34537_34538 : H12AffineEnvironment.transform 20 4160 env34537 = env34538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34537 == env34538) = true)

theorem identity34538 : scanCanonicalize (H12AffineFastState.compose env34538 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound34538 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,4160,144493,400636,485861,8328,65,292256,395772,416237,10281,1501,272393,256,21792,16464,74250]

theorem envBound34539 : H12AffineFastState.Bounded env34539 := by
  intro p hp
  have h : env34539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34538_34539 : H12AffineEnvironment.transform 14 29909 env34538 = env34539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env34538 == env34539) = true)

def env34540 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,144493,400500,485741,8192,65,292136,395636,416101,10281,1365,272393,256,21792,16464,74250]

theorem envBound34540 : H12AffineFastState.Bounded env34540 := by
  intro p hp
  have h : env34540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34539_34540 : H12AffineEnvironment.transform 6 8 env34539 = env34540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34539 == env34540) = true)

theorem identity34540 : scanCanonicalize (H12AffineFastState.compose env34540 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5440) := by decide +kernel

theorem selectedBound34540 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env34541 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,5440,262144,1024,29788,4160,8493,264500,359469,8192,65,292136,269364,281637,10281,1365,272393,256,21792,16464,74250]

theorem envBound34541 : H12AffineFastState.Bounded env34541 := by
  intro p hp
  have h : env34541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34540_34541 : H12AffineEnvironment.transform 16 5440 env34540 = env34541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5440 env34540 == env34541) = true)

theorem identity34541 : scanCanonicalize (H12AffineFastState.compose env34541 (packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound34541 : packedSelected [1,3,4,8,9,10,12,14,15,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env34542 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,5440,89459,1024,29788,4160,8493,87111,8542,8192,65,75867,82247,69974,10281,1365,95610,256,21792,16464,74250]

theorem envBound34542 : H12AffineFastState.Bounded env34542 := by
  intro p hp
  have h : env34542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34541_34542 : H12AffineEnvironment.transform 17 89459 env34541 = env34542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env34541 == env34542) = true)

theorem identity34542 : scanCanonicalize (H12AffineFastState.compose env34542 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34542 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env34543 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,65536,5392,89379,1024,29708,4112,8493,87063,8462,8192,17,75787,82199,69894,10281,1285,95530,256,21792,16384,74250]

theorem envBound34543 : H12AffineFastState.Bounded env34543 := by
  intro p hp
  have h : env34543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34542_34543 : H12AffineEnvironment.transform 5 16 env34542 = env34543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34542 == env34543) = true)

theorem identity34543 : scanCanonicalize (H12AffineFastState.compose env34543 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound34543 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env34544 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,29962,5392,10281,1024,29708,4112,8493,8477,8462,8192,17,23809,13341,25612,10281,1285,32,256,21792,16384,22272]

theorem envBound34544 : H12AffineFastState.Bounded env34544 := by
  intro p hp
  have h : env34544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34543_34544 : H12AffineEnvironment.transform 15 29962 env34543 = env34544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env34543 == env34544) = true)

theorem identity34544 : scanCanonicalize (H12AffineFastState.compose env34544 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound34544 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34545 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,5392,10281,1024,8461,4112,8493,8477,8462,8192,17,2048,13341,12557,10281,1285,32,256,33,5377,513]

theorem envBound34545 : H12AffineFastState.Bounded env34545 := by
  intro p hp
  have h : env34545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34544_34545 : H12AffineEnvironment.transform 13 5377 env34544 = env34545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env34544 == env34545) = true)

theorem identity34545 : scanCanonicalize (H12AffineFastState.compose env34545 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34545 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34546 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,263,5392,2341,1024,1,4112,33,17,2,268,17,2048,5393,4097,2341,1285,32,256,33,5377,513]

theorem envBound34546 : H12AffineFastState.Bounded env34546 := by
  intro p hp
  have h : env34546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34545_34546 : H12AffineEnvironment.transform 12 268 env34545 = env34546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34545 == env34546) = true)

theorem identity34546 : scanCanonicalize (H12AffineFastState.compose env34546 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34546 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34547 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4112,33,17,2,41,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound34547 : H12AffineFastState.Bounded env34547 := by
  intro p hp
  have h : env34547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34546_34547 : H12AffineEnvironment.transform 7 37 env34546 = env34547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34546 == env34547) = true)

def env34548 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1044,0,34,1029,2048,1024,1,32,33,17,2,41,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound34548 : H12AffineFastState.Bounded env34548 := by
  intro p hp
  have h : env34548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34547_34548 : H12AffineEnvironment.transform 11 48 env34547 = env34548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34547 == env34548) = true)

theorem identity34548 : scanCanonicalize (H12AffineFastState.compose env34548 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound34548 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34549 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1045,48,41,1044,0,34,1029,1045,1024,1,32,33,17,2,41,17,1045,1028,49,1045,1056,32,37,33,1044,513]

theorem envBound34549 : H12AffineFastState.Bounded env34549 := by
  intro p hp
  have h : env34549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34548_34549 : H12AffineEnvironment.transform 10 1045 env34548 = env34549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env34548 == env34549) = true)

def env34550 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,48,41,32,0,34,49,33,52,1,32,33,17,2,41,17,33,48,49,33,20,32,37,33,32,513]

theorem envBound34550 : H12AffineFastState.Bounded env34550 := by
  intro p hp
  have h : env34550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34549_34550 : H12AffineEnvironment.transform 9 52 env34549 = env34550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34549 == env34550) = true)

def env34551 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,48,41,33,0,34,48,32,53,1,32,33,17,2,41,17,32,49,49,32,21,32,37,33,33,513]

theorem envBound34551 : H12AffineFastState.Bounded env34551 := by
  intro p hp
  have h : env34551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34549_34551 : H12AffineEnvironment.transform 9 53 env34549 = env34551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34549 == env34551) = true)

theorem identity34551 : scanCanonicalize (H12AffineFastState.compose env34551 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34551 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34552 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,48,41,33,0,34,48,32,53,1,32,33,17,2,41,17,32,49,49,32,21,32,37,33,33,43]

theorem envBound34552 : H12AffineFastState.Bounded env34552 := by
  intro p hp
  have h : env34552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34551_34552 : H12AffineEnvironment.transform 8 42 env34551 = env34552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34551 == env34552) = true)

def leafEnv34552 : List Nat := [2,4,8,16,32,16,8,37,42,53,32,48,41,33,0,34,48,32,53,1,32,33,17,2,21,41,1,17,32,49,49,32,21,32,37,33,4,34,33,43,1,32,0]

def active34552 : List Nat := [0,1,2,3,4]

def tree34552 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34552 : H12WitnessSearch.Good tree34552 := H12GlobalWitnessIndex.good

theorem leafIdentity34552 : H12AffineFastState.composeSystem env34552 rootObs = leafEnv34552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34552 rootObs == leafEnv34552) = true)

theorem terminalChecked34552 : H12PackedTerminal.terminalCheckFast leafEnv34552 active34552 tree34552 = true := by decide +kernel

def env34553 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1045,0,34,1028,2048,1024,1,33,33,17,2,41,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound34553 : H12AffineFastState.Bounded env34553 := by
  intro p hp
  have h : env34553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34547_34553 : H12AffineEnvironment.transform 11 49 env34547 = env34553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34547 == env34553) = true)

theorem identity34553 : scanCanonicalize (H12AffineFastState.compose env34553 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound34553 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34554 : List Nat := [2,4,8,16,32,16,8,37,512,1024,33,49,41,1045,0,34,1028,33,1024,1,33,33,17,2,41,17,33,1029,48,33,1056,32,37,33,1045,513]

theorem envBound34554 : H12AffineFastState.Bounded env34554 := by
  intro p hp
  have h : env34554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34553_34554 : H12AffineEnvironment.transform 10 33 env34553 = env34554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env34553 == env34554) = true)

def env34555 : List Nat := [2,4,8,16,32,16,8,37,512,52,33,49,41,33,0,34,48,33,52,1,33,33,17,2,41,17,33,49,48,33,20,32,37,33,33,513]

theorem envBound34555 : H12AffineFastState.Bounded env34555 := by
  intro p hp
  have h : env34555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34554_34555 : H12AffineEnvironment.transform 9 52 env34554 = env34555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34554 == env34555) = true)

def env34556 : List Nat := [2,4,8,16,32,16,8,37,512,53,33,49,41,32,0,34,49,33,53,1,33,33,17,2,41,17,33,48,48,33,21,32,37,33,32,513]

theorem envBound34556 : H12AffineFastState.Bounded env34556 := by
  intro p hp
  have h : env34556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34554_34556 : H12AffineEnvironment.transform 9 53 env34554 = env34556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34554 == env34556) = true)

theorem identity34556 : scanCanonicalize (H12AffineFastState.compose env34556 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound34556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34557 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,49,41,32,0,34,49,33,53,1,33,33,17,2,41,17,33,48,48,33,21,32,37,33,32,42]

theorem envBound34557 : H12AffineFastState.Bounded env34557 := by
  intro p hp
  have h : env34557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34556_34557 : H12AffineEnvironment.transform 8 43 env34556 = env34557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env34556 == env34557) = true)

def leafEnv34557 : List Nat := [2,4,8,16,32,16,8,37,43,53,33,49,41,32,0,34,49,33,53,1,33,33,17,2,21,41,1,17,33,48,48,33,21,32,37,33,4,34,32,42,1,33,0]

def active34557 : List Nat := [0,1,2,3,4]

def tree34557 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34557 : H12WitnessSearch.Good tree34557 := H12GlobalWitnessIndex.good

theorem leafIdentity34557 : H12AffineFastState.composeSystem env34557 rootObs = leafEnv34557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34557 rootObs == leafEnv34557) = true)

theorem terminalChecked34557 : H12PackedTerminal.terminalCheckFast leafEnv34557 active34557 tree34557 = true := by decide +kernel

def env34558 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,144493,400501,485740,8193,65,292137,395637,416100,10281,1364,272393,256,21792,16464,74250]

theorem envBound34558 : H12AffineFastState.Bounded env34558 := by
  intro p hp
  have h : env34558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34539_34558 : H12AffineEnvironment.transform 6 9 env34539 = env34558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34539 == env34558) = true)

theorem identity34558 : scanCanonicalize (H12AffineFastState.compose env34558 (packedSelected [3,10,11,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound34558 : packedSelected [3,10,11,24,26,32] rootPS < 2^1333 := by decide +kernel

def env34559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,79130,262144,1024,29789,4160,65911,338287,285814,8193,65,292137,343151,355454,10281,1364,272393,256,21792,16464,74250]

theorem envBound34559 : H12AffineFastState.Bounded env34559 := by
  intro p hp
  have h : env34559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34558_34559 : H12AffineEnvironment.transform 16 79130 env34558 = env34559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env34558 == env34559) = true)

theorem identity34559 : scanCanonicalize (H12AffineFastState.compose env34559 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound34559 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env34560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,16401,262144,1024,29789,4160,29820,285796,285814,8193,65,292137,280932,268661,10281,1364,272393,256,21792,16464,22273]

theorem envBound34560 : H12AffineFastState.Bounded env34560 := by
  intro p hp
  have h : env34560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34559_34560 : H12AffineEnvironment.transform 15 29963 env34559 = env34560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env34559 == env34560) = true)

theorem identity34560 : scanCanonicalize (H12AffineFastState.compose env34560 (packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound34560 : packedSelected [0,1,3,7,8,9,10,12,14,15,16,17,22,24] rootPS < 2^1333 := by decide +kernel

def env34561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29963,16401,23808,1024,29789,4160,29820,356,374,8193,65,10281,5220,17525,10281,1364,29961,256,21792,16464,22273]

theorem envBound34561 : H12AffineFastState.Bounded env34561 := by
  intro p hp
  have h : env34561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34560_34561 : H12AffineEnvironment.transform 17 23808 env34560 = env34561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env34560 == env34561) = true)

theorem identity34561 : scanCanonicalize (H12AffineFastState.compose env34561 (packedSelected [0,2,6,11,14,16,18,20,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34561 : packedSelected [0,2,6,11,14,16,18,20,27] rootPS < 2^1333 := by decide +kernel

def env34562 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29788,29822,16401,23669,1024,29789,4160,29820,17,3,8193,65,10281,5220,17525,10281,1057,29820,117,21589,16464,22132]

theorem envBound34562 : H12AffineFastState.Bounded env34562 := by
  intro p hp
  have h : env34562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34561_34562 : H12AffineEnvironment.transform 7 117 env34561 = env34562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34561 == env34562) = true)

theorem identity34562 : scanCanonicalize (H12AffineFastState.compose env34562 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34562 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env34563 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13324,80,114,13341,10361,1024,81,4160,112,17,3,8193,65,10281,5220,12409,10281,1057,112,117,8281,13404,8824]

theorem envBound34563 : H12AffineFastState.Bounded env34563 := by
  intro p hp
  have h : env34563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34562_34563 : H12AffineEnvironment.transform 13 13324 env34562 = env34563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34562 == env34563) = true)

theorem identity34563 : scanCanonicalize (H12AffineFastState.compose env34563 (packedSelected [0,1,2,3,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6249) := by decide +kernel

theorem selectedBound34563 : packedSelected [0,1,2,3,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env34564 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,6249,3173,80,114,3188,4112,1024,81,4160,112,17,3,6248,65,4160,5220,2064,4160,1057,112,117,6192,3125,6673]

theorem envBound34564 : H12AffineFastState.Bounded env34564 := by
  intro p hp
  have h : env34564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34563_34564 : H12AffineEnvironment.transform 12 6249 env34563 = env34564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6249 env34563 == env34564) = true)

theorem identity34564 : scanCanonicalize (H12AffineFastState.compose env34564 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound34564 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env34565 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2064,121,3173,80,114,3188,2048,1024,81,2128,112,17,3,120,65,2128,3188,2064,2128,1057,112,117,32,3125,513]

theorem envBound34565 : H12AffineFastState.Bounded env34565 := by
  intro p hp
  have h : env34565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34564_34565 : H12AffineEnvironment.transform 11 2064 env34564 = env34565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env34564 == env34565) = true)

theorem identity34565 : scanCanonicalize (H12AffineFastState.compose env34565 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34565 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env34566 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,2064,121,2048,80,114,2065,2048,101,81,2128,112,17,3,120,65,2128,2065,2064,2128,68,112,117,32,2128,513]

theorem envBound34566 : H12AffineFastState.Bounded env34566 := by
  intro p hp
  have h : env34566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34565_34566 : H12AffineEnvironment.transform 9 101 env34565 = env34566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34565 == env34566) = true)

theorem identity34566 : scanCanonicalize (H12AffineFastState.compose env34566 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34566 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34567 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2064,40,2048,1,35,2065,2048,52,0,2049,33,17,3,41,16,2049,2065,2064,2049,21,33,36,32,2049,513]

theorem envBound34567 : H12AffineFastState.Bounded env34567 := by
  intro p hp
  have h : env34567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34566_34567 : H12AffineEnvironment.transform 5 17 env34566 = env34567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34566 == env34567) = true)

theorem identity34567 : scanCanonicalize (H12AffineFastState.compose env34567 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound34567 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34568 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,40,49,1,35,32,49,52,0,48,33,17,3,41,16,48,32,33,48,21,33,36,32,48,513]

theorem envBound34568 : H12AffineFastState.Bounded env34568 := by
  intro p hp
  have h : env34568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34567_34568 : H12AffineEnvironment.transform 10 49 env34567 = env34568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env34567 == env34568) = true)

def leafEnv34568 : List Nat := [2,4,8,16,32,17,9,36,512,52,49,33,40,49,1,35,32,49,52,0,48,33,17,3,21,41,1,16,48,32,33,48,21,33,36,32,4,34,48,513,1,49,0]

def active34568 : List Nat := [0,1,2,3,4,8]

def tree34568 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34568 : H12WitnessSearch.Good tree34568 := H12GlobalWitnessIndex.good

theorem leafIdentity34568 : H12AffineFastState.composeSystem env34568 rootObs = leafEnv34568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34568 rootObs == leafEnv34568) = true)

theorem terminalChecked34568 : H12PackedTerminal.terminalCheckFast leafEnv34568 active34568 tree34568 = true := by decide +kernel

def env34569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400637,498992,8328,65,295284,395773,416237,56573,1500,272392,256,21792,46213,74251]

theorem envBound34569 : H12AffineFastState.Bounded env34569 := by
  intro p hp
  have h : env34569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34537_34569 : H12AffineEnvironment.transform 20 4161 env34537 = env34569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34537 == env34569) = true)

theorem identity34569 : scanCanonicalize (H12AffineFastState.compose env34569 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138477) := by decide +kernel

theorem selectedBound34569 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138477,1024,32769,4161,180408,16,98781,8328,65,171417,5392,17664,56573,1500,144613,256,21792,46213,74251]

theorem envBound34570 : H12AffineFastState.Bounded env34570 := by
  intro p hp
  have h : env34570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34569_34570 : H12AffineEnvironment.transform 17 138477 env34569 = env34570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138477 env34569 == env34570) = true)

def env34571 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,4161,180272,16,98645,8192,65,171281,5392,17664,56437,1364,144493,256,21792,46093,74251]

theorem envBound34571 : H12AffineFastState.Bounded env34571 := by
  intro p hp
  have h : env34571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34570_34571 : H12AffineEnvironment.transform 6 8 env34570 = env34571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34570 == env34571) = true)

theorem identity34571 : scanCanonicalize (H12AffineFastState.compose env34571 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound34571 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34572 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,10281,1024,32769,4161,62588,16,98645,8192,65,43357,5392,17664,56437,1364,33,256,21792,46093,74251]

theorem envBound34572 : H12AffineFastState.Bounded env34572 := by
  intro p hp
  have h : env34572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34571_34572 : H12AffineEnvironment.transform 16 13388 env34571 = env34572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env34571 == env34572) = true)

theorem identity34572 : scanCanonicalize (H12AffineFastState.compose env34572 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound34572 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env34573 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13388,10281,1024,29788,4161,33,16,95496,8192,65,23808,5392,17664,10280,1364,33,256,21792,16464,74251]

theorem envBound34573 : H12AffineFastState.Bounded env34573 := by
  intro p hp
  have h : env34573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34572_34573 : H12AffineEnvironment.transform 14 29789 env34572 = env34573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env34572 == env34573) = true)

theorem identity34573 : scanCanonicalize (H12AffineFastState.compose env34573 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound34573 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env34574 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,13388,10281,1024,29788,4161,33,16,8542,8192,65,23808,5392,17664,10280,1364,33,256,21792,16464,30301]

theorem envBound34574 : H12AffineFastState.Bounded env34574 := by
  intro p hp
  have h : env34574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34573_34574 : H12AffineEnvironment.transform 15 21590 env34573 = env34574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env34573 == env34574) = true)

theorem identity34574 : scanCanonicalize (H12AffineFastState.compose env34574 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34574 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34575 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,1,8202,13388,10281,1024,0,4161,33,16,8542,8192,65,10588,5392,12636,10280,1364,33,256,8572,13324,513]

theorem envBound34575 : H12AffineFastState.Bounded env34575 := by
  intro p hp
  have h : env34575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34574_34575 : H12AffineEnvironment.transform 13 13404 env34574 = env34575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34574 == env34575) = true)

theorem identity34575 : scanCanonicalize (H12AffineFastState.compose env34575 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34575 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34576 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5393,2420,1024,0,4161,33,16,3,349,65,2049,5392,4097,2421,1364,33,256,33,5457,513]

theorem envBound34576 : H12AffineFastState.Bounded env34576 := by
  intro p hp
  have h : env34576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34575_34576 : H12AffineEnvironment.transform 12 349 env34575 = env34576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34575 == env34576) = true)

theorem identity34576 : scanCanonicalize (H12AffineFastState.compose env34576 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34576 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34577 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,262,5393,2341,1024,0,4112,33,16,3,268,16,2049,5392,4097,2340,1285,33,256,33,5376,513]

theorem envBound34577 : H12AffineFastState.Bounded env34577 := by
  intro p hp
  have h : env34577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34576_34577 : H12AffineEnvironment.transform 5 17 env34576 = env34577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34576 == env34577) = true)

theorem identity34577 : scanCanonicalize (H12AffineFastState.compose env34577 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound34577 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34578 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,49,268,1328,1,262,1312,2341,1024,0,33,33,16,3,268,16,2049,1313,48,2340,1285,33,256,33,1329,513]

theorem envBound34578 : H12AffineFastState.Bounded env34578 := by
  intro p hp
  have h : env34578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34577_34578 : H12AffineEnvironment.transform 11 49 env34577 = env34578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34577 == env34578) = true)

theorem identity34578 : scanCanonicalize (H12AffineFastState.compose env34578 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound34578 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34579 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1557,49,268,1328,1,262,1312,1840,1024,0,33,33,16,3,268,16,1556,1313,48,1841,1285,33,256,33,1329,513]

theorem envBound34579 : H12AffineFastState.Bounded env34579 := by
  intro p hp
  have h : env34579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34578_34579 : H12AffineEnvironment.transform 10 1557 env34578 = env34579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env34578 == env34579) = true)

theorem identity34579 : scanCanonicalize (H12AffineFastState.compose env34579 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound34579 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34580 : List Nat := [2,4,8,16,32,17,8,256,512,36,561,49,268,276,1,262,260,788,36,0,33,33,16,3,268,16,560,261,48,789,289,33,256,33,277,513]

theorem envBound34580 : H12AffineFastState.Bounded env34580 := by
  intro p hp
  have h : env34580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34579_34580 : H12AffineEnvironment.transform 9 36 env34579 = env34580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env34579 == env34580) = true)

theorem identity34580 : scanCanonicalize (H12AffineFastState.compose env34580 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound34580 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34581 : List Nat := [2,4,8,16,32,17,8,53,512,36,561,49,57,33,1,51,49,545,36,0,33,33,16,3,57,16,560,48,48,544,20,33,53,33,32,513]

theorem envBound34581 : H12AffineFastState.Bounded env34581 := by
  intro p hp
  have h : env34581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34580_34581 : H12AffineEnvironment.transform 7 53 env34580 = env34581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env34580 == env34581) = true)

theorem identity34581 : scanCanonicalize (H12AffineFastState.compose env34581 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34581 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34582 : List Nat := [2,4,8,0,32,1,8,37,512,36,545,33,41,33,1,35,33,545,36,0,33,33,0,3,41,0,544,32,32,544,4,33,37,33,32,513]

theorem envBound34582 : H12AffineFastState.Bounded env34582 := by
  intro p hp
  have h : env34582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34581_34582 : H12AffineEnvironment.transform 3 0 env34581 = env34582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34581 == env34582) = true)

theorem identity34582 : scanCanonicalize (H12AffineFastState.compose env34582 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound34582 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34583 : List Nat := [2,4,8,0,32,1,8,37,1,36,32,33,41,33,1,35,33,32,36,0,33,33,0,3,41,0,33,32,32,33,4,33,37,33,32,0]

theorem envBound34583 : H12AffineFastState.Bounded env34583 := by
  intro p hp
  have h : env34583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34582_34583 : H12AffineEnvironment.transform 8 1 env34582 = env34583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env34582 == env34583) = true)

theorem identity34583 : scanCanonicalize (H12AffineFastState.compose env34583 (packedSelected [8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34583 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env34584 : List Nat := [2,4,8,0,0,1,8,5,1,4,0,1,9,1,1,3,1,0,4,0,1,1,0,3,9,0,1,0,0,1,4,1,5,1,0,0]

theorem envBound34584 : H12AffineFastState.Bounded env34584 := by
  intro p hp
  have h : env34584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34583_34584 : H12AffineEnvironment.transform 4 0 env34583 = env34584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34583 == env34584) = true)

def env34585 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,180273,16,98644,8193,65,171280,5392,17664,56436,1365,144492,256,21792,46092,74251]

theorem envBound34585 : H12AffineFastState.Bounded env34585 := by
  intro p hp
  have h : env34585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34570_34585 : H12AffineEnvironment.transform 6 9 env34570 = env34585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34570 == env34585) = true)

theorem identity34585 : scanCanonicalize (H12AffineFastState.compose env34585 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound34585 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34586 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,35188,1024,32769,4161,21793,16,98644,8193,65,2048,5392,17664,56436,1365,41340,256,21792,46092,74251]

theorem envBound34586 : H12AffineFastState.Bounded env34586 := by
  intro p hp
  have h : env34586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34585_34586 : H12AffineEnvironment.transform 16 38160 env34585 = env34586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env34585 == env34586) = true)

def env34587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493628,498992,8328,65,2396468,2496956,416237,2149564,2102685,2373704,256,21792,46213,2175562]

theorem envBound34587 : H12AffineFastState.Bounded env34587 := by
  intro p hp
  have h : env34587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34536_34587 : H12AffineEnvironment.transform 21 180409 env34536 = env34587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env34536 == env34587) = true)

def env34588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400636,498992,8328,65,295284,395772,416237,56572,1501,272392,256,21792,46213,74250]

theorem envBound34588 : H12AffineFastState.Bounded env34588 := by
  intro p hp
  have h : env34588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34587_34588 : H12AffineEnvironment.transform 20 4160 env34587 = env34588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34587 == env34588) = true)

theorem identity34588 : scanCanonicalize (H12AffineFastState.compose env34588 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound34588 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,180409,62661,95497,8328,65,158029,57797,45524,56572,1501,180273,256,21792,46213,74250]

theorem envBound34589 : H12AffineFastState.Bounded env34589 := by
  intro p hp
  have h : env34589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34588_34589 : H12AffineEnvironment.transform 17 190521 env34588 = env34589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env34588 == env34589) = true)

theorem identity34589 : scanCanonicalize (H12AffineFastState.compose env34589 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound34589 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env34590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190521,1024,32769,4160,180409,62661,21762,8328,65,158029,57797,45524,56572,1501,180273,256,21792,46213,513]

theorem envBound34590 : H12AffineFastState.Bounded env34590 := by
  intro p hp
  have h : env34590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34589_34590 : H12AffineEnvironment.transform 15 8203 env34589 = env34590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env34589 == env34590) = true)

theorem identity34590 : scanCanonicalize (H12AffineFastState.compose env34590 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound34590 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env34591 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,131072,138476,1024,29908,4160,144492,16,21762,8328,65,158029,5392,17665,10281,1501,144612,256,21792,16464,513]

theorem envBound34591 : H12AffineFastState.Bounded env34591 := by
  intro p hp
  have h : env34591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34590_34591 : H12AffineEnvironment.transform 14 29909 env34590 = env34591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env34590 == env34591) = true)

theorem identity34591 : scanCanonicalize (H12AffineFastState.compose env34591 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound34591 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env34592 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,5441,2477,1024,29908,4160,8493,16,21762,8328,65,31756,5392,17665,10281,1501,8613,256,21792,16464,513]

theorem envBound34592 : H12AffineFastState.Bounded env34592 := by
  intro p hp
  have h : env34592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34591_34592 : H12AffineEnvironment.transform 16 5441 env34591 = env34592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env34591 == env34592) = true)

theorem identity34592 : scanCanonicalize (H12AffineFastState.compose env34592 (packedSelected [0,4,7,17,18,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound34592 : packedSelected [0,4,7,17,18,22,23] rootPS < 2^1333 := by decide +kernel

def env34593 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,16384,21841,399,5441,2477,1024,21840,4160,169,16,21762,268,65,23944,5392,17665,2477,1501,33,256,21792,16464,513]

theorem envBound34593 : H12AffineFastState.Bounded env34593 := by
  intro p hp
  have h : env34593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34592_34593 : H12AffineEnvironment.transform 12 388 env34592 = env34593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env34592 == env34593) = true)

theorem identity34593 : scanCanonicalize (H12AffineFastState.compose env34593 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound34593 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env34594 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,81,399,5441,2477,1024,80,4160,169,16,2,268,65,2184,5392,4097,2477,1501,33,256,32,5456,513]

theorem envBound34594 : H12AffineFastState.Bounded env34594 := by
  intro p hp
  have h : env34594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34593_34594 : H12AffineEnvironment.transform 13 5376 env34593 = env34594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34593 == env34594) = true)

theorem identity34594 : scanCanonicalize (H12AffineFastState.compose env34594 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34594 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34595 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5441,2341,1024,80,4160,33,16,2,268,65,2048,5392,4097,2341,1365,33,256,32,5456,513]

theorem envBound34595 : H12AffineFastState.Bounded env34595 := by
  intro p hp
  have h : env34595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34594_34595 : H12AffineEnvironment.transform 6 8 env34594 = env34595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34594 == env34595) = true)

theorem identity34595 : scanCanonicalize (H12AffineFastState.compose env34595 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34595 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34596 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5236,81,115,5173,2129,1024,80,4160,33,16,2,120,65,2048,5220,4097,2129,1057,33,116,32,5156,513]

theorem envBound34596 : H12AffineFastState.Bounded env34596 := by
  intro p hp
  have h : env34596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34595_34596 : H12AffineEnvironment.transform 7 116 env34595 = env34596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34595 == env34596) = true)

theorem identity34596 : scanCanonicalize (H12AffineFastState.compose env34596 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34596 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env34597 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,34,5173,2048,1024,1,4113,33,16,2,41,16,2048,5173,4097,2048,1057,33,37,32,5156,513]

theorem envBound34597 : H12AffineFastState.Bounded env34597 := by
  intro p hp
  have h : env34597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34596_34597 : H12AffineEnvironment.transform 5 17 env34596 = env34597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34596 == env34597) = true)

theorem identity34597 : scanCanonicalize (H12AffineFastState.compose env34597 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound34597 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34598 : List Nat := [2,4,8,16,32,17,8,37,512,1024,522,4096,41,5157,0,34,5173,522,1024,1,4113,33,16,2,41,16,522,5173,4097,522,1057,33,37,32,5156,513]

theorem envBound34598 : H12AffineFastState.Bounded env34598 := by
  intro p hp
  have h : env34598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34597_34598 : H12AffineEnvironment.transform 10 522 env34597 = env34598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env34597 == env34598) = true)

theorem identity34598 : scanCanonicalize (H12AffineFastState.compose env34598 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34598 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34599 : List Nat := [2,4,8,16,1,17,8,4,512,1024,522,4096,8,5124,0,3,5140,522,1024,1,4113,0,16,2,8,16,522,5140,4097,522,1024,0,4,1,5125,513]

theorem envBound34599 : H12AffineFastState.Bounded env34599 := by
  intro p hp
  have h : env34599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34598_34599 : H12AffineEnvironment.transform 4 1 env34598 = env34599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34598 == env34599) = true)

def env34600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400637,498992,8328,65,295285,395773,416237,56573,1500,272393,256,21792,46213,74251]

theorem envBound34600 : H12AffineFastState.Bounded env34600 := by
  intro p hp
  have h : env34600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34587_34600 : H12AffineEnvironment.transform 20 4161 env34587 = env34600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34587 == env34600) = true)

def env34601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,180409,144597,242968,8328,65,43357,139733,160197,56573,1500,33,256,21792,46213,74251]

theorem envBound34601 : H12AffineFastState.Bounded env34601 := by
  intro p hp
  have h : env34601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34600_34601 : H12AffineEnvironment.transform 17 10280 env34600 = env34601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env34600 == env34601) = true)

def env34602 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4161,21929,41413,73736,8328,65,43357,46277,58581,56573,1500,33,256,21792,46213,74251]

theorem envBound34602 : H12AffineFastState.Bounded env34602 := by
  intro p hp
  have h : env34602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34601_34602 : H12AffineEnvironment.transform 16 38160 env34601 = env34602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env34601 == env34602) = true)

theorem identity34602 : scanCanonicalize (H12AffineFastState.compose env34602 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound34602 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,13388,10280,1024,8541,4161,21929,153,73736,8328,65,2049,5529,17801,32161,1500,33,256,21792,5593,74251]

theorem envBound34603 : H12AffineFastState.Bounded env34603 := by
  intro p hp
  have h : env34603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34602_34603 : H12AffineEnvironment.transform 14 8540 env34602 = env34603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env34602 == env34603) = true)

theorem identity34603 : scanCanonicalize (H12AffineFastState.compose env34603 (packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 8402) := by decide +kernel

theorem selectedBound34603 : packedSelected [0,5,8,9,10,22,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env34604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8402,13388,10280,1024,8541,4161,21929,153,218,8328,65,2049,5529,17801,32161,1500,33,256,21792,5593,729]

theorem envBound34604 : H12AffineFastState.Bounded env34604 := by
  intro p hp
  have h : env34604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34603_34604 : H12AffineEnvironment.transform 15 8402 env34603 = env34604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8402 env34603 == env34604) = true)

theorem identity34604 : scanCanonicalize (H12AffineFastState.compose env34604 (packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound34604 : packedSelected [2,3,4,5,6,10,11,16,18,22] rootPS < 2^1333 := by decide +kernel

def env34605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1336,16384,1124,1514,4468,3344,1024,1125,4161,21929,153,218,1456,65,2049,5529,17801,22681,1500,33,256,21792,5593,729]

theorem envBound34605 : H12AffineFastState.Bounded env34605 := by
  intro p hp
  have h : env34605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34604_34605 : H12AffineEnvironment.transform 12 1336 env34604 = env34605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env34604 == env34605) = true)

theorem identity34605 : scanCanonicalize (H12AffineFastState.compose env34605 (packedSelected [1,3,8,10,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound34605 : packedSelected [1,3,8,10,16,20,24] rootPS < 2^1333 := by decide +kernel

def env34606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1336,4112,1124,1514,4468,3344,1024,1125,4161,1465,153,218,1456,65,2049,5529,5529,2185,1500,33,256,1328,5593,729]

theorem envBound34606 : H12AffineFastState.Bounded env34606 := by
  intro p hp
  have h : env34606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34605_34606 : H12AffineEnvironment.transform 13 4112 env34605 = env34606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env34605 == env34606) = true)

theorem identity34606 : scanCanonicalize (H12AffineFastState.compose env34606 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34606 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env34607 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4112,1124,1378,4468,3344,1024,1125,4161,1329,17,82,1336,65,2049,5393,5393,2049,1364,33,256,1328,5457,593]

theorem envBound34607 : H12AffineFastState.Bounded env34607 := by
  intro p hp
  have h : env34607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34606_34607 : H12AffineEnvironment.transform 6 8 env34606 = env34607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34606 == env34607) = true)

theorem identity34607 : scanCanonicalize (H12AffineFastState.compose env34607 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34607 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34608 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,1053,4112,1124,1095,4177,3125,1024,1125,4161,1044,17,82,1053,65,2049,5172,5172,2049,1137,33,37,1045,5236,593]

theorem envBound34608 : H12AffineFastState.Bounded env34608 := by
  intro p hp
  have h : env34608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34607_34608 : H12AffineEnvironment.transform 7 37 env34607 = env34608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34607 == env34608) = true)

theorem identity34608 : scanCanonicalize (H12AffineFastState.compose env34608 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound34608 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34609 : List Nat := [2,4,8,16,32,64,8,37,512,101,2048,4096,120,4112,1,34,4177,2128,101,0,4161,113,17,82,120,65,2049,4177,4177,2049,20,33,37,112,4113,593]

theorem envBound34609 : H12AffineFastState.Bounded env34609 := by
  intro p hp
  have h : env34609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34608_34609 : H12AffineEnvironment.transform 9 101 env34608 = env34609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env34608 == env34609) = true)

theorem identity34609 : scanCanonicalize (H12AffineFastState.compose env34609 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound34609 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env34610 : List Nat := [2,4,8,16,32,64,8,37,512,101,113,4096,120,4112,1,34,4177,33,101,0,4161,113,17,82,120,65,112,4177,4177,112,20,33,37,112,4113,593]

theorem envBound34610 : H12AffineFastState.Bounded env34610 := by
  intro p hp
  have h : env34610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34609_34610 : H12AffineEnvironment.transform 10 113 env34609 = env34610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env34609 == env34610) = true)

theorem identity34610 : scanCanonicalize (H12AffineFastState.compose env34610 (packedSelected [0,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound34610 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env34611 : List Nat := [2,4,8,16,32,64,8,37,512,101,113,64,120,80,1,34,17,33,101,0,1,113,17,82,120,65,112,17,17,112,20,33,37,112,81,593]

theorem envBound34611 : H12AffineFastState.Bounded env34611 := by
  intro p hp
  have h : env34611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34610_34611 : H12AffineEnvironment.transform 11 64 env34610 = env34611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env34610 == env34611) = true)

def env34612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1024,32769,4161,21928,41412,73737,8328,65,43357,46276,58580,56573,1500,33,256,21792,46213,74251]

theorem envBound34612 : H12AffineFastState.Bounded env34612 := by
  intro p hp
  have h : env34612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34601_34612 : H12AffineEnvironment.transform 16 38161 env34601 = env34612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env34601 == env34612) = true)

theorem identity34612 : scanCanonicalize (H12AffineFastState.compose env34612 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound34612 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,13508,10280,1024,8660,4161,21928,17,73737,8328,65,2184,5393,17665,32040,1500,33,256,21792,5456,74251]

theorem envBound34613 : H12AffineFastState.Bounded env34613 := by
  intro p hp
  have h : env34613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34612_34613 : H12AffineEnvironment.transform 14 8661 env34612 = env34613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env34612 == env34613) = true)

theorem identity34613 : scanCanonicalize (H12AffineFastState.compose env34613 (packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS)) = affineNative (2^(15+1) ^^^ 1467) := by decide +kernel

theorem selectedBound34613 : packedSelected [2,4,6,8,10,11,16,22,23,28] rootPS < 2^1333 := by decide +kernel

def env34614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,1467,13508,10280,1024,8660,4161,21928,17,9650,8328,65,2184,5393,17665,32040,1500,33,256,21792,5456,10160]

theorem envBound34614 : H12AffineFastState.Bounded env34614 := by
  intro p hp
  have h : env34614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34613_34614 : H12AffineEnvironment.transform 15 1467 env34613 = env34614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1467 env34613 == env34614) = true)

theorem identity34614 : scanCanonicalize (H12AffineFastState.compose env34614 (packedSelected [1,2,4,6,8,12,15,16,18,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34614 : packedSelected [1,2,4,6,8,12,15,16,18,22,23,26] rootPS < 2^1333 := by decide +kernel

def env34615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,8661,1467,13508,10280,1024,8660,4161,8692,17,9650,8328,65,2184,5393,12637,2420,1500,33,256,8572,5456,10160]

theorem envBound34615 : H12AffineFastState.Bounded env34615 := by
  intro p hp
  have h : env34615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34614_34615 : H12AffineEnvironment.transform 13 13404 env34614 = env34615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34614 == env34615) = true)

theorem identity34615 : scanCanonicalize (H12AffineFastState.compose env34615 (packedSelected [16,20] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound34615 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env34616 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12344,8661,479,12448,10280,100,8660,4161,8692,17,8662,8328,65,2184,4469,12637,2420,440,33,256,8572,4404,9172]

theorem envBound34616 : H12AffineFastState.Bounded env34616 := by
  intro p hp
  have h : env34616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34615_34616 : H12AffineEnvironment.transform 9 100 env34615 = env34616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env34615 == env34616) = true)

theorem identity34616 : scanCanonicalize (H12AffineFastState.compose env34616 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound34616 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env34617 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,40,4112,509,479,4232,2048,100,508,4161,476,17,510,160,65,2184,4469,4469,2420,440,33,256,340,4404,1020]

theorem envBound34617 : H12AffineFastState.Bounded env34617 := by
  intro p hp
  have h : env34617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34616_34617 : H12AffineEnvironment.transform 12 40 env34616 = env34617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env34616 == env34617) = true)

theorem identity34617 : scanCanonicalize (H12AffineFastState.compose env34617 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound34617 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env34618 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,4096,40,4112,292,262,4177,2048,100,293,4161,261,17,295,121,65,2129,4469,4469,2420,353,33,256,340,4404,805]

theorem envBound34618 : H12AffineFastState.Bounded env34618 := by
  intro p hp
  have h : env34618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34617_34618 : H12AffineEnvironment.transform 6 89 env34617 = env34618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env34617 == env34618) = true)

theorem identity34618 : scanCanonicalize (H12AffineFastState.compose env34618 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34618 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env34619 : List Nat := [2,4,8,16,32,64,89,116,512,100,2048,4096,40,4112,80,114,4177,2048,100,81,4161,113,17,83,121,65,2129,4097,4097,2048,21,33,116,32,4160,593]

theorem envBound34619 : H12AffineFastState.Bounded env34619 := by
  intro p hp
  have h : env34619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34618_34619 : H12AffineEnvironment.transform 7 116 env34618 = env34619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34618 == env34619) = true)

theorem identity34619 : scanCanonicalize (H12AffineFastState.compose env34619 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34619 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34620 : List Nat := [2,4,8,16,1,64,89,85,512,69,2048,4096,9,4112,80,83,4177,2048,69,81,4161,80,17,83,88,65,2129,4097,4097,2048,21,0,85,1,4160,593]

theorem envBound34620 : H12AffineFastState.Bounded env34620 := by
  intro p hp
  have h : env34620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34619_34620 : H12AffineEnvironment.transform 4 1 env34619 = env34620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34619 == env34620) = true)

theorem identity34620 : scanCanonicalize (H12AffineFastState.compose env34620 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound34620 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env34621 : List Nat := [2,4,8,16,1,64,89,85,512,69,2048,2113,9,2129,80,83,2064,2048,69,81,2048,80,17,83,88,65,2129,2112,2112,2048,21,0,85,1,2049,593]

theorem envBound34621 : H12AffineFastState.Bounded env34621 := by
  intro p hp
  have h : env34621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34620_34621 : H12AffineEnvironment.transform 11 2113 env34620 = env34621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env34620 == env34621) = true)

theorem identity34621 : scanCanonicalize (H12AffineFastState.compose env34621 (packedSelected [12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34621 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env34622 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,2064,9,2048,1,2,2064,2048,20,0,2048,1,17,2,9,16,2048,2065,2065,2048,21,0,4,1,2049,512]

theorem envBound34622 : H12AffineFastState.Bounded env34622 := by
  intro p hp
  have h : env34622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34621_34622 : H12AffineEnvironment.transform 5 17 env34621 = env34622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34621 == env34622) = true)

def env34623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,180409,144596,242969,8328,65,43356,139732,160196,56573,1500,32,256,21792,46213,74251]

theorem envBound34623 : H12AffineFastState.Bounded env34623 := by
  intro p hp
  have h : env34623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34600_34623 : H12AffineEnvironment.transform 17 10281 env34600 = env34623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env34600 == env34623) = true)

def env34624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1024,32769,4161,21929,41412,73737,8328,65,43356,46276,58580,56573,1500,32,256,21792,46213,74251]

theorem envBound34624 : H12AffineFastState.Bounded env34624 := by
  intro p hp
  have h : env34624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34623_34624 : H12AffineEnvironment.transform 16 38160 env34623 = env34624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env34623 == env34624) = true)

def env34625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,65536,38160,10281,1024,32769,4161,8573,41412,73737,8328,65,43356,46276,36864,43049,1500,32,256,8692,46213,74251]

theorem envBound34625 : H12AffineFastState.Bounded env34625 := by
  intro p hp
  have h : env34625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34624_34625 : H12AffineEnvironment.transform 13 13524 env34624 = env34625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env34624 == env34625) = true)

theorem identity34625 : scanCanonicalize (H12AffineFastState.compose env34625 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34625 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env34626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,38160,10281,1024,32769,4161,8573,41412,3,8328,65,43356,46276,36864,43049,1500,32,256,8692,46213,513]

theorem envBound34626 : H12AffineFastState.Bounded env34626 := by
  intro p hp
  have h : env34626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34625_34626 : H12AffineEnvironment.transform 15 8202 env34625 = env34626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34625 == env34626) = true)

theorem identity34626 : scanCanonicalize (H12AffineFastState.compose env34626 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound34626 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8660,8202,13508,10281,1024,8661,4161,8573,16,3,8328,65,2184,5392,12756,2557,1500,32,256,8692,5457,513]

theorem envBound34627 : H12AffineFastState.Bounded env34627 := by
  intro p hp
  have h : env34627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34626_34627 : H12AffineEnvironment.transform 14 8660 env34626 = env34627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env34626 == env34627) = true)

theorem identity34627 : scanCanonicalize (H12AffineFastState.compose env34627 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34627 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env34628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,8202,13388,10281,1024,8541,4161,8573,16,3,8192,65,2048,5392,12636,2421,1364,32,256,8572,5457,513]

theorem envBound34628 : H12AffineFastState.Bounded env34628 := by
  intro p hp
  have h : env34628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34627_34628 : H12AffineEnvironment.transform 6 8 env34627 = env34628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34627 == env34628) = true)

theorem identity34628 : scanCanonicalize (H12AffineFastState.compose env34628 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34628 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,1,343,5393,2420,1024,0,4161,32,16,3,349,65,2048,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound34629 : H12AffineFastState.Bounded env34629 := by
  intro p hp
  have h : env34629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34628_34629 : H12AffineEnvironment.transform 12 349 env34628 = env34629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34628 == env34629) = true)

theorem identity34629 : scanCanonicalize (H12AffineFastState.compose env34629 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound34629 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,349,1296,1,343,1280,2420,1024,0,80,32,16,3,349,65,2048,1281,16,2421,1364,32,256,33,1344,513]

theorem envBound34630 : H12AffineFastState.Bounded env34630 := by
  intro p hp
  have h : env34630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34629_34630 : H12AffineEnvironment.transform 11 17 env34629 = env34630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env34629 == env34630) = true)

theorem identity34630 : scanCanonicalize (H12AffineFastState.compose env34630 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound34630 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1077,17,349,1296,1,343,1280,1345,1024,0,80,32,16,3,349,65,1077,1281,16,1344,1364,32,256,33,1344,513]

theorem envBound34631 : H12AffineFastState.Bounded env34631 := by
  intro p hp
  have h : env34631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34630_34631 : H12AffineEnvironment.transform 10 1077 env34630 = env34631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env34630 == env34631) = true)

theorem identity34631 : scanCanonicalize (H12AffineFastState.compose env34631 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34631 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34632 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1077,17,268,1296,1,262,1280,1296,1024,0,1,32,16,3,268,16,1077,1281,16,1297,1285,32,256,33,1297,513]

theorem envBound34632 : H12AffineFastState.Bounded env34632 := by
  intro p hp
  have h : env34632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34631_34632 : H12AffineEnvironment.transform 5 17 env34631 = env34632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34631 == env34632) = true)

theorem identity34632 : scanCanonicalize (H12AffineFastState.compose env34632 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34633 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1077,17,41,1077,1,35,1061,1077,1024,0,1,32,16,3,41,16,1077,1060,16,1076,1056,32,37,33,1076,513]

theorem envBound34633 : H12AffineFastState.Bounded env34633 := by
  intro p hp
  have h : env34633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34632_34633 : H12AffineEnvironment.transform 7 37 env34632 = env34633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34632 == env34633) = true)

theorem identity34633 : scanCanonicalize (H12AffineFastState.compose env34633 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34633 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34634 : List Nat := [2,4,8,16,32,17,8,37,512,53,0,17,41,0,1,35,16,0,53,0,1,32,16,3,41,16,0,17,16,1,21,32,37,33,1,513]

theorem envBound34634 : H12AffineFastState.Bounded env34634 := by
  intro p hp
  have h : env34634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34633_34634 : H12AffineEnvironment.transform 9 53 env34633 = env34634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34633 == env34634) = true)

theorem identity34634 : scanCanonicalize (H12AffineFastState.compose env34634 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34634 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34635 : List Nat := [2,4,8,1,32,0,8,37,512,36,0,0,41,0,1,35,1,0,36,0,1,32,1,3,41,1,0,0,1,1,4,32,37,33,1,513]

theorem envBound34635 : H12AffineFastState.Bounded env34635 := by
  intro p hp
  have h : env34635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34634_34635 : H12AffineEnvironment.transform 3 1 env34634 = env34635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34634 == env34635) = true)

theorem identity34635 : scanCanonicalize (H12AffineFastState.compose env34635 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound34635 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34636 : List Nat := [2,4,8,1,32,0,8,37,42,36,0,0,41,0,1,35,1,0,36,0,1,32,1,3,41,1,0,0,1,1,4,32,37,33,1,43]

theorem envBound34636 : H12AffineFastState.Bounded env34636 := by
  intro p hp
  have h : env34636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34635_34636 : H12AffineEnvironment.transform 8 42 env34635 = env34636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env34635 == env34636) = true)

def env34637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,65536,38160,10281,1024,32769,4161,8572,41412,73737,8328,65,43356,46276,36865,43048,1500,32,256,8693,46213,74251]

theorem envBound34637 : H12AffineFastState.Bounded env34637 := by
  intro p hp
  have h : env34637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34624_34637 : H12AffineEnvironment.transform 13 13525 env34624 = env34637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env34624 == env34637) = true)

theorem identity34637 : scanCanonicalize (H12AffineFastState.compose env34637 (packedSelected [3,4,5,7,9,10,14,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound34637 : packedSelected [3,4,5,7,9,10,14,27,35] rootPS < 2^1333 := by decide +kernel

def env34638 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,41091,38160,10281,1024,32769,4161,8572,41412,32906,8328,65,43356,46276,36865,43048,1500,32,256,8693,46213,33416]

theorem envBound34638 : H12AffineFastState.Bounded env34638 := by
  intro p hp
  have h : env34638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34637_34638 : H12AffineEnvironment.transform 15 41091 env34637 = env34638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env34637 == env34638) = true)

theorem identity34638 : scanCanonicalize (H12AffineFastState.compose env34638 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound34638 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env34639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,32768,33246,38160,2420,1024,32769,4161,33,32921,32906,469,65,34817,38297,36865,35189,1500,32,256,168,38360,33416]

theorem envBound34639 : H12AffineFastState.Bounded env34639 := by
  intro p hp
  have h : env34639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34638_34639 : H12AffineEnvironment.transform 12 349 env34638 = env34639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env34638 == env34639) = true)

theorem identity34639 : scanCanonicalize (H12AffineFastState.compose env34639 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34639 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,0,478,5392,2420,1024,1,4161,33,153,138,469,65,2049,5529,4097,2421,1500,32,256,168,5592,648]

theorem envBound34640 : H12AffineFastState.Bounded env34640 := by
  intro p hp
  have h : env34640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34639_34640 : H12AffineEnvironment.transform 14 0 env34639 = env34640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34639 == env34640) = true)

def env34641 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,21928,41413,73736,8328,65,43356,46277,58581,56573,1500,32,256,21792,46213,74251]

theorem envBound34641 : H12AffineFastState.Bounded env34641 := by
  intro p hp
  have h : env34641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34623_34641 : H12AffineEnvironment.transform 16 38161 env34623 = env34641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env34623 == env34641) = true)

theorem identity34641 : scanCanonicalize (H12AffineFastState.compose env34641 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34641 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1024,32769,4161,21792,41293,73736,8192,65,43356,46157,58461,56437,1364,32,256,21792,46093,74251]

theorem envBound34642 : H12AffineFastState.Bounded env34642 := by
  intro p hp
  have h : env34642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34641_34642 : H12AffineEnvironment.transform 6 8 env34641 = env34642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34641 == env34642) = true)

theorem identity34642 : scanCanonicalize (H12AffineFastState.compose env34642 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound34642 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env34643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,38161,10281,1024,32769,4161,21792,41293,32770,8192,65,43356,46157,58461,56437,1364,32,256,21792,46093,33281]

theorem envBound34643 : H12AffineFastState.Bounded env34643 := by
  intro p hp
  have h : env34643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34642_34643 : H12AffineEnvironment.transform 15 40970 env34642 = env34643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env34642 == env34643) = true)

theorem identity34643 : scanCanonicalize (H12AffineFastState.compose env34643 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34643 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env34644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,8202,5393,10281,1024,1,4161,21792,8525,2,8192,65,10588,13389,25693,23669,1364,32,256,21792,13325,513]

theorem envBound34644 : H12AffineFastState.Bounded env34644 := by
  intro p hp
  have h : env34644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34643_34644 : H12AffineEnvironment.transform 14 0 env34643 = env34644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34643 == env34644) = true)

theorem identity34644 : scanCanonicalize (H12AffineFastState.compose env34644 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34644 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env34645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,5393,10281,1024,1,4161,8572,8525,2,8192,65,10588,13389,4097,10281,1364,32,256,8572,13325,513]

theorem envBound34645 : H12AffineFastState.Bounded env34645 := by
  intro p hp
  have h : env34645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34644_34645 : H12AffineEnvironment.transform 13 13404 env34644 = env34645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34644 == env34645) = true)

theorem identity34645 : scanCanonicalize (H12AffineFastState.compose env34645 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34645 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env34646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,0,262,5393,2341,1024,1,4161,112,65,2,268,65,2128,5441,4097,2341,1364,32,256,112,5377,513]

theorem envBound34646 : H12AffineFastState.Bounded env34646 := by
  intro p hp
  have h : env34646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34645_34646 : H12AffineEnvironment.transform 12 268 env34645 = env34646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34645 == env34646) = true)

theorem identity34646 : scanCanonicalize (H12AffineFastState.compose env34646 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34646 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34647 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1024,1,4112,33,16,2,268,16,2049,5392,4097,2341,1285,32,256,33,5377,513]

theorem envBound34647 : H12AffineFastState.Bounded env34647 := by
  intro p hp
  have h : env34647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34646_34647 : H12AffineEnvironment.transform 5 17 env34646 = env34647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34646 == env34647) = true)

theorem identity34647 : scanCanonicalize (H12AffineFastState.compose env34647 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound34647 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34648 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,277,268,1044,0,262,1028,2341,1024,1,261,33,16,2,268,16,2049,1029,276,2341,1285,32,256,33,1044,513]

theorem envBound34648 : H12AffineFastState.Bounded env34648 := by
  intro p hp
  have h : env34648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34647_34648 : H12AffineEnvironment.transform 11 277 env34647 = env34648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env34647 == env34648) = true)

theorem identity34648 : scanCanonicalize (H12AffineFastState.compose env34648 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound34648 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34649 : List Nat := [2,4,8,16,32,17,8,256,512,20,2048,277,268,0,0,262,16,2341,20,1,261,33,16,2,268,16,2049,17,276,2341,273,32,256,33,0,513]

theorem envBound34649 : H12AffineFastState.Bounded env34649 := by
  intro p hp
  have h : env34649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34648_34649 : H12AffineEnvironment.transform 9 20 env34648 = env34649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env34648 == env34649) = true)

theorem identity34649 : scanCanonicalize (H12AffineFastState.compose env34649 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound34649 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34650 : List Nat := [2,4,8,16,32,17,8,256,261,20,2048,277,268,0,0,262,16,2341,20,1,261,33,16,2,268,16,2049,17,276,2341,273,32,256,33,0,260]

theorem envBound34650 : H12AffineFastState.Bounded env34650 := by
  intro p hp
  have h : env34650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34649_34650 : H12AffineEnvironment.transform 8 261 env34649 = env34650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env34649 == env34650) = true)

theorem identity34650 : scanCanonicalize (H12AffineFastState.compose env34650 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound34650 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34651 : List Nat := [2,4,8,16,32,17,8,256,261,20,48,277,268,0,0,262,16,277,20,1,261,33,16,2,268,16,49,17,276,277,273,32,256,33,0,260]

theorem envBound34651 : H12AffineFastState.Bounded env34651 := by
  intro p hp
  have h : env34651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34650_34651 : H12AffineEnvironment.transform 10 48 env34650 = env34651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env34650 == env34651) = true)

theorem identity34651 : scanCanonicalize (H12AffineFastState.compose env34651 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound34651 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34652 : List Nat := [2,4,8,16,17,17,8,256,261,20,1,277,268,0,0,262,16,277,20,1,261,16,16,2,268,16,0,17,276,277,273,17,256,16,0,260]

theorem envBound34652 : H12AffineFastState.Bounded env34652 := by
  intro p hp
  have h : env34652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34651_34652 : H12AffineEnvironment.transform 4 17 env34651 = env34652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env34651 == env34652) = true)

theorem identity34652 : scanCanonicalize (H12AffineFastState.compose env34652 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound34652 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env34653 : List Nat := [2,4,8,16,17,17,8,5,0,20,1,16,9,0,0,3,16,16,20,1,0,16,16,2,9,16,0,17,17,16,20,17,5,16,0,1]

theorem envBound34653 : H12AffineFastState.Bounded env34653 := by
  intro p hp
  have h : env34653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34652_34653 : H12AffineEnvironment.transform 7 5 env34652 = env34653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env34652 == env34653) = true)

theorem identity34653 : scanCanonicalize (H12AffineFastState.compose env34653 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound34653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34654 : List Nat := [2,4,8,0,1,1,8,5,0,4,1,0,9,0,0,3,0,0,4,1,0,0,0,2,9,0,0,1,1,0,4,1,5,0,0,1]

theorem envBound34654 : H12AffineFastState.Bounded env34654 := by
  intro p hp
  have h : env34654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34653_34654 : H12AffineEnvironment.transform 3 0 env34653 = env34654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env34653 == env34654) = true)

def env34655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2493628,498993,8328,65,6705548,2496957,416237,2149564,2102684,6748400,256,21793,46212,2175563]

theorem envBound34655 : H12AffineFastState.Bounded env34655 := by
  intro p hp
  have h : env34655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34535_34655 : H12AffineEnvironment.transform 23 498993 env34535 = env34655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 498993 env34535 == env34655) = true)

def env34656 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180408,2493628,498993,8328,65,2396468,2496957,416237,2149564,2102684,2373704,256,21793,46212,2175563]

theorem envBound34656 : H12AffineFastState.Bounded env34656 := by
  intro p hp
  have h : env34656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34655_34656 : H12AffineEnvironment.transform 21 180408 env34655 = env34656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env34655 == env34656) = true)

def env34657 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180408,400636,498993,8328,65,295284,395773,416237,56572,1500,272392,256,21793,46212,74251]

theorem envBound34657 : H12AffineFastState.Bounded env34657 := by
  intro p hp
  have h : env34657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34656_34657 : H12AffineEnvironment.transform 20 4160 env34656 = env34657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34656 == env34657) = true)

theorem identity34657 : scanCanonicalize (H12AffineFastState.compose env34657 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound34657 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34658 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,4160,180408,73754,41431,8328,65,245138,79131,91403,56572,1500,201966,256,21793,46212,74251]

theorem envBound34658 : H12AffineFastState.Bounded env34658 := by
  intro p hp
  have h : env34658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34657_34658 : H12AffineEnvironment.transform 17 212198 env34657 = env34658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env34657 == env34658) = true)

def env34659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67754,1024,32769,4160,62708,73754,41431,8328,65,100830,79131,91403,56572,1500,73890,256,21793,46212,74251]

theorem envBound34659 : H12AffineFastState.Bounded env34659 := by
  intro p hp
  have h : env34659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34658_34659 : H12AffineEnvironment.transform 16 13388 env34658 = env34659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env34658 == env34659) = true)

theorem identity34659 : scanCanonicalize (H12AffineFastState.compose env34659 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 9576) := by decide +kernel

theorem selectedBound34659 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env34660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9576,65536,13388,67754,1024,9577,4160,20892,73754,1215,8328,65,76982,79131,91403,31124,1500,73890,256,21793,4588,74251]

theorem envBound34660 : H12AffineFastState.Bounded env34660 := by
  intro p hp
  have h : env34660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34659_34660 : H12AffineEnvironment.transform 14 9576 env34659 = env34660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9576 env34659 == env34660) = true)

theorem identity34660 : scanCanonicalize (H12AffineFastState.compose env34660 (packedSelected [0,1,3,5,14,15,16,18,19,26,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 6379) := by decide +kernel

theorem selectedBound34660 : packedSelected [0,1,3,5,14,15,16,18,19,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env34661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9576,6379,13388,4161,1024,9577,4160,20892,14577,1215,8328,65,13405,11760,32224,31124,1500,14409,256,21793,4588,15072]

theorem envBound34661 : H12AffineFastState.Bounded env34661 := by
  intro p hp
  have h : env34661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34660_34661 : H12AffineEnvironment.transform 15 6379 env34660 = env34661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6379 env34660 == env34661) = true)

theorem identity34661 : scanCanonicalize (H12AffineFastState.compose env34661 (packedSelected [5,9,10,11,16,22,24,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 7420) := by decide +kernel

theorem selectedBound34661 : packedSelected [5,9,10,11,16,22,24,26,31] rootPS < 2^1333 := by decide +kernel

def env34662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,7420,9576,6379,13388,4161,1024,9577,4160,3424,14577,1215,8328,65,13405,11760,8476,9576,1500,14409,256,2525,4588,15072]

theorem envBound34662 : H12AffineFastState.Bounded env34662 := by
  intro p hp
  have h : env34662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34661_34662 : H12AffineEnvironment.transform 13 7420 env34661 = env34662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7420 env34661 == env34662) = true)

theorem identity34662 : scanCanonicalize (H12AffineFastState.compose env34662 (packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34662 : packedSelected [0,1,3,5,8,9,10,11,12,16,18,19,20,22,27,38] rootPS < 2^1333 := by decide +kernel

def env34663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,7420,1125,6379,5441,4161,1024,1124,4160,3424,6652,1215,389,65,5456,3325,17,1125,1500,6468,256,2525,4588,7149]

theorem envBound34663 : H12AffineFastState.Bounded env34663 := by
  intro p hp
  have h : env34663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34662_34663 : H12AffineEnvironment.transform 12 269 env34662 = env34663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34662 == env34663) = true)

theorem identity34663 : scanCanonicalize (H12AffineFastState.compose env34663 (packedSelected [5,9,10,11,12,16,22,24] rootPS)) = affineNative (2^(11+1) ^^^ 3545) := by decide +kernel

theorem selectedBound34663 : packedSelected [5,9,10,11,12,16,22,24] rootPS < 2^1333 := by decide +kernel

def env34664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3545,269,293,1125,1330,2200,3480,1024,1124,3481,3424,1061,1215,389,65,2185,3325,17,1125,1500,1181,256,2525,3125,1588]

theorem envBound34664 : H12AffineFastState.Bounded env34664 := by
  intro p hp
  have h : env34664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34663_34664 : H12AffineEnvironment.transform 11 3545 env34663 = env34664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3545 env34663 == env34664) = true)

theorem identity34664 : scanCanonicalize (H12AffineFastState.compose env34664 (packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS)) = affineNative (2^(10+1) ^^^ 508) := by decide +kernel

theorem selectedBound34664 : packedSelected [0,1,4,7,8,9,10,11,12,16] rootPS < 2^1333 := by decide +kernel

def env34665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,508,1061,269,293,1125,1330,356,1124,1024,1124,1125,1180,1061,1215,389,65,373,1281,17,1125,1500,1181,256,33,1481,1588]

theorem envBound34665 : H12AffineFastState.Bounded env34665 := by
  intro p hp
  have h : env34665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34664_34665 : H12AffineEnvironment.transform 10 508 env34664 = env34665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 508 env34664 == env34665) = true)

theorem identity34665 : scanCanonicalize (H12AffineFastState.compose env34665 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34665 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env34666 : List Nat := [2,4,8,16,32,64,128,37,512,1024,217,1061,40,0,1125,1047,65,1124,1024,1124,1125,1180,1061,1215,160,65,80,1060,17,1125,1273,1181,37,33,1260,1588]

theorem envBound34666 : H12AffineFastState.Bounded env34666 := by
  intro p hp
  have h : env34666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34665_34666 : H12AffineEnvironment.transform 7 37 env34665 = env34666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34665 == env34666) = true)

theorem identity34666 : scanCanonicalize (H12AffineFastState.compose env34666 (packedSelected [1,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound34666 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env34667 : List Nat := [2,4,8,16,32,64,128,37,512,188,217,153,40,0,217,171,65,216,188,216,217,32,153,3,160,65,80,152,17,217,69,33,37,33,80,648]

theorem envBound34667 : H12AffineFastState.Bounded env34667 := by
  intro p hp
  have h : env34667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34666_34667 : H12AffineEnvironment.transform 9 188 env34666 = env34667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env34666 == env34667) = true)

theorem identity34667 : scanCanonicalize (H12AffineFastState.compose env34667 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound34667 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env34668 : List Nat := [2,4,8,16,32,49,128,37,512,188,168,153,40,0,168,171,48,169,188,169,168,32,153,3,160,48,33,152,17,168,52,33,37,33,33,648]

theorem envBound34668 : H12AffineFastState.Bounded env34668 := by
  intro p hp
  have h : env34668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34667_34668 : H12AffineEnvironment.transform 5 49 env34667 = env34668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env34667 == env34668) = true)

theorem identity34668 : scanCanonicalize (H12AffineFastState.compose env34668 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34668 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34669 : List Nat := [2,4,8,1,32,32,128,37,512,173,168,136,40,0,168,171,33,169,173,169,168,32,136,3,160,33,33,137,0,168,37,33,37,33,33,648]

theorem envBound34669 : H12AffineFastState.Bounded env34669 := by
  intro p hp
  have h : env34669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34668_34669 : H12AffineEnvironment.transform 3 1 env34668 = env34669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34668 == env34669) = true)

theorem identity34669 : scanCanonicalize (H12AffineFastState.compose env34669 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound34669 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env34670 : List Nat := [2,4,8,1,32,32,128,37,32,173,168,136,40,0,168,171,33,169,173,169,168,32,136,3,160,33,33,137,0,168,37,33,37,33,33,168]

theorem envBound34670 : H12AffineFastState.Bounded env34670 := by
  intro p hp
  have h : env34670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34669_34670 : H12AffineEnvironment.transform 8 32 env34669 = env34670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env34669 == env34670) = true)

theorem identity34670 : scanCanonicalize (H12AffineFastState.compose env34670 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound34670 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34671 : List Nat := [2,4,8,1,32,32,40,37,32,5,0,32,40,0,0,3,33,1,5,1,0,32,32,3,8,33,33,33,0,0,37,33,37,33,33,0]

theorem envBound34671 : H12AffineFastState.Bounded env34671 := by
  intro p hp
  have h : env34671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34670_34671 : H12AffineEnvironment.transform 6 40 env34670 = env34671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env34670 == env34671) = true)

theorem identity34671 : scanCanonicalize (H12AffineFastState.compose env34671 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34671 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34672 : List Nat := [2,4,8,1,1,1,9,4,1,5,0,1,9,0,0,3,0,1,5,1,0,1,1,3,8,0,0,0,0,0,4,0,4,0,0,0]

theorem envBound34672 : H12AffineFastState.Bounded env34672 := by
  intro p hp
  have h : env34672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34671_34672 : H12AffineEnvironment.transform 4 1 env34671 = env34672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34671 == env34672) = true)

theorem identity34672 : scanCanonicalize (H12AffineFastState.compose env34672 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound34672 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34673 : List Nat := [2,1,8,1,1,1,9,1,1,0,0,1,9,0,0,3,0,1,0,1,0,1,1,3,8,0,0,0,0,0,1,0,1,0,0,0]

theorem envBound34673 : H12AffineFastState.Bounded env34673 := by
  intro p hp
  have h : env34673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34672_34673 : H12AffineEnvironment.transform 1 1 env34672 = env34673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env34672 == env34673) = true)

theorem identity34673 : scanCanonicalize (H12AffineFastState.compose env34673 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound34673 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34674 : List Nat := [0,1,8,1,1,1,9,1,1,0,0,1,9,0,0,1,0,1,0,1,0,1,1,1,8,0,0,0,0,0,1,0,1,0,0,0]

theorem envBound34674 : H12AffineFastState.Bounded env34674 := by
  intro p hp
  have h : env34674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34673_34674 : H12AffineEnvironment.transform 0 0 env34673 = env34674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env34673 == env34674) = true)

theorem identity34674 : scanCanonicalize (H12AffineFastState.compose env34674 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound34674 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env34675 : List Nat := [0,1,0,1,1,1,1,1,1,0,0,1,1,0,0,1,0,1,0,1,0,1,1,1,0,0,0,0,0,0,1,0,1,0,0,0]

theorem envBound34675 : H12AffineFastState.Bounded env34675 := by
  intro p hp
  have h : env34675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34674_34675 : H12AffineEnvironment.transform 2 0 env34674 = env34675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env34674 == env34675) = true)

def env34676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13389,67755,1024,32769,4160,62709,73754,41431,8328,65,100831,79131,91403,56572,1500,73891,256,21793,46212,74251]

theorem envBound34676 : H12AffineFastState.Bounded env34676 := by
  intro p hp
  have h : env34676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34658_34676 : H12AffineEnvironment.transform 16 13389 env34658 = env34676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env34658 == env34676) = true)

theorem identity34676 : scanCanonicalize (H12AffineFastState.compose env34676 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound34676 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env34677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,40971,13389,43168,1024,32769,4160,62709,32785,41431,8328,65,10708,38160,50432,56572,1500,32936,256,21793,46212,33280]

theorem envBound34677 : H12AffineFastState.Bounded env34677 := by
  intro p hp
  have h : env34677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34676_34677 : H12AffineEnvironment.transform 15 40971 env34676 = env34677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env34676 == env34677) = true)

theorem identity34677 : scanCanonicalize (H12AffineFastState.compose env34677 (packedSelected [0,2,3,6,7,9,11,15,16,17,18,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound34677 : packedSelected [0,2,3,6,7,9,11,15,16,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env34678 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,479,13389,2420,1024,8661,4160,21793,8645,3,8328,65,10708,13508,25812,32040,1500,8572,256,21793,5456,9172]

theorem envBound34678 : H12AffineFastState.Bounded env34678 := by
  intro p hp
  have h : env34678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34677_34678 : H12AffineEnvironment.transform 14 8660 env34677 = env34678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env34677 == env34678) = true)

theorem identity34678 : scanCanonicalize (H12AffineFastState.compose env34678 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34678 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env34679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,13389,2420,1024,8541,4160,21793,8525,3,8192,65,10588,13388,25692,32040,1364,8572,256,21793,5456,9052]

theorem envBound34679 : H12AffineFastState.Bounded env34679 := by
  intro p hp
  have h : env34679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34678_34679 : H12AffineEnvironment.transform 6 8 env34678 = env34679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34678 == env34679) = true)

theorem identity34679 : scanCanonicalize (H12AffineFastState.compose env34679 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound34679 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env34680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,343,13389,2420,1024,8541,4160,8493,8525,3,8192,65,10588,13388,4176,2340,1364,8572,256,8493,5456,9052]

theorem envBound34680 : H12AffineFastState.Bounded env34680 := by
  intro p hp
  have h : env34680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34679_34680 : H12AffineEnvironment.transform 13 13324 env34679 = env34680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env34679 == env34680) = true)

theorem identity34680 : scanCanonicalize (H12AffineFastState.compose env34680 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34680 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env34681 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8460,263,13341,2340,1024,8461,4112,8493,8477,3,8192,17,10508,13340,4096,2340,1284,8492,256,8493,5376,8972]

theorem envBound34681 : H12AffineFastState.Bounded env34681 := by
  intro p hp
  have h : env34681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34680_34681 : H12AffineEnvironment.transform 5 16 env34680 = env34681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34680 == env34681) = true)

theorem identity34681 : scanCanonicalize (H12AffineFastState.compose env34681 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound34681 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env34682 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,263,5392,2340,1024,0,4112,32,16,3,269,17,2049,5393,4096,2340,1284,33,256,32,5376,513]

theorem envBound34682 : H12AffineFastState.Bounded env34682 := by
  intro p hp
  have h : env34682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34681_34682 : H12AffineEnvironment.transform 12 269 env34681 = env34682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env34681 == env34682) = true)

theorem identity34682 : scanCanonicalize (H12AffineFastState.compose env34682 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound34682 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34683 : List Nat := [2,4,8,16,32,16,8,53,512,1024,2048,4096,56,5172,1,50,5157,2065,1024,0,4112,32,16,3,56,17,2049,5156,4096,2065,1073,33,53,32,5173,513]

theorem envBound34683 : H12AffineFastState.Bounded env34683 := by
  intro p hp
  have h : env34683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34682_34683 : H12AffineEnvironment.transform 7 53 env34682 = env34683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env34682 == env34683) = true)

theorem identity34683 : scanCanonicalize (H12AffineFastState.compose env34683 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 3119) := by decide +kernel

theorem selectedBound34683 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34684 : List Nat := [2,4,8,16,32,16,8,53,512,1024,2048,3119,56,2075,1,50,2058,2065,1024,0,3135,32,16,3,56,17,2049,2059,3119,2065,1073,33,53,32,2074,513]

theorem envBound34684 : H12AffineFastState.Bounded env34684 := by
  intro p hp
  have h : env34684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34683_34684 : H12AffineEnvironment.transform 11 3119 env34683 = env34684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3119 env34683 == env34684) = true)

theorem identity34684 : scanCanonicalize (H12AffineFastState.compose env34684 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound34684 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env34685 : List Nat := [2,4,8,16,16,16,8,5,512,1024,2048,3103,8,2075,1,2,2058,2065,1024,0,3087,16,16,3,8,17,2049,2059,3103,2065,1025,17,5,16,2074,513]

theorem envBound34685 : H12AffineFastState.Bounded env34685 := by
  intro p hp
  have h : env34685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34684_34685 : H12AffineEnvironment.transform 4 16 env34684 = env34685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env34684 == env34685) = true)

theorem identity34685 : scanCanonicalize (H12AffineFastState.compose env34685 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound34685 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env34686 : List Nat := [2,4,8,16,16,16,8,5,512,15,2048,2064,8,2075,1,2,2058,2065,15,0,2048,16,16,3,8,17,2049,2059,2064,2065,14,17,5,16,2074,513]

theorem envBound34686 : H12AffineFastState.Bounded env34686 := by
  intro p hp
  have h : env34686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34685_34686 : H12AffineEnvironment.transform 9 15 env34685 = env34686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env34685 == env34686) = true)

theorem identity34686 : scanCanonicalize (H12AffineFastState.compose env34686 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound34686 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34687 : List Nat := [2,4,2,16,16,16,2,5,512,5,2048,2064,2,2065,1,2,2048,2065,5,0,2048,16,16,3,2,17,2049,2049,2064,2065,4,17,5,16,2064,513]

theorem envBound34687 : H12AffineFastState.Bounded env34687 := by
  intro p hp
  have h : env34687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34686_34687 : H12AffineEnvironment.transform 2 2 env34686 = env34687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env34686 == env34687) = true)

theorem identity34687 : scanCanonicalize (H12AffineFastState.compose env34687 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 519) := by decide +kernel

theorem selectedBound34687 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env34688 : List Nat := [2,4,2,16,16,16,2,5,512,5,519,535,2,534,1,2,519,534,5,0,519,16,16,3,2,17,518,518,535,534,4,17,5,16,535,513]

theorem envBound34688 : H12AffineFastState.Bounded env34688 := by
  intro p hp
  have h : env34688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34687_34688 : H12AffineEnvironment.transform 10 519 env34687 = env34688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 519 env34687 == env34688) = true)

def env34689 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180408,400637,498993,8328,65,295285,395772,416237,56573,1501,272393,256,21793,46212,74250]

theorem envBound34689 : H12AffineFastState.Bounded env34689 := by
  intro p hp
  have h : env34689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34656_34689 : H12AffineEnvironment.transform 20 4161 env34656 = env34689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34656 == env34689) = true)

theorem identity34689 : scanCanonicalize (H12AffineFastState.compose env34689 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound34689 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34690 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,180408,400637,412142,8328,65,295285,395772,416237,56573,1501,272393,256,21793,46212,63189]

theorem envBound34690 : H12AffineFastState.Bounded env34690 := by
  intro p hp
  have h : env34690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34689_34690 : H12AffineEnvironment.transform 15 54495 env34689 = env34690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env34689 == env34690) = true)

def env34691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,4161,180272,400501,412006,8192,65,295285,395636,416101,56437,1365,272393,256,21793,46092,63069]

theorem envBound34691 : H12AffineFastState.Bounded env34691 := by
  intro p hp
  have h : env34691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34690_34691 : H12AffineEnvironment.transform 6 8 env34690 = env34691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34690 == env34691) = true)

theorem identity34691 : scanCanonicalize (H12AffineFastState.compose env34691 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound34691 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env34692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,16449,262144,1024,32769,4161,32881,285748,264487,8192,65,295285,280885,268580,56437,1365,272393,256,21793,46092,63069]

theorem envBound34692 : H12AffineFastState.Bounded env34692 := by
  intro p hp
  have h : env34692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34691_34692 : H12AffineEnvironment.transform 16 16449 env34691 = env34692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env34691 == env34692) = true)

theorem identity34692 : scanCanonicalize (H12AffineFastState.compose env34692 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34692 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env34693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16449,262144,1024,29789,4161,29741,285748,264487,8192,65,292137,280885,268580,10281,1365,272393,256,21793,16464,513]

theorem envBound34693 : H12AffineFastState.Bounded env34693 := by
  intro p hp
  have h : env34693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34692_34693 : H12AffineEnvironment.transform 14 29788 env34692 = env34693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34692 == env34693) = true)

theorem identity34693 : scanCanonicalize (H12AffineFastState.compose env34693 (packedSelected [2,3,5,6,10,12,15,16,20] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound34693 : packedSelected [2,3,5,6,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env34694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,16449,2421,1024,29789,4161,29741,21825,82,8192,65,31836,16448,4177,10281,1365,8572,256,21793,16464,513]

theorem envBound34694 : H12AffineFastState.Bounded env34694 := by
  intro p hp
  have h : env34694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34693_34694 : H12AffineEnvironment.transform 17 2421 env34693 = env34694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env34693 == env34694) = true)

theorem identity34694 : scanCanonicalize (H12AffineFastState.compose env34694 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound34694 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34695 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,8203,16401,2341,1024,29709,4113,29741,21777,2,8192,17,31756,16400,4097,10281,1285,8492,256,21793,16384,513]

theorem envBound34695 : H12AffineFastState.Bounded env34695 := by
  intro p hp
  have h : env34695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34694_34695 : H12AffineEnvironment.transform 5 16 env34694 = env34695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env34694 == env34695) = true)

theorem identity34695 : scanCanonicalize (H12AffineFastState.compose env34695 (packedSelected [0,2,5,6,8,9,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound34695 : packedSelected [0,2,5,6,8,9,18] rootPS < 2^1333 := by decide +kernel

def env34696 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8203,5393,2341,1024,8461,4113,8493,17,2,8192,17,10508,5392,4097,10281,1285,8492,256,33,5376,513]

theorem envBound34696 : H12AffineFastState.Bounded env34696 := by
  intro p hp
  have h : env34696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34695_34696 : H12AffineEnvironment.transform 13 5376 env34695 = env34696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env34695 == env34696) = true)

theorem identity34696 : scanCanonicalize (H12AffineFastState.compose env34696 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound34696 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34697 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8232,8203,5173,2049,1024,8233,4113,8201,17,2,8192,17,10280,5172,4097,10281,1057,8200,36,33,5156,513]

theorem envBound34697 : H12AffineFastState.Bounded env34697 := by
  intro p hp
  have h : env34697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34696_34697 : H12AffineEnvironment.transform 7 36 env34696 = env34697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env34696 == env34697) = true)

theorem identity34697 : scanCanonicalize (H12AffineFastState.compose env34697 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound34697 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env34698 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,0,35,5173,2049,1024,1,4113,33,17,2,40,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound34698 : H12AffineFastState.Bounded env34698 := by
  intro p hp
  have h : env34698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34697_34698 : H12AffineEnvironment.transform 12 40 env34697 = env34698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env34697 == env34698) = true)

def env34699 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,0,35,1029,2049,1024,1,33,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound34699 : H12AffineFastState.Bounded env34699 := by
  intro p hp
  have h : env34699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34698_34699 : H12AffineEnvironment.transform 11 48 env34698 = env34699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env34698 == env34699) = true)

theorem identity34699 : scanCanonicalize (H12AffineFastState.compose env34699 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound34699 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34700 : List Nat := [2,4,8,16,32,16,8,36,48,1024,2048,48,40,1044,0,35,1029,2049,1024,1,33,33,17,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,49]

theorem envBound34700 : H12AffineFastState.Bounded env34700 := by
  intro p hp
  have h : env34700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34699_34700 : H12AffineEnvironment.transform 8 48 env34699 = env34700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34699 == env34700) = true)

def env34701 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,40,32,0,35,49,2049,52,1,33,33,17,2,40,17,2048,48,49,2049,21,32,36,33,32,49]

theorem envBound34701 : H12AffineFastState.Bounded env34701 := by
  intro p hp
  have h : env34701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34700_34701 : H12AffineEnvironment.transform 9 52 env34700 = env34701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env34700 == env34701) = true)

def env34702 : List Nat := [2,4,8,16,32,16,8,36,48,53,2048,48,40,33,0,35,48,2049,53,1,33,33,17,2,40,17,2048,49,49,2049,20,32,36,33,33,49]

theorem envBound34702 : H12AffineFastState.Bounded env34702 := by
  intro p hp
  have h : env34702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34700_34702 : H12AffineEnvironment.transform 9 53 env34700 = env34702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34700 == env34702) = true)

theorem identity34702 : scanCanonicalize (H12AffineFastState.compose env34702 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34703 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,43,40,33,0,35,43,2049,46,1,33,33,10,2,40,10,2048,42,42,2049,15,32,36,33,33,42]

theorem envBound34703 : H12AffineFastState.Bounded env34703 := by
  intro p hp
  have h : env34703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34702_34703 : H12AffineEnvironment.transform 3 11 env34702 = env34703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34702 == env34703) = true)

def leafEnv34703 : List Nat := [2,4,8,11,32,11,8,36,43,46,2048,43,40,33,0,35,43,2049,46,1,33,33,10,2,15,40,1,10,2048,42,42,2049,15,32,36,33,4,35,33,42,1,33,0]

def active34703 : List Nat := [0,1,2,4,10]

def tree34703 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34703 : H12WitnessSearch.Good tree34703 := H12GlobalWitnessIndex.good

theorem leafIdentity34703 : H12AffineFastState.composeSystem env34703 rootObs = leafEnv34703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34703 rootObs == leafEnv34703) = true)

theorem terminalChecked34703 : H12PackedTerminal.terminalCheckFast leafEnv34703 active34703 tree34703 = true := by decide +kernel

def env34704 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,0,35,1028,2049,1024,1,32,33,17,2,40,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound34704 : H12AffineFastState.Bounded env34704 := by
  intro p hp
  have h : env34704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34698_34704 : H12AffineEnvironment.transform 11 49 env34698 = env34704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env34698 == env34704) = true)

theorem identity34704 : scanCanonicalize (H12AffineFastState.compose env34704 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound34704 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34705 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,49,40,529,0,35,512,2049,516,1,32,33,17,2,40,17,2048,513,48,2049,549,32,36,33,529,513]

theorem envBound34705 : H12AffineFastState.Bounded env34705 := by
  intro p hp
  have h : env34705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34704_34705 : H12AffineEnvironment.transform 9 516 env34704 = env34705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env34704 == env34705) = true)

def env34706 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,49,40,33,0,35,48,2049,52,1,32,33,17,2,40,17,2048,49,48,2049,21,32,36,33,33,49]

theorem envBound34706 : H12AffineFastState.Bounded env34706 := by
  intro p hp
  have h : env34706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34705_34706 : H12AffineEnvironment.transform 8 48 env34705 = env34706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env34705 == env34706) = true)

def env34707 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,40,32,0,35,49,2049,53,1,32,33,17,2,40,17,2048,48,48,2049,20,32,36,33,32,48]

theorem envBound34707 : H12AffineFastState.Bounded env34707 := by
  intro p hp
  have h : env34707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34705_34707 : H12AffineEnvironment.transform 8 49 env34705 = env34707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env34705 == env34707) = true)

theorem identity34707 : scanCanonicalize (H12AffineFastState.compose env34707 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34708 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,42,40,32,0,35,42,2049,46,1,32,33,10,2,40,10,2048,43,43,2049,15,32,36,33,32,43]

theorem envBound34708 : H12AffineFastState.Bounded env34708 := by
  intro p hp
  have h : env34708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34707_34708 : H12AffineEnvironment.transform 3 11 env34707 = env34708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34707 == env34708) = true)

def leafEnv34708 : List Nat := [2,4,8,11,32,11,8,36,42,46,2048,42,40,32,0,35,42,2049,46,1,32,33,10,2,15,40,1,10,2048,43,43,2049,15,32,36,33,4,35,32,43,1,32,0]

def active34708 : List Nat := [0,1,2,4,10]

def tree34708 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood34708 : H12WitnessSearch.Good tree34708 := H12GlobalWitnessIndex.good

theorem leafIdentity34708 : H12AffineFastState.composeSystem env34708 rootObs = leafEnv34708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env34708 rootObs == leafEnv34708) = true)

theorem terminalChecked34708 : H12PackedTerminal.terminalCheckFast leafEnv34708 active34708 tree34708 = true := by decide +kernel

def env34709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4161,180273,400500,412007,8193,65,295285,395637,416100,56436,1364,272393,256,21793,46093,63068]

theorem envBound34709 : H12AffineFastState.Bounded env34709 := by
  intro p hp
  have h : env34709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34690_34709 : H12AffineEnvironment.transform 6 9 env34690 = env34709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34690 == env34709) = true)

theorem identity34709 : scanCanonicalize (H12AffineFastState.compose env34709 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound34709 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env34710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,34,131072,262144,1024,21621,4161,136261,400500,412007,8193,65,283905,395637,416100,2048,1364,272393,256,21793,24697,8744]

theorem envBound34710 : H12AffineFastState.Bounded env34710 := by
  intro p hp
  have h : env34710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34709_34710 : H12AffineEnvironment.transform 14 21620 env34709 = env34710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env34709 == env34710) = true)

theorem identity34710 : scanCanonicalize (H12AffineFastState.compose env34710 (packedSelected [2,4,6,7,8,10,11,12,14,15,17,22,23,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound34710 : packedSelected [2,4,6,7,8,10,11,12,14,15,17,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env34711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,34,5220,262144,1024,21621,4161,33,264208,285955,8193,65,283905,269585,281856,2048,1364,272393,256,21793,24697,8744]

theorem envBound34711 : H12AffineFastState.Bounded env34711 := by
  intro p hp
  have h : env34711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34710_34711 : H12AffineEnvironment.transform 16 5220 env34710 = env34711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env34710 == env34711) = true)

theorem identity34711 : scanCanonicalize (H12AffineFastState.compose env34711 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound34711 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env34712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,34,5220,23808,1024,21621,4161,33,21776,3,8193,65,2049,16401,4096,2048,1364,29961,256,21793,24697,8744]

theorem envBound34712 : H12AffineFastState.Bounded env34712 := by
  intro p hp
  have h : env34712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34711_34712 : H12AffineEnvironment.transform 17 23808 env34711 = env34712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env34711 == env34712) = true)

theorem identity34712 : scanCanonicalize (H12AffineFastState.compose env34712 (packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound34712 : packedSelected [0,1,3,5,7,8,9,10,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env34713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,1,34,5220,2421,1024,0,4161,33,357,3,8193,65,2049,5220,4096,2048,1364,8572,256,340,13324,8744]

theorem envBound34713 : H12AffineFastState.Bounded env34713 := by
  intro p hp
  have h : env34713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34712_34713 : H12AffineEnvironment.transform 13 5237 env34712 = env34713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env34712 == env34713) = true)

theorem identity34713 : scanCanonicalize (H12AffineFastState.compose env34713 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound34713 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env34714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,1,34,5220,2421,1024,0,4161,33,357,3,40,65,2049,5220,4096,2048,1364,341,256,340,5157,513]

theorem envBound34714 : H12AffineFastState.Bounded env34714 := by
  intro p hp
  have h : env34714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34713_34714 : H12AffineEnvironment.transform 12 41 env34713 = env34714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env34713 == env34714) = true)

theorem identity34714 : scanCanonicalize (H12AffineFastState.compose env34714 (packedSelected [2,3,5,6,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound34714 : packedSelected [2,3,5,6,10,12] rootPS < 2^1333 := by decide +kernel

def env34715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2404,41,3345,1,34,3328,2421,1024,0,2341,33,357,3,40,65,2049,3328,2404,2048,1364,341,256,340,3393,513]

theorem envBound34715 : H12AffineFastState.Bounded env34715 := by
  intro p hp
  have h : env34715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34714_34715 : H12AffineEnvironment.transform 11 2404 env34714 = env34715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env34714 == env34715) = true)

theorem identity34715 : scanCanonicalize (H12AffineFastState.compose env34715 (packedSelected [1,2,5,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound34715 : packedSelected [1,2,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34716 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2064,41,3173,1,34,3188,2049,1024,0,2129,33,17,3,40,65,2049,3188,2064,2048,1056,33,116,32,3125,513]

theorem envBound34716 : H12AffineFastState.Bounded env34716 := by
  intro p hp
  have h : env34716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34715_34716 : H12AffineEnvironment.transform 7 116 env34715 = env34716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env34715 == env34716) = true)

theorem identity34716 : scanCanonicalize (H12AffineFastState.compose env34716 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34716 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env34717 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,2064,41,3124,1,34,3109,2049,1024,0,2048,33,17,3,40,16,2049,3109,2064,2048,1056,33,37,32,3125,513]

theorem envBound34717 : H12AffineFastState.Bounded env34717 := by
  intro p hp
  have h : env34717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34716_34717 : H12AffineEnvironment.transform 5 17 env34716 = env34717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34716 == env34717) = true)

theorem identity34717 : scanCanonicalize (H12AffineFastState.compose env34717 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound34717 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34718 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,2064,41,2049,1,34,2064,2049,53,0,2048,33,17,3,40,16,2049,2064,2064,2048,21,33,37,32,2048,513]

theorem envBound34718 : H12AffineFastState.Bounded env34718 := by
  intro p hp
  have h : env34718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34717_34718 : H12AffineEnvironment.transform 9 53 env34717 = env34718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env34717 == env34718) = true)

theorem identity34718 : scanCanonicalize (H12AffineFastState.compose env34718 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound34718 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34719 : List Nat := [2,4,8,16,32,17,9,37,512,53,512,528,41,513,1,34,528,513,53,0,512,33,17,3,40,16,513,528,528,512,21,33,37,32,512,513]

theorem envBound34719 : H12AffineFastState.Bounded env34719 := by
  intro p hp
  have h : env34719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34718_34719 : H12AffineEnvironment.transform 10 512 env34718 = env34719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env34718 == env34719) = true)

theorem identity34719 : scanCanonicalize (H12AffineFastState.compose env34719 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound34719 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34720 : List Nat := [2,4,3,16,32,17,2,37,512,53,512,528,34,513,1,34,528,513,53,0,512,33,17,3,35,16,513,528,528,512,21,33,37,32,512,513]

theorem envBound34720 : H12AffineFastState.Bounded env34720 := by
  intro p hp
  have h : env34720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34719_34720 : H12AffineEnvironment.transform 2 3 env34719 = env34720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env34719 == env34720) = true)

def env34721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180409,2493628,498993,8328,65,2396469,2496957,416237,2149564,2102684,2373705,256,21793,46212,2175563]

theorem envBound34721 : H12AffineFastState.Bounded env34721 := by
  intro p hp
  have h : env34721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34655_34721 : H12AffineEnvironment.transform 21 180409 env34655 = env34721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env34655 == env34721) = true)

def env34722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180409,400636,498993,8328,65,295285,395773,416237,56572,1500,272393,256,21793,46212,74251]

theorem envBound34722 : H12AffineFastState.Bounded env34722 := by
  intro p hp
  have h : env34722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34721_34722 : H12AffineEnvironment.transform 20 4160 env34721 = env34722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env34721 == env34722) = true)

theorem identity34722 : scanCanonicalize (H12AffineFastState.compose env34722 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound34722 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4160,180409,400636,441659,8328,65,295285,395773,416237,56572,1500,272393,256,21793,46212,513]

theorem envBound34723 : H12AffineFastState.Bounded env34723 := by
  intro p hp
  have h : env34723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34722_34723 : H12AffineEnvironment.transform 15 8202 env34722 = env34723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env34722 == env34723) = true)

def env34724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,32937,285932,326955,8328,65,295285,281069,268797,56572,1500,272393,256,21793,46212,513]

theorem envBound34724 : H12AffineFastState.Bounded env34724 := by
  intro p hp
  have h : env34724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34723_34724 : H12AffineEnvironment.transform 16 16400 env34723 = env34724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env34723 == env34724) = true)

def env34725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,32801,285796,326955,8192,65,295285,280933,268661,56436,1364,272393,256,21793,46092,513]

theorem envBound34725 : H12AffineFastState.Bounded env34725 := by
  intro p hp
  have h : env34725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34724_34725 : H12AffineEnvironment.transform 6 8 env34724 = env34725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34724 == env34725) = true)

def env34726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4160,32800,285797,326955,8193,65,295285,280932,268660,56437,1365,272393,256,21793,46093,513]

theorem envBound34726 : H12AffineFastState.Bounded env34726 := by
  intro p hp
  have h : env34726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34724_34726 : H12AffineEnvironment.transform 6 9 env34724 = env34726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env34724 == env34726) = true)

theorem identity34726 : scanCanonicalize (H12AffineFastState.compose env34726 (packedSelected [0,14,27] rootPS)) = affineNative (2^(17+1) ^^^ 3172) := by decide +kernel

theorem selectedBound34726 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env34727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,3172,1024,32769,4160,32800,20481,61775,8193,65,36113,17664,5392,56437,1365,9325,256,21793,46093,513]

theorem envBound34727 : H12AffineFastState.Bounded env34727 := by
  intro p hp
  have h : env34727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34726_34727 : H12AffineEnvironment.transform 17 3172 env34726 = env34727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3172 env34726 == env34727) = true)

theorem identity34727 : scanCanonicalize (H12AffineFastState.compose env34727 (packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 20497) := by decide +kernel

theorem selectedBound34727 : packedSelected [3,4,5,9,10,11,14,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env34728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,20497,8202,16400,3172,1024,20496,4160,20529,20481,8542,8193,65,23808,17664,5392,3172,1365,9325,256,21793,25628,513]

theorem envBound34728 : H12AffineFastState.Bounded env34728 := by
  intro p hp
  have h : env34728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34727_34728 : H12AffineEnvironment.transform 14 20497 env34727 = env34728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20497 env34727 == env34728) = true)

theorem identity34728 : scanCanonicalize (H12AffineFastState.compose env34728 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound34728 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env34729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,8540,8202,12637,3172,1024,8541,4160,8572,8524,8542,8193,65,11341,13389,5392,3172,1365,9325,256,9324,5457,513]

theorem envBound34729 : H12AffineFastState.Bounded env34729 := by
  intro p hp
  have h : env34729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34728_34729 : H12AffineEnvironment.transform 13 12621 env34728 = env34729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env34728 == env34729) = true)

theorem identity34729 : scanCanonicalize (H12AffineFastState.compose env34729 (packedSelected [12,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound34729 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env34730 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,12621,8540,8202,12637,2048,100,8541,4160,8572,8524,8542,8193,65,10281,12329,4468,2048,305,8201,256,8200,4405,513]

theorem envBound34730 : H12AffineFastState.Bounded env34730 := by
  intro p hp
  have h : env34730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34729_34730 : H12AffineEnvironment.transform 9 100 env34729 = env34730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env34729 == env34730) = true)

theorem identity34730 : scanCanonicalize (H12AffineFastState.compose env34730 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound34730 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env34731 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,12344,8233,8202,12328,2048,100,8232,4160,8201,8249,8235,8193,65,10281,12329,4097,2048,68,8201,117,8200,4160,513]

theorem envBound34731 : H12AffineFastState.Bounded env34731 := by
  intro p hp
  have h : env34731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34730_34731 : H12AffineEnvironment.transform 7 117 env34730 = env34731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env34730 == env34731) = true)

theorem identity34731 : scanCanonicalize (H12AffineFastState.compose env34731 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound34731 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env34732 : List Nat := [2,4,8,16,32,64,9,117,512,100,32,4096,8192,12344,8233,8202,12328,32,100,8232,4160,8201,8249,8235,8193,65,8201,12329,4097,32,68,8201,117,8200,4160,513]

theorem envBound34732 : H12AffineFastState.Bounded env34732 := by
  intro p hp
  have h : env34732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34731_34732 : H12AffineEnvironment.transform 10 32 env34731 = env34732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env34731 == env34732) = true)

theorem identity34732 : scanCanonicalize (H12AffineFastState.compose env34732 (packedSelected [0,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound34732 : packedSelected [0,6,7,8] rootPS < 2^1333 := by decide +kernel

def env34733 : List Nat := [2,4,8,16,32,64,9,117,512,100,32,586,8192,8818,8233,8202,8802,32,100,8232,522,8201,8249,8235,8193,65,8201,8803,587,32,68,8201,117,8200,522,513]

theorem envBound34733 : H12AffineFastState.Bounded env34733 := by
  intro p hp
  have h : env34733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34732_34733 : H12AffineEnvironment.transform 11 586 env34732 = env34733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env34732 == env34733) = true)

theorem identity34733 : scanCanonicalize (H12AffineFastState.compose env34733 (packedSelected [0,1,2,3,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound34733 : packedSelected [0,1,2,3,6,7,9] rootPS < 2^1333 := by decide +kernel

def env34734 : List Nat := [2,4,8,16,1,64,9,84,512,69,1,586,8192,8787,8200,8202,8771,1,69,8201,522,8201,8216,8202,8193,65,8201,8770,587,1,68,8201,84,8200,522,513]

theorem envBound34734 : H12AffineFastState.Bounded env34734 := by
  intro p hp
  have h : env34734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34733_34734 : H12AffineEnvironment.transform 4 1 env34733 = env34734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env34733 == env34734) = true)

theorem identity34734 : scanCanonicalize (H12AffineFastState.compose env34734 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound34734 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env34735 : List Nat := [2,4,8,1,1,64,9,69,512,69,1,586,8192,8770,8200,8202,8771,1,69,8201,522,8201,8201,8202,8193,65,8201,8770,587,1,68,8201,69,8200,522,513]

theorem envBound34735 : H12AffineFastState.Bounded env34735 := by
  intro p hp
  have h : env34735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34734_34735 : H12AffineEnvironment.transform 3 1 env34734 = env34735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env34734 == env34735) = true)

theorem identity34735 : scanCanonicalize (H12AffineFastState.compose env34735 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 515) := by decide +kernel

theorem selectedBound34735 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env34736 : List Nat := [2,4,8,1,1,64,9,69,512,69,1,586,515,65,523,521,64,1,69,522,522,522,522,521,514,65,522,65,587,1,68,522,69,523,522,513]

theorem envBound34736 : H12AffineFastState.Bounded env34736 := by
  intro p hp
  have h : env34736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34735_34736 : H12AffineEnvironment.transform 12 515 env34735 = env34736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 515 env34735 == env34736) = true)

theorem identity34736 : scanCanonicalize (H12AffineFastState.compose env34736 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound34736 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env34737 : List Nat := [2,4,8,1,1,10,9,15,512,15,1,512,515,11,523,521,10,1,15,522,522,522,522,521,514,11,522,11,513,1,14,522,15,523,522,513]

theorem envBound34737 : H12AffineFastState.Bounded env34737 := by
  intro p hp
  have h : env34737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34736_34737 : H12AffineEnvironment.transform 5 10 env34736 = env34737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env34736 == env34737) = true)

def env34738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4160,32936,285933,326954,8328,65,295285,281068,268796,56572,1500,272393,256,21793,46212,513]

theorem envBound34738 : H12AffineFastState.Bounded env34738 := by
  intro p hp
  have h : env34738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34723_34738 : H12AffineEnvironment.transform 16 16401 env34723 = env34738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env34723 == env34738) = true)

theorem identity34738 : scanCanonicalize (H12AffineFastState.compose env34738 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 23805) := by decide +kernel

theorem selectedBound34738 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env34739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,23805,1024,32769,4160,32936,16,41431,8328,65,56712,5393,17665,56572,1500,29940,256,21793,46212,513]

theorem envBound34739 : H12AffineFastState.Bounded env34739 := by
  intro p hp
  have h : env34739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34738_34739 : H12AffineEnvironment.transform 17 23805 env34738 = env34739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23805 env34738 == env34739) = true)

theorem identity34739 : scanCanonicalize (H12AffineFastState.compose env34739 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound34739 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env34740 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8202,16401,23805,1024,1,4160,168,16,8663,8328,65,23944,5393,17665,23804,1500,29940,256,21793,13444,513]

theorem envBound34740 : H12AffineFastState.Bounded env34740 := by
  intro p hp
  have h : env34740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34739_34740 : H12AffineEnvironment.transform 14 0 env34739 = env34740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env34739 == env34740) = true)

theorem identity34740 : scanCanonicalize (H12AffineFastState.compose env34740 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound34740 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env34741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,0,8202,13389,10401,1024,1,4160,168,16,8663,8328,65,10708,5393,12637,10400,1500,168,256,8573,13444,513]

theorem envBound34741 : H12AffineFastState.Bounded env34741 := by
  intro p hp
  have h : env34741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34740_34741 : H12AffineEnvironment.transform 13 13404 env34740 = env34741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env34740 == env34741) = true)

theorem identity34741 : scanCanonicalize (H12AffineFastState.compose env34741 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound34741 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env34742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,0,479,5528,2420,1024,1,4160,168,16,2,349,65,2049,5393,4232,2421,1500,168,256,168,5457,513]

theorem envBound34742 : H12AffineFastState.Bounded env34742 := by
  intro p hp
  have h : env34742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34741_34742 : H12AffineEnvironment.transform 12 469 env34741 = env34742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env34741 == env34742) = true)

theorem identity34742 : scanCanonicalize (H12AffineFastState.compose env34742 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound34742 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env34743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,137,469,1280,0,479,1297,2420,1024,1,201,168,16,2,349,65,2049,1432,1,2421,1500,168,256,168,1496,513]

theorem envBound34743 : H12AffineFastState.Bounded env34743 := by
  intro p hp
  have h : env34743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34742_34743 : H12AffineEnvironment.transform 11 137 env34742 = env34743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env34742 == env34743) = true)

theorem identity34743 : scanCanonicalize (H12AffineFastState.compose env34743 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 382) := by decide +kernel

theorem selectedBound34743 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env34744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,382,137,469,1280,0,479,1297,10,1024,1,201,168,16,2,349,65,383,1432,1,11,1500,168,256,168,1496,513]

theorem envBound34744 : H12AffineFastState.Bounded env34744 := by
  intro p hp
  have h : env34744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34743_34744 : H12AffineEnvironment.transform 10 382 env34743 = env34744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 382 env34743 == env34744) = true)

theorem identity34744 : scanCanonicalize (H12AffineFastState.compose env34744 (packedSelected [1,3,11,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34744 : packedSelected [1,3,11,18] rootPS < 2^1333 := by decide +kernel

def env34745 : List Nat := [2,4,8,16,32,17,128,256,512,1024,303,137,388,1280,0,398,1297,10,1024,1,152,168,16,2,268,16,302,1432,1,11,1421,168,256,168,1417,513]

theorem envBound34745 : H12AffineFastState.Bounded env34745 := by
  intro p hp
  have h : env34745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34744_34745 : H12AffineEnvironment.transform 5 17 env34744 = env34745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34744 == env34745) = true)

theorem identity34745 : scanCanonicalize (H12AffineFastState.compose env34745 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 403) := by decide +kernel

theorem selectedBound34745 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env34746 : List Nat := [2,4,8,16,32,17,128,256,512,403,303,137,388,147,0,398,130,10,403,1,152,168,16,2,268,16,302,11,1,11,30,168,256,168,26,513]

theorem envBound34746 : H12AffineFastState.Bounded env34746 := by
  intro p hp
  have h : env34746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34745_34746 : H12AffineEnvironment.transform 9 403 env34745 = env34746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 403 env34745 == env34746) = true)

theorem identity34746 : scanCanonicalize (H12AffineFastState.compose env34746 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound34746 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env34747 : List Nat := [2,4,8,16,32,17,51,256,512,288,303,58,311,32,0,317,49,10,288,1,43,27,16,2,268,16,302,11,1,11,30,27,256,27,26,513]

theorem envBound34747 : H12AffineFastState.Bounded env34747 := by
  intro p hp
  have h : env34747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34746_34747 : H12AffineEnvironment.transform 6 51 env34746 = env34747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env34746 == env34747) = true)

theorem identity34747 : scanCanonicalize (H12AffineFastState.compose env34747 (packedSelected [1,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound34747 : packedSelected [1,4,5,9] rootPS < 2^1333 := by decide +kernel

def env34748 : List Nat := [2,4,8,16,32,17,51,62,512,30,17,58,9,32,0,3,49,10,30,1,43,27,16,2,50,16,16,11,1,11,30,27,62,27,26,513]

theorem envBound34748 : H12AffineFastState.Bounded env34748 := by
  intro p hp
  have h : env34748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34747_34748 : H12AffineEnvironment.transform 7 62 env34747 = env34748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env34747 == env34748) = true)

theorem identity34748 : scanCanonicalize (H12AffineFastState.compose env34748 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound34748 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env34749 : List Nat := [2,4,8,16,0,17,19,30,512,30,17,26,9,0,0,3,17,10,30,1,11,27,16,2,18,16,16,11,1,11,30,27,30,27,26,513]

theorem envBound34749 : H12AffineFastState.Bounded env34749 := by
  intro p hp
  have h : env34749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34748_34749 : H12AffineEnvironment.transform 4 0 env34748 = env34749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env34748 == env34749) = true)

theorem identity34749 : scanCanonicalize (H12AffineFastState.compose env34749 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound34749 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env34750 : List Nat := [2,4,8,16,0,17,19,30,30,30,17,26,9,0,0,3,17,10,30,1,11,27,16,2,18,16,16,11,1,11,30,27,30,27,26,31]

theorem envBound34750 : H12AffineFastState.Bounded env34750 := by
  intro p hp
  have h : env34750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34749_34750 : H12AffineEnvironment.transform 8 30 env34749 = env34750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env34749 == env34750) = true)

theorem identity34750 : scanCanonicalize (H12AffineFastState.compose env34750 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound34750 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env34751 : List Nat := [2,4,8,11,0,10,8,5,5,5,10,1,9,0,0,3,10,10,5,1,11,0,11,2,9,11,11,11,1,11,5,0,5,0,1,4]

theorem envBound34751 : H12AffineFastState.Bounded env34751 := by
  intro p hp
  have h : env34751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34750_34751 : H12AffineEnvironment.transform 3 11 env34750 = env34751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env34750 == env34751) = true)

def env34752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180409,400637,498993,8328,65,295284,395772,416237,56573,1501,272392,256,21793,46212,74250]

theorem envBound34752 : H12AffineFastState.Bounded env34752 := by
  intro p hp
  have h : env34752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34721_34752 : H12AffineEnvironment.transform 20 4161 env34721 = env34752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env34721 == env34752) = true)

theorem identity34752 : scanCanonicalize (H12AffineFastState.compose env34752 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound34752 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env34753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180409,120015,21763,8328,65,215366,115150,102879,56573,1501,254010,256,21793,46212,74250]

theorem envBound34753 : H12AffineFastState.Bounded env34753 := by
  intro p hp
  have h : env34753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34752_34753 : H12AffineEnvironment.transform 17 247858 env34752 = env34753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env34752 == env34753) = true)

def env34754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,130174,1024,32769,4161,62709,120015,21763,8328,65,97546,115150,102879,56573,1501,119926,256,21793,46212,74250]

theorem envBound34754 : H12AffineFastState.Bounded env34754 := by
  intro p hp
  have h : env34754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34753_34754 : H12AffineEnvironment.transform 16 13388 env34753 = env34754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env34753 == env34754) = true)

theorem identity34754 : scanCanonicalize (H12AffineFastState.compose env34754 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound34754 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env34755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,13388,10401,1024,32769,4161,62709,16,21763,8328,65,43477,5393,17664,56573,1501,169,256,21793,46212,63189]

theorem envBound34755 : H12AffineFastState.Bounded env34755 := by
  intro p hp
  have h : env34755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34754_34755 : H12AffineEnvironment.transform 15 54495 env34754 = env34755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env34754 == env34755) = true)

theorem identity34755 : scanCanonicalize (H12AffineFastState.compose env34755 (packedSelected [16,17,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound34755 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env34756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,8323,13388,10401,1024,29789,4161,169,16,21763,8328,65,23945,5393,17664,10401,1501,169,256,21793,16600,649]

theorem envBound34756 : H12AffineFastState.Bounded env34756 := by
  intro p hp
  have h : env34756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34755_34756 : H12AffineEnvironment.transform 14 29788 env34755 = env34756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env34755 == env34756) = true)

theorem identity34756 : scanCanonicalize (H12AffineFastState.compose env34756 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound34756 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env34757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8661,8323,13388,10401,1024,8660,4161,169,16,138,8328,65,2048,5393,4233,10401,1501,169,256,168,5457,649]

theorem envBound34757 : H12AffineFastState.Bounded env34757 := by
  intro p hp
  have h : env34757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34756_34757 : H12AffineEnvironment.transform 13 5513 env34756 = env34757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env34756 == env34757) = true)

theorem identity34757 : scanCanonicalize (H12AffineFastState.compose env34757 (packedSelected [2,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound34757 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env34758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,13388,10281,1024,8540,4161,33,16,2,8192,65,2048,5393,4097,10281,1365,33,256,32,5457,513]

theorem envBound34758 : H12AffineFastState.Bounded env34758 := by
  intro p hp
  have h : env34758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34757_34758 : H12AffineEnvironment.transform 6 8 env34757 = env34758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env34757 == env34758) = true)

theorem identity34758 : scanCanonicalize (H12AffineFastState.compose env34758 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound34758 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env34759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,81,263,5440,2341,1024,80,4161,33,16,2,268,65,2048,5393,4097,2341,1365,33,256,32,5457,513]

theorem envBound34759 : H12AffineFastState.Bounded env34759 := by
  intro p hp
  have h : env34759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34758_34759 : H12AffineEnvironment.transform 12 268 env34758 = env34759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env34758 == env34759) = true)

theorem identity34759 : scanCanonicalize (H12AffineFastState.compose env34759 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound34759 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env34760 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5156,81,34,5221,2048,1024,80,4161,33,16,2,41,65,2048,5172,4097,2048,1136,33,37,32,5236,513]

theorem envBound34760 : H12AffineFastState.Bounded env34760 := by
  intro p hp
  have h : env34760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34759_34760 : H12AffineEnvironment.transform 7 37 env34759 = env34760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env34759 == env34760) = true)

theorem identity34760 : scanCanonicalize (H12AffineFastState.compose env34760 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound34760 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env34761 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5172,2048,1024,1,4112,33,16,2,41,16,2048,5172,4097,2048,1057,33,37,32,5157,513]

theorem envBound34761 : H12AffineFastState.Bounded env34761 := by
  intro p hp
  have h : env34761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans34760_34761 : H12AffineEnvironment.transform 5 17 env34760 = env34761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env34760 == env34761) = true)

theorem identity34761 : scanCanonicalize (H12AffineFastState.compose env34761 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound34761 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1