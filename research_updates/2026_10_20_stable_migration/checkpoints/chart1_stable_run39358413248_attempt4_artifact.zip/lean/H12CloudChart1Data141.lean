import H12CloudChart1Data140

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound35768 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35769 : List Nat := [2,4,8,1,32,33,8,256,293,4,292,293,301,0,33,295,1,0,4,32,261,0,1,35,301,32,293,32,260,33,288,0,256,1,32,292]

theorem envBound35769 : H12AffineFastState.Bounded env35769 := by
  intro p hp
  have h : env35769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35768_35769 : H12AffineEnvironment.transform 3 1 env35768 = env35769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env35768 == env35769) = true)

theorem identity35769 : scanCanonicalize (H12AffineFastState.compose env35769 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35769 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env35770 : List Nat := [2,4,8,1,32,33,8,36,1,4,0,1,9,0,33,3,1,0,4,32,33,0,1,35,9,32,1,32,32,33,4,0,36,1,32,0]

theorem envBound35770 : H12AffineFastState.Bounded env35770 := by
  intro p hp
  have h : env35770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35769_35770 : H12AffineEnvironment.transform 7 36 env35769 = env35770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35769 == env35770) = true)

theorem identity35770 : scanCanonicalize (H12AffineFastState.compose env35770 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35770 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35771 : List Nat := [2,4,8,1,0,1,8,4,1,4,0,1,9,0,1,3,1,0,4,0,1,0,1,3,9,0,1,0,0,1,4,0,4,1,0,0]

theorem envBound35771 : H12AffineFastState.Bounded env35771 := by
  intro p hp
  have h : env35771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35770_35771 : H12AffineEnvironment.transform 4 0 env35770 = env35771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35770 == env35771) = true)

def env35772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58397,180273,16,95496,8193,65,171280,5392,45404,10281,61705,144492,256,21792,46092,120407]

theorem envBound35772 : H12AffineFastState.Bounded env35772 := by
  intro p hp
  have h : env35772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35757_35772 : H12AffineEnvironment.transform 6 9 env35757 = env35772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35757 == env35772) = true)

theorem identity35772 : scanCanonicalize (H12AffineFastState.compose env35772 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound35772 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,58397,32,16,95496,8193,65,23809,5392,45404,10281,61705,62589,256,21792,46092,120407]

theorem envBound35773 : H12AffineFastState.Bounded env35773 := by
  intro p hp
  have h : env35773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35772_35773 : H12AffineEnvironment.transform 16 49169 env35772 = env35773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35772 == env35773) = true)

theorem identity35773 : scanCanonicalize (H12AffineFastState.compose env35773 (packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound35773 : packedSelected [1,4,7,8,9,16,18,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env35774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,65536,16449,10280,1024,81,25677,32,16,95496,8193,65,23809,5392,12556,10281,29017,29741,256,21792,13404,87559]

theorem envBound35774 : H12AffineFastState.Bounded env35774 := by
  intro p hp
  have h : env35774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35773_35774 : H12AffineEnvironment.transform 14 80 env35773 = env35774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env35773 == env35774) = true)

theorem identity35774 : scanCanonicalize (H12AffineFastState.compose env35774 (packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound35774 : packedSelected [1,2,3,5,6,8,9,10,11,12,14,15,16,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env35775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,30042,16449,10280,1024,81,25677,32,16,82,8193,65,23809,5392,12556,10281,29017,29741,256,21792,13404,9053]

theorem envBound35775 : H12AffineFastState.Bounded env35775 := by
  intro p hp
  have h : env35775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35774_35775 : H12AffineEnvironment.transform 15 30042 env35774 = env35775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env35774 == env35775) = true)

theorem identity35775 : scanCanonicalize (H12AffineFastState.compose env35775 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35775 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env35776 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,1,29963,16400,10280,1024,0,25628,32,16,3,8193,16,23809,5392,12556,10281,28936,29741,256,21792,13325,8972]

theorem envBound35776 : H12AffineFastState.Bounded env35776 := by
  intro p hp
  have h : env35776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35775_35776 : H12AffineEnvironment.transform 5 17 env35775 = env35776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35775 == env35776) = true)

theorem identity35776 : scanCanonicalize (H12AffineFastState.compose env35776 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 10281) := by decide +kernel

theorem selectedBound35776 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35777 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,10281,1,7458,10297,10280,1024,0,3125,32,16,3,8193,16,13608,5392,12556,10281,6433,7172,256,15625,13325,8972]

theorem envBound35777 : H12AffineFastState.Bounded env35777 := by
  intro p hp
  have h : env35777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35776_35777 : H12AffineEnvironment.transform 13 10281 env35776 = env35777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10281 env35776 == env35777) = true)

theorem identity35777 : scanCanonicalize (H12AffineFastState.compose env35777 (packedSelected [3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound35777 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35778 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,8192,10281,1,263,10297,10280,1024,0,3125,32,16,3,8193,16,10509,2357,11561,10281,1284,33,256,8492,10280,8972]

theorem envBound35778 : H12AffineFastState.Bounded env35778 := by
  intro p hp
  have h : env35778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35777_35778 : H12AffineEnvironment.transform 11 3109 env35777 = env35778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env35777 == env35778) = true)

theorem identity35778 : scanCanonicalize (H12AffineFastState.compose env35778 (packedSelected [2,3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3132) := by decide +kernel

theorem selectedBound35778 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env35779 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,3132,1045,1,263,1029,1044,1024,0,3125,32,16,3,3133,16,1329,2357,277,1045,1284,33,256,3344,1044,3888]

theorem envBound35779 : H12AffineFastState.Bounded env35779 := by
  intro p hp
  have h : env35779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35778_35779 : H12AffineEnvironment.transform 12 3132 env35778 = env35779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3132 env35778 == env35779) = true)

theorem identity35779 : scanCanonicalize (H12AffineFastState.compose env35779 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound35779 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env35780 : List Nat := [2,4,8,16,32,17,9,256,512,1024,261,1312,1337,1045,1,263,1029,1044,1024,0,1328,32,16,3,1336,16,1329,48,277,1045,1284,33,256,1045,1044,1589]

theorem envBound35780 : H12AffineFastState.Bounded env35780 := by
  intro p hp
  have h : env35780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35779_35780 : H12AffineEnvironment.transform 10 261 env35779 = env35780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env35779 == env35780) = true)

theorem identity35780 : scanCanonicalize (H12AffineFastState.compose env35780 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35780 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env35781 : List Nat := [2,4,8,16,32,17,9,256,512,52,261,276,269,33,1,263,49,32,52,0,260,32,16,3,268,16,261,48,277,33,304,33,256,33,32,513]

theorem envBound35781 : H12AffineFastState.Bounded env35781 := by
  intro p hp
  have h : env35781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35780_35781 : H12AffineEnvironment.transform 9 52 env35780 = env35781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35780 == env35781) = true)

theorem identity35781 : scanCanonicalize (H12AffineFastState.compose env35781 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound35781 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35782 : List Nat := [2,4,8,16,32,17,9,52,512,52,49,32,57,33,1,51,49,32,52,0,48,32,16,3,56,16,49,48,33,33,4,33,52,33,32,513]

theorem envBound35782 : H12AffineFastState.Bounded env35782 := by
  intro p hp
  have h : env35782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35781_35782 : H12AffineEnvironment.transform 7 52 env35781 = env35782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env35781 == env35782) = true)

theorem identity35782 : scanCanonicalize (H12AffineFastState.compose env35782 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound35782 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35783 : List Nat := [2,4,8,16,32,17,9,52,32,52,49,32,57,33,1,51,49,32,52,0,48,32,16,3,56,16,49,48,33,33,4,33,52,33,32,33]

theorem envBound35783 : H12AffineFastState.Bounded env35783 := by
  intro p hp
  have h : env35783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35782_35783 : H12AffineEnvironment.transform 8 32 env35782 = env35783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env35782 == env35783) = true)

theorem identity35783 : scanCanonicalize (H12AffineFastState.compose env35783 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound35783 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35784 : List Nat := [2,4,8,16,16,17,9,4,16,4,1,16,9,17,1,3,1,16,4,0,0,16,16,3,8,16,1,0,17,17,4,17,4,17,16,17]

theorem envBound35784 : H12AffineFastState.Bounded env35784 := by
  intro p hp
  have h : env35784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35783_35784 : H12AffineEnvironment.transform 4 16 env35783 = env35784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env35783 == env35784) = true)

def env35785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452769,95497,8328,65,4218280,458145,45524,10401,399801,4594924,256,21792,46213,474734]

theorem envBound35785 : H12AffineFastState.Bounded env35785 := by
  intro p hp
  have h : env35785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35703_35785 : H12AffineEnvironment.transform 22 452769 env35703 = env35785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env35703 == env35785) = true)

def env35786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452769,95497,8328,65,292136,458145,45524,10401,399801,144492,256,21792,46213,474734]

theorem envBound35786 : H12AffineFastState.Bounded env35786 := by
  intro p hp
  have h : env35786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35785_35786 : H12AffineEnvironment.transform 21 272512 env35785 = env35786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35785 == env35786) = true)

theorem identity35786 : scanCanonicalize (H12AffineFastState.compose env35786 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound35786 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396324,272512,400500,95497,8328,65,292136,395636,17665,10401,399801,144492,256,21792,16464,474734]

theorem envBound35787 : H12AffineFastState.Bounded env35787 := by
  intro p hp
  have h : env35787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35786_35787 : H12AffineEnvironment.transform 14 29909 env35786 = env35787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env35786 == env35787) = true)

def env35788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140420,32,144596,95497,8328,65,23944,139732,17665,10401,143641,144492,256,21792,16464,202446]

theorem envBound35788 : H12AffineFastState.Bounded env35788 := by
  intro p hp
  have h : env35788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35787_35788 : H12AffineEnvironment.transform 17 10400 env35787 = env35788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env35787 == env35788) = true)

theorem identity35788 : scanCanonicalize (H12AffineFastState.compose env35788 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound35788 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env35789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,21590,131072,10400,1024,29908,140420,32,144596,8543,8328,65,23944,139732,17665,10401,143641,144492,256,21792,16464,148120]

theorem envBound35789 : H12AffineFastState.Bounded env35789 := by
  intro p hp
  have h : env35789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35788_35789 : H12AffineEnvironment.transform 15 21590 env35788 = env35789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env35788 == env35789) = true)

theorem identity35789 : scanCanonicalize (H12AffineFastState.compose env35789 (packedSelected [3,5,8,10,16,20,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound35789 : packedSelected [3,5,8,10,16,20,28,31] rootPS < 2^1333 := by decide +kernel

def env35790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8202,131072,10400,1024,136,140420,32,144596,8543,8328,65,10708,139732,12637,10401,143641,144492,256,8572,13324,145092]

theorem envBound35790 : H12AffineFastState.Bounded env35790 := by
  intro p hp
  have h : env35790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35789_35790 : H12AffineEnvironment.transform 13 13404 env35789 = env35790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env35789 == env35790) = true)

theorem identity35790 : scanCanonicalize (H12AffineFastState.compose env35790 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound35790 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env35791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8202,13388,10400,1024,136,4296,32,152,8543,8328,65,10708,5528,12637,10401,1365,32,256,8572,13324,648]

theorem envBound35791 : H12AffineFastState.Bounded env35791 := by
  intro p hp
  have h : env35791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35790_35791 : H12AffineEnvironment.transform 16 13388 env35790 = env35791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env35790 == env35791) = true)

theorem identity35791 : scanCanonicalize (H12AffineFastState.compose env35791 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound35791 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env35792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,121,5157,137,115,5173,2265,1024,136,4296,32,152,294,241,65,2477,5528,4388,2264,1365,32,256,261,5237,648]

theorem envBound35792 : H12AffineFastState.Bounded env35792 := by
  intro p hp
  have h : env35792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35791_35792 : H12AffineEnvironment.transform 12 121 env35791 = env35792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env35791 == env35792) = true)

theorem identity35792 : scanCanonicalize (H12AffineFastState.compose env35792 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound35792 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35793 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,121,5157,137,115,5173,2265,1024,136,4296,32,152,139,241,65,2048,5173,4233,2264,1272,32,173,168,5237,648]

theorem envBound35793 : H12AffineFastState.Bounded env35793 := by
  intro p hp
  have h : env35793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35792_35793 : H12AffineEnvironment.transform 7 173 env35792 = env35793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env35792 == env35793) = true)

theorem identity35793 : scanCanonicalize (H12AffineFastState.compose env35793 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35793 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env35794 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,121,5157,0,115,5173,2128,1024,1,4161,32,17,2,120,65,2048,5173,4096,2129,1137,32,36,33,5237,513]

theorem envBound35794 : H12AffineFastState.Bounded env35794 := by
  intro p hp
  have h : env35794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35793_35794 : H12AffineEnvironment.transform 6 9 env35793 = env35794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35793 == env35794) = true)

theorem identity35794 : scanCanonicalize (H12AffineFastState.compose env35794 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound35794 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35795 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,1061,121,0,0,115,16,2128,1024,1,1124,32,17,2,120,65,2048,16,1061,2129,1137,32,36,33,80,513]

theorem envBound35795 : H12AffineFastState.Bounded env35795 := by
  intro p hp
  have h : env35795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35794_35795 : H12AffineEnvironment.transform 11 1061 env35794 = env35795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env35794 == env35795) = true)

theorem identity35795 : scanCanonicalize (H12AffineFastState.compose env35795 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound35795 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35796 : List Nat := [2,4,8,16,32,64,9,36,512,1024,1077,1061,121,0,0,115,16,1125,1024,1,1124,32,17,2,120,65,1077,16,1061,1124,1137,32,36,33,80,513]

theorem envBound35796 : H12AffineFastState.Bounded env35796 := by
  intro p hp
  have h : env35796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35795_35796 : H12AffineEnvironment.transform 10 1077 env35795 = env35796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env35795 == env35796) = true)

def env35797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140421,33,144597,95497,8328,65,23945,139733,17665,10401,143640,144492,256,21792,16464,202447]

theorem envBound35797 : H12AffineFastState.Bounded env35797 := by
  intro p hp
  have h : env35797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35787_35797 : H12AffineEnvironment.transform 17 10401 env35787 = env35797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env35787 == env35797) = true)

theorem identity35797 : scanCanonicalize (H12AffineFastState.compose env35797 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound35797 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env35798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,131072,10401,1024,29908,140421,33,144597,29911,8328,65,23945,139733,17665,10401,143640,144492,256,21792,16464,136977]

theorem envBound35798 : H12AffineFastState.Bounded env35798 := by
  intro p hp
  have h : env35798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35797_35798 : H12AffineEnvironment.transform 15 478 env35797 = env35798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env35797 == env35798) = true)

theorem identity35798 : scanCanonicalize (H12AffineFastState.compose env35798 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound35798 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env35799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,478,13389,10401,1024,29908,4296,33,152,29911,8328,65,23945,5528,17665,10401,1365,33,256,21792,16464,9052]

theorem envBound35799 : H12AffineFastState.Bounded env35799 := by
  intro p hp
  have h : env35799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35798_35799 : H12AffineEnvironment.transform 16 13389 env35798 = env35799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env35798 == env35799) = true)

theorem identity35799 : scanCanonicalize (H12AffineFastState.compose env35799 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound35799 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8540,478,13389,10401,1024,8541,4296,33,152,8542,8328,65,2048,5528,4232,10401,1365,33,256,169,5593,9052]

theorem envBound35800 : H12AffineFastState.Bounded env35800 := by
  intro p hp
  have h : env35800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35799_35800 : H12AffineEnvironment.transform 13 5513 env35799 = env35800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env35799 == env35800) = true)

theorem identity35800 : scanCanonicalize (H12AffineFastState.compose env35800 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35800 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,1,478,5392,2556,1024,0,4296,33,152,3,469,65,2048,5528,4232,2556,1365,33,256,169,5593,513]

theorem envBound35801 : H12AffineFastState.Bounded env35801 := by
  intro p hp
  have h : env35801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35800_35801 : H12AffineEnvironment.transform 12 349 env35800 = env35801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35800 == env35801) = true)

theorem identity35801 : scanCanonicalize (H12AffineFastState.compose env35801 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35801 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35802 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5373,1,170,5220,2184,1024,0,4296,33,152,3,161,65,2048,5356,4232,2184,1057,33,116,169,5293,513]

theorem envBound35802 : H12AffineFastState.Bounded env35802 := by
  intro p hp
  have h : env35802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35801_35802 : H12AffineEnvironment.transform 7 116 env35801 = env35802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35801 == env35802) = true)

theorem identity35802 : scanCanonicalize (H12AffineFastState.compose env35802 (packedSelected [0,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35802 : packedSelected [0,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env35803 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,41,5293,1,170,5172,2184,1024,0,4248,33,152,3,161,17,2048,5308,4232,2184,1057,33,36,169,5293,513]

theorem envBound35803 : H12AffineFastState.Bounded env35803 := by
  intro p hp
  have h : env35803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35802_35803 : H12AffineEnvironment.transform 5 16 env35802 = env35803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35802 == env35803) = true)

theorem identity35803 : scanCanonicalize (H12AffineFastState.compose env35803 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35803 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env35804 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,35,5172,2049,1024,0,4113,33,17,3,40,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound35804 : H12AffineFastState.Bounded env35804 := by
  intro p hp
  have h : env35804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35803_35804 : H12AffineEnvironment.transform 6 9 env35803 = env35804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35803 == env35804) = true)

def env35805 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,48,41,1044,1,35,1028,2049,1024,0,33,33,17,3,40,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound35805 : H12AffineFastState.Bounded env35805 := by
  intro p hp
  have h : env35805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35804_35805 : H12AffineEnvironment.transform 11 48 env35804 = env35805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35804 == env35805) = true)

theorem identity35805 : scanCanonicalize (H12AffineFastState.compose env35805 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35806 : List Nat := [2,4,8,16,0,16,9,4,512,1024,2048,16,9,1044,1,3,1028,2049,1024,0,1,1,17,3,8,17,2048,1029,17,2049,1025,1,4,0,1044,513]

theorem envBound35806 : H12AffineFastState.Bounded env35806 := by
  intro p hp
  have h : env35806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35805_35806 : H12AffineEnvironment.transform 4 0 env35805 = env35806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35805 == env35806) = true)

def env35807 : List Nat := [2,4,8,16,0,16,9,4,512,20,2048,16,9,0,1,3,16,2049,20,0,1,1,17,3,8,17,2048,17,17,2049,21,1,4,0,0,513]

theorem envBound35807 : H12AffineFastState.Bounded env35807 := by
  intro p hp
  have h : env35807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35806_35807 : H12AffineEnvironment.transform 9 20 env35806 = env35807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env35806 == env35807) = true)

theorem identity35807 : scanCanonicalize (H12AffineFastState.compose env35807 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound35807 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35808 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,16,9,0,1,3,16,522,20,0,1,1,17,3,8,17,523,17,17,522,21,1,4,0,0,513]

theorem envBound35808 : H12AffineFastState.Bounded env35808 := by
  intro p hp
  have h : env35808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35807_35808 : H12AffineEnvironment.transform 10 523 env35807 = env35808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env35807 == env35808) = true)

def leafEnv35808 : List Nat := [2,4,8,16,0,16,9,4,512,20,523,16,9,0,1,3,16,522,20,0,1,1,17,3,21,8,1,17,523,17,17,522,21,1,4,0,4,2,0,513,1,1,0]

def active35808 : List Nat := [0,1,2,3,8]

def tree35808 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35808 : H12WitnessSearch.Good tree35808 := H12GlobalWitnessIndex.good

theorem leafIdentity35808 : H12AffineFastState.composeSystem env35808 rootObs = leafEnv35808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35808 rootObs == leafEnv35808) = true)

theorem terminalChecked35808 : H12PackedTerminal.terminalCheckFast leafEnv35808 active35808 tree35808 = true := by decide +kernel

def env35809 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,16,9,1,1,3,17,2049,21,0,1,1,17,3,8,17,2048,16,17,2049,20,1,4,0,1,513]

theorem envBound35809 : H12AffineFastState.Bounded env35809 := by
  intro p hp
  have h : env35809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35806_35809 : H12AffineEnvironment.transform 9 21 env35806 = env35809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env35806 == env35809) = true)

theorem identity35809 : scanCanonicalize (H12AffineFastState.compose env35809 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35809 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35810 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,9,1,1,3,17,1,21,0,1,1,17,3,8,17,0,16,17,1,20,1,4,0,1,513]

theorem envBound35810 : H12AffineFastState.Bounded env35810 := by
  intro p hp
  have h : env35810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35809_35810 : H12AffineEnvironment.transform 10 0 env35809 = env35810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35809 == env35810) = true)

def leafEnv35810 : List Nat := [2,4,8,16,0,16,9,4,512,21,0,16,9,1,1,3,17,1,21,0,1,1,17,3,20,8,1,17,0,16,17,1,20,1,4,0,4,2,1,513,1,1,0]

def active35810 : List Nat := [0,1,2,3,8]

def tree35810 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35810 : H12WitnessSearch.Good tree35810 := H12GlobalWitnessIndex.good

theorem leafIdentity35810 : H12AffineFastState.composeSystem env35810 rootObs = leafEnv35810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35810 rootObs == leafEnv35810) = true)

theorem terminalChecked35810 : H12PackedTerminal.terminalCheckFast leafEnv35810 active35810 tree35810 = true := by decide +kernel

def env35811 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,49,41,1045,1,35,1029,2049,1024,0,32,33,17,3,40,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound35811 : H12AffineFastState.Bounded env35811 := by
  intro p hp
  have h : env35811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35804_35811 : H12AffineEnvironment.transform 11 49 env35804 = env35811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35804 == env35811) = true)

theorem identity35811 : scanCanonicalize (H12AffineFastState.compose env35811 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound35811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35812 : List Nat := [2,4,8,16,32,16,9,36,512,21,2048,49,41,0,1,35,16,2049,21,0,32,33,17,3,40,17,2048,17,48,2049,52,33,36,32,0,513]

theorem envBound35812 : H12AffineFastState.Bounded env35812 := by
  intro p hp
  have h : env35812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35811_35812 : H12AffineEnvironment.transform 9 21 env35811 = env35812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env35811 == env35812) = true)

def env35813 : List Nat := [2,4,8,16,0,16,9,4,512,21,2048,17,9,0,1,3,16,2049,21,0,0,1,17,3,8,17,2048,17,16,2049,20,1,4,0,0,513]

theorem envBound35813 : H12AffineFastState.Bounded env35813 := by
  intro p hp
  have h : env35813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35812_35813 : H12AffineEnvironment.transform 4 0 env35812 = env35813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35812 == env35813) = true)

theorem identity35813 : scanCanonicalize (H12AffineFastState.compose env35813 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound35813 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35814 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,9,0,1,3,16,0,21,0,0,1,17,3,8,17,1,17,16,0,20,1,4,0,0,513]

theorem envBound35814 : H12AffineFastState.Bounded env35814 := by
  intro p hp
  have h : env35814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35813_35814 : H12AffineEnvironment.transform 10 1 env35813 = env35814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env35813 == env35814) = true)

def leafEnv35814 : List Nat := [2,4,8,16,0,16,9,4,512,21,1,17,9,0,1,3,16,0,21,0,0,1,17,3,20,8,1,17,1,17,16,0,20,1,4,0,4,2,0,513,1,0,0]

def active35814 : List Nat := [0,1,2,3,8]

def tree35814 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35814 : H12WitnessSearch.Good tree35814 := H12GlobalWitnessIndex.good

theorem leafIdentity35814 : H12AffineFastState.composeSystem env35814 rootObs = leafEnv35814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35814 rootObs == leafEnv35814) = true)

theorem terminalChecked35814 : H12PackedTerminal.terminalCheckFast leafEnv35814 active35814 tree35814 = true := by decide +kernel

def env35815 : List Nat := [2,4,8,16,1,16,9,5,512,21,2048,16,8,0,1,2,16,2049,21,0,1,0,17,3,9,17,2048,17,17,2049,21,0,5,1,0,513]

theorem envBound35815 : H12AffineFastState.Bounded env35815 := by
  intro p hp
  have h : env35815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35812_35815 : H12AffineEnvironment.transform 4 1 env35812 = env35815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35812 == env35815) = true)

theorem identity35815 : scanCanonicalize (H12AffineFastState.compose env35815 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound35815 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35816 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,16,8,0,1,2,16,522,21,0,1,0,17,3,9,17,523,17,17,522,21,0,5,1,0,513]

theorem envBound35816 : H12AffineFastState.Bounded env35816 := by
  intro p hp
  have h : env35816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35815_35816 : H12AffineEnvironment.transform 10 523 env35815 = env35816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env35815 == env35816) = true)

def leafEnv35816 : List Nat := [2,4,8,16,1,16,9,5,512,21,523,16,8,0,1,2,16,522,21,0,1,0,17,3,21,9,1,17,523,17,17,522,21,0,5,1,4,3,0,513,1,1,0]

def active35816 : List Nat := [0,1,2,3,8]

def tree35816 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35816 : H12WitnessSearch.Good tree35816 := H12GlobalWitnessIndex.good

theorem leafIdentity35816 : H12AffineFastState.composeSystem env35816 rootObs = leafEnv35816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35816 rootObs == leafEnv35816) = true)

theorem terminalChecked35816 : H12PackedTerminal.terminalCheckFast leafEnv35816 active35816 tree35816 = true := by decide +kernel

def env35817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452769,95497,8328,65,292137,458145,45524,10401,399801,144493,256,21792,46213,474734]

theorem envBound35817 : H12AffineFastState.Bounded env35817 := by
  intro p hp
  have h : env35817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35785_35817 : H12AffineEnvironment.transform 21 272513 env35785 = env35817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35785 == env35817) = true)

theorem identity35817 : scanCanonicalize (H12AffineFastState.compose env35817 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound35817 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4160,144613,62661,95497,8328,65,158029,57797,45524,10401,1501,144493,256,21792,46213,74250]

theorem envBound35818 : H12AffineFastState.Bounded env35818 := by
  intro p hp
  have h : env35818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35817_35818 : H12AffineEnvironment.transform 17 138340 env35817 = env35818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env35817 == env35818) = true)

theorem identity35818 : scanCanonicalize (H12AffineFastState.compose env35818 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35818 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env35819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1024,32769,4160,144613,62661,21762,8328,65,158029,57797,45524,10401,1501,144493,256,21792,46213,513]

theorem envBound35819 : H12AffineFastState.Bounded env35819 := by
  intro p hp
  have h : env35819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35818_35819 : H12AffineEnvironment.transform 15 8203 env35818 = env35819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35818 == env35819) = true)

theorem identity35819 : scanCanonicalize (H12AffineFastState.compose env35819 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35819 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env35820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,131072,138340,1024,32769,4160,136632,54680,21762,469,65,149520,49304,37001,2556,1501,136496,256,21792,38360,513]

theorem envBound35820 : H12AffineFastState.Bounded env35820 := by
  intro p hp
  have h : env35820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35819_35820 : H12AffineEnvironment.transform 12 349 env35819 = env35820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35819 == env35820) = true)

theorem identity35820 : scanCanonicalize (H12AffineFastState.compose env35820 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound35820 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env35821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,5528,2556,1024,32769,4160,32,54680,21762,469,65,23944,49304,37001,2556,1501,168,256,21792,38360,513]

theorem envBound35821 : H12AffineFastState.Bounded env35821 := by
  intro p hp
  have h : env35821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35820_35821 : H12AffineEnvironment.transform 16 5528 env35820 = env35821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env35820 == env35821) = true)

theorem identity35821 : scanCanonicalize (H12AffineFastState.compose env35821 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound35821 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env35822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21897,342,5528,2556,1024,21896,4160,32,17,21762,469,65,23944,5393,17664,2556,1501,168,256,21792,16465,513]

theorem envBound35822 : H12AffineFastState.Bounded env35822 := by
  intro p hp
  have h : env35822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35821_35822 : H12AffineEnvironment.transform 14 21897 env35821 = env35822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env35821 == env35822) = true)

theorem identity35822 : scanCanonicalize (H12AffineFastState.compose env35822 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound35822 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35823 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,16384,21841,342,5440,2340,1024,21840,4160,32,17,21762,269,65,23888,5393,17664,2340,1285,112,256,21792,16465,513]

theorem envBound35823 : H12AffineFastState.Bounded env35823 := by
  intro p hp
  have h : env35823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35822_35823 : H12AffineEnvironment.transform 6 88 env35822 = env35823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env35822 == env35823) = true)

theorem identity35823 : scanCanonicalize (H12AffineFastState.compose env35823 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35823 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env35824 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5457,0,342,5440,2340,1024,1,4160,32,17,83,269,65,2049,5393,4177,2340,1285,112,256,113,5376,513]

theorem envBound35824 : H12AffineFastState.Bounded env35824 := by
  intro p hp
  have h : env35824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35823_35824 : H12AffineEnvironment.transform 13 5457 env35823 = env35824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env35823 == env35824) = true)

theorem identity35824 : scanCanonicalize (H12AffineFastState.compose env35824 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1636) := by decide +kernel

theorem selectedBound35824 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env35825 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1636,349,821,0,342,804,2340,1024,1,1572,32,17,83,269,65,2049,885,1589,2340,1285,112,256,113,868,513]

theorem envBound35825 : H12AffineFastState.Bounded env35825 := by
  intro p hp
  have h : env35825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35824_35825 : H12AffineEnvironment.transform 11 1636 env35824 = env35825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1636 env35824 == env35825) = true)

theorem identity35825 : scanCanonicalize (H12AffineFastState.compose env35825 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound35825 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35826 : List Nat := [2,4,8,16,32,64,88,256,512,1024,805,1636,349,821,0,342,804,513,1024,1,1572,32,17,83,269,65,804,885,1589,513,1285,112,256,113,868,513]

theorem envBound35826 : H12AffineFastState.Bounded env35826 := by
  intro p hp
  have h : env35826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35825_35826 : H12AffineEnvironment.transform 10 805 env35825 = env35826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env35825 == env35826) = true)

theorem identity35826 : scanCanonicalize (H12AffineFastState.compose env35826 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound35826 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35827 : List Nat := [2,4,8,0,32,64,72,256,512,1024,805,1636,333,805,0,326,804,513,1024,1,1572,32,1,67,269,65,804,869,1573,513,1285,96,256,97,868,513]

theorem envBound35827 : H12AffineFastState.Bounded env35827 := by
  intro p hp
  have h : env35827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35826_35827 : H12AffineEnvironment.transform 3 0 env35826 = env35827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env35826 == env35827) = true)

theorem identity35827 : scanCanonicalize (H12AffineFastState.compose env35827 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound35827 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env35828 : List Nat := [2,4,8,0,32,64,72,256,512,257,805,869,333,805,0,326,804,513,257,1,805,32,1,67,269,65,804,869,804,513,4,96,256,97,868,513]

theorem envBound35828 : H12AffineFastState.Bounded env35828 := by
  intro p hp
  have h : env35828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35827_35828 : H12AffineEnvironment.transform 9 257 env35827 = env35828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env35827 == env35828) = true)

theorem identity35828 : scanCanonicalize (H12AffineFastState.compose env35828 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35828 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env35829 : List Nat := [2,4,8,0,32,64,72,37,512,36,512,576,104,512,0,99,513,513,36,1,512,32,1,67,40,65,513,576,513,513,4,96,37,97,577,513]

theorem envBound35829 : H12AffineFastState.Bounded env35829 := by
  intro p hp
  have h : env35829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35828_35829 : H12AffineEnvironment.transform 7 37 env35828 = env35829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35828 == env35829) = true)

def env35830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,8388608,8887721,8328,65,4218281,8393985,8804725,8830976,399800,12645452,256,21793,46212,474735]

theorem envBound35830 : H12AffineFastState.Bounded env35830 := by
  intro p hp
  have h : env35830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35702_35830 : H12AffineEnvironment.transform 23 8887721 env35702 = env35830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887721 env35702 == env35830) = true)

def env35831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452768,95497,8328,65,4218281,458145,45525,10400,399800,4594924,256,21793,46212,474735]

theorem envBound35831 : H12AffineFastState.Bounded env35831 := by
  intro p hp
  have h : env35831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35830_35831 : H12AffineEnvironment.transform 22 452768 env35830 = env35831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env35830 == env35831) = true)

def env35832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452768,95497,8328,65,292137,458145,45525,10400,399800,144492,256,21793,46212,474735]

theorem envBound35832 : H12AffineFastState.Bounded env35832 := by
  intro p hp
  have h : env35832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35831_35832 : H12AffineEnvironment.transform 21 272512 env35831 = env35832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35831 == env35832) = true)

theorem identity35832 : scanCanonicalize (H12AffineFastState.compose env35832 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound35832 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201966,120014,95497,8328,65,215367,115151,45525,10400,75222,144492,256,21793,46212,513]

theorem envBound35833 : H12AffineFastState.Bounded env35833 := by
  intro p hp
  have h : env35833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35832_35833 : H12AffineEnvironment.transform 17 212078 env35832 = env35833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env35832 == env35833) = true)

def env35834 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201830,119878,95497,8192,65,215367,115015,45405,10280,75102,144492,256,21793,46092,513]

theorem envBound35834 : H12AffineFastState.Bounded env35834 := by
  intro p hp
  have h : env35834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35833_35834 : H12AffineEnvironment.transform 6 8 env35833 = env35834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35833 == env35834) = true)

theorem identity35834 : scanCanonicalize (H12AffineFastState.compose env35834 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound35834 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env35835 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,23668,1024,32769,77898,29820,119878,95497,8192,65,10589,115015,45405,10280,75102,87158,256,21793,46092,513]

theorem envBound35835 : H12AffineFastState.Bounded env35835 := by
  intro p hp
  have h : env35835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35834_35835 : H12AffineEnvironment.transform 16 90138 env35834 = env35835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env35834 == env35835) = true)

theorem identity35835 : scanCanonicalize (H12AffineFastState.compose env35835 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound35835 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35836 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54279,46109,23668,1024,32769,58445,29820,65,41230,8192,65,10589,5440,45405,10280,61785,32881,256,21793,46092,513]

theorem envBound35836 : H12AffineFastState.Bounded env35836 := by
  intro p hp
  have h : env35836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35835_35836 : H12AffineEnvironment.transform 15 54279 env35835 = env35836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env35835 == env35836) = true)

theorem identity35836 : scanCanonicalize (H12AffineFastState.compose env35836 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound35836 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env35837 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21510,13340,23668,1024,0,25676,29820,65,8463,8192,65,10589,5440,12636,10280,29016,112,256,21793,13325,513]

theorem envBound35837 : H12AffineFastState.Bounded env35837 := by
  intro p hp
  have h : env35837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35836_35837 : H12AffineEnvironment.transform 14 1 env35836 = env35837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env35836 == env35837) = true)

theorem identity35837 : scanCanonicalize (H12AffineFastState.compose env35837 (packedSelected [2,6,17] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35837 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env35838 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,1,21510,13340,23588,1024,0,25628,29740,17,8463,8192,17,10509,5392,12556,10280,28936,32,256,21793,13325,513]

theorem envBound35838 : H12AffineFastState.Bounded env35838 := by
  intro p hp
  have h : env35838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35837_35838 : H12AffineEnvironment.transform 5 16 env35837 = env35838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35837 == env35838) = true)

theorem identity35838 : scanCanonicalize (H12AffineFastState.compose env35838 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35838 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35839 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,1,21510,5393,23588,1024,0,17681,21793,17,2,269,17,2048,5392,4097,2341,20485,32,256,21793,5376,513]

theorem envBound35839 : H12AffineFastState.Bounded env35839 := by
  intro p hp
  have h : env35839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35838_35839 : H12AffineEnvironment.transform 12 269 env35838 = env35839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35838 == env35839) = true)

theorem identity35839 : scanCanonicalize (H12AffineFastState.compose env35839 (packedSelected [3,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound35839 : packedSelected [3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env35840 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3329,269,16384,1,18695,2064,16677,1024,0,17681,18464,17,2,269,17,2048,2065,3328,2341,19716,32,256,18464,2049,513]

theorem envBound35840 : H12AffineFastState.Bounded env35840 := by
  intro p hp
  have h : env35840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35839_35840 : H12AffineEnvironment.transform 11 3329 env35839 = env35840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env35839 == env35840) = true)

theorem identity35840 : scanCanonicalize (H12AffineFastState.compose env35840 (packedSelected [4,5,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 3344) := by decide +kernel

theorem selectedBound35840 : packedSelected [4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env35841 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3329,269,3344,1,1047,2064,3125,1024,0,2049,1328,17,2,269,17,2048,2065,3328,2341,20,32,256,1328,2049,513]

theorem envBound35841 : H12AffineFastState.Bounded env35841 := by
  intro p hp
  have h : env35841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35840_35841 : H12AffineEnvironment.transform 13 3344 env35840 = env35841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3344 env35840 == env35841) = true)

theorem identity35841 : scanCanonicalize (H12AffineFastState.compose env35841 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35841 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35842 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2064,269,2049,1,262,2064,2340,273,0,2049,33,17,2,269,17,2048,2065,2065,2341,20,32,256,33,2049,513]

theorem envBound35842 : H12AffineFastState.Bounded env35842 := by
  intro p hp
  have h : env35842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35841_35842 : H12AffineEnvironment.transform 9 273 env35841 = env35842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35841 == env35842) = true)

theorem identity35842 : scanCanonicalize (H12AffineFastState.compose env35842 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound35842 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35843 : List Nat := [2,4,8,16,17,16,8,256,512,273,2048,2064,269,2049,1,262,2064,2325,273,0,2049,16,17,2,269,17,2048,2065,2065,2324,20,17,256,16,2049,513]

theorem envBound35843 : H12AffineFastState.Bounded env35843 := by
  intro p hp
  have h : env35843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35842_35843 : H12AffineEnvironment.transform 4 17 env35842 = env35843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env35842 == env35843) = true)

theorem identity35843 : scanCanonicalize (H12AffineFastState.compose env35843 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 789) := by decide +kernel

theorem selectedBound35843 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35844 : List Nat := [2,4,8,16,17,16,8,256,512,273,789,773,269,788,1,262,773,512,273,0,788,16,17,2,269,17,789,772,772,513,20,17,256,16,788,513]

theorem envBound35844 : H12AffineFastState.Bounded env35844 := by
  intro p hp
  have h : env35844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35843_35844 : H12AffineEnvironment.transform 10 789 env35843 = env35844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 789 env35843 == env35844) = true)

theorem identity35844 : scanCanonicalize (H12AffineFastState.compose env35844 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35844 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35845 : List Nat := [2,4,8,16,17,16,8,256,17,273,260,276,269,261,1,262,276,17,273,0,261,16,17,2,269,17,260,277,277,16,20,17,256,16,261,16]

theorem envBound35845 : H12AffineFastState.Bounded env35845 := by
  intro p hp
  have h : env35845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35844_35845 : H12AffineEnvironment.transform 8 17 env35844 = env35845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35844 == env35845) = true)

theorem identity35845 : scanCanonicalize (H12AffineFastState.compose env35845 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound35845 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35846 : List Nat := [2,4,8,16,17,16,8,5,17,20,1,17,8,0,1,3,17,17,20,0,0,16,17,2,8,17,1,16,16,16,20,17,5,16,0,16]

theorem envBound35846 : H12AffineFastState.Bounded env35846 := by
  intro p hp
  have h : env35846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35845_35846 : H12AffineEnvironment.transform 7 5 env35845 = env35846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env35845 == env35846) = true)

theorem identity35846 : scanCanonicalize (H12AffineFastState.compose env35846 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound35846 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35847 : List Nat := [2,4,8,11,10,11,8,5,10,15,1,10,8,0,1,3,10,10,15,0,0,11,10,2,8,10,1,11,11,11,15,10,5,11,0,11]

theorem envBound35847 : H12AffineFastState.Bounded env35847 := by
  intro p hp
  have h : env35847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35846_35847 : H12AffineEnvironment.transform 3 11 env35846 = env35847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env35846 == env35847) = true)

def env35848 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77898,201831,119879,95497,8193,65,215367,115014,45404,10281,75103,144492,256,21793,46093,513]

theorem envBound35848 : H12AffineFastState.Bounded env35848 := by
  intro p hp
  have h : env35848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35833_35848 : H12AffineEnvironment.transform 6 9 env35833 = env35848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35833 == env35848) = true)

theorem identity35848 : scanCanonicalize (H12AffineFastState.compose env35848 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound35848 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env35849 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10280,1024,32769,77898,33,119879,95497,8193,65,23809,115014,45404,10281,75103,73770,256,21793,46093,513]

theorem envBound35849 : H12AffineFastState.Bounded env35849 := by
  intro p hp
  have h : env35849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35848_35849 : H12AffineEnvironment.transform 16 70726 env35848 = env35849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env35848 == env35849) = true)

theorem identity35849 : scanCanonicalize (H12AffineFastState.compose env35849 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound35849 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env35850 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62731,57677,10280,1024,32769,50497,33,8524,32770,8193,65,23809,13389,45404,10281,53332,54561,256,21793,46093,513]

theorem envBound35850 : H12AffineFastState.Bounded env35850 := by
  intro p hp
  have h : env35850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35849_35850 : H12AffineEnvironment.transform 15 62731 env35849 = env35850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env35849 == env35850) = true)

theorem identity35850 : scanCanonicalize (H12AffineFastState.compose env35850 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35850 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env35851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,54278,49216,2341,1024,32769,50497,33,65,32770,268,65,23809,5440,36945,2340,53332,54561,256,21793,38144,513]

theorem envBound35851 : H12AffineFastState.Bounded env35851 := by
  intro p hp
  have h : env35851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35850_35851 : H12AffineEnvironment.transform 12 269 env35850 = env35851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35850 == env35851) = true)

theorem identity35851 : scanCanonicalize (H12AffineFastState.compose env35851 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35851 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env35852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,32768,33031,38209,2341,1024,32769,36928,33,65,32770,268,65,2048,5440,36945,2340,34133,32800,256,32,38144,513]

theorem envBound35852 : H12AffineFastState.Bounded env35852 := by
  intro p hp
  have h : env35852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35851_35852 : H12AffineEnvironment.transform 13 5377 env35851 = env35852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35851 == env35852) = true)

def env35853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452768,95497,8328,65,292136,458145,45525,10400,399800,144493,256,21793,46212,474735]

theorem envBound35853 : H12AffineFastState.Bounded env35853 := by
  intro p hp
  have h : env35853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35831_35853 : H12AffineEnvironment.transform 21 272513 env35831 = env35853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35831 == env35853) = true)

theorem identity35853 : scanCanonicalize (H12AffineFastState.compose env35853 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound35853 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,396324,272513,452768,41431,8328,65,292136,458145,45525,10400,399800,144493,256,21793,46212,453297]

theorem envBound35854 : H12AffineFastState.Bounded env35854 := by
  intro p hp
  have h : env35854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35853_35854 : H12AffineEnvironment.transform 15 54494 env35853 = env35854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env35853 == env35854) = true)

def env35855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,396324,272393,452648,41311,8192,65,292136,458025,45405,10280,399664,144493,256,21793,46092,453177]

theorem envBound35855 : H12AffineFastState.Bounded env35855 := by
  intro p hp
  have h : env35855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35854_35855 : H12AffineEnvironment.transform 6 8 env35854 = env35855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35854 == env35855) = true)

theorem identity35855 : scanCanonicalize (H12AffineFastState.compose env35855 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound35855 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env35856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,54358,131072,262144,1024,32769,396324,264304,444497,33062,121,65,283985,449872,37156,2129,399664,136212,256,21793,38005,444992]

theorem envBound35856 : H12AffineFastState.Bounded env35856 := by
  intro p hp
  have h : env35856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35855_35856 : H12AffineEnvironment.transform 12 121 env35855 = env35856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env35855 == env35856) = true)

theorem identity35856 : scanCanonicalize (H12AffineFastState.compose env35856 (packedSelected [1,3,7,10,14,16,18,19,23,24,26,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 182288) := by decide +kernel

theorem selectedBound35856 : packedSelected [1,3,7,10,14,16,18,19,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env35857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,54358,131072,182288,1024,32769,50228,180320,65,33062,121,65,171329,5440,37156,2129,53536,136212,256,21793,38005,592]

theorem envBound35857 : H12AffineFastState.Bounded env35857 := by
  intro p hp
  have h : env35857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35856_35857 : H12AffineEnvironment.transform 17 182288 env35856 = env35857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182288 env35856 == env35857) = true)

theorem identity35857 : scanCanonicalize (H12AffineFastState.compose env35857 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound35857 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env35858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,32768,54358,5393,56577,1024,32769,50228,54641,65,33062,121,65,34896,5440,37156,2129,53536,261,256,21793,38005,592]

theorem envBound35858 : H12AffineFastState.Bounded env35858 := by
  intro p hp
  have h : env35858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35857_35858 : H12AffineEnvironment.transform 16 5393 env35857 = env35858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env35857 == env35858) = true)

theorem identity35858 : scanCanonicalize (H12AffineFastState.compose env35858 (packedSelected [2,6,9,11,14,17,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound35858 : packedSelected [2,6,9,11,14,17,18,22] rootPS < 2^1333 := by decide +kernel

def env35859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21840,262,5393,2129,1024,21841,4452,33,65,21622,121,65,23808,5440,17524,2129,1136,261,256,21793,16677,592]

theorem envBound35859 : H12AffineFastState.Bounded env35859 := by
  intro p hp
  have h : env35859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35858_35859 : H12AffineEnvironment.transform 14 21840 env35858 = env35859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env35858 == env35859) = true)

theorem identity35859 : scanCanonicalize (H12AffineFastState.compose env35859 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound35859 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,5157,373,262,5393,2129,1024,372,4452,33,65,83,121,65,2341,5440,4177,2129,1136,261,256,260,5376,592]

theorem envBound35860 : H12AffineFastState.Bounded env35860 := by
  intro p hp
  have h : env35860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35859_35860 : H12AffineEnvironment.transform 13 5157 env35859 = env35860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env35859 == env35860) = true)

theorem identity35860 : scanCanonicalize (H12AffineFastState.compose env35860 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35860 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env35861 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,121,5157,80,35,5172,2129,1024,81,4161,33,65,83,121,65,2048,5221,4177,2129,1136,32,37,33,5157,592]

theorem envBound35861 : H12AffineFastState.Bounded env35861 := by
  intro p hp
  have h : env35861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35860_35861 : H12AffineEnvironment.transform 7 37 env35860 = env35861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35860 == env35861) = true)

def env35862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,396324,272392,452649,41310,8193,65,292136,458024,45404,10281,399665,144493,256,21793,46093,453176]

theorem envBound35862 : H12AffineFastState.Bounded env35862 := by
  intro p hp
  have h : env35862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35854_35862 : H12AffineEnvironment.transform 6 9 env35854 = env35862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35854 == env35862) = true)

theorem identity35862 : scanCanonicalize (H12AffineFastState.compose env35862 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 157801) := by decide +kernel

theorem selectedBound35862 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env35863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,157801,1024,32769,25677,147553,32832,41310,8193,65,138561,38209,45404,10281,29016,144493,256,21793,46093,33361]

theorem envBound35863 : H12AffineFastState.Bounded env35863 := by
  intro p hp
  have h : env35863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35862_35863 : H12AffineEnvironment.transform 17 157801 env35862 = env35863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157801 env35862 == env35863) = true)

theorem identity35863 : scanCanonicalize (H12AffineFastState.compose env35863 (packedSelected [3,7,8,12,14,15,17,20,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound35863 : packedSelected [3,7,8,12,14,15,17,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env35864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,21511,131072,157801,1024,81,25677,147553,16,8462,8193,65,138561,5393,12556,10281,29016,144493,256,21793,13405,513]

theorem envBound35864 : H12AffineFastState.Bounded env35864 := by
  intro p hp
  have h : env35864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35863_35864 : H12AffineEnvironment.transform 14 80 env35863 = env35864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env35863 == env35864) = true)

theorem identity35864 : scanCanonicalize (H12AffineFastState.compose env35864 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound35864 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,80,21511,16449,10280,1024,81,25677,32,16,8462,8193,65,23808,5393,12556,10281,29016,29740,256,21793,13405,513]

theorem envBound35865 : H12AffineFastState.Bounded env35865 := by
  intro p hp
  have h : env35865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35864_35865 : H12AffineEnvironment.transform 16 16449 env35864 = env35865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env35864 == env35865) = true)

theorem identity35865 : scanCanonicalize (H12AffineFastState.compose env35865 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35865 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env35866 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,80,262,5440,10280,1024,81,12620,32,16,8462,8193,65,2049,5393,12556,10281,9305,8493,256,32,13405,513]

theorem envBound35866 : H12AffineFastState.Bounded env35866 := by
  intro p hp
  have h : env35866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35865_35866 : H12AffineEnvironment.transform 13 5377 env35865 = env35866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35865 == env35866) = true)

theorem identity35866 : scanCanonicalize (H12AffineFastState.compose env35866 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound35866 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35867 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,80,262,5440,2421,1024,81,4113,32,16,83,348,65,2049,5393,4177,2420,1284,112,256,32,5376,513]

theorem envBound35867 : H12AffineFastState.Bounded env35867 := by
  intro p hp
  have h : env35867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35866_35867 : H12AffineEnvironment.transform 12 349 env35866 = env35867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env35866 == env35867) = true)

theorem identity35867 : scanCanonicalize (H12AffineFastState.compose env35867 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound35867 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env35868 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,349,2048,80,262,2113,2421,1024,81,3344,32,16,83,348,65,2049,2064,3408,2420,1284,112,256,32,2049,513]

theorem envBound35868 : H12AffineFastState.Bounded env35868 := by
  intro p hp
  have h : env35868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35867_35868 : H12AffineEnvironment.transform 11 3329 env35867 = env35868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env35867 == env35868) = true)

theorem identity35868 : scanCanonicalize (H12AffineFastState.compose env35868 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35868 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env35869 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,269,2048,0,262,2065,2341,1024,1,3344,32,16,3,268,17,2049,2064,3328,2340,1284,32,256,32,2049,513]

theorem envBound35869 : H12AffineFastState.Bounded env35869 := by
  intro p hp
  have h : env35869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35868_35869 : H12AffineEnvironment.transform 5 16 env35868 = env35869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35868 == env35869) = true)

theorem identity35869 : scanCanonicalize (H12AffineFastState.compose env35869 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound35869 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35870 : List Nat := [2,4,8,16,32,16,9,256,512,1024,0,1281,269,0,0,262,17,293,1024,1,1296,32,16,3,268,17,1,16,1280,292,1284,32,256,32,1,513]

theorem envBound35870 : H12AffineFastState.Bounded env35870 := by
  intro p hp
  have h : env35870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35869_35870 : H12AffineEnvironment.transform 10 0 env35869 = env35870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env35869 == env35870) = true)

theorem identity35870 : scanCanonicalize (H12AffineFastState.compose env35870 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound35870 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35871 : List Nat := [2,4,8,16,32,16,9,256,512,52,0,309,269,0,0,262,17,293,52,1,292,32,16,3,268,17,1,16,308,292,304,32,256,32,1,513]

theorem envBound35871 : H12AffineFastState.Bounded env35871 := by
  intro p hp
  have h : env35871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35870_35871 : H12AffineEnvironment.transform 9 52 env35870 = env35871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35870 == env35871) = true)

theorem identity35871 : scanCanonicalize (H12AffineFastState.compose env35871 (packedSelected [0,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35871 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env35872 : List Nat := [2,4,8,16,32,16,9,37,512,52,0,16,40,0,0,35,17,0,52,1,1,32,16,3,41,17,1,16,17,1,21,32,37,32,1,513]

theorem envBound35872 : H12AffineFastState.Bounded env35872 := by
  intro p hp
  have h : env35872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35871_35872 : H12AffineEnvironment.transform 7 37 env35871 = env35872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35871 == env35872) = true)

def env35873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,4194304,452769,95496,8328,65,4218281,458144,45524,10401,399800,4594925,256,21793,46212,474735]

theorem envBound35873 : H12AffineFastState.Bounded env35873 := by
  intro p hp
  have h : env35873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35830_35873 : H12AffineEnvironment.transform 22 452769 env35830 = env35873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env35830 == env35873) = true)

def env35874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272512,452769,95496,8328,65,292137,458144,45524,10401,399800,144493,256,21793,46212,474735]

theorem envBound35874 : H12AffineFastState.Bounded env35874 := by
  intro p hp
  have h : env35874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35873_35874 : H12AffineEnvironment.transform 21 272512 env35873 = env35874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env35873 == env35874) = true)

theorem identity35874 : scanCanonicalize (H12AffineFastState.compose env35874 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247994) := by decide +kernel

theorem selectedBound35874 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247994,1024,32769,115870,254010,73755,95496,8328,65,245139,79130,45524,10401,119042,144493,256,21793,46212,63189]

theorem envBound35875 : H12AffineFastState.Bounded env35875 := by
  intro p hp
  have h : env35875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35874_35875 : H12AffineEnvironment.transform 17 247994 env35874 = env35875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247994 env35874 == env35875) = true)

def env35876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,67754,1024,32769,115870,73770,73755,95496,8328,65,97667,79130,45524,10401,119042,62589,256,21793,46212,63189]

theorem envBound35876 : H12AffineFastState.Bounded env35876 := by
  intro p hp
  have h : env35876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35875_35876 : H12AffineEnvironment.transform 16 49168 env35875 = env35876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env35875 == env35876) = true)

theorem identity35876 : scanCanonicalize (H12AffineFastState.compose env35876 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound35876 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env35877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,5393,67754,1024,21760,70047,73770,73755,95496,8328,65,97667,79130,25813,10401,66563,8572,256,21793,24965,9172]

theorem envBound35877 : H12AffineFastState.Bounded env35877 := by
  intro p hp
  have h : env35877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35876_35877 : H12AffineEnvironment.transform 14 21761 env35876 = env35877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env35876 == env35877) = true)

theorem identity35877 : scanCanonicalize (H12AffineFastState.compose env35877 (packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35877 : packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env35878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21761,65536,5393,67754,1024,21760,70047,65910,65863,87124,468,65,89311,70726,17801,2557,66563,32,256,21793,16601,648]

theorem envBound35878 : H12AffineFastState.Bounded env35878 := by
  intro p hp
  have h : env35878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35877_35878 : H12AffineEnvironment.transform 12 348 env35877 = env35878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35877 == env35878) = true)

theorem identity35878 : scanCanonicalize (H12AffineFastState.compose env35878 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35878 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35879 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,5393,67619,1024,21760,69910,65910,65863,87124,349,65,89174,70726,17664,2420,66563,32,256,21793,16464,513]

theorem envBound35879 : H12AffineFastState.Bounded env35879 := by
  intro p hp
  have h : env35879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35878_35879 : H12AffineEnvironment.transform 6 9 env35878 = env35879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35878 == env35879) = true)

def env35880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,67755,1024,32769,115870,73771,73755,95496,8328,65,97666,79130,45524,10401,119042,62588,256,21793,46212,63189]

theorem envBound35880 : H12AffineFastState.Bounded env35880 := by
  intro p hp
  have h : env35880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35875_35880 : H12AffineEnvironment.transform 16 49169 env35875 = env35880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env35875 == env35880) = true)

theorem identity35880 : scanCanonicalize (H12AffineFastState.compose env35880 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound35880 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env35881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25028,67755,1024,8660,91467,73771,73755,95496,8328,65,97666,79130,4097,10401,94423,21929,256,21793,5457,22272]

theorem envBound35881 : H12AffineFastState.Bounded env35881 := by
  intro p hp
  have h : env35881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35880_35881 : H12AffineEnvironment.transform 14 8661 env35880 = env35881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env35880 == env35881) = true)

theorem identity35881 : scanCanonicalize (H12AffineFastState.compose env35881 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound35881 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8323,25028,10280,1024,8660,17864,168,152,21899,8328,65,23809,5529,4097,10401,20564,21929,256,21793,5457,22272]

theorem envBound35882 : H12AffineFastState.Bounded env35882 := by
  intro p hp
  have h : env35882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35881_35882 : H12AffineEnvironment.transform 15 8323 env35881 = env35882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env35881 == env35882) = true)

theorem identity35882 : scanCanonicalize (H12AffineFastState.compose env35882 (packedSelected [1,8,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound35882 : packedSelected [1,8,16,19,20] rootPS < 2^1333 := by decide +kernel

def env35883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,1,343,16400,2556,1024,0,17864,168,152,21899,348,65,23809,5529,4097,2421,20564,21929,256,21793,5457,22272]

theorem envBound35883 : H12AffineFastState.Bounded env35883 := by
  intro p hp
  have h : env35883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35882_35883 : H12AffineEnvironment.transform 12 468 env35882 = env35883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env35882 == env35883) = true)

theorem identity35883 : scanCanonicalize (H12AffineFastState.compose env35883 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35883 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,1,343,5393,2556,1024,0,4297,168,152,138,348,65,2048,5529,4097,2421,1365,168,256,32,5457,513]

theorem envBound35884 : H12AffineFastState.Bounded env35884 := by
  intro p hp
  have h : env35884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35883_35884 : H12AffineEnvironment.transform 13 5377 env35883 = env35884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35883 == env35884) = true)

theorem identity35884 : scanCanonicalize (H12AffineFastState.compose env35884 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound35884 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,343,5393,2421,1024,0,4160,33,17,3,348,65,2048,5392,4097,2421,1365,33,256,32,5457,513]

theorem envBound35885 : H12AffineFastState.Bounded env35885 := by
  intro p hp
  have h : env35885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35884_35885 : H12AffineEnvironment.transform 6 9 env35884 = env35885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35884 == env35885) = true)

theorem identity35885 : scanCanonicalize (H12AffineFastState.compose env35885 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound35885 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35886 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5236,1,34,5220,2048,1024,0,4160,33,17,3,41,65,2048,5221,4097,2048,1056,33,117,32,5156,513]

theorem envBound35886 : H12AffineFastState.Bounded env35886 := by
  intro p hp
  have h : env35886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35885_35886 : H12AffineEnvironment.transform 7 117 env35885 = env35886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env35885 == env35886) = true)

theorem identity35886 : scanCanonicalize (H12AffineFastState.compose env35886 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound35886 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35887 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,34,5172,2048,1024,0,4112,33,17,3,41,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound35887 : H12AffineFastState.Bounded env35887 := by
  intro p hp
  have h : env35887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35886_35887 : H12AffineEnvironment.transform 5 16 env35886 = env35887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env35886 == env35887) = true)

def env35888 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,40,1044,1,34,1028,2048,1024,0,32,33,17,3,41,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound35888 : H12AffineFastState.Bounded env35888 := by
  intro p hp
  have h : env35888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35887_35888 : H12AffineEnvironment.transform 11 48 env35887 = env35888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env35887 == env35888) = true)

theorem identity35888 : scanCanonicalize (H12AffineFastState.compose env35888 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound35888 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35889 : List Nat := [2,4,8,16,32,16,9,37,512,1024,1541,48,40,1044,1,34,1028,1541,1024,0,32,33,17,3,41,17,1541,1029,49,1541,1056,33,37,32,1044,513]

theorem envBound35889 : H12AffineFastState.Bounded env35889 := by
  intro p hp
  have h : env35889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35888_35889 : H12AffineEnvironment.transform 10 1541 env35888 = env35889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env35888 == env35889) = true)

def env35890 : List Nat := [2,4,8,16,32,16,9,37,512,52,561,48,40,32,1,34,48,561,52,0,32,33,17,3,41,17,561,49,49,561,20,33,37,32,32,513]

theorem envBound35890 : H12AffineFastState.Bounded env35890 := by
  intro p hp
  have h : env35890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35889_35890 : H12AffineEnvironment.transform 9 52 env35889 = env35890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35889 == env35890) = true)

theorem identity35890 : scanCanonicalize (H12AffineFastState.compose env35890 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound35890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35891 : List Nat := [2,4,8,16,27,16,9,30,512,15,522,11,19,27,1,25,11,522,15,0,27,26,17,3,18,17,522,10,10,522,20,26,30,27,27,513]

theorem envBound35891 : H12AffineFastState.Bounded env35891 := by
  intro p hp
  have h : env35891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35890_35891 : H12AffineEnvironment.transform 4 27 env35890 = env35891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env35890 == env35891) = true)

def leafEnv35891 : List Nat := [2,4,8,16,27,16,9,30,512,15,522,11,19,27,1,25,11,522,15,0,27,26,17,3,20,18,1,17,522,10,10,522,20,26,30,27,4,24,27,513,1,27,0]

def active35891 : List Nat := [0,1,2,3,8]

def tree35891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35891 : H12WitnessSearch.Good tree35891 := H12GlobalWitnessIndex.good

theorem leafIdentity35891 : H12AffineFastState.composeSystem env35891 rootObs = leafEnv35891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35891 rootObs == leafEnv35891) = true)

theorem terminalChecked35891 : H12PackedTerminal.terminalCheckFast leafEnv35891 active35891 tree35891 = true := by decide +kernel

def env35892 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,48,40,33,1,34,49,560,53,0,32,33,17,3,41,17,560,48,49,560,21,33,37,32,33,513]

theorem envBound35892 : H12AffineFastState.Bounded env35892 := by
  intro p hp
  have h : env35892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35889_35892 : H12AffineEnvironment.transform 9 53 env35889 = env35892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35889 == env35892) = true)

theorem identity35892 : scanCanonicalize (H12AffineFastState.compose env35892 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound35892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35893 : List Nat := [2,4,8,16,32,16,9,37,16,53,32,48,40,33,1,34,49,32,53,0,32,33,17,3,41,17,32,48,49,32,21,33,37,32,33,17]

theorem envBound35893 : H12AffineFastState.Bounded env35893 := by
  intro p hp
  have h : env35893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35892_35893 : H12AffineEnvironment.transform 8 16 env35892 = env35893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env35892 == env35893) = true)

def leafEnv35893 : List Nat := [2,4,8,16,32,16,9,37,16,53,32,48,40,33,1,34,49,32,53,0,32,33,17,3,21,41,1,17,32,48,49,32,21,33,37,32,4,35,33,17,1,32,0]

def active35893 : List Nat := [0,1,2,3,4]

def tree35893 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35893 : H12WitnessSearch.Good tree35893 := H12GlobalWitnessIndex.good

theorem leafIdentity35893 : H12AffineFastState.composeSystem env35893 rootObs = leafEnv35893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35893 rootObs == leafEnv35893) = true)

theorem terminalChecked35893 : H12PackedTerminal.terminalCheckFast leafEnv35893 active35893 tree35893 = true := by decide +kernel

def env35894 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,1,34,1029,2048,1024,0,33,33,17,3,41,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound35894 : H12AffineFastState.Bounded env35894 := by
  intro p hp
  have h : env35894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35887_35894 : H12AffineEnvironment.transform 11 49 env35887 = env35894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env35887 == env35894) = true)

theorem identity35894 : scanCanonicalize (H12AffineFastState.compose env35894 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound35894 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35895 : List Nat := [2,4,8,16,32,16,9,37,512,1024,560,49,40,1045,1,34,1029,560,1024,0,33,33,17,3,41,17,560,1028,48,560,1056,33,37,32,1045,513]

theorem envBound35895 : H12AffineFastState.Bounded env35895 := by
  intro p hp
  have h : env35895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35894_35895 : H12AffineEnvironment.transform 10 560 env35894 = env35895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env35894 == env35895) = true)

def env35896 : List Nat := [2,4,8,16,32,16,9,37,512,52,560,49,40,33,1,34,49,560,52,0,33,33,17,3,41,17,560,48,48,560,20,33,37,32,33,513]

theorem envBound35896 : H12AffineFastState.Bounded env35896 := by
  intro p hp
  have h : env35896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35895_35896 : H12AffineEnvironment.transform 9 52 env35895 = env35896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env35895 == env35896) = true)

theorem identity35896 : scanCanonicalize (H12AffineFastState.compose env35896 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound35896 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35897 : List Nat := [2,4,8,16,26,16,9,31,512,14,522,11,18,27,1,24,11,522,14,0,27,27,17,3,19,17,522,10,10,522,20,27,31,26,27,513]

theorem envBound35897 : H12AffineFastState.Bounded env35897 := by
  intro p hp
  have h : env35897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35896_35897 : H12AffineEnvironment.transform 4 26 env35896 = env35897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env35896 == env35897) = true)

def leafEnv35897 : List Nat := [2,4,8,16,26,16,9,31,512,14,522,11,18,27,1,24,11,522,14,0,27,27,17,3,20,19,1,17,522,10,10,522,20,27,31,26,4,25,27,513,1,27,0]

def active35897 : List Nat := [0,1,2,3,8]

def tree35897 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35897 : H12WitnessSearch.Good tree35897 := H12GlobalWitnessIndex.good

theorem leafIdentity35897 : H12AffineFastState.composeSystem env35897 rootObs = leafEnv35897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35897 rootObs == leafEnv35897) = true)

theorem terminalChecked35897 : H12PackedTerminal.terminalCheckFast leafEnv35897 active35897 tree35897 = true := by decide +kernel

def env35898 : List Nat := [2,4,8,16,32,16,9,37,512,53,560,49,40,32,1,34,48,560,53,0,33,33,17,3,41,17,560,49,48,560,21,33,37,32,32,513]

theorem envBound35898 : H12AffineFastState.Bounded env35898 := by
  intro p hp
  have h : env35898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35895_35898 : H12AffineEnvironment.transform 9 53 env35895 = env35898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35895 == env35898) = true)

theorem identity35898 : scanCanonicalize (H12AffineFastState.compose env35898 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound35898 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35899 : List Nat := [2,4,8,16,32,16,9,37,17,53,33,49,40,32,1,34,48,33,53,0,33,33,17,3,41,17,33,49,48,33,21,33,37,32,32,16]

theorem envBound35899 : H12AffineFastState.Bounded env35899 := by
  intro p hp
  have h : env35899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35898_35899 : H12AffineEnvironment.transform 8 17 env35898 = env35899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env35898 == env35899) = true)

def leafEnv35899 : List Nat := [2,4,8,16,32,16,9,37,17,53,33,49,40,32,1,34,48,33,53,0,33,33,17,3,21,41,1,17,33,49,48,33,21,33,37,32,4,35,32,16,1,33,0]

def active35899 : List Nat := [0,1,2,3,4]

def tree35899 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood35899 : H12WitnessSearch.Good tree35899 := H12GlobalWitnessIndex.good

theorem leafIdentity35899 : H12AffineFastState.composeSystem env35899 rootObs = leafEnv35899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env35899 rootObs == leafEnv35899) = true)

theorem terminalChecked35899 : H12PackedTerminal.terminalCheckFast leafEnv35899 active35899 tree35899 = true := by decide +kernel

def env35900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396324,272513,452769,95496,8328,65,292136,458144,45524,10401,399800,144492,256,21793,46212,474735]

theorem envBound35900 : H12AffineFastState.Bounded env35900 := by
  intro p hp
  have h : env35900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35873_35900 : H12AffineEnvironment.transform 21 272513 env35873 = env35900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env35873 == env35900) = true)

theorem identity35900 : scanCanonicalize (H12AffineFastState.compose env35900 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35900 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396324,272513,452769,21763,8328,65,292136,458144,45524,10401,399800,144492,256,21793,46212,400996]

theorem envBound35901 : H12AffineFastState.Bounded env35901 := by
  intro p hp
  have h : env35901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35900_35901 : H12AffineEnvironment.transform 15 8203 env35900 = env35901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35900 == env35901) = true)

def env35902 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396324,272393,452649,21763,8192,65,292136,458024,45404,10281,399664,144492,256,21793,46092,400996]

theorem envBound35902 : H12AffineFastState.Bounded env35902 := by
  intro p hp
  have h : env35902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35901_35902 : H12AffineEnvironment.transform 6 8 env35901 = env35902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35901 == env35902) = true)

theorem identity35902 : scanCanonicalize (H12AffineFastState.compose env35902 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46392) := by decide +kernel

theorem selectedBound35902 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env35903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,46392,262144,1024,32769,309532,272393,285969,21763,8192,65,292136,280592,45404,10281,306184,33108,256,21793,46092,306012]

theorem envBound35903 : H12AffineFastState.Bounded env35903 := by
  intro p hp
  have h : env35903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35902_35903 : H12AffineEnvironment.transform 16 46392 env35902 = env35903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46392 env35902 == env35903) = true)

theorem identity35903 : scanCanonicalize (H12AffineFastState.compose env35903 (packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound35903 : packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS < 2^1333 := by decide +kernel

def env35904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8203,5393,262144,1024,8232,268597,272393,285969,21763,8192,65,292136,280592,4469,10281,265249,8573,256,21793,5157,265077]

theorem envBound35904 : H12AffineFastState.Bounded env35904 := by
  intro p hp
  have h : env35904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35903_35904 : H12AffineEnvironment.transform 14 8233 env35903 = env35904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env35903 == env35904) = true)

theorem identity35904 : scanCanonicalize (H12AffineFastState.compose env35904 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound35904 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env35905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,8203,5393,10280,1024,8232,12573,33,30009,21763,8192,65,23808,24632,4469,10281,9225,8573,256,21793,5157,9053]

theorem envBound35905 : H12AffineFastState.Bounded env35905 := by
  intro p hp
  have h : env35905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35904_35905 : H12AffineEnvironment.transform 17 10280 env35904 = env35905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env35904 == env35905) = true)

theorem identity35905 : scanCanonicalize (H12AffineFastState.compose env35905 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound35905 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8233,8203,5393,10280,1024,8232,12573,33,356,8542,8192,65,10589,5221,4469,10281,9225,8573,256,8572,5157,9053]

theorem envBound35906 : H12AffineFastState.Bounded env35906 := by
  intro p hp
  have h : env35906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35905_35906 : H12AffineEnvironment.transform 13 13405 env35905 = env35906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env35905 == env35906) = true)

theorem identity35906 : scanCanonicalize (H12AffineFastState.compose env35906 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound35906 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35907 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13405,8233,8203,5221,10280,1024,8232,12393,33,16,8234,8192,65,10281,5221,4097,10281,9225,8201,116,8200,5157,8745]

theorem envBound35907 : H12AffineFastState.Bounded env35907 := by
  intro p hp
  have h : env35907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35906_35907 : H12AffineEnvironment.transform 7 116 env35906 = env35907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env35906 == env35907) = true)

theorem identity35907 : scanCanonicalize (H12AffineFastState.compose env35907 (packedSelected [0,1,2,3,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 2059) := by decide +kernel

theorem selectedBound35907 : packedSelected [0,1,2,3,6,7,12] rootPS < 2^1333 := by decide +kernel

def env35908 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2059,8192,11350,8233,8203,3182,10280,1024,8232,10338,33,16,8234,8192,65,10281,3182,2058,10281,9225,8201,116,8200,3118,8745]

theorem envBound35908 : H12AffineFastState.Bounded env35908 := by
  intro p hp
  have h : env35908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35907_35908 : H12AffineEnvironment.transform 11 2059 env35907 = env35908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2059 env35907 == env35908) = true)

theorem identity35908 : scanCanonicalize (H12AffineFastState.compose env35908 (packedSelected [0,1,3,5,7,8,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound35908 : packedSelected [0,1,3,5,7,8,11,14] rootPS < 2^1333 := by decide +kernel

def env35909 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2059,1031,2129,1070,1036,3182,3119,1024,1071,3173,33,16,1069,1031,65,3118,3182,2058,3118,14,1038,116,1039,3118,1582]

theorem envBound35909 : H12AffineFastState.Bounded env35909 := by
  intro p hp
  have h : env35909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35908_35909 : H12AffineEnvironment.transform 12 1031 env35908 = env35909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env35908 == env35909) = true)

theorem identity35909 : scanCanonicalize (H12AffineFastState.compose env35909 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35909 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35910 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,2059,1031,2048,1070,1036,3135,3119,1024,1071,3124,33,16,1069,1031,16,3118,3135,2058,3118,14,1038,37,1039,3118,1582]

theorem envBound35910 : H12AffineFastState.Bounded env35910 := by
  intro p hp
  have h : env35910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35909_35910 : H12AffineEnvironment.transform 5 17 env35909 = env35910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35909 == env35910) = true)

theorem identity35910 : scanCanonicalize (H12AffineFastState.compose env35910 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1028) := by decide +kernel

theorem selectedBound35910 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env35911 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1028,1039,1031,1028,1070,1036,59,43,1024,1071,48,33,16,1069,1031,16,42,59,1038,42,14,1038,37,1039,42,1582]

theorem envBound35911 : H12AffineFastState.Bounded env35911 := by
  intro p hp
  have h : env35911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35910_35911 : H12AffineEnvironment.transform 10 1028 env35910 = env35911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1028 env35910 == env35911) = true)

theorem identity35911 : scanCanonicalize (H12AffineFastState.compose env35911 (packedSelected [1,2,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound35911 : packedSelected [1,2,5,6] rootPS < 2^1333 := by decide +kernel

def env35912 : List Nat := [2,4,8,10,32,11,8,37,512,1024,1028,1039,1031,1028,1070,1036,33,43,1024,1071,42,33,10,1069,1031,10,42,33,1038,42,14,1038,37,1039,42,1582]

theorem envBound35912 : H12AffineFastState.Bounded env35912 := by
  intro p hp
  have h : env35912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35911_35912 : H12AffineEnvironment.transform 3 10 env35911 = env35912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env35911 == env35912) = true)

theorem identity35912 : scanCanonicalize (H12AffineFastState.compose env35912 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound35912 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env35913 : List Nat := [2,4,8,10,32,11,8,37,5,1024,1028,1039,1031,1028,1070,1036,33,43,1024,1071,42,33,10,1069,1031,10,42,33,1038,42,14,1038,37,1039,42,1067]

theorem envBound35913 : H12AffineFastState.Bounded env35913 := by
  intro p hp
  have h : env35913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35912_35913 : H12AffineEnvironment.transform 8 5 env35912 = env35913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env35912 == env35913) = true)

theorem identity35913 : scanCanonicalize (H12AffineFastState.compose env35913 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound35913 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env35914 : List Nat := [2,4,3,1,32,0,3,37,5,1024,1028,1028,1031,1028,1061,1031,33,32,1024,1060,33,33,1,1062,1031,1,33,33,1029,33,5,1029,37,1028,33,1056]

theorem envBound35914 : H12AffineFastState.Bounded env35914 := by
  intro p hp
  have h : env35914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35913_35914 : H12AffineEnvironment.transform 2 3 env35913 = env35914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env35913 == env35914) = true)

theorem identity35914 : scanCanonicalize (H12AffineFastState.compose env35914 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound35914 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35915 : List Nat := [2,4,3,1,32,0,3,37,5,5,1,1,2,1,32,2,33,32,5,33,33,33,1,35,2,1,33,33,0,33,5,0,37,1,33,37]

theorem envBound35915 : H12AffineFastState.Bounded env35915 := by
  intro p hp
  have h : env35915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35914_35915 : H12AffineEnvironment.transform 9 5 env35914 = env35915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env35914 == env35915) = true)

theorem identity35915 : scanCanonicalize (H12AffineFastState.compose env35915 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound35915 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env35916 : List Nat := [2,4,3,1,1,0,3,4,5,5,1,1,2,1,1,2,0,1,5,0,0,0,1,2,2,1,0,0,0,0,5,0,4,1,0,4]

theorem envBound35916 : H12AffineFastState.Bounded env35916 := by
  intro p hp
  have h : env35916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35915_35916 : H12AffineEnvironment.transform 4 1 env35915 = env35916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env35915 == env35916) = true)

theorem identity35916 : scanCanonicalize (H12AffineFastState.compose env35916 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35917 : List Nat := [2,3,3,1,1,0,3,3,2,2,1,1,2,1,1,2,0,1,2,0,0,0,1,2,2,1,0,0,0,0,2,0,3,1,0,3]

theorem envBound35917 : H12AffineFastState.Bounded env35917 := by
  intro p hp
  have h : env35917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35916_35917 : H12AffineEnvironment.transform 1 3 env35916 = env35917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35916 == env35917) = true)

def env35918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396324,272392,452648,21763,8193,65,292136,458025,45405,10280,399665,144492,256,21793,46093,400996]

theorem envBound35918 : H12AffineFastState.Bounded env35918 := by
  intro p hp
  have h : env35918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35901_35918 : H12AffineEnvironment.transform 6 9 env35901 = env35918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35901 == env35918) = true)

theorem identity35918 : scanCanonicalize (H12AffineFastState.compose env35918 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23669) := by decide +kernel

theorem selectedBound35918 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env35919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,23669,1024,32769,151633,29821,177245,21763,8193,65,10589,172380,45405,10280,148804,144492,256,21793,46093,147985]

theorem envBound35919 : H12AffineFastState.Bounded env35919 := by
  intro p hp
  have h : env35919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35918_35919 : H12AffineEnvironment.transform 17 23669 env35918 = env35919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23669 env35918 == env35919) = true)

theorem identity35919 : scanCanonicalize (H12AffineFastState.compose env35919 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound35919 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env35920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,131072,23669,1024,21761,151633,29821,155997,21763,8193,65,10589,160860,25693,10280,148804,144492,256,21793,24845,147985]

theorem envBound35920 : H12AffineFastState.Bounded env35920 := by
  intro p hp
  have h : env35920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35919_35920 : H12AffineEnvironment.transform 14 21760 env35919 = env35920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env35919 == env35920) = true)

theorem identity35920 : scanCanonicalize (H12AffineFastState.compose env35920 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound35920 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env35921 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,24908,23669,1024,21761,12573,29821,17,21763,8193,65,10589,5392,25693,10280,9224,21792,256,21793,24845,9053]

theorem envBound35921 : H12AffineFastState.Bounded env35921 := by
  intro p hp
  have h : env35921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35920_35921 : H12AffineEnvironment.transform 16 24908 env35920 = env35921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env35920 == env35921) = true)

theorem identity35921 : scanCanonicalize (H12AffineFastState.compose env35921 (packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 4886) := by decide +kernel

theorem selectedBound35921 : packedSelected [0,2,4,5,7,8,9,11,12,14] rootPS < 2^1333 := by decide +kernel

def env35922 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,4886,16384,21760,4893,21082,23669,1024,21761,523,18283,17,21763,4887,65,6731,5392,22347,6974,5918,21792,256,21793,21019,4171]

theorem envBound35922 : H12AffineFastState.Bounded env35922 := by
  intro p hp
  have h : env35922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35921_35922 : H12AffineEnvironment.transform 12 4886 env35921 = env35922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4886 env35921 == env35922) = true)

def env35923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound35923 : H12AffineFastState.Bounded env35923 := by
  intro p hp
  have h : env35923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35700_35923 : H12AffineEnvironment.transform 18 1025 env35700 = env35923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env35700 == env35923) = true)

theorem identity35923 : scanCanonicalize (H12AffineFastState.compose env35923 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10874021) := by decide +kernel

theorem selectedBound35923 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env35924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10874021,8328,65,6433956,8677416,10507601,8830977,2386100,12880228,257,272392,313772,2445154]

theorem envBound35924 : H12AffineFastState.Bounded env35924 := by
  intro p hp
  have h : env35924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35923_35924 : H12AffineEnvironment.transform 23 10874021 env35923 = env35924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10874021 env35923 == env35924) = true)

def env35925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433956,8393984,10507601,8568105,2102684,12645452,257,21792,46212,2175562]

theorem envBound35925 : H12AffineFastState.Bounded env35925 := by
  intro p hp
  have h : env35925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35924_35925 : H12AffineEnvironment.transform 17 32040 env35924 = env35925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env35924 == env35925) = true)

def env35926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101328,98781,8328,65,6433956,2098512,17665,2272633,2102684,6349852,257,21792,46212,2175562]

theorem envBound35926 : H12AffineFastState.Bounded env35926 := by
  intro p hp
  have h : env35926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35925_35926 : H12AffineEnvironment.transform 22 2101328 env35925 = env35926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env35925 == env35926) = true)

def env35927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,16,98781,8328,65,4340964,5392,17665,179513,1500,4256860,257,21792,46212,74250]

theorem envBound35927 : H12AffineFastState.Bounded env35927 := by
  intro p hp
  have h : env35927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35926_35927 : H12AffineEnvironment.transform 20 4160 env35926 = env35927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35926 == env35927) = true)

theorem identity35927 : scanCanonicalize (H12AffineFastState.compose env35927 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98678) := by decide +kernel

theorem selectedBound35927 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98678,16,98781,8328,65,245138,5392,17665,179513,1500,95530,257,21792,46212,74250]

theorem envBound35928 : H12AffineFastState.Bounded env35928 := by
  intro p hp
  have h : env35928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35927_35928 : H12AffineEnvironment.transform 21 98678 env35927 = env35928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98678 env35927 == env35928) = true)

def env35929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98678,16,98645,8192,65,245018,5392,17665,179513,1364,95530,257,21792,46092,74250]

theorem envBound35929 : H12AffineFastState.Bounded env35929 := by
  intro p hp
  have h : env35929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35928_35929 : H12AffineEnvironment.transform 6 8 env35928 = env35929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35928 == env35929) = true)

theorem identity35929 : scanCanonicalize (H12AffineFastState.compose env35929 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound35929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4160,98678,16,98645,8192,65,245018,5392,4097,179513,1364,73770,257,32,46092,74250]

theorem envBound35930 : H12AffineFastState.Bounded env35930 := by
  intro p hp
  have h : env35930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35929_35930 : H12AffineEnvironment.transform 13 5376 env35929 = env35930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env35929 == env35930) = true)

theorem identity35930 : scanCanonicalize (H12AffineFastState.compose env35930 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound35930 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env35931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,5441,10280,1025,32769,4160,98678,16,98645,8192,65,108635,5392,4097,43128,1364,73770,257,32,46092,74250]

theorem envBound35931 : H12AffineFastState.Bounded env35931 := by
  intro p hp
  have h : env35931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35930_35931 : H12AffineEnvironment.transform 16 5441 env35930 = env35931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env35930 == env35931) = true)

theorem identity35931 : scanCanonicalize (H12AffineFastState.compose env35931 (packedSelected [4,9,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound35931 : packedSelected [4,9,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env35932 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33031,5441,10280,1025,32769,4160,113,16,82,8192,65,10588,5392,4097,43128,1364,41261,257,32,46092,41741]

theorem envBound35932 : H12AffineFastState.Bounded env35932 := by
  intro p hp
  have h : env35932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35931_35932 : H12AffineEnvironment.transform 15 33031 env35931 = env35932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env35931 == env35932) = true)

theorem identity35932 : scanCanonicalize (H12AffineFastState.compose env35932 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound35932 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env35933 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,32768,33031,5441,2340,1025,32769,4160,113,16,82,268,65,2128,5392,4097,35188,1364,32801,257,32,38144,33281]

theorem envBound35933 : H12AffineFastState.Bounded env35933 := by
  intro p hp
  have h : env35933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35932_35933 : H12AffineEnvironment.transform 12 268 env35932 = env35933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env35932 == env35933) = true)

theorem identity35933 : scanCanonicalize (H12AffineFastState.compose env35933 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35933 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35934 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5376,32768,33031,5392,2340,1025,32769,4113,32,16,3,268,16,2049,5392,4097,35109,1285,32801,257,32,38144,33281]

theorem envBound35934 : H12AffineFastState.Bounded env35934 := by
  intro p hp
  have h : env35934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35933_35934 : H12AffineEnvironment.transform 5 17 env35933 = env35934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35933 == env35934) = true)

theorem identity35934 : scanCanonicalize (H12AffineFastState.compose env35934 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1322) := by decide +kernel

theorem selectedBound35934 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env35935 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1322,268,42,32768,33031,58,2340,1025,32769,1339,32,16,3,268,16,2049,58,1323,35109,1285,32801,257,32,32810,33281]

theorem envBound35935 : H12AffineFastState.Bounded env35935 := by
  intro p hp
  have h : env35935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35934_35935 : H12AffineEnvironment.transform 11 1322 env35934 = env35935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1322 env35934 == env35935) = true)

theorem identity35935 : scanCanonicalize (H12AffineFastState.compose env35935 (packedSelected [0,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound35935 : packedSelected [0,5,8,9] rootPS < 2^1333 := by decide +kernel

def env35936 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,287,268,42,32768,33031,58,2340,52,32769,270,32,16,3,268,16,2049,58,286,35109,304,32801,257,32,32810,33281]

theorem envBound35936 : H12AffineFastState.Bounded env35936 := by
  intro p hp
  have h : env35936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35935_35936 : H12AffineEnvironment.transform 9 53 env35935 = env35936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env35935 == env35936) = true)

theorem identity35936 : scanCanonicalize (H12AffineFastState.compose env35936 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 2096) := by decide +kernel

theorem selectedBound35936 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env35937 : List Nat := [2,4,8,16,32,17,8,256,512,53,2048,287,268,42,2096,2359,58,2340,52,2097,270,32,16,3,268,16,2049,58,286,277,304,2065,257,32,2074,2609]

theorem envBound35937 : H12AffineFastState.Bounded env35937 := by
  intro p hp
  have h : env35937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35936_35937 : H12AffineEnvironment.transform 14 2096 env35936 = env35937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2096 env35936 == env35937) = true)

theorem identity35937 : scanCanonicalize (H12AffineFastState.compose env35937 (packedSelected [3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound35937 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env35938 : List Nat := [2,4,8,16,32,17,8,256,512,53,276,287,268,42,292,35,58,48,52,293,270,32,16,3,268,16,277,58,286,277,304,261,257,32,270,805]

theorem envBound35938 : H12AffineFastState.Bounded env35938 := by
  intro p hp
  have h : env35938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35937_35938 : H12AffineEnvironment.transform 10 276 env35937 = env35938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env35937 == env35938) = true)

theorem identity35938 : scanCanonicalize (H12AffineFastState.compose env35938 (packedSelected [0,1,3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound35938 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env35939 : List Nat := [2,4,8,15,32,14,8,256,512,42,267,256,268,42,292,35,37,47,43,293,270,32,15,3,268,15,266,37,257,266,303,261,257,32,270,805]

theorem envBound35939 : H12AffineFastState.Bounded env35939 := by
  intro p hp
  have h : env35939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35938_35939 : H12AffineEnvironment.transform 3 15 env35938 = env35939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env35938 == env35939) = true)

theorem identity35939 : scanCanonicalize (H12AffineFastState.compose env35939 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound35939 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env35940 : List Nat := [2,4,8,15,32,14,8,4,512,42,15,4,8,42,32,35,37,47,43,33,10,32,15,3,8,15,14,37,5,14,43,1,5,32,10,545]

theorem envBound35940 : H12AffineFastState.Bounded env35940 := by
  intro p hp
  have h : env35940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35939_35940 : H12AffineEnvironment.transform 7 4 env35939 = env35940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env35939 == env35940) = true)

theorem identity35940 : scanCanonicalize (H12AffineFastState.compose env35940 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35940 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35941 : List Nat := [2,4,8,15,0,14,8,4,512,10,15,4,8,10,0,3,5,15,11,1,10,0,15,3,8,15,14,5,5,14,11,1,5,0,10,513]

theorem envBound35941 : H12AffineFastState.Bounded env35941 := by
  intro p hp
  have h : env35941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35940_35941 : H12AffineEnvironment.transform 4 0 env35940 = env35941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35940 == env35941) = true)

theorem identity35941 : scanCanonicalize (H12AffineFastState.compose env35941 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 5) := by decide +kernel

theorem selectedBound35941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35942 : List Nat := [2,4,8,15,0,14,8,4,5,10,15,4,8,10,0,3,5,15,11,1,10,0,15,3,8,15,14,5,5,14,11,1,5,0,10,4]

theorem envBound35942 : H12AffineFastState.Bounded env35942 := by
  intro p hp
  have h : env35942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35941_35942 : H12AffineEnvironment.transform 8 5 env35941 = env35942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 5 env35941 == env35942) = true)

theorem identity35942 : scanCanonicalize (H12AffineFastState.compose env35942 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound35942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35943 : List Nat := [2,3,8,8,0,9,8,3,2,10,8,3,8,10,0,3,2,8,11,1,10,0,8,3,8,8,9,2,2,9,11,1,2,0,10,3]

theorem envBound35943 : H12AffineFastState.Bounded env35943 := by
  intro p hp
  have h : env35943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35942_35943 : H12AffineEnvironment.transform 1 3 env35942 = env35943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env35942 == env35943) = true)

def env35944 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,98678,16,98644,8193,65,245019,5392,17665,179513,1365,95530,257,21792,46093,74250]

theorem envBound35944 : H12AffineFastState.Bounded env35944 := by
  intro p hp
  have h : env35944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35928_35944 : H12AffineEnvironment.transform 6 9 env35928 = env35944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35928 == env35944) = true)

theorem identity35944 : scanCanonicalize (H12AffineFastState.compose env35944 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound35944 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,4160,95530,16,95496,8193,65,215367,5392,17665,149861,1365,95530,257,21792,16465,74250]

theorem envBound35945 : H12AffineFastState.Bounded env35945 := by
  intro p hp
  have h : env35945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35944_35945 : H12AffineEnvironment.transform 14 29788 env35944 = env35945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env35944 == env35945) = true)

theorem identity35945 : scanCanonicalize (H12AffineFastState.compose env35945 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 8235) := by decide +kernel

theorem selectedBound35945 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env35946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8235,131072,32040,1025,29789,4160,21761,16,21795,8193,65,158060,5392,17665,149861,1365,21761,257,21792,16465,545]

theorem envBound35946 : H12AffineFastState.Bounded env35946 := by
  intro p hp
  have h : env35946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35945_35946 : H12AffineEnvironment.transform 15 8235 env35945 = env35946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8235 env35945 == env35946) = true)

theorem identity35946 : scanCanonicalize (H12AffineFastState.compose env35946 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16433) := by decide +kernel

theorem selectedBound35946 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env35947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8235,16433,32040,1025,29789,4160,21761,16,21795,8193,65,10589,5392,17665,2388,1365,21761,257,21792,16465,545]

theorem envBound35947 : H12AffineFastState.Bounded env35947 := by
  intro p hp
  have h : env35947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35946_35947 : H12AffineEnvironment.transform 16 16433 env35946 = env35947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16433 env35946 == env35947) = true)

theorem identity35947 : scanCanonicalize (H12AffineFastState.compose env35947 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35947 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35948 : List Nat := [2,4,8,16,0,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,16401,32008,1025,29789,4160,21761,16,21763,8193,65,10589,5392,17665,2388,1365,21761,257,21760,16465,513]

theorem envBound35948 : H12AffineFastState.Bounded env35948 := by
  intro p hp
  have h : env35948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35947_35948 : H12AffineEnvironment.transform 4 0 env35947 = env35948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35947 == env35948) = true)

theorem identity35948 : scanCanonicalize (H12AffineFastState.compose env35948 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35948 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35949 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,8192,16384,29005,8203,16401,30745,272,29004,4160,20496,16,20498,8193,65,10589,4097,16400,2388,68,20496,257,20497,16465,513]

theorem envBound35949 : H12AffineFastState.Bounded env35949 := by
  intro p hp
  have h : env35949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35948_35949 : H12AffineEnvironment.transform 9 273 env35948 = env35949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35948 == env35949) = true)

theorem identity35949 : scanCanonicalize (H12AffineFastState.compose env35949 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound35949 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35950 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,8192,4113,8540,8203,4096,10248,272,8541,4160,1,16,3,8193,65,10589,4097,4097,2388,68,1,257,0,4160,513]

theorem envBound35950 : H12AffineFastState.Bounded env35950 := by
  intro p hp
  have h : env35950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35949_35950 : H12AffineEnvironment.transform 13 4113 env35949 = env35950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env35949 == env35950) = true)

theorem identity35950 : scanCanonicalize (H12AffineFastState.compose env35950 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4185) := by decide +kernel

theorem selectedBound35950 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35951 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,4096,4185,4113,4357,4178,4096,6225,272,4356,4160,1,16,3,4184,65,6404,4097,4097,2388,68,1,257,0,4160,513]

theorem envBound35951 : H12AffineFastState.Bounded env35951 := by
  intro p hp
  have h : env35951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35950_35951 : H12AffineEnvironment.transform 12 4185 env35950 = env35951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4185 env35950 == env35951) = true)

theorem identity35951 : scanCanonicalize (H12AffineFastState.compose env35951 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 340) := by decide +kernel

theorem selectedBound35951 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env35952 : List Nat := [2,4,8,16,0,64,9,256,512,273,2048,340,269,325,81,262,340,2309,272,80,276,1,16,3,268,65,2128,341,341,2388,68,1,257,0,276,513]

theorem envBound35952 : H12AffineFastState.Bounded env35952 := by
  intro p hp
  have h : env35952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35951_35952 : H12AffineEnvironment.transform 11 340 env35951 = env35952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 340 env35951 == env35952) = true)

theorem identity35952 : scanCanonicalize (H12AffineFastState.compose env35952 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 324) := by decide +kernel

theorem selectedBound35952 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35953 : List Nat := [2,4,8,16,0,64,9,256,324,273,2048,340,269,325,81,262,340,2309,272,80,276,1,16,3,268,65,2128,341,341,2388,68,1,257,0,276,325]

theorem envBound35953 : H12AffineFastState.Bounded env35953 := by
  intro p hp
  have h : env35953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35952_35953 : H12AffineEnvironment.transform 8 324 env35952 = env35953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 324 env35952 == env35953) = true)

theorem identity35953 : scanCanonicalize (H12AffineFastState.compose env35953 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound35953 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env35954 : List Nat := [2,4,8,16,0,64,9,256,324,273,64,340,269,325,81,262,340,325,272,80,276,1,16,3,268,65,16,341,341,276,68,1,257,0,276,325]

theorem envBound35954 : H12AffineFastState.Bounded env35954 := by
  intro p hp
  have h : env35954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35953_35954 : H12AffineEnvironment.transform 10 64 env35953 = env35954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env35953 == env35954) = true)

theorem identity35954 : scanCanonicalize (H12AffineFastState.compose env35954 (packedSelected [4,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35954 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env35955 : List Nat := [2,4,8,16,0,17,9,256,277,273,17,261,269,276,0,262,261,276,272,1,276,1,16,3,268,16,16,260,260,276,21,1,257,0,276,276]

theorem envBound35955 : H12AffineFastState.Bounded env35955 := by
  intro p hp
  have h : env35955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35954_35955 : H12AffineEnvironment.transform 5 17 env35954 = env35955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35954 == env35955) = true)

theorem identity35955 : scanCanonicalize (H12AffineFastState.compose env35955 (packedSelected [4] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound35955 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env35956 : List Nat := [2,4,8,16,0,17,9,20,1,5,17,17,25,0,0,18,17,0,4,1,0,1,16,3,24,16,16,16,16,0,21,1,21,0,0,0]

theorem envBound35956 : H12AffineFastState.Bounded env35956 := by
  intro p hp
  have h : env35956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35955_35956 : H12AffineEnvironment.transform 7 20 env35955 = env35956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env35955 == env35956) = true)

theorem identity35956 : scanCanonicalize (H12AffineFastState.compose env35956 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound35956 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35957 : List Nat := [2,4,2,16,0,17,3,20,1,5,17,17,19,0,0,18,17,0,4,1,0,1,16,3,18,16,16,16,16,0,21,1,21,0,0,0]

theorem envBound35957 : H12AffineFastState.Bounded env35957 := by
  intro p hp
  have h : env35957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35956_35957 : H12AffineEnvironment.transform 2 2 env35956 = env35957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env35956 == env35957) = true)

def env35958 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,17,98781,8328,65,4340965,5393,17665,179512,1501,4256861,257,21792,46212,74251]

theorem envBound35958 : H12AffineFastState.Bounded env35958 := by
  intro p hp
  have h : env35958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35926_35958 : H12AffineEnvironment.transform 20 4161 env35926 = env35958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35926 == env35958) = true)

theorem identity35958 : scanCanonicalize (H12AffineFastState.compose env35958 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound35958 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,32040,1025,32769,4161,4194304,17,21762,8328,65,4340965,5393,17665,179512,1501,4256861,257,21792,46212,63188]

theorem envBound35959 : H12AffineFastState.Bounded env35959 := by
  intro p hp
  have h : env35959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35958_35959 : H12AffineEnvironment.transform 15 54495 env35958 = env35959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env35958 == env35959) = true)

def env35960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32040,1025,32769,4161,4194304,17,21762,8192,65,4340845,5393,17665,179512,1365,4256861,257,21792,46092,63068]

theorem envBound35960 : H12AffineFastState.Bounded env35960 := by
  intro p hp
  have h : env35960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35959_35960 : H12AffineEnvironment.transform 6 8 env35959 = env35960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35959 == env35960) = true)

theorem identity35960 : scanCanonicalize (H12AffineFastState.compose env35960 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound35960 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env35961 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4161,4194304,17,21762,8192,65,4340845,5393,17665,149861,1365,4194304,257,21792,16465,513]

theorem envBound35961 : H12AffineFastState.Bounded env35961 := by
  intro p hp
  have h : env35961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35960_35961 : H12AffineEnvironment.transform 14 29789 env35960 = env35961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env35960 == env35961) = true)

theorem identity35961 : scanCanonicalize (H12AffineFastState.compose env35961 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147504) := by decide +kernel

theorem selectedBound35961 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env35962 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4161,147504,17,21762,8192,65,31837,5393,17665,149861,1365,147504,257,21792,16465,513]

theorem envBound35962 : H12AffineFastState.Bounded env35962 := by
  intro p hp
  have h : env35962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35961_35962 : H12AffineEnvironment.transform 21 147504 env35961 = env35962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147504 env35961 == env35962) = true)

theorem identity35962 : scanCanonicalize (H12AffineFastState.compose env35962 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound35962 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,14,18,19,23] rootPS < 2^1333 := by decide +kernel

def env35963 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,131072,10281,1025,8541,4161,136497,17,3,8192,65,10588,5393,4096,138340,1365,136497,257,33,5456,513]

theorem envBound35963 : H12AffineFastState.Bounded env35963 := by
  intro p hp
  have h : env35963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35962_35963 : H12AffineEnvironment.transform 13 5377 env35962 = env35963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env35962 == env35963) = true)

theorem identity35963 : scanCanonicalize (H12AffineFastState.compose env35963 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound35963 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35964 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8202,13388,10281,1025,8541,4161,8573,17,3,8192,65,10588,5393,4096,10280,1365,8573,257,33,5456,513]

theorem envBound35964 : H12AffineFastState.Bounded env35964 := by
  intro p hp
  have h : env35964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35963_35964 : H12AffineEnvironment.transform 16 13388 env35963 = env35964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env35963 == env35964) = true)

theorem identity35964 : scanCanonicalize (H12AffineFastState.compose env35964 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound35964 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env35965 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,8192,4112,8540,8202,12637,10281,272,8541,4161,8573,17,3,8192,65,10588,4096,4096,10280,68,8573,257,33,4161,513]

theorem envBound35965 : H12AffineFastState.Bounded env35965 := by
  intro p hp
  have h : env35965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35964_35965 : H12AffineEnvironment.transform 9 273 env35964 = env35965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env35964 == env35965) = true)

theorem identity35965 : scanCanonicalize (H12AffineFastState.compose env35965 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound35965 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env35966 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,8192,4112,8540,8202,12637,8313,272,8541,4161,8573,17,3,8192,65,8460,4096,4096,8312,68,8573,257,33,4161,513]

theorem envBound35966 : H12AffineFastState.Bounded env35966 := by
  intro p hp
  have h : env35966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35965_35966 : H12AffineEnvironment.transform 10 80 env35965 = env35966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env35965 == env35966) = true)

theorem identity35966 : scanCanonicalize (H12AffineFastState.compose env35966 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35966 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35967 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,4096,348,4112,0,342,4097,293,272,1,4161,33,17,3,348,65,80,4096,4096,292,68,33,257,33,4161,513]

theorem envBound35967 : H12AffineFastState.Bounded env35967 := by
  intro p hp
  have h : env35967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35966_35967 : H12AffineEnvironment.transform 12 348 env35966 = env35967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35966 == env35967) = true)

theorem identity35967 : scanCanonicalize (H12AffineFastState.compose env35967 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound35967 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35968 : List Nat := [2,4,8,16,32,64,8,256,512,273,80,308,348,292,0,342,309,293,272,1,373,33,17,3,348,65,80,308,308,292,68,33,257,33,373,513]

theorem envBound35968 : H12AffineFastState.Bounded env35968 := by
  intro p hp
  have h : env35968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35967_35968 : H12AffineEnvironment.transform 11 308 env35967 = env35968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env35967 == env35968) = true)

theorem identity35968 : scanCanonicalize (H12AffineFastState.compose env35968 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 383) := by decide +kernel

theorem selectedBound35968 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env35969 : List Nat := [2,4,8,16,32,64,8,256,383,273,80,308,348,292,0,342,309,293,272,1,373,33,17,3,348,65,80,308,308,292,68,33,257,33,373,382]

theorem envBound35969 : H12AffineFastState.Bounded env35969 := by
  intro p hp
  have h : env35969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35968_35969 : H12AffineEnvironment.transform 8 383 env35968 = env35969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 383 env35968 == env35969) = true)

theorem identity35969 : scanCanonicalize (H12AffineFastState.compose env35969 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound35969 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env35970 : List Nat := [2,4,8,16,32,48,8,256,271,273,32,308,300,292,0,294,309,293,272,1,261,33,17,3,300,49,32,308,308,292,52,33,257,33,261,270]

theorem envBound35970 : H12AffineFastState.Bounded env35970 := by
  intro p hp
  have h : env35970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35969_35970 : H12AffineEnvironment.transform 5 48 env35969 = env35970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env35969 == env35970) = true)

theorem identity35970 : scanCanonicalize (H12AffineFastState.compose env35970 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound35970 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env35971 : List Nat := [2,4,8,16,32,48,8,36,43,53,32,16,8,0,0,2,17,1,52,1,33,33,17,3,8,49,32,16,16,0,52,33,37,33,33,42]

theorem envBound35971 : H12AffineFastState.Bounded env35971 := by
  intro p hp
  have h : env35971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35970_35971 : H12AffineEnvironment.transform 7 36 env35970 = env35971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env35970 == env35971) = true)

theorem identity35971 : scanCanonicalize (H12AffineFastState.compose env35971 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound35971 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env35972 : List Nat := [2,4,8,16,0,16,8,4,11,21,0,16,8,0,0,2,17,1,20,1,1,1,17,3,8,17,0,16,16,0,20,1,5,1,1,10]

theorem envBound35972 : H12AffineFastState.Bounded env35972 := by
  intro p hp
  have h : env35972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35971_35972 : H12AffineEnvironment.transform 4 0 env35971 = env35972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env35971 == env35972) = true)

theorem identity35972 : scanCanonicalize (H12AffineFastState.compose env35972 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound35972 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env35973 : List Nat := [2,4,6,16,0,16,6,4,5,21,0,16,6,0,0,2,17,1,20,1,1,1,17,3,6,17,0,16,16,0,20,1,5,1,1,4]

theorem envBound35973 : H12AffineFastState.Bounded env35973 := by
  intro p hp
  have h : env35973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35972_35973 : H12AffineEnvironment.transform 2 6 env35972 = env35973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env35972 == env35973) = true)

theorem identity35973 : scanCanonicalize (H12AffineFastState.compose env35973 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound35973 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env35974 : List Nat := [2,4,6,2,0,2,6,4,5,7,0,2,6,0,0,2,3,1,6,1,1,1,3,3,6,3,0,2,2,0,6,1,5,1,1,4]

theorem envBound35974 : H12AffineFastState.Bounded env35974 := by
  intro p hp
  have h : env35974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35973_35974 : H12AffineEnvironment.transform 3 2 env35973 = env35974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env35973 == env35974) = true)

def env35975 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,4161,4194304,17,21762,8193,65,4340844,5393,17665,179512,1364,4256861,257,21792,46093,63069]

theorem envBound35975 : H12AffineFastState.Bounded env35975 := by
  intro p hp
  have h : env35975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35959_35975 : H12AffineEnvironment.transform 6 9 env35959 = env35975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35959 == env35975) = true)

theorem identity35975 : scanCanonicalize (H12AffineFastState.compose env35975 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35975 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35976 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,131072,32040,1025,8540,4161,4194304,17,21762,8193,65,4340844,5393,17665,138341,1364,4216064,257,21792,5456,22272]

theorem envBound35976 : H12AffineFastState.Bounded env35976 := by
  intro p hp
  have h : env35976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35975_35976 : H12AffineEnvironment.transform 14 8541 env35975 = env35976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35975 == env35976) = true)

theorem identity35976 : scanCanonicalize (H12AffineFastState.compose env35976 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound35976 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env35977 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,16400,32040,1025,8540,4161,4194304,17,21762,8193,65,4226172,5393,17665,23669,1364,4216064,257,21792,5456,22272]

theorem envBound35977 : H12AffineFastState.Bounded env35977 := by
  intro p hp
  have h : env35977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35976_35977 : H12AffineEnvironment.transform 16 16400 env35976 = env35977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env35976 == env35977) = true)

theorem identity35977 : scanCanonicalize (H12AffineFastState.compose env35977 (packedSelected [1,2,6,8,10,14,15,18,20] rootPS)) = affineNative (2^(21+1) ^^^ 21588) := by decide +kernel

theorem selectedBound35977 : packedSelected [1,2,6,8,10,14,15,18,20] rootPS < 2^1333 := by decide +kernel

def env35978 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,29963,16400,32040,1025,8540,4161,21588,17,21762,8193,65,10280,5393,17665,23669,1364,340,257,21792,5456,22272]

theorem envBound35978 : H12AffineFastState.Bounded env35978 := by
  intro p hp
  have h : env35978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35977_35978 : H12AffineEnvironment.transform 21 21588 env35977 = env35978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21588 env35977 == env35978) = true)

theorem identity35978 : scanCanonicalize (H12AffineFastState.compose env35978 (packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound35978 : packedSelected [1,2,3,5,6,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env35979 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,343,13388,2420,1025,8540,4161,8200,17,8542,8193,65,10280,5393,12637,10281,1364,340,257,8572,5456,9052]

theorem envBound35979 : H12AffineFastState.Bounded env35979 := by
  intro p hp
  have h : env35979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35978_35979 : H12AffineEnvironment.transform 13 13404 env35978 = env35979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env35978 == env35979) = true)

theorem identity35979 : scanCanonicalize (H12AffineFastState.compose env35979 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound35979 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env35980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5392,2420,1025,0,4161,340,17,2,349,65,2420,5393,4097,2421,1364,340,257,32,5456,512]

theorem envBound35980 : H12AffineFastState.Bounded env35980 := by
  intro p hp
  have h : env35980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35979_35980 : H12AffineEnvironment.transform 12 348 env35979 = env35980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env35979 == env35980) = true)

theorem identity35980 : scanCanonicalize (H12AffineFastState.compose env35980 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound35980 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env35981 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,301,5376,1,294,5392,2309,1025,0,4144,293,17,2,300,48,2309,5393,4097,2308,1317,293,257,32,5409,512]

theorem envBound35981 : H12AffineFastState.Bounded env35981 := by
  intro p hp
  have h : env35981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35980_35981 : H12AffineEnvironment.transform 5 49 env35980 = env35981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env35980 == env35981) = true)

theorem identity35981 : scanCanonicalize (H12AffineFastState.compose env35981 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound35981 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env35982 : List Nat := [2,4,8,16,32,49,9,256,512,305,2048,4096,301,4145,1,294,4129,2309,304,0,4144,293,17,2,300,48,2309,4128,4097,2308,20,293,257,32,4112,512]

theorem envBound35982 : H12AffineFastState.Bounded env35982 := by
  intro p hp
  have h : env35982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35981_35982 : H12AffineEnvironment.transform 9 305 env35981 = env35982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env35981 == env35982) = true)

theorem identity35982 : scanCanonicalize (H12AffineFastState.compose env35982 (packedSelected [2,7] rootPS)) = affineNative (2^(10+1) ^^^ 772) := by decide +kernel

theorem selectedBound35982 : packedSelected [2,7] rootPS < 2^1333 := by decide +kernel

def env35983 : List Nat := [2,4,8,16,32,49,9,256,512,305,772,4096,301,4145,1,294,4129,513,304,0,4144,293,17,2,300,48,513,4128,4097,512,20,293,257,32,4112,512]

theorem envBound35983 : H12AffineFastState.Bounded env35983 := by
  intro p hp
  have h : env35983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35982_35983 : H12AffineEnvironment.transform 10 772 env35982 = env35983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 772 env35982 == env35983) = true)

theorem identity35983 : scanCanonicalize (H12AffineFastState.compose env35983 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35983 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env35984 : List Nat := [2,4,8,16,32,49,9,37,512,20,545,4096,8,4145,1,3,4129,513,21,0,4144,0,17,2,9,48,513,4128,4097,512,20,0,36,32,4112,512]

theorem envBound35984 : H12AffineFastState.Bounded env35984 := by
  intro p hp
  have h : env35984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35983_35984 : H12AffineEnvironment.transform 7 37 env35983 = env35984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35983 == env35984) = true)

theorem identity35984 : scanCanonicalize (H12AffineFastState.compose env35984 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound35984 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env35985 : List Nat := [2,4,8,16,32,49,9,37,32,20,1,4096,8,4145,1,3,4129,33,21,0,4144,0,17,2,9,48,33,4128,4097,32,20,0,36,32,4112,32]

theorem envBound35985 : H12AffineFastState.Bounded env35985 := by
  intro p hp
  have h : env35985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35984_35985 : H12AffineEnvironment.transform 8 32 env35984 = env35985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env35984 == env35985) = true)

def env35986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101329,98780,8328,65,6433956,2098513,17664,2272632,2102684,6349853,257,21792,46212,2175562]

theorem envBound35986 : H12AffineFastState.Bounded env35986 := by
  intro p hp
  have h : env35986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35925_35986 : H12AffineEnvironment.transform 22 2101329 env35925 = env35986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env35925 == env35986) = true)

def env35987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98780,8328,65,4340964,5393,17664,179512,1500,4256861,257,21792,46212,74250]

theorem envBound35987 : H12AffineFastState.Bounded env35987 := by
  intro p hp
  have h : env35987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35986_35987 : H12AffineEnvironment.transform 20 4160 env35986 = env35987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env35986 == env35987) = true)

theorem identity35987 : scanCanonicalize (H12AffineFastState.compose env35987 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound35987 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env35988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41431,8328,65,4340964,5393,17664,179512,1500,4256861,257,21792,46212,513]

theorem envBound35988 : H12AffineFastState.Bounded env35988 := by
  intro p hp
  have h : env35988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35987_35988 : H12AffineEnvironment.transform 15 8203 env35987 = env35988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env35987 == env35988) = true)

theorem identity35988 : scanCanonicalize (H12AffineFastState.compose env35988 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41381) := by decide +kernel

theorem selectedBound35988 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env35989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41381,17,41431,8328,65,171329,5393,17664,179512,1500,22008,257,21792,46212,513]

theorem envBound35989 : H12AffineFastState.Bounded env35989 := by
  intro p hp
  have h : env35989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35988_35989 : H12AffineEnvironment.transform 21 41381 env35988 = env35989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41381 env35988 == env35989) = true)

def env35990 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41261,17,41311,8192,65,171329,5393,17664,179512,1364,21872,257,21792,46092,513]

theorem envBound35990 : H12AffineFastState.Bounded env35990 := by
  intro p hp
  have h : env35990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35989_35990 : H12AffineEnvironment.transform 6 8 env35989 = env35990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env35989 == env35990) = true)

theorem identity35990 : scanCanonicalize (H12AffineFastState.compose env35990 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound35990 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env35991 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,21872,17,21762,8192,65,157980,5393,17664,149861,1364,21872,257,21792,16465,513]

theorem envBound35991 : H12AffineFastState.Bounded env35991 := by
  intro p hp
  have h : env35991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35990_35991 : H12AffineEnvironment.transform 14 29789 env35990 = env35991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env35990 == env35991) = true)

theorem identity35991 : scanCanonicalize (H12AffineFastState.compose env35991 (packedSelected [0,2,4,6,7,9,11,14,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound35991 : packedSelected [0,2,4,6,7,9,11,14,32] rootPS < 2^1333 := by decide +kernel

def env35992 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8203,131072,10361,1025,8461,4160,33,17,83,8192,65,146509,5393,4177,138292,1364,33,257,113,5376,513]

theorem envBound35992 : H12AffineFastState.Bounded env35992 := by
  intro p hp
  have h : env35992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35991_35992 : H12AffineEnvironment.transform 13 5457 env35991 = env35992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env35991 == env35992) = true)

theorem identity35992 : scanCanonicalize (H12AffineFastState.compose env35992 (packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound35992 : packedSelected [0,1,3,4,5,7,8,9,10,14,19] rootPS < 2^1333 := by decide +kernel

def env35993 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8460,8203,13389,10361,1025,8461,4160,33,17,83,8192,65,2048,5393,4177,10361,1364,33,257,113,5376,513]

theorem envBound35993 : H12AffineFastState.Bounded env35993 := by
  intro p hp
  have h : env35993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35992_35993 : H12AffineEnvironment.transform 16 13389 env35992 = env35993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env35992 == env35993) = true)

theorem identity35993 : scanCanonicalize (H12AffineFastState.compose env35993 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound35993 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env35994 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8460,8203,13340,10280,1025,8461,4113,33,17,2,8192,16,2048,5393,4096,10280,1285,33,257,32,5376,513]

theorem envBound35994 : H12AffineFastState.Bounded env35994 := by
  intro p hp
  have h : env35994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35993_35994 : H12AffineEnvironment.transform 5 17 env35993 = env35994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env35993 == env35994) = true)

theorem identity35994 : scanCanonicalize (H12AffineFastState.compose env35994 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound35994 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env35995 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,1,262,5393,2341,1025,0,4113,33,17,2,269,16,2048,5393,4096,2341,1285,33,257,32,5376,513]

theorem envBound35995 : H12AffineFastState.Bounded env35995 := by
  intro p hp
  have h : env35995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35994_35995 : H12AffineEnvironment.transform 12 269 env35994 = env35995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env35994 == env35995) = true)

theorem identity35995 : scanCanonicalize (H12AffineFastState.compose env35995 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound35995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env35996 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,1,35,5172,2048,1025,0,4113,33,17,2,40,16,2048,5172,4096,2048,1056,33,36,32,5157,513]

theorem envBound35996 : H12AffineFastState.Bounded env35996 := by
  intro p hp
  have h : env35996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35995_35996 : H12AffineEnvironment.transform 7 37 env35995 = env35996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env35995 == env35996) = true)

def env35997 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,41260,17,41310,8193,65,171329,5393,17664,179512,1365,21873,257,21792,46093,513]

theorem envBound35997 : H12AffineFastState.Bounded env35997 := by
  intro p hp
  have h : env35997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35989_35997 : H12AffineEnvironment.transform 6 9 env35989 = env35997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env35989 == env35997) = true)

theorem identity35997 : scanCanonicalize (H12AffineFastState.compose env35997 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound35997 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env35998 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,131072,32040,1025,8540,4160,113,17,3,8193,65,146460,5393,17664,138341,1365,21873,257,21792,5456,513]

theorem envBound35998 : H12AffineFastState.Bounded env35998 := by
  intro p hp
  have h : env35998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35997_35998 : H12AffineEnvironment.transform 14 8541 env35997 = env35998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env35997 == env35998) = true)

theorem identity35998 : scanCanonicalize (H12AffineFastState.compose env35998 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound35998 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env35999 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,32040,1025,8540,4160,113,17,3,8193,65,31757,5393,17664,23668,1365,21873,257,21792,5456,513]

theorem envBound35999 : H12AffineFastState.Bounded env35999 := by
  intro p hp
  have h : env35999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35998_35999 : H12AffineEnvironment.transform 16 16401 env35998 = env35999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env35998 == env35999) = true)

theorem identity35999 : scanCanonicalize (H12AffineFastState.compose env35999 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound35999 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env36000 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,16384,293,115,16401,23888,1025,292,4160,113,17,3,121,65,23669,5393,17664,23668,1365,21873,257,21792,5456,513]

theorem envBound36000 : H12AffineFastState.Bounded env36000 := by
  intro p hp
  have h : env36000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35999_36000 : H12AffineEnvironment.transform 12 120 env35999 = env36000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env35999 == env36000) = true)

theorem identity36000 : scanCanonicalize (H12AffineFastState.compose env36000 (packedSelected [2,5,6,8,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound36000 : packedSelected [2,5,6,8,11,18] rootPS < 2^1333 := by decide +kernel

def env36001 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,16384,0,115,16401,23669,1025,1,4160,113,17,3,121,65,23669,5172,17445,23668,1136,21588,36,21509,5237,513]

theorem envBound36001 : H12AffineFastState.Bounded env36001 := by
  intro p hp
  have h : env36001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36000_36001 : H12AffineEnvironment.transform 7 37 env36000 = env36001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env36000 == env36001) = true)

theorem identity36001 : scanCanonicalize (H12AffineFastState.compose env36001 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound36001 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env36002 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,16384,0,115,16401,22592,52,1,4160,113,17,3,121,65,22592,4097,16400,22593,69,20577,36,20528,4160,513]

theorem envBound36002 : H12AffineFastState.Bounded env36002 := by
  intro p hp
  have h : env36002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36001_36002 : H12AffineEnvironment.transform 9 53 env36001 = env36002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env36001 == env36002) = true)

theorem identity36002 : scanCanonicalize (H12AffineFastState.compose env36002 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4160) := by decide +kernel

theorem selectedBound36002 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env36003 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,120,4160,0,115,4177,2048,52,1,4160,113,17,3,121,65,2048,4097,4176,2049,69,33,36,112,4160,513]

theorem envBound36003 : H12AffineFastState.Bounded env36003 := by
  intro p hp
  have h : env36003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36002_36003 : H12AffineEnvironment.transform 13 4160 env36002 = env36003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4160 env36002 == env36003) = true)

theorem identity36003 : scanCanonicalize (H12AffineFastState.compose env36003 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound36003 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env36004 : List Nat := [2,4,8,16,32,49,9,37,512,53,2048,4096,9,4145,0,2,4128,2048,52,1,4145,0,17,3,8,48,2048,4097,4129,2049,52,33,36,1,4145,513]

theorem envBound36004 : H12AffineFastState.Bounded env36004 := by
  intro p hp
  have h : env36004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36003_36004 : H12AffineEnvironment.transform 5 49 env36003 = env36004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env36003 == env36004) = true)

theorem identity36004 : scanCanonicalize (H12AffineFastState.compose env36004 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound36004 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env36005 : List Nat := [2,4,8,16,32,49,9,37,512,53,2048,48,9,1,0,2,16,2048,52,1,1,0,17,3,8,48,2048,49,17,2049,52,33,36,1,1,513]

theorem envBound36005 : H12AffineFastState.Bounded env36005 := by
  intro p hp
  have h : env36005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36004_36005 : H12AffineEnvironment.transform 11 48 env36004 = env36005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env36004 == env36005) = true)

theorem identity36005 : scanCanonicalize (H12AffineFastState.compose env36005 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound36005 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env36006 : List Nat := [2,4,8,16,32,49,9,37,512,53,544,48,9,1,0,2,16,544,52,1,1,0,17,3,8,48,544,49,17,545,52,33,36,1,1,513]

theorem envBound36006 : H12AffineFastState.Bounded env36006 := by
  intro p hp
  have h : env36006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36005_36006 : H12AffineEnvironment.transform 10 544 env36005 = env36006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env36005 == env36006) = true)

theorem identity36006 : scanCanonicalize (H12AffineFastState.compose env36006 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound36006 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env36007 : List Nat := [2,4,8,16,16,1,9,21,512,5,528,0,9,1,0,2,16,528,4,1,1,0,17,3,8,0,528,1,17,529,4,17,20,1,1,513]

theorem envBound36007 : H12AffineFastState.Bounded env36007 := by
  intro p hp
  have h : env36007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36006_36007 : H12AffineEnvironment.transform 4 16 env36006 = env36007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env36006 == env36007) = true)

theorem identity36007 : scanCanonicalize (H12AffineFastState.compose env36007 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound36007 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env36008 : List Nat := [2,4,8,16,16,1,9,21,1,5,17,0,9,1,0,2,16,17,4,1,1,0,17,3,8,0,17,1,17,16,4,17,20,1,1,0]

theorem envBound36008 : H12AffineFastState.Bounded env36008 := by
  intro p hp
  have h : env36008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36007_36008 : H12AffineEnvironment.transform 8 1 env36007 = env36008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env36007 == env36008) = true)

theorem identity36008 : scanCanonicalize (H12AffineFastState.compose env36008 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound36008 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env36009 : List Nat := [2,4,8,0,0,1,9,5,1,5,1,0,9,1,0,2,0,1,4,1,1,0,1,3,8,0,1,1,1,0,4,1,4,1,1,0]

theorem envBound36009 : H12AffineFastState.Bounded env36009 := by
  intro p hp
  have h : env36009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36008_36009 : H12AffineEnvironment.transform 3 0 env36008 = env36009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env36008 == env36009) = true)

def env36010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,16,98780,8328,65,4340965,5392,17664,179513,1501,4256860,257,21792,46212,74251]

theorem envBound36010 : H12AffineFastState.Bounded env36010 := by
  intro p hp
  have h : env36010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans35986_36010 : H12AffineEnvironment.transform 20 4161 env35986 = env36010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env35986 == env36010) = true)

theorem identity36010 : scanCanonicalize (H12AffineFastState.compose env36010 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 95650) := by decide +kernel

theorem selectedBound36010 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env36011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95650,16,98780,8328,65,215367,5392,17664,179513,1501,98814,257,21792,46212,74251]

theorem envBound36011 : H12AffineFastState.Bounded env36011 := by
  intro p hp
  have h : env36011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36010_36011 : H12AffineEnvironment.transform 21 95650 env36010 = env36011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 95650 env36010 == env36011) = true)

def env36012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,95530,16,98644,8192,65,215367,5392,17664,179513,1365,98678,257,21792,46092,74251]

theorem envBound36012 : H12AffineFastState.Bounded env36012 := by
  intro p hp
  have h : env36012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36011_36012 : H12AffineEnvironment.transform 6 8 env36011 = env36012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env36011 == env36012) = true)

theorem identity36012 : scanCanonicalize (H12AffineFastState.compose env36012 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound36012 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env36013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4161,73770,16,98644,8192,65,203847,5392,4096,179513,1365,98678,257,32,46092,74251]

theorem envBound36013 : H12AffineFastState.Bounded env36013 := by
  intro p hp
  have h : env36013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36012_36013 : H12AffineEnvironment.transform 13 5376 env36012 = env36013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env36012 == env36013) = true)

theorem identity36013 : scanCanonicalize (H12AffineFastState.compose env36013 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound36013 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env36014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,10280,1025,32769,4161,33,16,41311,8192,65,146508,5392,4096,179513,1365,41341,257,32,46092,512]

theorem envBound36014 : H12AffineFastState.Bounded env36014 := by
  intro p hp
  have h : env36014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36013_36014 : H12AffineEnvironment.transform 15 8203 env36013 = env36014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env36013 == env36014) = true)

theorem identity36014 : scanCanonicalize (H12AffineFastState.compose env36014 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1125) := by decide +kernel

theorem selectedBound36014 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env36015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1125,8203,131072,10280,1025,1124,4161,33,16,9530,8192,65,146508,5392,4096,145756,1365,9496,257,32,12393,512]

theorem envBound36015 : H12AffineFastState.Bounded env36015 := by
  intro p hp
  have h : env36015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36014_36015 : H12AffineEnvironment.transform 14 1125 env36014 = env36015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1125 env36014 == env36015) = true)

theorem identity36015 : scanCanonicalize (H12AffineFastState.compose env36015 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound36015 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env36016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,8192,373,1125,8203,131072,10280,1025,1124,1076,33,16,9530,8192,65,141369,357,1141,142633,1365,9496,257,32,9244,512]

theorem envBound36016 : H12AffineFastState.Bounded env36016 := by
  intro p hp
  have h : env36016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36015_36016 : H12AffineEnvironment.transform 11 1141 env36015 = env36016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env36015 == env36016) = true)

theorem identity36016 : scanCanonicalize (H12AffineFastState.compose env36016 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound36016 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env36017 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1141,1100,373,1125,1095,131072,3172,1025,1124,1076,33,16,374,1100,65,134261,357,1141,133477,1365,340,257,32,80,512]

theorem envBound36017 : H12AffineFastState.Bounded env36017 := by
  intro p hp
  have h : env36017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans36016_36017 : H12AffineEnvironment.transform 12 1100 env36016 = env36017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env36016 == env36017) = true)

theorem identity36017 : scanCanonicalize (H12AffineFastState.compose env36017 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound36017 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env36018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,81,1141,1100,373,1125,1095,131072,1077,1025,1124,1076,33,16,374,1100,65,132132,357,1141,131380,1365,340,257,32,80,512]

theorem envBound36018 : H12AffineFastState.Bounded env36018 := by
  intro p hp
  have h : env36018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1