import H12CloudChart1Data187

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans47619_47620 : H12AffineEnvironment.transform 7 36 env47619 = env47620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47619 == env47620) = true)

def env47621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21929,351538,329760,8328,65,508091,302317,333858,236851,119043,272393,257,98814,90202,63189]

theorem envBound47621 : H12AffineFastState.Bounded env47621 := by
  intro p hp
  have h : env47621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47593_47621 : H12AffineEnvironment.transform 20 4161 env47593 = env47621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47593 == env47621) = true)

theorem identity47621 : scanCanonicalize (H12AffineFastState.compose env47621 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound47621 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,21929,73754,95496,8328,65,245139,57797,91402,236851,119043,21793,257,98814,90202,63189]

theorem envBound47622 : H12AffineFastState.Bounded env47622 := by
  intro p hp
  have h : env47622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47621_47622 : H12AffineEnvironment.transform 17 32040 env47621 = env47622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env47621 == env47622) = true)

def env47623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10400,1025,32769,4161,33,73754,73856,8328,65,245139,46157,77954,236851,99467,169,257,98814,79314,41821]

theorem envBound47623 : H12AffineFastState.Bounded env47623 := by
  intro p hp
  have h : env47623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47622_47623 : H12AffineEnvironment.transform 13 5512 env47622 = env47623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env47622 == env47623) = true)

theorem identity47623 : scanCanonicalize (H12AffineFastState.compose env47623 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound47623 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env47624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,5392,10400,1025,32769,4161,33,73754,73856,8328,65,108675,46157,77954,100387,99467,169,257,98814,79314,41821]

theorem envBound47624 : H12AffineFastState.Bounded env47624 := by
  intro p hp
  have h : env47624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47623_47624 : H12AffineEnvironment.transform 16 5392 env47623 = env47624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env47623 == env47624) = true)

theorem identity47624 : scanCanonicalize (H12AffineFastState.compose env47624 (packedSelected [16,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound47624 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,40971,5392,10400,1025,32769,4161,33,32785,32907,8328,65,2184,46157,37001,10280,9344,169,257,8693,38361,41821]

theorem envBound47625 : H12AffineFastState.Bounded env47625 := by
  intro p hp
  have h : env47625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47624_47625 : H12AffineEnvironment.transform 15 40971 env47624 = env47625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env47624 == env47625) = true)

theorem identity47625 : scanCanonicalize (H12AffineFastState.compose env47625 (packedSelected [1,3,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound47625 : packedSelected [1,3,24,28] rootPS < 2^1333 := by decide +kernel

def env47626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8660,479,5392,10400,1025,8661,4161,33,8645,8543,8328,65,2184,5529,12637,10280,9344,169,257,8693,13325,649]

theorem envBound47626 : H12AffineFastState.Bounded env47626 := by
  intro p hp
  have h : env47626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47625_47626 : H12AffineEnvironment.transform 14 8660 env47625 = env47626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env47625 == env47626) = true)

theorem identity47626 : scanCanonicalize (H12AffineFastState.compose env47626 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound47626 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,0,479,5392,2420,1025,1,4161,33,17,139,348,65,2184,5529,4233,2556,1364,169,257,33,5593,649]

theorem envBound47627 : H12AffineFastState.Bounded env47627 := by
  intro p hp
  have h : env47627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47626_47627 : H12AffineEnvironment.transform 12 468 env47626 = env47627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env47626 == env47627) = true)

theorem identity47627 : scanCanonicalize (H12AffineFastState.compose env47627 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47627 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env47628 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,240,5292,0,251,5172,2128,1025,1,4161,33,17,139,120,65,2184,5309,4233,2264,1136,169,37,33,5373,649]

theorem envBound47628 : H12AffineFastState.Bounded env47628 := by
  intro p hp
  have h : env47628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47627_47628 : H12AffineEnvironment.transform 7 36 env47627 = env47628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47627 == env47628) = true)

theorem identity47628 : scanCanonicalize (H12AffineFastState.compose env47628 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound47628 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47629 : List Nat := [2,4,8,16,32,48,128,36,512,1024,2048,4096,128,5292,0,139,5172,2080,1025,1,4145,33,17,139,8,49,2184,5309,4233,2216,1024,169,37,33,5261,649]

theorem envBound47629 : H12AffineFastState.Bounded env47629 := by
  intro p hp
  have h : env47629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47628_47629 : H12AffineEnvironment.transform 5 48 env47628 = env47629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env47628 == env47629) = true)

theorem identity47629 : scanCanonicalize (H12AffineFastState.compose env47629 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound47629 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47630 : List Nat := [2,4,8,16,32,48,128,36,512,21,2048,4096,128,4281,0,139,4129,2080,20,1,4145,33,17,139,8,49,2184,4264,4233,2216,21,169,37,33,4248,649]

theorem envBound47630 : H12AffineFastState.Bounded env47630 := by
  intro p hp
  have h : env47630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47629_47630 : H12AffineEnvironment.transform 9 21 env47629 = env47630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env47629 == env47630) = true)

theorem identity47630 : scanCanonicalize (H12AffineFastState.compose env47630 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47630 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47631 : List Nat := [2,4,8,16,1,17,128,5,512,21,2048,4096,128,4248,0,139,4096,2049,20,1,4112,0,17,139,8,16,2184,4233,4233,2185,21,136,4,0,4248,649]

theorem envBound47631 : H12AffineFastState.Bounded env47631 := by
  intro p hp
  have h : env47631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47630_47631 : H12AffineEnvironment.transform 4 1 env47630 = env47631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47630 == env47631) = true)

theorem identity47631 : scanCanonicalize (H12AffineFastState.compose env47631 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound47631 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47632 : List Nat := [2,4,8,16,1,17,9,5,512,21,2048,4096,9,4113,0,2,4096,2049,20,1,4112,0,17,2,8,16,2049,4096,4096,2048,21,1,4,0,4113,512]

theorem envBound47632 : H12AffineFastState.Bounded env47632 := by
  intro p hp
  have h : env47632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47631_47632 : H12AffineEnvironment.transform 6 9 env47631 = env47632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47631 == env47632) = true)

theorem identity47632 : scanCanonicalize (H12AffineFastState.compose env47632 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound47632 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47633 : List Nat := [2,4,8,16,1,17,9,5,512,21,512,4096,9,4113,0,2,4096,513,20,1,4112,0,17,2,8,16,513,4096,4096,512,21,1,4,0,4113,512]

theorem envBound47633 : H12AffineFastState.Bounded env47633 := by
  intro p hp
  have h : env47633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47632_47633 : H12AffineEnvironment.transform 10 512 env47632 = env47633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env47632 == env47633) = true)

theorem identity47633 : scanCanonicalize (H12AffineFastState.compose env47633 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 533) := by decide +kernel

theorem selectedBound47633 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47634 : List Nat := [2,4,8,16,1,17,9,5,512,21,512,533,9,516,0,2,533,513,20,1,517,0,17,2,8,16,513,533,533,512,21,1,4,0,516,512]

theorem envBound47634 : H12AffineFastState.Bounded env47634 := by
  intro p hp
  have h : env47634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47633_47634 : H12AffineEnvironment.transform 11 533 env47633 = env47634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 533 env47633 == env47634) = true)

theorem identity47634 : scanCanonicalize (H12AffineFastState.compose env47634 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound47634 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47635 : List Nat := [2,4,8,16,1,17,9,5,0,21,0,21,9,4,0,2,21,1,20,1,5,0,17,2,8,16,1,21,21,0,21,1,4,0,4,0]

theorem envBound47635 : H12AffineFastState.Bounded env47635 := by
  intro p hp
  have h : env47635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47634_47635 : H12AffineEnvironment.transform 8 0 env47634 = env47635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env47634 == env47635) = true)

theorem identity47635 : scanCanonicalize (H12AffineFastState.compose env47635 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47635 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47636 : List Nat := [2,4,8,4,1,5,9,5,0,1,0,1,9,4,0,2,1,1,0,1,5,0,5,2,8,4,1,1,1,0,1,1,4,0,4,0]

theorem envBound47636 : H12AffineFastState.Bounded env47636 := by
  intro p hp
  have h : env47636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47635_47636 : H12AffineEnvironment.transform 3 4 env47635 = env47636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47635 == env47636) = true)

def env47637 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,10401,1025,32769,4161,32,73754,73857,8328,65,245139,46156,77955,236851,99466,168,257,98814,79315,41820]

theorem envBound47637 : H12AffineFastState.Bounded env47637 := by
  intro p hp
  have h : env47637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47622_47637 : H12AffineEnvironment.transform 13 5513 env47622 = env47637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47622 == env47637) = true)

def env47638 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1025,32769,4161,32,73754,73737,8192,65,245019,46156,77835,236851,99330,32,257,98678,79195,41820]

theorem envBound47638 : H12AffineFastState.Bounded env47638 := by
  intro p hp
  have h : env47638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47637_47638 : H12AffineEnvironment.transform 6 8 env47637 = env47638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47637 == env47638) = true)

theorem identity47638 : scanCanonicalize (H12AffineFastState.compose env47638 (packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound47638 : packedSelected [0,1,2,4,5,6,8,9,10,11,16,18,24,27,31] rootPS < 2^1333 := by decide +kernel

def env47639 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,13340,10281,1025,32769,4161,32,73754,73737,8192,65,100615,46156,77835,108847,99330,32,257,98678,79195,41820]

theorem envBound47639 : H12AffineFastState.Bounded env47639 := by
  intro p hp
  have h : env47639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47638_47639 : H12AffineEnvironment.transform 16 13340 env47638 = env47639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env47638 == env47639) = true)

theorem identity47639 : scanCanonicalize (H12AffineFastState.compose env47639 (packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47639 : packedSelected [0,2,4,6,7,9,11,12,14,15,16,20,23] rootPS < 2^1333 := by decide +kernel

def env47640 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,13340,10281,1025,8540,4161,32,73754,73737,8192,65,75866,5393,77835,67698,75103,32,257,73771,79195,513]

theorem envBound47640 : H12AffineFastState.Bounded env47640 := by
  intro p hp
  have h : env47640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47639_47640 : H12AffineEnvironment.transform 14 8541 env47639 = env47640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47639 == env47640) = true)

theorem identity47640 : scanCanonicalize (H12AffineFastState.compose env47640 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47640 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env47641 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,65536,13340,10281,1025,8461,4112,32,73754,73737,8192,16,75787,5393,77835,67619,75022,32,257,73771,79114,513]

theorem envBound47641 : H12AffineFastState.Bounded env47641 := by
  intro p hp
  have h : env47641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47640_47641 : H12AffineEnvironment.transform 5 17 env47640 = env47641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47640 == env47641) = true)

theorem identity47641 : scanCanonicalize (H12AffineFastState.compose env47641 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound47641 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env47642 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,262,13340,10281,1025,8461,4112,32,8476,8463,8192,16,10509,5393,12557,2341,9224,32,257,8493,13324,513]

theorem envBound47642 : H12AffineFastState.Bounded env47642 := by
  intro p hp
  have h : env47642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47641_47642 : H12AffineEnvironment.transform 15 262 env47641 = env47642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env47641 == env47642) = true)

theorem identity47642 : scanCanonicalize (H12AffineFastState.compose env47642 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound47642 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47643 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1280,8192,1,8460,262,8476,10281,1025,8461,1296,32,8476,8463,8192,16,10509,17,9229,2341,9224,32,257,8493,8460,513]

theorem envBound47643 : H12AffineFastState.Bounded env47643 := by
  intro p hp
  have h : env47643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47642_47643 : H12AffineEnvironment.transform 11 1280 env47642 = env47643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env47642 == env47643) = true)

theorem identity47643 : scanCanonicalize (H12AffineFastState.compose env47643 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound47643 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47644 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1280,269,1,1,262,17,2340,1025,0,1296,32,17,2,269,16,2048,17,1280,2341,1285,32,257,32,1,513]

theorem envBound47644 : H12AffineFastState.Bounded env47644 := by
  intro p hp
  have h : env47644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47643_47644 : H12AffineEnvironment.transform 12 269 env47643 = env47644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env47643 == env47644) = true)

theorem identity47644 : scanCanonicalize (H12AffineFastState.compose env47644 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47644 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47645 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,1280,269,1,1,262,17,2309,1025,0,1296,1,17,2,269,16,2048,17,1280,2308,1285,1,257,1,1,513]

theorem envBound47645 : H12AffineFastState.Bounded env47645 := by
  intro p hp
  have h : env47645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47644_47645 : H12AffineEnvironment.transform 4 1 env47644 = env47645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47644 == env47645) = true)

theorem identity47645 : scanCanonicalize (H12AffineFastState.compose env47645 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound47645 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47646 : List Nat := [2,4,8,16,1,17,8,256,512,1024,512,1280,269,1,1,262,17,773,1025,0,1296,1,17,2,269,16,512,17,1280,772,1285,1,257,1,1,513]

theorem envBound47646 : H12AffineFastState.Bounded env47646 := by
  intro p hp
  have h : env47646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47645_47646 : H12AffineEnvironment.transform 10 512 env47645 = env47646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env47645 == env47646) = true)

theorem identity47646 : scanCanonicalize (H12AffineFastState.compose env47646 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47646 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47647 : List Nat := [2,4,8,1,1,0,8,256,512,1024,512,1280,269,1,1,262,0,773,1025,0,1281,1,0,2,269,1,512,0,1280,772,1285,1,257,1,1,513]

theorem envBound47647 : H12AffineFastState.Bounded env47647 := by
  intro p hp
  have h : env47647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47646_47647 : H12AffineEnvironment.transform 3 1 env47646 = env47647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47646 == env47647) = true)

theorem identity47647 : scanCanonicalize (H12AffineFastState.compose env47647 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound47647 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47648 : List Nat := [2,4,8,1,1,0,8,256,261,1024,261,1280,269,1,1,262,0,0,1025,0,1281,1,0,2,269,1,261,0,1280,1,1285,1,257,1,1,260]

theorem envBound47648 : H12AffineFastState.Bounded env47648 := by
  intro p hp
  have h : env47648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47647_47648 : H12AffineEnvironment.transform 8 261 env47647 = env47648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env47647 == env47648) = true)

def env47649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4161,32,73754,73736,8193,65,245018,46156,77834,236851,99331,33,257,98679,79194,41820]

theorem envBound47649 : H12AffineFastState.Bounded env47649 := by
  intro p hp
  have h : env47649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47637_47649 : H12AffineEnvironment.transform 6 9 env47637 = env47649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47637 == env47649) = true)

theorem identity47649 : scanCanonicalize (H12AffineFastState.compose env47649 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47649 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47650 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1025,8540,4161,32,73754,73736,8193,65,203847,5393,77834,212078,75102,33,257,73770,79194,513]

theorem envBound47650 : H12AffineFastState.Bounded env47650 := by
  intro p hp
  have h : env47650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47649_47650 : H12AffineEnvironment.transform 14 8541 env47649 = env47650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47649 == env47650) = true)

theorem identity47650 : scanCanonicalize (H12AffineFastState.compose env47650 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 7545) := by decide +kernel

theorem selectedBound47650 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env47651 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,5376,7204,65536,131072,5457,1025,7205,4161,32,73059,73073,7544,65,203847,5393,68979,196887,71719,33,257,73043,67619,513]

theorem envBound47651 : H12AffineFastState.Bounded env47651 := by
  intro p hp
  have h : env47651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47650_47651 : H12AffineEnvironment.transform 12 7545 env47650 = env47651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7545 env47650 == env47651) = true)

theorem identity47651 : scanCanonicalize (H12AffineFastState.compose env47651 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 69746) := by decide +kernel

theorem selectedBound47651 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env47652 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,7545,5376,7204,65536,69746,5457,1025,7205,4161,32,73059,73073,7544,65,3125,5393,68979,4453,71719,33,257,73043,67619,513]

theorem envBound47652 : H12AffineFastState.Bounded env47652 := by
  intro p hp
  have h : env47652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47651_47652 : H12AffineEnvironment.transform 16 69746 env47651 = env47652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69746 env47651 == env47652) = true)

theorem identity47652 : scanCanonicalize (H12AffineFastState.compose env47652 (packedSelected [0,7,16] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound47652 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env47653 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3329,120,2049,293,65536,68979,2128,1025,292,3392,32,65634,65648,121,65,3125,2064,68979,3172,66854,33,257,65618,67619,513]

theorem envBound47653 : H12AffineFastState.Bounded env47653 := by
  intro p hp
  have h : env47653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47652_47653 : H12AffineEnvironment.transform 11 3329 env47652 = env47653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env47652 == env47653) = true)

theorem identity47653 : scanCanonicalize (H12AffineFastState.compose env47653 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47653 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env47654 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,3189,120,2049,81,65536,68615,2128,1025,80,3124,32,65634,65648,121,65,3125,2064,68615,3172,66642,33,117,65618,67619,513]

theorem envBound47654 : H12AffineFastState.Bounded env47654 := by
  intro p hp
  have h : env47654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47653_47654 : H12AffineEnvironment.transform 7 116 env47653 = env47654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47653 == env47654) = true)

theorem identity47654 : scanCanonicalize (H12AffineFastState.compose env47654 (packedSelected [1,2,3,4,5,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47654 : packedSelected [1,2,3,4,5,6,8,9] rootPS < 2^1333 := by decide +kernel

def env47655 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2064,120,2049,81,65536,67682,2128,100,80,2129,32,65634,65648,121,65,2128,2064,67682,2049,65591,33,117,65618,67619,513]

theorem envBound47655 : H12AffineFastState.Bounded env47655 := by
  intro p hp
  have h : env47655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47654_47655 : H12AffineEnvironment.transform 9 101 env47654 = env47655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47654 == env47655) = true)

theorem identity47655 : scanCanonicalize (H12AffineFastState.compose env47655 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound47655 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env47656 : List Nat := [2,4,8,16,32,64,9,116,512,101,0,16,120,1,81,65536,65634,80,100,80,81,32,65634,65648,121,65,80,16,65634,1,65591,33,117,65618,65571,513]

theorem envBound47656 : H12AffineFastState.Bounded env47656 := by
  intro p hp
  have h : env47656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47655_47656 : H12AffineEnvironment.transform 10 0 env47655 = env47656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env47655 == env47656) = true)

theorem identity47656 : scanCanonicalize (H12AffineFastState.compose env47656 (packedSelected [0,1] rootPS)) = affineNative (2^(15+1) ^^^ 584) := by decide +kernel

theorem selectedBound47656 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env47657 : List Nat := [2,4,8,16,32,64,9,116,512,101,0,16,120,1,81,584,554,80,100,80,81,32,554,568,121,65,80,16,554,1,639,33,117,538,619,513]

theorem envBound47657 : H12AffineFastState.Bounded env47657 := by
  intro p hp
  have h : env47657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47656_47657 : H12AffineEnvironment.transform 15 584 env47656 = env47657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 584 env47656 == env47657) = true)

theorem identity47657 : scanCanonicalize (H12AffineFastState.compose env47657 (packedSelected [0,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound47657 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env47658 : List Nat := [2,4,8,16,32,64,9,116,16,101,0,16,120,1,81,88,58,80,100,80,81,32,58,40,121,65,80,16,58,1,111,33,117,10,123,17]

theorem envBound47658 : H12AffineFastState.Bounded env47658 := by
  intro p hp
  have h : env47658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47657_47658 : H12AffineEnvironment.transform 8 16 env47657 = env47658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env47657 == env47658) = true)

def env47659 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,16777216,8328,65,16959642,18973836,333858,2329970,19188066,16850984,257,17074654,17066106,19263156]

theorem envBound47659 : H12AffineFastState.Bounded env47659 := by
  intro p hp
  have h : env47659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47540_47659 : H12AffineEnvironment.transform 21 2115049 env47540 = env47659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2115049 env47540 == env47659) = true)

def env47660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431072,8328,65,2609402,302316,333858,2329970,119042,2373704,257,2199998,2191386,63188]

theorem envBound47660 : H12AffineFastState.Bounded env47660 := by
  intro p hp
  have h : env47660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47659_47660 : H12AffineEnvironment.transform 23 2431072 env47659 = env47660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431072 env47659 == env47660) = true)

def env47661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329760,8328,65,508090,302316,333858,236850,119042,272392,257,98814,90202,63188]

theorem envBound47661 : H12AffineFastState.Bounded env47661 := by
  intro p hp
  have h : env47661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47660_47661 : H12AffineEnvironment.transform 20 4160 env47660 = env47661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47660 == env47661) = true)

theorem identity47661 : scanCanonicalize (H12AffineFastState.compose env47661 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound47661 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,21929,297453,318718,8328,65,398436,302316,314620,149996,1500,272392,257,21792,46212,63188]

theorem envBound47662 : H12AffineFastState.Bounded env47662 := by
  intro p hp
  have h : env47662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47661_47662 : H12AffineEnvironment.transform 15 54494 env47661 = env47662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env47661 == env47662) = true)

def env47663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4160,21929,41413,62678,8328,65,146508,46276,58580,149996,1500,32,257,21792,46212,63188]

theorem envBound47663 : H12AffineFastState.Bounded env47663 := by
  intro p hp
  have h : env47663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47662_47663 : H12AffineEnvironment.transform 17 10280 env47662 = env47663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47662 == env47663) = true)

theorem identity47663 : scanCanonicalize (H12AffineFastState.compose env47663 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound47663 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,131072,10280,1025,8661,4160,21929,17,21762,8328,65,146508,5392,17664,149996,1500,32,257,21792,5456,22272]

theorem envBound47664 : H12AffineFastState.Bounded env47664 := by
  intro p hp
  have h : env47664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47663_47664 : H12AffineEnvironment.transform 14 8660 env47663 = env47664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env47663 == env47664) = true)

theorem identity47664 : scanCanonicalize (H12AffineFastState.compose env47664 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound47664 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29962,16400,10280,1025,8661,4160,21929,17,21762,8328,65,31836,5392,17664,2556,1500,32,257,21792,5456,22272]

theorem envBound47665 : H12AffineFastState.Bounded env47665 := by
  intro p hp
  have h : env47665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47664_47665 : H12AffineEnvironment.transform 16 16400 env47664 = env47665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env47664 == env47665) = true)

theorem identity47665 : scanCanonicalize (H12AffineFastState.compose env47665 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47665 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47666 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,8192,16384,8660,28699,16400,10280,272,8661,4160,20664,17,20499,8328,65,31053,4097,16401,2556,205,32,257,20529,4161,21009]

theorem envBound47666 : H12AffineFastState.Bounded env47666 := by
  intro p hp
  have h : env47666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47665_47666 : H12AffineEnvironment.transform 9 273 env47665 = env47666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47665 == env47666) = true)

theorem identity47666 : scanCanonicalize (H12AffineFastState.compose env47666 (packedSelected [11,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound47666 : packedSelected [11,16,18,20] rootPS < 2^1333 := by decide +kernel

def env47667 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,161,16384,373,20666,16400,2185,272,372,4160,20664,17,20499,41,65,23020,4097,16401,2556,205,32,257,20529,4161,21009]

theorem envBound47667 : H12AffineFastState.Bounded env47667 := by
  intro p hp
  have h : env47667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47666_47667 : H12AffineEnvironment.transform 12 161 env47666 = env47667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env47666 == env47667) = true)

theorem identity47667 : scanCanonicalize (H12AffineFastState.compose env47667 (packedSelected [0,4,7,11,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound47667 : packedSelected [0,4,7,11,18,22] rootPS < 2^1333 := by decide +kernel

def env47668 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,161,4112,373,170,4096,2185,272,372,4160,168,17,3,41,65,2556,4097,4097,2556,205,32,257,33,4161,513]

theorem envBound47668 : H12AffineFastState.Bounded env47668 := by
  intro p hp
  have h : env47668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47667_47668 : H12AffineEnvironment.transform 13 4112 env47667 = env47668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env47667 == env47668) = true)

theorem identity47668 : scanCanonicalize (H12AffineFastState.compose env47668 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound47668 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47669 : List Nat := [2,4,8,16,32,64,89,256,512,273,2048,4096,120,4112,373,115,4096,2128,272,372,4160,113,17,3,41,65,2341,4097,4097,2341,20,32,257,33,4161,513]

theorem envBound47669 : H12AffineFastState.Bounded env47669 := by
  intro p hp
  have h : env47669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47668_47669 : H12AffineEnvironment.transform 6 89 env47668 = env47669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env47668 == env47669) = true)

theorem identity47669 : scanCanonicalize (H12AffineFastState.compose env47669 (packedSelected [2,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47669 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env47670 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,41,4112,292,34,4096,2049,272,293,4113,32,17,3,41,16,2341,4097,4097,2341,20,32,257,33,4112,513]

theorem envBound47670 : H12AffineFastState.Bounded env47670 := by
  intro p hp
  have h : env47670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47669_47670 : H12AffineEnvironment.transform 5 17 env47669 = env47670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47669 == env47670) = true)

theorem identity47670 : scanCanonicalize (H12AffineFastState.compose env47670 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47670 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47671 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4112,0,34,4096,2049,52,1,4113,32,17,3,41,16,2049,4097,4097,2049,20,32,37,33,4112,513]

theorem envBound47671 : H12AffineFastState.Bounded env47671 := by
  intro p hp
  have h : env47671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47670_47671 : H12AffineEnvironment.transform 7 36 env47670 = env47671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47670 == env47671) = true)

theorem identity47671 : scanCanonicalize (H12AffineFastState.compose env47671 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound47671 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47672 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,32,41,48,0,34,32,2049,52,1,49,32,17,3,41,16,2049,33,33,2049,20,32,37,33,48,513]

theorem envBound47672 : H12AffineFastState.Bounded env47672 := by
  intro p hp
  have h : env47672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47671_47672 : H12AffineEnvironment.transform 11 32 env47671 = env47672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env47671 == env47672) = true)

theorem identity47672 : scanCanonicalize (H12AffineFastState.compose env47672 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound47672 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47673 : List Nat := [2,4,8,16,32,17,8,36,512,53,49,32,41,48,0,34,32,48,52,1,49,32,17,3,41,16,48,33,33,48,20,32,37,33,48,513]

theorem envBound47673 : H12AffineFastState.Bounded env47673 := by
  intro p hp
  have h : env47673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47672_47673 : H12AffineEnvironment.transform 10 49 env47672 = env47673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env47672 == env47673) = true)

theorem identity47673 : scanCanonicalize (H12AffineFastState.compose env47673 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound47673 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47674 : List Nat := [2,4,8,16,17,17,8,21,512,4,0,17,24,1,0,19,17,1,5,1,0,17,17,3,24,16,1,16,16,1,20,17,20,16,1,513]

theorem envBound47674 : H12AffineFastState.Bounded env47674 := by
  intro p hp
  have h : env47674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47673_47674 : H12AffineEnvironment.transform 4 17 env47673 = env47674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env47673 == env47674) = true)

def env47675 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4160,21929,41412,62679,8328,65,146509,46277,58581,149996,1500,33,257,21792,46212,63188]

theorem envBound47675 : H12AffineFastState.Bounded env47675 := by
  intro p hp
  have h : env47675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47662_47675 : H12AffineEnvironment.transform 17 10281 env47662 = env47675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env47662 == env47675) = true)

theorem identity47675 : scanCanonicalize (H12AffineFastState.compose env47675 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47675 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,4160,21793,41292,62559,8192,65,146509,46157,58461,149860,1364,33,257,21792,46092,63068]

theorem envBound47676 : H12AffineFastState.Bounded env47676 := by
  intro p hp
  have h : env47676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47675_47676 : H12AffineEnvironment.transform 6 8 env47675 = env47676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47675 == env47676) = true)

theorem identity47676 : scanCanonicalize (H12AffineFastState.compose env47676 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47676 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env47677 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,131072,10281,1025,32769,4113,21793,41245,62478,8192,16,146460,46108,58380,149813,1285,33,257,21792,46092,62989]

theorem envBound47677 : H12AffineFastState.Bounded env47677 := by
  intro p hp
  have h : env47677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47676_47677 : H12AffineEnvironment.transform 5 17 env47676 = env47677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47676 == env47677) = true)

theorem identity47677 : scanCanonicalize (H12AffineFastState.compose env47677 (packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound47677 : packedSelected [1,3,4,5,8,9,10,12,14,15,19,20] rootPS < 2^1333 := by decide +kernel

def env47678 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,54279,13340,10281,1025,32769,4113,21793,41245,62478,8192,16,2048,46108,58380,32041,1285,33,257,21792,46092,62989]

theorem envBound47678 : H12AffineFastState.Bounded env47678 := by
  intro p hp
  have h : env47678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47677_47678 : H12AffineEnvironment.transform 16 13340 env47677 = env47678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env47677 == env47678) = true)

theorem identity47678 : scanCanonicalize (H12AffineFastState.compose env47678 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47678 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env47679 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,32768,33031,13340,10281,1025,32769,4113,33,41245,41230,8192,16,2048,46108,45324,10281,1285,33,257,32,46092,41741]

theorem envBound47679 : H12AffineFastState.Bounded env47679 := by
  intro p hp
  have h : env47679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47678_47679 : H12AffineEnvironment.transform 13 5376 env47678 = env47679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47678 == env47679) = true)

theorem identity47679 : scanCanonicalize (H12AffineFastState.compose env47679 (packedSelected [0,2,4,7,9,12] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47679 : packedSelected [0,2,4,7,9,12] rootPS < 2^1333 := by decide +kernel

def env47680 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,0,263,13340,10281,1025,1,4113,33,8477,8462,8192,16,2048,13340,12556,10281,1285,33,257,32,13324,8973]

theorem envBound47680 : H12AffineFastState.Bounded env47680 := by
  intro p hp
  have h : env47680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47679_47680 : H12AffineEnvironment.transform 14 0 env47679 = env47680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47679 == env47680) = true)

theorem identity47680 : scanCanonicalize (H12AffineFastState.compose env47680 (packedSelected [1,8,14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47680 : packedSelected [1,8,14] rootPS < 2^1333 := by decide +kernel

def env47681 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,5157,0,34,13340,10281,1025,1,4113,33,8248,8235,8192,16,2048,13340,12329,10281,1056,33,36,32,13324,8744]

theorem envBound47681 : H12AffineFastState.Bounded env47681 := by
  intro p hp
  have h : env47681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47680_47681 : H12AffineEnvironment.transform 7 37 env47680 = env47681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47680 == env47681) = true)

theorem identity47681 : scanCanonicalize (H12AffineFastState.compose env47681 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47681 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env47682 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5157,0,34,5173,2048,1025,1,4113,33,17,2,41,16,2048,5173,4096,2048,1056,33,36,32,5157,513]

theorem envBound47682 : H12AffineFastState.Bounded env47682 := by
  intro p hp
  have h : env47682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47681_47682 : H12AffineEnvironment.transform 12 41 env47681 = env47682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47681 == env47682) = true)

def env47683 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1045,0,34,1029,2048,1025,1,33,33,17,2,41,16,2048,1029,48,2048,1056,33,36,32,1045,513]

theorem envBound47683 : H12AffineFastState.Bounded env47683 := by
  intro p hp
  have h : env47683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47682_47683 : H12AffineEnvironment.transform 11 48 env47682 = env47683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47682 == env47683) = true)

theorem identity47683 : scanCanonicalize (H12AffineFastState.compose env47683 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound47683 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47684 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,41,1045,0,34,1029,32,1025,1,33,33,17,2,41,16,32,1029,48,32,1056,33,36,32,1045,513]

theorem envBound47684 : H12AffineFastState.Bounded env47684 := by
  intro p hp
  have h : env47684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47683_47684 : H12AffineEnvironment.transform 10 32 env47683 = env47684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env47683 == env47684) = true)

def env47685 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,33,0,34,49,32,53,1,33,33,17,2,41,16,32,49,48,32,20,33,36,32,33,513]

theorem envBound47685 : H12AffineFastState.Bounded env47685 := by
  intro p hp
  have h : env47685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47684_47685 : H12AffineEnvironment.transform 9 52 env47684 = env47685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47684 == env47685) = true)

theorem identity47685 : scanCanonicalize (H12AffineFastState.compose env47685 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound47685 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47686 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,41,33,0,34,49,32,53,1,33,33,17,2,41,16,32,49,48,32,20,33,36,32,33,11]

theorem envBound47686 : H12AffineFastState.Bounded env47686 := by
  intro p hp
  have h : env47686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47685_47686 : H12AffineEnvironment.transform 8 10 env47685 = env47686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env47685 == env47686) = true)

def leafEnv47686 : List Nat := [2,4,8,16,32,17,8,37,10,52,32,48,41,33,0,34,49,32,53,1,33,33,17,2,21,41,1,16,32,49,48,32,20,33,36,32,5,34,33,11,1,33,0]

def active47686 : List Nat := [0,1,2,3,4]

def tree47686 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47686 : H12WitnessSearch.Good tree47686 := H12GlobalWitnessIndex.good

theorem leafIdentity47686 : H12AffineFastState.composeSystem env47686 rootObs = leafEnv47686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47686 rootObs == leafEnv47686) = true)

theorem terminalChecked47686 : H12PackedTerminal.terminalCheckFast leafEnv47686 active47686 tree47686 = true := by decide +kernel

def env47687 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,41,32,0,34,48,32,52,1,33,33,17,2,41,16,32,48,48,32,21,33,36,32,32,513]

theorem envBound47687 : H12AffineFastState.Bounded env47687 := by
  intro p hp
  have h : env47687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47684_47687 : H12AffineEnvironment.transform 9 53 env47684 = env47687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47684 == env47687) = true)

theorem identity47687 : scanCanonicalize (H12AffineFastState.compose env47687 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47687 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47688 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,0,0,2,16,0,20,1,1,1,17,2,9,16,0,16,16,0,21,1,4,0,0,513]

theorem envBound47688 : H12AffineFastState.Bounded env47688 := by
  intro p hp
  have h : env47688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47687_47688 : H12AffineEnvironment.transform 4 0 env47687 = env47688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47687 == env47688) = true)

def leafEnv47688 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,9,0,0,2,16,0,20,1,1,1,17,2,20,9,1,16,0,16,16,0,21,1,4,0,5,2,0,513,1,1,0]

def active47688 : List Nat := [0,1,2,3,8]

def tree47688 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47688 : H12WitnessSearch.Good tree47688 := H12GlobalWitnessIndex.good

theorem leafIdentity47688 : H12AffineFastState.composeSystem env47688 rootObs = leafEnv47688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47688 rootObs == leafEnv47688) = true)

theorem terminalChecked47688 : H12PackedTerminal.terminalCheckFast leafEnv47688 active47688 tree47688 = true := by decide +kernel

def env47689 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1044,0,34,1028,2048,1025,1,32,33,17,2,41,16,2048,1028,49,2048,1056,33,36,32,1044,513]

theorem envBound47689 : H12AffineFastState.Bounded env47689 := by
  intro p hp
  have h : env47689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47682_47689 : H12AffineEnvironment.transform 11 49 env47682 = env47689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env47682 == env47689) = true)

theorem identity47689 : scanCanonicalize (H12AffineFastState.compose env47689 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound47689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47690 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,41,1044,0,34,1028,1045,1025,1,32,33,17,2,41,16,1045,1028,49,1045,1056,33,36,32,1044,513]

theorem envBound47690 : H12AffineFastState.Bounded env47690 := by
  intro p hp
  have h : env47690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47689_47690 : H12AffineEnvironment.transform 10 1045 env47689 = env47690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env47689 == env47690) = true)

def env47691 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,41,32,0,34,48,33,53,1,32,33,17,2,41,16,33,48,49,33,20,33,36,32,32,513]

theorem envBound47691 : H12AffineFastState.Bounded env47691 := by
  intro p hp
  have h : env47691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47690_47691 : H12AffineEnvironment.transform 9 52 env47690 = env47691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47690 == env47691) = true)

theorem identity47691 : scanCanonicalize (H12AffineFastState.compose env47691 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound47691 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47692 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,41,32,0,34,48,33,53,1,32,33,17,2,41,16,33,48,49,33,20,33,36,32,32,10]

theorem envBound47692 : H12AffineFastState.Bounded env47692 := by
  intro p hp
  have h : env47692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47691_47692 : H12AffineEnvironment.transform 8 11 env47691 = env47692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env47691 == env47692) = true)

def leafEnv47692 : List Nat := [2,4,8,16,32,17,8,37,11,52,33,49,41,32,0,34,48,33,53,1,32,33,17,2,21,41,1,16,33,48,49,33,20,33,36,32,5,34,32,10,1,32,0]

def active47692 : List Nat := [0,1,2,3,4]

def tree47692 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47692 : H12WitnessSearch.Good tree47692 := H12GlobalWitnessIndex.good

theorem leafIdentity47692 : H12AffineFastState.composeSystem env47692 rootObs = leafEnv47692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47692 rootObs == leafEnv47692) = true)

theorem terminalChecked47692 : H12PackedTerminal.terminalCheckFast leafEnv47692 active47692 tree47692 = true := by decide +kernel

def env47693 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,41,33,0,34,49,32,52,1,32,33,17,2,41,16,32,49,49,32,21,33,36,32,33,513]

theorem envBound47693 : H12AffineFastState.Bounded env47693 := by
  intro p hp
  have h : env47693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47690_47693 : H12AffineEnvironment.transform 9 53 env47690 = env47693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47690 == env47693) = true)

theorem identity47693 : scanCanonicalize (H12AffineFastState.compose env47693 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47693 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47694 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,0,2,17,0,20,1,0,1,17,2,9,16,0,17,17,0,21,1,4,0,1,513]

theorem envBound47694 : H12AffineFastState.Bounded env47694 := by
  intro p hp
  have h : env47694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47693_47694 : H12AffineEnvironment.transform 4 0 env47693 = env47694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47693 == env47694) = true)

def leafEnv47694 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,1,0,2,17,0,20,1,0,1,17,2,20,9,1,16,0,17,17,0,21,1,4,0,5,2,1,513,1,0,0]

def active47694 : List Nat := [0,1,2,3,8]

def tree47694 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47694 : H12WitnessSearch.Good tree47694 := H12GlobalWitnessIndex.good

theorem leafIdentity47694 : H12AffineFastState.composeSystem env47694 rootObs = leafEnv47694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47694 rootObs == leafEnv47694) = true)

theorem terminalChecked47694 : H12PackedTerminal.terminalCheckFast leafEnv47694 active47694 tree47694 = true := by decide +kernel

def env47695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329761,8328,65,508091,302316,333858,236851,119042,272393,257,98815,90203,63188]

theorem envBound47695 : H12AffineFastState.Bounded env47695 := by
  intro p hp
  have h : env47695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47660_47695 : H12AffineEnvironment.transform 20 4161 env47660 = env47695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47660 == env47695) = true)

theorem identity47695 : scanCanonicalize (H12AffineFastState.compose env47695 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 109046) := by decide +kernel

theorem selectedBound47695 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,109046,1025,32769,4161,21928,62660,41431,8328,65,158029,79130,45524,236851,119042,98815,257,98815,90203,63188]

theorem envBound47696 : H12AffineFastState.Bounded env47696 := by
  intro p hp
  have h : env47696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47695_47696 : H12AffineEnvironment.transform 17 109046 env47695 = env47696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 109046 env47695 == env47696) = true)

theorem identity47696 : scanCanonicalize (H12AffineFastState.compose env47696 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound47696 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env47697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,89379,1025,29908,4161,21928,17,21762,8328,65,158029,79130,17665,223718,75223,95530,257,95530,90203,513]

theorem envBound47697 : H12AffineFastState.Bounded env47697 := by
  intro p hp
  have h : env47697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47696_47697 : H12AffineEnvironment.transform 14 29909 env47696 = env47697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env47696 == env47697) = true)

theorem identity47697 : scanCanonicalize (H12AffineFastState.compose env47697 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 90478) := by decide +kernel

theorem selectedBound47697 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env47698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90478,89379,1025,29908,4161,21928,17,21762,8328,65,67619,79130,17665,2184,75223,95530,257,95530,90203,513]

theorem envBound47698 : H12AffineFastState.Bounded env47698 := by
  intro p hp
  have h : env47698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47697_47698 : H12AffineEnvironment.transform 16 90478 env47697 = env47698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90478 env47697 == env47698) = true)

theorem identity47698 : scanCanonicalize (H12AffineFastState.compose env47698 (packedSelected [0,6,17,27] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound47698 : packedSelected [0,6,17,27] rootPS < 2^1333 := by decide +kernel

def env47699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30083,5357,10400,1025,29908,4161,21928,17,21762,8328,65,32160,16537,17665,2184,20564,169,257,169,5592,513]

theorem envBound47699 : H12AffineFastState.Bounded env47699 := by
  intro p hp
  have h : env47699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47698_47699 : H12AffineEnvironment.transform 15 30083 env47698 = env47699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env47698 == env47699) = true)

theorem identity47699 : scanCanonicalize (H12AffineFastState.compose env47699 (packedSelected [0,1,2,3,4,5,7,8,9,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound47699 : packedSelected [0,1,2,3,4,5,7,8,9,10,17,19] rootPS < 2^1333 := by decide +kernel

def env47700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,0,342,5357,10400,1025,1,4161,8573,17,8663,8328,65,2421,13388,12756,2184,9345,169,257,169,5592,513]

theorem envBound47700 : H12AffineFastState.Bounded env47700 := by
  intro p hp
  have h : env47700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47699_47700 : H12AffineEnvironment.transform 13 13525 env47699 = env47700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env47699 == env47700) = true)

theorem identity47700 : scanCanonicalize (H12AffineFastState.compose env47700 (packedSelected [0,1,3,5,6,7,8,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7301) := by decide +kernel

theorem selectedBound47700 : packedSelected [0,1,3,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env47701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7301,2128,0,342,5357,5157,1025,1,4161,7672,17,7506,7181,65,2421,2249,3409,2184,6148,169,257,169,5592,513]

theorem envBound47701 : H12AffineFastState.Bounded env47701 := by
  intro p hp
  have h : env47701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47700_47701 : H12AffineEnvironment.transform 12 7301 env47700 = env47701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7301 env47700 == env47701) = true)

theorem identity47701 : scanCanonicalize (H12AffineFastState.compose env47701 (packedSelected [2,3,4,5,9,10,11,14,17] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound47701 : packedSelected [2,3,4,5,9,10,11,14,17] rootPS < 2^1333 := by decide +kernel

def env47702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,3433,2128,0,342,1281,1481,1025,1,429,3092,17,3262,3553,65,2421,2249,3409,2184,2536,169,257,169,1076,513]

theorem envBound47702 : H12AffineFastState.Bounded env47702 := by
  intro p hp
  have h : env47702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47701_47702 : H12AffineEnvironment.transform 11 492 env47701 = env47702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env47701 == env47702) = true)

theorem identity47702 : scanCanonicalize (H12AffineFastState.compose env47702 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound47702 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env47703 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,492,2436,2128,0,342,492,292,236,1,429,2297,17,2131,2316,65,2421,2249,2492,2184,2536,169,257,169,217,513]

theorem envBound47703 : H12AffineFastState.Bounded env47703 := by
  intro p hp
  have h : env47703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47702_47703 : H12AffineEnvironment.transform 9 237 env47702 = env47703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env47702 == env47703) = true)

theorem identity47703 : scanCanonicalize (H12AffineFastState.compose env47703 (packedSelected [0,1,3,4,5,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound47703 : packedSelected [0,1,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env47704 : List Nat := [2,4,8,16,32,64,128,253,512,237,2048,17,2169,2128,0,171,17,217,236,1,80,2297,17,2131,2289,65,2184,2249,2113,2184,2069,169,252,169,217,513]

theorem envBound47704 : H12AffineFastState.Bounded env47704 := by
  intro p hp
  have h : env47704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47703_47704 : H12AffineEnvironment.transform 7 253 env47703 = env47704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env47703 == env47704) = true)

theorem identity47704 : scanCanonicalize (H12AffineFastState.compose env47704 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47704 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47705 : List Nat := [2,4,8,16,32,17,128,172,512,188,2048,17,2088,2049,0,171,17,136,189,1,1,2216,17,2050,2208,16,2184,2200,2064,2184,2069,169,173,169,136,513]

theorem envBound47705 : H12AffineFastState.Bounded env47705 := by
  intro p hp
  have h : env47705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47704_47705 : H12AffineEnvironment.transform 5 17 env47704 = env47705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47704 == env47705) = true)

theorem identity47705 : scanCanonicalize (H12AffineFastState.compose env47705 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound47705 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47706 : List Nat := [2,4,8,16,32,17,128,172,512,188,136,17,160,137,0,171,17,136,189,1,1,32,17,138,40,16,0,16,152,0,157,169,173,169,136,513]

theorem envBound47706 : H12AffineFastState.Bounded env47706 := by
  intro p hp
  have h : env47706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47705_47706 : H12AffineEnvironment.transform 10 136 env47705 = env47706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env47705 == env47706) = true)

def env47707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2115049,2444659,2431073,8328,65,2609403,302317,333858,2329970,119043,2373705,257,2199999,2191387,63189]

theorem envBound47707 : H12AffineFastState.Bounded env47707 := by
  intro p hp
  have h : env47707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47659_47707 : H12AffineEnvironment.transform 23 2431073 env47659 = env47707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2431073 env47659 == env47707) = true)

def env47708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,21929,351539,329761,8328,65,508091,302317,333858,236850,119043,272393,257,98815,90203,63189]

theorem envBound47708 : H12AffineFastState.Bounded env47708 := by
  intro p hp
  have h : env47708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47707_47708 : H12AffineEnvironment.transform 20 4160 env47707 = env47708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47707 == env47708) = true)

theorem identity47708 : scanCanonicalize (H12AffineFastState.compose env47708 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound47708 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89378,1025,32769,4160,21929,17,21763,8328,65,171417,115151,17664,236850,119043,95531,257,98815,90203,63189]

theorem envBound47709 : H12AffineFastState.Bounded env47709 := by
  intro p hp
  have h : env47709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47708_47709 : H12AffineEnvironment.transform 17 89378 env47708 = env47709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env47708 == env47709) = true)

theorem identity47709 : scanCanonicalize (H12AffineFastState.compose env47709 (packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 32939) := by decide +kernel

theorem selectedBound47709 : packedSelected [1,2,3,10,12,14,15,17,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env47710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,32939,131072,56713,1025,32769,4160,21929,17,21763,8328,65,171417,16740,17664,138649,20904,62848,257,340,57584,63189]

theorem envBound47710 : H12AffineFastState.Bounded env47710 := by
  intro p hp
  have h : env47710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47709_47710 : H12AffineEnvironment.transform 15 32939 env47709 = env47710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32939 env47709 == env47710) = true)

def env47711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,32803,131072,56577,1025,32769,4160,21793,17,21763,8192,65,171281,16740,17664,138513,20768,62728,257,340,57464,63069]

theorem envBound47711 : H12AffineFastState.Bounded env47711 := by
  intro p hp
  have h : env47711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47710_47711 : H12AffineEnvironment.transform 6 8 env47710 = env47711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47710 == env47711) = true)

theorem identity47711 : scanCanonicalize (H12AffineFastState.compose env47711 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound47711 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env47712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,29823,131072,10589,1025,29789,4160,21793,17,21763,8192,65,158029,16740,17664,138513,20768,340,257,340,5156,513]

theorem envBound47712 : H12AffineFastState.Bounded env47712 := by
  intro p hp
  have h : env47712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47711_47712 : H12AffineEnvironment.transform 14 29788 env47711 = env47712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env47711 == env47712) = true)

theorem identity47712 : scanCanonicalize (H12AffineFastState.compose env47712 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound47712 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env47713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8233,8202,131072,10589,1025,8232,4160,340,17,374,8192,65,146744,5393,4469,138513,1365,340,257,340,5156,513]

theorem envBound47713 : H12AffineFastState.Bounded env47713 := by
  intro p hp
  have h : env47713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47712_47713 : H12AffineEnvironment.transform 13 5237 env47712 = env47713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env47712 == env47713) = true)

theorem identity47713 : scanCanonicalize (H12AffineFastState.compose env47713 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47713 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,0,35,131072,2420,1025,1,4160,340,17,374,41,65,138513,5393,4469,138513,1365,340,257,340,5156,513]

theorem envBound47714 : H12AffineFastState.Bounded env47714 := by
  intro p hp
  have h : env47714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47713_47714 : H12AffineEnvironment.transform 12 41 env47713 = env47714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47713 == env47714) = true)

theorem identity47714 : scanCanonicalize (H12AffineFastState.compose env47714 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound47714 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,0,35,5221,2420,1025,1,4160,340,17,374,41,65,2420,5393,4469,2420,1365,340,257,340,5156,513]

theorem envBound47715 : H12AffineFastState.Bounded env47715 := by
  intro p hp
  have h : env47715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47714_47715 : H12AffineEnvironment.transform 16 5221 env47714 = env47715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env47714 == env47715) = true)

theorem identity47715 : scanCanonicalize (H12AffineFastState.compose env47715 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 622) := by decide +kernel

theorem selectedBound47715 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env47716 : List Nat := [2,4,8,16,32,64,8,256,512,622,2048,4096,41,4635,0,35,4619,2420,623,1,4160,340,17,374,41,65,2420,4991,4469,2420,827,340,257,340,4682,513]

theorem envBound47716 : H12AffineFastState.Bounded env47716 := by
  intro p hp
  have h : env47716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47715_47716 : H12AffineEnvironment.transform 9 622 env47715 = env47716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 622 env47715 == env47716) = true)

theorem identity47716 : scanCanonicalize (H12AffineFastState.compose env47716 (packedSelected [5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound47716 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env47717 : List Nat := [2,4,8,16,32,64,8,256,512,622,293,4096,41,4635,0,35,4619,81,623,1,4160,340,17,374,41,65,81,4991,4469,81,827,340,257,340,4682,513]

theorem envBound47717 : H12AffineFastState.Bounded env47717 := by
  intro p hp
  have h : env47717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47716_47717 : H12AffineEnvironment.transform 10 293 env47716 = env47717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env47716 == env47717) = true)

theorem identity47717 : scanCanonicalize (H12AffineFastState.compose env47717 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47717 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env47718 : List Nat := [2,4,8,16,32,64,8,117,512,622,80,4096,41,4635,0,35,4619,81,623,1,4160,33,17,3,41,65,81,4618,4096,81,590,33,116,33,4682,513]

theorem envBound47718 : H12AffineFastState.Bounded env47718 := by
  intro p hp
  have h : env47718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47717_47718 : H12AffineEnvironment.transform 7 117 env47717 = env47718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47717 == env47718) = true)

theorem identity47718 : scanCanonicalize (H12AffineFastState.compose env47718 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound47718 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47719 : List Nat := [2,4,8,16,32,64,8,117,512,622,80,17,41,522,0,35,538,81,623,1,81,33,17,3,41,65,81,539,17,81,590,33,116,33,603,513]

theorem envBound47719 : H12AffineFastState.Bounded env47719 := by
  intro p hp
  have h : env47719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47718_47719 : H12AffineEnvironment.transform 11 17 env47718 = env47719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47718 == env47719) = true)

theorem identity47719 : scanCanonicalize (H12AffineFastState.compose env47719 (packedSelected [0,1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47719 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env47720 : List Nat := [2,3,8,16,32,64,8,114,512,617,80,17,41,522,0,35,538,81,616,1,81,33,17,3,41,65,81,539,17,81,585,33,115,33,603,513]

theorem envBound47720 : H12AffineFastState.Bounded env47720 := by
  intro p hp
  have h : env47720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47719_47720 : H12AffineEnvironment.transform 1 3 env47719 = env47720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47719 == env47720) = true)

theorem identity47720 : scanCanonicalize (H12AffineFastState.compose env47720 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47720 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env47721 : List Nat := [2,3,8,16,32,64,8,114,43,66,80,17,41,33,0,35,49,81,67,1,81,33,17,3,41,65,81,48,17,81,98,33,115,33,112,42]

theorem envBound47721 : H12AffineFastState.Bounded env47721 := by
  intro p hp
  have h : env47721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47720_47721 : H12AffineEnvironment.transform 8 43 env47720 = env47721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47720 == env47721) = true)

theorem identity47721 : scanCanonicalize (H12AffineFastState.compose env47721 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound47721 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47722 : List Nat := [2,3,8,16,2,64,8,80,9,66,80,17,11,3,0,1,19,81,67,1,81,3,17,3,11,65,81,18,17,81,64,3,81,3,82,8]

theorem envBound47722 : H12AffineFastState.Bounded env47722 := by
  intro p hp
  have h : env47722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47721_47722 : H12AffineEnvironment.transform 4 2 env47721 = env47722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env47721 == env47722) = true)

def env47723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32802,131072,56576,1025,32769,4160,21792,17,21763,8193,65,171280,16740,17664,138512,20769,62729,257,340,57465,63068]

theorem envBound47723 : H12AffineFastState.Bounded env47723 := by
  intro p hp
  have h : env47723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47710_47723 : H12AffineEnvironment.transform 6 9 env47710 = env47723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47710 == env47723) = true)

theorem identity47723 : scanCanonicalize (H12AffineFastState.compose env47723 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47723 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8575,131072,31837,1025,8540,4160,21792,17,21763,8193,65,146509,16740,17664,138512,20769,21588,257,340,16676,22273]

theorem envBound47724 : H12AffineFastState.Bounded env47724 := by
  intro p hp
  have h : env47724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47723_47724 : H12AffineEnvironment.transform 14 8541 env47723 = env47724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47723 == env47724) = true)

theorem identity47724 : scanCanonicalize (H12AffineFastState.compose env47724 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 16740) := by decide +kernel

theorem selectedBound47724 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env47725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8575,16740,31837,1025,8540,4160,21792,17,21763,8193,65,32041,16740,17664,23668,20769,21588,257,340,16676,22273]

theorem envBound47725 : H12AffineFastState.Bounded env47725 := by
  intro p hp
  have h : env47725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47724_47725 : H12AffineEnvironment.transform 16 16740 env47724 = env47725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16740 env47724 == env47725) = true)

theorem identity47725 : scanCanonicalize (H12AffineFastState.compose env47725 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound47725 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8575,5220,10589,1025,8540,4160,32,17,3,8193,65,10281,5220,4096,2420,1057,340,257,340,5156,513]

theorem envBound47726 : H12AffineFastState.Bounded env47726 := by
  intro p hp
  have h : env47726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47725_47726 : H12AffineEnvironment.transform 13 5376 env47725 = env47726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env47725 == env47726) = true)

theorem identity47726 : scanCanonicalize (H12AffineFastState.compose env47726 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound47726 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,35,5220,2049,1025,0,4160,32,17,3,349,65,2421,5220,4096,2420,1057,340,257,340,5156,513]

theorem envBound47727 : H12AffineFastState.Bounded env47727 := by
  intro p hp
  have h : env47727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47726_47727 : H12AffineEnvironment.transform 12 348 env47726 = env47727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env47726 == env47727) = true)

theorem identity47727 : scanCanonicalize (H12AffineFastState.compose env47727 (packedSelected [0,1,6,7,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound47727 : packedSelected [0,1,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,17,348,1297,1,35,1141,2049,1025,0,81,32,17,3,349,65,2421,1141,17,2420,1057,340,257,340,1077,513]

theorem envBound47728 : H12AffineFastState.Bounded env47728 := by
  intro p hp
  have h : env47728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47727_47728 : H12AffineEnvironment.transform 11 17 env47727 = env47728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env47727 == env47728) = true)

theorem identity47728 : scanCanonicalize (H12AffineFastState.compose env47728 (packedSelected [1,2,4,7,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound47728 : packedSelected [1,2,4,7,8,10] rootPS < 2^1333 := by decide +kernel

def env47729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,17,348,1297,1,35,1141,372,1025,0,81,32,17,3,349,65,0,1141,17,1,1057,340,257,340,1077,513]

theorem envBound47729 : H12AffineFastState.Bounded env47729 := by
  intro p hp
  have h : env47729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47728_47729 : H12AffineEnvironment.transform 10 373 env47728 = env47729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env47728 == env47729) = true)

theorem identity47729 : scanCanonicalize (H12AffineFastState.compose env47729 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound47729 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env47730 : List Nat := [2,4,8,16,32,64,9,256,512,53,373,17,348,292,1,35,64,372,52,0,81,32,17,3,349,65,0,64,17,1,20,340,257,340,0,513]

theorem envBound47730 : H12AffineFastState.Bounded env47730 := by
  intro p hp
  have h : env47730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47729_47730 : H12AffineEnvironment.transform 9 53 env47729 = env47730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env47729 == env47730) = true)

theorem identity47730 : scanCanonicalize (H12AffineFastState.compose env47730 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47730 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47731 : List Nat := [2,4,8,16,32,17,9,256,512,53,292,17,269,292,1,35,17,293,52,0,0,32,17,3,268,16,0,17,17,1,20,261,257,261,0,513]

theorem envBound47731 : H12AffineFastState.Bounded env47731 := by
  intro p hp
  have h : env47731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47730_47731 : H12AffineEnvironment.transform 5 17 env47730 = env47731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47730 == env47731) = true)

theorem identity47731 : scanCanonicalize (H12AffineFastState.compose env47731 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound47731 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env47732 : List Nat := [2,4,8,16,32,17,9,256,261,53,292,17,269,292,1,35,17,293,52,0,0,32,17,3,268,16,0,17,17,1,20,261,257,261,0,260]

theorem envBound47732 : H12AffineFastState.Bounded env47732 := by
  intro p hp
  have h : env47732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47731_47732 : H12AffineEnvironment.transform 8 261 env47731 = env47732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env47731 == env47732) = true)

theorem identity47732 : scanCanonicalize (H12AffineFastState.compose env47732 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47732 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47733 : List Nat := [2,4,8,16,32,17,9,37,32,53,1,17,40,1,1,35,17,0,52,0,0,32,17,3,41,16,0,17,17,1,20,32,36,32,0,33]

theorem envBound47733 : H12AffineFastState.Bounded env47733 := by
  intro p hp
  have h : env47733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47732_47733 : H12AffineEnvironment.transform 7 37 env47732 = env47733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47732 == env47733) = true)

def env47734 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,21928,351538,329760,8328,65,508090,302317,333858,236851,119043,272392,257,98814,90202,63189]

theorem envBound47734 : H12AffineFastState.Bounded env47734 := by
  intro p hp
  have h : env47734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47707_47734 : H12AffineEnvironment.transform 20 4161 env47707 = env47734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47707 == env47734) = true)

theorem identity47734 : scanCanonicalize (H12AffineFastState.compose env47734 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47734 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,21928,294201,272427,8328,65,450737,302317,276521,179512,61704,272392,257,41461,16465,63189]

theorem envBound47735 : H12AffineFastState.Bounded env47735 := by
  intro p hp
  have h : env47735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47734_47735 : H12AffineEnvironment.transform 15 8203 env47734 = env47735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47734 == env47735) = true)

def env47736 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,21792,294201,272427,8192,65,450617,302181,276521,179512,61704,272392,257,41341,16465,63069]

theorem envBound47736 : H12AffineFastState.Bounded env47736 := by
  intro p hp
  have h : env47736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47735_47736 : H12AffineEnvironment.transform 6 8 env47735 = env47736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47735 == env47736) = true)

theorem identity47736 : scanCanonicalize (H12AffineFastState.compose env47736 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound47736 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env47737 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8203,131072,262144,1025,29789,4161,21792,294201,272427,8192,65,398437,288825,276521,149860,1364,272392,257,21793,16465,513]

theorem envBound47737 : H12AffineFastState.Bounded env47737 := by
  intro p hp
  have h : env47737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47736_47737 : H12AffineEnvironment.transform 14 29788 env47736 = env47737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env47736 == env47737) = true)

theorem identity47737 : scanCanonicalize (H12AffineFastState.compose env47737 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47737 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env47738 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29709,8203,131072,262144,1025,29708,4112,21792,294201,272427,8192,16,398388,288825,276521,149813,1285,272392,257,21793,16384,513]

theorem envBound47738 : H12AffineFastState.Bounded env47738 := by
  intro p hp
  have h : env47738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47737_47738 : H12AffineEnvironment.transform 5 17 env47737 = env47738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47737 == env47738) = true)

theorem identity47738 : scanCanonicalize (H12AffineFastState.compose env47738 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47738 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env47739 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,131072,262144,1025,8461,4112,33,272440,272427,8192,16,398388,277816,276521,138292,1285,272392,257,32,5377,513]

theorem envBound47739 : H12AffineFastState.Bounded env47739 := by
  intro p hp
  have h : env47739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47738_47739 : H12AffineEnvironment.transform 13 5377 env47738 = env47739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47738 == env47739) = true)

theorem identity47739 : scanCanonicalize (H12AffineFastState.compose env47739 (packedSelected [0,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound47739 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env47740 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,13341,262144,1025,8461,4112,33,272440,272427,8192,16,270377,277816,276521,10281,1285,272392,257,32,5377,513]

theorem envBound47740 : H12AffineFastState.Bounded env47740 := by
  intro p hp
  have h : env47740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47739_47740 : H12AffineEnvironment.transform 16 13341 env47739 = env47740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env47739 == env47740) = true)

theorem identity47740 : scanCanonicalize (H12AffineFastState.compose env47740 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47740 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47741 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,0,263,5393,262144,1025,1,4112,33,264500,264487,268,16,262437,269364,268581,2341,1285,264452,257,32,5377,513]

theorem envBound47741 : H12AffineFastState.Bounded env47741 := by
  intro p hp
  have h : env47741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47740_47741 : H12AffineEnvironment.transform 12 268 env47740 = env47741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47740 == env47741) = true)

theorem identity47741 : scanCanonicalize (H12AffineFastState.compose env47741 (packedSelected [0,1,4,5,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47741 : packedSelected [0,1,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env47742 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,0,35,5173,262144,1025,1,4112,33,264208,264195,40,16,262145,269364,268289,2049,1057,264224,37,32,5157,513]

theorem envBound47742 : H12AffineFastState.Bounded env47742 := by
  intro p hp
  have h : env47742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47741_47742 : H12AffineEnvironment.transform 7 36 env47741 = env47742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47741 == env47742) = true)

theorem identity47742 : scanCanonicalize (H12AffineFastState.compose env47742 (packedSelected [0,3,4,5,7,9,15] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound47742 : packedSelected [0,3,4,5,7,9,15] rootPS < 2^1333 := by decide +kernel

def env47743 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,40,5157,0,35,5173,2049,1025,1,4112,33,17,2,40,16,2048,5173,4096,2049,1057,33,37,32,5157,513]

theorem envBound47743 : H12AffineFastState.Bounded env47743 := by
  intro p hp
  have h : env47743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47742_47743 : H12AffineEnvironment.transform 17 2049 env47742 = env47743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env47742 == env47743) = true)

def env47744 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4161,21793,294201,272427,8193,65,450616,302180,276521,179512,61704,272392,257,41340,16465,63068]

theorem envBound47744 : H12AffineFastState.Bounded env47744 := by
  intro p hp
  have h : env47744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47735_47744 : H12AffineEnvironment.transform 6 9 env47735 = env47744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47735 == env47744) = true)

theorem identity47744 : scanCanonicalize (H12AffineFastState.compose env47744 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound47744 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env47745 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4161,21793,294201,272427,8193,65,303144,302180,276521,64808,61704,272392,257,41340,16465,63068]

theorem envBound47745 : H12AffineFastState.Bounded env47745 := by
  intro p hp
  have h : env47745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47744_47745 : H12AffineEnvironment.transform 16 16400 env47744 = env47745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env47744 == env47745) = true)

theorem identity47745 : scanCanonicalize (H12AffineFastState.compose env47745 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound47745 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,16400,262144,1025,29788,4161,21793,294201,272427,8193,65,283765,288825,276521,2421,1365,272392,257,21793,16465,513]

theorem envBound47746 : H12AffineFastState.Bounded env47746 := by
  intro p hp
  have h : env47746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47745_47746 : H12AffineEnvironment.transform 14 29789 env47745 = env47746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env47745 == env47746) = true)

theorem identity47746 : scanCanonicalize (H12AffineFastState.compose env47746 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound47746 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env47747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4453,9528,8203,4469,262144,1025,9529,4161,1092,273500,272427,8193,65,263440,276828,276521,2421,1365,272392,257,1092,4404,513]

theorem envBound47747 : H12AffineFastState.Bounded env47747 := by
  intro p hp
  have h : env47747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47746_47747 : H12AffineEnvironment.transform 13 4453 env47746 = env47747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env47746 == env47747) = true)

theorem identity47747 : scanCanonicalize (H12AffineFastState.compose env47747 (packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound47747 : packedSelected [2,3,4,5,6,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env47748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4453,9528,8203,4469,10589,1025,9529,4161,1092,1281,374,8193,65,11341,4097,4468,2421,1365,341,257,1092,4404,513]

theorem envBound47748 : H12AffineFastState.Bounded env47748 := by
  intro p hp
  have h : env47748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47747_47748 : H12AffineEnvironment.transform 17 10589 env47747 = env47748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env47747 == env47748) = true)

theorem identity47748 : scanCanonicalize (H12AffineFastState.compose env47748 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound47748 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47749 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4453,8232,8203,4469,10589,273,8233,4161,340,17,374,8193,65,10589,4097,4468,2421,69,341,257,340,4404,513]

theorem envBound47749 : H12AffineFastState.Bounded env47749 := by
  intro p hp
  have h : env47749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47748_47749 : H12AffineEnvironment.transform 9 272 env47748 = env47749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env47748 == env47749) = true)

theorem identity47749 : scanCanonicalize (H12AffineFastState.compose env47749 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound47749 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env47750 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,40,4453,0,35,4469,2421,273,1,4161,340,17,374,41,65,2421,4097,4468,2421,69,341,257,340,4404,513]

theorem envBound47750 : H12AffineFastState.Bounded env47750 := by
  intro p hp
  have h : env47750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47749_47750 : H12AffineEnvironment.transform 12 40 env47749 = env47750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env47749 == env47750) = true)

theorem identity47750 : scanCanonicalize (H12AffineFastState.compose env47750 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47750 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47751 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,40,4405,0,35,4389,2341,273,1,4113,260,17,294,41,17,2341,4097,4388,2341,21,261,257,260,4404,513]

theorem envBound47751 : H12AffineFastState.Bounded env47751 := by
  intro p hp
  have h : env47751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47750_47751 : H12AffineEnvironment.transform 5 16 env47750 = env47751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47750 == env47751) = true)

theorem identity47751 : scanCanonicalize (H12AffineFastState.compose env47751 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47751 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47752 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4112,0,35,4096,2048,52,1,4113,33,17,3,41,17,2048,4097,4097,2048,21,32,36,33,4113,513]

theorem envBound47752 : H12AffineFastState.Bounded env47752 := by
  intro p hp
  have h : env47752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47751_47752 : H12AffineEnvironment.transform 7 37 env47751 = env47752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47751 == env47752) = true)

theorem identity47752 : scanCanonicalize (H12AffineFastState.compose env47752 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound47752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47753 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2609,40,2593,0,35,2609,2048,52,1,2592,33,17,3,41,17,2048,2608,2608,2048,21,32,36,33,2592,513]

theorem envBound47753 : H12AffineFastState.Bounded env47753 := by
  intro p hp
  have h : env47753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47752_47753 : H12AffineEnvironment.transform 11 2609 env47752 = env47753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env47752 == env47753) = true)

theorem identity47753 : scanCanonicalize (H12AffineFastState.compose env47753 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound47753 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47754 : List Nat := [2,4,8,16,32,16,9,37,512,53,513,48,40,32,0,35,48,513,52,1,33,33,17,3,41,17,513,49,49,513,21,32,36,33,33,513]

theorem envBound47754 : H12AffineFastState.Bounded env47754 := by
  intro p hp
  have h : env47754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47753_47754 : H12AffineEnvironment.transform 10 513 env47753 = env47754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env47753 == env47754) = true)

def env47755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound47755 : H12AffineFastState.Bounded env47755 := by
  intro p hp
  have h : env47755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44619_47755 : H12AffineEnvironment.transform 31 145662401 env44619 = env47755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env44619 == env47755) = true)

def env47756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound47756 : H12AffineFastState.Bounded env47756 := by
  intro p hp
  have h : env47756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47755_47756 : H12AffineEnvironment.transform 29 155254784 env47755 = env47756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env47755 == env47756) = true)

def env47757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound47757 : H12AffineFastState.Bounded env47757 := by
  intro p hp
  have h : env47757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47756_47757 : H12AffineEnvironment.transform 25 64 env47756 = env47757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env47756 == env47757) = true)

def env47758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound47758 : H12AffineFastState.Bounded env47758 := by
  intro p hp
  have h : env47758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47757_47758 : H12AffineEnvironment.transform 26 30393344 env47757 = env47758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env47757 == env47758) = true)

def env47759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound47759 : H12AffineFastState.Bounded env47759 := by
  intro p hp
  have h : env47759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47758_47759 : H12AffineEnvironment.transform 18 1024 env47758 = env47759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env47758 == env47759) = true)

theorem identity47759 : scanCanonicalize (H12AffineFastState.compose env47759 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound47759 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env47760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,16777216,8328,64,29868032,16835014,8466459,8830976,25265168,20971658,256,25207271,25182274,25207750]

theorem envBound47760 : H12AffineFastState.Bounded env47760 := by
  intro p hp
  have h : env47760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47759_47760 : H12AffineEnvironment.transform 20 91467 env47759 = env47760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env47759 == env47760) = true)

def env47761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120028,8328,64,12981468,79130,8466459,8830976,8409292,4314198,256,8484155,8492190,8484634]

theorem envBound47761 : H12AffineFastState.Bounded env47761 := by
  intro p hp
  have h : env47761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47760_47761 : H12AffineEnvironment.transform 23 120028 env47760 = env47761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120028 env47760 == env47761) = true)

def env47762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98644,8328,64,12981468,79130,8466459,8820104,8389956,4293086,256,8462515,8492190,8462994]

theorem envBound47762 : H12AffineFastState.Bounded env47762 := by
  intro p hp
  have h : env47762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47761_47762 : H12AffineEnvironment.transform 13 5512 env47761 = env47762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env47761 == env47762) = true)

def env47763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98644,8328,64,8787196,79130,8466459,8820104,8389956,98814,256,8462515,8492190,8462994]

theorem envBound47763 : H12AffineFastState.Bounded env47763 := by
  intro p hp
  have h : env47763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47762_47763 : H12AffineEnvironment.transform 21 32 env47762 = env47763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env47762 == env47763) = true)

theorem identity47763 : scanCanonicalize (H12AffineFastState.compose env47763 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47763 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,8388608,98644,8192,64,8787060,79130,8466459,8819968,8389956,98678,256,8462395,8492054,8462874]

theorem envBound47764 : H12AffineFastState.Bounded env47764 := by
  intro p hp
  have h : env47764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47763_47764 : H12AffineEnvironment.transform 6 8 env47763 = env47764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47763 == env47764) = true)

def env47765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,16,98644,8192,64,398436,79130,77835,431376,1364,98678,256,73771,103430,74250]

theorem envBound47765 : H12AffineFastState.Bounded env47765 := by
  intro p hp
  have h : env47765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47764_47765 : H12AffineEnvironment.transform 22 16 env47764 = env47765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env47764 == env47765) = true)

theorem identity47765 : scanCanonicalize (H12AffineFastState.compose env47765 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47765 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env47766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,32,16,41311,8192,64,398436,5393,4096,431376,1364,41341,256,32,46093,513]

theorem envBound47766 : H12AffineFastState.Bounded env47766 := by
  intro p hp
  have h : env47766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47765_47766 : H12AffineEnvironment.transform 15 8203 env47765 = env47766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47765 == env47766) = true)

theorem identity47766 : scanCanonicalize (H12AffineFastState.compose env47766 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47766 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env47767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,32,16,2,8192,64,398436,5393,4096,406605,1364,32,256,32,5456,513]

theorem envBound47767 : H12AffineFastState.Bounded env47767 := by
  intro p hp
  have h : env47767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47766_47767 : H12AffineEnvironment.transform 14 8541 env47766 = env47767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47766 == env47767) = true)

theorem identity47767 : scanCanonicalize (H12AffineFastState.compose env47767 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound47767 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,10360,1024,8540,4160,32,16,2,8192,64,146460,5393,4096,138293,1364,32,256,32,5456,513]

theorem envBound47768 : H12AffineFastState.Bounded env47768 := by
  intro p hp
  have h : env47768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47767_47768 : H12AffineEnvironment.transform 17 10360 env47767 = env47768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env47767 == env47768) = true)

def env47769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,32,17,98644,8192,64,398437,79130,77834,431377,1365,98678,256,73770,103431,74251]

theorem envBound47769 : H12AffineFastState.Bounded env47769 := by
  intro p hp
  have h : env47769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47764_47769 : H12AffineEnvironment.transform 22 17 env47764 = env47769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env47764 == env47769) = true)

theorem identity47769 : scanCanonicalize (H12AffineFastState.compose env47769 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound47769 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,77899,32,17,98644,8192,64,146509,79130,77834,179513,1365,98678,256,73770,103431,74251]

theorem envBound47770 : H12AffineFastState.Bounded env47770 := by
  intro p hp
  have h : env47770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47769_47770 : H12AffineEnvironment.transform 17 10280 env47769 = env47770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env47769 == env47770) = true)

def env47771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,8388608,98644,8328,64,8787197,79130,8466459,8820104,8389956,98815,256,8462515,8492190,8462994]

theorem envBound47771 : H12AffineFastState.Bounded env47771 := by
  intro p hp
  have h : env47771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47762_47771 : H12AffineEnvironment.transform 21 33 env47762 = env47771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47762 == env47771) = true)

theorem identity47771 : scanCanonicalize (H12AffineFastState.compose env47771 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound47771 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,33,152,98644,8328,64,398437,79130,77955,431376,1500,98815,256,73771,103430,74250]

theorem envBound47772 : H12AffineFastState.Bounded env47772 := by
  intro p hp
  have h : env47772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47771_47772 : H12AffineEnvironment.transform 22 152 env47771 = env47772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env47771 == env47772) = true)

def env47773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,77899,33,16,98644,8192,64,398437,79130,77835,431376,1364,98679,256,73771,103430,74250]

theorem envBound47773 : H12AffineFastState.Bounded env47773 := by
  intro p hp
  have h : env47773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47772_47773 : H12AffineEnvironment.transform 6 8 env47772 = env47773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47772 == env47773) = true)

theorem identity47773 : scanCanonicalize (H12AffineFastState.compose env47773 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47773 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env47774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,131072,262144,1024,32769,4160,33,16,41311,8192,64,398437,5393,4096,431376,1364,41340,256,32,46093,513]

theorem envBound47774 : H12AffineFastState.Bounded env47774 := by
  intro p hp
  have h : env47774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47773_47774 : H12AffineEnvironment.transform 15 8203 env47773 = env47774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47773 == env47774) = true)

theorem identity47774 : scanCanonicalize (H12AffineFastState.compose env47774 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47774 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env47775 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,262144,1024,8540,4160,33,16,2,8192,64,398437,5393,4096,406605,1364,33,256,32,5456,513]

theorem envBound47775 : H12AffineFastState.Bounded env47775 := by
  intro p hp
  have h : env47775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47774_47775 : H12AffineEnvironment.transform 14 8541 env47774 = env47775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47774 == env47775) = true)

theorem identity47775 : scanCanonicalize (H12AffineFastState.compose env47775 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound47775 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47776 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,131072,10360,1024,8540,4160,33,16,2,8192,64,146461,5393,4096,138293,1364,33,256,32,5456,513]

theorem envBound47776 : H12AffineFastState.Bounded env47776 := by
  intro p hp
  have h : env47776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47775_47776 : H12AffineEnvironment.transform 17 10360 env47775 = env47776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env47775 == env47776) = true)

theorem identity47776 : scanCanonicalize (H12AffineFastState.compose env47776 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound47776 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47777 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8541,8203,13389,10360,1024,8540,4160,33,16,2,8192,64,2128,5393,4096,10360,1364,33,256,32,5456,513]

theorem envBound47777 : H12AffineFastState.Bounded env47777 := by
  intro p hp
  have h : env47777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47776_47777 : H12AffineEnvironment.transform 16 13389 env47776 = env47777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env47776 == env47777) = true)

theorem identity47777 : scanCanonicalize (H12AffineFastState.compose env47777 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47777 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,263,5441,2420,1024,80,4160,33,16,2,268,64,2128,5393,4096,2420,1364,33,256,32,5456,513]

theorem envBound47778 : H12AffineFastState.Bounded env47778 := by
  intro p hp
  have h : env47778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47777_47778 : H12AffineEnvironment.transform 12 268 env47777 = env47778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47777 == env47778) = true)

theorem identity47778 : scanCanonicalize (H12AffineFastState.compose env47778 (packedSelected [1,2,3,5,8,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47778 : packedSelected [1,2,3,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env47779 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,5157,81,34,5220,2129,1024,80,4160,33,16,2,41,64,2128,5172,4096,2129,1137,33,37,32,5237,513]

theorem envBound47779 : H12AffineFastState.Bounded env47779 := by
  intro p hp
  have h : env47779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47778_47779 : H12AffineEnvironment.transform 7 37 env47778 = env47779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47778 == env47779) = true)

theorem identity47779 : scanCanonicalize (H12AffineFastState.compose env47779 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47779 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47780 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,1,34,5172,2049,1024,0,4112,33,16,2,41,16,2048,5172,4096,2049,1057,33,37,32,5157,513]

theorem envBound47780 : H12AffineFastState.Bounded env47780 := by
  intro p hp
  have h : env47780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47779_47780 : H12AffineEnvironment.transform 5 16 env47779 = env47780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47779 == env47780) = true)

def env47781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,77898,33,17,98644,8193,64,398437,79130,77834,431376,1365,98678,256,73771,103430,74250]

theorem envBound47781 : H12AffineFastState.Bounded env47781 := by
  intro p hp
  have h : env47781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47772_47781 : H12AffineEnvironment.transform 6 9 env47772 = env47781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47772 == env47781) = true)

theorem identity47781 : scanCanonicalize (H12AffineFastState.compose env47781 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound47781 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35188,1024,32769,77898,33,17,98644,8193,64,171281,79130,77834,138340,1365,98678,256,73771,103430,74250]

theorem envBound47782 : H12AffineFastState.Bounded env47782 := by
  intro p hp
  have h : env47782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47781_47782 : H12AffineEnvironment.transform 17 35188 env47781 = env47782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env47781 == env47782) = true)

theorem identity47782 : scanCanonicalize (H12AffineFastState.compose env47782 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound47782 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5392,35188,1024,32769,77898,33,17,98644,8193,64,34817,79130,77834,2420,1365,98678,256,73771,103430,74250]

theorem envBound47783 : H12AffineFastState.Bounded env47783 := by
  intro p hp
  have h : env47783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47782_47783 : H12AffineEnvironment.transform 16 5392 env47782 = env47783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env47782 == env47783) = true)

def env47784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,4194304,8388608,98645,8328,64,12981468,79130,8466459,8820105,8389957,4293087,256,8462514,8492190,8462995]

theorem envBound47784 : H12AffineFastState.Bounded env47784 := by
  intro p hp
  have h : env47784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47761_47784 : H12AffineEnvironment.transform 13 5513 env47761 = env47784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env47761 == env47784) = true)

def env47785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,32,8388608,98645,8328,64,8787196,79130,8466459,8820105,8389957,98815,256,8462514,8492190,8462995]

theorem envBound47785 : H12AffineFastState.Bounded env47785 := by
  intro p hp
  have h : env47785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47784_47785 : H12AffineEnvironment.transform 21 32 env47784 = env47785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env47784 == env47785) = true)

theorem identity47785 : scanCanonicalize (H12AffineFastState.compose env47785 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47785 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,262144,1024,8540,78018,32,8388608,73736,8328,64,8787196,79130,8466459,8795348,8389957,73890,256,8462514,8467907,8462995]

theorem envBound47786 : H12AffineFastState.Bounded env47786 := by
  intro p hp
  have h : env47786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47785_47786 : H12AffineEnvironment.transform 14 8541 env47785 = env47786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47785 == env47786) = true)

def env47787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10400,1024,8540,78018,32,8388608,73736,8328,64,8535132,79130,8466459,8526964,8389957,73890,256,8462514,8467907,8462995]

theorem envBound47787 : H12AffineFastState.Bounded env47787 := by
  intro p hp
  have h : env47787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47786_47787 : H12AffineEnvironment.transform 17 10400 env47786 = env47787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47786 == env47787) = true)

def env47788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10400,1024,8540,78018,32,136584,73736,8328,64,10708,79130,206227,2556,135373,73890,256,210234,204875,210715]

theorem envBound47788 : H12AffineFastState.Bounded env47788 := by
  intro p hp
  have h : env47788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47787_47788 : H12AffineEnvironment.transform 22 136584 env47787 = env47788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136584 env47787 == env47788) = true)

theorem identity47788 : scanCanonicalize (H12AffineFastState.compose env47788 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound47788 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env47789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,5393,10400,1024,8540,78018,32,153,73736,8328,64,10708,79130,77954,2556,1500,73890,256,73771,79194,74250]

theorem envBound47789 : H12AffineFastState.Bounded env47789 := by
  intro p hp
  have h : env47789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47788_47789 : H12AffineEnvironment.transform 16 5393 env47788 = env47789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env47788 == env47789) = true)

theorem identity47789 : scanCanonicalize (H12AffineFastState.compose env47789 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47789 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env47790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,8203,5393,10400,1024,8540,4297,32,153,3,8328,64,10708,5393,4233,2556,1500,169,256,32,5457,513]

theorem envBound47790 : H12AffineFastState.Bounded env47790 := by
  intro p hp
  have h : env47790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47789_47790 : H12AffineEnvironment.transform 15 8203 env47789 = env47790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47789 == env47790) = true)

theorem identity47790 : scanCanonicalize (H12AffineFastState.compose env47790 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47790 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env47791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,5393,10280,1024,8540,4161,32,17,3,8192,64,10588,5393,4097,2420,1364,33,256,32,5457,513]

theorem envBound47791 : H12AffineFastState.Bounded env47791 := by
  intro p hp
  have h : env47791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47790_47791 : H12AffineEnvironment.transform 6 8 env47790 = env47791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47790 == env47791) = true)

theorem identity47791 : scanCanonicalize (H12AffineFastState.compose env47791 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47791 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,342,5393,2421,1024,1,4161,32,17,3,349,64,2049,5393,4097,2420,1364,33,256,32,5457,513]

theorem envBound47792 : H12AffineFastState.Bounded env47792 := by
  intro p hp
  have h : env47792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47791_47792 : H12AffineEnvironment.transform 12 349 env47791 = env47792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47791 == env47792) = true)

theorem identity47792 : scanCanonicalize (H12AffineFastState.compose env47792 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1867) := by decide +kernel

theorem selectedBound47792 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1867,4096,349,5377,0,342,5393,1598,1024,1,4161,32,17,3,349,64,1866,5393,4097,1599,1364,33,256,32,5457,513]

theorem envBound47793 : H12AffineFastState.Bounded env47793 := by
  intro p hp
  have h : env47793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47792_47793 : H12AffineEnvironment.transform 10 1867 env47792 = env47793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1867 env47792 == env47793) = true)

theorem identity47793 : scanCanonicalize (H12AffineFastState.compose env47793 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound47793 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47794 : List Nat := [2,4,8,16,32,64,8,256,512,321,522,4096,349,4160,0,342,4176,895,321,1,4161,32,17,3,349,64,523,4176,4097,894,21,33,256,32,4112,513]

theorem envBound47794 : H12AffineFastState.Bounded env47794 := by
  intro p hp
  have h : env47794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47793_47794 : H12AffineEnvironment.transform 9 321 env47793 = env47794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env47793 == env47794) = true)

theorem identity47794 : scanCanonicalize (H12AffineFastState.compose env47794 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47794 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47795 : List Nat := [2,4,8,16,32,64,8,4,512,69,522,4096,89,4160,0,82,4176,635,69,1,4161,32,17,3,89,64,523,4176,4097,634,21,33,4,32,4112,513]

theorem envBound47795 : H12AffineFastState.Bounded env47795 := by
  intro p hp
  have h : env47795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47794_47795 : H12AffineEnvironment.transform 7 4 env47794 = env47795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47794 == env47795) = true)

theorem identity47795 : scanCanonicalize (H12AffineFastState.compose env47795 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound47795 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env47796 : List Nat := [2,4,8,16,32,49,8,4,512,52,522,4096,40,4145,0,35,4129,522,52,1,4144,32,17,3,40,49,523,4129,4097,523,21,33,4,32,4112,513]

theorem envBound47796 : H12AffineFastState.Bounded env47796 := by
  intro p hp
  have h : env47796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47795_47796 : H12AffineEnvironment.transform 5 49 env47795 = env47796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env47795 == env47796) = true)

theorem identity47796 : scanCanonicalize (H12AffineFastState.compose env47796 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 53) := by decide +kernel

theorem selectedBound47796 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47797 : List Nat := [2,4,8,16,32,49,8,4,53,52,63,4096,40,4145,0,35,4129,63,52,1,4144,32,17,3,40,49,62,4129,4097,62,21,33,4,32,4112,52]

theorem envBound47797 : H12AffineFastState.Bounded env47797 := by
  intro p hp
  have h : env47797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47796_47797 : H12AffineEnvironment.transform 8 53 env47796 = env47797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env47796 == env47797) = true)

theorem identity47797 : scanCanonicalize (H12AffineFastState.compose env47797 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 9) := by decide +kernel

theorem selectedBound47797 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47798 : List Nat := [2,4,8,16,32,49,8,4,53,52,63,9,40,56,0,35,40,63,52,1,57,32,17,3,40,49,62,40,8,62,21,33,4,32,25,52]

theorem envBound47798 : H12AffineFastState.Bounded env47798 := by
  intro p hp
  have h : env47798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47797_47798 : H12AffineEnvironment.transform 11 9 env47797 = env47798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 9 env47797 == env47798) = true)

theorem identity47798 : scanCanonicalize (H12AffineFastState.compose env47798 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47798 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env47799 : List Nat := [2,4,8,16,0,17,8,4,21,20,31,9,8,24,0,3,8,31,20,1,25,0,17,3,8,17,30,8,8,30,21,1,4,0,25,20]

theorem envBound47799 : H12AffineFastState.Bounded env47799 := by
  intro p hp
  have h : env47799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47798_47799 : H12AffineEnvironment.transform 4 0 env47798 = env47799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47798 == env47799) = true)

theorem identity47799 : scanCanonicalize (H12AffineFastState.compose env47799 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound47799 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47800 : List Nat := [2,4,3,16,0,17,3,4,21,20,20,2,3,19,0,3,3,20,20,1,18,0,17,3,3,17,21,3,3,21,21,1,4,0,18,20]

theorem envBound47800 : H12AffineFastState.Bounded env47800 := by
  intro p hp
  have h : env47800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47799_47800 : H12AffineEnvironment.transform 2 3 env47799 = env47800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env47799 == env47800) = true)

theorem identity47800 : scanCanonicalize (H12AffineFastState.compose env47800 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47800 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47801 : List Nat := [2,4,3,0,0,1,3,4,5,4,4,2,3,3,0,3,3,4,4,1,2,0,1,3,3,1,5,3,3,5,5,1,4,0,2,4]

theorem envBound47801 : H12AffineFastState.Bounded env47801 := by
  intro p hp
  have h : env47801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47800_47801 : H12AffineEnvironment.transform 3 0 env47800 = env47801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47800 == env47801) = true)

def env47802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10400,1024,8540,78018,32,136585,73736,8328,64,10709,79130,206226,2557,135372,73890,256,210235,204874,210714]

theorem envBound47802 : H12AffineFastState.Bounded env47802 := by
  intro p hp
  have h : env47802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47787_47802 : H12AffineEnvironment.transform 22 136585 env47787 = env47802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 136585 env47787 == env47802) = true)

theorem identity47802 : scanCanonicalize (H12AffineFastState.compose env47802 (packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound47802 : packedSelected [1,2,4,6,7,8,11,12,14,15,18,19,22,27] rootPS < 2^1333 := by decide +kernel

def env47803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,70862,10400,1024,8540,78018,32,65863,73736,8328,64,10709,79130,12636,2557,66562,73890,256,8693,13444,9172]

theorem envBound47803 : H12AffineFastState.Bounded env47803 := by
  intro p hp
  have h : env47803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47802_47803 : H12AffineEnvironment.transform 16 70862 env47802 = env47803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env47802 == env47803) = true)

theorem identity47803 : scanCanonicalize (H12AffineFastState.compose env47803 (packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound47803 : packedSelected [0,1,4,7,10,16,19,20,22,28] rootPS < 2^1333 := by decide +kernel

def env47804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,65536,70862,2420,1024,136,69910,32,65863,66012,348,64,2049,70862,4232,2557,66562,65910,256,33,5456,512]

theorem envBound47804 : H12AffineFastState.Bounded env47804 := by
  intro p hp
  have h : env47804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47803_47804 : H12AffineEnvironment.transform 12 468 env47803 = env47804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env47803 == env47804) = true)

theorem identity47804 : scanCanonicalize (H12AffineFastState.compose env47804 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 7391) := by decide +kernel

theorem selectedBound47804 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env47805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,7391,2065,2420,1024,136,3529,32,7576,7427,348,64,2049,2065,4232,2557,6365,7593,256,33,5456,512]

theorem envBound47805 : H12AffineFastState.Bounded env47805 := by
  intro p hp
  have h : env47805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47804_47805 : H12AffineEnvironment.transform 15 7391 env47804 = env47805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7391 env47804 == env47805) = true)

theorem identity47805 : scanCanonicalize (H12AffineFastState.compose env47805 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(11+1) ^^^ 2233) := by decide +kernel

theorem selectedBound47805 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env47806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2233,468,3376,137,1126,2065,2420,1024,136,3529,32,1313,1466,348,64,2049,2065,2097,2557,100,1296,256,33,3561,512]

theorem envBound47806 : H12AffineFastState.Bounded env47806 := by
  intro p hp
  have h : env47806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47805_47806 : H12AffineEnvironment.transform 11 2233 env47805 = env47806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2233 env47805 == env47806) = true)

theorem identity47806 : scanCanonicalize (H12AffineFastState.compose env47806 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound47806 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env47807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,185,468,1328,137,1126,17,372,1024,136,1481,32,1313,1466,348,64,1,17,49,509,100,1296,256,33,1513,512]

theorem envBound47807 : H12AffineFastState.Bounded env47807 := by
  intro p hp
  have h : env47807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47806_47807 : H12AffineEnvironment.transform 10 0 env47806 = env47807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env47806 == env47807) = true)

theorem identity47807 : scanCanonicalize (H12AffineFastState.compose env47807 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound47807 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env47808 : List Nat := [2,4,8,16,32,64,128,256,512,204,0,185,468,508,137,170,17,372,204,136,261,32,493,374,348,64,1,17,49,509,100,476,256,33,293,512]

theorem envBound47808 : H12AffineFastState.Bounded env47808 := by
  intro p hp
  have h : env47808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47807_47808 : H12AffineEnvironment.transform 9 204 env47807 = env47808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env47807 == env47808) = true)

theorem identity47808 : scanCanonicalize (H12AffineFastState.compose env47808 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound47808 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env47809 : List Nat := [2,4,8,16,32,64,128,85,512,204,0,185,129,169,137,170,17,33,204,136,80,32,184,35,9,64,1,17,49,168,100,137,85,33,112,512]

theorem envBound47809 : H12AffineFastState.Bounded env47809 := by
  intro p hp
  have h : env47809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47808_47809 : H12AffineEnvironment.transform 7 85 env47808 = env47809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env47808 == env47809) = true)

theorem identity47809 : scanCanonicalize (H12AffineFastState.compose env47809 (packedSelected [0,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound47809 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env47810 : List Nat := [2,4,8,16,32,64,40,85,512,100,0,17,41,1,33,2,17,33,100,32,80,32,16,35,9,64,1,17,49,0,100,33,85,33,112,512]

theorem envBound47810 : H12AffineFastState.Bounded env47810 := by
  intro p hp
  have h : env47810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47809_47810 : H12AffineEnvironment.transform 6 40 env47809 = env47810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env47809 == env47810) = true)

theorem identity47810 : scanCanonicalize (H12AffineFastState.compose env47810 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47810 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47811 : List Nat := [2,4,8,16,0,64,8,85,512,68,0,17,9,1,1,2,17,1,68,0,80,0,16,3,9,64,1,17,17,0,68,1,85,1,80,512]

theorem envBound47811 : H12AffineFastState.Bounded env47811 := by
  intro p hp
  have h : env47811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47810_47811 : H12AffineEnvironment.transform 4 0 env47810 = env47811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47810 == env47811) = true)

theorem identity47811 : scanCanonicalize (H12AffineFastState.compose env47811 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47811 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47812 : List Nat := [2,4,8,0,0,64,8,69,512,68,0,1,9,1,1,2,1,1,68,0,64,0,0,3,9,64,1,1,1,0,68,1,69,1,64,512]

theorem envBound47812 : H12AffineFastState.Bounded env47812 := by
  intro p hp
  have h : env47812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47811_47812 : H12AffineEnvironment.transform 3 0 env47811 = env47812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47811 == env47812) = true)

theorem identity47812 : scanCanonicalize (H12AffineFastState.compose env47812 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound47812 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47813 : List Nat := [2,0,8,0,0,64,8,65,512,64,0,1,9,1,1,2,1,1,64,0,64,0,0,3,9,64,1,1,1,0,64,1,65,1,64,512]

theorem envBound47813 : H12AffineFastState.Bounded env47813 := by
  intro p hp
  have h : env47813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47812_47813 : H12AffineEnvironment.transform 1 0 env47812 = env47813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env47812 == env47813) = true)

theorem identity47813 : scanCanonicalize (H12AffineFastState.compose env47813 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound47813 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47814 : List Nat := [2,0,8,0,0,1,8,0,512,1,0,1,9,1,1,2,1,1,1,0,1,0,0,3,9,1,1,1,1,0,1,1,0,1,1,512]

theorem envBound47814 : H12AffineFastState.Bounded env47814 := by
  intro p hp
  have h : env47814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47813_47814 : H12AffineEnvironment.transform 5 1 env47813 = env47814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env47813 == env47814) = true)

theorem identity47814 : scanCanonicalize (H12AffineFastState.compose env47814 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47814 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47815 : List Nat := [2,0,8,0,0,1,8,0,1,1,0,1,9,1,1,2,1,1,1,0,1,0,0,3,9,1,1,1,1,0,1,1,0,1,1,1]

theorem envBound47815 : H12AffineFastState.Bounded env47815 := by
  intro p hp
  have h : env47815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47814_47815 : H12AffineEnvironment.transform 8 1 env47814 = env47815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47814 == env47815) = true)

def env47816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10401,1024,8540,78018,32,8388608,73736,8328,64,8535133,79130,8466459,8526965,8389957,73890,256,8462514,8467907,8462995]

theorem envBound47816 : H12AffineFastState.Bounded env47816 := by
  intro p hp
  have h : env47816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47786_47816 : H12AffineEnvironment.transform 17 10401 env47786 = env47816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env47786 == env47816) = true)

theorem identity47816 : scanCanonicalize (H12AffineFastState.compose env47816 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound47816 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,131072,10401,1024,8540,78018,32,16,73736,8328,64,146509,79130,77835,138341,1365,73890,256,73890,79315,74371]

theorem envBound47817 : H12AffineFastState.Bounded env47817 := by
  intro p hp
  have h : env47817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47816_47817 : H12AffineEnvironment.transform 22 16 env47816 = env47817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env47816 == env47817) = true)

theorem identity47817 : scanCanonicalize (H12AffineFastState.compose env47817 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound47817 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env47818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8541,65536,79251,10401,1024,8540,78018,32,16,73736,8328,64,68062,79130,77835,76278,1365,73890,256,73890,79315,74371]

theorem envBound47818 : H12AffineFastState.Bounded env47818 := by
  intro p hp
  have h : env47818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47817_47818 : H12AffineEnvironment.transform 16 79251 env47817 = env47818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env47817 == env47818) = true)

theorem identity47818 : scanCanonicalize (H12AffineFastState.compose env47818 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound47818 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,65536,70726,2420,1024,137,69911,32,16,66013,349,64,68062,70863,70110,67619,1365,65911,256,65911,70662,66390]

theorem envBound47819 : H12AffineFastState.Bounded env47819 := by
  intro p hp
  have h : env47819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47818_47819 : H12AffineEnvironment.transform 12 469 env47818 = env47819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env47818 == env47819) = true)

theorem identity47819 : scanCanonicalize (H12AffineFastState.compose env47819 (packedSelected [1,5,8,16,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound47819 : packedSelected [1,5,8,16,20,24] rootPS < 2^1333 := by decide +kernel

def env47820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,136,343,5393,2420,1024,137,4160,32,16,138,349,64,2185,5528,4233,2420,1365,32,256,32,5457,513]

theorem envBound47820 : H12AffineFastState.Bounded env47820 := by
  intro p hp
  have h : env47820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47819_47820 : H12AffineEnvironment.transform 15 343 env47819 = env47820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env47819 == env47820) = true)

theorem identity47820 : scanCanonicalize (H12AffineFastState.compose env47820 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47820 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env47821 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,469,4248,136,343,4096,2420,273,137,4160,32,16,138,349,64,2185,4233,4233,2420,68,32,256,32,4160,513]

theorem envBound47821 : H12AffineFastState.Bounded env47821 := by
  intro p hp
  have h : env47821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47820_47821 : H12AffineEnvironment.transform 9 273 env47820 = env47821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47820 == env47821) = true)

theorem identity47821 : scanCanonicalize (H12AffineFastState.compose env47821 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47821 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47822 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4112,0,343,4096,2420,273,1,4160,32,16,2,349,64,2049,4097,4097,2420,68,32,256,32,4160,513]

theorem envBound47822 : H12AffineFastState.Bounded env47822 := by
  intro p hp
  have h : env47822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47821_47822 : H12AffineEnvironment.transform 6 8 env47821 = env47822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47821 == env47822) = true)

theorem identity47822 : scanCanonicalize (H12AffineFastState.compose env47822 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound47822 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47823 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,4096,72,4112,0,66,4096,2145,4,1,4160,32,16,2,72,64,2049,4097,4097,2145,68,32,21,32,4160,513]

theorem envBound47823 : H12AffineFastState.Bounded env47823 := by
  intro p hp
  have h : env47823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47822_47823 : H12AffineEnvironment.transform 7 21 env47822 = env47823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env47822 == env47823) = true)

theorem identity47823 : scanCanonicalize (H12AffineFastState.compose env47823 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound47823 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47824 : List Nat := [2,4,8,16,32,64,8,21,512,4,2048,544,72,560,0,66,544,2145,4,1,608,32,16,2,72,64,2049,545,545,2145,68,32,21,32,608,513]

theorem envBound47824 : H12AffineFastState.Bounded env47824 := by
  intro p hp
  have h : env47824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47823_47824 : H12AffineEnvironment.transform 11 544 env47823 = env47824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env47823 == env47824) = true)

def env47825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,8388608,98645,8328,64,8787197,79130,8466459,8820105,8389957,98814,256,8462514,8492190,8462995]

theorem envBound47825 : H12AffineFastState.Bounded env47825 := by
  intro p hp
  have h : env47825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47784_47825 : H12AffineEnvironment.transform 21 33 env47784 = env47825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env47784 == env47825) = true)

theorem identity47825 : scanCanonicalize (H12AffineFastState.compose env47825 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 41293) := by decide +kernel

theorem selectedBound47825 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,262144,1024,32769,78018,33,41293,98645,8328,64,439728,79130,102742,406724,41992,98814,256,98815,79315,99294]

theorem envBound47826 : H12AffineFastState.Bounded env47826 := by
  intro p hp
  have h : env47826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47825_47826 : H12AffineEnvironment.transform 22 41293 env47825 = env47826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 41293 env47825 == env47826) = true)

theorem identity47826 : scanCanonicalize (H12AffineFastState.compose env47826 (packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound47826 : packedSelected [1,3,10,11,12,15,18,19,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env47827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,65536,131072,108927,1024,32769,78018,33,41293,98645,8328,64,203983,79130,102742,236987,41992,98814,256,98815,79315,99294]

theorem envBound47827 : H12AffineFastState.Bounded env47827 := by
  intro p hp
  have h : env47827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47826_47827 : H12AffineEnvironment.transform 17 108927 env47826 = env47827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env47826 == env47827) = true)

theorem identity47827 : scanCanonicalize (H12AffineFastState.compose env47827 (packedSelected [0,1,3,9,11,12,15,16,18,20,21,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound47827 : packedSelected [0,1,3,9,11,12,15,16,18,20,21,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env47828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,131072,10400,1024,32769,45341,33,41293,138,8328,64,171280,46277,4233,138340,41992,33,256,32,46092,513]

theorem envBound47828 : H12AffineFastState.Bounded env47828 := by
  intro p hp
  have h : env47828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47827_47828 : H12AffineEnvironment.transform 15 33247 env47827 = env47828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env47827 == env47828) = true)

theorem identity47828 : scanCanonicalize (H12AffineFastState.compose env47828 (packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound47828 : packedSelected [0,7,9,11,12,14,15,18,20,21,22] rootPS < 2^1333 := by decide +kernel

def env47829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,32768,33247,13461,10400,1024,32769,45341,33,41293,138,8328,64,43397,46277,4233,10481,41992,33,256,32,46092,513]

theorem envBound47829 : H12AffineFastState.Bounded env47829 := by
  intro p hp
  have h : env47829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47828_47829 : H12AffineEnvironment.transform 16 13461 env47828 = env47829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env47828 == env47829) = true)

theorem identity47829 : scanCanonicalize (H12AffineFastState.compose env47829 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound47829 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,20,21] rootPS < 2^1333 := by decide +kernel

def env47830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,8203,13461,10400,1024,8661,4297,33,153,138,8328,64,2129,5393,4233,10481,1500,33,256,32,5592,513]

theorem envBound47830 : H12AffineFastState.Bounded env47830 := by
  intro p hp
  have h : env47830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47829_47830 : H12AffineEnvironment.transform 14 8660 env47829 = env47830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env47829 == env47830) = true)

theorem identity47830 : scanCanonicalize (H12AffineFastState.compose env47830 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1172) := by decide +kernel

theorem selectedBound47830 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env47831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1172,5513,1344,1183,4097,3124,1024,1345,4297,33,153,138,1052,64,2129,5393,4233,3173,1500,33,256,32,5592,513]

theorem envBound47831 : H12AffineFastState.Bounded env47831 := by
  intro p hp
  have h : env47831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47830_47831 : H12AffineEnvironment.transform 12 1172 env47830 = env47831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1172 env47830 == env47831) = true)

theorem identity47831 : scanCanonicalize (H12AffineFastState.compose env47831 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound47831 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47832 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,468,4297,0,479,4097,2420,320,1,4297,33,153,138,348,64,2129,4177,4233,2341,156,33,256,32,4248,513]

theorem envBound47832 : H12AffineFastState.Bounded env47832 := by
  intro p hp
  have h : env47832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47831_47832 : H12AffineEnvironment.transform 9 320 env47831 = env47832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env47831 == env47832) = true)

theorem identity47832 : scanCanonicalize (H12AffineFastState.compose env47832 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47832 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47833 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,4096,388,4249,0,399,4097,2340,272,1,4249,33,153,138,268,16,2049,4097,4233,2341,156,33,256,32,4248,513]

theorem envBound47833 : H12AffineFastState.Bounded env47833 := by
  intro p hp
  have h : env47833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47832_47833 : H12AffineEnvironment.transform 5 16 env47832 = env47833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47832 == env47833) = true)

theorem identity47833 : scanCanonicalize (H12AffineFastState.compose env47833 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47833 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47834 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,268,4113,0,263,4097,2340,272,1,4113,33,17,2,268,16,2049,4097,4097,2341,20,33,256,32,4112,513]

theorem envBound47834 : H12AffineFastState.Bounded env47834 := by
  intro p hp
  have h : env47834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47833_47834 : H12AffineEnvironment.transform 6 8 env47833 = env47834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47833 == env47834) = true)

theorem identity47834 : scanCanonicalize (H12AffineFastState.compose env47834 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47834 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47835 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,0,34,4097,2049,53,1,4113,33,17,2,41,16,2049,4097,4097,2048,20,33,37,32,4112,513]

theorem envBound47835 : H12AffineFastState.Bounded env47835 := by
  intro p hp
  have h : env47835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47834_47835 : H12AffineEnvironment.transform 7 37 env47834 = env47835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47834 == env47835) = true)

theorem identity47835 : scanCanonicalize (H12AffineFastState.compose env47835 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2084) := by decide +kernel

theorem selectedBound47835 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47836 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,2084,41,2101,0,34,2085,2049,53,1,2101,33,17,2,41,16,2049,2085,2085,2048,20,33,37,32,2100,513]

theorem envBound47836 : H12AffineFastState.Bounded env47836 := by
  intro p hp
  have h : env47836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47835_47836 : H12AffineEnvironment.transform 11 2084 env47835 = env47836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2084 env47835 == env47836) = true)

theorem identity47836 : scanCanonicalize (H12AffineFastState.compose env47836 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound47836 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47837 : List Nat := [2,4,8,16,32,16,8,37,29,53,2048,2084,41,2101,0,34,2085,2049,53,1,2101,33,17,2,41,16,2049,2085,2085,2048,20,33,37,32,2100,28]

theorem envBound47837 : H12AffineFastState.Bounded env47837 := by
  intro p hp
  have h : env47837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47836_47837 : H12AffineEnvironment.transform 8 29 env47836 = env47837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env47836 == env47837) = true)

theorem identity47837 : scanCanonicalize (H12AffineFastState.compose env47837 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 22) := by decide +kernel

theorem selectedBound47837 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47838 : List Nat := [2,4,8,16,32,16,8,37,29,53,22,50,41,35,0,34,51,23,53,1,35,33,17,2,41,16,23,51,51,22,20,33,37,32,34,28]

theorem envBound47838 : H12AffineFastState.Bounded env47838 := by
  intro p hp
  have h : env47838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47837_47838 : H12AffineEnvironment.transform 10 22 env47837 = env47838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 22 env47837 == env47838) = true)

theorem identity47838 : scanCanonicalize (H12AffineFastState.compose env47838 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 23) := by decide +kernel

theorem selectedBound47838 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47839 : List Nat := [2,4,8,16,23,16,8,18,29,2,22,5,30,20,0,21,4,23,2,1,20,22,17,2,30,16,23,4,4,22,20,22,18,23,21,28]

theorem envBound47839 : H12AffineFastState.Bounded env47839 := by
  intro p hp
  have h : env47839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47838_47839 : H12AffineEnvironment.transform 4 23 env47838 = env47839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 23 env47838 == env47839) = true)

theorem identity47839 : scanCanonicalize (H12AffineFastState.compose env47839 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47839 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47840 : List Nat := [1,4,8,16,20,16,8,17,29,1,21,5,29,20,0,21,4,20,1,1,20,21,17,1,29,16,20,4,4,21,20,21,17,20,21,28]

theorem envBound47840 : H12AffineFastState.Bounded env47840 := by
  intro p hp
  have h : env47840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47839_47840 : H12AffineEnvironment.transform 0 1 env47839 = env47840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47839 == env47840) = true)

def env47841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,91467,4194304,8388608,120029,8328,64,12981469,79131,8466459,8830976,8409293,4314199,256,8484154,8492191,8484635]

theorem envBound47841 : H12AffineFastState.Bounded env47841 := by
  intro p hp
  have h : env47841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47760_47841 : H12AffineEnvironment.transform 23 120029 env47760 = env47841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 120029 env47760 == env47841) = true)

def env47842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,4194304,8388608,98645,8328,64,12981469,79131,8466459,8820104,8389957,4293087,256,8462514,8492191,8462995]

theorem envBound47842 : H12AffineFastState.Bounded env47842 := by
  intro p hp
  have h : env47842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47841_47842 : H12AffineEnvironment.transform 13 5512 env47841 = env47842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env47841 == env47842) = true)

def env47843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,8388608,98645,8328,64,8787197,79131,8466459,8820104,8389957,98815,256,8462514,8492191,8462995]

theorem envBound47843 : H12AffineFastState.Bounded env47843 := by
  intro p hp
  have h : env47843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47842_47843 : H12AffineEnvironment.transform 21 32 env47842 = env47843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env47842 == env47843) = true)

theorem identity47843 : scanCanonicalize (H12AffineFastState.compose env47843 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 98767) := by decide +kernel

theorem selectedBound47843 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,262144,1024,32769,78019,32,98767,98645,8328,64,496946,79131,45524,463943,99466,98815,256,41341,5456,41820]

theorem envBound47844 : H12AffineFastState.Bounded env47844 := by
  intro p hp
  have h : env47844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47843_47844 : H12AffineEnvironment.transform 22 98767 env47843 = env47844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 98767 env47843 == env47844) = true)

def env47845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10400,1024,32769,78019,32,98767,98645,8328,64,245138,79131,45524,212199,99466,98815,256,41341,5456,41820]

theorem envBound47845 : H12AffineFastState.Bounded env47845 := by
  intro p hp
  have h : env47845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47844_47845 : H12AffineEnvironment.transform 17 10400 env47844 = env47845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env47844 == env47845) = true)

def env47846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1024,32769,77899,32,98631,98645,8192,64,245018,79131,45404,212079,99330,98679,256,41341,5456,41820]

theorem envBound47846 : H12AffineFastState.Bounded env47846 := by
  intro p hp
  have h : env47846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47845_47846 : H12AffineEnvironment.transform 6 8 env47845 = env47846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47845 == env47846) = true)

theorem identity47846 : scanCanonicalize (H12AffineFastState.compose env47846 (packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound47846 : packedSelected [0,2,4,6,7,9,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env47847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,10280,1024,32769,45341,32,17,3,8192,64,146508,46157,45404,179513,1364,33,256,41341,5456,41820]

theorem envBound47847 : H12AffineFastState.Bounded env47847 := by
  intro p hp
  have h : env47847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47846_47847 : H12AffineEnvironment.transform 15 33110 env47846 = env47847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env47846 == env47847) = true)

theorem identity47847 : scanCanonicalize (H12AffineFastState.compose env47847 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 13372) := by decide +kernel

theorem selectedBound47847 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env47848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,13372,10280,1024,32769,45341,32,17,3,8192,64,2160,46157,45404,35077,1364,33,256,41341,5456,41820]

theorem envBound47848 : H12AffineFastState.Bounded env47848 := by
  intro p hp
  have h : env47848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47847_47848 : H12AffineEnvironment.transform 16 13372 env47847 = env47848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13372 env47847 == env47848) = true)

theorem identity47848 : scanCanonicalize (H12AffineFastState.compose env47848 (packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound47848 : packedSelected [0,1,3,4,5,7,8,9,10,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env47849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5376,32768,33110,5441,2389,1024,32769,36960,32,17,3,381,64,2160,38192,36897,35077,1364,33,256,32768,5456,33313]

theorem envBound47849 : H12AffineFastState.Bounded env47849 := by
  intro p hp
  have h : env47849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47848_47849 : H12AffineEnvironment.transform 12 381 env47848 = env47849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env47848 == env47849) = true)

theorem identity47849 : scanCanonicalize (H12AffineFastState.compose env47849 (packedSelected [0,6,7,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound47849 : packedSelected [0,6,7,14,20] rootPS < 2^1333 := by decide +kernel

def env47850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5376,33,375,5441,2389,1024,32,4161,32,17,3,381,64,2160,5393,4096,2340,1364,33,256,33,5456,512]

theorem envBound47850 : H12AffineFastState.Bounded env47850 := by
  intro p hp
  have h : env47850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47849_47850 : H12AffineEnvironment.transform 14 33 env47849 = env47850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env47849 == env47850) = true)

def env47851 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,77898,32,98630,98645,8193,64,245019,79131,45405,212078,99331,98678,256,41341,5456,41820]

theorem envBound47851 : H12AffineFastState.Bounded env47851 := by
  intro p hp
  have h : env47851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47845_47851 : H12AffineEnvironment.transform 6 9 env47845 = env47851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47845 == env47851) = true)

theorem identity47851 : scanCanonicalize (H12AffineFastState.compose env47851 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound47851 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47852 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,10281,1024,8540,77898,32,73755,73736,8193,64,203846,79131,4096,212078,75102,73771,256,32,5456,513]

theorem envBound47852 : H12AffineFastState.Bounded env47852 := by
  intro p hp
  have h : env47852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47851_47852 : H12AffineEnvironment.transform 14 8541 env47851 = env47852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env47851 == env47852) = true)

theorem identity47852 : scanCanonicalize (H12AffineFastState.compose env47852 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound47852 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env47853 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,13673,10281,1024,8540,77898,32,73755,73736,8193,64,76079,79131,4096,67847,75102,73771,256,32,5456,513]

theorem envBound47853 : H12AffineFastState.Bounded env47853 := by
  intro p hp
  have h : env47853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47852_47853 : H12AffineEnvironment.transform 16 13673 env47852 = env47853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env47852 == env47853) = true)

theorem identity47853 : scanCanonicalize (H12AffineFastState.compose env47853 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 9499) := by decide +kernel

theorem selectedBound47853 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,9499,13673,10281,1024,8540,5457,32,1280,1299,8193,64,3124,4096,4096,11292,69,1328,256,32,5456,513]

theorem envBound47854 : H12AffineFastState.Bounded env47854 := by
  intro p hp
  have h : env47854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47853_47854 : H12AffineEnvironment.transform 15 9499 env47853 = env47854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9499 env47853 == env47854) = true)

theorem identity47854 : scanCanonicalize (H12AffineFastState.compose env47854 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47854 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env47855 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4112,8541,8202,12408,10281,273,8540,4160,32,17,2,8193,64,2341,4096,4096,10509,69,33,256,32,4161,513]

theorem envBound47855 : H12AffineFastState.Bounded env47855 := by
  intro p hp
  have h : env47855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47854_47855 : H12AffineEnvironment.transform 9 273 env47854 = env47855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47854 == env47855) = true)

theorem identity47855 : scanCanonicalize (H12AffineFastState.compose env47855 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound47855 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47856 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,4096,8192,4112,8233,8202,12408,10281,101,8232,4160,32,17,2,8193,64,2129,4096,4096,10361,69,33,116,32,4161,513]

theorem envBound47856 : H12AffineFastState.Bounded env47856 := by
  intro p hp
  have h : env47856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47855_47856 : H12AffineEnvironment.transform 7 116 env47855 = env47856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env47855 == env47856) = true)

theorem identity47856 : scanCanonicalize (H12AffineFastState.compose env47856 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound47856 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env47857 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2113,8192,2129,8233,8202,10297,10281,101,8232,2049,32,17,2,8193,64,2129,2113,2113,10361,69,33,116,32,2048,513]

theorem envBound47857 : H12AffineFastState.Bounded env47857 := by
  intro p hp
  have h : env47857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47856_47857 : H12AffineEnvironment.transform 11 2113 env47856 = env47857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env47856 == env47857) = true)

theorem identity47857 : scanCanonicalize (H12AffineFastState.compose env47857 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound47857 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env47858 : List Nat := [2,4,8,16,32,64,9,116,512,101,2048,2113,120,2129,81,114,2113,2129,101,80,2049,32,17,2,121,64,2129,2113,2113,2049,69,33,116,32,2048,513]

theorem envBound47858 : H12AffineFastState.Bounded env47858 := by
  intro p hp
  have h : env47858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47857_47858 : H12AffineEnvironment.transform 12 120 env47857 = env47858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env47857 == env47858) = true)

theorem identity47858 : scanCanonicalize (H12AffineFastState.compose env47858 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 122) := by decide +kernel

theorem selectedBound47858 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47859 : List Nat := [2,4,8,16,32,64,9,116,512,101,122,59,120,43,81,114,59,43,101,80,123,32,17,2,121,64,43,59,59,123,69,33,116,32,122,513]

theorem envBound47859 : H12AffineFastState.Bounded env47859 := by
  intro p hp
  have h : env47859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47858_47859 : H12AffineEnvironment.transform 10 122 env47858 = env47859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 122 env47858 == env47859) = true)

theorem identity47859 : scanCanonicalize (H12AffineFastState.compose env47859 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound47859 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47860 : List Nat := [2,4,8,16,32,58,9,14,512,31,0,59,2,43,43,8,59,43,31,42,1,32,17,2,3,58,43,59,59,1,63,33,14,32,0,513]

theorem envBound47860 : H12AffineFastState.Bounded env47860 := by
  intro p hp
  have h : env47860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47859_47860 : H12AffineEnvironment.transform 5 58 env47859 = env47860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env47859 == env47860) = true)

theorem identity47860 : scanCanonicalize (H12AffineFastState.compose env47860 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 58) := by decide +kernel

theorem selectedBound47860 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47861 : List Nat := [2,4,8,16,32,58,9,14,58,31,0,59,2,43,43,8,59,43,31,42,1,32,17,2,3,58,43,59,59,1,63,33,14,32,0,59]

theorem envBound47861 : H12AffineFastState.Bounded env47861 := by
  intro p hp
  have h : env47861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47860_47861 : H12AffineEnvironment.transform 8 58 env47860 = env47861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 58 env47860 == env47861) = true)

theorem identity47861 : scanCanonicalize (H12AffineFastState.compose env47861 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound47861 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47862 : List Nat := [2,4,8,16,11,17,9,14,17,31,0,16,2,0,0,8,16,0,31,1,1,11,17,2,3,17,0,16,16,1,20,10,14,11,0,16]

theorem envBound47862 : H12AffineFastState.Bounded env47862 := by
  intro p hp
  have h : env47862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47861_47862 : H12AffineEnvironment.transform 4 11 env47861 = env47862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env47861 == env47862) = true)

def env47863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,131072,10401,1024,32769,78019,32,98767,98645,8328,64,245139,79131,45524,212198,99466,98815,256,41341,5456,41820]

theorem envBound47863 : H12AffineFastState.Bounded env47863 := by
  intro p hp
  have h : env47863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47844_47863 : H12AffineEnvironment.transform 17 10401 env47844 = env47863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env47844 == env47863) = true)

theorem identity47863 : scanCanonicalize (H12AffineFastState.compose env47863 (packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 103631) := by decide +kernel

theorem selectedBound47863 : packedSelected [0,1,4,5,7,8,16,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env47864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,65536,103631,10401,1024,32769,78019,32,98767,98645,8328,64,10588,79131,45524,43049,99466,98815,256,41341,5456,41820]

theorem envBound47864 : H12AffineFastState.Bounded env47864 := by
  intro p hp
  have h : env47864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47863_47864 : H12AffineEnvironment.transform 16 103631 env47863 = env47864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 103631 env47863 == env47864) = true)

theorem identity47864 : scanCanonicalize (H12AffineFastState.compose env47864 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound47864 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env47865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33247,5392,10401,1024,32769,45340,32,16,138,8328,64,10588,46276,45524,43049,1365,32,256,41341,5456,41820]

theorem envBound47865 : H12AffineFastState.Bounded env47865 := by
  intro p hp
  have h : env47865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47864_47865 : H12AffineEnvironment.transform 15 33247 env47864 = env47865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env47864 == env47865) = true)

theorem identity47865 : scanCanonicalize (H12AffineFastState.compose env47865 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound47865 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env47866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5512,32768,33247,5392,2340,1024,32769,37017,32,16,138,269,64,2265,38209,36945,35244,1365,32,256,33016,5456,33497]

theorem envBound47866 : H12AffineFastState.Bounded env47866 := by
  intro p hp
  have h : env47866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47865_47866 : H12AffineEnvironment.transform 12 389 env47865 = env47866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env47865 == env47866) = true)

theorem identity47866 : scanCanonicalize (H12AffineFastState.compose env47866 (packedSelected [0,1,3,9,10,11,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47866 : packedSelected [0,1,3,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env47867 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,33111,5392,2340,1024,32769,36881,32,16,2,269,64,2129,38209,36945,35108,1365,32,256,32880,5456,33361]

theorem envBound47867 : H12AffineFastState.Bounded env47867 := by
  intro p hp
  have h : env47867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47866_47867 : H12AffineEnvironment.transform 6 8 env47866 = env47867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47866 == env47867) = true)

theorem identity47867 : scanCanonicalize (H12AffineFastState.compose env47867 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound47867 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47868 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,1344,1047,5392,2340,1024,1345,5457,32,16,2,269,64,2129,4097,5393,3172,1365,32,256,1328,5456,1809]

theorem envBound47868 : H12AffineFastState.Bounded env47868 := by
  intro p hp
  have h : env47868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47867_47868 : H12AffineEnvironment.transform 14 1344 env47867 = env47868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env47867 == env47868) = true)

theorem identity47868 : scanCanonicalize (H12AffineFastState.compose env47868 (packedSelected [0,1,4,5,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound47868 : packedSelected [0,1,4,5,6,11,12] rootPS < 2^1333 := by decide +kernel

def env47869 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,269,5376,1329,1047,5392,2340,1024,1328,5408,32,16,2,269,49,2080,4097,5393,3093,1316,32,256,1328,5409,1809]

theorem envBound47869 : H12AffineFastState.Bounded env47869 := by
  intro p hp
  have h : env47869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47868_47869 : H12AffineEnvironment.transform 5 49 env47868 = env47869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env47868 == env47869) = true)

theorem identity47869 : scanCanonicalize (H12AffineFastState.compose env47869 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound47869 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47870 : List Nat := [2,4,8,16,32,49,8,256,512,273,2048,4096,269,4113,32,262,4097,2340,273,33,4145,32,16,2,269,49,2080,4097,4096,2308,53,32,256,33,4144,512]

theorem envBound47870 : H12AffineFastState.Bounded env47870 := by
  intro p hp
  have h : env47870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47869_47870 : H12AffineEnvironment.transform 9 273 env47869 = env47870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env47869 == env47870) = true)

theorem identity47870 : scanCanonicalize (H12AffineFastState.compose env47870 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47870 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47871 : List Nat := [2,4,8,16,32,49,8,37,512,52,2048,4096,40,4113,32,35,4097,2049,52,33,4145,32,16,2,40,49,2080,4097,4096,2081,53,32,37,33,4144,512]

theorem envBound47871 : H12AffineFastState.Bounded env47871 := by
  intro p hp
  have h : env47871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47870_47871 : H12AffineEnvironment.transform 7 37 env47870 = env47871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47870 == env47871) = true)

theorem identity47871 : scanCanonicalize (H12AffineFastState.compose env47871 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47871 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47872 : List Nat := [2,4,8,16,0,17,8,5,512,20,2048,4096,8,4113,0,3,4097,2049,20,1,4113,0,16,2,8,17,2048,4097,4096,2049,21,0,5,1,4112,512]

theorem envBound47872 : H12AffineFastState.Bounded env47872 := by
  intro p hp
  have h : env47872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47871_47872 : H12AffineEnvironment.transform 4 0 env47871 = env47872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47871 == env47872) = true)

theorem identity47872 : scanCanonicalize (H12AffineFastState.compose env47872 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47872 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47873 : List Nat := [2,4,8,16,0,17,8,5,1,20,2048,4096,8,4113,0,3,4097,2049,20,1,4113,0,16,2,8,17,2048,4097,4096,2049,21,0,5,1,4112,1]

theorem envBound47873 : H12AffineFastState.Bounded env47873 := by
  intro p hp
  have h : env47873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47872_47873 : H12AffineEnvironment.transform 8 1 env47872 = env47873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47872 == env47873) = true)

theorem identity47873 : scanCanonicalize (H12AffineFastState.compose env47873 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound47873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47874 : List Nat := [2,4,8,16,0,17,8,5,1,20,30,4096,8,4113,0,3,4097,31,20,1,4113,0,16,2,8,17,30,4097,4096,31,21,0,5,1,4112,1]

theorem envBound47874 : H12AffineFastState.Bounded env47874 := by
  intro p hp
  have h : env47874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47873_47874 : H12AffineEnvironment.transform 10 30 env47873 = env47874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env47873 == env47874) = true)

theorem identity47874 : scanCanonicalize (H12AffineFastState.compose env47874 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 15) := by decide +kernel

theorem selectedBound47874 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47875 : List Nat := [2,4,8,16,0,17,8,5,1,20,30,15,8,30,0,3,14,31,20,1,30,0,16,2,8,17,30,14,15,31,21,0,5,1,31,1]

theorem envBound47875 : H12AffineFastState.Bounded env47875 := by
  intro p hp
  have h : env47875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47874_47875 : H12AffineEnvironment.transform 11 15 env47874 = env47875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 15 env47874 == env47875) = true)

def leafEnv47875 : List Nat := [2,4,8,16,0,17,8,5,1,20,30,15,8,30,0,3,14,31,20,1,30,0,16,2,21,8,1,17,30,14,15,31,21,0,5,1,4,3,31,1,1,31,0]

def active47875 : List Nat := [0,1,2,3]

end H12CloudChart1