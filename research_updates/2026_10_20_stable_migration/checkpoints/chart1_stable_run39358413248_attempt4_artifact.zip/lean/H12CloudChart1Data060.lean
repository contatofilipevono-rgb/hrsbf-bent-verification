import H12CloudChart1Data059

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity15087 : scanCanonicalize (H12AffineFastState.compose env15087 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15087 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15088 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,0,8203,16401,10281,1024,1,4161,21928,8645,2,8328,65,31836,13508,25813,2556,1501,33,256,21793,13445,513]

theorem envBound15088 : H12AffineFastState.Bounded env15088 := by
  intro p hp
  have h : env15088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15087_15088 : H12AffineEnvironment.transform 14 0 env15087 = env15088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15087 == env15088) = true)

def env15089 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513341,510001,8328,65,6705548,2510013,396524,2136508,2102685,6729200,256,21792,46212,2175562]

theorem envBound15089 : H12AffineFastState.Bounded env15089 := by
  intro p hp
  have h : env15089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14972_15089 : H12AffineEnvironment.transform 22 2513341 env14972 = env15089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513341 env14972 == env15089) = true)

def env15090 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513341,510001,8328,65,2409524,2510013,396524,2136508,2102685,2373704,256,21792,46212,2175562]

theorem envBound15090 : H12AffineFastState.Bounded env15090 := by
  intro p hp
  have h : env15090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15089_15090 : H12AffineEnvironment.transform 21 169400 env15089 = env15090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env15089 == env15090) = true)

def env15091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412157,510001,8328,65,316532,417021,396524,35324,1501,272392,256,21792,46212,74250]

theorem envBound15091 : H12AffineFastState.Bounded env15091 := by
  intro p hp
  have h : env15091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15090_15091 : H12AffineEnvironment.transform 20 4160 env15090 = env15091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15090 == env15091) = true)

theorem identity15091 : scanCanonicalize (H12AffineFastState.compose env15091 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15091 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4160,169400,412157,452666,8328,65,316532,417021,396524,35324,1501,272392,256,21792,46212,513]

theorem envBound15092 : H12AffineFastState.Bounded env15092 := by
  intro p hp
  have h : env15092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15091_15092 : H12AffineEnvironment.transform 15 8203 env15091 = env15092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15091 == env15092) = true)

def env15093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,4160,54696,264685,305194,8328,65,316532,269549,281852,35324,1501,272392,256,21792,46212,513]

theorem envBound15093 : H12AffineFastState.Bounded env15093 := by
  intro p hp
  have h : env15093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15092_15093 : H12AffineEnvironment.transform 16 16400 env15092 = env15093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15092 == env15093) = true)

theorem identity15093 : scanCanonicalize (H12AffineFastState.compose env15093 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound15093 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,2557,1024,32769,4160,54696,16,41431,8328,65,56713,5392,17665,35324,1501,8693,256,21792,46212,513]

theorem envBound15094 : H12AffineFastState.Bounded env15094 := by
  intro p hp
  have h : env15094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15093_15094 : H12AffineEnvironment.transform 17 2557 env15093 = env15094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env15093 == env15094) = true)

theorem identity15094 : scanCanonicalize (H12AffineFastState.compose env15094 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound15094 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16400,2557,1024,21760,4160,169,16,29910,8328,65,2184,5392,17665,23805,1501,8693,256,21792,24965,513]

theorem envBound15095 : H12AffineFastState.Bounded env15095 := by
  intro p hp
  have h : env15095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15094_15095 : H12AffineEnvironment.transform 14 21761 env15094 = env15095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env15094 == env15095) = true)

theorem identity15095 : scanCanonicalize (H12AffineFastState.compose env15095 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15095 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env15096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,16400,2420,1024,21760,4160,32,16,29791,8193,65,2049,5392,17665,23668,1364,8572,256,21792,24844,513]

theorem envBound15096 : H12AffineFastState.Bounded env15096 := by
  intro p hp
  have h : env15096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15095_15096 : H12AffineEnvironment.transform 6 9 env15095 = env15096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15095 == env15096) = true)

theorem identity15096 : scanCanonicalize (H12AffineFastState.compose env15096 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound15096 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8203,13388,2420,1024,8540,4160,32,16,3,8193,65,2049,5392,12637,10280,1364,8572,256,8572,5456,513]

theorem envBound15097 : H12AffineFastState.Bounded env15097 := by
  intro p hp
  have h : env15097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15096_15097 : H12AffineEnvironment.transform 13 13404 env15096 = env15097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env15096 == env15097) = true)

theorem identity15097 : scanCanonicalize (H12AffineFastState.compose env15097 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1345) := by decide +kernel

theorem selectedBound15097 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env15098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1345,8192,8477,8541,8203,8461,2420,1024,8540,1281,32,16,3,8193,65,2049,81,9244,10280,1364,8572,256,8572,17,513]

theorem envBound15098 : H12AffineFastState.Bounded env15098 := by
  intro p hp
  have h : env15098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15097_15098 : H12AffineEnvironment.transform 11 1345 env15097 = env15098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1345 env15097 == env15098) = true)

def env15099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4160,54697,264684,305195,8328,65,316532,269548,281853,35324,1501,272392,256,21792,46212,513]

theorem envBound15099 : H12AffineFastState.Bounded env15099 := by
  intro p hp
  have h : env15099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15092_15099 : H12AffineEnvironment.transform 16 16401 env15092 = env15099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15092 == env15099) = true)

def env15100 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4112,54697,264636,305195,8328,17,316452,269500,281773,35244,1421,272392,256,21792,46212,513]

theorem envBound15100 : H12AffineFastState.Bounded env15100 := by
  intro p hp
  have h : env15100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15099_15100 : H12AffineEnvironment.transform 5 16 env15099 = env15100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15099 == env15100) = true)

theorem identity15100 : scanCanonicalize (H12AffineFastState.compose env15100 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound15100 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env15101 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56357,1024,32769,4112,54697,54681,29710,8328,17,2049,49305,37000,35244,1421,62509,256,21792,46212,513]

theorem envBound15101 : H12AffineFastState.Bounded env15101 := by
  intro p hp
  have h : env15101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15100_15101 : H12AffineEnvironment.transform 17 56357 env15100 = env15101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env15100 == env15101) = true)

theorem identity15101 : scanCanonicalize (H12AffineFastState.compose env15101 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(14+1) ^^^ 29829) := by decide +kernel

theorem selectedBound15101 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env15102 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29829,8203,16401,10400,1024,29828,4112,8492,8476,29710,8328,17,2049,13340,25613,32041,1421,168,256,21792,16385,513]

theorem envBound15102 : H12AffineFastState.Bounded env15102 := by
  intro p hp
  have h : env15102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15101_15102 : H12AffineEnvironment.transform 14 29829 env15101 = env15102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29829 env15101 == env15102) = true)

theorem identity15102 : scanCanonicalize (H12AffineFastState.compose env15102 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound15102 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15103 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,137,8203,13341,10400,1024,136,4112,8492,8476,2,8328,17,2049,13340,4097,2341,1421,168,256,8492,13325,513]

theorem envBound15103 : H12AffineFastState.Bounded env15103 := by
  intro p hp
  have h : env15103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15102_15103 : H12AffineEnvironment.transform 13 13324 env15102 = env15103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env15102 == env15103) = true)

theorem identity15103 : scanCanonicalize (H12AffineFastState.compose env15103 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound15103 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15104 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,137,398,5528,2341,1024,136,4112,169,153,2,269,17,2049,5529,4097,2341,1421,168,256,169,5512,513]

theorem envBound15104 : H12AffineFastState.Bounded env15104 := by
  intro p hp
  have h : env15104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15103_15104 : H12AffineEnvironment.transform 12 389 env15103 = env15104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env15103 == env15104) = true)

theorem identity15104 : scanCanonicalize (H12AffineFastState.compose env15104 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15104 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15105 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,262,5392,2341,1024,0,4112,33,17,2,269,17,2049,5393,4097,2341,1285,32,256,33,5376,513]

theorem envBound15105 : H12AffineFastState.Bounded env15105 := by
  intro p hp
  have h : env15105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15104_15105 : H12AffineEnvironment.transform 6 8 env15104 = env15105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15104 == env15105) = true)

theorem identity15105 : scanCanonicalize (H12AffineFastState.compose env15105 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound15105 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15106 : List Nat := [2,4,8,16,32,16,8,256,512,288,2048,4096,269,4129,1,262,4144,2341,288,0,4112,33,17,2,269,17,2049,4145,4097,2341,37,32,256,33,4128,513]

theorem envBound15106 : H12AffineFastState.Bounded env15106 := by
  intro p hp
  have h : env15106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15105_15106 : H12AffineEnvironment.transform 9 288 env15105 = env15106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env15105 == env15106) = true)

theorem identity15106 : scanCanonicalize (H12AffineFastState.compose env15106 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound15106 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15107 : List Nat := [2,4,8,16,32,16,8,256,512,288,2048,820,269,789,1,262,772,2341,288,0,804,33,17,2,269,17,2049,773,821,2341,37,32,256,33,788,513]

theorem envBound15107 : H12AffineFastState.Bounded env15107 := by
  intro p hp
  have h : env15107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15106_15107 : H12AffineEnvironment.transform 11 820 env15106 = env15107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env15106 == env15107) = true)

theorem identity15107 : scanCanonicalize (H12AffineFastState.compose env15107 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15107 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15108 : List Nat := [2,4,8,16,32,16,8,5,512,37,2048,561,8,528,1,3,513,2080,37,0,545,33,17,2,8,17,2049,512,560,2080,37,32,5,33,529,513]

theorem envBound15108 : H12AffineFastState.Bounded env15108 := by
  intro p hp
  have h : env15108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15107_15108 : H12AffineEnvironment.transform 7 5 env15107 = env15108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15107 == env15108) = true)

theorem identity15108 : scanCanonicalize (H12AffineFastState.compose env15108 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound15108 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15109 : List Nat := [2,4,8,16,32,16,8,5,512,37,512,561,8,528,1,3,513,544,37,0,545,33,17,2,8,17,513,512,560,544,37,32,5,33,529,513]

theorem envBound15109 : H12AffineFastState.Bounded env15109 := by
  intro p hp
  have h : env15109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15108_15109 : H12AffineEnvironment.transform 10 512 env15108 = env15109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env15108 == env15109) = true)

theorem identity15109 : scanCanonicalize (H12AffineFastState.compose env15109 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound15109 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env15110 : List Nat := [2,4,8,16,16,16,8,5,512,21,512,513,8,528,1,3,513,528,21,0,529,17,17,2,8,17,513,512,512,528,21,16,5,17,529,513]

theorem envBound15110 : H12AffineFastState.Bounded env15110 := by
  intro p hp
  have h : env15110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15109_15110 : H12AffineEnvironment.transform 4 16 env15109 = env15110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env15109 == env15110) = true)

theorem identity15110 : scanCanonicalize (H12AffineFastState.compose env15110 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound15110 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15111 : List Nat := [2,4,8,16,16,16,8,5,17,21,17,16,8,1,1,3,16,1,21,0,0,17,17,2,8,17,16,17,17,1,21,16,5,17,0,16]

theorem envBound15111 : H12AffineFastState.Bounded env15111 := by
  intro p hp
  have h : env15111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15110_15111 : H12AffineEnvironment.transform 8 17 env15110 = env15111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env15110 == env15111) = true)

theorem identity15111 : scanCanonicalize (H12AffineFastState.compose env15111 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound15111 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15112 : List Nat := [2,4,8,11,11,11,8,5,10,14,10,11,8,1,1,3,11,1,14,0,0,10,10,2,8,10,11,10,10,1,14,11,5,10,0,11]

theorem envBound15112 : H12AffineFastState.Bounded env15112 := by
  intro p hp
  have h : env15112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15111_15112 : H12AffineEnvironment.transform 3 11 env15111 = env15112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env15111 == env15112) = true)

theorem identity15112 : scanCanonicalize (H12AffineFastState.compose env15112 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound15112 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15113 : List Nat := [2,4,2,1,1,1,2,5,0,4,0,1,2,1,1,3,1,1,4,0,0,0,0,2,2,0,1,0,0,1,4,1,5,0,0,1]

theorem envBound15113 : H12AffineFastState.Bounded env15113 := by
  intro p hp
  have h : env15113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15112_15113 : H12AffineEnvironment.transform 2 2 env15112 = env15113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env15112 == env15113) = true)

def env15114 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1024,32769,4113,54697,264637,305195,8328,16,316453,269501,281772,35245,1420,272392,256,21792,46212,513]

theorem envBound15114 : H12AffineFastState.Bounded env15114 := by
  intro p hp
  have h : env15114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15099_15114 : H12AffineEnvironment.transform 5 17 env15099 = env15114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15099 == env15114) = true)

theorem identity15114 : scanCanonicalize (H12AffineFastState.compose env15114 (packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15114 : packedSelected [1,4,5,8,9,11,14,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env15115 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,8203,5393,262144,1024,32769,4113,32937,264637,305195,8328,16,295205,269501,268716,35245,1420,272392,256,32,46212,513]

theorem envBound15115 : H12AffineFastState.Bounded env15115 := by
  intro p hp
  have h : env15115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15114_15115 : H12AffineEnvironment.transform 13 5376 env15114 = env15115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15114 == env15115) = true)

theorem identity15115 : scanCanonicalize (H12AffineFastState.compose env15115 (packedSelected [3,5,7,8,14,17,18,20,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound15115 : packedSelected [3,5,7,8,14,17,18,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env15116 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,8203,5393,10280,1024,32769,4113,32937,8597,32771,8328,16,43277,13461,12676,35245,1420,32,256,32,46212,513]

theorem envBound15116 : H12AffineFastState.Bounded env15116 := by
  intro p hp
  have h : env15116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15115_15116 : H12AffineEnvironment.transform 17 10280 env15115 = env15116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15115 == env15116) = true)

theorem identity15116 : scanCanonicalize (H12AffineFastState.compose env15116 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound15116 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env15117 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,5376,32768,1182,5393,3261,1024,32769,4113,32937,1280,32771,1053,16,36248,4096,5393,35245,1420,32,256,32,36881,513]

theorem envBound15117 : H12AffineFastState.Bounded env15117 := by
  intro p hp
  have h : env15117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15116_15117 : H12AffineEnvironment.transform 12 1173 env15116 = env15117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env15116 == env15117) = true)

theorem identity15117 : scanCanonicalize (H12AffineFastState.compose env15117 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14] rootPS)) = affineNative (2^(14+1) ^^^ 7424) := by decide +kernel

theorem selectedBound15117 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env15118 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1173,5376,7424,1182,5393,3261,1024,7425,4113,7593,1280,7427,1053,16,4248,4096,5393,5293,1420,32,256,32,3345,513]

theorem envBound15118 : H12AffineFastState.Bounded env15118 := by
  intro p hp
  have h : env15118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15117_15118 : H12AffineEnvironment.transform 14 7424 env15117 = env15118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7424 env15117 == env15118) = true)

theorem identity15118 : scanCanonicalize (H12AffineFastState.compose env15118 (packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound15118 : packedSelected [1,2,3,4,5,6,8,9,12,15] rootPS < 2^1333 := by decide +kernel

def env15119 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,1173,2184,136,1182,2201,3261,1024,137,3481,33,1280,139,1053,16,3344,3464,2201,2341,1420,32,256,32,3345,513]

theorem envBound15119 : H12AffineFastState.Bounded env15119 := by
  intro p hp
  have h : env15119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15118_15119 : H12AffineEnvironment.transform 11 3464 env15118 = env15119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env15118 == env15119) = true)

theorem identity15119 : scanCanonicalize (H12AffineFastState.compose env15119 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound15119 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15120 : List Nat := [2,4,8,16,32,17,128,256,512,408,2048,2064,269,2184,136,262,2201,2341,408,137,2049,33,152,139,389,16,2184,2064,2201,2341,20,32,256,32,2185,513]

theorem envBound15120 : H12AffineFastState.Bounded env15120 := by
  intro p hp
  have h : env15120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15119_15120 : H12AffineEnvironment.transform 9 408 env15119 = env15120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env15119 == env15120) = true)

def env15121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412156,510001,8328,65,316533,417020,396524,35325,1500,272393,256,21792,46212,74251]

theorem envBound15121 : H12AffineFastState.Bounded env15121 := by
  intro p hp
  have h : env15121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15090_15121 : H12AffineEnvironment.transform 20 4161 env15090 = env15121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15090 == env15121) = true)

theorem identity15121 : scanCanonicalize (H12AffineFastState.compose env15121 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236851) := by decide +kernel

theorem selectedBound15121 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236851,1024,32769,4161,169400,120015,21762,8328,65,215366,115151,102879,35325,1500,243002,256,21792,46212,74251]

theorem envBound15122 : H12AffineFastState.Bounded env15122 := by
  intro p hp
  have h : env15122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15121_15122 : H12AffineEnvironment.transform 17 236851 env15121 = env15122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236851 env15121 == env15122) = true)

def env15123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4161,62708,120015,21762,8328,65,75786,115151,102879,35325,1500,119926,256,21792,46212,74251]

theorem envBound15123 : H12AffineFastState.Bounded env15123 := by
  intro p hp
  have h : env15123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15122_15123 : H12AffineEnvironment.transform 16 24908 env15122 = env15123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env15122 == env15123) = true)

def env15124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4161,62588,119879,21762,8192,65,75786,115015,102743,35189,1364,119926,256,21792,46092,74251]

theorem envBound15124 : H12AffineFastState.Bounded env15124 := by
  intro p hp
  have h : env15124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15123_15124 : H12AffineEnvironment.transform 6 8 env15123 = env15124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15123 == env15124) = true)

theorem identity15124 : scanCanonicalize (H12AffineFastState.compose env15124 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound15124 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,24908,32041,1024,32769,4161,62588,21777,21762,8192,65,43356,16401,4097,35189,1364,21792,256,21792,46092,41821]

theorem envBound15125 : H12AffineFastState.Bounded env15125 := by
  intro p hp
  have h : env15125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15124_15125 : H12AffineEnvironment.transform 15 33110 env15124 = env15125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env15124 == env15125) = true)

theorem identity15125 : scanCanonicalize (H12AffineFastState.compose env15125 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15125 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env15126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,32768,33110,16741,23808,1024,32769,4161,54357,21777,21762,41,65,35189,16401,4097,35189,1364,21792,256,21792,37925,33652]

theorem envBound15126 : H12AffineFastState.Bounded env15126 := by
  intro p hp
  have h : env15126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15125_15126 : H12AffineEnvironment.transform 12 41 env15125 = env15126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15125 == env15126) = true)

theorem identity15126 : scanCanonicalize (H12AffineFastState.compose env15126 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15126 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env15127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,0,342,16741,23808,1024,1,4161,21589,21777,21762,41,65,2421,16401,4097,2421,1364,21792,256,21792,5157,884]

theorem envBound15127 : H12AffineFastState.Bounded env15127 := by
  intro p hp
  have h : env15127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15126_15127 : H12AffineEnvironment.transform 14 0 env15126 = env15127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15126 == env15127) = true)

def env15128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24908,130175,1024,32769,4161,62589,119878,21762,8193,65,75786,115014,102742,35188,1365,119926,256,21792,46093,74251]

theorem envBound15128 : H12AffineFastState.Bounded env15128 := by
  intro p hp
  have h : env15128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15123_15128 : H12AffineEnvironment.transform 6 9 env15123 = env15128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15123 == env15128) = true)

theorem identity15128 : scanCanonicalize (H12AffineFastState.compose env15128 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15128 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,24908,56437,1024,32769,4161,62589,62540,21762,8193,65,2048,57676,45404,35188,1365,62588,256,21792,46093,513]

theorem envBound15129 : H12AffineFastState.Bounded env15129 := by
  intro p hp
  have h : env15129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15128_15129 : H12AffineEnvironment.transform 15 8202 env15128 = env15129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15128 == env15129) = true)

theorem identity15129 : scanCanonicalize (H12AffineFastState.compose env15129 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound15129 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env15130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,8202,13340,35109,1024,32769,4161,41261,41244,82,8193,65,2048,46108,45404,35188,1365,41260,256,112,46093,513]

theorem envBound15130 : H12AffineFastState.Bounded env15130 := by
  intro p hp
  have h : env15130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15129_15130 : H12AffineEnvironment.transform 13 5456 env15129 = env15130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env15129 == env15130) = true)

theorem identity15130 : scanCanonicalize (H12AffineFastState.compose env15130 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15130 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,32768,343,5441,35109,1024,32769,4161,32880,32833,82,348,65,2048,38209,36865,35188,1365,32881,256,112,38224,513]

theorem envBound15131 : H12AffineFastState.Bounded env15131 := by
  intro p hp
  have h : env15131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15130_15131 : H12AffineEnvironment.transform 12 349 env15130 = env15131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15130 == env15131) = true)

theorem identity15131 : scanCanonicalize (H12AffineFastState.compose env15131 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15131 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15132 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5377,32768,262,5392,35109,1024,32769,4112,32801,32784,3,269,16,2048,38160,36865,35109,1284,32800,256,33,38145,513]

theorem envBound15132 : H12AffineFastState.Bounded env15132 := by
  intro p hp
  have h : env15132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15131_15132 : H12AffineEnvironment.transform 5 17 env15131 = env15132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15131 == env15132) = true)

theorem identity15132 : scanCanonicalize (H12AffineFastState.compose env15132 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15132 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15133 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,32768,262,4097,35109,273,32769,4112,32801,32784,3,269,16,2048,36865,36865,35109,21,32800,256,33,36880,513]

theorem envBound15133 : H12AffineFastState.Bounded env15133 := by
  intro p hp
  have h : env15133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15132_15133 : H12AffineEnvironment.transform 9 273 env15132 = env15133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15132 == env15133) = true)

theorem identity15133 : scanCanonicalize (H12AffineFastState.compose env15133 (packedSelected [4,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15133 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15134 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,268,4112,1,262,4097,2340,273,0,4112,32,17,3,269,16,2048,4096,4096,2340,21,33,256,33,4113,513]

theorem envBound15134 : H12AffineFastState.Bounded env15134 := by
  intro p hp
  have h : env15134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15133_15134 : H12AffineEnvironment.transform 14 1 env15133 = env15134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15133 == env15134) = true)

theorem identity15134 : scanCanonicalize (H12AffineFastState.compose env15134 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound15134 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15135 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,293,268,309,1,262,292,2340,273,0,309,32,17,3,269,16,2048,293,293,2340,21,33,256,33,308,513]

theorem envBound15135 : H12AffineFastState.Bounded env15135 := by
  intro p hp
  have h : env15135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15134_15135 : H12AffineEnvironment.transform 11 293 env15134 = env15135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env15134 == env15135) = true)

theorem identity15135 : scanCanonicalize (H12AffineFastState.compose env15135 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound15135 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15136 : List Nat := [2,4,8,16,32,17,9,256,512,273,10,293,268,309,1,262,292,302,273,0,309,32,17,3,269,16,10,293,293,302,21,33,256,33,308,513]

theorem envBound15136 : H12AffineFastState.Bounded env15136 := by
  intro p hp
  have h : env15136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15135_15136 : H12AffineEnvironment.transform 10 10 env15135 = env15136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env15135 == env15136) = true)

theorem identity15136 : scanCanonicalize (H12AffineFastState.compose env15136 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15136 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15137 : List Nat := [2,4,8,16,32,17,9,4,512,21,10,33,8,49,1,2,32,42,21,0,49,32,17,3,9,16,10,33,33,42,21,33,4,33,48,513]

theorem envBound15137 : H12AffineFastState.Bounded env15137 := by
  intro p hp
  have h : env15137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15136_15137 : H12AffineEnvironment.transform 7 4 env15136 = env15137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15136 == env15137) = true)

theorem identity15137 : scanCanonicalize (H12AffineFastState.compose env15137 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15137 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env15138 : List Nat := [2,4,8,16,1,17,9,4,512,21,10,0,8,16,1,2,1,11,21,0,16,1,17,3,9,16,10,0,0,11,21,0,4,0,17,513]

theorem envBound15138 : H12AffineFastState.Bounded env15138 := by
  intro p hp
  have h : env15138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15137_15138 : H12AffineEnvironment.transform 4 1 env15137 = env15138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15137 == env15138) = true)

theorem identity15138 : scanCanonicalize (H12AffineFastState.compose env15138 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15138 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15139 : List Nat := [2,0,8,16,1,17,9,0,512,17,10,0,8,16,1,2,1,11,17,0,16,1,17,3,9,16,10,0,0,11,17,0,0,0,17,513]

theorem envBound15139 : H12AffineFastState.Bounded env15139 := by
  intro p hp
  have h : env15139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15138_15139 : H12AffineEnvironment.transform 1 0 env15138 = env15139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15138 == env15139) = true)

theorem identity15139 : scanCanonicalize (H12AffineFastState.compose env15139 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound15139 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15140 : List Nat := [2,0,8,16,1,17,9,0,19,17,10,0,8,16,1,2,1,11,17,0,16,1,17,3,9,16,10,0,0,11,17,0,0,0,17,18]

theorem envBound15140 : H12AffineFastState.Bounded env15140 := by
  intro p hp
  have h : env15140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15139_15140 : H12AffineEnvironment.transform 8 19 env15139 = env15140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env15139 == env15140) = true)

theorem identity15140 : scanCanonicalize (H12AffineFastState.compose env15140 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15140 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15141 : List Nat := [2,0,3,16,1,17,2,0,19,17,1,0,3,16,1,2,1,0,17,0,16,1,17,3,2,16,1,0,0,0,17,0,0,0,17,18]

theorem envBound15141 : H12AffineFastState.Bounded env15141 := by
  intro p hp
  have h : env15141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15140_15141 : H12AffineEnvironment.transform 2 3 env15140 = env15141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15140 == env15141) = true)

theorem identity15141 : scanCanonicalize (H12AffineFastState.compose env15141 (packedSelected [12] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15141 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env15142 : List Nat := [2,0,3,1,1,0,2,0,2,0,1,0,3,1,1,2,1,0,0,0,1,1,0,3,2,1,1,0,0,0,0,0,0,0,0,3]

theorem envBound15142 : H12AffineFastState.Bounded env15142 := by
  intro p hp
  have h : env15142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15141_15142 : H12AffineEnvironment.transform 3 1 env15141 = env15142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15141 == env15142) = true)

def env15143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4161,62709,120015,21762,8328,65,75787,115151,102879,35325,1500,119927,256,21792,46212,74251]

theorem envBound15143 : H12AffineFastState.Bounded env15143 := by
  intro p hp
  have h : env15143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15122_15143 : H12AffineEnvironment.transform 16 24909 env15122 = env15143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env15122 == env15143) = true)

def env15144 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4161,62589,119879,21762,8192,65,75787,115015,102743,35189,1364,119927,256,21792,46092,74251]

theorem envBound15144 : H12AffineFastState.Bounded env15144 := by
  intro p hp
  have h : env15144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15143_15144 : H12AffineEnvironment.transform 6 8 env15143 = env15144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15143 == env15144) = true)

theorem identity15144 : scanCanonicalize (H12AffineFastState.compose env15144 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15144 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15145 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,13389,108926,1024,32769,4161,41341,98631,2,8192,65,75787,103495,102743,35189,1364,98679,256,32,46092,74251]

theorem envBound15145 : H12AffineFastState.Bounded env15145 := by
  intro p hp
  have h : env15145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15144_15145 : H12AffineEnvironment.transform 13 5376 env15144 = env15145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15144 == env15145) = true)

theorem identity15145 : scanCanonicalize (H12AffineFastState.compose env15145 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15145 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env15146 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,65536,13389,76159,1024,0,4161,8572,65862,2,8192,65,75787,70726,69974,2420,1364,65910,256,32,13325,74251]

theorem envBound15146 : H12AffineFastState.Bounded env15146 := by
  intro p hp
  have h : env15146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15145_15146 : H12AffineEnvironment.transform 14 1 env15145 = env15146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15145 == env15146) = true)

theorem identity15146 : scanCanonicalize (H12AffineFastState.compose env15146 (packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound15146 : packedSelected [0,1,2,3,5,7,8,10,14,19] rootPS < 2^1333 := by decide +kernel

def env15147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,1,8574,13389,2049,1024,0,4161,8572,8248,2,8192,65,2421,13624,12328,2420,1364,8200,256,32,13325,885]

theorem envBound15147 : H12AffineFastState.Bounded env15147 := by
  intro p hp
  have h : env15147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15146_15147 : H12AffineEnvironment.transform 15 8574 env15146 = env15147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env15146 == env15147) = true)

theorem identity15147 : scanCanonicalize (H12AffineFastState.compose env15147 (packedSelected [0,2,4,7,9,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15147 : packedSelected [0,2,4,7,9,16] rootPS < 2^1333 := by decide +kernel

def env15148 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5236,1,8202,13389,2049,1024,0,4161,8200,8248,2,8192,65,2049,13388,12328,2048,1056,8200,116,32,13325,513]

theorem envBound15148 : H12AffineFastState.Bounded env15148 := by
  intro p hp
  have h : env15148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15147_15148 : H12AffineEnvironment.transform 7 116 env15147 = env15148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15147 == env15148) = true)

theorem identity15148 : scanCanonicalize (H12AffineFastState.compose env15148 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound15148 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env15149 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,1053,5236,1,1047,4176,2049,1024,0,4161,1045,1061,2,1053,65,2049,4177,5173,2048,1056,1045,116,32,4112,513]

theorem envBound15149 : H12AffineFastState.Bounded env15149 := by
  intro p hp
  have h : env15149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15148_15149 : H12AffineEnvironment.transform 12 1053 env15148 = env15149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env15148 == env15149) = true)

theorem identity15149 : scanCanonicalize (H12AffineFastState.compose env15149 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15149 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15150 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,4096,40,4161,1,34,4176,2049,53,0,4161,32,16,2,40,65,2049,4177,4096,2048,21,32,116,32,4112,513]

theorem envBound15150 : H12AffineFastState.Bounded env15150 := by
  intro p hp
  have h : env15150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15149_15150 : H12AffineEnvironment.transform 9 53 env15149 = env15150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15149 == env15150) = true)

theorem identity15150 : scanCanonicalize (H12AffineFastState.compose env15150 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound15150 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15151 : List Nat := [2,4,8,16,32,64,8,116,512,53,603,4096,40,4161,1,34,4176,602,53,0,4161,32,16,2,40,65,602,4177,4096,603,21,32,116,32,4112,513]

theorem envBound15151 : H12AffineFastState.Bounded env15151 := by
  intro p hp
  have h : env15151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15150_15151 : H12AffineEnvironment.transform 10 603 env15150 = env15151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env15150 == env15151) = true)

theorem identity15151 : scanCanonicalize (H12AffineFastState.compose env15151 (packedSelected [0,1] rootPS)) = affineNative (2^(11+1) ^^^ 71) := by decide +kernel

theorem selectedBound15151 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15152 : List Nat := [2,4,8,16,32,64,8,116,512,53,603,71,40,6,1,34,23,602,53,0,6,32,16,2,40,65,602,22,71,603,21,32,116,32,87,513]

theorem envBound15152 : H12AffineFastState.Bounded env15152 := by
  intro p hp
  have h : env15152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15151_15152 : H12AffineEnvironment.transform 11 71 env15151 = env15152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 71 env15151 == env15152) = true)

theorem identity15152 : scanCanonicalize (H12AffineFastState.compose env15152 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15152 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15153 : List Nat := [2,4,8,16,32,16,8,36,512,53,523,23,40,6,1,34,23,522,53,0,6,32,16,2,40,17,522,22,23,523,21,32,36,32,7,513]

theorem envBound15153 : H12AffineFastState.Bounded env15153 := by
  intro p hp
  have h : env15153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15152_15153 : H12AffineEnvironment.transform 5 16 env15152 = env15153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15152 == env15153) = true)

theorem identity15153 : scanCanonicalize (H12AffineFastState.compose env15153 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 57) := by decide +kernel

theorem selectedBound15153 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15154 : List Nat := [2,4,8,16,32,16,8,36,57,53,50,23,40,6,1,34,23,51,53,0,6,32,16,2,40,17,51,22,23,50,21,32,36,32,7,56]

theorem envBound15154 : H12AffineFastState.Bounded env15154 := by
  intro p hp
  have h : env15154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15153_15154 : H12AffineEnvironment.transform 8 57 env15153 = env15154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 57 env15153 == env15154) = true)

theorem identity15154 : scanCanonicalize (H12AffineFastState.compose env15154 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound15154 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15155 : List Nat := [2,4,8,3,32,3,8,36,42,38,33,4,40,6,1,34,4,32,38,0,6,32,3,2,40,2,32,5,4,33,6,32,36,32,7,43]

theorem envBound15155 : H12AffineFastState.Bounded env15155 := by
  intro p hp
  have h : env15155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15154_15155 : H12AffineEnvironment.transform 3 3 env15154 = env15155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env15154 == env15155) = true)

theorem identity15155 : scanCanonicalize (H12AffineFastState.compose env15155 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound15155 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15156 : List Nat := [2,4,8,3,6,3,8,2,12,0,7,4,14,6,1,4,4,6,0,0,6,6,3,2,14,2,6,5,4,7,6,6,2,6,7,13]

theorem envBound15156 : H12AffineFastState.Bounded env15156 := by
  intro p hp
  have h : env15156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15155_15156 : H12AffineEnvironment.transform 4 6 env15155 = env15156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env15155 == env15156) = true)

def env15157 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,130174,1024,32769,4161,62588,119878,21762,8193,65,75787,115014,102742,35188,1365,119927,256,21792,46093,74251]

theorem envBound15157 : H12AffineFastState.Bounded env15157 := by
  intro p hp
  have h : env15157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15143_15157 : H12AffineEnvironment.transform 6 9 env15143 = env15157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15143 == env15157) = true)

theorem identity15157 : scanCanonicalize (H12AffineFastState.compose env15157 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15157 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15158 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,24909,67619,1024,29788,4161,33,73755,21762,8193,65,75787,79131,91403,32041,1365,73770,256,21792,16464,74251]

theorem envBound15158 : H12AffineFastState.Bounded env15158 := by
  intro p hp
  have h : env15158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15157_15158 : H12AffineEnvironment.transform 14 29789 env15157 = env15158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15157 == env15158) = true)

def env15159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513341,510001,8328,65,2409525,2510013,396524,2136508,2102685,2373705,256,21792,46212,2175562]

theorem envBound15159 : H12AffineFastState.Bounded env15159 := by
  intro p hp
  have h : env15159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15089_15159 : H12AffineEnvironment.transform 21 169401 env15089 = env15159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env15089 == env15159) = true)

def env15160 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412157,510001,8328,65,316533,417021,396524,35324,1501,272393,256,21792,46212,74250]

theorem envBound15160 : H12AffineFastState.Bounded env15160 := by
  intro p hp
  have h : env15160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15159_15160 : H12AffineEnvironment.transform 20 4160 env15159 = env15160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15159 == env15160) = true)

theorem identity15160 : scanCanonicalize (H12AffineFastState.compose env15160 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223718) := by decide +kernel

theorem selectedBound15160 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15161 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223718,1024,32769,4160,169401,73755,41431,8328,65,245139,79131,91402,35324,1501,213487,256,21792,46212,74250]

theorem envBound15161 : H12AffineFastState.Bounded env15161 := by
  intro p hp
  have h : env15161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15160_15161 : H12AffineEnvironment.transform 17 223718 env15160 = env15161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223718 env15160 == env15161) = true)

def env15162 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24908,67754,1024,32769,4160,62709,73755,41431,8328,65,122079,79131,91402,35324,1501,73891,256,21792,46212,74250]

theorem envBound15162 : H12AffineFastState.Bounded env15162 := by
  intro p hp
  have h : env15162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15161_15162 : H12AffineEnvironment.transform 16 24908 env15161 = env15162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env15161 == env15162) = true)

theorem identity15162 : scanCanonicalize (H12AffineFastState.compose env15162 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(14+1) ^^^ 9697) := by decide +kernel

theorem selectedBound15162 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env15163 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9697,65536,24908,67754,1024,9696,4160,20756,73755,1078,8328,65,96574,79131,91402,11293,1501,73891,256,21792,4453,74250]

theorem envBound15163 : H12AffineFastState.Bounded env15163 := by
  intro p hp
  have h : env15163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15162_15163 : H12AffineEnvironment.transform 14 9697 env15162 = env15163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9697 env15162 == env15163) = true)

theorem identity15163 : scanCanonicalize (H12AffineFastState.compose env15163 (packedSelected [2,4,6,8,10,12,15,16,17,19,22,26,28] rootPS)) = affineNative (2^(15+1) ^^^ 20531) := by decide +kernel

theorem selectedBound15163 : packedSelected [2,4,6,8,10,12,15,16,17,19,22,26,28] rootPS < 2^1333 := by decide +kernel

def env15164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9697,20531,24908,22681,1024,9696,4160,20756,28712,1078,8328,65,10509,25896,13625,11293,1501,28816,256,21792,4453,29241]

theorem envBound15164 : H12AffineFastState.Bounded env15164 := by
  intro p hp
  have h : env15164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15163_15164 : H12AffineEnvironment.transform 15 20531 env15163 = env15164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20531 env15163 == env15164) = true)

theorem identity15164 : scanCanonicalize (H12AffineFastState.compose env15164 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 1456) := by decide +kernel

theorem selectedBound15164 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env15165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,81,20531,17660,22681,1024,80,4160,20756,21912,1078,1336,65,3261,16536,4233,2477,1501,21792,256,21792,4453,22409]

theorem envBound15165 : H12AffineFastState.Bounded env15165 := by
  intro p hp
  have h : env15165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15164_15165 : H12AffineEnvironment.transform 12 1456 env15164 = env15165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env15164 == env15165) = true)

theorem identity15165 : scanCanonicalize (H12AffineFastState.compose env15165 (packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound15165 : packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env15166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,5593,81,1514,4389,3392,1024,80,4160,1229,65,1078,1336,65,3261,5441,4233,2477,1501,249,256,249,4453,592]

theorem envBound15166 : H12AffineFastState.Bounded env15166 := by
  intro p hp
  have h : env15166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15165_15166 : H12AffineEnvironment.transform 13 5593 env15165 = env15166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env15165 == env15166) = true)

theorem identity15166 : scanCanonicalize (H12AffineFastState.compose env15166 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound15166 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env15167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,1456,3173,81,1514,2201,3392,1024,80,2556,1229,65,1078,1336,65,3261,3325,2357,2477,1501,249,256,249,2265,592]

theorem envBound15167 : H12AffineFastState.Bounded env15167 := by
  intro p hp
  have h : env15167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15166_15167 : H12AffineEnvironment.transform 11 2492 env15166 = env15167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env15166 == env15167) = true)

theorem identity15167 : scanCanonicalize (H12AffineFastState.compose env15167 (packedSelected [1,2,3,5,6,8,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound15167 : packedSelected [1,2,3,5,6,8,11,12] rootPS < 2^1333 := by decide +kernel

def env15168 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,2113,1101,3173,81,1047,2201,3261,1024,80,2049,1229,65,1078,1221,65,3261,3325,2248,2128,1056,249,253,249,2265,592]

theorem envBound15168 : H12AffineFastState.Bounded env15168 := by
  intro p hp
  have h : env15168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15167_15168 : H12AffineEnvironment.transform 7 253 env15167 = env15168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env15167 == env15168) = true)

theorem identity15168 : scanCanonicalize (H12AffineFastState.compose env15168 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound15168 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15169 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1125,1060,1101,0,81,1047,1276,216,1024,80,1124,1229,65,1078,1221,65,216,152,1197,1077,1056,249,253,249,1212,592]

theorem envBound15169 : H12AffineFastState.Bounded env15169 := by
  intro p hp
  have h : env15169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15168_15169 : H12AffineEnvironment.transform 10 1125 env15168 = env15169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env15168 == env15169) = true)

theorem identity15169 : scanCanonicalize (H12AffineFastState.compose env15169 (packedSelected [4,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound15169 : packedSelected [4,6,9,10] rootPS < 2^1333 := by decide +kernel

def env15170 : List Nat := [2,4,8,16,32,64,128,253,512,84,49,112,25,0,81,67,168,216,84,80,48,153,65,98,145,65,216,152,249,97,116,249,253,249,232,592]

theorem envBound15170 : H12AffineFastState.Bounded env15170 := by
  intro p hp
  have h : env15170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15169_15170 : H12AffineEnvironment.transform 9 84 env15169 = env15170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env15169 == env15170) = true)

theorem identity15170 : scanCanonicalize (H12AffineFastState.compose env15170 (packedSelected [1,3,5,6,8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound15170 : packedSelected [1,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env15171 : List Nat := [2,4,8,16,32,64,24,101,512,84,49,112,25,0,81,67,48,64,84,80,48,1,65,98,9,65,64,0,97,97,116,97,101,97,112,592]

theorem envBound15171 : H12AffineFastState.Bounded env15171 := by
  intro p hp
  have h : env15171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15170_15171 : H12AffineEnvironment.transform 6 24 env15170 = env15171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env15170 == env15171) = true)

theorem identity15171 : scanCanonicalize (H12AffineFastState.compose env15171 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound15171 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15172 : List Nat := [2,4,8,16,32,49,24,20,512,37,49,1,25,0,32,50,48,49,37,33,48,1,48,19,9,48,49,0,16,16,5,16,20,16,1,545]

theorem envBound15172 : H12AffineFastState.Bounded env15172 := by
  intro p hp
  have h : env15172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15171_15172 : H12AffineEnvironment.transform 5 49 env15171 = env15172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env15171 == env15172) = true)

theorem identity15172 : scanCanonicalize (H12AffineFastState.compose env15172 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15172 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env15173 : List Nat := [2,4,8,16,0,17,24,20,512,5,17,1,25,0,0,18,16,17,5,1,16,1,16,19,9,16,17,0,16,16,5,16,20,16,1,513]

theorem envBound15173 : H12AffineFastState.Bounded env15173 := by
  intro p hp
  have h : env15173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15172_15173 : H12AffineEnvironment.transform 4 0 env15172 = env15173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15172 == env15173) = true)

theorem identity15173 : scanCanonicalize (H12AffineFastState.compose env15173 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound15173 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15174 : List Nat := [2,4,8,11,0,10,3,15,512,5,10,1,2,0,0,9,11,10,5,1,11,1,11,8,9,11,10,0,11,11,5,11,15,11,1,513]

theorem envBound15174 : H12AffineFastState.Bounded env15174 := by
  intro p hp
  have h : env15174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15173_15174 : H12AffineEnvironment.transform 3 11 env15173 = env15174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env15173 == env15174) = true)

theorem identity15174 : scanCanonicalize (H12AffineFastState.compose env15174 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound15174 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15175 : List Nat := [2,4,5,6,0,7,3,2,512,5,7,1,2,0,0,4,6,7,5,1,6,1,6,5,4,6,7,0,6,6,5,6,2,6,1,513]

theorem envBound15175 : H12AffineFastState.Bounded env15175 := by
  intro p hp
  have h : env15175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15174_15175 : H12AffineEnvironment.transform 2 5 env15174 = env15175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env15174 == env15175) = true)

theorem identity15175 : scanCanonicalize (H12AffineFastState.compose env15175 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound15175 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15176 : List Nat := [2,3,2,1,0,0,3,2,512,2,0,1,2,0,0,3,1,0,2,1,1,1,1,2,3,1,0,0,1,1,2,1,2,1,1,513]

theorem envBound15176 : H12AffineFastState.Bounded env15176 := by
  intro p hp
  have h : env15176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15175_15176 : H12AffineEnvironment.transform 1 3 env15175 = env15176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env15175 == env15176) = true)

theorem identity15176 : scanCanonicalize (H12AffineFastState.compose env15176 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound15176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15177 : List Nat := [2,3,2,1,0,0,3,2,2,2,0,1,2,0,0,3,1,0,2,1,1,1,1,2,3,1,0,0,1,1,2,1,2,1,1,3]

theorem envBound15177 : H12AffineFastState.Bounded env15177 := by
  intro p hp
  have h : env15177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15176_15177 : H12AffineEnvironment.transform 8 2 env15176 = env15177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env15176 == env15177) = true)

def env15178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,67755,1024,32769,4160,62708,73755,41431,8328,65,122078,79131,91402,35324,1501,73890,256,21792,46212,74250]

theorem envBound15178 : H12AffineFastState.Bounded env15178 := by
  intro p hp
  have h : env15178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15161_15178 : H12AffineEnvironment.transform 16 24909 env15161 = env15178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env15161 == env15178) = true)

theorem identity15178 : scanCanonicalize (H12AffineFastState.compose env15178 (packedSelected [1,10,12,15,18,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound15178 : packedSelected [1,10,12,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env15179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,24909,43048,1024,32769,4160,62708,32920,41431,8328,65,31837,38296,50569,35324,1501,32801,256,21792,46212,33417]

theorem envBound15179 : H12AffineFastState.Bounded env15179 := by
  intro p hp
  have h : env15179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15178_15179 : H12AffineEnvironment.transform 15 41091 env15178 = env15179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env15178 == env15179) = true)

theorem identity15179 : scanCanonicalize (H12AffineFastState.compose env15179 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15179 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env15180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,33246,16400,35189,1024,32769,4160,54697,32920,32906,469,65,23808,38296,50569,35324,1501,32801,256,21792,38361,33417]

theorem envBound15180 : H12AffineFastState.Bounded env15180 := by
  intro p hp
  have h : env15180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15179_15180 : H12AffineEnvironment.transform 12 349 env15179 = env15180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15179 == env15180) = true)

theorem identity15180 : scanCanonicalize (H12AffineFastState.compose env15180 (packedSelected [1,2,4,6,8,16,17,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound15180 : packedSelected [1,2,4,6,8,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env15181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21761,21727,16400,23668,1024,21760,4160,168,21913,21899,469,65,23808,16537,4232,23805,1501,21792,256,21792,16600,22408]

theorem envBound15181 : H12AffineFastState.Bounded env15181 := by
  intro p hp
  have h : env15181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15180_15181 : H12AffineEnvironment.transform 14 21761 env15180 = env15181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env15180 == env15181) = true)

theorem identity15181 : scanCanonicalize (H12AffineFastState.compose env15181 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound15181 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env15182 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,137,343,5528,2556,1024,136,4160,168,17,3,469,65,2184,5393,4232,2421,1501,168,256,168,5456,512]

theorem envBound15182 : H12AffineFastState.Bounded env15182 := by
  intro p hp
  have h : env15182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15181_15182 : H12AffineEnvironment.transform 13 5512 env15181 = env15182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env15181 == env15182) = true)

theorem identity15182 : scanCanonicalize (H12AffineFastState.compose env15182 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15182 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15183 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,349,5409,32,343,5425,2389,1024,33,4160,1,17,3,380,65,2081,5393,4129,2421,1396,1,256,1,5456,512]

theorem envBound15183 : H12AffineFastState.Bounded env15183 := by
  intro p hp
  have h : env15183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15182_15183 : H12AffineEnvironment.transform 6 41 env15182 = env15183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15182 == env15183) = true)

theorem identity15183 : scanCanonicalize (H12AffineFastState.compose env15183 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3345) := by decide +kernel

theorem selectedBound15183 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env15184 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,3345,349,2096,32,343,2080,2389,1024,33,3409,1,17,3,380,65,2081,2048,3376,2421,1396,1,256,1,2113,512]

theorem envBound15184 : H12AffineFastState.Bounded env15184 := by
  intro p hp
  have h : env15184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15183_15184 : H12AffineEnvironment.transform 11 3345 env15183 = env15184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3345 env15183 == env15184) = true)

theorem identity15184 : scanCanonicalize (H12AffineFastState.compose env15184 (packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15184 : packedSelected [0,1,3,4,5,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env15185 : List Nat := [2,4,8,16,32,64,41,5,512,1024,2048,3092,88,2096,32,82,2080,2128,1024,33,3156,1,17,3,121,65,2081,2048,3125,2160,1137,1,5,1,2113,512]

theorem envBound15185 : H12AffineFastState.Bounded env15185 := by
  intro p hp
  have h : env15185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15184_15185 : H12AffineEnvironment.transform 7 5 env15184 = env15185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15184 == env15185) = true)

theorem identity15185 : scanCanonicalize (H12AffineFastState.compose env15185 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 47) := by decide +kernel

theorem selectedBound15185 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15186 : List Nat := [2,4,8,16,32,64,41,5,512,47,2048,2107,88,2096,32,82,2080,2128,47,33,2171,1,17,3,121,65,2081,2048,2074,2160,94,1,5,1,2113,512]

theorem envBound15186 : H12AffineFastState.Bounded env15186 := by
  intro p hp
  have h : env15186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15185_15186 : H12AffineEnvironment.transform 9 47 env15185 = env15186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 47 env15185 == env15186) = true)

theorem identity15186 : scanCanonicalize (H12AffineFastState.compose env15186 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound15186 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env15187 : List Nat := [2,4,8,16,32,64,41,5,512,47,97,90,88,81,32,82,65,49,47,33,26,1,17,3,121,65,64,97,123,17,94,1,5,1,32,512]

theorem envBound15187 : H12AffineFastState.Bounded env15187 := by
  intro p hp
  have h : env15187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15186_15187 : H12AffineEnvironment.transform 10 97 env15186 = env15187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env15186 == env15187) = true)

theorem identity15187 : scanCanonicalize (H12AffineFastState.compose env15187 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15187 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env15188 : List Nat := [2,4,8,16,32,17,41,5,512,47,48,11,9,0,32,3,16,49,47,33,26,1,17,3,40,16,17,48,42,17,15,1,5,1,32,512]

theorem envBound15188 : H12AffineFastState.Bounded env15188 := by
  intro p hp
  have h : env15188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15187_15188 : H12AffineEnvironment.transform 5 17 env15187 = env15188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15187 == env15188) = true)

theorem identity15188 : scanCanonicalize (H12AffineFastState.compose env15188 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound15188 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15189 : List Nat := [2,4,3,16,32,17,34,5,512,36,48,0,2,0,32,3,16,49,36,33,17,1,17,3,35,16,17,48,33,17,4,1,5,1,32,512]

theorem envBound15189 : H12AffineFastState.Bounded env15189 := by
  intro p hp
  have h : env15189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15188_15189 : H12AffineEnvironment.transform 2 3 env15188 = env15189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env15188 == env15189) = true)

theorem identity15189 : scanCanonicalize (H12AffineFastState.compose env15189 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15189 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15190 : List Nat := [2,4,3,16,1,17,3,5,512,5,17,0,2,0,1,3,16,16,5,0,17,1,17,3,2,16,17,17,0,17,4,1,5,1,1,512]

theorem envBound15190 : H12AffineFastState.Bounded env15190 := by
  intro p hp
  have h : env15190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15189_15190 : H12AffineEnvironment.transform 4 1 env15189 = env15190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15189 == env15190) = true)

theorem identity15190 : scanCanonicalize (H12AffineFastState.compose env15190 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound15190 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15191 : List Nat := [2,4,3,16,1,17,3,5,4,5,17,0,2,0,1,3,16,16,5,0,17,1,17,3,2,16,17,17,0,17,4,1,5,1,1,4]

theorem envBound15191 : H12AffineFastState.Bounded env15191 := by
  intro p hp
  have h : env15191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15190_15191 : H12AffineEnvironment.transform 8 4 env15190 = env15191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env15190 == env15191) = true)

theorem identity15191 : scanCanonicalize (H12AffineFastState.compose env15191 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15191 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env15192 : List Nat := [2,4,3,0,1,1,3,5,4,5,1,0,2,0,1,3,0,0,5,0,1,1,1,3,2,0,1,1,0,1,4,1,5,1,1,4]

theorem envBound15192 : H12AffineFastState.Bounded env15192 := by
  intro p hp
  have h : env15192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15191_15192 : H12AffineEnvironment.transform 3 0 env15191 = env15192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15191 == env15192) = true)

theorem identity15192 : scanCanonicalize (H12AffineFastState.compose env15192 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound15192 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15193 : List Nat := [2,2,3,0,1,1,3,3,2,3,1,0,2,0,1,3,0,0,3,0,1,1,1,3,2,0,1,1,0,1,2,1,3,1,1,2]

theorem envBound15193 : H12AffineFastState.Bounded env15193 := by
  intro p hp
  have h : env15193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15192_15193 : H12AffineEnvironment.transform 1 2 env15192 = env15193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env15192 == env15193) = true)

def env15194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412156,510001,8328,65,316532,417020,396524,35325,1500,272392,256,21792,46212,74251]

theorem envBound15194 : H12AffineFastState.Bounded env15194 := by
  intro p hp
  have h : env15194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15159_15194 : H12AffineEnvironment.transform 20 4161 env15159 = env15194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15159 == env15194) = true)

theorem identity15194 : scanCanonicalize (H12AffineFastState.compose env15194 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound15194 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,169401,412156,400622,8328,65,316532,417020,396524,35325,1500,272392,256,21792,46212,63188]

theorem envBound15195 : H12AffineFastState.Bounded env15195 := by
  intro p hp
  have h : env15195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15194_15195 : H12AffineEnvironment.transform 15 54495 env15194 = env15195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env15194 == env15195) = true)

def env15196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146912,1024,32769,4161,169401,29724,8462,8328,65,190868,24860,12556,35325,1500,136680,256,21792,46212,63188]

theorem envBound15196 : H12AffineFastState.Bounded env15196 := by
  intro p hp
  have h : env15196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15195_15196 : H12AffineEnvironment.transform 17 146912 env15195 = env15196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env15195 == env15196) = true)

theorem identity15196 : scanCanonicalize (H12AffineFastState.compose env15196 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15196 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env15197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30083,131072,146912,1024,8541,4161,144613,29724,8462,8328,65,149704,24860,12556,10401,1500,136680,256,21792,5592,22408]

theorem envBound15197 : H12AffineFastState.Bounded env15197 := by
  intro p hp
  have h : env15197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15196_15197 : H12AffineEnvironment.transform 14 8540 env15196 = env15197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15196 == env15197) = true)

theorem identity15197 : scanCanonicalize (H12AffineFastState.compose env15197 (packedSelected [0,3,4,5,7,8,17,22,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15197 : packedSelected [0,3,4,5,7,8,17,22,28] rootPS < 2^1333 := by decide +kernel

def env15198 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,30083,131072,146864,1024,8461,4113,144565,29724,8462,8328,17,149656,24860,12556,10401,1420,136632,256,21792,5512,22408]

theorem envBound15198 : H12AffineFastState.Bounded env15198 := by
  intro p hp
  have h : env15198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15197_15198 : H12AffineEnvironment.transform 5 16 env15197 = env15198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15197 == env15198) = true)

theorem identity15198 : scanCanonicalize (H12AffineFastState.compose env15198 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound15198 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env15199 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8460,8202,131072,146864,1024,8461,4113,144565,8597,8462,8328,17,138513,13461,12556,10401,1420,136632,256,169,5512,513]

theorem envBound15199 : H12AffineFastState.Bounded env15199 := by
  intro p hp
  have h : env15199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15198_15199 : H12AffineEnvironment.transform 13 5513 env15198 = env15199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env15198 == env15199) = true)

theorem identity15199 : scanCanonicalize (H12AffineFastState.compose env15199 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound15199 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15200 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8460,8202,5392,10400,1024,8461,4113,8613,8597,8462,8328,17,2049,13461,12556,10401,1420,168,256,169,5512,513]

theorem envBound15200 : H12AffineFastState.Bounded env15200 := by
  intro p hp
  have h : env15200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15199_15200 : H12AffineEnvironment.transform 16 5392 env15199 = env15200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env15199 == env15200) = true)

def env15201 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,146913,1024,32769,4161,169401,29725,8463,8328,65,190869,24861,12557,35325,1500,136681,256,21792,46212,63188]

theorem envBound15201 : H12AffineFastState.Bounded env15201 := by
  intro p hp
  have h : env15201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15195_15201 : H12AffineEnvironment.transform 17 146913 env15195 = env15201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env15195 == env15201) = true)

theorem identity15201 : scanCanonicalize (H12AffineFastState.compose env15201 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound15201 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env15202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29963,131072,146913,1024,8661,4161,144493,29725,8463,8328,65,149569,24861,12557,10281,1500,136681,256,21792,5456,22272]

theorem envBound15202 : H12AffineFastState.Bounded env15202 := by
  intro p hp
  have h : env15202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15201_15202 : H12AffineEnvironment.transform 14 8660 env15201 = env15202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env15201 == env15202) = true)

theorem identity15202 : scanCanonicalize (H12AffineFastState.compose env15202 (packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound15202 : packedSelected [0,1,4,5,7,8,11,17,22,24,32] rootPS < 2^1333 := by decide +kernel

def env15203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,29963,5529,10360,1024,8661,4161,8692,29725,8463,8328,65,24024,24861,12557,10281,1500,112,256,21792,5456,22272]

theorem envBound15203 : H12AffineFastState.Bounded env15203 := by
  intro p hp
  have h : env15203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15202_15203 : H12AffineEnvironment.transform 16 5529 env15202 = env15203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env15202 == env15203) = true)

theorem identity15203 : scanCanonicalize (H12AffineFastState.compose env15203 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound15203 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env15204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,8660,8322,5529,10360,1024,8661,4161,8692,8596,8463,8328,65,2129,13460,12557,10281,1500,112,256,169,5456,649]

theorem envBound15204 : H12AffineFastState.Bounded env15204 := by
  intro p hp
  have h : env15204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15203_15204 : H12AffineEnvironment.transform 13 5513 env15203 = env15204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env15203 == env15204) = true)

theorem identity15204 : scanCanonicalize (H12AffineFastState.compose env15204 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15204 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env15205 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5513,509,171,5529,2129,1024,508,4161,477,445,294,161,65,2129,5309,4388,2048,1500,112,256,169,5456,649]

theorem envBound15205 : H12AffineFastState.Bounded env15205 := by
  intro p hp
  have h : env15205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15204_15205 : H12AffineEnvironment.transform 12 41 env15204 = env15205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15204 == env15205) = true)

theorem identity15205 : scanCanonicalize (H12AffineFastState.compose env15205 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15205 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env15206 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,41,5513,428,171,5529,2048,1024,429,4112,396,445,294,161,16,2048,5309,4388,2048,1421,33,256,169,5377,649]

theorem envBound15206 : H12AffineFastState.Bounded env15206 := by
  intro p hp
  have h : env15206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15205_15206 : H12AffineEnvironment.transform 5 17 env15205 = env15206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15205 == env15206) = true)

theorem identity15206 : scanCanonicalize (H12AffineFastState.compose env15206 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound15206 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env15207 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1061,41,428,428,171,444,2048,1024,429,1077,396,445,294,161,16,2048,152,1281,2048,1421,33,256,169,292,649]

theorem envBound15207 : H12AffineFastState.Bounded env15207 := by
  intro p hp
  have h : env15207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15206_15207 : H12AffineEnvironment.transform 11 1061 env15206 = env15207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env15206 == env15207) = true)

theorem identity15207 : scanCanonicalize (H12AffineFastState.compose env15207 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound15207 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15208 : List Nat := [2,4,8,16,32,17,128,256,512,409,2048,444,41,428,428,171,444,2048,409,429,428,396,445,294,161,16,2048,152,152,2048,20,33,256,169,292,649]

theorem envBound15208 : H12AffineFastState.Bounded env15208 := by
  intro p hp
  have h : env15208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15207_15208 : H12AffineEnvironment.transform 9 409 env15207 = env15208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env15207 == env15208) = true)

theorem identity15208 : scanCanonicalize (H12AffineFastState.compose env15208 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound15208 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env15209 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,16,41,0,0,171,16,2048,53,1,0,32,17,138,161,16,2048,152,152,2048,20,33,172,169,136,649]

theorem envBound15209 : H12AffineFastState.Bounded env15209 := by
  intro p hp
  have h : env15209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15208_15209 : H12AffineEnvironment.transform 7 172 env15208 = env15209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env15208 == env15209) = true)

theorem identity15209 : scanCanonicalize (H12AffineFastState.compose env15209 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 152) := by decide +kernel

theorem selectedBound15209 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env15210 : List Nat := [2,4,8,16,32,17,128,172,512,53,152,16,41,0,0,171,16,152,53,1,0,32,17,138,161,16,152,152,152,152,20,33,172,169,136,649]

theorem envBound15210 : H12AffineFastState.Bounded env15210 := by
  intro p hp
  have h : env15210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15209_15210 : H12AffineEnvironment.transform 10 152 env15209 = env15210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 152 env15209 == env15210) = true)

theorem identity15210 : scanCanonicalize (H12AffineFastState.compose env15210 (packedSelected [0,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound15210 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env15211 : List Nat := [2,4,8,16,32,17,9,37,512,53,17,16,41,0,0,34,16,17,53,1,0,32,17,3,40,16,17,17,17,17,20,33,37,32,1,512]

theorem envBound15211 : H12AffineFastState.Bounded env15211 := by
  intro p hp
  have h : env15211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15210_15211 : H12AffineEnvironment.transform 6 9 env15210 = env15211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15210 == env15211) = true)

theorem identity15211 : scanCanonicalize (H12AffineFastState.compose env15211 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound15211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15212 : List Nat := [2,4,8,16,32,17,9,37,17,53,17,16,41,0,0,34,16,17,53,1,0,32,17,3,40,16,17,17,17,17,20,33,37,32,1,17]

theorem envBound15212 : H12AffineFastState.Bounded env15212 := by
  intro p hp
  have h : env15212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15211_15212 : H12AffineEnvironment.transform 8 17 env15211 = env15212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env15211 == env15212) = true)

theorem identity15212 : scanCanonicalize (H12AffineFastState.compose env15212 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound15212 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15213 : List Nat := [2,4,8,16,15,17,9,10,17,26,17,16,6,0,0,13,16,17,26,1,0,15,17,3,7,16,17,17,17,17,20,14,10,15,1,17]

theorem envBound15213 : H12AffineFastState.Bounded env15213 := by
  intro p hp
  have h : env15213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15212_15213 : H12AffineEnvironment.transform 4 15 env15212 = env15213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env15212 == env15213) = true)

theorem identity15213 : scanCanonicalize (H12AffineFastState.compose env15213 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound15213 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15214 : List Nat := [2,4,8,14,15,15,9,10,15,4,15,14,6,0,0,13,14,15,4,1,0,15,15,3,7,14,15,15,15,15,10,14,10,15,1,15]

theorem envBound15214 : H12AffineFastState.Bounded env15214 := by
  intro p hp
  have h : env15214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15213_15214 : H12AffineEnvironment.transform 3 14 env15213 = env15214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env15213 == env15214) = true)

def env15215 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830976,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound15215 : H12AffineFastState.Bounded env15215 := by
  intro p hp
  have h : env15215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14970_15215 : H12AffineEnvironment.transform 18 1025 env14970 = env15215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env14970 == env15215) = true)

theorem identity15215 : scanCanonicalize (H12AffineFastState.compose env15215 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272560) := by decide +kernel

theorem selectedBound15215 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272560,16777216,8328,65,21227697,18973837,2391521,190640,17149089,23160257,257,19262493,19205560,17075063]

theorem envBound15216 : H12AffineFastState.Bounded env15216 := by
  intro p hp
  have h : env15216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15215_15216 : H12AffineEnvironment.transform 22 272560 env15215 = env15216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272560 env15215 == env15216) = true)

def env15217 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227577,18973701,2391401,190520,17148969,23160137,257,19262493,19205424,17075063]

theorem envBound15217 : H12AffineFastState.Bounded env15217 := by
  intro p hp
  have h : env15217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15216_15217 : H12AffineEnvironment.transform 6 8 env15216 = env15217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15216 == env15217) = true)

theorem identity15217 : scanCanonicalize (H12AffineFastState.compose env15217 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound15217 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15218 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,41311,8192,65,4409702,2172250,2391401,190520,331126,6407190,257,2444610,2468975,272936]

theorem envBound15218 : H12AffineFastState.Bounded env15218 := by
  intro p hp
  have h : env15218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15217_15218 : H12AffineEnvironment.transform 23 41311 env15217 = env15218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env15217 == env15218) = true)

def env15219 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,272440,41311,8192,65,4262262,2172250,2391401,43048,331126,6407190,257,2444610,2468975,272936]

theorem envBound15219 : H12AffineFastState.Bounded env15219 := by
  intro p hp
  have h : env15219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15218_15219 : H12AffineEnvironment.transform 16 16400 env15218 = env15219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env15218 == env15219) = true)

theorem identity15219 : scanCanonicalize (H12AffineFastState.compose env15219 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound15219 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15220 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,41311,8192,65,4262262,2172250,2118976,43048,75103,6407190,257,2188651,2196550,513]

theorem envBound15220 : H12AffineFastState.Bounded env15220 := by
  intro p hp
  have h : env15220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15219_15220 : H12AffineEnvironment.transform 17 10281 env15219 = env15220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15219 == env15220) = true)

theorem identity15220 : scanCanonicalize (H12AffineFastState.compose env15220 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound15220 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env15221 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,115734,4194304,17,41311,8192,65,4262262,57676,102742,43048,75103,4194304,257,41341,16464,513]

theorem envBound15221 : H12AffineFastState.Bounded env15221 := by
  intro p hp
  have h : env15221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15220_15221 : H12AffineEnvironment.transform 20 115734 env15220 = env15221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env15220 == env15221) = true)

theorem identity15221 : scanCanonicalize (H12AffineFastState.compose env15221 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound15221 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env15222 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,343,16400,10281,1025,32769,50497,4194304,17,41311,8192,65,4196385,57676,36865,43048,9224,4194304,257,41341,16464,513]

theorem envBound15222 : H12AffineFastState.Bounded env15222 := by
  intro p hp
  have h : env15222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15221_15222 : H12AffineEnvironment.transform 15 343 env15221 = env15222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env15221 == env15222) = true)

theorem identity15222 : scanCanonicalize (H12AffineFastState.compose env15222 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound15222 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env15223 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16400,10281,1025,8541,25629,4194304,17,3,8192,65,4196385,16400,12637,2420,9224,4194304,257,33,16464,513]

theorem envBound15223 : H12AffineFastState.Bounded env15223 := by
  intro p hp
  have h : env15223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15222_15223 : H12AffineEnvironment.transform 14 8540 env15222 = env15223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env15222 == env15223) = true)

theorem identity15223 : scanCanonicalize (H12AffineFastState.compose env15223 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound15223 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env15224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,343,16400,10281,1025,8541,25629,8572,17,3,8192,65,10589,16400,12637,2420,9224,8572,257,33,16464,513]

theorem envBound15224 : H12AffineFastState.Bounded env15224 := by
  intro p hp
  have h : env15224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15223_15224 : H12AffineEnvironment.transform 21 8572 env15223 = env15224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env15223 == env15224) = true)

theorem identity15224 : scanCanonicalize (H12AffineFastState.compose env15224 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 9340) := by decide +kernel

theorem selectedBound15224 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env15225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,9340,8540,343,9324,10281,1025,8541,97,8572,17,3,8192,65,10589,9324,12637,2420,9224,8572,257,33,9260,513]

theorem envBound15225 : H12AffineFastState.Bounded env15225 := by
  intro p hp
  have h : env15225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15224_15225 : H12AffineEnvironment.transform 13 9340 env15224 = env15225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9340 env15224 == env15225) = true)

theorem identity15225 : scanCanonicalize (H12AffineFastState.compose env15225 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound15225 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env15226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,1313,1,343,1329,2420,1025,0,97,33,17,3,349,65,2048,1329,4096,2420,1365,33,257,33,1393,513]

theorem envBound15226 : H12AffineFastState.Bounded env15226 := by
  intro p hp
  have h : env15226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15225_15226 : H12AffineEnvironment.transform 12 349 env15225 = env15226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env15225 == env15226) = true)

theorem identity15226 : scanCanonicalize (H12AffineFastState.compose env15226 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound15226 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15227 : List Nat := [2,4,8,16,32,64,8,256,512,785,2048,4096,349,560,1,343,544,2420,784,0,97,33,17,3,349,65,2048,544,4096,2420,580,33,257,33,608,513]

theorem envBound15227 : H12AffineFastState.Bounded env15227 := by
  intro p hp
  have h : env15227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15226_15227 : H12AffineEnvironment.transform 9 785 env15226 = env15227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env15226 == env15227) = true)

def env15228 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,272440,41311,8192,65,4262263,2172250,2391401,43049,331126,6407190,257,2444610,2468975,272936]

theorem envBound15228 : H12AffineFastState.Bounded env15228 := by
  intro p hp
  have h : env15228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15218_15228 : H12AffineEnvironment.transform 16 16401 env15218 = env15228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env15218 == env15228) = true)

def env15229 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,58396,4194304,272440,41311,8192,65,4262263,115014,301429,43049,331126,4268042,257,371038,346227,272936]

theorem envBound15229 : H12AffineFastState.Bounded env15229 := by
  intro p hp
  have h : env15229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15228_15229 : H12AffineEnvironment.transform 20 58396 env15228 = env15229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env15228 == env15229) = true)

def env15230 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58396,4194304,16,41311,8192,65,4262263,115014,45405,43049,75102,4268042,257,98678,90203,512]

theorem envBound15230 : H12AffineFastState.Bounded env15230 := by
  intro p hp
  have h : env15230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15229_15230 : H12AffineEnvironment.transform 17 10280 env15229 = env15230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15229 == env15230) = true)

theorem identity15230 : scanCanonicalize (H12AffineFastState.compose env15230 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound15230 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15231 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58396,4194304,16,41002,8192,65,4261890,114739,45096,43049,74795,4268042,116,98307,90203,512]

theorem envBound15231 : H12AffineFastState.Bounded env15231 := by
  intro p hp
  have h : env15231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15230_15231 : H12AffineEnvironment.transform 7 117 env15230 = env15231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env15230 == env15231) = true)

theorem identity15231 : scanCanonicalize (H12AffineFastState.compose env15231 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 62588) := by decide +kernel

theorem selectedBound15231 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15232 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58396,62588,16,41002,8192,65,130174,114739,45096,43049,74795,119926,116,98307,90203,512]

theorem envBound15232 : H12AffineFastState.Bounded env15232 := by
  intro p hp
  have h : env15232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15231_15232 : H12AffineEnvironment.transform 21 62588 env15231 = env15232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62588 env15231 == env15232) = true)

theorem identity15232 : scanCanonicalize (H12AffineFastState.compose env15232 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound15232 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15233 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,32768,65536,5221,10280,1025,32769,45160,40968,16,41002,8192,65,108554,103495,45096,43049,74795,98306,116,98307,78895,512]

theorem envBound15233 : H12AffineFastState.Bounded env15233 := by
  intro p hp
  have h : env15233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15232_15233 : H12AffineEnvironment.transform 13 5236 env15232 = env15233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env15232 == env15233) = true)

theorem identity15233 : scanCanonicalize (H12AffineFastState.compose env15233 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound15233 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15234 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,8201,65536,5221,10280,1025,8200,4193,1,16,35,8192,65,67587,78926,4129,2080,74795,73739,116,73738,78895,512]

theorem envBound15234 : H12AffineFastState.Bounded env15234 := by
  intro p hp
  have h : env15234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15233_15234 : H12AffineEnvironment.transform 14 8201 env15233 = env15234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env15233 == env15234) = true)

theorem identity15234 : scanCanonicalize (H12AffineFastState.compose env15234 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound15234 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env15235 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1092,65536,5221,3173,1025,1093,4193,1,16,35,1101,65,67587,69635,4129,2080,65638,66630,116,66631,69730,512]

theorem envBound15235 : H12AffineFastState.Bounded env15235 := by
  intro p hp
  have h : env15235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15234_15235 : H12AffineEnvironment.transform 12 1101 env15234 = env15235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env15234 == env15235) = true)

theorem identity15235 : scanCanonicalize (H12AffineFastState.compose env15235 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(15+1) ^^^ 6162) := by decide +kernel

theorem selectedBound15235 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env15236 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,1101,5236,1092,6162,5221,3173,1025,1093,4193,1,16,35,1101,65,4113,2065,4129,2080,6260,7252,116,7253,2160,512]

theorem envBound15236 : H12AffineFastState.Bounded env15236 := by
  intro p hp
  have h : env15236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15235_15236 : H12AffineEnvironment.transform 15 6162 env15235 = env15236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6162 env15235 == env15236) = true)

theorem identity15236 : scanCanonicalize (H12AffineFastState.compose env15236 (packedSelected [1,2,6,8,10,18] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound15236 : packedSelected [1,2,6,8,10,18] rootPS < 2^1333 := by decide +kernel

def env15237 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,120,4161,113,6162,4176,2128,52,112,4193,1,16,35,120,65,4113,2065,4129,2080,6260,6241,116,6240,2160,512]

theorem envBound15237 : H12AffineFastState.Bounded env15237 := by
  intro p hp
  have h : env15237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15236_15237 : H12AffineEnvironment.transform 9 53 env15236 = env15237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env15236 == env15237) = true)

theorem identity15237 : scanCanonicalize (H12AffineFastState.compose env15237 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound15237 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env15238 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,2096,120,2161,113,34,2144,2128,52,112,2129,1,16,35,120,65,2081,2065,2065,2080,68,81,116,80,2160,512]

theorem envBound15238 : H12AffineFastState.Bounded env15238 := by
  intro p hp
  have h : env15238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15237_15238 : H12AffineEnvironment.transform 11 2096 env15237 = env15238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env15237 == env15238) = true)

def env15239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58396,4194304,17,41311,8192,65,4262263,115014,45404,43049,75103,4268042,257,98679,90202,513]

theorem envBound15239 : H12AffineFastState.Bounded env15239 := by
  intro p hp
  have h : env15239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15229_15239 : H12AffineEnvironment.transform 17 10281 env15229 = env15239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15229 == env15239) = true)

theorem identity15239 : scanCanonicalize (H12AffineFastState.compose env15239 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound15239 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env15240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1025,8540,17729,4194304,17,2,8192,65,4262263,90139,4097,2420,75103,4268042,257,73770,90202,513]

theorem envBound15240 : H12AffineFastState.Bounded env15240 := by
  intro p hp
  have h : env15240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15239_15240 : H12AffineEnvironment.transform 14 8541 env15239 = env15240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env15239 == env15240) = true)

theorem identity15240 : scanCanonicalize (H12AffineFastState.compose env15240 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound15240 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env15241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,263,16401,10281,1025,8540,17729,4194304,17,2,8192,65,4196464,24860,4097,2420,9304,4202765,257,8493,24925,513]

theorem envBound15241 : H12AffineFastState.Bounded env15241 := by
  intro p hp
  have h : env15241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15240_15241 : H12AffineEnvironment.transform 15 263 env15240 = env15241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env15240 == env15241) = true)

theorem identity15241 : scanCanonicalize (H12AffineFastState.compose env15241 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound15241 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,263,16401,10281,1025,8540,17729,113,17,2,8192,65,2049,24860,4097,2420,9304,8572,257,8493,24925,513]

theorem envBound15242 : H12AffineFastState.Bounded env15242 := by
  intro p hp
  have h : env15242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15241_15242 : H12AffineEnvironment.transform 21 113 env15241 = env15242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env15241 == env15242) = true)

theorem identity15242 : scanCanonicalize (H12AffineFastState.compose env15242 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15242 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env15243 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,263,16401,10281,1025,8460,17681,33,17,2,8192,17,2049,24860,4097,2340,9224,8492,257,8493,24845,513]

theorem envBound15243 : H12AffineFastState.Bounded env15243 := by
  intro p hp
  have h : env15243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15242_15243 : H12AffineEnvironment.transform 5 16 env15242 = env15243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15242 == env15243) = true)

def env15244 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,58397,4194304,272440,41311,8192,65,4262263,115015,301428,43049,331126,4268043,257,371039,346226,272936]

theorem envBound15244 : H12AffineFastState.Bounded env15244 := by
  intro p hp
  have h : env15244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15228_15244 : H12AffineEnvironment.transform 20 58397 env15228 = env15244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env15228 == env15244) = true)

def env15245 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58397,4194304,16,41311,8192,65,4262263,115015,45404,43049,75102,4268043,257,98679,90202,512]

theorem envBound15245 : H12AffineFastState.Bounded env15245 := by
  intro p hp
  have h : env15245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15244_15245 : H12AffineEnvironment.transform 17 10280 env15244 = env15245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15244 == env15245) = true)

theorem identity15245 : scanCanonicalize (H12AffineFastState.compose env15245 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound15245 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15246 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58397,4194304,16,41003,8192,65,4261891,114739,45096,43049,74794,4268043,117,98307,90202,512]

theorem envBound15246 : H12AffineFastState.Bounded env15246 := by
  intro p hp
  have h : env15246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15245_15246 : H12AffineEnvironment.transform 7 116 env15245 = env15246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env15245 == env15246) = true)

theorem identity15246 : scanCanonicalize (H12AffineFastState.compose env15246 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 119926) := by decide +kernel

theorem selectedBound15246 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15247 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1025,32769,58397,119926,16,41003,8192,65,56437,114739,45096,43049,74794,62589,117,98307,90202,512]

theorem envBound15247 : H12AffineFastState.Bounded env15247 := by
  intro p hp
  have h : env15247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15246_15247 : H12AffineEnvironment.transform 21 119926 env15246 = env15247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119926 env15246 == env15247) = true)

theorem identity15247 : scanCanonicalize (H12AffineFastState.compose env15247 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29823) := by decide +kernel

theorem selectedBound15247 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15248 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,29823,16401,10280,1025,32769,58397,40969,16,41003,8192,65,56437,46156,45096,43049,20565,62589,117,62588,5157,512]

theorem envBound15248 : H12AffineFastState.Bounded env15248 := by
  intro p hp
  have h : env15248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15247_15248 : H12AffineEnvironment.transform 15 29823 env15247 = env15248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29823 env15247 == env15248) = true)

theorem identity15248 : scanCanonicalize (H12AffineFastState.compose env15248 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound15248 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env15249 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5205,32768,8234,5188,10280,1025,32769,45128,40969,16,41003,8192,65,34848,46156,45096,43049,1024,41000,117,41001,5157,512]

theorem envBound15249 : H12AffineFastState.Bounded env15249 := by
  intro p hp
  have h : env15249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15248_15249 : H12AffineEnvironment.transform 13 5205 env15248 = env15249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env15248 == env15249) = true)

theorem identity15249 : scanCanonicalize (H12AffineFastState.compose env15249 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 113) := by decide +kernel

theorem selectedBound15249 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15250 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5205,113,8234,5188,10280,1025,112,12345,8312,16,8282,8192,65,2129,13373,12377,10328,1024,8281,117,8280,5157,512]

theorem envBound15250 : H12AffineFastState.Bounded env15250 := by
  intro p hp
  have h : env15250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15249_15250 : H12AffineEnvironment.transform 14 113 env15249 = env15250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 113 env15249 == env15250) = true)

theorem identity15250 : scanCanonicalize (H12AffineFastState.compose env15250 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound15250 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env15251 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,2064,8192,3141,113,8234,3156,10280,1025,112,10281,8312,16,8282,8192,65,2129,11309,10313,10328,1024,8281,117,8280,3125,512]

theorem envBound15251 : H12AffineFastState.Bounded env15251 := by
  intro p hp
  have h : env15251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15250_15251 : H12AffineEnvironment.transform 11 2064 env15250 = env15251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env15250 == env15251) = true)

theorem identity15251 : scanCanonicalize (H12AffineFastState.compose env15251 (packedSelected [0,1,2,7,8,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound15251 : packedSelected [0,1,2,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env15252 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,8192,2080,113,8234,2097,10280,100,112,10281,8312,16,8282,8192,65,2129,10312,10313,10328,101,8281,117,8280,2128,512]

theorem envBound15252 : H12AffineFastState.Bounded env15252 := by
  intro p hp
  have h : env15252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15251_15252 : H12AffineEnvironment.transform 9 101 env15251 = env15252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env15251 == env15252) = true)

theorem identity15252 : scanCanonicalize (H12AffineFastState.compose env15252 (packedSelected [1,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound15252 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env15253 : List Nat := [2,4,8,16,32,64,8,116,512,101,2048,2064,88,2080,113,114,2097,2160,100,112,2161,32,16,2,88,65,2129,2064,2065,2048,101,1,117,0,2128,512]

theorem envBound15253 : H12AffineFastState.Bounded env15253 := by
  intro p hp
  have h : env15253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15252_15253 : H12AffineEnvironment.transform 12 88 env15252 = env15253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env15252 == env15253) = true)

theorem identity15253 : scanCanonicalize (H12AffineFastState.compose env15253 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15253 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env15254 : List Nat := [2,4,8,16,32,48,8,4,512,21,2048,2064,40,2080,1,2,2097,2048,20,0,2049,32,16,2,40,49,2081,2064,2065,2048,21,1,5,0,2080,512]

theorem envBound15254 : H12AffineFastState.Bounded env15254 := by
  intro p hp
  have h : env15254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15253_15254 : H12AffineEnvironment.transform 5 48 env15253 = env15254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15253 == env15254) = true)

theorem identity15254 : scanCanonicalize (H12AffineFastState.compose env15254 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15254 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15255 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,9,2049,1,2,2064,2048,20,0,2049,1,16,2,9,16,2048,2064,2065,2048,21,1,5,0,2049,512]

theorem envBound15255 : H12AffineFastState.Bounded env15255 := by
  intro p hp
  have h : env15255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15254_15255 : H12AffineEnvironment.transform 4 1 env15254 = env15255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15254 == env15255) = true)

theorem identity15255 : scanCanonicalize (H12AffineFastState.compose env15255 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound15255 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15256 : List Nat := [2,4,8,16,1,17,8,4,512,21,20,4,9,21,1,2,4,20,20,0,21,1,16,2,9,16,20,4,5,20,21,1,5,0,21,512]

theorem envBound15256 : H12AffineFastState.Bounded env15256 := by
  intro p hp
  have h : env15256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15255_15256 : H12AffineEnvironment.transform 10 20 env15255 = env15256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env15255 == env15256) = true)

theorem identity15256 : scanCanonicalize (H12AffineFastState.compose env15256 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound15256 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15257 : List Nat := [2,4,8,16,1,17,8,4,7,21,20,4,9,21,1,2,4,20,20,0,21,1,16,2,9,16,20,4,5,20,21,1,5,0,21,7]

theorem envBound15257 : H12AffineFastState.Bounded env15257 := by
  intro p hp
  have h : env15257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15256_15257 : H12AffineEnvironment.transform 8 7 env15256 = env15257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env15256 == env15257) = true)

theorem identity15257 : scanCanonicalize (H12AffineFastState.compose env15257 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound15257 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15258 : List Nat := [2,4,8,8,1,9,8,4,7,13,12,4,9,13,1,2,4,12,12,0,13,1,8,2,9,8,12,4,5,12,13,1,5,0,13,7]

theorem envBound15258 : H12AffineFastState.Bounded env15258 := by
  intro p hp
  have h : env15258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15257_15258 : H12AffineEnvironment.transform 3 8 env15257 = env15258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env15257 == env15258) = true)

def env15259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,58397,4194304,17,41311,8192,65,4262263,115015,45405,43049,75103,4268043,257,98678,90203,513]

theorem envBound15259 : H12AffineFastState.Bounded env15259 := by
  intro p hp
  have h : env15259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15244_15259 : H12AffineEnvironment.transform 17 10281 env15244 = env15259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15244 == env15259) = true)

theorem identity15259 : scanCanonicalize (H12AffineFastState.compose env15259 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15259 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58397,4194304,17,41311,8192,65,4204924,57676,45405,43049,1364,4194304,257,41341,16464,513]

theorem envBound15260 : H12AffineFastState.Bounded env15260 := by
  intro p hp
  have h : env15260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15259_15260 : H12AffineEnvironment.transform 15 8203 env15259 = env15260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15259 == env15260) = true)

theorem identity15260 : scanCanonicalize (H12AffineFastState.compose env15260 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound15260 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env15261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,10281,1025,32769,58397,113,17,41311,8192,65,10509,57676,45405,43049,1364,113,257,41341,16464,513]

theorem envBound15261 : H12AffineFastState.Bounded env15261 := by
  intro p hp
  have h : env15261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15260_15261 : H12AffineEnvironment.transform 21 113 env15260 = env15261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env15260 == env15261) = true)

theorem identity15261 : scanCanonicalize (H12AffineFastState.compose env15261 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15261 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env15262 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,343,16401,2421,1025,32769,50497,113,17,32771,348,65,2129,49168,36865,35189,1364,113,257,32801,16464,513]

theorem envBound15262 : H12AffineFastState.Bounded env15262 := by
  intro p hp
  have h : env15262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15261_15262 : H12AffineEnvironment.transform 12 348 env15261 = env15262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15261 == env15262) = true)

theorem identity15262 : scanCanonicalize (H12AffineFastState.compose env15262 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15262 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env15263 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,263,16401,2341,1025,32769,50449,33,17,32771,268,17,2049,49168,36865,35109,1284,33,257,32801,16384,513]

theorem envBound15263 : H12AffineFastState.Bounded env15263 := by
  intro p hp
  have h : env15263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15262_15263 : H12AffineEnvironment.transform 5 16 env15262 = env15263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15262 == env15263) = true)

theorem identity15263 : scanCanonicalize (H12AffineFastState.compose env15263 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound15263 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15264 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,263,16401,2341,1025,1,17681,33,17,3,268,17,2049,16400,4097,2341,1284,33,257,33,16384,513]

theorem envBound15264 : H12AffineFastState.Bounded env15264 := by
  intro p hp
  have h : env15264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15263_15264 : H12AffineEnvironment.transform 14 0 env15263 = env15264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env15263 == env15264) = true)

theorem identity15264 : scanCanonicalize (H12AffineFastState.compose env15264 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15264 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15265 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5393,2341,1025,1,4113,33,17,3,268,17,2049,5392,4097,2341,1284,33,257,33,5376,513]

theorem envBound15265 : H12AffineFastState.Bounded env15265 := by
  intro p hp
  have h : env15265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15264_15265 : H12AffineEnvironment.transform 13 5376 env15264 = env15265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env15264 == env15265) = true)

theorem identity15265 : scanCanonicalize (H12AffineFastState.compose env15265 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound15265 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15266 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,309,268,1077,0,263,1060,2341,1025,1,292,33,17,3,268,17,2049,1061,308,2341,1284,33,257,33,1077,513]

theorem envBound15266 : H12AffineFastState.Bounded env15266 := by
  intro p hp
  have h : env15266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15265_15266 : H12AffineEnvironment.transform 11 309 env15265 = env15266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env15265 == env15266) = true)

def env15267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272441,16777216,8193,65,21227576,18973700,2391400,190521,17148968,23160136,257,19262493,19205425,17075063]

theorem envBound15267 : H12AffineFastState.Bounded env15267 := by
  intro p hp
  have h : env15267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15216_15267 : H12AffineEnvironment.transform 6 9 env15216 = env15267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15216 == env15267) = true)

theorem identity15267 : scanCanonicalize (H12AffineFastState.compose env15267 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 3) := by decide +kernel

theorem selectedBound15267 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env15268 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272441,3,8193,65,4450363,2196487,2391400,190521,371755,6382923,257,2485278,2428210,297844]

theorem envBound15268 : H12AffineFastState.Bounded env15268 := by
  intro p hp
  have h : env15268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15267_15268 : H12AffineEnvironment.transform 23 3 env15267 = env15268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 3 env15267 == env15268) = true)

theorem identity15268 : scanCanonicalize (H12AffineFastState.compose env15268 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound15268 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env15269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,2097152,4194304,272441,3,8193,65,4229153,2196487,2391400,100387,371755,6382923,257,2485278,2428210,297844]

theorem envBound15269 : H12AffineFastState.Bounded env15269 := by
  intro p hp
  have h : env15269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15268_15269 : H12AffineEnvironment.transform 16 90138 env15268 = env15269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env15268 == env15269) = true)

def env15270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,41293,3,8193,65,4229153,2196487,2159644,100387,75103,6382923,257,2188650,2196550,512]

theorem envBound15270 : H12AffineFastState.Bounded env15270 := by
  intro p hp
  have h : env15270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15269_15270 : H12AffineEnvironment.transform 17 35188 env15269 = env15270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env15269 == env15270) = true)

theorem identity15270 : scanCanonicalize (H12AffineFastState.compose env15270 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound15270 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env15271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,17461,4194304,41293,3,8193,65,4229153,114738,45097,100387,75103,4268414,257,74079,114803,512]

theorem envBound15271 : H12AffineFastState.Bounded env15271 := by
  intro p hp
  have h : env15271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15270_15271 : H12AffineEnvironment.transform 20 17461 env15270 = env15271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env15270 == env15271) = true)

theorem identity15271 : scanCanonicalize (H12AffineFastState.compose env15271 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound15271 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env15272 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,65536,90138,31836,1025,29993,17461,4194304,21605,3,8193,65,4226313,79130,17665,97547,75103,4268414,257,74079,79195,512]

theorem envBound15272 : H12AffineFastState.Bounded env15272 := by
  intro p hp
  have h : env15272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15271_15272 : H12AffineEnvironment.transform 14 29992 env15271 = env15272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env15271 == env15272) = true)

theorem identity15272 : scanCanonicalize (H12AffineFastState.compose env15272 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound15272 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env15273 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,65536,90138,31836,1025,29993,17461,32,21605,3,8193,65,32041,79130,17665,97547,75103,74078,257,74079,79195,512]

theorem envBound15273 : H12AffineFastState.Bounded env15273 := by
  intro p hp
  have h : env15273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15272_15273 : H12AffineEnvironment.transform 21 32 env15272 = env15273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env15272 == env15273) = true)

theorem identity15273 : scanCanonicalize (H12AffineFastState.compose env15273 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15273 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env15274 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29992,8203,16401,31836,1025,29993,17461,32,21605,3,8193,65,32041,5393,17665,23808,1364,341,257,340,5456,512]

theorem envBound15274 : H12AffineFastState.Bounded env15274 := by
  intro p hp
  have h : env15274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15273_15274 : H12AffineEnvironment.transform 15 8203 env15273 = env15274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15273 == env15274) = true)

theorem identity15274 : scanCanonicalize (H12AffineFastState.compose env15274 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound15274 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env15275 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,16384,21588,375,16401,23840,1025,21589,17461,32,21605,3,381,65,23637,5393,17665,23808,1364,341,257,340,5456,512]

theorem envBound15275 : H12AffineFastState.Bounded env15275 := by
  intro p hp
  have h : env15275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15274_15275 : H12AffineEnvironment.transform 12 380 env15274 = env15275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env15274 == env15275) = true)

theorem identity15275 : scanCanonicalize (H12AffineFastState.compose env15275 (packedSelected [6,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 5124) := by decide +kernel

theorem selectedBound15275 : packedSelected [6,14,17] rootPS < 2^1333 := by decide +kernel

def env15276 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,380,5124,80,375,5141,2340,1025,81,4145,32,97,3,381,65,2129,5393,4357,2308,1364,341,257,340,5456,512]

theorem envBound15276 : H12AffineFastState.Bounded env15276 := by
  intro p hp
  have h : env15276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15275_15276 : H12AffineEnvironment.transform 13 5124 env15275 = env15276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5124 env15275 == env15276) = true)

theorem identity15276 : scanCanonicalize (H12AffineFastState.compose env15276 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15276 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env15277 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,349,5124,80,342,5141,2309,1025,81,4112,1,64,3,348,65,2129,5393,4357,2308,1364,341,257,340,5456,512]

theorem envBound15277 : H12AffineFastState.Bounded env15277 := by
  intro p hp
  have h : env15277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15276_15277 : H12AffineEnvironment.transform 4 1 env15276 = env15277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15276 == env15277) = true)

theorem identity15277 : scanCanonicalize (H12AffineFastState.compose env15277 (packedSelected [2,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15277 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env15278 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,4096,268,5124,1,263,5141,2309,1025,0,4112,1,17,3,269,16,2048,5393,4357,2308,1285,260,257,261,5377,512]

theorem envBound15278 : H12AffineFastState.Bounded env15278 := by
  intro p hp
  have h : env15278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15277_15278 : H12AffineEnvironment.transform 5 17 env15277 = env15278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15277 == env15278) = true)

theorem identity15278 : scanCanonicalize (H12AffineFastState.compose env15278 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2075) := by decide +kernel

theorem selectedBound15278 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15279 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,2075,268,3103,1,263,3086,2309,1025,0,2059,1,17,3,269,16,2048,3338,2334,2308,1285,260,257,261,3354,512]

theorem envBound15279 : H12AffineFastState.Bounded env15279 := by
  intro p hp
  have h : env15279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15278_15279 : H12AffineEnvironment.transform 11 2075 env15278 = env15279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2075 env15278 == env15279) = true)

theorem identity15279 : scanCanonicalize (H12AffineFastState.compose env15279 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound15279 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15280 : List Nat := [2,4,8,16,1,17,9,4,512,1024,2048,2075,8,3103,1,3,3086,2049,1025,0,2059,1,17,3,9,16,2048,3086,2074,2048,1025,0,5,1,3102,512]

theorem envBound15280 : H12AffineFastState.Bounded env15280 := by
  intro p hp
  have h : env15280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15279_15280 : H12AffineEnvironment.transform 7 4 env15279 = env15280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env15279 == env15280) = true)

theorem identity15280 : scanCanonicalize (H12AffineFastState.compose env15280 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound15280 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15281 : List Nat := [2,4,8,16,1,17,9,4,512,1024,1038,1045,8,17,1,3,0,1039,1025,0,1029,1,17,3,9,16,1038,0,1044,1038,1025,0,5,1,16,512]

theorem envBound15281 : H12AffineFastState.Bounded env15281 := by
  intro p hp
  have h : env15281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15280_15281 : H12AffineEnvironment.transform 10 1038 env15280 = env15281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env15280 == env15281) = true)

theorem identity15281 : scanCanonicalize (H12AffineFastState.compose env15281 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15281 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15282 : List Nat := [2,4,8,16,1,17,9,4,0,1024,1038,1045,8,17,1,3,0,1039,1025,0,1029,1,17,3,9,16,1038,0,1044,1038,1025,0,5,1,16,0]

theorem envBound15282 : H12AffineFastState.Bounded env15282 := by
  intro p hp
  have h : env15282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15281_15282 : H12AffineEnvironment.transform 8 0 env15281 = env15282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15281 == env15282) = true)

theorem identity15282 : scanCanonicalize (H12AffineFastState.compose env15282 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound15282 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15283 : List Nat := [2,4,8,16,1,17,9,4,0,4,10,17,8,17,1,3,0,11,5,0,1,1,17,3,9,16,10,0,16,10,5,0,5,1,16,0]

theorem envBound15283 : H12AffineFastState.Bounded env15283 := by
  intro p hp
  have h : env15283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15282_15283 : H12AffineEnvironment.transform 9 4 env15282 = env15283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env15282 == env15283) = true)

theorem identity15283 : scanCanonicalize (H12AffineFastState.compose env15283 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound15283 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15284 : List Nat := [2,4,8,15,1,14,9,4,0,4,10,14,8,14,1,3,0,11,5,0,1,1,14,3,9,15,10,0,15,10,5,0,5,1,15,0]

theorem envBound15284 : H12AffineFastState.Bounded env15284 := by
  intro p hp
  have h : env15284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15283_15284 : H12AffineEnvironment.transform 3 15 env15283 = env15284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env15283 == env15284) = true)

theorem identity15284 : scanCanonicalize (H12AffineFastState.compose env15284 (packedSelected [7] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound15284 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15285 : List Nat := [2,1,8,10,1,11,9,1,0,1,10,11,8,11,1,3,0,11,0,0,1,1,11,3,9,10,10,0,10,10,0,0,0,1,10,0]

theorem envBound15285 : H12AffineFastState.Bounded env15285 := by
  intro p hp
  have h : env15285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15284_15285 : H12AffineEnvironment.transform 1 1 env15284 = env15285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env15284 == env15285) = true)

theorem identity15285 : scanCanonicalize (H12AffineFastState.compose env15285 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound15285 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15286 : List Nat := [0,1,8,8,1,9,9,1,0,1,8,9,8,9,1,1,0,9,0,0,1,1,9,1,9,8,8,0,8,8,0,0,0,1,8,0]

theorem envBound15286 : H12AffineFastState.Bounded env15286 := by
  intro p hp
  have h : env15286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15285_15286 : H12AffineEnvironment.transform 0 0 env15285 = env15286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env15285 == env15286) = true)

def env15287 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35189,1025,32769,2097152,4194304,41292,3,8193,65,4229153,2196487,2159645,100387,75102,6382923,257,2188651,2196551,513]

theorem envBound15287 : H12AffineFastState.Bounded env15287 := by
  intro p hp
  have h : env15287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15269_15287 : H12AffineEnvironment.transform 17 35189 env15269 = env15287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env15269 == env15287) = true)

def env15288 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35109,1025,32769,2097152,4194304,41244,3,8193,17,4229153,2196487,2159645,100387,75022,6382875,257,2188603,2196503,513]

theorem envBound15288 : H12AffineFastState.Bounded env15288 := by
  intro p hp
  have h : env15288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15287_15288 : H12AffineEnvironment.transform 5 16 env15287 = env15288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15287 == env15288) = true)

theorem identity15288 : scanCanonicalize (H12AffineFastState.compose env15288 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound15288 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env15289 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,2340,1025,0,2097152,4194304,8477,3,8193,17,4196384,2163718,2126876,67618,75022,6382875,257,2188603,2163734,513]

theorem envBound15289 : H12AffineFastState.Bounded env15289 := by
  intro p hp
  have h : env15289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15288_15289 : H12AffineEnvironment.transform 14 1 env15288 = env15289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env15288 == env15289) = true)

theorem identity15289 : scanCanonicalize (H12AffineFastState.compose env15289 (packedSelected [0,4,7,9,14,18,23] rootPS)) = affineNative (2^(21+1) ^^^ 2102561) := by decide +kernel

theorem selectedBound15289 : packedSelected [0,4,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env15290 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,90138,2340,1025,0,2097152,2102561,8477,3,8193,17,2104577,2163718,2126876,67618,75022,94266,257,2188603,2163734,513]

theorem envBound15290 : H12AffineFastState.Bounded env15290 := by
  intro p hp
  have h : env15290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15289_15290 : H12AffineEnvironment.transform 21 2102561 env15289 = env15290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2102561 env15289 == env15290) = true)

theorem identity15290 : scanCanonicalize (H12AffineFastState.compose env15290 (packedSelected [0,1,2,4,5,6,7,8,9,14,17,24] rootPS)) = affineNative (2^(15+1) ^^^ 20759) := by decide +kernel

theorem selectedBound15290 : packedSelected [0,1,2,4,5,6,7,8,9,14,17,24] rootPS < 2^1333 := by decide +kernel

def env15291 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,20759,12557,2340,1025,0,2097152,2102561,8477,3,8193,17,2104577,2118929,2126876,22837,29721,8493,257,2110508,2118913,513]

theorem envBound15291 : H12AffineFastState.Bounded env15291 := by
  intro p hp
  have h : env15291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15290_15291 : H12AffineEnvironment.transform 15 20759 env15290 = env15291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20759 env15290 == env15291) = true)

theorem identity15291 : scanCanonicalize (H12AffineFastState.compose env15291 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(20+1) ^^^ 5376) := by decide +kernel

theorem selectedBound15291 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env15292 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,20759,12557,2340,1025,0,5376,33,8477,3,8193,17,2049,16401,24860,22837,29721,8493,257,8492,16385,513]

theorem envBound15292 : H12AffineFastState.Bounded env15292 := by
  intro p hp
  have h : env15292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15291_15292 : H12AffineEnvironment.transform 20 5376 env15291 = env15292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5376 env15291 == env15292) = true)

theorem identity15292 : scanCanonicalize (H12AffineFastState.compose env15292 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound15292 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env15293 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,20759,4097,2340,1025,0,5376,33,17,3,269,17,2049,16401,16400,22837,21781,33,257,32,16385,513]

theorem envBound15293 : H12AffineFastState.Bounded env15293 := by
  intro p hp
  have h : env15293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15292_15293 : H12AffineEnvironment.transform 12 268 env15292 = env15293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env15292 == env15293) = true)

theorem identity15293 : scanCanonicalize (H12AffineFastState.compose env15293 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound15293 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15294 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,4112,1,263,4097,2340,1025,0,5376,33,17,3,269,17,2049,4097,4096,2341,1285,33,257,32,4113,513]

theorem envBound15294 : H12AffineFastState.Bounded env15294 := by
  intro p hp
  have h : env15294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15293_15294 : H12AffineEnvironment.transform 13 4112 env15293 = env15294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env15293 == env15294) = true)

def env15295 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35108,1025,32769,2097152,4194304,41245,3,8193,16,4229153,2196487,2159645,100387,75023,6382874,257,2188602,2196502,513]

theorem envBound15295 : H12AffineFastState.Bounded env15295 := by
  intro p hp
  have h : env15295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15287_15295 : H12AffineEnvironment.transform 5 17 env15287 = env15295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15287 == env15295) = true)

theorem identity15295 : scanCanonicalize (H12AffineFastState.compose env15295 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound15295 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env15296 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,262,24860,35108,1025,32769,2097152,4194304,41245,3,8193,16,4229153,2131201,2159645,35109,9225,6317084,257,2122812,2131216,513]

theorem envBound15296 : H12AffineFastState.Bounded env15296 := by
  intro p hp
  have h : env15296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15295_15296 : H12AffineEnvironment.transform 15 262 env15295 = env15296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env15295 == env15296) = true)

theorem identity15296 : scanCanonicalize (H12AffineFastState.compose env15296 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound15296 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env15297 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,262,24860,35108,1025,32769,58396,4194304,41245,3,8193,16,4229153,24861,4097,35109,9225,4227072,257,32800,24844,513]

theorem envBound15297 : H12AffineFastState.Bounded env15297 := by
  intro p hp
  have h : env15297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15296_15297 : H12AffineEnvironment.transform 20 58396 env15296 = env15297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env15296 == env15297) = true)

theorem identity15297 : scanCanonicalize (H12AffineFastState.compose env15297 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 20497) := by decide +kernel

theorem selectedBound15297 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env15298 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,20497,262,24860,22837,1025,20496,13325,4194304,28940,3,8193,16,4216880,24861,4097,22836,9225,4214801,257,20529,24844,513]

theorem envBound15298 : H12AffineFastState.Bounded env15298 := by
  intro p hp
  have h : env15298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15297_15298 : H12AffineEnvironment.transform 14 20497 env15297 = env15298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20497 env15297 == env15298) = true)

theorem identity15298 : scanCanonicalize (H12AffineFastState.compose env15298 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound15298 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env15299 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,20497,262,24860,22837,1025,20496,13325,8492,28940,3,8193,16,31004,24861,4097,22836,9225,28989,257,20529,24844,513]

theorem envBound15299 : H12AffineFastState.Bounded env15299 := by
  intro p hp
  have h : env15299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15298_15299 : H12AffineEnvironment.transform 21 8492 env15298 = env15299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env15298 == env15299) = true)

theorem identity15299 : scanCanonicalize (H12AffineFastState.compose env15299 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15299 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env15300 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,20497,262,16401,22837,1025,20496,5376,33,20481,3,268,16,22545,16400,4097,22836,1284,20528,257,20529,16385,513]

theorem envBound15300 : H12AffineFastState.Bounded env15300 := by
  intro p hp
  have h : env15300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15299_15300 : H12AffineEnvironment.transform 12 269 env15299 = env15300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15299 == env15300) = true)

theorem identity15300 : scanCanonicalize (H12AffineFastState.compose env15300 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound15300 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15301 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,4113,0,262,4096,2340,1025,1,5376,33,16,3,268,16,2048,4097,4097,2341,1284,33,257,32,4112,513]

theorem envBound15301 : H12AffineFastState.Bounded env15301 := by
  intro p hp
  have h : env15301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15300_15301 : H12AffineEnvironment.transform 13 4113 env15300 = env15301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env15300 == env15301) = true)

theorem identity15301 : scanCanonicalize (H12AffineFastState.compose env15301 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound15301 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15302 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1044,269,1029,0,262,1044,2340,1025,1,276,33,16,3,268,16,2048,1045,1045,2341,1284,33,257,32,1028,513]

theorem envBound15302 : H12AffineFastState.Bounded env15302 := by
  intro p hp
  have h : env15302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15301_15302 : H12AffineEnvironment.transform 11 1044 env15301 = env15302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env15301 == env15302) = true)

theorem identity15302 : scanCanonicalize (H12AffineFastState.compose env15302 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound15302 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15303 : List Nat := [2,4,8,16,32,17,9,256,277,1024,2048,1044,269,1029,0,262,1044,2340,1025,1,276,33,16,3,268,16,2048,1045,1045,2341,1284,33,257,32,1028,276]

theorem envBound15303 : H12AffineFastState.Bounded env15303 := by
  intro p hp
  have h : env15303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15302_15303 : H12AffineEnvironment.transform 8 277 env15302 = env15303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env15302 == env15303) = true)

theorem identity15303 : scanCanonicalize (H12AffineFastState.compose env15303 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound15303 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15304 : List Nat := [2,4,8,16,32,17,9,256,277,1024,1296,1044,269,1029,0,262,1044,1076,1025,1,276,33,16,3,268,16,1296,1045,1045,1077,1284,33,257,32,1028,276]

theorem envBound15304 : H12AffineFastState.Bounded env15304 := by
  intro p hp
  have h : env15304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15303_15304 : H12AffineEnvironment.transform 10 1296 env15303 = env15304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env15303 == env15304) = true)

theorem identity15304 : scanCanonicalize (H12AffineFastState.compose env15304 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15304 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env15305 : List Nat := [2,4,8,16,1,17,9,256,277,1024,1296,1044,269,1029,0,262,1044,1045,1025,1,276,0,16,3,268,16,1296,1045,1045,1044,1284,0,257,1,1028,276]

theorem envBound15305 : H12AffineFastState.Bounded env15305 := by
  intro p hp
  have h : env15305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15304_15305 : H12AffineEnvironment.transform 4 1 env15304 = env15305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15304 == env15305) = true)

theorem identity15305 : scanCanonicalize (H12AffineFastState.compose env15305 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound15305 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env15306 : List Nat := [2,4,2,16,1,17,3,256,277,1024,1296,1044,263,1029,0,262,1044,1045,1025,1,276,0,16,3,262,16,1296,1045,1045,1044,1284,0,257,1,1028,276]

theorem envBound15306 : H12AffineFastState.Bounded env15306 := by
  intro p hp
  have h : env15306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15305_15306 : H12AffineEnvironment.transform 2 2 env15305 = env15306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env15305 == env15306) = true)

def env15307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound15307 : H12AffineFastState.Bounded env15307 := by
  intro p hp
  have h : env15307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14969_15307 : H12AffineEnvironment.transform 26 30393345 env14969 = env15307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env14969 == env15307) = true)

def env15308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound15308 : H12AffineFastState.Bounded env15308 := by
  intro p hp
  have h : env15308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15307_15308 : H12AffineEnvironment.transform 18 1024 env15307 = env15308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env15307 == env15308) = true)

theorem identity15308 : scanCanonicalize (H12AffineFastState.compose env15308 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 437744) := by decide +kernel

theorem selectedBound15308 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env15309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,8388608,16777216,8328,65,29868033,17246588,8845473,8830976,25265169,21481520,256,25651549,25659640,25207750]

theorem envBound15309 : H12AffineFastState.Bounded env15309 := by
  intro p hp
  have h : env15309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15308_15309 : H12AffineEnvironment.transform 20 437744 env15308 = env15309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 437744 env15308 == env15309) = true)

def env15310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,8388608,8862844,8328,65,4258941,8393984,8845473,8830976,440429,12645452,256,21793,46212,499642]

theorem envBound15310 : H12AffineFastState.Bounded env15310 := by
  intro p hp
  have h : env15310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15309_15310 : H12AffineEnvironment.transform 23 8862844 env15309 = env15310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8862844 env15309 == env15310) = true)

def env15311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,4194304,441760,98780,8328,65,4258941,436384,17665,32160,440429,4606444,256,21793,46212,499642]

theorem envBound15311 : H12AffineFastState.Bounded env15311 := by
  intro p hp
  have h : env15311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15310_15311 : H12AffineEnvironment.transform 22 441760 env15310 = env15311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 441760 env15310 == env15311) = true)

def env15312 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,437744,272512,441760,98780,8328,65,316669,436384,17665,32160,440429,156012,256,21793,46212,499642]

theorem envBound15312 : H12AffineFastState.Bounded env15312 := by
  intro p hp
  have h : env15312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15311_15312 : H12AffineEnvironment.transform 21 272512 env15311 = env15312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env15311 == env15312) = true)

theorem identity15312 : scanCanonicalize (H12AffineFastState.compose env15312 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound15312 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15313 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,416036,272512,412020,95496,8328,65,270377,416884,17665,32160,412857,156012,256,21793,16464,486254]

theorem envBound15313 : H12AffineFastState.Bounded env15313 := by
  intro p hp
  have h : env15313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15312_15313 : H12AffineEnvironment.transform 14 29908 env15312 = env15313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env15312 == env15313) = true)

def env15314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,160132,32,156116,95496,8328,65,2185,160980,17665,32160,156697,156012,256,21793,16464,213966]

theorem envBound15314 : H12AffineFastState.Bounded env15314 := by
  intro p hp
  have h : env15314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15313_15314 : H12AffineEnvironment.transform 17 10400 env15313 = env15314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env15313 == env15314) = true)

theorem identity15314 : scanCanonicalize (H12AffineFastState.compose env15314 (packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound15314 : packedSelected [0,2,4,5,6,7,9,12,17,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env15315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8232,65536,131072,10400,1024,8233,140664,32,144680,74228,8328,65,2185,139304,4605,10588,143589,144784,256,477,5292,202546]

theorem envBound15315 : H12AffineFastState.Bounded env15315 := by
  intro p hp
  have h : env15315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15314_15315 : H12AffineEnvironment.transform 13 5372 env15314 = env15315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env15314 == env15315) = true)

theorem identity15315 : scanCanonicalize (H12AffineFastState.compose env15315 (packedSelected [3,7,10,11,16,18,23,24,26,27,32,35] rootPS)) = affineNative (2^(16+1) ^^^ 70962) := by decide +kernel

theorem selectedBound15315 : packedSelected [3,7,10,11,16,18,23,24,26,27,32,35] rootPS < 2^1333 := by decide +kernel

def env15316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8232,65536,70962,10400,1024,8233,77898,32,73754,74228,8328,65,2185,79130,4605,10588,75223,73890,256,477,5292,512]

theorem envBound15316 : H12AffineFastState.Bounded env15316 := by
  intro p hp
  have h : env15316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15315_15316 : H12AffineEnvironment.transform 16 70962 env15315 = env15316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70962 env15315 == env15316) = true)

theorem identity15316 : scanCanonicalize (H12AffineFastState.compose env15316 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15316 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env15317 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,5341,8201,65536,70931,10369,1024,8200,77898,1,73754,74197,8328,65,2185,79130,4572,10588,75223,73859,256,477,5261,512]

theorem envBound15317 : H12AffineFastState.Bounded env15317 := by
  intro p hp
  have h : env15317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15316_15317 : H12AffineEnvironment.transform 4 1 env15316 = env15317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15316 == env15317) = true)

theorem identity15317 : scanCanonicalize (H12AffineFastState.compose env15317 (packedSelected [4,6,9,10,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound15317 : packedSelected [4,6,9,10,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env15318 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,5341,8201,342,5189,10369,1024,8200,12572,1,8524,8323,8328,65,2185,13388,4572,10588,9345,8661,256,477,5261,512]

theorem envBound15318 : H12AffineFastState.Bounded env15318 := by
  intro p hp
  have h : env15318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15317_15318 : H12AffineEnvironment.transform 15 342 env15317 = env15318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env15317 == env15318) = true)

theorem identity15318 : scanCanonicalize (H12AffineFastState.compose env15318 (packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound15318 : packedSelected [0,1,2,4,6,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env15319 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8,5341,1,342,5189,2185,1024,0,4372,1,324,139,128,65,2185,5188,4572,2388,1161,477,256,477,5261,512]

theorem envBound15319 : H12AffineFastState.Bounded env15319 := by
  intro p hp
  have h : env15319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15318_15319 : H12AffineEnvironment.transform 12 8 env15318 = env15319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env15318 == env15319) = true)

theorem identity15319 : scanCanonicalize (H12AffineFastState.compose env15319 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound15319 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15320 : List Nat := [2,4,8,16,1,64,128,84,512,1024,2048,4096,8,5341,1,2,5189,2185,1024,0,4160,1,16,139,128,65,2185,5188,4232,2048,1161,137,84,137,5261,512]

theorem envBound15320 : H12AffineFastState.Bounded env15320 := by
  intro p hp
  have h : env15320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15319_15320 : H12AffineEnvironment.transform 7 84 env15319 = env15320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env15319 == env15320) = true)

theorem identity15320 : scanCanonicalize (H12AffineFastState.compose env15320 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound15320 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env15321 : List Nat := [2,4,8,16,1,64,128,84,512,1024,81,4096,8,5341,1,2,5189,216,1024,0,4160,1,16,139,128,65,216,5188,4232,81,1161,137,84,137,5261,512]

theorem envBound15321 : H12AffineFastState.Bounded env15321 := by
  intro p hp
  have h : env15321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15320_15321 : H12AffineEnvironment.transform 10 81 env15320 = env15321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env15320 == env15321) = true)

theorem identity15321 : scanCanonicalize (H12AffineFastState.compose env15321 (packedSelected [0,2,3,5,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound15321 : packedSelected [0,2,3,5,7,11] rootPS < 2^1333 := by decide +kernel

def env15322 : List Nat := [2,4,8,16,1,64,128,84,512,4,81,4096,8,4313,1,2,4161,216,4,0,4160,1,16,139,128,65,216,4160,4232,81,141,137,84,137,4233,512]

theorem envBound15322 : H12AffineFastState.Bounded env15322 := by
  intro p hp
  have h : env15322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15321_15322 : H12AffineEnvironment.transform 9 4 env15321 = env15322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env15321 == env15322) = true)

theorem identity15322 : scanCanonicalize (H12AffineFastState.compose env15322 (packedSelected [0,1,3,5,7,8,10] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound15322 : packedSelected [0,1,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env15323 : List Nat := [2,4,8,0,1,64,128,68,512,4,65,4096,8,4297,1,2,4161,200,4,0,4160,1,0,139,128,65,200,4160,4232,65,141,137,68,137,4233,512]

theorem envBound15323 : H12AffineFastState.Bounded env15323 := by
  intro p hp
  have h : env15323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15322_15323 : H12AffineEnvironment.transform 3 0 env15322 = env15323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env15322 == env15323) = true)

theorem identity15323 : scanCanonicalize (H12AffineFastState.compose env15323 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound15323 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env15324 : List Nat := [2,4,8,0,1,64,128,68,512,4,65,136,8,65,1,2,201,200,4,0,200,1,0,139,128,65,200,200,0,65,141,137,68,137,1,512]

theorem envBound15324 : H12AffineFastState.Bounded env15324 := by
  intro p hp
  have h : env15324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15323_15324 : H12AffineEnvironment.transform 11 136 env15323 = env15324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env15323 == env15324) = true)

theorem identity15324 : scanCanonicalize (H12AffineFastState.compose env15324 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 200) := by decide +kernel

theorem selectedBound15324 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env15325 : List Nat := [2,4,8,0,1,64,128,68,200,4,65,136,8,65,1,2,201,200,4,0,200,1,0,139,128,65,200,200,0,65,141,137,68,137,1,200]

theorem envBound15325 : H12AffineFastState.Bounded env15325 := by
  intro p hp
  have h : env15325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15324_15325 : H12AffineEnvironment.transform 8 200 env15324 = env15325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 200 env15324 == env15325) = true)

theorem identity15325 : scanCanonicalize (H12AffineFastState.compose env15325 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 72) := by decide +kernel

theorem selectedBound15325 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15326 : List Nat := [2,4,8,0,1,64,72,68,0,4,65,64,8,65,1,2,1,0,4,0,0,1,0,67,72,65,0,0,0,65,69,65,68,65,1,0]

theorem envBound15326 : H12AffineFastState.Bounded env15326 := by
  intro p hp
  have h : env15326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15325_15326 : H12AffineEnvironment.transform 6 72 env15325 = env15326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 72 env15325 == env15326) = true)

theorem identity15326 : scanCanonicalize (H12AffineFastState.compose env15326 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound15326 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15327 : List Nat := [2,4,8,0,1,0,8,4,0,4,1,0,8,1,1,2,1,0,4,0,0,1,0,3,8,1,0,0,0,1,5,1,4,1,1,0]

theorem envBound15327 : H12AffineFastState.Bounded env15327 := by
  intro p hp
  have h : env15327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15326_15327 : H12AffineEnvironment.transform 5 0 env15326 = env15327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env15326 == env15327) = true)

theorem identity15327 : scanCanonicalize (H12AffineFastState.compose env15327 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound15327 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15328 : List Nat := [2,0,8,0,1,0,8,0,0,0,1,0,8,1,1,2,1,0,0,0,0,1,0,3,8,1,0,0,0,1,1,1,0,1,1,0]

theorem envBound15328 : H12AffineFastState.Bounded env15328 := by
  intro p hp
  have h : env15328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15327_15328 : H12AffineEnvironment.transform 1 0 env15327 = env15328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env15327 == env15328) = true)

theorem identity15328 : scanCanonicalize (H12AffineFastState.compose env15328 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound15328 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15329 : List Nat := [1,0,8,0,1,0,8,0,0,0,1,0,8,1,1,1,1,0,0,0,0,1,0,0,8,1,0,0,0,1,1,1,0,1,1,0]

theorem envBound15329 : H12AffineFastState.Bounded env15329 := by
  intro p hp
  have h : env15329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15328_15329 : H12AffineEnvironment.transform 0 1 env15328 = env15329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env15328 == env15329) = true)

theorem identity15329 : scanCanonicalize (H12AffineFastState.compose env15329 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound15329 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15330 : List Nat := [1,0,0,0,1,0,0,0,0,0,1,0,0,1,1,1,1,0,0,0,0,1,0,0,0,1,0,0,0,1,1,1,0,1,1,0]

theorem envBound15330 : H12AffineFastState.Bounded env15330 := by
  intro p hp
  have h : env15330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15329_15330 : H12AffineEnvironment.transform 2 0 env15329 = env15330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env15329 == env15330) = true)

def env15331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,160133,33,156117,95496,8328,65,2184,160981,17665,32160,156696,156012,256,21793,16464,213967]

theorem envBound15331 : H12AffineFastState.Bounded env15331 := by
  intro p hp
  have h : env15331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15313_15331 : H12AffineEnvironment.transform 17 10401 env15313 = env15331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env15313 == env15331) = true)

theorem identity15331 : scanCanonicalize (H12AffineFastState.compose env15331 (packedSelected [0,2,4,5,6,7,9,15,16,17,20,23,24,26,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound15331 : packedSelected [0,2,4,5,6,7,9,15,16,17,20,23,24,26,32,35,41] rootPS < 2^1333 := by decide +kernel

def env15332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82383,10401,1024,29909,77898,33,73754,95496,8328,65,2184,79130,17665,32160,75223,73891,256,21793,16464,512]

theorem envBound15332 : H12AffineFastState.Bounded env15332 := by
  intro p hp
  have h : env15332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15331_15332 : H12AffineEnvironment.transform 16 82383 env15331 = env15332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env15331 == env15332) = true)

theorem identity15332 : scanCanonicalize (H12AffineFastState.compose env15332 (packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 14790) := by decide +kernel

theorem selectedBound15332 : packedSelected [0,1,2,6,7,8,10,11,14,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env15333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,14790,30729,10401,1024,29909,2444,33,6620,19662,8328,65,2184,3292,17665,32160,7185,6501,256,21793,16464,512]

theorem envBound15333 : H12AffineFastState.Bounded env15333 := by
  intro p hp
  have h : env15333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15332_15333 : H12AffineEnvironment.transform 15 14790 env15332 = env15333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 14790 env15332 == env15333) = true)

theorem identity15333 : scanCanonicalize (H12AffineFastState.compose env15333 (packedSelected [2,3,5,6,9,11,15,16,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15333 : packedSelected [2,3,5,6,9,11,15,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env15334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,16384,21757,6639,22560,2184,1024,21756,2444,33,6620,19662,161,65,2184,3292,17665,23945,7185,6501,256,21793,16464,512]

theorem envBound15334 : H12AffineFastState.Bounded env15334 := by
  intro p hp
  have h : env15334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15333_15334 : H12AffineEnvironment.transform 12 41 env15333 = env15334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15333 == env15334) = true)

theorem identity15334 : scanCanonicalize (H12AffineFastState.compose env15334 (packedSelected [2,5,6,12,15,17,19,24] rootPS)) = affineNative (2^(11+1) ^^^ 2492) := by decide +kernel

theorem selectedBound15334 : packedSelected [2,5,6,12,15,17,19,24] rootPS < 2^1333 := by decide +kernel

def env15335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,41,16384,19777,83,16796,2184,1024,19776,2444,33,96,19662,161,65,2184,3292,17665,17461,1453,217,256,19613,16464,512]

theorem envBound15335 : H12AffineFastState.Bounded env15335 := by
  intro p hp
  have h : env15335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15334_15335 : H12AffineEnvironment.transform 11 2492 env15334 = env15335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2492 env15334 == env15335) = true)

theorem identity15335 : scanCanonicalize (H12AffineFastState.compose env15335 (packedSelected [1,2,8,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 3345) := by decide +kernel

theorem selectedBound15335 : packedSelected [1,2,8,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env15336 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2492,41,3345,80,83,3213,2184,1024,81,2444,33,96,479,161,65,2184,3292,2064,2340,1453,217,256,396,3393,512]

theorem envBound15336 : H12AffineFastState.Bounded env15336 := by
  intro p hp
  have h : env15336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15335_15336 : H12AffineEnvironment.transform 13 3345 env15335 = env15336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3345 env15335 == env15336) = true)

theorem identity15336 : scanCanonicalize (H12AffineFastState.compose env15336 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound15336 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env15337 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1376,1244,41,113,80,83,493,1512,1024,81,1260,33,96,479,161,65,1512,444,1392,1092,1453,217,256,396,33,512]

theorem envBound15337 : H12AffineFastState.Bounded env15337 := by
  intro p hp
  have h : env15337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15336_15337 : H12AffineEnvironment.transform 10 1376 env15336 = env15337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env15336 == env15337) = true)

theorem identity15337 : scanCanonicalize (H12AffineFastState.compose env15337 (packedSelected [1,4,8,9,10,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound15337 : packedSelected [1,4,8,9,10,15,18] rootPS < 2^1333 := by decide +kernel

def env15338 : List Nat := [2,4,8,16,32,64,128,173,512,1024,1229,1244,41,113,80,83,64,1093,1024,81,1260,33,96,114,161,65,1093,17,1245,1092,1024,217,173,33,33,512]

theorem envBound15338 : H12AffineFastState.Bounded env15338 := by
  intro p hp
  have h : env15338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15337_15338 : H12AffineEnvironment.transform 7 173 env15337 = env15338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env15337 == env15338) = true)

theorem identity15338 : scanCanonicalize (H12AffineFastState.compose env15338 (packedSelected [2,6,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound15338 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env15339 : List Nat := [2,4,8,16,32,64,128,173,512,68,137,152,41,113,80,83,64,1,68,81,168,33,96,114,161,65,1,17,153,0,68,217,173,33,33,512]

theorem envBound15339 : H12AffineFastState.Bounded env15339 := by
  intro p hp
  have h : env15339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15338_15339 : H12AffineEnvironment.transform 9 68 env15338 = env15339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env15338 == env15339) = true)

theorem identity15339 : scanCanonicalize (H12AffineFastState.compose env15339 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound15339 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env15340 : List Nat := [2,4,8,16,32,64,41,4,512,68,32,49,41,113,80,83,64,1,68,81,1,33,96,114,8,65,1,17,48,0,68,112,4,33,33,512]

theorem envBound15340 : H12AffineFastState.Bounded env15340 := by
  intro p hp
  have h : env15340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15339_15340 : H12AffineEnvironment.transform 6 41 env15339 = env15340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env15339 == env15340) = true)

theorem identity15340 : scanCanonicalize (H12AffineFastState.compose env15340 (packedSelected [0,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15340 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env15341 : List Nat := [2,4,8,16,32,17,41,4,512,21,32,49,41,32,1,2,17,1,21,0,1,33,49,35,8,16,1,17,48,0,21,33,4,33,33,512]

theorem envBound15341 : H12AffineFastState.Bounded env15341 := by
  intro p hp
  have h : env15341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15340_15341 : H12AffineEnvironment.transform 5 17 env15340 = env15341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15340 == env15341) = true)

theorem identity15341 : scanCanonicalize (H12AffineFastState.compose env15341 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound15341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15342 : List Nat := [2,4,8,16,6,17,15,4,512,21,6,23,15,6,1,2,17,1,21,0,1,7,23,5,8,16,1,17,22,0,21,7,4,7,7,512]

theorem envBound15342 : H12AffineFastState.Bounded env15342 := by
  intro p hp
  have h : env15342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15341_15342 : H12AffineEnvironment.transform 4 6 env15341 = env15342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env15341 == env15342) = true)

theorem identity15342 : scanCanonicalize (H12AffineFastState.compose env15342 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound15342 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15343 : List Nat := [2,4,8,6,6,7,15,4,512,3,6,1,15,6,1,2,7,1,3,0,1,7,1,5,8,6,1,7,0,0,3,7,4,7,7,512]

theorem envBound15343 : H12AffineFastState.Bounded env15343 := by
  intro p hp
  have h : env15343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15342_15343 : H12AffineEnvironment.transform 3 6 env15342 = env15343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env15342 == env15343) = true)

theorem identity15343 : scanCanonicalize (H12AffineFastState.compose env15343 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound15343 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15344 : List Nat := [2,4,5,6,6,7,2,4,512,3,6,1,2,6,1,2,7,1,3,0,1,7,1,5,5,6,1,7,0,0,3,7,4,7,7,512]

theorem envBound15344 : H12AffineFastState.Bounded env15344 := by
  intro p hp
  have h : env15344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15343_15344 : H12AffineEnvironment.transform 2 5 env15343 = env15344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env15343 == env15344) = true)

theorem identity15344 : scanCanonicalize (H12AffineFastState.compose env15344 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

end H12CloudChart1