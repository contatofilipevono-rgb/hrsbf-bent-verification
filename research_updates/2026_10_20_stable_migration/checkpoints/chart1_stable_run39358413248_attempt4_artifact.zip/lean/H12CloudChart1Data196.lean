import H12CloudChart1Data195

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound49654 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env49655 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,2048,9,3157,32768,3,35908,2080,1025,32769,2112,32,17,3,8,64,2049,35909,2049,2080,33793,33,84,32800,3076,33280]

theorem envBound49655 : H12AffineFastState.Bounded env49655 := by
  intro p hp
  have h : env49655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49654_49655 : H12AffineEnvironment.transform 7 85 env49654 = env49655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env49654 == env49655) = true)

theorem identity49655 : scanCanonicalize (H12AffineFastState.compose env49655 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49655 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49656 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,2048,9,3157,1,3,3141,2080,1025,0,2112,32,17,3,8,64,2049,3140,2049,2080,1024,33,84,33,3076,513]

theorem envBound49656 : H12AffineFastState.Bounded env49656 := by
  intro p hp
  have h : env49656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49655_49656 : H12AffineEnvironment.transform 14 1 env49655 = env49656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49655 == env49656) = true)

theorem identity49656 : scanCanonicalize (H12AffineFastState.compose env49656 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound49656 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49657 : List Nat := [2,4,8,16,32,64,9,85,512,1024,576,576,9,1557,1,3,1541,608,1025,0,512,32,17,3,8,64,577,1540,577,608,1024,33,84,33,1604,513]

theorem envBound49657 : H12AffineFastState.Bounded env49657 := by
  intro p hp
  have h : env49657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49656_49657 : H12AffineEnvironment.transform 10 576 env49656 = env49657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env49656 == env49657) = true)

theorem identity49657 : scanCanonicalize (H12AffineFastState.compose env49657 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49657 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49658 : List Nat := [2,4,8,16,32,17,9,4,512,1024,529,529,9,1557,1,3,1541,561,1025,0,512,32,17,3,8,17,528,1540,528,561,1024,33,5,33,1557,513]

theorem envBound49658 : H12AffineFastState.Bounded env49658 := by
  intro p hp
  have h : env49658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49657_49658 : H12AffineEnvironment.transform 5 17 env49657 = env49658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49657 == env49658) = true)

theorem identity49658 : scanCanonicalize (H12AffineFastState.compose env49658 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound49658 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49659 : List Nat := [2,4,8,16,32,17,9,4,512,548,529,529,9,49,1,3,33,561,549,0,512,32,17,3,8,17,528,32,528,561,548,33,5,33,49,513]

theorem envBound49659 : H12AffineFastState.Bounded env49659 := by
  intro p hp
  have h : env49659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49658_49659 : H12AffineEnvironment.transform 9 548 env49658 = env49659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env49658 == env49659) = true)

theorem identity49659 : scanCanonicalize (H12AffineFastState.compose env49659 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49659 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49660 : List Nat := [2,4,8,16,32,17,9,4,0,36,17,17,9,49,1,3,33,49,37,0,0,32,17,3,8,17,16,32,16,49,36,33,5,33,49,1]

theorem envBound49660 : H12AffineFastState.Bounded env49660 := by
  intro p hp
  have h : env49660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49659_49660 : H12AffineEnvironment.transform 8 0 env49659 = env49660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49659 == env49660) = true)

theorem identity49660 : scanCanonicalize (H12AffineFastState.compose env49660 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49660 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49661 : List Nat := [2,4,8,0,32,1,9,4,0,36,1,1,9,33,1,3,33,33,37,0,0,32,1,3,8,1,0,32,0,33,36,33,5,33,33,1]

theorem envBound49661 : H12AffineFastState.Bounded env49661 := by
  intro p hp
  have h : env49661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49660_49661 : H12AffineEnvironment.transform 3 0 env49660 = env49661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49660 == env49661) = true)

theorem identity49661 : scanCanonicalize (H12AffineFastState.compose env49661 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49661 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49662 : List Nat := [2,4,8,0,0,1,9,4,0,4,1,1,9,1,1,3,1,1,5,0,0,0,1,3,8,1,0,0,0,1,4,1,5,1,1,1]

theorem envBound49662 : H12AffineFastState.Bounded env49662 := by
  intro p hp
  have h : env49662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49661_49662 : H12AffineEnvironment.transform 4 0 env49661 = env49662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49661 == env49662) = true)

def env49663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97546,115151,17665,2363593,119042,329731,257,2199999,2191387,63189]

theorem envBound49663 : H12AffineFastState.Bounded env49663 := by
  intro p hp
  have h : env49663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49641_49663 : H12AffineEnvironment.transform 21 272513 env49641 = env49663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49641 == env49663) = true)

def env49664 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,2097152,272393,2101329,2114883,8192,64,97546,115015,17665,2363457,119042,329731,257,2199863,2191387,63069]

theorem envBound49664 : H12AffineFastState.Bounded env49664 := by
  intro p hp
  have h : env49664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49663_49664 : H12AffineEnvironment.transform 6 8 env49663 = env49664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49663 == env49664) = true)

def env49665 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4160,272393,17,21763,8192,64,97546,115015,17665,262145,119042,329731,257,98679,90203,63069]

theorem envBound49665 : H12AffineFastState.Bounded env49665 := by
  intro p hp
  have h : env49665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49664_49665 : H12AffineEnvironment.transform 20 4160 env49664 = env49665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49664 == env49665) = true)

theorem identity49665 : scanCanonicalize (H12AffineFastState.compose env49665 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound49665 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49666 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35188,1025,32769,4160,41341,17,21763,8192,64,97546,115015,17665,35189,119042,98679,257,98679,90203,63069]

theorem envBound49666 : H12AffineFastState.Bounded env49666 := by
  intro p hp
  have h : env49666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49665_49666 : H12AffineEnvironment.transform 17 35188 env49665 = env49666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env49665 == env49666) = true)

theorem identity49666 : scanCanonicalize (H12AffineFastState.compose env49666 (packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 21794) := by decide +kernel

theorem selectedBound49666 : packedSelected [3,5,7,10,12,14,15,19,20,26,27] rootPS < 2^1333 := by decide +kernel

def env49667 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21794,49168,35188,1025,32769,4160,41341,17,21763,8192,64,10280,37989,17665,35189,33824,54357,257,54357,13689,63069]

theorem envBound49667 : H12AffineFastState.Bounded env49667 := by
  intro p hp
  have h : env49667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49666_49667 : H12AffineEnvironment.transform 15 21794 env49666 = env49667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21794 env49666 == env49667) = true)

theorem identity49667 : scanCanonicalize (H12AffineFastState.compose env49667 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound49667 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env49668 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21794,5392,23668,1025,21761,4160,29821,17,21763,8192,64,10280,16741,17665,23669,20768,341,257,341,13689,9053]

theorem envBound49668 : H12AffineFastState.Bounded env49668 := by
  intro p hp
  have h : env49668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49667_49668 : H12AffineEnvironment.transform 14 21760 env49667 = env49668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env49667 == env49668) = true)

theorem identity49668 : scanCanonicalize (H12AffineFastState.compose env49668 (packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49668 : packedSelected [1,2,3,6,8,9,10,11,12,14,15,18,22,24] rootPS < 2^1333 := by decide +kernel

def env49669 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,16384,21760,21794,5392,23668,1025,21761,4160,21588,17,21763,41,64,2049,16741,17665,23669,20768,341,257,341,5456,884]

theorem envBound49669 : H12AffineFastState.Bounded env49669 := by
  intro p hp
  have h : env49669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49668_49669 : H12AffineEnvironment.transform 12 41 env49668 = env49669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49668 == env49669) = true)

theorem identity49669 : scanCanonicalize (H12AffineFastState.compose env49669 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound49669 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env49670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5237,373,343,5392,2049,1025,372,4160,33,17,374,41,64,2049,5392,4468,2048,1365,341,257,341,5456,884]

theorem envBound49670 : H12AffineFastState.Bounded env49670 := by
  intro p hp
  have h : env49670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49669_49670 : H12AffineEnvironment.transform 13 5237 env49669 = env49670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env49669 == env49670) = true)

theorem identity49670 : scanCanonicalize (H12AffineFastState.compose env49670 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound49670 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1296,41,357,373,343,0,2049,1025,372,1360,33,17,374,41,64,2049,0,1124,2048,1365,341,257,341,64,884]

theorem envBound49671 : H12AffineFastState.Bounded env49671 := by
  intro p hp
  have h : env49671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49670_49671 : H12AffineEnvironment.transform 11 1296 env49670 = env49671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env49670 == env49671) = true)

theorem identity49671 : scanCanonicalize (H12AffineFastState.compose env49671 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49671 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env49672 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,1296,8,324,340,343,0,2049,1025,341,1360,0,17,343,8,64,2049,0,1093,2048,1365,341,257,341,64,853]

theorem envBound49672 : H12AffineFastState.Bounded env49672 := by
  intro p hp
  have h : env49672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49671_49672 : H12AffineEnvironment.transform 4 1 env49671 = env49672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49671 == env49672) = true)

theorem identity49672 : scanCanonicalize (H12AffineFastState.compose env49672 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound49672 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49673 : List Nat := [2,4,8,16,1,64,8,256,512,272,2048,0,8,324,340,343,0,2049,273,341,64,0,17,343,8,64,2049,0,341,2048,69,341,257,341,64,853]

theorem envBound49673 : H12AffineFastState.Bounded env49673 := by
  intro p hp
  have h : env49673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49672_49673 : H12AffineEnvironment.transform 9 272 env49672 = env49673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env49672 == env49673) = true)

theorem identity49673 : scanCanonicalize (H12AffineFastState.compose env49673 (packedSelected [11] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound49673 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env49674 : List Nat := [2,4,8,16,1,64,8,256,512,272,81,0,8,324,340,343,0,80,273,341,64,0,17,343,8,64,80,0,341,81,69,341,257,341,64,853]

theorem envBound49674 : H12AffineFastState.Bounded env49674 := by
  intro p hp
  have h : env49674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49673_49674 : H12AffineEnvironment.transform 10 81 env49673 = env49674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env49673 == env49674) = true)

def env49675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,16,21762,8192,64,97546,115015,17665,262144,119042,329731,257,98678,90202,63069]

theorem envBound49675 : H12AffineFastState.Bounded env49675 := by
  intro p hp
  have h : env49675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49664_49675 : H12AffineEnvironment.transform 20 4161 env49664 = env49675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49664 == env49675) = true)

theorem identity49675 : scanCanonicalize (H12AffineFastState.compose env49675 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound49675 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,262144,1025,8541,4161,272393,16,21762,8192,64,97546,90139,17665,262144,94302,329731,257,73770,90202,22273]

theorem envBound49676 : H12AffineFastState.Bounded env49676 := by
  intro p hp
  have h : env49676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49675_49676 : H12AffineEnvironment.transform 14 8540 env49675 = env49676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env49675 == env49676) = true)

theorem identity49676 : scanCanonicalize (H12AffineFastState.compose env49676 (packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound49676 : packedSelected [0,1,3,4,7,10,19,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,24908,2421,1025,8541,4161,8572,16,21762,8192,64,97546,90139,17665,2421,94302,65910,257,73770,90202,22273]

theorem envBound49677 : H12AffineFastState.Bounded env49677 := by
  intro p hp
  have h : env49677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49676_49677 : H12AffineEnvironment.transform 17 2421 env49676 = env49677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env49676 == env49677) = true)

theorem identity49677 : scanCanonicalize (H12AffineFastState.compose env49677 (packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound49677 : packedSelected [1,3,4,5,7,8,9,10,18,23,26,27] rootPS < 2^1333 := by decide +kernel

def env49678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,30043,24908,2421,1025,8541,4161,8572,16,21762,8192,64,2129,5440,17665,2421,1285,29741,257,21873,5377,22273]

theorem envBound49678 : H12AffineFastState.Bounded env49678 := by
  intro p hp
  have h : env49678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49677_49678 : H12AffineEnvironment.transform 15 30043 env49677 = env49678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env49677 == env49678) = true)

theorem identity49678 : scanCanonicalize (H12AffineFastState.compose env49678 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound49678 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env49679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,8540,8495,13624,2421,1025,8541,4161,8572,16,374,8192,64,2129,5440,4469,2421,1285,8281,257,261,5377,885]

theorem envBound49679 : H12AffineFastState.Bounded env49679 := by
  intro p hp
  have h : env49679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49678_49679 : H12AffineEnvironment.transform 13 5236 env49678 = env49679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env49678 == env49679) = true)

theorem identity49679 : scanCanonicalize (H12AffineFastState.compose env49679 (packedSelected [4,9,14,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49679 : packedSelected [4,9,14,16,18,23] rootPS < 2^1333 := by decide +kernel

def env49680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5236,81,34,5173,2421,1025,80,4161,113,16,374,269,64,2129,5440,4469,2421,1285,340,257,261,5377,885]

theorem envBound49680 : H12AffineFastState.Bounded env49680 := by
  intro p hp
  have h : env49680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49679_49680 : H12AffineEnvironment.transform 12 269 env49679 = env49680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49679 == env49680) = true)

theorem identity49680 : scanCanonicalize (H12AffineFastState.compose env49680 (packedSelected [0,4,7,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49680 : packedSelected [0,4,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env49681 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,121,5236,81,34,5173,2049,1025,80,4161,113,16,2,121,64,2129,5172,4097,2049,1137,32,117,113,5237,513]

theorem envBound49681 : H12AffineFastState.Bounded env49681 := by
  intro p hp
  have h : env49681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49680_49681 : H12AffineEnvironment.transform 7 116 env49680 = env49681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49680 == env49681) = true)

theorem identity49681 : scanCanonicalize (H12AffineFastState.compose env49681 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49681 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49682 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5173,2049,1025,0,4113,33,16,2,41,16,2049,5172,4097,2049,1057,32,37,33,5157,513]

theorem envBound49682 : H12AffineFastState.Bounded env49682 := by
  intro p hp
  have h : env49682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49681_49682 : H12AffineEnvironment.transform 5 16 env49681 = env49682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49681 == env49682) = true)

theorem identity49682 : scanCanonicalize (H12AffineFastState.compose env49682 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49682 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49683 : List Nat := [2,4,8,16,17,16,8,21,512,1024,2048,4096,24,5141,1,19,5124,2049,1025,0,4113,16,16,2,24,16,2049,5125,4097,2049,1040,17,20,16,5140,513]

theorem envBound49683 : H12AffineFastState.Bounded env49683 := by
  intro p hp
  have h : env49683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49682_49683 : H12AffineEnvironment.transform 4 17 env49682 = env49683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49682 == env49683) = true)

theorem identity49683 : scanCanonicalize (H12AffineFastState.compose env49683 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 528) := by decide +kernel

theorem selectedBound49683 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49684 : List Nat := [2,4,8,16,17,16,8,21,512,1024,2048,528,24,1541,1,19,1556,2049,1025,0,513,16,16,2,24,16,2049,1557,529,2049,1040,17,20,16,1540,513]

theorem envBound49684 : H12AffineFastState.Bounded env49684 := by
  intro p hp
  have h : env49684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49683_49684 : H12AffineEnvironment.transform 11 528 env49683 = env49684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 528 env49683 == env49684) = true)

theorem identity49684 : scanCanonicalize (H12AffineFastState.compose env49684 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound49684 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49685 : List Nat := [2,4,8,16,17,16,8,21,512,5,2048,528,24,512,1,19,529,2049,4,0,513,16,16,2,24,16,2049,528,529,2049,21,17,20,16,513,513]

theorem envBound49685 : H12AffineFastState.Bounded env49685 := by
  intro p hp
  have h : env49685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49684_49685 : H12AffineEnvironment.transform 9 5 env49684 = env49685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env49684 == env49685) = true)

def env49686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272392,2101329,2114883,8193,64,97546,115014,17665,2363456,119042,329731,257,2199862,2191387,63068]

theorem envBound49686 : H12AffineFastState.Bounded env49686 := by
  intro p hp
  have h : env49686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49663_49686 : H12AffineEnvironment.transform 6 9 env49663 = env49686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49663 == env49686) = true)

def env49687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21763,8193,64,97546,115014,17665,262144,119042,329731,257,98678,90203,63068]

theorem envBound49687 : H12AffineFastState.Bounded env49687 := by
  intro p hp
  have h : env49687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49686_49687 : H12AffineEnvironment.transform 20 4160 env49686 = env49687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49686 == env49687) = true)

theorem identity49687 : scanCanonicalize (H12AffineFastState.compose env49687 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound49687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4160,33,17,21763,8193,64,97546,115014,17665,10281,119042,73770,257,98678,90203,63068]

theorem envBound49688 : H12AffineFastState.Bounded env49688 := by
  intro p hp
  have h : env49688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49687_49688 : H12AffineEnvironment.transform 17 10281 env49687 = env49688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49687 == env49688) = true)

theorem identity49688 : scanCanonicalize (H12AffineFastState.compose env49688 (packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound49688 : packedSelected [0,1,2,6,7,8,11,16,23,26] rootPS < 2^1333 := by decide +kernel

def env49689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21591,49169,10281,1025,32769,4160,33,17,21763,8193,64,10589,38161,17665,10281,34133,29821,257,54561,13324,63068]

theorem envBound49689 : H12AffineFastState.Bounded env49689 := by
  intro p hp
  have h : env49689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49688_49689 : H12AffineEnvironment.transform 15 21591 env49688 = env49689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env49688 == env49689) = true)

theorem identity49689 : scanCanonicalize (H12AffineFastState.compose env49689 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound49689 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env49690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,21591,5393,10281,1025,21761,4160,33,17,21763,8193,64,10589,16401,17665,10281,20565,29821,257,33,13324,9052]

theorem envBound49690 : H12AffineFastState.Bounded env49690 := by
  intro p hp
  have h : env49690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49689_49690 : H12AffineEnvironment.transform 14 21760 env49689 = env49690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env49689 == env49690) = true)

theorem identity49690 : scanCanonicalize (H12AffineFastState.compose env49690 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound49690 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8202,5393,10281,1025,8540,4160,33,17,8542,8193,64,10589,13388,12636,10281,9224,32,257,33,13324,9052]

theorem envBound49691 : H12AffineFastState.Bounded env49691 := by
  intro p hp
  have h : env49691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49690_49691 : H12AffineEnvironment.transform 13 13405 env49690 = env49691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env49690 == env49691) = true)

theorem identity49691 : scanCanonicalize (H12AffineFastState.compose env49691 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49691 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,80,263,5393,2340,1025,81,4160,33,17,83,268,64,2128,5441,4177,2340,1285,32,257,33,5377,593]

theorem envBound49692 : H12AffineFastState.Bounded env49692 := by
  intro p hp
  have h : env49692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49691_49692 : H12AffineEnvironment.transform 12 269 env49691 = env49692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49691 == env49692) = true)

theorem identity49692 : scanCanonicalize (H12AffineFastState.compose env49692 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound49692 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env49693 : List Nat := [2,4,8,16,32,64,9,256,512,1024,523,4096,269,5456,80,263,5393,815,1025,81,4160,33,17,83,268,64,603,5441,4177,815,1285,32,257,33,5377,593]

theorem envBound49693 : H12AffineFastState.Bounded env49693 := by
  intro p hp
  have h : env49693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49692_49693 : H12AffineEnvironment.transform 10 523 env49692 = env49693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env49692 == env49693) = true)

theorem identity49693 : scanCanonicalize (H12AffineFastState.compose env49693 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound49693 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env49694 : List Nat := [2,4,8,16,32,64,9,84,512,1024,523,4096,89,5124,80,83,5189,635,1025,81,4160,33,17,83,88,64,603,5141,4177,635,1105,32,85,33,5205,593]

theorem envBound49694 : H12AffineFastState.Bounded env49694 := by
  intro p hp
  have h : env49694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49693_49694 : H12AffineEnvironment.transform 7 84 env49693 = env49694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env49693 == env49694) = true)

theorem identity49694 : scanCanonicalize (H12AffineFastState.compose env49694 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49694 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49695 : List Nat := [2,4,8,16,1,64,9,84,512,1024,523,4096,89,5124,80,83,5189,602,1025,81,4160,0,17,83,88,64,603,5141,4177,602,1105,1,85,0,5205,593]

theorem envBound49695 : H12AffineFastState.Bounded env49695 := by
  intro p hp
  have h : env49695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49694_49695 : H12AffineEnvironment.transform 4 1 env49694 = env49695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49694 == env49695) = true)

theorem identity49695 : scanCanonicalize (H12AffineFastState.compose env49695 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49695 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env49696 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,4096,9,5124,0,3,5141,522,1025,1,4112,0,17,3,8,16,523,5141,4097,522,1025,1,5,0,5125,513]

theorem envBound49696 : H12AffineFastState.Bounded env49696 := by
  intro p hp
  have h : env49696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49695_49696 : H12AffineEnvironment.transform 5 16 env49695 = env49696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49695 == env49696) = true)

def env49697 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,16,9,1044,0,3,1029,522,1025,1,0,0,17,3,8,16,523,1029,17,522,1025,1,5,0,1045,513]

theorem envBound49697 : H12AffineFastState.Bounded env49697 := by
  intro p hp
  have h : env49697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49696_49697 : H12AffineEnvironment.transform 11 16 env49696 = env49697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env49696 == env49697) = true)

theorem identity49697 : scanCanonicalize (H12AffineFastState.compose env49697 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound49697 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49698 : List Nat := [2,4,8,5,1,5,9,4,512,1024,523,5,9,1025,0,3,1029,522,1025,1,0,0,4,3,8,5,523,1029,4,522,1025,1,5,0,1024,513]

theorem envBound49698 : H12AffineFastState.Bounded env49698 := by
  intro p hp
  have h : env49698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49697_49698 : H12AffineEnvironment.transform 3 5 env49697 = env49698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49697 == env49698) = true)

def env49699 : List Nat := [2,4,8,5,1,5,9,4,512,0,523,5,9,1,0,3,5,522,1,1,0,0,4,3,8,5,523,5,4,522,1,1,5,0,0,513]

theorem envBound49699 : H12AffineFastState.Bounded env49699 := by
  intro p hp
  have h : env49699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49698_49699 : H12AffineEnvironment.transform 9 0 env49698 = env49699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env49698 == env49699) = true)

theorem identity49699 : scanCanonicalize (H12AffineFastState.compose env49699 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound49699 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49700 : List Nat := [0,4,8,5,1,5,9,4,512,0,521,5,9,1,0,1,5,520,1,1,0,0,4,1,8,5,521,5,4,520,1,1,5,0,0,513]

theorem envBound49700 : H12AffineFastState.Bounded env49700 := by
  intro p hp
  have h : env49700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49699_49700 : H12AffineEnvironment.transform 0 0 env49699 = env49700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env49699 == env49700) = true)

def leafEnv49700 : List Nat := [0,4,8,5,1,5,9,4,512,0,521,5,9,1,0,1,5,520,1,1,0,0,4,1,1,8,1,5,521,5,4,520,1,1,5,0,4,0,0,513,1,1,0]

def active49700 : List Nat := [1,2,8]

def tree49700 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49700 : H12WitnessSearch.Good tree49700 := H12GlobalWitnessIndex.good

theorem leafIdentity49700 : H12AffineFastState.composeSystem env49700 rootObs = leafEnv49700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49700 rootObs == leafEnv49700) = true)

theorem terminalChecked49700 : H12PackedTerminal.terminalCheckFast leafEnv49700 active49700 tree49700 = true := by decide +kernel

def env49701 : List Nat := [2,4,8,5,1,5,9,4,512,1,523,5,9,0,0,3,4,522,0,1,0,0,4,3,8,5,523,4,4,522,0,1,5,0,1,513]

theorem envBound49701 : H12AffineFastState.Bounded env49701 := by
  intro p hp
  have h : env49701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49698_49701 : H12AffineEnvironment.transform 9 1 env49698 = env49701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env49698 == env49701) = true)

theorem identity49701 : scanCanonicalize (H12AffineFastState.compose env49701 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound49701 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49702 : List Nat := [2,4,8,5,1,5,9,4,8,1,3,5,9,0,0,3,4,2,0,1,0,0,4,3,8,5,3,4,4,2,0,1,5,0,1,9]

theorem envBound49702 : H12AffineFastState.Bounded env49702 := by
  intro p hp
  have h : env49702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49701_49702 : H12AffineEnvironment.transform 8 8 env49701 = env49702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env49701 == env49702) = true)

def leafEnv49702 : List Nat := [2,4,8,5,1,5,9,4,8,1,3,5,9,0,0,3,4,2,0,1,0,0,4,3,0,8,1,5,3,4,4,2,0,1,5,0,4,2,1,9,1,1,0]

def active49702 : List Nat := [0,1,2]

def tree49702 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49702 : H12WitnessSearch.Good tree49702 := H12GlobalWitnessIndex.good

theorem leafIdentity49702 : H12AffineFastState.composeSystem env49702 rootObs = leafEnv49702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49702 rootObs == leafEnv49702) = true)

theorem terminalChecked49702 : H12PackedTerminal.terminalCheckFast leafEnv49702 active49702 tree49702 = true := by decide +kernel

def env49703 : List Nat := [2,4,8,16,1,16,9,4,512,1024,523,17,9,1045,0,3,1028,522,1025,1,1,0,17,3,8,16,523,1028,16,522,1025,1,5,0,1044,513]

theorem envBound49703 : H12AffineFastState.Bounded env49703 := by
  intro p hp
  have h : env49703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49696_49703 : H12AffineEnvironment.transform 11 17 env49696 = env49703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env49696 == env49703) = true)

theorem identity49703 : scanCanonicalize (H12AffineFastState.compose env49703 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound49703 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49704 : List Nat := [2,4,8,16,1,16,9,4,512,1,523,17,9,20,0,3,5,522,0,1,1,0,17,3,8,16,523,5,16,522,0,1,5,0,21,513]

theorem envBound49704 : H12AffineFastState.Bounded env49704 := by
  intro p hp
  have h : env49704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49703_49704 : H12AffineEnvironment.transform 9 1 env49703 = env49704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env49703 == env49704) = true)

def env49705 : List Nat := [2,4,8,4,1,4,9,4,512,1,523,5,9,0,0,3,5,522,0,1,1,0,5,3,8,4,523,5,4,522,0,1,5,0,1,513]

theorem envBound49705 : H12AffineFastState.Bounded env49705 := by
  intro p hp
  have h : env49705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49704_49705 : H12AffineEnvironment.transform 3 4 env49704 = env49705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env49704 == env49705) = true)

theorem identity49705 : scanCanonicalize (H12AffineFastState.compose env49705 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound49705 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49706 : List Nat := [1,4,8,4,1,4,9,4,512,1,520,5,9,0,0,0,5,521,0,1,1,0,5,0,8,4,520,5,4,521,0,1,5,0,1,513]

theorem envBound49706 : H12AffineFastState.Bounded env49706 := by
  intro p hp
  have h : env49706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49705_49706 : H12AffineEnvironment.transform 0 1 env49705 = env49706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env49705 == env49706) = true)

def leafEnv49706 : List Nat := [1,4,8,4,1,4,9,4,512,1,520,5,9,0,0,0,5,521,0,1,1,0,5,0,0,8,1,4,520,5,4,521,0,1,5,0,4,1,1,513,1,0,0]

def active49706 : List Nat := [1,2,8]

def tree49706 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49706 : H12WitnessSearch.Good tree49706 := H12GlobalWitnessIndex.good

theorem leafIdentity49706 : H12AffineFastState.composeSystem env49706 rootObs = leafEnv49706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49706 rootObs == leafEnv49706) = true)

theorem terminalChecked49706 : H12PackedTerminal.terminalCheckFast leafEnv49706 active49706 tree49706 = true := by decide +kernel

def env49707 : List Nat := [2,4,8,5,1,5,9,4,512,1,523,4,9,1,0,3,5,522,0,1,1,0,4,3,8,5,523,5,5,522,0,1,5,0,0,513]

theorem envBound49707 : H12AffineFastState.Bounded env49707 := by
  intro p hp
  have h : env49707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49704_49707 : H12AffineEnvironment.transform 3 5 env49704 = env49707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49704 == env49707) = true)

theorem identity49707 : scanCanonicalize (H12AffineFastState.compose env49707 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound49707 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49708 : List Nat := [2,4,8,5,1,5,9,4,9,1,2,4,9,1,0,3,5,3,0,1,1,0,4,3,8,5,2,5,5,3,0,1,5,0,0,8]

theorem envBound49708 : H12AffineFastState.Bounded env49708 := by
  intro p hp
  have h : env49708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49707_49708 : H12AffineEnvironment.transform 8 9 env49707 = env49708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env49707 == env49708) = true)

def leafEnv49708 : List Nat := [2,4,8,5,1,5,9,4,9,1,2,4,9,1,0,3,5,3,0,1,1,0,4,3,0,8,1,5,2,5,5,3,0,1,5,0,4,2,0,8,1,0,0]

def active49708 : List Nat := [0,1,2]

def tree49708 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49708 : H12WitnessSearch.Good tree49708 := H12GlobalWitnessIndex.good

theorem leafIdentity49708 : H12AffineFastState.composeSystem env49708 rootObs = leafEnv49708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49708 rootObs == leafEnv49708) = true)

theorem terminalChecked49708 : H12PackedTerminal.terminalCheckFast leafEnv49708 active49708 tree49708 = true := by decide +kernel

def env49709 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4161,272392,16,21762,8193,64,97546,115014,17665,262145,119042,329731,257,98679,90202,63068]

theorem envBound49709 : H12AffineFastState.Bounded env49709 := by
  intro p hp
  have h : env49709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49686_49709 : H12AffineEnvironment.transform 20 4161 env49686 = env49709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49686 == env49709) = true)

theorem identity49709 : scanCanonicalize (H12AffineFastState.compose env49709 (packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 89459) := by decide +kernel

theorem selectedBound49709 : packedSelected [0,4,8,14,15,16,18,19,22,23,26,27,28,31,41] rootPS < 2^1333 := by decide +kernel

def env49710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,89459,1025,32769,4161,95611,16,21762,8193,64,97546,115014,17665,89458,119042,21872,257,98679,90202,63068]

theorem envBound49710 : H12AffineFastState.Bounded env49710 := by
  intro p hp
  have h : env49710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49709_49710 : H12AffineEnvironment.transform 17 89459 env49709 = env49710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89459 env49709 == env49710) = true)

theorem identity49710 : scanCanonicalize (H12AffineFastState.compose env49710 (packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound49710 : packedSelected [0,1,3,9,11,15,18,22,23,24,27,28,32,38] rootPS < 2^1333 := by decide +kernel

def env49711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,65536,13340,89459,1025,29708,4161,95611,16,21762,8193,64,97546,79179,17665,89458,75023,21872,257,95610,90202,593]

theorem envBound49711 : H12AffineFastState.Bounded env49711 := by
  intro p hp
  have h : env49711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49710_49711 : H12AffineEnvironment.transform 14 29709 env49710 = env49711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env49710 == env49711) = true)

theorem identity49711 : scanCanonicalize (H12AffineFastState.compose env49711 (packedSelected [18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound49711 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env49712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,8540,65536,13340,67618,1025,8541,4161,73770,16,83,8193,64,75867,79179,4176,67619,75023,33,257,73771,79115,593]

theorem envBound49712 : H12AffineFastState.Bounded env49712 := by
  intro p hp
  have h : env49712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49711_49712 : H12AffineEnvironment.transform 13 5457 env49711 = env49712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env49711 == env49712) = true)

theorem identity49712 : scanCanonicalize (H12AffineFastState.compose env49712 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49712 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env49713 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,65536,13340,67618,1025,8461,4113,73770,16,3,8193,16,75787,79131,4096,67619,75023,33,257,73771,79115,513]

theorem envBound49713 : H12AffineFastState.Bounded env49713 := by
  intro p hp
  have h : env49713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49712_49713 : H12AffineEnvironment.transform 5 16 env49712 = env49713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49712 == env49713) = true)

theorem identity49713 : scanCanonicalize (H12AffineFastState.compose env49713 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(15+1) ^^^ 1330) := by decide +kernel

theorem selectedBound49713 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49714 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5377,8460,1330,13340,3344,1025,8461,4113,9496,16,3,8193,16,11577,12329,4096,3345,8253,33,257,9497,12345,513]

theorem envBound49714 : H12AffineFastState.Bounded env49714 := by
  intro p hp
  have h : env49714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49713_49714 : H12AffineEnvironment.transform 15 1330 env49713 = env49714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1330 env49713 == env49714) = true)

theorem identity49714 : scanCanonicalize (H12AffineFastState.compose env49714 (packedSelected [0,1,3,5,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49714 : packedSelected [0,1,3,5,7,8,14] rootPS < 2^1333 := by decide +kernel

def env49715 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5377,1,1330,5393,3344,1025,0,4113,1045,16,3,268,16,3124,4388,4096,3345,304,33,257,1044,4404,513]

theorem envBound49715 : H12AffineFastState.Bounded env49715 := by
  intro p hp
  have h : env49715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49714_49715 : H12AffineEnvironment.transform 12 269 env49714 = env49715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49714 == env49715) = true)

theorem identity49715 : scanCanonicalize (H12AffineFastState.compose env49715 (packedSelected [0,1,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound49715 : packedSelected [0,1,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env49716 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1297,4096,269,5377,1,1330,5393,1,1025,0,4113,1045,16,3,268,16,293,4388,4096,0,304,33,257,1044,4404,513]

theorem envBound49716 : H12AffineFastState.Bounded env49716 := by
  intro p hp
  have h : env49716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49715_49716 : H12AffineEnvironment.transform 10 1297 env49715 = env49716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env49715 == env49716) = true)

def env49717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,8388608,2114882,8328,64,15025626,115150,10507600,8650905,10600786,4268163,257,8487407,8478795,10544773]

theorem envBound49717 : H12AffineFastState.Bounded env49717 := by
  intro p hp
  have h : env49717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49600_49717 : H12AffineEnvironment.transform 16 49305 env49600 = env49717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49305 env49600 == env49717) = true)

def env49718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101328,2114882,8328,64,4543882,115150,17664,2363593,119042,4268163,257,2199999,2191387,63189]

theorem envBound49718 : H12AffineFastState.Bounded env49718 := by
  intro p hp
  have h : env49718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49717_49718 : H12AffineEnvironment.transform 22 2101328 env49717 = env49718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env49717 == env49718) = true)

def env49719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,97546,115150,17664,2363593,119042,329731,257,2199999,2191387,63189]

theorem envBound49719 : H12AffineFastState.Bounded env49719 := by
  intro p hp
  have h : env49719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49718_49719 : H12AffineEnvironment.transform 21 272512 env49718 = env49719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49718 == env49719) = true)

theorem identity49719 : scanCanonicalize (H12AffineFastState.compose env49719 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49719 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49305,262144,1025,32769,2097152,272512,2101328,2114882,8328,64,23809,57797,17664,2363593,61705,272392,257,2142644,2117648,63189]

theorem envBound49720 : H12AffineFastState.Bounded env49720 := by
  intro p hp
  have h : env49720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49719_49720 : H12AffineEnvironment.transform 15 8203 env49719 = env49720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49719 == env49720) = true)

def env49721 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49169,262144,1025,32769,2097152,272392,2101328,2114882,8192,64,23809,57677,17664,2363457,61705,272392,257,2142524,2117648,63069]

theorem envBound49721 : H12AffineFastState.Bounded env49721 := by
  intro p hp
  have h : env49721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49720_49721 : H12AffineEnvironment.transform 6 8 env49720 = env49721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49720 == env49721) = true)

def env49722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,262144,1025,32769,2097152,272393,2101328,2114882,8193,64,23809,57676,17664,2363456,61705,272392,257,2142525,2117648,63068]

theorem envBound49722 : H12AffineFastState.Bounded env49722 := by
  intro p hp
  have h : env49722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49720_49722 : H12AffineEnvironment.transform 6 9 env49720 = env49722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49720 == env49722) = true)

theorem identity49722 : scanCanonicalize (H12AffineFastState.compose env49722 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound49722 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env49723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8203,46157,262144,1025,32769,2097152,272393,2101328,2109727,8193,64,10588,38161,12637,2363456,34132,272392,257,2142525,2106445,33281]

theorem envBound49723 : H12AffineFastState.Bounded env49723 := by
  intro p hp
  have h : env49723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49722_49723 : H12AffineEnvironment.transform 13 13405 env49722 = env49723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env49722 == env49723) = true)

theorem identity49723 : scanCanonicalize (H12AffineFastState.compose env49723 (packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 268597) := by decide +kernel

theorem selectedBound49723 : packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS < 2^1333 := by decide +kernel

def env49724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8203,46157,262144,1025,32769,268597,272393,264549,272426,8193,64,10588,38161,12637,2421,34132,272392,257,305160,277880,33281]

theorem envBound49724 : H12AffineFastState.Bounded env49724 := by
  intro p hp
  have h : env49724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49723_49724 : H12AffineEnvironment.transform 20 268597 env49723 = env49724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268597 env49723 == env49724) = true)

theorem identity49724 : scanCanonicalize (H12AffineFastState.compose env49724 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound49724 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env49725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,372,8203,13625,262144,1025,373,268597,272393,264549,272426,8193,64,10588,5221,12637,2421,1056,272392,257,272764,277880,885]

theorem envBound49725 : H12AffineFastState.Bounded env49725 := by
  intro p hp
  have h : env49725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49724_49725 : H12AffineEnvironment.transform 14 372 env49724 = env49725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env49724 == env49725) = true)

theorem identity49725 : scanCanonicalize (H12AffineFastState.compose env49725 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49725 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49726 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,13405,0,8203,13389,262144,1025,1,268353,272393,264209,272426,8193,64,10280,5221,12329,2049,1056,272392,117,272392,277516,513]

theorem envBound49726 : H12AffineFastState.Bounded env49726 := by
  intro p hp
  have h : env49726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49725_49726 : H12AffineEnvironment.transform 7 116 env49725 = env49726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49725 == env49726) = true)

def env49727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101328,2114882,8328,64,97547,115150,17664,2363593,119042,329730,257,2199999,2191387,63189]

theorem envBound49727 : H12AffineFastState.Bounded env49727 := by
  intro p hp
  have h : env49727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49718_49727 : H12AffineEnvironment.transform 21 272513 env49718 = env49727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49718 == env49727) = true)

theorem identity49727 : scanCanonicalize (H12AffineFastState.compose env49727 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound49727 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77898,272513,73754,95496,8328,64,97547,115150,17664,336003,119042,329730,257,41461,16465,63189]

theorem envBound49728 : H12AffineFastState.Bounded env49728 := by
  intro p hp
  have h : env49728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49727_49728 : H12AffineEnvironment.transform 20 77898 env49727 = env49728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env49727 == env49728) = true)

def env49729 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77850,272513,73754,95496,8328,16,97547,115102,17664,336003,119042,329730,257,41381,16385,63109]

theorem envBound49729 : H12AffineFastState.Bounded env49729 := by
  intro p hp
  have h : env49729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49728_49729 : H12AffineEnvironment.transform 5 16 env49728 = env49729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49728 == env49729) = true)

theorem identity49729 : scanCanonicalize (H12AffineFastState.compose env49729 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(17+1) ^^^ 100387) := by decide +kernel

theorem selectedBound49729 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env49730 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,100387,1025,32769,77850,106658,73754,95496,8328,16,97547,115102,17664,43168,119042,32801,257,41381,16385,63109]

theorem envBound49730 : H12AffineFastState.Bounded env49730 := by
  intro p hp
  have h : env49730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49729_49730 : H12AffineEnvironment.transform 17 100387 env49729 = env49730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100387 env49729 == env49730) = true)

theorem identity49730 : scanCanonicalize (H12AffineFastState.compose env49730 (packedSelected [0,1,4,7,10,11,16,20,22,26,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound49730 : packedSelected [0,1,4,7,10,11,16,20,22,26,28,32] rootPS < 2^1333 := by decide +kernel

def env49731 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40971,49305,10280,1025,32769,36881,169,32785,54531,8328,16,56576,24981,17664,43168,28937,32801,257,41381,16385,63109]

theorem envBound49731 : H12AffineFastState.Bounded env49731 := by
  intro p hp
  have h : env49731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49730_49731 : H12AffineEnvironment.transform 15 40971 env49730 = env49731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env49730 == env49731) = true)

theorem identity49731 : scanCanonicalize (H12AffineFastState.compose env49731 (packedSelected [0,1,4,7,8,16,18,19,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 12692) := by decide +kernel

theorem selectedBound49731 : packedSelected [0,1,4,7,8,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env49732 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,12692,32768,40971,45325,10280,1025,32769,36881,169,32785,42135,8328,16,44180,4097,13460,43168,157,32801,257,41381,12693,34577]

theorem envBound49732 : H12AffineFastState.Bounded env49732 := by
  intro p hp
  have h : env49732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49731_49732 : H12AffineEnvironment.transform 13 12692 env49731 = env49732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12692 env49731 == env49732) = true)

theorem identity49732 : scanCanonicalize (H12AffineFastState.compose env49732 (packedSelected [2,3,4,5,6,10,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound49732 : packedSelected [2,3,4,5,6,10,17,20,22] rootPS < 2^1333 := by decide +kernel

def env49733 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4113,32768,33166,37000,2477,1025,32769,36881,169,32785,34066,269,16,36113,4097,5393,35109,157,32801,257,32800,4112,34577]

theorem envBound49733 : H12AffineFastState.Bounded env49733 := by
  intro p hp
  have h : env49733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49732_49733 : H12AffineEnvironment.transform 12 389 env49732 = env49733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env49732 == env49733) = true)

theorem identity49733 : scanCanonicalize (H12AffineFastState.compose env49733 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49733 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env49734 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,4113,1,399,4233,2477,1025,0,4112,169,16,1299,269,16,3344,4097,5393,2340,157,32,257,33,4112,1808]

theorem envBound49734 : H12AffineFastState.Bounded env49734 := by
  intro p hp
  have h : env49734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49733_49734 : H12AffineEnvironment.transform 14 1 env49733 = env49734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49733 == env49734) = true)

theorem identity49734 : scanCanonicalize (H12AffineFastState.compose env49734 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49734 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env49735 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,389,4113,1,399,4233,2477,52,0,4112,169,16,294,269,16,2341,4097,4388,2340,157,32,257,33,4112,805]

theorem envBound49735 : H12AffineFastState.Bounded env49735 := by
  intro p hp
  have h : env49735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49734_49735 : H12AffineEnvironment.transform 9 53 env49734 = env49735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49734 == env49735) = true)

theorem identity49735 : scanCanonicalize (H12AffineFastState.compose env49735 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound49735 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env49736 : List Nat := [2,4,8,16,32,16,128,172,512,53,2048,4096,41,4113,1,35,4233,2049,52,0,4112,169,16,138,161,16,2185,4097,4232,2184,157,32,173,33,4112,649]

theorem envBound49736 : H12AffineFastState.Bounded env49736 := by
  intro p hp
  have h : env49736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49735_49736 : H12AffineEnvironment.transform 7 172 env49735 = env49736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env49735 == env49736) = true)

theorem identity49736 : scanCanonicalize (H12AffineFastState.compose env49736 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49736 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49737 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,1,35,4096,2049,52,0,4112,32,16,3,40,16,2048,4097,4097,2049,20,32,36,33,4112,512]

theorem envBound49737 : H12AffineFastState.Bounded env49737 := by
  intro p hp
  have h : env49737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49736_49737 : H12AffineEnvironment.transform 6 9 env49736 = env49737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49736 == env49737) = true)

def env49738 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,77851,272513,73754,95496,8328,17,97547,115103,17664,336003,119042,329730,257,41380,16384,63108]

theorem envBound49738 : H12AffineFastState.Bounded env49738 := by
  intro p hp
  have h : env49738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49728_49738 : H12AffineEnvironment.transform 5 17 env49728 = env49738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49728 == env49738) = true)

theorem identity49738 : scanCanonicalize (H12AffineFastState.compose env49738 (packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound49738 : packedSelected [4,5,7,8,9,15,16,17,18,19,20,23,24,27,28,31,38] rootPS < 2^1333 := by decide +kernel

def env49739 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21896,65536,5393,262144,1025,21897,77851,272513,73754,95496,8328,17,97547,70679,17664,336003,66698,329730,257,29740,16384,8972]

theorem envBound49739 : H12AffineFastState.Bounded env49739 := by
  intro p hp
  have h : env49739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49738_49739 : H12AffineEnvironment.transform 14 21896 env49738 = env49739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env49738 == env49739) = true)

theorem identity49739 : scanCanonicalize (H12AffineFastState.compose env49739 (packedSelected [1,4,7,9,10,26,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound49739 : packedSelected [1,4,7,9,10,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49740 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21896,65536,5393,97327,1025,21897,77851,87214,73754,95496,8328,17,97547,70679,17664,23724,66698,29741,257,29740,16384,8972]

theorem envBound49740 : H12AffineFastState.Bounded env49740 := by
  intro p hp
  have h : env49740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49739_49740 : H12AffineEnvironment.transform 17 97327 env49739 = env49740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env49739 == env49740) = true)

theorem identity49740 : scanCanonicalize (H12AffineFastState.compose env49740 (packedSelected [3,10,16,18,19,20,23,24] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49740 : packedSelected [3,10,16,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env49741 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21761,65536,5393,97327,1025,21760,77851,87079,73754,95496,8193,17,97547,70679,17664,23589,66563,29741,257,29740,16384,8972]

theorem envBound49741 : H12AffineFastState.Bounded env49741 := by
  intro p hp
  have h : env49741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49740_49741 : H12AffineEnvironment.transform 6 9 env49740 = env49741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49740 == env49741) = true)

theorem identity49741 : scanCanonicalize (H12AffineFastState.compose env49741 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49741 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env49742 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,21761,65536,5393,89378,1025,21760,69910,87079,65815,87045,268,17,89094,70679,17664,23589,66563,21792,257,21793,16384,513]

theorem envBound49742 : H12AffineFastState.Bounded env49742 := by
  intro p hp
  have h : env49742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49741_49742 : H12AffineEnvironment.transform 12 269 env49741 = env49742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49741 == env49742) = true)

theorem identity49742 : scanCanonicalize (H12AffineFastState.compose env49742 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound49742 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49743 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,65536,5393,67619,1025,1,69910,65830,65815,65796,268,17,67847,70679,4097,2340,66563,33,257,32,5377,513]

theorem envBound49743 : H12AffineFastState.Bounded env49743 := by
  intro p hp
  have h : env49743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49742_49743 : H12AffineEnvironment.transform 13 5377 env49742 = env49743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env49742 == env49743) = true)

theorem identity49743 : scanCanonicalize (H12AffineFastState.compose env49743 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound49743 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49744 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5393,2340,1025,1,4113,33,16,3,268,17,2048,5392,4097,2340,1284,33,257,32,5377,513]

theorem envBound49744 : H12AffineFastState.Bounded env49744 := by
  intro p hp
  have h : env49744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49743_49744 : H12AffineEnvironment.transform 15 263 env49743 = env49744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env49743 == env49744) = true)

theorem identity49744 : scanCanonicalize (H12AffineFastState.compose env49744 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49745 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,35,5173,2048,1025,1,4113,33,16,3,40,17,2048,5172,4097,2048,1056,33,37,32,5157,513]

theorem envBound49745 : H12AffineFastState.Bounded env49745 := by
  intro p hp
  have h : env49745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49744_49745 : H12AffineEnvironment.transform 7 36 env49744 = env49745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49744 == env49745) = true)

def env49746 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,0,35,1029,2048,1025,1,33,33,16,3,40,17,2048,1028,49,2048,1056,33,37,32,1045,513]

theorem envBound49746 : H12AffineFastState.Bounded env49746 := by
  intro p hp
  have h : env49746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49745_49746 : H12AffineEnvironment.transform 11 48 env49745 = env49746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49745 == env49746) = true)

theorem identity49746 : scanCanonicalize (H12AffineFastState.compose env49746 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound49746 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49747 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,48,41,1045,0,35,1029,529,1025,1,33,33,16,3,40,17,529,1028,49,529,1056,33,37,32,1045,513]

theorem envBound49747 : H12AffineFastState.Bounded env49747 := by
  intro p hp
  have h : env49747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49746_49747 : H12AffineEnvironment.transform 10 529 env49746 = env49747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env49746 == env49747) = true)

def env49748 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,41,33,0,35,49,529,53,1,33,33,16,3,40,17,529,48,49,529,20,33,37,32,33,513]

theorem envBound49748 : H12AffineFastState.Bounded env49748 := by
  intro p hp
  have h : env49748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49747_49748 : H12AffineEnvironment.transform 9 52 env49747 = env49748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49747 == env49748) = true)

def env49749 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,41,32,0,35,48,529,52,1,33,33,16,3,40,17,529,49,49,529,21,33,37,32,32,513]

theorem envBound49749 : H12AffineFastState.Bounded env49749 := by
  intro p hp
  have h : env49749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49747_49749 : H12AffineEnvironment.transform 9 53 env49747 = env49749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49747 == env49749) = true)

theorem identity49749 : scanCanonicalize (H12AffineFastState.compose env49749 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound49749 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49750 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,48,41,32,0,35,48,59,52,1,33,33,16,3,40,17,59,49,49,59,21,33,37,32,32,43]

theorem envBound49750 : H12AffineFastState.Bounded env49750 := by
  intro p hp
  have h : env49750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49749_49750 : H12AffineEnvironment.transform 8 42 env49749 = env49750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env49749 == env49750) = true)

def leafEnv49750 : List Nat := [2,4,8,16,32,17,9,36,42,53,59,48,41,32,0,35,48,59,52,1,33,33,16,3,20,40,1,17,59,49,49,59,21,33,37,32,5,34,32,43,1,33,0]

def active49750 : List Nat := [0,1,2,3,4]

def tree49750 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49750 : H12WitnessSearch.Good tree49750 := H12GlobalWitnessIndex.good

theorem leafIdentity49750 : H12AffineFastState.composeSystem env49750 rootObs = leafEnv49750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49750 rootObs == leafEnv49750) = true)

theorem terminalChecked49750 : H12PackedTerminal.terminalCheckFast leafEnv49750 active49750 tree49750 = true := by decide +kernel

def env49751 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,0,35,1028,2048,1025,1,32,33,16,3,40,17,2048,1029,48,2048,1056,33,37,32,1044,513]

theorem envBound49751 : H12AffineFastState.Bounded env49751 := by
  intro p hp
  have h : env49751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49745_49751 : H12AffineEnvironment.transform 11 49 env49745 = env49751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49745 == env49751) = true)

theorem identity49751 : scanCanonicalize (H12AffineFastState.compose env49751 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound49751 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49752 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,49,41,1044,0,35,1028,1572,1025,1,32,33,16,3,40,17,1572,1029,48,1572,1056,33,37,32,1044,513]

theorem envBound49752 : H12AffineFastState.Bounded env49752 := by
  intro p hp
  have h : env49752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49751_49752 : H12AffineEnvironment.transform 10 1572 env49751 = env49752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env49751 == env49752) = true)

def env49753 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,41,32,0,35,48,528,53,1,32,33,16,3,40,17,528,49,48,528,20,33,37,32,32,513]

theorem envBound49753 : H12AffineFastState.Bounded env49753 := by
  intro p hp
  have h : env49753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49752_49753 : H12AffineEnvironment.transform 9 52 env49752 = env49753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49752 == env49753) = true)

def env49754 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,41,33,0,35,49,529,52,1,32,33,16,3,40,17,529,48,48,529,21,33,37,32,33,513]

theorem envBound49754 : H12AffineFastState.Bounded env49754 := by
  intro p hp
  have h : env49754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49752_49754 : H12AffineEnvironment.transform 9 53 env49752 = env49754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49752 == env49754) = true)

theorem identity49754 : scanCanonicalize (H12AffineFastState.compose env49754 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49755 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,49,41,33,0,35,49,58,52,1,32,33,16,3,40,17,58,48,48,58,21,33,37,32,33,42]

theorem envBound49755 : H12AffineFastState.Bounded env49755 := by
  intro p hp
  have h : env49755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49754_49755 : H12AffineEnvironment.transform 8 43 env49754 = env49755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49754 == env49755) = true)

def leafEnv49755 : List Nat := [2,4,8,16,32,17,9,36,43,53,58,49,41,33,0,35,49,58,52,1,32,33,16,3,20,40,1,17,58,48,48,58,21,33,37,32,5,34,33,42,1,32,0]

def active49755 : List Nat := [0,1,2,3,4]

def tree49755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49755 : H12WitnessSearch.Good tree49755 := H12GlobalWitnessIndex.good

theorem leafIdentity49755 : H12AffineFastState.composeSystem env49755 rootObs = leafEnv49755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49755 rootObs == leafEnv49755) = true)

theorem terminalChecked49755 : H12PackedTerminal.terminalCheckFast leafEnv49755 active49755 tree49755 = true := by decide +kernel

def env49756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,4194304,2101329,2114882,8328,64,4543883,115150,17665,2363592,119043,4268163,257,2199998,2191386,63188]

theorem envBound49756 : H12AffineFastState.Bounded env49756 := by
  intro p hp
  have h : env49756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49717_49756 : H12AffineEnvironment.transform 22 2101329 env49717 = env49756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env49717 == env49756) = true)

def env49757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,97547,115150,17665,2363592,119043,329731,257,2199998,2191386,63188]

theorem envBound49757 : H12AffineFastState.Bounded env49757 := by
  intro p hp
  have h : env49757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49756_49757 : H12AffineEnvironment.transform 21 272512 env49756 = env49757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env49756 == env49757) = true)

theorem identity49757 : scanCanonicalize (H12AffineFastState.compose env49757 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound49757 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,49305,262144,1025,32769,2097152,272512,2101329,2114882,8328,64,43477,5392,17665,2363592,1501,318685,257,2114912,2139332,63188]

theorem envBound49758 : H12AffineFastState.Bounded env49758 := by
  intro p hp
  have h : env49758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49757_49758 : H12AffineEnvironment.transform 15 54494 env49757 = env49758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env49757 == env49758) = true)

theorem identity49758 : scanCanonicalize (H12AffineFastState.compose env49758 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound49758 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8203,13388,262144,1025,29908,2097152,272512,2101329,2114882,8328,64,23808,5392,17665,2363592,1501,272392,257,2114912,2117649,513]

theorem envBound49759 : H12AffineFastState.Bounded env49759 := by
  intro p hp
  have h : env49759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49758_49759 : H12AffineEnvironment.transform 14 29909 env49758 = env49759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env49758 == env49759) = true)

theorem identity49759 : scanCanonicalize (H12AffineFastState.compose env49759 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound49759 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env49760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8203,13388,262144,1025,136,2097152,272512,2101329,2109726,8328,64,10588,5392,12637,2363592,1501,272392,257,2109756,2106445,513]

theorem envBound49760 : H12AffineFastState.Bounded env49760 := by
  intro p hp
  have h : env49760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49759_49760 : H12AffineEnvironment.transform 13 13404 env49759 = env49760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env49759 == env49760) = true)

theorem identity49760 : scanCanonicalize (H12AffineFastState.compose env49760 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound49760 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8203,13388,262144,1025,136,4160,272512,17,8542,8328,64,10588,5392,12637,262280,1501,272392,257,8572,13325,513]

theorem envBound49761 : H12AffineFastState.Bounded env49761 := by
  intro p hp
  have h : env49761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49760_49761 : H12AffineEnvironment.transform 20 4160 env49760 = env49761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49760 == env49761) = true)

theorem identity49761 : scanCanonicalize (H12AffineFastState.compose env49761 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound49761 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,137,8203,13388,10281,1025,136,4160,169,17,8542,8328,64,10588,5392,12637,10401,1501,33,257,8572,13325,513]

theorem envBound49762 : H12AffineFastState.Bounded env49762 := by
  intro p hp
  have h : env49762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49761_49762 : H12AffineEnvironment.transform 17 10281 env49761 = env49762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env49761 == env49762) = true)

theorem identity49762 : scanCanonicalize (H12AffineFastState.compose env49762 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49762 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5377,137,342,5393,2420,1025,136,4160,169,17,3,469,64,2049,5392,4096,2556,1501,33,257,33,5456,513]

theorem envBound49763 : H12AffineFastState.Bounded env49763 := by
  intro p hp
  have h : env49763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49762_49763 : H12AffineEnvironment.transform 12 349 env49762 = env49763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49762 == env49763) = true)

theorem identity49763 : scanCanonicalize (H12AffineFastState.compose env49763 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49763 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49764 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,41,5237,137,34,5221,2048,1025,136,4160,169,17,3,161,64,2049,5220,4096,2184,1193,33,117,33,5156,513]

theorem envBound49764 : H12AffineFastState.Bounded env49764 := by
  intro p hp
  have h : env49764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49763_49764 : H12AffineEnvironment.transform 7 116 env49763 = env49764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49763 == env49764) = true)

theorem identity49764 : scanCanonicalize (H12AffineFastState.compose env49764 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49764 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49765 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,0,34,5221,2048,1025,1,4160,32,17,3,40,64,2049,5220,4096,2049,1056,33,117,33,5156,513]

theorem envBound49765 : H12AffineFastState.Bounded env49765 := by
  intro p hp
  have h : env49765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49764_49765 : H12AffineEnvironment.transform 6 9 env49764 = env49765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49764 == env49765) = true)

theorem identity49765 : scanCanonicalize (H12AffineFastState.compose env49765 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 91) := by decide +kernel

theorem selectedBound49765 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49766 : List Nat := [2,4,8,16,32,64,9,116,512,1024,91,4096,41,5237,0,34,5221,91,1025,1,4160,32,17,3,40,64,90,5220,4096,90,1056,33,117,33,5156,513]

theorem envBound49766 : H12AffineFastState.Bounded env49766 := by
  intro p hp
  have h : env49766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49765_49766 : H12AffineEnvironment.transform 10 91 env49765 = env49766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 91 env49765 == env49766) = true)

theorem identity49766 : scanCanonicalize (H12AffineFastState.compose env49766 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound49766 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49767 : List Nat := [2,4,8,16,32,64,9,116,512,1024,91,1,41,1140,0,34,1124,91,1025,1,65,32,17,3,40,64,90,1125,1,90,1056,33,117,33,1061,513]

theorem envBound49767 : H12AffineFastState.Bounded env49767 := by
  intro p hp
  have h : env49767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49766_49767 : H12AffineEnvironment.transform 11 1 env49766 = env49767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env49766 == env49767) = true)

theorem identity49767 : scanCanonicalize (H12AffineFastState.compose env49767 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 62) := by decide +kernel

theorem selectedBound49767 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49768 : List Nat := [2,4,8,16,32,64,9,116,512,62,91,1,41,74,0,34,90,91,63,1,65,32,17,3,40,64,90,91,1,90,30,33,117,33,27,513]

theorem envBound49768 : H12AffineFastState.Bounded env49768 := by
  intro p hp
  have h : env49768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49767_49768 : H12AffineEnvironment.transform 9 62 env49767 = env49768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 62 env49767 == env49768) = true)

theorem identity49768 : scanCanonicalize (H12AffineFastState.compose env49768 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49768 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env49769 : List Nat := [2,4,8,16,0,64,9,84,512,30,91,1,9,74,0,2,90,91,31,1,65,0,17,3,8,64,90,91,1,90,30,1,85,1,27,513]

theorem envBound49769 : H12AffineFastState.Bounded env49769 := by
  intro p hp
  have h : env49769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49768_49769 : H12AffineEnvironment.transform 4 0 env49768 = env49769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49768 == env49769) = true)

def env49770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,2097152,272513,2101329,2114882,8328,64,97546,115150,17665,2363592,119043,329730,257,2199998,2191386,63188]

theorem envBound49770 : H12AffineFastState.Bounded env49770 := by
  intro p hp
  have h : env49770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49756_49770 : H12AffineEnvironment.transform 21 272513 env49756 = env49770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env49756 == env49770) = true)

theorem identity49770 : scanCanonicalize (H12AffineFastState.compose env49770 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115870) := by decide +kernel

theorem selectedBound49770 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,262144,1025,32769,115870,272513,120015,98780,8328,64,97546,115150,17665,382038,119043,329730,257,21792,46212,63188]

theorem envBound49771 : H12AffineFastState.Bounded env49771 := by
  intro p hp
  have h : env49771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49770_49771 : H12AffineEnvironment.transform 20 115870 env49770 = env49771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115870 env49770 == env49771) = true)

def env49772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10400,1025,32769,115870,33,120015,98780,8328,64,97546,115150,17665,130294,119043,73890,257,21792,46212,63188]

theorem envBound49772 : H12AffineFastState.Bounded env49772 := by
  intro p hp
  have h : env49772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49771_49772 : H12AffineEnvironment.transform 17 10400 env49771 = env49772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49771 == env49772) = true)

theorem identity49772 : scanCanonicalize (H12AffineFastState.compose env49772 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound49772 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,263,49305,10400,1025,32769,50585,33,54728,32987,8328,64,31757,49353,17665,65009,53252,8613,257,21792,46212,63188]

theorem envBound49773 : H12AffineFastState.Bounded env49773 := by
  intro p hp
  have h : env49773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49772_49773 : H12AffineEnvironment.transform 15 263 env49772 = env49773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env49772 == env49773) = true)

theorem identity49773 : scanCanonicalize (H12AffineFastState.compose env49773 (packedSelected [1,10,16,20,26,28] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49773 : packedSelected [1,10,16,20,26,28] rootPS < 2^1333 := by decide +kernel

def env49774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,263,49305,2477,1025,32769,50585,33,54728,32987,389,64,23808,49353,17665,56572,53252,168,257,21792,38281,55257]

theorem envBound49774 : H12AffineFastState.Bounded env49774 := by
  intro p hp
  have h : env49774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49773_49774 : H12AffineEnvironment.transform 12 269 env49773 = env49774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49773 == env49774) = true)

theorem identity49774 : scanCanonicalize (H12AffineFastState.compose env49774 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49774 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env49775 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,32768,263,49217,2421,1025,32769,50497,33,54544,32771,349,64,23808,49169,17665,56356,53252,112,257,21792,38225,55041]

theorem envBound49775 : H12AffineFastState.Bounded env49775 := by
  intro p hp
  have h : env49775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49774_49775 : H12AffineEnvironment.transform 6 88 env49774 = env49775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49774 == env49775) = true)

theorem identity49775 : scanCanonicalize (H12AffineFastState.compose env49775 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound49775 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env49776 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,16384,81,263,16400,2421,1025,80,17680,33,21825,82,349,64,23808,16448,17665,23669,20565,112,257,21792,5376,22352]

theorem envBound49776 : H12AffineFastState.Bounded env49776 := by
  intro p hp
  have h : env49776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49775_49776 : H12AffineEnvironment.transform 14 81 env49775 = env49776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env49775 == env49776) = true)

theorem identity49776 : scanCanonicalize (H12AffineFastState.compose env49776 (packedSelected [0,1,2,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49776 : packedSelected [0,1,2,8,9] rootPS < 2^1333 := by decide +kernel

def env49777 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,121,16384,81,115,16400,2049,1025,80,17508,33,21557,82,41,64,23668,16448,17525,23669,20565,112,117,21588,5236,22052]

theorem envBound49777 : H12AffineFastState.Bounded env49777 := by
  intro p hp
  have h : env49777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49776_49777 : H12AffineEnvironment.transform 7 116 env49776 = env49777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49776 == env49777) = true)

theorem identity49777 : scanCanonicalize (H12AffineFastState.compose env49777 (packedSelected [2,6,14] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound49777 : packedSelected [2,6,14] rootPS < 2^1333 := by decide +kernel

def env49778 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,121,5157,81,115,5173,2049,1025,80,4161,33,16,82,41,64,2129,5221,4176,2128,1136,112,117,113,5236,513]

theorem envBound49778 : H12AffineFastState.Bounded env49778 := by
  intro p hp
  have h : env49778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49777_49778 : H12AffineEnvironment.transform 13 5157 env49777 = env49778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env49777 == env49778) = true)

def env49779 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,35,5173,2049,1025,0,4113,33,16,2,41,16,2049,5173,4096,2048,1056,32,37,33,5156,513]

theorem envBound49779 : H12AffineFastState.Bounded env49779 := by
  intro p hp
  have h : env49779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49778_49779 : H12AffineEnvironment.transform 5 16 env49778 = env49779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49778 == env49779) = true)

theorem identity49779 : scanCanonicalize (H12AffineFastState.compose env49779 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound49779 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49780 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,1,35,4097,2049,53,0,4113,33,16,2,41,16,2049,4097,4096,2048,20,32,37,33,4112,513]

theorem envBound49780 : H12AffineFastState.Bounded env49780 := by
  intro p hp
  have h : env49780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49779_49780 : H12AffineEnvironment.transform 9 52 env49779 = env49780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49779 == env49780) = true)

theorem identity49780 : scanCanonicalize (H12AffineFastState.compose env49780 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound49780 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49781 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,4096,41,4113,1,35,4097,49,53,0,4113,33,16,2,41,16,49,4097,4096,48,20,32,37,33,4112,513]

theorem envBound49781 : H12AffineFastState.Bounded env49781 := by
  intro p hp
  have h : env49781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49780_49781 : H12AffineEnvironment.transform 10 48 env49780 = env49781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env49780 == env49781) = true)

theorem identity49781 : scanCanonicalize (H12AffineFastState.compose env49781 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound49781 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49782 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,41,48,1,35,32,49,53,0,48,33,16,2,41,16,49,32,33,48,20,32,37,33,49,513]

theorem envBound49782 : H12AffineFastState.Bounded env49782 := by
  intro p hp
  have h : env49782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49781_49782 : H12AffineEnvironment.transform 11 33 env49781 = env49782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env49781 == env49782) = true)

def leafEnv49782 : List Nat := [2,4,8,16,32,16,8,36,512,52,48,33,41,48,1,35,32,49,53,0,48,33,16,2,21,41,1,16,49,32,33,48,20,32,37,33,5,35,49,513,1,49,0]

def active49782 : List Nat := [0,1,2,3,4,8]

def tree49782 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49782 : H12WitnessSearch.Good tree49782 := H12GlobalWitnessIndex.good

theorem leafIdentity49782 : H12AffineFastState.composeSystem env49782 rootObs = leafEnv49782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49782 rootObs == leafEnv49782) = true)

theorem terminalChecked49782 : H12PackedTerminal.terminalCheckFast leafEnv49782 active49782 tree49782 = true := by decide +kernel

def env49783 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,0,34,5173,2049,1025,1,4112,33,16,3,41,17,2048,5172,4097,2049,1057,33,36,32,5157,513]

theorem envBound49783 : H12AffineFastState.Bounded env49783 := by
  intro p hp
  have h : env49783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49778_49783 : H12AffineEnvironment.transform 5 17 env49778 = env49783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49778 == env49783) = true)

def env49784 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1045,0,34,1029,2049,1025,1,32,33,16,3,41,17,2048,1028,49,2049,1057,33,36,32,1045,513]

theorem envBound49784 : H12AffineFastState.Bounded env49784 := by
  intro p hp
  have h : env49784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49783_49784 : H12AffineEnvironment.transform 11 48 env49783 = env49784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49783 == env49784) = true)

theorem identity49784 : scanCanonicalize (H12AffineFastState.compose env49784 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49784 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49785 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,32,0,34,48,2049,52,1,32,33,16,3,41,17,2048,49,49,2049,20,33,36,32,32,513]

theorem envBound49785 : H12AffineFastState.Bounded env49785 := by
  intro p hp
  have h : env49785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49784_49785 : H12AffineEnvironment.transform 9 53 env49784 = env49785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49784 == env49785) = true)

theorem identity49785 : scanCanonicalize (H12AffineFastState.compose env49785 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49785 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49786 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,48,40,32,0,34,48,2049,52,1,32,33,16,3,41,17,2048,49,49,2049,20,33,36,32,32,42]

theorem envBound49786 : H12AffineFastState.Bounded env49786 := by
  intro p hp
  have h : env49786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49785_49786 : H12AffineEnvironment.transform 8 43 env49785 = env49786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49785 == env49786) = true)

def leafEnv49786 : List Nat := [2,4,8,16,32,17,9,37,43,53,2048,48,40,32,0,34,48,2049,52,1,32,33,16,3,21,41,1,17,2048,49,49,2049,20,33,36,32,5,35,32,42,1,32,0]

def active49786 : List Nat := [0,1,2,3,4,10]

def tree49786 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49786 : H12WitnessSearch.Good tree49786 := H12GlobalWitnessIndex.good

theorem leafIdentity49786 : H12AffineFastState.composeSystem env49786 rootObs = leafEnv49786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49786 rootObs == leafEnv49786) = true)

theorem terminalChecked49786 : H12PackedTerminal.terminalCheckFast leafEnv49786 active49786 tree49786 = true := by decide +kernel

def env49787 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1044,0,34,1028,2049,1025,1,33,33,16,3,41,17,2048,1029,48,2049,1057,33,36,32,1044,513]

theorem envBound49787 : H12AffineFastState.Bounded env49787 := by
  intro p hp
  have h : env49787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49783_49787 : H12AffineEnvironment.transform 11 49 env49783 = env49787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49783 == env49787) = true)

def env49788 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,32,0,34,48,2049,53,1,33,33,16,3,41,17,2048,49,48,2049,21,33,36,32,32,513]

theorem envBound49788 : H12AffineFastState.Bounded env49788 := by
  intro p hp
  have h : env49788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49787_49788 : H12AffineEnvironment.transform 9 52 env49787 = env49788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49787 == env49788) = true)

def env49789 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,49,40,33,0,34,49,2049,52,1,33,33,16,3,41,17,2048,48,48,2049,20,33,36,32,33,513]

theorem envBound49789 : H12AffineFastState.Bounded env49789 := by
  intro p hp
  have h : env49789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49787_49789 : H12AffineEnvironment.transform 9 53 env49787 = env49789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49787 == env49789) = true)

theorem identity49789 : scanCanonicalize (H12AffineFastState.compose env49789 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound49789 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49790 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,49,40,33,0,34,49,2049,52,1,33,33,16,3,41,17,2048,48,48,2049,20,33,36,32,33,43]

theorem envBound49790 : H12AffineFastState.Bounded env49790 := by
  intro p hp
  have h : env49790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49789_49790 : H12AffineEnvironment.transform 8 42 env49789 = env49790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env49789 == env49790) = true)

def leafEnv49790 : List Nat := [2,4,8,16,32,17,9,37,42,53,2048,49,40,33,0,34,49,2049,52,1,33,33,16,3,21,41,1,17,2048,48,48,2049,20,33,36,32,5,35,33,43,1,33,0]

def active49790 : List Nat := [0,1,2,3,4,10]

def tree49790 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49790 : H12WitnessSearch.Good tree49790 := H12GlobalWitnessIndex.good

theorem leafIdentity49790 : H12AffineFastState.composeSystem env49790 rootObs = leafEnv49790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49790 rootObs == leafEnv49790) = true)

theorem terminalChecked49790 : H12PackedTerminal.terminalCheckFast leafEnv49790 active49790 tree49790 = true := by decide +kernel

def env49791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49305,10401,1025,32769,115870,32,120015,98780,8328,64,97546,115150,17665,130295,119043,73891,257,21792,46212,63188]

theorem envBound49791 : H12AffineFastState.Bounded env49791 := by
  intro p hp
  have h : env49791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49771_49791 : H12AffineEnvironment.transform 17 10401 env49771 = env49791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env49771 == env49791) = true)

theorem identity49791 : scanCanonicalize (H12AffineFastState.compose env49791 (packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 29942) := by decide +kernel

theorem selectedBound49791 : packedSelected [0,2,3,6,8,16,20,23,24,26,27,28,32,35,38,41] rootPS < 2^1333 := by decide +kernel

def env49792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29942,49305,10401,1025,32769,45160,32,41017,62762,8328,64,2556,46392,17665,34817,42485,21589,257,21792,46212,63188]

theorem envBound49792 : H12AffineFastState.Bounded env49792 := by
  intro p hp
  have h : env49792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49791_49792 : H12AffineEnvironment.transform 15 29942 env49791 = env49792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29942 env49791 == env49792) = true)

theorem identity49792 : scanCanonicalize (H12AffineFastState.compose env49792 (packedSelected [3,5,7,11,12,14,15,16,17,18,23,27,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound49792 : packedSelected [3,5,7,11,12,14,15,16,17,18,23,27,31,32] rootPS < 2^1333 := by decide +kernel

def env49793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8233,29942,24752,10401,1025,8232,4161,32,16,21763,8328,64,2556,5393,17665,10280,1500,21589,257,21792,5293,22269]

theorem envBound49793 : H12AffineFastState.Bounded env49793 := by
  intro p hp
  have h : env49793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49792_49793 : H12AffineEnvironment.transform 14 8233 env49792 = env49793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env49792 == env49793) = true)

theorem identity49793 : scanCanonicalize (H12AffineFastState.compose env49793 (packedSelected [0,2,7,14,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound49793 : packedSelected [0,2,7,14,17,20] rootPS < 2^1333 := by decide +kernel

def env49794 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13688,8233,398,5576,10401,1025,8232,4161,32,16,8315,8328,64,2556,5393,12409,10280,1500,8493,257,8280,5293,9093]

theorem envBound49794 : H12AffineFastState.Bounded env49794 := by
  intro p hp
  have h : env49794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49793_49794 : H12AffineEnvironment.transform 13 13688 env49793 = env49794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env49793 == env49794) = true)

theorem identity49794 : scanCanonicalize (H12AffineFastState.compose env49794 (packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49794 : packedSelected [0,1,3,5,7,8,9,10,14,16,17,19,22] rootPS < 2^1333 := by decide +kernel

def env49795 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,13324,8233,250,5308,10401,1025,8232,4161,32,16,8315,8328,64,2184,5221,12409,10280,1192,8281,117,8280,5293,8945]

theorem envBound49795 : H12AffineFastState.Bounded env49795 := by
  intro p hp
  have h : env49795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49794_49795 : H12AffineEnvironment.transform 7 116 env49794 = env49795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49794 == env49795) = true)

theorem identity49795 : scanCanonicalize (H12AffineFastState.compose env49795 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 241) := by decide +kernel

theorem selectedBound49795 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env49796 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,241,5373,216,250,5308,2128,1025,217,4161,32,16,138,121,64,2184,5221,4232,2265,1192,168,117,169,5293,512]

theorem envBound49796 : H12AffineFastState.Bounded env49796 := by
  intro p hp
  have h : env49796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49795_49796 : H12AffineEnvironment.transform 12 241 env49795 = env49796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 241 env49795 == env49796) = true)

theorem identity49796 : scanCanonicalize (H12AffineFastState.compose env49796 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound49796 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49797 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,41,5157,0,34,5220,2128,1025,1,4161,32,16,82,121,64,2128,5221,4176,2049,1136,112,117,113,5237,512]

theorem envBound49797 : H12AffineFastState.Bounded env49797 := by
  intro p hp
  have h : env49797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49796_49797 : H12AffineEnvironment.transform 6 88 env49796 = env49797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env49796 == env49797) = true)

theorem identity49797 : scanCanonicalize (H12AffineFastState.compose env49797 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound49797 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49798 : List Nat := [2,4,8,16,32,49,41,5,512,1024,2048,4096,41,5157,0,34,5141,2081,1025,1,4144,32,16,35,8,49,2081,5140,4129,2049,1025,1,4,0,5124,512]

theorem envBound49798 : H12AffineFastState.Bounded env49798 := by
  intro p hp
  have h : env49798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49797_49798 : H12AffineEnvironment.transform 5 49 env49797 = env49798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env49797 == env49798) = true)

theorem identity49798 : scanCanonicalize (H12AffineFastState.compose env49798 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound49798 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49799 : List Nat := [2,4,8,16,32,49,41,5,512,52,2048,4096,41,4113,0,34,4129,2081,53,1,4144,32,16,35,8,49,2081,4128,4129,2049,53,1,4,0,4144,512]

theorem envBound49799 : H12AffineFastState.Bounded env49799 := by
  intro p hp
  have h : env49799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49798_49799 : H12AffineEnvironment.transform 9 52 env49798 = env49799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49798 == env49799) = true)

theorem identity49799 : scanCanonicalize (H12AffineFastState.compose env49799 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound49799 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env49800 : List Nat := [2,4,8,16,32,49,41,5,512,52,2048,2097,41,2080,0,34,2064,2081,53,1,2049,32,16,35,8,49,2081,2065,2064,2049,53,1,4,0,2049,512]

theorem envBound49800 : H12AffineFastState.Bounded env49800 := by
  intro p hp
  have h : env49800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49799_49800 : H12AffineEnvironment.transform 11 2097 env49799 = env49800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env49799 == env49800) = true)

theorem identity49800 : scanCanonicalize (H12AffineFastState.compose env49800 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound49800 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49801 : List Nat := [2,4,8,16,32,49,41,5,512,52,560,513,41,528,0,34,544,529,53,1,561,32,16,35,8,49,529,545,544,561,53,1,4,0,561,512]

theorem envBound49801 : H12AffineFastState.Bounded env49801 := by
  intro p hp
  have h : env49801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49800_49801 : H12AffineEnvironment.transform 10 560 env49800 = env49801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env49800 == env49801) = true)

theorem identity49801 : scanCanonicalize (H12AffineFastState.compose env49801 (packedSelected [0,4,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49801 : packedSelected [0,4,10] rootPS < 2^1333 := by decide +kernel

def env49802 : List Nat := [2,4,8,16,0,17,9,5,512,20,528,513,9,528,0,2,512,529,21,1,529,0,16,3,8,17,529,513,512,529,21,1,4,0,529,512]

theorem envBound49802 : H12AffineFastState.Bounded env49802 := by
  intro p hp
  have h : env49802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49801_49802 : H12AffineEnvironment.transform 4 0 env49801 = env49802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49801 == env49802) = true)

theorem identity49802 : scanCanonicalize (H12AffineFastState.compose env49802 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49802 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49803 : List Nat := [2,4,8,0,0,1,9,5,512,4,512,513,9,512,0,2,512,513,5,1,513,0,0,3,8,1,513,513,512,513,5,1,4,0,513,512]

theorem envBound49803 : H12AffineFastState.Bounded env49803 := by
  intro p hp
  have h : env49803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49802_49803 : H12AffineEnvironment.transform 3 0 env49802 = env49803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49802 == env49803) = true)

theorem identity49803 : scanCanonicalize (H12AffineFastState.compose env49803 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49803 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49804 : List Nat := [2,1,8,0,0,1,9,0,512,1,512,513,9,512,0,2,512,513,0,1,513,0,0,3,8,1,513,513,512,513,0,1,1,0,513,512]

theorem envBound49804 : H12AffineFastState.Bounded env49804 := by
  intro p hp
  have h : env49804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49803_49804 : H12AffineEnvironment.transform 1 1 env49803 = env49804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49803 == env49804) = true)

def env49805 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507600,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound49805 : H12AffineFastState.Bounded env49805 := by
  intro p hp
  have h : env49805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49353_49805 : H12AffineEnvironment.transform 26 30393345 env49353 = env49805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env49353 == env49805) = true)

def env49806 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507600,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound49806 : H12AffineFastState.Bounded env49806 := by
  intro p hp
  have h : env49806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49805_49806 : H12AffineEnvironment.transform 18 1024 env49805 = env49806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env49805 == env49806) = true)

theorem identity49806 : scanCanonicalize (H12AffineFastState.compose env49806 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8388762) := by decide +kernel

theorem selectedBound49806 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49807 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8388762,8328,64,4702363,10585111,10507600,8830976,99466,14771546,256,2212919,2172307,41820]

theorem envBound49807 : H12AffineFastState.Bounded env49807 := by
  intro p hp
  have h : env49807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49806_49807 : H12AffineEnvironment.transform 23 8388762 env49806 = env49807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8388762 env49806 == env49807) = true)

def env49808 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,147474,8328,64,4702363,2344095,2233816,295048,99466,6497746,256,2212919,2172307,41820]

theorem envBound49808 : H12AffineFastState.Bounded env49808 := by
  intro p hp
  have h : env49808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49807_49808 : H12AffineEnvironment.transform 22 147592 env49807 = env49808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env49807 == env49808) = true)

def env49809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147592,147474,8328,64,4450363,2344095,2233816,43048,99466,6497746,256,2212919,2172307,41820]

theorem envBound49809 : H12AffineFastState.Bounded env49809 := by
  intro p hp
  have h : env49809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49808_49809 : H12AffineEnvironment.transform 17 10400 env49808 = env49809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49808 == env49809) = true)

def env49810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,2097152,4194304,147456,147474,8192,64,4450363,2343959,2233680,43048,99330,6497626,256,2212919,2172187,41820]

theorem envBound49810 : H12AffineFastState.Bounded env49810 := by
  intro p hp
  have h : env49810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49809_49810 : H12AffineEnvironment.transform 6 8 env49809 = env49810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49809 == env49810) = true)

theorem identity49810 : scanCanonicalize (H12AffineFastState.compose env49810 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49810 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env49811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,2097152,4194304,147456,147474,8192,64,4409702,2319690,2233680,2421,75103,6497626,256,2188650,2172187,513]

theorem envBound49811 : H12AffineFastState.Bounded env49811 := by
  intro p hp
  have h : env49811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49810_49811 : H12AffineEnvironment.transform 14 8541 env49810 = env49811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49810 == env49811) = true)

theorem identity49811 : scanCanonicalize (H12AffineFastState.compose env49811 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound49811 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env49812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1024,8540,2097152,4194304,73754,73736,8192,64,4204924,2098512,2192714,2421,75103,6309184,256,2188650,2172187,513]

theorem envBound49812 : H12AffineFastState.Bounded env49812 := by
  intro p hp
  have h : env49812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49811_49812 : H12AffineEnvironment.transform 16 90138 env49811 = env49812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env49811 == env49812) = true)

theorem identity49812 : scanCanonicalize (H12AffineFastState.compose env49812 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound49812 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env49813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28698,4096,10280,1024,8540,2097152,4194304,20480,20498,8192,64,4204924,2098512,2098512,2421,21829,6309184,256,2102640,2118913,513]

theorem envBound49813 : H12AffineFastState.Bounded env49813 := by
  intro p hp
  have h : env49813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49812_49813 : H12AffineEnvironment.transform 15 28698 env49812 = env49813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env49812 == env49813) = true)

theorem identity49813 : scanCanonicalize (H12AffineFastState.compose env49813 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 7252) := by decide +kernel

theorem selectedBound49813 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env49814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28698,4096,10280,1024,8540,2097152,7252,20480,20498,8192,64,13608,2098512,2098512,2421,21829,2119956,256,2102640,2118913,513]

theorem envBound49814 : H12AffineFastState.Bounded env49814 := by
  intro p hp
  have h : env49814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49813_49814 : H12AffineEnvironment.transform 21 7252 env49813 = env49814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 7252 env49813 == env49814) = true)

theorem identity49814 : scanCanonicalize (H12AffineFastState.compose env49814 (packedSelected [11,23] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound49814 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env49815 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,8541,28698,4096,10280,100,8540,2097152,6192,20480,20498,8192,64,12620,2097460,2097460,2421,20769,2119956,256,2101524,2117989,513]

theorem envBound49815 : H12AffineFastState.Bounded env49815 := by
  intro p hp
  have h : env49815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49814_49815 : H12AffineEnvironment.transform 9 100 env49814 = env49815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env49814 == env49815) = true)

theorem identity49815 : scanCanonicalize (H12AffineFastState.compose env49815 (packedSelected [2,3,6,8,10,14] rootPS)) = affineNative (2^(20+1) ^^^ 2341) := by decide +kernel

theorem selectedBound49815 : packedSelected [2,3,6,8,10,14] rootPS < 2^1333 := by decide +kernel

def env49816 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,16384,8541,28698,4096,10280,100,8540,2341,6192,20480,20498,8192,64,12620,2065,2065,2421,20769,20529,256,6193,22592,513]

theorem envBound49816 : H12AffineFastState.Bounded env49816 := by
  intro p hp
  have h : env49816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49815_49816 : H12AffineEnvironment.transform 20 2341 env49815 = env49816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2341 env49815 == env49816) = true)

theorem identity49816 : scanCanonicalize (H12AffineFastState.compose env49816 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49816 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49817 : List Nat := [2,4,8,16,32,64,8,256,512,100,2048,4096,8192,4112,8541,8202,4096,10280,100,8540,2341,6192,16,2,8192,64,12620,2065,2065,2421,305,33,256,6193,2128,513]

theorem envBound49817 : H12AffineFastState.Bounded env49817 := by
  intro p hp
  have h : env49817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49816_49817 : H12AffineEnvironment.transform 13 4112 env49816 = env49817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49816 == env49817) = true)

theorem identity49817 : scanCanonicalize (H12AffineFastState.compose env49817 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49817 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49818 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,4112,8461,8202,4096,10280,52,8460,2341,6192,16,2,8192,16,12572,2065,2065,2341,305,33,256,6193,2048,513]

theorem envBound49818 : H12AffineFastState.Bounded env49818 := by
  intro p hp
  have h : env49818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49817_49818 : H12AffineEnvironment.transform 5 16 env49817 = env49818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49817 == env49818) = true)

theorem identity49818 : scanCanonicalize (H12AffineFastState.compose env49818 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound49818 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env49819 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,2065,8192,2049,8461,8202,2065,10280,52,8460,2341,33,16,2,8192,16,10509,2065,2065,2341,305,33,256,32,2048,513]

theorem envBound49819 : H12AffineFastState.Bounded env49819 := by
  intro p hp
  have h : env49819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49818_49819 : H12AffineEnvironment.transform 11 2065 env49818 = env49819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env49818 == env49819) = true)

theorem identity49819 : scanCanonicalize (H12AffineFastState.compose env49819 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49819 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49820 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,2065,8192,2049,8232,8202,2065,10280,52,8233,2048,33,16,2,8192,16,10280,2065,2065,2048,20,33,37,32,2048,513]

theorem envBound49820 : H12AffineFastState.Bounded env49820 := by
  intro p hp
  have h : env49820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49819_49820 : H12AffineEnvironment.transform 7 37 env49819 = env49820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49819 == env49820) = true)

theorem identity49820 : scanCanonicalize (H12AffineFastState.compose env49820 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound49820 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49821 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,8192,48,8232,8202,32,8217,52,8233,49,33,16,2,8192,16,8217,32,32,49,20,33,37,32,49,513]

theorem envBound49821 : H12AffineFastState.Bounded env49821 := by
  intro p hp
  have h : env49821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49820_49821 : H12AffineEnvironment.transform 10 49 env49820 = env49821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env49820 == env49821) = true)

theorem identity49821 : scanCanonicalize (H12AffineFastState.compose env49821 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49821 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49822 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,41,48,1,35,32,48,52,0,49,33,16,2,41,16,48,32,32,49,20,33,37,32,49,513]

theorem envBound49822 : H12AffineFastState.Bounded env49822 := by
  intro p hp
  have h : env49822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49821_49822 : H12AffineEnvironment.transform 12 41 env49821 = env49822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49821 == env49822) = true)

def leafEnv49822 : List Nat := [2,4,8,16,32,16,8,37,512,52,49,32,41,48,1,35,32,48,52,0,49,33,16,2,20,41,1,16,48,32,32,49,20,33,37,32,4,35,49,513,1,48,0]

def active49822 : List Nat := [0,1,2,3,4,8]

def tree49822 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49822 : H12WitnessSearch.Good tree49822 := H12GlobalWitnessIndex.good

theorem leafIdentity49822 : H12AffineFastState.composeSystem env49822 rootObs = leafEnv49822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49822 rootObs == leafEnv49822) = true)

theorem terminalChecked49822 : H12PackedTerminal.terminalCheckFast leafEnv49822 active49822 tree49822 = true := by decide +kernel

def env49823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,2097152,4194304,147457,147474,8193,64,4450363,2343958,2233681,43048,99331,6497627,256,2212919,2172186,41820]

theorem envBound49823 : H12AffineFastState.Bounded env49823 := by
  intro p hp
  have h : env49823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49809_49823 : H12AffineEnvironment.transform 6 9 env49809 = env49823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49809 == env49823) = true)

theorem identity49823 : scanCanonicalize (H12AffineFastState.compose env49823 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49823 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env49824 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147457,147474,8193,64,4409702,2319691,2233681,2421,75102,6497627,256,2188650,2172186,513]

theorem envBound49824 : H12AffineFastState.Bounded env49824 := by
  intro p hp
  have h : env49824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49823_49824 : H12AffineEnvironment.transform 14 8541 env49823 = env49824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49823 == env49824) = true)

theorem identity49824 : scanCanonicalize (H12AffineFastState.compose env49824 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound49824 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env49825 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,131072,10281,1024,8540,2097152,4194304,147457,147474,8193,64,4343856,2253853,2233681,2421,9224,6431757,256,2122812,2106444,513]

theorem envBound49825 : H12AffineFastState.Bounded env49825 := by
  intro p hp
  have h : env49825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49824_49825 : H12AffineEnvironment.transform 15 342 env49824 = env49825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env49824 == env49825) = true)

theorem identity49825 : scanCanonicalize (H12AffineFastState.compose env49825 (packedSelected [1,4,8,9,14,16,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 25629) := by decide +kernel

theorem selectedBound49825 : packedSelected [1,4,8,9,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env49826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,131072,10281,1024,8540,25629,4194304,147457,147474,8193,64,4343856,131072,160076,2421,9224,4341776,256,33,16465,513]

theorem envBound49826 : H12AffineFastState.Bounded env49826 := by
  intro p hp
  have h : env49826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49825_49826 : H12AffineEnvironment.transform 20 25629 env49825 = env49826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25629 env49825 == env49826) = true)

theorem identity49826 : scanCanonicalize (H12AffineFastState.compose env49826 (packedSelected [1,3,5,8,11,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 8493) := by decide +kernel

theorem selectedBound49826 : packedSelected [1,3,5,8,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env49827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,342,131072,10281,1024,8540,25629,8493,147457,147474,8193,64,157981,131072,160076,2421,9224,155965,256,33,16465,513]

theorem envBound49827 : H12AffineFastState.Bounded env49827 := by
  intro p hp
  have h : env49827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49826_49827 : H12AffineEnvironment.transform 21 8493 env49826 = env49827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8493 env49826 == env49827) = true)

theorem identity49827 : scanCanonicalize (H12AffineFastState.compose env49827 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49827 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49828 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,262,131072,10281,1024,8460,25629,8493,147457,147474,8193,16,157981,131072,160028,2341,9224,155965,256,33,16385,513]

theorem envBound49828 : H12AffineFastState.Bounded env49828 := by
  intro p hp
  have h : env49828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49827_49828 : H12AffineEnvironment.transform 5 16 env49827 = env49828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49827 == env49828) = true)

theorem identity49828 : scanCanonicalize (H12AffineFastState.compose env49828 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49828 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env49829 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,262,131072,2340,1024,1,17680,32,147457,147474,268,16,149520,131072,151569,2341,1285,147504,256,33,16385,513]

theorem envBound49829 : H12AffineFastState.Bounded env49829 := by
  intro p hp
  have h : env49829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49828_49829 : H12AffineEnvironment.transform 12 269 env49828 = env49829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49828 == env49829) = true)

theorem identity49829 : scanCanonicalize (H12AffineFastState.compose env49829 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(16+1) ^^^ 3109) := by decide +kernel

theorem selectedBound49829 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env49830 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,262,3109,2340,1024,1,17680,32,19492,19511,268,16,17461,3109,23604,2341,1285,19477,256,33,16385,513]

theorem envBound49830 : H12AffineFastState.Bounded env49830 := by
  intro p hp
  have h : env49830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49829_49830 : H12AffineEnvironment.transform 16 3109 env49829 = env49830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 3109 env49829 == env49830) = true)

theorem identity49830 : scanCanonicalize (H12AffineFastState.compose env49830 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49830 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env49831 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,16384,0,262,2064,2340,53,1,16677,32,18449,18434,268,16,16384,2064,22529,2341,304,18464,256,33,16385,513]

theorem envBound49831 : H12AffineFastState.Bounded env49831 := by
  intro p hp
  have h : env49831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49830_49831 : H12AffineEnvironment.transform 9 53 env49830 = env49831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49830 == env49831) = true)

theorem identity49831 : scanCanonicalize (H12AffineFastState.compose env49831 (packedSelected [0,3,4,5,12] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound49831 : packedSelected [0,3,4,5,12] rootPS < 2^1333 := by decide +kernel

def env49832 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,2048,0,262,2064,2340,53,1,2341,32,17,2,268,16,2048,2064,4097,2341,304,32,256,33,2049,513]

theorem envBound49832 : H12AffineFastState.Bounded env49832 := by
  intro p hp
  have h : env49832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49831_49832 : H12AffineEnvironment.transform 13 2048 env49831 = env49832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env49831 == env49832) = true)

theorem identity49832 : scanCanonicalize (H12AffineFastState.compose env49832 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound49832 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49833 : List Nat := [2,4,8,16,32,16,9,52,512,53,2048,4096,57,2048,0,50,2064,2064,53,1,2065,32,17,2,56,16,2048,2064,4097,2065,4,32,52,33,2049,513]

theorem envBound49833 : H12AffineFastState.Bounded env49833 := by
  intro p hp
  have h : env49833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49832_49833 : H12AffineEnvironment.transform 7 52 env49832 = env49833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env49832 == env49833) = true)

theorem identity49833 : scanCanonicalize (H12AffineFastState.compose env49833 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound49833 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49834 : List Nat := [2,4,8,10,32,10,9,46,512,47,2048,4096,35,2048,0,40,2058,2058,47,1,2059,32,11,2,34,10,2048,2058,4097,2059,4,32,46,33,2049,513]

theorem envBound49834 : H12AffineFastState.Bounded env49834 := by
  intro p hp
  have h : env49834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49833_49834 : H12AffineEnvironment.transform 3 10 env49833 = env49834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env49833 == env49834) = true)

theorem identity49834 : scanCanonicalize (H12AffineFastState.compose env49834 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 42) := by decide +kernel

theorem selectedBound49834 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49835 : List Nat := [2,4,8,10,32,10,9,46,512,47,42,4096,35,42,0,40,32,32,47,1,33,32,11,2,34,10,42,32,4097,33,4,32,46,33,43,513]

theorem envBound49835 : H12AffineFastState.Bounded env49835 := by
  intro p hp
  have h : env49835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49834_49835 : H12AffineEnvironment.transform 10 42 env49834 = env49835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 42 env49834 == env49835) = true)

theorem identity49835 : scanCanonicalize (H12AffineFastState.compose env49835 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 43) := by decide +kernel

theorem selectedBound49835 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49836 : List Nat := [2,4,8,10,32,10,9,46,512,47,42,43,35,42,0,40,32,32,47,1,33,32,11,2,34,10,42,32,42,33,4,32,46,33,43,513]

theorem envBound49836 : H12AffineFastState.Bounded env49836 := by
  intro p hp
  have h : env49836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49835_49836 : H12AffineEnvironment.transform 11 43 env49835 = env49836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 43 env49835 == env49836) = true)

theorem identity49836 : scanCanonicalize (H12AffineFastState.compose env49836 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49836 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49837 : List Nat := [2,4,5,7,32,7,4,35,512,34,39,38,35,39,0,37,32,32,34,1,33,32,6,2,34,7,39,32,39,33,4,32,35,33,38,513]

theorem envBound49837 : H12AffineFastState.Bounded env49837 := by
  intro p hp
  have h : env49837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49836_49837 : H12AffineEnvironment.transform 2 5 env49836 = env49837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49836 == env49837) = true)

def env49838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147592,147474,8328,64,4450362,2344095,2233816,43049,99466,6497746,256,2212919,2172307,41820]

theorem envBound49838 : H12AffineFastState.Bounded env49838 := by
  intro p hp
  have h : env49838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49808_49838 : H12AffineEnvironment.transform 17 10401 env49808 = env49838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env49808 == env49838) = true)

theorem identity49838 : scanCanonicalize (H12AffineFastState.compose env49838 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16536) := by decide +kernel

theorem selectedBound49838 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4303010,2196487,2118976,43049,99466,6382922,256,2212919,2172307,41820]

theorem envBound49839 : H12AffineFastState.Bounded env49839 := by
  intro p hp
  have h : env49839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49838_49839 : H12AffineEnvironment.transform 16 16536 env49838 = env49839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env49838 == env49839) = true)

theorem identity49839 : scanCanonicalize (H12AffineFastState.compose env49839 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound49839 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env49840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16536,10401,1024,32769,2097152,4194304,16,138,8328,64,4204925,2098648,2118976,43049,1365,6349973,256,2115048,2139212,41820]

theorem envBound49840 : H12AffineFastState.Bounded env49840 := by
  intro p hp
  have h : env49840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49839_49840 : H12AffineEnvironment.transform 15 33247 env49839 = env49840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env49839 == env49840) = true)

theorem identity49840 : scanCanonicalize (H12AffineFastState.compose env49840 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound49840 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env49841 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16536,10401,1024,32769,2097152,32,16,138,8328,64,10589,2098648,2118976,43049,1365,2155701,256,2115048,2139212,41820]

theorem envBound49841 : H12AffineFastState.Bounded env49841 := by
  intro p hp
  have h : env49841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49840_49841 : H12AffineEnvironment.transform 21 32 env49840 = env49841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env49840 == env49841) = true)

theorem identity49841 : scanCanonicalize (H12AffineFastState.compose env49841 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50448) := by decide +kernel

theorem selectedBound49841 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env49842 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,16536,10401,1024,32769,50448,32,16,138,8328,64,10589,49352,36944,43049,1365,8613,256,33016,24924,41820]

theorem envBound49842 : H12AffineFastState.Bounded env49842 := by
  intro p hp
  have h : env49842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49841_49842 : H12AffineEnvironment.transform 20 50448 env49841 = env49842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50448 env49841 == env49842) = true)

theorem identity49842 : scanCanonicalize (H12AffineFastState.compose env49842 (packedSelected [4,9,10,11,12,15,17,18,19,21] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound49842 : packedSelected [4,9,10,11,12,15,17,18,19,21] rootPS < 2^1333 := by decide +kernel

def env49843 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,8202,16536,10401,1024,8660,25797,32,16,138,8328,64,10589,24861,12677,2556,1365,8613,256,8493,24924,649]

theorem envBound49843 : H12AffineFastState.Bounded env49843 := by
  intro p hp
  have h : env49843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49842_49843 : H12AffineEnvironment.transform 14 8661 env49842 = env49843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env49842 == env49843) = true)

theorem identity49843 : scanCanonicalize (H12AffineFastState.compose env49843 (packedSelected [4,5,6,7,8,10,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound49843 : packedSelected [4,5,6,7,8,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env49844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,16384,1213,1378,16536,3529,1024,1212,16813,32,16,138,1504,64,3125,17525,5357,2556,1365,1229,256,1093,17460,649]

theorem envBound49844 : H12AffineFastState.Bounded env49844 := by
  intro p hp
  have h : env49844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49843_49844 : H12AffineEnvironment.transform 12 1384 env49843 = env49844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env49843 == env49844) = true)

theorem identity49844 : scanCanonicalize (H12AffineFastState.compose env49844 (packedSelected [0,2,3,8,9,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound49844 : packedSelected [0,2,3,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env49845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,5236,1213,1378,5356,3529,1024,1212,5593,32,16,138,1504,64,3125,4097,5357,2556,1365,1229,256,1093,4160,649]

theorem envBound49845 : H12AffineFastState.Bounded env49845 := by
  intro p hp
  have h : env49845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49844_49845 : H12AffineEnvironment.transform 13 5236 env49844 = env49845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env49844 == env49845) = true)

theorem identity49845 : scanCanonicalize (H12AffineFastState.compose env49845 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound49845 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env49846 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,120,4452,429,114,4604,2265,272,428,4297,32,16,138,240,64,2341,4097,4605,2556,69,477,256,341,4160,649]

theorem envBound49846 : H12AffineFastState.Bounded env49846 := by
  intro p hp
  have h : env49846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49845_49846 : H12AffineEnvironment.transform 9 272 env49845 = env49846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env49845 == env49846) = true)

theorem identity49846 : scanCanonicalize (H12AffineFastState.compose env49846 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49846 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env49847 : List Nat := [2,4,8,16,32,64,128,117,512,101,2048,4096,120,4113,216,114,4233,2265,101,217,4297,32,16,138,240,64,2128,4097,4232,2185,69,168,117,32,4160,649]

theorem envBound49847 : H12AffineFastState.Bounded env49847 := by
  intro p hp
  have h : env49847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49846_49847 : H12AffineEnvironment.transform 7 117 env49846 = env49847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49846 == env49847) = true)

theorem identity49847 : scanCanonicalize (H12AffineFastState.compose env49847 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound49847 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env49848 : List Nat := [2,4,8,16,32,64,89,117,512,101,2048,4096,120,4113,1,114,4176,2048,101,0,4112,32,16,83,41,64,2128,4097,4177,2128,69,113,117,32,4160,592]

theorem envBound49848 : H12AffineFastState.Bounded env49848 := by
  intro p hp
  have h : env49848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49847_49848 : H12AffineEnvironment.transform 6 89 env49847 = env49848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env49847 == env49848) = true)

theorem identity49848 : scanCanonicalize (H12AffineFastState.compose env49848 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49848 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49849 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,40,4113,1,34,4096,2048,53,0,4112,32,16,3,41,16,2048,4097,4097,2048,21,33,37,32,4112,512]

theorem envBound49849 : H12AffineFastState.Bounded env49849 := by
  intro p hp
  have h : env49849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49848_49849 : H12AffineEnvironment.transform 5 16 env49848 = env49849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49848 == env49849) = true)

theorem identity49849 : scanCanonicalize (H12AffineFastState.compose env49849 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2608) := by decide +kernel

theorem selectedBound49849 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49850 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,2608,40,2593,1,34,2608,2048,53,0,2592,32,16,3,41,16,2048,2609,2609,2048,21,33,37,32,2592,512]

theorem envBound49850 : H12AffineFastState.Bounded env49850 := by
  intro p hp
  have h : env49850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49849_49850 : H12AffineEnvironment.transform 11 2608 env49849 = env49850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2608 env49849 == env49850) = true)

theorem identity49850 : scanCanonicalize (H12AffineFastState.compose env49850 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound49850 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49851 : List Nat := [2,4,8,16,32,16,9,37,20,53,2048,2084,40,2101,1,34,2084,2048,53,0,2100,32,16,3,41,16,2048,2085,2085,2048,21,33,37,32,2100,20]

theorem envBound49851 : H12AffineFastState.Bounded env49851 := by
  intro p hp
  have h : env49851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49850_49851 : H12AffineEnvironment.transform 8 20 env49850 = env49851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env49850 == env49851) = true)

theorem identity49851 : scanCanonicalize (H12AffineFastState.compose env49851 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49851 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49852 : List Nat := [2,4,8,16,0,16,9,5,20,21,2048,2052,8,2069,1,2,2052,2048,21,0,2068,0,16,3,9,16,2048,2053,2053,2048,21,1,5,0,2068,20]

theorem envBound49852 : H12AffineFastState.Bounded env49852 := by
  intro p hp
  have h : env49852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49851_49852 : H12AffineEnvironment.transform 4 0 env49851 = env49852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49851 == env49852) = true)

theorem identity49852 : scanCanonicalize (H12AffineFastState.compose env49852 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound49852 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49853 : List Nat := [2,4,8,5,0,5,9,5,1,0,2048,2052,8,2048,1,2,2052,2048,0,0,2049,0,5,3,9,5,2048,2053,2053,2048,0,1,5,0,2049,1]

theorem envBound49853 : H12AffineFastState.Bounded env49853 := by
  intro p hp
  have h : env49853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49852_49853 : H12AffineEnvironment.transform 3 5 env49852 = env49853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env49852 == env49853) = true)

def leafEnv49853 : List Nat := [2,4,8,5,0,5,9,5,1,0,2048,2052,8,2048,1,2,2052,2048,0,0,2049,0,5,3,0,9,1,5,2048,2053,2053,2048,0,1,5,0,4,3,2049,1,1,2048,0]

def active49853 : List Nat := [0,1,2,10]

def tree49853 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49853 : H12WitnessSearch.Good tree49853 := H12GlobalWitnessIndex.good

theorem leafIdentity49853 : H12AffineFastState.composeSystem env49853 rootObs = leafEnv49853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49853 rootObs == leafEnv49853) = true)

theorem terminalChecked49853 : H12PackedTerminal.terminalCheckFast leafEnv49853 active49853 tree49853 = true := by decide +kernel

def env49854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,147475,8328,64,4702363,2344094,2233817,295049,99466,6497747,256,2212919,2172307,41820]

theorem envBound49854 : H12AffineFastState.Bounded env49854 := by
  intro p hp
  have h : env49854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49807_49854 : H12AffineEnvironment.transform 22 147593 env49807 = env49854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env49807 == env49854) = true)

def env49855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10400,1024,32769,2097152,4194304,147593,147475,8328,64,4450363,2344094,2233817,43049,99466,6497747,256,2212919,2172307,41820]

theorem envBound49855 : H12AffineFastState.Bounded env49855 := by
  intro p hp
  have h : env49855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49854_49855 : H12AffineEnvironment.transform 17 10400 env49854 = env49855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49854 == env49855) = true)

theorem identity49855 : scanCanonicalize (H12AffineFastState.compose env49855 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49855 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147593,147475,8328,64,4409702,2319811,2233817,2420,75223,6497747,256,2188650,2172307,513]

theorem envBound49856 : H12AffineFastState.Bounded env49856 := by
  intro p hp
  have h : env49856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49855_49856 : H12AffineEnvironment.transform 14 8541 env49855 = env49856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49855 == env49856) = true)

def env49857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10280,1024,8540,2097152,4194304,147457,147475,8192,64,4409702,2319691,2233681,2420,75103,6497627,256,2188650,2172187,513]

theorem envBound49857 : H12AffineFastState.Bounded env49857 := by
  intro p hp
  have h : env49857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49856_49857 : H12AffineEnvironment.transform 6 8 env49856 = env49857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49856 == env49857) = true)

theorem identity49857 : scanCanonicalize (H12AffineFastState.compose env49857 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound49857 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env49858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1024,8540,2097152,4194304,73755,73737,8192,64,4204924,2098513,2192715,2420,75103,6309185,256,2188650,2172187,513]

theorem envBound49858 : H12AffineFastState.Bounded env49858 := by
  intro p hp
  have h : env49858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49857_49858 : H12AffineEnvironment.transform 16 90138 env49857 = env49858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env49857 == env49858) = true)

theorem identity49858 : scanCanonicalize (H12AffineFastState.compose env49858 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 79195) := by decide +kernel

theorem selectedBound49858 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env49859 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1024,8540,79195,4194304,73755,73737,8192,64,4204924,77834,16400,2420,75103,4288538,256,20529,4160,513]

theorem envBound49859 : H12AffineFastState.Bounded env49859 := by
  intro p hp
  have h : env49859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49858_49859 : H12AffineEnvironment.transform 20 79195 env49858 = env49859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79195 env49858 == env49859) = true)

theorem identity49859 : scanCanonicalize (H12AffineFastState.compose env49859 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 73042) := by decide +kernel

theorem selectedBound49859 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env49860 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10280,1024,8540,79195,73042,73755,73737,8192,64,78894,77834,16400,2420,75103,27976,256,20529,4160,513]

theorem envBound49860 : H12AffineFastState.Bounded env49860 := by
  intro p hp
  have h : env49860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49859_49860 : H12AffineEnvironment.transform 21 73042 env49859 = env49860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73042 env49859 == env49860) = true)

theorem identity49860 : scanCanonicalize (H12AffineFastState.compose env49860 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound49860 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env49861 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10589,8541,65536,67911,10280,1024,8540,79195,73042,73755,73737,8192,64,78894,77834,10573,2420,75103,1045,256,14700,4160,513]

theorem envBound49861 : H12AffineFastState.Bounded env49861 := by
  intro p hp
  have h : env49861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49860_49861 : H12AffineEnvironment.transform 13 10589 env49860 = env49861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env49860 == env49861) = true)

theorem identity49861 : scanCanonicalize (H12AffineFastState.compose env49861 (packedSelected [0,3,7,8,10,11,14,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 5938) := by decide +kernel

theorem selectedBound49861 : packedSelected [0,3,7,8,10,11,14,15,20] rootPS < 2^1333 := by decide +kernel

def env49862 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,10589,8541,5938,7797,10280,1024,8540,8809,2656,14121,14139,8192,64,8988,10040,10573,2420,12909,1045,256,14700,4160,513]

theorem envBound49862 : H12AffineFastState.Bounded env49862 := by
  intro p hp
  have h : env49862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49861_49862 : H12AffineEnvironment.transform 15 5938 env49861 = env49862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5938 env49861 == env49862) = true)

theorem identity49862 : scanCanonicalize (H12AffineFastState.compose env49862 (packedSelected [0,4,9,11,14,27] rootPS)) = affineNative (2^(12+1) ^^^ 3961) := by decide +kernel

theorem selectedBound49862 : packedSelected [0,4,9,11,14,27] rootPS < 2^1333 := by decide +kernel

def env49863 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3961,1572,3620,5938,7797,1873,1024,3621,3344,2656,6224,6210,3961,64,3173,2113,1588,2420,7444,1045,256,5653,4160,513]

theorem envBound49863 : H12AffineFastState.Bounded env49863 := by
  intro p hp
  have h : env49863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49862_49863 : H12AffineEnvironment.transform 12 3961 env49862 = env49863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3961 env49862 == env49863) = true)

theorem identity49863 : scanCanonicalize (H12AffineFastState.compose env49863 (packedSelected [0,5,7,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound49863 : packedSelected [0,5,7,8,12] rootPS < 2^1333 := by decide +kernel

def env49864 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,3961,1572,3620,3955,1588,1873,1024,3621,3344,2656,17,3,3961,64,3173,2113,1588,2420,1365,1045,256,3668,2049,513]

theorem envBound49864 : H12AffineFastState.Bounded env49864 := by
  intro p hp
  have h : env49864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49863_49864 : H12AffineEnvironment.transform 11 2113 env49863 = env49864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env49863 == env49864) = true)

theorem identity49864 : scanCanonicalize (H12AffineFastState.compose env49864 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1653) := by decide +kernel

theorem selectedBound49864 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env49865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1653,1588,268,1572,81,262,1588,1873,1024,80,869,1045,17,3,268,64,528,1588,1588,1793,1365,1045,256,33,1652,513]

theorem envBound49865 : H12AffineFastState.Bounded env49865 := by
  intro p hp
  have h : env49865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49864_49865 : H12AffineEnvironment.transform 10 1653 env49864 = env49865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1653 env49864 == env49865) = true)

theorem identity49865 : scanCanonicalize (H12AffineFastState.compose env49865 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49865 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49866 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1572,1588,268,1572,0,262,1588,1792,1024,1,820,1045,17,3,268,17,528,1588,1588,1793,1284,1045,256,33,1573,513]

theorem envBound49866 : H12AffineFastState.Bounded env49866 := by
  intro p hp
  have h : env49866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49865_49866 : H12AffineEnvironment.transform 5 17 env49865 = env49866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49865 == env49866) = true)

theorem identity49866 : scanCanonicalize (H12AffineFastState.compose env49866 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound49866 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env49867 : List Nat := [2,4,8,16,32,17,8,256,293,1024,1281,1297,268,1281,0,262,1297,1061,1024,1,17,1045,17,3,268,17,309,1297,1297,1060,1284,1045,256,33,1280,292]

theorem envBound49867 : H12AffineFastState.Bounded env49867 := by
  intro p hp
  have h : env49867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49866_49867 : H12AffineEnvironment.transform 8 293 env49866 = env49867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env49866 == env49867) = true)

theorem identity49867 : scanCanonicalize (H12AffineFastState.compose env49867 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound49867 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49868 : List Nat := [2,4,8,16,32,17,8,63,26,1024,1086,1070,51,1086,0,57,1070,1061,1024,1,17,1045,17,3,51,17,10,1070,1070,1060,1083,1045,63,33,1087,27]

theorem envBound49868 : H12AffineFastState.Bounded env49868 := by
  intro p hp
  have h : env49868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49867_49868 : H12AffineEnvironment.transform 7 63 env49867 = env49868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env49867 == env49868) = true)

theorem identity49868 : scanCanonicalize (H12AffineFastState.compose env49868 (packedSelected [7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49868 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env49869 : List Nat := [2,4,8,16,32,17,8,63,26,53,11,27,51,11,0,57,27,16,53,1,17,32,17,3,51,17,10,27,27,17,14,32,63,33,10,27]

theorem envBound49869 : H12AffineFastState.Bounded env49869 := by
  intro p hp
  have h : env49869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49868_49869 : H12AffineEnvironment.transform 9 53 env49868 = env49869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49868 == env49869) = true)

def env49870 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147456,147475,8193,64,4409702,2319690,2233680,2420,75102,6497626,256,2188650,2172186,513]

theorem envBound49870 : H12AffineFastState.Bounded env49870 := by
  intro p hp
  have h : env49870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49856_49870 : H12AffineEnvironment.transform 6 9 env49856 = env49870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49856 == env49870) = true)

theorem identity49870 : scanCanonicalize (H12AffineFastState.compose env49870 (packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS)) = affineNative (2^(20+1) ^^^ 91467) := by decide +kernel

theorem selectedBound49870 : packedSelected [0,1,4,5,7,9,10,12,14,15,16,20,24,28] rootPS < 2^1333 := by decide +kernel

def env49871 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,91467,4194304,147456,147475,8193,64,4409702,131073,225307,2420,75102,4341777,256,33,16465,513]

theorem envBound49871 : H12AffineFastState.Bounded env49871 := by
  intro p hp
  have h : env49871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49870_49871 : H12AffineEnvironment.transform 20 91467 env49870 = env49871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91467 env49870 == env49871) = true)

theorem identity49871 : scanCanonicalize (H12AffineFastState.compose env49871 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound49871 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env49872 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,91467,4194304,16,3,8193,64,4262262,16401,77835,2420,75102,4194305,256,33,16465,513]

theorem envBound49872 : H12AffineFastState.Bounded env49872 := by
  intro p hp
  have h : env49872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49871_49872 : H12AffineEnvironment.transform 16 16400 env49871 = env49872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49871 == env49872) = true)

theorem identity49872 : scanCanonicalize (H12AffineFastState.compose env49872 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound49872 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49873 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,91467,73771,16,3,8193,64,10589,16401,77835,2420,75102,73770,256,33,16465,513]

theorem envBound49873 : H12AffineFastState.Bounded env49873 := by
  intro p hp
  have h : env49873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49872_49873 : H12AffineEnvironment.transform 21 73771 env49872 = env49873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env49872 == env49873) = true)

theorem identity49873 : scanCanonicalize (H12AffineFastState.compose env49873 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound49873 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49874 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8283,16400,10281,1024,8540,17680,112,16,3,8193,64,10589,16401,4176,2420,1285,113,256,33,16465,513]

theorem envBound49874 : H12AffineFastState.Bounded env49874 := by
  intro p hp
  have h : env49874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49873_49874 : H12AffineEnvironment.transform 15 8283 env49873 = env49874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env49873 == env49874) = true)

theorem identity49874 : scanCanonicalize (H12AffineFastState.compose env49874 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49874 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49875 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,262,16400,2420,1024,1,17680,112,16,3,348,64,2048,16401,4176,2420,1285,113,256,33,16465,513]

theorem envBound49875 : H12AffineFastState.Bounded env49875 := by
  intro p hp
  have h : env49875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49874_49875 : H12AffineEnvironment.transform 12 349 env49874 = env49875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49874 == env49875) = true)

theorem identity49875 : scanCanonicalize (H12AffineFastState.compose env49875 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound49875 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49876 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5237,0,262,5221,2420,1024,1,4453,112,16,3,348,64,2048,5220,4176,2420,1285,113,256,33,5156,513]

theorem envBound49876 : H12AffineFastState.Bounded env49876 := by
  intro p hp
  have h : env49876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49875_49876 : H12AffineEnvironment.transform 13 5237 env49875 = env49876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env49875 == env49876) = true)

theorem identity49876 : scanCanonicalize (H12AffineFastState.compose env49876 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49876 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env49877 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5156,0,262,5172,2341,1024,1,4404,33,16,3,269,17,2048,5173,4097,2341,1285,32,256,33,5156,513]

theorem envBound49877 : H12AffineFastState.Bounded env49877 := by
  intro p hp
  have h : env49877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49876_49877 : H12AffineEnvironment.transform 5 17 env49876 = env49877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49876 == env49877) = true)

def env49878 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2836,0,262,2820,2341,1024,1,3588,33,16,3,269,17,2048,2821,3889,2341,1285,32,256,33,2836,513]

theorem envBound49878 : H12AffineFastState.Bounded env49878 := by
  intro p hp
  have h : env49878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49877_49878 : H12AffineEnvironment.transform 11 3888 env49877 = env49878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env49877 == env49878) = true)

def env49879 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1044,0,262,1028,1573,1024,1,260,33,16,3,269,17,1792,1029,49,1573,1285,32,256,33,1044,513]

theorem envBound49879 : H12AffineFastState.Bounded env49879 := by
  intro p hp
  have h : env49879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49878_49879 : H12AffineEnvironment.transform 10 1792 env49878 = env49879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env49878 == env49879) = true)

theorem identity49879 : scanCanonicalize (H12AffineFastState.compose env49879 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49879 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49880 : List Nat := [2,4,8,16,32,17,9,256,512,53,821,48,268,33,0,262,49,528,53,1,260,33,16,3,269,17,821,48,49,528,304,32,256,33,33,513]

theorem envBound49880 : H12AffineFastState.Bounded env49880 := by
  intro p hp
  have h : env49880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49879_49880 : H12AffineEnvironment.transform 9 53 env49879 = env49880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49879 == env49880) = true)

theorem identity49880 : scanCanonicalize (H12AffineFastState.compose env49880 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound49880 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49881 : List Nat := [2,4,8,16,32,17,9,256,271,53,58,48,268,33,0,262,49,287,53,1,260,33,16,3,269,17,58,48,49,287,304,32,256,33,33,270]

theorem envBound49881 : H12AffineFastState.Bounded env49881 := by
  intro p hp
  have h : env49881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49880_49881 : H12AffineEnvironment.transform 8 271 env49880 = env49881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env49880 == env49881) = true)

def leafEnv49881 : List Nat := [2,4,8,16,32,17,9,256,271,53,58,48,268,33,0,262,49,287,53,1,260,33,16,3,304,269,1,17,58,48,49,287,304,32,256,33,4,263,33,270,1,260,0]

def active49881 : List Nat := [0,1,2,3,4,7]

def tree49881 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49881 : H12WitnessSearch.Good tree49881 := H12GlobalWitnessIndex.good

theorem leafIdentity49881 : H12AffineFastState.composeSystem env49881 rootObs = leafEnv49881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49881 rootObs == leafEnv49881) = true)

theorem terminalChecked49881 : H12PackedTerminal.terminalCheckFast leafEnv49881 active49881 tree49881 = true := by decide +kernel

def env49882 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1045,0,262,1029,1572,1024,1,261,33,16,3,269,17,1793,1028,48,1572,1285,32,256,33,1045,513]

theorem envBound49882 : H12AffineFastState.Bounded env49882 := by
  intro p hp
  have h : env49882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49878_49882 : H12AffineEnvironment.transform 10 1793 env49878 = env49882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env49878 == env49882) = true)

theorem identity49882 : scanCanonicalize (H12AffineFastState.compose env49882 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49882 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49883 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,49,40,1045,0,34,1029,1572,1024,1,33,33,16,3,41,17,1573,1028,48,1572,1057,32,36,33,1045,513]

theorem envBound49883 : H12AffineFastState.Bounded env49883 := by
  intro p hp
  have h : env49883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49882_49883 : H12AffineEnvironment.transform 7 36 env49882 = env49883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49882 == env49883) = true)

def env49884 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,40,33,0,34,49,528,52,1,33,33,16,3,41,17,529,48,48,528,21,32,36,33,33,513]

theorem envBound49884 : H12AffineFastState.Bounded env49884 := by
  intro p hp
  have h : env49884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49883_49884 : H12AffineEnvironment.transform 9 52 env49883 = env49884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49883 == env49884) = true)

def env49885 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,40,32,0,34,48,529,53,1,33,33,16,3,41,17,528,49,48,529,20,32,36,33,32,513]

theorem envBound49885 : H12AffineFastState.Bounded env49885 := by
  intro p hp
  have h : env49885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49883_49885 : H12AffineEnvironment.transform 9 53 env49883 = env49885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49883 == env49885) = true)

theorem identity49885 : scanCanonicalize (H12AffineFastState.compose env49885 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound49885 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49886 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,49,40,32,0,34,48,59,53,1,33,33,16,3,41,17,58,49,48,59,20,32,36,33,32,43]

theorem envBound49886 : H12AffineFastState.Bounded env49886 := by
  intro p hp
  have h : env49886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49885_49886 : H12AffineEnvironment.transform 8 42 env49885 = env49886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env49885 == env49886) = true)

def leafEnv49886 : List Nat := [2,4,8,16,32,17,9,36,42,53,58,49,40,32,0,34,48,59,53,1,33,33,16,3,20,41,1,17,58,49,48,59,20,32,36,33,4,35,32,43,1,33,0]

def active49886 : List Nat := [0,1,2,3,4]

def tree49886 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49886 : H12WitnessSearch.Good tree49886 := H12GlobalWitnessIndex.good

theorem leafIdentity49886 : H12AffineFastState.composeSystem env49886 rootObs = leafEnv49886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49886 rootObs == leafEnv49886) = true)

theorem terminalChecked49886 : H12PackedTerminal.terminalCheckFast leafEnv49886 active49886 tree49886 = true := by decide +kernel

def env49887 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2837,0,262,2821,2341,1024,1,3589,33,16,3,269,17,2048,2820,3888,2341,1285,32,256,33,2837,513]

theorem envBound49887 : H12AffineFastState.Bounded env49887 := by
  intro p hp
  have h : env49887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49877_49887 : H12AffineEnvironment.transform 11 3889 env49877 = env49887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env49877 == env49887) = true)

def env49888 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1045,0,262,1029,1573,1024,1,261,33,16,3,269,17,1792,1028,48,1573,1285,32,256,33,1045,513]

theorem envBound49888 : H12AffineFastState.Bounded env49888 := by
  intro p hp
  have h : env49888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49887_49888 : H12AffineEnvironment.transform 10 1792 env49887 = env49888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env49887 == env49888) = true)

def env49889 : List Nat := [2,4,8,16,32,17,9,256,512,52,820,49,268,33,0,262,49,529,52,1,261,33,16,3,269,17,820,48,48,529,305,32,256,33,33,513]

theorem envBound49889 : H12AffineFastState.Bounded env49889 := by
  intro p hp
  have h : env49889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49888_49889 : H12AffineEnvironment.transform 9 52 env49888 = env49889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49888 == env49889) = true)

def env49890 : List Nat := [2,4,8,16,32,17,9,256,512,53,821,49,268,32,0,262,48,528,53,1,261,33,16,3,269,17,821,49,48,528,304,32,256,33,32,513]

theorem envBound49890 : H12AffineFastState.Bounded env49890 := by
  intro p hp
  have h : env49890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49888_49890 : H12AffineEnvironment.transform 9 53 env49888 = env49890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49888 == env49890) = true)

theorem identity49890 : scanCanonicalize (H12AffineFastState.compose env49890 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound49890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49891 : List Nat := [2,4,8,16,32,17,9,256,270,53,59,49,268,32,0,262,48,286,53,1,261,33,16,3,269,17,59,49,48,286,304,32,256,33,32,271]

theorem envBound49891 : H12AffineFastState.Bounded env49891 := by
  intro p hp
  have h : env49891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49890_49891 : H12AffineEnvironment.transform 8 270 env49890 = env49891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env49890 == env49891) = true)

def leafEnv49891 : List Nat := [2,4,8,16,32,17,9,256,270,53,59,49,268,32,0,262,48,286,53,1,261,33,16,3,304,269,1,17,59,49,48,286,304,32,256,33,4,263,32,271,1,261,0]

def active49891 : List Nat := [0,1,2,3,4,7]

def tree49891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49891 : H12WitnessSearch.Good tree49891 := H12GlobalWitnessIndex.good

theorem leafIdentity49891 : H12AffineFastState.composeSystem env49891 rootObs = leafEnv49891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49891 rootObs == leafEnv49891) = true)

theorem terminalChecked49891 : H12PackedTerminal.terminalCheckFast leafEnv49891 active49891 tree49891 = true := by decide +kernel

def env49892 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1044,0,262,1028,1572,1024,1,260,33,16,3,269,17,1793,1029,49,1572,1285,32,256,33,1044,513]

theorem envBound49892 : H12AffineFastState.Bounded env49892 := by
  intro p hp
  have h : env49892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49887_49892 : H12AffineEnvironment.transform 10 1793 env49887 = env49892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env49887 == env49892) = true)

theorem identity49892 : scanCanonicalize (H12AffineFastState.compose env49892 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound49892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49893 : List Nat := [2,4,8,16,32,17,9,256,512,273,528,48,268,261,0,262,277,821,273,1,260,33,16,3,269,17,528,276,49,821,20,32,256,33,261,513]

theorem envBound49893 : H12AffineFastState.Bounded env49893 := by
  intro p hp
  have h : env49893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49892_49893 : H12AffineEnvironment.transform 9 273 env49892 = env49893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env49892 == env49893) = true)

def env49894 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,40,33,0,34,49,529,53,1,32,33,16,3,41,17,528,48,49,529,20,32,36,33,33,513]

theorem envBound49894 : H12AffineFastState.Bounded env49894 := by
  intro p hp
  have h : env49894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49893_49894 : H12AffineEnvironment.transform 7 36 env49893 = env49894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49893 == env49894) = true)

theorem identity49894 : scanCanonicalize (H12AffineFastState.compose env49894 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49894 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49895 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,48,40,33,0,34,49,58,53,1,32,33,16,3,41,17,59,48,49,58,20,32,36,33,33,42]

theorem envBound49895 : H12AffineFastState.Bounded env49895 := by
  intro p hp
  have h : env49895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49894_49895 : H12AffineEnvironment.transform 8 43 env49894 = env49895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49894 == env49895) = true)

def leafEnv49895 : List Nat := [2,4,8,16,32,17,9,36,43,53,59,48,40,33,0,34,49,58,53,1,32,33,16,3,20,41,1,17,59,48,49,58,20,32,36,33,4,35,33,42,1,32,0]

def active49895 : List Nat := [0,1,2,3,4]

def tree49895 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49895 : H12WitnessSearch.Good tree49895 := H12GlobalWitnessIndex.good

theorem leafIdentity49895 : H12AffineFastState.composeSystem env49895 rootObs = leafEnv49895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49895 rootObs == leafEnv49895) = true)

theorem terminalChecked49895 : H12PackedTerminal.terminalCheckFast leafEnv49895 active49895 tree49895 = true := by decide +kernel

def env49896 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,48,41,32,0,35,48,528,52,1,33,33,16,3,40,17,528,49,49,528,20,32,37,33,32,513]

theorem envBound49896 : H12AffineFastState.Bounded env49896 := by
  intro p hp
  have h : env49896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49893_49896 : H12AffineEnvironment.transform 7 37 env49893 = env49896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49893 == env49896) = true)

def env49897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10401,1024,32769,2097152,4194304,147593,147475,8328,64,4450362,2344094,2233817,43048,99466,6497747,256,2212919,2172307,41820]

theorem envBound49897 : H12AffineFastState.Bounded env49897 := by
  intro p hp
  have h : env49897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49854_49897 : H12AffineEnvironment.transform 17 10401 env49854 = env49897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env49854 == env49897) = true)

theorem identity49897 : scanCanonicalize (H12AffineFastState.compose env49897 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound49897 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,10401,1024,32769,2097152,4194304,41293,41431,8328,64,4262398,2172250,2159645,43048,99466,6407191,256,2212919,2172307,41820]

theorem envBound49898 : H12AffineFastState.Bounded env49898 := by
  intro p hp
  have h : env49898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49897_49898 : H12AffineEnvironment.transform 16 57796 env49897 = env49898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env49897 == env49898) = true)

theorem identity49898 : scanCanonicalize (H12AffineFastState.compose env49898 (packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound49898 : packedSelected [0,1,5,8,9,14,17,19,21,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env49899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,57796,10401,1024,32769,2097152,4194304,41293,41431,8328,64,4204925,2098649,2159645,43048,41993,6349972,256,2155700,2098448,41820]

theorem envBound49899 : H12AffineFastState.Bounded env49899 := by
  intro p hp
  have h : env49899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49898_49899 : H12AffineEnvironment.transform 15 8323 env49898 = env49899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env49898 == env49899) = true)

theorem identity49899 : scanCanonicalize (H12AffineFastState.compose env49899 (packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound49899 : packedSelected [0,4,7,11,12,15,16,17,18,20,21,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env49900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,57796,10401,1024,32769,2097152,41341,41293,41431,8328,64,34816,2098649,2159645,43048,41993,2115049,256,2155700,2098448,41820]

theorem envBound49900 : H12AffineFastState.Bounded env49900 := by
  intro p hp
  have h : env49900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49899_49900 : H12AffineEnvironment.transform 21 41341 env49899 = env49900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env49899 == env49900) = true)

theorem identity49900 : scanCanonicalize (H12AffineFastState.compose env49900 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 50449) := by decide +kernel

theorem selectedBound49900 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env49901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8323,57796,10401,1024,32769,50449,41341,41293,41431,8328,64,34816,49352,12556,43048,41993,33016,256,8613,49153,41820]

theorem envBound49901 : H12AffineFastState.Bounded env49901 := by
  intro p hp
  have h : env49901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49900_49901 : H12AffineEnvironment.transform 20 50449 env49900 = env49901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 50449 env49900 == env49901) = true)

end H12CloudChart1