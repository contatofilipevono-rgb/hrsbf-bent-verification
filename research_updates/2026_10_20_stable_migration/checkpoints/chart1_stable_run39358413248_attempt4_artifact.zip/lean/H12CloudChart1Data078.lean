import H12CloudChart1Data077

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound19707 : H12AffineFastState.Bounded env19707 := by
  intro p hp
  have h : env19707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19706_19707 : H12AffineEnvironment.transform 21 409024 env19706 = env19707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 409024 env19706 == env19707) = true)

theorem identity19707 : scanCanonicalize (H12AffineFastState.compose env19707 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound19707 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,146792,1024,8540,4297,168,16,138,8328,64,10629,5392,4232,2340,1365,168,256,32,5592,513]

theorem envBound19708 : H12AffineFastState.Bounded env19708 := by
  intro p hp
  have h : env19708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19707_19708 : H12AffineEnvironment.transform 17 146792 env19707 = env19708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env19707 == env19708) = true)

theorem identity19708 : scanCanonicalize (H12AffineFastState.compose env19708 (packedSelected [0,3,4,10,14,18,19,20,22,23,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound19708 : packedSelected [0,3,4,10,14,18,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env19709 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,217,262,131072,138476,1024,216,4297,168,16,138,268,64,2049,5392,4232,2340,1365,168,256,32,5592,513]

theorem envBound19709 : H12AffineFastState.Bounded env19709 := by
  intro p hp
  have h : env19709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19708_19709 : H12AffineEnvironment.transform 12 388 env19708 = env19709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env19708 == env19709) = true)

theorem identity19709 : scanCanonicalize (H12AffineFastState.compose env19709 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound19709 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env19710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5376,217,262,5393,2557,1024,216,4297,168,16,138,268,64,2049,5392,4232,2340,1365,168,256,32,5592,513]

theorem envBound19710 : H12AffineFastState.Bounded env19710 := by
  intro p hp
  have h : env19710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19709_19710 : H12AffineEnvironment.transform 16 5393 env19709 = env19710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env19709 == env19710) = true)

theorem identity19710 : scanCanonicalize (H12AffineFastState.compose env19710 (packedSelected [0,4,7,9,11,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 3325) := by decide +kernel

theorem selectedBound19710 : packedSelected [0,4,7,9,11,12,18] rootPS < 2^1333 := by decide +kernel

def env19711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3325,388,2557,217,262,2540,2557,1024,216,3124,168,16,138,268,64,2049,2541,3189,2340,1365,168,256,32,2341,513]

theorem envBound19711 : H12AffineFastState.Bounded env19711 := by
  intro p hp
  have h : env19711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19710_19711 : H12AffineEnvironment.transform 11 3325 env19710 = env19711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3325 env19710 == env19711) = true)

theorem identity19711 : scanCanonicalize (H12AffineFastState.compose env19711 (packedSelected [0,3,4,5,7,9,10,11,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19711 : packedSelected [0,3,4,5,7,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env19712 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,2541,388,2557,217,262,2540,2557,272,216,2340,168,16,138,268,64,2049,2541,2405,2340,69,168,256,32,2341,513]

theorem envBound19712 : H12AffineFastState.Bounded env19712 := by
  intro p hp
  have h : env19712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19711_19712 : H12AffineEnvironment.transform 9 272 env19711 = env19712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19711 == env19712) = true)

theorem identity19712 : scanCanonicalize (H12AffineFastState.compose env19712 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19712 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19713 : List Nat := [2,4,8,16,32,16,128,256,512,272,2048,2493,388,2477,137,262,2492,2477,272,136,2340,168,16,138,268,16,2049,2493,2357,2340,21,168,256,32,2341,513]

theorem envBound19713 : H12AffineFastState.Bounded env19713 := by
  intro p hp
  have h : env19713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19712_19713 : H12AffineEnvironment.transform 5 16 env19712 = env19713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19712 == env19713) = true)

theorem identity19713 : scanCanonicalize (H12AffineFastState.compose env19713 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound19713 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19714 : List Nat := [2,4,8,16,32,16,128,256,512,272,0,445,388,429,137,262,444,429,272,136,292,168,16,138,268,16,1,445,309,292,21,168,256,32,293,513]

theorem envBound19714 : H12AffineFastState.Bounded env19714 := by
  intro p hp
  have h : env19714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19713_19714 : H12AffineEnvironment.transform 10 0 env19713 = env19714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env19713 == env19714) = true)

def env19715 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,262144,1024,8540,4297,409025,16,138,8328,64,10628,5392,4232,406604,1365,409025,256,32,5592,513]

theorem envBound19715 : H12AffineFastState.Bounded env19715 := by
  intro p hp
  have h : env19715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19706_19715 : H12AffineEnvironment.transform 21 409025 env19706 = env19715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 409025 env19706 == env19715) = true)

theorem identity19715 : scanCanonicalize (H12AffineFastState.compose env19715 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146913) := by decide +kernel

theorem selectedBound19715 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8322,131072,146913,1024,8540,4297,32,16,138,8328,64,10628,5392,4232,2477,1365,32,256,32,5592,513]

theorem envBound19716 : H12AffineFastState.Bounded env19716 := by
  intro p hp
  have h : env19716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19715_19716 : H12AffineEnvironment.transform 17 146913 env19715 = env19716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env19715 == env19716) = true)

theorem identity19716 : scanCanonicalize (H12AffineFastState.compose env19716 (packedSelected [18,23] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19716 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,80,399,131072,138476,1024,81,4297,32,16,138,389,64,2185,5392,4232,2477,1365,32,256,32,5592,513]

theorem envBound19717 : H12AffineFastState.Bounded env19717 := by
  intro p hp
  have h : env19717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19716_19717 : H12AffineEnvironment.transform 12 269 env19716 = env19717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19716 == env19717) = true)

theorem identity19717 : scanCanonicalize (H12AffineFastState.compose env19717 (packedSelected [0,3,4,7,10,19,22,24] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound19717 : packedSelected [0,3,4,7,10,19,22,24] rootPS < 2^1333 := by decide +kernel

def env19718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5376,80,399,5528,2420,1024,81,4297,32,16,138,389,64,2185,5392,4232,2477,1365,32,256,32,5592,513]

theorem envBound19718 : H12AffineFastState.Bounded env19718 := by
  intro p hp
  have h : env19718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19717_19718 : H12AffineEnvironment.transform 16 5528 env19717 = env19718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env19717 == env19718) = true)

theorem identity19718 : scanCanonicalize (H12AffineFastState.compose env19718 (packedSelected [3,5,10,11,12,18] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound19718 : packedSelected [3,5,10,11,12,18] rootPS < 2^1333 := by decide +kernel

def env19719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,4096,269,5376,80,399,5528,1077,1024,81,4297,32,16,138,389,64,1480,5392,4232,1260,1365,32,256,32,5592,513]

theorem envBound19719 : H12AffineFastState.Bounded env19719 := by
  intro p hp
  have h : env19719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19718_19719 : H12AffineEnvironment.transform 10 1345 env19718 = env19719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env19718 == env19719) = true)

theorem identity19719 : scanCanonicalize (H12AffineFastState.compose env19719 (packedSelected [0,7,11,12,15,20] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound19719 : packedSelected [0,7,11,12,15,20] rootPS < 2^1333 := by decide +kernel

def env19720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1345,1141,269,373,80,399,493,1077,1024,81,1212,32,16,138,389,64,1480,357,1277,1260,1365,32,256,32,429,513]

theorem envBound19720 : H12AffineFastState.Bounded env19720 := by
  intro p hp
  have h : env19720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19719_19720 : H12AffineEnvironment.transform 11 1141 env19719 = env19720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env19719 == env19720) = true)

theorem identity19720 : scanCanonicalize (H12AffineFastState.compose env19720 (packedSelected [1,4,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound19720 : packedSelected [1,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env19721 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1345,1141,269,373,80,343,309,1077,1024,81,1124,32,16,82,349,64,1296,357,1061,1076,1365,32,256,32,373,513]

theorem envBound19721 : H12AffineFastState.Bounded env19721 := by
  intro p hp
  have h : env19721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19720_19721 : H12AffineEnvironment.transform 6 88 env19720 = env19721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env19720 == env19721) = true)

theorem identity19721 : scanCanonicalize (H12AffineFastState.compose env19721 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound19721 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env19722 : List Nat := [2,4,8,16,32,64,88,101,512,1024,1060,1141,104,16,80,50,80,1077,1024,81,1124,32,16,82,56,64,1141,0,1061,1076,1072,32,101,32,16,513]

theorem envBound19722 : H12AffineFastState.Bounded env19722 := by
  intro p hp
  have h : env19722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19721_19722 : H12AffineEnvironment.transform 7 101 env19721 = env19722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env19721 == env19722) = true)

def env19723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,17,98645,8328,64,4592709,5393,4233,431377,1364,4235613,256,33,46213,74370]

theorem envBound19723 : H12AffineFastState.Bounded env19723 := by
  intro p hp
  have h : env19723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19703_19723 : H12AffineEnvironment.transform 13 5377 env19703 = env19723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19703 == env19723) = true)

theorem identity19723 : scanCanonicalize (H12AffineFastState.compose env19723 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41460) := by decide +kernel

theorem selectedBound19723 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,41460,17,98645,8328,64,439729,5393,4233,431377,1364,169,256,33,46213,74370]

theorem envBound19724 : H12AffineFastState.Bounded env19724 := by
  intro p hp
  have h : env19724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19723_19724 : H12AffineEnvironment.transform 21 41460 env19723 = env19724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41460 env19723 == env19724) = true)

def env19725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4160,41340,17,98645,8192,64,439609,5393,4097,431377,1364,33,256,33,46093,74250]

theorem envBound19725 : H12AffineFastState.Bounded env19725 := by
  intro p hp
  have h : env19725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19724_19725 : H12AffineEnvironment.transform 6 8 env19724 = env19725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19724 == env19725) = true)

theorem identity19725 : scanCanonicalize (H12AffineFastState.compose env19725 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound19725 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,67618,1024,32769,4160,41340,17,98645,8192,64,245019,5393,4097,236851,1364,33,256,33,46093,74250]

theorem envBound19726 : H12AffineFastState.Bounded env19726 := by
  intro p hp
  have h : env19726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19725_19726 : H12AffineEnvironment.transform 17 67618 env19725 = env19726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env19725 == env19726) = true)

theorem identity19726 : scanCanonicalize (H12AffineFastState.compose env19726 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 46109) := by decide +kernel

theorem selectedBound19726 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,46109,67618,1024,32769,4160,41340,17,98645,8192,64,67846,5393,4097,76078,1364,33,256,33,46093,74250]

theorem envBound19727 : H12AffineFastState.Bounded env19727 := by
  intro p hp
  have h : env19727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19726_19727 : H12AffineEnvironment.transform 16 46109 env19726 = env19727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46109 env19726 == env19727) = true)

theorem identity19727 : scanCanonicalize (H12AffineFastState.compose env19727 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19727 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env19728 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,65536,38160,67618,1024,32769,4160,32881,17,98645,269,64,67846,5393,4097,67619,1364,33,256,33,38144,66311]

theorem envBound19728 : H12AffineFastState.Bounded env19728 := by
  intro p hp
  have h : env19728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19727_19728 : H12AffineEnvironment.transform 12 269 env19727 = env19728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19727 == env19728) = true)

theorem identity19728 : scanCanonicalize (H12AffineFastState.compose env19728 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound19728 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env19729 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,65536,5441,67618,1024,80,4160,32,17,65796,269,64,67846,5393,4097,67619,1364,33,256,33,5457,66311]

theorem envBound19729 : H12AffineFastState.Bounded env19729 := by
  intro p hp
  have h : env19729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19728_19729 : H12AffineEnvironment.transform 14 81 env19728 = env19729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env19728 == env19729) = true)

theorem identity19729 : scanCanonicalize (H12AffineFastState.compose env19729 (packedSelected [1,4,6,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1875) := by decide +kernel

theorem selectedBound19729 : packedSelected [1,4,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env19730 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,1875,5441,3953,1024,80,4160,32,17,1623,269,64,3669,5393,4097,3952,1364,33,256,33,5457,1108]

theorem envBound19730 : H12AffineFastState.Bounded env19730 := by
  intro p hp
  have h : env19730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19729_19730 : H12AffineEnvironment.transform 15 1875 env19729 = env19730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1875 env19729 == env19730) = true)

theorem identity19730 : scanCanonicalize (H12AffineFastState.compose env19730 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 849) := by decide +kernel

theorem selectedBound19730 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env19731 : List Nat := [2,4,8,16,32,64,8,256,512,849,2048,4096,269,4688,81,2,4624,2080,849,80,4160,32,17,262,269,64,2308,4672,4097,2081,517,33,256,33,4608,773]

theorem envBound19731 : H12AffineFastState.Bounded env19731 := by
  intro p hp
  have h : env19731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19730_19731 : H12AffineEnvironment.transform 9 849 env19730 = env19731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 849 env19730 == env19731) = true)

theorem identity19731 : scanCanonicalize (H12AffineFastState.compose env19731 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19731 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19732 : List Nat := [2,4,8,16,32,17,8,256,512,768,2048,4096,269,4609,0,2,4624,2080,768,1,4113,32,17,262,269,17,2308,4625,4097,2081,517,33,256,33,4608,773]

theorem envBound19732 : H12AffineFastState.Bounded env19732 := by
  intro p hp
  have h : env19732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19731_19732 : H12AffineEnvironment.transform 5 17 env19731 = env19732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19731 == env19732) = true)

theorem identity19732 : scanCanonicalize (H12AffineFastState.compose env19732 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound19732 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env19733 : List Nat := [2,4,8,16,32,17,8,256,512,768,2048,292,269,805,0,2,820,2080,768,1,309,32,17,262,269,17,2308,821,293,2081,517,33,256,33,804,773]

theorem envBound19733 : H12AffineFastState.Bounded env19733 := by
  intro p hp
  have h : env19733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19732_19733 : H12AffineEnvironment.transform 11 292 env19732 = env19733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env19732 == env19733) = true)

theorem identity19733 : scanCanonicalize (H12AffineFastState.compose env19733 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19733 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env19734 : List Nat := [2,4,8,16,1,17,8,256,512,768,2048,261,269,772,0,2,789,2049,768,1,276,1,17,262,269,17,2308,788,260,2048,517,0,256,0,773,773]

theorem envBound19734 : H12AffineFastState.Bounded env19734 := by
  intro p hp
  have h : env19734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19733_19734 : H12AffineEnvironment.transform 4 1 env19733 = env19734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19733 == env19734) = true)

theorem identity19734 : scanCanonicalize (H12AffineFastState.compose env19734 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound19734 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env19735 : List Nat := [2,4,8,16,1,17,8,256,512,768,513,261,269,772,0,2,789,512,768,1,276,1,17,262,269,17,773,788,260,513,517,0,256,0,773,773]

theorem envBound19735 : H12AffineFastState.Bounded env19735 := by
  intro p hp
  have h : env19735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19734_19735 : H12AffineEnvironment.transform 10 513 env19734 = env19735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env19734 == env19735) = true)

theorem identity19735 : scanCanonicalize (H12AffineFastState.compose env19735 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound19735 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env19736 : List Nat := [2,4,8,16,1,17,8,256,261,5,260,261,269,1,0,2,16,261,5,1,276,1,17,262,269,17,0,17,260,260,256,0,256,0,0,0]

theorem envBound19736 : H12AffineFastState.Bounded env19736 := by
  intro p hp
  have h : env19736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19735_19736 : H12AffineEnvironment.transform 8 261 env19735 = env19736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env19735 == env19736) = true)

theorem identity19736 : scanCanonicalize (H12AffineFastState.compose env19736 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19736 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19737 : List Nat := [2,4,8,0,1,1,8,256,261,5,260,261,269,1,0,2,0,261,5,1,260,1,1,262,269,1,0,1,260,260,256,0,256,0,0,0]

theorem envBound19737 : H12AffineFastState.Bounded env19737 := by
  intro p hp
  have h : env19737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19736_19737 : H12AffineEnvironment.transform 3 0 env19736 = env19737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19736 == env19737) = true)

theorem identity19737 : scanCanonicalize (H12AffineFastState.compose env19737 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19737 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19738 : List Nat := [2,4,8,0,1,1,8,4,1,5,0,1,9,1,0,2,0,1,5,1,0,1,1,2,9,1,0,1,0,0,4,0,4,0,0,0]

theorem envBound19738 : H12AffineFastState.Bounded env19738 := by
  intro p hp
  have h : env19738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19737_19738 : H12AffineEnvironment.transform 7 4 env19737 = env19738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19737 == env19738) = true)

def env19739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4161,41341,17,98645,8193,64,439608,5393,4096,431377,1364,32,256,33,46092,74251]

theorem envBound19739 : H12AffineFastState.Bounded env19739 := by
  intro p hp
  have h : env19739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19724_19739 : H12AffineEnvironment.transform 6 9 env19724 = env19739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19724 == env19739) = true)

theorem identity19739 : scanCanonicalize (H12AffineFastState.compose env19739 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound19739 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,108927,1024,32769,4161,41341,17,98645,8193,64,203847,5393,4096,212078,1364,32,256,33,46092,74251]

theorem envBound19740 : H12AffineFastState.Bounded env19740 := by
  intro p hp
  have h : env19740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19739_19740 : H12AffineEnvironment.transform 17 108927 env19739 = env19740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env19739 == env19740) = true)

theorem identity19740 : scanCanonicalize (H12AffineFastState.compose env19740 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound19740 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,79130,108927,1024,32769,4161,41341,17,98645,8193,64,10589,5393,4096,2420,1364,32,256,33,46092,74251]

theorem envBound19741 : H12AffineFastState.Bounded env19741 := by
  intro p hp
  have h : env19741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19740_19741 : H12AffineEnvironment.transform 16 79130 env19740 = env19741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env19740 == env19741) = true)

theorem identity19741 : scanCanonicalize (H12AffineFastState.compose env19741 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound19741 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,35,13625,43356,1024,32769,4161,41341,17,33142,8193,64,10589,5393,4096,2420,1364,32,256,33,46092,8744]

theorem envBound19742 : H12AffineFastState.Bounded env19742 := by
  intro p hp
  have h : env19742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19741_19742 : H12AffineEnvironment.transform 15 35 env19741 = env19742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env19741 == env19742) = true)

theorem identity19742 : scanCanonicalize (H12AffineFastState.compose env19742 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound19742 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env19743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,35,5393,35188,1024,32769,4161,33109,17,33142,41,64,2421,5393,4096,2420,1364,32,256,33,37924,512]

theorem envBound19743 : H12AffineFastState.Bounded env19743 := by
  intro p hp
  have h : env19743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19742_19743 : H12AffineEnvironment.transform 12 40 env19742 = env19743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env19742 == env19743) = true)

theorem identity19743 : scanCanonicalize (H12AffineFastState.compose env19743 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19743 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19744 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5157,32768,35,5173,34896,1024,32769,4161,32881,17,32850,41,64,2129,5173,4096,2128,1136,32,36,33,37924,512]

theorem envBound19744 : H12AffineFastState.Bounded env19744 := by
  intro p hp
  have h : env19744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19743_19744 : H12AffineEnvironment.transform 7 36 env19743 = env19744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19743 == env19744) = true)

theorem identity19744 : scanCanonicalize (H12AffineFastState.compose env19744 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(14+1) ^^^ 5733) := by decide +kernel

theorem selectedBound19744 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env19745 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,40,5157,5733,35,5173,7733,1024,5732,4161,5652,17,5687,41,64,2129,5173,4096,2128,1136,32,36,33,577,512]

theorem envBound19745 : H12AffineFastState.Bounded env19745 := by
  intro p hp
  have h : env19745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19744_19745 : H12AffineEnvironment.transform 14 5733 env19744 = env19745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5733 env19744 == env19745) = true)

theorem identity19745 : scanCanonicalize (H12AffineFastState.compose env19745 (packedSelected [0,1,2,3,4,5,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 1124) := by decide +kernel

theorem selectedBound19745 : packedSelected [0,1,2,3,4,5,8,10] rootPS < 2^1333 := by decide +kernel

def env19746 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,1124,40,65,513,35,81,2641,1024,512,1061,624,17,595,41,64,2129,81,1124,2128,1136,32,36,33,577,512]

theorem envBound19746 : H12AffineFastState.Bounded env19746 := by
  intro p hp
  have h : env19746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19745_19746 : H12AffineEnvironment.transform 11 1124 env19745 = env19746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1124 env19745 == env19746) = true)

theorem identity19746 : scanCanonicalize (H12AffineFastState.compose env19746 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound19746 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env19747 : List Nat := [2,4,8,16,32,64,9,36,512,564,2048,592,40,65,513,35,81,2641,564,512,529,624,17,595,41,64,2129,81,592,2128,580,32,36,33,577,512]

theorem envBound19747 : H12AffineFastState.Bounded env19747 := by
  intro p hp
  have h : env19747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19746_19747 : H12AffineEnvironment.transform 9 564 env19746 = env19747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env19746 == env19747) = true)

theorem identity19747 : scanCanonicalize (H12AffineFastState.compose env19747 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound19747 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19748 : List Nat := [2,4,8,16,32,48,9,36,512,564,2048,544,40,49,513,35,33,2593,564,512,529,512,17,547,41,48,2081,33,544,2080,564,32,36,33,561,512]

theorem envBound19748 : H12AffineFastState.Bounded env19748 := by
  intro p hp
  have h : env19748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19747_19748 : H12AffineEnvironment.transform 5 48 env19747 = env19748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env19747 == env19748) = true)

theorem identity19748 : scanCanonicalize (H12AffineFastState.compose env19748 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19748 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19749 : List Nat := [2,4,8,16,1,17,9,5,512,533,2048,513,9,16,513,2,0,2560,533,512,529,512,17,514,8,17,2048,0,513,2049,533,1,5,0,528,512]

theorem envBound19749 : H12AffineFastState.Bounded env19749 := by
  intro p hp
  have h : env19749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19748_19749 : H12AffineEnvironment.transform 4 1 env19748 = env19749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19748 == env19749) = true)

theorem identity19749 : scanCanonicalize (H12AffineFastState.compose env19749 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19749 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env19750 : List Nat := [2,4,8,16,1,17,9,5,1,20,2048,0,9,16,0,2,0,2049,20,1,16,1,17,3,8,17,2048,0,0,2049,20,1,5,0,17,1]

theorem envBound19750 : H12AffineFastState.Bounded env19750 := by
  intro p hp
  have h : env19750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19749_19750 : H12AffineEnvironment.transform 8 1 env19749 = env19750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19749 == env19750) = true)

theorem identity19750 : scanCanonicalize (H12AffineFastState.compose env19750 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound19750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19751 : List Nat := [2,4,8,15,1,14,9,5,1,11,2048,0,9,15,0,2,0,2049,11,1,15,1,14,3,8,14,2048,0,0,2049,11,1,5,0,14,1]

theorem envBound19751 : H12AffineFastState.Bounded env19751 := by
  intro p hp
  have h : env19751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19750_19751 : H12AffineEnvironment.transform 3 15 env19750 = env19751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env19750 == env19751) = true)

theorem identity19751 : scanCanonicalize (H12AffineFastState.compose env19751 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound19751 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env19752 : List Nat := [2,4,8,15,1,14,9,5,1,11,14,0,9,15,0,2,0,15,11,1,15,1,14,3,8,14,14,0,0,15,11,1,5,0,14,1]

theorem envBound19752 : H12AffineFastState.Bounded env19752 := by
  intro p hp
  have h : env19752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19751_19752 : H12AffineEnvironment.transform 10 14 env19751 = env19752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env19751 == env19752) = true)

def env19753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,21777,2213020,8328,64,6705549,16400,2097216,431376,2102685,4235613,256,21793,46212,2175563]

theorem envBound19753 : H12AffineFastState.Bounded env19753 := by
  intro p hp
  have h : env19753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19673_19753 : H12AffineEnvironment.transform 22 21777 env19673 = env19753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21777 env19673 == env19753) = true)

def env19754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17864,4194304,21777,98644,8328,64,4592709,16400,17800,431376,20565,4235613,256,21793,46212,96131]

theorem envBound19754 : H12AffineFastState.Bounded env19754 := by
  intro p hp
  have h : env19754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19753_19754 : H12AffineEnvironment.transform 20 17864 env19753 = env19754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env19753 == env19754) = true)

def env19755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,4194304,17,98644,8328,64,4592709,5392,4232,431376,1365,4235613,256,33,46212,74371]

theorem envBound19755 : H12AffineFastState.Bounded env19755 := by
  intro p hp
  have h : env19755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19754_19755 : H12AffineEnvironment.transform 13 5376 env19754 = env19755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19754 == env19755) = true)

theorem identity19755 : scanCanonicalize (H12AffineFastState.compose env19755 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 73890) := by decide +kernel

theorem selectedBound19755 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4296,73890,17,98644,8328,64,472295,5392,4232,431376,1365,98815,256,33,46212,74371]

theorem envBound19756 : H12AffineFastState.Bounded env19756 := by
  intro p hp
  have h : env19756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19755_19756 : H12AffineEnvironment.transform 21 73890 env19755 = env19756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73890 env19755 == env19756) = true)

def env19757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,73770,17,98644,8192,64,472175,5392,4096,431376,1365,98679,256,33,46092,74251]

theorem envBound19757 : H12AffineFastState.Bounded env19757 := by
  intro p hp
  have h : env19757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19756_19757 : H12AffineEnvironment.transform 6 8 env19756 = env19757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19756 == env19757) = true)

theorem identity19757 : scanCanonicalize (H12AffineFastState.compose env19757 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound19757 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67619,1024,32769,4160,73770,17,98644,8192,64,146508,5392,4096,236851,1365,98679,256,33,46092,74251]

theorem envBound19758 : H12AffineFastState.Bounded env19758 := by
  intro p hp
  have h : env19758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19757_19758 : H12AffineEnvironment.transform 17 67619 env19757 = env19758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env19757 == env19758) = true)

theorem identity19758 : scanCanonicalize (H12AffineFastState.compose env19758 (packedSelected [2,3,5,6,11,12,14,16,18,19,23] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound19758 : packedSelected [2,3,5,6,11,12,14,16,18,19,23] rootPS < 2^1333 := by decide +kernel

def env19759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,38160,67619,1024,32769,4160,73770,17,98644,8192,64,43356,5392,4096,67619,1365,98679,256,33,46092,74251]

theorem envBound19759 : H12AffineFastState.Bounded env19759 := by
  intro p hp
  have h : env19759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19758_19759 : H12AffineEnvironment.transform 16 38160 env19758 = env19759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env19758 == env19759) = true)

theorem identity19759 : scanCanonicalize (H12AffineFastState.compose env19759 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound19759 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env19760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,81,65536,5441,67619,1024,80,4160,73770,17,65797,8192,64,10509,5392,4096,67619,1365,65830,256,33,13405,74251]

theorem envBound19760 : H12AffineFastState.Bounded env19760 := by
  intro p hp
  have h : env19760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19759_19760 : H12AffineEnvironment.transform 14 81 env19759 = env19760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env19759 == env19760) = true)

theorem identity19760 : scanCanonicalize (H12AffineFastState.compose env19760 (packedSelected [2,3,5,6,11,12,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound19760 : packedSelected [2,3,5,6,11,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env19761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,81,343,5441,2420,1024,80,4160,8573,17,82,8192,64,10509,5392,4096,2420,1365,113,256,33,13405,9052]

theorem envBound19761 : H12AffineFastState.Bounded env19761 := by
  intro p hp
  have h : env19761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19760_19761 : H12AffineEnvironment.transform 15 343 env19760 = env19761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env19760 == env19761) = true)

theorem identity19761 : scanCanonicalize (H12AffineFastState.compose env19761 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound19761 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,81,343,5441,2420,1024,80,4160,113,17,82,268,64,2049,5392,4096,2420,1365,113,256,33,5457,592]

theorem envBound19762 : H12AffineFastState.Bounded env19762 := by
  intro p hp
  have h : env19762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19761_19762 : H12AffineEnvironment.transform 12 268 env19761 = env19762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env19761 == env19762) = true)

theorem identity19762 : scanCanonicalize (H12AffineFastState.compose env19762 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound19762 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,4096,268,5376,81,343,5441,292,1024,80,4160,113,17,82,268,64,81,5392,4096,292,1365,113,256,33,5457,592]

theorem envBound19763 : H12AffineFastState.Bounded env19763 := by
  intro p hp
  have h : env19763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19762_19763 : H12AffineEnvironment.transform 10 80 env19762 = env19763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env19762 == env19763) = true)

theorem identity19763 : scanCanonicalize (H12AffineFastState.compose env19763 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19763 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env19764 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,4096,268,5376,0,262,5392,292,1024,1,4113,32,17,3,268,17,0,5392,4096,292,1284,32,256,33,5376,513]

theorem envBound19764 : H12AffineFastState.Bounded env19764 := by
  intro p hp
  have h : env19764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19763_19764 : H12AffineEnvironment.transform 5 17 env19763 = env19764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19763 == env19764) = true)

theorem identity19764 : scanCanonicalize (H12AffineFastState.compose env19764 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound19764 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19765 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1,308,268,1076,0,262,1060,292,1024,1,293,32,17,3,268,17,0,1060,308,292,1284,32,256,33,1076,513]

theorem envBound19765 : H12AffineFastState.Bounded env19765 := by
  intro p hp
  have h : env19765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19764_19765 : H12AffineEnvironment.transform 11 308 env19764 = env19765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env19764 == env19765) = true)

theorem identity19765 : scanCanonicalize (H12AffineFastState.compose env19765 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound19765 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19766 : List Nat := [2,4,8,16,32,17,8,256,512,272,1,308,268,292,0,262,308,292,272,1,293,32,17,3,268,17,0,308,308,292,20,32,256,33,292,513]

theorem envBound19766 : H12AffineFastState.Bounded env19766 := by
  intro p hp
  have h : env19766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19765_19766 : H12AffineEnvironment.transform 9 272 env19765 = env19766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env19765 == env19766) = true)

def env19767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,73771,17,98644,8193,64,472174,5392,4097,431376,1365,98678,256,33,46093,74250]

theorem envBound19767 : H12AffineFastState.Bounded env19767 := by
  intro p hp
  have h : env19767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19756_19767 : H12AffineEnvironment.transform 6 9 env19756 = env19767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19756 == env19767) = true)

theorem identity19767 : scanCanonicalize (H12AffineFastState.compose env19767 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound19767 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108926,1024,32769,4161,73771,17,98644,8193,64,171280,5392,4097,212078,1365,98678,256,33,46093,74250]

theorem envBound19768 : H12AffineFastState.Bounded env19768 := by
  intro p hp
  have h : env19768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19767_19768 : H12AffineEnvironment.transform 17 108926 env19767 = env19768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env19767 == env19768) = true)

theorem identity19768 : scanCanonicalize (H12AffineFastState.compose env19768 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound19768 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env19769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,65536,131072,76158,1024,1,4161,73771,17,65876,8193,64,138512,5392,4097,212078,1365,65910,256,33,13325,74250]

theorem envBound19769 : H12AffineFastState.Bounded env19769 := by
  intro p hp
  have h : env19769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19768_19769 : H12AffineEnvironment.transform 14 0 env19768 = env19769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env19768 == env19769) = true)

theorem identity19769 : scanCanonicalize (H12AffineFastState.compose env19769 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound19769 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env19770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,65536,70727,76158,1024,1,4161,73771,17,65876,8193,64,67927,5392,4097,10281,1365,65910,256,33,13325,74250]

theorem envBound19770 : H12AffineFastState.Bounded env19770 := by
  intro p hp
  have h : env19770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19769_19770 : H12AffineEnvironment.transform 16 70727 env19769 = env19770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env19769 == env19770) = true)

theorem identity19770 : scanCanonicalize (H12AffineFastState.compose env19770 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19770 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env19771 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,65536,70727,67619,1024,1,4161,65910,17,65876,348,64,67927,5392,4097,2420,1365,65910,256,33,5456,66391]

theorem envBound19771 : H12AffineFastState.Bounded env19771 := by
  intro p hp
  have h : env19771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19770_19771 : H12AffineEnvironment.transform 12 349 env19770 = env19771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19770 == env19771) = true)

theorem identity19771 : scanCanonicalize (H12AffineFastState.compose env19771 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound19771 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,83,5140,2160,1024,1,4161,293,17,263,348,64,2308,5392,4097,2420,1365,293,256,33,5456,772]

theorem envBound19772 : H12AffineFastState.Bounded env19772 := by
  intro p hp
  have h : env19772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19771_19772 : H12AffineEnvironment.transform 15 83 env19771 = env19772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env19771 == env19772) = true)

theorem identity19772 : scanCanonicalize (H12AffineFastState.compose env19772 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound19772 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env19773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,81,349,1361,0,83,1093,2160,1024,1,16,293,17,263,348,64,2308,1345,80,2420,1365,293,256,33,1281,772]

theorem envBound19773 : H12AffineFastState.Bounded env19773 := by
  intro p hp
  have h : env19773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19772_19773 : H12AffineEnvironment.transform 11 81 env19772 = env19773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env19772 == env19773) = true)

theorem identity19773 : scanCanonicalize (H12AffineFastState.compose env19773 (packedSelected [1,6,8,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound19773 : packedSelected [1,6,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19774 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,32,300,1312,0,34,1076,2049,1024,1,16,293,17,263,301,49,2308,1328,33,2309,1316,293,256,33,1281,772]

theorem envBound19774 : H12AffineFastState.Bounded env19774 := by
  intro p hp
  have h : env19774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19773_19774 : H12AffineEnvironment.transform 5 49 env19773 = env19774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env19773 == env19774) = true)

theorem identity19774 : scanCanonicalize (H12AffineFastState.compose env19774 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19774 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19775 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,32,40,1060,0,34,1076,2049,1024,1,16,33,17,3,41,49,2048,1076,33,2049,1056,33,4,33,1029,512]

theorem envBound19775 : H12AffineFastState.Bounded env19775 := by
  intro p hp
  have h : env19775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19774_19775 : H12AffineEnvironment.transform 7 4 env19774 = env19775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19774 == env19775) = true)

theorem identity19775 : scanCanonicalize (H12AffineFastState.compose env19775 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound19775 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19776 : List Nat := [2,4,8,16,32,49,9,4,512,1024,11,32,40,1060,0,34,1076,10,1024,1,16,33,17,3,41,49,11,1076,33,10,1056,33,4,33,1029,512]

theorem envBound19776 : H12AffineFastState.Bounded env19776 := by
  intro p hp
  have h : env19776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19775_19776 : H12AffineEnvironment.transform 10 11 env19775 = env19776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env19775 == env19776) = true)

theorem identity19776 : scanCanonicalize (H12AffineFastState.compose env19776 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound19776 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env19777 : List Nat := [2,4,8,16,32,49,9,4,512,31,11,32,40,59,0,34,43,10,31,1,16,33,17,3,41,49,11,43,33,10,63,33,4,33,26,512]

theorem envBound19777 : H12AffineFastState.Bounded env19777 := by
  intro p hp
  have h : env19777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19776_19777 : H12AffineEnvironment.transform 9 31 env19776 = env19777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env19776 == env19777) = true)

theorem identity19777 : scanCanonicalize (H12AffineFastState.compose env19777 (packedSelected [1,2,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound19777 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env19778 : List Nat := [2,4,8,16,0,17,9,4,512,31,11,0,8,27,0,2,11,10,31,1,16,1,17,3,9,17,11,11,1,10,31,1,4,1,26,512]

theorem envBound19778 : H12AffineFastState.Bounded env19778 := by
  intro p hp
  have h : env19778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19777_19778 : H12AffineEnvironment.transform 4 0 env19777 = env19778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env19777 == env19778) = true)

theorem identity19778 : scanCanonicalize (H12AffineFastState.compose env19778 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound19778 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19779 : List Nat := [2,4,8,11,0,10,9,4,512,4,11,0,8,0,0,2,11,10,4,1,11,1,10,3,9,10,11,11,1,10,4,1,4,1,1,512]

theorem envBound19779 : H12AffineFastState.Bounded env19779 := by
  intro p hp
  have h : env19779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19778_19779 : H12AffineEnvironment.transform 3 11 env19778 = env19779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env19778 == env19779) = true)

theorem identity19779 : scanCanonicalize (H12AffineFastState.compose env19779 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound19779 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19780 : List Nat := [2,4,6,5,0,4,7,4,512,4,5,0,6,0,0,2,5,4,4,1,5,1,4,3,7,4,5,5,1,4,4,1,4,1,1,512]

theorem envBound19780 : H12AffineFastState.Bounded env19780 := by
  intro p hp
  have h : env19780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19779_19780 : H12AffineEnvironment.transform 2 6 env19779 = env19780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env19779 == env19780) = true)

def env19781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4297,4194304,16,98644,8328,64,4592709,5393,4233,431376,1364,4235613,256,32,46212,74370]

theorem envBound19781 : H12AffineFastState.Bounded env19781 := by
  intro p hp
  have h : env19781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19754_19781 : H12AffineEnvironment.transform 13 5377 env19754 = env19781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19754 == env19781) = true)

theorem identity19781 : scanCanonicalize (H12AffineFastState.compose env19781 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19781 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,4194304,16,41311,8328,64,4592709,5393,4233,431376,1364,4235613,256,32,46212,649]

theorem envBound19782 : H12AffineFastState.Bounded env19782 := by
  intro p hp
  have h : env19782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19781_19782 : H12AffineEnvironment.transform 15 8203 env19781 = env19782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19781 == env19782) = true)

theorem identity19782 : scanCanonicalize (H12AffineFastState.compose env19782 (packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS)) = affineNative (2^(21+1) ^^^ 297221) := by decide +kernel

theorem selectedBound19782 : packedSelected [0,3,4,7,10,14,16,20,21,22,24,26,35] rootPS < 2^1333 := by decide +kernel

def env19783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4297,297221,16,41311,8328,64,171328,5393,4233,431376,1364,272472,256,32,46212,649]

theorem envBound19783 : H12AffineFastState.Bounded env19783 := by
  intro p hp
  have h : env19783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19782_19783 : H12AffineEnvironment.transform 21 297221 env19782 = env19783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 297221 env19782 == env19783) = true)

def env19784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4161,297221,16,41311,8192,64,171328,5393,4097,431376,1364,272472,256,32,46092,513]

theorem envBound19784 : H12AffineFastState.Bounded env19784 := by
  intro p hp
  have h : env19784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19783_19784 : H12AffineEnvironment.transform 6 8 env19783 = env19784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19783 == env19784) = true)

theorem identity19784 : scanCanonicalize (H12AffineFastState.compose env19784 (packedSelected [0,3,7,10,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19784 : packedSelected [0,3,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env19785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,262144,1024,8540,4161,272472,16,2,8192,64,146461,5393,4097,406605,1364,272472,256,32,5457,513]

theorem envBound19785 : H12AffineFastState.Bounded env19785 := by
  intro p hp
  have h : env19785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19784_19785 : H12AffineEnvironment.transform 14 8541 env19784 = env19785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19784 == env19785) = true)

theorem identity19785 : scanCanonicalize (H12AffineFastState.compose env19785 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 146792) := by decide +kernel

theorem selectedBound19785 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19786 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8203,131072,146792,1024,8540,4161,136496,16,2,8192,64,146461,5393,4097,2341,1364,136496,256,32,5457,513]

theorem envBound19786 : H12AffineFastState.Bounded env19786 := by
  intro p hp
  have h : env19786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19785_19786 : H12AffineEnvironment.transform 17 146792 env19785 = env19786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146792 env19785 == env19786) = true)

theorem identity19786 : scanCanonicalize (H12AffineFastState.compose env19786 (packedSelected [1,8,12,15,18,19,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19786 : packedSelected [1,8,12,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env19787 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,131072,146744,1024,8460,4113,136496,16,2,8192,16,146461,5393,4097,2341,1284,136496,256,32,5377,513]

theorem envBound19787 : H12AffineFastState.Bounded env19787 := by
  intro p hp
  have h : env19787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19786_19787 : H12AffineEnvironment.transform 5 16 env19786 = env19787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19786 == env19787) = true)

theorem identity19787 : scanCanonicalize (H12AffineFastState.compose env19787 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound19787 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19788 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,13341,2341,1024,8460,4113,8493,16,2,8192,16,2048,5393,4097,2341,1284,8493,256,32,5377,513]

theorem envBound19788 : H12AffineFastState.Bounded env19788 := by
  intro p hp
  have h : env19788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19787_19788 : H12AffineEnvironment.transform 16 13341 env19787 = env19788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env19787 == env19788) = true)

theorem identity19788 : scanCanonicalize (H12AffineFastState.compose env19788 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19788 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env19789 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,262,5392,2341,1024,1,4113,32,16,2,269,16,2048,5393,4097,2341,1284,32,256,32,5377,513]

theorem envBound19789 : H12AffineFastState.Bounded env19789 := by
  intro p hp
  have h : env19789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19788_19789 : H12AffineEnvironment.transform 12 269 env19788 = env19789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19788 == env19789) = true)

theorem identity19789 : scanCanonicalize (H12AffineFastState.compose env19789 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19789 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19790 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4405,0,262,4388,2341,52,1,4113,32,16,2,269,16,2048,4389,4097,2341,304,32,256,32,4405,513]

theorem envBound19790 : H12AffineFastState.Bounded env19790 := by
  intro p hp
  have h : env19790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19789_19790 : H12AffineEnvironment.transform 9 52 env19789 = env19790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19789 == env19790) = true)

theorem identity19790 : scanCanonicalize (H12AffineFastState.compose env19790 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19790 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19791 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4113,0,34,4096,2049,52,1,4113,32,16,2,41,16,2048,4097,4097,2049,20,32,36,32,4113,513]

theorem envBound19791 : H12AffineFastState.Bounded env19791 := by
  intro p hp
  have h : env19791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19790_19791 : H12AffineEnvironment.transform 7 36 env19790 = env19791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19790 == env19791) = true)

theorem identity19791 : scanCanonicalize (H12AffineFastState.compose env19791 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound19791 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19792 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,4096,41,4113,0,34,4096,2049,52,1,4113,32,16,2,41,16,2048,4097,4097,2049,20,32,36,32,4113,49]

theorem envBound19792 : H12AffineFastState.Bounded env19792 := by
  intro p hp
  have h : env19792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19791_19792 : H12AffineEnvironment.transform 8 48 env19791 = env19792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env19791 == env19792) = true)

theorem identity19792 : scanCanonicalize (H12AffineFastState.compose env19792 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound19792 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19793 : List Nat := [2,4,8,16,17,16,8,21,1,5,2048,4096,24,4113,0,19,4096,2049,5,1,4113,17,16,2,24,16,2048,4097,4097,2049,20,17,21,17,4113,0]

theorem envBound19793 : H12AffineFastState.Bounded env19793 := by
  intro p hp
  have h : env19793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19792_19793 : H12AffineEnvironment.transform 4 17 env19792 = env19793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env19792 == env19793) = true)

def env19794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,262144,1024,32769,4160,297221,16,41311,8193,64,171328,5393,4096,431376,1364,272472,256,32,46093,512]

theorem envBound19794 : H12AffineFastState.Bounded env19794 := by
  intro p hp
  have h : env19794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19783_19794 : H12AffineEnvironment.transform 6 9 env19783 = env19794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19783 == env19794) = true)

theorem identity19794 : scanCanonicalize (H12AffineFastState.compose env19794 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 171280) := by decide +kernel

theorem selectedBound19794 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env19795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,8203,131072,171280,1024,32769,4160,136213,16,41311,8193,64,171328,5393,4096,2048,1364,177480,256,32,46093,512]

theorem envBound19795 : H12AffineFastState.Bounded env19795 := by
  intro p hp
  have h : env19795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19794_19795 : H12AffineEnvironment.transform 17 171280 env19794 = env19795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171280 env19794 == env19795) = true)

theorem identity19795 : scanCanonicalize (H12AffineFastState.compose env19795 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19795 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19796 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,131072,146508,1024,8541,4160,136213,16,3,8193,64,146460,5393,4096,2048,1364,136212,256,32,5457,512]

theorem envBound19796 : H12AffineFastState.Bounded env19796 := by
  intro p hp
  have h : env19796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19795_19796 : H12AffineEnvironment.transform 14 8540 env19795 = env19796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19795 == env19796) = true)

theorem identity19796 : scanCanonicalize (H12AffineFastState.compose env19796 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5141) := by decide +kernel

theorem selectedBound19796 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8540,8203,5141,10329,1024,8541,4160,0,16,3,8193,64,10249,5393,4096,2048,1364,1,256,32,5457,512]

theorem envBound19797 : H12AffineFastState.Bounded env19797 := by
  intro p hp
  have h : env19797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19796_19797 : H12AffineEnvironment.transform 16 5141 env19796 = env19797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5141 env19796 == env19797) = true)

theorem identity19797 : scanCanonicalize (H12AffineFastState.compose env19797 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound19797 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19798 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,1,342,5141,2308,1024,0,4160,0,16,3,348,64,2388,5393,4096,2048,1364,1,256,32,5457,512]

theorem envBound19798 : H12AffineFastState.Bounded env19798 := by
  intro p hp
  have h : env19798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19797_19798 : H12AffineEnvironment.transform 12 349 env19797 = env19798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env19797 == env19798) = true)

def env19799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,17865,4194304,21777,98645,8328,64,4592708,16400,17801,431376,20564,4235613,256,21793,46212,96130]

theorem envBound19799 : H12AffineFastState.Bounded env19799 := by
  intro p hp
  have h : env19799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19753_19799 : H12AffineEnvironment.transform 20 17865 env19753 = env19799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env19753 == env19799) = true)

def env19800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,4194304,17,98645,8328,64,4592708,5392,4233,431376,1364,4235613,256,33,46212,74370]

theorem envBound19800 : H12AffineFastState.Bounded env19800 := by
  intro p hp
  have h : env19800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19799_19800 : H12AffineEnvironment.transform 13 5376 env19799 = env19800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env19799 == env19800) = true)

theorem identity19800 : scanCanonicalize (H12AffineFastState.compose env19800 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound19800 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19801 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4297,98679,17,98645,8328,64,496947,5392,4233,431376,1364,73770,256,33,46212,74370]

theorem envBound19801 : H12AffineFastState.Bounded env19801 := by
  intro p hp
  have h : env19801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19800_19801 : H12AffineEnvironment.transform 21 98679 env19800 = env19801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env19800 == env19801) = true)

def env19802 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4161,98679,17,98645,8192,64,496947,5392,4097,431376,1364,73770,256,33,46092,74250]

theorem envBound19802 : H12AffineFastState.Bounded env19802 := by
  intro p hp
  have h : env19802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19801_19802 : H12AffineEnvironment.transform 6 8 env19801 = env19802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19801 == env19802) = true)

theorem identity19802 : scanCanonicalize (H12AffineFastState.compose env19802 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound19802 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19803 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,67618,1024,32769,4161,98679,17,98645,8192,64,171281,5392,4097,236850,1364,73770,256,33,46092,74250]

theorem envBound19803 : H12AffineFastState.Bounded env19803 := by
  intro p hp
  have h : env19803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19802_19803 : H12AffineEnvironment.transform 17 67618 env19802 = env19803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env19802 == env19803) = true)

theorem identity19803 : scanCanonicalize (H12AffineFastState.compose env19803 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound19803 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env19804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,131072,35189,1024,32769,4161,32,17,2,8192,64,171281,5392,4097,138341,1364,41341,256,33,46092,41821]

theorem envBound19804 : H12AffineFastState.Bounded env19804 := by
  intro p hp
  have h : env19804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19803_19804 : H12AffineEnvironment.transform 15 33111 env19803 = env19804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env19803 == env19804) = true)

theorem identity19804 : scanCanonicalize (H12AffineFastState.compose env19804 (packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 5140) := by decide +kernel

theorem selectedBound19804 : packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env19805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,5140,35189,1024,32769,4161,32,17,2,8192,64,35077,5392,4097,2161,1364,41341,256,33,46092,41821]

theorem envBound19805 : H12AffineFastState.Bounded env19805 := by
  intro p hp
  have h : env19805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19804_19805 : H12AffineEnvironment.transform 16 5140 env19804 = env19805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5140 env19804 == env19805) = true)

theorem identity19805 : scanCanonicalize (H12AffineFastState.compose env19805 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound19805 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env19806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8203,5140,10281,1024,8541,4161,32,17,2,8192,64,10329,5392,4097,2161,1364,33,256,33,5456,513]

theorem envBound19806 : H12AffineFastState.Bounded env19806 := by
  intro p hp
  have h : env19806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19805_19806 : H12AffineEnvironment.transform 14 8540 env19805 = env19806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env19805 == env19806) = true)

theorem identity19806 : scanCanonicalize (H12AffineFastState.compose env19806 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19806 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19807 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,8192,5125,8281,8203,5140,10281,1024,8280,4161,32,17,2,8192,64,10329,5141,4097,2161,1105,33,5,33,5205,513]

theorem envBound19807 : H12AffineFastState.Bounded env19807 := by
  intro p hp
  have h : env19807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19806_19807 : H12AffineEnvironment.transform 7 5 env19806 = env19807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19806 == env19807) = true)

theorem identity19807 : scanCanonicalize (H12AffineFastState.compose env19807 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound19807 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env19808 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,4096,88,5125,1,83,5140,2161,1024,0,4161,32,17,2,88,64,2049,5141,4097,2161,1105,33,5,33,5205,513]

theorem envBound19808 : H12AffineFastState.Bounded env19808 := by
  intro p hp
  have h : env19808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19807_19808 : H12AffineEnvironment.transform 12 88 env19807 = env19808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env19807 == env19808) = true)

theorem identity19808 : scanCanonicalize (H12AffineFastState.compose env19808 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 576) := by decide +kernel

theorem selectedBound19808 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19809 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,576,88,1605,1,83,1620,2161,1024,0,513,32,17,2,88,64,2049,1621,577,2161,1105,33,5,33,1557,513]

theorem envBound19809 : H12AffineFastState.Bounded env19809 := by
  intro p hp
  have h : env19809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19808_19809 : H12AffineEnvironment.transform 11 576 env19808 = env19809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 576 env19808 == env19809) = true)

theorem identity19809 : scanCanonicalize (H12AffineFastState.compose env19809 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound19809 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19810 : List Nat := [2,4,8,16,32,64,8,5,512,1024,1541,576,88,1605,1,83,1620,1652,1024,0,513,32,17,2,88,64,1540,1621,577,1652,1105,33,5,33,1557,513]

theorem envBound19810 : H12AffineFastState.Bounded env19810 := by
  intro p hp
  have h : env19810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19809_19810 : H12AffineEnvironment.transform 10 1541 env19809 = env19810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env19809 == env19810) = true)

def env19811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,4160,98679,17,98645,8193,64,496947,5392,4096,431376,1364,73770,256,33,46093,74251]

theorem envBound19811 : H12AffineFastState.Bounded env19811 := by
  intro p hp
  have h : env19811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19801_19811 : H12AffineEnvironment.transform 6 9 env19801 = env19811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19801 == env19811) = true)

theorem identity19811 : scanCanonicalize (H12AffineFastState.compose env19811 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound19811 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,108927,1024,32769,4160,98679,17,98645,8193,64,146508,5392,4096,212079,1364,73770,256,33,46093,74251]

theorem envBound19812 : H12AffineFastState.Bounded env19812 := by
  intro p hp
  have h : env19812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19811_19812 : H12AffineEnvironment.transform 17 108927 env19811 = env19812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env19811 == env19812) = true)

theorem identity19812 : scanCanonicalize (H12AffineFastState.compose env19812 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19812 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env19813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,131072,35189,1024,32769,4160,41341,17,41311,8193,64,146508,5392,4096,138341,1364,32,256,33,46093,513]

theorem envBound19813 : H12AffineFastState.Bounded env19813 := by
  intro p hp
  have h : env19813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19812_19813 : H12AffineEnvironment.transform 15 8202 env19812 = env19813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19812 == env19813) = true)

theorem identity19813 : scanCanonicalize (H12AffineFastState.compose env19813 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1344) := by decide +kernel

theorem selectedBound19813 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1344,8202,131072,3125,1024,1345,4160,9277,17,9247,8193,64,146508,5392,4096,138341,1364,32,256,33,12621,513]

theorem envBound19814 : H12AffineFastState.Bounded env19814 := by
  intro p hp
  have h : env19814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19813_19814 : H12AffineEnvironment.transform 14 1344 env19813 = env19814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1344 env19813 == env19814) = true)

theorem identity19814 : scanCanonicalize (H12AffineFastState.compose env19814 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19814 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env19815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1344,8202,5392,3125,1024,1345,4160,9277,17,9247,8193,64,10588,5392,4096,2421,1364,32,256,33,12621,513]

theorem envBound19815 : H12AffineFastState.Bounded env19815 := by
  intro p hp
  have h : env19815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19814_19815 : H12AffineEnvironment.transform 16 5392 env19814 = env19815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19814 == env19815) = true)

theorem identity19815 : scanCanonicalize (H12AffineFastState.compose env19815 (packedSelected [3,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 3100) := by decide +kernel

theorem selectedBound19815 : packedSelected [3,8,10,12] rootPS < 2^1333 := by decide +kernel

def env19816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3100,5376,1344,3094,5392,3125,1024,1345,4160,2081,17,2051,3101,64,1344,5392,4096,2421,1364,32,256,33,7505,513]

theorem envBound19816 : H12AffineFastState.Bounded env19816 := by
  intro p hp
  have h : env19816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19815_19816 : H12AffineEnvironment.transform 12 3100 env19815 = env19816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3100 env19815 == env19816) = true)

theorem identity19816 : scanCanonicalize (H12AffineFastState.compose env19816 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound19816 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env19817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,3100,0,1344,3094,16,3125,1024,1345,1344,2081,17,2051,3101,64,1344,16,1280,2421,1364,32,256,33,2129,513]

theorem envBound19817 : H12AffineFastState.Bounded env19817 := by
  intro p hp
  have h : env19817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19816_19817 : H12AffineEnvironment.transform 11 1280 env19816 = env19817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env19816 == env19817) = true)

theorem identity19817 : scanCanonicalize (H12AffineFastState.compose env19817 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19817 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env19818 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1140,3100,0,1076,3094,16,3125,1024,1077,1076,2081,17,2051,3101,64,1076,16,1140,2049,1056,32,116,33,2129,513]

theorem envBound19818 : H12AffineFastState.Bounded env19818 := by
  intro p hp
  have h : env19818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19817_19818 : H12AffineEnvironment.transform 7 116 env19817 = env19818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19817 == env19818) = true)

theorem identity19818 : scanCanonicalize (H12AffineFastState.compose env19818 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19818 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env19819 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,1060,3100,0,1076,3094,16,3125,1024,1077,1076,2081,17,2051,3101,16,1076,16,1060,2049,1056,32,36,33,2049,513]

theorem envBound19819 : H12AffineFastState.Bounded env19819 := by
  intro p hp
  have h : env19819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19818_19819 : H12AffineEnvironment.transform 5 16 env19818 = env19819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19818 == env19819) = true)

theorem identity19819 : scanCanonicalize (H12AffineFastState.compose env19819 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound19819 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env19820 : List Nat := [2,4,8,16,32,16,9,36,512,1024,1076,1060,40,0,1076,34,16,1,1024,1077,1076,1045,17,1079,41,16,1076,16,1060,1077,1056,32,36,33,1077,513]

theorem envBound19820 : H12AffineFastState.Bounded env19820 := by
  intro p hp
  have h : env19820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19819_19820 : H12AffineEnvironment.transform 10 1076 env19819 = env19820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env19819 == env19820) = true)

theorem identity19820 : scanCanonicalize (H12AffineFastState.compose env19820 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19820 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19821 : List Nat := [2,4,8,16,32,16,9,36,512,52,0,16,40,0,0,34,16,1,52,1,0,33,17,3,41,16,0,16,16,1,20,32,36,33,1,513]

theorem envBound19821 : H12AffineFastState.Bounded env19821 := by
  intro p hp
  have h : env19821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19820_19821 : H12AffineEnvironment.transform 9 52 env19820 = env19821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19820 == env19821) = true)

theorem identity19821 : scanCanonicalize (H12AffineFastState.compose env19821 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19821 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19822 : List Nat := [2,4,8,0,32,0,9,36,512,36,0,0,40,0,0,34,0,1,36,1,0,33,1,3,41,0,0,0,0,1,4,32,36,33,1,513]

theorem envBound19822 : H12AffineFastState.Bounded env19822 := by
  intro p hp
  have h : env19822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19821_19822 : H12AffineEnvironment.transform 3 0 env19821 = env19822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19821 == env19822) = true)

theorem identity19822 : scanCanonicalize (H12AffineFastState.compose env19822 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound19822 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19823 : List Nat := [2,4,8,0,11,0,9,15,512,15,0,0,3,0,0,9,0,1,15,1,0,10,1,3,2,0,0,0,0,1,4,11,15,10,1,513]

theorem envBound19823 : H12AffineFastState.Bounded env19823 := by
  intro p hp
  have h : env19823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19822_19823 : H12AffineEnvironment.transform 4 11 env19822 = env19823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env19822 == env19823) = true)

def env19824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,4296,4194304,16,98645,8328,64,4592708,5393,4232,431376,1365,4235613,256,32,46212,74371]

theorem envBound19824 : H12AffineFastState.Bounded env19824 := by
  intro p hp
  have h : env19824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19799_19824 : H12AffineEnvironment.transform 13 5377 env19799 = env19824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env19799 == env19824) = true)

theorem identity19824 : scanCanonicalize (H12AffineFastState.compose env19824 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound19824 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,33247,131072,262144,1024,32769,4296,4194304,16,138,8328,64,4592708,5393,4232,431376,1365,4235613,256,32,46212,41820]

theorem envBound19825 : H12AffineFastState.Bounded env19825 := by
  intro p hp
  have h : env19825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19824_19825 : H12AffineEnvironment.transform 15 33247 env19824 = env19825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env19824 == env19825) = true)

def env19826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4160,4194304,16,2,8192,64,4592708,5393,4096,431376,1365,4235613,256,32,46092,41820]

theorem envBound19826 : H12AffineFastState.Bounded env19826 := by
  intro p hp
  have h : env19826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19825_19826 : H12AffineEnvironment.transform 6 8 env19825 = env19826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19825 == env19826) = true)

theorem identity19826 : scanCanonicalize (H12AffineFastState.compose env19826 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19826 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4160,4194304,16,2,8192,64,4592708,5393,4096,406605,1365,4194304,256,32,5457,513]

theorem envBound19827 : H12AffineFastState.Bounded env19827 := by
  intro p hp
  have h : env19827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19826_19827 : H12AffineEnvironment.transform 14 8541 env19826 = env19827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19826 == env19827) = true)

theorem identity19827 : scanCanonicalize (H12AffineFastState.compose env19827 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound19827 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19828 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,262144,1024,8540,4160,32,16,2,8192,64,398436,5393,4096,406605,1365,32,256,32,5457,513]

theorem envBound19828 : H12AffineFastState.Bounded env19828 := by
  intro p hp
  have h : env19828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19827_19828 : H12AffineEnvironment.transform 21 32 env19827 = env19828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env19827 == env19828) = true)

theorem identity19828 : scanCanonicalize (H12AffineFastState.compose env19828 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound19828 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env19829 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,131072,138341,1024,8540,4160,32,16,2,8192,64,2049,5393,4096,10280,1365,32,256,32,5457,513]

theorem envBound19829 : H12AffineFastState.Bounded env19829 := by
  intro p hp
  have h : env19829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19828_19829 : H12AffineEnvironment.transform 17 138341 env19828 = env19829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env19828 == env19829) = true)

theorem identity19829 : scanCanonicalize (H12AffineFastState.compose env19829 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound19829 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env19830 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,8202,5392,2421,1024,8540,4160,32,16,2,8192,64,2049,5393,4096,10280,1365,32,256,32,5457,513]

theorem envBound19830 : H12AffineFastState.Bounded env19830 := by
  intro p hp
  have h : env19830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19829_19830 : H12AffineEnvironment.transform 16 5392 env19829 = env19830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env19829 == env19830) = true)

theorem identity19830 : scanCanonicalize (H12AffineFastState.compose env19830 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound19830 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env19831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5377,1296,1095,5392,2421,1024,1297,4160,32,16,2,1101,64,2049,5393,4096,3173,1365,32,256,32,5457,513]

theorem envBound19831 : H12AffineFastState.Bounded env19831 := by
  intro p hp
  have h : env19831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19830_19831 : H12AffineEnvironment.transform 12 1101 env19830 = env19831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env19830 == env19831) = true)

theorem identity19831 : scanCanonicalize (H12AffineFastState.compose env19831 (packedSelected [5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound19831 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env19832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1818,4096,1101,5377,1296,1095,5392,1647,1024,1297,4160,32,16,2,1101,64,1819,5393,4096,895,1365,32,256,32,5457,513]

theorem envBound19832 : H12AffineFastState.Bounded env19832 := by
  intro p hp
  have h : env19832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19831_19832 : H12AffineEnvironment.transform 10 1818 env19831 = env19832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env19831 == env19832) = true)

def env19833 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,131072,262144,1024,32769,4161,4194304,16,3,8193,64,4592708,5393,4097,431376,1365,4235613,256,32,46093,41820]

theorem envBound19833 : H12AffineFastState.Bounded env19833 := by
  intro p hp
  have h : env19833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19825_19833 : H12AffineEnvironment.transform 6 9 env19825 = env19833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19825 == env19833) = true)

theorem identity19833 : scanCanonicalize (H12AffineFastState.compose env19833 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound19833 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env19834 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33110,46157,262144,1024,32769,4161,4194304,16,3,8193,64,4497417,5393,4097,270685,1365,4235613,256,32,46093,41820]

theorem envBound19834 : H12AffineFastState.Bounded env19834 := by
  intro p hp
  have h : env19834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19833_19834 : H12AffineEnvironment.transform 16 46157 env19833 = env19834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env19833 == env19834) = true)

theorem identity19834 : scanCanonicalize (H12AffineFastState.compose env19834 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound19834 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env19835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5392,262144,1024,8540,4161,4194304,16,3,8193,64,4456788,5393,4097,270685,1365,4194304,256,32,5456,513]

theorem envBound19835 : H12AffineFastState.Bounded env19835 := by
  intro p hp
  have h : env19835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19834_19835 : H12AffineEnvironment.transform 14 8541 env19834 = env19835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env19834 == env19835) = true)

theorem identity19835 : scanCanonicalize (H12AffineFastState.compose env19835 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10361) := by decide +kernel

theorem selectedBound19835 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8203,5392,10361,1024,8540,4161,4194304,16,3,8193,64,4204845,5393,4097,2340,1365,4194304,256,32,5456,513]

theorem envBound19836 : H12AffineFastState.Bounded env19836 := by
  intro p hp
  have h : env19836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19835_19836 : H12AffineEnvironment.transform 17 10361 env19835 = env19836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10361 env19835 == env19836) = true)

theorem identity19836 : scanCanonicalize (H12AffineFastState.compose env19836 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19836 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env19837 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,4405,8541,8203,4388,10361,52,8540,4161,4194304,16,3,8193,64,4204845,4389,4097,2340,353,4194304,256,32,4452,513]

theorem envBound19837 : H12AffineFastState.Bounded env19837 := by
  intro p hp
  have h : env19837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19836_19837 : H12AffineEnvironment.transform 9 52 env19836 = env19837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19836 == env19837) = true)

theorem identity19837 : scanCanonicalize (H12AffineFastState.compose env19837 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 341) := by decide +kernel

theorem selectedBound19837 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env19838 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,8192,4405,8541,8203,4388,10361,52,8540,4161,341,16,3,8193,64,10360,4389,4097,2340,353,341,256,32,4452,513]

theorem envBound19838 : H12AffineFastState.Bounded env19838 := by
  intro p hp
  have h : env19838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19837_19838 : H12AffineEnvironment.transform 21 341 env19837 = env19838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 341 env19837 == env19838) = true)

theorem identity19838 : scanCanonicalize (H12AffineFastState.compose env19838 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19838 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env19839 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,348,4405,1,343,4388,2341,52,0,4161,341,16,3,349,64,2340,4389,4097,2340,353,341,256,32,4452,513]

theorem envBound19839 : H12AffineFastState.Bounded env19839 := by
  intro p hp
  have h : env19839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19838_19839 : H12AffineEnvironment.transform 12 348 env19838 = env19839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19838 == env19839) = true)

theorem identity19839 : scanCanonicalize (H12AffineFastState.compose env19839 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19839 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env19840 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,269,4405,1,262,4388,2341,52,0,4112,260,16,3,268,17,2340,4389,4097,2340,304,260,256,32,4405,513]

theorem envBound19840 : H12AffineFastState.Bounded env19840 := by
  intro p hp
  have h : env19840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19839_19840 : H12AffineEnvironment.transform 5 17 env19839 = env19840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19839 == env19840) = true)

theorem identity19840 : scanCanonicalize (H12AffineFastState.compose env19840 (packedSelected [1,2,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound19840 : packedSelected [1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env19841 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,0,269,309,1,262,292,2341,52,0,16,260,16,3,268,17,2340,293,1,2340,304,260,256,32,309,513]

theorem envBound19841 : H12AffineFastState.Bounded env19841 := by
  intro p hp
  have h : env19841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19840_19841 : H12AffineEnvironment.transform 11 0 env19840 = env19841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env19840 == env19841) = true)

theorem identity19841 : scanCanonicalize (H12AffineFastState.compose env19841 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound19841 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env19842 : List Nat := [2,4,8,1,32,0,9,256,512,37,2048,0,269,292,1,262,292,2341,37,0,1,260,1,3,268,0,2340,293,1,2340,289,260,256,32,292,513]

theorem envBound19842 : H12AffineFastState.Bounded env19842 := by
  intro p hp
  have h : env19842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19841_19842 : H12AffineEnvironment.transform 3 1 env19841 = env19842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env19841 == env19842) = true)

theorem identity19842 : scanCanonicalize (H12AffineFastState.compose env19842 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound19842 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19843 : List Nat := [2,4,8,1,32,0,9,37,512,37,2048,0,40,1,1,35,1,2048,37,0,1,33,1,3,41,0,2049,0,1,2049,4,33,37,32,1,513]

theorem envBound19843 : H12AffineFastState.Bounded env19843 := by
  intro p hp
  have h : env19843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19842_19843 : H12AffineEnvironment.transform 7 37 env19842 = env19843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env19842 == env19843) = true)

def env19844 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160257,257,27378861,27337993,25207751]

theorem envBound19844 : H12AffineFastState.Bounded env19844 := by
  intro p hp
  have h : env19844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19671_19844 : H12AffineEnvironment.transform 18 1025 env19671 = env19844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env19671 == env19844) = true)

theorem identity19844 : scanCanonicalize (H12AffineFastState.compose env19844 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2237469) := by decide +kernel

theorem selectedBound19844 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env19845 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237469,16777216,8328,64,23454748,18973837,160076,2417693,19111949,23160257,257,17031344,16974100,19040218]

theorem envBound19845 : H12AffineFastState.Bounded env19845 := by
  intro p hp
  have h : env19845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19844_19845 : H12AffineEnvironment.transform 22 2237469 env19844 = env19845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2237469 env19844 == env19845) = true)

def env19846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237469,243088,8328,64,6705548,2240797,160076,2417693,2102685,6475857,257,21792,46212,2175562]

theorem envBound19846 : H12AffineFastState.Bounded env19846 := by
  intro p hp
  have h : env19846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19845_19846 : H12AffineEnvironment.transform 23 243088 env19845 = env19846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env19845 == env19846) = true)

def env19847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237469,243088,8328,64,2144660,2240797,160076,2417693,2102685,2373705,257,21792,46212,2175562]

theorem envBound19847 : H12AffineFastState.Bounded env19847 := by
  intro p hp
  have h : env19847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19846_19847 : H12AffineEnvironment.transform 21 452632 env19846 = env19847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env19846 == env19847) = true)

def env19848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144477,243088,8328,64,43476,139613,160076,324701,1501,272393,257,21792,46212,74250]

theorem envBound19848 : H12AffineFastState.Bounded env19848 := by
  intro p hp
  have h : env19848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19847_19848 : H12AffineEnvironment.transform 20 4160 env19847 = env19848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19847 == env19848) = true)

theorem identity19848 : scanCanonicalize (H12AffineFastState.compose env19848 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound19848 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318548,17,98780,8328,64,43476,5393,17664,324701,1501,272393,257,21792,46212,74250]

theorem envBound19849 : H12AffineFastState.Bounded env19849 := by
  intro p hp
  have h : env19849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19848_19849 : H12AffineEnvironment.transform 16 13388 env19848 = env19849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env19848 == env19849) = true)

def env19850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318548,17,98644,8192,64,43356,5393,17664,324701,1365,272393,257,21792,46092,74250]

theorem envBound19850 : H12AffineFastState.Bounded env19850 := by
  intro p hp
  have h : env19850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19849_19850 : H12AffineEnvironment.transform 6 8 env19849 = env19850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19849 == env19850) = true)

theorem identity19850 : scanCanonicalize (H12AffineFastState.compose env19850 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108927) := by decide +kernel

theorem selectedBound19850 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,108927,1025,32769,4160,95531,17,98644,8192,64,43356,5393,17664,89378,1365,98678,257,21792,46092,74250]

theorem envBound19851 : H12AffineFastState.Bounded env19851 := by
  intro p hp
  have h : env19851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19850_19851 : H12AffineEnvironment.transform 17 108927 env19850 = env19851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108927 env19850 == env19851) = true)

theorem identity19851 : scanCanonicalize (H12AffineFastState.compose env19851 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19851 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env19852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5456,32768,65536,13388,108927,1025,32769,4160,73851,17,98644,8192,64,43356,5393,4176,67698,1365,98678,257,112,46092,74250]

theorem envBound19852 : H12AffineFastState.Bounded env19852 := by
  intro p hp
  have h : env19852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19851_19852 : H12AffineEnvironment.transform 13 5456 env19851 = env19852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19851 == env19852) = true)

theorem identity19852 : scanCanonicalize (H12AffineFastState.compose env19852 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound19852 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env19853 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,5236,32768,65536,13388,108635,1025,32769,4160,73851,17,98416,8192,64,43128,5173,4176,67698,1137,98386,37,112,46092,74250]

theorem envBound19853 : H12AffineFastState.Bounded env19853 := by
  intro p hp
  have h : env19853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19852_19853 : H12AffineEnvironment.transform 7 36 env19852 = env19853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env19852 == env19853) = true)

def env19854 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4160,318548,17,98645,8193,64,43357,5393,17664,324701,1364,272393,257,21792,46093,74250]

theorem envBound19854 : H12AffineFastState.Bounded env19854 := by
  intro p hp
  have h : env19854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19849_19854 : H12AffineEnvironment.transform 6 9 env19849 = env19854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env19849 == env19854) = true)

theorem identity19854 : scanCanonicalize (H12AffineFastState.compose env19854 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound19854 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67618,1025,32769,4160,119926,17,98645,8193,64,43357,5393,17664,130175,1364,73771,257,21792,46093,74250]

theorem envBound19855 : H12AffineFastState.Bounded env19855 := by
  intro p hp
  have h : env19855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19854_19855 : H12AffineEnvironment.transform 17 67618 env19854 = env19855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env19854 == env19855) = true)

theorem identity19855 : scanCanonicalize (H12AffineFastState.compose env19855 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound19855 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env19856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,13388,23668,1025,32769,4160,32800,17,54531,8193,64,43357,5393,17664,43049,1364,29821,257,21792,46093,30300]

theorem envBound19856 : H12AffineFastState.Bounded env19856 := by
  intro p hp
  have h : env19856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19855_19856 : H12AffineEnvironment.transform 15 21590 env19855 = env19856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env19855 == env19856) = true)

theorem identity19856 : scanCanonicalize (H12AffineFastState.compose env19856 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound19856 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env19857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21590,5392,23668,1025,32769,4160,32800,17,54531,349,64,34817,5393,17664,35189,1364,21793,257,21792,38225,22272]

theorem envBound19857 : H12AffineFastState.Bounded env19857 := by
  intro p hp
  have h : env19857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19856_19857 : H12AffineEnvironment.transform 12 348 env19856 = env19857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env19856 == env19857) = true)

theorem identity19857 : scanCanonicalize (H12AffineFastState.compose env19857 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19857 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,262,5392,2340,1025,32769,4160,32800,17,32851,349,64,34817,5393,4176,35189,1364,113,257,112,38225,592]

theorem envBound19858 : H12AffineFastState.Bounded env19858 := by
  intro p hp
  have h : env19858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19857_19858 : H12AffineEnvironment.transform 13 5456 env19857 = env19858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19857 == env19858) = true)

theorem identity19858 : scanCanonicalize (H12AffineFastState.compose env19858 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19858 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env19859 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,32768,262,5392,2340,1025,32769,4112,32800,17,32771,269,16,34817,5393,4096,35109,1284,33,257,32,38145,512]

theorem envBound19859 : H12AffineFastState.Bounded env19859 := by
  intro p hp
  have h : env19859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19858_19859 : H12AffineEnvironment.transform 5 16 env19858 = env19859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19858 == env19859) = true)

theorem identity19859 : scanCanonicalize (H12AffineFastState.compose env19859 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound19859 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19860 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,33,262,5392,2340,1025,32,4112,1,17,34,269,16,2080,5393,4096,2308,1284,33,257,32,5408,512]

theorem envBound19860 : H12AffineFastState.Bounded env19860 := by
  intro p hp
  have h : env19860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19859_19860 : H12AffineEnvironment.transform 14 33 env19859 = env19860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env19859 == env19860) = true)

theorem identity19860 : scanCanonicalize (H12AffineFastState.compose env19860 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19860 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19861 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5124,33,2,5140,2080,1025,32,4112,1,17,34,9,16,2080,5141,4096,2048,1024,33,5,32,5156,512]

theorem envBound19861 : H12AffineFastState.Bounded env19861 := by
  intro p hp
  have h : env19861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19860_19861 : H12AffineEnvironment.transform 7 4 env19860 = env19861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19860 == env19861) = true)

theorem identity19861 : scanCanonicalize (H12AffineFastState.compose env19861 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound19861 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env19862 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1566,4096,8,5124,33,2,5140,1598,1025,32,4112,1,17,34,9,16,1598,5141,4096,1566,1024,33,5,32,5156,512]

theorem envBound19862 : H12AffineFastState.Bounded env19862 := by
  intro p hp
  have h : env19862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19861_19862 : H12AffineEnvironment.transform 10 1566 env19861 = env19862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env19861 == env19862) = true)

def env19863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144476,243088,8328,64,43477,139612,160076,324700,1500,272392,257,21792,46212,74251]

theorem envBound19863 : H12AffineFastState.Bounded env19863 := by
  intro p hp
  have h : env19863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19847_19863 : H12AffineEnvironment.transform 20 4161 env19847 = env19863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19847 == env19863) = true)

theorem identity19863 : scanCanonicalize (H12AffineFastState.compose env19863 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound19863 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,4161,400589,144476,213317,8328,64,23808,139612,160076,262281,1500,272392,257,21792,16465,74251]

theorem envBound19864 : H12AffineFastState.Bounded env19864 := by
  intro p hp
  have h : env19864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19863_19864 : H12AffineEnvironment.transform 14 29909 env19863 = env19864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env19863 == env19864) = true)

def env19865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32240,1025,29908,4161,155965,144476,213317,8328,64,23808,139612,160076,32121,1500,22008,257,21792,16465,74251]

theorem envBound19865 : H12AffineFastState.Bounded env19865 := by
  intro p hp
  have h : env19865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19864_19865 : H12AffineEnvironment.transform 17 32240 env19864 = env19865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env19864 == env19865) = true)

theorem identity19865 : scanCanonicalize (H12AffineFastState.compose env19865 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79298) := by decide +kernel

theorem selectedBound19865 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79298,32240,1025,29908,4161,87295,65950,29831,8328,64,23808,70814,83086,32121,1500,22008,257,21792,16465,74251]

theorem envBound19866 : H12AffineFastState.Bounded env19866 := by
  intro p hp
  have h : env19866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19865_19866 : H12AffineEnvironment.transform 16 79298 env19865 = env19866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79298 env19865 == env19866) = true)

def env19867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32241,1025,29908,4161,155964,144476,213317,8328,64,23808,139612,160076,32120,1500,22009,257,21792,16465,74251]

theorem envBound19867 : H12AffineFastState.Bounded env19867 := by
  intro p hp
  have h : env19867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19864_19867 : H12AffineEnvironment.transform 17 32241 env19864 = env19867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env19864 == env19867) = true)

theorem identity19867 : scanCanonicalize (H12AffineFastState.compose env19867 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79179) := by decide +kernel

theorem selectedBound19867 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,79179,32241,1025,29908,4161,87159,65815,29710,8328,64,23808,70679,82951,32120,1500,22009,257,21792,16465,74251]

theorem envBound19868 : H12AffineFastState.Bounded env19868 := by
  intro p hp
  have h : env19868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19867_19868 : H12AffineEnvironment.transform 16 79179 env19867 = env19868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79179 env19867 == env19868) = true)

theorem identity19868 : scanCanonicalize (H12AffineFastState.compose env19868 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound19868 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env19869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30083,16584,32241,1025,29908,4161,8692,29844,29710,8328,64,23808,24980,12676,32120,1500,22009,257,21792,16465,22408]

theorem envBound19869 : H12AffineFastState.Bounded env19869 := by
  intro p hp
  have h : env19869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19868_19869 : H12AffineEnvironment.transform 15 30083 env19868 = env19869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env19868 == env19869) = true)

theorem identity19869 : scanCanonicalize (H12AffineFastState.compose env19869 (packedSelected [4,9,10,11,12,15,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound19869 : packedSelected [4,9,10,11,12,15,18,19] rootPS < 2^1333 := by decide +kernel

def env19870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,21590,16584,23588,1025,21761,4161,33,21825,21979,349,64,23808,16449,4177,23725,1500,22009,257,21792,16465,22408]

theorem envBound19870 : H12AffineFastState.Bounded env19870 := by
  intro p hp
  have h : env19870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19869_19870 : H12AffineEnvironment.transform 12 469 env19869 = env19870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env19869 == env19870) = true)

theorem identity19870 : scanCanonicalize (H12AffineFastState.compose env19870 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound19870 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env19871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5513,137,479,5441,2477,1025,136,4161,33,200,82,349,64,2185,5576,4177,2340,1500,112,257,169,5592,513]

theorem envBound19871 : H12AffineFastState.Bounded env19871 := by
  intro p hp
  have h : env19871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19870_19871 : H12AffineEnvironment.transform 13 5513 env19870 = env19871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env19870 == env19871) = true)

theorem identity19871 : scanCanonicalize (H12AffineFastState.compose env19871 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound19871 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env19872 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,80,262,5441,2420,1025,81,4161,33,17,82,349,64,2128,5393,4177,2340,1285,112,257,112,5377,513]

theorem envBound19872 : H12AffineFastState.Bounded env19872 := by
  intro p hp
  have h : env19872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19871_19872 : H12AffineEnvironment.transform 6 89 env19871 = env19872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env19871 == env19872) = true)

theorem identity19872 : scanCanonicalize (H12AffineFastState.compose env19872 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 772) := by decide +kernel

theorem selectedBound19872 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env19873 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,772,268,1620,80,262,1605,2420,1025,81,837,33,17,82,349,64,2128,1557,853,2340,1285,112,257,112,1541,513]

theorem envBound19873 : H12AffineFastState.Bounded env19873 := by
  intro p hp
  have h : env19873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19872_19873 : H12AffineEnvironment.transform 11 772 env19872 = env19873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 772 env19872 == env19873) = true)

theorem identity19873 : scanCanonicalize (H12AffineFastState.compose env19873 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound19873 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env19874 : List Nat := [2,4,8,16,32,64,89,256,512,1024,814,772,268,1620,80,262,1605,602,1025,81,837,33,17,82,349,64,894,1557,853,522,1285,112,257,112,1541,513]

theorem envBound19874 : H12AffineFastState.Bounded env19874 := by
  intro p hp
  have h : env19874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19873_19874 : H12AffineEnvironment.transform 10 814 env19873 = env19874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env19873 == env19874) = true)

theorem identity19874 : scanCanonicalize (H12AffineFastState.compose env19874 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound19874 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env19875 : List Nat := [2,4,8,16,32,64,89,256,512,305,814,772,268,869,80,262,884,602,304,81,837,33,17,82,349,64,894,804,853,522,52,112,257,112,820,513]

theorem envBound19875 : H12AffineFastState.Bounded env19875 := by
  intro p hp
  have h : env19875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19874_19875 : H12AffineEnvironment.transform 9 305 env19874 = env19875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env19874 == env19875) = true)

theorem identity19875 : scanCanonicalize (H12AffineFastState.compose env19875 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound19875 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env19876 : List Nat := [2,4,8,16,32,64,89,4,512,53,554,512,8,609,80,2,624,602,52,81,577,33,17,82,89,64,634,544,593,522,52,112,5,112,560,513]

theorem envBound19876 : H12AffineFastState.Bounded env19876 := by
  intro p hp
  have h : env19876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19875_19876 : H12AffineEnvironment.transform 7 4 env19875 = env19876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env19875 == env19876) = true)

theorem identity19876 : scanCanonicalize (H12AffineFastState.compose env19876 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 22) := by decide +kernel

theorem selectedBound19876 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env19877 : List Nat := [2,4,8,16,22,64,89,4,512,3,540,512,8,599,80,2,582,602,2,81,577,23,17,82,89,64,588,534,593,522,2,70,5,70,518,513]

theorem envBound19877 : H12AffineFastState.Bounded env19877 := by
  intro p hp
  have h : env19877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19876_19877 : H12AffineEnvironment.transform 4 22 env19876 = env19877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 22 env19876 == env19877) = true)

def env19878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452633,2237469,243088,8328,64,2144661,2240797,160076,2417693,2102685,2373704,257,21792,46212,2175562]

theorem envBound19878 : H12AffineFastState.Bounded env19878 := by
  intro p hp
  have h : env19878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19846_19878 : H12AffineEnvironment.transform 21 452633 env19846 = env19878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452633 env19846 == env19878) = true)

def env19879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452633,144477,243088,8328,64,43477,139613,160076,324701,1501,272392,257,21792,46212,74250]

theorem envBound19879 : H12AffineFastState.Bounded env19879 := by
  intro p hp
  have h : env19879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19878_19879 : H12AffineEnvironment.transform 20 4160 env19878 = env19879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19878 == env19879) = true)

def env19880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,180273,144477,243088,8328,64,43477,139613,160076,56437,1501,32,257,21792,46212,74250]

theorem envBound19880 : H12AffineFastState.Bounded env19880 := by
  intro p hp
  have h : env19880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19879_19880 : H12AffineEnvironment.transform 17 10280 env19879 = env19880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env19879 == env19880) = true)

def env19881 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1025,32769,4160,21793,41293,73856,8328,64,43477,46157,58460,56437,1501,32,257,21792,46212,74250]

theorem envBound19881 : H12AffineFastState.Bounded env19881 := by
  intro p hp
  have h : env19881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19880_19881 : H12AffineEnvironment.transform 16 38160 env19880 = env19881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env19880 == env19881) = true)

theorem identity19881 : scanCanonicalize (H12AffineFastState.compose env19881 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound19881 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,38160,10280,1025,32769,4160,21793,41293,41311,8328,64,43477,46157,58460,56437,1501,32,257,21792,46212,41941]

theorem envBound19882 : H12AffineFastState.Bounded env19882 := by
  intro p hp
  have h : env19882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19881_19882 : H12AffineEnvironment.transform 15 33247 env19881 = env19882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env19881 == env19882) = true)

theorem identity19882 : scanCanonicalize (H12AffineFastState.compose env19882 (packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound19882 : packedSelected [0,3,4,5,7,8,16,20,22,28] rootPS < 2^1333 := by decide +kernel

def env19883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,8402,13341,10280,1025,8460,4160,21793,64,82,8328,64,2264,5440,17745,32120,1501,32,257,21792,5513,728]

theorem envBound19883 : H12AffineFastState.Bounded env19883 := by
  intro p hp
  have h : env19883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19882_19883 : H12AffineEnvironment.transform 14 8461 env19882 = env19883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env19882 == env19883) = true)

theorem identity19883 : scanCanonicalize (H12AffineFastState.compose env19883 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound19883 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13728,8461,8402,13341,10280,1025,8460,4160,8321,64,82,8328,64,2264,5440,12529,2264,1501,32,257,8320,5513,728]

theorem envBound19884 : H12AffineFastState.Bounded env19884 := by
  intro p hp
  have h : env19884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19883_19884 : H12AffineEnvironment.transform 13 13728 env19883 = env19884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env19883 == env19884) = true)

theorem identity19884 : scanCanonicalize (H12AffineFastState.compose env19884 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19884 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env19885 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,13525,8312,8402,13341,10280,1025,8313,4160,8321,64,82,8328,64,2264,5173,12529,2264,1192,32,116,8320,5372,728]

theorem envBound19885 : H12AffineFastState.Bounded env19885 := by
  intro p hp
  have h : env19885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19884_19885 : H12AffineEnvironment.transform 7 117 env19884 = env19885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19884 == env19885) = true)

theorem identity19885 : scanCanonicalize (H12AffineFastState.compose env19885 (packedSelected [12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1173) := by decide +kernel

theorem selectedBound19885 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env19886 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,1173,4160,1261,1095,4232,3261,1025,1260,4160,1044,64,82,1053,64,2264,5173,5220,2264,1192,32,116,1045,5372,728]

theorem envBound19886 : H12AffineFastState.Bounded env19886 := by
  intro p hp
  have h : env19886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19885_19886 : H12AffineEnvironment.transform 12 1173 env19885 = env19886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1173 env19885 == env19886) = true)

theorem identity19886 : scanCanonicalize (H12AffineFastState.compose env19886 (packedSelected [1,8,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19886 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env19887 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,4096,1173,4113,1212,1046,4232,3261,1025,1213,4113,1044,17,3,1053,17,2185,5173,5173,2185,1192,32,37,1045,5293,649]

theorem envBound19887 : H12AffineFastState.Bounded env19887 := by
  intro p hp
  have h : env19887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19886_19887 : H12AffineEnvironment.transform 5 17 env19886 = env19887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19886 == env19887) = true)

theorem identity19887 : scanCanonicalize (H12AffineFastState.compose env19887 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound19887 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19888 : List Nat := [2,4,8,16,32,17,128,36,512,1024,2048,2064,1173,2049,1212,1046,2200,3261,1025,1213,2049,1044,17,3,1053,17,2185,3109,3109,2185,1192,32,37,1045,3261,649]

theorem envBound19888 : H12AffineFastState.Bounded env19888 := by
  intro p hp
  have h : env19888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19887_19888 : H12AffineEnvironment.transform 11 2064 env19887 = env19888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env19887 == env19888) = true)

theorem identity19888 : scanCanonicalize (H12AffineFastState.compose env19888 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19888 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env19889 : List Nat := [2,4,8,16,32,17,128,36,512,52,2048,2064,161,2049,136,34,2200,2185,53,137,2049,32,17,3,41,17,2185,2065,2065,2185,156,32,37,33,2185,649]

theorem envBound19889 : H12AffineFastState.Bounded env19889 := by
  intro p hp
  have h : env19889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19888_19889 : H12AffineEnvironment.transform 9 52 env19888 = env19889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19888 == env19889) = true)

theorem identity19889 : scanCanonicalize (H12AffineFastState.compose env19889 (packedSelected [2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound19889 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env19890 : List Nat := [2,4,8,16,32,17,128,36,512,52,136,152,161,137,136,34,16,1,53,137,137,32,17,3,41,17,1,153,153,1,156,32,37,33,1,649]

theorem envBound19890 : H12AffineFastState.Bounded env19890 := by
  intro p hp
  have h : env19890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19889_19890 : H12AffineEnvironment.transform 10 136 env19889 = env19890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env19889 == env19890) = true)

theorem identity19890 : scanCanonicalize (H12AffineFastState.compose env19890 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19890 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env19891 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,16,41,1,0,34,16,1,53,1,1,32,17,3,41,17,1,17,17,1,20,32,37,33,1,513]

theorem envBound19891 : H12AffineFastState.Bounded env19891 := by
  intro p hp
  have h : env19891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19890_19891 : H12AffineEnvironment.transform 6 8 env19890 = env19891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19890 == env19891) = true)

theorem identity19891 : scanCanonicalize (H12AffineFastState.compose env19891 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound19891 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19892 : List Nat := [2,4,8,16,16,17,8,20,512,4,0,16,25,1,0,18,16,1,5,1,1,16,17,3,25,17,1,17,17,1,20,16,21,17,1,513]

theorem envBound19892 : H12AffineFastState.Bounded env19892 := by
  intro p hp
  have h : env19892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19891_19892 : H12AffineEnvironment.transform 4 16 env19891 = env19892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env19891 == env19892) = true)

def env19893 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4160,21792,41292,73857,8328,64,43477,46156,58461,56437,1501,32,257,21792,46212,74250]

theorem envBound19893 : H12AffineFastState.Bounded env19893 := by
  intro p hp
  have h : env19893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19880_19893 : H12AffineEnvironment.transform 16 38161 env19880 = env19893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env19880 == env19893) = true)

theorem identity19893 : scanCanonicalize (H12AffineFastState.compose env19893 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound19893 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,38161,10280,1025,32769,4160,21792,41292,41430,8328,64,43477,46156,58461,56437,1501,32,257,21792,46212,41821]

theorem envBound19894 : H12AffineFastState.Bounded env19894 := by
  intro p hp
  have h : env19894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19893_19894 : H12AffineEnvironment.transform 15 33111 env19893 = env19894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env19893 == env19894) = true)

theorem identity19894 : scanCanonicalize (H12AffineFastState.compose env19894 (packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound19894 : packedSelected [0,2,3,4,6,9,10,11,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19895 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,32768,32939,38125,10280,1025,32769,4160,21724,41136,41002,8328,64,43049,46156,58461,56437,1057,32,253,21724,46212,41633]

theorem envBound19895 : H12AffineFastState.Bounded env19895 := by
  intro p hp
  have h : env19895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19894_19895 : H12AffineEnvironment.transform 7 252 env19894 = env19895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env19894 == env19895) = true)

theorem identity19895 : scanCanonicalize (H12AffineFastState.compose env19895 (packedSelected [0,3,5,7,9,10,12,14,15,18,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound19895 : packedSelected [0,3,5,7,9,10,12,14,15,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env19896 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,13325,32768,32939,38125,10280,1025,32769,4160,8401,41136,41002,8328,64,43049,46156,36944,43128,1057,32,253,8401,46212,41633]

theorem envBound19896 : H12AffineFastState.Bounded env19896 := by
  intro p hp
  have h : env19896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19895_19896 : H12AffineEnvironment.transform 13 13325 env19895 = env19896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env19895 == env19896) = true)

theorem identity19896 : scanCanonicalize (H12AffineFastState.compose env19896 (packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound19896 : packedSelected [2,3,5,6,9,10,11,12,14,15,18,22] rootPS < 2^1333 := by decide +kernel

def env19897 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,13325,137,34,5220,10280,1025,136,4160,8401,8249,8355,8328,64,10400,13509,4313,10481,1057,32,253,8401,13325,8744]

theorem envBound19897 : H12AffineFastState.Bounded env19897 := by
  intro p hp
  have h : env19897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19896_19897 : H12AffineEnvironment.transform 14 137 env19896 = env19897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env19896 == env19897) = true)

theorem identity19897 : scanCanonicalize (H12AffineFastState.compose env19897 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound19897 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19898 : List Nat := [2,4,8,16,32,64,128,252,512,52,2048,4096,8192,12345,137,34,4176,10280,53,136,4160,8401,8249,8355,8328,64,10400,12529,4313,10481,21,32,253,8401,12345,8744]

theorem envBound19898 : H12AffineFastState.Bounded env19898 := by
  intro p hp
  have h : env19898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19897_19898 : H12AffineEnvironment.transform 9 52 env19897 = env19898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env19897 == env19898) = true)

def env19899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4160,180272,144477,243088,8328,64,43477,139613,160076,56436,1501,33,257,21792,46212,74250]

theorem envBound19899 : H12AffineFastState.Bounded env19899 := by
  intro p hp
  have h : env19899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19879_19899 : H12AffineEnvironment.transform 17 10281 env19879 = env19899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env19879 == env19899) = true)

def env19900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,21792,41293,73856,8328,64,43477,46157,58460,56436,1501,33,257,21792,46212,74250]

theorem envBound19900 : H12AffineFastState.Bounded env19900 := by
  intro p hp
  have h : env19900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19899_19900 : H12AffineEnvironment.transform 16 38160 env19899 = env19900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env19899 == env19900) = true)

theorem identity19900 : scanCanonicalize (H12AffineFastState.compose env19900 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound19900 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,38160,10281,1025,32769,4160,21792,41293,2,8328,64,43477,46157,58460,56436,1501,33,257,21792,46212,648]

theorem envBound19901 : H12AffineFastState.Bounded env19901 := by
  intro p hp
  have h : env19901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19900_19901 : H12AffineEnvironment.transform 15 8322 env19900 = env19901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env19900 == env19901) = true)

theorem identity19901 : scanCanonicalize (H12AffineFastState.compose env19901 (packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound19901 : packedSelected [1,3,5,8,9,10,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env19902 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,8283,38160,10281,1025,32769,4160,21792,41293,2,8273,64,43276,46157,58460,56436,1284,33,257,21792,46173,593]

theorem envBound19902 : H12AffineFastState.Bounded env19902 := by
  intro p hp
  have h : env19902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19901_19902 : H12AffineEnvironment.transform 6 89 env19901 = env19902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env19901 == env19902) = true)

theorem identity19902 : scanCanonicalize (H12AffineFastState.compose env19902 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound19902 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env19903 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21841,8283,16449,10281,1025,21840,4160,21792,29724,2,8273,64,31837,24860,12557,2341,1284,33,257,21792,24844,593]

theorem envBound19903 : H12AffineFastState.Bounded env19903 := by
  intro p hp
  have h : env19903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19902_19903 : H12AffineEnvironment.transform 14 21841 env19902 = env19903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env19902 == env19903) = true)

theorem identity19903 : scanCanonicalize (H12AffineFastState.compose env19903 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound19903 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env19904 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,21841,342,16449,2340,1025,21840,4160,21792,21777,2,348,64,23888,16401,4096,2341,1284,33,257,21792,16385,593]

theorem envBound19904 : H12AffineFastState.Bounded env19904 := by
  intro p hp
  have h : env19904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19903_19904 : H12AffineEnvironment.transform 12 269 env19903 = env19904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env19903 == env19904) = true)

theorem identity19904 : scanCanonicalize (H12AffineFastState.compose env19904 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound19904 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env19905 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5457,0,342,5392,2340,1025,1,4160,113,64,2,348,64,2049,5440,4096,2341,1284,33,257,113,5456,593]

theorem envBound19905 : H12AffineFastState.Bounded env19905 := by
  intro p hp
  have h : env19905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19904_19905 : H12AffineEnvironment.transform 13 5457 env19904 = env19905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env19904 == env19905) = true)

theorem identity19905 : scanCanonicalize (H12AffineFastState.compose env19905 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19905 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env19906 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,263,5392,2340,1025,1,4113,32,17,2,269,17,2049,5393,4096,2341,1284,33,257,32,5377,512]

theorem envBound19906 : H12AffineFastState.Bounded env19906 := by
  intro p hp
  have h : env19906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19905_19906 : H12AffineEnvironment.transform 5 17 env19905 = env19906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19905 == env19906) = true)

theorem identity19906 : scanCanonicalize (H12AffineFastState.compose env19906 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19906 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19907 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,4096,269,5376,0,263,5392,2309,1025,1,4113,1,17,2,269,17,2049,5393,4096,2308,1284,0,257,1,5377,512]

theorem envBound19907 : H12AffineFastState.Bounded env19907 := by
  intro p hp
  have h : env19907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19906_19907 : H12AffineEnvironment.transform 4 1 env19906 = env19907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env19906 == env19907) = true)

theorem identity19907 : scanCanonicalize (H12AffineFastState.compose env19907 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound19907 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env19908 : List Nat := [2,4,8,16,1,17,8,256,512,1024,523,4096,269,5376,0,263,5392,782,1025,1,4113,1,17,2,269,17,522,5393,4096,783,1284,0,257,1,5377,512]

theorem envBound19908 : H12AffineFastState.Bounded env19908 := by
  intro p hp
  have h : env19908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19907_19908 : H12AffineEnvironment.transform 10 523 env19907 = env19908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env19907 == env19908) = true)

def env19909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,4160,21793,41292,73857,8328,64,43477,46156,58461,56436,1501,33,257,21792,46212,74250]

theorem envBound19909 : H12AffineFastState.Bounded env19909 := by
  intro p hp
  have h : env19909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19899_19909 : H12AffineEnvironment.transform 16 38161 env19899 = env19909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env19899 == env19909) = true)

theorem identity19909 : scanCanonicalize (H12AffineFastState.compose env19909 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound19909 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1025,32769,4160,21793,41292,138,8328,64,43477,46156,58461,56436,1501,33,257,21792,46212,513]

theorem envBound19910 : H12AffineFastState.Bounded env19910 := by
  intro p hp
  have h : env19910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19909_19910 : H12AffineEnvironment.transform 15 8203 env19909 = env19910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env19909 == env19910) = true)

theorem identity19910 : scanCanonicalize (H12AffineFastState.compose env19910 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound19910 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env19911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,38161,10281,1025,32769,4160,169,41292,138,8328,64,43477,46156,45525,35324,1501,33,257,168,46212,513]

theorem envBound19911 : H12AffineFastState.Bounded env19911 := by
  intro p hp
  have h : env19911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19910_19911 : H12AffineEnvironment.transform 13 5512 env19910 = env19911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env19910 == env19911) = true)

theorem identity19911 : scanCanonicalize (H12AffineFastState.compose env19911 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound19911 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env19912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5512,32768,34,38161,2048,1025,32769,4160,169,33125,138,161,64,35324,37989,37372,35324,1501,33,257,168,38061,513]

theorem envBound19912 : H12AffineFastState.Bounded env19912 := by
  intro p hp
  have h : env19912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19911_19912 : H12AffineEnvironment.transform 12 41 env19911 = env19912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env19911 == env19912) = true)

theorem identity19912 : scanCanonicalize (H12AffineFastState.compose env19912 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound19912 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env19913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5512,372,34,5221,2048,1025,373,4160,169,17,138,161,64,2184,5393,4232,2184,1501,33,257,168,5593,513]

theorem envBound19913 : H12AffineFastState.Bounded env19913 := by
  intro p hp
  have h : env19913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19912_19913 : H12AffineEnvironment.transform 14 372 env19912 = env19913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env19912 == env19913) = true)

theorem identity19913 : scanCanonicalize (H12AffineFastState.compose env19913 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound19913 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env19914 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5376,372,34,5221,2048,1025,373,4160,33,17,2,41,64,2048,5393,4096,2048,1365,33,257,32,5457,513]

theorem envBound19914 : H12AffineFastState.Bounded env19914 := by
  intro p hp
  have h : env19914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19913_19914 : H12AffineEnvironment.transform 6 8 env19913 = env19914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env19913 == env19914) = true)

def env19915 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452633,144476,243088,8328,64,43476,139612,160076,324700,1500,272393,257,21792,46212,74251]

theorem envBound19915 : H12AffineFastState.Bounded env19915 := by
  intro p hp
  have h : env19915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19878_19915 : H12AffineEnvironment.transform 20 4161 env19878 = env19915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19878 == env19915) = true)

theorem identity19915 : scanCanonicalize (H12AffineFastState.compose env19915 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound19915 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19916 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,262144,1025,32769,4161,272513,62660,95496,8328,64,43476,57796,45524,324700,1500,272393,257,21792,46212,74251]

theorem envBound19916 : H12AffineFastState.Bounded env19916 := by
  intro p hp
  have h : env19916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19915_19916 : H12AffineEnvironment.transform 16 49304 env19915 = env19916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env19915 == env19916) = true)

theorem identity19916 : scanCanonicalize (H12AffineFastState.compose env19916 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound19916 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env19917 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49304,262144,1025,32769,4161,272513,62660,21762,8328,64,43476,57796,45524,324700,1500,272393,257,21792,46212,513]

theorem envBound19917 : H12AffineFastState.Bounded env19917 := by
  intro p hp
  have h : env19917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19916_19917 : H12AffineEnvironment.transform 15 8202 env19916 = env19917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env19916 == env19917) = true)

theorem identity19917 : scanCanonicalize (H12AffineFastState.compose env19917 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound19917 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env19918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49304,10401,1025,32769,4161,32,62660,21762,8328,64,43476,57796,45524,56573,1500,168,257,21792,46212,513]

theorem envBound19918 : H12AffineFastState.Bounded env19918 := by
  intro p hp
  have h : env19918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19917_19918 : H12AffineEnvironment.transform 17 10401 env19917 = env19918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19917 == env19918) = true)

theorem identity19918 : scanCanonicalize (H12AffineFastState.compose env19918 (packedSelected [2,4,6,9,10,11,15,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 7560) := by decide +kernel

theorem selectedBound19918 : packedSelected [2,4,6,9,10,11,15,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env19919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,7560,8202,23824,10401,1025,7561,4161,32,26956,21762,8328,64,13404,31820,11356,16757,1500,168,257,21792,10508,513]

theorem envBound19919 : H12AffineFastState.Bounded env19919 := by
  intro p hp
  have h : env19919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19918_19919 : H12AffineEnvironment.transform 14 7560 env19918 = env19919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7560 env19918 == env19919) = true)

theorem identity19919 : scanCanonicalize (H12AffineFastState.compose env19919 (packedSelected [0,1,2,3,5,6,7,8,9,11,15,17,22] rootPS)) = affineNative (2^(11+1) ^^^ 3328) := by decide +kernel

theorem selectedBound19919 : packedSelected [0,1,2,3,5,6,7,8,9,11,15,17,22] rootPS < 2^1333 := by decide +kernel

def env19920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,8192,16384,136,8202,16400,10401,1025,137,3393,32,26956,18434,8328,64,10588,24908,11356,16757,1500,168,257,18464,10508,513]

theorem envBound19920 : H12AffineFastState.Bounded env19920 := by
  intro p hp
  have h : env19920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19919_19920 : H12AffineEnvironment.transform 11 3328 env19919 = env19920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3328 env19919 == env19920) = true)

theorem identity19920 : scanCanonicalize (H12AffineFastState.compose env19920 (packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 2209) := by decide +kernel

theorem selectedBound19920 : packedSelected [0,1,2,4,6,7,8,9,10,11,12,14,18] rootPS < 2^1333 := by decide +kernel

def env19921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,2209,16384,136,2219,16400,0,1025,137,3393,32,16877,18434,2089,64,509,18925,1277,16757,1500,168,257,18464,429,513]

theorem envBound19921 : H12AffineFastState.Bounded env19921 := by
  intro p hp
  have h : env19921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19920_19921 : H12AffineEnvironment.transform 12 2209 env19920 = env19921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2209 env19920 == env19921) = true)

theorem identity19921 : scanCanonicalize (H12AffineFastState.compose env19921 (packedSelected [1,2,4,5,6,8,9,12,15,17,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1260) := by decide +kernel

theorem selectedBound19921 : packedSelected [1,2,4,5,6,8,9,12,15,17,23,24] rootPS < 2^1333 := by decide +kernel

def env19922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3328,2209,1260,136,2219,1276,0,1025,137,3393,32,1281,3310,2089,64,509,3329,1277,1433,1500,168,257,3276,429,513]

theorem envBound19922 : H12AffineFastState.Bounded env19922 := by
  intro p hp
  have h : env19922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19921_19922 : H12AffineEnvironment.transform 13 1260 env19921 = env19922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1260 env19921 == env19922) = true)

theorem identity19922 : scanCanonicalize (H12AffineFastState.compose env19922 (packedSelected [1,2,3,4,5,6,7,8,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound19922 : packedSelected [1,2,3,4,5,6,7,8,12,14,15] rootPS < 2^1333 := by decide +kernel

def env19923 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,3328,2169,1076,80,2163,1060,0,1025,81,3393,32,1281,3126,2089,64,293,3329,1061,1345,1284,112,257,3092,373,513]

theorem envBound19923 : H12AffineFastState.Bounded env19923 := by
  intro p hp
  have h : env19923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19922_19923 : H12AffineEnvironment.transform 6 88 env19922 = env19923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env19922 == env19923) = true)

theorem identity19923 : scanCanonicalize (H12AffineFastState.compose env19923 (packedSelected [6,7,9] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound19923 : packedSelected [6,7,9] rootPS < 2^1333 := by decide +kernel

def env19924 : List Nat := [2,4,8,16,32,64,88,256,512,1024,293,1061,348,1076,80,342,1060,0,1025,81,1124,32,1281,1299,268,64,293,1060,1061,1345,1284,112,257,1329,373,513]

theorem envBound19924 : H12AffineFastState.Bounded env19924 := by
  intro p hp
  have h : env19924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19923_19924 : H12AffineEnvironment.transform 10 293 env19923 = env19924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env19923 == env19924) = true)

theorem identity19924 : scanCanonicalize (H12AffineFastState.compose env19924 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19924 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env19925 : List Nat := [2,4,8,16,32,64,88,117,512,1024,80,1061,41,1076,80,35,1060,0,1025,81,1124,32,1140,1126,121,64,80,1060,1061,1076,1137,112,116,1092,0,513]

theorem envBound19925 : H12AffineFastState.Bounded env19925 := by
  intro p hp
  have h : env19925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19924_19925 : H12AffineEnvironment.transform 7 117 env19924 = env19925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19924 == env19925) = true)

theorem identity19925 : scanCanonicalize (H12AffineFastState.compose env19925 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound19925 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env19926 : List Nat := [2,4,8,16,32,64,88,117,512,101,80,64,41,81,80,35,65,0,100,81,1,32,17,3,121,64,80,65,64,81,20,112,116,33,0,513]

theorem envBound19926 : H12AffineFastState.Bounded env19926 := by
  intro p hp
  have h : env19926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19925_19926 : H12AffineEnvironment.transform 9 101 env19925 = env19926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env19925 == env19926) = true)

theorem identity19926 : scanCanonicalize (H12AffineFastState.compose env19926 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19926 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19927 : List Nat := [2,4,8,16,32,17,9,36,512,52,1,17,41,0,1,35,16,0,53,0,1,32,17,3,40,17,1,16,17,0,20,33,37,33,0,513]

theorem envBound19927 : H12AffineFastState.Bounded env19927 := by
  intro p hp
  have h : env19927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19926_19927 : H12AffineEnvironment.transform 5 17 env19926 = env19927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19926 == env19927) = true)

theorem identity19927 : scanCanonicalize (H12AffineFastState.compose env19927 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound19927 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env19928 : List Nat := [2,4,8,16,11,17,9,15,512,31,1,17,2,0,1,8,16,0,30,0,1,11,17,3,3,17,1,16,17,0,20,10,14,10,0,513]

theorem envBound19928 : H12AffineFastState.Bounded env19928 := by
  intro p hp
  have h : env19928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19927_19928 : H12AffineEnvironment.transform 4 11 env19927 = env19928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env19927 == env19928) = true)

theorem identity19928 : scanCanonicalize (H12AffineFastState.compose env19928 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound19928 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19929 : List Nat := [2,4,8,0,11,1,9,15,512,15,1,1,2,0,1,8,0,0,14,0,1,11,1,3,3,1,1,0,1,0,4,10,14,10,0,513]

theorem envBound19929 : H12AffineFastState.Bounded env19929 := by
  intro p hp
  have h : env19929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19928_19929 : H12AffineEnvironment.transform 3 0 env19928 = env19929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env19928 == env19929) = true)

theorem identity19929 : scanCanonicalize (H12AffineFastState.compose env19929 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound19929 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env19930 : List Nat := [2,4,8,0,11,1,9,15,1,15,1,1,2,0,1,8,0,0,14,0,1,11,1,3,3,1,1,0,1,0,4,10,14,10,0,0]

theorem envBound19930 : H12AffineFastState.Bounded env19930 := by
  intro p hp
  have h : env19930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19929_19930 : H12AffineEnvironment.transform 8 1 env19929 = env19930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env19929 == env19930) = true)

def env19931 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2237469,243089,8328,64,6705549,2240796,160076,2417693,2102684,6475856,257,21793,46213,2175563]

theorem envBound19931 : H12AffineFastState.Bounded env19931 := by
  intro p hp
  have h : env19931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19845_19931 : H12AffineEnvironment.transform 23 243089 env19845 = env19931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env19845 == env19931) = true)

def env19932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,2237469,243089,8328,64,2144661,2240796,160076,2417693,2102684,2373704,257,21793,46213,2175563]

theorem envBound19932 : H12AffineFastState.Bounded env19932 := by
  intro p hp
  have h : env19932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19931_19932 : H12AffineEnvironment.transform 21 452632 env19931 = env19932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env19931 == env19932) = true)

def env19933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,144477,243089,8328,64,43477,139612,160076,324701,1500,272392,257,21793,46213,74251]

theorem envBound19933 : H12AffineFastState.Bounded env19933 := by
  intro p hp
  have h : env19933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19932_19933 : H12AffineEnvironment.transform 20 4160 env19932 = env19933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env19932 == env19933) = true)

theorem identity19933 : scanCanonicalize (H12AffineFastState.compose env19933 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound19933 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4160,452632,144477,155983,8328,64,43477,139612,160076,324701,1500,272392,257,21793,46213,63189]

theorem envBound19934 : H12AffineFastState.Bounded env19934 := by
  intro p hp
  have h : env19934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19933_19934 : H12AffineEnvironment.transform 15 54494 env19933 = env19934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env19933 == env19934) = true)

def env19935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146912,1025,32769,4160,54776,144477,155983,8328,64,43477,139612,160076,182717,1500,136680,257,21793,46213,63189]

theorem envBound19935 : H12AffineFastState.Bounded env19935 := by
  intro p hp
  have h : env19935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19934_19935 : H12AffineEnvironment.transform 17 146912 env19934 = env19935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env19934 == env19935) = true)

theorem identity19935 : scanCanonicalize (H12AffineFastState.compose env19935 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57748) := by decide +kernel

theorem selectedBound19935 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,57748,56436,1025,32769,4160,54776,54729,32987,8328,64,43477,49352,37080,10281,1500,62588,257,21793,46213,63189]

theorem envBound19936 : H12AffineFastState.Bounded env19936 := by
  intro p hp
  have h : env19936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19935_19936 : H12AffineEnvironment.transform 16 57748 env19935 = env19936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57748 env19935 == env19936) = true)

theorem identity19936 : scanCanonicalize (H12AffineFastState.compose env19936 (packedSelected [0,9,11,12,15,18,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound19936 : packedSelected [0,9,11,12,15,18,22,27] rootPS < 2^1333 := by decide +kernel

def env19937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,479,13461,2421,1025,21760,4160,249,200,21978,8328,64,31956,5577,17881,10281,1500,8573,257,21793,24964,9172]

theorem envBound19937 : H12AffineFastState.Bounded env19937 := by
  intro p hp
  have h : env19937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19936_19937 : H12AffineEnvironment.transform 14 21761 env19936 = env19937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env19936 == env19937) = true)

theorem identity19937 : scanCanonicalize (H12AffineFastState.compose env19937 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound19937 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env19938 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,263,13389,2421,1025,21760,4160,33,16,21762,8272,64,31756,5393,17665,10281,1284,8573,257,21793,24924,8972]

theorem envBound19938 : H12AffineFastState.Bounded env19938 := by
  intro p hp
  have h : env19938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19937_19938 : H12AffineEnvironment.transform 6 88 env19937 = env19938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env19937 == env19938) = true)

theorem identity19938 : scanCanonicalize (H12AffineFastState.compose env19938 (packedSelected [11,12,15,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound19938 : packedSelected [11,12,15,17,18] rootPS < 2^1333 := by decide +kernel

def env19939 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,13405,8540,263,13389,2421,1025,8541,4160,33,16,8543,8272,64,2129,5393,12636,10281,1284,8573,257,8572,5377,8972]

theorem envBound19939 : H12AffineFastState.Bounded env19939 := by
  intro p hp
  have h : env19939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19938_19939 : H12AffineEnvironment.transform 13 13405 env19938 = env19939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env19938 == env19939) = true)

theorem identity19939 : scanCanonicalize (H12AffineFastState.compose env19939 (packedSelected [0,1,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound19939 : packedSelected [0,1,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env19940 : List Nat := [2,4,8,16,32,64,88,256,512,100,2048,4096,8192,12345,8540,263,12329,2421,101,8541,4160,33,16,8543,8272,64,2129,4469,12636,10281,352,8573,257,8572,4453,8972]

theorem envBound19940 : H12AffineFastState.Bounded env19940 := by
  intro p hp
  have h : env19940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19939_19940 : H12AffineEnvironment.transform 9 100 env19939 = env19940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env19939 == env19940) = true)

theorem identity19940 : scanCanonicalize (H12AffineFastState.compose env19940 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19940 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env19941 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,8192,12345,8460,263,12329,2341,53,8461,4112,33,16,8463,8192,16,2049,4389,12556,10281,304,8493,257,8492,4405,8972]

theorem envBound19941 : H12AffineFastState.Bounded env19941 := by
  intro p hp
  have h : env19941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19940_19941 : H12AffineEnvironment.transform 5 16 env19940 = env19941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19940 == env19941) = true)

def env19942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146913,1025,32769,4160,54777,144477,155983,8328,64,43477,139612,160076,182716,1500,136681,257,21793,46213,63189]

theorem envBound19942 : H12AffineFastState.Bounded env19942 := by
  intro p hp
  have h : env19942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19934_19942 : H12AffineEnvironment.transform 17 146913 env19934 = env19942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env19934 == env19942) = true)

theorem identity19942 : scanCanonicalize (H12AffineFastState.compose env19942 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound19942 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env19943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,57629,56572,1025,32769,4160,54777,54592,32850,8328,64,43477,49217,36945,10401,1500,62708,257,21793,46213,63189]

theorem envBound19943 : H12AffineFastState.Bounded env19943 := by
  intro p hp
  have h : env19943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19942_19943 : H12AffineEnvironment.transform 16 57629 env19942 = env19943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env19942 == env19943) = true)

theorem identity19943 : scanCanonicalize (H12AffineFastState.compose env19943 (packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound19943 : packedSelected [0,1,2,4,5,6,7,8,9,10,11,14,17,18,24,31] rootPS < 2^1333 := by decide +kernel

def env19944 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,54494,57449,56572,1025,32769,4160,54413,54324,32850,8328,64,43169,49217,36945,10401,1192,62708,117,21589,46213,63189]

theorem envBound19944 : H12AffineFastState.Bounded env19944 := by
  intro p hp
  have h : env19944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19943_19944 : H12AffineEnvironment.transform 7 116 env19943 = env19944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env19943 == env19944) = true)

theorem identity19944 : scanCanonicalize (H12AffineFastState.compose env19944 (packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound19944 : packedSelected [2,4,6,7,8,10,11,12,14,15,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env19945 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,16384,32768,54414,57401,56492,1025,32769,4112,54413,54324,32770,8328,16,43169,49169,36865,10401,1192,62628,37,21509,46213,63109]

theorem envBound19945 : H12AffineFastState.Bounded env19945 := by
  intro p hp
  have h : env19945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19944_19945 : H12AffineEnvironment.transform 5 16 env19944 = env19945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env19944 == env19945) = true)

theorem identity19945 : scanCanonicalize (H12AffineFastState.compose env19945 (packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8352) := by decide +kernel

theorem selectedBound19945 : packedSelected [1,2,4,6,8,11,12,15,16,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env19946 : List Nat := [2,4,8,16,32,16,128,36,512,1024,2048,4096,8192,16384,8352,29742,16537,31756,1025,8353,4112,29741,29844,8354,8328,16,2049,24753,12449,10401,1192,21508,37,21509,5157,22053]

theorem envBound19946 : H12AffineFastState.Bounded env19946 := by
  intro p hp
  have h : env19946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19945_19946 : H12AffineEnvironment.transform 14 8352 env19945 = env19946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env19945 == env19946) = true)

def env19947 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,144476,243089,8328,64,43476,139613,160076,324700,1501,272393,257,21793,46213,74250]

theorem envBound19947 : H12AffineFastState.Bounded env19947 := by
  intro p hp
  have h : env19947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19932_19947 : H12AffineEnvironment.transform 20 4161 env19932 = env19947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env19932 == env19947) = true)

theorem identity19947 : scanCanonicalize (H12AffineFastState.compose env19947 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound19947 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env19948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,262144,1025,32769,4161,392286,73754,41431,8328,64,43476,79131,91402,324700,1501,272393,257,21793,46213,74250]

theorem envBound19948 : H12AffineFastState.Bounded env19948 := by
  intro p hp
  have h : env19948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19947_19948 : H12AffineEnvironment.transform 16 70726 env19947 = env19948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env19947 == env19948) = true)

def env19949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10400,1025,32769,4161,120062,73754,41431,8328,64,43476,79131,91402,56572,1501,169,257,21793,46213,74250]

theorem envBound19949 : H12AffineFastState.Bounded env19949 := by
  intro p hp
  have h : env19949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19948_19949 : H12AffineEnvironment.transform 17 10400 env19948 = env19949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env19948 == env19949) = true)

theorem identity19949 : scanCanonicalize (H12AffineFastState.compose env19949 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound19949 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env19950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49305,10400,1025,32769,4161,33,62661,41431,8328,64,43476,57796,45525,56572,1501,169,257,21793,46213,63189]

theorem envBound19950 : H12AffineFastState.Bounded env19950 := by
  intro p hp
  have h : env19950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19949_19950 : H12AffineEnvironment.transform 15 54495 env19949 = env19950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env19949 == env19950) = true)

theorem identity19950 : scanCanonicalize (H12AffineFastState.compose env19950 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound19950 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env19951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,32768,33167,38345,10400,1025,32769,4161,33,41365,41431,8328,64,43476,46228,45525,35244,1501,169,257,113,46213,41861]

theorem envBound19951 : H12AffineFastState.Bounded env19951 := by
  intro p hp
  have h : env19951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19950_19951 : H12AffineEnvironment.transform 13 5456 env19950 = env19951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env19950 == env19951) = true)

theorem identity19951 : scanCanonicalize (H12AffineFastState.compose env19951 (packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound19951 : packedSelected [1,2,6,8,9,11,12,14,15,18,19,22] rootPS < 2^1333 := by decide +kernel

def env19952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,80,479,5529,10400,1025,81,4161,33,8645,8583,8328,64,10628,13508,12677,2556,1501,169,257,113,13525,9173]

theorem envBound19952 : H12AffineFastState.Bounded env19952 := by
  intro p hp
  have h : env19952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19951_19952 : H12AffineEnvironment.transform 14 80 env19951 = env19952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env19951 == env19952) = true)

theorem identity19952 : scanCanonicalize (H12AffineFastState.compose env19952 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound19952 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env19953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5456,80,479,5529,2341,1025,81,4161,33,64,2,269,64,2049,5441,4096,2556,1501,169,257,113,5456,592]

theorem envBound19953 : H12AffineFastState.Bounded env19953 := by
  intro p hp
  have h : env19953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19952_19953 : H12AffineEnvironment.transform 12 389 env19952 = env19953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env19952 == env19953) = true)

theorem identity19953 : scanCanonicalize (H12AffineFastState.compose env19953 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound19953 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env19954 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,349,5456,80,263,5441,2341,1025,81,4161,33,64,2,269,64,2049,5441,4096,2340,1285,113,257,113,5456,592]

theorem envBound19954 : H12AffineFastState.Bounded env19954 := by
  intro p hp
  have h : env19954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19953_19954 : H12AffineEnvironment.transform 6 88 env19953 = env19954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env19953 == env19954) = true)

theorem identity19954 : scanCanonicalize (H12AffineFastState.compose env19954 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound19954 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env19955 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,40,5157,80,114,5172,2128,1025,81,4161,33,64,2,120,64,2049,5172,4096,2129,1136,113,116,113,5157,592]

theorem envBound19955 : H12AffineFastState.Bounded env19955 := by
  intro p hp
  have h : env19955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19954_19955 : H12AffineEnvironment.transform 7 117 env19954 = env19955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env19954 == env19955) = true)

theorem identity19955 : scanCanonicalize (H12AffineFastState.compose env19955 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound19955 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env19956 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,5157,1,35,5172,2049,1025,0,4112,33,17,2,41,17,2049,5172,4096,2048,1057,32,37,32,5157,513]

theorem envBound19956 : H12AffineFastState.Bounded env19956 := by
  intro p hp
  have h : env19956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19955_19956 : H12AffineEnvironment.transform 5 17 env19955 = env19956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env19955 == env19956) = true)

theorem identity19956 : scanCanonicalize (H12AffineFastState.compose env19956 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound19956 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env19957 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,40,1044,1,35,1029,2049,1025,0,33,33,17,2,41,17,2049,1029,49,2048,1057,32,37,32,1044,513]

theorem envBound19957 : H12AffineFastState.Bounded env19957 := by
  intro p hp
  have h : env19957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19956_19957 : H12AffineEnvironment.transform 11 49 env19956 = env19957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env19956 == env19957) = true)

theorem identity19957 : scanCanonicalize (H12AffineFastState.compose env19957 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1541) := by decide +kernel

theorem selectedBound19957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env19958 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1541,49,40,1044,1,35,1029,1540,1025,0,33,33,17,2,41,17,1540,1029,49,1541,1057,32,37,32,1044,513]

theorem envBound19958 : H12AffineFastState.Bounded env19958 := by
  intro p hp
  have h : env19958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19957_19958 : H12AffineEnvironment.transform 10 1541 env19957 = env19958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1541 env19957 == env19958) = true)

def env19959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10401,1025,32769,4161,120063,73754,41431,8328,64,43476,79131,91402,56573,1501,168,257,21793,46213,74250]

theorem envBound19959 : H12AffineFastState.Bounded env19959 := by
  intro p hp
  have h : env19959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19948_19959 : H12AffineEnvironment.transform 17 10401 env19948 = env19959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env19948 == env19959) = true)

theorem identity19959 : scanCanonicalize (H12AffineFastState.compose env19959 (packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS)) = affineNative (2^(14+1) ^^^ 21976) := by decide +kernel

theorem selectedBound19959 : packedSelected [0,1,3,5,8,9,11,14,15,16,20,22,26,27,31,32,35,38] rootPS < 2^1333 := by decide +kernel

def env19960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21976,65536,70726,10401,1025,21977,4161,65831,73754,29711,8328,64,31756,79131,91402,2341,1501,168,257,21793,24925,74250]

theorem envBound19960 : H12AffineFastState.Bounded env19960 := by
  intro p hp
  have h : env19960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19959_19960 : H12AffineEnvironment.transform 14 21976 env19959 = env19960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21976 env19959 == env19960) = true)

theorem identity19960 : scanCanonicalize (H12AffineFastState.compose env19960 (packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound19960 : packedSelected [0,2,6,8,10,11,12,14,15,16,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env19961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,508,65536,70726,10401,1025,509,4161,65831,73754,8235,8328,64,10280,79131,78126,2341,1501,168,257,261,13689,74250]

theorem envBound19961 : H12AffineFastState.Bounded env19961 := by
  intro p hp
  have h : env19961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19960_19961 : H12AffineEnvironment.transform 13 5156 env19960 = env19961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env19960 == env19961) = true)

theorem identity19961 : scanCanonicalize (H12AffineFastState.compose env19961 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound19961 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env19962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,508,263,5441,10401,1025,509,4161,32,8477,8235,8328,64,10280,13340,12329,2341,1501,168,257,261,13689,8973]

theorem envBound19962 : H12AffineFastState.Bounded env19962 := by
  intro p hp
  have h : env19962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19961_19962 : H12AffineEnvironment.transform 15 263 env19961 = env19962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env19961 == env19962) = true)

theorem identity19962 : scanCanonicalize (H12AffineFastState.compose env19962 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound19962 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env19963 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,5156,249,2,5188,10401,1025,248,4161,32,8216,8235,8328,64,10280,13340,12329,2080,1240,168,4,0,13436,8712]

theorem envBound19963 : H12AffineFastState.Bounded env19963 := by
  intro p hp
  have h : env19963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19962_19963 : H12AffineEnvironment.transform 7 5 env19962 = env19963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env19962 == env19963) = true)

theorem identity19963 : scanCanonicalize (H12AffineFastState.compose env19963 (packedSelected [0,2,3,5,7,10,12,14,15,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 208) := by decide +kernel

theorem selectedBound19963 : packedSelected [0,2,3,5,7,10,12,14,15,17,20] rootPS < 2^1333 := by decide +kernel

def env19964 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,208,5156,249,2,5188,2161,1025,248,4161,32,200,251,88,64,2296,5324,4345,2080,1240,168,4,0,5292,728]

theorem envBound19964 : H12AffineFastState.Bounded env19964 := by
  intro p hp
  have h : env19964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans19963_19964 : H12AffineEnvironment.transform 12 208 env19963 = env19964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 208 env19963 == env19964) = true)

theorem identity19964 : scanCanonicalize (H12AffineFastState.compose env19964 (packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound19964 : packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env19965 : List Nat := [2,4,8,16,1,64,128,5,512,1024,2048,4096,208,5125,216,2,5188,2128,1025,217,4161,1,200,218,88,64,2265,5324,4312,2049,1240,137,4,0,5261,728]

end H12CloudChart1