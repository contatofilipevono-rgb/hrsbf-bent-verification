import H12CloudChart1Data069

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound17646 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17647 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4373,261,263,4096,2309,273,260,4112,1,17,262,269,16,2308,4097,4357,2309,21,1,257,293,4372,512]

theorem envBound17647 : H12AffineFastState.Bounded env17647 := by
  intro p hp
  have h : env17647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17646_17647 : H12AffineEnvironment.transform 9 272 env17646 = env17647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env17646 == env17647) = true)

theorem identity17647 : scanCanonicalize (H12AffineFastState.compose env17647 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17647 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17648 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4145,33,35,4096,2081,53,32,4112,1,17,34,41,16,2080,4097,4129,2081,21,1,37,1,4144,512]

theorem envBound17648 : H12AffineFastState.Bounded env17648 := by
  intro p hp
  have h : env17648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17647_17648 : H12AffineEnvironment.transform 7 36 env17647 = env17648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17647 == env17648) = true)

theorem identity17648 : scanCanonicalize (H12AffineFastState.compose env17648 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound17648 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env17649 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2096,41,2049,33,35,2096,2081,53,32,2080,1,17,34,41,16,2080,2097,2065,2081,21,1,37,1,2048,512]

theorem envBound17649 : H12AffineFastState.Bounded env17649 := by
  intro p hp
  have h : env17649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17648_17649 : H12AffineEnvironment.transform 11 2096 env17648 = env17649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env17648 == env17649) = true)

theorem identity17649 : scanCanonicalize (H12AffineFastState.compose env17649 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound17649 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env17650 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,17,41,32,33,35,17,0,53,32,1,1,17,34,41,16,1,16,48,0,21,1,37,1,33,512]

theorem envBound17650 : H12AffineFastState.Bounded env17650 := by
  intro p hp
  have h : env17650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17649_17650 : H12AffineEnvironment.transform 10 33 env17649 = env17650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env17649 == env17650) = true)

theorem identity17650 : scanCanonicalize (H12AffineFastState.compose env17650 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17650 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17651 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,9,0,1,3,17,0,21,0,1,1,17,2,9,16,1,16,16,0,21,1,5,1,1,512]

theorem envBound17651 : H12AffineFastState.Bounded env17651 := by
  intro p hp
  have h : env17651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17650_17651 : H12AffineEnvironment.transform 4 0 env17650 = env17651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17650 == env17651) = true)

theorem identity17651 : scanCanonicalize (H12AffineFastState.compose env17651 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound17651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17652 : List Nat := [2,4,8,16,0,16,8,4,17,20,1,17,9,0,1,3,17,0,21,0,1,1,17,2,9,16,1,16,16,0,21,1,5,1,1,17]

theorem envBound17652 : H12AffineFastState.Bounded env17652 := by
  intro p hp
  have h : env17652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17651_17652 : H12AffineEnvironment.transform 8 17 env17651 = env17652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env17651 == env17652) = true)

theorem identity17652 : scanCanonicalize (H12AffineFastState.compose env17652 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound17652 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17653 : List Nat := [2,0,8,16,0,16,8,0,17,16,1,17,9,0,1,3,17,0,17,0,1,1,17,2,9,16,1,16,16,0,17,1,1,1,1,17]

theorem envBound17653 : H12AffineFastState.Bounded env17653 := by
  intro p hp
  have h : env17653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17652_17653 : H12AffineEnvironment.transform 1 0 env17652 = env17653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env17652 == env17653) = true)

def env17654 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4113,400405,144517,213405,8328,17,23945,139653,160148,262144,1420,272393,257,21792,16384,74250]

theorem envBound17654 : H12AffineFastState.Bounded env17654 := by
  intro p hp
  have h : env17654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17639_17654 : H12AffineEnvironment.transform 5 17 env17639 = env17654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17639 == env17654) = true)

theorem identity17654 : scanCanonicalize (H12AffineFastState.compose env17654 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound17654 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env17655 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,79251,262144,1025,29829,4113,338310,65814,29710,8328,17,23945,70678,82951,262144,1420,272393,257,21792,16384,74250]

theorem envBound17655 : H12AffineFastState.Bounded env17655 := by
  intro p hp
  have h : env17655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17654_17655 : H12AffineEnvironment.transform 16 79251 env17654 = env17655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env17654 == env17655) = true)

theorem identity17655 : scanCanonicalize (H12AffineFastState.compose env17655 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound17655 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env17656 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,65536,79251,67754,1025,29829,4113,8492,65814,29710,8328,17,23945,70678,82951,67754,1420,73891,257,21792,16384,74250]

theorem envBound17656 : H12AffineFastState.Bounded env17656 := by
  intro p hp
  have h : env17656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17655_17656 : H12AffineEnvironment.transform 17 67754 env17655 = env17656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env17655 == env17656) = true)

theorem identity17656 : scanCanonicalize (H12AffineFastState.compose env17656 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound17656 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env17657 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,29962,16537,32160,1025,29829,4113,8492,29724,29710,8328,17,23945,24860,12557,32160,1420,21929,257,21792,16384,22272]

theorem envBound17657 : H12AffineFastState.Bounded env17657 := by
  intro p hp
  have h : env17657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17656_17657 : H12AffineEnvironment.transform 15 29962 env17656 = env17657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env17656 == env17657) = true)

theorem identity17657 : scanCanonicalize (H12AffineFastState.compose env17657 (packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17657 : packedSelected [1,2,3,4,5,6,8,9,12,17,18] rootPS < 2^1333 := by decide +kernel

def env17658 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,8202,5529,10400,1025,8581,4113,8492,8476,8462,8328,17,2185,13340,12557,10400,1420,169,257,32,5376,512]

theorem envBound17658 : H12AffineFastState.Bounded env17658 := by
  intro p hp
  have h : env17658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17657_17658 : H12AffineEnvironment.transform 13 5376 env17657 = env17658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17657 == env17658) = true)

theorem identity17658 : scanCanonicalize (H12AffineFastState.compose env17658 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound17658 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17659 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,8192,5376,8493,8202,5424,10249,1025,8492,4113,8492,8476,8462,8225,17,2080,13340,12557,10249,1317,0,257,32,5376,512]

theorem envBound17659 : H12AffineFastState.Bounded env17659 := by
  intro p hp
  have h : env17659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17658_17659 : H12AffineEnvironment.transform 6 41 env17658 = env17659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17658 == env17659) = true)

theorem identity17659 : scanCanonicalize (H12AffineFastState.compose env17659 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound17659 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17660 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,4096,40,5376,261,34,5424,2081,1025,260,4113,260,308,294,9,17,2080,5172,4389,2081,1317,0,257,32,5376,512]

theorem envBound17660 : H12AffineFastState.Bounded env17660 := by
  intro p hp
  have h : env17660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17659_17660 : H12AffineEnvironment.transform 12 40 env17659 = env17660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17659 == env17660) = true)

theorem identity17660 : scanCanonicalize (H12AffineFastState.compose env17660 (packedSelected [0,2,3,5,7,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound17660 : packedSelected [0,2,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env17661 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,3077,40,2309,261,34,2357,2081,1025,260,3092,260,308,294,9,17,2080,2097,3360,2081,1317,0,257,32,2309,512]

theorem envBound17661 : H12AffineFastState.Bounded env17661 := by
  intro p hp
  have h : env17661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17660_17661 : H12AffineEnvironment.transform 11 3077 env17660 = env17661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env17660 == env17661) = true)

theorem identity17661 : scanCanonicalize (H12AffineFastState.compose env17661 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17661 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env17662 : List Nat := [2,4,8,16,1,17,8,256,512,1024,2048,3077,9,2309,261,3,2324,2048,1025,260,3092,260,277,263,9,17,2049,2064,3329,2048,1284,0,257,1,2309,512]

theorem envBound17662 : H12AffineFastState.Bounded env17662 := by
  intro p hp
  have h : env17662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17661_17662 : H12AffineEnvironment.transform 4 1 env17661 = env17662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17661 == env17662) = true)

theorem identity17662 : scanCanonicalize (H12AffineFastState.compose env17662 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17662 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env17663 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,3077,9,2049,1,3,2064,2048,1025,0,3092,0,17,3,9,17,2049,2064,3077,2048,1024,0,5,1,2049,512]

theorem envBound17663 : H12AffineFastState.Bounded env17663 := by
  intro p hp
  have h : env17663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17662_17663 : H12AffineEnvironment.transform 7 4 env17662 = env17663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17662 == env17663) = true)

theorem identity17663 : scanCanonicalize (H12AffineFastState.compose env17663 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17663 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17664 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1,1028,9,0,1,3,17,1,1025,0,1045,0,17,3,9,17,0,17,1028,1,1024,0,5,1,0,512]

theorem envBound17664 : H12AffineFastState.Bounded env17664 := by
  intro p hp
  have h : env17664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17663_17664 : H12AffineEnvironment.transform 10 1 env17663 = env17664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17663 == env17664) = true)

theorem identity17664 : scanCanonicalize (H12AffineFastState.compose env17664 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17664 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17665 : List Nat := [2,4,8,16,1,17,8,4,0,1024,1,1028,9,0,1,3,17,1,1025,0,1045,0,17,3,9,17,0,17,1028,1,1024,0,5,1,0,0]

theorem envBound17665 : H12AffineFastState.Bounded env17665 := by
  intro p hp
  have h : env17665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17664_17665 : H12AffineEnvironment.transform 8 0 env17664 = env17665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17664 == env17665) = true)

theorem identity17665 : scanCanonicalize (H12AffineFastState.compose env17665 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound17665 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env17666 : List Nat := [2,4,8,16,1,17,8,4,0,20,1,16,9,0,1,3,17,1,21,0,1,0,17,3,9,17,0,17,16,1,20,0,5,1,0,0]

theorem envBound17666 : H12AffineFastState.Bounded env17666 := by
  intro p hp
  have h : env17666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17665_17666 : H12AffineEnvironment.transform 9 20 env17665 = env17666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env17665 == env17666) = true)

theorem identity17666 : scanCanonicalize (H12AffineFastState.compose env17666 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound17666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17667 : List Nat := [2,4,8,14,1,15,8,4,0,10,1,14,9,0,1,3,15,1,11,0,1,0,15,3,9,15,0,15,14,1,10,0,5,1,0,0]

theorem envBound17667 : H12AffineFastState.Bounded env17667 := by
  intro p hp
  have h : env17667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17666_17667 : H12AffineEnvironment.transform 3 14 env17666 = env17667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env17666 == env17667) = true)

def env17668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452753,144597,242969,8328,64,43357,139733,160197,324820,1500,272392,257,21792,46212,74251]

theorem envBound17668 : H12AffineFastState.Bounded env17668 := by
  intro p hp
  have h : env17668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17637_17668 : H12AffineEnvironment.transform 20 4161 env17637 = env17668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17637 == env17668) = true)

theorem identity17668 : scanCanonicalize (H12AffineFastState.compose env17668 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 13508) := by decide +kernel

theorem selectedBound17668 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,262144,1025,32769,4161,318549,17,98781,8328,64,43357,5393,17665,324820,1500,272392,257,21792,46212,74251]

theorem envBound17669 : H12AffineFastState.Bounded env17669 := by
  intro p hp
  have h : env17669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17668_17669 : H12AffineEnvironment.transform 16 13508 env17668 = env17669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env17668 == env17669) = true)

def env17670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,262144,1025,32769,4161,318549,17,98645,8192,64,43357,5393,17665,324700,1364,272392,257,21792,46092,74251]

theorem envBound17670 : H12AffineFastState.Bounded env17670 := by
  intro p hp
  have h : env17670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17669_17670 : H12AffineEnvironment.transform 6 8 env17669 = env17670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17669 == env17670) = true)

theorem identity17670 : scanCanonicalize (H12AffineFastState.compose env17670 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound17670 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13388,67619,1025,32769,4161,119926,17,98645,8192,64,43357,5393,17665,130175,1364,73771,257,21792,46092,74251]

theorem envBound17671 : H12AffineFastState.Bounded env17671 := by
  intro p hp
  have h : env17671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17670_17671 : H12AffineEnvironment.transform 17 67619 env17670 = env17671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env17670 == env17671) = true)

theorem identity17671 : scanCanonicalize (H12AffineFastState.compose env17671 (packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound17671 : packedSelected [1,2,3,6,8,14,15,16,19,23,24] rootPS < 2^1333 := by decide +kernel

def env17672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,21590,13388,23669,1025,32769,4161,32800,17,54531,8192,64,43357,5393,17665,43049,1364,29821,257,21792,46092,30301]

theorem envBound17672 : H12AffineFastState.Bounded env17672 := by
  intro p hp
  have h : env17672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17671_17672 : H12AffineEnvironment.transform 15 21590 env17671 = env17672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env17671 == env17672) = true)

theorem identity17672 : scanCanonicalize (H12AffineFastState.compose env17672 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17672 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env17673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,21590,5392,23669,1025,32769,4161,32800,17,54531,348,64,34817,5393,17665,35189,1364,21793,257,21792,38224,22273]

theorem envBound17673 : H12AffineFastState.Bounded env17673 := by
  intro p hp
  have h : env17673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17672_17673 : H12AffineEnvironment.transform 12 348 env17672 = env17673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17672 == env17673) = true)

theorem identity17673 : scanCanonicalize (H12AffineFastState.compose env17673 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound17673 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5457,32768,263,5392,2340,1025,32769,4161,32800,17,32850,348,64,34817,5393,4176,35189,1364,112,257,113,38224,592]

theorem envBound17674 : H12AffineFastState.Bounded env17674 := by
  intro p hp
  have h : env17674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17673_17674 : H12AffineEnvironment.transform 13 5457 env17673 = env17674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env17673 == env17674) = true)

theorem identity17674 : scanCanonicalize (H12AffineFastState.compose env17674 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17674 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env17675 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,32768,263,5392,2340,1025,32769,4113,32800,17,32770,268,16,34817,5393,4096,35109,1284,32,257,33,38144,512]

theorem envBound17675 : H12AffineFastState.Bounded env17675 := by
  intro p hp
  have h : env17675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17674_17675 : H12AffineEnvironment.transform 5 16 env17674 = env17675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17674 == env17675) = true)

theorem identity17675 : scanCanonicalize (H12AffineFastState.compose env17675 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound17675 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17676 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,33,263,5392,2340,1025,32,4113,1,17,35,268,16,2080,5393,4096,2308,1284,32,257,33,5409,512]

theorem envBound17676 : H12AffineFastState.Bounded env17676 := by
  intro p hp
  have h : env17676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17675_17676 : H12AffineEnvironment.transform 14 33 env17675 = env17676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env17675 == env17676) = true)

theorem identity17676 : scanCanonicalize (H12AffineFastState.compose env17676 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17676 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17677 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,33,34,5173,2049,1025,32,4113,1,17,35,41,16,2080,5172,4096,2081,1057,32,36,33,5124,512]

theorem envBound17677 : H12AffineFastState.Bounded env17677 := by
  intro p hp
  have h : env17677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17676_17677 : H12AffineEnvironment.transform 7 37 env17676 = env17677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17676 == env17677) = true)

theorem identity17677 : scanCanonicalize (H12AffineFastState.compose env17677 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound17677 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env17678 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1567,4096,41,5156,33,34,5173,1566,1025,32,4113,1,17,35,41,16,1599,5172,4096,1598,1057,32,36,33,5124,512]

theorem envBound17678 : H12AffineFastState.Bounded env17678 := by
  intro p hp
  have h : env17678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17677_17678 : H12AffineEnvironment.transform 10 1567 env17677 = env17678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env17677 == env17678) = true)

def env17679 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,262144,1025,32769,4161,318549,17,98644,8193,64,43357,5393,17665,324701,1365,272392,257,21792,46093,74251]

theorem envBound17679 : H12AffineFastState.Bounded env17679 := by
  intro p hp
  have h : env17679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17669_17679 : H12AffineEnvironment.transform 6 9 env17669 = env17679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17669 == env17679) = true)

theorem identity17679 : scanCanonicalize (H12AffineFastState.compose env17679 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 108926) := by decide +kernel

theorem selectedBound17679 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17680 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13389,108926,1025,32769,4161,95531,17,98644,8193,64,43357,5393,17665,89379,1365,98678,257,21792,46093,74251]

theorem envBound17680 : H12AffineFastState.Bounded env17680 := by
  intro p hp
  have h : env17680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17679_17680 : H12AffineEnvironment.transform 17 108926 env17679 = env17680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108926 env17679 == env17680) = true)

theorem identity17680 : scanCanonicalize (H12AffineFastState.compose env17680 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33031) := by decide +kernel

theorem selectedBound17680 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env17681 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33031,13389,10361,1025,32769,4161,62508,17,83,8193,64,43357,5393,17665,56356,1365,113,257,21792,46093,41740]

theorem envBound17681 : H12AffineFastState.Bounded env17681 := by
  intro p hp
  have h : env17681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17680_17681 : H12AffineEnvironment.transform 15 33031 env17680 = env17681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33031 env17680 == env17681) = true)

theorem identity17681 : scanCanonicalize (H12AffineFastState.compose env17681 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound17681 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env17682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,292,35,13389,10361,1025,293,4161,29960,17,83,8193,64,10361,5393,17665,23808,1365,113,257,21792,13609,8744]

theorem envBound17682 : H12AffineFastState.Bounded env17682 := by
  intro p hp
  have h : env17682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17681_17682 : H12AffineEnvironment.transform 14 292 env17681 = env17682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env17681 == env17682) = true)

theorem identity17682 : scanCanonicalize (H12AffineFastState.compose env17682 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound17682 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18,19,26] rootPS < 2^1333 := by decide +kernel

def env17683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,292,35,5221,2129,1025,293,4161,21792,17,83,41,64,2129,5393,17665,23808,1365,113,257,21792,5377,512]

theorem envBound17683 : H12AffineFastState.Bounded env17683 := by
  intro p hp
  have h : env17683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17682_17683 : H12AffineEnvironment.transform 12 40 env17682 = env17683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env17682 == env17683) = true)

theorem identity17683 : scanCanonicalize (H12AffineFastState.compose env17683 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound17683 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env17684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5456,292,35,5221,2129,1025,293,4161,112,17,83,41,64,2129,5393,4177,2128,1365,113,257,112,5377,512]

theorem envBound17684 : H12AffineFastState.Bounded env17684 := by
  intro p hp
  have h : env17684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17683_17684 : H12AffineEnvironment.transform 13 5456 env17683 = env17684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env17683 == env17684) = true)

theorem identity17684 : scanCanonicalize (H12AffineFastState.compose env17684 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound17684 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17685 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,40,5157,81,35,5221,2129,1025,80,4161,112,17,83,41,64,2129,5220,4177,2128,1056,113,116,112,5236,512]

theorem envBound17685 : H12AffineFastState.Bounded env17685 := by
  intro p hp
  have h : env17685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17684_17685 : H12AffineEnvironment.transform 7 117 env17684 = env17685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env17684 == env17685) = true)

theorem identity17685 : scanCanonicalize (H12AffineFastState.compose env17685 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17685 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17686 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,8,5125,81,3,5189,2129,1025,80,4161,80,17,83,9,64,2129,5188,4177,2128,1024,81,84,80,5204,512]

theorem envBound17686 : H12AffineFastState.Bounded env17686 := by
  intro p hp
  have h : env17686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17685_17686 : H12AffineEnvironment.transform 4 0 env17685 = env17686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17685 == env17686) = true)

theorem identity17686 : scanCanonicalize (H12AffineFastState.compose env17686 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 3157) := by decide +kernel

theorem selectedBound17686 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env17687 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,3157,8,2128,81,3,2064,2129,1025,80,3092,80,17,83,9,64,2129,2065,3076,2128,1024,81,84,80,2049,512]

theorem envBound17687 : H12AffineFastState.Bounded env17687 := by
  intro p hp
  have h : env17687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17686_17687 : H12AffineEnvironment.transform 11 3157 env17686 = env17687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env17686 == env17687) = true)

theorem identity17687 : scanCanonicalize (H12AffineFastState.compose env17687 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound17687 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17688 : List Nat := [2,4,8,16,0,64,9,85,512,1024,81,1028,8,1,81,3,65,0,1025,80,1093,80,17,83,9,64,0,64,1109,1,1024,81,84,80,80,512]

theorem envBound17688 : H12AffineFastState.Bounded env17688 := by
  intro p hp
  have h : env17688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17687_17688 : H12AffineEnvironment.transform 10 81 env17687 = env17688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env17687 == env17688) = true)

theorem identity17688 : scanCanonicalize (H12AffineFastState.compose env17688 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17688 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env17689 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1,1028,8,1,1,3,17,0,1025,0,1045,0,17,3,9,16,0,16,1029,1,1024,1,4,0,0,512]

theorem envBound17689 : H12AffineFastState.Bounded env17689 := by
  intro p hp
  have h : env17689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17688_17689 : H12AffineEnvironment.transform 5 16 env17688 = env17689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17688 == env17689) = true)

theorem identity17689 : scanCanonicalize (H12AffineFastState.compose env17689 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound17689 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17690 : List Nat := [2,4,8,16,0,16,9,5,512,517,1,513,8,1,1,3,17,0,516,0,528,0,17,3,9,16,0,16,512,1,517,1,4,0,0,512]

theorem envBound17690 : H12AffineFastState.Bounded env17690 := by
  intro p hp
  have h : env17690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17689_17690 : H12AffineEnvironment.transform 9 517 env17689 = env17690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env17689 == env17690) = true)

theorem identity17690 : scanCanonicalize (H12AffineFastState.compose env17690 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17690 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17691 : List Nat := [2,4,8,16,0,16,9,5,1,4,1,0,8,1,1,3,17,0,5,0,17,0,17,3,9,16,0,16,1,1,4,1,4,0,0,1]

theorem envBound17691 : H12AffineFastState.Bounded env17691 := by
  intro p hp
  have h : env17691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17690_17691 : H12AffineEnvironment.transform 8 1 env17690 = env17691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17690 == env17691) = true)

def env17692 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265169,145662400,525568,140903597,27337993,25733062]

theorem envBound17692 : H12AffineFastState.Bounded env17692 := by
  intro p hp
  have h : env17692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17010_17692 : H12AffineEnvironment.transform 25 65 env17010 = env17692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env17010 == env17692) = true)

def env17693 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound17693 : H12AffineFastState.Bounded env17693 := by
  intro p hp
  have h : env17693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17692_17693 : H12AffineEnvironment.transform 26 30393344 env17692 = env17693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env17692 == env17693) = true)

def env17694 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound17694 : H12AffineFastState.Bounded env17694 := by
  intro p hp
  have h : env17694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17693_17694 : H12AffineEnvironment.transform 18 1024 env17693 = env17694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env17693 == env17694) = true)

theorem identity17694 : scanCanonicalize (H12AffineFastState.compose env17694 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874484) := by decide +kernel

theorem selectedBound17694 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17695 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874484,8328,65,4237812,10939768,10507600,8830977,454117,15076404,256,2534745,2510077,510514]

theorem envBound17695 : H12AffineFastState.Bounded env17695 := by
  intro p hp
  have h : env17695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17694_17695 : H12AffineEnvironment.transform 23 8874484 env17694 = env17695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874484 env17694 == env17695) = true)

def env17696 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,8388608,8874484,8328,65,4237812,8393984,8826152,8830977,454117,12645452,256,21793,46213,510514]

theorem envBound17696 : H12AffineFastState.Bounded env17696 := by
  intro p hp
  have h : env17696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17695_17696 : H12AffineEnvironment.transform 20 456824 env17695 = env17696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env17695 == env17696) = true)

def env17697 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,98780,8328,65,4237812,458024,17664,10281,454117,4594788,256,21793,46213,510514]

theorem envBound17697 : H12AffineFastState.Bounded env17697 := by
  intro p hp
  have h : env17697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17696_17697 : H12AffineEnvironment.transform 22 452648 env17696 = env17697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env17696 == env17697) = true)

def env17698 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,98780,8328,65,295284,458024,17664,10281,454117,144612,256,21793,46213,510514]

theorem envBound17698 : H12AffineFastState.Bounded env17698 := by
  intro p hp
  have h : env17698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17697_17698 : H12AffineEnvironment.transform 21 272512 env17697 = env17698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17697 == env17698) = true)

theorem identity17698 : scanCanonicalize (H12AffineFastState.compose env17698 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound17698 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17699 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,396460,272512,400636,95496,8328,65,292256,395772,17664,10281,399665,144612,256,21793,16465,474854]

theorem envBound17699 : H12AffineFastState.Bounded env17699 := by
  intro p hp
  have h : env17699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17698_17699 : H12AffineEnvironment.transform 14 29908 env17698 = env17699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env17698 == env17699) = true)

def env17700 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10400,1024,29909,140300,32,144476,95496,8328,65,23808,139612,17664,10281,143761,144612,256,21793,16465,202310]

theorem envBound17700 : H12AffineFastState.Bounded env17700 := by
  intro p hp
  have h : env17700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17699_17700 : H12AffineEnvironment.transform 17 10400 env17699 = env17700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env17699 == env17700) = true)

theorem identity17700 : scanCanonicalize (H12AffineFastState.compose env17700 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound17700 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env17701 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,5529,10400,1024,29909,12693,32,8645,95496,8328,65,23808,13509,17664,10281,9224,8573,256,21793,16465,66527]

theorem envBound17701 : H12AffineFastState.Bounded env17701 := by
  intro p hp
  have h : env17701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17700_17701 : H12AffineEnvironment.transform 16 5529 env17700 = env17701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env17700 == env17701) = true)

theorem identity17701 : scanCanonicalize (H12AffineFastState.compose env17701 (packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound17701 : packedSelected [0,3,5,8,9,10,17,18,19,22,23,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env17702 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8581,65536,5529,10400,1024,8580,12693,32,8645,73817,8328,65,2129,13509,4177,10281,9224,8573,256,112,5376,66527]

theorem envBound17702 : H12AffineFastState.Bounded env17702 := by
  intro p hp
  have h : env17702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17701_17702 : H12AffineEnvironment.transform 13 5457 env17701 = env17702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env17701 == env17702) = true)

theorem identity17702 : scanCanonicalize (H12AffineFastState.compose env17702 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound17702 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env17703 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8581,343,5529,10400,1024,8580,12693,32,8645,8462,8328,65,2129,13509,4177,10281,9224,8573,256,112,5376,648]

theorem envBound17703 : H12AffineFastState.Bounded env17703 := by
  intro p hp
  have h : env17703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17702_17703 : H12AffineEnvironment.transform 15 343 env17702 = env17703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env17702 == env17703) = true)

theorem identity17703 : scanCanonicalize (H12AffineFastState.compose env17703 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound17703 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env17704 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,41,5457,428,343,5529,2185,1024,429,4540,32,492,295,161,65,2129,5356,4177,2048,1057,340,256,112,5376,648]

theorem envBound17704 : H12AffineFastState.Bounded env17704 := by
  intro p hp
  have h : env17704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17703_17704 : H12AffineEnvironment.transform 12 41 env17703 = env17704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env17703 == env17704) = true)

theorem identity17704 : scanCanonicalize (H12AffineFastState.compose env17704 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound17704 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env17705 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,41,4113,428,343,4313,2185,320,429,4540,32,492,295,161,65,2129,4524,4177,2048,353,340,256,112,4160,648]

theorem envBound17705 : H12AffineFastState.Bounded env17705 := by
  intro p hp
  have h : env17705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17704_17705 : H12AffineEnvironment.transform 9 320 env17704 = env17705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env17704 == env17705) = true)

theorem identity17705 : scanCanonicalize (H12AffineFastState.compose env17705 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound17705 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env17706 : List Nat := [2,4,8,16,32,64,128,116,512,52,2048,4096,41,4113,216,35,4313,2185,52,217,4296,32,152,83,161,65,2129,4312,4177,2048,21,32,116,112,4160,648]

theorem envBound17706 : H12AffineFastState.Bounded env17706 := by
  intro p hp
  have h : env17706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17705_17706 : H12AffineEnvironment.transform 7 116 env17705 = env17706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env17705 == env17706) = true)

theorem identity17706 : scanCanonicalize (H12AffineFastState.compose env17706 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound17706 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17707 : List Nat := [2,4,8,16,32,64,41,116,512,52,2048,4096,41,4113,113,35,4208,2080,52,112,4193,32,49,83,8,65,2129,4209,4177,2048,21,32,116,112,4160,545]

theorem envBound17707 : H12AffineFastState.Bounded env17707 := by
  intro p hp
  have h : env17707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17706_17707 : H12AffineEnvironment.transform 6 41 env17706 = env17707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env17706 == env17707) = true)

theorem identity17707 : scanCanonicalize (H12AffineFastState.compose env17707 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound17707 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env17708 : List Nat := [2,4,8,16,32,64,41,116,512,52,2048,529,41,512,113,35,609,2080,52,112,624,32,49,83,8,65,2129,608,576,2048,21,32,116,112,593,545]

theorem envBound17708 : H12AffineFastState.Bounded env17708 := by
  intro p hp
  have h : env17708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17707_17708 : H12AffineEnvironment.transform 11 529 env17707 = env17708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env17707 == env17708) = true)

theorem identity17708 : scanCanonicalize (H12AffineFastState.compose env17708 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound17708 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env17709 : List Nat := [2,4,8,16,32,64,41,116,512,52,528,529,41,512,113,35,609,560,52,112,624,32,49,83,8,65,577,608,576,528,21,32,116,112,593,545]

theorem envBound17709 : H12AffineFastState.Bounded env17709 := by
  intro p hp
  have h : env17709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17708_17709 : H12AffineEnvironment.transform 10 528 env17708 = env17709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env17708 == env17709) = true)

theorem identity17709 : scanCanonicalize (H12AffineFastState.compose env17709 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17709 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env17710 : List Nat := [2,4,8,16,1,64,8,85,512,21,528,529,8,512,80,2,576,529,21,81,593,1,16,83,8,65,577,577,576,528,21,1,85,81,593,512]

theorem envBound17710 : H12AffineFastState.Bounded env17710 := by
  intro p hp
  have h : env17710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17709_17710 : H12AffineEnvironment.transform 4 1 env17709 = env17710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17709 == env17710) = true)

theorem identity17710 : scanCanonicalize (H12AffineFastState.compose env17710 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17710 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17711 : List Nat := [2,4,8,16,1,17,8,4,512,21,528,529,8,512,1,2,529,529,21,0,512,1,16,2,8,16,528,528,529,528,21,1,4,0,512,512]

theorem envBound17711 : H12AffineFastState.Bounded env17711 := by
  intro p hp
  have h : env17711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17710_17711 : H12AffineEnvironment.transform 5 17 env17710 = env17711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17710 == env17711) = true)

theorem identity17711 : scanCanonicalize (H12AffineFastState.compose env17711 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound17711 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17712 : List Nat := [2,4,8,16,1,17,8,4,21,21,5,4,8,21,1,2,4,4,21,0,21,1,16,2,8,16,5,5,4,5,21,1,4,0,21,21]

theorem envBound17712 : H12AffineFastState.Bounded env17712 := by
  intro p hp
  have h : env17712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17711_17712 : H12AffineEnvironment.transform 8 21 env17711 = env17712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env17711 == env17712) = true)

theorem identity17712 : scanCanonicalize (H12AffineFastState.compose env17712 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound17712 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17713 : List Nat := [2,4,0,16,1,17,0,4,21,21,5,4,0,21,1,2,4,4,21,0,21,1,16,2,0,16,5,5,4,5,21,1,4,0,21,21]

theorem envBound17713 : H12AffineFastState.Bounded env17713 := by
  intro p hp
  have h : env17713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17712_17713 : H12AffineEnvironment.transform 2 0 env17712 = env17713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env17712 == env17713) = true)

theorem identity17713 : scanCanonicalize (H12AffineFastState.compose env17713 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17713 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17714 : List Nat := [2,4,0,1,1,0,0,4,4,4,5,4,0,4,1,2,4,4,4,0,4,1,1,2,0,1,5,5,4,5,4,1,4,0,4,4]

theorem envBound17714 : H12AffineFastState.Bounded env17714 := by
  intro p hp
  have h : env17714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17713_17714 : H12AffineEnvironment.transform 3 1 env17713 = env17714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17713 == env17714) = true)

theorem identity17714 : scanCanonicalize (H12AffineFastState.compose env17714 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound17714 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env17715 : List Nat := [0,4,0,1,1,0,0,4,4,4,5,4,0,4,1,0,4,4,4,0,4,1,1,0,0,1,5,5,4,5,4,1,4,0,4,4]

theorem envBound17715 : H12AffineFastState.Bounded env17715 := by
  intro p hp
  have h : env17715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17714_17715 : H12AffineEnvironment.transform 0 0 env17714 = env17715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env17714 == env17715) = true)

def env17716 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140301,33,144477,95496,8328,65,23809,139613,17664,10281,143760,144612,256,21793,16465,202311]

theorem envBound17716 : H12AffineFastState.Bounded env17716 := by
  intro p hp
  have h : env17716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17699_17716 : H12AffineEnvironment.transform 17 10401 env17699 = env17716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env17699 == env17716) = true)

theorem identity17716 : scanCanonicalize (H12AffineFastState.compose env17716 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound17716 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env17717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,65536,131072,10401,1024,136,140301,33,144477,65877,8328,65,10588,139613,12637,10281,143760,144612,256,8572,13324,202311]

theorem envBound17717 : H12AffineFastState.Bounded env17717 := by
  intro p hp
  have h : env17717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17716_17717 : H12AffineEnvironment.transform 13 13405 env17716 = env17717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env17716 == env17717) = true)

theorem identity17717 : scanCanonicalize (H12AffineFastState.compose env17717 (packedSelected [0,4,7,11,18,22,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound17717 : packedSelected [0,4,7,11,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env17718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,65536,70726,10401,1024,136,77899,33,73755,65877,8328,65,10588,79131,12637,10281,75222,73890,256,8572,13324,513]

theorem envBound17718 : H12AffineFastState.Bounded env17718 := by
  intro p hp
  have h : env17718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17717_17718 : H12AffineEnvironment.transform 16 70726 env17717 = env17718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env17717 == env17718) = true)

theorem identity17718 : scanCanonicalize (H12AffineFastState.compose env17718 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17718 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17719 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,137,65536,70679,10401,1024,136,77850,33,73755,65796,8328,16,10509,79131,12556,10281,75143,73890,256,8493,13324,513]

theorem envBound17719 : H12AffineFastState.Bounded env17719 := by
  intro p hp
  have h : env17719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17718_17719 : H12AffineEnvironment.transform 5 17 env17718 = env17719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17718 == env17719) = true)

theorem identity17719 : scanCanonicalize (H12AffineFastState.compose env17719 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound17719 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env17720 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,137,399,5528,10401,1024,136,12693,33,8596,139,8328,16,10509,13460,12556,10281,9224,8493,256,8493,13324,513]

theorem envBound17720 : H12AffineFastState.Bounded env17720 := by
  intro p hp
  have h : env17720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17719_17720 : H12AffineEnvironment.transform 15 399 env17719 = env17720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env17719 == env17720) = true)

theorem identity17720 : scanCanonicalize (H12AffineFastState.compose env17720 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17720 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env17721 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,13324,1,263,5392,10281,1024,0,12573,33,8476,3,8192,16,10509,13340,12556,10281,9224,8493,256,8493,13324,513]

theorem envBound17721 : H12AffineFastState.Bounded env17721 := by
  intro p hp
  have h : env17721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17720_17721 : H12AffineEnvironment.transform 6 8 env17720 = env17721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17720 == env17721) = true)

def env17722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,98780,8328,65,295285,458024,17664,10281,454117,144613,256,21793,46213,510514]

theorem envBound17722 : H12AffineFastState.Bounded env17722 := by
  intro p hp
  have h : env17722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17697_17722 : H12AffineEnvironment.transform 21 272513 env17697 = env17722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17697 == env17722) = true)

theorem identity17722 : scanCanonicalize (H12AffineFastState.compose env17722 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound17722 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,58516,144493,62660,98780,8328,65,171417,57796,17664,10281,61705,144613,256,21793,46213,120542]

theorem envBound17723 : H12AffineFastState.Bounded env17723 := by
  intro p hp
  have h : env17723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17722_17723 : H12AffineEnvironment.transform 17 138476 env17722 = env17723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env17722 == env17723) = true)

def env17724 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58396,144493,62540,98644,8192,65,171281,57676,17664,10281,61705,144493,256,21793,46093,120406]

theorem envBound17724 : H12AffineFastState.Bounded env17724 := by
  intro p hp
  have h : env17724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17723_17724 : H12AffineEnvironment.transform 6 8 env17723 = env17724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17723 == env17724) = true)

theorem identity17724 : scanCanonicalize (H12AffineFastState.compose env17724 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17724 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env17725 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,138340,1024,32769,45340,144493,41292,98644,8192,65,171281,46156,4096,10281,41993,144493,256,33,46093,99158]

theorem envBound17725 : H12AffineFastState.Bounded env17725 := by
  intro p hp
  have h : env17725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17724_17725 : H12AffineEnvironment.transform 13 5376 env17724 = env17725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17724 == env17725) = true)

theorem identity17725 : scanCanonicalize (H12AffineFastState.compose env17725 (packedSelected [1,3,16,17,18,20,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 41051) := by decide +kernel

theorem selectedBound17725 : packedSelected [1,3,16,17,18,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env17726 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,41051,131072,138340,1024,32769,45340,144493,41292,8463,8192,65,171281,46156,4096,10281,41993,144493,256,33,46093,8973]

theorem envBound17726 : H12AffineFastState.Bounded env17726 := by
  intro p hp
  have h : env17726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17725_17726 : H12AffineEnvironment.transform 15 41051 env17725 = env17726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41051 env17725 == env17726) = true)

theorem identity17726 : scanCanonicalize (H12AffineFastState.compose env17726 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound17726 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env17727 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8461,342,131072,138340,1024,8460,4113,144493,65,8463,8192,65,146460,5441,4096,10281,1284,144493,256,33,5376,8973]

theorem envBound17727 : H12AffineFastState.Bounded env17727 := by
  intro p hp
  have h : env17727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17726_17727 : H12AffineEnvironment.transform 14 8461 env17726 = env17727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env17726 == env17727) = true)

theorem identity17727 : scanCanonicalize (H12AffineFastState.compose env17727 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17727 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env17728 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,8461,263,131072,138293,1024,8460,4113,144444,16,8463,8192,16,146460,5392,4096,10281,1284,144444,256,33,5376,8973]

theorem envBound17728 : H12AffineFastState.Bounded env17728 := by
  intro p hp
  have h : env17728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17727_17728 : H12AffineEnvironment.transform 5 17 env17727 = env17728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17727 == env17728) = true)

theorem identity17728 : scanCanonicalize (H12AffineFastState.compose env17728 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17728 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17729 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,8192,5376,8461,263,131072,138261,1024,8460,4113,144412,16,8463,8192,16,146460,5392,4096,10249,1284,144412,256,1,5376,8973]

theorem envBound17729 : H12AffineFastState.Bounded env17729 := by
  intro p hp
  have h : env17729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17728_17729 : H12AffineEnvironment.transform 4 0 env17728 = env17729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17728 == env17729) = true)

def env17730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58397,144493,62541,98645,8193,65,171280,57677,17664,10281,61705,144492,256,21793,46092,120407]

theorem envBound17730 : H12AffineFastState.Bounded env17730 := by
  intro p hp
  have h : env17730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17723_17730 : H12AffineEnvironment.transform 6 9 env17723 = env17730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17723 == env17730) = true)

theorem identity17730 : scanCanonicalize (H12AffineFastState.compose env17730 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound17730 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env17731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,115,131072,138341,1024,32769,58397,144493,62541,33062,8193,65,171280,57677,17664,10281,61705,144492,256,21793,46092,54820]

theorem envBound17731 : H12AffineFastState.Bounded env17731 := by
  intro p hp
  have h : env17731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17730_17731 : H12AffineEnvironment.transform 15 115 env17730 = env17731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env17730 == env17731) = true)

theorem identity17731 : scanCanonicalize (H12AffineFastState.compose env17731 (packedSelected [0,4,11,14,16,22,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound17731 : packedSelected [0,4,11,14,16,22,27,32] rootPS < 2^1333 := by decide +kernel

def env17732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,115,131072,138341,1024,29708,4112,144493,64,29995,8193,65,157981,5440,17664,10281,1284,144492,256,21793,16385,8745]

theorem envBound17732 : H12AffineFastState.Bounded env17732 := by
  intro p hp
  have h : env17732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17731_17732 : H12AffineEnvironment.transform 14 29709 env17731 = env17732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env17731 == env17732) = true)

theorem identity17732 : scanCanonicalize (H12AffineFastState.compose env17732 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound17732 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env17733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,115,5441,2340,1024,29708,4112,8492,64,29995,8193,65,31836,5440,17664,10281,1284,8493,256,21793,16385,8745]

theorem envBound17733 : H12AffineFastState.Bounded env17733 := by
  intro p hp
  have h : env17733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17732_17733 : H12AffineEnvironment.transform 16 5441 env17732 = env17733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env17732 == env17733) = true)

theorem identity17733 : scanCanonicalize (H12AffineFastState.compose env17733 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17733 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env17734 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29709,34,5392,2340,1024,29708,4112,8492,17,29995,8193,16,31757,5393,17664,10281,1284,8493,256,21793,16385,8745]

theorem envBound17734 : H12AffineFastState.Bounded env17734 := by
  intro p hp
  have h : env17734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17733_17734 : H12AffineEnvironment.transform 5 17 env17733 = env17734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17733 == env17734) = true)

theorem identity17734 : scanCanonicalize (H12AffineFastState.compose env17734 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound17734 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env17735 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,34,5392,2340,1024,21760,4112,32,17,21543,269,16,23809,5393,17664,2341,1284,33,256,21793,16385,805]

theorem envBound17735 : H12AffineFastState.Bounded env17735 := by
  intro p hp
  have h : env17735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17734_17735 : H12AffineEnvironment.transform 12 268 env17734 = env17735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env17734 == env17735) = true)

theorem identity17735 : scanCanonicalize (H12AffineFastState.compose env17735 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound17735 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env17736 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,4113,1296,34,5392,2340,1024,1297,4112,32,17,1078,269,16,3344,5393,5393,2341,1284,33,256,1328,4112,805]

theorem envBound17736 : H12AffineFastState.Bounded env17736 := by
  intro p hp
  have h : env17736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17735_17736 : H12AffineEnvironment.transform 13 4113 env17735 = env17736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env17735 == env17736) = true)

theorem identity17736 : scanCanonicalize (H12AffineFastState.compose env17736 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17736 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17737 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,40,4113,1076,34,5172,2048,1024,1077,4112,32,17,1078,41,16,3124,5173,5173,2049,1056,33,36,1044,4112,513]

theorem envBound17737 : H12AffineFastState.Bounded env17737 := by
  intro p hp
  have h : env17737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17736_17737 : H12AffineEnvironment.transform 7 36 env17736 = env17737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17736 == env17737) = true)

def env17738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,98781,8328,65,4237812,458025,17665,10280,454117,4594789,256,21793,46213,510514]

theorem envBound17738 : H12AffineFastState.Bounded env17738 := by
  intro p hp
  have h : env17738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17696_17738 : H12AffineEnvironment.transform 22 452649 env17696 = env17738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env17696 == env17738) = true)

def env17739 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,98781,8328,65,295284,458025,17665,10280,454117,144613,256,21793,46213,510514]

theorem envBound17739 : H12AffineFastState.Bounded env17739 := by
  intro p hp
  have h : env17739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17738_17739 : H12AffineEnvironment.transform 21 272512 env17738 = env17739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17738 == env17739) = true)

def env17740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452649,98645,8192,65,295284,458025,17665,10280,453997,144493,256,21793,46093,510514]

theorem envBound17740 : H12AffineFastState.Bounded env17740 := by
  intro p hp
  have h : env17740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17739_17740 : H12AffineEnvironment.transform 6 8 env17739 = env17740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17739 == env17740) = true)

theorem identity17740 : scanCanonicalize (H12AffineFastState.compose env17740 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound17740 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77899,254011,73754,98645,8192,65,215367,79130,17665,10280,75102,144493,256,21793,46093,513]

theorem envBound17741 : H12AffineFastState.Bounded env17741 := by
  intro p hp
  have h : env17741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17740_17741 : H12AffineEnvironment.transform 17 247859 env17740 = env17741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env17740 == env17741) = true)

theorem identity17741 : scanCanonicalize (H12AffineFastState.compose env17741 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound17741 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env17742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,77899,33,73754,98645,8192,65,43357,79130,17665,10280,75102,119927,256,21793,46093,513]

theorem envBound17742 : H12AffineFastState.Bounded env17742 := by
  intro p hp
  have h : env17742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17741_17742 : H12AffineEnvironment.transform 16 122906 env17741 = env17742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env17741 == env17742) = true)

theorem identity17742 : scanCanonicalize (H12AffineFastState.compose env17742 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17742 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env17743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,10281,1024,32769,4161,33,16,41311,8192,65,43357,5392,17665,10280,1364,62589,256,21793,46093,513]

theorem envBound17743 : H12AffineFastState.Bounded env17743 := by
  intro p hp
  have h : env17743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17742_17743 : H12AffineEnvironment.transform 15 8202 env17742 = env17743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17742 == env17743) = true)

theorem identity17743 : scanCanonicalize (H12AffineFastState.compose env17743 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17743 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env17744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,263,49168,2340,1024,32769,4161,33,16,32850,269,65,34896,5392,17665,2341,1364,54640,256,21793,38144,513]

theorem envBound17744 : H12AffineFastState.Bounded env17744 := by
  intro p hp
  have h : env17744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17743_17744 : H12AffineEnvironment.transform 12 269 env17743 = env17744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17743 == env17744) = true)

theorem identity17744 : scanCanonicalize (H12AffineFastState.compose env17744 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound17744 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env17745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,32768,263,38208,2340,1024,32769,4161,33,16,32850,269,65,34896,5392,4177,2341,1364,32800,256,113,38144,513]

theorem envBound17745 : H12AffineFastState.Bounded env17745 := by
  intro p hp
  have h : env17745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17744_17745 : H12AffineEnvironment.transform 13 5456 env17744 = env17745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env17744 == env17745) = true)

theorem identity17745 : scanCanonicalize (H12AffineFastState.compose env17745 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound17745 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5456,80,263,5392,2340,1024,81,4161,33,16,2,269,65,2048,5392,4177,2341,1364,112,256,113,5456,513]

theorem envBound17746 : H12AffineFastState.Bounded env17746 := by
  intro p hp
  have h : env17746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17745_17746 : H12AffineEnvironment.transform 14 80 env17745 = env17746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env17745 == env17746) = true)

theorem identity17746 : scanCanonicalize (H12AffineFastState.compose env17746 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2145) := by decide +kernel

theorem selectedBound17746 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env17747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2145,269,3377,80,263,3441,2340,1024,81,2080,33,16,2,269,65,2048,3441,2096,2341,1364,112,256,113,3377,513]

theorem envBound17747 : H12AffineFastState.Bounded env17747 := by
  intro p hp
  have h : env17747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17746_17747 : H12AffineEnvironment.transform 11 2145 env17746 = env17747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2145 env17746 == env17747) = true)

theorem identity17747 : scanCanonicalize (H12AffineFastState.compose env17747 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound17747 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env17748 : List Nat := [2,4,8,16,32,64,8,256,512,304,2048,2145,269,2049,80,263,2113,2340,304,81,2080,33,16,2,269,65,2048,2113,2096,2341,100,112,256,113,2049,513]

theorem envBound17748 : H12AffineFastState.Bounded env17748 := by
  intro p hp
  have h : env17748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17747_17748 : H12AffineEnvironment.transform 9 304 env17747 = env17748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env17747 == env17748) = true)

theorem identity17748 : scanCanonicalize (H12AffineFastState.compose env17748 (packedSelected [4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17748 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env17749 : List Nat := [2,4,8,16,1,64,8,256,512,273,2048,2112,269,2049,80,263,2113,2309,273,81,2049,0,16,2,269,65,2048,2113,2065,2308,69,81,256,80,2049,513]

theorem envBound17749 : H12AffineFastState.Bounded env17749 := by
  intro p hp
  have h : env17749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17748_17749 : H12AffineEnvironment.transform 4 1 env17748 = env17749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17748 == env17749) = true)

theorem identity17749 : scanCanonicalize (H12AffineFastState.compose env17749 (packedSelected [3,5,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17749 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env17750 : List Nat := [2,4,8,16,1,17,8,256,512,273,2048,2065,269,2049,1,263,2064,2309,273,0,2049,0,16,2,269,16,2048,2064,2065,2308,20,0,256,1,2049,513]

theorem envBound17750 : H12AffineFastState.Bounded env17750 := by
  intro p hp
  have h : env17750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17749_17750 : H12AffineEnvironment.transform 5 17 env17749 = env17750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17749 == env17750) = true)

theorem identity17750 : scanCanonicalize (H12AffineFastState.compose env17750 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound17750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17751 : List Nat := [2,4,8,16,1,17,8,256,512,273,260,277,269,261,1,263,276,1,273,0,261,0,16,2,269,16,260,276,277,0,20,0,256,1,261,513]

theorem envBound17751 : H12AffineFastState.Bounded env17751 := by
  intro p hp
  have h : env17751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17750_17751 : H12AffineEnvironment.transform 10 260 env17750 = env17751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env17750 == env17751) = true)

def env17752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272393,452649,98644,8193,65,295284,458025,17665,10280,453996,144492,256,21793,46092,510514]

theorem envBound17752 : H12AffineFastState.Bounded env17752 := by
  intro p hp
  have h : env17752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17739_17752 : H12AffineEnvironment.transform 6 9 env17739 = env17752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17739 == env17752) = true)

theorem identity17752 : scanCanonicalize (H12AffineFastState.compose env17752 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound17752 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env17753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,309352,272393,305209,98644,8193,65,295284,310585,17665,10280,306556,29820,256,21793,46092,363042]

theorem envBound17753 : H12AffineFastState.Bounded env17753 := by
  intro p hp
  have h : env17753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17752_17753 : H12AffineEnvironment.transform 16 16400 env17752 = env17753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17752 == env17753) = true)

theorem identity17753 : scanCanonicalize (H12AffineFastState.compose env17753 (packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS)) = affineNative (2^(17+1) ^^^ 100386) := by decide +kernel

theorem selectedBound17753 : packedSelected [0,3,4,7,10,11,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env17754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100386,1024,32769,77898,106539,73755,98644,8193,65,67926,79131,17665,10280,75102,29820,256,21793,46092,512]

theorem envBound17754 : H12AffineFastState.Bounded env17754 := by
  intro p hp
  have h : env17754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17753_17754 : H12AffineEnvironment.transform 17 100386 env17753 = env17754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100386 env17753 == env17754) = true)

theorem identity17754 : scanCanonicalize (H12AffineFastState.compose env17754 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound17754 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,65536,13625,100386,1024,32769,77898,106539,73755,98644,8193,65,67926,79131,12328,10280,75102,341,256,8200,46092,512]

theorem envBound17755 : H12AffineFastState.Bounded env17755 := by
  intro p hp
  have h : env17755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17754_17755 : H12AffineEnvironment.transform 13 13609 env17754 = env17755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env17754 == env17755) = true)

theorem identity17755 : scanCanonicalize (H12AffineFastState.compose env17755 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound17755 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env17756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,8201,65536,13625,75819,1024,8200,77898,65570,73755,74077,8193,65,67926,79131,12328,10280,75102,341,256,8200,5125,512]

theorem envBound17756 : H12AffineFastState.Bounded env17756 := by
  intro p hp
  have h : env17756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17755_17756 : H12AffineEnvironment.transform 14 8201 env17755 = env17756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env17755 == env17756) = true)

theorem identity17756 : scanCanonicalize (H12AffineFastState.compose env17756 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound17756 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env17757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,341,65536,5221,67959,1024,340,69910,65570,65863,65537,349,65,67926,70727,4468,2420,66562,341,256,340,5125,512]

theorem envBound17757 : H12AffineFastState.Bounded env17757 := by
  intro p hp
  have h : env17757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17756_17757 : H12AffineEnvironment.transform 12 348 env17756 = env17757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env17756 == env17757) = true)

theorem identity17757 : scanCanonicalize (H12AffineFastState.compose env17757 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound17757 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5237,341,115,5221,2308,1024,340,4453,81,308,114,349,65,2341,5172,4468,2420,1137,341,256,340,5125,512]

theorem envBound17758 : H12AffineFastState.Bounded env17758 := by
  intro p hp
  have h : env17758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17757_17758 : H12AffineEnvironment.transform 15 115 env17757 = env17758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env17757 == env17758) = true)

theorem identity17758 : scanCanonicalize (H12AffineFastState.compose env17758 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound17758 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env17759 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,301,5124,292,2,5140,2308,1024,293,4372,32,308,3,300,48,2341,5172,4357,2309,1024,292,256,293,5125,512]

theorem envBound17759 : H12AffineFastState.Bounded env17759 := by
  intro p hp
  have h : env17759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17758_17759 : H12AffineEnvironment.transform 5 49 env17758 = env17759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env17758 == env17759) = true)

theorem identity17759 : scanCanonicalize (H12AffineFastState.compose env17759 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound17759 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env17760 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,41,5124,32,2,5140,2048,1024,33,4112,32,48,3,40,48,2081,5172,4097,2049,1024,32,4,33,5125,512]

theorem envBound17760 : H12AffineFastState.Bounded env17760 := by
  intro p hp
  have h : env17760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17759_17760 : H12AffineEnvironment.transform 7 4 env17759 = env17760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env17759 == env17760) = true)

theorem identity17760 : scanCanonicalize (H12AffineFastState.compose env17760 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound17760 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17761 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,0,2,5140,2048,1024,1,4112,0,16,3,8,16,2049,5140,4097,2049,1024,0,4,1,5125,512]

theorem envBound17761 : H12AffineFastState.Bounded env17761 := by
  intro p hp
  have h : env17761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17760_17761 : H12AffineEnvironment.transform 4 0 env17760 = env17761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env17760 == env17761) = true)

theorem identity17761 : scanCanonicalize (H12AffineFastState.compose env17761 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound17761 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17762 : List Nat := [2,4,8,16,0,17,9,4,512,1024,523,4096,9,5124,0,2,5140,523,1024,1,4112,0,16,3,8,16,522,5140,4097,522,1024,0,4,1,5125,512]

theorem envBound17762 : H12AffineFastState.Bounded env17762 := by
  intro p hp
  have h : env17762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17761_17762 : H12AffineEnvironment.transform 10 523 env17761 = env17762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env17761 == env17762) = true)

def env17763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,98781,8328,65,295285,458025,17665,10280,454117,144612,256,21793,46213,510514]

theorem envBound17763 : H12AffineFastState.Bounded env17763 := by
  intro p hp
  have h : env17763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17738_17763 : H12AffineEnvironment.transform 21 272513 env17738 = env17763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17738 == env17763) = true)

theorem identity17763 : scanCanonicalize (H12AffineFastState.compose env17763 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190521) := by decide +kernel

theorem selectedBound17763 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17764 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,180408,16,98781,8328,65,158028,5392,17665,10280,1500,144612,256,21793,46213,74251]

theorem envBound17764 : H12AffineFastState.Bounded env17764 := by
  intro p hp
  have h : env17764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17763_17764 : H12AffineEnvironment.transform 17 190521 env17763 = env17764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190521 env17763 == env17764) = true)

theorem identity17764 : scanCanonicalize (H12AffineFastState.compose env17764 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17764 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env17765 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4161,180408,16,41431,8328,65,158028,5392,17665,10280,1500,144612,256,21793,46213,513]

theorem envBound17765 : H12AffineFastState.Bounded env17765 := by
  intro p hp
  have h : env17765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17764_17765 : H12AffineEnvironment.transform 15 8202 env17764 = env17765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17764 == env17765) = true)

theorem identity17765 : scanCanonicalize (H12AffineFastState.compose env17765 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound17765 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43049,1024,32769,4161,32936,16,41431,8328,65,10588,5392,17665,10280,1500,29940,256,21793,46213,513]

theorem envBound17766 : H12AffineFastState.Bounded env17766 := by
  intro p hp
  have h : env17766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17765_17766 : H12AffineEnvironment.transform 16 16400 env17765 = env17766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17765 == env17766) = true)

theorem identity17766 : scanCanonicalize (H12AffineFastState.compose env17766 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound17766 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env17767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,8202,13508,43049,1024,32769,4161,32936,16,41431,8328,65,10588,5392,12757,10280,1500,32,256,8693,46213,513]

theorem envBound17767 : H12AffineFastState.Bounded env17767 := by
  intro p hp
  have h : env17767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17766_17767 : H12AffineEnvironment.transform 13 13524 env17766 = env17767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env17766 == env17767) = true)

theorem identity17767 : scanCanonicalize (H12AffineFastState.compose env17767 (packedSelected [2,6,17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17767 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env17768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8540,8202,13508,2421,1024,8541,4161,8692,16,139,8328,65,10588,5392,12757,10280,1500,32,256,8693,5593,513]

theorem envBound17768 : H12AffineFastState.Bounded env17768 := by
  intro p hp
  have h : env17768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17767_17768 : H12AffineEnvironment.transform 14 8540 env17767 = env17768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17767 == env17768) = true)

theorem identity17768 : scanCanonicalize (H12AffineFastState.compose env17768 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound17768 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17769 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,136,478,5392,2421,1024,137,4161,32,16,139,348,65,2184,5392,4097,2556,1500,32,256,33,5593,513]

theorem envBound17769 : H12AffineFastState.Bounded env17769 := by
  intro p hp
  have h : env17769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17768_17769 : H12AffineEnvironment.transform 12 468 env17768 = env17769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env17768 == env17769) = true)

theorem identity17769 : scanCanonicalize (H12AffineFastState.compose env17769 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 2556) := by decide +kernel

theorem selectedBound17769 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env17770 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2556,468,3324,136,478,3308,2421,1024,137,2493,32,16,139,348,65,2184,3308,2557,2556,1500,32,256,33,3109,513]

theorem envBound17770 : H12AffineFastState.Bounded env17770 := by
  intro p hp
  have h : env17770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17769_17770 : H12AffineEnvironment.transform 11 2556 env17769 = env17770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2556 env17769 == env17770) = true)

def env17771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,8388608,8874484,8328,65,4237812,8393985,8826153,8830977,454117,12645453,256,21792,46212,510514]

theorem envBound17771 : H12AffineFastState.Bounded env17771 := by
  intro p hp
  have h : env17771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17695_17771 : H12AffineEnvironment.transform 20 456825 env17695 = env17771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env17695 == env17771) = true)

def env17772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,98780,8328,65,4237812,458025,17665,10281,454117,4594789,256,21792,46212,510514]

theorem envBound17772 : H12AffineFastState.Bounded env17772 := by
  intro p hp
  have h : env17772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17771_17772 : H12AffineEnvironment.transform 22 452648 env17771 = env17772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env17771 == env17772) = true)

def env17773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,98780,8328,65,295284,458025,17665,10281,454117,144613,256,21792,46212,510514]

theorem envBound17773 : H12AffineFastState.Bounded env17773 := by
  intro p hp
  have h : env17773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17772_17773 : H12AffineEnvironment.transform 21 272512 env17772 = env17773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17772 == env17773) = true)

theorem identity17773 : scanCanonicalize (H12AffineFastState.compose env17773 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound17773 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17774 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115871,201830,120014,98780,8328,65,245138,115151,17665,10281,119043,144613,256,21792,46212,63188]

theorem envBound17774 : H12AffineFastState.Bounded env17774 := by
  intro p hp
  have h : env17774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17773_17774 : H12AffineEnvironment.transform 17 212198 env17773 = env17774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env17773 == env17774) = true)

def env17775 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115871,201782,119966,98700,8328,17,245138,115103,17665,10281,119043,144565,256,21792,46212,63108]

theorem envBound17775 : H12AffineFastState.Bounded env17775 := by
  intro p hp
  have h : env17775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17774_17775 : H12AffineEnvironment.transform 5 16 env17774 = env17775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17774 == env17775) = true)

theorem identity17775 : scanCanonicalize (H12AffineFastState.compose env17775 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115103) := by decide +kernel

theorem selectedBound17775 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env17776 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,115103,64809,1024,32769,115871,54697,119966,98700,8328,17,31757,115103,17665,10281,119043,128298,256,21792,46212,63108]

theorem envBound17776 : H12AffineFastState.Bounded env17776 := by
  intro p hp
  have h : env17776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17775_17776 : H12AffineEnvironment.transform 16 115103 env17775 = env17776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115103 env17775 == env17776) = true)

theorem identity17776 : scanCanonicalize (H12AffineFastState.compose env17776 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound17776 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env17777 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,62730,13461,64809,1024,32769,12693,54697,8596,29830,8328,17,31757,13461,17665,10281,9225,32,256,21792,46212,63108]

theorem envBound17777 : H12AffineFastState.Bounded env17777 := by
  intro p hp
  have h : env17777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17776_17777 : H12AffineEnvironment.transform 15 62730 env17776 = env17777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env17776 == env17777) = true)

theorem identity17777 : scanCanonicalize (H12AffineFastState.compose env17777 (packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound17777 : packedSelected [0,3,4,7,10,16,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env17778 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,33030,13461,35109,1024,32769,12693,41381,8596,138,8328,17,2049,13461,12557,10281,9225,32,256,8492,46212,33416]

theorem envBound17778 : H12AffineFastState.Bounded env17778 := by
  intro p hp
  have h : env17778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17777_17778 : H12AffineEnvironment.transform 13 13324 env17777 = env17778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env17777 == env17778) = true)

theorem identity17778 : scanCanonicalize (H12AffineFastState.compose env17778 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound17778 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env17779 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,8580,8322,13461,10401,1024,8581,12693,33,8596,138,8328,17,2049,13461,12557,10281,9225,32,256,8492,5376,8972]

theorem envBound17779 : H12AffineFastState.Bounded env17779 := by
  intro p hp
  have h : env17779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17778_17779 : H12AffineEnvironment.transform 14 8580 env17778 = env17779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env17778 == env17779) = true)

theorem identity17779 : scanCanonicalize (H12AffineFastState.compose env17779 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound17779 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17780 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,1,263,5392,2340,1024,0,4112,33,17,138,269,17,2049,5392,4232,2476,1420,32,256,169,5376,649]

theorem envBound17780 : H12AffineFastState.Bounded env17780 := by
  intro p hp
  have h : env17780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17779_17780 : H12AffineEnvironment.transform 12 389 env17779 = env17780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env17779 == env17780) = true)

theorem identity17780 : scanCanonicalize (H12AffineFastState.compose env17780 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound17780 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env17781 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,301,5409,1,263,5392,2340,1024,0,4112,33,17,34,269,17,2049,5392,4128,2308,1316,32,256,1,5376,545]

theorem envBound17781 : H12AffineFastState.Bounded env17781 := by
  intro p hp
  have h : env17781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17780_17781 : H12AffineEnvironment.transform 6 40 env17780 = env17781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env17780 == env17781) = true)

theorem identity17781 : scanCanonicalize (H12AffineFastState.compose env17781 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17781 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17782 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,268,5376,1,263,5392,2309,1024,0,4112,0,17,3,269,17,2049,5392,4097,2308,1285,1,256,1,5376,512]

theorem envBound17782 : H12AffineFastState.Bounded env17782 := by
  intro p hp
  have h : env17782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17781_17782 : H12AffineEnvironment.transform 4 1 env17781 = env17782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17781 == env17782) = true)

theorem identity17782 : scanCanonicalize (H12AffineFastState.compose env17782 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound17782 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17783 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,0,268,1280,1,263,1296,2309,1024,0,16,0,17,3,269,17,2049,1296,1,2308,1285,1,256,1,1280,512]

theorem envBound17783 : H12AffineFastState.Bounded env17783 := by
  intro p hp
  have h : env17783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17782_17783 : H12AffineEnvironment.transform 11 0 env17782 = env17783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env17782 == env17783) = true)

theorem identity17783 : scanCanonicalize (H12AffineFastState.compose env17783 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound17783 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17784 : List Nat := [2,4,8,16,1,16,9,256,512,1024,10,0,268,1280,1,263,1296,271,1024,0,16,0,17,3,269,17,11,1296,1,270,1285,1,256,1,1280,512]

theorem envBound17784 : H12AffineFastState.Bounded env17784 := by
  intro p hp
  have h : env17784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17783_17784 : H12AffineEnvironment.transform 10 10 env17783 = env17784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env17783 == env17784) = true)

theorem identity17784 : scanCanonicalize (H12AffineFastState.compose env17784 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound17784 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17785 : List Nat := [2,4,8,16,1,16,9,256,512,4,10,0,268,260,1,263,276,271,4,0,16,0,17,3,269,17,11,276,1,270,257,1,256,1,260,512]

theorem envBound17785 : H12AffineFastState.Bounded env17785 := by
  intro p hp
  have h : env17785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17784_17785 : H12AffineEnvironment.transform 9 4 env17784 = env17785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env17784 == env17785) = true)

theorem identity17785 : scanCanonicalize (H12AffineFastState.compose env17785 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound17785 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17786 : List Nat := [2,4,8,16,1,16,9,31,512,4,10,0,19,27,1,24,11,16,4,0,16,0,17,3,18,17,11,11,1,17,30,1,31,1,27,512]

theorem envBound17786 : H12AffineFastState.Bounded env17786 := by
  intro p hp
  have h : env17786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17785_17786 : H12AffineEnvironment.transform 7 31 env17785 = env17786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env17785 == env17786) = true)

def env17787 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115871,201783,119967,98701,8328,16,245138,115102,17665,10281,119043,144564,256,21792,46212,63109]

theorem envBound17787 : H12AffineFastState.Bounded env17787 := by
  intro p hp
  have h : env17787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17774_17787 : H12AffineEnvironment.transform 5 17 env17774 = env17787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17774 == env17787) = true)

theorem identity17787 : scanCanonicalize (H12AffineFastState.compose env17787 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound17787 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env17788 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76079,1024,32769,115871,65967,119967,98701,8328,16,108554,115102,17665,10281,119043,8492,256,21792,46212,63109]

theorem envBound17788 : H12AffineFastState.Bounded env17788 := by
  intro p hp
  have h : env17788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17787_17788 : H12AffineEnvironment.transform 16 5528 env17787 = env17788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env17787 == env17788) = true)

theorem identity17788 : scanCanonicalize (H12AffineFastState.compose env17788 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound17788 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env17789 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40970,5528,35109,1024,32769,25749,41381,29845,8583,8328,16,2048,24980,17665,10281,28937,8492,256,21792,46212,63109]

theorem envBound17789 : H12AffineFastState.Bounded env17789 := by
  intro p hp
  have h : env17789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17788_17789 : H12AffineEnvironment.transform 15 40970 env17788 = env17789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env17788 == env17789) = true)

theorem identity17789 : scanCanonicalize (H12AffineFastState.compose env17789 (packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound17789 : packedSelected [0,3,4,7,10,16,18,19,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env17790 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,0,8202,5528,2341,1024,1,25749,8613,29845,8583,8328,16,2048,24980,17665,10281,28937,8492,256,21792,13444,30341]

theorem envBound17790 : H12AffineFastState.Bounded env17790 := by
  intro p hp
  have h : env17790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17789_17790 : H12AffineEnvironment.transform 14 0 env17789 = env17790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env17789 == env17790) = true)

theorem identity17790 : scanCanonicalize (H12AffineFastState.compose env17790 (packedSelected [1,3,4,5,7,8,10,11,16,18] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound17790 : packedSelected [1,3,4,5,7,8,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env17791 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1572,4096,8192,16384,0,8202,5528,1793,1024,1,25749,8613,29845,8583,8328,16,1572,24980,17665,9741,28937,8492,256,21792,13444,30341]

theorem envBound17791 : H12AffineFastState.Bounded env17791 := by
  intro p hp
  have h : env17791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17790_17791 : H12AffineEnvironment.transform 10 1572 env17790 = env17791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env17790 == env17791) = true)

theorem identity17791 : scanCanonicalize (H12AffineFastState.compose env17791 (packedSelected [2,3,5,7,9,10,12,15,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound17791 : packedSelected [2,3,5,7,9,10,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env17792 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1572,4096,8192,13576,0,8202,5528,1793,1024,1,4509,8613,413,8583,8328,16,1572,5276,12297,9741,1025,8492,256,8232,13444,909]

theorem envBound17792 : H12AffineFastState.Bounded env17792 := by
  intro p hp
  have h : env17792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17791_17792 : H12AffineEnvironment.transform 13 13576 env17791 = env17792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env17791 == env17792) = true)

theorem identity17792 : scanCanonicalize (H12AffineFastState.compose env17792 (packedSelected [1,2,7,8,9,12,15,16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound17792 : packedSelected [1,2,7,8,9,12,15,16,17,20] rootPS < 2^1333 := by decide +kernel

def env17793 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1572,4096,8,5376,0,2,5528,1793,1024,1,4509,429,413,399,128,16,1572,5276,4097,1541,1025,292,256,32,5260,909]

theorem envBound17793 : H12AffineFastState.Bounded env17793 := by
  intro p hp
  have h : env17793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17792_17793 : H12AffineEnvironment.transform 12 8 env17792 = env17793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env17792 == env17793) = true)

theorem identity17793 : scanCanonicalize (H12AffineFastState.compose env17793 (packedSelected [0,3,5,9,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17793 : packedSelected [0,3,5,9,11,12] rootPS < 2^1333 := by decide +kernel

def env17794 : List Nat := [2,4,8,16,32,17,128,5,512,1024,1572,4096,8,5125,0,2,5277,1540,1024,1,4248,168,152,138,128,16,1572,5276,4097,1541,1025,33,5,32,5260,648]

theorem envBound17794 : H12AffineFastState.Bounded env17794 := by
  intro p hp
  have h : env17794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17793_17794 : H12AffineEnvironment.transform 7 5 env17793 = env17794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17793 == env17794) = true)

theorem identity17794 : scanCanonicalize (H12AffineFastState.compose env17794 (packedSelected [1,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound17794 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env17795 : List Nat := [2,4,8,0,32,1,128,5,512,1024,1572,4096,8,5125,0,2,5261,1540,1024,1,4232,168,136,138,128,0,1572,5260,4097,1541,1025,33,5,32,5260,648]

theorem envBound17795 : H12AffineFastState.Bounded env17795 := by
  intro p hp
  have h : env17795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17794_17795 : H12AffineEnvironment.transform 3 0 env17794 = env17795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env17794 == env17795) = true)

theorem identity17795 : scanCanonicalize (H12AffineFastState.compose env17795 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 545) := by decide +kernel

theorem selectedBound17795 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env17796 : List Nat := [2,4,8,0,32,1,128,5,512,1024,1572,545,8,1572,0,2,1708,1540,1024,1,681,168,136,138,128,0,1572,1709,544,1541,1025,33,5,32,1709,648]

theorem envBound17796 : H12AffineFastState.Bounded env17796 := by
  intro p hp
  have h : env17796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17795_17796 : H12AffineEnvironment.transform 11 545 env17795 = env17796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 545 env17795 == env17796) = true)

theorem identity17796 : scanCanonicalize (H12AffineFastState.compose env17796 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 172) := by decide +kernel

theorem selectedBound17796 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env17797 : List Nat := [2,4,8,0,32,1,128,5,512,172,648,545,8,648,0,2,512,680,172,1,681,168,136,138,128,0,648,513,544,681,173,33,5,32,513,648]

theorem envBound17797 : H12AffineFastState.Bounded env17797 := by
  intro p hp
  have h : env17797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17796_17797 : H12AffineEnvironment.transform 9 172 env17796 = env17797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env17796 == env17797) = true)

theorem identity17797 : scanCanonicalize (H12AffineFastState.compose env17797 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound17797 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17798 : List Nat := [2,4,8,0,32,1,9,5,512,37,513,545,8,513,0,2,512,545,37,1,544,33,1,3,9,0,513,513,544,544,36,33,5,32,513,513]

theorem envBound17798 : H12AffineFastState.Bounded env17798 := by
  intro p hp
  have h : env17798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17797_17798 : H12AffineEnvironment.transform 6 9 env17797 = env17798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17797 == env17798) = true)

theorem identity17798 : scanCanonicalize (H12AffineFastState.compose env17798 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17798 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17799 : List Nat := [2,4,8,0,1,1,9,5,512,4,513,512,8,513,0,2,512,512,4,1,513,0,1,3,9,0,513,513,513,513,5,0,5,1,513,513]

theorem envBound17799 : H12AffineFastState.Bounded env17799 := by
  intro p hp
  have h : env17799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17798_17799 : H12AffineEnvironment.transform 4 1 env17798 = env17799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17798 == env17799) = true)

theorem identity17799 : scanCanonicalize (H12AffineFastState.compose env17799 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound17799 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17800 : List Nat := [2,4,8,0,1,1,9,5,1,4,0,1,8,0,0,2,1,1,4,1,0,0,1,3,9,0,0,0,0,0,5,0,5,1,0,0]

theorem envBound17800 : H12AffineFastState.Bounded env17800 := by
  intro p hp
  have h : env17800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17799_17800 : H12AffineEnvironment.transform 8 1 env17799 = env17800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env17799 == env17800) = true)

theorem identity17800 : scanCanonicalize (H12AffineFastState.compose env17800 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound17800 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17801 : List Nat := [2,4,2,0,1,1,3,5,1,4,0,1,2,0,0,2,1,1,4,1,0,0,1,3,3,0,0,0,0,0,5,0,5,1,0,0]

theorem envBound17801 : H12AffineFastState.Bounded env17801 := by
  intro p hp
  have h : env17801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17800_17801 : H12AffineEnvironment.transform 2 2 env17800 = env17801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env17800 == env17801) = true)

def env17802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,98780,8328,65,295285,458025,17665,10281,454117,144612,256,21792,46212,510514]

theorem envBound17802 : H12AffineFastState.Bounded env17802 := by
  intro p hp
  have h : env17802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17772_17802 : H12AffineEnvironment.transform 21 272513 env17772 = env17802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17772 == env17802) = true)

theorem identity17802 : scanCanonicalize (H12AffineFastState.compose env17802 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound17802 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,456825,272513,452648,21762,8328,65,295285,458025,17665,10281,454117,144612,256,21792,46212,401132]

theorem envBound17803 : H12AffineFastState.Bounded env17803 := by
  intro p hp
  have h : env17803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17802_17803 : H12AffineEnvironment.transform 15 54494 env17802 = env17803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env17802 == env17803) = true)

def env17804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456825,272393,452648,21762,8192,65,295285,458025,17665,10281,453997,144492,256,21792,46092,400996]

theorem envBound17804 : H12AffineFastState.Bounded env17804 := by
  intro p hp
  have h : env17804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17803_17804 : H12AffineEnvironment.transform 6 8 env17803 = env17804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17803 == env17804) = true)

theorem identity17804 : scanCanonicalize (H12AffineFastState.compose env17804 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound17804 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env17805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1024,32769,165201,21793,169216,21762,8192,65,64605,163841,17665,10281,168005,144492,256,21792,46092,156492]

theorem envBound17805 : H12AffineFastState.Bounded env17805 := by
  intro p hp
  have h : env17805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17804_17805 : H12AffineEnvironment.transform 17 32040 env17804 = env17805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env17804 == env17805) = true)

theorem identity17805 : scanCanonicalize (H12AffineFastState.compose env17805 (packedSelected [1,7,8,12,14,15,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound17805 : packedSelected [1,7,8,12,14,15,19,20,27] rootPS < 2^1333 := by decide +kernel

def env17806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,30043,131072,32040,1024,8460,140380,21793,144397,21762,8192,65,23888,139532,17665,10281,143688,144492,256,21792,5377,156492]

theorem envBound17806 : H12AffineFastState.Bounded env17806 := by
  intro p hp
  have h : env17806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17805_17806 : H12AffineEnvironment.transform 14 8461 env17805 = env17806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env17805 == env17806) = true)

theorem identity17806 : scanCanonicalize (H12AffineFastState.compose env17806 (packedSelected [16,17,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound17806 : packedSelected [16,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env17807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8461,30043,24860,32040,1024,8460,17728,21793,21777,21762,8192,65,23888,16400,17665,10281,20564,21872,256,21792,5377,592]

theorem envBound17807 : H12AffineFastState.Bounded env17807 := by
  intro p hp
  have h : env17807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17806_17807 : H12AffineEnvironment.transform 16 24860 env17806 = env17807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env17806 == env17807) = true)

theorem identity17807 : scanCanonicalize (H12AffineFastState.compose env17807 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17807 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17808 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,29962,24860,32040,1024,8460,17681,21793,21777,21762,8192,16,23809,16400,17665,10281,20485,21793,256,21792,5377,513]

theorem envBound17808 : H12AffineFastState.Bounded env17808 := by
  intro p hp
  have h : env17808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17807_17808 : H12AffineEnvironment.transform 5 17 env17807 = env17808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17807 == env17808) = true)

def env17809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456825,272392,452648,21762,8193,65,295285,458025,17665,10281,453996,144493,256,21792,46093,400997]

theorem envBound17809 : H12AffineFastState.Bounded env17809 := by
  intro p hp
  have h : env17809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17803_17809 : H12AffineEnvironment.transform 6 9 env17803 = env17809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17803 == env17809) = true)

theorem identity17809 : scanCanonicalize (H12AffineFastState.compose env17809 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 149569) := by decide +kernel

theorem selectedBound17809 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env17810 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,149569,1024,32769,45112,155721,41065,21762,8193,65,182580,46440,17665,10281,42285,144493,256,21792,46093,22052]

theorem envBound17810 : H12AffineFastState.Bounded env17810 := by
  intro p hp
  have h : env17810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17809_17810 : H12AffineEnvironment.transform 17 149569 env17809 = env17810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149569 env17809 == env17810) = true)

theorem identity17810 : scanCanonicalize (H12AffineFastState.compose env17810 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound17810 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env17811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,32768,54359,131072,149569,1024,32769,36929,147504,32784,21762,120,65,182580,38161,17665,2128,34132,136212,256,21792,38004,22052]

theorem envBound17811 : H12AffineFastState.Bounded env17811 := by
  intro p hp
  have h : env17811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17810_17811 : H12AffineEnvironment.transform 12 121 env17810 = env17811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env17810 == env17811) = true)

theorem identity17811 : scanCanonicalize (H12AffineFastState.compose env17811 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound17811 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env17812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21760,343,131072,149569,1024,21761,17729,147504,21776,21762,120,65,138292,16401,17665,2128,20564,136212,256,21792,16756,22052]

theorem envBound17812 : H12AffineFastState.Bounded env17812 := by
  intro p hp
  have h : env17812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17811_17812 : H12AffineEnvironment.transform 14 21760 env17811 = env17812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env17811 == env17812) = true)

theorem identity17812 : scanCanonicalize (H12AffineFastState.compose env17812 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 16693) := by decide +kernel

theorem selectedBound17812 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env17813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21760,343,16693,2420,1024,21761,17729,261,21776,21762,120,65,23809,16401,17665,2128,20564,21793,256,21792,16756,22052]

theorem envBound17813 : H12AffineFastState.Bounded env17813 := by
  intro p hp
  have h : env17813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17812_17813 : H12AffineEnvironment.transform 16 16693 env17812 = env17813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16693 env17812 == env17813) = true)

theorem identity17813 : scanCanonicalize (H12AffineFastState.compose env17813 (packedSelected [0,1,4,7,8,9,10,11,12,15,16,17] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound17813 : packedSelected [0,1,4,7,8,9,10,11,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env17814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,121,16384,19508,343,16693,2420,1024,19509,17729,261,19492,19510,120,65,17461,16401,17665,2128,18784,19477,256,19476,16756,20240]

theorem envBound17814 : H12AffineFastState.Bounded env17814 := by
  intro p hp
  have h : env17814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17813_17814 : H12AffineEnvironment.transform 11 2356 env17813 = env17814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env17813 == env17814) = true)

theorem identity17814 : scanCanonicalize (H12AffineFastState.compose env17814 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 3393) := by decide +kernel

theorem selectedBound17814 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env17815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,121,3393,373,343,3188,2420,1024,372,2048,261,357,375,120,65,2420,3408,2112,2128,1057,340,256,341,3125,593]

theorem envBound17815 : H12AffineFastState.Bounded env17815 := by
  intro p hp
  have h : env17815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17814_17815 : H12AffineEnvironment.transform 13 3393 env17814 = env17815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3393 env17814 == env17815) = true)

theorem identity17815 : scanCanonicalize (H12AffineFastState.compose env17815 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17815 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env17816 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,2356,121,2420,373,343,2113,2420,53,372,2048,261,357,375,120,65,2420,2405,2112,2128,20,340,256,341,2048,593]

theorem envBound17816 : H12AffineFastState.Bounded env17816 := by
  intro p hp
  have h : env17816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17815_17816 : H12AffineEnvironment.transform 9 53 env17815 = env17816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17815 == env17816) = true)

theorem identity17816 : scanCanonicalize (H12AffineFastState.compose env17816 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound17816 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17817 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2065,121,2129,80,114,2113,2129,53,81,2048,32,64,82,120,65,2129,2112,2112,2128,20,113,37,112,2048,593]

theorem envBound17817 : H12AffineFastState.Bounded env17817 := by
  intro p hp
  have h : env17817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17816_17817 : H12AffineEnvironment.transform 7 37 env17816 = env17817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env17816 == env17817) = true)

theorem identity17817 : scanCanonicalize (H12AffineFastState.compose env17817 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound17817 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env17818 : List Nat := [2,4,8,16,32,48,9,37,512,53,2048,2065,9,2081,32,2,2097,2081,53,33,2048,32,48,34,8,49,2081,2096,2096,2080,20,1,37,0,2048,545]

theorem envBound17818 : H12AffineFastState.Bounded env17818 := by
  intro p hp
  have h : env17818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17817_17818 : H12AffineEnvironment.transform 5 48 env17817 = env17818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env17817 == env17818) = true)

theorem identity17818 : scanCanonicalize (H12AffineFastState.compose env17818 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound17818 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17819 : List Nat := [2,4,8,16,32,48,9,37,512,53,49,32,9,16,32,2,0,16,53,33,49,32,48,34,8,49,16,1,1,17,20,1,37,0,49,545]

theorem envBound17819 : H12AffineFastState.Bounded env17819 := by
  intro p hp
  have h : env17819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17818_17819 : H12AffineEnvironment.transform 10 49 env17818 = env17819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env17818 == env17819) = true)

def env17820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,98781,8328,65,4237812,458024,17664,10280,454117,4594788,256,21792,46212,510514]

theorem envBound17820 : H12AffineFastState.Bounded env17820 := by
  intro p hp
  have h : env17820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17771_17820 : H12AffineEnvironment.transform 22 452649 env17771 = env17820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env17771 == env17820) = true)

def env17821 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,98781,8328,65,295284,458024,17664,10280,454117,144612,256,21792,46212,510514]

theorem envBound17821 : H12AffineFastState.Bounded env17821 := by
  intro p hp
  have h : env17821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17820_17821 : H12AffineEnvironment.transform 21 272512 env17820 = env17821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env17820 == env17821) = true)

theorem identity17821 : scanCanonicalize (H12AffineFastState.compose env17821 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound17821 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,77898,254131,73754,98781,8328,65,215367,79131,17664,10280,75222,144612,256,21792,46212,513]

theorem envBound17822 : H12AffineFastState.Bounded env17822 := by
  intro p hp
  have h : env17822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17821_17822 : H12AffineEnvironment.transform 17 247859 env17821 = env17822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env17821 == env17822) = true)

theorem identity17822 : scanCanonicalize (H12AffineFastState.compose env17822 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17822 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env17823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,180409,16,41431,8328,65,158029,5393,17664,10280,1500,144612,256,21792,46212,513]

theorem envBound17823 : H12AffineFastState.Bounded env17823 := by
  intro p hp
  have h : env17823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17822_17823 : H12AffineEnvironment.transform 15 8202 env17822 = env17823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17822 == env17823) = true)

theorem identity17823 : scanCanonicalize (H12AffineFastState.compose env17823 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound17823 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env17824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4160,32936,16,41431,8328,65,10588,5393,17664,10280,1500,29941,256,21792,46212,513]

theorem envBound17824 : H12AffineFastState.Bounded env17824 := by
  intro p hp
  have h : env17824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17823_17824 : H12AffineEnvironment.transform 16 16401 env17823 = env17824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env17823 == env17824) = true)

theorem identity17824 : scanCanonicalize (H12AffineFastState.compose env17824 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17824 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env17825 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4113,32936,16,41350,8328,16,10509,5393,17664,10280,1421,29860,256,21792,46212,513]

theorem envBound17825 : H12AffineFastState.Bounded env17825 := by
  intro p hp
  have h : env17825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17824_17825 : H12AffineEnvironment.transform 5 17 env17824 = env17825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17824 == env17825) = true)

theorem identity17825 : scanCanonicalize (H12AffineFastState.compose env17825 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound17825 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env17826 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4113,32800,16,41230,8192,16,10509,5393,17664,10280,1285,29740,256,21792,46092,513]

theorem envBound17826 : H12AffineFastState.Bounded env17826 := by
  intro p hp
  have h : env17826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17825_17826 : H12AffineEnvironment.transform 6 8 env17825 = env17826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17825 == env17826) = true)

theorem identity17826 : scanCanonicalize (H12AffineFastState.compose env17826 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound17826 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17827 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,1,8202,16401,10281,1024,0,4113,33,16,8463,8192,16,10509,5393,17664,10280,1285,29740,256,21792,13325,513]

theorem envBound17827 : H12AffineFastState.Bounded env17827 := by
  intro p hp
  have h : env17827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17826_17827 : H12AffineEnvironment.transform 14 1 env17826 = env17827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env17826 == env17827) = true)

theorem identity17827 : scanCanonicalize (H12AffineFastState.compose env17827 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound17827 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env17828 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5376,1,8202,5393,10281,1024,0,4113,33,16,8463,8192,16,10509,5393,4096,10280,1285,8492,256,32,13325,513]

theorem envBound17828 : H12AffineFastState.Bounded env17828 := by
  intro p hp
  have h : env17828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17827_17828 : H12AffineEnvironment.transform 13 5376 env17827 = env17828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env17827 == env17828) = true)

theorem identity17828 : scanCanonicalize (H12AffineFastState.compose env17828 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 3645) := by decide +kernel

theorem selectedBound17828 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env17829 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,3645,5376,1,3639,5393,1556,1024,0,4113,33,16,3890,3645,16,1840,5393,4096,1557,1285,3857,256,32,6704,513]

theorem envBound17829 : H12AffineFastState.Bounded env17829 := by
  intro p hp
  have h : env17829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17828_17829 : H12AffineEnvironment.transform 12 3645 env17828 = env17829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3645 env17828 == env17829) = true)

theorem identity17829 : scanCanonicalize (H12AffineFastState.compose env17829 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1840) := by decide +kernel

theorem selectedBound17829 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17830 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1840,4096,269,5376,1,263,5393,1556,1024,0,4113,33,16,2,269,16,1840,5393,4096,1557,1285,33,256,32,5376,513]

theorem envBound17830 : H12AffineFastState.Bounded env17830 := by
  intro p hp
  have h : env17830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17829_17830 : H12AffineEnvironment.transform 10 1840 env17829 = env17830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1840 env17829 == env17830) = true)

theorem identity17830 : scanCanonicalize (H12AffineFastState.compose env17830 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound17830 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17831 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1840,1029,269,261,1,263,276,1556,1024,0,1044,33,16,2,269,16,1840,276,1029,1557,1285,33,256,32,261,513]

theorem envBound17831 : H12AffineFastState.Bounded env17831 := by
  intro p hp
  have h : env17831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17830_17831 : H12AffineEnvironment.transform 11 1029 env17830 = env17831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env17830 == env17831) = true)

theorem identity17831 : scanCanonicalize (H12AffineFastState.compose env17831 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound17831 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17832 : List Nat := [2,4,8,16,32,17,8,256,512,305,513,308,269,261,1,263,276,805,305,0,293,33,16,2,269,16,513,276,308,804,52,33,256,32,261,513]

theorem envBound17832 : H12AffineFastState.Bounded env17832 := by
  intro p hp
  have h : env17832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17831_17832 : H12AffineEnvironment.transform 9 305 env17831 = env17832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env17831 == env17832) = true)

theorem identity17832 : scanCanonicalize (H12AffineFastState.compose env17832 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound17832 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env17833 : List Nat := [2,4,8,16,32,17,8,256,308,305,309,308,269,261,1,263,276,17,305,0,293,33,16,2,269,16,309,276,308,16,52,33,256,32,261,309]

theorem envBound17833 : H12AffineFastState.Bounded env17833 := by
  intro p hp
  have h : env17833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17832_17833 : H12AffineEnvironment.transform 8 308 env17832 = env17833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env17832 == env17833) = true)

theorem identity17833 : scanCanonicalize (H12AffineFastState.compose env17833 (packedSelected [7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound17833 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env17834 : List Nat := [2,4,8,16,16,17,8,256,260,257,261,260,269,261,1,263,276,17,257,0,277,17,16,2,269,16,261,276,260,16,4,17,256,16,261,261]

theorem envBound17834 : H12AffineFastState.Bounded env17834 := by
  intro p hp
  have h : env17834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17833_17834 : H12AffineEnvironment.transform 4 16 env17833 = env17834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env17833 == env17834) = true)

def env17835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,98781,8328,65,295285,458024,17664,10280,454117,144613,256,21792,46212,510514]

theorem envBound17835 : H12AffineFastState.Bounded env17835 := by
  intro p hp
  have h : env17835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17820_17835 : H12AffineEnvironment.transform 21 272513 env17820 = env17835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env17820 == env17835) = true)

theorem identity17835 : scanCanonicalize (H12AffineFastState.compose env17835 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272513,452649,41431,8328,65,295285,458024,17664,10280,454117,144613,256,21792,46212,453176]

theorem envBound17836 : H12AffineFastState.Bounded env17836 := by
  intro p hp
  have h : env17836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17835_17836 : H12AffineEnvironment.transform 15 8202 env17835 = env17836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17835 == env17836) = true)

def env17837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507600,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound17837 : H12AffineFastState.Bounded env17837 := by
  intro p hp
  have h : env17837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17693_17837 : H12AffineEnvironment.transform 18 1025 env17693 = env17837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env17693 == env17837) = true)

theorem identity17837 : scanCanonicalize (H12AffineFastState.compose env17837 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound17837 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env17838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575541,18973837,10507600,8538484,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound17838 : H12AffineFastState.Bounded env17838 := by
  intro p hp
  have h : env17838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17837_17838 : H12AffineEnvironment.transform 17 35188 env17837 = env17838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env17837 == env17838) = true)

def env17839 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575541,18973701,10507600,8538484,25265169,23160136,257,27378724,27337993,25207631]

theorem envBound17839 : H12AffineFastState.Bounded env17839 := by
  intro p hp
  have h : env17839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17838_17839 : H12AffineEnvironment.transform 6 8 env17838 = env17839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env17838 == env17839) = true)

theorem identity17839 : scanCanonicalize (H12AffineFastState.compose env17839 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound17839 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env17840 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,8388608,16777216,8192,65,29370734,18973701,10507600,8464751,25265169,23160136,257,27378724,27337993,25207631]

theorem envBound17840 : H12AffineFastState.Bounded env17840 := by
  intro p hp
  have h : env17840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17839_17840 : H12AffineEnvironment.transform 16 90139 env17839 = env17840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env17839 == env17840) = true)

def env17841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,8388608,98644,8192,65,12691514,2098513,10507600,8464751,8389957,6349852,257,10503536,10527837,8462875]

theorem envBound17841 : H12AffineFastState.Bounded env17841 := by
  intro p hp
  have h : env17841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17840_17841 : H12AffineEnvironment.transform 23 98644 env17840 = env17841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98644 env17840 == env17841) = true)

theorem identity17841 : scanCanonicalize (H12AffineFastState.compose env17841 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound17841 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env17842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,73754,98644,8192,65,4229152,2098513,2192714,2421,75103,6349852,257,2188650,2196551,513]

theorem envBound17842 : H12AffineFastState.Bounded env17842 := by
  intro p hp
  have h : env17842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17841_17842 : H12AffineEnvironment.transform 22 73754 env17841 = env17842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env17841 == env17842) = true)

theorem identity17842 : scanCanonicalize (H12AffineFastState.compose env17842 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound17842 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env17843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,73770,73754,98644,8192,65,108554,2098513,2192714,2421,75103,2212918,257,2188650,2196551,513]

theorem envBound17843 : H12AffineFastState.Bounded env17843 := by
  intro p hp
  have h : env17843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17842_17843 : H12AffineEnvironment.transform 21 73770 env17842 = env17843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env17842 == env17843) = true)

theorem identity17843 : scanCanonicalize (H12AffineFastState.compose env17843 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound17843 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,91466,73770,73754,98644,8192,65,108554,90139,4096,2421,75103,41340,257,32,57613,513]

theorem envBound17844 : H12AffineFastState.Bounded env17844 := by
  intro p hp
  have h : env17844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17843_17844 : H12AffineEnvironment.transform 20 91466 env17843 = env17844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env17843 == env17844) = true)

theorem identity17844 : scanCanonicalize (H12AffineFastState.compose env17844 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 53574) := by decide +kernel

theorem selectedBound17844 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env17845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,53574,45405,35188,1025,32769,46092,61804,61788,20498,8192,65,31052,45405,4096,2421,62489,41340,257,32,57613,513]

theorem envBound17845 : H12AffineFastState.Bounded env17845 := by
  intro p hp
  have h : env17845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17844_17845 : H12AffineEnvironment.transform 15 53574 env17844 = env17845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53574 env17844 == env17845) = true)

theorem identity17845 : scanCanonicalize (H12AffineFastState.compose env17845 (packedSelected [3,5,10,21] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound17845 : packedSelected [3,5,10,21] rootPS < 2^1333 := by decide +kernel

def env17846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29005,8203,16400,30777,1025,29004,17729,33,17,20498,8192,65,31052,16400,4096,2421,1364,20529,257,32,4160,513]

theorem envBound17846 : H12AffineFastState.Bounded env17846 := by
  intro p hp
  have h : env17846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17845_17846 : H12AffineEnvironment.transform 14 29005 env17845 = env17846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env17845 == env17846) = true)

theorem identity17846 : scanCanonicalize (H12AffineFastState.compose env17846 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound17846 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8541,8203,4096,10281,1025,8540,5457,33,17,2,8192,65,10588,4096,4096,2421,1364,33,257,32,4160,513]

theorem envBound17847 : H12AffineFastState.Bounded env17847 := by
  intro p hp
  have h : env17847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17846_17847 : H12AffineEnvironment.transform 13 4112 env17846 = env17847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env17846 == env17847) = true)

def env17848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,4194304,8388608,98645,8192,65,12691515,2098512,10507600,8464751,8389956,6349853,257,10503537,10527836,8462874]

theorem envBound17848 : H12AffineFastState.Bounded env17848 := by
  intro p hp
  have h : env17848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17840_17848 : H12AffineEnvironment.transform 23 98645 env17840 = env17848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env17840 == env17848) = true)

theorem identity17848 : scanCanonicalize (H12AffineFastState.compose env17848 (packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound17848 : packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env17849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,2097152,98679,8388608,98645,8192,65,8399180,2098512,10507600,8464751,8389956,2188650,257,10503537,10527836,8462874]

theorem envBound17849 : H12AffineFastState.Bounded env17849 := by
  intro p hp
  have h : env17849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17848_17849 : H12AffineEnvironment.transform 21 98679 env17848 = env17849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env17848 == env17849) = true)

def env17850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,4160,98679,8388608,98645,8192,65,8399180,5392,8406288,8464751,8389956,95530,257,8410417,8434716,8462874]

theorem envBound17850 : H12AffineFastState.Bounded env17850 := by
  intro p hp
  have h : env17850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17849_17850 : H12AffineEnvironment.transform 20 4160 env17849 = env17850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env17849 == env17850) = true)

def env17851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,4160,98679,16,98645,8192,65,10588,5392,17664,76159,1364,95530,257,21793,46092,74250]

theorem envBound17851 : H12AffineFastState.Bounded env17851 := by
  intro p hp
  have h : env17851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17850_17851 : H12AffineEnvironment.transform 22 16 env17850 = env17851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env17850 == env17851) = true)

theorem identity17851 : scanCanonicalize (H12AffineFastState.compose env17851 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound17851 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,35188,1025,32769,4160,41341,16,41311,8192,65,10588,5392,17664,2421,1364,21792,257,21793,46092,512]

theorem envBound17852 : H12AffineFastState.Bounded env17852 := by
  intro p hp
  have h : env17852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17851_17852 : H12AffineEnvironment.transform 15 8202 env17851 = env17852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env17851 == env17852) = true)

theorem identity17852 : scanCanonicalize (H12AffineFastState.compose env17852 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound17852 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,32768,8202,13625,35188,1025,32769,4160,41341,16,41311,8192,65,10588,5392,12328,2421,1364,8200,257,8201,46092,512]

theorem envBound17853 : H12AffineFastState.Bounded env17853 := by
  intro p hp
  have h : env17853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17852_17853 : H12AffineEnvironment.transform 13 13608 env17852 = env17853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env17852 == env17853) = true)

theorem identity17853 : scanCanonicalize (H12AffineFastState.compose env17853 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound17853 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5157,32768,263,5172,35188,1025,32769,4160,32880,16,32850,269,65,2129,5392,4389,2421,1364,261,257,260,38145,512]

theorem envBound17854 : H12AffineFastState.Bounded env17854 := by
  intro p hp
  have h : env17854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17853_17854 : H12AffineEnvironment.transform 12 269 env17853 = env17854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env17853 == env17854) = true)

theorem identity17854 : scanCanonicalize (H12AffineFastState.compose env17854 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17854 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env17855 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,32768,263,5172,35108,1025,32769,4112,32800,16,32770,269,17,2049,5392,4389,2341,1284,261,257,260,38145,512]

theorem envBound17855 : H12AffineFastState.Bounded env17855 := by
  intro p hp
  have h : env17855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17854_17855 : H12AffineEnvironment.transform 5 16 env17854 = env17855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17854 == env17855) = true)

theorem identity17855 : scanCanonicalize (H12AffineFastState.compose env17855 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17855 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17856 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,269,5124,32768,263,5141,35077,1025,32769,4112,32769,16,32770,269,17,2049,5392,4356,2308,1284,261,257,260,38145,512]

theorem envBound17856 : H12AffineFastState.Bounded env17856 := by
  intro p hp
  have h : env17856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17855_17856 : H12AffineEnvironment.transform 4 1 env17855 = env17856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17855 == env17856) = true)

theorem identity17856 : scanCanonicalize (H12AffineFastState.compose env17856 (packedSelected [3,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound17856 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env17857 : List Nat := [2,4,8,16,1,16,8,256,512,1024,783,4096,269,5124,32768,263,5141,33290,1025,32769,4112,32769,16,32770,269,17,782,5392,4356,523,1284,261,257,260,38145,512]

theorem envBound17857 : H12AffineFastState.Bounded env17857 := by
  intro p hp
  have h : env17857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17856_17857 : H12AffineEnvironment.transform 10 783 env17856 = env17857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env17856 == env17857) = true)

theorem identity17857 : scanCanonicalize (H12AffineFastState.compose env17857 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound17857 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env17858 : List Nat := [2,4,8,16,1,16,8,5,512,1024,522,4096,8,5124,32768,2,5141,33290,1025,32769,4112,32769,16,32770,8,17,523,5141,4097,523,1025,0,4,1,37892,512]

theorem envBound17858 : H12AffineFastState.Bounded env17858 := by
  intro p hp
  have h : env17858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17857_17858 : H12AffineEnvironment.transform 7 5 env17857 = env17858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env17857 == env17858) = true)

theorem identity17858 : scanCanonicalize (H12AffineFastState.compose env17858 (packedSelected [2] rootPS)) = affineNative (2^(14+1) ^^^ 1045) := by decide +kernel

theorem selectedBound17858 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17859 : List Nat := [2,4,8,16,1,16,8,5,512,1024,522,4096,8,5124,1045,2,5141,1567,1025,1044,4112,1044,16,1047,8,17,523,5141,4097,523,1025,0,4,1,4113,512]

theorem envBound17859 : H12AffineFastState.Bounded env17859 := by
  intro p hp
  have h : env17859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17858_17859 : H12AffineEnvironment.transform 14 1045 env17858 = env17859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1045 env17858 == env17859) = true)

theorem identity17859 : scanCanonicalize (H12AffineFastState.compose env17859 (packedSelected [3,4] rootPS)) = affineNative (2^(11+1) ^^^ 1053) := by decide +kernel

theorem selectedBound17859 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env17860 : List Nat := [2,4,8,16,1,16,8,5,512,1024,522,1053,8,25,1045,2,8,1567,1025,1044,1037,1044,16,1047,8,17,523,8,1052,523,1025,0,4,1,1036,512]

theorem envBound17860 : H12AffineFastState.Bounded env17860 := by
  intro p hp
  have h : env17860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17859_17860 : H12AffineEnvironment.transform 11 1053 env17859 = env17860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1053 env17859 == env17860) = true)

theorem identity17860 : scanCanonicalize (H12AffineFastState.compose env17860 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 519) := by decide +kernel

theorem selectedBound17860 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env17861 : List Nat := [2,4,8,16,1,16,8,5,512,519,522,538,8,25,530,2,8,24,518,531,522,531,16,528,8,17,523,8,539,523,518,0,4,1,523,512]

theorem envBound17861 : H12AffineFastState.Bounded env17861 := by
  intro p hp
  have h : env17861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17860_17861 : H12AffineEnvironment.transform 9 519 env17860 = env17861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 519 env17860 == env17861) = true)

theorem identity17861 : scanCanonicalize (H12AffineFastState.compose env17861 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound17861 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env17862 : List Nat := [2,4,8,16,1,16,8,5,10,13,0,16,8,25,24,2,8,24,12,25,0,25,16,26,8,17,1,8,17,1,12,0,4,1,1,10]

theorem envBound17862 : H12AffineFastState.Bounded env17862 := by
  intro p hp
  have h : env17862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17861_17862 : H12AffineEnvironment.transform 8 10 env17861 = env17862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env17861 == env17862) = true)

theorem identity17862 : scanCanonicalize (H12AffineFastState.compose env17862 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound17862 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env17863 : List Nat := [2,4,8,8,1,8,8,5,10,13,0,8,8,1,0,2,8,0,12,1,0,1,8,2,8,9,1,8,9,1,12,0,4,1,1,10]

theorem envBound17863 : H12AffineFastState.Bounded env17863 := by
  intro p hp
  have h : env17863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17862_17863 : H12AffineEnvironment.transform 3 8 env17862 = env17863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env17862 == env17863) = true)

theorem identity17863 : scanCanonicalize (H12AffineFastState.compose env17863 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound17863 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17864 : List Nat := [2,3,8,8,1,8,8,2,10,10,0,8,8,1,0,2,8,0,11,1,0,1,8,2,8,9,1,8,9,1,11,0,3,1,1,10]

theorem envBound17864 : H12AffineFastState.Bounded env17864 := by
  intro p hp
  have h : env17864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17863_17864 : H12AffineEnvironment.transform 1 3 env17863 = env17864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env17863 == env17864) = true)

def env17865 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,4160,98679,17,98645,8192,65,10589,5392,17665,76158,1365,95530,257,21792,46093,74251]

theorem envBound17865 : H12AffineFastState.Bounded env17865 := by
  intro p hp
  have h : env17865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17850_17865 : H12AffineEnvironment.transform 22 17 env17850 = env17865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env17850 == env17865) = true)

theorem identity17865 : scanCanonicalize (H12AffineFastState.compose env17865 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound17865 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17866 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1025,32769,4160,32,17,2,8192,65,10589,5392,17665,43049,1365,62589,257,21792,46093,41820]

theorem envBound17866 : H12AffineFastState.Bounded env17866 := by
  intro p hp
  have h : env17866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17865_17866 : H12AffineEnvironment.transform 15 33111 env17865 = env17866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env17865 == env17866) = true)

theorem identity17866 : scanCanonicalize (H12AffineFastState.compose env17866 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17866 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env17867 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,33031,57628,35108,1025,32769,4112,32,17,2,8192,17,10509,5392,17665,43049,1285,62509,257,21792,46093,41740]

theorem envBound17867 : H12AffineFastState.Bounded env17867 := by
  intro p hp
  have h : env17867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17866_17867 : H12AffineEnvironment.transform 5 16 env17866 = env17867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17866 == env17867) = true)

theorem identity17867 : scanCanonicalize (H12AffineFastState.compose env17867 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound17867 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env17868 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13609,32768,33031,37941,35108,1025,32769,4112,32,17,2,8192,17,10509,5392,12328,43049,1285,33028,257,8201,46093,41740]

theorem envBound17868 : H12AffineFastState.Bounded env17868 := by
  intro p hp
  have h : env17868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17867_17868 : H12AffineEnvironment.transform 13 13609 env17867 = env17868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env17867 == env17868) = true)

theorem identity17868 : scanCanonicalize (H12AffineFastState.compose env17868 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound17868 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env17869 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1052,4405,32768,33031,37941,35108,1025,32769,4112,32,17,2,1052,17,3345,5392,5172,35893,1285,33028,257,1045,36881,34576]

theorem envBound17869 : H12AffineFastState.Bounded env17869 := by
  intro p hp
  have h : env17869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17868_17869 : H12AffineEnvironment.transform 12 1052 env17868 = env17869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env17868 == env17869) = true)

theorem identity17869 : scanCanonicalize (H12AffineFastState.compose env17869 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound17869 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env17870 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1052,4405,4113,4374,1060,6453,1025,4112,4112,32,17,2,1052,17,3345,5392,5172,7204,1285,4373,257,1045,0,5889]

theorem envBound17870 : H12AffineFastState.Bounded env17870 := by
  intro p hp
  have h : env17870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17869_17870 : H12AffineEnvironment.transform 14 4113 env17869 = env17870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env17869 == env17870) = true)

theorem identity17870 : scanCanonicalize (H12AffineFastState.compose env17870 (packedSelected [12] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound17870 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env17871 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,4096,1052,4405,4113,4374,1060,4404,1025,4112,4112,32,17,2,1052,17,1296,5392,5172,5157,1285,4373,257,1045,0,5889]

theorem envBound17871 : H12AffineFastState.Bounded env17871 := by
  intro p hp
  have h : env17871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17870_17871 : H12AffineEnvironment.transform 10 1 env17870 = env17871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env17870 == env17871) = true)

theorem identity17871 : scanCanonicalize (H12AffineFastState.compose env17871 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound17871 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env17872 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1,1280,1052,1077,1297,1046,1060,1076,1025,1296,1296,32,17,2,1052,17,1296,16,308,293,1285,1045,257,1045,0,513]

theorem envBound17872 : H12AffineFastState.Bounded env17872 := by
  intro p hp
  have h : env17872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17871_17872 : H12AffineEnvironment.transform 11 1280 env17871 = env17872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env17871 == env17872) = true)

theorem identity17872 : scanCanonicalize (H12AffineFastState.compose env17872 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17872 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env17873 : List Nat := [2,4,8,16,32,16,8,256,512,53,1,309,41,0,292,35,17,1,52,293,293,32,17,2,41,17,293,16,308,293,304,32,257,32,0,513]

theorem envBound17873 : H12AffineFastState.Bounded env17873 := by
  intro p hp
  have h : env17873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17872_17873 : H12AffineEnvironment.transform 9 53 env17872 = env17873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17872 == env17873) = true)

theorem identity17873 : scanCanonicalize (H12AffineFastState.compose env17873 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17873 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17874 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,17,41,0,0,35,17,1,52,1,1,32,17,2,41,17,1,16,16,1,20,32,37,32,0,513]

theorem envBound17874 : H12AffineFastState.Bounded env17874 := by
  intro p hp
  have h : env17874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17873_17874 : H12AffineEnvironment.transform 7 36 env17873 = env17874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17873 == env17874) = true)

theorem identity17874 : scanCanonicalize (H12AffineFastState.compose env17874 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound17874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17875 : List Nat := [2,4,8,16,1,16,8,5,512,20,1,17,8,0,0,2,17,1,21,1,1,1,17,2,8,17,1,16,16,1,20,1,4,1,0,513]

theorem envBound17875 : H12AffineFastState.Bounded env17875 := by
  intro p hp
  have h : env17875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17874_17875 : H12AffineEnvironment.transform 4 1 env17874 = env17875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env17874 == env17875) = true)

theorem identity17875 : scanCanonicalize (H12AffineFastState.compose env17875 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound17875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17876 : List Nat := [2,4,8,1,1,1,8,5,512,5,1,0,8,0,0,2,0,1,4,1,1,1,0,2,8,0,1,1,1,1,5,1,4,1,0,513]

theorem envBound17876 : H12AffineFastState.Bounded env17876 := by
  intro p hp
  have h : env17876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17875_17876 : H12AffineEnvironment.transform 3 1 env17875 = env17876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env17875 == env17876) = true)

def env17877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,4161,98679,8388608,98645,8192,65,8399180,5393,8406289,8464751,8389956,95531,257,8410416,8434717,8462874]

theorem envBound17877 : H12AffineFastState.Bounded env17877 := by
  intro p hp
  have h : env17877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17849_17877 : H12AffineEnvironment.transform 20 4161 env17849 = env17877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env17849 == env17877) = true)

theorem identity17877 : scanCanonicalize (H12AffineFastState.compose env17877 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound17877 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env17878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,35188,1025,32769,4161,98679,73755,98645,8192,65,67927,5393,91402,2420,75103,95531,257,95531,103430,513]

theorem envBound17878 : H12AffineFastState.Bounded env17878 := by
  intro p hp
  have h : env17878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17877_17878 : H12AffineEnvironment.transform 22 73755 env17877 = env17878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env17877 == env17878) = true)

theorem identity17878 : scanCanonicalize (H12AffineFastState.compose env17878 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(15+1) ^^^ 61515) := by decide +kernel

theorem selectedBound17878 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env17879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,61515,36944,35188,1025,32769,4161,28988,53328,28958,8192,65,63772,5393,38209,2420,54548,34144,257,34144,25677,513]

theorem envBound17879 : H12AffineFastState.Bounded env17879 := by
  intro p hp
  have h : env17879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17878_17879 : H12AffineEnvironment.transform 15 61515 env17878 = env17879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 61515 env17878 == env17879) = true)

theorem identity17879 : scanCanonicalize (H12AffineFastState.compose env17879 (packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound17879 : packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env17880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,292,29039,4468,2128,1025,293,4161,28988,20852,28958,8192,65,30776,5393,5221,2420,21552,1092,257,1092,25677,513]

theorem envBound17880 : H12AffineFastState.Bounded env17880 := by
  intro p hp
  have h : env17880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17879_17880 : H12AffineEnvironment.transform 14 292 env17879 = env17880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env17879 == env17880) = true)

theorem identity17880 : scanCanonicalize (H12AffineFastState.compose env17880 (packedSelected [0,2,5,6,7,8,14,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 4200) := by decide +kernel

theorem selectedBound17880 : packedSelected [0,2,5,6,7,8,14,18,20] rootPS < 2^1333 := by decide +kernel

def env17881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4200,16384,292,16647,4468,2128,1025,293,4161,16724,20852,16758,4200,65,18512,5393,5221,2420,21552,1092,257,1092,21541,513]

theorem envBound17881 : H12AffineFastState.Bounded env17881 := by
  intro p hp
  have h : env17881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17880_17881 : H12AffineEnvironment.transform 12 4200 env17880 = env17881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4200 env17880 == env17881) = true)

theorem identity17881 : scanCanonicalize (H12AffineFastState.compose env17881 (packedSelected [1,2,6,12,15,18,24] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound17881 : packedSelected [1,2,6,12,15,18,24] rootPS < 2^1333 := by decide +kernel

def env17882 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,4200,16384,292,16647,4468,2128,52,293,4161,16724,20852,16758,4200,65,18512,4388,4176,2420,20485,113,257,113,20496,513]

theorem envBound17882 : H12AffineFastState.Bounded env17882 := by
  intro p hp
  have h : env17882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17881_17882 : H12AffineEnvironment.transform 9 53 env17881 = env17882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env17881 == env17882) = true)

theorem identity17882 : scanCanonicalize (H12AffineFastState.compose env17882 (packedSelected [3,4,5,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 6500) := by decide +kernel

theorem selectedBound17882 : packedSelected [3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env17883 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,4200,6500,292,6243,4468,2128,52,293,4161,6192,2064,6162,4200,65,4404,4388,4176,2420,2401,113,257,113,2420,513]

theorem envBound17883 : H12AffineFastState.Bounded env17883 := by
  intro p hp
  have h : env17883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17882_17883 : H12AffineEnvironment.transform 13 6500 env17882 = env17883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6500 env17882 == env17883) = true)

theorem identity17883 : scanCanonicalize (H12AffineFastState.compose env17883 (packedSelected [1,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound17883 : packedSelected [1,4,7,8] rootPS < 2^1333 := by decide +kernel

def env17884 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,65,41,2341,292,2082,309,2128,52,293,0,2161,2064,2131,41,65,373,357,17,2420,2401,113,257,113,2420,513]

theorem envBound17884 : H12AffineFastState.Bounded env17884 := by
  intro p hp
  have h : env17884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17883_17884 : H12AffineEnvironment.transform 11 65 env17883 = env17884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env17883 == env17884) = true)

theorem identity17884 : scanCanonicalize (H12AffineFastState.compose env17884 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound17884 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env17885 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,17,41,2341,292,2082,309,2048,52,293,0,2081,2064,2051,41,17,293,309,17,2340,2353,33,257,33,2340,513]

theorem envBound17885 : H12AffineFastState.Bounded env17885 := by
  intro p hp
  have h : env17885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17884_17885 : H12AffineEnvironment.transform 5 16 env17884 = env17885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env17884 == env17885) = true)

theorem identity17885 : scanCanonicalize (H12AffineFastState.compose env17885 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound17885 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17886 : List Nat := [2,4,8,16,32,16,8,256,512,53,0,17,41,293,292,34,309,0,52,293,0,33,16,3,41,17,293,309,17,292,305,33,257,33,292,513]

theorem envBound17886 : H12AffineFastState.Bounded env17886 := by
  intro p hp
  have h : env17886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17885_17886 : H12AffineEnvironment.transform 10 0 env17885 = env17886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env17885 == env17886) = true)

theorem identity17886 : scanCanonicalize (H12AffineFastState.compose env17886 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound17886 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env17887 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,17,41,1,0,34,17,0,52,1,0,33,16,3,41,17,1,17,17,0,21,33,37,33,0,513]

theorem envBound17887 : H12AffineFastState.Bounded env17887 := by
  intro p hp
  have h : env17887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17886_17887 : H12AffineEnvironment.transform 7 36 env17886 = env17887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env17886 == env17887) = true)

theorem identity17887 : scanCanonicalize (H12AffineFastState.compose env17887 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound17887 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env17888 : List Nat := [2,4,8,16,32,16,8,36,0,53,0,17,41,1,0,34,17,0,52,1,0,33,16,3,41,17,1,17,17,0,21,33,37,33,0,1]

theorem envBound17888 : H12AffineFastState.Bounded env17888 := by
  intro p hp
  have h : env17888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17887_17888 : H12AffineEnvironment.transform 8 0 env17887 = env17888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env17887 == env17888) = true)

theorem identity17888 : scanCanonicalize (H12AffineFastState.compose env17888 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound17888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env17889 : List Nat := [2,4,8,16,10,16,8,14,0,31,0,17,3,1,0,8,17,0,30,1,0,11,16,3,3,17,1,17,17,0,21,11,15,11,0,1]

theorem envBound17889 : H12AffineFastState.Bounded env17889 := by
  intro p hp
  have h : env17889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17888_17889 : H12AffineEnvironment.transform 4 10 env17888 = env17889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env17888 == env17889) = true)

def env17890 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575541,18973700,10507600,8538484,25265169,23160137,257,27378725,27337993,25207630]

theorem envBound17890 : H12AffineFastState.Bounded env17890 := by
  intro p hp
  have h : env17890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17838_17890 : H12AffineEnvironment.transform 6 9 env17838 = env17890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env17838 == env17890) = true)

def env17891 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,16777216,8193,65,21039477,18973700,2233680,2420,17024017,23160137,257,19104805,19096841,16966478]

theorem envBound17891 : H12AffineFastState.Bounded env17891 := by
  intro p hp
  have h : env17891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17890_17891 : H12AffineEnvironment.transform 22 147456 env17890 = env17891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env17890 == env17891) = true)

theorem identity17891 : scanCanonicalize (H12AffineFastState.compose env17891 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound17891 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env17892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,188751,8193,65,4450362,2319691,2233680,2420,75102,6521862,257,2188650,2196550,513]

theorem envBound17892 : H12AffineFastState.Bounded env17892 := by
  intro p hp
  have h : env17892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17891_17892 : H12AffineEnvironment.transform 23 188751 env17891 = env17892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env17891 == env17892) = true)

def env17893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,41311,8193,65,4302890,2172251,2118976,2420,75102,6407190,257,2188650,2196550,513]

theorem envBound17893 : H12AffineFastState.Bounded env17893 := by
  intro p hp
  have h : env17893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17892_17893 : H12AffineEnvironment.transform 16 16400 env17892 = env17893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env17892 == env17893) = true)

theorem identity17893 : scanCanonicalize (H12AffineFastState.compose env17893 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound17893 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env17894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1025,32769,2097152,4194304,16,41311,8193,65,4229153,2098512,2118976,2420,1365,6349853,257,2114913,2139213,513]

theorem envBound17894 : H12AffineFastState.Bounded env17894 := by
  intro p hp
  have h : env17894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17893_17894 : H12AffineEnvironment.transform 15 8203 env17893 = env17894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env17893 == env17894) = true)

theorem identity17894 : scanCanonicalize (H12AffineFastState.compose env17894 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound17894 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env17895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,35188,1025,32769,2097152,32,16,41311,8193,65,34817,2098512,2118976,2420,1365,2155581,257,2114913,2139213,513]

theorem envBound17895 : H12AffineFastState.Bounded env17895 := by
  intro p hp
  have h : env17895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17894_17895 : H12AffineEnvironment.transform 21 32 env17894 = env17895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env17894 == env17895) = true)

theorem identity17895 : scanCanonicalize (H12AffineFastState.compose env17895 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound17895 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env17896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8203,16400,10280,1025,8541,2097152,32,16,3,8193,65,10589,2098512,2118976,2420,1365,2114913,257,2114913,2098449,513]

theorem envBound17896 : H12AffineFastState.Bounded env17896 := by
  intro p hp
  have h : env17896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17895_17896 : H12AffineEnvironment.transform 14 8540 env17895 = env17896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env17895 == env17896) = true)

theorem identity17896 : scanCanonicalize (H12AffineFastState.compose env17896 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound17896 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env17897 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8203,16400,10280,1025,8460,2097152,32,16,3,8193,16,10508,2098433,2118929,2341,1284,2114864,257,2114864,2098449,513]

theorem envBound17897 : H12AffineFastState.Bounded env17897 := by
  intro p hp
  have h : env17897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17896_17897 : H12AffineEnvironment.transform 5 17 env17896 = env17897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env17896 == env17897) = true)

theorem identity17897 : scanCanonicalize (H12AffineFastState.compose env17897 (packedSelected [5,8] rootPS)) = affineNative (2^(20+1) ^^^ 26664) := by decide +kernel

theorem selectedBound17897 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env17898 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8461,8203,16400,10280,1025,8460,26664,32,16,3,8193,16,10508,27945,15673,2341,1284,11544,257,11544,27961,513]

theorem envBound17898 : H12AffineFastState.Bounded env17898 := by
  intro p hp
  have h : env17898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17897_17898 : H12AffineEnvironment.transform 20 26664 env17897 = env17898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26664 env17897 == env17898) = true)

theorem identity17898 : scanCanonicalize (H12AffineFastState.compose env17898 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 6420) := by decide +kernel

theorem selectedBound17898 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env17899 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,6420,8461,8203,6404,10280,1025,8460,12604,32,16,3,8193,16,10508,13373,15673,2341,1284,11544,257,11544,13357,513]

theorem envBound17899 : H12AffineFastState.Bounded env17899 := by
  intro p hp
  have h : env17899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17898_17899 : H12AffineEnvironment.transform 13 6420 env17898 = env17899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6420 env17898 == env17899) = true)

theorem identity17899 : scanCanonicalize (H12AffineFastState.compose env17899 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 261) := by decide +kernel

theorem selectedBound17899 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env17900 : List Nat := [2,4,8,16,32,17,9,256,512,1024,261,4096,8192,4113,8461,8203,4097,8493,1025,8460,12604,32,16,3,8193,16,8201,13373,13372,32,1284,9245,257,9245,13357,513]

theorem envBound17900 : H12AffineFastState.Bounded env17900 := by
  intro p hp
  have h : env17900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17899_17900 : H12AffineEnvironment.transform 10 261 env17899 = env17900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 261 env17899 == env17900) = true)

theorem identity17900 : scanCanonicalize (H12AffineFastState.compose env17900 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound17900 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env17901 : List Nat := [2,4,8,16,32,17,9,256,512,1024,261,1061,8192,1076,8461,8203,1060,8493,1025,8460,9497,32,16,3,8193,16,8201,8216,8217,32,1284,9245,257,9245,8200,513]

theorem envBound17901 : H12AffineFastState.Bounded env17901 := by
  intro p hp
  have h : env17901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17900_17901 : H12AffineEnvironment.transform 11 1061 env17900 = env17901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env17900 == env17901) = true)

theorem identity17901 : scanCanonicalize (H12AffineFastState.compose env17901 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound17901 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env17902 : List Nat := [2,4,8,16,32,17,9,256,17,1024,261,1061,8192,1076,8461,8203,1060,8493,1025,8460,9497,32,16,3,8193,16,8201,8216,8217,32,1284,9245,257,9245,8200,16]

theorem envBound17902 : H12AffineFastState.Bounded env17902 := by
  intro p hp
  have h : env17902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17901_17902 : H12AffineEnvironment.transform 8 17 env17901 = env17902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env17901 == env17902) = true)

theorem identity17902 : scanCanonicalize (H12AffineFastState.compose env17902 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(12+1) ^^^ 1037) := by decide +kernel

theorem selectedBound17902 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env17903 : List Nat := [2,4,8,16,32,17,9,256,17,1024,261,1061,1037,1076,1280,1030,1060,1312,1025,1281,276,32,16,3,1036,16,1028,1045,1044,32,1284,16,257,16,1029,16]

theorem envBound17903 : H12AffineFastState.Bounded env17903 := by
  intro p hp
  have h : env17903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans17902_17903 : H12AffineEnvironment.transform 12 1037 env17902 = env17903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1037 env17902 == env17903) = true)

end H12CloudChart1