import H12CloudChart1Data111

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity28381 : scanCanonicalize (H12AffineFastState.compose env28381 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound28381 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28382 : List Nat := [2,4,8,1,1,0,8,5,1,4,0,1,9,0,1,2,1,1,5,0,1,1,0,3,9,0,1,1,1,0,5,0,4,1,1,0]

theorem envBound28382 : H12AffineFastState.Bounded env28382 := by
  intro p hp
  have h : env28382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28381_28382 : H12AffineEnvironment.transform 5 0 env28381 = env28382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28381 == env28382) = true)

def env28383 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32121,1025,29788,2097152,21873,2101329,2114883,8193,64,97546,79131,17664,2125113,75103,95610,257,2188651,2191387,513]

theorem envBound28383 : H12AffineFastState.Bounded env28383 := by
  intro p hp
  have h : env28383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28369_28383 : H12AffineEnvironment.transform 6 9 env28369 = env28383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28369 == env28383) = true)

theorem identity28383 : scanCanonicalize (H12AffineFastState.compose env28383 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 4112) := by decide +kernel

theorem selectedBound28383 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env28384 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32121,1025,29788,4112,21873,65,21843,8193,64,97546,79131,17664,32041,75103,95610,257,95611,90123,513]

theorem envBound28384 : H12AffineFastState.Bounded env28384 := by
  intro p hp
  have h : env28384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28383_28384 : H12AffineEnvironment.transform 20 4112 env28383 = env28384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4112 env28383 == env28384) = true)

theorem identity28384 : scanCanonicalize (H12AffineFastState.compose env28384 (packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound28384 : packedSelected [0,2,3,5,6,7,10,12,15,20] rootPS < 2^1333 := by decide +kernel

def env28385 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8461,65536,13389,10281,1025,8460,4112,33,65,3,8193,64,75866,79131,4176,10361,75103,73770,257,73771,79195,513]

theorem envBound28385 : H12AffineFastState.Bounded env28385 := by
  intro p hp
  have h : env28385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28384_28385 : H12AffineEnvironment.transform 13 5456 env28384 = env28385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env28384 == env28385) = true)

theorem identity28385 : scanCanonicalize (H12AffineFastState.compose env28385 (packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28385 : packedSelected [1,2,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env28386 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8461,8202,13389,10281,1025,8460,4112,33,65,3,8193,64,2128,5393,4176,10361,1365,32,257,33,5457,513]

theorem envBound28386 : H12AffineFastState.Bounded env28386 := by
  intro p hp
  have h : env28386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28385_28386 : H12AffineEnvironment.transform 15 8202 env28385 = env28386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28385 == env28386) = true)

def env28387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,13389,32241,1025,29909,2097152,21872,2101329,2114883,8328,64,97546,79131,17664,2125112,75222,95730,257,2188651,2191387,513]

theorem envBound28387 : H12AffineFastState.Bounded env28387 := by
  intro p hp
  have h : env28387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28368_28387 : H12AffineEnvironment.transform 17 32241 env28368 = env28387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env28368 == env28387) = true)

theorem identity28387 : scanCanonicalize (H12AffineFastState.compose env28387 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28387 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env28388 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13389,32120,1025,29788,2097152,21872,2101329,2114883,8193,64,97546,79131,17664,2125112,75103,95611,257,2188651,2191387,513]

theorem envBound28388 : H12AffineFastState.Bounded env28388 := by
  intro p hp
  have h : env28388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28387_28388 : H12AffineEnvironment.transform 6 9 env28387 = env28388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28387 == env28388) = true)

theorem identity28388 : scanCanonicalize (H12AffineFastState.compose env28388 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28388 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env28389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,13389,32120,1025,29788,2097152,21872,2101329,2114883,8193,64,23808,5393,17664,2125112,1365,21873,257,2114913,2117649,513]

theorem envBound28389 : H12AffineFastState.Bounded env28389 := by
  intro p hp
  have h : env28389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28388_28389 : H12AffineEnvironment.transform 15 8202 env28388 = env28389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28388 == env28389) = true)

theorem identity28389 : scanCanonicalize (H12AffineFastState.compose env28389 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28389 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env28390 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,29708,8202,13340,32041,1025,29709,2097152,21793,2101248,2114834,8193,17,23808,5393,17664,2125112,1284,21792,257,2114864,2117649,513]

theorem envBound28390 : H12AffineFastState.Bounded env28390 := by
  intro p hp
  have h : env28390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28389_28390 : H12AffineEnvironment.transform 5 17 env28389 = env28390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28389 == env28390) = true)

def env28391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507600,155254785,25265169,145662400,525568,140903597,27337993,25733062]

theorem envBound28391 : H12AffineFastState.Bounded env28391 := by
  intro p hp
  have h : env28391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans27689_28391 : H12AffineEnvironment.transform 25 65 env27689 = env28391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env27689 == env28391) = true)

def env28392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507600,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound28392 : H12AffineFastState.Bounded env28392 := by
  intro p hp
  have h : env28392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28391_28392 : H12AffineEnvironment.transform 26 30393344 env28391 = env28392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env28391 == env28392) = true)

def env28393 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound28393 : H12AffineFastState.Bounded env28393 := by
  intro p hp
  have h : env28393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28392_28393 : H12AffineEnvironment.transform 18 1024 env28392 = env28393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env28392 == env28393) = true)

theorem identity28393 : scanCanonicalize (H12AffineFastState.compose env28393 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound28393 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28394 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362363,18973837,10507600,8456378,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound28394 : H12AffineFastState.Bounded env28394 := by
  intro p hp
  have h : env28394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28393_28394 : H12AffineEnvironment.transform 17 247995 env28393 = env28394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env28393 == env28394) = true)

def env28395 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784807,5393,10507600,8456378,10491277,4256860,256,8410417,8434837,10564186]

theorem envBound28395 : H12AffineFastState.Bounded env28395 := by
  intro p hp
  have h : env28395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28394_28395 : H12AffineEnvironment.transform 23 2199964 env28394 = env28395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env28394 == env28395) = true)

def env28396 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,8388608,98780,8328,65,12683623,5393,8406288,8456378,8390093,4256860,256,8410417,8434837,8462874]

theorem envBound28396 : H12AffineFastState.Bounded env28396 := by
  intro p hp
  have h : env28396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28395_28396 : H12AffineEnvironment.transform 20 4160 env28395 = env28396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28395 == env28396) = true)

def env28397 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374560,98780,8328,65,215367,5393,4359472,4442266,4376045,4256860,256,4363537,4355253,4448826]

theorem envBound28397 : H12AffineFastState.Bounded env28397 := by
  intro p hp
  have h : env28397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28396_28397 : H12AffineEnvironment.transform 22 4374560 env28396 = env28397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env28396 == env28397) = true)

theorem identity28397 : scanCanonicalize (H12AffineFastState.compose env28397 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28397 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28398 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4160,4194304,4374560,41431,8328,65,158028,5393,4359472,4384913,4376045,4256860,256,4363537,4355253,4375089]

theorem envBound28398 : H12AffineFastState.Bounded env28398 := by
  intro p hp
  have h : env28398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28397_28398 : H12AffineEnvironment.transform 15 8203 env28397 = env28398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28397 == env28398) = true)

theorem identity28398 : scanCanonicalize (H12AffineFastState.compose env28398 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound28398 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28399 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190640,1024,32769,4160,180272,16,41431,8328,65,158028,5393,17664,10401,1501,144492,256,21793,46213,513]

theorem envBound28399 : H12AffineFastState.Bounded env28399 := by
  intro p hp
  have h : env28399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28398_28399 : H12AffineEnvironment.transform 21 180272 env28398 = env28399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env28398 == env28399) = true)

theorem identity28399 : scanCanonicalize (H12AffineFastState.compose env28399 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound28399 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env28400 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43168,1024,32769,4160,32800,16,41431,8328,65,10588,5393,17664,10401,1501,29820,256,21793,46213,513]

theorem envBound28400 : H12AffineFastState.Bounded env28400 := by
  intro p hp
  have h : env28400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28399_28400 : H12AffineEnvironment.transform 16 16400 env28399 = env28400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28399 == env28400) = true)

theorem identity28400 : scanCanonicalize (H12AffineFastState.compose env28400 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28400 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env28401 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,32768,8203,13389,43168,1024,32769,4160,32800,16,41431,8328,65,10588,5393,12637,10401,1501,33,256,8572,46213,513]

theorem envBound28401 : H12AffineFastState.Bounded env28401 := by
  intro p hp
  have h : env28401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28400_28401 : H12AffineEnvironment.transform 13 13405 env28400 = env28401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28400 == env28401) = true)

theorem identity28401 : scanCanonicalize (H12AffineFastState.compose env28401 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28401 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,8540,8203,13389,2556,1024,8541,4160,8572,16,139,8328,65,10588,5393,12637,10401,1501,33,256,8572,5593,513]

theorem envBound28402 : H12AffineFastState.Bounded env28402 := by
  intro p hp
  have h : env28402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28401_28402 : H12AffineEnvironment.transform 14 8540 env28401 = env28402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28401 == env28402) = true)

theorem identity28402 : scanCanonicalize (H12AffineFastState.compose env28402 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28402 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,0,343,5393,2556,1024,1,4160,32,16,139,468,65,2048,5393,4097,2557,1501,33,256,32,5593,513]

theorem envBound28403 : H12AffineFastState.Bounded env28403 := by
  intro p hp
  have h : env28403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28402_28403 : H12AffineEnvironment.transform 12 348 env28402 = env28403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28402 == env28403) = true)

theorem identity28403 : scanCanonicalize (H12AffineFastState.compose env28403 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2420) := by decide +kernel

theorem selectedBound28403 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28404 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2420,348,3189,0,343,3173,2556,1024,1,2356,32,16,139,468,65,2048,3173,2421,2557,1501,33,256,32,3245,513]

theorem envBound28404 : H12AffineFastState.Bounded env28404 := by
  intro p hp
  have h : env28404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28403_28404 : H12AffineEnvironment.transform 11 2420 env28403 = env28404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2420 env28403 == env28404) = true)

theorem identity28404 : scanCanonicalize (H12AffineFastState.compose env28404 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 231) := by decide +kernel

theorem selectedBound28404 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env28405 : List Nat := [2,4,8,16,32,64,128,231,512,1024,2048,2195,187,3189,0,176,3173,2075,1024,1,2259,32,16,139,51,65,2048,3173,2194,2074,1082,33,231,32,3245,513]

theorem envBound28405 : H12AffineFastState.Bounded env28405 := by
  intro p hp
  have h : env28405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28404_28405 : H12AffineEnvironment.transform 7 231 env28404 = env28405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 231 env28404 == env28405) = true)

theorem identity28405 : scanCanonicalize (H12AffineFastState.compose env28405 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28405 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env28406 : List Nat := [2,4,8,16,32,64,8,111,512,1024,2048,2075,51,3189,0,56,3173,2075,1024,1,2139,32,16,3,51,65,2048,3173,2074,2074,1082,33,111,32,3109,513]

theorem envBound28406 : H12AffineFastState.Bounded env28406 := by
  intro p hp
  have h : env28406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28405_28406 : H12AffineEnvironment.transform 6 8 env28405 = env28406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28405 == env28406) = true)

theorem identity28406 : scanCanonicalize (H12AffineFastState.compose env28406 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 126) := by decide +kernel

theorem selectedBound28406 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28407 : List Nat := [2,4,8,16,32,64,8,111,512,126,2048,2075,51,2059,0,56,2075,2075,126,1,2139,32,16,3,51,65,2048,2075,2074,2074,68,33,111,32,2139,513]

theorem envBound28407 : H12AffineFastState.Bounded env28407 := by
  intro p hp
  have h : env28407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28406_28407 : H12AffineEnvironment.transform 9 126 env28406 = env28407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 126 env28406 == env28407) = true)

theorem identity28407 : scanCanonicalize (H12AffineFastState.compose env28407 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound28407 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28408 : List Nat := [2,4,8,16,32,1,8,46,512,63,2048,2075,51,2059,0,56,2075,2075,63,1,2074,32,16,3,51,0,2048,2075,2074,2074,5,33,46,32,2074,513]

theorem envBound28408 : H12AffineFastState.Bounded env28408 := by
  intro p hp
  have h : env28408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28407_28408 : H12AffineEnvironment.transform 5 1 env28407 = env28408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env28407 == env28408) = true)

theorem identity28408 : scanCanonicalize (H12AffineFastState.compose env28408 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 531) := by decide +kernel

theorem selectedBound28408 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env28409 : List Nat := [2,4,8,16,32,1,8,46,512,63,531,520,51,536,0,56,520,520,63,1,521,32,16,3,51,0,531,520,521,521,5,33,46,32,521,513]

theorem envBound28409 : H12AffineFastState.Bounded env28409 := by
  intro p hp
  have h : env28409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28408_28409 : H12AffineEnvironment.transform 10 531 env28408 = env28409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 531 env28408 == env28409) = true)

theorem identity28409 : scanCanonicalize (H12AffineFastState.compose env28409 (packedSelected [8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28409 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env28410 : List Nat := [2,4,8,11,32,1,8,46,512,36,520,520,40,515,0,35,520,520,36,1,521,32,11,3,40,0,520,520,521,521,5,33,46,32,521,513]

theorem envBound28410 : H12AffineFastState.Bounded env28410 := by
  intro p hp
  have h : env28410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28409_28410 : H12AffineEnvironment.transform 3 11 env28409 = env28410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28409 == env28410) = true)

theorem identity28410 : scanCanonicalize (H12AffineFastState.compose env28410 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 12) := by decide +kernel

theorem selectedBound28410 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28411 : List Nat := [2,4,8,11,32,1,8,46,12,36,4,4,40,15,0,35,4,4,36,1,5,32,11,3,40,0,4,4,5,5,5,33,46,32,5,13]

theorem envBound28411 : H12AffineFastState.Bounded env28411 := by
  intro p hp
  have h : env28411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28410_28411 : H12AffineEnvironment.transform 8 12 env28410 = env28411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 12 env28410 == env28411) = true)

theorem identity28411 : scanCanonicalize (H12AffineFastState.compose env28411 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28411 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env28412 : List Nat := [2,4,3,0,32,1,3,37,7,36,4,4,35,4,0,35,4,4,36,1,5,32,0,3,35,0,4,4,5,5,5,33,37,32,5,6]

theorem envBound28412 : H12AffineFastState.Bounded env28412 := by
  intro p hp
  have h : env28412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28411_28412 : H12AffineEnvironment.transform 2 3 env28411 = env28412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28411 == env28412) = true)

theorem identity28412 : scanCanonicalize (H12AffineFastState.compose env28412 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound28412 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28413 : List Nat := [2,4,3,0,5,1,3,0,7,1,4,4,6,4,0,6,4,4,1,1,5,5,0,3,6,0,4,4,5,5,5,4,0,5,5,6]

theorem envBound28413 : H12AffineFastState.Bounded env28413 := by
  intro p hp
  have h : env28413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28412_28413 : H12AffineEnvironment.transform 4 5 env28412 = env28413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env28412 == env28413) = true)

def env28414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374561,98780,8328,65,215366,5393,4359473,4442267,4376044,4256860,256,4363536,4355252,4448827]

theorem envBound28414 : H12AffineFastState.Bounded env28414 := by
  intro p hp
  have h : env28414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28396_28414 : H12AffineEnvironment.transform 22 4374561 env28396 = env28414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env28396 == env28414) = true)

theorem identity28414 : scanCanonicalize (H12AffineFastState.compose env28414 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254010) := by decide +kernel

theorem selectedBound28414 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,254010,73755,98780,8328,65,215366,5393,91403,10401,75222,201830,256,95530,103566,513]

theorem envBound28415 : H12AffineFastState.Bounded env28415 := by
  intro p hp
  have h : env28415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28414_28415 : H12AffineEnvironment.transform 21 254010 env28414 = env28415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254010 env28414 == env28415) = true)

def env28416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,254010,73755,98644,8192,65,215366,5393,91403,10281,75102,201830,256,95530,103430,513]

theorem envBound28416 : H12AffineFastState.Bounded env28416 := by
  intro p hp
  have h : env28416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28415_28416 : H12AffineEnvironment.transform 6 8 env28415 = env28416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28415 == env28416) = true)

theorem identity28416 : scanCanonicalize (H12AffineFastState.compose env28416 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28416 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env28417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,43049,1024,32769,4160,32800,73755,98644,8192,65,10588,5393,91403,10281,75102,29820,256,95530,103430,513]

theorem envBound28417 : H12AffineFastState.Bounded env28417 := by
  intro p hp
  have h : env28417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28416_28417 : H12AffineEnvironment.transform 16 90138 env28416 = env28417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28416 == env28417) = true)

theorem identity28417 : scanCanonicalize (H12AffineFastState.compose env28417 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound28417 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env28418 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,65536,90138,23588,1024,29708,4160,29741,73755,95577,8192,65,10588,5393,91403,10281,75102,29820,256,95530,90123,513]

theorem envBound28418 : H12AffineFastState.Bounded env28418 := by
  intro p hp
  have h : env28418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28417_28418 : H12AffineEnvironment.transform 14 29709 env28417 = env28418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env28417 == env28418) = true)

theorem identity28418 : scanCanonicalize (H12AffineFastState.compose env28418 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 9278) := by decide +kernel

theorem selectedBound28418 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,9278,17444,23588,1024,29708,4160,29741,1061,20839,8192,65,10588,5393,16693,10281,352,29820,256,20756,17461,513]

theorem envBound28419 : H12AffineFastState.Bounded env28419 := by
  intro p hp
  have h : env28419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28418_28419 : H12AffineEnvironment.transform 15 9278 env28418 = env28419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9278 env28418 == env28419) = true)

theorem identity28419 : scanCanonicalize (H12AffineFastState.compose env28419 (packedSelected [1,3,17,24,28] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28419 : packedSelected [1,3,17,24,28] rootPS < 2^1333 := by decide +kernel

def env28420 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,16384,28729,8202,16400,22544,52,28728,4160,28697,17,20839,8192,65,10588,4389,16693,10281,352,28744,256,20756,16385,513]

theorem envBound28420 : H12AffineFastState.Bounded env28420 := by
  intro p hp
  have h : env28420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28419_28420 : H12AffineEnvironment.transform 9 52 env28419 = env28420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28419 == env28420) = true)

theorem identity28420 : scanCanonicalize (H12AffineFastState.compose env28420 (packedSelected [2,3,4,7,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound28420 : packedSelected [2,3,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env28421 : List Nat := [2,4,8,16,32,64,8,256,512,52,2048,4096,8192,12392,81,8202,12408,10360,52,80,4160,113,17,8463,8192,65,10588,4389,12637,10281,352,32,256,8572,12393,513]

theorem envBound28421 : H12AffineFastState.Bounded env28421 := by
  intro p hp
  have h : env28421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28420_28421 : H12AffineEnvironment.transform 13 12392 env28420 = env28421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env28420 == env28421) = true)

theorem identity28421 : scanCanonicalize (H12AffineFastState.compose env28421 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28421 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28422 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,4096,8192,12345,0,8202,12329,10281,52,1,4113,32,17,8463,8192,16,10509,4389,12556,10281,305,32,256,8493,12344,513]

theorem envBound28422 : H12AffineFastState.Bounded env28422 := by
  intro p hp
  have h : env28422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28421_28422 : H12AffineEnvironment.transform 5 17 env28421 = env28422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28421 == env28422) = true)

theorem identity28422 : scanCanonicalize (H12AffineFastState.compose env28422 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28422 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28423 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,17,8192,8232,0,8202,8248,10281,52,1,0,32,17,8463,8192,16,10509,308,8477,10281,305,32,256,8493,8233,513]

theorem envBound28423 : H12AffineFastState.Bounded env28423 := by
  intro p hp
  have h : env28423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28422_28423 : H12AffineEnvironment.transform 11 17 env28422 = env28423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28422 == env28423) = true)

theorem identity28423 : scanCanonicalize (H12AffineFastState.compose env28423 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound28423 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28424 : List Nat := [2,4,8,16,32,17,8,256,512,52,292,17,8192,8232,0,8202,8248,8461,52,1,0,32,17,8463,8192,16,8233,308,8477,8461,305,32,256,8493,8233,513]

theorem envBound28424 : H12AffineFastState.Bounded env28424 := by
  intro p hp
  have h : env28424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28423_28424 : H12AffineEnvironment.transform 10 292 env28423 = env28424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env28423 == env28424) = true)

def env28425 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,254010,73755,98645,8193,65,215366,5393,91403,10280,75103,201830,256,95530,103431,513]

theorem envBound28425 : H12AffineFastState.Bounded env28425 := by
  intro p hp
  have h : env28425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28415_28425 : H12AffineEnvironment.transform 6 9 env28415 = env28425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28415 == env28425) = true)

theorem identity28425 : scanCanonicalize (H12AffineFastState.compose env28425 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound28425 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env28426 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10281,1024,32769,4160,33,73755,98645,8193,65,43357,5393,91403,10280,75103,62589,256,95530,103431,513]

theorem envBound28426 : H12AffineFastState.Bounded env28426 := by
  intro p hp
  have h : env28426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28425_28426 : H12AffineEnvironment.transform 16 122907 env28425 = env28426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env28425 == env28426) = true)

theorem identity28426 : scanCanonicalize (H12AffineFastState.compose env28426 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28426 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env28427 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10281,1024,32769,4160,33,16,41310,8193,65,43357,5393,17664,10280,1364,62589,256,21793,46092,513]

theorem envBound28427 : H12AffineFastState.Bounded env28427 := by
  intro p hp
  have h : env28427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28426_28427 : H12AffineEnvironment.transform 15 8203 env28426 = env28427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28426 == env28427) = true)

theorem identity28427 : scanCanonicalize (H12AffineFastState.compose env28427 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28427 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env28428 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,32768,262,49168,2340,1024,32769,4160,33,16,32851,268,65,34896,5393,17664,2341,1364,54640,256,21793,38145,513]

theorem envBound28428 : H12AffineFastState.Bounded env28428 := by
  intro p hp
  have h : env28428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28427_28428 : H12AffineEnvironment.transform 12 269 env28427 = env28428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28427 == env28428) = true)

theorem identity28428 : scanCanonicalize (H12AffineFastState.compose env28428 (packedSelected [3,4,5,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound28428 : packedSelected [3,4,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env28429 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,32768,262,38209,2340,1024,32769,4160,33,16,32851,268,65,34896,5393,4177,2341,1364,32801,256,112,38145,513]

theorem envBound28429 : H12AffineFastState.Bounded env28429 := by
  intro p hp
  have h : env28429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28428_28429 : H12AffineEnvironment.transform 13 5457 env28428 = env28429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env28428 == env28429) = true)

theorem identity28429 : scanCanonicalize (H12AffineFastState.compose env28429 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound28429 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,80,262,5393,2340,1024,81,4160,33,16,3,268,65,2048,5393,4177,2341,1364,113,256,112,5457,513]

theorem envBound28430 : H12AffineFastState.Bounded env28430 := by
  intro p hp
  have h : env28430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28429_28430 : H12AffineEnvironment.transform 14 80 env28429 = env28430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env28429 == env28430) = true)

theorem identity28430 : scanCanonicalize (H12AffineFastState.compose env28430 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound28430 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env28431 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2096,269,3425,80,262,3361,2340,1024,81,2160,33,16,3,268,65,2048,3361,2145,2341,1364,113,256,112,3425,513]

theorem envBound28431 : H12AffineFastState.Bounded env28431 := by
  intro p hp
  have h : env28431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28430_28431 : H12AffineEnvironment.transform 11 2096 env28430 = env28431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env28430 == env28431) = true)

theorem identity28431 : scanCanonicalize (H12AffineFastState.compose env28431 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound28431 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28432 : List Nat := [2,4,8,16,32,64,9,256,512,305,2048,2096,269,2128,80,262,2064,2340,305,81,2160,33,16,3,268,65,2048,2064,2145,2341,101,113,256,112,2128,513]

theorem envBound28432 : H12AffineFastState.Bounded env28432 := by
  intro p hp
  have h : env28432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28431_28432 : H12AffineEnvironment.transform 9 305 env28431 = env28432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env28431 == env28432) = true)

theorem identity28432 : scanCanonicalize (H12AffineFastState.compose env28432 (packedSelected [4,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28432 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env28433 : List Nat := [2,4,8,16,32,48,9,256,512,305,2048,2096,269,2080,32,262,2064,2340,305,33,2048,33,16,3,268,49,2048,2064,2065,2341,21,1,256,0,2080,513]

theorem envBound28433 : H12AffineFastState.Bounded env28433 := by
  intro p hp
  have h : env28433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28432_28433 : H12AffineEnvironment.transform 5 48 env28432 = env28433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28432 == env28433) = true)

theorem identity28433 : scanCanonicalize (H12AffineFastState.compose env28433 (packedSelected [3,5,19] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28433 : packedSelected [3,5,19] rootPS < 2^1333 := by decide +kernel

def env28434 : List Nat := [2,4,8,16,1,17,9,256,512,272,2048,2065,269,2049,1,262,2064,2309,272,0,2048,0,16,3,268,16,2048,2064,2065,2308,21,1,256,0,2049,513]

theorem envBound28434 : H12AffineFastState.Bounded env28434 := by
  intro p hp
  have h : env28434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28433_28434 : H12AffineEnvironment.transform 4 1 env28433 = env28434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28433 == env28434) = true)

theorem identity28434 : scanCanonicalize (H12AffineFastState.compose env28434 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound28434 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28435 : List Nat := [2,4,8,16,1,17,9,256,512,272,260,277,269,261,1,262,276,1,272,0,260,0,16,3,268,16,260,276,277,0,21,1,256,0,261,513]

theorem envBound28435 : H12AffineFastState.Bounded env28435 := by
  intro p hp
  have h : env28435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28434_28435 : H12AffineEnvironment.transform 10 260 env28434 = env28435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env28434 == env28435) = true)

def env28436 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,8388608,98781,8328,65,12683622,5393,8406289,8456378,8390092,4256860,256,8410417,8434837,8462875]

theorem envBound28436 : H12AffineFastState.Bounded env28436 := by
  intro p hp
  have h : env28436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28395_28436 : H12AffineEnvironment.transform 20 4161 env28395 = env28436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28395 == env28436) = true)

def env28437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374560,98781,8328,65,215366,5393,4359473,4442266,4376044,4256860,256,4363537,4355253,4448827]

theorem envBound28437 : H12AffineFastState.Bounded env28437 := by
  intro p hp
  have h : env28437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28436_28437 : H12AffineEnvironment.transform 22 4374560 env28436 = env28437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env28436 == env28437) = true)

theorem identity28437 : scanCanonicalize (H12AffineFastState.compose env28437 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound28437 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138341,1024,32769,4161,4194304,4374560,21763,8328,65,171416,5393,4359473,4332612,4376044,4256860,256,4363537,4355253,4339429]

theorem envBound28438 : H12AffineFastState.Bounded env28438 := by
  intro p hp
  have h : env28438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28437_28438 : H12AffineEnvironment.transform 15 54494 env28437 = env28438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env28437 == env28438) = true)

def env28439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138341,1024,32769,4161,180408,152,21763,8328,65,171416,5393,17801,56572,1364,144612,256,21929,46093,63069]

theorem envBound28439 : H12AffineFastState.Bounded env28439 := by
  intro p hp
  have h : env28439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28438_28439 : H12AffineEnvironment.transform 21 180408 env28438 = env28439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env28438 == env28439) = true)

theorem identity28439 : scanCanonicalize (H12AffineFastState.compose env28439 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28439 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env28440 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,30082,131072,138341,1024,8541,4161,156132,152,21763,8328,65,146628,5393,17801,32160,1364,144612,256,21929,5457,22273]

theorem envBound28440 : H12AffineFastState.Bounded env28440 := by
  intro p hp
  have h : env28440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28439_28440 : H12AffineEnvironment.transform 14 8540 env28439 = env28440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28439 == env28440) = true)

theorem identity28440 : scanCanonicalize (H12AffineFastState.compose env28440 (packedSelected [1,17,18,19,23,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound28440 : packedSelected [1,17,18,19,23,28,31] rootPS < 2^1333 := by decide +kernel

def env28441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,136,21590,131072,138341,1024,137,4161,147504,152,21763,348,65,138512,5393,17801,23668,1364,136496,256,21929,5457,22273]

theorem envBound28441 : H12AffineFastState.Bounded env28441 := by
  intro p hp
  have h : env28441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28440_28441 : H12AffineEnvironment.transform 12 468 env28440 = env28441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env28440 == env28441) = true)

theorem identity28441 : scanCanonicalize (H12AffineFastState.compose env28441 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound28441 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env28442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,479,131072,138341,1024,137,4161,136633,152,138,348,65,138512,5393,4096,2557,1364,136496,256,32,5457,648]

theorem envBound28442 : H12AffineFastState.Bounded env28442 := by
  intro p hp
  have h : env28442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28441_28442 : H12AffineEnvironment.transform 13 5513 env28441 = env28442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env28441 == env28442) = true)

theorem identity28442 : scanCanonicalize (H12AffineFastState.compose env28442 (packedSelected [6,14] rootPS)) = affineNative (2^(16+1) ^^^ 5560) := by decide +kernel

theorem selectedBound28442 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env28443 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,136,479,5560,2525,1024,137,4161,1,152,138,348,65,2216,5393,4096,2557,1364,136,256,32,5457,648]

theorem envBound28443 : H12AffineFastState.Bounded env28443 := by
  intro p hp
  have h : env28443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28442_28443 : H12AffineEnvironment.transform 16 5560 env28442 = env28443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5560 env28442 == env28443) = true)

def env28444 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138341,1024,32769,4161,180409,153,21763,8328,65,171416,5393,17800,56573,1365,144613,256,21928,46092,63068]

theorem envBound28444 : H12AffineFastState.Bounded env28444 := by
  intro p hp
  have h : env28444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28438_28444 : H12AffineEnvironment.transform 21 180409 env28438 = env28444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180409 env28438 == env28444) = true)

theorem identity28444 : scanCanonicalize (H12AffineFastState.compose env28444 (packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound28444 : packedSelected [0,1,3,9,10,11,14,17,19,22,24,26,27,28,31,32,35] rootPS < 2^1333 := by decide +kernel

def env28445 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21840,398,131072,138341,1024,21841,4161,136681,153,21763,8328,65,149704,5393,17800,2477,1365,144613,256,21928,24924,8972]

theorem envBound28445 : H12AffineFastState.Bounded env28445 := by
  intro p hp
  have h : env28445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28444_28445 : H12AffineEnvironment.transform 14 21840 env28444 = env28445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env28444 == env28445) = true)

theorem identity28445 : scanCanonicalize (H12AffineFastState.compose env28445 (packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound28445 : packedSelected [0,3,9,11,16,17,19,20,22,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env28446 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21840,398,24908,32041,1024,21841,4161,29861,153,21763,8328,65,10628,5393,17800,2477,1365,21929,256,21928,24924,8972]

theorem envBound28446 : H12AffineFastState.Bounded env28446 := by
  intro p hp
  have h : env28446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28445_28446 : H12AffineEnvironment.transform 16 24908 env28445 = env28446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env28445 == env28446) = true)

theorem identity28446 : scanCanonicalize (H12AffineFastState.compose env28446 (packedSelected [3,10,16,17,18,19,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28446 : packedSelected [3,10,16,17,18,19,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,81,398,13389,10280,1024,80,4161,8612,153,2,8328,65,10628,5393,4233,2477,1365,168,256,169,13405,8972]

theorem envBound28447 : H12AffineFastState.Bounded env28447 := by
  intro p hp
  have h : env28447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28446_28447 : H12AffineEnvironment.transform 13 5377 env28446 = env28447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28446 == env28447) = true)

theorem identity28447 : scanCanonicalize (H12AffineFastState.compose env28447 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound28447 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28448 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4249,81,398,12757,10280,408,80,4161,8612,153,2,8328,65,10628,4233,4233,2477,205,168,256,169,12741,8972]

theorem envBound28448 : H12AffineFastState.Bounded env28448 := by
  intro p hp
  have h : env28448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28447_28448 : H12AffineEnvironment.transform 9 408 env28447 = env28448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env28447 == env28448) = true)

theorem identity28448 : scanCanonicalize (H12AffineFastState.compose env28448 (packedSelected [2,4,6,9,11,12,14,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound28448 : packedSelected [2,4,6,9,11,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env28449 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,469,4249,81,398,4096,2557,408,80,4161,113,153,2,349,65,2129,4233,4233,2477,205,168,256,169,4112,729]

theorem envBound28449 : H12AffineFastState.Bounded env28449 := by
  intro p hp
  have h : env28449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28448_28449 : H12AffineEnvironment.transform 12 469 env28448 = env28449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env28448 == env28449) = true)

theorem identity28449 : scanCanonicalize (H12AffineFastState.compose env28449 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28449 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env28450 : List Nat := [2,4,8,16,32,16,128,256,512,408,2048,4096,389,4249,1,398,4096,2477,408,0,4113,33,153,2,269,17,2049,4233,4233,2477,157,168,256,169,4112,649]

theorem envBound28450 : H12AffineFastState.Bounded env28450 := by
  intro p hp
  have h : env28450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28449_28450 : H12AffineEnvironment.transform 5 16 env28449 = env28450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28449 == env28450) = true)

theorem identity28450 : scanCanonicalize (H12AffineFastState.compose env28450 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28450 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env28451 : List Nat := [2,4,8,16,32,16,128,4,512,156,2048,4096,129,4249,1,138,4096,2217,156,0,4113,33,153,2,9,17,2049,4233,4233,2217,157,168,4,169,4112,649]

theorem envBound28451 : H12AffineFastState.Bounded env28451 := by
  intro p hp
  have h : env28451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28450_28451 : H12AffineEnvironment.transform 7 4 env28450 = env28451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28450 == env28451) = true)

theorem identity28451 : scanCanonicalize (H12AffineFastState.compose env28451 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound28451 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env28452 : List Nat := [2,4,8,16,32,16,128,4,512,156,2048,2097,129,2216,1,138,2097,2217,156,0,2080,33,153,2,9,17,2049,2232,2232,2217,157,168,4,169,2081,649]

theorem envBound28452 : H12AffineFastState.Bounded env28452 := by
  intro p hp
  have h : env28452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28451_28452 : H12AffineEnvironment.transform 11 2097 env28451 = env28452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env28451 == env28452) = true)

theorem identity28452 : scanCanonicalize (H12AffineFastState.compose env28452 (packedSelected [0,1,2,3,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28452 : packedSelected [0,1,2,3,6,9] rootPS < 2^1333 := by decide +kernel

def env28453 : List Nat := [2,4,8,16,32,16,8,4,512,20,2048,2097,9,2080,1,2,2097,2081,20,0,2080,33,17,2,9,17,2049,2096,2096,2081,21,32,4,33,2081,513]

theorem envBound28453 : H12AffineFastState.Bounded env28453 := by
  intro p hp
  have h : env28453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28452_28453 : H12AffineEnvironment.transform 6 8 env28452 = env28453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28452 == env28453) = true)

theorem identity28453 : scanCanonicalize (H12AffineFastState.compose env28453 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound28453 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28454 : List Nat := [2,4,8,16,17,16,8,4,512,20,2048,2048,9,2065,1,2,2048,2064,20,0,2065,16,17,2,9,17,2049,2049,2049,2064,21,17,4,16,2064,513]

theorem envBound28454 : H12AffineFastState.Bounded env28454 := by
  intro p hp
  have h : env28454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28453_28454 : H12AffineEnvironment.transform 4 17 env28453 = env28454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env28453 == env28454) = true)

theorem identity28454 : scanCanonicalize (H12AffineFastState.compose env28454 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28454 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28455 : List Nat := [2,4,8,11,10,11,8,4,512,15,2048,2048,9,2058,1,2,2048,2059,15,0,2058,11,10,2,9,10,2049,2049,2049,2059,14,10,4,11,2059,513]

theorem envBound28455 : H12AffineFastState.Bounded env28455 := by
  intro p hp
  have h : env28455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28454_28455 : H12AffineEnvironment.transform 3 11 env28454 = env28455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28454 == env28455) = true)

theorem identity28455 : scanCanonicalize (H12AffineFastState.compose env28455 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound28455 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28456 : List Nat := [2,4,8,11,10,11,8,4,512,15,513,513,9,523,1,2,513,522,15,0,523,11,10,2,9,10,512,512,512,522,14,10,4,11,522,513]

theorem envBound28456 : H12AffineFastState.Bounded env28456 := by
  intro p hp
  have h : env28456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28455_28456 : H12AffineEnvironment.transform 10 513 env28455 = env28456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env28455 == env28456) = true)

theorem identity28456 : scanCanonicalize (H12AffineFastState.compose env28456 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound28456 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28457 : List Nat := [2,4,8,11,10,11,8,4,11,15,10,10,9,0,1,2,10,1,15,0,0,11,10,2,9,10,11,11,11,1,14,10,4,11,1,10]

theorem envBound28457 : H12AffineFastState.Bounded env28457 := by
  intro p hp
  have h : env28457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28456_28457 : H12AffineEnvironment.transform 8 11 env28456 = env28457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env28456 == env28457) = true)

theorem identity28457 : scanCanonicalize (H12AffineFastState.compose env28457 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound28457 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env28458 : List Nat := [2,4,2,1,0,1,2,4,1,5,0,0,3,0,1,2,0,1,5,0,0,1,0,2,3,0,1,1,1,1,4,0,4,1,1,0]

theorem envBound28458 : H12AffineFastState.Bounded env28458 := by
  intro p hp
  have h : env28458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28457_28458 : H12AffineEnvironment.transform 2 2 env28457 = env28458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env28457 == env28458) = true)

def env28459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374561,98781,8328,65,215367,5393,4359472,4442267,4376045,4256860,256,4363536,4355252,4448826]

theorem envBound28459 : H12AffineFastState.Bounded env28459 := by
  intro p hp
  have h : env28459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28436_28459 : H12AffineEnvironment.transform 22 4374561 env28436 = env28459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env28436 == env28459) = true)

theorem identity28459 : scanCanonicalize (H12AffineFastState.compose env28459 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound28459 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,201967,120014,98781,8328,65,215367,5393,102879,56436,119042,254131,256,98815,90203,63189]

theorem envBound28460 : H12AffineFastState.Bounded env28460 := by
  intro p hp
  have h : env28460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28459_28460 : H12AffineEnvironment.transform 21 201967 env28459 = env28460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env28459 == env28460) = true)

def env28461 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13508,130175,1024,32769,4161,73771,120014,98781,8328,65,97667,5393,102879,56436,119042,119927,256,98815,90203,63189]

theorem envBound28461 : H12AffineFastState.Bounded env28461 := by
  intro p hp
  have h : env28461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28460_28461 : H12AffineEnvironment.transform 16 13508 env28460 = env28461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13508 env28460 == env28461) = true)

theorem identity28461 : scanCanonicalize (H12AffineFastState.compose env28461 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound28461 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env28462 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29788,65536,13508,67619,1024,29789,4161,73771,73874,95617,8328,65,97667,5393,91523,10280,75102,73771,256,95651,90203,649]

theorem envBound28462 : H12AffineFastState.Bounded env28462 := by
  intro p hp
  have h : env28462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28461_28462 : H12AffineEnvironment.transform 14 29788 env28461 = env28462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env28461 == env28462) = true)

theorem identity28462 : scanCanonicalize (H12AffineFastState.compose env28462 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound28462 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env28463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21761,65536,5529,67619,1024,21760,4161,65910,65999,87260,469,65,89310,5393,83166,2421,66563,65910,256,87294,82182,649]

theorem envBound28463 : H12AffineFastState.Bounded env28463 := by
  intro p hp
  have h : env28463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28462_28463 : H12AffineEnvironment.transform 12 349 env28462 = env28463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env28462 == env28463) = true)

theorem identity28463 : scanCanonicalize (H12AffineFastState.compose env28463 (packedSelected [0,1,2,5,6,7,8,17,18,20,23,24] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound28463 : packedSelected [0,1,2,5,6,7,8,17,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env28464 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,16384,20497,65536,4233,67619,272,20496,4161,65910,65999,86476,469,65,88526,4097,82382,2421,65811,65910,256,86510,82182,649]

theorem envBound28464 : H12AffineFastState.Bounded env28464 := by
  intro p hp
  have h : env28464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28463_28464 : H12AffineEnvironment.transform 9 272 env28463 = env28464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env28463 == env28464) = true)

theorem identity28464 : scanCanonicalize (H12AffineFastState.compose env28464 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound28464 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env28465 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4113,0,65536,4233,67619,272,1,4161,65910,65999,66013,469,65,68063,4097,70111,2421,65811,65910,256,66047,69911,649]

theorem envBound28465 : H12AffineFastState.Bounded env28465 := by
  intro p hp
  have h : env28465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28464_28465 : H12AffineEnvironment.transform 13 4113 env28464 = env28465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env28464 == env28465) = true)

theorem identity28465 : scanCanonicalize (H12AffineFastState.compose env28465 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound28465 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28466 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,349,4113,0,479,4233,2556,272,1,4161,169,16,2,469,65,2048,4097,4096,2421,204,169,256,32,4296,649]

theorem envBound28466 : H12AffineFastState.Bounded env28466 := by
  intro p hp
  have h : env28466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28465_28466 : H12AffineEnvironment.transform 15 479 env28465 = env28466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env28465 == env28466) = true)

theorem identity28466 : scanCanonicalize (H12AffineFastState.compose env28466 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28466 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28467 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,349,4113,0,343,4097,2420,272,1,4161,33,16,2,349,65,2048,4097,4096,2421,68,33,256,32,4160,513]

theorem envBound28467 : H12AffineFastState.Bounded env28467 := by
  intro p hp
  have h : env28467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28466_28467 : H12AffineEnvironment.transform 6 8 env28466 = env28467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28466 == env28467) = true)

theorem identity28467 : scanCanonicalize (H12AffineFastState.compose env28467 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 340) := by decide +kernel

theorem selectedBound28467 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28468 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,340,349,325,0,343,341,2420,272,1,277,33,16,2,349,65,2048,341,340,2421,68,33,256,32,276,513]

theorem envBound28468 : H12AffineFastState.Bounded env28468 := by
  intro p hp
  have h : env28468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28467_28468 : H12AffineEnvironment.transform 11 340 env28467 = env28468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 340 env28467 == env28468) = true)

theorem identity28468 : scanCanonicalize (H12AffineFastState.compose env28468 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound28468 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28469 : List Nat := [2,4,8,16,32,64,8,256,49,272,2048,340,349,325,0,343,341,2420,272,1,277,33,16,2,349,65,2048,341,340,2421,68,33,256,32,276,48]

theorem envBound28469 : H12AffineFastState.Bounded env28469 := by
  intro p hp
  have h : env28469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28468_28469 : H12AffineEnvironment.transform 8 49 env28468 = env28469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env28468 == env28469) = true)

theorem identity28469 : scanCanonicalize (H12AffineFastState.compose env28469 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28469 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env28470 : List Nat := [2,4,8,16,32,16,8,256,49,272,2048,260,269,277,0,263,261,2340,272,1,277,33,16,2,269,17,2048,261,260,2341,20,33,256,32,276,48]

theorem envBound28470 : H12AffineFastState.Bounded env28470 := by
  intro p hp
  have h : env28470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28469_28470 : H12AffineEnvironment.transform 5 16 env28469 = env28470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28469 == env28470) = true)

theorem identity28470 : scanCanonicalize (H12AffineFastState.compose env28470 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound28470 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28471 : List Nat := [2,4,8,16,32,16,8,256,49,272,293,260,269,277,0,263,261,1,272,1,277,33,16,2,269,17,293,261,260,0,20,33,256,32,276,48]

theorem envBound28471 : H12AffineFastState.Bounded env28471 := by
  intro p hp
  have h : env28471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28470_28471 : H12AffineEnvironment.transform 10 293 env28470 = env28471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env28470 == env28471) = true)

theorem identity28471 : scanCanonicalize (H12AffineFastState.compose env28471 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28471 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env28472 : List Nat := [2,4,8,16,1,16,8,256,16,272,260,260,269,277,0,263,261,1,272,1,277,0,16,2,269,17,260,261,260,0,20,0,256,1,276,17]

theorem envBound28472 : H12AffineFastState.Bounded env28472 := by
  intro p hp
  have h : env28472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28471_28472 : H12AffineEnvironment.transform 4 1 env28471 = env28472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28471 == env28472) = true)

theorem identity28472 : scanCanonicalize (H12AffineFastState.compose env28472 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 30) := by decide +kernel

theorem selectedBound28472 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env28473 : List Nat := [2,4,8,16,1,16,8,30,16,14,26,26,19,11,0,25,27,1,14,1,11,0,16,2,19,17,26,27,26,0,20,0,30,1,10,17]

theorem envBound28473 : H12AffineFastState.Bounded env28473 := by
  intro p hp
  have h : env28473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28472_28473 : H12AffineEnvironment.transform 7 30 env28472 = env28473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 30 env28472 == env28473) = true)

theorem identity28473 : scanCanonicalize (H12AffineFastState.compose env28473 (packedSelected [0,7] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound28473 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28474 : List Nat := [2,4,8,11,1,11,8,5,11,14,1,1,8,11,0,2,0,1,14,1,11,0,11,2,8,10,1,0,1,0,15,0,5,1,10,10]

theorem envBound28474 : H12AffineFastState.Bounded env28474 := by
  intro p hp
  have h : env28474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28473_28474 : H12AffineEnvironment.transform 3 11 env28473 = env28474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env28473 == env28474) = true)

def env28475 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,13509,130174,1024,32769,4161,73770,120014,98781,8328,65,97666,5393,102879,56436,119042,119926,256,98815,90203,63189]

theorem envBound28475 : H12AffineFastState.Bounded env28475 := by
  intro p hp
  have h : env28475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28460_28475 : H12AffineEnvironment.transform 16 13509 env28460 = env28475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env28460 == env28475) = true)

theorem identity28475 : scanCanonicalize (H12AffineFastState.compose env28475 (packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound28475 : packedSelected [0,1,4,5,7,8,11,17,18,19,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env28476 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,13509,97526,1024,137,4161,73770,87110,65877,8328,65,97666,5393,69975,23804,86410,87294,256,65911,90203,30301]

theorem envBound28476 : H12AffineFastState.Bounded env28476 := by
  intro p hp
  have h : env28476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28475_28476 : H12AffineEnvironment.transform 14 136 env28475 = env28476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env28475 == env28476) = true)

theorem identity28476 : scanCanonicalize (H12AffineFastState.compose env28476 (packedSelected [3,4,5,7,8,9,14,15,17,18,19,23,26,27,28,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 5593) := by decide +kernel

theorem selectedBound28476 : packedSelected [3,4,5,7,8,9,14,15,17,18,19,23,26,27,28,35,38] rootPS < 2^1333 := by decide +kernel

def env28477 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,136,65536,13509,76079,1024,137,4161,73770,65951,65877,8328,65,75867,5393,69975,2341,66643,65831,256,65911,79234,9092]

theorem envBound28477 : H12AffineFastState.Bounded env28477 := by
  intro p hp
  have h : env28477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28476_28477 : H12AffineEnvironment.transform 13 5593 env28476 = env28477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5593 env28476 == env28477) = true)

theorem identity28477 : scanCanonicalize (H12AffineFastState.compose env28477 (packedSelected [0,9,16,20,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound28477 : packedSelected [0,9,16,20,22,27] rootPS < 2^1333 := by decide +kernel

def env28478 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5593,136,399,13509,10400,1024,137,4161,8613,16,218,8328,65,10708,5393,4312,2341,1500,168,256,248,13325,9092]

theorem envBound28478 : H12AffineFastState.Bounded env28478 := by
  intro p hp
  have h : env28478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28477_28478 : H12AffineEnvironment.transform 15 399 env28477 = env28478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env28477 == env28478) = true)

theorem identity28478 : scanCanonicalize (H12AffineFastState.compose env28478 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound28478 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env28479 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,136,399,13461,10400,1024,137,4113,8613,16,138,8328,17,10628,5393,4232,2341,1420,168,256,168,13325,9092]

theorem envBound28479 : H12AffineFastState.Bounded env28479 := by
  intro p hp
  have h : env28479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28478_28479 : H12AffineEnvironment.transform 5 16 env28478 = env28479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28478 == env28479) = true)

theorem identity28479 : scanCanonicalize (H12AffineFastState.compose env28479 (packedSelected [1,3,5,7,8,9,10,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 6925) := by decide +kernel

theorem selectedBound28479 : packedSelected [1,3,5,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env28480 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,6925,5513,136,399,3992,5037,1024,137,4113,6824,16,138,7045,17,4745,5393,4232,2341,1420,168,256,168,3840,6281]

theorem envBound28480 : H12AffineFastState.Bounded env28480 := by
  intro p hp
  have h : env28480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28479_28480 : H12AffineEnvironment.transform 12 6925 env28479 = env28480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6925 env28479 == env28480) = true)

theorem identity28480 : scanCanonicalize (H12AffineFastState.compose env28480 (packedSelected [0,1,4,8,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound28480 : packedSelected [0,1,4,8,11,12,15] rootPS < 2^1333 := by decide +kernel

def env28481 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2200,917,3345,136,399,3992,2869,1024,137,2185,560,16,138,797,17,2577,3465,2064,2341,1420,168,256,168,3840,17]

theorem envBound28481 : H12AffineFastState.Bounded env28481 := by
  intro p hp
  have h : env28481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28480_28481 : H12AffineEnvironment.transform 11 2200 env28480 = env28481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env28480 == env28481) = true)

theorem identity28481 : scanCanonicalize (H12AffineFastState.compose env28481 (packedSelected [0,4,6,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound28481 : packedSelected [0,4,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env28482 : List Nat := [2,4,8,16,32,16,128,256,512,1024,168,48,917,1465,136,399,1840,925,1024,137,33,560,16,138,797,17,697,1313,184,397,1420,168,256,168,1960,17]

theorem envBound28482 : H12AffineFastState.Bounded env28482 := by
  intro p hp
  have h : env28482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28481_28482 : H12AffineEnvironment.transform 10 168 env28481 = env28482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env28481 == env28482) = true)

theorem identity28482 : scanCanonicalize (H12AffineFastState.compose env28482 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 168) := by decide +kernel

theorem selectedBound28482 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env28483 : List Nat := [2,4,8,16,32,16,128,256,168,1024,168,48,317,1465,136,399,1432,309,1024,137,33,152,16,138,437,17,17,1313,184,397,1420,168,256,168,1280,17]

theorem envBound28483 : H12AffineFastState.Bounded env28483 := by
  intro p hp
  have h : env28483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28482_28483 : H12AffineEnvironment.transform 8 168 env28482 = env28483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 168 env28482 == env28483) = true)

theorem identity28483 : scanCanonicalize (H12AffineFastState.compose env28483 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 392) := by decide +kernel

theorem selectedBound28483 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env28484 : List Nat := [2,4,8,16,32,16,128,256,168,392,168,48,317,49,136,399,16,309,392,137,33,152,16,138,437,17,17,169,184,397,4,168,256,168,136,17]

theorem envBound28484 : H12AffineFastState.Bounded env28484 := by
  intro p hp
  have h : env28484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28483_28484 : H12AffineEnvironment.transform 9 392 env28483 = env28484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 392 env28483 == env28484) = true)

theorem identity28484 : scanCanonicalize (H12AffineFastState.compose env28484 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound28484 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env28485 : List Nat := [2,4,8,16,32,16,128,141,168,5,168,48,176,49,136,2,16,184,5,137,33,152,16,138,56,17,17,169,184,0,4,168,141,168,136,17]

theorem envBound28485 : H12AffineFastState.Bounded env28485 := by
  intro p hp
  have h : env28485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28484_28485 : H12AffineEnvironment.transform 7 141 env28484 = env28485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env28484 == env28485) = true)

theorem identity28485 : scanCanonicalize (H12AffineFastState.compose env28485 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound28485 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28486 : List Nat := [2,4,8,16,32,16,57,52,17,5,17,48,9,49,49,2,16,1,5,48,33,33,16,51,56,17,17,16,1,0,4,17,52,17,49,17]

theorem envBound28486 : H12AffineFastState.Bounded env28486 := by
  intro p hp
  have h : env28486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28485_28486 : H12AffineEnvironment.transform 6 57 env28485 = env28486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env28485 == env28486) = true)

theorem identity28486 : scanCanonicalize (H12AffineFastState.compose env28486 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28486 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env28487 : List Nat := [2,4,8,16,0,16,25,20,17,5,17,16,9,17,17,2,16,1,5,16,1,1,16,19,24,17,17,16,1,0,4,17,20,17,17,17]

theorem envBound28487 : H12AffineFastState.Bounded env28487 := by
  intro p hp
  have h : env28487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28486_28487 : H12AffineEnvironment.transform 4 0 env28486 = env28487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28486 == env28487) = true)

theorem identity28487 : scanCanonicalize (H12AffineFastState.compose env28487 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28487 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28488 : List Nat := [2,4,8,0,0,0,9,4,1,5,1,0,9,1,1,2,0,1,5,0,1,1,0,3,8,1,1,0,1,0,4,1,4,1,1,1]

theorem envBound28488 : H12AffineFastState.Bounded env28488 := by
  intro p hp
  have h : env28488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28487_28488 : H12AffineEnvironment.transform 3 0 env28487 = env28488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28487 == env28488) = true)

theorem identity28488 : scanCanonicalize (H12AffineFastState.compose env28488 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound28488 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28489 : List Nat := [2,0,8,0,0,0,9,0,1,1,1,0,9,1,1,2,0,1,1,0,1,1,0,3,8,1,1,0,1,0,0,1,0,1,1,1]

theorem envBound28489 : H12AffineFastState.Bounded env28489 := by
  intro p hp
  have h : env28489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28488_28489 : H12AffineEnvironment.transform 1 0 env28488 = env28489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env28488 == env28489) = true)

theorem identity28489 : scanCanonicalize (H12AffineFastState.compose env28489 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound28489 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28490 : List Nat := [2,0,0,0,0,0,1,0,1,1,1,0,1,1,1,2,0,1,1,0,1,1,0,3,0,1,1,0,1,0,0,1,0,1,1,1]

theorem envBound28490 : H12AffineFastState.Bounded env28490 := by
  intro p hp
  have h : env28490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28489_28490 : H12AffineEnvironment.transform 2 0 env28489 = env28490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env28489 == env28490) = true)

theorem identity28490 : scanCanonicalize (H12AffineFastState.compose env28490 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28490 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28491 : List Nat := [0,0,0,0,0,0,1,0,1,1,1,0,1,1,1,0,0,1,1,0,1,1,0,1,0,1,1,0,1,0,0,1,0,1,1,1]

theorem envBound28491 : H12AffineFastState.Bounded env28491 := by
  intro p hp
  have h : env28491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28490_28491 : H12AffineEnvironment.transform 0 0 env28490 = env28491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28490 == env28491) = true)

def env28492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784806,5392,10507600,8456378,10491276,4256861,256,8410416,8434836,10564187]

theorem envBound28492 : H12AffineFastState.Bounded env28492 := by
  intro p hp
  have h : env28492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28394_28492 : H12AffineEnvironment.transform 23 2199965 env28394 = env28492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env28394 == env28492) = true)

def env28493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,8388608,98781,8328,65,12683622,5392,8406288,8456378,8390092,4256861,256,8410416,8434836,8462875]

theorem envBound28493 : H12AffineFastState.Bounded env28493 := by
  intro p hp
  have h : env28493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28492_28493 : H12AffineEnvironment.transform 20 4160 env28492 = env28493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env28492 == env28493) = true)

def env28494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374560,98781,8328,65,215366,5392,4359472,4442266,4376044,4256861,256,4363536,4355252,4448827]

theorem envBound28494 : H12AffineFastState.Bounded env28494 := by
  intro p hp
  have h : env28494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28493_28494 : H12AffineEnvironment.transform 22 4374560 env28493 = env28494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env28493 == env28494) = true)

theorem identity28494 : scanCanonicalize (H12AffineFastState.compose env28494 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound28494 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,144613,62661,98781,8328,65,215366,5392,45525,130175,61705,180408,256,41461,16465,120542]

theorem envBound28495 : H12AffineFastState.Bounded env28495 := by
  intro p hp
  have h : env28495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28494_28495 : H12AffineEnvironment.transform 21 144613 env28494 = env28495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env28494 == env28495) = true)

def env28496 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4112,144565,62613,98701,8328,17,215318,5392,45445,130095,61705,180408,256,41381,16385,120462]

theorem envBound28496 : H12AffineFastState.Bounded env28496 := by
  intro p hp
  have h : env28496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28495_28496 : H12AffineEnvironment.transform 5 16 env28495 = env28496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env28495 == env28496) = true)

theorem identity28496 : scanCanonicalize (H12AffineFastState.compose env28496 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28496 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env28497 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,90138,43169,1024,32769,4112,87215,62613,98701,8328,17,10508,5392,45445,130095,61705,106658,256,41381,16385,120462]

theorem envBound28497 : H12AffineFastState.Bounded env28497 := by
  intro p hp
  have h : env28497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28496_28497 : H12AffineEnvironment.transform 16 90138 env28496 = env28497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28496 == env28497) = true)

theorem identity28497 : scanCanonicalize (H12AffineFastState.compose env28497 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 54415) := by decide +kernel

theorem selectedBound28497 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env28498 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,46229,43169,1024,32769,4112,32800,62613,21762,8328,17,10508,5392,45445,10400,61705,29741,256,41381,16385,513]

theorem envBound28498 : H12AffineFastState.Bounded env28498 := by
  intro p hp
  have h : env28498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28497_28498 : H12AffineEnvironment.transform 15 54415 env28497 = env28498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54415 env28497 == env28498) = true)

theorem identity28498 : scanCanonicalize (H12AffineFastState.compose env28498 (packedSelected [1,2,4,5,6,7,8,9,24,27] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound28498 : packedSelected [1,2,4,5,6,7,8,9,24,27] rootPS < 2^1333 := by decide +kernel

def env28499 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,32768,33167,46229,43169,1024,32769,4112,32800,41365,2,8328,17,10508,5392,45445,10400,41993,8493,256,41381,5377,513]

theorem envBound28499 : H12AffineFastState.Bounded env28499 := by
  intro p hp
  have h : env28499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28498_28499 : H12AffineEnvironment.transform 13 5376 env28498 = env28499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28498 == env28499) = true)

theorem identity28499 : scanCanonicalize (H12AffineFastState.compose env28499 (packedSelected [17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound28499 : packedSelected [17,18,23] rootPS < 2^1333 := by decide +kernel

def env28500 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8460,8323,5529,2477,1024,8461,4112,8492,153,2,8328,17,10508,5392,4233,10400,1285,8493,256,169,5377,513]

theorem envBound28500 : H12AffineFastState.Bounded env28500 := by
  intro p hp
  have h : env28500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28499_28500 : H12AffineEnvironment.transform 14 8460 env28499 = env28500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env28499 == env28500) = true)

theorem identity28500 : scanCanonicalize (H12AffineFastState.compose env28500 (packedSelected [0,1,2,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(11+1) ^^^ 956) := by decide +kernel

theorem selectedBound28500 : packedSelected [0,1,2,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env28501 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,956,8192,1724,8460,8323,1573,2477,1024,8461,940,8492,153,2,8328,17,10508,1708,821,10400,1285,8493,256,169,1725,513]

theorem envBound28501 : H12AffineFastState.Bounded env28501 := by
  intro p hp
  have h : env28501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28500_28501 : H12AffineEnvironment.transform 11 956 env28500 = env28501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 956 env28500 == env28501) = true)

theorem identity28501 : scanCanonicalize (H12AffineFastState.compose env28501 (packedSelected [5,7,8,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 2965) := by decide +kernel

theorem selectedBound28501 : packedSelected [5,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env28502 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,956,2965,1724,2713,2838,1573,2477,1024,2712,940,2745,153,2,2845,17,665,1708,821,821,1285,2744,256,169,1725,513]

theorem envBound28502 : H12AffineFastState.Bounded env28502 := by
  intro p hp
  have h : env28502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28501_28502 : H12AffineEnvironment.transform 12 2965 env28501 = env28502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2965 env28501 == env28502) = true)

theorem identity28502 : scanCanonicalize (H12AffineFastState.compose env28502 (packedSelected [2,6,17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28502 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env28503 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,820,2845,1588,2577,2838,1573,2341,1024,2576,804,2609,17,2,2845,17,529,1572,821,821,1285,2608,256,33,1589,513]

theorem envBound28503 : H12AffineFastState.Bounded env28503 := by
  intro p hp
  have h : env28503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28502_28503 : H12AffineEnvironment.transform 6 8 env28502 = env28503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28502 == env28503) = true)

theorem identity28503 : scanCanonicalize (H12AffineFastState.compose env28503 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1840) := by decide +kernel

theorem selectedBound28503 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28504 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1840,820,1069,1588,1313,1062,1573,1557,1024,1312,804,1281,17,2,1069,17,529,1572,821,821,1285,1280,256,33,1589,513]

theorem envBound28504 : H12AffineFastState.Bounded env28504 := by
  intro p hp
  have h : env28504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28503_28504 : H12AffineEnvironment.transform 10 1840 env28503 = env28504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1840 env28503 == env28504) = true)

theorem identity28504 : scanCanonicalize (H12AffineFastState.compose env28504 (packedSelected [5,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28504 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env28505 : List Nat := [2,4,8,0,32,0,8,256,512,1024,1824,804,1069,1572,1313,1062,1573,1541,1024,1312,804,1281,1,2,1069,1,513,1572,805,805,1285,1280,256,33,1573,513]

theorem envBound28505 : H12AffineFastState.Bounded env28505 := by
  intro p hp
  have h : env28505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28504_28505 : H12AffineEnvironment.transform 3 0 env28504 = env28505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28504 == env28505) = true)

theorem identity28505 : scanCanonicalize (H12AffineFastState.compose env28505 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound28505 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28506 : List Nat := [2,4,8,0,32,0,8,256,512,36,772,804,9,512,261,2,513,545,36,260,804,293,1,2,9,1,513,512,805,805,289,292,256,33,513,513]

theorem envBound28506 : H12AffineFastState.Bounded env28506 := by
  intro p hp
  have h : env28506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28505_28506 : H12AffineEnvironment.transform 9 36 env28505 = env28506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env28505 == env28506) = true)

theorem identity28506 : scanCanonicalize (H12AffineFastState.compose env28506 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28506 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env28507 : List Nat := [2,4,8,0,32,0,8,4,512,36,512,544,9,512,1,2,513,545,36,0,544,33,1,2,9,1,513,512,545,545,37,32,4,33,513,513]

theorem envBound28507 : H12AffineFastState.Bounded env28507 := by
  intro p hp
  have h : env28507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28506_28507 : H12AffineEnvironment.transform 7 4 env28506 = env28507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28506 == env28507) = true)

theorem identity28507 : scanCanonicalize (H12AffineFastState.compose env28507 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound28507 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env28508 : List Nat := [2,4,8,0,1,0,8,4,512,5,512,513,9,512,1,2,513,512,5,0,513,0,1,2,9,1,513,512,512,512,4,1,4,0,513,513]

theorem envBound28508 : H12AffineFastState.Bounded env28508 := by
  intro p hp
  have h : env28508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28507_28508 : H12AffineEnvironment.transform 4 1 env28507 = env28508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env28507 == env28508) = true)

theorem identity28508 : scanCanonicalize (H12AffineFastState.compose env28508 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28508 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28509 : List Nat := [2,4,8,0,1,0,8,4,0,5,0,1,9,0,1,2,1,0,5,0,1,0,1,2,9,1,1,0,0,0,4,1,4,0,1,1]

theorem envBound28509 : H12AffineFastState.Bounded env28509 := by
  intro p hp
  have h : env28509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28508_28509 : H12AffineEnvironment.transform 8 0 env28508 = env28509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28508 == env28509) = true)

theorem identity28509 : scanCanonicalize (H12AffineFastState.compose env28509 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound28509 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28510 : List Nat := [2,4,3,0,1,0,3,4,0,5,0,1,2,0,1,2,1,0,5,0,1,0,1,2,2,1,1,0,0,0,4,1,4,0,1,1]

theorem envBound28510 : H12AffineFastState.Bounded env28510 := by
  intro p hp
  have h : env28510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28509_28510 : H12AffineEnvironment.transform 2 3 env28509 = env28510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env28509 == env28510) = true)

def env28511 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4113,144564,62612,98700,8328,16,215319,5392,45444,130094,61705,180408,256,41380,16384,120463]

theorem envBound28511 : H12AffineFastState.Bounded env28511 := by
  intro p hp
  have h : env28511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28495_28511 : H12AffineEnvironment.transform 5 17 env28495 = env28511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28495 == env28511) = true)

theorem identity28511 : scanCanonicalize (H12AffineFastState.compose env28511 (packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound28511 : packedSelected [4,7,9,10,11,12,16,17,19,20,26,27,31,32,41] rootPS < 2^1333 := by decide +kernel

def env28512 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,21647,131072,171060,1024,32769,4113,144564,62612,54531,8328,16,138648,5392,45444,43169,61705,180408,256,41380,16384,33280]

theorem envBound28512 : H12AffineFastState.Bounded env28512 := by
  intro p hp
  have h : env28512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28511_28512 : H12AffineEnvironment.transform 15 21647 env28511 = env28512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env28511 == env28512) = true)

theorem identity28512 : scanCanonicalize (H12AffineFastState.compose env28512 (packedSelected [0,1,4,7,18,19,22,23,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound28512 : packedSelected [0,1,4,7,18,19,22,23,28,31] rootPS < 2^1333 := by decide +kernel

def env28513 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,32768,398,131072,171060,1024,32769,4113,144564,41365,32770,8328,16,138648,5392,45444,43169,41992,169401,256,41380,5377,33280]

theorem envBound28513 : H12AffineFastState.Bounded env28513 := by
  intro p hp
  have h : env28513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28512_28513 : H12AffineEnvironment.transform 13 5377 env28512 = env28513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28512 == env28513) = true)

theorem identity28513 : scanCanonicalize (H12AffineFastState.compose env28513 (packedSelected [3,10,17,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound28513 : packedSelected [3,10,17,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env28514 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,136,398,131072,138428,1024,137,4113,144564,8477,138,8328,16,138648,5392,12556,10281,9344,136497,256,8492,5377,648]

theorem envBound28514 : H12AffineFastState.Bounded env28514 := by
  intro p hp
  have h : env28514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28513_28514 : H12AffineEnvironment.transform 14 136 env28513 = env28514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env28513 == env28514) = true)

theorem identity28514 : scanCanonicalize (H12AffineFastState.compose env28514 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28514 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env28515 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,1,263,131072,138293,1024,0,4113,144445,8477,3,8193,16,138513,5392,12556,10281,9225,136497,256,8492,5377,513]

theorem envBound28515 : H12AffineFastState.Bounded env28515 := by
  intro p hp
  have h : env28515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28514_28515 : H12AffineEnvironment.transform 6 9 env28514 = env28515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28514 == env28515) = true)

theorem identity28515 : scanCanonicalize (H12AffineFastState.compose env28515 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound28515 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28516 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,1,263,13340,10281,1024,0,4113,33,8477,3,8193,16,10509,5392,12556,10281,9225,8493,256,8492,5377,513]

theorem envBound28516 : H12AffineFastState.Bounded env28516 := by
  intro p hp
  have h : env28516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28515_28516 : H12AffineEnvironment.transform 16 13340 env28515 = env28516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env28515 == env28516) = true)

theorem identity28516 : scanCanonicalize (H12AffineFastState.compose env28516 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound28516 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28517 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2340,1024,0,4113,33,16,3,268,16,2048,5392,4097,2340,1284,32,256,33,5377,513]

theorem envBound28517 : H12AffineFastState.Bounded env28517 := by
  intro p hp
  have h : env28517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28516_28517 : H12AffineEnvironment.transform 12 269 env28516 = env28517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env28516 == env28517) = true)

theorem identity28517 : scanCanonicalize (H12AffineFastState.compose env28517 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound28517 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28518 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,293,269,1060,1,263,1076,2340,1024,0,308,33,16,3,268,16,2048,1077,292,2340,1284,32,256,33,1060,513]

theorem envBound28518 : H12AffineFastState.Bounded env28518 := by
  intro p hp
  have h : env28518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28517_28518 : H12AffineEnvironment.transform 11 293 env28517 = env28518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env28517 == env28518) = true)

theorem identity28518 : scanCanonicalize (H12AffineFastState.compose env28518 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound28518 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28519 : List Nat := [2,4,8,16,32,17,9,256,0,1024,2048,293,269,1060,1,263,1076,2340,1024,0,308,33,16,3,268,16,2048,1077,292,2340,1284,32,256,33,1060,1]

theorem envBound28519 : H12AffineFastState.Bounded env28519 := by
  intro p hp
  have h : env28519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28518_28519 : H12AffineEnvironment.transform 8 0 env28518 = env28519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env28518 == env28519) = true)

theorem identity28519 : scanCanonicalize (H12AffineFastState.compose env28519 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28519 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28520 : List Nat := [2,4,8,16,32,17,9,256,0,52,2048,293,269,16,1,263,0,2340,52,0,308,33,16,3,268,16,2048,1,292,2340,304,32,256,33,16,1]

theorem envBound28520 : H12AffineFastState.Bounded env28520 := by
  intro p hp
  have h : env28520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28519_28520 : H12AffineEnvironment.transform 9 52 env28519 = env28520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28519 == env28520) = true)

def env28521 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,4194304,4374561,98781,8328,65,215367,5392,4359473,4442267,4376045,4256861,256,4363537,4355253,4448826]

theorem envBound28521 : H12AffineFastState.Bounded env28521 := by
  intro p hp
  have h : env28521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28493_28521 : H12AffineEnvironment.transform 22 4374561 env28493 = env28521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env28493 == env28521) = true)

theorem identity28521 : scanCanonicalize (H12AffineFastState.compose env28521 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound28521 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28522 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212078,1024,29908,4160,4194304,4338932,95496,8328,65,215367,5392,4354532,4406350,4337976,4194440,256,4350404,4355253,4396783]

theorem envBound28522 : H12AffineFastState.Bounded env28522 := by
  intro p hp
  have h : env28522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28521_28522 : H12AffineEnvironment.transform 14 29909 env28521 = env28522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env28521 == env28522) = true)

def env28523 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212078,1024,29908,4160,144612,16,95496,8328,65,215367,5392,17664,67754,1500,144492,256,21792,16465,74251]

theorem envBound28523 : H12AffineFastState.Bounded env28523 := by
  intro p hp
  have h : env28523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28522_28523 : H12AffineEnvironment.transform 21 144612 env28522 = env28523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144612 env28522 == env28523) = true)

theorem identity28523 : scanCanonicalize (H12AffineFastState.compose env28523 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28523 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env28524 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,131072,138340,1024,29908,4160,144612,16,21762,8328,65,158029,5392,17664,10400,1500,144492,256,21792,16465,513]

theorem envBound28524 : H12AffineFastState.Bounded env28524 := by
  intro p hp
  have h : env28524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28523_28524 : H12AffineEnvironment.transform 15 8202 env28523 = env28524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28523 == env28524) = true)

theorem identity28524 : scanCanonicalize (H12AffineFastState.compose env28524 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound28524 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env28525 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8580,8202,131072,138340,1024,8581,4160,144612,16,83,8328,65,146460,5392,4177,10400,1500,144492,256,113,5376,513]

theorem envBound28525 : H12AffineFastState.Bounded env28525 := by
  intro p hp
  have h : env28525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28524_28525 : H12AffineEnvironment.transform 13 5457 env28524 = env28525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env28524 == env28525) = true)

theorem identity28525 : scanCanonicalize (H12AffineFastState.compose env28525 (packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28525 : packedSelected [0,2,3,4,6,7,10,17,18,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env28526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5457,216,342,131072,138340,1024,217,4160,136632,16,83,468,65,138560,5392,4177,2556,1500,136496,256,113,5376,513]

theorem envBound28526 : H12AffineFastState.Bounded env28526 := by
  intro p hp
  have h : env28526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28525_28526 : H12AffineEnvironment.transform 12 348 env28525 = env28526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28525 == env28526) = true)

theorem identity28526 : scanCanonicalize (H12AffineFastState.compose env28526 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound28526 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5457,216,342,5392,2420,1024,217,4160,168,16,83,468,65,2128,5392,4177,2556,1500,32,256,113,5376,513]

theorem envBound28527 : H12AffineFastState.Bounded env28527 := by
  intro p hp
  have h : env28527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28526_28527 : H12AffineEnvironment.transform 16 5392 env28526 = env28527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env28526 == env28527) = true)

theorem identity28527 : scanCanonicalize (H12AffineFastState.compose env28527 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound28527 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env28528 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,4096,348,4160,216,342,4097,2420,273,217,4160,168,16,83,468,65,2128,4097,4177,2556,205,32,256,113,4113,513]

theorem envBound28528 : H12AffineFastState.Bounded env28528 := by
  intro p hp
  have h : env28528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28527_28528 : H12AffineEnvironment.transform 9 273 env28527 = env28528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env28527 == env28528) = true)

theorem identity28528 : scanCanonicalize (H12AffineFastState.compose env28528 (packedSelected [2,3,4,5,7,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 853) := by decide +kernel

theorem selectedBound28528 : packedSelected [2,3,4,5,7,11,15] rootPS < 2^1333 := by decide +kernel

def env28529 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,853,348,789,216,342,852,2420,273,217,789,168,16,83,468,65,2128,852,772,2556,205,32,256,113,836,513]

theorem envBound28529 : H12AffineFastState.Bounded env28529 := by
  intro p hp
  have h : env28529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28528_28529 : H12AffineEnvironment.transform 11 853 env28528 = env28529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 853 env28528 == env28529) = true)

theorem identity28529 : scanCanonicalize (H12AffineFastState.compose env28529 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound28529 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env28530 : List Nat := [2,4,8,16,32,64,128,37,512,52,2048,624,121,560,216,115,625,2129,52,217,560,168,16,83,241,65,2128,625,545,2265,205,32,37,113,609,513]

theorem envBound28530 : H12AffineFastState.Bounded env28530 := by
  intro p hp
  have h : env28530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28529_28530 : H12AffineEnvironment.transform 7 37 env28529 = env28530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env28529 == env28530) = true)

theorem identity28530 : scanCanonicalize (H12AffineFastState.compose env28530 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound28530 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28531 : List Nat := [2,4,8,16,32,64,40,37,512,52,2048,624,121,560,112,115,625,2129,52,113,560,0,16,83,89,65,2128,625,545,2161,101,32,37,113,609,513]

theorem envBound28531 : H12AffineFastState.Bounded env28531 := by
  intro p hp
  have h : env28531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28530_28531 : H12AffineEnvironment.transform 6 40 env28530 = env28531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env28530 == env28531) = true)

theorem identity28531 : scanCanonicalize (H12AffineFastState.compose env28531 (packedSelected [0,1,2,7,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound28531 : packedSelected [0,1,2,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28532 : List Nat := [2,4,8,16,32,64,40,37,512,52,64,624,121,560,112,115,625,17,52,113,560,0,16,83,89,65,16,625,545,49,101,32,37,113,609,513]

theorem envBound28532 : H12AffineFastState.Bounded env28532 := by
  intro p hp
  have h : env28532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28531_28532 : H12AffineEnvironment.transform 10 64 env28531 = env28532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env28531 == env28532) = true)

theorem identity28532 : scanCanonicalize (H12AffineFastState.compose env28532 (packedSelected [4,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound28532 : packedSelected [4,7,10] rootPS < 2^1333 := by decide +kernel

def env28533 : List Nat := [2,4,8,16,32,48,40,37,512,52,48,512,9,560,0,3,513,17,52,1,560,0,16,35,41,49,16,513,545,49,21,32,37,1,529,513]

theorem envBound28533 : H12AffineFastState.Bounded env28533 := by
  intro p hp
  have h : env28533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28532_28533 : H12AffineEnvironment.transform 5 48 env28532 = env28533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env28532 == env28533) = true)

theorem identity28533 : scanCanonicalize (H12AffineFastState.compose env28533 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28533 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env28534 : List Nat := [2,4,8,16,0,16,8,5,512,20,16,512,9,528,0,3,513,17,20,1,528,0,16,3,9,17,16,513,513,17,21,0,5,1,529,513]

theorem envBound28534 : H12AffineFastState.Bounded env28534 := by
  intro p hp
  have h : env28534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28533_28534 : H12AffineEnvironment.transform 4 0 env28533 = env28534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28533 == env28534) = true)

theorem identity28534 : scanCanonicalize (H12AffineFastState.compose env28534 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound28534 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28535 : List Nat := [2,1,8,16,0,16,8,0,512,17,16,512,9,528,0,3,513,17,17,1,528,0,16,3,9,17,16,513,513,17,16,0,0,1,529,513]

theorem envBound28535 : H12AffineFastState.Bounded env28535 := by
  intro p hp
  have h : env28535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28534_28535 : H12AffineEnvironment.transform 1 1 env28534 = env28535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env28534 == env28535) = true)

theorem identity28535 : scanCanonicalize (H12AffineFastState.compose env28535 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound28535 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28536 : List Nat := [0,1,8,16,0,16,8,0,512,17,16,512,9,528,0,1,513,17,17,1,528,0,16,1,9,17,16,513,513,17,16,0,0,1,529,513]

theorem envBound28536 : H12AffineFastState.Bounded env28536 := by
  intro p hp
  have h : env28536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28535_28536 : H12AffineEnvironment.transform 0 0 env28535 = env28536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env28535 == env28536) = true)

theorem identity28536 : scanCanonicalize (H12AffineFastState.compose env28536 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound28536 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env28537 : List Nat := [0,1,8,16,0,16,8,0,24,17,16,24,9,8,0,1,25,17,17,1,8,0,16,1,9,17,16,25,25,17,16,0,0,1,9,25]

theorem envBound28537 : H12AffineFastState.Bounded env28537 := by
  intro p hp
  have h : env28537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28536_28537 : H12AffineEnvironment.transform 8 24 env28536 = env28537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env28536 == env28537) = true)

theorem identity28537 : scanCanonicalize (H12AffineFastState.compose env28537 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound28537 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env28538 : List Nat := [0,1,8,8,0,8,8,0,0,9,8,0,9,8,0,1,1,9,9,1,8,0,8,1,9,9,8,1,1,9,8,0,0,1,9,1]

theorem envBound28538 : H12AffineFastState.Bounded env28538 := by
  intro p hp
  have h : env28538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28537_28538 : H12AffineEnvironment.transform 3 8 env28537 = env28538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env28537 == env28538) = true)

def env28539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,212078,1024,29908,4160,144613,17,95496,8328,65,215367,5392,17665,67755,1501,144493,256,21793,16464,74250]

theorem envBound28539 : H12AffineFastState.Bounded env28539 := by
  intro p hp
  have h : env28539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28522_28539 : H12AffineEnvironment.transform 21 144613 env28522 = env28539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env28522 == env28539) = true)

def env28540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,212078,1024,8660,4160,144613,17,73736,8328,65,203847,5392,4097,67755,1501,144493,256,33,5456,74250]

theorem envBound28540 : H12AffineFastState.Bounded env28540 := by
  intro p hp
  have h : env28540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28539_28540 : H12AffineEnvironment.transform 13 5376 env28539 = env28540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env28539 == env28540) = true)

theorem identity28540 : scanCanonicalize (H12AffineFastState.compose env28540 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound28540 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8322,131072,138476,1024,8660,4160,144613,17,138,8328,65,146629,5392,4097,10281,1501,144493,256,33,5456,648]

theorem envBound28541 : H12AffineFastState.Bounded env28541 := by
  intro p hp
  have h : env28541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28540_28541 : H12AffineEnvironment.transform 15 8322 env28540 = env28541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env28540 == env28541) = true)

theorem identity28541 : scanCanonicalize (H12AffineFastState.compose env28541 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound28541 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env28542 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,5292,8313,8322,131072,138476,1024,8312,4160,144613,17,138,8328,65,146629,5308,4097,10281,1137,144493,172,33,5372,648]

theorem envBound28542 : H12AffineFastState.Bounded env28542 := by
  intro p hp
  have h : env28542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28541_28542 : H12AffineEnvironment.transform 7 172 env28541 = env28542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env28541 == env28542) = true)

theorem identity28542 : scanCanonicalize (H12AffineFastState.compose env28542 (packedSelected [3,5,10,11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound28542 : packedSelected [3,5,10,11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env28543 : List Nat := [2,4,8,16,32,64,128,172,512,1024,2048,4096,8192,5292,8313,8322,13461,10361,1024,8312,4160,112,17,138,8328,65,2128,5308,4097,10281,1137,248,172,33,5372,648]

theorem envBound28543 : H12AffineFastState.Bounded env28543 := by
  intro p hp
  have h : env28543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28542_28543 : H12AffineEnvironment.transform 16 13461 env28542 = env28543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env28542 == env28543) = true)

theorem identity28543 : scanCanonicalize (H12AffineFastState.compose env28543 (packedSelected [0,4,6,7,9,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound28543 : packedSelected [0,4,6,7,9,16,20] rootPS < 2^1333 := by decide +kernel

def env28544 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,8192,5236,8313,8282,13389,10361,1024,8312,4160,112,17,82,8272,65,2128,5220,4097,10281,1137,32,116,33,5156,592]

theorem envBound28544 : H12AffineFastState.Bounded env28544 := by
  intro p hp
  have h : env28544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28543_28544 : H12AffineEnvironment.transform 6 88 env28543 = env28544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env28543 == env28544) = true)

theorem identity28544 : scanCanonicalize (H12AffineFastState.compose env28544 (packedSelected [0,1,2,3,5,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound28544 : packedSelected [0,1,2,3,5,7,8,11] rootPS < 2^1333 := by decide +kernel

def env28545 : List Nat := [2,4,8,16,32,64,88,116,512,1024,2048,4096,1053,5236,1124,1095,4176,3172,1024,1125,4160,112,17,82,1101,65,2128,5220,4097,3124,1137,32,116,33,5156,592]

theorem envBound28545 : H12AffineFastState.Bounded env28545 := by
  intro p hp
  have h : env28545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28544_28545 : H12AffineEnvironment.transform 12 1053 env28544 = env28545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env28544 == env28545) = true)

theorem identity28545 : scanCanonicalize (H12AffineFastState.compose env28545 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound28545 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28546 : List Nat := [2,4,8,16,32,64,88,116,512,52,2048,4096,41,4160,80,115,4176,2128,52,81,4160,112,17,82,121,65,2128,4176,4097,2048,69,32,116,33,4112,592]

theorem envBound28546 : H12AffineFastState.Bounded env28546 := by
  intro p hp
  have h : env28546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28545_28546 : H12AffineEnvironment.transform 9 52 env28545 = env28546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env28545 == env28546) = true)

theorem identity28546 : scanCanonicalize (H12AffineFastState.compose env28546 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2096) := by decide +kernel

theorem selectedBound28546 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env28547 : List Nat := [2,4,8,16,32,64,88,116,512,52,2048,2096,41,2160,80,115,2144,2128,52,81,2160,112,17,82,121,65,2128,2144,2097,2048,69,32,116,33,2080,592]

theorem envBound28547 : H12AffineFastState.Bounded env28547 := by
  intro p hp
  have h : env28547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28546_28547 : H12AffineEnvironment.transform 11 2096 env28546 = env28547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2096 env28546 == env28547) = true)

theorem identity28547 : scanCanonicalize (H12AffineFastState.compose env28547 (packedSelected [1,2,3,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 79) := by decide +kernel

theorem selectedBound28547 : packedSelected [1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env28548 : List Nat := [2,4,8,16,32,64,88,116,512,52,79,127,41,63,80,115,47,31,52,81,63,112,17,82,121,65,31,47,126,79,69,32,116,33,111,592]

theorem envBound28548 : H12AffineFastState.Bounded env28548 := by
  intro p hp
  have h : env28548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28547_28548 : H12AffineEnvironment.transform 10 79 env28547 = env28548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 79 env28547 == env28548) = true)

theorem identity28548 : scanCanonicalize (H12AffineFastState.compose env28548 (packedSelected [3,4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound28548 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env28549 : List Nat := [2,4,8,16,8,64,88,92,512,28,79,87,1,23,80,91,7,31,28,81,23,88,17,82,81,65,31,7,86,79,69,8,92,9,71,592]

theorem envBound28549 : H12AffineFastState.Bounded env28549 := by
  intro p hp
  have h : env28549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28548_28549 : H12AffineEnvironment.transform 4 8 env28548 = env28549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env28548 == env28549) = true)

def env28550 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,212078,1024,8661,4160,144613,17,73737,8328,65,203846,5392,4096,67755,1501,144493,256,32,5457,74250]

theorem envBound28550 : H12AffineFastState.Bounded env28550 := by
  intro p hp
  have h : env28550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28539_28550 : H12AffineEnvironment.transform 13 5377 env28539 = env28550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env28539 == env28550) = true)

theorem identity28550 : scanCanonicalize (H12AffineFastState.compose env28550 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound28550 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28551 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,131072,138341,1024,8661,4160,144613,17,2,8328,65,146509,5392,4096,10400,1501,144493,256,32,5457,513]

theorem envBound28551 : H12AffineFastState.Bounded env28551 := by
  intro p hp
  have h : env28551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28550_28551 : H12AffineEnvironment.transform 15 8203 env28550 = env28551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env28550 == env28551) = true)

theorem identity28551 : scanCanonicalize (H12AffineFastState.compose env28551 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound28551 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8203,13461,10480,1024,8661,4160,112,17,2,8328,65,2264,5392,4096,10400,1501,248,256,32,5457,513]

theorem envBound28552 : H12AffineFastState.Bounded env28552 := by
  intro p hp
  have h : env28552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28551_28552 : H12AffineEnvironment.transform 16 13461 env28551 = env28552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env28551 == env28552) = true)

theorem identity28552 : scanCanonicalize (H12AffineFastState.compose env28552 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound28552 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,5377,81,398,5392,2421,1024,80,4160,112,17,2,269,65,2264,5392,4096,2341,1501,248,256,32,5457,513]

theorem envBound28553 : H12AffineFastState.Bounded env28553 := by
  intro p hp
  have h : env28553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28552_28553 : H12AffineEnvironment.transform 12 389 env28552 = env28553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env28552 == env28553) = true)

theorem identity28553 : scanCanonicalize (H12AffineFastState.compose env28553 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound28553 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env28554 : List Nat := [2,4,8,16,32,64,128,256,512,116,2048,4096,389,4469,81,398,4452,2421,116,80,4160,112,17,2,269,65,2264,4452,4096,2341,425,248,256,32,4389,513]

theorem envBound28554 : H12AffineFastState.Bounded env28554 := by
  intro p hp
  have h : env28554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28553_28554 : H12AffineEnvironment.transform 9 116 env28553 = env28554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env28553 == env28554) = true)

theorem identity28554 : scanCanonicalize (H12AffineFastState.compose env28554 (packedSelected [0,3,7,8,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 664) := by decide +kernel

theorem selectedBound28554 : packedSelected [0,3,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env28555 : List Nat := [2,4,8,16,32,64,128,256,512,116,664,4096,389,4469,81,398,4452,1005,116,80,4160,112,17,2,269,65,576,4452,4096,957,425,248,256,32,4389,513]

theorem envBound28555 : H12AffineFastState.Bounded env28555 := by
  intro p hp
  have h : env28555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28554_28555 : H12AffineEnvironment.transform 10 664 env28554 = env28555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 664 env28554 == env28555) = true)

theorem identity28555 : scanCanonicalize (H12AffineFastState.compose env28555 (packedSelected [1,2,3,4,7,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28555 : packedSelected [1,2,3,4,7,11,15] rootPS < 2^1333 := by decide +kernel

def env28556 : List Nat := [2,4,8,16,32,64,128,116,512,116,664,4096,241,4097,81,250,4112,665,116,80,4160,112,17,2,121,65,576,4112,4096,713,221,248,116,32,4177,513]

theorem envBound28556 : H12AffineFastState.Bounded env28556 := by
  intro p hp
  have h : env28556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28555_28556 : H12AffineEnvironment.transform 7 116 env28555 = env28556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28555 == env28556) = true)

theorem identity28556 : scanCanonicalize (H12AffineFastState.compose env28556 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound28556 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28557 : List Nat := [2,4,8,16,32,64,24,116,512,116,512,4096,105,4097,81,98,4112,513,116,80,4160,112,17,2,121,65,576,4112,4096,593,69,96,116,32,4177,513]

theorem envBound28557 : H12AffineFastState.Bounded env28557 := by
  intro p hp
  have h : env28557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28556_28557 : H12AffineEnvironment.transform 6 24 env28556 = env28557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env28556 == env28557) = true)

theorem identity28557 : scanCanonicalize (H12AffineFastState.compose env28557 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound28557 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env28558 : List Nat := [2,4,8,16,32,0,24,52,512,52,512,4096,41,4097,17,34,4112,513,52,16,4096,48,17,2,57,1,512,4112,4096,529,5,32,52,32,4113,513]

theorem envBound28558 : H12AffineFastState.Bounded env28558 := by
  intro p hp
  have h : env28558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28557_28558 : H12AffineEnvironment.transform 5 0 env28557 = env28558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env28557 == env28558) = true)

theorem identity28558 : scanCanonicalize (H12AffineFastState.compose env28558 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28558 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28559 : List Nat := [2,4,8,0,32,0,8,36,512,36,512,4096,41,4097,1,34,4096,513,36,0,4096,32,1,2,41,1,512,4096,4096,513,5,32,36,32,4097,513]

theorem envBound28559 : H12AffineFastState.Bounded env28559 := by
  intro p hp
  have h : env28559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28558_28559 : H12AffineEnvironment.transform 3 0 env28558 = env28559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28558 == env28559) = true)

theorem identity28559 : scanCanonicalize (H12AffineFastState.compose env28559 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound28559 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28560 : List Nat := [2,4,8,0,32,0,8,36,1,36,1,4096,41,4097,1,34,4096,0,36,0,4096,32,1,2,41,1,1,4096,4096,0,5,32,36,32,4097,0]

theorem envBound28560 : H12AffineFastState.Bounded env28560 := by
  intro p hp
  have h : env28560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28559_28560 : H12AffineEnvironment.transform 8 1 env28559 = env28560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env28559 == env28560) = true)

theorem identity28560 : scanCanonicalize (H12AffineFastState.compose env28560 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound28560 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env28561 : List Nat := [2,4,8,0,11,0,8,15,1,15,1,4096,2,4097,1,9,4096,0,15,0,4096,11,1,2,2,1,1,4096,4096,0,5,11,15,11,4097,0]

theorem envBound28561 : H12AffineFastState.Bounded env28561 := by
  intro p hp
  have h : env28561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28560_28561 : H12AffineEnvironment.transform 4 11 env28560 = env28561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env28560 == env28561) = true)

def env28562 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,8388608,98780,8328,65,12683623,5392,8406289,8456378,8390093,4256861,256,8410416,8434836,8462874]

theorem envBound28562 : H12AffineFastState.Bounded env28562 := by
  intro p hp
  have h : env28562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28492_28562 : H12AffineEnvironment.transform 20 4161 env28492 = env28562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env28492 == env28562) = true)

def env28563 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374560,98780,8328,65,215367,5392,4359473,4442266,4376045,4256861,256,4363536,4355252,4448826]

theorem envBound28563 : H12AffineFastState.Bounded env28563 := by
  intro p hp
  have h : env28563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28562_28563 : H12AffineEnvironment.transform 22 4374560 env28562 = env28563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374560 env28562 == env28563) = true)

theorem identity28563 : scanCanonicalize (H12AffineFastState.compose env28563 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180272) := by decide +kernel

theorem selectedBound28563 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env28564 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,180272,16,98780,8328,65,215367,5392,17665,67754,1501,144493,256,21792,46212,74250]

theorem envBound28564 : H12AffineFastState.Bounded env28564 := by
  intro p hp
  have h : env28564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28563_28564 : H12AffineEnvironment.transform 21 180272 env28563 = env28564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180272 env28563 == env28564) = true)

def env28565 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180272,16,98644,8192,65,215367,5392,17665,67618,1365,144493,256,21792,46092,74250]

theorem envBound28565 : H12AffineFastState.Bounded env28565 := by
  intro p hp
  have h : env28565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28564_28565 : H12AffineEnvironment.transform 6 8 env28564 = env28565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28564 == env28565) = true)

theorem identity28565 : scanCanonicalize (H12AffineFastState.compose env28565 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound28565 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28566 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,108927,1024,32769,4161,41340,16,98644,8192,65,75787,5392,17665,67618,1365,21793,256,21792,46092,74250]

theorem envBound28566 : H12AffineFastState.Bounded env28566 := by
  intro p hp
  have h : env28566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28565_28566 : H12AffineEnvironment.transform 16 24908 env28565 = env28566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env28565 == env28566) = true)

theorem identity28566 : scanCanonicalize (H12AffineFastState.compose env28566 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound28566 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env28567 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,32768,65536,13624,108927,1024,32769,4161,41340,16,98644,8192,65,75787,5392,4469,67618,1365,341,256,340,46092,74250]

theorem envBound28567 : H12AffineFastState.Bounded env28567 := by
  intro p hp
  have h : env28567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28566_28567 : H12AffineEnvironment.transform 13 5236 env28566 = env28567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env28566 == env28567) = true)

theorem identity28567 : scanCanonicalize (H12AffineFastState.compose env28567 (packedSelected [1,8,12,15,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound28567 : packedSelected [1,8,12,15,19] rootPS < 2^1333 := by decide +kernel

def env28568 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,32768,342,13624,43049,1024,32769,4161,41340,16,32770,8192,65,10589,5392,4469,2420,1365,341,256,340,46092,9052]

theorem envBound28568 : H12AffineFastState.Bounded env28568 := by
  intro p hp
  have h : env28568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28567_28568 : H12AffineEnvironment.transform 15 342 env28567 = env28568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env28567 == env28568) = true)

theorem identity28568 : scanCanonicalize (H12AffineFastState.compose env28568 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound28568 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env28569 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,293,342,13624,10508,1024,292,4161,8281,16,295,8192,65,10589,5392,4469,2420,1365,341,256,340,13609,9052]

theorem envBound28569 : H12AffineFastState.Bounded env28569 := by
  intro p hp
  have h : env28569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28568_28569 : H12AffineEnvironment.transform 14 293 env28568 = env28569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env28568 == env28569) = true)

def env28570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4161,180272,16,98645,8193,65,215367,5392,17665,67619,1364,144493,256,21792,46093,74250]

theorem envBound28570 : H12AffineFastState.Bounded env28570 := by
  intro p hp
  have h : env28570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28564_28570 : H12AffineEnvironment.transform 6 9 env28564 = env28570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28564 == env28570) = true)

theorem identity28570 : scanCanonicalize (H12AffineFastState.compose env28570 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound28570 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28571 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,67618,1024,32769,4161,32,16,98645,8193,65,100695,5392,17665,67619,1364,62589,256,21792,46093,74250]

theorem envBound28571 : H12AffineFastState.Bounded env28571 := by
  intro p hp
  have h : env28571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28570_28571 : H12AffineEnvironment.transform 16 49168 env28570 = env28571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env28570 == env28571) = true)

theorem identity28571 : scanCanonicalize (H12AffineFastState.compose env28571 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28571 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env28572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,16401,67618,1024,0,4161,32,16,65876,8193,65,67926,5392,17665,67619,1364,29820,256,21792,13324,74250]

theorem envBound28572 : H12AffineFastState.Bounded env28572 := by
  intro p hp
  have h : env28572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28571_28572 : H12AffineEnvironment.transform 14 1 env28571 = env28572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28571 == env28572) = true)

theorem identity28572 : scanCanonicalize (H12AffineFastState.compose env28572 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28572 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env28573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8202,16401,10280,1024,0,4161,32,16,8542,8193,65,10588,5392,17665,10281,1364,29820,256,21792,13324,512]

theorem envBound28573 : H12AffineFastState.Bounded env28573 := by
  intro p hp
  have h : env28573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28572_28573 : H12AffineEnvironment.transform 15 8202 env28572 = env28573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28572 == env28573) = true)

theorem identity28573 : scanCanonicalize (H12AffineFastState.compose env28573 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound28573 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env28574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1085,16384,1,1079,16401,3093,1024,0,4161,32,16,1379,1084,65,3425,5392,17665,3092,1364,20545,256,21792,4145,512]

theorem envBound28574 : H12AffineFastState.Bounded env28574 := by
  intro p hp
  have h : env28574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28573_28574 : H12AffineEnvironment.transform 12 1085 env28573 = env28574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env28573 == env28574) = true)

theorem identity28574 : scanCanonicalize (H12AffineFastState.compose env28574 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound28574 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28575 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,4096,120,16384,1,114,16401,2128,69,0,4161,32,16,294,121,65,2340,4437,16708,2129,273,20545,256,20837,4145,512]

theorem envBound28575 : H12AffineFastState.Bounded env28575 := by
  intro p hp
  have h : env28575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28574_28575 : H12AffineEnvironment.transform 9 69 env28574 = env28575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env28574 == env28575) = true)

theorem identity28575 : scanCanonicalize (H12AffineFastState.compose env28575 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 2389) := by decide +kernel

theorem selectedBound28575 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env28576 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,4096,120,2389,1,114,2372,2128,69,0,4161,32,16,294,121,65,2340,4437,2065,2129,273,6420,256,6192,4145,512]

theorem envBound28576 : H12AffineFastState.Bounded env28576 := by
  intro p hp
  have h : env28576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28575_28576 : H12AffineEnvironment.transform 13 2389 env28575 = env28576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2389 env28575 == env28576) = true)

theorem identity28576 : scanCanonicalize (H12AffineFastState.compose env28576 (packedSelected [0,1,4,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 113) := by decide +kernel

theorem selectedBound28576 : packedSelected [0,1,4,6,8] rootPS < 2^1333 := by decide +kernel

def env28577 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,113,120,2389,1,114,2372,2128,69,0,48,32,16,294,121,65,2340,292,2065,2129,273,2405,256,2113,64,512]

theorem envBound28577 : H12AffineFastState.Bounded env28577 := by
  intro p hp
  have h : env28577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28576_28577 : H12AffineEnvironment.transform 11 113 env28576 = env28577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 113 env28576 == env28577) = true)

theorem identity28577 : scanCanonicalize (H12AffineFastState.compose env28577 (packedSelected [0,2,6,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 276) := by decide +kernel

theorem selectedBound28577 : packedSelected [0,2,6,7,12] rootPS < 2^1333 := by decide +kernel

def env28578 : List Nat := [2,4,8,16,32,64,9,256,512,69,276,113,120,65,1,114,80,324,69,0,48,32,16,294,121,65,48,292,261,325,273,113,256,341,64,512]

theorem envBound28578 : H12AffineFastState.Bounded env28578 := by
  intro p hp
  have h : env28578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28577_28578 : H12AffineEnvironment.transform 10 276 env28577 = env28578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 276 env28577 == env28578) = true)

theorem identity28578 : scanCanonicalize (H12AffineFastState.compose env28578 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound28578 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env28579 : List Nat := [2,4,8,1,32,64,9,256,512,69,261,96,105,65,1,99,65,324,69,0,33,32,1,294,104,65,33,292,261,325,256,96,256,324,64,512]

theorem envBound28579 : H12AffineFastState.Bounded env28579 := by
  intro p hp
  have h : env28579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28578_28579 : H12AffineEnvironment.transform 3 1 env28578 = env28579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env28578 == env28579) = true)

theorem identity28579 : scanCanonicalize (H12AffineFastState.compose env28579 (packedSelected [1,2,5] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound28579 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env28580 : List Nat := [2,4,8,1,32,64,9,256,97,69,261,96,105,65,1,99,65,324,69,0,33,32,1,294,104,65,33,292,261,325,256,96,256,324,64,97]

theorem envBound28580 : H12AffineFastState.Bounded env28580 := by
  intro p hp
  have h : env28580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28579_28580 : H12AffineEnvironment.transform 8 97 env28579 = env28580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env28579 == env28580) = true)

theorem identity28580 : scanCanonicalize (H12AffineFastState.compose env28580 (packedSelected [1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound28580 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env28581 : List Nat := [2,4,8,1,32,64,9,36,97,69,33,96,105,65,1,99,65,96,69,0,33,32,1,2,104,65,33,0,33,97,36,96,36,96,64,97]

theorem envBound28581 : H12AffineFastState.Bounded env28581 := by
  intro p hp
  have h : env28581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28580_28581 : H12AffineEnvironment.transform 7 36 env28580 = env28581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env28580 == env28581) = true)

theorem identity28581 : scanCanonicalize (H12AffineFastState.compose env28581 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound28581 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28582 : List Nat := [2,4,8,1,32,32,9,36,1,37,33,0,9,33,1,3,33,0,37,0,33,32,1,2,8,33,33,0,33,1,36,0,36,0,32,1]

theorem envBound28582 : H12AffineFastState.Bounded env28582 := by
  intro p hp
  have h : env28582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28581_28582 : H12AffineEnvironment.transform 5 32 env28581 = env28582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env28581 == env28582) = true)

def env28583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4161,4194304,4374561,98780,8328,65,215366,5392,4359472,4442267,4376044,4256861,256,4363537,4355253,4448827]

theorem envBound28583 : H12AffineFastState.Bounded env28583 := by
  intro p hp
  have h : env28583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28562_28583 : H12AffineEnvironment.transform 22 4374561 env28562 = env28583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4374561 env28562 == env28583) = true)

def env28584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100523,1024,32769,4161,4194304,4227121,98780,8328,65,67926,5392,4244768,4294795,4228604,4256861,256,4248833,4207781,4301355]

theorem envBound28584 : H12AffineFastState.Bounded env28584 := by
  intro p hp
  have h : env28584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28583_28584 : H12AffineEnvironment.transform 16 16400 env28583 = env28584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env28583 == env28584) = true)

theorem identity28584 : scanCanonicalize (H12AffineFastState.compose env28584 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(21+1) ^^^ 32936) := by decide +kernel

theorem selectedBound28584 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env28585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,100523,1024,32769,4161,32936,153,98780,8328,65,67926,5392,17800,67619,1364,29941,256,21929,46093,74371]

theorem envBound28585 : H12AffineFastState.Bounded env28585 := by
  intro p hp
  have h : env28585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28584_28585 : H12AffineEnvironment.transform 21 32936 env28584 = env28585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32936 env28584 == env28585) = true)

theorem identity28585 : scanCanonicalize (H12AffineFastState.compose env28585 (packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound28585 : packedSelected [5,8,16,18,20,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env28586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43169,1024,32769,4161,32936,153,41430,8328,65,10588,5392,17800,10281,1364,29941,256,21929,46093,649]

theorem envBound28586 : H12AffineFastState.Bounded env28586 := by
  intro p hp
  have h : env28586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28585_28586 : H12AffineEnvironment.transform 15 8202 env28585 = env28586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env28585 == env28586) = true)

theorem identity28586 : scanCanonicalize (H12AffineFastState.compose env28586 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound28586 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env28587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8202,16400,2557,1024,8541,4161,8692,153,138,8328,65,10588,5392,17800,10281,1364,29941,256,21929,5457,649]

theorem envBound28587 : H12AffineFastState.Bounded env28587 := by
  intro p hp
  have h : env28587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28586_28587 : H12AffineEnvironment.transform 14 8540 env28586 = env28587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env28586 == env28587) = true)

theorem identity28587 : scanCanonicalize (H12AffineFastState.compose env28587 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound28587 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env28588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,16400,2421,1024,8541,4161,8572,17,2,8192,65,10588,5392,17664,10281,1364,29821,256,21793,5457,513]

theorem envBound28588 : H12AffineFastState.Bounded env28588 := by
  intro p hp
  have h : env28588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28587_28588 : H12AffineEnvironment.transform 6 8 env28587 = env28588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28587 == env28588) = true)

theorem identity28588 : scanCanonicalize (H12AffineFastState.compose env28588 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound28588 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env28589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5156,8540,8202,5172,2421,1024,8541,4161,8572,17,2,8192,65,10588,5392,4388,10281,1364,8281,256,261,5457,513]

theorem envBound28589 : H12AffineFastState.Bounded env28589 := by
  intro p hp
  have h : env28589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28588_28589 : H12AffineEnvironment.transform 13 5156 env28588 = env28589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env28588 == env28589) = true)

theorem identity28589 : scanCanonicalize (H12AffineFastState.compose env28589 (packedSelected [1,2,6,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound28589 : packedSelected [1,2,6,8,10] rootPS < 2^1333 := by decide +kernel

def env28590 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5156,372,34,5172,2421,1024,373,4161,340,17,2,40,65,2420,5392,4388,2049,1364,113,256,261,5457,513]

theorem envBound28590 : H12AffineFastState.Bounded env28590 := by
  intro p hp
  have h : env28590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28589_28590 : H12AffineEnvironment.transform 12 40 env28589 = env28590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env28589 == env28590) = true)

theorem identity28590 : scanCanonicalize (H12AffineFastState.compose env28590 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound28590 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28591 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,40,2048,372,34,2064,2421,1024,373,3173,340,17,2,40,65,2420,2356,3328,2049,1364,113,256,261,2421,513]

theorem envBound28591 : H12AffineFastState.Bounded env28591 := by
  intro p hp
  have h : env28591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28590_28591 : H12AffineEnvironment.transform 11 3108 env28590 = env28591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env28590 == env28591) = true)

theorem identity28591 : scanCanonicalize (H12AffineFastState.compose env28591 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound28591 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env28592 : List Nat := [2,4,8,16,32,64,8,256,512,1024,292,1280,40,292,372,34,308,81,1024,373,1345,340,17,2,40,65,80,16,1060,293,1364,113,256,261,81,513]

theorem envBound28592 : H12AffineFastState.Bounded env28592 := by
  intro p hp
  have h : env28592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28591_28592 : H12AffineEnvironment.transform 10 292 env28591 = env28592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env28591 == env28592) = true)

theorem identity28592 : scanCanonicalize (H12AffineFastState.compose env28592 (packedSelected [1,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound28592 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env28593 : List Nat := [2,4,8,16,32,64,8,256,512,53,292,309,40,292,372,34,308,81,53,373,372,340,17,2,40,65,80,16,17,293,353,113,256,261,81,513]

theorem envBound28593 : H12AffineFastState.Bounded env28593 := by
  intro p hp
  have h : env28593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28592_28593 : H12AffineEnvironment.transform 9 53 env28592 = env28593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env28592 == env28593) = true)

theorem identity28593 : scanCanonicalize (H12AffineFastState.compose env28593 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound28593 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28594 : List Nat := [2,4,8,16,32,64,8,117,512,53,81,64,40,81,1,34,65,81,53,0,1,33,17,2,40,65,80,16,17,80,20,113,117,112,81,513]

theorem envBound28594 : H12AffineFastState.Bounded env28594 := by
  intro p hp
  have h : env28594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28593_28594 : H12AffineEnvironment.transform 7 117 env28593 = env28594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env28593 == env28594) = true)

def env28595 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,100522,1024,32769,4161,4194304,4227120,98780,8328,65,67927,5392,4244769,4294794,4228605,4256861,256,4248832,4207780,4301354]

theorem envBound28595 : H12AffineFastState.Bounded env28595 := by
  intro p hp
  have h : env28595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28583_28595 : H12AffineEnvironment.transform 16 16401 env28583 = env28595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env28583 == env28595) = true)

theorem identity28595 : scanCanonicalize (H12AffineFastState.compose env28595 (packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 41091) := by decide +kernel

theorem selectedBound28595 : packedSelected [0,4,5,7,8,11,17,18,22,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env28596 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,41091,16401,10281,1024,32769,4161,4194304,4227120,8543,8328,65,43476,5392,4244769,4204553,4228605,4256861,256,4248832,4207780,4194985]

theorem envBound28596 : H12AffineFastState.Bounded env28596 := by
  intro p hp
  have h : env28596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28595_28596 : H12AffineEnvironment.transform 15 41091 env28595 = env28596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41091 env28595 == env28596) = true)

theorem identity28596 : scanCanonicalize (H12AffineFastState.compose env28596 (packedSelected [1,3,5,8,12,16,17,20,26,31,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound28596 : packedSelected [1,3,5,8,12,16,17,20,26,31,41] rootPS < 2^1333 := by decide +kernel

def env28597 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1024,32769,4161,4194304,4227120,8543,8193,65,43357,5392,4244769,4204553,4228468,4256861,256,4248832,4207661,4194848]

theorem envBound28597 : H12AffineFastState.Bounded env28597 := by
  intro p hp
  have h : env28597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28596_28597 : H12AffineEnvironment.transform 6 9 env28596 = env28597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env28596 == env28597) = true)

theorem identity28597 : scanCanonicalize (H12AffineFastState.compose env28597 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound28597 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env28598 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40970,16401,10281,1024,32769,4161,33,32785,8543,8193,65,43357,5392,50432,10280,34133,62588,256,54561,13324,513]

theorem envBound28598 : H12AffineFastState.Bounded env28598 := by
  intro p hp
  have h : env28598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28597_28598 : H12AffineEnvironment.transform 21 33 env28597 = env28598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env28597 == env28598) = true)

theorem identity28598 : scanCanonicalize (H12AffineFastState.compose env28598 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound28598 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env28599 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40970,13388,10281,1024,32769,4161,33,32785,8543,8193,65,43357,5392,45405,10280,34133,32801,256,41340,13324,513]

theorem envBound28599 : H12AffineFastState.Bounded env28599 := by
  intro p hp
  have h : env28599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28598_28599 : H12AffineEnvironment.transform 13 13405 env28598 = env28599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env28598 == env28599) = true)

theorem identity28599 : scanCanonicalize (H12AffineFastState.compose env28599 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound28599 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28600 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,1,8203,13388,10281,1024,0,4161,33,16,8543,8193,65,10588,5392,12636,10280,1364,32,256,8573,13324,513]

theorem envBound28600 : H12AffineFastState.Bounded env28600 := by
  intro p hp
  have h : env28600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28599_28600 : H12AffineEnvironment.transform 14 1 env28599 = env28600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env28599 == env28600) = true)

theorem identity28600 : scanCanonicalize (H12AffineFastState.compose env28600 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound28600 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28601 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,343,5392,2421,1024,0,4161,33,16,3,349,65,2048,5392,4096,2420,1364,32,256,33,5456,513]

theorem envBound28601 : H12AffineFastState.Bounded env28601 := by
  intro p hp
  have h : env28601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28600_28601 : H12AffineEnvironment.transform 12 348 env28600 = env28601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env28600 == env28601) = true)

theorem identity28601 : scanCanonicalize (H12AffineFastState.compose env28601 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound28601 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28602 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,357,348,1124,1,343,1141,2421,1024,0,292,33,16,3,349,65,2048,1141,357,2420,1364,32,256,33,1077,513]

theorem envBound28602 : H12AffineFastState.Bounded env28602 := by
  intro p hp
  have h : env28602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28601_28602 : H12AffineEnvironment.transform 11 357 env28601 = env28602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env28601 == env28602) = true)

theorem identity28602 : scanCanonicalize (H12AffineFastState.compose env28602 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound28602 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env28603 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,357,348,1124,1,343,1141,1297,1024,0,292,33,16,3,349,65,1124,1141,357,1296,1364,32,256,33,1077,513]

theorem envBound28603 : H12AffineFastState.Bounded env28603 := by
  intro p hp
  have h : env28603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28602_28603 : H12AffineEnvironment.transform 10 1124 env28602 = env28603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env28602 == env28603) = true)

theorem identity28603 : scanCanonicalize (H12AffineFastState.compose env28603 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound28603 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env28604 : List Nat := [2,4,8,16,32,64,9,256,309,1024,1124,357,348,1124,1,343,1141,1297,1024,0,292,33,16,3,349,65,1124,1141,357,1296,1364,32,256,33,1077,308]

theorem envBound28604 : H12AffineFastState.Bounded env28604 := by
  intro p hp
  have h : env28604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28603_28604 : H12AffineEnvironment.transform 8 309 env28603 = env28604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env28603 == env28604) = true)

theorem identity28604 : scanCanonicalize (H12AffineFastState.compose env28604 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound28604 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env28605 : List Nat := [2,4,8,16,32,33,9,256,309,1024,1029,260,317,1029,1,310,1044,1297,1024,0,292,33,16,3,316,32,1029,1044,260,1296,1333,32,256,33,1077,308]

theorem envBound28605 : H12AffineFastState.Bounded env28605 := by
  intro p hp
  have h : env28605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28604_28605 : H12AffineEnvironment.transform 5 33 env28604 = env28605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env28604 == env28605) = true)

theorem identity28605 : scanCanonicalize (H12AffineFastState.compose env28605 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28605 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env28606 : List Nat := [2,4,8,16,0,1,9,256,277,1024,1029,260,285,1029,1,278,1044,1297,1024,0,260,1,16,3,284,0,1029,1044,260,1296,1301,0,256,1,1045,276]

theorem envBound28606 : H12AffineFastState.Bounded env28606 := by
  intro p hp
  have h : env28606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28605_28606 : H12AffineEnvironment.transform 4 0 env28605 = env28606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28605 == env28606) = true)

theorem identity28606 : scanCanonicalize (H12AffineFastState.compose env28606 (packedSelected [0,2,4,15] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound28606 : packedSelected [0,2,4,15] rootPS < 2^1333 := by decide +kernel

def env28607 : List Nat := [2,4,8,0,0,1,9,256,261,1024,1029,260,269,1029,1,262,1028,1281,1024,0,260,1,0,3,268,0,1029,1028,260,1280,1285,0,256,1,1029,260]

theorem envBound28607 : H12AffineFastState.Bounded env28607 := by
  intro p hp
  have h : env28607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28606_28607 : H12AffineEnvironment.transform 3 0 env28606 = env28607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env28606 == env28607) = true)

theorem identity28607 : scanCanonicalize (H12AffineFastState.compose env28607 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound28607 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env28608 : List Nat := [2,4,8,0,0,1,9,256,261,256,261,260,269,261,1,262,260,1,256,0,260,1,0,3,268,0,261,260,260,0,5,0,256,1,261,260]

theorem envBound28608 : H12AffineFastState.Bounded env28608 := by
  intro p hp
  have h : env28608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28607_28608 : H12AffineEnvironment.transform 9 256 env28607 = env28608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env28607 == env28608) = true)

theorem identity28608 : scanCanonicalize (H12AffineFastState.compose env28608 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound28608 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env28609 : List Nat := [2,4,8,0,0,1,9,4,1,4,1,0,9,1,1,2,0,1,4,0,0,1,0,3,8,0,1,0,0,0,5,0,4,1,1,0]

theorem envBound28609 : H12AffineFastState.Bounded env28609 := by
  intro p hp
  have h : env28609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28608_28609 : H12AffineEnvironment.transform 7 4 env28608 = env28609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env28608 == env28609) = true)

def env28610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507600,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound28610 : H12AffineFastState.Bounded env28610 := by
  intro p hp
  have h : env28610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28392_28610 : H12AffineEnvironment.transform 18 1025 env28392 = env28610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env28392 == env28610) = true)

theorem identity28610 : scanCanonicalize (H12AffineFastState.compose env28610 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8661050) := by decide +kernel

theorem selectedBound28610 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env28611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8328,65,4450363,10857654,10507600,8830976,371755,15027706,257,2485398,2428211,297981]

theorem envBound28611 : H12AffineFastState.Bounded env28611 := by
  intro p hp
  have h : env28611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28610_28611 : H12AffineEnvironment.transform 23 8661050 env28610 = env28611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8661050 env28610 == env28611) = true)

def env28612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8661050,8192,65,4450363,10857534,10507600,8830976,371755,15027570,257,2485278,2428211,297845]

theorem envBound28612 : H12AffineFastState.Bounded env28612 := by
  intro p hp
  have h : env28612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28611_28612 : H12AffineEnvironment.transform 6 8 env28611 = env28612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env28611 == env28612) = true)

theorem identity28612 : scanCanonicalize (H12AffineFastState.compose env28612 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound28612 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env28613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,8429902,8192,65,4450363,10560842,10507600,8538484,75103,14795782,257,2188650,2196551,513]

theorem envBound28613 : H12AffineFastState.Bounded env28613 := by
  intro p hp
  have h : env28613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28612_28613 : H12AffineEnvironment.transform 17 35188 env28612 = env28613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env28612 == env28613) = true)

def env28614 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,16,41310,8192,65,4450363,2172250,2118976,149860,75103,6407190,257,2188650,2196551,513]

theorem envBound28614 : H12AffineFastState.Bounded env28614 := by
  intro p hp
  have h : env28614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28613_28614 : H12AffineEnvironment.transform 22 16 env28613 = env28614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env28613 == env28614) = true)

theorem identity28614 : scanCanonicalize (H12AffineFastState.compose env28614 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound28614 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env28615 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229153,2172250,2118976,76158,75103,6407190,257,2188650,2196551,513]

theorem envBound28615 : H12AffineFastState.Bounded env28615 := by
  intro p hp
  have h : env28615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28614_28615 : H12AffineEnvironment.transform 16 90138 env28614 = env28615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env28614 == env28615) = true)

theorem identity28615 : scanCanonicalize (H12AffineFastState.compose env28615 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound28615 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env28616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57677,35188,1025,32769,2097152,4194304,16,41310,8192,65,4229153,2139149,2118976,43049,41992,6309185,257,2155581,2098448,513]

theorem envBound28616 : H12AffineFastState.Bounded env28616 := by
  intro p hp
  have h : env28616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28615_28616 : H12AffineEnvironment.transform 15 33111 env28615 = env28616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env28615 == env28616) = true)

theorem identity28616 : scanCanonicalize (H12AffineFastState.compose env28616 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound28616 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env28617 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1025,8540,2097152,4194304,16,3,8192,65,4204924,2098512,2118976,2420,1365,6309185,257,2114912,2098448,513]

theorem envBound28617 : H12AffineFastState.Bounded env28617 := by
  intro p hp
  have h : env28617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28616_28617 : H12AffineEnvironment.transform 14 8541 env28616 = env28617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env28616 == env28617) = true)

theorem identity28617 : scanCanonicalize (H12AffineFastState.compose env28617 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound28617 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28618 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1025,8540,2097152,2114912,16,3,8192,65,2124828,2098512,2118976,2420,1365,33,257,2114912,2098448,513]

theorem envBound28618 : H12AffineFastState.Bounded env28618 := by
  intro p hp
  have h : env28618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28617_28618 : H12AffineEnvironment.transform 21 2114912 env28617 = env28618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env28617 == env28618) = true)

theorem identity28618 : scanCanonicalize (H12AffineFastState.compose env28618 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound28618 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env28619 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1025,8540,25677,8493,16,3,8192,65,2129,24861,12557,2420,1365,33,257,8493,24925,513]

theorem envBound28619 : H12AffineFastState.Bounded env28619 := by
  intro p hp
  have h : env28619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28618_28619 : H12AffineEnvironment.transform 20 25677 env28618 = env28619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env28618 == env28619) = true)

theorem identity28619 : scanCanonicalize (H12AffineFastState.compose env28619 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound28619 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env28620 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,81,262,16400,2341,1025,80,17729,33,16,3,268,65,2129,16401,4097,2420,1365,33,257,33,16465,513]

theorem envBound28620 : H12AffineFastState.Bounded env28620 := by
  intro p hp
  have h : env28620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28619_28620 : H12AffineEnvironment.transform 12 268 env28619 = env28620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env28619 == env28620) = true)

theorem identity28620 : scanCanonicalize (H12AffineFastState.compose env28620 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1393) := by decide +kernel

theorem selectedBound28620 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env28621 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1393,268,16384,81,262,16400,2341,1025,80,17729,33,16,3,268,65,2129,16401,1392,2420,1365,33,257,33,16465,513]

theorem envBound28621 : H12AffineFastState.Bounded env28621 := by
  intro p hp
  have h : env28621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28620_28621 : H12AffineEnvironment.transform 11 1393 env28620 = env28621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1393 env28620 == env28621) = true)

theorem identity28621 : scanCanonicalize (H12AffineFastState.compose env28621 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 2624) := by decide +kernel

theorem selectedBound28621 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env28622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1393,268,2624,81,262,2640,2341,1025,80,3841,33,16,3,268,65,2129,2641,1392,2420,1365,33,257,33,2577,513]

theorem envBound28622 : H12AffineFastState.Bounded env28622 := by
  intro p hp
  have h : env28622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28621_28622 : H12AffineEnvironment.transform 13 2624 env28621 = env28622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2624 env28621 == env28622) = true)

theorem identity28622 : scanCanonicalize (H12AffineFastState.compose env28622 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound28622 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env28623 : List Nat := [2,4,8,16,32,64,8,256,277,1024,2048,1393,268,2389,81,262,2373,2341,1025,80,3092,33,16,3,268,65,2129,2372,1392,2420,1365,33,257,33,2308,276]

theorem envBound28623 : H12AffineFastState.Bounded env28623 := by
  intro p hp
  have h : env28623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28622_28623 : H12AffineEnvironment.transform 8 277 env28622 = env28623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env28622 == env28623) = true)

theorem identity28623 : scanCanonicalize (H12AffineFastState.compose env28623 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound28623 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env28624 : List Nat := [2,4,8,16,32,64,8,85,64,1024,2048,1060,89,2048,81,83,2064,2160,1025,80,3092,33,16,3,89,65,2129,2065,1061,2081,1024,33,84,33,2129,65]

theorem envBound28624 : H12AffineFastState.Bounded env28624 := by
  intro p hp
  have h : env28624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28623_28624 : H12AffineEnvironment.transform 7 85 env28623 = env28624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env28623 == env28624) = true)

def env28625 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,17,41311,8192,65,4450363,2172251,2118977,149861,75103,6407191,257,2188650,2196551,513]

theorem envBound28625 : H12AffineFastState.Bounded env28625 := by
  intro p hp
  have h : env28625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28613_28625 : H12AffineEnvironment.transform 22 17 env28613 = env28625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env28613 == env28625) = true)

theorem identity28625 : scanCanonicalize (H12AffineFastState.compose env28625 (packedSelected [0,1,5,7,8,19,20,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound28625 : packedSelected [0,1,5,7,8,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env28626 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,115735,4194304,17,41311,8192,65,4450363,57676,102742,149861,75103,4194304,257,41341,16464,513]

theorem envBound28626 : H12AffineFastState.Bounded env28626 := by
  intro p hp
  have h : env28626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28625_28626 : H12AffineEnvironment.transform 20 115735 env28625 = env28626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env28625 == env28626) = true)

def env28627 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,131072,9292,1025,11577,92463,4194304,17,3175,8192,65,4408579,19572,81006,149861,75103,4194304,257,3141,16464,513]

theorem envBound28627 : H12AffineFastState.Bounded env28627 := by
  intro p hp
  have h : env28627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28626_28627 : H12AffineEnvironment.transform 14 11576 env28626 = env28627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 11576 env28626 == env28627) = true)

theorem identity28627 : scanCanonicalize (H12AffineFastState.compose env28627 (packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound28627 : packedSelected [4,5,8,9,10,11,12,15,18,19,24,28,32] rootPS < 2^1333 := by decide +kernel

def env28628 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,11576,65536,82247,9292,1025,11577,92463,4194304,17,3175,8192,65,4195396,19572,81006,67618,75103,4194304,257,3141,16464,513]

theorem envBound28628 : H12AffineFastState.Bounded env28628 := by
  intro p hp
  have h : env28628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28627_28628 : H12AffineEnvironment.transform 16 82247 env28627 = env28628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env28627 == env28628) = true)

def env28629 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8540,65536,82247,9292,1025,8541,91467,4194304,17,3,8192,65,4195396,16400,77834,66630,75103,4194304,257,33,16464,513]

theorem envBound28629 : H12AffineFastState.Bounded env28629 := by
  intro p hp
  have h : env28629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28628_28629 : H12AffineEnvironment.transform 10 1124 env28628 = env28629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env28628 == env28629) = true)

theorem identity28629 : scanCanonicalize (H12AffineFastState.compose env28629 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound28629 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env28630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,8192,16384,8540,28698,12637,9292,1025,8541,5457,4194304,17,3,8192,65,4195396,16400,16400,29788,21829,4194304,257,33,16464,513]

theorem envBound28630 : H12AffineFastState.Bounded env28630 := by
  intro p hp
  have h : env28630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28629_28630 : H12AffineEnvironment.transform 15 28698 env28629 = env28630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env28629 == env28630) = true)

theorem identity28630 : scanCanonicalize (H12AffineFastState.compose env28630 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound28630 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env28631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,4096,41,16384,373,20531,4468,1125,1025,372,5457,4194304,17,3,41,65,4195396,16400,16400,21621,21829,4194304,257,33,16464,513]

theorem envBound28631 : H12AffineFastState.Bounded env28631 := by
  intro p hp
  have h : env28631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28630_28631 : H12AffineEnvironment.transform 12 41 env28630 = env28631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env28630 == env28631) = true)

theorem identity28631 : scanCanonicalize (H12AffineFastState.compose env28631 (packedSelected [1,8,19] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound28631 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env28632 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,1,20531,4096,1125,1025,0,5157,4194304,17,3,41,65,4195396,16400,16400,21621,21553,4194304,117,33,16464,513]

theorem envBound28632 : H12AffineFastState.Bounded env28632 := by
  intro p hp
  have h : env28632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28631_28632 : H12AffineEnvironment.transform 7 116 env28631 = env28632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env28631 == env28632) = true)

theorem identity28632 : scanCanonicalize (H12AffineFastState.compose env28632 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 1044) := by decide +kernel

theorem selectedBound28632 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env28633 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,16384,1,20531,4096,1125,1025,0,5157,1044,17,3,41,65,80,16400,16400,21621,21553,1044,117,33,16464,513]

theorem envBound28633 : H12AffineFastState.Bounded env28633 := by
  intro p hp
  have h : env28633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28632_28633 : H12AffineEnvironment.transform 21 1044 env28632 = env28633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1044 env28632 == env28633) = true)

theorem identity28633 : scanCanonicalize (H12AffineFastState.compose env28633 (packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound28633 : packedSelected [0,1,2,3,4,5,6,7,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env28634 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,4096,41,0,1,4147,4096,1125,1025,0,5157,1044,17,3,41,65,80,16,16,5237,5169,1044,117,33,80,513]

theorem envBound28634 : H12AffineFastState.Bounded env28634 := by
  intro p hp
  have h : env28634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28633_28634 : H12AffineEnvironment.transform 13 0 env28633 = env28634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env28633 == env28634) = true)

theorem identity28634 : scanCanonicalize (H12AffineFastState.compose env28634 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound28634 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env28635 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1124,17,41,0,1,34,17,1125,1025,0,1076,1044,17,3,41,65,80,16,16,1124,1056,1044,117,33,80,513]

theorem envBound28635 : H12AffineFastState.Bounded env28635 := by
  intro p hp
  have h : env28635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28634_28635 : H12AffineEnvironment.transform 11 17 env28634 = env28635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env28634 == env28635) = true)

theorem identity28635 : scanCanonicalize (H12AffineFastState.compose env28635 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound28635 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env28636 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1077,17,41,0,1,34,17,1076,1025,0,1076,1044,17,3,41,16,1,16,16,1077,1056,1044,36,33,1,513]

theorem envBound28636 : H12AffineFastState.Bounded env28636 := by
  intro p hp
  have h : env28636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28635_28636 : H12AffineEnvironment.transform 5 17 env28635 = env28636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env28635 == env28636) = true)

theorem identity28636 : scanCanonicalize (H12AffineFastState.compose env28636 (packedSelected [0,1,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound28636 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env28637 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,17,9,0,1,2,17,1044,1025,0,1044,1044,17,3,9,16,1,16,16,1045,1024,1044,4,1,1,513]

theorem envBound28637 : H12AffineFastState.Bounded env28637 := by
  intro p hp
  have h : env28637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans28636_28637 : H12AffineEnvironment.transform 4 0 env28636 = env28637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env28636 == env28637) = true)

theorem identity28637 : scanCanonicalize (H12AffineFastState.compose env28637 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound28637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1