import H12CloudChart1Data048

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity12275 : scanCanonicalize (H12AffineFastState.compose env12275 (packedSelected [3,5,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12275 : packedSelected [3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env12276 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1,160,1197,0,171,1077,2184,1025,1,16,32,153,2,40,17,2049,1076,137,2185,1057,169,172,33,1061,513]

theorem envBound12276 : H12AffineFastState.Bounded env12276 := by
  intro p hp
  have h : env12276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12275_12276 : H12AffineEnvironment.transform 5 16 env12275 = env12276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12275 == env12276) = true)

theorem identity12276 : scanCanonicalize (H12AffineFastState.compose env12276 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12276 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12277 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,1,40,1061,0,35,1077,2048,1025,1,16,32,17,2,40,17,2049,1076,1,2049,1057,33,36,33,1061,513]

theorem envBound12277 : H12AffineFastState.Bounded env12277 := by
  intro p hp
  have h : env12277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12276_12277 : H12AffineEnvironment.transform 6 8 env12276 = env12277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12276 == env12277) = true)

theorem identity12277 : scanCanonicalize (H12AffineFastState.compose env12277 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound12277 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12278 : List Nat := [2,4,8,16,32,16,8,37,512,52,2048,1,40,17,0,35,1,2048,53,1,16,32,17,2,40,17,2049,0,1,2049,21,33,36,33,17,513]

theorem envBound12278 : H12AffineFastState.Bounded env12278 := by
  intro p hp
  have h : env12278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12277_12278 : H12AffineEnvironment.transform 9 52 env12277 = env12278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env12277 == env12278) = true)

theorem identity12278 : scanCanonicalize (H12AffineFastState.compose env12278 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 37) := by decide +kernel

theorem selectedBound12278 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12279 : List Nat := [2,4,8,16,32,16,8,37,37,52,2048,1,40,17,0,35,1,2048,53,1,16,32,17,2,40,17,2049,0,1,2049,21,33,36,33,17,36]

theorem envBound12279 : H12AffineFastState.Bounded env12279 := by
  intro p hp
  have h : env12279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12278_12279 : H12AffineEnvironment.transform 8 37 env12278 = env12279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 37 env12278 == env12279) = true)

theorem identity12279 : scanCanonicalize (H12AffineFastState.compose env12279 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 9) := by decide +kernel

theorem selectedBound12279 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12280 : List Nat := [2,4,8,16,32,16,8,37,37,52,9,1,40,17,0,35,1,9,53,1,16,32,17,2,40,17,8,0,1,8,21,33,36,33,17,36]

theorem envBound12280 : H12AffineFastState.Bounded env12280 := by
  intro p hp
  have h : env12280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12279_12280 : H12AffineEnvironment.transform 10 9 env12279 = env12280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 9 env12279 == env12280) = true)

theorem identity12280 : scanCanonicalize (H12AffineFastState.compose env12280 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound12280 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12281 : List Nat := [1,4,8,16,32,16,8,37,37,52,9,1,40,17,0,32,1,9,53,1,16,32,17,1,40,17,8,0,1,8,21,33,36,33,17,36]

theorem envBound12281 : H12AffineFastState.Bounded env12281 := by
  intro p hp
  have h : env12281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12280_12281 : H12AffineEnvironment.transform 0 1 env12280 = env12281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env12280 == env12281) = true)

theorem identity12281 : scanCanonicalize (H12AffineFastState.compose env12281 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound12281 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12282 : List Nat := [1,4,8,16,24,16,8,29,29,12,9,1,16,17,0,24,1,9,13,1,16,24,17,1,16,17,8,0,1,8,21,25,28,25,17,28]

theorem envBound12282 : H12AffineFastState.Bounded env12282 := by
  intro p hp
  have h : env12282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12281_12282 : H12AffineEnvironment.transform 4 24 env12281 = env12282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env12281 == env12282) = true)

def env12283 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,8388608,8487373,8328,65,171417,8393985,8406288,8526964,1500,8451181,257,21792,46212,74250]

theorem envBound12283 : H12AffineFastState.Bounded env12283 := by
  intro p hp
  have h : env12283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12240_12283 : H12AffineEnvironment.transform 21 33 env12240 = env12283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12240 == env12283) = true)

theorem identity12283 : scanCanonicalize (H12AffineFastState.compose env12283 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound12283 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,17,98780,8328,65,171417,5392,17665,138341,1500,62588,257,21792,46212,74250]

theorem envBound12284 : H12AffineFastState.Bounded env12284 := by
  intro p hp
  have h : env12284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12283_12284 : H12AffineEnvironment.transform 22 17 env12283 = env12284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12283 == env12284) = true)

def env12285 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,17,98644,8192,65,171281,5392,17665,138341,1364,62588,257,21792,46092,74250]

theorem envBound12285 : H12AffineFastState.Bounded env12285 := by
  intro p hp
  have h : env12285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12284_12285 : H12AffineEnvironment.transform 6 8 env12284 = env12285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12284 == env12285) = true)

theorem identity12285 : scanCanonicalize (H12AffineFastState.compose env12285 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12285 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12286 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56436,1025,32769,4161,33,17,41311,8192,65,171281,5392,17665,138341,1364,62588,257,21792,46092,513]

theorem envBound12286 : H12AffineFastState.Bounded env12286 := by
  intro p hp
  have h : env12286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12285_12286 : H12AffineEnvironment.transform 15 8203 env12285 = env12286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12285 == env12286) = true)

theorem identity12286 : scanCanonicalize (H12AffineFastState.compose env12286 (packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound12286 : packedSelected [0,2,3,6,7,10,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12287 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,56436,1025,32769,4161,33,17,41311,8192,65,23809,5392,17665,56437,1364,62588,257,21792,46092,513]

theorem envBound12287 : H12AffineFastState.Bounded env12287 := by
  intro p hp
  have h : env12287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12286_12287 : H12AffineEnvironment.transform 16 49168 env12286 = env12287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env12286 == env12287) = true)

theorem identity12287 : scanCanonicalize (H12AffineFastState.compose env12287 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12287 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12288 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8203,49168,56357,1025,32769,4112,33,17,41230,8192,16,23809,5392,17665,56356,1285,62509,257,21792,46092,513]

theorem envBound12288 : H12AffineFastState.Bounded env12288 := by
  intro p hp
  have h : env12288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12287_12288 : H12AffineEnvironment.transform 5 17 env12287 = env12288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12287 == env12288) = true)

def env12289 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56436,1025,32769,4161,33,17,98645,8193,65,171280,5392,17665,138341,1365,62588,257,21792,46093,74250]

theorem envBound12289 : H12AffineFastState.Bounded env12289 := by
  intro p hp
  have h : env12289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12284_12289 : H12AffineEnvironment.transform 6 9 env12284 = env12289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12284 == env12289) = true)

theorem identity12289 : scanCanonicalize (H12AffineFastState.compose env12289 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound12289 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,56436,1025,32769,4161,33,17,3,8193,65,171280,5392,17665,138341,1365,62588,257,21792,46093,41820]

theorem envBound12290 : H12AffineFastState.Bounded env12290 := by
  intro p hp
  have h : env12290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12289_12290 : H12AffineEnvironment.transform 15 33110 env12289 = env12290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env12289 == env12290) = true)

theorem identity12290 : scanCanonicalize (H12AffineFastState.compose env12290 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound12290 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,16401,56436,1025,32769,4161,33,17,3,8193,65,56577,5392,17665,23668,1365,62588,257,21792,46093,41820]

theorem envBound12291 : H12AffineFastState.Bounded env12291 := by
  intro p hp
  have h : env12291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12290_12291 : H12AffineEnvironment.transform 16 16401 env12290 = env12291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env12290 == env12291) = true)

theorem identity12291 : scanCanonicalize (H12AffineFastState.compose env12291 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12291 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,32041,1025,8540,4161,33,17,3,8193,65,31836,5392,17665,23668,1365,21793,257,21792,5456,513]

theorem envBound12292 : H12AffineFastState.Bounded env12292 := by
  intro p hp
  have h : env12292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12291_12292 : H12AffineEnvironment.transform 14 8541 env12291 = env12292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12291 == env12292) = true)

theorem identity12292 : scanCanonicalize (H12AffineFastState.compose env12292 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12292 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8541,8203,5441,10361,1025,8540,4161,33,17,3,8193,65,10508,5392,4177,2340,1365,113,257,112,5456,513]

theorem envBound12293 : H12AffineFastState.Bounded env12293 := by
  intro p hp
  have h : env12293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12292_12293 : H12AffineEnvironment.transform 13 5456 env12292 = env12293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12292 == env12293) = true)

theorem identity12293 : scanCanonicalize (H12AffineFastState.compose env12293 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12293 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12294 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,5237,8312,8203,5220,10361,1025,8313,4161,33,17,3,8193,65,10281,5173,4177,2049,1136,113,36,112,5237,513]

theorem envBound12294 : H12AffineFastState.Bounded env12294 := by
  intro p hp
  have h : env12294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12293_12294 : H12AffineEnvironment.transform 7 37 env12293 = env12294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12293 == env12294) = true)

theorem identity12294 : scanCanonicalize (H12AffineFastState.compose env12294 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12294 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12295 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,4096,8192,4160,8312,8203,4177,10361,52,8313,4161,33,17,3,8193,65,10281,4096,4177,2049,69,113,36,112,4160,513]

theorem envBound12295 : H12AffineFastState.Bounded env12295 := by
  intro p hp
  have h : env12295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12294_12295 : H12AffineEnvironment.transform 9 53 env12294 = env12295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12294 == env12295) = true)

theorem identity12295 : scanCanonicalize (H12AffineFastState.compose env12295 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound12295 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env12296 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,2113,8192,2049,8312,8203,2064,10361,52,8313,2048,33,17,3,8193,65,10281,2113,2064,2049,69,113,36,112,2049,513]

theorem envBound12296 : H12AffineFastState.Bounded env12296 := by
  intro p hp
  have h : env12296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12295_12296 : H12AffineEnvironment.transform 11 2113 env12295 = env12296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env12295 == env12296) = true)

theorem identity12296 : scanCanonicalize (H12AffineFastState.compose env12296 (packedSelected [0,2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound12296 : packedSelected [0,2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env12297 : List Nat := [2,4,8,16,32,64,9,37,512,53,32,97,8192,33,8312,8203,48,8281,52,8313,32,33,17,3,8193,65,8201,97,48,33,69,113,36,112,33,513]

theorem envBound12297 : H12AffineFastState.Bounded env12297 := by
  intro p hp
  have h : env12297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12296_12297 : H12AffineEnvironment.transform 10 32 env12296 = env12297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env12296 == env12297) = true)

theorem identity12297 : scanCanonicalize (H12AffineFastState.compose env12297 (packedSelected [3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12297 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env12298 : List Nat := [2,4,8,16,32,16,9,37,512,53,32,49,8192,33,8232,8203,48,8201,52,8233,32,33,17,3,8193,17,8201,49,48,33,21,33,36,32,33,513]

theorem envBound12298 : H12AffineFastState.Bounded env12298 := by
  intro p hp
  have h : env12298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12297_12298 : H12AffineEnvironment.transform 5 16 env12297 = env12298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12297 == env12298) = true)

theorem identity12298 : scanCanonicalize (H12AffineFastState.compose env12298 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 569) := by decide +kernel

theorem selectedBound12298 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12299 : List Nat := [2,4,8,16,32,16,9,37,512,53,32,49,569,33,529,562,48,560,52,528,32,33,17,3,568,17,560,49,48,33,21,33,36,32,33,513]

theorem envBound12299 : H12AffineFastState.Bounded env12299 := by
  intro p hp
  have h : env12299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12298_12299 : H12AffineEnvironment.transform 12 569 env12298 = env12299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 569 env12298 == env12299) = true)

theorem identity12299 : scanCanonicalize (H12AffineFastState.compose env12299 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound12299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12300 : List Nat := [2,4,8,16,32,16,9,37,48,53,32,49,9,33,33,2,48,0,52,32,32,33,17,3,8,17,0,49,48,33,21,33,36,32,33,49]

theorem envBound12300 : H12AffineFastState.Bounded env12300 := by
  intro p hp
  have h : env12300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12299_12300 : H12AffineEnvironment.transform 8 48 env12299 = env12300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env12299 == env12300) = true)

theorem identity12300 : scanCanonicalize (H12AffineFastState.compose env12300 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound12300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12301 : List Nat := [2,4,8,16,27,16,9,30,11,14,27,10,9,26,26,2,11,0,15,27,27,26,17,3,8,17,0,10,11,26,21,26,31,27,26,10]

theorem envBound12301 : H12AffineFastState.Bounded env12301 := by
  intro p hp
  have h : env12301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12300_12301 : H12AffineEnvironment.transform 4 27 env12300 = env12301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env12300 == env12301) = true)

def env12302 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,2097152,4194304,8388608,10588557,8328,65,6458873,8393984,10507601,8526965,2102684,12645453,257,21793,46213,2175562]

theorem envBound12302 : H12AffineFastState.Bounded env12302 := by
  intro p hp
  have h : env12302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12183_12302 : H12AffineEnvironment.transform 17 56437 env12183 = env12302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env12183 == env12302) = true)

def env12303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,4194304,8388608,8487373,8328,65,4365753,8393984,8406289,8526965,1500,12645453,257,21793,46213,74250]

theorem envBound12303 : H12AffineFastState.Bounded env12303 := by
  intro p hp
  have h : env12303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12302_12303 : H12AffineEnvironment.transform 20 4160 env12302 = env12303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12302 == env12303) = true)

def env12304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,32,8388608,8487373,8328,65,171417,8393984,8406289,8526965,1500,8451181,257,21793,46213,74250]

theorem envBound12304 : H12AffineFastState.Bounded env12304 := by
  intro p hp
  have h : env12304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12303_12304 : H12AffineEnvironment.transform 21 32 env12303 = env12304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12303 == env12304) = true)

theorem identity12304 : scanCanonicalize (H12AffineFastState.compose env12304 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12304 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4160,32,8388608,8430022,8328,65,171417,8393984,8406289,8526965,1500,8451181,257,21793,46213,513]

theorem envBound12305 : H12AffineFastState.Bounded env12305 := by
  intro p hp
  have h : env12305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12304_12305 : H12AffineEnvironment.transform 15 8203 env12304 = env12305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12304 == env12305) = true)

def env12306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1025,32769,4160,32,8388608,8430022,8328,65,56713,8393984,8406289,8412261,1500,8451181,257,21793,46213,513]

theorem envBound12306 : H12AffineFastState.Bounded env12306 := by
  intro p hp
  have h : env12306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12305_12306 : H12AffineEnvironment.transform 16 16400 env12305 = env12306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env12305 == env12306) = true)

theorem identity12306 : scanCanonicalize (H12AffineFastState.compose env12306 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(22+1) ^^^ 17) := by decide +kernel

theorem selectedBound12306 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1025,32769,4160,32,17,41431,8328,65,56713,5393,17664,23668,1500,62588,257,21793,46213,513]

theorem envBound12307 : H12AffineFastState.Bounded env12307 := by
  intro p hp
  have h : env12307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12306_12307 : H12AffineEnvironment.transform 22 17 env12306 = env12307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env12306 == env12307) = true)

theorem identity12307 : scanCanonicalize (H12AffineFastState.compose env12307 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12307 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12308 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,56437,1025,32769,4160,32,17,41311,8192,65,56577,5393,17664,23668,1364,62588,257,21793,46093,513]

theorem envBound12308 : H12AffineFastState.Bounded env12308 := by
  intro p hp
  have h : env12308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12307_12308 : H12AffineEnvironment.transform 6 8 env12307 = env12308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12307 == env12308) = true)

theorem identity12308 : scanCanonicalize (H12AffineFastState.compose env12308 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12308 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env12309 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,5392,35189,1025,32769,4160,32,17,41311,8192,65,34817,5393,4096,2420,1364,41340,257,33,46093,513]

theorem envBound12309 : H12AffineFastState.Bounded env12309 := by
  intro p hp
  have h : env12309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12308_12309 : H12AffineEnvironment.transform 13 5376 env12308 = env12309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12308 == env12309) = true)

theorem identity12309 : scanCanonicalize (H12AffineFastState.compose env12309 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12309 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12310 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,32768,343,5392,35189,1025,32769,4160,32,17,32771,348,65,34817,5393,4096,2420,1364,32800,257,33,38225,513]

theorem envBound12310 : H12AffineFastState.Bounded env12310 := by
  intro p hp
  have h : env12310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12309_12310 : H12AffineEnvironment.transform 12 348 env12309 = env12310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12309 == env12310) = true)

theorem identity12310 : scanCanonicalize (H12AffineFastState.compose env12310 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound12310 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12311 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,81,343,5392,2340,1025,80,4160,32,17,82,348,65,2128,5393,4096,2420,1364,113,257,33,5376,513]

theorem envBound12311 : H12AffineFastState.Bounded env12311 := by
  intro p hp
  have h : env12311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12310_12311 : H12AffineEnvironment.transform 14 81 env12310 = env12311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env12310 == env12311) = true)

theorem identity12311 : scanCanonicalize (H12AffineFastState.compose env12311 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12311 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12312 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1025,1,4113,32,17,3,269,16,2049,5393,4096,2341,1285,32,257,33,5376,513]

theorem envBound12312 : H12AffineFastState.Bounded env12312 := by
  intro p hp
  have h : env12312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12311_12312 : H12AffineEnvironment.transform 5 17 env12311 = env12312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12311 == env12312) = true)

theorem identity12312 : scanCanonicalize (H12AffineFastState.compose env12312 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 261) := by decide +kernel

theorem selectedBound12312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12313 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,261,269,1029,0,262,1045,2340,1025,1,276,32,17,3,269,16,2049,1044,261,2341,1285,32,257,33,1029,513]

theorem envBound12313 : H12AffineFastState.Bounded env12313 := by
  intro p hp
  have h : env12313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12312_12313 : H12AffineEnvironment.transform 11 261 env12312 = env12313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 261 env12312 == env12313) = true)

theorem identity12313 : scanCanonicalize (H12AffineFastState.compose env12313 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1307) := by decide +kernel

theorem selectedBound12313 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12314 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1307,261,269,1029,0,262,1045,1087,1025,1,276,32,17,3,269,16,1306,1044,261,1086,1285,32,257,33,1029,513]

theorem envBound12314 : H12AffineFastState.Bounded env12314 := by
  intro p hp
  have h : env12314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12313_12314 : H12AffineEnvironment.transform 10 1307 env12313 = env12314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1307 env12313 == env12314) = true)

theorem identity12314 : scanCanonicalize (H12AffineFastState.compose env12314 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 318) := by decide +kernel

theorem selectedBound12314 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12315 : List Nat := [2,4,8,16,32,17,8,256,318,1024,1307,261,269,1029,0,262,1045,1087,1025,1,276,32,17,3,269,16,1306,1044,261,1086,1285,32,257,33,1029,319]

theorem envBound12315 : H12AffineFastState.Bounded env12315 := by
  intro p hp
  have h : env12315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12314_12315 : H12AffineEnvironment.transform 8 318 env12314 = env12315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 318 env12314 == env12315) = true)

theorem identity12315 : scanCanonicalize (H12AffineFastState.compose env12315 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound12315 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12316 : List Nat := [2,4,8,16,32,17,8,256,318,14,277,261,269,11,0,262,27,49,15,1,276,32,17,3,269,16,276,26,261,48,267,32,257,33,11,319]

theorem envBound12316 : H12AffineFastState.Bounded env12316 := by
  intro p hp
  have h : env12316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12315_12316 : H12AffineEnvironment.transform 9 14 env12315 = env12316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env12315 == env12316) = true)

theorem identity12316 : scanCanonicalize (H12AffineFastState.compose env12316 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12316 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12317 : List Nat := [2,4,8,16,32,17,8,4,58,14,17,1,9,11,0,2,27,49,15,1,16,32,17,3,9,16,16,26,1,48,15,32,5,33,11,59]

theorem envBound12317 : H12AffineFastState.Bounded env12317 := by
  intro p hp
  have h : env12317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12316_12317 : H12AffineEnvironment.transform 7 4 env12316 = env12317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12316 == env12317) = true)

theorem identity12317 : scanCanonicalize (H12AffineFastState.compose env12317 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12317 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env12318 : List Nat := [2,4,8,16,0,17,8,4,26,14,17,1,9,11,0,2,27,17,15,1,16,0,17,3,9,16,16,26,1,16,15,0,5,1,11,27]

theorem envBound12318 : H12AffineFastState.Bounded env12318 := by
  intro p hp
  have h : env12318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12317_12318 : H12AffineEnvironment.transform 4 0 env12317 = env12318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12317 == env12318) = true)

theorem identity12318 : scanCanonicalize (H12AffineFastState.compose env12318 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound12318 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12319 : List Nat := [2,4,8,12,0,13,8,4,6,14,13,1,9,11,0,2,7,13,15,1,12,0,13,3,9,12,12,6,1,12,15,0,5,1,11,7]

theorem envBound12319 : H12AffineFastState.Bounded env12319 := by
  intro p hp
  have h : env12319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12318_12319 : H12AffineEnvironment.transform 3 12 env12318 = env12319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env12318 == env12319) = true)

def env12320 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56437,1025,32769,4160,32,8388608,8430022,8328,65,56712,8393984,8406289,8412260,1500,8451181,257,21793,46213,513]

theorem envBound12320 : H12AffineFastState.Bounded env12320 := by
  intro p hp
  have h : env12320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12305_12320 : H12AffineEnvironment.transform 16 16401 env12305 = env12320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env12305 == env12320) = true)

def env12321 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56437,1025,32769,4160,32,20480,61894,8328,65,56712,17664,5393,3172,1500,42093,257,21793,46213,513]

theorem envBound12321 : H12AffineFastState.Bounded env12321 := by
  intro p hp
  have h : env12321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12320_12321 : H12AffineEnvironment.transform 22 20480 env12320 = env12321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20480 env12320 == env12321) = true)

theorem identity12321 : scanCanonicalize (H12AffineFastState.compose env12321 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9245) := by decide +kernel

theorem selectedBound12321 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env12322 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9245,8203,16401,30824,1025,9244,4160,32,20480,21979,8328,65,31125,17664,5393,3172,1500,112,257,21793,4248,513]

theorem envBound12322 : H12AffineFastState.Bounded env12322 := by
  intro p hp
  have h : env12322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12321_12322 : H12AffineEnvironment.transform 14 9245 env12321 = env12322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9245 env12321 == env12322) = true)

theorem identity12322 : scanCanonicalize (H12AffineFastState.compose env12322 (packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12322 : packedSelected [0,1,3,7,12,15,20,24,28,38,41] rootPS < 2^1333 := by decide +kernel

def env12323 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,9245,8203,5441,11576,1025,9244,4160,32,1360,139,8328,65,11461,4176,5393,3172,1500,112,257,113,4248,513]

theorem envBound12323 : H12AffineFastState.Bounded env12323 := by
  intro p hp
  have h : env12323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12322_12323 : H12AffineEnvironment.transform 13 5456 env12322 = env12323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12322 == env12323) = true)

theorem identity12323 : scanCanonicalize (H12AffineFastState.compose env12323 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound12323 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12324 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,8192,4297,8580,8203,4312,10401,408,8581,4160,32,201,139,8328,65,10588,4176,4232,2557,69,112,257,113,4248,513]

theorem envBound12324 : H12AffineFastState.Bounded env12324 := by
  intro p hp
  have h : env12324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12323_12324 : H12AffineEnvironment.transform 9 409 env12323 = env12324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env12323 == env12324) = true)

theorem identity12324 : scanCanonicalize (H12AffineFastState.compose env12324 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12324 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12325 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,269,4297,137,262,4312,2476,408,136,4160,32,201,139,389,65,2129,4176,4232,2557,69,112,257,113,4248,513]

theorem envBound12325 : H12AffineFastState.Bounded env12325 := by
  intro p hp
  have h : env12325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12324_12325 : H12AffineEnvironment.transform 12 269 env12324 = env12325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12324 == env12325) = true)

theorem identity12325 : scanCanonicalize (H12AffineFastState.compose env12325 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound12325 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env12326 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,649,269,576,137,262,593,2476,408,136,713,32,201,139,389,65,2129,729,513,2557,69,112,257,113,529,513]

theorem envBound12326 : H12AffineFastState.Bounded env12326 := by
  intro p hp
  have h : env12326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12325_12326 : H12AffineEnvironment.transform 11 649 env12325 = env12326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env12325 == env12326) = true)

def env12327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,56437,1025,32769,4160,32,20481,61895,8328,65,56712,17665,5392,3173,1500,42092,257,21793,46213,513]

theorem envBound12327 : H12AffineFastState.Bounded env12327 := by
  intro p hp
  have h : env12327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12320_12327 : H12AffineEnvironment.transform 22 20481 env12320 = env12327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 20481 env12320 == env12327) = true)

theorem identity12327 : scanCanonicalize (H12AffineFastState.compose env12327 (packedSelected [0,14,27] rootPS)) = affineNative (2^(14+1) ^^^ 9364) := by decide +kernel

theorem selectedBound12327 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env12328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9364,8203,16401,30945,1025,9365,4160,32,20481,21843,8328,65,31004,17665,5392,3173,1500,248,257,21793,4113,513]

theorem envBound12328 : H12AffineFastState.Bounded env12328 := by
  intro p hp
  have h : env12328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12327_12328 : H12AffineEnvironment.transform 14 9364 env12327 = env12328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9364 env12327 == env12328) = true)

theorem identity12328 : scanCanonicalize (H12AffineFastState.compose env12328 (packedSelected [0,1,3,7,20,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12328 : packedSelected [0,1,3,7,20,24,28] rootPS < 2^1333 := by decide +kernel

def env12329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,9364,8203,5441,11697,1025,9365,4160,32,1361,3,8328,65,11340,4177,5392,3173,1500,248,257,113,4113,513]

theorem envBound12329 : H12AffineFastState.Bounded env12329 := by
  intro p hp
  have h : env12329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12328_12329 : H12AffineEnvironment.transform 13 5456 env12328 = env12329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12328 == env12329) = true)

theorem identity12329 : scanCanonicalize (H12AffineFastState.compose env12329 (packedSelected [0,7,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound12329 : packedSelected [0,7,17,20] rootPS < 2^1333 := by decide +kernel

def env12330 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,8192,4296,8460,8203,4313,10281,409,8461,4160,32,201,3,8328,65,10708,4177,4232,2557,68,248,257,113,4113,513]

theorem envBound12330 : H12AffineFastState.Bounded env12330 := by
  intro p hp
  have h : env12330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12329_12330 : H12AffineEnvironment.transform 9 408 env12329 = env12330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env12329 == env12330) = true)

theorem identity12330 : scanCanonicalize (H12AffineFastState.compose env12330 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound12330 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12331 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,389,4296,137,398,4313,2476,409,136,4160,32,201,3,269,65,2129,4177,4232,2557,68,248,257,113,4113,513]

theorem envBound12331 : H12AffineFastState.Bounded env12331 := by
  intro p hp
  have h : env12331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12330_12331 : H12AffineEnvironment.transform 12 389 env12330 = env12331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env12330 == env12331) = true)

def env12332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,8388608,8487373,8328,65,171416,8393984,8406289,8526965,1500,8451180,257,21793,46213,74250]

theorem envBound12332 : H12AffineFastState.Bounded env12332 := by
  intro p hp
  have h : env12332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12303_12332 : H12AffineEnvironment.transform 21 33 env12303 = env12332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12303 == env12332) = true)

theorem identity12332 : scanCanonicalize (H12AffineFastState.compose env12332 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound12332 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,73754,41431,8328,65,171416,79130,91403,212079,1500,119926,257,21793,46213,74250]

theorem envBound12333 : H12AffineFastState.Bounded env12333 := by
  intro p hp
  have h : env12333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12332_12333 : H12AffineEnvironment.transform 22 73754 env12332 = env12333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env12332 == env12333) = true)

def env12334 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,73754,41123,8328,65,171244,78958,91263,212079,1192,119926,117,21589,46213,74250]

theorem envBound12334 : H12AffineFastState.Bounded env12334 := by
  intro p hp
  have h : env12334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12333_12334 : H12AffineEnvironment.transform 7 116 env12333 = env12334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12333 == env12334) = true)

theorem identity12334 : scanCanonicalize (H12AffineFastState.compose env12334 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12334 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12335 : List Nat := [2,4,8,16,32,64,128,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4160,33,17,41123,8328,65,171244,5221,17524,138340,1192,62589,117,21589,46213,513]

theorem envBound12335 : H12AffineFastState.Bounded env12335 := by
  intro p hp
  have h : env12335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12334_12335 : H12AffineEnvironment.transform 15 8203 env12334 = env12335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12334 == env12335) = true)

theorem identity12335 : scanCanonicalize (H12AffineFastState.compose env12335 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12335 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12336 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,32768,8203,131072,56437,1025,32769,4160,33,17,41082,8273,65,171061,5221,17524,138340,1137,62589,117,21589,46172,513]

theorem envBound12336 : H12AffineFastState.Bounded env12336 := by
  intro p hp
  have h : env12336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12335_12336 : H12AffineEnvironment.transform 6 89 env12335 = env12336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12335 == env12336) = true)

theorem identity12336 : scanCanonicalize (H12AffineFastState.compose env12336 (packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound12336 : packedSelected [1,2,3,4,6,8,9,10,12,14,15,20,24] rootPS < 2^1333 := by decide +kernel

def env12337 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,8192,16384,32768,8203,49168,56437,1025,32769,4160,33,17,41082,8273,65,23589,5221,17524,56436,1137,62589,117,21589,46172,513]

theorem envBound12337 : H12AffineFastState.Bounded env12337 := by
  intro p hp
  have h : env12337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12336_12337 : H12AffineEnvironment.transform 16 49168 env12336 = env12337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env12336 == env12337) = true)

theorem identity12337 : scanCanonicalize (H12AffineFastState.compose env12337 (packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12337 : packedSelected [0,1,2,3,5,6,7,8,10,11,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env12338 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,32768,8203,49168,56357,1025,32769,4112,33,17,41002,8193,17,23589,5173,17444,56356,1057,62509,37,21509,46092,513]

theorem envBound12338 : H12AffineFastState.Bounded env12338 := by
  intro p hp
  have h : env12338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12337_12338 : H12AffineEnvironment.transform 5 16 env12337 = env12338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12337 == env12338) = true)

theorem identity12338 : scanCanonicalize (H12AffineFastState.compose env12338 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 28729) := by decide +kernel

theorem selectedBound12338 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12339 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,28729,8203,12329,11292,1025,28728,4112,33,17,20499,8193,17,23589,5173,17444,11293,1057,1044,37,21509,17461,513]

theorem envBound12339 : H12AffineFastState.Bounded env12339 := by
  intro p hp
  have h : env12339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12338_12339 : H12AffineEnvironment.transform 14 28729 env12338 = env12339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28729 env12338 == env12339) = true)

theorem identity12339 : scanCanonicalize (H12AffineFastState.compose env12339 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound12339 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12340 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,4112,8233,8203,12329,11292,1025,8232,4112,33,17,3,8193,17,3125,5173,5172,11293,1057,1044,37,1045,5157,513]

theorem envBound12340 : H12AffineFastState.Bounded env12340 := by
  intro p hp
  have h : env12340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12339_12340 : H12AffineEnvironment.transform 13 4112 env12339 = env12340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env12339 == env12340) = true)

theorem identity12340 : scanCanonicalize (H12AffineFastState.compose env12340 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound12340 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12341 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,4112,8233,8203,12329,10281,52,8232,4112,33,17,3,8193,17,2048,4096,4097,10280,20,33,37,32,4112,513]

theorem envBound12341 : H12AffineFastState.Bounded env12341 := by
  intro p hp
  have h : env12341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12340_12341 : H12AffineEnvironment.transform 9 53 env12340 = env12341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env12340 == env12341) = true)

theorem identity12341 : scanCanonicalize (H12AffineFastState.compose env12341 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound12341 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12342 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,40,4112,1,35,4097,2049,52,0,4112,33,17,3,41,17,2048,4096,4097,2048,20,33,37,32,4112,513]

theorem envBound12342 : H12AffineFastState.Bounded env12342 := by
  intro p hp
  have h : env12342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12341_12342 : H12AffineEnvironment.transform 12 40 env12341 = env12342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env12341 == env12342) = true)

theorem identity12342 : scanCanonicalize (H12AffineFastState.compose env12342 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12342 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12343 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,4096,40,4112,1,35,4097,1,52,0,4112,33,17,3,41,17,0,4096,4097,0,20,33,37,32,4112,513]

theorem envBound12343 : H12AffineFastState.Bounded env12343 := by
  intro p hp
  have h : env12343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12342_12343 : H12AffineEnvironment.transform 10 0 env12342 = env12343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12342 == env12343) = true)

theorem identity12343 : scanCanonicalize (H12AffineFastState.compose env12343 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound12343 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12344 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,570,40,554,1,35,571,1,52,0,554,33,17,3,41,17,0,570,571,0,20,33,37,32,554,513]

theorem envBound12344 : H12AffineFastState.Bounded env12344 := by
  intro p hp
  have h : env12344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12343_12344 : H12AffineEnvironment.transform 11 570 env12343 = env12344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env12343 == env12344) = true)

theorem identity12344 : scanCanonicalize (H12AffineFastState.compose env12344 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12344 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12345 : List Nat := [2,4,8,16,1,16,9,5,512,20,0,539,9,523,1,2,538,1,21,0,523,0,17,3,8,17,0,539,538,0,20,0,4,1,523,513]

theorem envBound12345 : H12AffineFastState.Bounded env12345 := by
  intro p hp
  have h : env12345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12344_12345 : H12AffineEnvironment.transform 4 1 env12344 = env12345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12344 == env12345) = true)

theorem identity12345 : scanCanonicalize (H12AffineFastState.compose env12345 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound12345 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12346 : List Nat := [2,4,8,16,1,16,9,5,11,20,0,16,9,0,1,2,17,1,21,0,0,0,17,3,8,17,0,16,17,0,20,0,4,1,0,10]

theorem envBound12346 : H12AffineFastState.Bounded env12346 := by
  intro p hp
  have h : env12346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12345_12346 : H12AffineEnvironment.transform 8 11 env12345 = env12346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env12345 == env12346) = true)

theorem identity12346 : scanCanonicalize (H12AffineFastState.compose env12346 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12346 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12347 : List Nat := [2,4,2,16,1,16,3,5,1,20,0,16,3,0,1,2,17,1,21,0,0,0,17,3,2,17,0,16,17,0,20,0,4,1,0,0]

theorem envBound12347 : H12AffineFastState.Bounded env12347 := by
  intro p hp
  have h : env12347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12346_12347 : H12AffineEnvironment.transform 2 2 env12346 = env12347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12346 == env12347) = true)

theorem identity12347 : scanCanonicalize (H12AffineFastState.compose env12347 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12347 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12348 : List Nat := [2,4,2,0,1,0,3,5,1,4,0,0,3,0,1,2,1,1,5,0,0,0,1,3,2,1,0,0,1,0,4,0,4,1,0,0]

theorem envBound12348 : H12AffineFastState.Bounded env12348 := by
  intro p hp
  have h : env12348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12347_12348 : H12AffineEnvironment.transform 3 0 env12347 = env12348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12347 == env12348) = true)

def env12349 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4160,33,73754,41122,8328,65,171245,78959,91262,212079,1193,119926,116,21588,46213,74250]

theorem envBound12349 : H12AffineFastState.Bounded env12349 := by
  intro p hp
  have h : env12349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12333_12349 : H12AffineEnvironment.transform 7 117 env12333 = env12349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12333 == env12349) = true)

def env12350 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,131072,56325,1025,32769,4144,33,73754,41122,8328,49,171165,78879,91150,211999,1193,119814,4,21540,46213,74250]

theorem envBound12350 : H12AffineFastState.Bounded env12350 := by
  intro p hp
  have h : env12350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12349_12350 : H12AffineEnvironment.transform 5 48 env12349 = env12350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env12349 == env12350) = true)

theorem identity12350 : scanCanonicalize (H12AffineFastState.compose env12350 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 38044) := by decide +kernel

theorem selectedBound12350 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env12351 : List Nat := [2,4,8,16,32,48,128,5,512,1024,2048,4096,8192,16384,32768,65536,38044,56325,1025,32769,4144,33,73754,41122,8328,49,2049,78879,91150,108675,1193,119814,4,21540,46213,74250]

theorem envBound12351 : H12AffineFastState.Bounded env12351 := by
  intro p hp
  have h : env12351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12350_12351 : H12AffineEnvironment.transform 16 38044 env12350 = env12351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38044 env12350 == env12351) = true)

theorem identity12351 : scanCanonicalize (H12AffineFastState.compose env12351 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12351 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12352 : List Nat := [2,4,8,16,32,48,9,5,512,1024,2048,4096,8192,16384,32768,65536,37909,56325,1025,32769,4144,33,73754,41003,8193,49,2049,78879,91150,108554,1056,119814,4,21540,46092,74250]

theorem envBound12352 : H12AffineFastState.Bounded env12352 := by
  intro p hp
  have h : env12352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12351_12352 : H12AffineEnvironment.transform 6 9 env12351 = env12352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12351 == env12352) = true)

def env12353 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,131072,56324,1025,32769,4145,33,73754,41122,8328,48,171164,78878,91151,211998,1193,119815,5,21541,46213,74250]

theorem envBound12353 : H12AffineFastState.Bounded env12353 := by
  intro p hp
  have h : env12353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12349_12353 : H12AffineEnvironment.transform 5 49 env12349 = env12353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env12349 == env12353) = true)

theorem identity12353 : scanCanonicalize (H12AffineFastState.compose env12353 (packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound12353 : packedSelected [3,5,6,7,8,12,14,17,18,19,20,26,27,28,32,35,41] rootPS < 2^1333 := by decide +kernel

def env12354 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,16384,32768,65536,24632,56324,1025,32769,4145,33,73754,41122,8328,48,64676,78878,91151,89126,1193,119815,5,21541,46213,74250]

theorem envBound12354 : H12AffineFastState.Bounded env12354 := by
  intro p hp
  have h : env12354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12353_12354 : H12AffineEnvironment.transform 16 24632 env12353 = env12354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env12353 == env12354) = true)

theorem identity12354 : scanCanonicalize (H12AffineFastState.compose env12354 (packedSelected [0,2,5,7,8,9,10,11,18,20,22,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound12354 : packedSelected [0,2,5,7,8,9,10,11,18,20,22,24,26,28] rootPS < 2^1333 := by decide +kernel

def env12355 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,13444,32768,65536,5308,43136,1025,32769,4145,33,73754,41122,8328,48,34848,78878,69771,75938,1193,106627,5,8353,46213,74250]

theorem envBound12355 : H12AffineFastState.Bounded env12355 := by
  intro p hp
  have h : env12355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12354_12355 : H12AffineEnvironment.transform 13 13444 env12354 = env12355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env12354 == env12355) = true)

theorem identity12355 : scanCanonicalize (H12AffineFastState.compose env12355 (packedSelected [1,2,4,5,6,8,11,17,19,20,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 41123) := by decide +kernel

theorem selectedBound12355 : packedSelected [1,2,4,5,6,8,11,17,19,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12356 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,13444,32768,41123,5308,43136,1025,32769,4145,33,32953,41122,8328,48,34848,38077,45096,34817,1193,32,5,8353,46213,33449]

theorem envBound12356 : H12AffineFastState.Bounded env12356 := by
  intro p hp
  have h : env12356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12355_12356 : H12AffineEnvironment.transform 15 41123 env12355 = env12356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41123 env12355 == env12356) = true)

theorem identity12356 : scanCanonicalize (H12AffineFastState.compose env12356 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound12356 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env12357 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8192,13444,8232,139,5308,2216,1025,8233,4145,33,8337,138,8328,48,10248,13461,4096,10281,1193,32,5,8353,5293,8833]

theorem envBound12357 : H12AffineFastState.Bounded env12357 := by
  intro p hp
  have h : env12357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12356_12357 : H12AffineEnvironment.transform 14 8232 env12356 = env12357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env12356 == env12357) = true)

theorem identity12357 : scanCanonicalize (H12AffineFastState.compose env12357 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound12357 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env12358 : List Nat := [2,4,8,16,32,49,128,4,512,1024,2048,4096,8,5260,32,139,5308,2216,1025,33,4145,33,153,138,128,48,2048,5277,4096,2081,1193,32,5,169,5293,649]

theorem envBound12358 : H12AffineFastState.Bounded env12358 := by
  intro p hp
  have h : env12358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12357_12358 : H12AffineEnvironment.transform 12 8 env12357 = env12358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env12357 == env12358) = true)

theorem identity12358 : scanCanonicalize (H12AffineFastState.compose env12358 (packedSelected [0,2,7,11,12] rootPS)) = affineNative (2^(10+1) ^^^ 1212) := by decide +kernel

theorem selectedBound12358 : packedSelected [0,2,7,11,12] rootPS < 2^1333 := by decide +kernel

def env12359 : List Nat := [2,4,8,16,32,49,128,4,512,1024,1212,4096,8,5260,32,139,5308,1044,1025,33,4145,33,153,138,128,48,1212,5277,4096,1181,1193,32,5,169,5293,649]

theorem envBound12359 : H12AffineFastState.Bounded env12359 := by
  intro p hp
  have h : env12359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12358_12359 : H12AffineEnvironment.transform 10 1212 env12358 = env12359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1212 env12358 == env12359) = true)

def env12360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,4194304,8388608,8487372,8328,65,4365752,8393984,8406288,8526965,1501,12645453,257,21793,46213,74251]

theorem envBound12360 : H12AffineFastState.Bounded env12360 := by
  intro p hp
  have h : env12360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12302_12360 : H12AffineEnvironment.transform 20 4161 env12302 = env12360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12302 == env12360) = true)

def env12361 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,32,8388608,8487372,8328,65,171416,8393984,8406288,8526965,1501,8451181,257,21793,46213,74251]

theorem envBound12361 : H12AffineFastState.Bounded env12361 := by
  intro p hp
  have h : env12361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12360_12361 : H12AffineEnvironment.transform 21 32 env12360 = env12361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12360 == env12361) = true)

theorem identity12361 : scanCanonicalize (H12AffineFastState.compose env12361 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound12361 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12362 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,56437,1025,32769,4161,32,8388608,8410386,8328,65,171416,8393984,8406288,8526965,1501,8451181,257,21793,46213,63189]

theorem envBound12362 : H12AffineFastState.Bounded env12362 := by
  intro p hp
  have h : env12362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12361_12362 : H12AffineEnvironment.transform 15 54494 env12361 = env12362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env12361 == env12362) = true)

def env12363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,56437,1025,32769,4161,32,8388608,8410386,8192,65,171280,8393984,8406288,8526965,1365,8451181,257,21793,46093,63069]

theorem envBound12363 : H12AffineFastState.Bounded env12363 := by
  intro p hp
  have h : env12363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12362_12363 : H12AffineEnvironment.transform 6 8 env12362 = env12363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12362 == env12363) = true)

theorem identity12363 : scanCanonicalize (H12AffineFastState.compose env12363 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound12363 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,10281,1025,29789,4161,32,8388608,8410386,8192,65,158028,8393984,8406288,8526965,1365,8388657,257,21793,16465,513]

theorem envBound12364 : H12AffineFastState.Bounded env12364 := by
  intro p hp
  have h : env12364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12363_12364 : H12AffineEnvironment.transform 14 29788 env12363 = env12364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env12363 == env12364) = true)

theorem identity12364 : scanCanonicalize (H12AffineFastState.compose env12364 (packedSelected [1,8,10,11,14,15,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound12364 : packedSelected [1,8,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env12365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16400,10281,1025,29789,4161,32,8388608,8410386,8192,65,10588,8393984,8406288,8412261,1365,8388657,257,21793,16465,513]

theorem envBound12365 : H12AffineFastState.Bounded env12365 := by
  intro p hp
  have h : env12365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12364_12365 : H12AffineEnvironment.transform 16 16400 env12364 = env12365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env12364 == env12365) = true)

theorem identity12365 : scanCanonicalize (H12AffineFastState.compose env12365 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(22+1) ^^^ 21777) := by decide +kernel

theorem selectedBound12365 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env12366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,16400,10281,1025,29789,4161,32,21777,3,8192,65,10588,16401,4097,2420,1365,21792,257,21793,16465,513]

theorem envBound12366 : H12AffineFastState.Bounded env12366 := by
  intro p hp
  have h : env12366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12365_12366 : H12AffineEnvironment.transform 22 21777 env12365 = env12366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 21777 env12365 == env12366) = true)

theorem identity12366 : scanCanonicalize (H12AffineFastState.compose env12366 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12366 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12367 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,8202,5392,10281,1025,8541,4161,32,17,3,8192,65,10588,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound12367 : H12AffineFastState.Bounded env12367 := by
  intro p hp
  have h : env12367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12366_12367 : H12AffineEnvironment.transform 13 5376 env12366 = env12367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12366 == env12367) = true)

theorem identity12367 : scanCanonicalize (H12AffineFastState.compose env12367 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12367 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12368 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,1,343,5392,2420,1025,0,4161,32,17,3,349,65,2049,5393,4097,2420,1365,32,257,33,5457,513]

theorem envBound12368 : H12AffineFastState.Bounded env12368 := by
  intro p hp
  have h : env12368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12367_12368 : H12AffineEnvironment.transform 12 349 env12367 = env12368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12367 == env12368) = true)

theorem identity12368 : scanCanonicalize (H12AffineFastState.compose env12368 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1572) := by decide +kernel

theorem selectedBound12368 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12369 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1572,349,804,1,343,820,2420,1025,0,1637,32,17,3,349,65,2049,821,1573,2420,1365,32,257,33,885,513]

theorem envBound12369 : H12AffineFastState.Bounded env12369 := by
  intro p hp
  have h : env12369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12368_12369 : H12AffineEnvironment.transform 11 1572 env12368 = env12369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1572 env12368 == env12369) = true)

theorem identity12369 : scanCanonicalize (H12AffineFastState.compose env12369 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound12369 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12370 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1573,1572,349,804,1,343,820,1873,1025,0,1637,32,17,3,349,65,1572,821,1573,1873,1365,32,257,33,885,513]

theorem envBound12370 : H12AffineFastState.Bounded env12370 := by
  intro p hp
  have h : env12370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12369_12370 : H12AffineEnvironment.transform 10 1573 env12369 = env12370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env12369 == env12370) = true)

theorem identity12370 : scanCanonicalize (H12AffineFastState.compose env12370 (packedSelected [5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12370 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env12371 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1573,1572,269,804,1,263,820,1793,1025,0,1589,32,17,3,269,17,1572,821,1573,1793,1285,32,257,33,805,513]

theorem envBound12371 : H12AffineFastState.Bounded env12371 := by
  intro p hp
  have h : env12371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12370_12371 : H12AffineEnvironment.transform 5 16 env12370 = env12371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12370 == env12371) = true)

theorem identity12371 : scanCanonicalize (H12AffineFastState.compose env12371 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound12371 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12372 : List Nat := [2,4,8,16,32,16,8,52,512,1024,1573,1572,57,528,1,51,512,1589,1025,0,1589,32,17,3,57,17,1572,513,1573,1589,1073,32,53,33,529,513]

theorem envBound12372 : H12AffineFastState.Bounded env12372 := by
  intro p hp
  have h : env12372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12371_12372 : H12AffineEnvironment.transform 7 52 env12371 = env12372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env12371 == env12372) = true)

theorem identity12372 : scanCanonicalize (H12AffineFastState.compose env12372 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound12372 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12373 : List Nat := [2,4,8,16,32,16,8,52,512,565,16,17,57,528,1,51,512,0,564,0,0,32,17,3,57,17,17,513,16,0,516,32,53,33,529,513]

theorem envBound12373 : H12AffineFastState.Bounded env12373 := by
  intro p hp
  have h : env12373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12372_12373 : H12AffineEnvironment.transform 9 565 env12372 = env12373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env12372 == env12373) = true)

def env12374 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,56437,1025,32769,4161,32,8388608,8410386,8193,65,171281,8393984,8406288,8526965,1364,8451181,257,21793,46092,63068]

theorem envBound12374 : H12AffineFastState.Bounded env12374 := by
  intro p hp
  have h : env12374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12362_12374 : H12AffineEnvironment.transform 6 9 env12362 = env12374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12362 == env12374) = true)

theorem identity12374 : scanCanonicalize (H12AffineFastState.compose env12374 (packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound12374 : packedSelected [0,1,2,5,6,8,11,14,18,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env12375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,29822,131072,31836,1025,8232,4161,32,8388608,8410386,8193,65,146744,8393984,8406288,8526965,1364,8410180,257,21793,5157,22133]

theorem envBound12375 : H12AffineFastState.Bounded env12375 := by
  intro p hp
  have h : env12375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12374_12375 : H12AffineEnvironment.transform 14 8233 env12374 = env12375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env12374 == env12375) = true)

theorem identity12375 : scanCanonicalize (H12AffineFastState.compose env12375 (packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound12375 : packedSelected [1,3,4,5,8,9,10,14,16,17,19] rootPS < 2^1333 := by decide +kernel

def env12376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8233,29822,5392,31836,1025,8232,4161,32,8388608,8410386,8193,65,10280,8393984,8406288,8391013,1364,8410180,257,21793,5157,22133]

theorem envBound12376 : H12AffineFastState.Bounded env12376 := by
  intro p hp
  have h : env12376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12375_12376 : H12AffineEnvironment.transform 16 5392 env12375 = env12376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env12375 == env12376) = true)

theorem identity12376 : scanCanonicalize (H12AffineFastState.compose env12376 (packedSelected [2,4,9,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound12376 : packedSelected [2,4,9,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env12377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8233,8203,5392,10281,1025,8232,4161,32,8388608,8388967,8193,65,10280,8393984,8393061,8391013,1364,8388657,257,340,5157,512]

theorem envBound12377 : H12AffineFastState.Bounded env12377 := by
  intro p hp
  have h : env12377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12376_12377 : H12AffineEnvironment.transform 13 5237 env12376 = env12377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env12376 == env12377) = true)

theorem identity12377 : scanCanonicalize (H12AffineFastState.compose env12377 (packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound12377 : packedSelected [0,1,2,3,4,5,6,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env12378 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5237,293,263,5392,2341,1025,292,4161,32,8388608,8388967,269,65,2340,8393984,8393061,8391013,1364,8388657,257,340,5157,512]

theorem envBound12378 : H12AffineFastState.Bounded env12378 := by
  intro p hp
  have h : env12378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12377_12378 : H12AffineEnvironment.transform 12 268 env12377 = env12378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env12377 == env12378) = true)

theorem identity12378 : scanCanonicalize (H12AffineFastState.compose env12378 (packedSelected [0,3,5,6,7,10,11] rootPS)) = affineNative (2^(22+1) ^^^ 277) := by decide +kernel

theorem selectedBound12378 : packedSelected [0,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env12379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5237,293,263,5392,2341,1025,292,4161,32,277,114,269,65,2340,5141,4208,2160,1364,292,257,340,5157,512]

theorem envBound12379 : H12AffineFastState.Bounded env12379 := by
  intro p hp
  have h : env12379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12378_12379 : H12AffineEnvironment.transform 22 277 env12378 = env12379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 277 env12378 == env12379) = true)

theorem identity12379 : scanCanonicalize (H12AffineFastState.compose env12379 (packedSelected [0,1,4,6,7,8,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound12379 : packedSelected [0,1,4,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env12380 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,268,5124,293,263,5392,2341,1025,292,4144,32,277,3,269,48,2340,5141,4097,2049,1317,292,257,293,5157,512]

theorem envBound12380 : H12AffineFastState.Bounded env12380 := by
  intro p hp
  have h : env12380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12379_12380 : H12AffineEnvironment.transform 5 49 env12379 = env12380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env12379 == env12380) = true)

theorem identity12380 : scanCanonicalize (H12AffineFastState.compose env12380 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12380 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env12381 : List Nat := [2,4,8,16,32,49,9,4,512,1024,2048,4096,8,5124,33,3,5140,2081,1025,32,4144,32,17,3,9,48,2080,5141,4097,2049,1057,32,5,33,5157,512]

theorem envBound12381 : H12AffineFastState.Bounded env12381 := by
  intro p hp
  have h : env12381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12380_12381 : H12AffineEnvironment.transform 7 4 env12380 = env12381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12380 == env12381) = true)

theorem identity12381 : scanCanonicalize (H12AffineFastState.compose env12381 (packedSelected [20] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12381 : packedSelected [20] rootPS < 2^1333 := by decide +kernel

def env12382 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,0,3,5140,2048,1025,1,4113,1,17,3,9,17,2049,5141,4097,2049,1024,1,5,0,5124,512]

theorem envBound12382 : H12AffineFastState.Bounded env12382 := by
  intro p hp
  have h : env12382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12381_12382 : H12AffineEnvironment.transform 4 1 env12381 = env12382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12381 == env12382) = true)

def env12383 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,16,8,1044,0,3,1028,2048,1025,1,1,1,17,3,9,17,2049,1029,17,2049,1024,1,5,0,1044,512]

theorem envBound12383 : H12AffineFastState.Bounded env12383 := by
  intro p hp
  have h : env12383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12382_12383 : H12AffineEnvironment.transform 11 16 env12382 = env12383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12382 == env12383) = true)

theorem identity12383 : scanCanonicalize (H12AffineFastState.compose env12383 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound12383 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12384 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,16,8,0,0,3,16,2048,21,1,1,1,17,3,9,17,2049,17,17,2049,20,1,5,0,0,512]

theorem envBound12384 : H12AffineFastState.Bounded env12384 := by
  intro p hp
  have h : env12384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12383_12384 : H12AffineEnvironment.transform 9 20 env12383 = env12384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12383 == env12384) = true)

theorem identity12384 : scanCanonicalize (H12AffineFastState.compose env12384 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 20) := by decide +kernel

theorem selectedBound12384 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12385 : List Nat := [2,4,8,16,1,16,9,4,512,20,20,16,8,0,0,3,16,20,21,1,1,1,17,3,9,17,21,17,17,21,20,1,5,0,0,512]

theorem envBound12385 : H12AffineFastState.Bounded env12385 := by
  intro p hp
  have h : env12385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12384_12385 : H12AffineEnvironment.transform 10 20 env12384 = env12385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 20 env12384 == env12385) = true)

def leafEnv12385 : List Nat := [2,4,8,16,1,16,9,4,512,20,20,16,8,0,0,3,16,20,21,1,1,1,17,3,21,9,1,17,21,17,17,21,20,1,5,0,5,2,0,512,1,1,0]

def active12385 : List Nat := [0,1,2,3,8]

def tree12385 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12385 : H12WitnessSearch.Good tree12385 := H12GlobalWitnessIndex.good

theorem leafIdentity12385 : H12AffineFastState.composeSystem env12385 rootObs = leafEnv12385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12385 rootObs == leafEnv12385) = true)

theorem terminalChecked12385 : H12PackedTerminal.terminalCheckFast leafEnv12385 active12385 tree12385 = true := by decide +kernel

def env12386 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,17,8,1045,0,3,1029,2048,1025,1,0,1,17,3,9,17,2049,1028,16,2049,1024,1,5,0,1045,512]

theorem envBound12386 : H12AffineFastState.Bounded env12386 := by
  intro p hp
  have h : env12386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12382_12386 : H12AffineEnvironment.transform 11 17 env12382 = env12386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12382 == env12386) = true)

def env12387 : List Nat := [2,4,8,16,1,16,9,4,512,20,2048,17,8,1,0,3,17,2048,21,1,0,1,17,3,9,17,2049,16,16,2049,20,1,5,0,1,512]

theorem envBound12387 : H12AffineFastState.Bounded env12387 := by
  intro p hp
  have h : env12387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12386_12387 : H12AffineEnvironment.transform 9 20 env12386 = env12387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12386 == env12387) = true)

theorem identity12387 : scanCanonicalize (H12AffineFastState.compose env12387 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound12387 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12388 : List Nat := [2,4,8,16,1,16,9,4,512,20,21,17,8,1,0,3,17,21,21,1,0,1,17,3,9,17,20,16,16,20,20,1,5,0,1,512]

theorem envBound12388 : H12AffineFastState.Bounded env12388 := by
  intro p hp
  have h : env12388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12387_12388 : H12AffineEnvironment.transform 10 21 env12387 = env12388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env12387 == env12388) = true)

def leafEnv12388 : List Nat := [2,4,8,16,1,16,9,4,512,20,21,17,8,1,0,3,17,21,21,1,0,1,17,3,21,9,1,17,20,16,16,20,20,1,5,0,5,2,1,512,1,0,0]

def active12388 : List Nat := [0,1,2,3,8]

def tree12388 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12388 : H12WitnessSearch.Good tree12388 := H12GlobalWitnessIndex.good

theorem leafIdentity12388 : H12AffineFastState.composeSystem env12388 rootObs = leafEnv12388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12388 rootObs == leafEnv12388) = true)

theorem terminalChecked12388 : H12PackedTerminal.terminalCheckFast leafEnv12388 active12388 tree12388 = true := by decide +kernel

def env12389 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,0,0,3,16,2048,20,1,0,1,17,3,9,17,2049,17,16,2049,21,1,5,0,0,512]

theorem envBound12389 : H12AffineFastState.Bounded env12389 := by
  intro p hp
  have h : env12389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12386_12389 : H12AffineEnvironment.transform 9 21 env12386 = env12389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env12386 == env12389) = true)

theorem identity12389 : scanCanonicalize (H12AffineFastState.compose env12389 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 543) := by decide +kernel

theorem selectedBound12389 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12390 : List Nat := [2,4,8,16,1,16,9,4,512,21,543,17,8,0,0,3,16,543,20,1,0,1,17,3,9,17,542,17,16,542,21,1,5,0,0,512]

theorem envBound12390 : H12AffineFastState.Bounded env12390 := by
  intro p hp
  have h : env12390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12389_12390 : H12AffineEnvironment.transform 10 543 env12389 = env12390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 543 env12389 == env12390) = true)

def leafEnv12390 : List Nat := [2,4,8,16,1,16,9,4,512,21,543,17,8,0,0,3,16,543,20,1,0,1,17,3,20,9,1,17,542,17,16,542,21,1,5,0,5,2,0,512,1,0,0]

def active12390 : List Nat := [0,1,2,3,8]

def tree12390 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12390 : H12WitnessSearch.Good tree12390 := H12GlobalWitnessIndex.good

theorem leafIdentity12390 : H12AffineFastState.composeSystem env12390 rootObs = leafEnv12390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12390 rootObs == leafEnv12390) = true)

theorem terminalChecked12390 : H12PackedTerminal.terminalCheckFast leafEnv12390 active12390 tree12390 = true := by decide +kernel

def env12391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,8388608,8487372,8328,65,171417,8393984,8406288,8526965,1501,8451180,257,21793,46213,74251]

theorem envBound12391 : H12AffineFastState.Bounded env12391 := by
  intro p hp
  have h : env12391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12360_12391 : H12AffineEnvironment.transform 21 33 env12360 = env12391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env12360 == env12391) = true)

theorem identity12391 : scanCanonicalize (H12AffineFastState.compose env12391 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 120015) := by decide +kernel

theorem selectedBound12391 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56437,1025,32769,4161,33,120015,21763,8328,65,171417,115151,102879,247994,1501,73891,257,21793,46213,74251]

theorem envBound12392 : H12AffineFastState.Bounded env12392 := by
  intro p hp
  have h : env12392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12391_12392 : H12AffineEnvironment.transform 22 120015 env12391 = env12392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 120015 env12391 == env12392) = true)

def env12393 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56357,1025,32769,4113,33,119967,21763,8328,17,171417,115103,102799,247994,1421,73891,257,21793,46213,74251]

theorem envBound12393 : H12AffineFastState.Bounded env12393 := by
  intro p hp
  have h : env12393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12392_12393 : H12AffineEnvironment.transform 5 16 env12392 = env12393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12392 == env12393) = true)

theorem identity12393 : scanCanonicalize (H12AffineFastState.compose env12393 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound12393 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env12394 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,5529,56357,1025,32769,4113,33,119967,21763,8328,17,34816,115103,102799,122147,1421,73891,257,21793,46213,74251]

theorem envBound12394 : H12AffineFastState.Bounded env12394 := by
  intro p hp
  have h : env12394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12393_12394 : H12AffineEnvironment.transform 16 5529 env12393 = env12394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env12393 == env12394) = true)

theorem identity12394 : scanCanonicalize (H12AffineFastState.compose env12394 (packedSelected [3,4,5,7,8,9,14,27,28,35] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound12394 : packedSelected [3,4,5,7,8,9,14,27,28,35] rootPS < 2^1333 := by decide +kernel

def env12395 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,5529,56357,1025,32769,4113,33,17,21763,8328,17,34816,5393,17665,2477,1421,62509,257,21793,46213,63109]

theorem envBound12395 : H12AffineFastState.Bounded env12395 := by
  intro p hp
  have h : env12395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12394_12395 : H12AffineEnvironment.transform 15 54414 env12394 = env12395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env12394 == env12395) = true)

theorem identity12395 : scanCanonicalize (H12AffineFastState.compose env12395 (packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound12395 : packedSelected [0,1,2,3,5,6,7,8,9,12,17,18,22] rootPS < 2^1333 := by decide +kernel

def env12396 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,32768,40970,5529,43169,1025,32769,4113,33,17,8583,8328,17,34816,5393,12677,2477,1421,32937,257,8613,46213,33281]

theorem envBound12396 : H12AffineFastState.Bounded env12396 := by
  intro p hp
  have h : env12396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12395_12396 : H12AffineEnvironment.transform 13 13444 env12395 = env12396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env12395 == env12396) = true)

theorem identity12396 : scanCanonicalize (H12AffineFastState.compose env12396 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12396 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env12397 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13444,8461,263,5529,2476,1025,8460,4113,33,17,8583,8328,17,10509,5393,12677,2477,1421,8612,257,8613,5512,8972]

theorem envBound12397 : H12AffineFastState.Bounded env12397 := by
  intro p hp
  have h : env12397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12396_12397 : H12AffineEnvironment.transform 14 8461 env12396 = env12397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env12396 == env12397) = true)

theorem identity12397 : scanCanonicalize (H12AffineFastState.compose env12397 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1677) := by decide +kernel

theorem selectedBound12397 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env12398 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1677,4096,8192,13444,8461,263,5529,1825,1025,8460,4113,33,17,8583,8328,17,10112,5393,12677,1824,1421,8612,257,8613,5512,8972]

theorem envBound12398 : H12AffineFastState.Bounded env12398 := by
  intro p hp
  have h : env12398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12397_12398 : H12AffineEnvironment.transform 10 1677 env12397 = env12398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1677 env12397 == env12398) = true)

theorem identity12398 : scanCanonicalize (H12AffineFastState.compose env12398 (packedSelected [0,1,6,8,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound12398 : packedSelected [0,1,6,8,9,14] rootPS < 2^1333 := by decide +kernel

def env12399 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1677,4096,1336,4540,1077,263,5529,1825,1025,1076,4113,33,17,1215,1456,17,696,5393,5309,1824,1421,1180,257,1181,5512,1588]

theorem envBound12399 : H12AffineFastState.Bounded env12399 := by
  intro p hp
  have h : env12399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12398_12399 : H12AffineEnvironment.transform 12 1336 env12398 = env12399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env12398 == env12399) = true)

theorem identity12399 : scanCanonicalize (H12AffineFastState.compose env12399 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound12399 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env12400 : List Nat := [2,4,8,16,32,16,128,256,512,769,396,4096,569,4540,820,263,4760,32,768,821,4113,33,17,958,689,17,696,4624,5052,33,652,925,257,924,4745,309]

theorem envBound12400 : H12AffineFastState.Bounded env12400 := by
  intro p hp
  have h : env12400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12399_12400 : H12AffineEnvironment.transform 9 769 env12399 = env12400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env12399 == env12400) = true)

theorem identity12400 : scanCanonicalize (H12AffineFastState.compose env12400 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 560) := by decide +kernel

theorem selectedBound12400 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env12401 : List Nat := [2,4,8,16,32,16,128,256,512,769,396,560,569,908,820,263,168,32,768,821,545,33,17,958,689,17,696,32,396,33,652,925,257,924,185,309]

theorem envBound12401 : H12AffineFastState.Bounded env12401 := by
  intro p hp
  have h : env12401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12400_12401 : H12AffineEnvironment.transform 11 560 env12400 = env12401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 560 env12400 == env12401) = true)

theorem identity12401 : scanCanonicalize (H12AffineFastState.compose env12401 (packedSelected [0,1,3,5,8,9,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound12401 : packedSelected [0,1,3,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env12402 : List Nat := [2,4,8,16,32,16,128,256,309,52,396,261,268,185,1,263,168,32,53,0,276,33,17,139,388,17,397,32,396,33,441,168,257,169,185,309]

theorem envBound12402 : H12AffineFastState.Bounded env12402 := by
  intro p hp
  have h : env12402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12401_12402 : H12AffineEnvironment.transform 8 309 env12401 = env12402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env12401 == env12402) = true)

theorem identity12402 : scanCanonicalize (H12AffineFastState.compose env12402 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound12402 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12403 : List Nat := [2,4,8,16,32,16,3,256,309,52,271,261,268,58,1,263,43,32,53,0,276,33,17,8,263,17,270,32,271,33,314,43,257,42,58,309]

theorem envBound12403 : H12AffineFastState.Bounded env12403 := by
  intro p hp
  have h : env12403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12402_12403 : H12AffineEnvironment.transform 6 3 env12402 = env12403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env12402 == env12403) = true)

theorem identity12403 : scanCanonicalize (H12AffineFastState.compose env12403 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 6) := by decide +kernel

theorem selectedBound12403 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12404 : List Nat := [2,4,8,16,32,16,3,6,51,52,9,3,10,58,1,1,43,32,53,0,18,33,17,8,1,17,8,32,9,33,60,43,7,42,58,51]

theorem envBound12404 : H12AffineFastState.Bounded env12404 := by
  intro p hp
  have h : env12404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12403_12404 : H12AffineEnvironment.transform 7 6 env12403 = env12404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 6 env12403 == env12404) = true)

theorem identity12404 : scanCanonicalize (H12AffineFastState.compose env12404 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12404 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12405 : List Nat := [2,4,8,16,1,16,3,6,18,21,9,3,10,27,1,1,10,1,20,0,18,0,17,8,1,17,8,1,9,0,29,10,7,11,27,18]

theorem envBound12405 : H12AffineFastState.Bounded env12405 := by
  intro p hp
  have h : env12405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12404_12405 : H12AffineEnvironment.transform 4 1 env12404 = env12405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12404 == env12405) = true)

theorem identity12405 : scanCanonicalize (H12AffineFastState.compose env12405 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound12405 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12406 : List Nat := [2,0,8,16,1,16,3,2,18,17,9,3,10,27,1,1,10,1,16,0,18,0,17,8,1,17,8,1,9,0,25,10,3,11,27,18]

theorem envBound12406 : H12AffineFastState.Bounded env12406 := by
  intro p hp
  have h : env12406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12405_12406 : H12AffineEnvironment.transform 1 0 env12405 = env12406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env12405 == env12406) = true)

theorem identity12406 : scanCanonicalize (H12AffineFastState.compose env12406 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12406 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12407 : List Nat := [2,0,2,16,1,16,3,2,18,17,3,3,0,17,1,1,0,1,16,0,18,0,17,2,1,17,2,1,3,0,19,0,3,1,17,18]

theorem envBound12407 : H12AffineFastState.Bounded env12407 := by
  intro p hp
  have h : env12407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12406_12407 : H12AffineEnvironment.transform 2 2 env12406 = env12407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12406 == env12407) = true)

theorem identity12407 : scanCanonicalize (H12AffineFastState.compose env12407 (packedSelected [8] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound12407 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env12408 : List Nat := [0,0,0,16,1,16,1,0,16,17,1,1,0,17,1,1,0,1,16,0,16,0,17,0,1,17,0,1,1,0,17,0,1,1,17,16]

theorem envBound12408 : H12AffineFastState.Bounded env12408 := by
  intro p hp
  have h : env12408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12407_12408 : H12AffineEnvironment.transform 0 0 env12407 = env12408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env12407 == env12408) = true)

def env12409 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,56356,1025,32769,4112,33,119966,21763,8328,16,171417,115102,102798,247994,1420,73891,257,21793,46213,74251]

theorem envBound12409 : H12AffineFastState.Bounded env12409 := by
  intro p hp
  have h : env12409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12392_12409 : H12AffineEnvironment.transform 5 17 env12392 = env12409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12392 == env12409) = true)

theorem identity12409 : scanCanonicalize (H12AffineFastState.compose env12409 (packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound12409 : packedSelected [0,1,5,8,9,11,12,15,18,19,22,23,24,26,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env12410 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,79251,56356,1025,32769,4112,33,119966,21763,8328,16,108554,115102,102798,64809,1420,73891,257,21793,46213,74251]

theorem envBound12410 : H12AffineFastState.Bounded env12410 := by
  intro p hp
  have h : env12410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12409_12410 : H12AffineEnvironment.transform 16 79251 env12409 = env12410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env12409 == env12410) = true)

theorem identity12410 : scanCanonicalize (H12AffineFastState.compose env12410 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound12410 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env12411 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,33030,46229,56356,1025,32769,4112,33,21912,21763,8328,16,10508,16536,4232,64809,1420,41381,257,21793,46213,41741]

theorem envBound12411 : H12AffineFastState.Bounded env12411 := by
  intro p hp
  have h : env12411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12410_12411 : H12AffineEnvironment.transform 15 33030 env12410 = env12411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env12410 == env12411) = true)

theorem identity12411 : scanCanonicalize (H12AffineFastState.compose env12411 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12411 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env12412 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,8202,5529,32040,1025,8461,4112,33,21912,21763,8328,16,10508,16536,4232,23589,1420,169,257,21793,5513,513]

theorem envBound12412 : H12AffineFastState.Bounded env12412 := by
  intro p hp
  have h : env12412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12411_12412 : H12AffineEnvironment.transform 14 8460 env12411 = env12412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12411 == env12412) = true)

theorem identity12412 : scanCanonicalize (H12AffineFastState.compose env12412 (packedSelected [2,3,5,6,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 189) := by decide +kernel

theorem selectedBound12412 : packedSelected [2,3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env12413 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,16384,8369,8202,5156,31893,1025,8368,4112,33,21541,21694,8328,16,10417,16536,4232,23589,1073,169,188,21660,5172,513]

theorem envBound12413 : H12AffineFastState.Bounded env12413 := by
  intro p hp
  have h : env12413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12412_12413 : H12AffineEnvironment.transform 7 189 env12412 = env12413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 189 env12412 == env12413) = true)

theorem identity12413 : scanCanonicalize (H12AffineFastState.compose env12413 (packedSelected [2,3,4,5,6,9,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5172) := by decide +kernel

theorem selectedBound12413 : packedSelected [2,3,4,5,6,9,10,16] rootPS < 2^1333 := by decide +kernel

def env12414 : List Nat := [2,4,8,16,32,17,128,189,512,1024,2048,4096,8192,5172,8369,8202,5156,10401,1025,8368,4112,33,17,138,8328,16,10417,5292,4232,2065,1073,169,188,168,5172,513]

theorem envBound12414 : H12AffineFastState.Bounded env12414 := by
  intro p hp
  have h : env12414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12413_12414 : H12AffineEnvironment.transform 13 5172 env12413 = env12414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5172 env12413 == env12414) = true)

theorem identity12414 : scanCanonicalize (H12AffineFastState.compose env12414 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12414 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12415 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,4096,8192,5172,8248,8202,5156,10280,1025,8249,4112,33,17,3,8193,16,10296,5157,4097,2065,1073,32,53,33,5172,513]

theorem envBound12415 : H12AffineFastState.Bounded env12415 := by
  intro p hp
  have h : env12415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12414_12415 : H12AffineEnvironment.transform 6 9 env12414 = env12415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12414 == env12415) = true)

theorem identity12415 : scanCanonicalize (H12AffineFastState.compose env12415 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound12415 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12416 : List Nat := [2,4,8,16,32,17,9,52,512,1024,2048,4096,9,5172,49,3,5156,2081,1025,48,4112,33,17,3,8,16,2097,5157,4097,2065,1073,32,53,33,5172,513]

theorem envBound12416 : H12AffineFastState.Bounded env12416 := by
  intro p hp
  have h : env12416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12415_12416 : H12AffineEnvironment.transform 12 9 env12415 = env12416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env12415 == env12416) = true)

theorem identity12416 : scanCanonicalize (H12AffineFastState.compose env12416 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound12416 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12417 : List Nat := [2,4,8,16,32,17,9,52,512,1024,544,4096,9,5172,49,3,5156,513,1025,48,4112,33,17,3,8,16,529,5157,4097,561,1073,32,53,33,5172,513]

theorem envBound12417 : H12AffineFastState.Bounded env12417 := by
  intro p hp
  have h : env12417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12416_12417 : H12AffineEnvironment.transform 10 544 env12416 = env12417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env12416 == env12417) = true)

theorem identity12417 : scanCanonicalize (H12AffineFastState.compose env12417 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound12417 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12418 : List Nat := [2,4,8,16,32,17,9,52,512,36,544,4096,9,4112,49,3,4096,513,37,48,4112,33,17,3,8,16,529,4097,4097,561,21,32,53,33,4112,513]

theorem envBound12418 : H12AffineFastState.Bounded env12418 := by
  intro p hp
  have h : env12418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12417_12418 : H12AffineEnvironment.transform 9 36 env12417 = env12418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env12417 == env12418) = true)

theorem identity12418 : scanCanonicalize (H12AffineFastState.compose env12418 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound12418 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12419 : List Nat := [2,4,8,16,32,17,9,52,512,36,544,529,9,513,49,3,529,513,37,48,513,33,17,3,8,16,529,528,528,561,21,32,53,33,513,513]

theorem envBound12419 : H12AffineFastState.Bounded env12419 := by
  intro p hp
  have h : env12419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12418_12419 : H12AffineEnvironment.transform 11 529 env12418 = env12419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env12418 == env12419) = true)

theorem identity12419 : scanCanonicalize (H12AffineFastState.compose env12419 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12419 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12420 : List Nat := [2,4,8,16,0,17,9,20,512,4,512,529,9,513,17,3,529,513,5,16,513,1,17,3,8,16,529,528,528,529,21,0,21,1,513,513]

theorem envBound12420 : H12AffineFastState.Bounded env12420 := by
  intro p hp
  have h : env12420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12419_12420 : H12AffineEnvironment.transform 4 0 env12419 = env12420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12419 == env12420) = true)

def env12421 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound12421 : H12AffineFastState.Bounded env12421 := by
  intro p hp
  have h : env12421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans11993_12421 : H12AffineEnvironment.transform 26 30393345 env11993 = env12421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env11993 == env12421) = true)

def env12422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound12422 : H12AffineFastState.Bounded env12422 := by
  intro p hp
  have h : env12422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12421_12422 : H12AffineEnvironment.transform 18 1024 env12421 = env12422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12421 == env12422) = true)

theorem identity12422 : scanCanonicalize (H12AffineFastState.compose env12422 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510136) := by decide +kernel

theorem selectedBound12422 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510136,8328,65,12585145,2509876,10507601,8830976,8801449,6729081,256,10882068,10939824,8874878]

theorem envBound12423 : H12AffineFastState.Bounded env12423 := by
  intro p hp
  have h : env12423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12422_12423 : H12AffineEnvironment.transform 23 510136 env12422 = env12423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510136 env12422 == env12423) = true)

def env12424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513204,510136,8328,65,6705549,2509876,396389,2136372,2102685,6729081,256,21792,46212,2175562]

theorem envBound12424 : H12AffineFastState.Bounded env12424 := by
  intro p hp
  have h : env12424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12423_12424 : H12AffineEnvironment.transform 22 2513204 env12423 = env12424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513204 env12423 == env12424) = true)

def env12425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513204,510136,8328,65,2409661,2509876,396389,2136372,2102685,2373705,256,21792,46212,2175562]

theorem envBound12425 : H12AffineFastState.Bounded env12425 := by
  intro p hp
  have h : env12425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12424_12425 : H12AffineEnvironment.transform 21 169264 env12424 = env12425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env12424 == env12425) = true)

def env12426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,510136,8328,65,316669,416884,396389,35188,1501,272393,256,21792,46212,74250]

theorem envBound12426 : H12AffineFastState.Bounded env12426 := by
  intro p hp
  have h : env12426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12425_12426 : H12AffineEnvironment.transform 20 4160 env12425 = env12426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12425 == env12426) = true)

theorem identity12426 : scanCanonicalize (H12AffineFastState.compose env12426 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound12426 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,4160,169264,412020,400486,8328,65,316669,416884,396389,35188,1501,272393,256,21792,46212,63188]

theorem envBound12427 : H12AffineFastState.Bounded env12427 := by
  intro p hp
  have h : env12427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12426_12427 : H12AffineEnvironment.transform 15 54494 env12426 = env12427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env12426 == env12427) = true)

def env12428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,262144,1024,32769,4160,54640,264500,285734,8328,65,316669,269364,281637,35188,1501,272393,256,21792,46212,63188]

theorem envBound12428 : H12AffineFastState.Bounded env12428 := by
  intro p hp
  have h : env12428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12427_12428 : H12AffineEnvironment.transform 16 16448 env12427 = env12428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env12427 == env12428) = true)

theorem identity12428 : scanCanonicalize (H12AffineFastState.compose env12428 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56573) := by decide +kernel

theorem selectedBound12428 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16448,56573,1024,32769,4160,54640,54729,32987,8328,65,2048,49353,37080,35188,1501,62708,256,21792,46212,63188]

theorem envBound12429 : H12AffineFastState.Bounded env12429 := by
  intro p hp
  have h : env12429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12428_12429 : H12AffineEnvironment.transform 17 56573 env12428 = env12429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56573 env12428 == env12429) = true)

theorem identity12429 : scanCanonicalize (H12AffineFastState.compose env12429 (packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound12429 : packedSelected [0,2,3,4,5,6,7,8,9,10,11,14,16,18,20,28,31] rootPS < 2^1333 := by decide +kernel

def env12430 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5156,32768,33018,5220,35033,1024,32769,4160,33108,33261,32987,8328,65,2048,38125,37080,35188,1501,41168,256,260,46212,41712]

theorem envBound12430 : H12AffineFastState.Bounded env12430 := by
  intro p hp
  have h : env12430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12429_12430 : H12AffineEnvironment.transform 13 5156 env12429 = env12430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env12429 == env12430) = true)

theorem identity12430 : scanCanonicalize (H12AffineFastState.compose env12430 (packedSelected [1,2,3,5,6,7,8,9,10,11,16,19,22,23,27] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12430 : packedSelected [1,2,3,5,6,7,8,9,10,11,16,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env12431 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,8192,5156,32768,33018,5220,35033,1024,32769,4160,32880,32969,32987,8328,65,2048,38125,37080,34896,1273,41168,36,32,46212,41712]

theorem envBound12431 : H12AffineFastState.Bounded env12431 := by
  intro p hp
  have h : env12431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12430_12431 : H12AffineEnvironment.transform 7 36 env12430 = env12431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12430 == env12431) = true)

theorem identity12431 : scanCanonicalize (H12AffineFastState.compose env12431 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12431 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,17,18,19] rootPS < 2^1333 := by decide +kernel

def env12432 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,8192,5156,32768,32803,5220,34816,1024,32769,4160,32880,32784,32770,8273,65,2048,37940,36865,34896,1056,40969,36,32,46173,41513]

theorem envBound12432 : H12AffineFastState.Bounded env12432 := by
  intro p hp
  have h : env12432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12431_12432 : H12AffineEnvironment.transform 6 89 env12431 = env12432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12431 == env12432) = true)

theorem identity12432 : scanCanonicalize (H12AffineFastState.compose env12432 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound12432 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env12433 : List Nat := [2,4,8,16,32,64,89,36,512,1024,2048,4096,120,5156,32768,32803,5220,34816,1024,32769,4160,32880,32784,32770,41,65,2048,37940,36865,34896,1056,32881,36,32,37925,33361]

theorem envBound12433 : H12AffineFastState.Bounded env12433 := by
  intro p hp
  have h : env12433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12432_12433 : H12AffineEnvironment.transform 12 120 env12432 = env12433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env12432 == env12433) = true)

theorem identity12433 : scanCanonicalize (H12AffineFastState.compose env12433 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12433 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12434 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,40,5156,32768,32803,5172,34816,1024,32769,4112,32800,32784,32770,41,17,2048,37940,36865,34816,1056,32801,36,32,37925,33281]

theorem envBound12434 : H12AffineFastState.Bounded env12434 := by
  intro p hp
  have h : env12434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12433_12434 : H12AffineEnvironment.transform 5 16 env12433 = env12434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12433 == env12434) = true)

theorem identity12434 : scanCanonicalize (H12AffineFastState.compose env12434 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12434 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env12435 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,9,5125,32768,32770,5141,34816,1024,32769,4112,32769,32784,32770,8,17,2048,37909,36865,34816,1025,32768,5,1,37892,33281]

theorem envBound12435 : H12AffineFastState.Bounded env12435 := by
  intro p hp
  have h : env12435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12434_12435 : H12AffineEnvironment.transform 4 1 env12434 = env12435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12434 == env12435) = true)

theorem identity12435 : scanCanonicalize (H12AffineFastState.compose env12435 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12435 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12436 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,9,5125,0,2,5141,2048,1024,1,4112,1,16,2,8,17,2048,5141,4097,2048,1025,0,5,1,5124,513]

theorem envBound12436 : H12AffineFastState.Bounded env12436 := by
  intro p hp
  have h : env12436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12435_12436 : H12AffineEnvironment.transform 14 0 env12435 = env12436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12435 == env12436) = true)

def env12437 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,262144,1024,32769,4160,54641,264501,285735,8328,65,316669,269365,281636,35188,1501,272393,256,21792,46212,63188]

theorem envBound12437 : H12AffineFastState.Bounded env12437 := by
  intro p hp
  have h : env12437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12427_12437 : H12AffineEnvironment.transform 16 16449 env12427 = env12437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env12427 == env12437) = true)

theorem identity12437 : scanCanonicalize (H12AffineFastState.compose env12437 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56436) := by decide +kernel

theorem selectedBound12437 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12438 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,16449,56436,1024,32769,4160,54641,54593,32851,8328,65,2185,49217,36944,35188,1501,62589,256,21792,46212,63188]

theorem envBound12438 : H12AffineFastState.Bounded env12438 := by
  intro p hp
  have h : env12438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12437_12438 : H12AffineEnvironment.transform 17 56436 env12437 = env12438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env12437 == env12438) = true)

theorem identity12438 : scanCanonicalize (H12AffineFastState.compose env12438 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound12438 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env12439 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8461,30163,16449,32121,1024,8460,4160,29820,29772,8542,8328,65,2185,24908,12637,10361,1501,21872,256,21792,5513,22489]

theorem envBound12439 : H12AffineFastState.Bounded env12439 := by
  intro p hp
  have h : env12439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12438_12439 : H12AffineEnvironment.transform 14 8461 env12438 = env12439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env12438 == env12439) = true)

theorem identity12439 : scanCanonicalize (H12AffineFastState.compose env12439 (packedSelected [1,2,3,4,5,6,8,9,12,16,17,18,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12439 : packedSelected [1,2,3,4,5,6,8,9,12,16,17,18,20] rootPS < 2^1333 := by decide +kernel

def env12440 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,8461,29962,16449,32121,1024,8460,4160,29820,29772,8542,8273,65,2128,24908,12637,10361,1284,21872,256,21792,5456,22272]

theorem envBound12440 : H12AffineFastState.Bounded env12440 := by
  intro p hp
  have h : env12440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12439_12440 : H12AffineEnvironment.transform 6 89 env12439 = env12440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12439 == env12440) = true)

def env12441 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,510136,8328,65,316668,416885,396389,35189,1500,272392,256,21792,46212,74251]

theorem envBound12441 : H12AffineFastState.Bounded env12441 := by
  intro p hp
  have h : env12441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12425_12441 : H12AffineEnvironment.transform 20 4161 env12425 = env12441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12425 == env12441) = true)

theorem identity12441 : scanCanonicalize (H12AffineFastState.compose env12441 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound12441 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12442 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223599,1024,32769,4161,169264,73754,41431,8328,65,245139,79130,91402,35189,1500,213351,256,21792,46212,74251]

theorem envBound12442 : H12AffineFastState.Bounded env12442 := by
  intro p hp
  have h : env12442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12441_12442 : H12AffineEnvironment.transform 17 223599 env12441 = env12442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env12441 == env12442) = true)

def env12443 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4113,169264,73754,41351,8328,17,245139,79130,91402,35109,1420,213303,256,21792,46212,74251]

theorem envBound12443 : H12AffineFastState.Bounded env12443 := by
  intro p hp
  have h : env12443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12442_12443 : H12AffineEnvironment.transform 5 16 env12442 = env12443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12442 == env12443) = true)

theorem identity12443 : scanCanonicalize (H12AffineFastState.compose env12443 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound12443 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env12444 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,13341,89378,1024,32769,4113,41261,73754,41351,8328,17,100750,79130,91402,35109,1420,95530,256,21792,46212,74251]

theorem envBound12444 : H12AffineFastState.Bounded env12444 := by
  intro p hp
  have h : env12444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12443_12444 : H12AffineEnvironment.transform 16 13341 env12443 = env12444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env12443 == env12444) = true)

theorem identity12444 : scanCanonicalize (H12AffineFastState.compose env12444 (packedSelected [1,3,5,8,14,18,19,23,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound12444 : packedSelected [1,3,5,8,14,18,19,23,31,35] rootPS < 2^1333 := by decide +kernel

def env12445 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,65536,13341,89378,1024,21761,4113,29741,73754,29831,8328,17,89230,79130,91402,23589,1420,95530,256,21792,24964,74251]

theorem envBound12445 : H12AffineFastState.Bounded env12445 := by
  intro p hp
  have h : env12445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12444_12445 : H12AffineEnvironment.transform 14 21760 env12444 = env12445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env12444 == env12445) = true)

theorem identity12445 : scanCanonicalize (H12AffineFastState.compose env12445 (packedSelected [1,3,5,8,10,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound12445 : packedSelected [1,3,5,8,10,26] rootPS < 2^1333 := by decide +kernel

def env12446 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,8322,13341,32160,1024,21761,4113,29741,152,29831,8328,17,31756,5528,17800,23589,1420,21928,256,21792,24964,649]

theorem envBound12446 : H12AffineFastState.Bounded env12446 := by
  intro p hp
  have h : env12446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12445_12446 : H12AffineEnvironment.transform 15 8322 env12445 = env12446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env12445 == env12446) = true)

theorem identity12446 : scanCanonicalize (H12AffineFastState.compose env12446 (packedSelected [0,1,2,6,7,8,12,15,16,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound12446 : packedSelected [0,1,2,6,7,8,12,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env12447 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,137,8322,13341,10281,1024,136,4113,8612,152,8462,8328,17,10629,5528,4097,2476,1420,33,256,169,13325,649]

theorem envBound12447 : H12AffineFastState.Bounded env12447 := by
  intro p hp
  have h : env12447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12446_12447 : H12AffineEnvironment.transform 13 5513 env12446 = env12447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env12446 == env12447) = true)

theorem identity12447 : scanCanonicalize (H12AffineFastState.compose env12447 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12447 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12448 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5513,137,399,5392,2340,1024,136,4113,169,152,3,389,17,2184,5528,4097,2476,1420,33,256,169,5376,649]

theorem envBound12448 : H12AffineFastState.Bounded env12448 := by
  intro p hp
  have h : env12448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12447_12448 : H12AffineEnvironment.transform 12 269 env12447 = env12448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12447 == env12448) = true)

theorem identity12448 : scanCanonicalize (H12AffineFastState.compose env12448 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12448 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env12449 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,0,262,5392,2340,1024,1,4113,32,17,3,268,17,2049,5393,4097,2341,1285,33,256,32,5376,512]

theorem envBound12449 : H12AffineFastState.Bounded env12449 := by
  intro p hp
  have h : env12449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12448_12449 : H12AffineEnvironment.transform 6 9 env12448 = env12449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12448 == env12449) = true)

theorem identity12449 : scanCanonicalize (H12AffineFastState.compose env12449 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12449 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12450 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,269,5376,0,262,5392,2309,1024,1,4113,1,17,3,268,17,2049,5393,4097,2308,1285,0,256,1,5376,512]

theorem envBound12450 : H12AffineFastState.Bounded env12450 := by
  intro p hp
  have h : env12450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12449_12450 : H12AffineEnvironment.transform 4 1 env12449 = env12450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12449 == env12450) = true)

theorem identity12450 : scanCanonicalize (H12AffineFastState.compose env12450 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12450 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12451 : List Nat := [2,4,8,16,1,16,9,5,512,1024,2048,4096,8,5125,0,3,5141,2048,1024,1,4113,1,17,3,9,17,2049,5140,4097,2049,1024,0,5,1,5125,512]

theorem envBound12451 : H12AffineFastState.Bounded env12451 := by
  intro p hp
  have h : env12451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12450_12451 : H12AffineEnvironment.transform 7 5 env12450 = env12451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12450 == env12451) = true)

def env12452 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4112,169264,73754,41350,8328,16,245139,79130,91402,35108,1421,213302,256,21792,46212,74251]

theorem envBound12452 : H12AffineFastState.Bounded env12452 := by
  intro p hp
  have h : env12452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12442_12452 : H12AffineEnvironment.transform 5 17 env12442 = env12452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12442 == env12452) = true)

theorem identity12452 : scanCanonicalize (H12AffineFastState.compose env12452 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound12452 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env12453 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,56357,1024,32769,4112,73771,73754,41350,8328,16,2184,79130,91402,35108,1421,62509,256,21792,46212,74251]

theorem envBound12453 : H12AffineFastState.Bounded env12453 := by
  intro p hp
  have h : env12453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12452_12453 : H12AffineEnvironment.transform 16 111899 env12452 = env12453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env12452 == env12453) = true)

theorem identity12453 : scanCanonicalize (H12AffineFastState.compose env12453 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 54414) := by decide +kernel

theorem selectedBound12453 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env12454 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,24981,56357,1024,32769,4112,62629,62612,41350,8328,16,2184,57748,45444,35108,1421,62509,256,21792,46212,63109]

theorem envBound12454 : H12AffineFastState.Bounded env12454 := by
  intro p hp
  have h : env12454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12453_12454 : H12AffineEnvironment.transform 15 54414 env12453 = env12454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54414 env12453 == env12454) = true)

theorem identity12454 : scanCanonicalize (H12AffineFastState.compose env12454 (packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12454 : packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env12455 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8460,30082,24981,32041,1024,8461,4112,21929,21912,138,8328,16,2184,16536,4232,10280,1421,21793,256,21792,5512,22409]

theorem envBound12455 : H12AffineFastState.Bounded env12455 := by
  intro p hp
  have h : env12455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12454_12455 : H12AffineEnvironment.transform 14 8460 env12454 = env12455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12454 == env12455) = true)

theorem identity12455 : scanCanonicalize (H12AffineFastState.compose env12455 (packedSelected [1,3,4,5,6,8,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1084) := by decide +kernel

theorem selectedBound12455 : packedSelected [1,3,4,5,6,8,9,14] rootPS < 2^1333 := by decide +kernel

def env12456 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1084,16384,1328,20926,17833,22805,1024,1329,4112,21929,21912,138,1204,16,2184,16536,4232,3092,1421,21793,256,21792,5512,22409]

theorem envBound12456 : H12AffineFastState.Bounded env12456 := by
  intro p hp
  have h : env12456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12455_12456 : H12AffineEnvironment.transform 12 1084 env12455 = env12456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1084 env12455 == env12456) = true)

theorem identity12456 : scanCanonicalize (H12AffineFastState.compose env12456 (packedSelected [1,2,3,5,8,11,12,16] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound12456 : packedSelected [1,2,3,5,8,11,12,16] rootPS < 2^1333 := by decide +kernel

def env12457 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,1084,4113,1328,431,5560,2308,1024,1329,4112,1464,1417,138,1204,16,2184,4233,4232,3092,1421,1328,256,1329,5512,1944]

theorem envBound12457 : H12AffineFastState.Bounded env12457 := by
  intro p hp
  have h : env12457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12456_12457 : H12AffineEnvironment.transform 13 4113 env12456 = env12457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env12456 == env12457) = true)

theorem identity12457 : scanCanonicalize (H12AffineFastState.compose env12457 (packedSelected [1,4,8,9,10,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12457 : packedSelected [1,4,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env12458 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,1052,4113,1296,399,5528,2308,1024,1297,4112,1432,1417,138,1172,16,2184,4233,4232,3092,1421,1296,256,1297,5512,1944]

theorem envBound12458 : H12AffineFastState.Bounded env12458 := by
  intro p hp
  have h : env12458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12457_12458 : H12AffineEnvironment.transform 4 0 env12457 = env12458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12457 == env12458) = true)

theorem identity12458 : scanCanonicalize (H12AffineFastState.compose env12458 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12458 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12459 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,1052,4113,1296,262,5393,2308,1024,1297,4112,1297,1280,3,1053,16,2049,4096,4097,3092,1284,1296,256,1297,5377,1809]

theorem envBound12459 : H12AffineFastState.Bounded env12459 := by
  intro p hp
  have h : env12459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12458_12459 : H12AffineEnvironment.transform 6 9 env12458 = env12459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12458 == env12459) = true)

theorem identity12459 : scanCanonicalize (H12AffineFastState.compose env12459 (packedSelected [2,6] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12459 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12460 : List Nat := [2,4,8,16,0,17,9,256,512,273,2048,4096,269,4113,1,262,4096,2308,273,0,4112,0,17,3,268,16,2049,4096,4097,2309,21,1,256,0,4112,512]

theorem envBound12460 : H12AffineFastState.Bounded env12460 := by
  intro p hp
  have h : env12460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12459_12460 : H12AffineEnvironment.transform 9 273 env12459 = env12460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12459 == env12460) = true)

theorem identity12460 : scanCanonicalize (H12AffineFastState.compose env12460 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound12460 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12461 : List Nat := [2,4,8,16,0,17,9,256,512,273,2048,0,269,17,1,262,0,2308,273,0,16,0,17,3,268,16,2049,0,1,2309,21,1,256,0,16,512]

theorem envBound12461 : H12AffineFastState.Bounded env12461 := by
  intro p hp
  have h : env12461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12460_12461 : H12AffineEnvironment.transform 11 0 env12460 = env12461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env12460 == env12461) = true)

theorem identity12461 : scanCanonicalize (H12AffineFastState.compose env12461 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound12461 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12462 : List Nat := [2,4,8,16,0,17,9,256,512,273,11,0,269,17,1,262,0,271,273,0,16,0,17,3,268,16,10,0,1,270,21,1,256,0,16,512]

theorem envBound12462 : H12AffineFastState.Bounded env12462 := by
  intro p hp
  have h : env12462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12461_12462 : H12AffineEnvironment.transform 10 11 env12461 = env12462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env12461 == env12462) = true)

def env12463 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513204,510136,8328,65,2409660,2509876,396389,2136372,2102685,2373704,256,21792,46212,2175562]

theorem envBound12463 : H12AffineFastState.Bounded env12463 := by
  intro p hp
  have h : env12463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12424_12463 : H12AffineEnvironment.transform 21 169265 env12424 = env12463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env12424 == env12463) = true)

def env12464 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,510136,8328,65,316668,416884,396389,35188,1501,272392,256,21792,46212,74250]

theorem envBound12464 : H12AffineFastState.Bounded env12464 := by
  intro p hp
  have h : env12464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12463_12464 : H12AffineEnvironment.transform 20 4160 env12463 = env12464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12463 == env12464) = true)

theorem identity12464 : scanCanonicalize (H12AffineFastState.compose env12464 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236986) := by decide +kernel

theorem selectedBound12464 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12465 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236986,1024,32769,4160,169265,120014,21762,8328,65,215366,115150,102879,35188,1501,243122,256,21792,46212,74250]

theorem envBound12465 : H12AffineFastState.Bounded env12465 := by
  intro p hp
  have h : env12465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12464_12465 : H12AffineEnvironment.transform 17 236986 env12464 = env12465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236986 env12464 == env12465) = true)

def env12466 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130174,1024,32769,4160,62709,120014,21762,8328,65,75906,115150,102879,35188,1501,119926,256,21792,46212,74250]

theorem envBound12466 : H12AffineFastState.Bounded env12466 := by
  intro p hp
  have h : env12466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12465_12466 : H12AffineEnvironment.transform 16 25028 env12465 = env12466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env12465 == env12466) = true)

theorem identity12466 : scanCanonicalize (H12AffineFastState.compose env12466 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound12466 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env12467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,25028,76158,1024,21761,4160,8693,65998,21762,8328,65,75906,70862,83167,23668,1501,65910,256,21792,24964,74250]

theorem envBound12467 : H12AffineFastState.Bounded env12467 := by
  intro p hp
  have h : env12467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12466_12467 : H12AffineEnvironment.transform 14 21760 env12466 = env12467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env12466 == env12467) = true)

theorem identity12467 : scanCanonicalize (H12AffineFastState.compose env12467 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12467 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env12468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,25028,2421,1024,21761,4160,8693,8645,21762,8328,65,2185,13509,25812,23668,1501,8573,256,21792,24964,513]

theorem envBound12468 : H12AffineFastState.Bounded env12468 := by
  intro p hp
  have h : env12468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12467_12468 : H12AffineEnvironment.transform 15 8203 env12467 = env12468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12467 == env12468) = true)

theorem identity12468 : scanCanonicalize (H12AffineFastState.compose env12468 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound12468 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21760,478,16401,2421,1024,21761,4160,32,16,21762,349,65,2185,5392,17665,23668,1501,168,256,21792,16465,513]

theorem envBound12469 : H12AffineFastState.Bounded env12469 := by
  intro p hp
  have h : env12469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12468_12469 : H12AffineEnvironment.transform 12 469 env12468 = env12469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env12468 == env12469) = true)

theorem identity12469 : scanCanonicalize (H12AffineFastState.compose env12469 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12469 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12470 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,16384,21760,263,16401,2421,1024,21761,4160,32,16,21762,349,65,2128,5392,17665,23668,1284,113,256,21792,16465,513]

theorem envBound12470 : H12AffineFastState.Bounded env12470 := by
  intro p hp
  have h : env12470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12469_12470 : H12AffineEnvironment.transform 6 89 env12469 = env12470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12469 == env12470) = true)

theorem identity12470 : scanCanonicalize (H12AffineFastState.compose env12470 (packedSelected [0,3,4,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4917) := by decide +kernel

theorem selectedBound12470 : packedSelected [0,3,4,8,10,11] rootPS < 2^1333 := by decide +kernel

def env12471 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,4917,1589,263,4900,2421,1024,1588,4160,32,16,1591,349,65,2128,5392,5684,3905,1284,113,256,1557,4964,513]

theorem envBound12471 : H12AffineFastState.Bounded env12471 := by
  intro p hp
  have h : env12471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12470_12471 : H12AffineEnvironment.transform 13 4917 env12470 = env12471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4917 env12470 == env12471) = true)

theorem identity12471 : scanCanonicalize (H12AffineFastState.compose env12471 (packedSelected [0,1,2,3,5,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 64) := by decide +kernel

theorem selectedBound12471 : packedSelected [0,1,2,3,5,8,9,12] rootPS < 2^1333 := by decide +kernel

def env12472 : List Nat := [2,4,8,16,32,64,89,256,512,1024,64,4096,268,4917,1589,263,4900,309,1024,1588,4160,32,16,1591,349,65,16,5392,5684,1793,1284,113,256,1557,4964,513]

theorem envBound12472 : H12AffineFastState.Bounded env12472 := by
  intro p hp
  have h : env12472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12471_12472 : H12AffineEnvironment.transform 10 64 env12471 = env12472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env12471 == env12472) = true)

theorem identity12472 : scanCanonicalize (H12AffineFastState.compose env12472 (packedSelected [0,3,5,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12472 : packedSelected [0,3,5,9,14] rootPS < 2^1333 := by decide +kernel

def env12473 : List Nat := [2,4,8,16,32,16,9,256,512,1024,16,4096,268,4917,1589,263,4900,309,1024,1588,4112,32,16,1591,269,17,16,5392,5684,1793,1284,33,256,1557,4916,513]

theorem envBound12473 : H12AffineFastState.Bounded env12473 := by
  intro p hp
  have h : env12473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12472_12473 : H12AffineEnvironment.transform 5 16 env12472 = env12473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12472 == env12473) = true)

theorem identity12473 : scanCanonicalize (H12AffineFastState.compose env12473 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound12473 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env12474 : List Nat := [2,4,8,16,32,16,9,256,292,1024,16,4096,268,4113,1297,263,4096,309,1024,1296,4112,32,16,1299,269,17,16,5392,5392,1061,1284,33,256,1329,4112,293]

theorem envBound12474 : H12AffineFastState.Bounded env12474 := by
  intro p hp
  have h : env12474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12473_12474 : H12AffineEnvironment.transform 8 292 env12473 = env12474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env12473 == env12474) = true)

theorem identity12474 : scanCanonicalize (H12AffineFastState.compose env12474 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound12474 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env12475 : List Nat := [2,4,8,16,32,16,9,256,292,1024,16,16,268,1,1297,263,16,309,1024,1296,0,32,16,1299,269,17,16,1280,1280,1061,1284,33,256,1329,0,293]

theorem envBound12475 : H12AffineFastState.Bounded env12475 := by
  intro p hp
  have h : env12475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12474_12475 : H12AffineEnvironment.transform 11 16 env12474 = env12475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12474 == env12475) = true)

theorem identity12475 : scanCanonicalize (H12AffineFastState.compose env12475 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12475 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12476 : List Nat := [2,4,8,1,32,1,9,256,292,1024,1,1,268,1,1280,263,1,292,1024,1281,0,32,1,1282,269,0,1,1280,1280,1061,1284,33,256,1312,0,293]

theorem envBound12476 : H12AffineFastState.Bounded env12476 := by
  intro p hp
  have h : env12476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12475_12476 : H12AffineEnvironment.transform 3 1 env12475 = env12476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12475 == env12476) = true)

theorem identity12476 : scanCanonicalize (H12AffineFastState.compose env12476 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12476 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env12477 : List Nat := [2,4,8,1,1,1,9,256,261,1024,1,1,268,1,1280,263,1,261,1024,1281,0,1,1,1282,269,0,1,1280,1280,1028,1284,0,256,1281,0,260]

theorem envBound12477 : H12AffineFastState.Bounded env12477 := by
  intro p hp
  have h : env12477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12476_12477 : H12AffineEnvironment.transform 4 1 env12476 = env12477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12476 == env12477) = true)

theorem identity12477 : scanCanonicalize (H12AffineFastState.compose env12477 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound12477 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env12478 : List Nat := [2,4,8,1,1,1,9,4,1,1024,1,1,8,1,1028,3,1,1,1024,1029,0,1,1,1030,9,0,1,1028,1028,1028,1024,0,4,1029,0,0]

theorem envBound12478 : H12AffineFastState.Bounded env12478 := by
  intro p hp
  have h : env12478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12477_12478 : H12AffineEnvironment.transform 7 4 env12477 = env12478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env12477 == env12478) = true)

def env12479 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130175,1024,32769,4160,62708,120014,21762,8328,65,75907,115150,102879,35188,1501,119927,256,21792,46212,74250]

theorem envBound12479 : H12AffineFastState.Bounded env12479 := by
  intro p hp
  have h : env12479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12465_12479 : H12AffineEnvironment.transform 16 25029 env12465 = env12479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env12465 == env12479) = true)

theorem identity12479 : scanCanonicalize (H12AffineFastState.compose env12479 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound12479 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env12480 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,25029,2421,1024,32769,4160,62708,8644,21762,8328,65,56713,13508,25813,35188,1501,8573,256,21792,46212,55040]

theorem envBound12480 : H12AffineFastState.Bounded env12480 := by
  intro p hp
  have h : env12480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12479_12480 : H12AffineEnvironment.transform 15 62730 env12479 = env12480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env12479 == env12480) = true)

def env12481 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24909,2421,1024,32769,4160,62588,8524,21762,8192,65,56577,13388,25693,35188,1365,8573,256,21792,46092,55040]

theorem envBound12481 : H12AffineFastState.Bounded env12481 := by
  intro p hp
  have h : env12481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12480_12481 : H12AffineEnvironment.transform 6 8 env12480 = env12481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12480 == env12481) = true)

theorem identity12481 : scanCanonicalize (H12AffineFastState.compose env12481 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound12481 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12482 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8203,24909,2421,1024,21760,4160,8573,8524,21762,8192,65,2048,13388,25693,23669,1365,8573,256,21792,24845,513]

theorem envBound12482 : H12AffineFastState.Bounded env12482 := by
  intro p hp
  have h : env12482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12481_12482 : H12AffineEnvironment.transform 14 21761 env12481 = env12482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env12481 == env12482) = true)

theorem identity12482 : scanCanonicalize (H12AffineFastState.compose env12482 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12482 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12483 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,343,16401,2421,1024,21760,4160,33,16,21762,348,65,2048,5392,17665,23669,1365,33,256,21792,16465,513]

theorem envBound12483 : H12AffineFastState.Bounded env12483 := by
  intro p hp
  have h : env12483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12482_12483 : H12AffineEnvironment.transform 12 348 env12482 = env12483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12482 == env12483) = true)

theorem identity12483 : scanCanonicalize (H12AffineFastState.compose env12483 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12483 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12484 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5456,81,343,5441,2421,1024,80,4160,33,16,82,348,65,2048,5392,4177,2341,1365,33,256,112,5377,513]

theorem envBound12484 : H12AffineFastState.Bounded env12484 := by
  intro p hp
  have h : env12484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12483_12484 : H12AffineEnvironment.transform 13 5456 env12483 = env12484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12483 == env12484) = true)

theorem identity12484 : scanCanonicalize (H12AffineFastState.compose env12484 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound12484 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env12485 : List Nat := [2,4,8,16,32,64,8,256,512,769,2048,4096,348,4689,81,343,4672,2421,769,80,4160,33,16,82,348,65,2048,4625,4177,2341,596,33,256,112,4608,513]

theorem envBound12485 : H12AffineFastState.Bounded env12485 := by
  intro p hp
  have h : env12485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12484_12485 : H12AffineEnvironment.transform 9 769 env12484 = env12485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env12484 == env12485) = true)

theorem identity12485 : scanCanonicalize (H12AffineFastState.compose env12485 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 884) := by decide +kernel

theorem selectedBound12485 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env12486 : List Nat := [2,4,8,16,32,64,8,256,512,769,884,4096,348,4689,81,343,4672,513,769,80,4160,33,16,82,348,65,884,4625,4177,593,596,33,256,112,4608,513]

theorem envBound12486 : H12AffineFastState.Bounded env12486 := by
  intro p hp
  have h : env12486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12485_12486 : H12AffineEnvironment.transform 10 884 env12485 = env12486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 884 env12485 == env12486) = true)

theorem identity12486 : scanCanonicalize (H12AffineFastState.compose env12486 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(11+1) ^^^ 820) := by decide +kernel

theorem selectedBound12486 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env12487 : List Nat := [2,4,8,16,32,64,8,256,512,769,884,820,348,357,81,343,372,513,769,80,884,33,16,82,348,65,884,293,869,593,596,33,256,112,308,513]

theorem envBound12487 : H12AffineFastState.Bounded env12487 := by
  intro p hp
  have h : env12487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12486_12487 : H12AffineEnvironment.transform 11 820 env12486 = env12487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 820 env12486 == env12487) = true)

theorem identity12487 : scanCanonicalize (H12AffineFastState.compose env12487 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 81) := by decide +kernel

theorem selectedBound12487 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12488 : List Nat := [2,4,8,16,32,64,8,256,81,336,293,357,348,357,81,343,372,80,336,80,293,33,16,82,348,65,293,293,308,0,5,33,256,112,308,80]

theorem envBound12488 : H12AffineFastState.Bounded env12488 := by
  intro p hp
  have h : env12488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12487_12488 : H12AffineEnvironment.transform 8 81 env12487 = env12488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 81 env12487 == env12488) = true)

theorem identity12488 : scanCanonicalize (H12AffineFastState.compose env12488 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12488 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12489 : List Nat := [2,4,8,16,32,64,8,36,81,116,1,65,120,65,81,115,80,80,116,80,1,33,16,82,120,65,1,1,16,0,5,33,36,112,16,80]

theorem envBound12489 : H12AffineFastState.Bounded env12489 := by
  intro p hp
  have h : env12489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12488_12489 : H12AffineEnvironment.transform 7 36 env12488 = env12489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12488 == env12489) = true)

theorem identity12489 : scanCanonicalize (H12AffineFastState.compose env12489 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12489 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12490 : List Nat := [2,4,8,16,32,16,8,36,1,36,1,17,40,17,1,35,0,0,36,0,1,33,16,2,40,17,1,1,16,0,5,33,36,32,16,0]

theorem envBound12490 : H12AffineFastState.Bounded env12490 := by
  intro p hp
  have h : env12490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12489_12490 : H12AffineEnvironment.transform 5 16 env12489 = env12490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12489 == env12490) = true)

def env12491 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24908,2421,1024,32769,4160,62589,8525,21762,8193,65,56576,13389,25692,35188,1364,8573,256,21792,46093,55040]

theorem envBound12491 : H12AffineFastState.Bounded env12491 := by
  intro p hp
  have h : env12491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12480_12491 : H12AffineEnvironment.transform 6 9 env12480 = env12491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12480 == env12491) = true)

theorem identity12491 : scanCanonicalize (H12AffineFastState.compose env12491 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound12491 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12492 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,33111,5393,2421,1024,32769,4160,32800,8525,8543,8193,65,43357,13389,4097,35188,1364,8573,256,8573,46093,41821]

theorem envBound12492 : H12AffineFastState.Bounded env12492 := by
  intro p hp
  have h : env12492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12491_12492 : H12AffineEnvironment.transform 13 13405 env12491 = env12492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env12491 == env12492) = true)

theorem identity12492 : scanCanonicalize (H12AffineFastState.compose env12492 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound12492 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env12493 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,372,35,5393,2421,1024,373,4160,340,8525,8543,8193,65,10281,13389,4097,2048,1364,8573,256,8573,13689,8745]

theorem envBound12493 : H12AffineFastState.Bounded env12493 := by
  intro p hp
  have h : env12493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12492_12493 : H12AffineEnvironment.transform 14 372 env12492 = env12493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env12492 == env12493) = true)

theorem identity12493 : scanCanonicalize (H12AffineFastState.compose env12493 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12493 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env12494 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,1,35,5220,2048,1024,0,4160,33,8248,8234,8193,65,10281,13389,4097,2048,1057,8200,117,8200,13324,8745]

theorem envBound12494 : H12AffineFastState.Bounded env12494 := by
  intro p hp
  have h : env12494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12493_12494 : H12AffineEnvironment.transform 7 117 env12493 = env12494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12493 == env12494) = true)

theorem identity12494 : scanCanonicalize (H12AffineFastState.compose env12494 (packedSelected [0,1,2,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound12494 : packedSelected [0,1,2,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env12495 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1077,4096,8192,13405,1,35,5220,1077,1024,0,4160,33,8248,8234,8193,65,9244,13389,4097,1077,1057,8200,117,8200,13324,8745]

theorem envBound12495 : H12AffineFastState.Bounded env12495 := by
  intro p hp
  have h : env12495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12494_12495 : H12AffineEnvironment.transform 10 1077 env12494 = env12495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env12494 == env12495) = true)

theorem identity12495 : scanCanonicalize (H12AffineFastState.compose env12495 (packedSelected [0,1,2,3,5,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound12495 : packedSelected [0,1,2,3,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env12496 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,4096,8192,12345,1,35,4096,81,100,0,4160,33,8248,8234,8193,65,8312,12329,4097,81,69,8200,117,8200,12392,8745]

theorem envBound12496 : H12AffineFastState.Bounded env12496 := by
  intro p hp
  have h : env12496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12495_12496 : H12AffineEnvironment.transform 9 100 env12495 = env12496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env12495 == env12496) = true)

theorem identity12496 : scanCanonicalize (H12AffineFastState.compose env12496 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound12496 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env12497 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,16,8192,8233,1,35,16,81,100,0,80,33,8248,8234,8193,65,8312,8249,17,81,69,8200,117,8200,8312,8745]

theorem envBound12497 : H12AffineFastState.Bounded env12497 := by
  intro p hp
  have h : env12497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12496_12497 : H12AffineEnvironment.transform 11 16 env12496 = env12497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12496 == env12497) = true)

theorem identity12497 : scanCanonicalize (H12AffineFastState.compose env12497 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound12497 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env12498 : List Nat := [2,4,8,16,32,64,9,117,512,100,81,16,41,0,1,35,16,81,100,0,80,33,17,3,40,65,81,16,17,81,69,33,117,33,81,512]

theorem envBound12498 : H12AffineFastState.Bounded env12498 := by
  intro p hp
  have h : env12498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12497_12498 : H12AffineEnvironment.transform 12 41 env12497 = env12498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env12497 == env12498) = true)

theorem identity12498 : scanCanonicalize (H12AffineFastState.compose env12498 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 69) := by decide +kernel

theorem selectedBound12498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12499 : List Nat := [2,4,8,16,32,64,9,117,69,100,81,16,41,0,1,35,16,81,100,0,80,33,17,3,40,65,81,16,17,81,69,33,117,33,81,69]

theorem envBound12499 : H12AffineFastState.Bounded env12499 := by
  intro p hp
  have h : env12499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12498_12499 : H12AffineEnvironment.transform 8 69 env12498 = env12499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 69 env12498 == env12499) = true)

theorem identity12499 : scanCanonicalize (H12AffineFastState.compose env12499 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound12499 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12500 : List Nat := [2,4,8,6,32,64,9,99,69,100,71,6,41,0,1,35,6,71,100,0,70,33,7,3,40,65,71,6,7,71,69,33,99,33,71,69]

theorem envBound12500 : H12AffineFastState.Bounded env12500 := by
  intro p hp
  have h : env12500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12499_12500 : H12AffineEnvironment.transform 3 6 env12499 = env12500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env12499 == env12500) = true)

theorem identity12500 : scanCanonicalize (H12AffineFastState.compose env12500 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12501 : List Nat := [2,4,8,6,1,64,9,66,69,69,71,6,8,0,1,2,6,71,69,0,70,0,7,3,9,65,71,6,7,71,69,0,66,0,71,69]

theorem envBound12501 : H12AffineFastState.Bounded env12501 := by
  intro p hp
  have h : env12501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12500_12501 : H12AffineEnvironment.transform 4 1 env12500 = env12501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12500 == env12501) = true)

theorem identity12501 : scanCanonicalize (H12AffineFastState.compose env12501 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 15) := by decide +kernel

theorem selectedBound12501 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env12502 : List Nat := [2,4,8,6,1,15,9,13,10,10,8,6,8,0,1,2,6,8,10,0,9,0,7,3,9,14,8,6,7,8,10,0,13,0,8,10]

theorem envBound12502 : H12AffineFastState.Bounded env12502 := by
  intro p hp
  have h : env12502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12501_12502 : H12AffineEnvironment.transform 5 15 env12501 = env12502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 15 env12501 == env12502) = true)

theorem identity12502 : scanCanonicalize (H12AffineFastState.compose env12502 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound12502 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env12503 : List Nat := [2,4,0,6,1,7,1,5,2,2,0,6,0,0,1,2,6,0,2,0,1,0,7,3,1,6,0,6,7,0,2,0,5,0,0,2]

theorem envBound12503 : H12AffineFastState.Bounded env12503 := by
  intro p hp
  have h : env12503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12502_12503 : H12AffineEnvironment.transform 2 0 env12502 = env12503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env12502 == env12503) = true)

def env12504 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412021,510136,8328,65,316669,416885,396389,35189,1500,272393,256,21792,46212,74251]

theorem envBound12504 : H12AffineFastState.Bounded env12504 := by
  intro p hp
  have h : env12504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12463_12504 : H12AffineEnvironment.transform 20 4161 env12463 = env12504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12463 == env12504) = true)

theorem identity12504 : scanCanonicalize (H12AffineFastState.compose env12504 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12504 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,169265,412021,452786,8328,65,316669,416885,396389,35189,1500,272393,256,21792,46212,513]

theorem envBound12505 : H12AffineFastState.Bounded env12505 := by
  intro p hp
  have h : env12505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12504_12505 : H12AffineEnvironment.transform 15 8202 env12504 = env12505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12504 == env12505) = true)

def env12506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4161,54561,264549,305314,8328,65,316669,269413,281717,35189,1500,272393,256,21792,46212,513]

theorem envBound12506 : H12AffineFastState.Bounded env12506 := by
  intro p hp
  have h : env12506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12505_12506 : H12AffineEnvironment.transform 16 16400 env12505 = env12506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env12505 == env12506) = true)

def env12507 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4113,54561,264501,305314,8328,17,316589,269365,281637,35109,1420,272393,256,21792,46212,513]

theorem envBound12507 : H12AffineFastState.Bounded env12507 := by
  intro p hp
  have h : env12507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12506_12507 : H12AffineEnvironment.transform 5 16 env12506 = env12507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12506 == env12507) = true)

theorem identity12507 : scanCanonicalize (H12AffineFastState.compose env12507 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 32160) := by decide +kernel

theorem selectedBound12507 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env12508 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32160,1024,32769,4113,54561,29845,54530,8328,17,43277,24981,12677,35109,1420,21929,256,21792,46212,513]

theorem envBound12508 : H12AffineFastState.Bounded env12508 := by
  intro p hp
  have h : env12508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12507_12508 : H12AffineEnvironment.transform 17 32160 env12507 = env12508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32160 env12507 == env12508) = true)

theorem identity12508 : scanCanonicalize (H12AffineFastState.compose env12508 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12508 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env12509 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,32040,1024,32769,4113,54561,29725,54530,8192,17,43277,24861,12557,35109,1284,21793,256,21792,46092,513]

theorem envBound12509 : H12AffineFastState.Bounded env12509 := by
  intro p hp
  have h : env12509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12508_12509 : H12AffineEnvironment.transform 6 8 env12508 = env12509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12508 == env12509) = true)

theorem identity12509 : scanCanonicalize (H12AffineFastState.compose env12509 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound12509 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env12510 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,8202,16400,32040,1024,8461,4113,29741,29725,29710,8192,17,2049,24861,12557,10281,1284,21793,256,21792,5376,513]

theorem envBound12510 : H12AffineFastState.Bounded env12510 := by
  intro p hp
  have h : env12510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12509_12510 : H12AffineEnvironment.transform 14 8460 env12509 = env12510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env12509 == env12510) = true)

theorem identity12510 : scanCanonicalize (H12AffineFastState.compose env12510 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12510 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12511 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8460,8202,5392,10280,1024,8461,4113,8493,8477,8462,8192,17,2049,13341,12557,10281,1284,33,256,32,5376,513]

theorem envBound12511 : H12AffineFastState.Bounded env12511 := by
  intro p hp
  have h : env12511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12510_12511 : H12AffineEnvironment.transform 13 5376 env12510 = env12511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12510 == env12511) = true)

theorem identity12511 : scanCanonicalize (H12AffineFastState.compose env12511 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound12511 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12512 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,1,263,5392,2341,1024,0,4113,32,16,3,269,17,2049,5392,4096,2340,1284,33,256,32,5376,513]

theorem envBound12512 : H12AffineFastState.Bounded env12512 := by
  intro p hp
  have h : env12512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12511_12512 : H12AffineEnvironment.transform 12 269 env12511 = env12512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env12511 == env12512) = true)

theorem identity12512 : scanCanonicalize (H12AffineFastState.compose env12512 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound12512 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12513 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,49,269,1329,1,263,1313,2341,1024,0,32,32,16,3,269,17,2049,1313,49,2340,1284,33,256,32,1329,513]

theorem envBound12513 : H12AffineFastState.Bounded env12513 := by
  intro p hp
  have h : env12513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12512_12513 : H12AffineEnvironment.transform 11 49 env12512 = env12513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env12512 == env12513) = true)

theorem identity12513 : scanCanonicalize (H12AffineFastState.compose env12513 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12513 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12514 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,1,35,1029,2049,1024,0,32,32,16,3,41,17,2049,1029,49,2048,1056,33,36,32,1045,513]

theorem envBound12514 : H12AffineFastState.Bounded env12514 := by
  intro p hp
  have h : env12514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12513_12514 : H12AffineEnvironment.transform 7 36 env12513 = env12514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12513 == env12514) = true)

theorem identity12514 : scanCanonicalize (H12AffineFastState.compose env12514 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12514 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12515 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,49,41,1045,1,35,1029,0,1024,0,32,32,16,3,41,17,0,1029,49,1,1056,33,36,32,1045,513]

theorem envBound12515 : H12AffineFastState.Bounded env12515 := by
  intro p hp
  have h : env12515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12514_12515 : H12AffineEnvironment.transform 10 1 env12514 = env12515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12514 == env12515) = true)

theorem identity12515 : scanCanonicalize (H12AffineFastState.compose env12515 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound12515 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12516 : List Nat := [2,4,8,16,32,16,8,36,512,565,1,49,41,544,1,35,560,0,565,0,32,32,16,3,41,17,0,560,49,1,533,33,36,32,544,513]

theorem envBound12516 : H12AffineFastState.Bounded env12516 := by
  intro p hp
  have h : env12516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12515_12516 : H12AffineEnvironment.transform 9 565 env12515 = env12516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env12515 == env12516) = true)

theorem identity12516 : scanCanonicalize (H12AffineFastState.compose env12516 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12516 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12517 : List Nat := [2,4,8,1,32,1,8,36,512,548,1,32,41,544,1,35,545,0,548,0,32,32,1,3,41,0,0,545,32,1,516,33,36,32,544,513]

theorem envBound12517 : H12AffineFastState.Bounded env12517 := by
  intro p hp
  have h : env12517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12516_12517 : H12AffineEnvironment.transform 3 1 env12516 = env12517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12516 == env12517) = true)

def env12518 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,4112,54561,264500,305314,8328,16,316588,269364,281636,35108,1421,272393,256,21792,46212,513]

theorem envBound12518 : H12AffineFastState.Bounded env12518 := by
  intro p hp
  have h : env12518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12506_12518 : H12AffineEnvironment.transform 5 17 env12506 = env12518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12506 == env12518) = true)

theorem identity12518 : scanCanonicalize (H12AffineFastState.compose env12518 (packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12518 : packedSelected [1,3,4,7,9,11,18,23,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env12519 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10280,1024,32769,4112,54561,8476,32906,8328,16,64644,13340,25612,35108,1421,33,256,21792,46212,513]

theorem envBound12519 : H12AffineFastState.Bounded env12519 := by
  intro p hp
  have h : env12519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12518_12519 : H12AffineEnvironment.transform 17 10280 env12518 = env12519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12518 == env12519) = true)

theorem identity12519 : scanCanonicalize (H12AffineFastState.compose env12519 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(14+1) ^^^ 9529) := by decide +kernel

theorem selectedBound12519 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env12520 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,9529,8202,16400,10280,1024,9528,4112,28696,8476,9651,8328,16,22973,13340,25612,11293,1421,33,256,21792,4541,513]

theorem envBound12520 : H12AffineFastState.Bounded env12520 := by
  intro p hp
  have h : env12520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12519_12520 : H12AffineEnvironment.transform 14 9529 env12519 = env12520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9529 env12519 == env12520) = true)

theorem identity12520 : scanCanonicalize (H12AffineFastState.compose env12520 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13728) := by decide +kernel

theorem selectedBound12520 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env12521 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13728,9529,8202,13744,10280,1024,9528,4112,1464,8476,9651,8328,16,11293,13340,4524,11293,1421,33,256,8320,4541,513]

theorem envBound12521 : H12AffineFastState.Bounded env12521 := by
  intro p hp
  have h : env12521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12520_12521 : H12AffineEnvironment.transform 13 13728 env12520 = env12521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13728 env12520 == env12521) = true)

theorem identity12521 : scanCanonicalize (H12AffineFastState.compose env12521 (packedSelected [3,5,10,11,12,15,17,23] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12521 : packedSelected [3,5,10,11,12,15,17,23] rootPS < 2^1333 := by decide +kernel

def env12522 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,8192,12465,8232,8202,12449,10280,273,8233,4112,169,8476,8354,8328,16,10508,12557,4524,10508,156,33,256,8320,4541,513]

theorem envBound12522 : H12AffineFastState.Bounded env12522 := by
  intro p hp
  have h : env12522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12521_12522 : H12AffineEnvironment.transform 9 273 env12521 = env12522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12521 == env12522) = true)

theorem identity12522 : scanCanonicalize (H12AffineFastState.compose env12522 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound12522 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12523 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,161,4112,137,171,4096,2185,273,136,4112,169,445,3,41,16,2477,4524,4524,2477,156,33,256,33,4541,513]

theorem envBound12523 : H12AffineFastState.Bounded env12523 := by
  intro p hp
  have h : env12523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12522_12523 : H12AffineEnvironment.transform 12 161 env12522 = env12523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env12522 == env12523) = true)

theorem identity12523 : scanCanonicalize (H12AffineFastState.compose env12523 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound12523 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12524 : List Nat := [2,4,8,16,32,17,128,172,512,189,2048,4096,161,4112,137,171,4096,2185,189,136,4112,169,17,3,41,16,2049,4096,4096,2049,156,33,172,33,4113,513]

theorem envBound12524 : H12AffineFastState.Bounded env12524 := by
  intro p hp
  have h : env12524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12523_12524 : H12AffineEnvironment.transform 7 172 env12523 = env12524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env12523 == env12524) = true)

theorem identity12524 : scanCanonicalize (H12AffineFastState.compose env12524 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12524 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12525 : List Nat := [2,4,8,1,32,0,128,172,512,172,2048,4096,161,4097,137,171,4096,2185,172,136,4097,169,0,3,41,1,2049,4096,4096,2049,141,33,172,33,4096,513]

theorem envBound12525 : H12AffineFastState.Bounded env12525 := by
  intro p hp
  have h : env12525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12524_12525 : H12AffineEnvironment.transform 3 1 env12524 = env12525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12524 == env12525) = true)

theorem identity12525 : scanCanonicalize (H12AffineFastState.compose env12525 (packedSelected [0,1,3] rootPS)) = affineNative (2^(11+1) ^^^ 649) := by decide +kernel

theorem selectedBound12525 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env12526 : List Nat := [2,4,8,1,32,0,128,172,512,172,2048,649,161,648,137,171,649,2185,172,136,648,169,0,3,41,1,2049,649,649,2049,141,33,172,33,649,513]

theorem envBound12526 : H12AffineFastState.Bounded env12526 := by
  intro p hp
  have h : env12526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12525_12526 : H12AffineEnvironment.transform 11 649 env12525 = env12526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 649 env12525 == env12526) = true)

theorem identity12526 : scanCanonicalize (H12AffineFastState.compose env12526 (packedSelected [0,1,5] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound12526 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env12527 : List Nat := [2,4,8,1,32,0,128,172,1,172,2048,136,161,137,137,171,136,2185,172,136,137,169,0,3,41,1,2049,136,136,2049,141,33,172,33,136,0]

theorem envBound12527 : H12AffineFastState.Bounded env12527 := by
  intro p hp
  have h : env12527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12526_12527 : H12AffineEnvironment.transform 8 1 env12526 = env12527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env12526 == env12527) = true)

theorem identity12527 : scanCanonicalize (H12AffineFastState.compose env12527 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12527 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12528 : List Nat := [2,4,8,1,32,0,8,36,1,36,2048,0,41,1,1,35,0,2049,36,0,1,33,0,3,41,1,2049,0,0,2049,5,33,36,33,0,0]

theorem envBound12528 : H12AffineFastState.Bounded env12528 := by
  intro p hp
  have h : env12528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12527_12528 : H12AffineEnvironment.transform 6 8 env12527 = env12528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12527 == env12528) = true)

theorem identity12528 : scanCanonicalize (H12AffineFastState.compose env12528 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12528 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12529 : List Nat := [2,4,2,1,32,0,2,36,1,36,2048,0,35,1,1,35,0,2049,36,0,1,33,0,3,35,1,2049,0,0,2049,5,33,36,33,0,0]

theorem envBound12529 : H12AffineFastState.Bounded env12529 := by
  intro p hp
  have h : env12529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12528_12529 : H12AffineEnvironment.transform 2 2 env12528 = env12529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12528 == env12529) = true)

def env12530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,4161,54560,264548,305315,8328,65,316669,269412,281716,35189,1500,272393,256,21792,46212,513]

theorem envBound12530 : H12AffineFastState.Bounded env12530 := by
  intro p hp
  have h : env12530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12505_12530 : H12AffineEnvironment.transform 16 16401 env12505 = env12530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env12505 == env12530) = true)

theorem identity12530 : scanCanonicalize (H12AffineFastState.compose env12530 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

end H12CloudChart1