import H12CloudChart1Data115

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity29407 : scanCanonicalize (H12AffineFastState.compose env29407 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29407 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env29408 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3109,41,3125,1077,1047,2064,2048,1025,1076,3124,33,16,1078,40,17,2049,3109,2064,2049,20,1045,37,33,2049,513]

theorem envBound29408 : H12AffineFastState.Bounded env29408 := by
  intro p hp
  have h : env29408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29407_29408 : H12AffineEnvironment.transform 5 17 env29407 = env29408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29407 == env29408) = true)

theorem identity29408 : scanCanonicalize (H12AffineFastState.compose env29408 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound29408 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env29409 : List Nat := [2,4,8,16,32,17,9,36,512,52,2048,2065,41,2049,1,35,2064,2048,53,0,2048,33,16,2,40,17,2049,2065,2064,2049,20,33,37,33,2049,513]

theorem envBound29409 : H12AffineFastState.Bounded env29409 := by
  intro p hp
  have h : env29409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29408_29409 : H12AffineEnvironment.transform 9 52 env29408 = env29409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env29408 == env29409) = true)

theorem identity29409 : scanCanonicalize (H12AffineFastState.compose env29409 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound29409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29410 : List Nat := [2,4,8,16,32,17,9,36,512,52,33,48,41,32,1,35,49,33,53,0,33,33,16,2,40,17,32,48,49,32,20,33,37,33,32,513]

theorem envBound29410 : H12AffineFastState.Bounded env29410 := by
  intro p hp
  have h : env29410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29409_29410 : H12AffineEnvironment.transform 10 33 env29409 = env29410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env29409 == env29410) = true)

theorem identity29410 : scanCanonicalize (H12AffineFastState.compose env29410 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound29410 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29411 : List Nat := [2,4,8,16,32,17,9,36,32,52,33,48,41,32,1,35,49,33,53,0,33,33,16,2,40,17,32,48,49,32,20,33,37,33,32,33]

theorem envBound29411 : H12AffineFastState.Bounded env29411 := by
  intro p hp
  have h : env29411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29410_29411 : H12AffineEnvironment.transform 8 32 env29410 = env29411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env29410 == env29411) = true)

theorem identity29411 : scanCanonicalize (H12AffineFastState.compose env29411 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound29411 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29412 : List Nat := [2,4,8,16,16,17,9,20,16,4,17,0,25,16,1,19,1,17,5,0,17,17,16,2,24,17,16,0,1,16,20,17,21,17,16,17]

theorem envBound29412 : H12AffineFastState.Bounded env29412 := by
  intro p hp
  have h : env29412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29411_29412 : H12AffineEnvironment.transform 4 16 env29411 = env29412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env29411 == env29412) = true)

theorem identity29412 : scanCanonicalize (H12AffineFastState.compose env29412 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29412 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29413 : List Nat := [2,4,8,0,0,1,9,4,0,4,1,0,9,0,1,3,1,1,5,0,1,1,0,2,8,1,0,0,1,0,4,1,5,1,0,1]

theorem envBound29413 : H12AffineFastState.Bounded env29413 := by
  intro p hp
  have h : env29413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29412_29413 : H12AffineEnvironment.transform 3 0 env29412 = env29413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29412 == env29413) = true)

def env29414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180224,169235,8328,64,4691218,115150,17664,262145,119043,4268163,257,213487,237643,63188]

theorem envBound29414 : H12AffineFastState.Bounded env29414 := by
  intro p hp
  have h : env29414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29341_29414 : H12AffineEnvironment.transform 20 184401 env29341 = env29414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env29341 == env29414) = true)

def env29415 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180224,169235,8328,64,245138,115150,17664,262145,119043,329731,257,213487,237643,63188]

theorem envBound29415 : H12AffineFastState.Bounded env29415 := by
  intro p hp
  have h : env29415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29414_29415 : H12AffineEnvironment.transform 21 272512 env29414 = env29415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29414 == env29415) = true)

theorem identity29415 : scanCanonicalize (H12AffineFastState.compose env29415 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound29415 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29416 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272512,17,21762,8328,64,97667,115150,17664,262145,119043,329731,257,98814,90202,63188]

theorem envBound29416 : H12AffineFastState.Bounded env29416 := by
  intro p hp
  have h : env29416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29415_29416 : H12AffineEnvironment.transform 16 49169 env29415 = env29416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29415 == env29416) = true)

def env29417 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21762,8192,64,97547,115014,17664,262145,119043,329731,257,98678,90202,63068]

theorem envBound29417 : H12AffineFastState.Bounded env29417 := by
  intro p hp
  have h : env29417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29416_29417 : H12AffineEnvironment.transform 6 8 env29416 = env29417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29416 == env29417) = true)

theorem identity29417 : scanCanonicalize (H12AffineFastState.compose env29417 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound29417 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29418 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56437,1025,32769,4160,62589,17,21762,8192,64,97547,115014,17664,56436,119043,119926,257,98678,90202,63068]

theorem envBound29418 : H12AffineFastState.Bounded env29418 := by
  intro p hp
  have h : env29418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29417_29418 : H12AffineEnvironment.transform 17 56437 env29417 = env29418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env29417 == env29418) = true)

theorem identity29418 : scanCanonicalize (H12AffineFastState.compose env29418 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound29418 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29419 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30043,49169,56437,1025,32769,4160,62589,17,21762,8192,64,2128,46109,17664,56436,42072,41261,257,62509,5377,63068]

theorem envBound29419 : H12AffineFastState.Bounded env29419 := by
  intro p hp
  have h : env29419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29418_29419 : H12AffineEnvironment.transform 15 30043 env29418 = env29419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env29418 == env29419) = true)

theorem identity29419 : scanCanonicalize (H12AffineFastState.compose env29419 (packedSelected [0,7,10,14,15,16,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound29419 : packedSelected [0,7,10,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env29420 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,30043,24909,32041,1025,8541,4160,21793,17,21762,8192,64,2128,5441,17664,32040,1284,113,257,21873,5377,22272]

theorem envBound29420 : H12AffineFastState.Bounded env29420 := by
  intro p hp
  have h : env29420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29419_29420 : H12AffineEnvironment.transform 14 8540 env29419 = env29420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env29419 == env29420) = true)

theorem identity29420 : scanCanonicalize (H12AffineFastState.compose env29420 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29420 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env29421 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8461,29962,24860,32041,1025,8460,4113,21793,17,21762,8192,17,2049,5392,17664,32040,1284,32,257,21792,5377,22272]

theorem envBound29421 : H12AffineFastState.Bounded env29421 := by
  intro p hp
  have h : env29421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29420_29421 : H12AffineEnvironment.transform 5 17 env29420 = env29421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29420 == env29421) = true)

theorem identity29421 : scanCanonicalize (H12AffineFastState.compose env29421 (packedSelected [1,2,6,8,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound29421 : packedSelected [1,2,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env29422 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,4405,8461,9279,12329,11292,1025,8460,4113,1044,17,1079,8192,17,2049,5392,5173,11293,1284,32,257,1045,5377,1589]

theorem envBound29422 : H12AffineFastState.Bounded env29422 := by
  intro p hp
  have h : env29422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29421_29422 : H12AffineEnvironment.transform 13 4405 env29421 = env29422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env29421 == env29422) = true)

theorem identity29422 : scanCanonicalize (H12AffineFastState.compose env29422 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound29422 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env29423 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,1336,4405,1077,263,5393,2340,1025,1076,4113,1044,17,1079,1336,17,2049,5392,5173,2341,1284,32,257,1045,5377,1589]

theorem envBound29423 : H12AffineFastState.Bounded env29423 := by
  intro p hp
  have h : env29423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29422_29423 : H12AffineEnvironment.transform 12 1336 env29422 = env29423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env29422 == env29423) = true)

theorem identity29423 : scanCanonicalize (H12AffineFastState.compose env29423 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound29423 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29424 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,0,1336,309,1077,263,1297,2340,1025,1076,17,1044,17,1079,1336,17,2049,1296,1077,2341,1284,32,257,1045,1281,1589]

theorem envBound29424 : H12AffineFastState.Bounded env29424 := by
  intro p hp
  have h : env29424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29423_29424 : H12AffineEnvironment.transform 11 0 env29423 = env29424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env29423 == env29424) = true)

theorem identity29424 : scanCanonicalize (H12AffineFastState.compose env29424 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound29424 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env29425 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,0,301,309,32,263,260,2340,20,33,17,1,17,34,301,17,2049,261,32,2341,273,32,257,0,276,544]

theorem envBound29425 : H12AffineFastState.Bounded env29425 := by
  intro p hp
  have h : env29425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29424_29425 : H12AffineEnvironment.transform 9 21 env29424 = env29425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env29424 == env29425) = true)

theorem identity29425 : scanCanonicalize (H12AffineFastState.compose env29425 (packedSelected [1,2,3,5,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29425 : packedSelected [1,2,3,5,8,10] rootPS < 2^1333 := by decide +kernel

def env29426 : List Nat := [2,4,8,16,17,17,8,256,512,21,2048,0,284,260,17,263,260,2325,20,16,17,1,17,19,284,17,2049,261,17,2324,273,17,257,0,276,529]

theorem envBound29426 : H12AffineFastState.Bounded env29426 := by
  intro p hp
  have h : env29426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29425_29426 : H12AffineEnvironment.transform 4 17 env29425 = env29426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29425 == env29426) = true)

theorem identity29426 : scanCanonicalize (H12AffineFastState.compose env29426 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29426 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env29427 : List Nat := [2,4,8,0,1,1,8,256,512,5,2048,0,268,260,1,263,260,2309,4,0,1,1,1,3,268,1,2049,261,1,2308,257,1,257,0,260,513]

theorem envBound29427 : H12AffineFastState.Bounded env29427 := by
  intro p hp
  have h : env29427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29426_29427 : H12AffineEnvironment.transform 3 0 env29426 = env29427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29426 == env29427) = true)

theorem identity29427 : scanCanonicalize (H12AffineFastState.compose env29427 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound29427 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29428 : List Nat := [2,4,8,0,1,1,8,256,260,5,2048,0,268,260,1,263,260,2309,4,0,1,1,1,3,268,1,2049,261,1,2308,257,1,257,0,260,261]

theorem envBound29428 : H12AffineFastState.Bounded env29428 := by
  intro p hp
  have h : env29428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29427_29428 : H12AffineEnvironment.transform 8 260 env29427 = env29428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env29427 == env29428) = true)

theorem identity29428 : scanCanonicalize (H12AffineFastState.compose env29428 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound29428 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29429 : List Nat := [2,4,8,0,1,1,8,256,260,5,1,0,268,260,1,263,260,260,4,0,1,1,1,3,268,1,0,261,1,261,257,1,257,0,260,261]

theorem envBound29429 : H12AffineFastState.Bounded env29429 := by
  intro p hp
  have h : env29429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29428_29429 : H12AffineEnvironment.transform 10 1 env29428 = env29429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env29428 == env29429) = true)

theorem identity29429 : scanCanonicalize (H12AffineFastState.compose env29429 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29429 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29430 : List Nat := [2,4,8,0,1,1,8,5,1,5,1,0,9,1,1,2,1,1,4,0,1,1,1,3,9,1,0,0,1,0,4,1,4,0,1,0]

theorem envBound29430 : H12AffineFastState.Bounded env29430 := by
  intro p hp
  have h : env29430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29429_29430 : H12AffineEnvironment.transform 7 5 env29429 = env29430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29429 == env29430) = true)

theorem identity29430 : scanCanonicalize (H12AffineFastState.compose env29430 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29431 : List Nat := [2,4,2,0,1,1,2,5,1,5,1,0,3,1,1,2,1,1,4,0,1,1,1,3,3,1,0,0,1,0,4,1,4,0,1,0]

theorem envBound29431 : H12AffineFastState.Bounded env29431 := by
  intro p hp
  have h : env29431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29430_29431 : H12AffineEnvironment.transform 2 2 env29430 = env29431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29430 == env29431) = true)

def env29432 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21762,8193,64,97546,115015,17664,262145,119043,329731,257,98679,90202,63069]

theorem envBound29432 : H12AffineFastState.Bounded env29432 := by
  intro p hp
  have h : env29432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29416_29432 : H12AffineEnvironment.transform 6 9 env29416 = env29432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29416 == env29432) = true)

theorem identity29432 : scanCanonicalize (H12AffineFastState.compose env29432 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound29432 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29433 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32041,1025,32769,4160,21792,17,21762,8193,64,97546,115015,17664,32040,119043,95530,257,98679,90202,63069]

theorem envBound29433 : H12AffineFastState.Bounded env29433 := by
  intro p hp
  have h : env29433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29432_29433 : H12AffineEnvironment.transform 17 32041 env29432 = env29433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env29432 == env29433) = true)

theorem identity29433 : scanCanonicalize (H12AffineFastState.compose env29433 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound29433 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29434 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8575,49169,32041,1025,32769,4160,21792,17,21762,8193,64,23669,57400,17664,32040,61564,21589,257,40968,16677,63069]

theorem envBound29434 : H12AffineFastState.Bounded env29434 := by
  intro p hp
  have h : env29434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29433_29434 : H12AffineEnvironment.transform 15 8575 env29433 = env29434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env29433 == env29434) = true)

theorem identity29434 : scanCanonicalize (H12AffineFastState.compose env29434 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29434 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env29435 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,35,49169,23669,1025,32769,4160,21792,17,21762,349,64,23669,49508,17664,23668,53536,21589,257,33108,16677,55041]

theorem envBound29435 : H12AffineFastState.Bounded env29435 := by
  intro p hp
  have h : env29435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29434_29435 : H12AffineEnvironment.transform 12 348 env29434 = env29435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29434 == env29435) = true)

theorem identity29435 : scanCanonicalize (H12AffineFastState.compose env29435 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound29435 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29436 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,35,5393,23669,1025,21761,4160,21792,17,21762,349,64,23669,5220,17664,23668,1056,21589,257,21588,16677,513]

theorem envBound29436 : H12AffineFastState.Bounded env29436 := by
  intro p hp
  have h : env29436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29435_29436 : H12AffineEnvironment.transform 14 21760 env29435 = env29436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env29435 == env29436) = true)

theorem identity29436 : scanCanonicalize (H12AffineFastState.compose env29436 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound29436 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29437 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,4113,1297,35,5393,3172,1025,1296,4160,1329,17,1299,349,64,3172,5220,5393,3173,1056,1092,257,1093,4404,513]

theorem envBound29437 : H12AffineFastState.Bounded env29437 := by
  intro p hp
  have h : env29437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29436_29437 : H12AffineEnvironment.transform 13 4113 env29436 = env29437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env29436 == env29437) = true)

theorem identity29437 : scanCanonicalize (H12AffineFastState.compose env29437 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29437 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29438 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,348,4113,373,35,4469,2048,101,372,4160,341,17,375,349,64,2048,4096,4469,2049,68,32,257,33,4404,513]

theorem envBound29438 : H12AffineFastState.Bounded env29438 := by
  intro p hp
  have h : env29438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29437_29438 : H12AffineEnvironment.transform 9 100 env29437 = env29438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29437 == env29438) = true)

theorem identity29438 : scanCanonicalize (H12AffineFastState.compose env29438 (packedSelected [0,1,3,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 2837) := by decide +kernel

theorem selectedBound29438 : packedSelected [0,1,3,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29439 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2837,348,2820,373,35,2656,2048,101,372,2901,341,17,375,349,64,2048,2837,2656,2049,68,32,257,33,2593,513]

theorem envBound29439 : H12AffineFastState.Bounded env29439 := by
  intro p hp
  have h : env29439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29438_29439 : H12AffineEnvironment.transform 11 2837 env29438 = env29439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2837 env29438 == env29439) = true)

theorem identity29439 : scanCanonicalize (H12AffineFastState.compose env29439 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound29439 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29440 : List Nat := [2,4,8,16,32,64,9,256,512,100,544,309,348,292,373,35,64,544,101,372,373,341,17,375,349,64,544,309,64,545,68,32,257,33,1,513]

theorem envBound29440 : H12AffineFastState.Bounded env29440 := by
  intro p hp
  have h : env29440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29439_29440 : H12AffineEnvironment.transform 10 544 env29439 = env29440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env29439 == env29440) = true)

theorem identity29440 : scanCanonicalize (H12AffineFastState.compose env29440 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(8+1) ^^^ 341) := by decide +kernel

theorem selectedBound29440 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env29441 : List Nat := [2,4,8,16,32,64,9,256,341,100,373,309,348,292,373,35,64,373,101,372,373,341,17,375,349,64,373,309,64,372,68,32,257,33,1,340]

theorem envBound29441 : H12AffineFastState.Bounded env29441 := by
  intro p hp
  have h : env29441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29440_29441 : H12AffineEnvironment.transform 8 341 env29440 = env29441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 341 env29440 == env29441) = true)

theorem identity29441 : scanCanonicalize (H12AffineFastState.compose env29441 (packedSelected [0,1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29441 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env29442 : List Nat := [2,4,8,16,32,16,9,256,261,52,293,309,268,292,293,35,16,293,53,292,293,261,17,295,269,16,293,309,16,292,20,32,257,33,1,260]

theorem envBound29442 : H12AffineFastState.Bounded env29442 := by
  intro p hp
  have h : env29442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29441_29442 : H12AffineEnvironment.transform 5 16 env29441 = env29442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29441 == env29442) = true)

theorem identity29442 : scanCanonicalize (H12AffineFastState.compose env29442 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29442 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env29443 : List Nat := [2,4,8,16,32,16,9,36,33,52,1,17,40,0,1,35,16,1,53,0,1,33,17,3,41,16,1,17,16,0,20,32,37,33,1,32]

theorem envBound29443 : H12AffineFastState.Bounded env29443 := by
  intro p hp
  have h : env29443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29442_29443 : H12AffineEnvironment.transform 7 36 env29442 = env29443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29442 == env29443) = true)

theorem identity29443 : scanCanonicalize (H12AffineFastState.compose env29443 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29443 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29444 : List Nat := [2,4,8,16,1,16,9,5,0,21,1,17,9,0,1,2,16,1,20,0,1,0,17,3,8,16,1,17,16,0,20,1,4,0,1,1]

theorem envBound29444 : H12AffineFastState.Bounded env29444 := by
  intro p hp
  have h : env29444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29443_29444 : H12AffineEnvironment.transform 4 1 env29443 = env29444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29443 == env29444) = true)

theorem identity29444 : scanCanonicalize (H12AffineFastState.compose env29444 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound29444 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29445 : List Nat := [2,4,8,11,1,11,9,5,0,14,1,10,9,0,1,2,11,1,15,0,1,0,10,3,8,11,1,10,11,0,15,1,4,0,1,1]

theorem envBound29445 : H12AffineFastState.Bounded env29445 := by
  intro p hp
  have h : env29445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29444_29445 : H12AffineEnvironment.transform 3 11 env29444 = env29445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env29444 == env29445) = true)

theorem identity29445 : scanCanonicalize (H12AffineFastState.compose env29445 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound29445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29446 : List Nat := [2,4,2,1,1,1,3,5,0,4,1,0,3,0,1,2,1,1,5,0,1,0,0,3,2,1,1,0,1,0,5,1,4,0,1,1]

theorem envBound29446 : H12AffineFastState.Bounded env29446 := by
  intro p hp
  have h : env29446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29445_29446 : H12AffineEnvironment.transform 2 2 env29445 = env29446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env29445 == env29446) = true)

def env29447 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180224,169235,8328,64,245139,115150,17664,262145,119043,329730,257,213487,237643,63188]

theorem envBound29447 : H12AffineFastState.Bounded env29447 := by
  intro p hp
  have h : env29447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29414_29447 : H12AffineEnvironment.transform 21 272513 env29414 = env29447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29414 == env29447) = true)

def env29448 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272393,180224,169235,8192,64,245019,115014,17664,262145,119043,329730,257,213351,237643,63068]

theorem envBound29448 : H12AffineFastState.Bounded env29448 := by
  intro p hp
  have h : env29448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29447_29448 : H12AffineEnvironment.transform 6 8 env29447 = env29448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29447 == env29448) = true)

def env29449 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272393,16,21763,8192,64,97547,115014,17664,262145,119043,329730,257,98679,90203,63068]

theorem envBound29449 : H12AffineFastState.Bounded env29449 := by
  intro p hp
  have h : env29449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29448_29449 : H12AffineEnvironment.transform 16 49168 env29448 = env29449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29448 == env29449) = true)

theorem identity29449 : scanCanonicalize (H12AffineFastState.compose env29449 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound29449 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29450 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,13389,262144,1025,29788,4161,272393,16,21763,8192,64,97547,79131,17664,262145,75102,329730,257,95530,90203,513]

theorem envBound29450 : H12AffineFastState.Bounded env29450 := by
  intro p hp
  have h : env29450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29449_29450 : H12AffineEnvironment.transform 14 29789 env29449 = env29450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env29449 == env29450) = true)

theorem identity29450 : scanCanonicalize (H12AffineFastState.compose env29450 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound29450 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29451 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21590,13389,262144,1025,29788,4161,272393,16,21763,8192,64,10589,24909,17664,262145,28936,285780,257,8572,13325,513]

theorem envBound29451 : H12AffineFastState.Bounded env29451 := by
  intro p hp
  have h : env29451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29450_29451 : H12AffineEnvironment.transform 15 21590 env29450 = env29451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env29450 == env29451) = true)

theorem identity29451 : scanCanonicalize (H12AffineFastState.compose env29451 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29451 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29452 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,5392,262144,1025,21761,4161,264532,16,21763,349,64,2048,16400,17664,262145,20565,285780,257,33,5456,513]

theorem envBound29452 : H12AffineFastState.Bounded env29452 := by
  intro p hp
  have h : env29452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29451_29452 : H12AffineEnvironment.transform 12 349 env29451 = env29452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29451 == env29452) = true)

theorem identity29452 : scanCanonicalize (H12AffineFastState.compose env29452 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound29452 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29453 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21590,5392,2420,1025,21761,4161,32,16,21763,349,64,2048,16400,17664,2421,20565,21792,257,33,5456,513]

theorem envBound29453 : H12AffineFastState.Bounded env29453 := by
  intro p hp
  have h : env29453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29452_29453 : H12AffineEnvironment.transform 17 2420 env29452 = env29453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env29452 == env29453) = true)

theorem identity29453 : scanCanonicalize (H12AffineFastState.compose env29453 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound29453 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29454 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4112,1296,1094,5392,2420,1025,1297,4161,32,16,1299,349,64,2048,4096,5392,2421,69,1328,257,33,5456,513]

theorem envBound29454 : H12AffineFastState.Bounded env29454 := by
  intro p hp
  have h : env29454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29453_29454 : H12AffineEnvironment.transform 13 4112 env29453 = env29454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env29453 == env29454) = true)

theorem identity29454 : scanCanonicalize (H12AffineFastState.compose env29454 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound29454 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env29455 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,349,4112,1296,1094,5392,1076,1025,1297,4161,32,16,1299,349,64,1344,4096,5392,1077,69,1328,257,33,5456,513]

theorem envBound29455 : H12AffineFastState.Bounded env29455 := by
  intro p hp
  have h : env29455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29454_29455 : H12AffineEnvironment.transform 10 1344 env29454 = env29455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env29454 == env29455) = true)

theorem identity29455 : scanCanonicalize (H12AffineFastState.compose env29455 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound29455 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29456 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,4096,349,4112,373,35,4469,81,100,372,4161,32,16,374,349,64,293,4096,4469,80,69,341,257,33,4405,513]

theorem envBound29456 : H12AffineFastState.Bounded env29456 := by
  intro p hp
  have h : env29456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29455_29456 : H12AffineEnvironment.transform 9 101 env29455 = env29456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env29455 == env29456) = true)

theorem identity29456 : scanCanonicalize (H12AffineFastState.compose env29456 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound29456 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29457 : List Nat := [2,4,8,16,32,64,8,256,512,101,293,357,349,373,373,35,16,81,100,372,292,32,16,374,349,64,293,357,16,80,69,341,257,33,80,513]

theorem envBound29457 : H12AffineFastState.Bounded env29457 := by
  intro p hp
  have h : env29457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29456_29457 : H12AffineEnvironment.transform 11 357 env29456 = env29457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env29456 == env29457) = true)

theorem identity29457 : scanCanonicalize (H12AffineFastState.compose env29457 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound29457 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env29458 : List Nat := [2,4,8,16,32,64,8,116,512,101,81,17,41,1,1,35,16,81,100,0,80,32,16,2,41,64,81,17,16,80,69,33,117,33,80,513]

theorem envBound29458 : H12AffineFastState.Bounded env29458 := by
  intro p hp
  have h : env29458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29457_29458 : H12AffineEnvironment.transform 7 116 env29457 = env29458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env29457 == env29458) = true)

theorem identity29458 : scanCanonicalize (H12AffineFastState.compose env29458 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 33) := by decide +kernel

theorem selectedBound29458 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29459 : List Nat := [2,4,8,16,32,33,8,21,512,4,48,17,41,1,1,35,16,48,5,0,49,32,16,2,41,33,48,17,16,49,36,33,20,33,49,513]

theorem envBound29459 : H12AffineFastState.Bounded env29459 := by
  intro p hp
  have h : env29459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29458_29459 : H12AffineEnvironment.transform 5 33 env29458 = env29459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 33 env29458 == env29459) = true)

def env29460 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272393,17,21762,8192,64,97546,115014,17664,262145,119043,329730,257,98678,90202,63068]

theorem envBound29460 : H12AffineFastState.Bounded env29460 := by
  intro p hp
  have h : env29460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29448_29460 : H12AffineEnvironment.transform 16 49169 env29448 = env29460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29448 == env29460) = true)

theorem identity29460 : scanCanonicalize (H12AffineFastState.compose env29460 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound29460 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29461 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,56437,1025,32769,4160,62588,17,21762,8192,64,97546,115014,17664,56436,119043,119927,257,98678,90202,63068]

theorem envBound29461 : H12AffineFastState.Bounded env29461 := by
  intro p hp
  have h : env29461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29460_29461 : H12AffineEnvironment.transform 17 56437 env29460 = env29461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env29460 == env29461) = true)

theorem identity29461 : scanCanonicalize (H12AffineFastState.compose env29461 (packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound29461 : packedSelected [1,2,4,5,6,8,9,10,11,15,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env29462 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,65536,49169,56437,1025,32769,4160,54640,17,21762,268,64,89094,115014,17664,56436,119043,119927,257,98678,82262,55120]

theorem envBound29462 : H12AffineFastState.Bounded env29462 := by
  intro p hp
  have h : env29462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29461_29462 : H12AffineEnvironment.transform 12 268 env29461 = env29462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env29461 == env29462) = true)

theorem identity29462 : scanCanonicalize (H12AffineFastState.compose env29462 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29462 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env29463 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,65536,49169,56357,1025,32769,4112,54560,17,21762,268,16,89094,114966,17664,56356,119043,119847,257,98598,82182,55040]

theorem envBound29463 : H12AffineFastState.Bounded env29463 := by
  intro p hp
  have h : env29463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29462_29463 : H12AffineEnvironment.transform 5 16 env29462 = env29463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29462 == env29463) = true)

theorem identity29463 : scanCanonicalize (H12AffineFastState.compose env29463 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound29463 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env29464 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,32768,33030,49169,56357,1025,32769,4112,54560,17,21762,268,16,56576,16400,17664,56356,20485,21793,257,32,49152,55040]

theorem envBound29464 : H12AffineFastState.Bounded env29464 := by
  intro p hp
  have h : env29464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29463_29464 : H12AffineEnvironment.transform 15 33030 env29463 = env29464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env29463 == env29464) = true)

theorem identity29464 : scanCanonicalize (H12AffineFastState.compose env29464 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29464 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env29465 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,1,263,16400,23588,1025,0,4112,21793,17,21762,268,16,23809,16400,17664,23589,20485,21793,257,32,16385,22273]

theorem envBound29465 : H12AffineFastState.Bounded env29465 := by
  intro p hp
  have h : env29465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29464_29465 : H12AffineEnvironment.transform 14 1 env29464 = env29465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29464 == env29465) = true)

theorem identity29465 : scanCanonicalize (H12AffineFastState.compose env29465 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound29465 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env29466 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5156,1,263,5172,2048,1025,0,4112,261,17,294,268,16,2341,5172,4388,2049,1057,261,257,32,5157,805]

theorem envBound29466 : H12AffineFastState.Bounded env29466 := by
  intro p hp
  have h : env29466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29465_29466 : H12AffineEnvironment.transform 13 5156 env29465 = env29466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env29465 == env29466) = true)

theorem identity29466 : scanCanonicalize (H12AffineFastState.compose env29466 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound29466 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29467 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3108,268,2048,1,263,2064,2048,1025,0,3124,261,17,294,268,16,2341,2064,3328,2049,1057,261,257,32,2049,805]

theorem envBound29467 : H12AffineFastState.Bounded env29467 := by
  intro p hp
  have h : env29467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29466_29467 : H12AffineEnvironment.transform 11 3108 env29466 = env29467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env29466 == env29467) = true)

theorem identity29467 : scanCanonicalize (H12AffineFastState.compose env29467 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29467 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env29468 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,3108,41,2048,1,34,2064,2048,1025,0,3124,32,17,3,41,16,2048,2064,3109,2049,1057,32,36,32,2049,512]

theorem envBound29468 : H12AffineFastState.Bounded env29468 := by
  intro p hp
  have h : env29468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29467_29468 : H12AffineEnvironment.transform 7 37 env29467 = env29468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29467 == env29468) = true)

theorem identity29468 : scanCanonicalize (H12AffineFastState.compose env29468 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound29468 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29469 : List Nat := [2,4,8,16,32,16,8,37,512,20,2048,2096,41,2048,1,34,2064,2048,21,0,2080,32,17,3,41,16,2048,2064,2097,2049,53,32,36,32,2049,512]

theorem envBound29469 : H12AffineFastState.Bounded env29469 := by
  intro p hp
  have h : env29469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29468_29469 : H12AffineEnvironment.transform 9 20 env29468 = env29469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29468 == env29469) = true)

theorem identity29469 : scanCanonicalize (H12AffineFastState.compose env29469 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound29469 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29470 : List Nat := [2,4,8,16,32,16,8,37,42,20,2048,2096,41,2048,1,34,2064,2048,21,0,2080,32,17,3,41,16,2048,2064,2097,2049,53,32,36,32,2049,42]

theorem envBound29470 : H12AffineFastState.Bounded env29470 := by
  intro p hp
  have h : env29470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29469_29470 : H12AffineEnvironment.transform 8 42 env29469 = env29470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env29469 == env29470) = true)

theorem identity29470 : scanCanonicalize (H12AffineFastState.compose env29470 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 28) := by decide +kernel

theorem selectedBound29470 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29471 : List Nat := [2,4,8,16,32,16,8,37,42,20,28,44,41,28,1,34,12,28,21,0,60,32,17,3,41,16,28,12,45,29,53,32,36,32,29,42]

theorem envBound29471 : H12AffineFastState.Bounded env29471 := by
  intro p hp
  have h : env29471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29470_29471 : H12AffineEnvironment.transform 10 28 env29470 = env29471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 28 env29470 == env29471) = true)

theorem identity29471 : scanCanonicalize (H12AffineFastState.compose env29471 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound29471 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29472 : List Nat := [2,4,8,16,28,16,8,25,22,20,28,16,21,28,1,30,12,28,21,0,0,28,17,3,21,16,28,12,17,29,9,28,24,28,29,22]

theorem envBound29472 : H12AffineFastState.Bounded env29472 := by
  intro p hp
  have h : env29472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29471_29472 : H12AffineEnvironment.transform 4 28 env29471 = env29472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env29471 == env29472) = true)

theorem identity29472 : scanCanonicalize (H12AffineFastState.compose env29472 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound29472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29473 : List Nat := [2,4,8,9,5,9,8,0,15,13,5,9,12,5,1,7,12,5,12,0,0,5,8,3,12,9,5,12,8,4,9,5,1,5,4,15]

theorem envBound29473 : H12AffineFastState.Bounded env29473 := by
  intro p hp
  have h : env29473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29472_29473 : H12AffineEnvironment.transform 3 9 env29472 = env29473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env29472 == env29473) = true)

theorem identity29473 : scanCanonicalize (H12AffineFastState.compose env29473 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29473 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env29474 : List Nat := [2,1,8,9,0,9,8,0,10,8,0,9,9,0,1,2,9,0,9,0,0,0,8,3,9,9,0,9,8,1,9,0,1,0,1,10]

theorem envBound29474 : H12AffineFastState.Bounded env29474 := by
  intro p hp
  have h : env29474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29473_29474 : H12AffineEnvironment.transform 1 1 env29473 = env29474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29473 == env29474) = true)

def env29475 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272392,180224,169235,8193,64,245018,115015,17664,262145,119043,329730,257,213350,237643,63069]

theorem envBound29475 : H12AffineFastState.Bounded env29475 := by
  intro p hp
  have h : env29475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29447_29475 : H12AffineEnvironment.transform 6 9 env29447 = env29475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29447 == env29475) = true)

def env29476 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1025,32769,4161,272392,16,21763,8193,64,97546,115015,17664,262145,119043,329730,257,98678,90203,63069]

theorem envBound29476 : H12AffineFastState.Bounded env29476 := by
  intro p hp
  have h : env29476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29475_29476 : H12AffineEnvironment.transform 16 49168 env29475 = env29476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29475 == env29476) = true)

theorem identity29476 : scanCanonicalize (H12AffineFastState.compose env29476 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29476 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29477 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,262144,1025,32769,4161,272392,16,3,8193,64,75786,103495,4096,262145,99331,329730,257,98678,79195,41821]

theorem envBound29477 : H12AffineFastState.Bounded env29477 := by
  intro p hp
  have h : env29477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29476_29477 : H12AffineEnvironment.transform 13 5376 env29476 = env29477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29476 == env29477) = true)

theorem identity29477 : scanCanonicalize (H12AffineFastState.compose env29477 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 10360) := by decide +kernel

theorem selectedBound29477 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env29478 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,38160,10360,1025,32769,4161,112,16,3,8193,64,75786,103495,4096,10361,99331,73850,257,98678,79195,41821]

theorem envBound29478 : H12AffineFastState.Bounded env29478 := by
  intro p hp
  have h : env29478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29477_29478 : H12AffineEnvironment.transform 17 10360 env29477 = env29478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10360 env29477 == env29478) = true)

theorem identity29478 : scanCanonicalize (H12AffineFastState.compose env29478 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound29478 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env29479 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,32768,65536,38160,2049,1025,32769,4161,112,16,3,120,64,67699,103495,4096,2048,99331,65539,257,98678,70946,33572]

theorem envBound29479 : H12AffineFastState.Bounded env29479 := by
  intro p hp
  have h : env29479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29478_29479 : H12AffineEnvironment.transform 12 121 env29478 = env29479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env29478 == env29479) = true)

theorem identity29479 : scanCanonicalize (H12AffineFastState.compose env29479 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound29479 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29480 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,81,65536,5441,2049,1025,80,4161,112,16,3,120,64,67699,70678,4096,2048,66642,65539,257,65831,70946,885]

theorem envBound29480 : H12AffineFastState.Bounded env29480 := by
  intro p hp
  have h : env29480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29479_29480 : H12AffineEnvironment.transform 14 81 env29479 = env29480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env29479 == env29480) = true)

theorem identity29480 : scanCanonicalize (H12AffineFastState.compose env29480 (packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound29480 : packedSelected [1,3,4,5,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env29481 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5376,81,343,5441,2049,1025,80,4161,112,16,3,120,64,2340,5441,4096,2048,1285,340,257,112,5237,885]

theorem envBound29481 : H12AffineFastState.Bounded env29481 := by
  intro p hp
  have h : env29481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29480_29481 : H12AffineEnvironment.transform 15 343 env29480 = env29481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env29480 == env29481) = true)

def env29482 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,4160,272392,17,21762,8193,64,97547,115015,17664,262145,119043,329730,257,98679,90202,63069]

theorem envBound29482 : H12AffineFastState.Bounded env29482 := by
  intro p hp
  have h : env29482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29475_29482 : H12AffineEnvironment.transform 16 49169 env29475 = env29482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29475 == env29482) = true)

theorem identity29482 : scanCanonicalize (H12AffineFastState.compose env29482 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound29482 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29483 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,32041,1025,32769,4160,21793,17,21762,8193,64,97547,115015,17664,32040,119043,95531,257,98679,90202,63069]

theorem envBound29483 : H12AffineFastState.Bounded env29483 := by
  intro p hp
  have h : env29483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29482_29483 : H12AffineEnvironment.transform 17 32041 env29482 = env29483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env29482 == env29483) = true)

theorem identity29483 : scanCanonicalize (H12AffineFastState.compose env29483 (packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 32883) := by decide +kernel

theorem selectedBound29483 : packedSelected [0,1,4,5,12,14,15,19,20,22,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env29484 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,32883,49169,32041,1025,32769,4160,21793,17,21762,8193,64,64888,16692,17664,32040,20848,62808,257,260,57385,63069]

theorem envBound29484 : H12AffineFastState.Bounded env29484 := by
  intro p hp
  have h : env29484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29483_29484 : H12AffineEnvironment.transform 15 32883 env29483 = env29484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 32883 env29483 == env29484) = true)

theorem identity29484 : scanCanonicalize (H12AffineFastState.compose env29484 (packedSelected [4,9,14,19,20,26] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound29484 : packedSelected [4,9,14,19,20,26] rootPS < 2^1333 := by decide +kernel

def env29485 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,21795,5441,32041,1025,21841,4160,21793,17,21762,8193,64,10280,16692,17664,32040,20848,8200,257,260,13689,8973]

theorem envBound29485 : H12AffineFastState.Bounded env29485 := by
  intro p hp
  have h : env29485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29484_29485 : H12AffineEnvironment.transform 14 21840 env29484 = env29485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env29484 == env29485) = true)

theorem identity29485 : scanCanonicalize (H12AffineFastState.compose env29485 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29485 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env29486 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,21760,21795,5393,32041,1025,21761,4112,21793,17,21762,8193,16,10280,16692,17664,32040,20768,8200,257,260,13609,8973]

theorem envBound29486 : H12AffineFastState.Bounded env29486 := by
  intro p hp
  have h : env29486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29485_29486 : H12AffineEnvironment.transform 5 16 env29485 = env29486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29485 == env29486) = true)

theorem identity29486 : scanCanonicalize (H12AffineFastState.compose env29486 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound29486 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29487 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13324,8460,8495,5393,2341,1025,8461,4112,8493,17,8462,8193,16,10280,13624,12556,2340,9516,8200,257,260,13609,8973]

theorem envBound29487 : H12AffineFastState.Bounded env29487 := by
  intro p hp
  have h : env29487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29486_29487 : H12AffineEnvironment.transform 13 13324 env29486 = env29487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env29486 == env29487) = true)

def env29488 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,180225,2114883,8328,64,6636867,115151,2266448,262144,2294098,4268162,257,213487,237643,2238085]

theorem envBound29488 : H12AffineFastState.Bounded env29488 := by
  intro p hp
  have h : env29488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29340_29488 : H12AffineEnvironment.transform 22 180225 env29340 = env29488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 180225 env29340 == env29488) = true)

def env29489 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,4194304,180225,169235,8328,64,4691219,115151,17664,262144,119042,4268162,257,213487,237643,63189]

theorem envBound29489 : H12AffineFastState.Bounded env29489 := by
  intro p hp
  have h : env29489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29488_29489 : H12AffineEnvironment.transform 20 184400 env29488 = env29489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184400 env29488 == env29489) = true)

def env29490 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272512,180225,169235,8328,64,245139,115151,17664,262144,119042,329730,257,213487,237643,63189]

theorem envBound29490 : H12AffineFastState.Bounded env29490 := by
  intro p hp
  have h : env29490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29489_29490 : H12AffineEnvironment.transform 21 272512 env29489 = env29490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29489 == env29490) = true)

theorem identity29490 : scanCanonicalize (H12AffineFastState.compose env29490 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound29490 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29491 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,184400,272512,180225,169235,8328,64,158029,5393,17664,262144,1500,318684,257,169265,160917,63189]

theorem envBound29491 : H12AffineFastState.Bounded env29491 := by
  intro p hp
  have h : env29491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29490_29491 : H12AffineEnvironment.transform 15 54494 env29490 = env29491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env29490 == env29491) = true)

theorem identity29491 : scanCanonicalize (H12AffineFastState.compose env29491 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound29491 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env29492 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,262144,1025,29909,140420,272512,144597,156103,8328,64,158029,5393,17664,262144,1500,272392,257,156133,160917,513]

theorem envBound29492 : H12AffineFastState.Bounded env29492 := by
  intro p hp
  have h : env29492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29491_29492 : H12AffineEnvironment.transform 14 29908 env29491 = env29492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env29491 == env29492) = true)

theorem identity29492 : scanCanonicalize (H12AffineFastState.compose env29492 (packedSelected [7,14,16,27] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound29492 : packedSelected [7,14,16,27] rootPS < 2^1333 := by decide +kernel

def env29493 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,2557,1025,29909,140420,8573,144597,156103,8328,64,158029,5393,17664,2557,1500,8693,257,156133,160917,513]

theorem envBound29493 : H12AffineFastState.Bounded env29493 := by
  intro p hp
  have h : env29493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29492_29493 : H12AffineEnvironment.transform 17 2557 env29492 = env29493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env29492 == env29493) = true)

theorem identity29493 : scanCanonicalize (H12AffineFastState.compose env29493 (packedSelected [1,5,8,11,17,18,23,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound29493 : packedSelected [1,5,8,11,17,18,23,24,32] rootPS < 2^1333 := by decide +kernel

def env29494 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,8202,131072,2557,1025,1,140420,8573,144597,136467,8328,64,138649,5393,12756,2557,1500,8693,257,136497,131137,513]

theorem envBound29494 : H12AffineFastState.Bounded env29494 := by
  intro p hp
  have h : env29494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29493_29494 : H12AffineEnvironment.transform 13 13524 env29493 = env29494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env29493 == env29494) = true)

theorem identity29494 : scanCanonicalize (H12AffineFastState.compose env29494 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound29494 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env29495 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,0,8202,5528,2557,1025,1,12572,8573,8525,139,8328,64,2049,5393,12756,2557,1500,8693,257,169,5593,513]

theorem envBound29495 : H12AffineFastState.Bounded env29495 := by
  intro p hp
  have h : env29495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29494_29495 : H12AffineEnvironment.transform 16 5528 env29494 = env29495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env29494 == env29495) = true)

theorem identity29495 : scanCanonicalize (H12AffineFastState.compose env29495 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound29495 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env29496 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2049,8192,11477,0,8202,3481,2557,1025,1,10525,8573,8525,139,8328,64,2049,3344,10709,2557,1500,8693,257,169,3544,513]

theorem envBound29496 : H12AffineFastState.Bounded env29496 := by
  intro p hp
  have h : env29496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29495_29496 : H12AffineEnvironment.transform 11 2049 env29495 = env29496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env29495 == env29496) = true)

theorem identity29496 : scanCanonicalize (H12AffineFastState.compose env29496 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29496 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env29497 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2049,8192,11357,0,8202,3345,2421,1025,1,10525,8573,8525,3,8192,64,2049,3344,10589,2421,1364,8573,257,33,3408,513]

theorem envBound29497 : H12AffineFastState.Bounded env29497 := by
  intro p hp
  have h : env29497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29496_29497 : H12AffineEnvironment.transform 6 8 env29496 = env29497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29496 == env29497) = true)

theorem identity29497 : scanCanonicalize (H12AffineFastState.compose env29497 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29497 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env29498 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2049,348,3329,0,342,3345,2421,1025,1,2113,33,17,3,348,64,2049,3344,2049,2421,1364,33,257,33,3408,513]

theorem envBound29498 : H12AffineFastState.Bounded env29498 := by
  intro p hp
  have h : env29498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29497_29498 : H12AffineEnvironment.transform 12 348 env29497 = env29498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29497 == env29498) = true)

theorem identity29498 : scanCanonicalize (H12AffineFastState.compose env29498 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound29498 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29499 : List Nat := [2,4,8,16,32,64,8,256,512,46,2048,2049,348,2351,0,342,2367,2421,47,1,2113,33,17,3,348,64,2049,2366,2049,2421,378,33,257,33,2430,513]

theorem envBound29499 : H12AffineFastState.Bounded env29499 := by
  intro p hp
  have h : env29499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29498_29499 : H12AffineEnvironment.transform 9 46 env29498 = env29499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env29498 == env29499) = true)

theorem identity29499 : scanCanonicalize (H12AffineFastState.compose env29499 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound29499 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env29500 : List Nat := [2,4,8,16,32,64,8,62,512,46,2048,2049,98,2065,0,104,2049,2123,47,1,2113,33,17,3,98,64,2049,2048,2049,2123,68,33,63,33,2112,513]

theorem envBound29500 : H12AffineFastState.Bounded env29500 := by
  intro p hp
  have h : env29500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29499_29500 : H12AffineEnvironment.transform 7 62 env29499 = env29500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env29499 == env29500) = true)

theorem identity29500 : scanCanonicalize (H12AffineFastState.compose env29500 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 27) := by decide +kernel

theorem selectedBound29500 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29501 : List Nat := [2,4,8,16,32,27,8,62,512,46,2048,2049,57,2065,0,51,2049,2064,47,1,2074,33,17,3,57,27,2049,2048,2049,2064,31,33,63,33,2075,513]

theorem envBound29501 : H12AffineFastState.Bounded env29501 := by
  intro p hp
  have h : env29501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29500_29501 : H12AffineEnvironment.transform 5 27 env29500 = env29501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 27 env29500 == env29501) = true)

theorem identity29501 : scanCanonicalize (H12AffineFastState.compose env29501 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 530) := by decide +kernel

theorem selectedBound29501 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env29502 : List Nat := [2,4,8,16,32,27,8,62,512,46,530,531,57,515,0,51,531,514,47,1,520,33,17,3,57,27,531,530,531,514,31,33,63,33,521,513]

theorem envBound29502 : H12AffineFastState.Bounded env29502 := by
  intro p hp
  have h : env29502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29501_29502 : H12AffineEnvironment.transform 10 530 env29501 = env29502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 530 env29501 == env29502) = true)

theorem identity29502 : scanCanonicalize (H12AffineFastState.compose env29502 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound29502 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env29503 : List Nat := [2,4,3,16,32,16,3,53,512,37,530,531,50,515,0,51,531,514,36,1,515,33,17,3,50,16,531,530,531,514,20,33,52,33,514,513]

theorem envBound29503 : H12AffineFastState.Bounded env29503 := by
  intro p hp
  have h : env29503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29502_29503 : H12AffineEnvironment.transform 2 3 env29502 = env29503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env29502 == env29503) = true)

theorem identity29503 : scanCanonicalize (H12AffineFastState.compose env29503 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound29503 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29504 : List Nat := [2,4,3,16,1,16,3,20,512,4,530,531,19,515,0,18,531,514,5,1,515,0,17,3,19,16,531,530,531,514,20,0,21,0,514,513]

theorem envBound29504 : H12AffineFastState.Bounded env29504 := by
  intro p hp
  have h : env29504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29503_29504 : H12AffineEnvironment.transform 4 1 env29503 = env29504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env29503 == env29504) = true)

def env29505 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184400,272513,180225,169235,8328,64,245138,115151,17664,262144,119042,329731,257,213487,237643,63189]

theorem envBound29505 : H12AffineFastState.Bounded env29505 := by
  intro p hp
  have h : env29505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29489_29505 : H12AffineEnvironment.transform 21 272513 env29489 = env29505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29489 == env29505) = true)

theorem identity29505 : scanCanonicalize (H12AffineFastState.compose env29505 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound29505 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29506 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,262144,1025,32769,115870,272513,120015,98781,8328,64,43356,115151,17664,262144,119042,329731,257,21793,46213,63189]

theorem envBound29506 : H12AffineFastState.Bounded env29506 := by
  intro p hp
  have h : env29506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29505_29506 : H12AffineEnvironment.transform 16 70862 env29505 = env29506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env29505 == env29506) = true)

theorem identity29506 : scanCanonicalize (H12AffineFastState.compose env29506 (packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 76158) := by decide +kernel

theorem selectedBound29506 : packedSelected [1,3,10,12,15,16,17,19,20,24,26,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env29507 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70862,76158,1025,32769,115870,66047,120015,98781,8328,64,43356,115151,17664,76158,119042,8573,257,21793,46213,63189]

theorem envBound29507 : H12AffineFastState.Bounded env29507 := by
  intro p hp
  have h : env29507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29506_29507 : H12AffineEnvironment.transform 17 76158 env29506 = env29507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76158 env29506 == env29507) = true)

def env29508 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70726,76158,1025,32769,115734,65911,119879,98645,8192,64,43356,115015,17664,76158,119042,8573,257,21793,46093,63069]

theorem envBound29508 : H12AffineFastState.Bounded env29508 := by
  intro p hp
  have h : env29508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29507_29508 : H12AffineEnvironment.transform 6 8 env29507 = env29508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29507 == env29508) = true)

theorem identity29508 : scanCanonicalize (H12AffineFastState.compose env29508 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound29508 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29509 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,70726,76158,1025,29789,77898,65911,73755,95497,8192,64,23808,79131,17664,76158,75102,8573,257,21793,16465,513]

theorem envBound29509 : H12AffineFastState.Bounded env29509 := by
  intro p hp
  have h : env29509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29508_29509 : H12AffineEnvironment.transform 14 29788 env29508 = env29509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env29508 == env29509) = true)

theorem identity29509 : scanCanonicalize (H12AffineFastState.compose env29509 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29509 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env29510 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8541,65536,70726,76158,1025,8540,77898,65911,73755,73736,8192,64,2049,79131,4097,76158,75102,8573,257,32,5456,513]

theorem envBound29510 : H12AffineFastState.Bounded env29510 := by
  intro p hp
  have h : env29510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29509_29510 : H12AffineEnvironment.transform 13 5377 env29509 = env29510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29509 == env29510) = true)

theorem identity29510 : scanCanonicalize (H12AffineFastState.compose env29510 (packedSelected [2,6,17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29510 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env29511 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,65536,70726,67618,1025,0,69910,65911,65863,65876,348,64,2049,70727,4097,67618,66562,33,257,32,5456,513]

theorem envBound29511 : H12AffineFastState.Bounded env29511 := by
  intro p hp
  have h : env29511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29510_29511 : H12AffineEnvironment.transform 12 348 env29510 = env29511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29510 == env29511) = true)

theorem identity29511 : scanCanonicalize (H12AffineFastState.compose env29511 (packedSelected [0,7,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1345) := by decide +kernel

theorem selectedBound29511 : packedSelected [0,7,12,15] rootPS < 2^1333 := by decide +kernel

def env29512 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,348,5377,1,65536,70726,66915,1025,0,69910,65911,65863,65876,348,64,1344,70727,4097,66915,66562,33,257,32,5456,513]

theorem envBound29512 : H12AffineFastState.Bounded env29512 := by
  intro p hp
  have h : env29512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29511_29512 : H12AffineEnvironment.transform 10 1345 env29511 = env29512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env29511 == env29512) = true)

theorem identity29512 : scanCanonicalize (H12AffineFastState.compose env29512 (packedSelected [0,1,4,5,7,9,10,18] rootPS)) = affineNative (2^(15+1) ^^^ 5206) := by decide +kernel

theorem selectedBound29512 : packedSelected [0,1,4,5,7,9,10,18] rootPS < 2^1333 := by decide +kernel

def env29513 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,4096,348,5377,1,5206,16,4405,1025,0,1344,5409,5393,5378,348,64,1344,17,4097,4405,4180,33,257,32,5456,513]

theorem envBound29513 : H12AffineFastState.Bounded env29513 := by
  intro p hp
  have h : env29513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29512_29513 : H12AffineEnvironment.transform 15 5206 env29512 = env29513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 5206 env29512 == env29513) = true)

theorem identity29513 : scanCanonicalize (H12AffineFastState.compose env29513 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound29513 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env29514 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1345,1361,348,80,1,263,16,1124,1025,0,1344,112,64,83,348,64,1344,17,1360,1124,1285,33,257,32,1,513]

theorem envBound29514 : H12AffineFastState.Bounded env29514 := by
  intro p hp
  have h : env29514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29513_29514 : H12AffineEnvironment.transform 11 1361 env29513 = env29514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env29513 == env29514) = true)

theorem identity29514 : scanCanonicalize (H12AffineFastState.compose env29514 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29514 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env29515 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1297,1281,268,0,1,263,16,1076,1025,0,1296,32,16,3,268,16,1296,17,1280,1076,1285,33,257,32,1,513]

theorem envBound29515 : H12AffineFastState.Bounded env29515 := by
  intro p hp
  have h : env29515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29514_29515 : H12AffineEnvironment.transform 5 16 env29514 = env29515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29514 == env29515) = true)

theorem identity29515 : scanCanonicalize (H12AffineFastState.compose env29515 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound29515 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29516 : List Nat := [2,4,8,16,32,16,8,256,512,272,1,17,268,0,1,263,16,292,273,0,0,32,16,3,268,16,0,17,16,292,21,33,257,32,1,513]

theorem envBound29516 : H12AffineFastState.Bounded env29516 := by
  intro p hp
  have h : env29516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29515_29516 : H12AffineEnvironment.transform 9 272 env29515 = env29516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env29515 == env29516) = true)

theorem identity29516 : scanCanonicalize (H12AffineFastState.compose env29516 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound29516 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29517 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,17,40,0,1,35,16,0,53,0,0,32,16,3,40,16,0,17,16,0,21,33,37,32,1,513]

theorem envBound29517 : H12AffineFastState.Bounded env29517 := by
  intro p hp
  have h : env29517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29516_29517 : H12AffineEnvironment.transform 7 36 env29516 = env29517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env29516 == env29517) = true)

theorem identity29517 : scanCanonicalize (H12AffineFastState.compose env29517 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29517 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29518 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,17,8,0,1,3,16,0,21,0,0,0,16,3,8,16,0,17,16,0,21,1,5,0,1,513]

theorem envBound29518 : H12AffineFastState.Bounded env29518 := by
  intro p hp
  have h : env29518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29517_29518 : H12AffineEnvironment.transform 4 0 env29517 = env29518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29517 == env29518) = true)

theorem identity29518 : scanCanonicalize (H12AffineFastState.compose env29518 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29518 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29519 : List Nat := [2,4,8,1,0,1,8,4,512,5,1,0,8,0,1,3,1,0,4,0,0,0,1,3,8,1,0,0,1,0,4,1,5,0,1,513]

theorem envBound29519 : H12AffineFastState.Bounded env29519 := by
  intro p hp
  have h : env29519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29518_29519 : H12AffineEnvironment.transform 3 1 env29518 = env29519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29518 == env29519) = true)

def env29520 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,76158,1025,32769,115735,65910,119878,98644,8193,64,43356,115014,17664,76158,119042,8573,257,21793,46092,63068]

theorem envBound29520 : H12AffineFastState.Bounded env29520 := by
  intro p hp
  have h : env29520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29507_29520 : H12AffineEnvironment.transform 6 9 env29507 = env29520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29507 == env29520) = true)

theorem identity29520 : scanCanonicalize (H12AffineFastState.compose env29520 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound29520 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env29521 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,65536,70727,76158,1025,0,82966,65910,87111,65877,8193,64,10589,82247,17664,76158,86275,8573,257,21793,13325,30301]

theorem envBound29521 : H12AffineFastState.Bounded env29521 := by
  intro p hp
  have h : env29521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29520_29521 : H12AffineEnvironment.transform 14 1 env29520 = env29521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env29520 == env29521) = true)

theorem identity29521 : scanCanonicalize (H12AffineFastState.compose env29521 (packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound29521 : packedSelected [1,3,4,8,9,10,12,14,15,16,17,18,23,24] rootPS < 2^1333 := by decide +kernel

def env29522 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,29822,24633,23808,1025,0,12392,29960,8249,29995,8193,64,10589,13625,17664,23808,9597,8573,257,21793,13325,30301]

theorem envBound29522 : H12AffineFastState.Bounded env29522 := by
  intro p hp
  have h : env29522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29521_29522 : H12AffineEnvironment.transform 15 29822 env29521 = env29522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env29521 == env29522) = true)

theorem identity29522 : scanCanonicalize (H12AffineFastState.compose env29522 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound29522 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29523 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,34,5221,10588,1025,0,12392,340,8249,375,8193,64,10589,13625,12636,10588,9597,8573,257,8573,13325,513]

theorem envBound29523 : H12AffineFastState.Bounded env29523 := by
  intro p hp
  have h : env29523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29522_29523 : H12AffineEnvironment.transform 13 13404 env29522 = env29523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env29522 == env29523) = true)

theorem identity29523 : scanCanonicalize (H12AffineFastState.compose env29523 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound29523 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29524 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4113,1,34,5221,3345,1025,0,5157,340,1140,375,1100,64,3344,4468,5393,3345,304,1328,257,1328,4160,513]

theorem envBound29524 : H12AffineFastState.Bounded env29524 := by
  intro p hp
  have h : env29524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29523_29524 : H12AffineEnvironment.transform 12 1101 env29523 = env29524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env29523 == env29524) = true)

theorem identity29524 : scanCanonicalize (H12AffineFastState.compose env29524 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound29524 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env29525 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,41,4113,1,34,4097,2421,101,0,4161,340,16,375,40,64,2420,4468,4469,2421,304,340,257,340,4160,513]

theorem envBound29525 : H12AffineFastState.Bounded env29525 := by
  intro p hp
  have h : env29525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29524_29525 : H12AffineEnvironment.transform 9 100 env29524 = env29525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env29524 == env29525) = true)

def env29526 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,4194304,180225,169234,8328,64,4691218,115151,17665,262144,119043,4268162,257,213487,237643,63188]

theorem envBound29526 : H12AffineFastState.Bounded env29526 := by
  intro p hp
  have h : env29526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29488_29526 : H12AffineEnvironment.transform 20 184401 env29488 = env29526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 184401 env29488 == env29526) = true)

def env29527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272512,180225,169234,8328,64,245138,115151,17665,262144,119043,329730,257,213487,237643,63188]

theorem envBound29527 : H12AffineFastState.Bounded env29527 := by
  intro p hp
  have h : env29527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29526_29527 : H12AffineEnvironment.transform 21 272512 env29526 = env29527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env29526 == env29527) = true)

theorem identity29527 : scanCanonicalize (H12AffineFastState.compose env29527 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound29527 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272512,180225,169234,8328,64,171416,57797,17665,262144,61705,272392,257,156133,163905,63188]

theorem envBound29528 : H12AffineFastState.Bounded env29528 := by
  intro p hp
  have h : env29528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29527_29528 : H12AffineEnvironment.transform 15 8202 env29527 = env29528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env29527 == env29528) = true)

def env29529 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272392,180225,169234,8192,64,171280,57677,17665,262144,61705,272392,257,156013,163905,63068]

theorem envBound29529 : H12AffineFastState.Bounded env29529 := by
  intro p hp
  have h : env29529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29528_29529 : H12AffineEnvironment.transform 6 8 env29528 = env29529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29528 == env29529) = true)

def env29530 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4161,272392,17,21762,8192,64,23808,57677,17665,262144,61705,272392,257,41341,16465,63068]

theorem envBound29530 : H12AffineFastState.Bounded env29530 := by
  intro p hp
  have h : env29530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29529_29530 : H12AffineEnvironment.transform 16 49168 env29529 = env29530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29529 == env29530) = true)

theorem identity29530 : scanCanonicalize (H12AffineFastState.compose env29530 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound29530 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29531 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49168,56437,1025,32769,4161,62589,17,21762,8192,64,23808,57677,17665,56437,61705,62589,257,41341,16465,63068]

theorem envBound29531 : H12AffineFastState.Bounded env29531 := by
  intro p hp
  have h : env29531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29530_29531 : H12AffineEnvironment.transform 17 56437 env29530 = env29531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env29530 == env29531) = true)

theorem identity29531 : scanCanonicalize (H12AffineFastState.compose env29531 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound29531 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env29532 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8202,38161,35188,1025,32769,4161,41340,17,3,8192,64,2049,46156,4096,35188,41992,41340,257,41341,5456,41821]

theorem envBound29532 : H12AffineFastState.Bounded env29532 := by
  intro p hp
  have h : env29532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29531_29532 : H12AffineEnvironment.transform 13 5377 env29531 = env29532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env29531 == env29532) = true)

theorem identity29532 : scanCanonicalize (H12AffineFastState.compose env29532 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29532 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env29533 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,32768,343,38161,35188,1025,32769,4161,32801,17,3,349,64,2049,38161,4096,35188,34133,32801,257,32800,5456,33280]

theorem envBound29533 : H12AffineFastState.Bounded env29533 := by
  intro p hp
  have h : env29533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29532_29533 : H12AffineEnvironment.transform 12 349 env29532 = env29533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29532 == env29533) = true)

theorem identity29533 : scanCanonicalize (H12AffineFastState.compose env29533 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound29533 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env29534 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,2048,343,7441,372,1025,2049,4161,2081,17,3,349,64,2049,7441,4096,372,3413,2081,257,2080,5456,2560]

theorem envBound29534 : H12AffineFastState.Bounded env29534 := by
  intro p hp
  have h : env29534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29533_29534 : H12AffineEnvironment.transform 14 2048 env29533 = env29534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env29533 == env29534) = true)

theorem identity29534 : scanCanonicalize (H12AffineFastState.compose env29534 (packedSelected [1,4,5,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29534 : packedSelected [1,4,5,9,11] rootPS < 2^1333 := by decide +kernel

def env29535 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,4096,349,4404,2048,343,6436,372,52,2049,4161,2081,17,3,349,64,2049,6436,4096,372,2400,2081,257,2080,4453,2560]

theorem envBound29535 : H12AffineFastState.Bounded env29535 := by
  intro p hp
  have h : env29535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29534_29535 : H12AffineEnvironment.transform 9 53 env29534 = env29535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29534 == env29535) = true)

theorem identity29535 : scanCanonicalize (H12AffineFastState.compose env29535 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound29535 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env29536 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,349,2341,2048,343,309,372,52,2049,2128,2081,17,3,349,64,2049,309,2065,372,2400,2081,257,2080,2420,2560]

theorem envBound29536 : H12AffineFastState.Bounded env29536 := by
  intro p hp
  have h : env29536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29535_29536 : H12AffineEnvironment.transform 11 2065 env29535 = env29536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env29535 == env29536) = true)

theorem identity29536 : scanCanonicalize (H12AffineFastState.compose env29536 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound29536 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env29537 : List Nat := [2,4,8,16,32,64,8,256,512,53,0,17,349,293,0,343,309,372,52,1,80,33,17,3,349,64,1,309,17,372,352,33,257,32,372,512]

theorem envBound29537 : H12AffineFastState.Bounded env29537 := by
  intro p hp
  have h : env29537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29536_29537 : H12AffineEnvironment.transform 10 0 env29536 = env29537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env29536 == env29537) = true)

theorem identity29537 : scanCanonicalize (H12AffineFastState.compose env29537 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29537 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29538 : List Nat := [2,4,8,16,32,64,8,5,512,53,0,17,88,32,0,82,48,113,52,1,80,33,17,3,88,64,1,48,17,113,101,33,4,32,113,512]

theorem envBound29538 : H12AffineFastState.Bounded env29538 := by
  intro p hp
  have h : env29538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29537_29538 : H12AffineEnvironment.transform 7 5 env29537 = env29538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29537 == env29538) = true)

theorem identity29538 : scanCanonicalize (H12AffineFastState.compose env29538 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29538 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29539 : List Nat := [2,4,8,16,32,17,8,5,512,53,0,17,9,32,0,3,48,32,52,1,1,33,17,3,9,17,1,48,17,32,52,33,4,32,32,512]

theorem envBound29539 : H12AffineFastState.Bounded env29539 := by
  intro p hp
  have h : env29539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29538_29539 : H12AffineEnvironment.transform 5 17 env29538 = env29539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29538 == env29539) = true)

theorem identity29539 : scanCanonicalize (H12AffineFastState.compose env29539 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29539 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29540 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,9,0,0,3,16,0,20,1,1,1,17,3,9,17,1,16,17,0,20,1,4,0,0,512]

theorem envBound29540 : H12AffineFastState.Bounded env29540 := by
  intro p hp
  have h : env29540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29539_29540 : H12AffineEnvironment.transform 4 0 env29539 = env29540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29539 == env29540) = true)

theorem identity29540 : scanCanonicalize (H12AffineFastState.compose env29540 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound29540 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29541 : List Nat := [2,4,8,16,0,17,8,5,1,21,0,17,9,0,0,3,16,0,20,1,1,1,17,3,9,17,1,16,17,0,20,1,4,0,0,1]

theorem envBound29541 : H12AffineFastState.Bounded env29541 := by
  intro p hp
  have h : env29541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29540_29541 : H12AffineEnvironment.transform 8 1 env29540 = env29541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env29540 == env29541) = true)

theorem identity29541 : scanCanonicalize (H12AffineFastState.compose env29541 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound29541 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29542 : List Nat := [2,4,8,15,0,14,8,5,1,10,0,14,9,0,0,3,15,0,11,1,1,1,14,3,9,14,1,15,14,0,11,1,4,0,0,1]

theorem envBound29542 : H12AffineFastState.Bounded env29542 := by
  intro p hp
  have h : env29542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29541_29542 : H12AffineEnvironment.transform 3 15 env29541 = env29542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env29541 == env29542) = true)

def env29543 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4160,272392,16,21763,8192,64,23809,57677,17665,262144,61705,272392,257,41340,16464,63068]

theorem envBound29543 : H12AffineFastState.Bounded env29543 := by
  intro p hp
  have h : env29543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29529_29543 : H12AffineEnvironment.transform 16 49169 env29529 = env29543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29529 == env29543) = true)

theorem identity29543 : scanCanonicalize (H12AffineFastState.compose env29543 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound29543 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29544 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8202,13388,262144,1025,29788,4160,272392,16,21763,8192,64,23809,5392,17665,262144,1364,272392,257,21793,16464,513]

theorem envBound29544 : H12AffineFastState.Bounded env29544 := by
  intro p hp
  have h : env29544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29543_29544 : H12AffineEnvironment.transform 14 29789 env29543 = env29544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env29543 == env29544) = true)

theorem identity29544 : scanCanonicalize (H12AffineFastState.compose env29544 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29544 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29545 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,8202,13340,262144,1025,29708,4112,272392,16,21763,8192,16,23809,5392,17665,262144,1284,272392,257,21793,16384,513]

theorem envBound29545 : H12AffineFastState.Bounded env29545 := by
  intro p hp
  have h : env29545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29544_29545 : H12AffineEnvironment.transform 5 16 env29544 = env29545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29544 == env29545) = true)

theorem identity29545 : scanCanonicalize (H12AffineFastState.compose env29545 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29545 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29546 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,13340,262144,1025,8460,4112,272392,16,3,8192,16,2049,5392,4097,262144,1284,272392,257,33,5376,513]

theorem envBound29546 : H12AffineFastState.Bounded env29546 := by
  intro p hp
  have h : env29546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29545_29546 : H12AffineEnvironment.transform 13 5376 env29545 = env29546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29545 == env29546) = true)

theorem identity29546 : scanCanonicalize (H12AffineFastState.compose env29546 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound29546 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29547 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5376,8461,8202,13340,2340,1025,8460,4112,8492,16,3,8192,16,2049,5392,4097,2340,1284,8492,257,33,5376,513]

theorem envBound29547 : H12AffineFastState.Bounded env29547 := by
  intro p hp
  have h : env29547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29546_29547 : H12AffineEnvironment.transform 17 2340 env29546 = env29547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env29546 == env29547) = true)

theorem identity29547 : scanCanonicalize (H12AffineFastState.compose env29547 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 7465) := by decide +kernel

theorem selectedBound29547 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env29548 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,7465,5376,7204,7459,2357,2340,1025,7205,4112,7173,16,3,7465,16,2049,5392,4097,2340,1284,7173,257,33,5376,513]

theorem envBound29548 : H12AffineFastState.Bounded env29548 := by
  intro p hp
  have h : env29548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29547_29548 : H12AffineEnvironment.transform 12 7465 env29547 = env29548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7465 env29547 == env29548) = true)

theorem identity29548 : scanCanonicalize (H12AffineFastState.compose env29548 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound29548 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env29549 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,7180,5157,7204,7174,2064,2049,1025,7205,4112,7173,16,3,7180,16,2049,5173,4097,2049,1057,7173,36,33,5157,513]

theorem envBound29549 : H12AffineFastState.Bounded env29549 := by
  intro p hp
  have h : env29549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29548_29549 : H12AffineEnvironment.transform 7 37 env29548 = env29549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env29548 == env29549) = true)

def env29550 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,184401,272393,180225,169234,8193,64,171281,57676,17665,262144,61705,272392,257,156012,163905,63069]

theorem envBound29550 : H12AffineFastState.Bounded env29550 := by
  intro p hp
  have h : env29550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29528_29550 : H12AffineEnvironment.transform 6 9 env29528 = env29550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29528 == env29550) = true)

def env29551 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,262144,1025,32769,4161,272393,17,21762,8193,64,23809,57676,17665,262144,61705,272392,257,41340,16465,63069]

theorem envBound29551 : H12AffineFastState.Bounded env29551 := by
  intro p hp
  have h : env29551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29550_29551 : H12AffineEnvironment.transform 16 49168 env29550 = env29551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env29550 == env29551) = true)

theorem identity29551 : scanCanonicalize (H12AffineFastState.compose env29551 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound29551 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29552 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49168,32041,1025,32769,4161,21792,17,21762,8193,64,23809,57676,17665,32041,61705,21793,257,41340,16465,63069]

theorem envBound29552 : H12AffineFastState.Bounded env29552 := by
  intro p hp
  have h : env29552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29551_29552 : H12AffineEnvironment.transform 17 32041 env29551 = env29552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env29551 == env29552) = true)

theorem identity29552 : scanCanonicalize (H12AffineFastState.compose env29552 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound29552 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env29553 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21621,8202,5221,32041,1025,21620,4161,21792,17,21762,8193,64,23809,13625,17665,32041,9596,21793,257,29961,16465,8744]

theorem envBound29553 : H12AffineFastState.Bounded env29553 := by
  intro p hp
  have h : env29553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29552_29553 : H12AffineEnvironment.transform 14 21621 env29552 = env29553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env29552 == env29553) = true)

theorem identity29553 : scanCanonicalize (H12AffineFastState.compose env29553 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound29553 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env29554 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,16384,21621,34,5221,23809,1025,21620,4161,21792,17,21762,41,64,23809,5393,17665,23809,1364,21793,257,21793,16465,512]

theorem envBound29554 : H12AffineFastState.Bounded env29554 := by
  intro p hp
  have h : env29554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29553_29554 : H12AffineEnvironment.transform 12 40 env29553 = env29554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env29553 == env29554) = true)

theorem identity29554 : scanCanonicalize (H12AffineFastState.compose env29554 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound29554 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env29555 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5236,1,34,5221,2421,1025,0,4161,340,17,374,41,64,2421,5393,4469,2421,1364,341,257,341,5157,512]

theorem envBound29555 : H12AffineFastState.Bounded env29555 := by
  intro p hp
  have h : env29555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29554_29555 : H12AffineEnvironment.transform 13 5236 env29554 = env29555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env29554 == env29555) = true)

theorem identity29555 : scanCanonicalize (H12AffineFastState.compose env29555 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound29555 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29556 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,40,5236,1,34,5221,2080,1025,0,4161,1,17,35,41,64,2080,5188,4128,2080,1025,0,84,0,5157,512]

theorem envBound29556 : H12AffineFastState.Bounded env29556 := by
  intro p hp
  have h : env29556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29555_29556 : H12AffineEnvironment.transform 7 85 env29555 = env29556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env29555 == env29556) = true)

theorem identity29556 : scanCanonicalize (H12AffineFastState.compose env29556 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1087) := by decide +kernel

theorem selectedBound29556 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env29557 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,1087,40,75,1,34,90,2080,1025,0,1150,1,17,35,41,64,2080,123,1055,2080,1025,0,84,0,26,512]

theorem envBound29557 : H12AffineFastState.Bounded env29557 := by
  intro p hp
  have h : env29557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29556_29557 : H12AffineEnvironment.transform 11 1087 env29556 = env29557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1087 env29556 == env29557) = true)

theorem identity29557 : scanCanonicalize (H12AffineFastState.compose env29557 (packedSelected [5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound29557 : packedSelected [5,8,12] rootPS < 2^1333 := by decide +kernel

def env29558 : List Nat := [2,4,8,16,32,64,9,85,512,1024,11,1087,40,75,1,34,90,43,1025,0,1150,1,17,35,41,64,43,123,1055,43,1025,0,84,0,26,512]

theorem envBound29558 : H12AffineFastState.Bounded env29558 := by
  intro p hp
  have h : env29558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29557_29558 : H12AffineEnvironment.transform 10 11 env29557 = env29558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env29557 == env29558) = true)

def env29559 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,4160,272393,16,21763,8193,64,23808,57676,17665,262144,61705,272392,257,41341,16464,63069]

theorem envBound29559 : H12AffineFastState.Bounded env29559 := by
  intro p hp
  have h : env29559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29550_29559 : H12AffineEnvironment.transform 16 49169 env29550 = env29559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env29550 == env29559) = true)

theorem identity29559 : scanCanonicalize (H12AffineFastState.compose env29559 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound29559 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env29560 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,38161,262144,1025,32769,4160,272393,16,3,8193,64,2048,46156,4097,262144,41993,272392,257,41341,5456,41821]

theorem envBound29560 : H12AffineFastState.Bounded env29560 := by
  intro p hp
  have h : env29560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29559_29560 : H12AffineEnvironment.transform 13 5376 env29559 = env29560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env29559 == env29560) = true)

theorem identity29560 : scanCanonicalize (H12AffineFastState.compose env29560 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29560 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env29561 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,32768,342,38161,262144,1025,32769,4160,264533,16,3,349,64,2048,38160,4097,262144,34133,264532,257,32801,5456,33281]

theorem envBound29561 : H12AffineFastState.Bounded env29561 := by
  intro p hp
  have h : env29561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29560_29561 : H12AffineEnvironment.transform 12 348 env29560 = env29561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29560 == env29561) = true)

theorem identity29561 : scanCanonicalize (H12AffineFastState.compose env29561 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29561 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29562 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5393,262144,1025,1,4160,264533,16,3,349,64,2048,5392,4097,262144,1365,264532,257,33,5456,513]

theorem envBound29562 : H12AffineFastState.Bounded env29562 := by
  intro p hp
  have h : env29562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29561_29562 : H12AffineEnvironment.transform 14 0 env29561 = env29562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29561 == env29562) = true)

theorem identity29562 : scanCanonicalize (H12AffineFastState.compose env29562 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound29562 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29563 : List Nat := [2,4,8,16,32,64,9,256,373,1024,2048,4096,348,5376,0,342,5393,262144,1025,1,4160,264533,16,3,349,64,2048,5392,4097,262144,1365,264532,257,33,5456,372]

theorem envBound29563 : H12AffineFastState.Bounded env29563 := by
  intro p hp
  have h : env29563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29562_29563 : H12AffineEnvironment.transform 8 373 env29562 = env29563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env29562 == env29563) = true)

theorem identity29563 : scanCanonicalize (H12AffineFastState.compose env29563 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29563 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29564 : List Nat := [2,4,8,16,32,16,9,256,293,1024,2048,4096,268,5376,0,262,5393,262144,1025,1,4112,264453,16,3,269,16,2048,5392,4097,262144,1285,264452,257,33,5376,292]

theorem envBound29564 : H12AffineFastState.Bounded env29564 := by
  intro p hp
  have h : env29564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29563_29564 : H12AffineEnvironment.transform 5 16 env29563 = env29564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29563 == env29564) = true)

theorem identity29564 : scanCanonicalize (H12AffineFastState.compose env29564 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound29564 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29565 : List Nat := [2,4,8,16,32,16,9,52,17,1024,2048,4096,56,5172,0,50,5157,262144,1025,1,4112,264241,16,3,57,16,2048,5156,4097,262144,1073,264240,53,33,5172,16]

theorem envBound29565 : H12AffineFastState.Bounded env29565 := by
  intro p hp
  have h : env29565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29564_29565 : H12AffineEnvironment.transform 7 52 env29564 = env29565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env29564 == env29565) = true)

theorem identity29565 : scanCanonicalize (H12AffineFastState.compose env29565 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound29565 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29566 : List Nat := [2,4,8,16,32,16,9,52,17,1024,2048,1076,56,0,0,50,17,262144,1025,1,1060,264241,16,3,57,16,2048,16,1077,262144,1073,264240,53,33,0,16]

theorem envBound29566 : H12AffineFastState.Bounded env29566 := by
  intro p hp
  have h : env29566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29565_29566 : H12AffineEnvironment.transform 11 1076 env29565 = env29566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env29565 == env29566) = true)

theorem identity29566 : scanCanonicalize (H12AffineFastState.compose env29566 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 16) := by decide +kernel

theorem selectedBound29566 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env29567 : List Nat := [2,4,8,16,32,16,9,52,17,1024,2048,1076,56,0,0,50,17,16,1025,1,1060,2081,16,3,57,16,2048,16,1077,16,1073,2080,53,33,0,16]

theorem envBound29567 : H12AffineFastState.Bounded env29567 := by
  intro p hp
  have h : env29567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29566_29567 : H12AffineEnvironment.transform 17 16 env29566 = env29567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 16 env29566 == env29567) = true)

theorem identity29567 : scanCanonicalize (H12AffineFastState.compose env29567 (packedSelected [10] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound29567 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env29568 : List Nat := [2,4,8,16,32,16,9,52,17,1024,16,1076,56,0,0,50,17,16,1025,1,1060,49,16,3,57,16,16,16,1077,16,1073,48,53,33,0,16]

theorem envBound29568 : H12AffineFastState.Bounded env29568 := by
  intro p hp
  have h : env29568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29567_29568 : H12AffineEnvironment.transform 10 16 env29567 = env29568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env29567 == env29568) = true)

theorem identity29568 : scanCanonicalize (H12AffineFastState.compose env29568 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound29568 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29569 : List Nat := [2,4,8,16,32,16,9,52,17,36,16,16,56,0,0,50,17,16,37,1,0,49,16,3,57,16,16,16,17,16,21,48,53,33,0,16]

theorem envBound29569 : H12AffineFastState.Bounded env29569 := by
  intro p hp
  have h : env29569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29568_29569 : H12AffineEnvironment.transform 9 36 env29568 = env29569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env29568 == env29569) = true)

theorem identity29569 : scanCanonicalize (H12AffineFastState.compose env29569 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound29569 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29570 : List Nat := [2,4,8,16,17,16,9,5,17,21,16,16,9,0,0,3,17,16,20,1,0,0,16,3,8,16,16,16,17,16,21,1,4,16,0,16]

theorem envBound29570 : H12AffineFastState.Bounded env29570 := by
  intro p hp
  have h : env29570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29569_29570 : H12AffineEnvironment.transform 4 17 env29569 = env29570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env29569 == env29570) = true)

theorem identity29570 : scanCanonicalize (H12AffineFastState.compose env29570 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound29570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29571 : List Nat := [2,4,8,0,1,0,9,5,1,5,0,0,9,0,0,3,1,0,4,1,0,0,0,3,8,0,0,0,1,0,5,1,4,0,0,0]

theorem envBound29571 : H12AffineFastState.Bounded env29571 := by
  intro p hp
  have h : env29571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29570_29571 : H12AffineEnvironment.transform 3 0 env29570 = env29571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env29570 == env29571) = true)

def env29572 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,184401,272513,180225,169234,8328,64,245139,115151,17665,262144,119043,329731,257,213487,237643,63188]

theorem envBound29572 : H12AffineFastState.Bounded env29572 := by
  intro p hp
  have h : env29572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29526_29572 : H12AffineEnvironment.transform 21 272513 env29526 = env29572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env29526 == env29572) = true)

theorem identity29572 : scanCanonicalize (H12AffineFastState.compose env29572 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound29572 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env29573 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77899,272513,73755,95496,8328,64,23945,115151,17665,262144,119043,329731,257,41461,16465,63188]

theorem envBound29573 : H12AffineFastState.Bounded env29573 := by
  intro p hp
  have h : env29573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29572_29573 : H12AffineEnvironment.transform 16 122906 env29572 = env29573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env29572 == env29573) = true)

def env29574 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77899,272473,73755,95496,8272,64,23889,114967,17665,262144,119043,329731,257,41261,16465,62988]

theorem envBound29574 : H12AffineFastState.Bounded env29574 := by
  intro p hp
  have h : env29574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29573_29574 : H12AffineEnvironment.transform 6 88 env29573 = env29574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env29573 == env29574) = true)

theorem identity29574 : scanCanonicalize (H12AffineFastState.compose env29574 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound29574 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env29575 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,65536,79131,262144,1025,21760,77899,272473,73755,95496,8272,64,23889,70678,17665,262144,66562,329731,257,29740,16465,8973]

theorem envBound29575 : H12AffineFastState.Bounded env29575 := by
  intro p hp
  have h : env29575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29574_29575 : H12AffineEnvironment.transform 14 21761 env29574 = env29575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env29574 == env29575) = true)

theorem identity29575 : scanCanonicalize (H12AffineFastState.compose env29575 (packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 97326) := by decide +kernel

theorem selectedBound29575 : packedSelected [1,3,4,7,9,18,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env29576 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,65536,79131,97326,1025,21760,77899,87159,73755,95496,8272,64,23889,70678,17665,97326,66562,29741,257,29740,16465,8973]

theorem envBound29576 : H12AffineFastState.Bounded env29576 := by
  intro p hp
  have h : env29576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29575_29576 : H12AffineEnvironment.transform 17 97326 env29575 = env29576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97326 env29575 == env29576) = true)

theorem identity29576 : scanCanonicalize (H12AffineFastState.compose env29576 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound29576 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env29577 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,16384,21761,262,13341,32040,1025,21760,12621,21873,8477,29710,8272,64,23889,5392,17665,32040,1284,29741,257,29740,16465,8973]

theorem envBound29577 : H12AffineFastState.Bounded env29577 := by
  intro p hp
  have h : env29577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29576_29577 : H12AffineEnvironment.transform 15 262 env29576 = env29577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env29576 == env29577) = true)

theorem identity29577 : scanCanonicalize (H12AffineFastState.compose env29577 (packedSelected [2,11,14,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound29577 : packedSelected [2,11,14,15,17] rootPS < 2^1333 := by decide +kernel

def env29578 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,4144,1329,262,13341,11544,1025,1328,12621,1345,8477,9278,8272,64,3425,5392,5425,11544,1284,9245,257,9244,4193,8973]

theorem envBound29578 : H12AffineFastState.Bounded env29578 := by
  intro p hp
  have h : env29578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29577_29578 : H12AffineEnvironment.transform 13 4144 env29577 = env29578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env29577 == env29578) = true)

theorem identity29578 : scanCanonicalize (H12AffineFastState.compose env29578 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound29578 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env29579 : List Nat := [2,4,8,16,32,64,88,256,512,304,2048,4096,8192,4144,1,262,12589,10280,305,0,12621,113,8477,8462,8272,64,2129,4128,4097,10280,52,8493,257,8492,4193,8973]

theorem envBound29579 : H12AffineFastState.Bounded env29579 := by
  intro p hp
  have h : env29579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29578_29579 : H12AffineEnvironment.transform 9 304 env29578 = env29579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env29578 == env29579) = true)

theorem identity29579 : scanCanonicalize (H12AffineFastState.compose env29579 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 300) := by decide +kernel

theorem selectedBound29579 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29580 : List Nat := [2,4,8,16,32,64,88,256,512,304,2048,4096,300,4144,1,262,4097,2308,305,0,4193,113,49,34,380,64,2129,4128,4097,2308,52,1,257,0,4193,545]

theorem envBound29580 : H12AffineFastState.Bounded env29580 := by
  intro p hp
  have h : env29580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29579_29580 : H12AffineEnvironment.transform 12 300 env29579 = env29580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 300 env29579 == env29580) = true)

theorem identity29580 : scanCanonicalize (H12AffineFastState.compose env29580 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound29580 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29581 : List Nat := [2,4,8,16,32,48,40,256,512,304,2048,4096,300,4144,1,262,4097,2308,305,0,4113,1,49,34,268,48,2081,4128,4097,2308,52,1,257,0,4113,545]

theorem envBound29581 : H12AffineFastState.Bounded env29581 := by
  intro p hp
  have h : env29581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29580_29581 : H12AffineEnvironment.transform 5 48 env29580 = env29581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env29580 == env29581) = true)

theorem identity29581 : scanCanonicalize (H12AffineFastState.compose env29581 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 308) := by decide +kernel

theorem selectedBound29581 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env29582 : List Nat := [2,4,8,16,32,48,40,256,512,304,308,4096,300,4144,1,262,4097,48,305,0,4113,1,49,34,268,48,277,4128,4097,48,52,1,257,0,4113,545]

theorem envBound29582 : H12AffineFastState.Bounded env29582 := by
  intro p hp
  have h : env29582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29581_29582 : H12AffineEnvironment.transform 10 308 env29581 = env29582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 308 env29581 == env29582) = true)

theorem identity29582 : scanCanonicalize (H12AffineFastState.compose env29582 (packedSelected [3,5,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29582 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29583 : List Nat := [2,4,8,16,0,16,8,256,512,272,276,4096,268,4112,1,262,4097,16,273,0,4113,1,17,2,268,16,277,4096,4097,16,20,1,257,0,4113,513]

theorem envBound29583 : H12AffineFastState.Bounded env29583 := by
  intro p hp
  have h : env29583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29582_29583 : H12AffineEnvironment.transform 4 0 env29582 = env29583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29582 == env29583) = true)

theorem identity29583 : scanCanonicalize (H12AffineFastState.compose env29583 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound29583 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29584 : List Nat := [2,4,8,16,0,16,8,256,512,272,276,276,268,260,1,262,277,16,273,0,261,1,17,2,268,16,277,276,277,16,20,1,257,0,261,513]

theorem envBound29584 : H12AffineFastState.Bounded env29584 := by
  intro p hp
  have h : env29584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29583_29584 : H12AffineEnvironment.transform 11 276 env29583 = env29584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env29583 == env29584) = true)

theorem identity29584 : scanCanonicalize (H12AffineFastState.compose env29584 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound29584 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29585 : List Nat := [2,4,8,16,0,16,8,5,512,21,17,17,9,1,1,3,16,16,20,0,0,1,17,2,9,16,16,17,16,16,20,1,4,0,0,513]

theorem envBound29585 : H12AffineFastState.Bounded env29585 := by
  intro p hp
  have h : env29585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29584_29585 : H12AffineEnvironment.transform 7 5 env29584 = env29585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env29584 == env29585) = true)

def env29586 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,77899,272472,73755,95496,8273,64,23888,114966,17665,262144,119043,329731,257,41260,16465,62989]

theorem envBound29586 : H12AffineFastState.Bounded env29586 := by
  intro p hp
  have h : env29586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29573_29586 : H12AffineEnvironment.transform 6 89 env29573 = env29586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env29573 == env29586) = true)

theorem identity29586 : scanCanonicalize (H12AffineFastState.compose env29586 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound29586 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env29587 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57676,262144,1025,32769,12573,272472,8525,29790,8273,64,23888,49216,17665,262144,53333,264533,257,41260,16465,62989]

theorem envBound29587 : H12AffineFastState.Bounded env29587 := by
  intro p hp
  have h : env29587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29586_29587 : H12AffineEnvironment.transform 15 342 env29586 = env29587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env29586 == env29587) = true)

theorem identity29587 : scanCanonicalize (H12AffineFastState.compose env29587 (packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 64889) := by decide +kernel

theorem selectedBound29587 : packedSelected [0,1,3,4,7,18,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env29588 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,342,57676,64889,1025,32769,12573,54561,8525,29790,8273,64,23888,49216,17665,64889,53333,62508,257,41260,16465,62989]

theorem envBound29588 : H12AffineFastState.Bounded env29588 := by
  intro p hp
  have h : env29588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29587_29588 : H12AffineEnvironment.transform 17 64889 env29587 = env29588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64889 env29587 == env29588) = true)

theorem identity29588 : scanCanonicalize (H12AffineFastState.compose env29588 (packedSelected [0,4,7,16,17,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound29588 : packedSelected [0,4,7,16,17,20,22] rootPS < 2^1333 := by decide +kernel

def env29589 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21841,342,13341,10280,1025,21840,12573,112,8525,29790,8273,64,23888,5393,17665,10280,1284,8573,257,29821,16465,9052]

theorem envBound29589 : H12AffineFastState.Bounded env29589 := by
  intro p hp
  have h : env29589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29588_29589 : H12AffineEnvironment.transform 14 21841 env29588 = env29589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env29588 == env29589) = true)

theorem identity29589 : scanCanonicalize (H12AffineFastState.compose env29589 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound29589 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env29590 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,16384,21841,342,5441,2420,1025,21840,4161,112,17,21762,269,64,23888,5393,17665,2420,1284,33,257,21793,16465,512]

theorem envBound29590 : H12AffineFastState.Bounded env29590 := by
  intro p hp
  have h : env29590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29589_29590 : H12AffineEnvironment.transform 12 348 env29589 = env29590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env29589 == env29590) = true)

theorem identity29590 : scanCanonicalize (H12AffineFastState.compose env29590 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound29590 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29591 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5408,113,342,5441,2420,1025,112,4161,112,17,34,269,64,2160,5393,4129,2420,1284,33,257,1,5489,512]

theorem envBound29591 : H12AffineFastState.Bounded env29591 := by
  intro p hp
  have h : env29591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29590_29591 : H12AffineEnvironment.transform 13 5408 env29590 = env29591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env29590 == env29591) = true)

theorem identity29591 : scanCanonicalize (H12AffineFastState.compose env29591 (packedSelected [0,2,3,5,7,15] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound29591 : packedSelected [0,2,3,5,7,15] rootPS < 2^1333 := by decide +kernel

def env29592 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,292,348,1028,113,342,1125,2420,1025,112,357,112,17,34,269,64,2160,1077,261,2420,1284,33,257,1,1109,512]

theorem envBound29592 : H12AffineFastState.Bounded env29592 := by
  intro p hp
  have h : env29592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29591_29592 : H12AffineEnvironment.transform 11 292 env29591 = env29592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env29591 == env29592) = true)

theorem identity29592 : scanCanonicalize (H12AffineFastState.compose env29592 (packedSelected [0,1,2,8,9,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound29592 : packedSelected [0,1,2,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29593 : List Nat := [2,4,8,16,32,64,89,256,48,1024,2048,292,348,1028,113,342,1125,2420,1025,112,357,112,17,34,269,64,2160,1077,261,2420,1284,33,257,1,1109,48]

theorem envBound29593 : H12AffineFastState.Bounded env29593 := by
  intro p hp
  have h : env29593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29592_29593 : H12AffineEnvironment.transform 8 48 env29592 = env29593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env29592 == env29593) = true)

theorem identity29593 : scanCanonicalize (H12AffineFastState.compose env29593 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound29593 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env29594 : List Nat := [2,4,8,16,32,64,89,85,48,1024,2048,113,9,1028,113,3,1125,2081,1025,112,48,112,17,34,88,64,2160,1077,80,2081,1105,33,84,1,1109,48]

theorem envBound29594 : H12AffineFastState.Bounded env29594 := by
  intro p hp
  have h : env29594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29593_29594 : H12AffineEnvironment.transform 7 85 env29593 = env29594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env29593 == env29594) = true)

theorem identity29594 : scanCanonicalize (H12AffineFastState.compose env29594 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29594 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29595 : List Nat := [2,4,8,16,0,64,89,85,16,1024,2048,81,9,1028,81,3,1093,2049,1025,80,16,80,17,2,88,64,2128,1045,80,2049,1105,1,84,1,1109,16]

theorem envBound29595 : H12AffineFastState.Bounded env29595 := by
  intro p hp
  have h : env29595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29594_29595 : H12AffineEnvironment.transform 4 0 env29594 = env29595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29594 == env29595) = true)

theorem identity29595 : scanCanonicalize (H12AffineFastState.compose env29595 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound29595 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29596 : List Nat := [2,4,8,16,0,1,24,20,16,1024,2048,16,9,1028,16,3,1028,2049,1025,17,16,17,17,2,25,1,2065,1045,17,2049,1040,1,21,1,1044,16]

theorem envBound29596 : H12AffineFastState.Bounded env29596 := by
  intro p hp
  have h : env29596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29595_29596 : H12AffineEnvironment.transform 5 1 env29595 = env29596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env29595 == env29596) = true)

theorem identity29596 : scanCanonicalize (H12AffineFastState.compose env29596 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound29596 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29597 : List Nat := [2,4,8,16,0,1,24,20,16,1024,17,16,9,1028,16,3,1028,16,1025,17,16,17,17,2,25,1,0,1045,17,16,1040,1,21,1,1044,16]

theorem envBound29597 : H12AffineFastState.Bounded env29597 := by
  intro p hp
  have h : env29597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29596_29597 : H12AffineEnvironment.transform 10 17 env29596 = env29597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env29596 == env29597) = true)

theorem identity29597 : scanCanonicalize (H12AffineFastState.compose env29597 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound29597 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env29598 : List Nat := [2,4,8,16,0,1,24,20,16,20,17,16,9,16,16,3,16,16,21,17,16,17,17,2,25,1,0,1,17,16,4,1,21,1,0,16]

theorem envBound29598 : H12AffineFastState.Bounded env29598 := by
  intro p hp
  have h : env29598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29597_29598 : H12AffineEnvironment.transform 9 20 env29597 = env29598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env29597 == env29598) = true)

theorem identity29598 : scanCanonicalize (H12AffineFastState.compose env29598 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29598 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env29599 : List Nat := [2,4,8,1,0,1,9,5,1,5,0,1,9,1,1,3,1,1,4,0,1,0,0,2,8,1,0,1,0,1,4,1,4,1,0,1]

theorem envBound29599 : H12AffineFastState.Bounded env29599 := by
  intro p hp
  have h : env29599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29598_29599 : H12AffineEnvironment.transform 3 1 env29598 = env29599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29598 == env29599) = true)

theorem identity29599 : scanCanonicalize (H12AffineFastState.compose env29599 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound29599 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29600 : List Nat := [2,1,8,1,0,1,9,0,1,0,0,1,9,1,1,3,1,1,1,0,1,0,0,2,8,1,0,1,0,1,1,1,1,1,0,1]

theorem envBound29600 : H12AffineFastState.Bounded env29600 := by
  intro p hp
  have h : env29600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29599_29600 : H12AffineEnvironment.transform 1 1 env29599 = env29600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env29599 == env29600) = true)

theorem identity29600 : scanCanonicalize (H12AffineFastState.compose env29600 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound29600 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29601 : List Nat := [2,1,0,1,0,1,1,0,1,0,0,1,1,1,1,3,1,1,1,0,1,0,0,2,0,1,0,1,0,1,1,1,1,1,0,1]

theorem envBound29601 : H12AffineFastState.Bounded env29601 := by
  intro p hp
  have h : env29601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29600_29601 : H12AffineEnvironment.transform 2 0 env29600 = env29601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env29600 == env29601) = true)

theorem identity29601 : scanCanonicalize (H12AffineFastState.compose env29601 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound29601 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env29602 : List Nat := [0,1,0,1,0,1,1,0,1,0,0,1,1,1,1,1,1,1,1,0,1,0,0,0,0,1,0,1,0,1,1,1,1,1,0,1]

theorem envBound29602 : H12AffineFastState.Bounded env29602 := by
  intro p hp
  have h : env29602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29601_29602 : H12AffineEnvironment.transform 0 0 env29601 = env29602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env29601 == env29602) = true)

def env29603 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497101,10507601,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound29603 : H12AffineFastState.Bounded env29603 := by
  intro p hp
  have h : env29603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29142_29603 : H12AffineEnvironment.transform 26 30393345 env29142 = env29603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env29142 == env29603) = true)

def env29604 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound29604 : H12AffineFastState.Bounded env29604 := by
  intro p hp
  have h : env29604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29603_29604 : H12AffineEnvironment.transform 18 1024 env29603 = env29604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env29603 == env29604) = true)

theorem identity29604 : scanCanonicalize (H12AffineFastState.compose env29604 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound29604 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env29605 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2,8328,64,13090819,2196623,10507601,8830977,8487954,6383042,256,10601647,10560779,8430532]

theorem envBound29605 : H12AffineFastState.Bounded env29605 := by
  intro p hp
  have h : env29605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29604_29605 : H12AffineEnvironment.transform 23 2 env29604 = env29605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env29604 == env29605) = true)

def env29606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,2,8328,64,4554891,2196623,2233817,295049,246938,6383042,256,2327591,2319747,189260]

theorem envBound29606 : H12AffineFastState.Bounded env29606 := by
  intro p hp
  have h : env29606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29605_29606 : H12AffineEnvironment.transform 22 147592 env29605 = env29606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env29605 == env29606) = true)

def env29607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,2,8328,64,4450363,2196623,2233817,190521,246938,6383042,256,2327591,2319747,189260]

theorem envBound29607 : H12AffineFastState.Bounded env29607 := by
  intro p hp
  have h : env29607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29606_29607 : H12AffineEnvironment.transform 17 157872 env29606 = env29607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env29606 == env29607) = true)

theorem identity29607 : scanCanonicalize (H12AffineFastState.compose env29607 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound29607 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,2,8328,64,4302891,2196623,2119113,43049,99466,6383042,256,2212919,2172307,41820]

theorem envBound29608 : H12AffineFastState.Bounded env29608 := by
  intro p hp
  have h : env29608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29607_29608 : H12AffineEnvironment.transform 16 16400 env29607 = env29608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env29607 == env29608) = true)

def env29609 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,16,2,8192,64,4302891,2196487,2118977,43049,99330,6382922,256,2212919,2172187,41820]

theorem envBound29609 : H12AffineFastState.Bounded env29609 := by
  intro p hp
  have h : env29609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29608_29609 : H12AffineEnvironment.transform 6 8 env29608 = env29609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29608 == env29609) = true)

theorem identity29609 : scanCanonicalize (H12AffineFastState.compose env29609 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29609 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29610 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,2097152,4194304,16,2,8192,64,4262262,2172250,2118977,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound29610 : H12AffineFastState.Bounded env29610 := by
  intro p hp
  have h : env29610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29609_29610 : H12AffineEnvironment.transform 14 8541 env29609 = env29610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29609 == env29610) = true)

theorem identity29610 : scanCanonicalize (H12AffineFastState.compose env29610 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound29610 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env29611 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,91466,4194304,16,2,8192,64,4262262,16400,77835,2420,75103,4194304,256,32,16465,513]

theorem envBound29611 : H12AffineFastState.Bounded env29611 := by
  intro p hp
  have h : env29611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29610_29611 : H12AffineEnvironment.transform 20 91466 env29610 = env29611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env29610 == env29611) = true)

theorem identity29611 : scanCanonicalize (H12AffineFastState.compose env29611 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29611 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29612 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,65536,16400,2421,1024,1,82967,4194304,16,2,349,64,4262262,16400,69974,2420,66562,4194304,256,32,16465,513]

theorem envBound29612 : H12AffineFastState.Bounded env29612 := by
  intro p hp
  have h : env29612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29611_29612 : H12AffineEnvironment.transform 12 349 env29611 = env29612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29611 == env29612) = true)

theorem identity29612 : scanCanonicalize (H12AffineFastState.compose env29612 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound29612 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env29613 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,342,16400,2421,1024,1,17729,4194304,16,2,349,64,4196384,16400,4096,2420,1364,4194304,256,32,16465,513]

theorem envBound29613 : H12AffineFastState.Bounded env29613 := by
  intro p hp
  have h : env29613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29612_29613 : H12AffineEnvironment.transform 15 342 env29612 = env29613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env29612 == env29613) = true)

theorem identity29613 : scanCanonicalize (H12AffineFastState.compose env29613 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound29613 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29614 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,0,262,16400,2341,1024,1,17681,4194304,16,2,269,16,4196384,16400,4096,2340,1284,4194304,256,32,16385,513]

theorem envBound29614 : H12AffineFastState.Bounded env29614 := by
  intro p hp
  have h : env29614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29613_29614 : H12AffineEnvironment.transform 5 16 env29613 = env29614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env29613 == env29614) = true)

theorem identity29614 : scanCanonicalize (H12AffineFastState.compose env29614 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound29614 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env29615 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,0,262,5173,2341,1024,1,4404,4194304,16,2,269,16,4196384,5173,4096,2340,1284,4194304,256,32,5156,513]

theorem envBound29615 : H12AffineFastState.Bounded env29615 := by
  intro p hp
  have h : env29615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29614_29615 : H12AffineEnvironment.transform 13 5157 env29614 = env29615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env29614 == env29615) = true)

theorem identity29615 : scanCanonicalize (H12AffineFastState.compose env29615 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound29615 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env29616 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5157,0,262,5173,2341,1024,1,4404,32,16,2,269,16,2048,5173,4096,2340,1284,32,256,32,5156,513]

theorem envBound29616 : H12AffineFastState.Bounded env29616 := by
  intro p hp
  have h : env29616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29615_29616 : H12AffineEnvironment.transform 21 32 env29615 = env29616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29615 == env29616) = true)

theorem identity29616 : scanCanonicalize (H12AffineFastState.compose env29616 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29616 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29617 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5125,0,262,5141,2309,1024,1,4372,0,16,2,269,16,2048,5141,4096,2308,1284,0,256,0,5124,513]

theorem envBound29617 : H12AffineFastState.Bounded env29617 := by
  intro p hp
  have h : env29617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29616_29617 : H12AffineEnvironment.transform 4 0 env29616 = env29617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29616 == env29617) = true)

theorem identity29617 : scanCanonicalize (H12AffineFastState.compose env29617 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1281) := by decide +kernel

theorem selectedBound29617 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29618 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,1281,269,260,0,262,276,2309,1024,1,1045,0,16,2,269,16,2048,276,1281,2308,1284,0,256,0,261,513]

theorem envBound29618 : H12AffineFastState.Bounded env29618 := by
  intro p hp
  have h : env29618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29617_29618 : H12AffineEnvironment.transform 11 1281 env29617 = env29618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env29617 == env29618) = true)

theorem identity29618 : scanCanonicalize (H12AffineFastState.compose env29618 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound29618 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env29619 : List Nat := [2,4,8,16,0,16,8,256,512,1024,1557,1281,269,260,0,262,276,1808,1024,1,1045,0,16,2,269,16,1557,276,1281,1809,1284,0,256,0,261,513]

theorem envBound29619 : H12AffineFastState.Bounded env29619 := by
  intro p hp
  have h : env29619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29618_29619 : H12AffineEnvironment.transform 10 1557 env29618 = env29619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env29618 == env29619) = true)

theorem identity29619 : scanCanonicalize (H12AffineFastState.compose env29619 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound29619 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env29620 : List Nat := [2,4,8,16,0,16,8,256,512,768,277,513,269,260,0,262,276,16,768,1,789,0,16,2,269,16,277,276,513,17,516,0,256,0,261,513]

theorem envBound29620 : H12AffineFastState.Bounded env29620 := by
  intro p hp
  have h : env29620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29619_29620 : H12AffineEnvironment.transform 9 768 env29619 = env29620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env29619 == env29620) = true)

theorem identity29620 : scanCanonicalize (H12AffineFastState.compose env29620 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound29620 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env29621 : List Nat := [2,4,8,16,0,16,8,256,261,5,277,260,269,260,0,262,276,16,5,1,16,0,16,2,269,16,277,276,260,17,257,0,256,0,261,260]

theorem envBound29621 : H12AffineFastState.Bounded env29621 := by
  intro p hp
  have h : env29621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29620_29621 : H12AffineEnvironment.transform 8 261 env29620 = env29621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env29620 == env29621) = true)

theorem identity29621 : scanCanonicalize (H12AffineFastState.compose env29621 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound29621 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29622 : List Nat := [2,4,8,1,0,1,8,256,261,5,260,260,269,260,0,262,261,1,5,1,1,0,1,2,269,1,260,261,260,0,257,0,256,0,261,260]

theorem envBound29622 : H12AffineFastState.Bounded env29622 := by
  intro p hp
  have h : env29622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29621_29622 : H12AffineEnvironment.transform 3 1 env29621 = env29622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env29621 == env29622) = true)

theorem identity29622 : scanCanonicalize (H12AffineFastState.compose env29622 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound29622 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29623 : List Nat := [2,4,8,1,0,1,8,14,11,5,10,10,3,10,0,8,11,1,5,1,1,0,1,2,3,1,10,11,10,0,15,0,14,0,11,10]

theorem envBound29623 : H12AffineFastState.Bounded env29623 := by
  intro p hp
  have h : env29623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29622_29623 : H12AffineEnvironment.transform 7 14 env29622 = env29623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env29622 == env29623) = true)

def env29624 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,2097152,4194304,17,2,8193,64,4302891,2196486,2118976,43049,99331,6382923,256,2212919,2172186,41820]

theorem envBound29624 : H12AffineFastState.Bounded env29624 := by
  intro p hp
  have h : env29624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29608_29624 : H12AffineEnvironment.transform 6 9 env29608 = env29624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env29608 == env29624) = true)

theorem identity29624 : scanCanonicalize (H12AffineFastState.compose env29624 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound29624 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29625 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,2097152,4194304,17,2,8193,64,4229152,2139149,2118976,43049,41992,6309184,256,2155580,2098449,41820]

theorem envBound29625 : H12AffineFastState.Bounded env29625 := by
  intro p hp
  have h : env29625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29624_29625 : H12AffineEnvironment.transform 15 8203 env29624 = env29625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env29624 == env29625) = true)

theorem identity29625 : scanCanonicalize (H12AffineFastState.compose env29625 (packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound29625 : packedSelected [1,3,4,5,7,8,9,10,16,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env29626 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,17681,4194304,17,2,8193,64,4229152,57628,4177,43049,41992,4194385,256,41261,16384,41820]

theorem envBound29626 : H12AffineFastState.Bounded env29626 := by
  intro p hp
  have h : env29626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29625_29626 : H12AffineEnvironment.transform 20 17681 env29625 = env29626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env29625 == env29626) = true)

theorem identity29626 : scanCanonicalize (H12AffineFastState.compose env29626 (packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 62728) := by decide +kernel

theorem selectedBound29626 : packedSelected [0,1,7,8,9,12,14,15,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env29627 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10281,1024,32769,17681,62728,17,2,8193,64,32040,57628,4177,43049,41992,62809,256,41261,16384,41820]

theorem envBound29627 : H12AffineFastState.Bounded env29627 := by
  intro p hp
  have h : env29627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29626_29627 : H12AffineEnvironment.transform 21 62728 env29626 = env29627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62728 env29626 == env29627) = true)

theorem identity29627 : scanCanonicalize (H12AffineFastState.compose env29627 (packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound29627 : packedSelected [3,4,5,9,10,12,14,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env29628 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8203,16400,10281,1024,1,17681,29960,17,2,8193,64,32040,24860,4177,10281,9224,30041,256,8493,16384,9052]

theorem envBound29628 : H12AffineFastState.Bounded env29628 := by
  intro p hp
  have h : env29628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29627_29628 : H12AffineEnvironment.transform 14 0 env29627 = env29628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env29627 == env29628) = true)

theorem identity29628 : scanCanonicalize (H12AffineFastState.compose env29628 (packedSelected [1,8,19] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound29628 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env29629 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,16384,0,1378,16400,3392,1024,1,17681,20577,17,2,1384,64,22593,17525,4177,3392,353,20528,256,1092,16384,1589]

theorem envBound29629 : H12AffineFastState.Bounded env29629 := by
  intro p hp
  have h : env29629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29628_29629 : H12AffineEnvironment.transform 12 1385 env29628 = env29629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env29628 == env29629) = true)

theorem identity29629 : scanCanonicalize (H12AffineFastState.compose env29629 (packedSelected [4,9,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound29629 : packedSelected [4,9,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env29630 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1385,4112,0,1378,4096,3392,1024,1,5377,113,17,2,1384,64,2129,5221,4177,3392,353,32,256,1092,4112,1589]

theorem envBound29630 : H12AffineFastState.Bounded env29630 := by
  intro p hp
  have h : env29630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29629_29630 : H12AffineEnvironment.transform 13 4112 env29629 = env29630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env29629 == env29630) = true)

theorem identity29630 : scanCanonicalize (H12AffineFastState.compose env29630 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound29630 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env29631 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,348,4112,0,343,4096,2421,53,1,4404,113,17,2,349,64,2129,4176,4177,2421,353,32,256,113,4112,512]

theorem envBound29631 : H12AffineFastState.Bounded env29631 := by
  intro p hp
  have h : env29631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29630_29631 : H12AffineEnvironment.transform 9 53 env29630 = env29631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env29630 == env29631) = true)

theorem identity29631 : scanCanonicalize (H12AffineFastState.compose env29631 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound29631 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env29632 : List Nat := [2,4,8,16,0,64,9,256,512,21,2048,4096,348,4112,0,343,4096,2389,21,1,4372,81,17,2,349,64,2129,4176,4177,2389,321,0,256,81,4112,512]

theorem envBound29632 : H12AffineFastState.Bounded env29632 := by
  intro p hp
  have h : env29632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29631_29632 : H12AffineEnvironment.transform 4 0 env29631 = env29632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env29631 == env29632) = true)

theorem identity29632 : scanCanonicalize (H12AffineFastState.compose env29632 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound29632 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env29633 : List Nat := [2,4,8,16,0,64,9,84,512,21,2048,4096,8,4112,0,3,4096,2049,21,1,4160,81,17,2,9,64,2129,4176,4177,2049,21,0,84,81,4112,512]

theorem envBound29633 : H12AffineFastState.Bounded env29633 := by
  intro p hp
  have h : env29633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29632_29633 : H12AffineEnvironment.transform 7 84 env29632 = env29633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env29632 == env29633) = true)

theorem identity29633 : scanCanonicalize (H12AffineFastState.compose env29633 (packedSelected [3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 580) := by decide +kernel

theorem selectedBound29633 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env29634 : List Nat := [2,4,8,16,0,64,9,84,512,21,2048,580,8,596,0,3,580,2049,21,1,516,81,17,2,9,64,2129,532,533,2049,21,0,84,81,596,512]

theorem envBound29634 : H12AffineFastState.Bounded env29634 := by
  intro p hp
  have h : env29634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29633_29634 : H12AffineEnvironment.transform 11 580 env29633 = env29634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 580 env29633 == env29634) = true)

theorem identity29634 : scanCanonicalize (H12AffineFastState.compose env29634 (packedSelected [1,4,7] rootPS)) = affineNative (2^(8+1) ^^^ 19) := by decide +kernel

theorem selectedBound29634 : packedSelected [1,4,7] rootPS < 2^1333 := by decide +kernel

def env29635 : List Nat := [2,4,8,16,0,64,9,84,19,21,2048,87,8,71,0,3,87,2049,21,1,23,81,17,2,9,64,2129,7,6,2049,21,0,84,81,71,19]

theorem envBound29635 : H12AffineFastState.Bounded env29635 := by
  intro p hp
  have h : env29635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29634_29635 : H12AffineEnvironment.transform 8 19 env29634 = env29635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 19 env29634 == env29635) = true)

theorem identity29635 : scanCanonicalize (H12AffineFastState.compose env29635 (packedSelected [3,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 25) := by decide +kernel

theorem selectedBound29635 : packedSelected [3,4,8] rootPS < 2^1333 := by decide +kernel

def env29636 : List Nat := [2,4,8,16,0,64,9,84,19,21,25,87,8,71,0,3,87,24,21,1,23,81,17,2,9,64,72,7,6,24,21,0,84,81,71,19]

theorem envBound29636 : H12AffineFastState.Bounded env29636 := by
  intro p hp
  have h : env29636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29635_29636 : H12AffineEnvironment.transform 10 25 env29635 = env29636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 25 env29635 == env29636) = true)

theorem identity29636 : scanCanonicalize (H12AffineFastState.compose env29636 (packedSelected [0,1,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29636 : packedSelected [0,1,9] rootPS < 2^1333 := by decide +kernel

def env29637 : List Nat := [2,4,8,16,0,17,9,5,19,21,25,6,8,22,0,3,6,24,21,1,23,0,17,2,9,17,25,7,6,24,21,0,5,0,22,19]

theorem envBound29637 : H12AffineFastState.Bounded env29637 := by
  intro p hp
  have h : env29637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29636_29637 : H12AffineEnvironment.transform 5 17 env29636 = env29637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29636 == env29637) = true)

theorem identity29637 : scanCanonicalize (H12AffineFastState.compose env29637 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound29637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env29638 : List Nat := [2,4,8,4,0,5,9,5,7,1,13,6,8,2,0,3,6,12,1,1,3,0,5,2,9,5,13,7,6,12,1,0,5,0,2,7]

theorem envBound29638 : H12AffineFastState.Bounded env29638 := by
  intro p hp
  have h : env29638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29637_29638 : H12AffineEnvironment.transform 3 4 env29637 = env29638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env29637 == env29638) = true)

theorem identity29638 : scanCanonicalize (H12AffineFastState.compose env29638 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound29638 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env29639 : List Nat := [2,4,1,4,0,5,0,5,7,1,4,6,1,2,0,3,6,5,1,1,3,0,5,2,0,5,4,7,6,5,1,0,5,0,2,7]

theorem envBound29639 : H12AffineFastState.Bounded env29639 := by
  intro p hp
  have h : env29639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29638_29639 : H12AffineEnvironment.transform 2 1 env29638 = env29639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env29638 == env29639) = true)

def env29640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,2,8328,64,4450362,2196623,2233817,190520,246938,6383042,256,2327591,2319747,189260]

theorem envBound29640 : H12AffineFastState.Bounded env29640 := by
  intro p hp
  have h : env29640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29606_29640 : H12AffineEnvironment.transform 17 157873 env29606 = env29640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env29606 == env29640) = true)

theorem identity29640 : scanCanonicalize (H12AffineFastState.compose env29640 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29640 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450362,2196487,2233681,190520,246802,6382922,256,2327591,2319627,189260]

theorem envBound29641 : H12AffineFastState.Bounded env29641 := by
  intro p hp
  have h : env29641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29640_29641 : H12AffineEnvironment.transform 6 8 env29640 = env29641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29640 == env29641) = true)

theorem identity29641 : scanCanonicalize (H12AffineFastState.compose env29641 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound29641 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35188,1024,32769,2097152,4194304,41293,2,8192,64,4262263,2196487,2159644,2421,75103,6382922,256,2188650,2196550,513]

theorem envBound29642 : H12AffineFastState.Bounded env29642 := by
  intro p hp
  have h : env29642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29641_29642 : H12AffineEnvironment.transform 16 57677 env29641 = env29642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env29641 == env29642) = true)

theorem identity29642 : scanCanonicalize (H12AffineFastState.compose env29642 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound29642 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35188,1024,32769,2097152,4194304,41293,2,8192,64,4229153,2098513,2159644,2421,41993,6349852,256,2155580,2098448,513]

theorem envBound29643 : H12AffineFastState.Bounded env29643 := by
  intro p hp
  have h : env29643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29642_29643 : H12AffineEnvironment.transform 15 33110 env29642 = env29643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env29642 == env29643) = true)

theorem identity29643 : scanCanonicalize (H12AffineFastState.compose env29643 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound29643 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env29644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57677,35188,1024,32769,2097152,32,41293,2,8192,64,34817,2098513,2159644,2421,41993,2155580,256,2155580,2098448,513]

theorem envBound29644 : H12AffineFastState.Bounded env29644 := by
  intro p hp
  have h : env29644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29643_29644 : H12AffineEnvironment.transform 21 32 env29643 = env29644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env29643 == env29644) = true)

theorem identity29644 : scanCanonicalize (H12AffineFastState.compose env29644 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound29644 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env29645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,263,24860,2341,1024,80,2097152,32,8476,2,8192,64,2128,2098513,2126925,2421,9304,2122861,256,2122861,2098448,513]

theorem envBound29645 : H12AffineFastState.Bounded env29645 := by
  intro p hp
  have h : env29645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29644_29645 : H12AffineEnvironment.transform 14 81 env29644 = env29645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env29644 == env29645) = true)

theorem identity29645 : scanCanonicalize (H12AffineFastState.compose env29645 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound29645 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env29646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5236,81,263,13672,2341,1024,80,2097152,32,8476,2,8192,64,2128,2098513,2105401,2421,9304,2109465,256,2109465,2098448,513]

theorem envBound29646 : H12AffineFastState.Bounded env29646 := by
  intro p hp
  have h : env29646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29645_29646 : H12AffineEnvironment.transform 13 5236 env29645 = env29646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env29645 == env29646) = true)

theorem identity29646 : scanCanonicalize (H12AffineFastState.compose env29646 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound29646 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env29647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,81,263,5173,2341,1024,80,2097152,32,65,2,349,64,2128,2098513,2097508,2421,1285,2101572,256,2101572,2098448,513]

theorem envBound29647 : H12AffineFastState.Bounded env29647 := by
  intro p hp
  have h : env29647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29646_29647 : H12AffineEnvironment.transform 12 349 env29646 = env29647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env29646 == env29647) = true)

theorem identity29647 : scanCanonicalize (H12AffineFastState.compose env29647 (packedSelected [0,1,2,3,6,7] rootPS)) = affineNative (2^(20+1) ^^^ 4453) := by decide +kernel

theorem selectedBound29647 : packedSelected [0,1,2,3,6,7] rootPS < 2^1333 := by decide +kernel

def env29648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5236,81,263,5173,2341,1024,80,4453,32,65,2,349,64,2128,5172,4097,2421,1285,33,256,33,5237,513]

theorem envBound29648 : H12AffineFastState.Bounded env29648 := by
  intro p hp
  have h : env29648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29647_29648 : H12AffineEnvironment.transform 20 4453 env29647 = env29648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4453 env29647 == env29648) = true)

theorem identity29648 : scanCanonicalize (H12AffineFastState.compose env29648 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound29648 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env29649 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4453,81,263,4388,2341,273,80,4453,32,65,2,349,64,2128,4389,4097,2421,20,33,256,33,4452,513]

theorem envBound29649 : H12AffineFastState.Bounded env29649 := by
  intro p hp
  have h : env29649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29648_29649 : H12AffineEnvironment.transform 9 273 env29648 = env29649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env29648 == env29649) = true)

def env29650 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,2,8328,64,4554890,2196623,2233816,295048,246939,6383042,256,2327590,2319746,189261]

theorem envBound29650 : H12AffineFastState.Bounded env29650 := by
  intro p hp
  have h : env29650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29605_29650 : H12AffineEnvironment.transform 22 147593 env29605 = env29650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env29605 == env29650) = true)

def env29651 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,2,8328,64,4450362,2196623,2233816,190520,246939,6383042,256,2327590,2319746,189261]

theorem envBound29651 : H12AffineFastState.Bounded env29651 := by
  intro p hp
  have h : env29651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29650_29651 : H12AffineEnvironment.transform 17 157872 env29650 = env29651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env29650 == env29651) = true)

theorem identity29651 : scanCanonicalize (H12AffineFastState.compose env29651 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound29651 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29652 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,35188,1024,32769,2097152,4194304,41293,2,8328,64,4262398,2196623,2159644,2556,75103,6383042,256,2188770,2196550,649]

theorem envBound29652 : H12AffineFastState.Bounded env29652 := by
  intro p hp
  have h : env29652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29651_29652 : H12AffineEnvironment.transform 16 57796 env29651 = env29652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env29651 == env29652) = true)

theorem identity29652 : scanCanonicalize (H12AffineFastState.compose env29652 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29652 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1024,32769,2097152,4194304,41293,2,8192,64,4262262,2196487,2159644,2420,75103,6382922,256,2188650,2196550,513]

theorem envBound29653 : H12AffineFastState.Bounded env29653 := by
  intro p hp
  have h : env29653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29652_29653 : H12AffineEnvironment.transform 6 8 env29652 = env29653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env29652 == env29653) = true)

theorem identity29653 : scanCanonicalize (H12AffineFastState.compose env29653 (packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound29653 : packedSelected [1,4,5,8,9,14,16,19,24,26] rootPS < 2^1333 := by decide +kernel

def env29654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1024,32769,2097152,4194304,41293,2,8192,64,4229153,2098512,2159644,2420,41992,6349853,256,2155581,2098449,513]

theorem envBound29654 : H12AffineFastState.Bounded env29654 := by
  intro p hp
  have h : env29654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29653_29654 : H12AffineEnvironment.transform 15 33111 env29653 = env29654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env29653 == env29654) = true)

theorem identity29654 : scanCanonicalize (H12AffineFastState.compose env29654 (packedSelected [11,17,18,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 2155580) := by decide +kernel

theorem selectedBound29654 : packedSelected [11,17,18,23,32] rootPS < 2^1333 := by decide +kernel

def env29655 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1024,32769,2097152,2155580,41293,2,8192,64,2124829,2098512,2159644,2420,41992,33,256,2155581,2098449,513]

theorem envBound29655 : H12AffineFastState.Bounded env29655 := by
  intro p hp
  have h : env29655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29654_29655 : H12AffineEnvironment.transform 21 2155580 env29654 = env29655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env29654 == env29655) = true)

theorem identity29655 : scanCanonicalize (H12AffineFastState.compose env29655 (packedSelected [0,1,3,14,15,17,24,27,28,38] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound29655 : packedSelected [0,1,3,14,15,17,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env29656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33111,57676,35188,1024,32769,17681,41261,41293,2,8192,64,10508,16449,45325,2420,41992,33,256,41260,16384,513]

theorem envBound29656 : H12AffineFastState.Bounded env29656 := by
  intro p hp
  have h : env29656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29655_29656 : H12AffineEnvironment.transform 20 17681 env29655 = env29656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env29655 == env29656) = true)

theorem identity29656 : scanCanonicalize (H12AffineFastState.compose env29656 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound29656 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env29657 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,33030,57629,35109,1024,32769,17681,41261,41244,2,8192,17,10508,16400,45325,2341,41992,33,256,41260,16384,513]

theorem envBound29657 : H12AffineFastState.Bounded env29657 := by
  intro p hp
  have h : env29657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29656_29657 : H12AffineEnvironment.transform 5 17 env29656 = env29657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env29656 == env29657) = true)

theorem identity29657 : scanCanonicalize (H12AffineFastState.compose env29657 (packedSelected [3,4,8,9,10,11] rootPS)) = affineNative (2^(14+1) ^^^ 22053) := by decide +kernel

theorem selectedBound29657 : packedSelected [3,4,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env29658 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,22053,22307,14136,24320,1024,22052,17681,30472,30521,2,8192,17,10508,16400,26408,2341,29229,33,256,30473,16384,513]

theorem envBound29658 : H12AffineFastState.Bounded env29658 := by
  intro p hp
  have h : env29658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29657_29658 : H12AffineEnvironment.transform 14 22053 env29657 = env29658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22053 env29657 == env29658) = true)

theorem identity29658 : scanCanonicalize (H12AffineFastState.compose env29658 (packedSelected [1,8,10,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1061) := by decide +kernel

theorem selectedBound29658 : packedSelected [1,8,10,14,15] rootPS < 2^1333 := by decide +kernel

def env29659 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,1061,4608,4870,14136,6949,1024,4609,308,13101,13084,2,8192,17,10508,1077,8973,2341,13832,33,256,13100,1061,513]

theorem envBound29659 : H12AffineFastState.Bounded env29659 := by
  intro p hp
  have h : env29659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29658_29659 : H12AffineEnvironment.transform 13 1061 env29658 = env29659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1061 env29658 == env29659) = true)

def env29660 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,2,8328,64,4450363,2196623,2233816,190521,246939,6383042,256,2327590,2319746,189261]

theorem envBound29660 : H12AffineFastState.Bounded env29660 := by
  intro p hp
  have h : env29660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29650_29660 : H12AffineEnvironment.transform 17 157873 env29650 = env29660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env29650 == env29660) = true)

theorem identity29660 : scanCanonicalize (H12AffineFastState.compose env29660 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound29660 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env29661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157873,1024,8540,2097152,4194304,147593,2,8328,64,4409702,2172370,2233816,149860,222662,6383042,256,2303355,2319746,147984]

theorem envBound29661 : H12AffineFastState.Bounded env29661 := by
  intro p hp
  have h : env29661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29660_29661 : H12AffineEnvironment.transform 14 8541 env29660 = env29661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env29660 == env29661) = true)

def env29662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10401,1024,8540,2097152,4194304,153,2,8328,64,4262262,2172370,2119112,2420,75222,6383042,256,2188651,2172306,512]

theorem envBound29662 : H12AffineFastState.Bounded env29662 := by
  intro p hp
  have h : env29662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans29661_29662 : H12AffineEnvironment.transform 16 16400 env29661 = env29662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env29661 == env29662) = true)

theorem identity29662 : scanCanonicalize (H12AffineFastState.compose env29662 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound29662 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env29663 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,2097152,4194304,17,2,8192,64,4262262,2172250,2118976,2420,75102,6382922,256,2188651,2172186,512]

end H12CloudChart1