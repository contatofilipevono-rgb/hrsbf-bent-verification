import H12CloudChart1Data128

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound32735 : H12AffineFastState.Bounded env32735 := by
  intro p hp
  have h : env32735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32734_32735 : H12AffineEnvironment.transform 12 268 env32734 = env32735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32734 == env32735) = true)

theorem identity32735 : scanCanonicalize (H12AffineFastState.compose env32735 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32735 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env32736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,65536,5441,2340,1024,80,4160,33,16,65797,269,65,2049,5393,4096,2341,1365,32,256,33,5456,66311]

theorem envBound32736 : H12AffineFastState.Bounded env32736 := by
  intro p hp
  have h : env32736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32735_32736 : H12AffineEnvironment.transform 6 9 env32735 = env32736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32735 == env32736) = true)

def env32737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,17,98781,8328,65,4237692,5392,17665,10401,1501,4256860,256,21792,46212,74250]

theorem envBound32737 : H12AffineFastState.Bounded env32737 := by
  intro p hp
  have h : env32737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32722_32737 : H12AffineEnvironment.transform 20 4161 env32722 = env32737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32722 == env32737) = true)

theorem identity32737 : scanCanonicalize (H12AffineFastState.compose env32737 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144613) := by decide +kernel

theorem selectedBound32737 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,144613,17,98781,8328,65,171417,5392,17665,10401,1501,180409,256,21792,46212,74250]

theorem envBound32738 : H12AffineFastState.Bounded env32738 := by
  intro p hp
  have h : env32738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32737_32738 : H12AffineEnvironment.transform 21 144613 env32737 = env32738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144613 env32737 == env32738) = true)

def env32739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,144493,17,98645,8192,65,171281,5392,17665,10281,1365,180273,256,21792,46092,74250]

theorem envBound32739 : H12AffineFastState.Bounded env32739 := by
  intro p hp
  have h : env32739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32738_32739 : H12AffineEnvironment.transform 6 8 env32738 = env32739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32738 == env32739) = true)

theorem identity32739 : scanCanonicalize (H12AffineFastState.compose env32739 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32739 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4161,144493,17,73737,8192,65,146509,5392,17665,10281,1365,156013,256,21792,5456,74250]

theorem envBound32740 : H12AffineFastState.Bounded env32740 := by
  intro p hp
  have h : env32740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32739_32740 : H12AffineEnvironment.transform 14 8540 env32739 = env32740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32739 == env32740) = true)

theorem identity32740 : scanCanonicalize (H12AffineFastState.compose env32740 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32740 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,65536,131072,146792,1024,8541,4161,144493,17,73737,8192,65,146509,5392,12557,10281,1365,136545,256,8492,5456,74250]

theorem envBound32741 : H12AffineFastState.Bounded env32741 := by
  intro p hp
  have h : env32741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32740_32741 : H12AffineEnvironment.transform 13 13324 env32740 = env32741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32740 == env32741) = true)

theorem identity32741 : scanCanonicalize (H12AffineFastState.compose env32741 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound32741 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env32742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,65536,13673,2049,1024,8541,4161,260,17,73737,8192,65,2340,5392,12557,10281,1365,8200,256,8492,5456,74250]

theorem envBound32742 : H12AffineFastState.Bounded env32742 := by
  intro p hp
  have h : env32742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32741_32742 : H12AffineEnvironment.transform 16 13673 env32741 = env32742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env32741 == env32742) = true)

theorem identity32742 : scanCanonicalize (H12AffineFastState.compose env32742 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32742 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env32743 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8460,65536,13625,2049,1024,8461,4113,260,17,73737,8192,17,2340,5392,12557,10281,1285,8200,256,8492,5376,74250]

theorem envBound32743 : H12AffineFastState.Bounded env32743 := by
  intro p hp
  have h : env32743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32742_32743 : H12AffineEnvironment.transform 5 16 env32742 = env32743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32742 == env32743) = true)

theorem identity32743 : scanCanonicalize (H12AffineFastState.compose env32743 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound32743 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env32744 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13324,8460,8495,13625,2049,1024,8461,4113,260,17,294,8192,17,2340,5392,12557,10281,1285,8200,256,8492,5376,805]

theorem envBound32744 : H12AffineFastState.Bounded env32744 := by
  intro p hp
  have h : env32744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32743_32744 : H12AffineEnvironment.transform 15 8495 env32743 = env32744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env32743 == env32744) = true)

theorem identity32744 : scanCanonicalize (H12AffineFastState.compose env32744 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32744 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env32745 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,13324,8232,8203,13341,2049,1024,8233,4113,32,17,2,8192,17,2048,5172,12329,10281,1057,8200,36,8200,5156,513]

theorem envBound32745 : H12AffineFastState.Bounded env32745 := by
  intro p hp
  have h : env32745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32744_32745 : H12AffineEnvironment.transform 7 36 env32744 = env32745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32744 == env32745) = true)

def env32746 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,144492,17,98644,8193,65,171280,5392,17665,10280,1364,180272,256,21792,46093,74250]

theorem envBound32746 : H12AffineFastState.Bounded env32746 := by
  intro p hp
  have h : env32746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32738_32746 : H12AffineEnvironment.transform 6 9 env32738 = env32746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32738 == env32746) = true)

theorem identity32746 : scanCanonicalize (H12AffineFastState.compose env32746 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound32746 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32747 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190521,1024,32769,4161,144492,17,2,8193,65,171280,5392,17665,10280,1364,180272,256,21792,46093,41820]

theorem envBound32747 : H12AffineFastState.Bounded env32747 := by
  intro p hp
  have h : env32747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32746_32747 : H12AffineEnvironment.transform 15 33110 env32746 = env32747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env32746 == env32747) = true)

theorem identity32747 : scanCanonicalize (H12AffineFastState.compose env32747 (packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32747 : packedSelected [0,4,8,10,12,14,15,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env32748 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,343,131072,157752,1024,0,4161,144492,17,2,8193,65,138513,5392,17665,10280,1364,147505,256,21792,13324,9053]

theorem envBound32748 : H12AffineFastState.Bounded env32748 := by
  intro p hp
  have h : env32748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32747_32748 : H12AffineEnvironment.transform 14 1 env32747 = env32748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32747 == env32748) = true)

theorem identity32748 : scanCanonicalize (H12AffineFastState.compose env32748 (packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound32748 : packedSelected [0,1,3,4,5,7,8,10,16,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env32749 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,343,24908,2420,1024,0,4161,21792,17,2,8193,65,31837,5392,17665,10280,1364,8573,256,21792,13324,9053]

theorem envBound32749 : H12AffineFastState.Bounded env32749 := by
  intro p hp
  have h : env32749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32748_32749 : H12AffineEnvironment.transform 16 24908 env32748 = env32749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env32748 == env32749) = true)

theorem identity32749 : scanCanonicalize (H12AffineFastState.compose env32749 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32749 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env32750 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,1,343,16448,2420,1024,0,4161,21792,17,2,269,65,23889,5392,17665,2340,1364,113,256,21792,5376,593]

theorem envBound32750 : H12AffineFastState.Bounded env32750 := by
  intro p hp
  have h : env32750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32749_32750 : H12AffineEnvironment.transform 12 268 env32749 = env32750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32749 == env32750) = true)

theorem identity32750 : scanCanonicalize (H12AffineFastState.compose env32750 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32750 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32751 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,263,16400,2340,1024,0,4113,21792,17,2,269,17,23809,5392,17665,2340,1284,33,256,21792,5376,513]

theorem envBound32751 : H12AffineFastState.Bounded env32751 := by
  intro p hp
  have h : env32751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32750_32751 : H12AffineEnvironment.transform 5 16 env32750 = env32751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32750 == env32751) = true)

def env32752 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101329,98780,8328,65,6338876,2098512,17664,2111712,2102684,6349852,256,21792,46212,2175563]

theorem envBound32752 : H12AffineFastState.Bounded env32752 := by
  intro p hp
  have h : env32752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32721_32752 : H12AffineEnvironment.transform 17 190641 env32721 = env32752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env32721 == env32752) = true)

def env32753 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,17,98780,8328,65,4237692,5392,17664,10400,1500,4256860,256,21792,46212,74251]

theorem envBound32753 : H12AffineFastState.Bounded env32753 := by
  intro p hp
  have h : env32753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32752_32753 : H12AffineEnvironment.transform 20 4160 env32752 = env32753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32752 == env32753) = true)

theorem identity32753 : scanCanonicalize (H12AffineFastState.compose env32753 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180273) := by decide +kernel

theorem selectedBound32753 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32754 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,180273,17,98780,8328,65,158029,5392,17664,10400,1500,144493,256,21792,46212,74251]

theorem envBound32754 : H12AffineFastState.Bounded env32754 := by
  intro p hp
  have h : env32754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32753_32754 : H12AffineEnvironment.transform 21 180273 env32753 = env32754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180273 env32753 == env32754) = true)

theorem identity32754 : scanCanonicalize (H12AffineFastState.compose env32754 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32754 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env32755 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190641,1024,32769,4160,180273,17,41430,8328,65,158029,5392,17664,10400,1500,144493,256,21792,46212,513]

theorem envBound32755 : H12AffineFastState.Bounded env32755 := by
  intro p hp
  have h : env32755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32754_32755 : H12AffineEnvironment.transform 15 8202 env32754 = env32755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32754 == env32755) = true)

theorem identity32755 : scanCanonicalize (H12AffineFastState.compose env32755 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound32755 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32756 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43169,1024,32769,4160,32801,17,41430,8328,65,10589,5392,17664,10400,1500,29821,256,21792,46212,513]

theorem envBound32756 : H12AffineFastState.Bounded env32756 := by
  intro p hp
  have h : env32756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32755_32756 : H12AffineEnvironment.transform 16 16400 env32755 = env32756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env32755 == env32756) = true)

theorem identity32756 : scanCanonicalize (H12AffineFastState.compose env32756 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound32756 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env32757 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8202,16400,23724,1024,29708,4160,29740,17,21979,8328,65,10589,5392,17664,10400,1500,29821,256,21792,16521,513]

theorem envBound32757 : H12AffineFastState.Bounded env32757 := by
  intro p hp
  have h : env32757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32756_32757 : H12AffineEnvironment.transform 14 29709 env32756 = env32757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env32756 == env32757) = true)

theorem identity32757 : scanCanonicalize (H12AffineFastState.compose env32757 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32757 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env32758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29709,8202,16400,23588,1024,29708,4160,29740,17,21843,8192,65,10589,5392,17664,10280,1364,29821,256,21792,16385,513]

theorem envBound32758 : H12AffineFastState.Bounded env32758 := by
  intro p hp
  have h : env32758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32757_32758 : H12AffineEnvironment.transform 6 8 env32757 = env32758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32757 == env32758) = true)

theorem identity32758 : scanCanonicalize (H12AffineFastState.compose env32758 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound32758 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4404,9529,8202,4388,3344,1024,9528,4160,9496,17,1127,8192,65,10589,5392,5172,10280,1364,9545,256,1044,4405,513]

theorem envBound32759 : H12AffineFastState.Bounded env32759 := by
  intro p hp
  have h : env32759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32758_32759 : H12AffineEnvironment.transform 13 4404 env32758 = env32759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env32758 == env32759) = true)

theorem identity32759 : scanCanonicalize (H12AffineFastState.compose env32759 (packedSelected [0,4,5,6,7,8,9,10,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32759 : packedSelected [0,4,5,6,7,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env32760 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,4161,9292,8202,4177,3173,1024,9293,4160,9325,17,1127,8192,65,10280,5221,5172,10280,1057,9276,117,1044,4160,513]

theorem envBound32760 : H12AffineFastState.Bounded env32760 := by
  intro p hp
  have h : env32760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32759_32760 : H12AffineEnvironment.transform 7 117 env32759 = env32760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32759 == env32760) = true)

theorem identity32760 : scanCanonicalize (H12AffineFastState.compose env32760 (packedSelected [0,2,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound32760 : packedSelected [0,2,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env32761 : List Nat := [2,4,8,16,32,64,8,117,512,53,2048,4096,8192,4161,8313,8202,4177,2128,53,8312,4160,8280,17,82,8192,65,10280,4176,4097,10280,20,8201,117,33,4160,513]

theorem envBound32761 : H12AffineFastState.Bounded env32761 := by
  intro p hp
  have h : env32761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32760_32761 : H12AffineEnvironment.transform 9 53 env32760 = env32761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32760 == env32761) = true)

theorem identity32761 : scanCanonicalize (H12AffineFastState.compose env32761 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32761 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32762 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,8192,4112,8232,8202,4096,2049,53,8233,4113,8201,17,3,8192,16,10280,4097,4097,10280,20,8201,36,33,4113,513]

theorem envBound32762 : H12AffineFastState.Bounded env32762 := by
  intro p hp
  have h : env32762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32761_32762 : H12AffineEnvironment.transform 5 17 env32761 = env32762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32761 == env32762) = true)

def env32763 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,16,98780,8328,65,4237693,5393,17664,10401,1501,4256861,256,21792,46212,74250]

theorem envBound32763 : H12AffineFastState.Bounded env32763 := by
  intro p hp
  have h : env32763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32752_32763 : H12AffineEnvironment.transform 20 4161 env32752 = env32763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32752 == env32763) = true)

def env32764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,4194304,16,98644,8192,65,4237693,5393,17664,10281,1365,4256861,256,21792,46092,74250]

theorem envBound32764 : H12AffineFastState.Bounded env32764 := by
  intro p hp
  have h : env32764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32763_32764 : H12AffineEnvironment.transform 6 8 env32763 = env32764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32763 == env32764) = true)

theorem identity32764 : scanCanonicalize (H12AffineFastState.compose env32764 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound32764 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4161,4194304,16,98644,8192,65,4237693,5393,17664,10281,1365,4256861,256,21792,46092,74250]

theorem envBound32765 : H12AffineFastState.Bounded env32765 := by
  intro p hp
  have h : env32765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32764_32765 : H12AffineEnvironment.transform 16 24908 env32764 = env32765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env32764 == env32765) = true)

theorem identity32765 : scanCanonicalize (H12AffineFastState.compose env32765 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 62508) := by decide +kernel

theorem selectedBound32765 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35189,1024,32769,4161,62508,16,98644,8192,65,23889,5393,17664,10281,1365,113,256,21792,46092,74250]

theorem envBound32766 : H12AffineFastState.Bounded env32766 := by
  intro p hp
  have h : env32766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32765_32766 : H12AffineEnvironment.transform 21 62508 env32765 = env32766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62508 env32765 == env32766) = true)

theorem identity32766 : scanCanonicalize (H12AffineFastState.compose env32766 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound32766 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env32767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30042,24908,35189,1024,32769,4161,62508,16,62478,8192,65,23889,5393,17664,10281,1365,113,256,21792,46092,22352]

theorem envBound32767 : H12AffineFastState.Bounded env32767 := by
  intro p hp
  have h : env32767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32766_32767 : H12AffineEnvironment.transform 15 30042 env32766 = env32767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env32766 == env32767) = true)

theorem identity32767 : scanCanonicalize (H12AffineFastState.compose env32767 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound32767 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env32768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,80,30042,24908,2341,1024,81,4161,29820,16,29790,8192,65,23889,5393,17664,10281,1365,113,256,21792,13404,22352]

theorem envBound32768 : H12AffineFastState.Bounded env32768 := by
  intro p hp
  have h : env32768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32767_32768 : H12AffineEnvironment.transform 14 80 env32767 = env32768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env32767 == env32768) = true)

theorem identity32768 : scanCanonicalize (H12AffineFastState.compose env32768 (packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound32768 : packedSelected [1,2,3,5,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env32769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5125,80,8543,13641,2341,1024,81,4161,8313,16,8283,8192,65,2388,5393,4357,10281,1365,113,256,293,13404,853]

theorem envBound32769 : H12AffineFastState.Bounded env32769 := by
  intro p hp
  have h : env32769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32768_32769 : H12AffineEnvironment.transform 13 5125 env32768 = env32769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env32768 == env32769) = true)

theorem identity32769 : scanCanonicalize (H12AffineFastState.compose env32769 (packedSelected [4,6,9,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32769 : packedSelected [4,6,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env32770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5125,80,83,5189,2341,1024,81,4161,373,16,343,268,65,2388,5393,4357,2341,1365,113,256,293,5456,853]

theorem envBound32770 : H12AffineFastState.Bounded env32770 := by
  intro p hp
  have h : env32770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32769_32770 : H12AffineEnvironment.transform 12 268 env32769 = env32770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32769 == env32770) = true)

theorem identity32770 : scanCanonicalize (H12AffineFastState.compose env32770 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32770 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32771 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,5125,80,83,5189,2128,1024,81,4161,0,16,34,121,65,2081,5220,4208,2128,1056,113,117,80,5157,544]

theorem envBound32771 : H12AffineFastState.Bounded env32771 := by
  intro p hp
  have h : env32771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32770_32771 : H12AffineEnvironment.transform 7 117 env32770 = env32771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32770 == env32771) = true)

theorem identity32771 : scanCanonicalize (H12AffineFastState.compose env32771 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound32771 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32772 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,2065,121,3092,80,83,3156,2128,1024,81,2128,0,16,34,121,65,2081,3189,2145,2128,1056,113,117,80,3124,544]

theorem envBound32772 : H12AffineFastState.Bounded env32772 := by
  intro p hp
  have h : env32772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32771_32772 : H12AffineEnvironment.transform 11 2065 env32771 = env32772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env32771 == env32772) = true)

theorem identity32772 : scanCanonicalize (H12AffineFastState.compose env32772 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1092) := by decide +kernel

theorem selectedBound32772 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env32773 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1092,1109,121,80,80,83,16,1044,1024,81,1044,0,16,34,121,65,1125,49,1061,1044,1056,113,117,80,112,544]

theorem envBound32773 : H12AffineFastState.Bounded env32773 := by
  intro p hp
  have h : env32773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32772_32773 : H12AffineEnvironment.transform 10 1092 env32772 = env32773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1092 env32772 == env32773) = true)

theorem identity32773 : scanCanonicalize (H12AffineFastState.compose env32773 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound32773 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env32774 : List Nat := [2,4,8,16,32,64,8,117,512,100,32,49,121,80,80,83,16,112,100,81,112,0,16,34,121,65,1,49,65,112,68,113,117,80,112,544]

theorem envBound32774 : H12AffineFastState.Bounded env32774 := by
  intro p hp
  have h : env32774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32773_32774 : H12AffineEnvironment.transform 9 100 env32773 = env32774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env32773 == env32774) = true)

theorem identity32774 : scanCanonicalize (H12AffineFastState.compose env32774 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound32774 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env32775 : List Nat := [2,4,8,16,32,0,8,53,512,36,32,49,57,16,16,19,16,48,36,17,48,0,16,34,57,1,1,49,1,48,4,49,53,16,48,544]

theorem envBound32775 : H12AffineFastState.Bounded env32775 := by
  intro p hp
  have h : env32775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32774_32775 : H12AffineEnvironment.transform 5 0 env32774 = env32775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env32774 == env32775) = true)

theorem identity32775 : scanCanonicalize (H12AffineFastState.compose env32775 (packedSelected [0,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound32775 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env32776 : List Nat := [2,4,8,16,32,0,8,53,32,36,32,49,57,16,16,19,16,48,36,17,48,0,16,34,57,1,1,49,1,48,4,49,53,16,48,0]

theorem envBound32776 : H12AffineFastState.Bounded env32776 := by
  intro p hp
  have h : env32776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32775_32776 : H12AffineEnvironment.transform 8 32 env32775 = env32776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env32775 == env32776) = true)

theorem identity32776 : scanCanonicalize (H12AffineFastState.compose env32776 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32776 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env32777 : List Nat := [2,4,8,16,0,0,8,21,0,4,0,17,25,16,16,19,16,16,4,17,16,0,16,2,25,1,1,17,1,16,4,17,21,16,16,0]

theorem envBound32777 : H12AffineFastState.Bounded env32777 := by
  intro p hp
  have h : env32777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32776_32777 : H12AffineEnvironment.transform 4 0 env32776 = env32777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32776 == env32777) = true)

def env32778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,4194304,16,98645,8193,65,4237693,5393,17664,10280,1364,4256861,256,21792,46093,74250]

theorem envBound32778 : H12AffineFastState.Bounded env32778 := by
  intro p hp
  have h : env32778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32763_32778 : H12AffineEnvironment.transform 6 9 env32763 = env32778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32763 == env32778) = true)

theorem identity32778 : scanCanonicalize (H12AffineFastState.compose env32778 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound32778 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32779 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,4194304,16,98645,8193,65,4237693,5393,17664,10280,1364,4256861,256,21792,46093,74250]

theorem envBound32779 : H12AffineFastState.Bounded env32779 := by
  intro p hp
  have h : env32779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32778_32779 : H12AffineEnvironment.transform 16 49168 env32778 = env32779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env32778 == env32779) = true)

theorem identity32779 : scanCanonicalize (H12AffineFastState.compose env32779 (packedSelected [18,23] rootPS)) = affineNative (2^(21+1) ^^^ 65910) := by decide +kernel

theorem selectedBound32779 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env32780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,65910,16,98645,8193,65,108555,5393,17664,10280,1364,128299,256,21792,46093,74250]

theorem envBound32780 : H12AffineFastState.Bounded env32780 := by
  intro p hp
  have h : env32780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32779_32780 : H12AffineEnvironment.transform 21 65910 env32779 = env32780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65910 env32779 == env32780) = true)

theorem identity32780 : scanCanonicalize (H12AffineFastState.compose env32780 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32780 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env32781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,49168,10280,1024,32769,4161,8573,16,41310,8193,65,34816,5393,17664,10280,1364,54560,256,21792,46093,513]

theorem envBound32781 : H12AffineFastState.Bounded env32781 := by
  intro p hp
  have h : env32781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32780_32781 : H12AffineEnvironment.transform 15 8203 env32780 = env32781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32780 == env32781) = true)

theorem identity32781 : scanCanonicalize (H12AffineFastState.compose env32781 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound32781 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8203,38160,10280,1024,32769,4161,8573,16,41310,8193,65,34816,5393,4096,10280,1364,32800,256,32,46093,513]

theorem envBound32782 : H12AffineFastState.Bounded env32782 := by
  intro p hp
  have h : env32782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32781_32782 : H12AffineEnvironment.transform 13 5376 env32781 = env32782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env32781 == env32782) = true)

theorem identity32782 : scanCanonicalize (H12AffineFastState.compose env32782 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound32782 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,0,8203,5392,10280,1024,1,4161,8573,16,8542,8193,65,2048,5393,4096,10280,1364,32,256,32,13325,513]

theorem envBound32783 : H12AffineFastState.Bounded env32783 := by
  intro p hp
  have h : env32783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32782_32783 : H12AffineEnvironment.transform 14 0 env32782 = env32783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env32782 == env32783) = true)

theorem identity32783 : scanCanonicalize (H12AffineFastState.compose env32783 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 3378) := by decide +kernel

theorem selectedBound32783 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,3378,5376,0,3385,5392,1306,1024,1,4161,3151,16,3180,3379,65,2048,5393,4096,1306,1364,32,256,32,6463,513]

theorem envBound32784 : H12AffineFastState.Bounded env32784 := by
  intro p hp
  have h : env32784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32783_32784 : H12AffineEnvironment.transform 12 3378 env32783 = env32784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3378 env32783 == env32784) = true)

def env32785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2554081,485741,8328,65,6705548,2551265,437680,2111713,2102685,6687917,256,21793,46213,2175562]

theorem envBound32785 : H12AffineFastState.Bounded env32785 := by
  intro p hp
  have h : env32785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32720_32785 : H12AffineEnvironment.transform 22 2554081 env32720 = env32785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2554081 env32720 == env32785) = true)

def env32786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,2097152,4194304,2101329,98781,8328,65,6338876,2098513,17664,2111713,2102685,6349853,256,21793,46213,2175562]

theorem envBound32786 : H12AffineFastState.Bounded env32786 := by
  intro p hp
  have h : env32786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32785_32786 : H12AffineEnvironment.transform 17 190640 env32785 = env32786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190640 env32785 == env32786) = true)

def env32787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,4194304,17,98781,8328,65,4237692,5393,17664,10401,1501,4256861,256,21793,46213,74250]

theorem envBound32787 : H12AffineFastState.Bounded env32787 := by
  intro p hp
  have h : env32787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32786_32787 : H12AffineEnvironment.transform 20 4160 env32786 = env32787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32786 == env32787) = true)

theorem identity32787 : scanCanonicalize (H12AffineFastState.compose env32787 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 201967) := by decide +kernel

theorem selectedBound32787 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4160,201967,17,98781,8328,65,245139,5393,17664,10401,1501,254130,256,21793,46213,74250]

theorem envBound32788 : H12AffineFastState.Bounded env32788 := by
  intro p hp
  have h : env32788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32787_32788 : H12AffineEnvironment.transform 21 201967 env32787 = env32788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 201967 env32787 == env32788) = true)

def env32789 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,201831,17,98645,8192,65,245019,5393,17664,10281,1365,254010,256,21793,46093,74250]

theorem envBound32789 : H12AffineFastState.Bounded env32789 := by
  intro p hp
  have h : env32789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32788_32789 : H12AffineEnvironment.transform 6 8 env32788 = env32789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32788 == env32789) = true)

theorem identity32789 : scanCanonicalize (H12AffineFastState.compose env32789 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32789 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32790 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149860,1024,8541,4160,201831,17,73737,8192,65,203847,5393,17664,10281,1365,213350,256,21793,5457,74250]

theorem envBound32790 : H12AffineFastState.Bounded env32790 := by
  intro p hp
  have h : env32790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32789_32790 : H12AffineEnvironment.transform 14 8540 env32789 = env32790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32789 == env32790) = true)

theorem identity32790 : scanCanonicalize (H12AffineFastState.compose env32790 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound32790 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32791 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,65536,131072,146793,1024,8541,4160,201831,17,73737,8192,65,203847,5393,12557,10281,1365,210283,256,8492,5457,74250]

theorem envBound32791 : H12AffineFastState.Bounded env32791 := by
  intro p hp
  have h : env32791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32790_32791 : H12AffineEnvironment.transform 13 13325 env32790 = env32791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env32790 == env32791) = true)

theorem identity32791 : scanCanonicalize (H12AffineFastState.compose env32791 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 79178) := by decide +kernel

theorem selectedBound32791 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env32792 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,65536,79178,67619,1024,8541,4160,8493,17,73737,8192,65,10509,5393,12557,10281,1365,33,256,8492,5457,74250]

theorem envBound32792 : H12AffineFastState.Bounded env32792 := by
  intro p hp
  have h : env32792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32791_32792 : H12AffineEnvironment.transform 16 79178 env32791 = env32792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79178 env32791 == env32792) = true)

theorem identity32792 : scanCanonicalize (H12AffineFastState.compose env32792 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound32792 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env32793 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4405,1124,65536,69746,67619,1024,1125,4160,1045,17,66865,1336,65,3125,5393,5173,3345,1365,33,256,1044,5457,67378]

theorem envBound32793 : H12AffineFastState.Bounded env32793 := by
  intro p hp
  have h : env32793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32792_32793 : H12AffineEnvironment.transform 12 1336 env32792 = env32793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env32792 == env32793) = true)

theorem identity32793 : scanCanonicalize (H12AffineFastState.compose env32793 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(11+1) ^^^ 2112) := by decide +kernel

theorem selectedBound32793 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env32794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,1336,2421,1124,65536,67634,67619,1024,1125,2048,1045,17,66865,1336,65,3125,3409,3189,3345,1365,33,256,1044,3345,67378]

theorem envBound32794 : H12AffineFastState.Bounded env32794 := by
  intro p hp
  have h : env32794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32793_32794 : H12AffineEnvironment.transform 11 2112 env32793 = env32794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2112 env32793 == env32794) = true)

theorem identity32794 : scanCanonicalize (H12AffineFastState.compose env32794 (packedSelected [0,1,3,5,7,8,12,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound32794 : packedSelected [0,1,3,5,7,8,12,14,18] rootPS < 2^1333 := by decide +kernel

def env32795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2112,1336,2421,1124,343,2405,2420,1024,1125,2048,1045,17,1126,1336,65,3125,3409,3189,3345,1365,33,256,1044,3345,1637]

theorem envBound32795 : H12AffineFastState.Bounded env32795 := by
  intro p hp
  have h : env32795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32794_32795 : H12AffineEnvironment.transform 15 343 env32794 = env32795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env32794 == env32795) = true)

theorem identity32795 : scanCanonicalize (H12AffineFastState.compose env32795 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound32795 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,1360,1336,1125,1124,343,1141,1124,1024,1125,1296,1045,17,1126,1336,65,293,65,357,1,1365,33,256,1044,1,1637]

theorem envBound32796 : H12AffineFastState.Bounded env32796 := by
  intro p hp
  have h : env32796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32795_32796 : H12AffineEnvironment.transform 10 1296 env32795 = env32796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env32795 == env32796) = true)

theorem identity32796 : scanCanonicalize (H12AffineFastState.compose env32796 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound32796 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env32797 : List Nat := [2,4,8,16,32,64,8,256,512,321,81,17,121,292,293,343,308,293,321,292,81,340,17,295,121,65,293,65,357,1,20,33,256,341,1,804]

theorem envBound32797 : H12AffineFastState.Bounded env32797 := by
  intro p hp
  have h : env32797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32796_32797 : H12AffineEnvironment.transform 9 321 env32796 = env32797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env32796 == env32797) = true)

theorem identity32797 : scanCanonicalize (H12AffineFastState.compose env32797 (packedSelected [0,2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 65) := by decide +kernel

theorem selectedBound32797 : packedSelected [0,2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env32798 : List Nat := [2,4,8,16,32,64,8,65,512,0,81,17,121,101,100,22,117,100,0,101,81,21,17,102,121,65,100,65,36,1,20,33,65,20,1,613]

theorem envBound32798 : H12AffineFastState.Bounded env32798 := by
  intro p hp
  have h : env32798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32797_32798 : H12AffineEnvironment.transform 7 65 env32797 = env32798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 65 env32797 == env32798) = true)

theorem identity32798 : scanCanonicalize (H12AffineFastState.compose env32798 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(5+1) ^^^ 37) := by decide +kernel

theorem selectedBound32798 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env32799 : List Nat := [2,4,8,16,32,37,8,36,512,0,52,17,28,0,1,22,16,1,0,0,52,21,17,3,28,36,1,36,36,1,20,33,36,20,1,512]

theorem envBound32799 : H12AffineFastState.Bounded env32799 := by
  intro p hp
  have h : env32799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32798_32799 : H12AffineEnvironment.transform 5 37 env32798 = env32799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 37 env32798 == env32799) = true)

theorem identity32799 : scanCanonicalize (H12AffineFastState.compose env32799 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound32799 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32800 : List Nat := [2,4,8,14,32,37,8,36,512,0,42,15,2,0,1,8,14,1,0,0,42,11,15,3,2,36,1,36,36,1,10,33,36,10,1,512]

theorem envBound32800 : H12AffineFastState.Bounded env32800 := by
  intro p hp
  have h : env32800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32799_32800 : H12AffineEnvironment.transform 3 14 env32799 = env32800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env32799 == env32800) = true)

theorem identity32800 : scanCanonicalize (H12AffineFastState.compose env32800 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound32800 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env32801 : List Nat := [2,4,8,14,32,37,8,36,34,0,42,15,2,0,1,8,14,1,0,0,42,11,15,3,2,36,1,36,36,1,10,33,36,10,1,34]

theorem envBound32801 : H12AffineFastState.Bounded env32801 := by
  intro p hp
  have h : env32801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32800_32801 : H12AffineEnvironment.transform 8 34 env32800 = env32801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env32800 == env32801) = true)

theorem identity32801 : scanCanonicalize (H12AffineFastState.compose env32801 (packedSelected [0,1,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound32801 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env32802 : List Nat := [2,4,3,5,32,37,3,36,34,0,33,4,2,0,1,3,5,1,0,0,33,0,4,3,2,36,1,36,36,1,1,33,36,1,1,34]

theorem envBound32802 : H12AffineFastState.Bounded env32802 := by
  intro p hp
  have h : env32802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32801_32802 : H12AffineEnvironment.transform 2 3 env32801 = env32802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env32801 == env32802) = true)

theorem identity32802 : scanCanonicalize (H12AffineFastState.compose env32802 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound32802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32803 : List Nat := [2,1,3,0,32,32,3,33,34,0,33,1,2,0,1,3,0,1,0,0,33,0,1,3,2,33,1,33,33,1,1,33,33,1,1,34]

theorem envBound32803 : H12AffineFastState.Bounded env32803 := by
  intro p hp
  have h : env32803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32802_32803 : H12AffineEnvironment.transform 1 1 env32802 = env32803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env32802 == env32803) = true)

def env32804 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4160,201830,17,98644,8193,65,245018,5393,17664,10280,1364,254011,256,21793,46092,74250]

theorem envBound32804 : H12AffineFastState.Bounded env32804 := by
  intro p hp
  have h : env32804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32788_32804 : H12AffineEnvironment.transform 6 9 env32788 = env32804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32788 == env32804) = true)

theorem identity32804 : scanCanonicalize (H12AffineFastState.compose env32804 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound32804 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32805 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,131072,190521,1024,32769,4160,169264,17,2,8193,65,146508,5393,17664,10280,1364,156013,256,21793,46092,41820]

theorem envBound32805 : H12AffineFastState.Bounded env32805 := by
  intro p hp
  have h : env32805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32804_32805 : H12AffineEnvironment.transform 15 33110 env32804 = env32805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env32804 == env32805) = true)

theorem identity32805 : scanCanonicalize (H12AffineFastState.compose env32805 (packedSelected [7,8,10,12,14,15,16,27,28] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound32805 : packedSelected [7,8,10,12,14,15,16,27,28] rootPS < 2^1333 := by decide +kernel

def env32806 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,33110,57677,2420,1024,32769,4160,29821,17,2,8193,65,56577,5393,17664,10280,1364,32800,256,21793,46092,41820]

theorem envBound32806 : H12AffineFastState.Bounded env32806 := by
  intro p hp
  have h : env32806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32805_32806 : H12AffineEnvironment.transform 16 57677 env32805 = env32806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env32805 == env32806) = true)

theorem identity32806 : scanCanonicalize (H12AffineFastState.compose env32806 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound32806 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env32807 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,29962,5393,2420,1024,29789,4160,29821,17,2,8193,65,10589,5393,17664,10280,1364,29820,256,21793,16464,22272]

theorem envBound32807 : H12AffineFastState.Bounded env32807 := by
  intro p hp
  have h : env32807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32806_32807 : H12AffineEnvironment.transform 14 29788 env32806 = env32807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env32806 == env32807) = true)

theorem identity32807 : scanCanonicalize (H12AffineFastState.compose env32807 (packedSelected [0,7,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 6160) := by decide +kernel

theorem selectedBound32807 : packedSelected [0,7,11,18] rootPS < 2^1333 := by decide +kernel

def env32808 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,6160,11340,11546,5393,2420,1024,11341,4160,11373,17,2,8193,65,10589,5393,7440,10280,1364,11372,256,3377,6208,3856]

theorem envBound32808 : H12AffineFastState.Bounded env32808 := by
  intro p hp
  have h : env32808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32807_32808 : H12AffineEnvironment.transform 13 6160 env32807 = env32808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6160 env32807 == env32808) = true)

theorem identity32808 : scanCanonicalize (H12AffineFastState.compose env32808 (packedSelected [0,1,2,4,6,7,8,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound32808 : packedSelected [0,1,2,4,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env32809 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1376,4096,8192,5488,8492,8314,5393,1044,1024,8493,4160,8461,17,2,8193,65,9277,5393,4208,9544,1364,8460,256,81,5408,624]

theorem envBound32809 : H12AffineFastState.Bounded env32809 := by
  intro p hp
  have h : env32809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32808_32809 : H12AffineEnvironment.transform 10 1376 env32808 = env32809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env32808 == env32809) = true)

theorem identity32809 : scanCanonicalize (H12AffineFastState.compose env32809 (packedSelected [1,2,3,5,6,8,10,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound32809 : packedSelected [1,2,3,5,6,8,10,19] rootPS < 2^1333 := by decide +kernel

def env32810 : List Nat := [2,4,8,16,0,64,9,256,512,1024,1344,4096,8192,5456,8460,8282,5393,1044,1024,8461,4160,8461,17,2,8193,65,9245,5393,4176,9544,1364,8460,256,81,5376,592]

theorem envBound32810 : H12AffineFastState.Bounded env32810 := by
  intro p hp
  have h : env32810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32809_32810 : H12AffineEnvironment.transform 4 0 env32809 = env32810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env32809 == env32810) = true)

theorem identity32810 : scanCanonicalize (H12AffineFastState.compose env32810 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32810 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32811 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1296,4096,8192,5376,8460,8202,5393,1044,1024,8461,4112,8461,17,2,8193,17,9245,5393,4096,9496,1284,8460,256,1,5376,512]

theorem envBound32811 : H12AffineFastState.Bounded env32811 := by
  intro p hp
  have h : env32811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32810_32811 : H12AffineEnvironment.transform 5 16 env32810 = env32811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32810 == env32811) = true)

theorem identity32811 : scanCanonicalize (H12AffineFastState.compose env32811 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32811 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32812 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1296,4096,268,5376,0,262,5393,1044,1024,1,4112,1,17,2,269,17,1297,5393,4096,1044,1284,0,256,1,5376,512]

theorem envBound32812 : H12AffineFastState.Bounded env32812 := by
  intro p hp
  have h : env32812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32811_32812 : H12AffineEnvironment.transform 12 268 env32811 = env32812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32811 == env32812) = true)

theorem identity32812 : scanCanonicalize (H12AffineFastState.compose env32812 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 276) := by decide +kernel

theorem selectedBound32812 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32813 : List Nat := [2,4,8,16,0,16,9,256,512,1024,1296,276,268,1044,0,262,1029,1044,1024,1,260,1,17,2,269,17,1297,1029,276,1044,1284,0,256,1,1044,512]

theorem envBound32813 : H12AffineFastState.Bounded env32813 := by
  intro p hp
  have h : env32813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32812_32813 : H12AffineEnvironment.transform 11 276 env32812 = env32813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 276 env32812 == env32813) = true)

theorem identity32813 : scanCanonicalize (H12AffineFastState.compose env32813 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound32813 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32814 : List Nat := [2,4,8,16,0,16,9,256,512,20,260,276,268,0,0,262,17,0,20,1,260,1,17,2,269,17,261,17,276,0,272,0,256,1,0,512]

theorem envBound32814 : H12AffineFastState.Bounded env32814 := by
  intro p hp
  have h : env32814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32813_32814 : H12AffineEnvironment.transform 9 20 env32813 = env32814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env32813 == env32814) = true)

def env32815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190640,1024,32769,4161,4194304,16,98781,8328,65,4237693,5392,17664,10400,1500,4256860,256,21793,46213,74251]

theorem envBound32815 : H12AffineFastState.Bounded env32815 := by
  intro p hp
  have h : env32815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32786_32815 : H12AffineEnvironment.transform 20 4161 env32786 = env32815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32786 == env32815) = true)

theorem identity32815 : scanCanonicalize (H12AffineFastState.compose env32815 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound32815 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,190640,1024,32769,4161,4194304,16,21763,8328,65,4237693,5392,17664,10400,1500,4256860,256,21793,46213,63189]

theorem envBound32816 : H12AffineFastState.Bounded env32816 := by
  intro p hp
  have h : env32816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32815_32816 : H12AffineEnvironment.transform 15 54494 env32815 = env32816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env32815 == env32816) = true)

def env32817 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,190520,1024,32769,4161,4194304,16,21763,8192,65,4237693,5392,17664,10280,1364,4256860,256,21793,46093,63069]

theorem envBound32817 : H12AffineFastState.Bounded env32817 := by
  intro p hp
  have h : env32817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32816_32817 : H12AffineEnvironment.transform 6 8 env32816 = env32817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32816 == env32817) = true)

theorem identity32817 : scanCanonicalize (H12AffineFastState.compose env32817 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound32817 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4161,4194304,16,21763,8192,65,4237693,5392,17664,10280,1364,4256860,256,21793,46093,63069]

theorem envBound32818 : H12AffineFastState.Bounded env32818 := by
  intro p hp
  have h : env32818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32817_32818 : H12AffineEnvironment.transform 16 24909 env32817 = env32818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env32817 == env32818) = true)

theorem identity32818 : scanCanonicalize (H12AffineFastState.compose env32818 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 54560) := by decide +kernel

theorem selectedBound32818 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,35189,1024,32769,4161,54560,16,21763,8192,65,31837,5392,17664,10280,1364,8572,256,21793,46093,63069]

theorem envBound32819 : H12AffineFastState.Bounded env32819 := by
  intro p hp
  have h : env32819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32818_32819 : H12AffineEnvironment.transform 21 54560 env32818 = env32819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 54560 env32818 == env32819) = true)

theorem identity32819 : scanCanonicalize (H12AffineFastState.compose env32819 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32819 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env32820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,24909,10281,1024,8541,4161,29820,16,21763,8192,65,31837,5392,17664,10280,1364,8572,256,21793,5457,22273]

theorem envBound32820 : H12AffineFastState.Bounded env32820 := by
  intro p hp
  have h : env32820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32819_32820 : H12AffineEnvironment.transform 14 8540 env32819 = env32820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32819 == env32820) = true)

theorem identity32820 : scanCanonicalize (H12AffineFastState.compose env32820 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound32820 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,4112,8540,9498,12637,10281,1024,8541,4161,9324,16,1299,8192,65,11341,5392,5392,10280,1364,8572,256,1329,5457,1809]

theorem envBound32821 : H12AffineFastState.Bounded env32821 := by
  intro p hp
  have h : env32821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32820_32821 : H12AffineEnvironment.transform 13 4112 env32820 = env32821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env32820 == env32821) = true)

theorem identity32821 : scanCanonicalize (H12AffineFastState.compose env32821 (packedSelected [11,18] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound32821 : packedSelected [11,18] rootPS < 2^1333 := by decide +kernel

def env32822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,4112,1124,34,5221,3345,1024,1125,4161,340,16,1299,1336,65,2421,5392,5392,3344,1364,1092,256,1329,5457,1809]

theorem envBound32822 : H12AffineFastState.Bounded env32822 := by
  intro p hp
  have h : env32822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32821_32822 : H12AffineEnvironment.transform 12 1336 env32821 = env32822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env32821 == env32822) = true)

theorem identity32822 : scanCanonicalize (H12AffineFastState.compose env32822 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound32822 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32823 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4112,372,34,4469,2049,272,373,4161,340,16,3,40,65,2421,4096,4096,2048,68,340,256,33,4161,513]

theorem envBound32823 : H12AffineFastState.Bounded env32823 := by
  intro p hp
  have h : env32823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32822_32823 : H12AffineEnvironment.transform 9 272 env32822 = env32823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env32822 == env32823) = true)

theorem identity32823 : scanCanonicalize (H12AffineFastState.compose env32823 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32823 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32824 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,40,4112,292,34,4389,2049,272,293,4113,260,16,3,40,17,2341,4096,4096,2048,20,260,256,33,4113,513]

theorem envBound32824 : H12AffineFastState.Bounded env32824 := by
  intro p hp
  have h : env32824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32823_32824 : H12AffineEnvironment.transform 5 16 env32823 = env32824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32823 == env32824) = true)

theorem identity32824 : scanCanonicalize (H12AffineFastState.compose env32824 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound32824 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env32825 : List Nat := [2,4,8,16,32,16,8,53,512,37,2048,4096,40,4112,17,34,4112,2049,37,16,4113,49,16,3,40,17,2064,4096,4096,2048,20,49,53,33,4113,513]

theorem envBound32825 : H12AffineFastState.Bounded env32825 := by
  intro p hp
  have h : env32825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32824_32825 : H12AffineEnvironment.transform 7 53 env32824 = env32825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env32824 == env32825) = true)

def env32826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,190521,1024,32769,4161,4194304,16,21763,8193,65,4237693,5392,17664,10281,1365,4256860,256,21793,46092,63068]

theorem envBound32826 : H12AffineFastState.Bounded env32826 := by
  intro p hp
  have h : env32826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32816_32826 : H12AffineEnvironment.transform 6 9 env32816 = env32826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32816 == env32826) = true)

theorem identity32826 : scanCanonicalize (H12AffineFastState.compose env32826 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound32826 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,10280,1024,32769,4161,4194304,16,21763,8193,65,4237693,5392,17664,10281,1365,4256860,256,21793,46092,63068]

theorem envBound32827 : H12AffineFastState.Bounded env32827 := by
  intro p hp
  have h : env32827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32826_32827 : H12AffineEnvironment.transform 16 49169 env32826 = env32827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env32826 == env32827) = true)

theorem identity32827 : scanCanonicalize (H12AffineFastState.compose env32827 (packedSelected [18,23] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound32827 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env32828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,81,21510,16448,10280,1024,80,4161,4194304,16,21763,8193,65,4204844,5392,17664,10281,1365,4224013,256,21793,13405,30221]

theorem envBound32828 : H12AffineFastState.Bounded env32828 := by
  intro p hp
  have h : env32828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32827_32828 : H12AffineEnvironment.transform 14 81 env32827 = env32828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env32827 == env32828) = true)

theorem identity32828 : scanCanonicalize (H12AffineFastState.compose env32828 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32828 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env32829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,81,21510,16448,2420,1024,80,4161,4194304,16,21763,349,65,4196464,5392,17664,2421,1365,4216145,256,21793,5377,22353]

theorem envBound32829 : H12AffineFastState.Bounded env32829 := by
  intro p hp
  have h : env32829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32828_32829 : H12AffineEnvironment.transform 12 348 env32828 = env32829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32828 == env32829) = true)

theorem identity32829 : scanCanonicalize (H12AffineFastState.compose env32829 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32829 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32830 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,21510,16400,2340,1024,0,4113,4194304,16,21763,269,17,4196384,5392,17664,2341,1285,4216065,256,21793,5377,22273]

theorem envBound32830 : H12AffineFastState.Bounded env32830 := by
  intro p hp
  have h : env32830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32829_32830 : H12AffineEnvironment.transform 5 16 env32829 = env32830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32829 == env32830) = true)

theorem identity32830 : scanCanonicalize (H12AffineFastState.compose env32830 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(21+1) ^^^ 21793) := by decide +kernel

theorem selectedBound32830 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env32831 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,1,21510,16400,2340,1024,0,4113,21793,16,21763,269,17,23809,5392,17664,2341,1285,32,256,21793,5377,22273]

theorem envBound32831 : H12AffineFastState.Bounded env32831 := by
  intro p hp
  have h : env32831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32830_32831 : H12AffineEnvironment.transform 21 21793 env32830 = env32831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21793 env32830 == env32831) = true)

theorem identity32831 : scanCanonicalize (H12AffineFastState.compose env32831 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound32831 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env32832 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,4113,1,1047,4097,2340,1024,0,4113,1328,16,1298,269,17,3344,5392,5393,2341,1285,32,256,1328,5377,1808]

theorem envBound32832 : H12AffineFastState.Bounded env32832 := by
  intro p hp
  have h : env32832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32831_32832 : H12AffineEnvironment.transform 13 4113 env32831 = env32832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env32831 == env32832) = true)

theorem identity32832 : scanCanonicalize (H12AffineFastState.compose env32832 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3329) := by decide +kernel

theorem selectedBound32832 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env32833 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3329,268,3344,1,1047,3328,2340,1024,0,3344,1328,16,1298,269,17,3344,2065,2064,2341,1285,32,256,1328,2048,1808]

theorem envBound32833 : H12AffineFastState.Bounded env32833 := by
  intro p hp
  have h : env32833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32832_32833 : H12AffineEnvironment.transform 11 3329 env32832 = env32833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3329 env32832 == env32833) = true)

def env32834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,2097152,4194304,2101328,98780,8328,65,6338877,2098512,17665,2111713,2102685,6349852,256,21793,46213,2175562]

theorem envBound32834 : H12AffineFastState.Bounded env32834 := by
  intro p hp
  have h : env32834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32785_32834 : H12AffineEnvironment.transform 17 190641 env32785 = env32834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env32785 == env32834) = true)

def env32835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4160,4194304,16,98780,8328,65,4237693,5392,17665,10401,1501,4256860,256,21793,46213,74250]

theorem envBound32835 : H12AffineFastState.Bounded env32835 := by
  intro p hp
  have h : env32835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32834_32835 : H12AffineEnvironment.transform 20 4160 env32834 = env32835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env32834 == env32835) = true)

theorem identity32835 : scanCanonicalize (H12AffineFastState.compose env32835 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32835 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32836 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4160,4194304,16,41431,8328,65,4237693,5392,17665,10401,1501,4256860,256,21793,46213,513]

theorem envBound32836 : H12AffineFastState.Bounded env32836 := by
  intro p hp
  have h : env32836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32835_32836 : H12AffineEnvironment.transform 15 8203 env32835 = env32836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32835 == env32836) = true)

theorem identity32836 : scanCanonicalize (H12AffineFastState.compose env32836 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound32836 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190641,1024,32769,4160,32800,16,41431,8328,65,10589,5392,17665,10401,1501,29820,256,21793,46213,513]

theorem envBound32837 : H12AffineFastState.Bounded env32837 := by
  intro p hp
  have h : env32837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32836_32837 : H12AffineEnvironment.transform 21 32800 env32836 = env32837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env32836 == env32837) = true)

theorem identity32837 : scanCanonicalize (H12AffineFastState.compose env32837 (packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound32837 : packedSelected [0,3,4,7,10,11,17,18,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env32838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,25028,35189,1024,32769,4160,32800,16,41431,8328,65,10589,5392,17665,10401,1501,29820,256,21793,46213,513]

theorem envBound32838 : H12AffineFastState.Bounded env32838 := by
  intro p hp
  have h : env32838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32837_32838 : H12AffineEnvironment.transform 16 25028 env32837 = env32838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env32837 == env32838) = true)

theorem identity32838 : scanCanonicalize (H12AffineFastState.compose env32838 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32838 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env32839 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,24909,35189,1024,32769,4160,32800,16,41310,8193,65,10589,5392,17665,10280,1364,29820,256,21793,46092,513]

theorem envBound32839 : H12AffineFastState.Bounded env32839 := by
  intro p hp
  have h : env32839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32838_32839 : H12AffineEnvironment.transform 6 9 env32838 = env32839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32838 == env32839) = true)

theorem identity32839 : scanCanonicalize (H12AffineFastState.compose env32839 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound32839 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32840 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,24909,32041,1024,29789,4160,29820,16,21762,8193,65,10589,5392,17665,10280,1364,29820,256,21793,16464,513]

theorem envBound32840 : H12AffineFastState.Bounded env32840 := by
  intro p hp
  have h : env32840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32839_32840 : H12AffineEnvironment.transform 14 29788 env32839 = env32840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env32839 == env32840) = true)

theorem identity32840 : scanCanonicalize (H12AffineFastState.compose env32840 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound32840 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env32841 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8203,5393,2421,1024,1,4160,32,16,8542,8193,65,10589,5392,12637,10280,1364,32,256,8573,13324,513]

theorem envBound32841 : H12AffineFastState.Bounded env32841 := by
  intro p hp
  have h : env32841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32840_32841 : H12AffineEnvironment.transform 13 13404 env32840 = env32841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env32840 == env32841) = true)

theorem identity32841 : scanCanonicalize (H12AffineFastState.compose env32841 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32841 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32842 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,342,5393,2421,1024,1,4160,32,16,3,348,65,2048,5392,4096,2421,1364,32,256,32,5457,513]

theorem envBound32842 : H12AffineFastState.Bounded env32842 := by
  intro p hp
  have h : env32842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32841_32842 : H12AffineEnvironment.transform 12 349 env32841 = env32842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32841 == env32842) = true)

theorem identity32842 : scanCanonicalize (H12AffineFastState.compose env32842 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1135) := by decide +kernel

theorem selectedBound32842 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,4096,349,5377,0,342,5393,1306,1024,1,4160,32,16,3,348,65,1135,5392,4096,1306,1364,32,256,32,5457,513]

theorem envBound32843 : H12AffineFastState.Bounded env32843 := by
  intro p hp
  have h : env32843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32842_32843 : H12AffineEnvironment.transform 10 1135 env32842 = env32843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1135 env32842 == env32843) = true)

theorem identity32843 : scanCanonicalize (H12AffineFastState.compose env32843 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound32843 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1135,373,349,1140,0,342,1124,1306,1024,1,309,32,16,3,348,65,1135,1125,373,1306,1364,32,256,32,1060,513]

theorem envBound32844 : H12AffineFastState.Bounded env32844 := by
  intro p hp
  have h : env32844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32843_32844 : H12AffineEnvironment.transform 11 373 env32843 = env32844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env32843 == env32844) = true)

theorem identity32844 : scanCanonicalize (H12AffineFastState.compose env32844 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32844 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env32845 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1135,0,40,1140,0,35,1124,1135,1024,1,64,32,16,3,41,65,1135,1125,0,1135,1057,32,117,32,1060,513]

theorem envBound32845 : H12AffineFastState.Bounded env32845 := by
  intro p hp
  have h : env32845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32844_32845 : H12AffineEnvironment.transform 7 117 env32844 = env32845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32844 == env32845) = true)

theorem identity32845 : scanCanonicalize (H12AffineFastState.compose env32845 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 110) := by decide +kernel

theorem selectedBound32845 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env32846 : List Nat := [2,4,8,16,32,64,9,117,512,110,1,0,40,26,0,35,10,1,110,1,64,32,16,3,41,65,1,11,0,1,79,32,117,32,74,513]

theorem envBound32846 : H12AffineFastState.Bounded env32846 := by
  intro p hp
  have h : env32846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32845_32846 : H12AffineEnvironment.transform 9 110 env32845 = env32846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 110 env32845 == env32846) = true)

theorem identity32846 : scanCanonicalize (H12AffineFastState.compose env32846 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound32846 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env32847 : List Nat := [2,4,8,16,32,59,9,14,512,21,1,0,40,26,0,35,10,1,21,1,59,32,16,3,41,58,1,11,0,1,52,32,14,32,49,513]

theorem envBound32847 : H12AffineFastState.Bounded env32847 := by
  intro p hp
  have h : env32847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32846_32847 : H12AffineEnvironment.transform 5 59 env32846 = env32847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env32846 == env32847) = true)

def env32848 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,4194304,17,98780,8328,65,4237692,5393,17665,10400,1500,4256861,256,21793,46213,74251]

theorem envBound32848 : H12AffineFastState.Bounded env32848 := by
  intro p hp
  have h : env32848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32834_32848 : H12AffineEnvironment.transform 20 4161 env32834 = env32848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env32834 == env32848) = true)

theorem identity32848 : scanCanonicalize (H12AffineFastState.compose env32848 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254011) := by decide +kernel

theorem selectedBound32848 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env32849 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,4161,254011,17,98780,8328,65,215367,5393,17665,10400,1500,201830,256,21793,46213,74251]

theorem envBound32849 : H12AffineFastState.Bounded env32849 := by
  intro p hp
  have h : env32849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32848_32849 : H12AffineEnvironment.transform 21 254011 env32848 = env32849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254011 env32848 == env32849) = true)

def env32850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,4161,254011,17,98644,8192,65,215367,5393,17665,10280,1364,201830,256,21793,46093,74251]

theorem envBound32850 : H12AffineFastState.Bounded env32850 := by
  intro p hp
  have h : env32850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32849_32850 : H12AffineEnvironment.transform 6 8 env32849 = env32850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32849 == env32850) = true)

theorem identity32850 : scanCanonicalize (H12AffineFastState.compose env32850 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound32850 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env32851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,131072,149861,1024,8541,4161,213351,17,73736,8192,65,215367,5393,17665,10280,1364,201830,256,21793,5457,74251]

theorem envBound32851 : H12AffineFastState.Bounded env32851 := by
  intro p hp
  have h : env32851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32850_32851 : H12AffineEnvironment.transform 14 8540 env32850 = env32851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env32850 == env32851) = true)

theorem identity32851 : scanCanonicalize (H12AffineFastState.compose env32851 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound32851 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8202,131072,149861,1024,8541,4161,156013,17,2,8192,65,158029,5393,17665,10280,1364,144492,256,21793,5457,513]

theorem envBound32852 : H12AffineFastState.Bounded env32852 := by
  intro p hp
  have h : env32852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32851_32852 : H12AffineEnvironment.transform 15 8202 env32851 = env32852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env32851 == env32852) = true)

theorem identity32852 : scanCanonicalize (H12AffineFastState.compose env32852 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32852 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env32853 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8312,8202,131072,149569,1024,8313,4161,155721,17,2,8192,65,157801,5173,17445,10280,1136,144492,36,21509,5237,513]

theorem envBound32853 : H12AffineFastState.Bounded env32853 := by
  intro p hp
  have h : env32853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32852_32853 : H12AffineEnvironment.transform 7 36 env32852 = env32853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32852 == env32853) = true)

theorem identity32853 : scanCanonicalize (H12AffineFastState.compose env32853 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound32853 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env32854 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,8312,8202,16400,2129,1024,8313,4161,8281,17,2,8192,65,10361,5173,17445,10280,1136,29820,36,21509,5237,513]

theorem envBound32854 : H12AffineFastState.Bounded env32854 := by
  intro p hp
  have h : env32854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32853_32854 : H12AffineEnvironment.transform 16 16400 env32853 = env32854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env32853 == env32854) = true)

theorem identity32854 : scanCanonicalize (H12AffineFastState.compose env32854 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 12393) := by decide +kernel

theorem selectedBound32854 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32855 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,12393,8312,8202,12409,2129,1024,8313,4161,8281,17,2,8192,65,10361,5173,13388,10280,1136,1045,36,9324,5237,513]

theorem envBound32855 : H12AffineFastState.Bounded env32855 := by
  intro p hp
  have h : env32855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32854_32855 : H12AffineEnvironment.transform 13 12393 env32854 = env32855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12393 env32854 == env32855) = true)

def env32856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4161,254011,17,98645,8193,65,215367,5393,17665,10281,1365,201830,256,21793,46092,74251]

theorem envBound32856 : H12AffineFastState.Bounded env32856 := by
  intro p hp
  have h : env32856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32849_32856 : H12AffineEnvironment.transform 6 9 env32849 = env32856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32849 == env32856) = true)

theorem identity32856 : scanCanonicalize (H12AffineFastState.compose env32856 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32856 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env32857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,65536,131072,171060,1024,32769,4161,234551,17,98645,8193,65,212299,5393,12557,10281,1365,201830,256,8493,46092,74251]

theorem envBound32857 : H12AffineFastState.Bounded env32857 := by
  intro p hp
  have h : env32857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32856_32857 : H12AffineEnvironment.transform 13 13324 env32856 = env32857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32856 == env32857) = true)

theorem identity32857 : scanCanonicalize (H12AffineFastState.compose env32857 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 46108) := by decide +kernel

theorem selectedBound32857 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env32858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,65536,46108,10280,1024,32769,4161,73771,17,98645,8193,65,100695,5393,12557,10281,1365,106618,256,8493,46092,74251]

theorem envBound32858 : H12AffineFastState.Bounded env32858 := by
  intro p hp
  have h : env32858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32857_32858 : H12AffineEnvironment.transform 16 46108 env32857 = env32858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46108 env32857 == env32858) = true)

theorem identity32858 : scanCanonicalize (H12AffineFastState.compose env32858 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound32858 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env32859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,1,65536,13341,10280,1024,0,4161,73771,17,65876,8193,65,67926,5393,12557,10281,1365,73851,256,8493,13325,74251]

theorem envBound32859 : H12AffineFastState.Bounded env32859 := by
  intro p hp
  have h : env32859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32858_32859 : H12AffineEnvironment.transform 14 1 env32858 = env32859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env32858 == env32859) = true)

theorem identity32859 : scanCanonicalize (H12AffineFastState.compose env32859 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32859 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env32860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,65536,5393,2340,1024,0,4161,65831,17,65876,269,65,67926,5393,4097,2341,1365,65911,256,33,5377,66311]

theorem envBound32860 : H12AffineFastState.Bounded env32860 := by
  intro p hp
  have h : env32860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32859_32860 : H12AffineEnvironment.transform 12 268 env32859 = env32860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env32859 == env32860) = true)

theorem identity32860 : scanCanonicalize (H12AffineFastState.compose env32860 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound32860 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,1,263,5393,2340,1024,0,4161,32,17,83,269,65,2129,5393,4097,2341,1365,112,256,33,5377,512]

theorem envBound32861 : H12AffineFastState.Bounded env32861 := by
  intro p hp
  have h : env32861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32860_32861 : H12AffineEnvironment.transform 15 263 env32860 = env32861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env32860 == env32861) = true)

theorem identity32861 : scanCanonicalize (H12AffineFastState.compose env32861 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound32861 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env32862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,48,268,1328,1,263,1313,2340,1024,0,113,32,17,83,269,65,2129,1313,49,2341,1365,112,256,33,1329,512]

theorem envBound32862 : H12AffineFastState.Bounded env32862 := by
  intro p hp
  have h : env32862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32861_32862 : H12AffineEnvironment.transform 11 48 env32861 = env32862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32861 == env32862) = true)

theorem identity32862 : scanCanonicalize (H12AffineFastState.compose env32862 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound32862 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32863 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,48,268,1328,1,263,1313,2340,1024,0,1,32,17,35,269,49,2081,1313,49,2341,1317,0,256,33,1329,512]

theorem envBound32863 : H12AffineFastState.Bounded env32863 := by
  intro p hp
  have h : env32863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32862_32863 : H12AffineEnvironment.transform 5 48 env32862 = env32863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env32862 == env32863) = true)

theorem identity32863 : scanCanonicalize (H12AffineFastState.compose env32863 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound32863 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32864 : List Nat := [2,4,8,16,32,48,9,256,512,1024,555,48,268,1328,1,263,1313,783,1024,0,1,32,17,35,269,49,522,1313,49,782,1317,0,256,33,1329,512]

theorem envBound32864 : H12AffineFastState.Bounded env32864 := by
  intro p hp
  have h : env32864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32863_32864 : H12AffineEnvironment.transform 10 555 env32863 = env32864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env32863 == env32864) = true)

theorem identity32864 : scanCanonicalize (H12AffineFastState.compose env32864 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32864 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env32865 : List Nat := [2,4,8,16,32,48,9,37,512,1024,555,48,41,1045,1,34,1028,554,1024,0,1,32,17,35,40,49,522,1028,49,555,1024,0,37,33,1044,512]

theorem envBound32865 : H12AffineFastState.Bounded env32865 := by
  intro p hp
  have h : env32865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32864_32865 : H12AffineEnvironment.transform 7 37 env32864 = env32865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32864 == env32865) = true)

theorem identity32865 : scanCanonicalize (H12AffineFastState.compose env32865 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound32865 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env32866 : List Nat := [2,4,8,16,32,48,9,37,512,542,555,48,41,523,1,34,538,554,542,0,1,32,17,35,40,49,522,538,49,555,542,0,37,33,522,512]

theorem envBound32866 : H12AffineFastState.Bounded env32866 := by
  intro p hp
  have h : env32866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32865_32866 : H12AffineEnvironment.transform 9 542 env32865 = env32866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env32865 == env32866) = true)

theorem identity32866 : scanCanonicalize (H12AffineFastState.compose env32866 (packedSelected [0,1,2] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound32866 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env32867 : List Nat := [2,4,8,9,32,41,9,37,512,519,555,41,41,523,1,34,515,554,519,0,1,32,8,35,40,40,522,515,40,555,519,0,37,33,522,512]

theorem envBound32867 : H12AffineFastState.Bounded env32867 := by
  intro p hp
  have h : env32867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32866_32867 : H12AffineEnvironment.transform 3 9 env32866 = env32867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env32866 == env32867) = true)

theorem identity32867 : scanCanonicalize (H12AffineFastState.compose env32867 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32867 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32868 : List Nat := [2,4,8,9,32,41,9,37,42,45,1,41,41,33,1,34,41,0,45,0,1,32,8,35,40,40,32,41,40,1,45,0,37,33,32,42]

theorem envBound32868 : H12AffineFastState.Bounded env32868 := by
  intro p hp
  have h : env32868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32867_32868 : H12AffineEnvironment.transform 8 42 env32867 = env32868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32867 == env32868) = true)

def env32869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973837,10507601,8830977,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound32869 : H12AffineFastState.Bounded env32869 := by
  intro p hp
  have h : env32869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32718_32869 : H12AffineEnvironment.transform 18 1025 env32718 = env32869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env32718 == env32869) = true)

theorem identity32869 : scanCanonicalize (H12AffineFastState.compose env32869 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 297452) := by decide +kernel

theorem selectedBound32869 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env32870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,297452,16777216,8328,65,21187053,18973837,2415805,149997,17108477,23160256,257,19221824,19246309,17050155]

theorem envBound32870 : H12AffineFastState.Bounded env32870 := by
  intro p hp
  have h : env32870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32869_32870 : H12AffineEnvironment.transform 22 297452 env32869 = env32870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 297452 env32869 == env32870) = true)

def env32871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182764,1025,32769,2097152,4194304,147456,16777216,8328,65,21187053,18973837,2233681,149997,17024017,23160256,257,19104940,19096841,16966599]

theorem envBound32871 : H12AffineFastState.Bounded env32871 := by
  intro p hp
  have h : env32871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32870_32871 : H12AffineEnvironment.transform 17 182764 env32870 = env32871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182764 env32870 == env32871) = true)

theorem identity32871 : scanCanonicalize (H12AffineFastState.compose env32871 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188870) := by decide +kernel

theorem selectedBound32871 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env32872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182764,1025,32769,2097152,4194304,147456,188870,8328,65,4302891,2319691,2233681,149997,75223,6521862,257,2188650,2196687,513]

theorem envBound32872 : H12AffineFastState.Bounded env32872 := by
  intro p hp
  have h : env32872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32871_32872 : H12AffineEnvironment.transform 23 188870 env32871 = env32872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188870 env32871 == env32872) = true)

def env32873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35188,1025,32769,2097152,4194304,152,41310,8328,65,4302891,2172371,2119113,2421,75223,6407326,257,2188650,2196687,513]

theorem envBound32873 : H12AffineFastState.Bounded env32873 := by
  intro p hp
  have h : env32873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32872_32873 : H12AffineEnvironment.transform 16 16536 env32872 = env32873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env32872 == env32873) = true)

theorem identity32873 : scanCanonicalize (H12AffineFastState.compose env32873 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound32873 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16536,10400,1025,8661,2097152,4194304,152,138,8328,65,4262399,2172371,2119113,2421,75223,6382922,257,2188650,2172187,513]

theorem envBound32874 : H12AffineFastState.Bounded env32874 := by
  intro p hp
  have h : env32874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32873_32874 : H12AffineEnvironment.transform 14 8660 env32873 = env32874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env32873 == env32874) = true)

theorem identity32874 : scanCanonicalize (H12AffineFastState.compose env32874 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound32874 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env32875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16536,10400,1025,8661,2097152,4194304,152,138,8328,65,4204925,2098513,2119113,2421,1365,6309320,257,2115048,2098585,513]

theorem envBound32875 : H12AffineFastState.Bounded env32875 := by
  intro p hp
  have h : env32875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32874_32875 : H12AffineEnvironment.transform 15 8322 env32874 = env32875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env32874 == env32875) = true)

theorem identity32875 : scanCanonicalize (H12AffineFastState.compose env32875 (packedSelected [0,3,5,7,10,17,20] rootPS)) = affineNative (2^(20+1) ^^^ 17865) := by decide +kernel

theorem selectedBound32875 : packedSelected [0,3,5,7,10,17,20] rootPS < 2^1333 := by decide +kernel

def env32876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16536,10400,1025,8661,17865,4194304,152,138,8328,65,4204925,16536,4096,2421,1365,4194305,257,33,16464,513]

theorem envBound32876 : H12AffineFastState.Bounded env32876 := by
  intro p hp
  have h : env32876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32875_32876 : H12AffineEnvironment.transform 20 17865 env32875 = env32876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env32875 == env32876) = true)

theorem identity32876 : scanCanonicalize (H12AffineFastState.compose env32876 (packedSelected [2,6,17] rootPS)) = affineNative (2^(21+1) ^^^ 249) := by decide +kernel

theorem selectedBound32876 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env32877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8322,16536,10400,1025,8661,17865,249,152,138,8328,65,10628,16536,4096,2421,1365,248,257,33,16464,513]

theorem envBound32877 : H12AffineFastState.Bounded env32877 := by
  intro p hp
  have h : env32877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32876_32877 : H12AffineEnvironment.transform 21 249 env32876 = env32877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 249 env32876 == env32877) = true)

theorem identity32877 : scanCanonicalize (H12AffineFastState.compose env32877 (packedSelected [0,1,7,8,10,12,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound32877 : packedSelected [0,1,7,8,10,12,14,18] rootPS < 2^1333 := by decide +kernel

def env32878 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8581,8322,16536,10400,1025,8580,17816,168,152,138,8328,16,10628,16536,4096,2340,1284,169,257,33,16385,513]

theorem envBound32878 : H12AffineFastState.Bounded env32878 := by
  intro p hp
  have h : env32878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32877_32878 : H12AffineEnvironment.transform 5 17 env32877 = env32878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32877 == env32878) = true)

theorem identity32878 : scanCanonicalize (H12AffineFastState.compose env32878 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound32878 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32879 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,160,16384,293,34,16536,2048,1025,292,17816,168,152,138,40,16,2340,16536,4096,2340,1284,169,257,33,16385,513]

theorem envBound32879 : H12AffineFastState.Bounded env32879 := by
  intro p hp
  have h : env32879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32878_32879 : H12AffineEnvironment.transform 12 160 env32878 = env32879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env32878 == env32879) = true)

theorem identity32879 : scanCanonicalize (H12AffineFastState.compose env32879 (packedSelected [3,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound32879 : packedSelected [3,8,10,11] rootPS < 2^1333 := by decide +kernel

def env32880 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2065,160,16384,293,34,16536,2048,1025,292,17816,168,152,138,40,16,2340,16536,2065,2340,1284,169,257,33,16385,513]

theorem envBound32880 : H12AffineFastState.Bounded env32880 := by
  intro p hp
  have h : env32880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32879_32880 : H12AffineEnvironment.transform 11 2065 env32879 = env32880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env32879 == env32880) = true)

theorem identity32880 : scanCanonicalize (H12AffineFastState.compose env32880 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound32880 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32881 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,2065,41,16384,293,34,16401,2048,1025,292,17681,33,17,3,40,16,2340,16401,2065,2340,1284,32,257,33,16385,513]

theorem envBound32881 : H12AffineFastState.Bounded env32881 := by
  intro p hp
  have h : env32881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32880_32881 : H12AffineEnvironment.transform 6 9 env32880 = env32881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32880 == env32881) = true)

theorem identity32881 : scanCanonicalize (H12AffineFastState.compose env32881 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32881 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32882 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2065,41,16384,293,34,16401,2048,272,292,16384,33,17,3,40,16,2340,16401,2065,2340,21,32,257,33,16385,513]

theorem envBound32882 : H12AffineFastState.Bounded env32882 := by
  intro p hp
  have h : env32882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32881_32882 : H12AffineEnvironment.transform 9 273 env32881 = env32882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32881 == env32882) = true)

theorem identity32882 : scanCanonicalize (H12AffineFastState.compose env32882 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound32882 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32883 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,41,16384,0,34,16401,2048,53,1,16384,33,17,3,40,16,2049,16401,2065,2049,21,32,36,33,16385,513]

theorem envBound32883 : H12AffineFastState.Bounded env32883 := by
  intro p hp
  have h : env32883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32882_32883 : H12AffineEnvironment.transform 7 37 env32882 = env32883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env32882 == env32883) = true)

theorem identity32883 : scanCanonicalize (H12AffineFastState.compose env32883 (packedSelected [10] rootPS)) = affineNative (2^(13+1) ^^^ 2048) := by decide +kernel

theorem selectedBound32883 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env32884 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2065,41,2048,0,34,2065,2048,53,1,2048,33,17,3,40,16,2049,2065,2065,2049,21,32,36,33,2049,513]

theorem envBound32884 : H12AffineFastState.Bounded env32884 := by
  intro p hp
  have h : env32884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32883_32884 : H12AffineEnvironment.transform 13 2048 env32883 = env32884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2048 env32883 == env32884) = true)

theorem identity32884 : scanCanonicalize (H12AffineFastState.compose env32884 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound32884 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32885 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,41,48,0,34,33,48,53,1,48,33,17,3,40,16,49,33,33,49,21,32,36,33,49,513]

theorem envBound32885 : H12AffineFastState.Bounded env32885 := by
  intro p hp
  have h : env32885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32884_32885 : H12AffineEnvironment.transform 10 48 env32884 = env32885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env32884 == env32885) = true)

def leafEnv32885 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,33,41,48,0,34,33,48,53,1,48,33,17,3,20,40,1,16,49,33,33,49,21,32,36,33,5,35,49,513,1,49,0]

def active32885 : List Nat := [0,1,2,3,4,8]

def tree32885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32885 : H12WitnessSearch.Good tree32885 := H12GlobalWitnessIndex.good

theorem leafIdentity32885 : H12AffineFastState.composeSystem env32885 rootObs = leafEnv32885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32885 rootObs == leafEnv32885) = true)

theorem terminalChecked32885 : H12PackedTerminal.terminalCheckFast leafEnv32885 active32885 tree32885 = true := by decide +kernel

def env32886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35189,1025,32769,2097152,4194304,153,41311,8328,65,4302891,2172370,2119112,2420,75223,6407327,257,2188650,2196687,513]

theorem envBound32886 : H12AffineFastState.Bounded env32886 := by
  intro p hp
  have h : env32886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32872_32886 : H12AffineEnvironment.transform 16 16537 env32872 = env32886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env32872 == env32886) = true)

theorem identity32886 : scanCanonicalize (H12AffineFastState.compose env32886 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32886 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41311,8192,65,4302891,2172250,2118976,2420,75103,6407191,257,2188650,2196551,513]

theorem envBound32887 : H12AffineFastState.Bounded env32887 := by
  intro p hp
  have h : env32887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32886_32887 : H12AffineEnvironment.transform 6 8 env32886 = env32887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32886 == env32887) = true)

theorem identity32887 : scanCanonicalize (H12AffineFastState.compose env32887 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound32887 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env32888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115735,4194304,17,41311,8192,65,4302891,57677,102743,2420,75103,4194304,257,41341,16464,513]

theorem envBound32888 : H12AffineFastState.Bounded env32888 := by
  intro p hp
  have h : env32888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32887_32888 : H12AffineEnvironment.transform 20 115735 env32887 = env32888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env32887 == env32888) = true)

def env32889 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16401,10589,1025,8233,91199,4194304,17,375,8192,65,4261891,16741,78207,2420,75103,4194304,257,341,16464,513]

theorem envBound32889 : H12AffineFastState.Bounded env32889 := by
  intro p hp
  have h : env32889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32888_32889 : H12AffineEnvironment.transform 14 8232 env32888 = env32889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env32888 == env32889) = true)

theorem identity32889 : scanCanonicalize (H12AffineFastState.compose env32889 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound32889 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env32890 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,34,16401,10589,1025,8233,25629,4194304,17,375,8192,65,4196385,16741,12637,2420,9597,4194304,257,341,16464,513]

theorem envBound32890 : H12AffineFastState.Bounded env32890 := by
  intro p hp
  have h : env32890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32889_32890 : H12AffineEnvironment.transform 15 34 env32889 = env32890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env32889 == env32890) = true)

theorem identity32890 : scanCanonicalize (H12AffineFastState.compose env32890 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8280) := by decide +kernel

theorem selectedBound32890 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env32891 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,34,16401,10589,1025,8233,25629,8280,17,375,8192,65,10361,16741,12637,2420,9597,8280,257,341,16464,513]

theorem envBound32891 : H12AffineFastState.Bounded env32891 := by
  intro p hp
  have h : env32891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32890_32891 : H12AffineEnvironment.transform 21 8280 env32890 = env32891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8280 env32890 == env32891) = true)

theorem identity32891 : scanCanonicalize (H12AffineFastState.compose env32891 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound32891 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env32892 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,34,16401,10280,1025,8233,25629,8280,17,2,8192,65,10361,16400,12328,2049,9224,8280,116,32,16464,513]

theorem envBound32892 : H12AffineFastState.Bounded env32892 := by
  intro p hp
  have h : env32892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32891_32892 : H12AffineEnvironment.transform 7 117 env32891 = env32892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32891 == env32892) = true)

theorem identity32892 : scanCanonicalize (H12AffineFastState.compose env32892 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32892 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32893 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,34,16401,10280,1025,8233,25629,8200,17,2,8192,17,10281,16400,12328,2049,9224,8200,36,32,16384,513]

theorem envBound32893 : H12AffineFastState.Bounded env32893 := by
  intro p hp
  have h : env32893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32892_32893 : H12AffineEnvironment.transform 5 16 env32892 = env32893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32892 == env32893) = true)

theorem identity32893 : scanCanonicalize (H12AffineFastState.compose env32893 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound32893 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32894 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,5157,8232,34,5172,10280,1025,8233,12344,8200,17,2,8192,17,10281,5173,12328,2049,9224,8200,36,32,5157,513]

theorem envBound32894 : H12AffineFastState.Bounded env32894 := by
  intro p hp
  have h : env32894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32893_32894 : H12AffineEnvironment.transform 13 5157 env32893 = env32894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env32893 == env32894) = true)

theorem identity32894 : scanCanonicalize (H12AffineFastState.compose env32894 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32894 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32895 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5157,1,34,5172,2049,1025,0,4113,33,17,2,41,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound32895 : H12AffineFastState.Bounded env32895 := by
  intro p hp
  have h : env32895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32894_32895 : H12AffineEnvironment.transform 12 41 env32894 = env32895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32894 == env32895) = true)

def env32896 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1045,1,34,1028,2049,1025,0,33,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound32896 : H12AffineFastState.Bounded env32896 := by
  intro p hp
  have h : env32896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32895_32896 : H12AffineEnvironment.transform 11 48 env32895 = env32896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32895 == env32896) = true)

theorem identity32896 : scanCanonicalize (H12AffineFastState.compose env32896 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound32896 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32897 : List Nat := [2,4,8,16,32,16,8,37,48,1024,2048,48,41,1045,1,34,1028,2049,1025,0,33,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1045,49]

theorem envBound32897 : H12AffineFastState.Bounded env32897 := by
  intro p hp
  have h : env32897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32896_32897 : H12AffineEnvironment.transform 8 48 env32896 = env32897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32896 == env32897) = true)

def env32898 : List Nat := [2,4,8,16,32,16,8,37,48,52,2048,48,41,33,1,34,48,2049,53,0,33,33,17,2,41,17,2048,49,49,2049,21,33,36,32,33,49]

theorem envBound32898 : H12AffineFastState.Bounded env32898 := by
  intro p hp
  have h : env32898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32897_32898 : H12AffineEnvironment.transform 9 52 env32897 = env32898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32897 == env32898) = true)

def env32899 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,48,41,32,1,34,49,2049,52,0,33,33,17,2,41,17,2048,48,49,2049,20,33,36,32,32,49]

theorem envBound32899 : H12AffineFastState.Bounded env32899 := by
  intro p hp
  have h : env32899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32897_32899 : H12AffineEnvironment.transform 9 53 env32897 = env32899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32897 == env32899) = true)

theorem identity32899 : scanCanonicalize (H12AffineFastState.compose env32899 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32899 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32900 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,43,41,32,1,34,42,2049,47,0,33,33,10,2,41,10,2048,43,42,2049,15,33,36,32,32,42]

theorem envBound32900 : H12AffineFastState.Bounded env32900 := by
  intro p hp
  have h : env32900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32899_32900 : H12AffineEnvironment.transform 3 11 env32899 = env32900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32899 == env32900) = true)

def leafEnv32900 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,43,41,32,1,34,42,2049,47,0,33,33,10,2,14,41,1,10,2048,43,42,2049,15,33,36,32,5,34,32,42,1,33,0]

def active32900 : List Nat := [0,1,2,4,10]

def tree32900 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32900 : H12WitnessSearch.Good tree32900 := H12GlobalWitnessIndex.good

theorem leafIdentity32900 : H12AffineFastState.composeSystem env32900 rootObs = leafEnv32900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32900 rootObs == leafEnv32900) = true)

theorem terminalChecked32900 : H12PackedTerminal.terminalCheckFast leafEnv32900 active32900 tree32900 = true := by decide +kernel

def env32901 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1044,1,34,1029,2049,1025,0,32,33,17,2,41,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound32901 : H12AffineFastState.Bounded env32901 := by
  intro p hp
  have h : env32901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32895_32901 : H12AffineEnvironment.transform 11 49 env32895 = env32901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32895 == env32901) = true)

theorem identity32901 : scanCanonicalize (H12AffineFastState.compose env32901 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound32901 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32902 : List Nat := [2,4,8,16,32,16,8,37,512,516,2048,49,41,528,1,34,513,2049,517,0,32,33,17,2,41,17,2048,512,48,2049,549,33,36,32,528,513]

theorem envBound32902 : H12AffineFastState.Bounded env32902 := by
  intro p hp
  have h : env32902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32901_32902 : H12AffineEnvironment.transform 9 516 env32901 = env32902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env32901 == env32902) = true)

def env32903 : List Nat := [2,4,8,16,32,16,8,37,48,52,2048,49,41,32,1,34,49,2049,53,0,32,33,17,2,41,17,2048,48,48,2049,21,33,36,32,32,49]

theorem envBound32903 : H12AffineFastState.Bounded env32903 := by
  intro p hp
  have h : env32903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32902_32903 : H12AffineEnvironment.transform 8 48 env32902 = env32903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env32902 == env32903) = true)

def env32904 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,49,41,33,1,34,48,2049,52,0,32,33,17,2,41,17,2048,49,48,2049,20,33,36,32,33,48]

theorem envBound32904 : H12AffineFastState.Bounded env32904 := by
  intro p hp
  have h : env32904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32902_32904 : H12AffineEnvironment.transform 8 49 env32902 = env32904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env32902 == env32904) = true)

theorem identity32904 : scanCanonicalize (H12AffineFastState.compose env32904 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound32904 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32905 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,42,41,33,1,34,43,2049,47,0,32,33,10,2,41,10,2048,42,43,2049,15,33,36,32,33,43]

theorem envBound32905 : H12AffineFastState.Bounded env32905 := by
  intro p hp
  have h : env32905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32904_32905 : H12AffineEnvironment.transform 3 11 env32904 = env32905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env32904 == env32905) = true)

def leafEnv32905 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,42,41,33,1,34,43,2049,47,0,32,33,10,2,14,41,1,10,2048,42,43,2049,15,33,36,32,5,34,33,43,1,32,0]

def active32905 : List Nat := [0,1,2,4,10]

def tree32905 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32905 : H12WitnessSearch.Good tree32905 := H12GlobalWitnessIndex.good

theorem leafIdentity32905 : H12AffineFastState.composeSystem env32905 rootObs = leafEnv32905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32905 rootObs == leafEnv32905) = true)

theorem terminalChecked32905 : H12PackedTerminal.terminalCheckFast leafEnv32905 active32905 tree32905 = true := by decide +kernel

def env32906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16401,10588,1025,8232,91198,4194304,17,374,8192,65,4261890,16740,78206,2420,75103,4194304,257,340,16464,513]

theorem envBound32906 : H12AffineFastState.Bounded env32906 := by
  intro p hp
  have h : env32906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32888_32906 : H12AffineEnvironment.transform 14 8233 env32888 = env32906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env32888 == env32906) = true)

theorem identity32906 : scanCanonicalize (H12AffineFastState.compose env32906 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound32906 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env32907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,343,16401,10588,1025,8232,25961,4194304,17,374,8192,65,4196693,16740,12329,2420,9224,4194304,257,340,16464,513]

theorem envBound32907 : H12AffineFastState.Bounded env32907 := by
  intro p hp
  have h : env32907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32906_32907 : H12AffineEnvironment.transform 15 343 env32906 = env32907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env32906 == env32907) = true)

theorem identity32907 : scanCanonicalize (H12AffineFastState.compose env32907 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound32907 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env32908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,343,16401,10588,1025,8232,25961,8201,17,374,8192,65,10588,16740,12329,2420,9224,8201,257,340,16464,513]

theorem envBound32908 : H12AffineFastState.Bounded env32908 := by
  intro p hp
  have h : env32908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32907_32908 : H12AffineEnvironment.transform 21 8201 env32907 = env32908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env32907 == env32908) = true)

theorem identity32908 : scanCanonicalize (H12AffineFastState.compose env32908 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound32908 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env32909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,373,343,16401,2048,1025,372,17461,341,17,374,348,65,2048,16740,4469,2420,1364,341,257,340,16464,513]

theorem envBound32909 : H12AffineFastState.Bounded env32909 := by
  intro p hp
  have h : env32909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32908_32909 : H12AffineEnvironment.transform 12 348 env32908 = env32909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env32908 == env32909) = true)

theorem identity32909 : scanCanonicalize (H12AffineFastState.compose env32909 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound32909 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32910 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,293,263,16401,2048,1025,292,17461,261,17,294,268,17,2048,16692,4389,2340,1284,261,257,260,16384,513]

theorem envBound32910 : H12AffineFastState.Bounded env32910 := by
  intro p hp
  have h : env32910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32909_32910 : H12AffineEnvironment.transform 5 16 env32909 = env32910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32909 == env32910) = true)

theorem identity32910 : scanCanonicalize (H12AffineFastState.compose env32910 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound32910 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32911 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,1,35,16401,2048,1025,0,17461,33,17,2,40,17,2048,16400,4097,2048,1056,33,37,32,16384,513]

theorem envBound32911 : H12AffineFastState.Bounded env32911 := by
  intro p hp
  have h : env32911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32910_32911 : H12AffineEnvironment.transform 7 36 env32910 = env32911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env32910 == env32911) = true)

theorem identity32911 : scanCanonicalize (H12AffineFastState.compose env32911 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound32911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32912 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5172,2048,1025,0,4112,33,17,2,40,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound32912 : H12AffineFastState.Bounded env32912 := by
  intro p hp
  have h : env32912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32911_32912 : H12AffineEnvironment.transform 13 5157 env32911 = env32912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env32911 == env32912) = true)

def env32913 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1045,1,35,1028,2048,1025,0,32,33,17,2,40,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound32913 : H12AffineFastState.Bounded env32913 := by
  intro p hp
  have h : env32913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32912_32913 : H12AffineEnvironment.transform 11 48 env32912 = env32913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32912 == env32913) = true)

theorem identity32913 : scanCanonicalize (H12AffineFastState.compose env32913 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound32913 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32914 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1045,48,40,1045,1,35,1028,1045,1025,0,32,33,17,2,40,17,1045,1029,49,1045,1056,33,37,32,1045,513]

theorem envBound32914 : H12AffineFastState.Bounded env32914 := by
  intro p hp
  have h : env32914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32913_32914 : H12AffineEnvironment.transform 10 1045 env32913 = env32914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env32913 == env32914) = true)

def env32915 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,48,40,33,1,35,48,33,53,0,32,33,17,2,40,17,33,49,49,33,20,33,37,32,33,513]

theorem envBound32915 : H12AffineFastState.Bounded env32915 := by
  intro p hp
  have h : env32915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32914_32915 : H12AffineEnvironment.transform 9 52 env32914 = env32915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32914 == env32915) = true)

def env32916 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,48,40,32,1,35,49,32,52,0,32,33,17,2,40,17,32,48,49,32,21,33,37,32,32,513]

theorem envBound32916 : H12AffineFastState.Bounded env32916 := by
  intro p hp
  have h : env32916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32914_32916 : H12AffineEnvironment.transform 9 53 env32914 = env32916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32914 == env32916) = true)

theorem identity32916 : scanCanonicalize (H12AffineFastState.compose env32916 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound32916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32917 : List Nat := [2,4,8,16,32,16,8,36,42,53,32,48,40,32,1,35,49,32,52,0,32,33,17,2,40,17,32,48,49,32,21,33,37,32,32,43]

theorem envBound32917 : H12AffineFastState.Bounded env32917 := by
  intro p hp
  have h : env32917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32916_32917 : H12AffineEnvironment.transform 8 42 env32916 = env32917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env32916 == env32917) = true)

def leafEnv32917 : List Nat := [2,4,8,16,32,16,8,36,42,53,32,48,40,32,1,35,49,32,52,0,32,33,17,2,20,40,1,17,32,48,49,32,21,33,37,32,5,35,32,43,1,32,0]

def active32917 : List Nat := [0,1,2,3,4]

def tree32917 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32917 : H12WitnessSearch.Good tree32917 := H12GlobalWitnessIndex.good

theorem leafIdentity32917 : H12AffineFastState.composeSystem env32917 rootObs = leafEnv32917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32917 rootObs == leafEnv32917) = true)

theorem terminalChecked32917 : H12PackedTerminal.terminalCheckFast leafEnv32917 active32917 tree32917 = true := by decide +kernel

def env32918 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1044,1,35,1029,2048,1025,0,33,33,17,2,40,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound32918 : H12AffineFastState.Bounded env32918 := by
  intro p hp
  have h : env32918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32912_32918 : H12AffineEnvironment.transform 11 49 env32912 = env32918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env32912 == env32918) = true)

theorem identity32918 : scanCanonicalize (H12AffineFastState.compose env32918 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound32918 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32919 : List Nat := [2,4,8,16,32,16,8,36,512,1024,33,49,40,1044,1,35,1029,33,1025,0,33,33,17,2,40,17,33,1028,48,33,1056,33,37,32,1044,513]

theorem envBound32919 : H12AffineFastState.Bounded env32919 := by
  intro p hp
  have h : env32919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32918_32919 : H12AffineEnvironment.transform 10 33 env32918 = env32919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env32918 == env32919) = true)

def env32920 : List Nat := [2,4,8,16,32,16,8,36,512,52,33,49,40,32,1,35,49,33,53,0,33,33,17,2,40,17,33,48,48,33,20,33,37,32,32,513]

theorem envBound32920 : H12AffineFastState.Bounded env32920 := by
  intro p hp
  have h : env32920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32919_32920 : H12AffineEnvironment.transform 9 52 env32919 = env32920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env32919 == env32920) = true)

def env32921 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,49,40,33,1,35,48,33,52,0,33,33,17,2,40,17,33,49,48,33,21,33,37,32,33,513]

theorem envBound32921 : H12AffineFastState.Bounded env32921 := by
  intro p hp
  have h : env32921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32919_32921 : H12AffineEnvironment.transform 9 53 env32919 = env32921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32919 == env32921) = true)

theorem identity32921 : scanCanonicalize (H12AffineFastState.compose env32921 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound32921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32922 : List Nat := [2,4,8,16,32,16,8,36,43,53,33,49,40,33,1,35,48,33,52,0,33,33,17,2,40,17,33,49,48,33,21,33,37,32,33,42]

theorem envBound32922 : H12AffineFastState.Bounded env32922 := by
  intro p hp
  have h : env32922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32921_32922 : H12AffineEnvironment.transform 8 43 env32921 = env32922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env32921 == env32922) = true)

def leafEnv32922 : List Nat := [2,4,8,16,32,16,8,36,43,53,33,49,40,33,1,35,48,33,52,0,33,33,17,2,20,40,1,17,33,49,48,33,21,33,37,32,5,35,33,42,1,33,0]

def active32922 : List Nat := [0,1,2,3,4]

def tree32922 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32922 : H12WitnessSearch.Good tree32922 := H12GlobalWitnessIndex.good

theorem leafIdentity32922 : H12AffineFastState.composeSystem env32922 rootObs = leafEnv32922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32922 rootObs == leafEnv32922) = true)

theorem terminalChecked32922 : H12PackedTerminal.terminalCheckFast leafEnv32922 active32922 tree32922 = true := by decide +kernel

def env32923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,182765,1025,32769,2097152,4194304,147457,16777216,8328,65,21187053,18973837,2233680,149997,17024016,23160256,257,19104941,19096840,16966598]

theorem envBound32923 : H12AffineFastState.Bounded env32923 := by
  intro p hp
  have h : env32923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32870_32923 : H12AffineEnvironment.transform 17 182765 env32870 = env32923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 182765 env32870 == env32923) = true)

def env32924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16536,35189,1025,32769,2097152,4194304,153,16777216,8328,65,21039477,18973837,2119112,2421,16876680,23160256,257,18990133,18949520,16819038]

theorem envBound32924 : H12AffineFastState.Bounded env32924 := by
  intro p hp
  have h : env32924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32923_32924 : H12AffineEnvironment.transform 16 16536 env32923 = env32924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16536 env32923 == env32924) = true)

theorem identity32924 : scanCanonicalize (H12AffineFastState.compose env32924 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound32924 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,16777216,8192,65,21039477,18973701,2118976,2421,16876544,23160136,257,18990133,18949400,16819038]

theorem envBound32925 : H12AffineFastState.Bounded env32925 := by
  intro p hp
  have h : env32925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32924_32925 : H12AffineEnvironment.transform 6 8 env32924 = env32925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32924 == env32925) = true)

def env32926 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,2097152,4194304,17,16777216,8192,65,21039105,18973701,2118708,2049,16876544,23159868,117,18990133,18949228,16818730]

theorem envBound32926 : H12AffineFastState.Bounded env32926 := by
  intro p hp
  have h : env32926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32925_32926 : H12AffineEnvironment.transform 7 116 env32925 = env32926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env32925 == env32926) = true)

theorem identity32926 : scanCanonicalize (H12AffineFastState.compose env32926 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound32926 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env32927 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,16777216,8192,65,21039105,16834619,77834,2049,16876544,20971522,117,16818187,16793682,16818730]

theorem envBound32927 : H12AffineFastState.Bounded env32927 := by
  intro p hp
  have h : env32927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32926_32927 : H12AffineEnvironment.transform 20 91198 env32926 = env32927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env32926 == env32927) = true)

def env32928 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,16777216,8192,17,21039105,16834619,77834,2049,16876544,20971522,37,16818187,16793602,16818730]

theorem envBound32928 : H12AffineFastState.Bounded env32928 := by
  intro p hp
  have h : env32928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32927_32928 : H12AffineEnvironment.transform 5 16 env32927 = env32928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32927 == env32928) = true)

theorem identity32928 : scanCanonicalize (H12AffineFastState.compose env32928 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4292608) := by decide +kernel

theorem selectedBound32928 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32929 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,4292608,8192,17,34817,4284475,77834,2049,4195328,98306,37,4268043,4308994,4268586]

theorem envBound32929 : H12AffineFastState.Bounded env32929 := by
  intro p hp
  have h : env32929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32928_32929 : H12AffineEnvironment.transform 23 4292608 env32928 = env32929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4292608 env32928 == env32929) = true)

theorem identity32929 : scanCanonicalize (H12AffineFastState.compose env32929 (packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8233) := by decide +kernel

theorem selectedBound32929 : packedSelected [0,3,7,9,10,14,17,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env32930 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8233,65536,16400,10280,1025,8232,91198,4194304,17,4268073,8192,17,10280,4284475,77834,2049,4195328,73771,37,4268043,4284459,4268586]

theorem envBound32930 : H12AffineFastState.Bounded env32930 := by
  intro p hp
  have h : env32930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32929_32930 : H12AffineEnvironment.transform 14 8233 env32929 = env32930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env32929 == env32930) = true)

theorem identity32930 : scanCanonicalize (H12AffineFastState.compose env32930 (packedSelected [0,2,4,7,9,17] rootPS)) = affineNative (2^(21+1) ^^^ 87047) := by decide +kernel

theorem selectedBound32930 : packedSelected [0,2,4,7,9,17] rootPS < 2^1333 := by decide +kernel

def env32931 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8233,65536,16400,10280,1025,8232,91198,87047,17,29742,8192,17,10280,13372,77834,2049,86023,73771,37,29708,13356,30253]

theorem envBound32931 : H12AffineFastState.Bounded env32931 := by
  intro p hp
  have h : env32931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32930_32931 : H12AffineEnvironment.transform 21 87047 env32930 = env32931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 87047 env32930 == env32931) = true)

theorem identity32931 : scanCanonicalize (H12AffineFastState.compose env32931 (packedSelected [2,11,12,14,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound32931 : packedSelected [2,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env32932 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,16384,8233,34,16400,10280,1025,8232,25628,21541,17,29742,8192,17,10280,13372,12328,2049,20517,8201,37,29708,13356,30253]

theorem envBound32932 : H12AffineFastState.Bounded env32932 := by
  intro p hp
  have h : env32932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32931_32932 : H12AffineEnvironment.transform 15 34 env32931 = env32932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env32931 == env32932) = true)

theorem identity32932 : scanCanonicalize (H12AffineFastState.compose env32932 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound32932 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env32933 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,16384,0,34,16400,2049,1025,1,17461,21541,17,21511,41,17,2049,5141,4097,2049,20517,32,37,21541,5125,22020]

theorem envBound32933 : H12AffineFastState.Bounded env32933 := by
  intro p hp
  have h : env32933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32932_32933 : H12AffineEnvironment.transform 12 41 env32932 = env32933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env32932 == env32933) = true)

theorem identity32933 : scanCanonicalize (H12AffineFastState.compose env32933 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound32933 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env32934 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,16384,0,34,16400,2049,1025,1,17461,17429,17,17463,41,17,2049,1061,49,2049,16405,32,37,17429,1077,17972]

theorem envBound32934 : H12AffineFastState.Bounded env32934 := by
  intro p hp
  have h : env32934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32933_32934 : H12AffineEnvironment.transform 11 48 env32933 = env32934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env32933 == env32934) = true)

theorem identity32934 : scanCanonicalize (H12AffineFastState.compose env32934 (packedSelected [2,3,5] rootPS)) = affineNative (2^(13+1) ^^^ 3093) := by decide +kernel

theorem selectedBound32934 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32935 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,3093,0,34,3077,2049,1025,1,2080,2048,17,2082,41,17,2049,1061,49,2049,3072,32,37,2048,1077,2593]

theorem envBound32935 : H12AffineFastState.Bounded env32935 := by
  intro p hp
  have h : env32935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32934_32935 : H12AffineEnvironment.transform 13 3093 env32934 = env32935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3093 env32934 == env32935) = true)

def env32936 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,16777216,8192,16,21039105,16834619,77834,2049,16876544,20971522,36,16818187,16793603,16818730]

theorem envBound32936 : H12AffineFastState.Bounded env32936 := by
  intro p hp
  have h : env32936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32927_32936 : H12AffineEnvironment.transform 5 17 env32927 = env32936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32927 == env32936) = true)

theorem identity32936 : scanCanonicalize (H12AffineFastState.compose env32936 (packedSelected [3,7,10,14,17,20,24,26,27] rootPS)) = affineNative (2^(23+1) ^^^ 4235274) := by decide +kernel

theorem selectedBound32936 : packedSelected [3,7,10,14,17,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env32937 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,4194304,17,4235274,8192,16,108555,4210737,77834,2049,4269066,40968,36,4194305,4251657,4194848]

theorem envBound32937 : H12AffineFastState.Bounded env32937 := by
  intro p hp
  have h : env32937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32936_32937 : H12AffineEnvironment.transform 23 4235274 env32936 = env32937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 4235274 env32936 == env32937) = true)

theorem identity32937 : scanCanonicalize (H12AffineFastState.compose env32937 (packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound32937 : packedSelected [0,7,9,14,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env32938 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34817,1025,32769,91198,8200,17,32770,8192,16,108555,24633,77834,2049,66562,40968,36,8201,49153,8744]

theorem envBound32938 : H12AffineFastState.Bounded env32938 := by
  intro p hp
  have h : env32938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32937_32938 : H12AffineEnvironment.transform 21 8200 env32937 = env32938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env32937 == env32938) = true)

theorem identity32938 : scanCanonicalize (H12AffineFastState.compose env32938 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound32938 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env32939 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,8192,16384,8232,65536,16400,10281,1025,8233,91198,8200,17,8234,8192,16,67619,24633,77834,2049,66562,32,36,8201,24617,8744]

theorem envBound32939 : H12AffineFastState.Bounded env32939 := by
  intro p hp
  have h : env32939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32938_32939 : H12AffineEnvironment.transform 14 8232 env32938 = env32939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env32938 == env32939) = true)

theorem identity32939 : scanCanonicalize (H12AffineFastState.compose env32939 (packedSelected [12,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound32939 : packedSelected [12,15,17] rootPS < 2^1333 := by decide +kernel

def env32940 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,16384,8232,65536,16400,10281,52,8233,90123,8200,17,8234,8192,16,67619,24633,77834,2049,65591,32,36,8201,24617,8744]

theorem envBound32940 : H12AffineFastState.Bounded env32940 := by
  intro p hp
  have h : env32940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32939_32940 : H12AffineEnvironment.transform 9 53 env32939 = env32940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env32939 == env32940) = true)

theorem identity32940 : scanCanonicalize (H12AffineFastState.compose env32940 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound32940 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env32941 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,8192,4112,8232,65536,4096,10281,52,8233,77851,8200,17,8234,8192,16,67619,12329,77834,2049,65591,32,36,8201,12345,8744]

theorem envBound32941 : H12AffineFastState.Bounded env32941 := by
  intro p hp
  have h : env32941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32940_32941 : H12AffineEnvironment.transform 13 4112 env32940 = env32941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env32940 == env32941) = true)

theorem identity32941 : scanCanonicalize (H12AffineFastState.compose env32941 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32941 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32942 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,4112,0,65536,4096,2049,52,1,69683,32,17,2,40,16,67619,4097,69666,2049,65591,32,36,33,4113,512]

theorem envBound32942 : H12AffineFastState.Bounded env32942 := by
  intro p hp
  have h : env32942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32941_32942 : H12AffineEnvironment.transform 12 40 env32941 = env32942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32941 == env32942) = true)

theorem identity32942 : scanCanonicalize (H12AffineFastState.compose env32942 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound32942 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32943 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,4096,40,4112,0,2,4096,2049,52,1,4145,32,17,2,40,16,2081,4097,4128,2049,53,32,36,33,4113,512]

theorem envBound32943 : H12AffineFastState.Bounded env32943 := by
  intro p hp
  have h : env32943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32942_32943 : H12AffineEnvironment.transform 15 2 env32942 = env32943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env32942 == env32943) = true)

theorem identity32943 : scanCanonicalize (H12AffineFastState.compose env32943 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound32943 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32944 : List Nat := [2,4,8,16,1,17,8,4,512,20,2048,4096,9,4112,0,2,4096,2049,21,1,4112,1,17,2,9,16,2048,4097,4097,2049,20,1,5,0,4113,512]

theorem envBound32944 : H12AffineFastState.Bounded env32944 := by
  intro p hp
  have h : env32944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32943_32944 : H12AffineEnvironment.transform 4 1 env32943 = env32944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env32943 == env32944) = true)

theorem identity32944 : scanCanonicalize (H12AffineFastState.compose env32944 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound32944 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32945 : List Nat := [2,4,8,16,1,17,8,4,1,20,2048,4096,9,4112,0,2,4096,2049,21,1,4112,1,17,2,9,16,2048,4097,4097,2049,20,1,5,0,4113,1]

theorem envBound32945 : H12AffineFastState.Bounded env32945 := by
  intro p hp
  have h : env32945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32944_32945 : H12AffineEnvironment.transform 8 1 env32944 = env32945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env32944 == env32945) = true)

theorem identity32945 : scanCanonicalize (H12AffineFastState.compose env32945 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound32945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32946 : List Nat := [2,4,8,5,1,4,8,4,1,1,2048,4096,9,4101,0,2,4096,2049,0,1,4101,1,4,2,9,5,2048,4097,4097,2049,1,1,5,0,4100,1]

theorem envBound32946 : H12AffineFastState.Bounded env32946 := by
  intro p hp
  have h : env32946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32945_32946 : H12AffineEnvironment.transform 3 5 env32945 = env32946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env32945 == env32946) = true)

theorem identity32946 : scanCanonicalize (H12AffineFastState.compose env32946 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 2052) := by decide +kernel

theorem selectedBound32946 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env32947 : List Nat := [2,4,8,5,1,4,8,4,1,1,2048,2052,9,2049,0,2,2052,2049,0,1,2049,1,4,2,9,5,2048,2053,2053,2049,1,1,5,0,2048,1]

theorem envBound32947 : H12AffineFastState.Bounded env32947 := by
  intro p hp
  have h : env32947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32946_32947 : H12AffineEnvironment.transform 11 2052 env32946 = env32947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2052 env32946 == env32947) = true)

def leafEnv32947 : List Nat := [2,4,8,5,1,4,8,4,1,1,2048,2052,9,2049,0,2,2052,2049,0,1,2049,1,4,2,0,9,1,5,2048,2053,2053,2049,1,1,5,0,5,2,2048,1,1,2048,0]

def active32947 : List Nat := [0,1,2,10]

def tree32947 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood32947 : H12WitnessSearch.Good tree32947 := H12GlobalWitnessIndex.good

theorem leafIdentity32947 : H12AffineFastState.composeSystem env32947 rootObs = leafEnv32947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env32947 rootObs == leafEnv32947) = true)

theorem terminalChecked32947 : H12PackedTerminal.terminalCheckFast leafEnv32947 active32947 tree32947 = true := by decide +kernel

def env32948 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,16777216,8192,65,21039104,18973701,2118709,2048,16876544,23159869,116,18990133,18949229,16818731]

theorem envBound32948 : H12AffineFastState.Bounded env32948 := by
  intro p hp
  have h : env32948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32925_32948 : H12AffineEnvironment.transform 7 117 env32925 = env32948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env32925 == env32948) = true)

theorem identity32948 : scanCanonicalize (H12AffineFastState.compose env32948 (packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2212885) := by decide +kernel

theorem selectedBound32948 : packedSelected [0,1,3,5,7,8,9,10,12,14,15,17,19,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env32949 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,2212885,8192,65,6343701,16400,2118709,2048,2113557,4235304,116,32,57464,2188862]

theorem envBound32949 : H12AffineFastState.Bounded env32949 := by
  intro p hp
  have h : env32949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32948_32949 : H12AffineEnvironment.transform 23 2212885 env32948 = env32949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2212885 env32948 == env32949) = true)

def env32950 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,2212885,8192,17,6343701,16400,2118709,2048,2113557,4235304,36,32,57384,2188862]

theorem envBound32950 : H12AffineFastState.Bounded env32950 := by
  intro p hp
  have h : env32950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32949_32950 : H12AffineEnvironment.transform 5 16 env32949 = env32950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env32949 == env32950) = true)

theorem identity32950 : scanCanonicalize (H12AffineFastState.compose env32950 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound32950 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env32951 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,65536,16400,10280,1025,8233,2097152,4194304,17,2188349,8192,17,6319165,16400,2118709,2048,2113557,4194304,36,32,16384,2188862]

theorem envBound32951 : H12AffineFastState.Bounded env32951 := by
  intro p hp
  have h : env32951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32950_32951 : H12AffineEnvironment.transform 14 8232 env32950 = env32951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env32950 == env32951) = true)

theorem identity32951 : scanCanonicalize (H12AffineFastState.compose env32951 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91199) := by decide +kernel

theorem selectedBound32951 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env32952 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,65536,16400,10280,1025,8233,91199,4194304,17,2,8192,17,4261890,16400,77834,2048,74794,4194304,36,32,16384,513]

theorem envBound32952 : H12AffineFastState.Bounded env32952 := by
  intro p hp
  have h : env32952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32951_32952 : H12AffineEnvironment.transform 20 91199 env32951 = env32952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91199 env32951 == env32952) = true)

theorem identity32952 : scanCanonicalize (H12AffineFastState.compose env32952 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32952 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32953 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,8203,16400,10280,1025,8233,17460,4194304,17,2,8192,17,4204553,16400,4097,2048,1057,4194304,36,32,16384,513]

theorem envBound32953 : H12AffineFastState.Bounded env32953 := by
  intro p hp
  have h : env32953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32952_32953 : H12AffineEnvironment.transform 15 8203 env32952 = env32953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32952 == env32953) = true)

def env32954 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,4194304,17,2212885,8192,16,6343701,16400,2118709,2048,2113557,4235304,37,32,57385,2188862]

theorem envBound32954 : H12AffineFastState.Bounded env32954 := by
  intro p hp
  have h : env32954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32949_32954 : H12AffineEnvironment.transform 5 17 env32949 = env32954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env32949 == env32954) = true)

theorem identity32954 : scanCanonicalize (H12AffineFastState.compose env32954 (packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS)) = affineNative (2^(21+1) ^^^ 65538) := by decide +kernel

theorem selectedBound32954 : packedSelected [0,2,3,4,5,6,8,9,11,17,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env32955 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,2097152,65538,17,2212885,8192,16,2214935,16400,2118709,2048,2113557,106538,37,32,57385,2188862]

theorem envBound32955 : H12AffineFastState.Bounded env32955 := by
  intro p hp
  have h : env32955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32954_32955 : H12AffineEnvironment.transform 21 65538 env32954 = env32955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 65538 env32954 == env32955) = true)

theorem identity32955 : scanCanonicalize (H12AffineFastState.compose env32955 (packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 123966) := by decide +kernel

theorem selectedBound32955 : packedSelected [0,1,3,5,7,8,9,10,14,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env32956 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,32768,65536,16400,34816,1025,32769,123966,65538,17,8235,8192,16,10281,16400,110603,2048,107563,106538,37,32,57385,33280]

theorem envBound32956 : H12AffineFastState.Bounded env32956 := by
  intro p hp
  have h : env32956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32955_32956 : H12AffineEnvironment.transform 20 123966 env32955 = env32956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 123966 env32955 == env32956) = true)

theorem identity32956 : scanCanonicalize (H12AffineFastState.compose env32956 (packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 29740) := by decide +kernel

theorem selectedBound32956 : packedSelected [0,2,3,4,5,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env32957 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,29740,65536,16400,31788,1025,29741,69650,65538,17,8235,8192,16,10281,16400,82983,2048,86023,87046,37,32,5125,30252]

theorem envBound32957 : H12AffineFastState.Bounded env32957 := by
  intro p hp
  have h : env32957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32956_32957 : H12AffineEnvironment.transform 14 29740 env32956 = env32957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29740 env32956 == env32957) = true)

theorem identity32957 : scanCanonicalize (H12AffineFastState.compose env32957 (packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS)) = affineNative (2^(15+1) ^^^ 21542) := by decide +kernel

theorem selectedBound32957 : packedSelected [1,3,6,8,10,11,12,14,15,18,24] rootPS < 2^1333 := by decide +kernel

def env32958 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,8192,16384,29740,21542,16400,31788,1025,29741,17460,21540,17,8235,8192,16,10281,16400,4097,2048,1057,32,37,32,5125,30252]

theorem envBound32958 : H12AffineFastState.Bounded env32958 := by
  intro p hp
  have h : env32958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32957_32958 : H12AffineEnvironment.transform 15 21542 env32957 = env32958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21542 env32957 == env32958) = true)

theorem identity32958 : scanCanonicalize (H12AffineFastState.compose env32958 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound32958 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env32959 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1550,8192,16384,25122,16936,16400,27170,1025,25123,17460,16938,17,8235,8192,16,10281,16400,1551,2048,1057,32,37,32,523,24610]

theorem envBound32959 : H12AffineFastState.Bounded env32959 := by
  intro p hp
  have h : env32959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32958_32959 : H12AffineEnvironment.transform 11 1550 env32958 = env32959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env32958 == env32959) = true)

theorem identity32959 : scanCanonicalize (H12AffineFastState.compose env32959 (packedSelected [0,2,5,8,9,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 0) := by decide +kernel

theorem selectedBound32959 : packedSelected [0,2,5,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env32960 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1550,8192,0,8738,552,16,10786,1025,8739,1076,554,17,8235,8192,16,10281,16,1551,2048,1057,32,37,32,523,8226]

theorem envBound32960 : H12AffineFastState.Bounded env32960 := by
  intro p hp
  have h : env32960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32959_32960 : H12AffineEnvironment.transform 13 0 env32959 = env32960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 0 env32959 == env32960) = true)

theorem identity32960 : scanCanonicalize (H12AffineFastState.compose env32960 (packedSelected [0,5,8,9,10,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 1598) := by decide +kernel

theorem selectedBound32960 : packedSelected [0,5,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env32961 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1598,1550,8192,0,8738,552,16,9244,1025,8739,1076,554,17,8235,8192,16,9751,16,1551,1598,1057,32,37,32,523,8226]

theorem envBound32961 : H12AffineFastState.Bounded env32961 := by
  intro p hp
  have h : env32961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32960_32961 : H12AffineEnvironment.transform 10 1598 env32960 = env32961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1598 env32960 == env32961) = true)

theorem identity32961 : scanCanonicalize (H12AffineFastState.compose env32961 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound32961 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env32962 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1598,1550,40,0,522,552,16,1076,1025,523,1076,554,17,3,40,16,1599,16,1551,1598,1057,32,37,32,523,10]

theorem envBound32962 : H12AffineFastState.Bounded env32962 := by
  intro p hp
  have h : env32962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32961_32962 : H12AffineEnvironment.transform 12 40 env32961 = env32962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env32961 == env32962) = true)

theorem identity32962 : scanCanonicalize (H12AffineFastState.compose env32962 (packedSelected [2,3,5] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound32962 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env32963 : List Nat := [2,4,8,16,32,17,8,36,11,1024,1077,1029,40,0,1,35,16,1076,1025,0,1076,33,17,3,40,16,1076,16,1028,1077,1057,32,37,32,0,10]

theorem envBound32963 : H12AffineFastState.Bounded env32963 := by
  intro p hp
  have h : env32963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32962_32963 : H12AffineEnvironment.transform 8 11 env32962 = env32963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env32962 == env32963) = true)

theorem identity32963 : scanCanonicalize (H12AffineFastState.compose env32963 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound32963 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env32964 : List Nat := [2,4,8,16,16,17,8,20,11,1024,1029,1029,24,0,1,19,16,1028,1025,0,1028,17,17,3,24,16,1028,16,1028,1029,1041,16,21,16,0,10]

theorem envBound32964 : H12AffineFastState.Bounded env32964 := by
  intro p hp
  have h : env32964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32963_32964 : H12AffineEnvironment.transform 4 16 env32963 = env32964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env32963 == env32964) = true)

theorem identity32964 : scanCanonicalize (H12AffineFastState.compose env32964 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound32964 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32965 : List Nat := [2,4,8,10,10,11,8,14,11,1024,1029,1029,2,0,1,9,10,1028,1025,0,1028,11,11,3,2,10,1028,10,1028,1029,1035,10,15,10,0,10]

theorem envBound32965 : H12AffineFastState.Bounded env32965 := by
  intro p hp
  have h : env32965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32964_32965 : H12AffineEnvironment.transform 3 10 env32964 = env32965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env32964 == env32965) = true)

theorem identity32965 : scanCanonicalize (H12AffineFastState.compose env32965 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound32965 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env32966 : List Nat := [1,4,8,9,9,8,8,13,8,1024,1029,1029,1,0,1,9,9,1028,1025,0,1028,8,8,0,1,9,1028,9,1028,1029,1032,9,12,9,0,9]

theorem envBound32966 : H12AffineFastState.Bounded env32966 := by
  intro p hp
  have h : env32966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32965_32966 : H12AffineEnvironment.transform 0 1 env32965 = env32966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env32965 == env32966) = true)

theorem identity32966 : scanCanonicalize (H12AffineFastState.compose env32966 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound32966 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32967 : List Nat := [1,4,0,1,1,0,0,5,0,1024,1029,1029,1,0,1,1,1,1028,1025,0,1028,0,0,0,1,1,1028,1,1028,1029,1024,1,4,1,0,1]

theorem envBound32967 : H12AffineFastState.Bounded env32967 := by
  intro p hp
  have h : env32967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32966_32967 : H12AffineEnvironment.transform 2 0 env32966 = env32967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env32966 == env32967) = true)

theorem identity32967 : scanCanonicalize (H12AffineFastState.compose env32967 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound32967 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env32968 : List Nat := [1,4,0,1,1,0,0,5,0,1,4,4,1,0,1,1,1,5,0,0,5,0,0,0,1,1,5,1,5,4,1,1,4,1,0,1]

theorem envBound32968 : H12AffineFastState.Bounded env32968 := by
  intro p hp
  have h : env32968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32967_32968 : H12AffineEnvironment.transform 9 1 env32967 = env32968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env32967 == env32968) = true)

def env32969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16537,35188,1025,32769,2097152,4194304,152,16777216,8328,65,21039476,18973837,2119113,2420,16876681,23160256,257,18990132,18949521,16819039]

theorem envBound32969 : H12AffineFastState.Bounded env32969 := by
  intro p hp
  have h : env32969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32923_32969 : H12AffineEnvironment.transform 16 16537 env32923 = env32969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16537 env32923 == env32969) = true)

theorem identity32969 : scanCanonicalize (H12AffineFastState.compose env32969 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound32969 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env32970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16537,10400,1025,8661,2097152,4194304,152,16777216,8328,65,21039476,18949465,2119113,2420,16852317,23160256,257,18965984,18949521,16777867]

theorem envBound32970 : H12AffineFastState.Bounded env32970 := by
  intro p hp
  have h : env32970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32969_32970 : H12AffineEnvironment.transform 14 8660 env32969 = env32970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env32969 == env32970) = true)

def env32971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,2097152,4194304,16,16777216,8192,65,21039476,18949465,2118977,2420,16852317,23160136,257,18965864,18949401,16777731]

theorem envBound32971 : H12AffineFastState.Bounded env32971 := by
  intro p hp
  have h : env32971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32970_32971 : H12AffineEnvironment.transform 6 8 env32970 = env32971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env32970 == env32971) = true)

theorem identity32971 : scanCanonicalize (H12AffineFastState.compose env32971 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound32971 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,16401,10280,1025,8541,2097152,4194304,16,2,8192,65,4262262,2172251,2118977,2420,75103,6382922,257,2188650,2172187,513]

theorem envBound32972 : H12AffineFastState.Bounded env32972 := by
  intro p hp
  have h : env32972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32971_32972 : H12AffineEnvironment.transform 23 2 env32971 = env32972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env32971 == env32972) = true)

theorem identity32972 : scanCanonicalize (H12AffineFastState.compose env32972 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound32972 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env32973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,2097152,4194304,16,2,8192,65,4204925,2098512,2118977,2420,1364,6309185,257,2114913,2098448,513]

theorem envBound32973 : H12AffineFastState.Bounded env32973 := by
  intro p hp
  have h : env32973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32972_32973 : H12AffineEnvironment.transform 15 8203 env32972 = env32973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env32972 == env32973) = true)

theorem identity32973 : scanCanonicalize (H12AffineFastState.compose env32973 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 2114913) := by decide +kernel

theorem selectedBound32973 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32974 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,2097152,2114913,16,2,8192,65,2124828,2098512,2118977,2420,1364,32,257,2114913,2098448,513]

theorem envBound32974 : H12AffineFastState.Bounded env32974 := by
  intro p hp
  have h : env32974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32973_32974 : H12AffineEnvironment.transform 21 2114913 env32973 = env32974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114913 env32973 == env32974) = true)

theorem identity32974 : scanCanonicalize (H12AffineFastState.compose env32974 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound32974 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env32975 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,8203,16401,10280,1025,8541,17728,33,16,2,8192,65,10588,16400,4097,2420,1364,32,257,33,16464,513]

theorem envBound32975 : H12AffineFastState.Bounded env32975 := by
  intro p hp
  have h : env32975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32974_32975 : H12AffineEnvironment.transform 20 17728 env32974 = env32975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env32974 == env32975) = true)

theorem identity32975 : scanCanonicalize (H12AffineFastState.compose env32975 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound32975 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env32976 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,8540,8203,13341,10280,1025,8541,12620,33,16,2,8192,65,10588,13340,4097,2420,1364,32,257,33,13404,513]

theorem envBound32976 : H12AffineFastState.Bounded env32976 := by
  intro p hp
  have h : env32976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32975_32976 : H12AffineEnvironment.transform 13 13324 env32975 = env32976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env32975 == env32976) = true)

theorem identity32976 : scanCanonicalize (H12AffineFastState.compose env32976 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound32976 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env32977 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5457,1,342,5440,2421,1025,0,4113,33,16,2,349,65,2049,5441,4097,2420,1364,32,257,33,5377,513]

theorem envBound32977 : H12AffineFastState.Bounded env32977 := by
  intro p hp
  have h : env32977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32976_32977 : H12AffineEnvironment.transform 12 349 env32976 = env32977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env32976 == env32977) = true)

theorem identity32977 : scanCanonicalize (H12AffineFastState.compose env32977 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound32977 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env32978 : List Nat := [2,4,8,16,32,64,8,256,512,784,2048,4096,349,4673,1,342,4688,2421,785,0,4113,33,16,2,349,65,2049,4689,4097,2420,580,32,257,33,4625,513]

theorem envBound32978 : H12AffineFastState.Bounded env32978 := by
  intro p hp
  have h : env32978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32977_32978 : H12AffineEnvironment.transform 9 784 env32977 = env32978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env32977 == env32978) = true)

theorem identity32978 : scanCanonicalize (H12AffineFastState.compose env32978 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound32978 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env32979 : List Nat := [2,4,8,16,32,64,8,256,512,784,2048,81,349,528,1,342,513,2421,785,0,64,33,16,2,349,65,2049,512,80,2420,580,32,257,33,576,513]

theorem envBound32979 : H12AffineFastState.Bounded env32979 := by
  intro p hp
  have h : env32979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32978_32979 : H12AffineEnvironment.transform 11 81 env32978 = env32979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env32978 == env32979) = true)

def env32980 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,2097152,4194304,17,16777216,8193,65,21039476,18949465,2118976,2420,16852317,23160137,257,18965865,18949400,16777730]

theorem envBound32980 : H12AffineFastState.Bounded env32980 := by
  intro p hp
  have h : env32980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32970_32980 : H12AffineEnvironment.transform 6 9 env32970 = env32980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env32970 == env32980) = true)

theorem identity32980 : scanCanonicalize (H12AffineFastState.compose env32980 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(23+1) ^^^ 73737) := by decide +kernel

theorem selectedBound32980 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env32981 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,2097152,4194304,17,73737,8193,65,4204925,2098512,2118976,2420,1364,6309184,257,2114912,2098449,74251]

theorem envBound32981 : H12AffineFastState.Bounded env32981 := by
  intro p hp
  have h : env32981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32980_32981 : H12AffineEnvironment.transform 23 73737 env32980 = env32981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73737 env32980 == env32981) = true)

theorem identity32981 : scanCanonicalize (H12AffineFastState.compose env32981 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound32981 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env32982 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28698,16400,10281,1025,8540,2097152,4194304,17,20499,8193,65,4204925,2098512,2118976,2420,1364,6309184,257,2114912,2098449,21009]

theorem envBound32982 : H12AffineFastState.Bounded env32982 := by
  intro p hp
  have h : env32982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32981_32982 : H12AffineEnvironment.transform 15 28698 env32981 = env32982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env32981 == env32982) = true)

theorem identity32982 : scanCanonicalize (H12AffineFastState.compose env32982 (packedSelected [0,4,7,11,17,18,22] rootPS)) = affineNative (2^(21+1) ^^^ 9496) := by decide +kernel

theorem selectedBound32982 : packedSelected [0,4,7,11,17,18,22] rootPS < 2^1333 := by decide +kernel

def env32983 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28698,16400,10281,1025,8540,2097152,9496,17,20499,8193,65,3173,2098512,2118976,2420,1364,2121816,257,2114912,2098449,21009]

theorem envBound32983 : H12AffineFastState.Bounded env32983 := by
  intro p hp
  have h : env32983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32982_32983 : H12AffineEnvironment.transform 21 9496 env32982 = env32983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 9496 env32982 == env32983) = true)

theorem identity32983 : scanCanonicalize (H12AffineFastState.compose env32983 (packedSelected [3,5,10,11,23] rootPS)) = affineNative (2^(20+1) ^^^ 4452) := by decide +kernel

theorem selectedBound32983 : packedSelected [3,5,10,11,23] rootPS < 2^1333 := by decide +kernel

def env32984 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,28698,16400,10281,1025,8540,4452,9496,17,20499,8193,65,3173,5172,17444,2420,1364,28988,257,21508,5237,21009]

theorem envBound32984 : H12AffineFastState.Bounded env32984 := by
  intro p hp
  have h : env32984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32983_32984 : H12AffineEnvironment.transform 20 4452 env32983 = env32984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4452 env32983 == env32984) = true)

theorem identity32984 : scanCanonicalize (H12AffineFastState.compose env32984 (packedSelected [12,15,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound32984 : packedSelected [12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env32985 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4113,8541,8203,4097,10281,1025,8540,4452,9496,17,2,8193,65,3173,5172,5173,2420,1364,8493,257,1045,5237,512]

theorem envBound32985 : H12AffineFastState.Bounded env32985 := by
  intro p hp
  have h : env32985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32984_32985 : H12AffineEnvironment.transform 13 4113 env32984 = env32985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env32984 == env32985) = true)

theorem identity32985 : scanCanonicalize (H12AffineFastState.compose env32985 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound32985 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env32986 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,8192,4113,8541,8203,4097,10281,272,8540,4452,8201,17,2,8193,65,2420,4389,4388,2420,69,8493,257,260,4452,512]

theorem envBound32986 : H12AffineFastState.Bounded env32986 := by
  intro p hp
  have h : env32986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32985_32986 : H12AffineEnvironment.transform 9 273 env32985 = env32986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env32985 == env32986) = true)

theorem identity32986 : scanCanonicalize (H12AffineFastState.compose env32986 (packedSelected [4,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 113) := by decide +kernel

theorem selectedBound32986 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env32987 : List Nat := [2,4,8,16,32,64,9,256,512,273,113,4096,8192,4113,8541,8203,4097,8280,272,8540,4452,8201,17,2,8193,65,261,4389,4388,261,69,8493,257,260,4452,512]

theorem envBound32987 : H12AffineFastState.Bounded env32987 := by
  intro p hp
  have h : env32987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans32986_32987 : H12AffineEnvironment.transform 10 113 env32986 = env32987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 113 env32986 == env32987) = true)

theorem identity32987 : scanCanonicalize (H12AffineFastState.compose env32987 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound32987 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1