import H12CloudChart1Data164

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound41845 : H12AffineFastState.Bounded env41845 := by
  intro p hp
  have h : env41845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41844_41845 : H12AffineEnvironment.transform 10 1345 env41844 = env41845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1345 env41844 == env41845) = true)

theorem identity41845 : scanCanonicalize (H12AffineFastState.compose env41845 (packedSelected [0,1,2,3,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound41845 : packedSelected [0,1,2,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env41846 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1077,4096,1100,5236,1125,34,4096,81,1024,1124,5156,1092,16,2,1100,64,1077,5221,5221,81,69,1092,116,32,5156,513]

theorem envBound41846 : H12AffineFastState.Bounded env41846 := by
  intro p hp
  have h : env41846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41845_41846 : H12AffineEnvironment.transform 7 116 env41845 = env41846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env41845 == env41846) = true)

theorem identity41846 : scanCanonicalize (H12AffineFastState.compose env41846 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41846 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env41847 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,4096,1052,5156,1077,34,4096,1,1024,1076,5156,1044,16,2,1052,16,1077,5173,5173,1,21,1044,36,32,5156,513]

theorem envBound41847 : H12AffineFastState.Bounded env41847 := by
  intro p hp
  have h : env41847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41846_41847 : H12AffineEnvironment.transform 5 16 env41846 = env41847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41846 == env41847) = true)

theorem identity41847 : scanCanonicalize (H12AffineFastState.compose env41847 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound41847 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env41848 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,1044,1052,48,1077,34,1044,1,1024,1076,48,1044,16,2,1052,16,1077,33,33,1,21,1044,36,32,48,513]

theorem envBound41848 : H12AffineFastState.Bounded env41848 := by
  intro p hp
  have h : env41848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41847_41848 : H12AffineEnvironment.transform 11 1044 env41847 = env41848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env41847 == env41848) = true)

def env41849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,10281,1024,32769,77898,73771,62541,21762,8192,64,67926,57676,102742,97407,75103,73771,256,21792,46093,513]

theorem envBound41849 : H12AffineFastState.Bounded env41849 := by
  intro p hp
  have h : env41849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41839_41849 : H12AffineEnvironment.transform 17 10281 env41839 = env41849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41839 == env41849) = true)

theorem identity41849 : scanCanonicalize (H12AffineFastState.compose env41849 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound41849 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,28698,4096,10281,1024,32769,16464,20529,62541,21762,8192,64,31052,57676,57676,3173,21829,20529,256,21792,46093,513]

theorem envBound41850 : H12AffineFastState.Bounded env41850 := by
  intro p hp
  have h : env41850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41849_41850 : H12AffineEnvironment.transform 15 28698 env41849 = env41850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env41849 == env41850) = true)

theorem identity41850 : scanCanonicalize (H12AffineFastState.compose env41850 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound41850 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,28698,4096,10281,1024,8540,16464,20529,21776,21762,8192,64,31052,16401,16401,3173,21829,20529,256,21792,5456,513]

theorem envBound41851 : H12AffineFastState.Bounded env41851 := by
  intro p hp
  have h : env41851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41850_41851 : H12AffineEnvironment.transform 14 8541 env41850 = env41851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env41850 == env41851) = true)

theorem identity41851 : scanCanonicalize (H12AffineFastState.compose env41851 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound41851 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env41852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1052,16384,1345,21510,4096,3125,1024,1344,16464,20529,21776,21762,1052,64,23888,16401,16401,3173,21829,20529,256,21792,5456,513]

theorem envBound41852 : H12AffineFastState.Bounded env41852 := by
  intro p hp
  have h : env41852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41851_41852 : H12AffineEnvironment.transform 12 1052 env41851 = env41852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env41851 == env41852) = true)

theorem identity41852 : scanCanonicalize (H12AffineFastState.compose env41852 (packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound41852 : packedSelected [0,1,2,3,5,6,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env41853 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,121,16384,292,20579,4096,2128,101,293,16464,20529,20853,20839,121,64,22837,16401,16401,2048,20768,20529,256,20805,4405,513]

theorem envBound41853 : H12AffineFastState.Bounded env41853 := by
  intro p hp
  have h : env41853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41852_41853 : H12AffineEnvironment.transform 9 101 env41852 = env41853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env41852 == env41853) = true)

theorem identity41853 : scanCanonicalize (H12AffineFastState.compose env41853 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 2420) := by decide +kernel

theorem selectedBound41853 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env41854 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,4096,121,2420,292,6423,4096,2128,101,293,2340,6469,6145,6163,121,64,4161,2405,2405,2048,6228,6469,256,6193,4405,513]

theorem envBound41854 : H12AffineFastState.Bounded env41854 := by
  intro p hp
  have h : env41854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41853_41854 : H12AffineEnvironment.transform 13 2420 env41853 = env41854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2420 env41853 == env41854) = true)

def env41855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,77898,329731,62540,21762,8193,64,158028,57677,102743,406605,75102,329730,256,21792,46092,513]

theorem envBound41855 : H12AffineFastState.Bounded env41855 := by
  intro p hp
  have h : env41855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41837_41855 : H12AffineEnvironment.transform 6 9 env41837 = env41855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41837 == env41855) = true)

def env41856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77898,73771,62540,21762,8193,64,158028,57677,102743,138341,75102,73770,256,21792,46092,513]

theorem envBound41856 : H12AffineFastState.Bounded env41856 := by
  intro p hp
  have h : env41856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41855_41856 : H12AffineEnvironment.transform 17 10280 env41855 = env41856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env41855 == env41856) = true)

def env41857 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77850,73771,62492,21762,8193,16,157980,57629,102663,138293,75022,73770,256,21792,46092,513]

theorem envBound41857 : H12AffineFastState.Bounded env41857 := by
  intro p hp
  have h : env41857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41856_41857 : H12AffineEnvironment.transform 5 16 env41856 = env41857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41856 == env41857) = true)

theorem identity41857 : scanCanonicalize (H12AffineFastState.compose env41857 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound41857 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env41858 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,131072,10280,1024,0,77850,73771,29725,21762,8193,16,157980,24860,69894,138293,75022,73770,256,21792,13325,513]

theorem envBound41858 : H12AffineFastState.Bounded env41858 := by
  intro p hp
  have h : env41858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41857_41858 : H12AffineEnvironment.transform 14 1 env41857 = env41858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env41857 == env41858) = true)

theorem identity41858 : scanCanonicalize (H12AffineFastState.compose env41858 (packedSelected [0,3,5,7,10,11,14] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound41858 : packedSelected [0,3,5,7,10,11,14] rootPS < 2^1333 := by decide +kernel

def env41859 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,65536,16400,10280,1024,0,77850,73771,29725,21762,8193,16,10508,24860,69894,23589,75022,73770,256,21792,13325,513]

theorem envBound41859 : H12AffineFastState.Bounded env41859 := by
  intro p hp
  have h : env41859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41858_41859 : H12AffineEnvironment.transform 16 16400 env41858 = env41859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env41858 == env41859) = true)

theorem identity41859 : scanCanonicalize (H12AffineFastState.compose env41859 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41859 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env41860 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,1,8202,16400,10280,1024,0,4112,33,29725,21762,8193,16,10508,24860,12556,23589,1284,32,256,21792,13325,513]

theorem envBound41860 : H12AffineFastState.Bounded env41860 := by
  intro p hp
  have h : env41860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41859_41860 : H12AffineEnvironment.transform 15 8202 env41859 = env41860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41859 == env41860) = true)

theorem identity41860 : scanCanonicalize (H12AffineFastState.compose env41860 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound41860 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41861 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,8202,13341,10280,1024,0,4112,33,16,8463,8193,16,10508,5393,12556,10280,1284,32,256,8493,13325,513]

theorem envBound41861 : H12AffineFastState.Bounded env41861 := by
  intro p hp
  have h : env41861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41860_41861 : H12AffineEnvironment.transform 13 13325 env41860 = env41861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env41860 == env41861) = true)

theorem identity41861 : scanCanonicalize (H12AffineFastState.compose env41861 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41861 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env41862 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,262,5393,2340,1024,0,4112,33,16,3,269,16,2048,5393,4096,2340,1284,32,256,33,5377,513]

theorem envBound41862 : H12AffineFastState.Bounded env41862 := by
  intro p hp
  have h : env41862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41861_41862 : H12AffineEnvironment.transform 12 268 env41861 = env41862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41861 == env41862) = true)

theorem identity41862 : scanCanonicalize (H12AffineFastState.compose env41862 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41862 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41863 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5156,1,35,5172,2049,1024,0,4112,33,16,3,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound41863 : H12AffineFastState.Bounded env41863 := by
  intro p hp
  have h : env41863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41862_41863 : H12AffineEnvironment.transform 7 37 env41862 = env41863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41862 == env41863) = true)

def env41864 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,48,41,1044,1,35,1028,2049,1024,0,32,33,16,3,40,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound41864 : H12AffineFastState.Bounded env41864 := by
  intro p hp
  have h : env41864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41863_41864 : H12AffineEnvironment.transform 11 48 env41863 = env41864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env41863 == env41864) = true)

theorem identity41864 : scanCanonicalize (H12AffineFastState.compose env41864 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound41864 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41865 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,48,41,32,1,35,48,2049,52,0,32,33,16,3,40,16,2048,48,48,2049,21,32,37,33,32,513]

theorem envBound41865 : H12AffineFastState.Bounded env41865 := by
  intro p hp
  have h : env41865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41864_41865 : H12AffineEnvironment.transform 9 52 env41864 = env41865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env41864 == env41865) = true)

theorem identity41865 : scanCanonicalize (H12AffineFastState.compose env41865 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41865 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41866 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,1,2,17,2049,21,0,1,0,16,3,9,16,2048,17,17,2049,21,1,4,0,1,513]

theorem envBound41866 : H12AffineFastState.Bounded env41866 := by
  intro p hp
  have h : env41866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41865_41866 : H12AffineEnvironment.transform 4 1 env41865 = env41866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41865 == env41866) = true)

def leafEnv41866 : List Nat := [2,4,8,16,1,16,9,4,512,21,2048,17,8,1,1,2,17,2049,21,0,1,0,16,3,21,9,1,16,2048,17,17,2049,21,1,4,0,4,3,1,513,1,1,0]

def active41866 : List Nat := [0,1,2,3,8,10]

def tree41866 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41866 : H12WitnessSearch.Good tree41866 := H12GlobalWitnessIndex.good

theorem leafIdentity41866 : H12AffineFastState.composeSystem env41866 rootObs = leafEnv41866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41866 rootObs == leafEnv41866) = true)

theorem terminalChecked41866 : H12PackedTerminal.terminalCheckFast leafEnv41866 active41866 tree41866 = true := by decide +kernel

def env41867 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,41,1045,1,35,1029,2049,1024,0,33,33,16,3,40,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound41867 : H12AffineFastState.Bounded env41867 := by
  intro p hp
  have h : env41867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41863_41867 : H12AffineEnvironment.transform 11 49 env41863 = env41867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env41863 == env41867) = true)

def env41868 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,77851,73771,62493,21762,8193,17,157981,57628,102662,138292,75023,73770,256,21792,46092,513]

theorem envBound41868 : H12AffineFastState.Bounded env41868 := by
  intro p hp
  have h : env41868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41856_41868 : H12AffineEnvironment.transform 5 17 env41856 = env41868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41856 == env41868) = true)

theorem identity41868 : scanCanonicalize (H12AffineFastState.compose env41868 (packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound41868 : packedSelected [0,3,4,7,9,11,12,14,16,18,20,24] rootPS < 2^1333 := by decide +kernel

def env41869 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,90139,10280,1024,32769,77851,73771,62493,21762,8193,17,67846,57628,102662,97327,75023,73770,256,21792,46092,513]

theorem envBound41869 : H12AffineFastState.Bounded env41869 := by
  intro p hp
  have h : env41869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41868_41869 : H12AffineEnvironment.transform 16 90139 env41868 = env41869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env41868 == env41869) = true)

theorem identity41869 : scanCanonicalize (H12AffineFastState.compose env41869 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound41869 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41870 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,65536,90139,10280,1024,21761,77851,73771,8477,21762,8193,17,67846,13340,82950,97327,75023,73770,256,21792,24844,513]

theorem envBound41870 : H12AffineFastState.Bounded env41870 := by
  intro p hp
  have h : env41870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41869_41870 : H12AffineEnvironment.transform 14 21760 env41869 = env41870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env41869 == env41870) = true)

theorem identity41870 : scanCanonicalize (H12AffineFastState.compose env41870 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound41870 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41871 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,21760,29962,5393,10280,1024,21761,17681,21793,8477,21762,8193,17,31756,13340,12556,2341,20485,21792,256,21792,24844,513]

theorem envBound41871 : H12AffineFastState.Bounded env41871 := by
  intro p hp
  have h : env41871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41870_41871 : H12AffineEnvironment.transform 15 29962 env41870 = env41871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env41870 == env41871) = true)

theorem identity41871 : scanCanonicalize (H12AffineFastState.compose env41871 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound41871 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env41872 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13608,8232,34,5393,10280,1024,8233,12345,8201,8477,8234,8193,17,2340,13340,12556,2341,9517,8200,256,8200,5156,513]

theorem envBound41872 : H12AffineFastState.Bounded env41872 := by
  intro p hp
  have h : env41872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41871_41872 : H12AffineEnvironment.transform 13 13608 env41871 = env41872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env41871 == env41872) = true)

theorem identity41872 : scanCanonicalize (H12AffineFastState.compose env41872 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41872 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env41873 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,40,5376,0,34,5393,2048,1024,1,4113,33,309,2,41,17,2340,5172,4388,2341,1285,32,256,32,5156,513]

theorem envBound41873 : H12AffineFastState.Bounded env41873 := by
  intro p hp
  have h : env41873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41872_41873 : H12AffineEnvironment.transform 12 40 env41872 = env41873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41872 == env41873) = true)

theorem identity41873 : scanCanonicalize (H12AffineFastState.compose env41873 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound41873 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env41874 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,308,40,1076,0,34,1061,2048,1024,1,293,33,309,2,41,17,2340,1280,16,2341,1285,32,256,32,1296,513]

theorem envBound41874 : H12AffineFastState.Bounded env41874 := by
  intro p hp
  have h : env41874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41873_41874 : H12AffineEnvironment.transform 11 308 env41873 = env41874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env41873 == env41874) = true)

theorem identity41874 : scanCanonicalize (H12AffineFastState.compose env41874 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound41874 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env41875 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1077,308,40,1076,0,34,1061,1077,1024,1,293,33,309,2,41,17,1297,1280,16,1296,1285,32,256,32,1296,513]

theorem envBound41875 : H12AffineFastState.Bounded env41875 := by
  intro p hp
  have h : env41875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41874_41875 : H12AffineEnvironment.transform 10 1077 env41874 = env41875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env41874 == env41875) = true)

theorem identity41875 : scanCanonicalize (H12AffineFastState.compose env41875 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound41875 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41876 : List Nat := [2,4,8,16,32,17,9,256,512,304,261,308,40,260,0,34,277,261,304,1,293,33,309,2,41,17,33,48,16,32,53,32,256,32,32,513]

theorem envBound41876 : H12AffineFastState.Bounded env41876 := by
  intro p hp
  have h : env41876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41875_41876 : H12AffineEnvironment.transform 9 304 env41875 = env41876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env41875 == env41876) = true)

theorem identity41876 : scanCanonicalize (H12AffineFastState.compose env41876 (packedSelected [0,3,8] rootPS)) = affineNative (2^(7+1) ^^^ 43) := by decide +kernel

theorem selectedBound41876 : packedSelected [0,3,8] rootPS < 2^1333 := by decide +kernel

def env41877 : List Nat := [2,4,8,16,32,17,9,43,512,27,46,31,40,47,0,34,62,46,27,1,14,33,30,2,41,17,33,48,16,32,53,32,43,32,32,513]

theorem envBound41877 : H12AffineFastState.Bounded env41877 := by
  intro p hp
  have h : env41877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41876_41877 : H12AffineEnvironment.transform 7 43 env41876 = env41877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 43 env41876 == env41877) = true)

theorem identity41877 : scanCanonicalize (H12AffineFastState.compose env41877 (packedSelected [2,14] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound41877 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env41878 : List Nat := [2,4,7,16,32,17,6,36,512,20,33,16,39,32,0,34,49,33,20,1,1,33,17,2,38,17,33,48,16,32,53,32,36,32,32,513]

theorem envBound41878 : H12AffineFastState.Bounded env41878 := by
  intro p hp
  have h : env41878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41877_41878 : H12AffineEnvironment.transform 2 7 env41877 = env41878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env41877 == env41878) = true)

theorem identity41878 : scanCanonicalize (H12AffineFastState.compose env41878 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound41878 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41879 : List Nat := [2,4,7,16,32,17,6,36,4,20,33,16,39,32,0,34,49,33,20,1,1,33,17,2,38,17,33,48,16,32,53,32,36,32,32,5]

theorem envBound41879 : H12AffineFastState.Bounded env41879 := by
  intro p hp
  have h : env41879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41878_41879 : H12AffineEnvironment.transform 8 4 env41878 = env41879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env41878 == env41879) = true)

theorem identity41879 : scanCanonicalize (H12AffineFastState.compose env41879 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41879 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41880 : List Nat := [1,4,4,16,32,17,5,36,4,20,33,16,36,32,0,33,49,33,20,1,1,33,17,1,37,17,33,48,16,32,53,32,36,32,32,5]

theorem envBound41880 : H12AffineFastState.Bounded env41880 := by
  intro p hp
  have h : env41880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41879_41880 : H12AffineEnvironment.transform 0 1 env41879 = env41880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41879 == env41880) = true)

def env41881 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,77898,73770,62540,21762,8193,64,158028,57677,102743,138340,75102,73771,256,21792,46092,513]

theorem envBound41881 : H12AffineFastState.Bounded env41881 := by
  intro p hp
  have h : env41881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41855_41881 : H12AffineEnvironment.transform 17 10281 env41855 = env41881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41855 == env41881) = true)

theorem identity41881 : scanCanonicalize (H12AffineFastState.compose env41881 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound41881 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41882 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10281,1024,29789,77898,73770,16,21762,8193,64,158028,5393,91403,138340,75102,73771,256,21792,16464,513]

theorem envBound41882 : H12AffineFastState.Bounded env41882 := by
  intro p hp
  have h : env41882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41881_41882 : H12AffineEnvironment.transform 14 29788 env41881 = env41882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env41881 == env41882) = true)

theorem identity41882 : scanCanonicalize (H12AffineFastState.compose env41882 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound41882 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41883 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,90138,10281,1024,29789,77898,73770,16,21762,8193,64,67926,5393,91403,97406,75102,73771,256,21792,16464,513]

theorem envBound41883 : H12AffineFastState.Bounded env41883 := by
  intro p hp
  have h : env41883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41882_41883 : H12AffineEnvironment.transform 16 90138 env41882 = env41883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env41882 == env41883) = true)

theorem identity41883 : scanCanonicalize (H12AffineFastState.compose env41883 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 28698) := by decide +kernel

theorem selectedBound41883 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env41884 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,28698,4096,10281,1024,29789,16464,20528,16,21762,8193,64,31052,5393,5393,3172,21828,20529,256,21792,16464,513]

theorem envBound41884 : H12AffineFastState.Bounded env41884 := by
  intro p hp
  have h : env41884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41883_41884 : H12AffineEnvironment.transform 15 28698 env41883 = env41884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28698 env41883 == env41884) = true)

theorem identity41884 : scanCanonicalize (H12AffineFastState.compose env41884 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 5133) := by decide +kernel

theorem selectedBound41884 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env41885 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5133,16384,16465,17431,4096,7204,1024,16464,16464,20528,16,21762,5132,64,19777,5393,5393,3172,21828,20529,256,21792,16464,513]

theorem envBound41885 : H12AffineFastState.Bounded env41885 := by
  intro p hp
  have h : env41885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41884_41885 : H12AffineEnvironment.transform 12 5133 env41884 = env41885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5133 env41884 == env41885) = true)

theorem identity41885 : scanCanonicalize (H12AffineFastState.compose env41885 (packedSelected [0,2,4,6,7,9,11,14,23] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound41885 : packedSelected [0,2,4,6,7,9,11,14,23] rootPS < 2^1333 := by decide +kernel

def env41886 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,16384,16465,17431,1061,2049,1024,16464,16464,17429,16,16679,41,64,19777,308,308,3172,16737,17428,256,16645,16464,513]

theorem envBound41886 : H12AffineFastState.Bounded env41886 := by
  intro p hp
  have h : env41886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41885_41886 : H12AffineEnvironment.transform 11 1061 env41885 = env41886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env41885 == env41886) = true)

theorem identity41886 : scanCanonicalize (H12AffineFastState.compose env41886 (packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 3393) := by decide +kernel

theorem selectedBound41886 : packedSelected [1,2,3,4,5,8,9,11,14,15] rootPS < 2^1333 := by decide +kernel

def env41887 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1061,40,3393,3344,2390,1061,2049,1024,3345,3345,2388,16,3174,41,64,0,308,308,3172,3104,2389,256,3140,3345,513]

theorem envBound41887 : H12AffineFastState.Bounded env41887 := by
  intro p hp
  have h : env41887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41886_41887 : H12AffineEnvironment.transform 13 3393 env41886 = env41887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3393 env41886 == env41887) = true)

theorem identity41887 : scanCanonicalize (H12AffineFastState.compose env41887 (packedSelected [0,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound41887 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env41888 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,64,40,2340,2421,2390,64,2049,101,2420,2420,2388,16,2051,41,64,0,308,308,2049,2117,2389,256,2081,2420,513]

theorem envBound41888 : H12AffineFastState.Bounded env41888 := by
  intro p hp
  have h : env41888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41887_41888 : H12AffineEnvironment.transform 9 101 env41887 = env41888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env41887 == env41888) = true)

theorem identity41888 : scanCanonicalize (H12AffineFastState.compose env41888 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound41888 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env41889 : List Nat := [2,4,8,16,32,64,9,256,512,101,373,64,40,81,0,35,64,372,101,1,1,33,16,374,41,64,0,308,308,372,304,32,256,340,1,513]

theorem envBound41889 : H12AffineFastState.Bounded env41889 := by
  intro p hp
  have h : env41889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41888_41889 : H12AffineEnvironment.transform 10 373 env41888 = env41889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env41888 == env41889) = true)

theorem identity41889 : scanCanonicalize (H12AffineFastState.compose env41889 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound41889 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41890 : List Nat := [2,4,8,16,32,0,9,256,512,37,309,0,40,17,0,35,0,308,37,1,1,33,16,310,41,0,0,308,308,308,304,32,256,276,1,513]

theorem envBound41890 : H12AffineFastState.Bounded env41890 := by
  intro p hp
  have h : env41890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41889_41890 : H12AffineEnvironment.transform 5 0 env41889 = env41890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env41889 == env41890) = true)

theorem identity41890 : scanCanonicalize (H12AffineFastState.compose env41890 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound41890 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41891 : List Nat := [2,4,8,16,32,0,9,256,308,37,309,0,40,17,0,35,0,308,37,1,1,33,16,310,41,0,0,308,308,308,304,32,256,276,1,309]

theorem envBound41891 : H12AffineFastState.Bounded env41891 := by
  intro p hp
  have h : env41891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41890_41891 : H12AffineEnvironment.transform 8 308 env41890 = env41891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env41890 == env41891) = true)

theorem identity41891 : scanCanonicalize (H12AffineFastState.compose env41891 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound41891 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41892 : List Nat := [2,4,8,16,32,0,9,36,16,37,17,0,40,17,0,35,0,16,37,1,1,33,16,18,41,0,0,16,16,16,20,32,36,48,1,17]

theorem envBound41892 : H12AffineFastState.Bounded env41892 := by
  intro p hp
  have h : env41892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41891_41892 : H12AffineEnvironment.transform 7 36 env41891 = env41892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env41891 == env41892) = true)

theorem identity41892 : scanCanonicalize (H12AffineFastState.compose env41892 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41892 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41893 : List Nat := [2,4,8,16,1,0,9,5,16,4,17,0,9,17,0,2,0,16,4,1,1,0,16,18,8,0,0,16,16,16,20,1,5,17,1,17]

theorem envBound41893 : H12AffineFastState.Bounded env41893 := by
  intro p hp
  have h : env41893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41892_41893 : H12AffineEnvironment.transform 4 1 env41892 = env41893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41892 == env41893) = true)

theorem identity41893 : scanCanonicalize (H12AffineFastState.compose env41893 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41893 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41894 : List Nat := [2,4,8,0,1,0,9,5,0,4,1,0,9,1,0,2,0,0,4,1,1,0,0,2,8,0,0,0,0,0,4,1,5,1,1,1]

theorem envBound41894 : H12AffineFastState.Bounded env41894 := by
  intro p hp
  have h : env41894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41893_41894 : H12AffineEnvironment.transform 3 0 env41893 = env41894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41893 == env41894) = true)

def env41895 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2373825,62661,2188616,8328,64,158029,57796,2138516,406724,2102685,2373705,256,21792,46213,2175563]

theorem envBound41895 : H12AffineFastState.Bounded env41895 := by
  intro p hp
  have h : env41895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41835_41895 : H12AffineEnvironment.transform 21 2373825 env41835 = env41895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2373825 env41835 == env41895) = true)

theorem identity41895 : scanCanonicalize (H12AffineFastState.compose env41895 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound41895 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41896 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,2097152,2373825,16,2188616,8328,64,158029,5393,2118977,406724,2102685,2373705,256,21792,16464,2175563]

theorem envBound41896 : H12AffineFastState.Bounded env41896 := by
  intro p hp
  have h : env41896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41895_41896 : H12AffineEnvironment.transform 14 29909 env41895 = env41896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env41895 == env41896) = true)

def env41897 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,262144,1024,8660,2097152,2373825,16,2175048,8328,64,146509,5393,2097217,406724,2102685,2373705,256,32,5456,2175563]

theorem envBound41897 : H12AffineFastState.Bounded env41897 := by
  intro p hp
  have h : env41897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41896_41897 : H12AffineEnvironment.transform 13 5376 env41896 = env41897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env41896 == env41897) = true)

def env41898 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,262144,1024,8660,2097152,2373825,16,2175048,8328,64,10589,5393,2097217,270804,2102685,2373705,256,32,5456,2175563]

theorem envBound41898 : H12AffineFastState.Bounded env41898 := by
  intro p hp
  have h : env41898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41897_41898 : H12AffineEnvironment.transform 16 5392 env41897 = env41898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env41897 == env41898) = true)

theorem identity41898 : scanCanonicalize (H12AffineFastState.compose env41898 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound41898 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env41899 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,262144,1024,8660,77898,329867,16,2,8328,64,10589,5393,77835,270804,75223,329731,256,32,5456,513]

theorem envBound41899 : H12AffineFastState.Bounded env41899 := by
  intro p hp
  have h : env41899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41898_41899 : H12AffineEnvironment.transform 20 77898 env41898 = env41899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env41898 == env41899) = true)

theorem identity41899 : scanCanonicalize (H12AffineFastState.compose env41899 (packedSelected [0,2,4,6,11,14,18,20,22,23,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound41899 : packedSelected [0,2,4,6,11,14,18,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env41900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5392,10281,1024,8660,77898,73890,16,2,8328,64,10589,5393,77835,2557,75223,73770,256,32,5456,513]

theorem envBound41900 : H12AffineFastState.Bounded env41900 := by
  intro p hp
  have h : env41900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41899_41900 : H12AffineEnvironment.transform 17 10281 env41899 = env41900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env41899 == env41900) = true)

theorem identity41900 : scanCanonicalize (H12AffineFastState.compose env41900 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 170) := by decide +kernel

theorem selectedBound41900 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env41901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,170,5392,10281,1024,8660,12512,8200,16,2,8328,64,10589,5393,12449,2557,9597,8320,256,32,5456,513]

theorem envBound41901 : H12AffineFastState.Bounded env41901 := by
  intro p hp
  have h : env41901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41900_41901 : H12AffineEnvironment.transform 15 170 env41900 = env41901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 170 env41900 == env41901) = true)

theorem identity41901 : scanCanonicalize (H12AffineFastState.compose env41901 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 204) := by decide +kernel

theorem selectedBound41901 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env41902 : List Nat := [2,4,8,16,32,64,128,256,512,204,2048,4096,8192,4556,8661,170,4572,10281,204,8660,12512,8200,16,2,8328,64,10589,4573,12449,2557,8625,8320,256,32,4508,513]

theorem envBound41902 : H12AffineFastState.Bounded env41902 := by
  intro p hp
  have h : env41902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41901_41902 : H12AffineEnvironment.transform 9 204 env41901 = env41902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 204 env41901 == env41902) = true)

theorem identity41902 : scanCanonicalize (H12AffineFastState.compose env41902 (packedSelected [1,2,3,4,5,6,8,9,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound41902 : packedSelected [1,2,3,4,5,6,8,9,14,15] rootPS < 2^1333 := by decide +kernel

def env41903 : List Nat := [2,4,8,16,32,64,128,256,512,204,2048,308,8192,248,8661,170,232,10281,204,8660,8660,8200,16,2,8328,64,10589,233,8597,2557,8625,8320,256,32,168,513]

theorem envBound41903 : H12AffineFastState.Bounded env41903 := by
  intro p hp
  have h : env41903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41902_41903 : H12AffineEnvironment.transform 11 308 env41902 = env41903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env41902 == env41903) = true)

theorem identity41903 : scanCanonicalize (H12AffineFastState.compose env41903 (packedSelected [0,1,2,4,7,8,9,19] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound41903 : packedSelected [0,1,2,4,7,8,9,19] rootPS < 2^1333 := by decide +kernel

def env41904 : List Nat := [2,4,8,16,32,64,128,256,512,204,2048,308,160,248,373,170,232,2185,204,372,372,168,16,2,40,64,2557,233,309,2557,273,32,256,32,168,513]

theorem envBound41904 : H12AffineFastState.Bounded env41904 := by
  intro p hp
  have h : env41904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41903_41904 : H12AffineEnvironment.transform 12 160 env41903 = env41904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env41903 == env41904) = true)

theorem identity41904 : scanCanonicalize (H12AffineFastState.compose env41904 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 220) := by decide +kernel

theorem selectedBound41904 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41905 : List Nat := [2,4,8,16,32,64,128,220,512,204,2048,232,160,248,169,170,232,2185,204,168,168,168,16,2,40,64,2081,233,233,2081,205,32,220,32,168,513]

theorem envBound41905 : H12AffineFastState.Bounded env41905 := by
  intro p hp
  have h : env41905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41904_41905 : H12AffineEnvironment.transform 7 220 env41904 = env41905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 220 env41904 == env41905) = true)

theorem identity41905 : scanCanonicalize (H12AffineFastState.compose env41905 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound41905 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41906 : List Nat := [2,4,8,16,32,64,41,117,512,101,2048,65,9,81,0,3,65,2080,101,1,1,1,16,2,40,64,2081,64,64,2081,100,32,117,32,1,513]

theorem envBound41906 : H12AffineFastState.Bounded env41906 := by
  intro p hp
  have h : env41906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41905_41906 : H12AffineEnvironment.transform 6 41 env41905 = env41906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env41905 == env41906) = true)

theorem identity41906 : scanCanonicalize (H12AffineFastState.compose env41906 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41906 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41907 : List Nat := [2,4,8,16,32,16,41,37,512,53,2048,17,9,1,0,3,17,2080,53,1,1,1,16,2,40,16,2081,16,16,2081,52,32,37,32,1,513]

theorem envBound41907 : H12AffineFastState.Bounded env41907 := by
  intro p hp
  have h : env41907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41906_41907 : H12AffineEnvironment.transform 5 16 env41906 = env41907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41906 == env41907) = true)

theorem identity41907 : scanCanonicalize (H12AffineFastState.compose env41907 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41907 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41908 : List Nat := [2,4,8,16,1,16,8,4,512,20,2048,17,9,1,0,3,17,2049,20,1,1,1,16,2,9,16,2048,16,16,2048,21,1,4,1,1,513]

theorem envBound41908 : H12AffineFastState.Bounded env41908 := by
  intro p hp
  have h : env41908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41907_41908 : H12AffineEnvironment.transform 4 1 env41907 = env41908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41907 == env41908) = true)

theorem identity41908 : scanCanonicalize (H12AffineFastState.compose env41908 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound41908 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41909 : List Nat := [2,4,8,16,1,16,8,4,512,20,529,17,9,1,0,3,17,528,20,1,1,1,16,2,9,16,529,16,16,529,21,1,4,1,1,513]

theorem envBound41909 : H12AffineFastState.Bounded env41909 := by
  intro p hp
  have h : env41909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41908_41909 : H12AffineEnvironment.transform 10 529 env41908 = env41909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env41908 == env41909) = true)

theorem identity41909 : scanCanonicalize (H12AffineFastState.compose env41909 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound41909 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41910 : List Nat := [2,4,8,0,1,0,8,4,512,4,513,1,9,1,0,3,1,512,4,1,1,1,0,2,9,0,513,0,0,513,5,1,4,1,1,513]

theorem envBound41910 : H12AffineFastState.Bounded env41910 := by
  intro p hp
  have h : env41910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41909_41910 : H12AffineEnvironment.transform 3 0 env41909 = env41910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env41909 == env41910) = true)

def env41911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,5393,262144,1024,8660,2097152,2373825,16,2175048,8328,64,10588,5393,2097217,270805,2102685,2373705,256,32,5456,2175563]

theorem envBound41911 : H12AffineFastState.Bounded env41911 := by
  intro p hp
  have h : env41911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41897_41911 : H12AffineEnvironment.transform 16 5393 env41897 = env41911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env41897 == env41911) = true)

def env41912 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,5393,262144,1024,8580,2097152,2373777,16,2175000,8328,16,10508,5393,2097169,270725,2102685,2373657,256,32,5376,2175515]

theorem envBound41912 : H12AffineFastState.Bounded env41912 := by
  intro p hp
  have h : env41912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41911_41912 : H12AffineEnvironment.transform 5 16 env41911 = env41912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41911 == env41912) = true)

theorem identity41912 : scanCanonicalize (H12AffineFastState.compose env41912 (packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS)) = affineNative (2^(20+1) ^^^ 334011) := by decide +kernel

theorem selectedBound41912 : packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS < 2^1333 := by decide +kernel

def env41913 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,65536,5393,262144,1024,8580,334011,73770,16,272547,8328,16,10508,5393,333994,270725,331046,73890,256,32,5376,273056]

theorem envBound41913 : H12AffineFastState.Bounded env41913 := by
  intro p hp
  have h : env41913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41912_41913 : H12AffineEnvironment.transform 20 334011 env41912 = env41913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 334011 env41912 == env41913) = true)

theorem identity41913 : scanCanonicalize (H12AffineFastState.compose env41913 (packedSelected [0,4,7,11,12,15,16,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound41913 : packedSelected [0,4,7,11,12,15,16,20,22,23] rootPS < 2^1333 := by decide +kernel

def env41914 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8581,398,5393,262144,1024,8580,268597,8612,16,272547,8328,16,10508,5393,268580,270725,265384,8492,256,32,5376,273056]

theorem envBound41914 : H12AffineFastState.Bounded env41914 := by
  intro p hp
  have h : env41914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41913_41914 : H12AffineEnvironment.transform 15 398 env41913 = env41914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env41913 == env41914) = true)

theorem identity41914 : scanCanonicalize (H12AffineFastState.compose env41914 (packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound41914 : packedSelected [0,3,4,5,7,9,11,15,16,19] rootPS < 2^1333 := by decide +kernel

def env41915 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5376,1,398,5393,262144,1024,0,268597,32,16,264487,268,16,2184,5393,268580,262145,265384,168,256,32,5376,264996]

theorem envBound41915 : H12AffineFastState.Bounded env41915 := by
  intro p hp
  have h : env41915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41914_41915 : H12AffineEnvironment.transform 12 388 env41914 = env41915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env41914 == env41915) = true)

theorem identity41915 : scanCanonicalize (H12AffineFastState.compose env41915 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound41915 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env41916 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,300,5376,1,294,5393,262144,1024,0,268597,32,16,264487,268,16,2080,5393,268580,262145,265216,0,256,32,5376,264996]

theorem envBound41916 : H12AffineFastState.Bounded env41916 := by
  intro p hp
  have h : env41916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41915_41916 : H12AffineEnvironment.transform 6 40 env41915 = env41916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env41915 == env41916) = true)

theorem identity41916 : scanCanonicalize (H12AffineFastState.compose env41916 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound41916 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41917 : List Nat := [2,4,8,16,32,16,40,256,512,1024,2048,4096,300,5376,1,294,5393,2340,1024,0,4113,32,16,3,268,16,2080,5393,4096,2341,1316,0,256,32,5376,512]

theorem envBound41917 : H12AffineFastState.Bounded env41917 := by
  intro p hp
  have h : env41917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41916_41917 : H12AffineEnvironment.transform 17 2340 env41916 = env41917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env41916 == env41917) = true)

theorem identity41917 : scanCanonicalize (H12AffineFastState.compose env41917 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound41917 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env41918 : List Nat := [2,4,8,16,32,16,40,256,512,53,2048,4096,300,4405,1,294,4388,2340,53,0,4113,32,16,3,268,16,2080,4388,4096,2341,273,0,256,32,4405,512]

theorem envBound41918 : H12AffineFastState.Bounded env41918 := by
  intro p hp
  have h : env41918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41917_41918 : H12AffineEnvironment.transform 9 53 env41917 = env41918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env41917 == env41918) = true)

theorem identity41918 : scanCanonicalize (H12AffineFastState.compose env41918 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound41918 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env41919 : List Nat := [2,4,8,16,32,16,40,37,512,53,2048,4096,9,4112,1,3,4097,2049,53,0,4113,32,16,3,41,16,2080,4097,4096,2048,52,0,37,32,4112,512]

theorem envBound41919 : H12AffineFastState.Bounded env41919 := by
  intro p hp
  have h : env41919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41918_41919 : H12AffineEnvironment.transform 7 37 env41918 = env41919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env41918 == env41919) = true)

theorem identity41919 : scanCanonicalize (H12AffineFastState.compose env41919 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound41919 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41920 : List Nat := [2,4,8,16,32,16,40,37,30,53,2048,4096,9,4112,1,3,4097,2049,53,0,4113,32,16,3,41,16,2080,4097,4096,2048,52,0,37,32,4112,30]

theorem envBound41920 : H12AffineFastState.Bounded env41920 := by
  intro p hp
  have h : env41920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41919_41920 : H12AffineEnvironment.transform 8 30 env41919 = env41920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env41919 == env41920) = true)

def env41921 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,8580,65536,5393,262144,1024,8581,2097152,2373776,16,2175001,8328,17,10509,5393,2097168,270724,2102685,2373656,256,32,5377,2175514]

theorem envBound41921 : H12AffineFastState.Bounded env41921 := by
  intro p hp
  have h : env41921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41911_41921 : H12AffineEnvironment.transform 5 17 env41911 = env41921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41911 == env41921) = true)

theorem identity41921 : scanCanonicalize (H12AffineFastState.compose env41921 (packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound41921 : packedSelected [1,5,8,11,12,16,18,20,23,24,32,41] rootPS < 2^1333 := by decide +kernel

def env41922 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,0,65536,5393,262144,1024,1,2097152,2365716,16,2167197,268,17,2185,5393,2097168,262144,2102685,2365852,256,32,5377,2167710]

theorem envBound41922 : H12AffineFastState.Bounded env41922 := by
  intro p hp
  have h : env41922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41921_41922 : H12AffineEnvironment.transform 12 388 env41921 = env41922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env41921 == env41922) = true)

theorem identity41922 : scanCanonicalize (H12AffineFastState.compose env41922 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 268733) := by decide +kernel

theorem selectedBound41922 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env41923 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,0,65536,5393,262144,1024,1,268733,169,16,329760,268,17,2185,5393,268717,262144,265248,33,256,32,5377,330275]

theorem envBound41923 : H12AffineFastState.Bounded env41923 := by
  intro p hp
  have h : env41923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41922_41923 : H12AffineEnvironment.transform 20 268733 env41922 = env41923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268733 env41922 == env41923) = true)

theorem identity41923 : scanCanonicalize (H12AffineFastState.compose env41923 (packedSelected [0,2,3,4,5,6,7,10,11,12,16,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound41923 : packedSelected [0,2,3,4,5,6,7,10,11,12,16,20,22] rootPS < 2^1333 := by decide +kernel

def env41924 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5293,0,65536,5308,262144,1024,1,268304,169,16,329760,161,17,2185,5308,268288,262144,265248,33,173,32,5292,330275]

theorem envBound41924 : H12AffineFastState.Bounded env41924 := by
  intro p hp
  have h : env41924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41923_41924 : H12AffineEnvironment.transform 7 173 env41923 = env41924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env41923 == env41924) = true)

theorem identity41924 : scanCanonicalize (H12AffineFastState.compose env41924 (packedSelected [0,6,7,11,14,15,16] rootPS)) = affineNative (2^(17+1) ^^^ 67722) := by decide +kernel

theorem selectedBound41924 : packedSelected [0,6,7,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env41925 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5293,0,65536,5308,67722,1024,1,69786,169,16,170,161,17,2185,5308,69770,67722,66730,33,173,32,5292,681]

theorem envBound41925 : H12AffineFastState.Bounded env41925 := by
  intro p hp
  have h : env41925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41924_41925 : H12AffineEnvironment.transform 17 67722 env41924 = env41925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67722 env41924 == env41925) = true)

theorem identity41925 : scanCanonicalize (H12AffineFastState.compose env41925 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 3) := by decide +kernel

theorem selectedBound41925 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env41926 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5293,0,3,5308,2185,1024,1,4249,169,16,170,161,17,2185,5308,4233,2185,1193,33,173,32,5292,681]

theorem envBound41926 : H12AffineFastState.Bounded env41926 := by
  intro p hp
  have h : env41926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41925_41926 : H12AffineEnvironment.transform 15 3 env41925 = env41926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3 env41925 == env41926) = true)

theorem identity41926 : scanCanonicalize (H12AffineFastState.compose env41926 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41926 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env41927 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,3,5173,2048,1024,1,4112,32,16,35,40,17,2048,5173,4096,2048,1056,33,36,32,5157,544]

theorem envBound41927 : H12AffineFastState.Bounded env41927 := by
  intro p hp
  have h : env41927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41926_41927 : H12AffineEnvironment.transform 6 9 env41926 = env41927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41926 == env41927) = true)

theorem identity41927 : scanCanonicalize (H12AffineFastState.compose env41927 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41927 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env41928 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,4096,9,5124,0,3,5141,2048,1024,1,4112,0,16,3,8,17,2048,5141,4096,2048,1024,1,4,0,5125,512]

theorem envBound41928 : H12AffineFastState.Bounded env41928 := by
  intro p hp
  have h : env41928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41927_41928 : H12AffineEnvironment.transform 4 0 env41927 = env41928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41927 == env41928) = true)

theorem identity41928 : scanCanonicalize (H12AffineFastState.compose env41928 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound41928 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41929 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,3076,9,2048,0,3,2065,2048,1024,1,3092,0,16,3,8,17,2048,2065,3076,2048,1024,1,4,0,2049,512]

theorem envBound41929 : H12AffineFastState.Bounded env41929 := by
  intro p hp
  have h : env41929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41928_41929 : H12AffineEnvironment.transform 11 3076 env41928 = env41929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env41928 == env41929) = true)

theorem identity41929 : scanCanonicalize (H12AffineFastState.compose env41929 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound41929 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41930 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,2065,9,2048,0,3,2065,2048,21,1,2049,0,16,3,8,17,2048,2065,2065,2048,21,1,4,0,2049,512]

theorem envBound41930 : H12AffineFastState.Bounded env41930 := by
  intro p hp
  have h : env41930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41929_41930 : H12AffineEnvironment.transform 9 21 env41929 = env41930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env41929 == env41930) = true)

theorem identity41930 : scanCanonicalize (H12AffineFastState.compose env41930 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41931 : List Nat := [2,4,8,16,0,17,9,4,1,21,2048,2065,9,2048,0,3,2065,2048,21,1,2049,0,16,3,8,17,2048,2065,2065,2048,21,1,4,0,2049,1]

theorem envBound41931 : H12AffineFastState.Bounded env41931 := by
  intro p hp
  have h : env41931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41930_41931 : H12AffineEnvironment.transform 8 1 env41930 = env41931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41930 == env41931) = true)

theorem identity41931 : scanCanonicalize (H12AffineFastState.compose env41931 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound41931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41932 : List Nat := [2,4,8,5,0,4,9,4,1,0,2048,2052,9,2048,0,3,2052,2048,0,1,2049,0,5,3,8,4,2048,2052,2052,2048,0,1,4,0,2049,1]

theorem envBound41932 : H12AffineFastState.Bounded env41932 := by
  intro p hp
  have h : env41932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41931_41932 : H12AffineEnvironment.transform 3 5 env41931 = env41932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env41931 == env41932) = true)

def leafEnv41932 : List Nat := [2,4,8,5,0,4,9,4,1,0,2048,2052,9,2048,0,3,2052,2048,0,1,2049,0,5,3,0,8,1,4,2048,2052,2052,2048,0,1,4,0,4,2,2049,1,1,2048,0]

def active41932 : List Nat := [0,1,2,10]

def tree41932 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood41932 : H12WitnessSearch.Good tree41932 := H12GlobalWitnessIndex.good

theorem leafIdentity41932 : H12AffineFastState.composeSystem env41932 rootObs = leafEnv41932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env41932 rootObs == leafEnv41932) = true)

theorem terminalChecked41932 : H12PackedTerminal.terminalCheckFast leafEnv41932 active41932 tree41932 = true := by decide +kernel

def env41933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,262144,1024,8661,2097152,2373825,16,2175049,8328,64,146508,5393,2097216,406724,2102685,2373705,256,33,5457,2175563]

theorem envBound41933 : H12AffineFastState.Bounded env41933 := by
  intro p hp
  have h : env41933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41896_41933 : H12AffineEnvironment.transform 13 5377 env41896 = env41933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41896 == env41933) = true)

theorem identity41933 : scanCanonicalize (H12AffineFastState.compose env41933 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound41933 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env41934 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,131072,262144,1024,8540,2097152,2373704,16,2175049,8193,64,146508,5393,2097216,406605,2102548,2373705,256,33,5457,2175563]

theorem envBound41934 : H12AffineFastState.Bounded env41934 := by
  intro p hp
  have h : env41934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41933_41934 : H12AffineEnvironment.transform 6 9 env41933 = env41934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env41933 == env41934) = true)

def env41935 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5392,262144,1024,8540,2097152,2373704,16,2175049,8193,64,10588,5393,2097216,270685,2102548,2373705,256,33,5457,2175563]

theorem envBound41935 : H12AffineFastState.Bounded env41935 := by
  intro p hp
  have h : env41935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41934_41935 : H12AffineEnvironment.transform 16 5392 env41934 = env41935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env41934 == env41935) = true)

theorem identity41935 : scanCanonicalize (H12AffineFastState.compose env41935 (packedSelected [0,4,7,11,18,22,23,32] rootPS)) = affineNative (2^(20+1) ^^^ 4160) := by decide +kernel

theorem selectedBound41935 : packedSelected [0,4,7,11,18,22,23,32] rootPS < 2^1333 := by decide +kernel

def env41936 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5392,262144,1024,8540,4160,272392,16,73737,8193,64,10588,5393,4096,270685,1364,272393,256,33,5457,74251]

theorem envBound41936 : H12AffineFastState.Bounded env41936 := by
  intro p hp
  have h : env41936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41935_41936 : H12AffineEnvironment.transform 20 4160 env41935 = env41936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env41935 == env41936) = true)

theorem identity41936 : scanCanonicalize (H12AffineFastState.compose env41936 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound41936 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,2,5392,262144,1024,8540,4160,272392,16,8203,8193,64,10588,5393,4096,270685,1364,272393,256,33,5457,8713]

theorem envBound41937 : H12AffineFastState.Bounded env41937 := by
  intro p hp
  have h : env41937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41936_41937 : H12AffineEnvironment.transform 15 2 env41936 = env41937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env41936 == env41937) = true)

theorem identity41937 : scanCanonicalize (H12AffineFastState.compose env41937 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound41937 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,2,5392,2080,1024,8540,4160,8232,16,8203,8193,64,10588,5393,4096,10621,1364,8233,256,33,5457,8713]

theorem envBound41938 : H12AffineFastState.Bounded env41938 := by
  intro p hp
  have h : env41938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41937_41938 : H12AffineEnvironment.transform 17 2080 env41937 = env41938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env41937 == env41938) = true)

theorem identity41938 : scanCanonicalize (H12AffineFastState.compose env41938 (packedSelected [1,3,5,6,8,11,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound41938 : packedSelected [1,3,5,6,8,11,12,16] rootPS < 2^1333 := by decide +kernel

def env41939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5377,81,2,5392,2080,1024,80,4160,292,16,263,269,64,2128,5393,4096,2161,1364,293,256,33,5457,773]

theorem envBound41939 : H12AffineFastState.Bounded env41939 := by
  intro p hp
  have h : env41939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41938_41939 : H12AffineEnvironment.transform 12 268 env41938 = env41939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env41938 == env41939) = true)

theorem identity41939 : scanCanonicalize (H12AffineFastState.compose env41939 (packedSelected [0,4,5,6,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 831) := by decide +kernel

theorem selectedBound41939 : packedSelected [0,4,5,6,8,10,11] rootPS < 2^1333 := by decide +kernel

def env41940 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,831,268,1598,81,2,1583,2080,1024,80,895,292,16,263,269,64,2128,1582,831,2161,1364,293,256,33,1646,773]

theorem envBound41940 : H12AffineFastState.Bounded env41940 := by
  intro p hp
  have h : env41940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41939_41940 : H12AffineEnvironment.transform 11 831 env41939 = env41940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 831 env41939 == env41940) = true)

theorem identity41940 : scanCanonicalize (H12AffineFastState.compose env41940 (packedSelected [1,2,4,5,6,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound41940 : packedSelected [1,2,4,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env41941 : List Nat := [2,4,8,16,32,64,9,5,512,1024,2048,570,9,1598,81,2,1583,2080,1024,80,634,33,16,2,8,64,2128,1582,570,2161,1105,32,5,33,1646,512]

theorem envBound41941 : H12AffineFastState.Bounded env41941 := by
  intro p hp
  have h : env41941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41940_41941 : H12AffineEnvironment.transform 7 5 env41940 = env41941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env41940 == env41941) = true)

theorem identity41941 : scanCanonicalize (H12AffineFastState.compose env41941 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 1614) := by decide +kernel

theorem selectedBound41941 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env41942 : List Nat := [2,4,8,16,32,64,9,5,512,1024,1614,570,9,1598,81,2,1583,1646,1024,80,634,33,16,2,8,64,1566,1582,570,1599,1105,32,5,33,1646,512]

theorem envBound41942 : H12AffineFastState.Bounded env41942 := by
  intro p hp
  have h : env41942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41941_41942 : H12AffineEnvironment.transform 10 1614 env41941 = env41942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1614 env41941 == env41942) = true)

theorem identity41942 : scanCanonicalize (H12AffineFastState.compose env41942 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound41942 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env41943 : List Nat := [2,4,8,16,32,64,9,5,512,20,602,570,9,554,81,2,571,634,20,80,634,33,16,2,8,64,522,570,570,555,69,32,5,33,634,512]

theorem envBound41943 : H12AffineFastState.Bounded env41943 := by
  intro p hp
  have h : env41943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41942_41943 : H12AffineEnvironment.transform 9 20 env41942 = env41943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env41942 == env41943) = true)

theorem identity41943 : scanCanonicalize (H12AffineFastState.compose env41943 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 123) := by decide +kernel

theorem selectedBound41943 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41944 : List Nat := [2,4,8,16,32,64,9,5,123,20,33,65,9,81,81,2,64,1,20,80,1,33,16,2,8,64,113,65,65,80,69,32,5,33,1,123]

theorem envBound41944 : H12AffineFastState.Bounded env41944 := by
  intro p hp
  have h : env41944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41943_41944 : H12AffineEnvironment.transform 8 123 env41943 = env41944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 123 env41943 == env41944) = true)

theorem identity41944 : scanCanonicalize (H12AffineFastState.compose env41944 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound41944 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env41945 : List Nat := [2,4,8,16,32,48,9,5,11,20,33,49,9,33,33,2,48,1,20,32,1,33,16,2,8,48,1,49,49,32,53,32,5,33,1,11]

theorem envBound41945 : H12AffineFastState.Bounded env41945 := by
  intro p hp
  have h : env41945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41944_41945 : H12AffineEnvironment.transform 5 48 env41944 = env41945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env41944 == env41945) = true)

theorem identity41945 : scanCanonicalize (H12AffineFastState.compose env41945 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound41945 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env41946 : List Nat := [2,4,8,14,32,46,9,5,11,10,33,47,9,33,33,2,46,1,10,32,1,33,14,2,8,46,1,47,47,32,43,32,5,33,1,11]

theorem envBound41946 : H12AffineFastState.Bounded env41946 := by
  intro p hp
  have h : env41946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41945_41946 : H12AffineEnvironment.transform 3 14 env41945 = env41946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env41945 == env41946) = true)

theorem identity41946 : scanCanonicalize (H12AffineFastState.compose env41946 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound41946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41947 : List Nat := [1,4,8,13,32,45,9,5,8,9,33,44,9,33,33,1,45,1,9,32,1,33,13,1,8,45,1,44,44,32,40,32,5,33,1,8]

theorem envBound41947 : H12AffineFastState.Bounded env41947 := by
  intro p hp
  have h : env41947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41946_41947 : H12AffineEnvironment.transform 0 1 env41946 = env41947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env41946 == env41947) = true)

def env41948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5393,262144,1024,8540,2097152,2373704,16,2175049,8193,64,10589,5393,2097216,270684,2102548,2373705,256,33,5457,2175563]

theorem envBound41948 : H12AffineFastState.Bounded env41948 := by
  intro p hp
  have h : env41948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41934_41948 : H12AffineEnvironment.transform 16 5393 env41934 = env41948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env41934 == env41948) = true)

theorem identity41948 : scanCanonicalize (H12AffineFastState.compose env41948 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound41948 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env41949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5393,262144,1024,8540,77898,329730,16,3,8193,64,10589,5393,77834,270684,75102,329731,256,33,5457,513]

theorem envBound41949 : H12AffineFastState.Bounded env41949 := by
  intro p hp
  have h : env41949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41948_41949 : H12AffineEnvironment.transform 20 77898 env41948 = env41949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env41948 == env41949) = true)

theorem identity41949 : scanCanonicalize (H12AffineFastState.compose env41949 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 67618) := by decide +kernel

theorem selectedBound41949 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env41950 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5393,67618,1024,8540,77898,32,16,3,8193,64,10589,5393,77834,76158,75102,33,256,33,5457,513]

theorem envBound41950 : H12AffineFastState.Bounded env41950 := by
  intro p hp
  have h : env41950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41949_41950 : H12AffineEnvironment.transform 17 67618 env41949 = env41950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67618 env41949 == env41950) = true)

theorem identity41950 : scanCanonicalize (H12AffineFastState.compose env41950 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound41950 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env41951 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8192,5205,8201,65536,5189,67618,1024,8200,77898,32,16,3,8193,64,10249,5189,77834,75818,74762,33,84,33,5125,513]

theorem envBound41951 : H12AffineFastState.Bounded env41951 := by
  intro p hp
  have h : env41951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41950_41951 : H12AffineEnvironment.transform 7 84 env41950 = env41951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env41950 == env41951) = true)

theorem identity41951 : scanCanonicalize (H12AffineFastState.compose env41951 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound41951 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env41952 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8192,5205,8201,8202,5189,10280,1024,8200,4160,32,16,3,8193,64,10249,5189,4096,2080,1024,33,84,33,5125,513]

theorem envBound41952 : H12AffineFastState.Bounded env41952 := by
  intro p hp
  have h : env41952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41951_41952 : H12AffineEnvironment.transform 15 8202 env41951 = env41952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env41951 == env41952) = true)

theorem identity41952 : scanCanonicalize (H12AffineFastState.compose env41952 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound41952 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41953 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8192,5125,8201,8202,5141,10280,1024,8200,4112,32,16,3,8193,16,10249,5141,4096,2080,1024,33,4,33,5125,513]

theorem envBound41953 : H12AffineFastState.Bounded env41953 := by
  intro p hp
  have h : env41953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41952_41953 : H12AffineEnvironment.transform 5 16 env41952 = env41953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41952 == env41953) = true)

theorem identity41953 : scanCanonicalize (H12AffineFastState.compose env41953 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41953 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41954 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,40,5125,33,34,5141,2048,1024,32,4112,32,16,3,41,16,2081,5141,4096,2080,1024,33,4,33,5125,513]

theorem envBound41954 : H12AffineFastState.Bounded env41954 := by
  intro p hp
  have h : env41954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41953_41954 : H12AffineEnvironment.transform 12 40 env41953 = env41954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41953 == env41954) = true)

theorem identity41954 : scanCanonicalize (H12AffineFastState.compose env41954 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound41954 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env41955 : List Nat := [2,4,8,16,32,16,9,4,512,1024,32,4096,40,5125,33,34,5141,32,1024,32,4112,32,16,3,41,16,1,5141,4096,0,1024,33,4,33,5125,513]

theorem envBound41955 : H12AffineFastState.Bounded env41955 := by
  intro p hp
  have h : env41955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41954_41955 : H12AffineEnvironment.transform 10 32 env41954 = env41955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env41954 == env41955) = true)

theorem identity41955 : scanCanonicalize (H12AffineFastState.compose env41955 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound41955 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env41956 : List Nat := [2,4,8,16,32,16,9,4,1,1024,32,4096,40,5125,33,34,5141,32,1024,32,4112,32,16,3,41,16,1,5141,4096,0,1024,33,4,33,5125,0]

theorem envBound41956 : H12AffineFastState.Bounded env41956 := by
  intro p hp
  have h : env41956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41955_41956 : H12AffineEnvironment.transform 8 1 env41955 = env41956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env41955 == env41956) = true)

theorem identity41956 : scanCanonicalize (H12AffineFastState.compose env41956 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound41956 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env41957 : List Nat := [2,4,8,16,1,16,9,4,1,1024,1,4096,9,5125,0,3,5141,1,1024,1,4112,1,16,3,8,16,1,5141,4096,0,1024,0,4,0,5125,0]

theorem envBound41957 : H12AffineFastState.Bounded env41957 := by
  intro p hp
  have h : env41957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41956_41957 : H12AffineEnvironment.transform 4 1 env41956 = env41957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env41956 == env41957) = true)

theorem identity41957 : scanCanonicalize (H12AffineFastState.compose env41957 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound41957 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env41958 : List Nat := [2,4,8,16,1,16,9,4,1,1024,1,1029,9,0,0,3,16,1,1024,1,1045,1,16,3,8,16,1,16,1029,0,1024,0,4,0,0,0]

theorem envBound41958 : H12AffineFastState.Bounded env41958 := by
  intro p hp
  have h : env41958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41957_41958 : H12AffineEnvironment.transform 11 1029 env41957 = env41958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env41957 == env41958) = true)

def env41959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound41959 : H12AffineFastState.Bounded env41959 := by
  intro p hp
  have h : env41959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41715_41959 : H12AffineEnvironment.transform 18 1025 env41715 = env41959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env41715 == env41959) = true)

theorem identity41959 : scanCanonicalize (H12AffineFastState.compose env41959 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2262472) := by decide +kernel

theorem selectedBound41959 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env41960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262472,16777216,8328,64,23414216,18973837,184473,2377160,19071448,23160256,257,16990564,17014976,19015183]

theorem envBound41960 : H12AffineFastState.Bounded env41960 := by
  intro p hp
  have h : env41960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41959_41960 : H12AffineEnvironment.transform 22 2262472 env41959 = env41960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2262472 env41959 == env41960) = true)

def env41961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262472,201796,8328,64,6705548,2265289,184473,2377160,2102684,6451588,257,21792,46212,2175563]

theorem envBound41961 : H12AffineFastState.Bounded env41961 := by
  intro p hp
  have h : env41961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41960_41961 : H12AffineEnvironment.transform 23 201796 env41960 = env41961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201796 env41960 == env41961) = true)

def env41962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603796,2098513,17665,2377160,2102684,6349852,257,21792,46212,2175563]

theorem envBound41962 : H12AffineFastState.Bounded env41962 := by
  intro p hp
  have h : env41962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41961_41962 : H12AffineEnvironment.transform 16 38296 env41961 = env41962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env41961 == env41962) = true)

def env41963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157716,2098513,17665,2377160,2102684,2411676,257,21792,46212,2175563]

theorem envBound41963 : H12AffineFastState.Bounded env41963 := by
  intro p hp
  have h : env41963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41962_41963 : H12AffineEnvironment.transform 21 272512 env41962 = env41963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env41962 == env41963) = true)

theorem identity41963 : scanCanonicalize (H12AffineFastState.compose env41963 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound41963 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env41964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38296,262144,1025,32769,2097152,272512,2101328,21762,8328,64,2157716,2098513,17665,2377160,2102684,2411676,257,21792,46212,2156181]

theorem envBound41964 : H12AffineFastState.Bounded env41964 := by
  intro p hp
  have h : env41964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41963_41964 : H12AffineEnvironment.transform 15 54494 env41963 = env41964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env41963 == env41964) = true)

def env41965 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,262144,1025,32769,2097152,272512,2101248,21762,8328,16,2157716,2098433,17665,2377112,2102684,2411676,257,21792,46212,2156181]

theorem envBound41965 : H12AffineFastState.Bounded env41965 := by
  intro p hp
  have h : env41965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41964_41965 : H12AffineEnvironment.transform 5 16 env41964 = env41965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env41964 == env41965) = true)

theorem identity41965 : scanCanonicalize (H12AffineFastState.compose env41965 (packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound41965 : packedSelected [1,3,4,7,9,10,11,12,15,17,19,24,26,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env41966 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,262144,1025,32769,58396,272512,62492,21762,8328,16,2184,57629,17665,303492,61824,272512,257,21792,46212,649]

theorem envBound41966 : H12AffineFastState.Bounded env41966 := by
  intro p hp
  have h : env41966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41965_41966 : H12AffineEnvironment.transform 20 58396 env41965 = env41966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env41965 == env41966) = true)

theorem identity41966 : scanCanonicalize (H12AffineFastState.compose env41966 (packedSelected [1,3,5,12,15,17,26,28] rootPS)) = affineNative (2^(17+1) ^^^ 32161) := by decide +kernel

theorem selectedBound41966 : packedSelected [1,3,5,12,15,17,26,28] rootPS < 2^1333 := by decide +kernel

def env41967 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54414,38296,32161,1025,32769,58396,21793,62492,21762,8328,16,2184,57629,17665,56357,61824,21793,257,21792,46212,649]

theorem envBound41967 : H12AffineFastState.Bounded env41967 := by
  intro p hp
  have h : env41967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41966_41967 : H12AffineEnvironment.transform 17 32161 env41966 = env41967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env41966 == env41967) = true)

theorem identity41967 : scanCanonicalize (H12AffineFastState.compose env41967 (packedSelected [0,2,6,7,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound41967 : packedSelected [0,2,6,7,16,18,23] rootPS < 2^1333 := by decide +kernel

def env41968 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,262,16400,32161,1025,21897,12692,21793,8596,21762,8328,16,2184,13461,17665,2477,9224,21793,257,21792,24844,649]

theorem envBound41968 : H12AffineFastState.Bounded env41968 := by
  intro p hp
  have h : env41968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41967_41968 : H12AffineEnvironment.transform 14 21896 env41967 = env41968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env41967 == env41968) = true)

theorem identity41968 : scanCanonicalize (H12AffineFastState.compose env41968 (packedSelected [0,2,6,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound41968 : packedSelected [0,2,6,7,16,17] rootPS < 2^1333 := by decide +kernel

def env41969 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,137,262,5393,10400,1025,136,12692,32,8596,3,8328,16,2184,13461,4096,2477,9224,32,257,33,13325,649]

theorem envBound41969 : H12AffineFastState.Bounded env41969 := by
  intro p hp
  have h : env41969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41968_41969 : H12AffineEnvironment.transform 13 5377 env41968 = env41969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env41968 == env41969) = true)

theorem identity41969 : scanCanonicalize (H12AffineFastState.compose env41969 (packedSelected [3,4,5,6,9,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 5148) := by decide +kernel

theorem selectedBound41969 : packedSelected [3,4,5,6,9,11,12] rootPS < 2^1333 := by decide +kernel

def env41970 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,5148,5377,137,262,5393,7356,1025,136,1416,32,5512,3,5268,16,2184,137,4096,2477,4116,32,257,33,17,649]

theorem envBound41970 : H12AffineFastState.Bounded env41970 := by
  intro p hp
  have h : env41970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41969_41970 : H12AffineEnvironment.transform 12 5148 env41969 = env41970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5148 env41969 == env41970) = true)

theorem identity41970 : scanCanonicalize (H12AffineFastState.compose env41970 (packedSelected [0,2,4,7,9,10,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 1432) := by decide +kernel

theorem selectedBound41970 : packedSelected [0,2,4,7,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env41971 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1432,388,153,137,262,137,2340,1025,136,1416,32,16,3,268,16,2184,137,1432,2477,1420,32,257,33,17,649]

theorem envBound41971 : H12AffineFastState.Bounded env41971 := by
  intro p hp
  have h : env41971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41970_41971 : H12AffineEnvironment.transform 11 1432 env41970 = env41971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env41970 == env41971) = true)

theorem identity41971 : scanCanonicalize (H12AffineFastState.compose env41971 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1588) := by decide +kernel

theorem selectedBound41971 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env41972 : List Nat := [2,4,8,16,32,16,128,256,512,1024,1588,1432,388,153,137,262,137,1808,1025,136,1416,32,16,3,268,16,1724,137,1432,1945,1420,32,257,33,17,649]

theorem envBound41972 : H12AffineFastState.Bounded env41972 := by
  intro p hp
  have h : env41972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41971_41972 : H12AffineEnvironment.transform 10 1588 env41971 = env41972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1588 env41971 == env41972) = true)

theorem identity41972 : scanCanonicalize (H12AffineFastState.compose env41972 (packedSelected [0,2,5,6,7,8] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound41972 : packedSelected [0,2,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env41973 : List Nat := [2,4,8,16,32,16,128,256,293,1024,1297,1432,388,153,137,262,137,1077,1025,136,1416,32,16,3,268,16,1433,137,1432,1212,1420,32,257,33,17,428]

theorem envBound41973 : H12AffineFastState.Bounded env41973 := by
  intro p hp
  have h : env41973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41972_41973 : H12AffineEnvironment.transform 8 293 env41972 = env41973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env41972 == env41973) = true)

theorem identity41973 : scanCanonicalize (H12AffineFastState.compose env41973 (packedSelected [0,1,2,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 188) := by decide +kernel

theorem selectedBound41973 : packedSelected [0,1,2,5,6,7] rootPS < 2^1333 := by decide +kernel

def env41974 : List Nat := [2,4,8,16,32,16,128,188,153,1024,1197,1060,56,153,137,186,137,1077,1025,136,1076,32,16,3,176,16,1061,137,1060,1212,1072,32,189,33,17,16]

theorem envBound41974 : H12AffineFastState.Bounded env41974 := by
  intro p hp
  have h : env41974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41973_41974 : H12AffineEnvironment.transform 7 188 env41973 = env41974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 188 env41973 == env41974) = true)

theorem identity41974 : scanCanonicalize (H12AffineFastState.compose env41974 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound41974 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env41975 : List Nat := [2,4,8,16,32,16,24,36,1,1024,1077,1060,56,1,17,34,17,1077,1025,16,1076,32,16,3,40,16,1061,17,1060,1060,1072,32,37,33,17,16]

theorem envBound41975 : H12AffineFastState.Bounded env41975 := by
  intro p hp
  have h : env41975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41974_41975 : H12AffineEnvironment.transform 6 24 env41974 = env41975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env41974 == env41975) = true)

def env41976 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,262144,1025,32769,2097152,272512,2101249,21762,8328,17,2157716,2098432,17665,2377113,2102684,2411676,257,21792,46212,2156181]

theorem envBound41976 : H12AffineFastState.Bounded env41976 := by
  intro p hp
  have h : env41976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41964_41976 : H12AffineEnvironment.transform 5 17 env41964 = env41976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env41964 == env41976) = true)

def env41977 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23808,1025,32769,2097152,30080,2101249,21762,8328,17,2157716,2098432,17665,2103449,2102684,2134428,257,21792,46212,2156181]

theorem envBound41977 : H12AffineFastState.Bounded env41977 := by
  intro p hp
  have h : env41977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41976_41977 : H12AffineEnvironment.transform 17 23808 env41976 = env41977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env41976 == env41977) = true)

theorem identity41977 : scanCanonicalize (H12AffineFastState.compose env41977 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 12345) := by decide +kernel

theorem selectedBound41977 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env41978 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23808,1025,32769,12345,30080,8248,21762,8328,17,56493,13625,17665,10400,9637,41381,257,21792,46212,54956]

theorem envBound41978 : H12AffineFastState.Bounded env41978 := by
  intro p hp
  have h : env41978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41977_41978 : H12AffineEnvironment.transform 20 12345 env41977 = env41978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12345 env41977 == env41978) = true)

theorem identity41978 : scanCanonicalize (H12AffineFastState.compose env41978 (packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 21676) := by decide +kernel

theorem selectedBound41978 : packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env41979 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21676,35,16692,23808,1025,21677,12345,30080,8248,21762,8328,17,2049,13625,17665,10400,9637,29961,257,21792,24616,512]

theorem envBound41979 : H12AffineFastState.Bounded env41979 := by
  intro p hp
  have h : env41979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41978_41979 : H12AffineEnvironment.transform 14 21676 env41978 = env41979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21676 env41978 == env41979) = true)

theorem identity41979 : scanCanonicalize (H12AffineFastState.compose env41979 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound41979 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,17,18,19] rootPS < 2^1333 := by decide +kernel

def env41980 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,16384,21676,35,16692,23808,1025,21677,4540,21509,445,21762,269,17,2049,5308,17665,2341,1056,21644,257,21792,16813,512]

theorem envBound41980 : H12AffineFastState.Bounded env41980 := by
  intro p hp
  have h : env41980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41979_41980 : H12AffineEnvironment.transform 12 389 env41979 = env41980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env41979 == env41980) = true)

theorem identity41980 : scanCanonicalize (H12AffineFastState.compose env41980 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound41980 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41981 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,16384,21676,35,16536,23724,1025,21677,4112,21509,17,21678,161,17,2049,5308,17581,2185,1056,21644,173,21644,16385,512]

theorem envBound41981 : H12AffineFastState.Bounded env41981 := by
  intro p hp
  have h : env41981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41980_41981 : H12AffineEnvironment.transform 7 172 env41980 = env41981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env41980 == env41981) = true)

theorem identity41981 : scanCanonicalize (H12AffineFastState.compose env41981 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5260) := by decide +kernel

theorem selectedBound41981 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env41982 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,41,5260,32,35,5140,2080,1025,33,4112,137,17,34,161,17,2049,5308,4129,2185,1056,0,173,0,5261,512]

theorem envBound41982 : H12AffineFastState.Bounded env41982 := by
  intro p hp
  have h : env41982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41981_41982 : H12AffineEnvironment.transform 13 5260 env41981 = env41982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5260 env41981 == env41982) = true)

theorem identity41982 : scanCanonicalize (H12AffineFastState.compose env41982 (packedSelected [3,4,5,6,7,12] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound41982 : packedSelected [3,4,5,6,7,12] rootPS < 2^1333 := by decide +kernel

def env41983 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1044,4096,41,5260,32,35,5140,1076,1025,33,4112,137,17,34,161,17,1045,5308,4129,1181,1056,0,173,0,5261,512]

theorem envBound41983 : H12AffineFastState.Bounded env41983 := by
  intro p hp
  have h : env41983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41982_41983 : H12AffineEnvironment.transform 10 1044 env41982 = env41983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env41982 == env41983) = true)

theorem identity41983 : scanCanonicalize (H12AffineFastState.compose env41983 (packedSelected [10] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound41983 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env41984 : List Nat := [2,4,8,16,32,17,128,172,512,188,168,4096,41,4144,32,35,4264,136,189,33,4112,137,17,34,161,17,169,4096,4129,33,156,0,173,0,4145,512]

theorem envBound41984 : H12AffineFastState.Bounded env41984 := by
  intro p hp
  have h : env41984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41983_41984 : H12AffineEnvironment.transform 9 188 env41983 = env41984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env41983 == env41984) = true)

theorem identity41984 : scanCanonicalize (H12AffineFastState.compose env41984 (packedSelected [3,5] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound41984 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env41985 : List Nat := [2,4,8,16,32,17,41,5,512,21,1,4096,41,4144,32,35,4097,33,20,33,4112,32,17,34,8,17,0,4096,4129,33,53,0,4,0,4145,512]

theorem envBound41985 : H12AffineFastState.Bounded env41985 := by
  intro p hp
  have h : env41985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41984_41985 : H12AffineEnvironment.transform 6 41 env41984 = env41985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env41984 == env41985) = true)

theorem identity41985 : scanCanonicalize (H12AffineFastState.compose env41985 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound41985 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env41986 : List Nat := [2,4,8,16,0,17,9,5,512,21,1,4096,9,4112,0,3,4097,1,20,1,4112,0,17,2,8,17,0,4096,4097,1,21,0,4,0,4113,512]

theorem envBound41986 : H12AffineFastState.Bounded env41986 := by
  intro p hp
  have h : env41986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41985_41986 : H12AffineEnvironment.transform 4 0 env41985 = env41986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env41985 == env41986) = true)

theorem identity41986 : scanCanonicalize (H12AffineFastState.compose env41986 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 526) := by decide +kernel

theorem selectedBound41986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env41987 : List Nat := [2,4,8,16,0,17,9,5,512,21,1,526,9,542,0,3,527,1,20,1,542,0,17,2,8,17,0,526,527,1,21,0,4,0,543,512]

theorem envBound41987 : H12AffineFastState.Bounded env41987 := by
  intro p hp
  have h : env41987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41986_41987 : H12AffineEnvironment.transform 11 526 env41986 = env41987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 526 env41986 == env41987) = true)

theorem identity41987 : scanCanonicalize (H12AffineFastState.compose env41987 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound41987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env41988 : List Nat := [2,4,8,16,0,17,9,5,31,21,1,17,9,1,0,3,16,1,20,1,1,0,17,2,8,17,0,17,16,1,21,0,4,0,0,31]

theorem envBound41988 : H12AffineFastState.Bounded env41988 := by
  intro p hp
  have h : env41988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41987_41988 : H12AffineEnvironment.transform 8 31 env41987 = env41988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env41987 == env41988) = true)

def env41989 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23809,1025,32769,2097152,30081,2101249,21762,8328,17,2157716,2098432,17665,2103448,2102684,2134429,257,21792,46212,2156181]

theorem envBound41989 : H12AffineFastState.Bounded env41989 := by
  intro p hp
  have h : env41989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41976_41989 : H12AffineEnvironment.transform 17 23809 env41976 = env41989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env41976 == env41989) = true)

theorem identity41989 : scanCanonicalize (H12AffineFastState.compose env41989 (packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS)) = affineNative (2^(20+1) ^^^ 12464) := by decide +kernel

theorem selectedBound41989 : packedSelected [0,3,5,7,9,12,14,15,16,17,19,22,26,31] rootPS < 2^1333 := by decide +kernel

def env41990 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54415,38296,23809,1025,32769,12464,30081,8369,21762,8328,17,56356,13744,17665,10280,9516,41261,257,21792,46212,54821]

theorem envBound41990 : H12AffineFastState.Bounded env41990 := by
  intro p hp
  have h : env41990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41989_41990 : H12AffineEnvironment.transform 20 12464 env41989 = env41990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12464 env41989 == env41990) = true)

theorem identity41990 : scanCanonicalize (H12AffineFastState.compose env41990 (packedSelected [1,2,3,4,5,6,8,10,11,16,18,22,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound41990 : packedSelected [1,2,3,4,5,6,8,10,11,16,18,22,26] rootPS < 2^1333 := by decide +kernel

def env41991 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13325,32768,41090,38296,10508,1025,32769,12464,396,8369,8463,8328,17,43049,13744,12556,10280,9516,41261,257,8493,46212,41512]

theorem envBound41991 : H12AffineFastState.Bounded env41991 := by
  intro p hp
  have h : env41991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41990_41991 : H12AffineEnvironment.transform 13 13325 env41990 = env41991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env41990 == env41991) = true)

theorem identity41991 : scanCanonicalize (H12AffineFastState.compose env41991 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound41991 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env41992 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,40,5157,32768,32938,38296,2340,1025,32769,4248,396,153,295,160,17,34817,5528,4388,2048,1284,33029,257,261,38060,33280]

theorem envBound41992 : H12AffineFastState.Bounded env41992 := by
  intro p hp
  have h : env41992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41991_41992 : H12AffineEnvironment.transform 12 40 env41991 = env41992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env41991 == env41992) = true)

theorem identity41992 : scanCanonicalize (H12AffineFastState.compose env41992 (packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound41992 : packedSelected [0,2,4,6,7,9,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env41993 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,40,5157,292,398,5308,2340,1025,293,4248,396,153,295,160,17,2341,5528,4388,2048,1284,33,257,261,5512,804]

theorem envBound41993 : H12AffineFastState.Bounded env41993 := by
  intro p hp
  have h : env41993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41992_41993 : H12AffineEnvironment.transform 14 292 env41992 = env41993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env41992 == env41993) = true)

theorem identity41993 : scanCanonicalize (H12AffineFastState.compose env41993 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound41993 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env41994 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,40,5157,292,262,5172,2340,1025,293,4112,260,17,295,40,17,2341,5392,4388,2048,1284,33,257,261,5376,804]

theorem envBound41994 : H12AffineFastState.Bounded env41994 := by
  intro p hp
  have h : env41994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41993_41994 : H12AffineEnvironment.transform 6 8 env41993 = env41994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env41993 == env41994) = true)

theorem identity41994 : scanCanonicalize (H12AffineFastState.compose env41994 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound41994 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env41995 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,4096,40,5157,292,262,5172,292,1025,293,4112,260,17,295,40,17,293,5392,4388,0,1284,33,257,261,5376,804]

theorem envBound41995 : H12AffineFastState.Bounded env41995 := by
  intro p hp
  have h : env41995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41994_41995 : H12AffineEnvironment.transform 10 0 env41994 = env41995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env41994 == env41995) = true)

theorem identity41995 : scanCanonicalize (H12AffineFastState.compose env41995 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound41995 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env41996 : List Nat := [2,4,8,16,32,17,8,256,512,21,0,4096,40,4144,292,262,4129,292,20,293,4112,260,17,295,40,17,293,4357,4388,0,273,33,257,261,4373,804]

theorem envBound41996 : H12AffineFastState.Bounded env41996 := by
  intro p hp
  have h : env41996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41995_41996 : H12AffineEnvironment.transform 9 21 env41995 = env41996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env41995 == env41996) = true)

theorem identity41996 : scanCanonicalize (H12AffineFastState.compose env41996 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound41996 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env41997 : List Nat := [2,4,8,16,32,17,8,256,512,21,0,48,40,0,292,262,17,292,20,293,32,260,17,295,40,17,293,309,276,0,273,33,257,261,293,804]

theorem envBound41997 : H12AffineFastState.Bounded env41997 := by
  intro p hp
  have h : env41997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41996_41997 : H12AffineEnvironment.transform 11 48 env41996 = env41997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env41996 == env41997) = true)

theorem identity41997 : scanCanonicalize (H12AffineFastState.compose env41997 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound41997 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env41998 : List Nat := [2,4,8,16,32,17,8,256,16,21,0,48,40,0,292,262,17,292,20,293,32,260,17,295,40,17,293,309,276,0,273,33,257,261,293,308]

theorem envBound41998 : H12AffineFastState.Bounded env41998 := by
  intro p hp
  have h : env41998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41997_41998 : H12AffineEnvironment.transform 8 16 env41997 = env41998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env41997 == env41998) = true)

def env41999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157717,2098513,17665,2377160,2102684,2411677,257,21792,46212,2175563]

theorem envBound41999 : H12AffineFastState.Bounded env41999 := by
  intro p hp
  have h : env41999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41962_41999 : H12AffineEnvironment.transform 21 272513 env41962 = env41999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env41962 == env41999) = true)

theorem identity41999 : scanCanonicalize (H12AffineFastState.compose env41999 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 115871) := by decide +kernel

theorem selectedBound41999 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,115871,272513,120015,98780,8328,64,75786,115150,17665,360791,119043,329730,257,21792,46212,63188]

theorem envBound42000 : H12AffineFastState.Bounded env42000 := by
  intro p hp
  have h : env42000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41999_42000 : H12AffineEnvironment.transform 20 115871 env41999 = env42000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115871 env41999 == env42000) = true)

def env42001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,10400,1025,32769,115871,33,120015,98780,8328,64,75786,115150,17665,109047,119043,73890,257,21792,46212,63188]

theorem envBound42001 : H12AffineFastState.Bounded env42001 := by
  intro p hp
  have h : env42001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42000_42001 : H12AffineEnvironment.transform 17 10400 env42000 = env42001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env42000 == env42001) = true)

theorem identity42001 : scanCanonicalize (H12AffineFastState.compose env42001 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound42001 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env42002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,342,38296,10400,1025,32769,50633,33,54681,32906,8328,64,10588,49304,17665,43169,53333,8692,257,21792,46212,63188]

theorem envBound42002 : H12AffineFastState.Bounded env42002 := by
  intro p hp
  have h : env42002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42001_42002 : H12AffineEnvironment.transform 15 342 env42001 = env42002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env42001 == env42002) = true)

theorem identity42002 : scanCanonicalize (H12AffineFastState.compose env42002 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42002 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env42003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,38296,2557,1025,32769,50633,33,54681,32906,469,64,2049,49304,17665,35324,53333,169,257,21792,38361,55177]

theorem envBound42003 : H12AffineFastState.Bounded env42003 := by
  intro p hp
  have h : env42003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42002_42003 : H12AffineEnvironment.transform 12 349 env42002 = env42003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42002 == env42003) = true)

theorem identity42003 : scanCanonicalize (H12AffineFastState.compose env42003 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42003 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env42004 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,1,342,5529,2557,1025,0,17864,33,21912,139,469,64,2049,16537,17665,2557,20564,169,257,21792,5592,22408]

theorem envBound42004 : H12AffineFastState.Bounded env42004 := by
  intro p hp
  have h : env42004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42003_42004 : H12AffineEnvironment.transform 14 1 env42003 = env42004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42003 == env42004) = true)

theorem identity42004 : scanCanonicalize (H12AffineFastState.compose env42004 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound42004 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env42005 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5236,1,342,5529,2557,1025,0,4540,33,492,139,469,64,2049,5357,4469,2557,1056,169,257,340,5592,1020]

theorem envBound42005 : H12AffineFastState.Bounded env42005 := by
  intro p hp
  have h : env42005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42004_42005 : H12AffineEnvironment.transform 13 5236 env42004 = env42005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env42004 == env42005) = true)

theorem identity42005 : scanCanonicalize (H12AffineFastState.compose env42005 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound42005 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42006 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,4096,121,5236,1,114,5309,2265,1025,0,4248,33,200,139,241,64,2049,5357,4177,2265,1056,169,37,112,5372,728]

theorem envBound42006 : H12AffineFastState.Bounded env42006 := by
  intro p hp
  have h : env42006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42005_42006 : H12AffineEnvironment.transform 7 36 env42005 = env42006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env42005 == env42006) = true)

theorem identity42006 : scanCanonicalize (H12AffineFastState.compose env42006 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2249) := by decide +kernel

theorem selectedBound42006 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env42007 : List Nat := [2,4,8,16,32,64,128,36,512,1024,2048,2249,121,3261,1,114,3188,2265,1025,0,2129,33,200,139,241,64,2049,3108,2200,2265,1056,169,37,112,3125,728]

theorem envBound42007 : H12AffineFastState.Bounded env42007 := by
  intro p hp
  have h : env42007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42006_42007 : H12AffineEnvironment.transform 11 2249 env42006 = env42007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2249 env42006 == env42007) = true)

def env42008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,10401,1025,32769,115871,32,120015,98780,8328,64,75786,115150,17665,109046,119043,73891,257,21792,46212,63188]

theorem envBound42008 : H12AffineFastState.Bounded env42008 := by
  intro p hp
  have h : env42008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42000_42008 : H12AffineEnvironment.transform 17 10401 env42000 = env42008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env42000 == env42008) = true)

theorem identity42008 : scanCanonicalize (H12AffineFastState.compose env42008 (packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 62711) := by decide +kernel

theorem selectedBound42008 : packedSelected [0,1,2,3,4,6,7,8,9,10,12,16,19,20,23,24,26,32,35,38] rootPS < 2^1333 := by decide +kernel

def env42009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62711,38296,10401,1025,32769,12392,32,8248,29995,8328,64,56573,13625,17665,23809,9716,54356,257,21792,46212,63188]

theorem envBound42009 : H12AffineFastState.Bounded env42009 := by
  intro p hp
  have h : env42009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42008_42009 : H12AffineEnvironment.transform 15 62711 env42008 = env42009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62711 env42008 == env42009) = true)

theorem identity42009 : scanCanonicalize (H12AffineFastState.compose env42009 (packedSelected [1,4,9,14,16,19,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound42009 : packedSelected [1,4,9,14,16,19,28,31] rootPS < 2^1333 := by decide +kernel

def env42010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,34,24909,10401,1025,29908,12392,32,8248,29995,8328,64,10280,13625,17665,23809,9716,8321,257,21792,16465,513]

theorem envBound42010 : H12AffineFastState.Bounded env42010 := by
  intro p hp
  have h : env42010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42009_42010 : H12AffineEnvironment.transform 14 29909 env42009 = env42010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env42009 == env42010) = true)

theorem identity42010 : scanCanonicalize (H12AffineFastState.compose env42010 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 11460) := by decide +kernel

theorem selectedBound42010 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env42011 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11460,6161,34,3465,10401,1025,6160,12392,32,8248,6639,8328,64,10280,13625,10693,12741,9716,8321,257,14820,11413,513]

theorem envBound42011 : H12AffineFastState.Bounded env42011 := by
  intro p hp
  have h : env42011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42010_42011 : H12AffineEnvironment.transform 13 11460 env42010 = env42011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11460 env42010 == env42011) = true)

theorem identity42011 : scanCanonicalize (H12AffineFastState.compose env42011 (packedSelected [0,7,10,11,12,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound42011 : packedSelected [0,7,10,11,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env42012 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,152,8192,11460,2185,34,3465,10401,1025,2184,8432,32,8248,2423,8328,64,10280,9633,10693,8541,9716,8321,257,10620,11413,513]

theorem envBound42012 : H12AffineFastState.Bounded env42012 := by
  intro p hp
  have h : env42012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42011_42012 : H12AffineEnvironment.transform 11 152 env42011 = env42012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env42011 == env42012) = true)

theorem identity42012 : scanCanonicalize (H12AffineFastState.compose env42012 (packedSelected [2,6,12,14,16,18] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound42012 : packedSelected [2,6,12,14,16,18] rootPS < 2^1333 := by decide +kernel

def env42013 : List Nat := [2,4,8,16,32,64,128,256,512,188,2048,152,8192,10360,2185,34,2357,10401,189,2184,8432,32,8248,2423,8328,64,10280,8477,10693,8541,8520,8321,257,10620,10281,513]

theorem envBound42013 : H12AffineFastState.Bounded env42013 := by
  intro p hp
  have h : env42013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42012_42013 : H12AffineEnvironment.transform 9 188 env42012 = env42013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env42012 == env42013) = true)

theorem identity42013 : scanCanonicalize (H12AffineFastState.compose env42013 (packedSelected [1,2,3,5,6,8,9,11,16,22] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound42013 : packedSelected [1,2,3,5,6,8,9,11,16,22] rootPS < 2^1333 := by decide +kernel

def env42014 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,152,8192,10360,2185,34,2112,10401,189,2184,8432,32,8248,2050,8328,64,10280,8296,10416,8232,8253,8321,116,10249,10281,513]

theorem envBound42014 : H12AffineFastState.Bounded env42014 := by
  intro p hp
  have h : env42014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42013_42014 : H12AffineEnvironment.transform 7 117 env42013 = env42014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env42013 == env42014) = true)

theorem identity42014 : scanCanonicalize (H12AffineFastState.compose env42014 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 2289) := by decide +kernel

theorem selectedBound42014 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env42015 : List Nat := [2,4,8,16,32,64,128,117,512,188,2048,152,2289,137,2185,34,2112,80,189,2184,2049,32,2249,2050,2169,64,217,2201,65,2265,2252,2160,116,248,216,513]

theorem envBound42015 : H12AffineFastState.Bounded env42015 := by
  intro p hp
  have h : env42015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42014_42015 : H12AffineEnvironment.transform 12 2289 env42014 = env42015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2289 env42014 == env42015) = true)

theorem identity42015 : scanCanonicalize (H12AffineFastState.compose env42015 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound42015 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env42016 : List Nat := [2,4,8,16,32,64,128,117,512,188,136,152,121,137,1,34,200,80,189,0,137,32,65,138,241,64,217,17,65,81,68,248,116,248,216,513]

theorem envBound42016 : H12AffineFastState.Bounded env42016 := by
  intro p hp
  have h : env42016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42015_42016 : H12AffineEnvironment.transform 10 136 env42015 = env42016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env42015 == env42016) = true)

theorem identity42016 : scanCanonicalize (H12AffineFastState.compose env42016 (packedSelected [0,3] rootPS)) = affineNative (2^(6+1) ^^^ 73) := by decide +kernel

theorem selectedBound42016 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env42017 : List Nat := [2,4,8,16,32,64,73,117,512,117,65,81,121,64,1,34,1,80,116,0,64,32,65,67,56,64,16,17,65,81,68,49,116,49,17,513]

theorem envBound42017 : H12AffineFastState.Bounded env42017 := by
  intro p hp
  have h : env42017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42016_42017 : H12AffineEnvironment.transform 6 73 env42016 = env42017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 73 env42016 == env42017) = true)

theorem identity42017 : scanCanonicalize (H12AffineFastState.compose env42017 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound42017 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42018 : List Nat := [2,4,8,16,32,32,41,21,512,21,33,49,25,32,1,34,1,48,20,0,32,32,33,35,56,32,16,17,33,49,36,49,20,49,17,513]

theorem envBound42018 : H12AffineFastState.Bounded env42018 := by
  intro p hp
  have h : env42018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42017_42018 : H12AffineEnvironment.transform 5 32 env42017 = env42018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env42017 == env42018) = true)

theorem identity42018 : scanCanonicalize (H12AffineFastState.compose env42018 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42018 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env42019 : List Nat := [2,4,8,16,32,32,41,21,17,21,33,49,25,32,1,34,1,48,20,0,32,32,33,35,56,32,16,17,33,49,36,49,20,49,17,16]

theorem envBound42019 : H12AffineFastState.Bounded env42019 := by
  intro p hp
  have h : env42019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42018_42019 : H12AffineEnvironment.transform 8 17 env42018 = env42019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42018 == env42019) = true)

def env42020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,4194304,2101329,98781,8328,64,6603797,2098512,17664,2377160,2102684,6349853,257,21792,46212,2175563]

theorem envBound42020 : H12AffineFastState.Bounded env42020 := by
  intro p hp
  have h : env42020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41961_42020 : H12AffineEnvironment.transform 16 38297 env41961 = env42020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env41961 == env42020) = true)

def env42021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272512,2101329,98781,8328,64,2157717,2098512,17664,2377160,2102684,2411677,257,21792,46212,2175563]

theorem envBound42021 : H12AffineFastState.Bounded env42021 := by
  intro p hp
  have h : env42021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42020_42021 : H12AffineEnvironment.transform 21 272512 env42020 = env42021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42020 == env42021) = true)

theorem identity42021 : scanCanonicalize (H12AffineFastState.compose env42021 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42021 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38297,262144,1025,32769,2097152,272512,2101329,41431,8328,64,2157717,2098512,17664,2377160,2102684,2411677,257,21792,46212,2101825]

theorem envBound42022 : H12AffineFastState.Bounded env42022 := by
  intro p hp
  have h : env42022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42021_42022 : H12AffineEnvironment.transform 15 8202 env42021 = env42022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42021 == env42022) = true)

def env42023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,2097152,272392,2101329,41311,8192,64,2157597,2098512,17664,2377024,2102548,2411541,257,21792,46092,2101825]

theorem envBound42023 : H12AffineFastState.Bounded env42023 := by
  intro p hp
  have h : env42023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42022_42023 : H12AffineEnvironment.transform 6 8 env42022 = env42023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42022 == env42023) = true)

theorem identity42023 : scanCanonicalize (H12AffineFastState.compose env42023 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 276585) := by decide +kernel

theorem selectedBound42023 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env42024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,276585,272392,272440,41311,8192,64,316532,277817,17664,32041,273789,62588,257,21792,46092,272936]

theorem envBound42024 : H12AffineFastState.Bounded env42024 := by
  intro p hp
  have h : env42024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42023_42024 : H12AffineEnvironment.transform 20 276585 env42023 = env42024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276585 env42023 == env42024) = true)

theorem identity42024 : scanCanonicalize (H12AffineFastState.compose env42024 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound42024 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42025 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10280,1025,32769,4161,32,16,41311,8192,64,64604,5393,17664,32041,1365,62588,257,21792,46092,512]

theorem envBound42025 : H12AffineFastState.Bounded env42025 := by
  intro p hp
  have h : env42025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42024_42025 : H12AffineEnvironment.transform 17 10280 env42024 = env42025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42024 == env42025) = true)

theorem identity42025 : scanCanonicalize (H12AffineFastState.compose env42025 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 12620) := by decide +kernel

theorem selectedBound42025 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42026 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,12620,8202,9309,10280,1025,12621,4161,32,16,4115,8192,64,19728,5393,17664,32041,1365,17712,257,21792,1344,512]

theorem envBound42026 : H12AffineFastState.Bounded env42026 := by
  intro p hp
  have h : env42026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42025_42026 : H12AffineEnvironment.transform 14 12620 env42025 = env42026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12620 env42025 == env42026) = true)

theorem identity42026 : scanCanonicalize (H12AffineFastState.compose env42026 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 1125) := by decide +kernel

theorem selectedBound42026 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1125,12620,8202,9309,10280,1025,12621,4161,32,16,4115,8192,64,2421,5393,357,14668,1365,341,257,4421,1344,512]

theorem envBound42027 : H12AffineFastState.Bounded env42027 := by
  intro p hp
  have h : env42027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42026_42027 : H12AffineEnvironment.transform 13 1125 env42026 = env42027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1125 env42026 == env42027) = true)

theorem identity42027 : scanCanonicalize (H12AffineFastState.compose env42027 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 97) := by decide +kernel

theorem selectedBound42027 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env42028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,97,8192,1125,8493,8202,9309,10280,1025,8492,32,32,16,114,8192,64,2421,1392,357,10541,1365,341,257,292,1344,512]

theorem envBound42028 : H12AffineFastState.Bounded env42028 := by
  intro p hp
  have h : env42028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42027_42028 : H12AffineEnvironment.transform 11 97 env42027 = env42028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 97 env42027 == env42028) = true)

def env42029 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,2097152,272393,2101329,41310,8193,64,2157596,2098512,17664,2377025,2102549,2411540,257,21792,46093,2101825]

theorem envBound42029 : H12AffineFastState.Bounded env42029 := by
  intro p hp
  have h : env42029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42022_42029 : H12AffineEnvironment.transform 6 9 env42022 = env42029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42022 == env42029) = true)

theorem identity42029 : scanCanonicalize (H12AffineFastState.compose env42029 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 301364) := by decide +kernel

theorem selectedBound42029 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env42030 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,262144,1025,32769,301364,272393,297317,41310,8193,64,292136,302180,17664,56437,298017,21792,257,21792,46093,297845]

theorem envBound42030 : H12AffineFastState.Bounded env42030 := by
  intro p hp
  have h : env42030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42029_42030 : H12AffineEnvironment.transform 20 301364 env42029 = env42030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 301364 env42029 == env42030) = true)

theorem identity42030 : scanCanonicalize (H12AffineFastState.compose env42030 (packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 64604) := by decide +kernel

theorem selectedBound42030 : packedSelected [0,2,3,7,9,10,11,16,17,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env42031 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38160,64604,1025,32769,25960,54357,30009,41310,8193,64,35188,24632,17664,56437,28797,21792,257,21792,46093,30505]

theorem envBound42031 : H12AffineFastState.Bounded env42031 := by
  intro p hp
  have h : env42031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42030_42031 : H12AffineEnvironment.transform 17 64604 env42030 = env42031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64604 env42030 == env42031) = true)

theorem identity42031 : scanCanonicalize (H12AffineFastState.compose env42031 (packedSelected [0,6,7,14,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound42031 : packedSelected [0,6,7,14,16,17] rootPS < 2^1333 := by decide +kernel

def env42032 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,8202,38160,35189,1025,32769,4161,41340,16,41310,8193,64,35188,5393,12329,43356,1364,8201,257,8201,46093,512]

theorem envBound42032 : H12AffineFastState.Bounded env42032 := by
  intro p hp
  have h : env42032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42031_42032 : H12AffineEnvironment.transform 13 13609 env42031 = env42032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env42031 == env42032) = true)

theorem identity42032 : scanCanonicalize (H12AffineFastState.compose env42032 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound42032 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env42033 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,1,8202,5393,2420,1025,0,4161,8573,16,8543,8193,64,2421,5393,12329,10589,1364,8201,257,8201,13324,512]

theorem envBound42033 : H12AffineFastState.Bounded env42033 := by
  intro p hp
  have h : env42033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42032_42033 : H12AffineEnvironment.transform 14 1 env42032 = env42033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env42032 == env42033) = true)

theorem identity42033 : scanCanonicalize (H12AffineFastState.compose env42033 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42033 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env42034 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13609,1,8202,5393,2341,1025,0,4112,8492,16,8462,8193,17,2340,5393,12329,10508,1285,8201,257,8201,13324,512]

theorem envBound42034 : H12AffineFastState.Bounded env42034 := by
  intro p hp
  have h : env42034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42033_42034 : H12AffineEnvironment.transform 5 17 env42033 = env42034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42033 == env42034) = true)

theorem identity42034 : scanCanonicalize (H12AffineFastState.compose env42034 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 7180) := by decide +kernel

theorem selectedBound42034 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env42035 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,7180,2341,1,7174,5393,2341,1025,0,4112,7456,16,7426,7181,17,2340,5393,3109,5376,1285,7173,257,7173,2048,512]

theorem envBound42035 : H12AffineFastState.Bounded env42035 := by
  intro p hp
  have h : env42035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42034_42035 : H12AffineEnvironment.transform 12 7180 env42034 = env42035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7180 env42034 == env42035) = true)

theorem identity42035 : scanCanonicalize (H12AffineFastState.compose env42035 (packedSelected [2,3,4,5,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound42035 : packedSelected [2,3,4,5,7,11] rootPS < 2^1333 := by decide +kernel

def env42036 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,48,3132,2341,1,3126,1313,2341,1025,0,32,3344,16,3378,3133,17,2340,1313,3109,1328,1285,3125,257,3125,2048,512]

theorem envBound42036 : H12AffineFastState.Bounded env42036 := by
  intro p hp
  have h : env42036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42035_42036 : H12AffineEnvironment.transform 11 48 env42035 = env42036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42035 == env42036) = true)

theorem identity42036 : scanCanonicalize (H12AffineFastState.compose env42036 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound42036 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env42037 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1044,48,40,1329,1,34,1313,1329,1025,0,32,260,16,294,41,17,1328,1313,49,1328,1285,33,257,33,1044,512]

theorem envBound42037 : H12AffineFastState.Bounded env42037 := by
  intro p hp
  have h : env42037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42036_42037 : H12AffineEnvironment.transform 10 1044 env42036 = env42037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env42036 == env42037) = true)

theorem identity42037 : scanCanonicalize (H12AffineFastState.compose env42037 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42037 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42038 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1044,48,40,1044,1,34,1028,1044,1025,0,32,33,16,3,41,17,1045,1028,49,1045,1056,33,36,33,1044,512]

theorem envBound42038 : H12AffineFastState.Bounded env42038 := by
  intro p hp
  have h : env42038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42037_42038 : H12AffineEnvironment.transform 7 37 env42037 = env42038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42037 == env42038) = true)

theorem identity42038 : scanCanonicalize (H12AffineFastState.compose env42038 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound42038 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42039 : List Nat := [2,4,8,16,32,17,9,37,512,17,5,48,40,5,1,34,21,5,16,0,32,33,16,3,41,17,4,21,49,4,49,33,36,33,5,512]

theorem envBound42039 : H12AffineFastState.Bounded env42039 := by
  intro p hp
  have h : env42039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42038_42039 : H12AffineEnvironment.transform 9 17 env42038 = env42039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env42038 == env42039) = true)

theorem identity42039 : scanCanonicalize (H12AffineFastState.compose env42039 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound42039 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42040 : List Nat := [2,4,8,16,32,17,9,37,10,17,5,48,40,5,1,34,21,5,16,0,32,33,16,3,41,17,4,21,49,4,49,33,36,33,5,10]

theorem envBound42040 : H12AffineFastState.Bounded env42040 := by
  intro p hp
  have h : env42040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42039_42040 : H12AffineEnvironment.transform 8 10 env42039 = env42040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env42039 == env42040) = true)

theorem identity42040 : scanCanonicalize (H12AffineFastState.compose env42040 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound42040 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env42041 : List Nat := [2,0,8,16,32,17,9,33,10,17,1,48,40,1,1,34,17,1,16,0,32,33,16,3,41,17,0,17,49,0,49,33,32,33,1,10]

theorem envBound42041 : H12AffineFastState.Bounded env42041 := by
  intro p hp
  have h : env42041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42040_42041 : H12AffineEnvironment.transform 1 0 env42040 = env42041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env42040 == env42041) = true)

theorem identity42041 : scanCanonicalize (H12AffineFastState.compose env42041 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound42041 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42042 : List Nat := [2,0,8,16,2,17,9,3,10,17,1,18,10,1,1,0,17,1,16,0,2,3,16,3,11,17,0,17,19,0,19,3,2,3,1,10]

theorem envBound42042 : H12AffineFastState.Bounded env42042 := by
  intro p hp
  have h : env42042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42041_42042 : H12AffineEnvironment.transform 4 2 env42041 = env42042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env42041 == env42042) = true)

theorem identity42042 : scanCanonicalize (H12AffineFastState.compose env42042 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound42042 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env42043 : List Nat := [0,0,8,16,0,17,9,1,8,17,1,16,8,1,1,0,17,1,16,0,0,1,16,1,9,17,0,17,17,0,17,1,0,1,1,8]

theorem envBound42043 : H12AffineFastState.Bounded env42043 := by
  intro p hp
  have h : env42043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42042_42043 : H12AffineEnvironment.transform 0 0 env42042 = env42043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env42042 == env42043) = true)

def env42044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272513,2101329,98781,8328,64,2157716,2098512,17664,2377160,2102684,2411676,257,21792,46212,2175563]

theorem envBound42044 : H12AffineFastState.Bounded env42044 := by
  intro p hp
  have h : env42044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42020_42044 : H12AffineEnvironment.transform 21 272513 env42020 = env42044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42020 == env42044) = true)

theorem identity42044 : scanCanonicalize (H12AffineFastState.compose env42044 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound42044 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,77898,272513,73755,98781,8328,64,122078,79130,17664,357762,75222,392406,257,21792,46212,513]

theorem envBound42045 : H12AffineFastState.Bounded env42045 := by
  intro p hp
  have h : env42045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42044_42045 : H12AffineEnvironment.transform 20 77898 env42044 = env42045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env42044 == env42045) = true)

def env42046 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,77898,272393,73755,98645,8192,64,121942,79130,17664,357642,75102,392286,257,21792,46092,513]

theorem envBound42046 : H12AffineFastState.Bounded env42046 := by
  intro p hp
  have h : env42046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42045_42046 : H12AffineEnvironment.transform 6 8 env42045 = env42046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env42045 == env42046) = true)

def env42047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,77898,33,73755,98645,8192,64,121942,79130,17664,89378,75102,119926,257,21792,46092,513]

theorem envBound42047 : H12AffineFastState.Bounded env42047 := by
  intro p hp
  have h : env42047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42046_42047 : H12AffineEnvironment.transform 17 10280 env42046 = env42047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env42046 == env42047) = true)

theorem identity42047 : scanCanonicalize (H12AffineFastState.compose env42047 (packedSelected [2,6,12,14,15,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound42047 : packedSelected [2,6,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env42048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,10280,1025,21761,77898,33,73755,87125,8192,64,67926,79130,17664,89378,75102,65910,257,21792,24844,513]

theorem envBound42048 : H12AffineFastState.Bounded env42048 := by
  intro p hp
  have h : env42048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42047_42048 : H12AffineEnvironment.transform 14 21760 env42047 = env42048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env42047 == env42048) = true)

theorem identity42048 : scanCanonicalize (H12AffineFastState.compose env42048 (packedSelected [0,1,4,7,8,9,14,19] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound42048 : packedSelected [0,1,4,7,8,9,14,19] rootPS < 2^1333 := by decide +kernel

def env42049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21591,16401,10280,1025,21761,25629,33,29772,2,8192,64,23809,24909,17664,2421,28937,21793,257,21792,24844,513]

theorem envBound42049 : H12AffineFastState.Bounded env42049 := by
  intro p hp
  have h : env42049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42048_42049 : H12AffineEnvironment.transform 15 21591 env42048 = env42049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env42048 == env42049) = true)

theorem identity42049 : scanCanonicalize (H12AffineFastState.compose env42049 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound42049 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env42050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,21591,16401,2421,1025,21761,17728,33,21777,2,349,64,23809,16400,17664,2421,20564,21793,257,21792,16465,513]

theorem envBound42050 : H12AffineFastState.Bounded env42050 := by
  intro p hp
  have h : env42050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42049_42050 : H12AffineEnvironment.transform 12 349 env42049 = env42050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env42049 == env42050) = true)

theorem identity42050 : scanCanonicalize (H12AffineFastState.compose env42050 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound42050 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env42051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5456,80,263,5441,2421,1025,81,4112,33,65,2,349,64,2129,5440,4176,2421,1284,113,257,112,5377,513]

theorem envBound42051 : H12AffineFastState.Bounded env42051 := by
  intro p hp
  have h : env42051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42050_42051 : H12AffineEnvironment.transform 13 5456 env42050 = env42051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env42050 == env42051) = true)

theorem identity42051 : scanCanonicalize (H12AffineFastState.compose env42051 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42051 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env42052 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,263,5392,2340,1025,0,4112,33,16,2,268,17,2048,5393,4097,2340,1284,32,257,33,5377,513]

theorem envBound42052 : H12AffineFastState.Bounded env42052 := by
  intro p hp
  have h : env42052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42051_42052 : H12AffineEnvironment.transform 5 17 env42051 = env42052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42051 == env42052) = true)

theorem identity42052 : scanCanonicalize (H12AffineFastState.compose env42052 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42052 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42053 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,1,34,5173,2049,1025,0,4112,33,16,2,41,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound42053 : H12AffineFastState.Bounded env42053 := by
  intro p hp
  have h : env42053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42052_42053 : H12AffineEnvironment.transform 7 37 env42052 = env42053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42052 == env42053) = true)

def env42054 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,1,34,1029,2049,1025,0,32,33,16,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound42054 : H12AffineFastState.Bounded env42054 := by
  intro p hp
  have h : env42054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42053_42054 : H12AffineEnvironment.transform 11 48 env42053 = env42054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env42053 == env42054) = true)

theorem identity42054 : scanCanonicalize (H12AffineFastState.compose env42054 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound42054 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42055 : List Nat := [2,4,8,16,32,17,8,37,16,1024,2048,48,41,1044,1,34,1029,2049,1025,0,32,33,16,2,41,17,2048,1028,49,2049,1057,32,36,33,1044,17]

theorem envBound42055 : H12AffineFastState.Bounded env42055 := by
  intro p hp
  have h : env42055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42054_42055 : H12AffineEnvironment.transform 8 16 env42054 = env42055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42054 == env42055) = true)

def env42056 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,48,41,32,1,34,49,2049,53,0,32,33,16,2,41,17,2048,48,49,2049,21,32,36,33,32,17]

theorem envBound42056 : H12AffineFastState.Bounded env42056 := by
  intro p hp
  have h : env42056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42055_42056 : H12AffineEnvironment.transform 9 52 env42055 = env42056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42055 == env42056) = true)

theorem identity42056 : scanCanonicalize (H12AffineFastState.compose env42056 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound42056 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42057 : List Nat := [2,4,8,16,32,17,8,37,16,52,32,48,41,32,1,34,49,33,53,0,32,33,16,2,41,17,32,48,49,33,21,32,36,33,32,17]

theorem envBound42057 : H12AffineFastState.Bounded env42057 := by
  intro p hp
  have h : env42057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42056_42057 : H12AffineEnvironment.transform 10 32 env42056 = env42057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env42056 == env42057) = true)

def leafEnv42057 : List Nat := [2,4,8,16,32,17,8,37,16,52,32,48,41,32,1,34,49,33,53,0,32,33,16,2,20,41,1,17,32,48,49,33,21,32,36,33,5,34,32,17,1,32,0]

def active42057 : List Nat := [0,1,2,3,4]

def tree42057 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42057 : H12WitnessSearch.Good tree42057 := H12GlobalWitnessIndex.good

theorem leafIdentity42057 : H12AffineFastState.composeSystem env42057 rootObs = leafEnv42057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42057 rootObs == leafEnv42057) = true)

theorem terminalChecked42057 : H12PackedTerminal.terminalCheckFast leafEnv42057 active42057 tree42057 = true := by decide +kernel

def env42058 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,48,41,33,1,34,48,2049,52,0,32,33,16,2,41,17,2048,49,49,2049,20,32,36,33,33,17]

theorem envBound42058 : H12AffineFastState.Bounded env42058 := by
  intro p hp
  have h : env42058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42055_42058 : H12AffineEnvironment.transform 9 53 env42055 = env42058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env42055 == env42058) = true)

theorem identity42058 : scanCanonicalize (H12AffineFastState.compose env42058 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound42058 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42059 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,48,41,33,1,34,48,27,52,0,32,33,16,2,41,17,26,49,49,27,20,32,36,33,33,17]

theorem envBound42059 : H12AffineFastState.Bounded env42059 := by
  intro p hp
  have h : env42059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42058_42059 : H12AffineEnvironment.transform 10 26 env42058 = env42059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env42058 == env42059) = true)

def leafEnv42059 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,48,41,33,1,34,48,27,52,0,32,33,16,2,21,41,1,17,26,49,49,27,20,32,36,33,5,34,33,17,1,32,0]

def active42059 : List Nat := [0,1,2,3,4]

def tree42059 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42059 : H12WitnessSearch.Good tree42059 := H12GlobalWitnessIndex.good

theorem leafIdentity42059 : H12AffineFastState.composeSystem env42059 rootObs = leafEnv42059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42059 rootObs == leafEnv42059) = true)

theorem terminalChecked42059 : H12PackedTerminal.terminalCheckFast leafEnv42059 active42059 tree42059 = true := by decide +kernel

def env42060 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,1,34,1028,2049,1025,0,33,33,16,2,41,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound42060 : H12AffineFastState.Bounded env42060 := by
  intro p hp
  have h : env42060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42053_42060 : H12AffineEnvironment.transform 11 49 env42053 = env42060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env42053 == env42060) = true)

theorem identity42060 : scanCanonicalize (H12AffineFastState.compose env42060 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound42060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42061 : List Nat := [2,4,8,16,32,17,8,37,512,549,2048,49,41,560,1,34,545,2049,548,0,33,33,16,2,41,17,2048,544,48,2049,516,32,36,33,560,513]

theorem envBound42061 : H12AffineFastState.Bounded env42061 := by
  intro p hp
  have h : env42061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42060_42061 : H12AffineEnvironment.transform 9 549 env42060 = env42061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env42060 == env42061) = true)

def env42062 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,49,41,32,1,34,49,2049,52,0,33,33,16,2,41,17,2048,48,48,2049,20,32,36,33,32,17]

theorem envBound42062 : H12AffineFastState.Bounded env42062 := by
  intro p hp
  have h : env42062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42061_42062 : H12AffineEnvironment.transform 8 16 env42061 = env42062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env42061 == env42062) = true)

theorem identity42062 : scanCanonicalize (H12AffineFastState.compose env42062 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound42062 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42063 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,49,41,32,1,34,49,27,52,0,33,33,16,2,41,17,26,48,48,27,20,32,36,33,32,17]

theorem envBound42063 : H12AffineFastState.Bounded env42063 := by
  intro p hp
  have h : env42063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42062_42063 : H12AffineEnvironment.transform 10 26 env42062 = env42063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env42062 == env42063) = true)

def leafEnv42063 : List Nat := [2,4,8,16,32,17,8,37,16,53,26,49,41,32,1,34,49,27,52,0,33,33,16,2,21,41,1,17,26,48,48,27,20,32,36,33,5,34,32,17,1,33,0]

def active42063 : List Nat := [0,1,2,3,4]

def tree42063 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42063 : H12WitnessSearch.Good tree42063 := H12GlobalWitnessIndex.good

theorem leafIdentity42063 : H12AffineFastState.composeSystem env42063 rootObs = leafEnv42063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42063 rootObs == leafEnv42063) = true)

theorem terminalChecked42063 : H12PackedTerminal.terminalCheckFast leafEnv42063 active42063 tree42063 = true := by decide +kernel

def env42064 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,49,41,33,1,34,48,2049,53,0,33,33,16,2,41,17,2048,49,48,2049,21,32,36,33,33,16]

theorem envBound42064 : H12AffineFastState.Bounded env42064 := by
  intro p hp
  have h : env42064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42061_42064 : H12AffineEnvironment.transform 8 17 env42061 = env42064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42061 == env42064) = true)

theorem identity42064 : scanCanonicalize (H12AffineFastState.compose env42064 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound42064 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42065 : List Nat := [2,4,8,16,32,17,8,37,17,52,33,49,41,33,1,34,48,32,53,0,33,33,16,2,41,17,33,49,48,32,21,32,36,33,33,16]

theorem envBound42065 : H12AffineFastState.Bounded env42065 := by
  intro p hp
  have h : env42065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42064_42065 : H12AffineEnvironment.transform 10 33 env42064 = env42065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env42064 == env42065) = true)

def leafEnv42065 : List Nat := [2,4,8,16,32,17,8,37,17,52,33,49,41,33,1,34,48,32,53,0,33,33,16,2,20,41,1,17,33,49,48,32,21,32,36,33,5,34,33,16,1,33,0]

def active42065 : List Nat := [0,1,2,3,4]

def tree42065 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood42065 : H12WitnessSearch.Good tree42065 := H12GlobalWitnessIndex.good

theorem leafIdentity42065 : H12AffineFastState.composeSystem env42065 rootObs = leafEnv42065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env42065 rootObs == leafEnv42065) = true)

theorem terminalChecked42065 : H12PackedTerminal.terminalCheckFast leafEnv42065 active42065 tree42065 = true := by decide +kernel

def env42066 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10281,1025,32769,77898,32,73755,98645,8192,64,121942,79130,17664,89379,75102,119927,257,21792,46092,513]

theorem envBound42066 : H12AffineFastState.Bounded env42066 := by
  intro p hp
  have h : env42066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42046_42066 : H12AffineEnvironment.transform 17 10281 env42046 = env42066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env42046 == env42066) = true)

theorem identity42066 : scanCanonicalize (H12AffineFastState.compose env42066 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound42066 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env42067 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10281,1025,32769,4161,32,16,41310,8192,64,64605,5393,17664,32040,1365,62588,257,21792,46092,513]

theorem envBound42067 : H12AffineFastState.Bounded env42067 := by
  intro p hp
  have h : env42067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42066_42067 : H12AffineEnvironment.transform 15 8203 env42066 = env42067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env42066 == env42067) = true)

theorem identity42067 : scanCanonicalize (H12AffineFastState.compose env42067 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound42067 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env42068 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,32768,3143,38161,1125,1025,32769,4161,32,16,36114,3148,64,53265,5393,17664,20836,1365,55344,257,21792,38976,513]

theorem envBound42068 : H12AffineFastState.Bounded env42068 := by
  intro p hp
  have h : env42068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42067_42068 : H12AffineEnvironment.transform 12 3148 env42067 = env42068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env42067 == env42068) = true)

theorem identity42068 : scanCanonicalize (H12AffineFastState.compose env42068 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound42068 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env42069 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,21760,3143,16401,1125,1025,21761,4161,32,16,22546,3148,64,1297,5393,17664,20836,1365,3376,257,21792,19776,513]

theorem envBound42069 : H12AffineFastState.Bounded env42069 := by
  intro p hp
  have h : env42069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42068_42069 : H12AffineEnvironment.transform 14 21760 env42068 = env42069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env42068 == env42069) = true)

theorem identity42069 : scanCanonicalize (H12AffineFastState.compose env42069 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound42069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42070 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,349,16384,21760,342,16401,1125,1025,21761,4161,32,16,21763,349,64,1297,5393,17664,20836,1365,33,257,21792,16465,513]

theorem envBound42070 : H12AffineFastState.Bounded env42070 := by
  intro p hp
  have h : env42070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42069_42070 : H12AffineEnvironment.transform 10 1297 env42069 = env42070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env42069 == env42070) = true)

theorem identity42070 : scanCanonicalize (H12AffineFastState.compose env42070 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42070 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env42071 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,16384,21541,115,16401,1125,1025,21540,4161,32,16,21542,120,64,1076,5172,17445,20545,1136,33,36,21509,16465,513]

theorem envBound42071 : H12AffineFastState.Bounded env42071 := by
  intro p hp
  have h : env42071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42070_42071 : H12AffineEnvironment.transform 7 37 env42070 = env42071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42070 == env42071) = true)

theorem identity42071 : scanCanonicalize (H12AffineFastState.compose env42071 (packedSelected [3,4,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound42071 : packedSelected [3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env42072 : List Nat := [2,4,8,16,32,64,8,37,512,1024,1076,4096,120,4112,1077,115,4097,1125,1025,1076,4161,32,16,1078,120,64,1076,5172,5173,81,1136,33,36,1045,4161,513]

theorem envBound42072 : H12AffineFastState.Bounded env42072 := by
  intro p hp
  have h : env42072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42071_42072 : H12AffineEnvironment.transform 13 4112 env42071 = env42072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env42071 == env42072) = true)

theorem identity42072 : scanCanonicalize (H12AffineFastState.compose env42072 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound42072 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env42073 : List Nat := [2,4,8,16,32,64,8,37,512,100,80,4096,120,4112,81,115,4097,1,101,80,4161,32,16,82,120,64,80,4176,4177,81,20,33,36,113,4161,513]

theorem envBound42073 : H12AffineFastState.Bounded env42073 := by
  intro p hp
  have h : env42073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42072_42073 : H12AffineEnvironment.transform 9 100 env42072 = env42073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env42072 == env42073) = true)

theorem identity42073 : scanCanonicalize (H12AffineFastState.compose env42073 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound42073 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env42074 : List Nat := [2,4,8,16,32,64,8,37,512,100,80,17,120,1,81,115,16,1,101,80,80,32,16,82,120,64,80,65,64,81,20,33,36,113,80,513]

theorem envBound42074 : H12AffineFastState.Bounded env42074 := by
  intro p hp
  have h : env42074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42073_42074 : H12AffineEnvironment.transform 11 17 env42073 = env42074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env42073 == env42074) = true)

theorem identity42074 : scanCanonicalize (H12AffineFastState.compose env42074 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42074 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env42075 : List Nat := [2,4,8,16,32,17,8,37,512,53,1,17,41,1,0,34,16,1,52,1,1,32,16,3,41,17,1,16,17,0,20,33,36,32,1,513]

theorem envBound42075 : H12AffineFastState.Bounded env42075 := by
  intro p hp
  have h : env42075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42074_42075 : H12AffineEnvironment.transform 5 17 env42074 = env42075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42074 == env42075) = true)

theorem identity42075 : scanCanonicalize (H12AffineFastState.compose env42075 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound42075 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42076 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,8,1,0,3,16,1,21,1,1,1,16,3,8,17,1,16,17,0,20,0,5,1,1,513]

theorem envBound42076 : H12AffineFastState.Bounded env42076 := by
  intro p hp
  have h : env42076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42075_42076 : H12AffineEnvironment.transform 4 1 env42075 = env42076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env42075 == env42076) = true)

theorem identity42076 : scanCanonicalize (H12AffineFastState.compose env42076 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound42076 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42077 : List Nat := [2,4,8,16,1,17,8,4,17,20,1,17,8,1,0,3,16,1,21,1,1,1,16,3,8,17,1,16,17,0,20,0,5,1,1,16]

theorem envBound42077 : H12AffineFastState.Bounded env42077 := by
  intro p hp
  have h : env42077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42076_42077 : H12AffineEnvironment.transform 8 17 env42076 = env42077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env42076 == env42077) = true)

def env42078 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,77898,272392,73755,98644,8193,64,121943,79130,17664,357643,75103,392287,257,21792,46093,513]

theorem envBound42078 : H12AffineFastState.Bounded env42078 := by
  intro p hp
  have h : env42078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42045_42078 : H12AffineEnvironment.transform 6 9 env42045 = env42078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42045 == env42078) = true)

theorem identity42078 : scanCanonicalize (H12AffineFastState.compose env42078 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound42078 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env42079 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,50496,272392,54545,29790,8193,64,10589,49168,17664,294913,53333,264533,257,21792,46093,513]

theorem envBound42079 : H12AffineFastState.Bounded env42079 := by
  intro p hp
  have h : env42079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42078_42079 : H12AffineEnvironment.transform 15 62730 env42078 = env42079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env42078 == env42079) = true)

theorem identity42079 : scanCanonicalize (H12AffineFastState.compose env42079 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound42079 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env42080 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,10589,1025,32769,50496,341,54545,29790,8193,64,10589,49168,17664,43356,53333,8200,257,21792,46093,513]

theorem envBound42080 : H12AffineFastState.Bounded env42080 := by
  intro p hp
  have h : env42080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42079_42080 : H12AffineEnvironment.transform 17 10589 env42079 = env42080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env42079 == env42080) = true)

theorem identity42080 : scanCanonicalize (H12AffineFastState.compose env42080 (packedSelected [0,2,6,7,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound42080 : packedSelected [0,2,6,7,11,20,23] rootPS < 2^1333 := by decide +kernel

def env42081 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8312,21874,13672,10589,1025,8313,25912,341,30057,29790,8193,64,10589,24680,17664,2340,28717,8200,257,21792,5237,513]

theorem envBound42081 : H12AffineFastState.Bounded env42081 := by
  intro p hp
  have h : env42081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42080_42081 : H12AffineEnvironment.transform 14 8312 env42080 = env42081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env42080 == env42081) = true)

theorem identity42081 : scanCanonicalize (H12AffineFastState.compose env42081 (packedSelected [1,2,3,4,6,8,9,10,11,12,14,15,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound42081 : packedSelected [1,2,3,4,6,8,9,10,11,12,14,15,18,20,24] rootPS < 2^1333 := by decide +kernel

def env42082 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4453,8312,1047,13672,10589,1025,8313,13405,341,9228,9531,8193,64,10589,12557,5221,2340,8520,8200,257,1093,5237,513]

theorem envBound42082 : H12AffineFastState.Bounded env42082 := by
  intro p hp
  have h : env42082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42081_42082 : H12AffineEnvironment.transform 13 4453 env42081 = env42082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env42081 == env42082) = true)

theorem identity42082 : scanCanonicalize (H12AffineFastState.compose env42082 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound42082 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env42083 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1052,4453,1124,1047,4468,3393,1025,1125,4161,341,16,295,1053,64,3393,5393,5221,2340,1364,1044,257,1093,5237,513]

theorem envBound42083 : H12AffineFastState.Bounded env42083 := by
  intro p hp
  have h : env42083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42082_42083 : H12AffineEnvironment.transform 12 1052 env42082 = env42083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env42082 == env42083) = true)

theorem identity42083 : scanCanonicalize (H12AffineFastState.compose env42083 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound42083 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env42084 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,4096,40,4453,80,35,4468,2421,53,81,4161,341,16,295,41,64,2421,4389,4177,2340,352,32,257,113,4161,513]

theorem envBound42084 : H12AffineFastState.Bounded env42084 := by
  intro p hp
  have h : env42084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42083_42084 : H12AffineEnvironment.transform 9 52 env42083 = env42084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env42083 == env42084) = true)

theorem identity42084 : scanCanonicalize (H12AffineFastState.compose env42084 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound42084 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env42085 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,40,4404,1,35,4389,2340,53,0,4112,260,16,295,41,17,2340,4389,4096,2340,305,32,257,32,4112,513]

theorem envBound42085 : H12AffineFastState.Bounded env42085 := by
  intro p hp
  have h : env42085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42084_42085 : H12AffineEnvironment.transform 5 17 env42084 = env42085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env42084 == env42085) = true)

theorem identity42085 : scanCanonicalize (H12AffineFastState.compose env42085 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound42085 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env42086 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,1,35,4096,2049,53,0,4112,33,16,2,41,17,2049,4096,4096,2049,20,32,36,32,4112,513]

theorem envBound42086 : H12AffineFastState.Bounded env42086 := by
  intro p hp
  have h : env42086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42085_42086 : H12AffineEnvironment.transform 7 37 env42085 = env42086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env42085 == env42086) = true)

theorem identity42086 : scanCanonicalize (H12AffineFastState.compose env42086 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound42086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env42087 : List Nat := [2,4,8,16,32,17,9,37,1,52,2048,4096,40,4113,1,35,4096,2049,53,0,4112,33,16,2,41,17,2049,4096,4096,2049,20,32,36,32,4112,0]

theorem envBound42087 : H12AffineFastState.Bounded env42087 := by
  intro p hp
  have h : env42087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42086_42087 : H12AffineEnvironment.transform 8 1 env42086 = env42087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env42086 == env42087) = true)

theorem identity42087 : scanCanonicalize (H12AffineFastState.compose env42087 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound42087 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env42088 : List Nat := [2,4,8,16,32,17,9,37,1,52,27,4096,40,4113,1,35,4096,26,53,0,4112,33,16,2,41,17,26,4096,4096,26,20,32,36,32,4112,0]

theorem envBound42088 : H12AffineFastState.Bounded env42088 := by
  intro p hp
  have h : env42088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42087_42088 : H12AffineEnvironment.transform 10 27 env42087 = env42088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env42087 == env42088) = true)

theorem identity42088 : scanCanonicalize (H12AffineFastState.compose env42088 (packedSelected [3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound42088 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env42089 : List Nat := [2,4,8,16,32,17,9,37,1,52,27,17,40,0,1,35,17,26,53,0,1,33,16,2,41,17,26,17,17,26,20,32,36,32,1,0]

theorem envBound42089 : H12AffineFastState.Bounded env42089 := by
  intro p hp
  have h : env42089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42088_42089 : H12AffineEnvironment.transform 11 17 env42088 = env42089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env42088 == env42089) = true)

theorem identity42089 : scanCanonicalize (H12AffineFastState.compose env42089 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound42089 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env42090 : List Nat := [2,4,8,11,32,10,9,37,1,47,0,10,40,0,1,35,10,1,46,0,1,33,11,2,41,10,1,10,10,1,15,32,36,32,1,0]

theorem envBound42090 : H12AffineFastState.Bounded env42090 := by
  intro p hp
  have h : env42090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42089_42090 : H12AffineEnvironment.transform 3 11 env42089 = env42090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env42089 == env42090) = true)

def env42091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2262472,201797,8328,64,6705549,2265288,184473,2377160,2102685,6451589,257,21793,46213,2175562]

theorem envBound42091 : H12AffineFastState.Bounded env42091 := by
  intro p hp
  have h : env42091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans41960_42091 : H12AffineEnvironment.transform 23 201797 env41960 = env42091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 201797 env41960 == env42091) = true)

def env42092 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,4194304,2101328,98781,8328,64,6603797,2098512,17665,2377160,2102685,6349853,257,21793,46213,2175562]

theorem envBound42092 : H12AffineFastState.Bounded env42092 := by
  intro p hp
  have h : env42092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42091_42092 : H12AffineEnvironment.transform 16 38296 env42091 = env42092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env42091 == env42092) = true)

def env42093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272512,2101328,98781,8328,64,2157717,2098512,17665,2377160,2102685,2411677,257,21793,46213,2175562]

theorem envBound42093 : H12AffineFastState.Bounded env42093 := by
  intro p hp
  have h : env42093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42092_42093 : H12AffineEnvironment.transform 21 272512 env42092 = env42093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env42092 == env42093) = true)

theorem identity42093 : scanCanonicalize (H12AffineFastState.compose env42093 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound42093 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env42094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4161,272512,17,98781,8328,64,64724,5393,17665,284041,1500,318684,257,21793,46213,74251]

theorem envBound42094 : H12AffineFastState.Bounded env42094 := by
  intro p hp
  have h : env42094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42093_42094 : H12AffineEnvironment.transform 20 4161 env42093 = env42094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env42093 == env42094) = true)

theorem identity42094 : scanCanonicalize (H12AffineFastState.compose env42094 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound42094 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env42095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,262144,1025,32769,4161,272512,17,41431,8328,64,64724,5393,17665,284041,1500,318684,257,21793,46213,513]

theorem envBound42095 : H12AffineFastState.Bounded env42095 := by
  intro p hp
  have h : env42095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42094_42095 : H12AffineEnvironment.transform 15 8202 env42094 = env42095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env42094 == env42095) = true)

def env42096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,2097152,272513,2101328,98781,8328,64,2157716,2098512,17665,2377160,2102685,2411676,257,21793,46213,2175562]

theorem envBound42096 : H12AffineFastState.Bounded env42096 := by
  intro p hp
  have h : env42096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42092_42096 : H12AffineEnvironment.transform 21 272513 env42092 = env42096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env42092 == env42096) = true)

def env42097 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,2097152,272393,2101328,98645,8192,64,2157596,2098512,17665,2377024,2102549,2411540,257,21793,46093,2175562]

end H12CloudChart1