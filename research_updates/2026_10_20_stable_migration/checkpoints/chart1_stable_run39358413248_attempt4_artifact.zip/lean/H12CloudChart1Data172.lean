import H12CloudChart1Data171

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity43609 : scanCanonicalize (H12AffineFastState.compose env43609 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound43609 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43610 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,48,40,33,0,34,49,2049,53,1,32,33,16,3,41,16,2048,49,48,2049,20,32,37,33,33,11]

theorem envBound43610 : H12AffineFastState.Bounded env43610 := by
  intro p hp
  have h : env43610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43609_43610 : H12AffineEnvironment.transform 8 10 env43609 = env43610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env43609 == env43610) = true)

def leafEnv43610 : List Nat := [2,4,8,16,32,16,9,37,10,53,2048,48,40,33,0,34,49,2049,53,1,32,33,16,3,20,41,1,16,2048,49,48,2049,20,32,37,33,4,35,33,11,1,32,0]

def active43610 : List Nat := [0,1,2,3,4,10]

def tree43610 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43610 : H12WitnessSearch.Good tree43610 := H12GlobalWitnessIndex.good

theorem leafIdentity43610 : H12AffineFastState.composeSystem env43610 rootObs = leafEnv43610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43610 rootObs == leafEnv43610) = true)

theorem terminalChecked43610 : H12PackedTerminal.terminalCheckFast leafEnv43610 active43610 tree43610 = true := by decide +kernel

def env43611 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,49,40,1045,0,34,1029,2049,1024,1,33,33,16,3,41,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound43611 : H12AffineFastState.Bounded env43611 := by
  intro p hp
  have h : env43611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43607_43611 : H12AffineEnvironment.transform 11 49 env43607 = env43611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43607 == env43611) = true)

def env43612 : List Nat := [2,4,8,16,32,16,9,37,512,52,2048,49,40,33,0,34,49,2049,52,1,33,33,16,3,41,16,2048,49,49,2049,21,32,37,33,33,513]

theorem envBound43612 : H12AffineFastState.Bounded env43612 := by
  intro p hp
  have h : env43612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43611_43612 : H12AffineEnvironment.transform 9 52 env43611 = env43612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43611 == env43612) = true)

theorem identity43612 : scanCanonicalize (H12AffineFastState.compose env43612 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43612 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43613 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,8,1,0,2,17,2049,20,1,1,1,16,3,9,16,2048,17,17,2049,21,0,5,1,1,513]

theorem envBound43613 : H12AffineFastState.Bounded env43613 := by
  intro p hp
  have h : env43613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43612_43613 : H12AffineEnvironment.transform 4 0 env43612 = env43613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43612 == env43613) = true)

def leafEnv43613 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,17,8,1,0,2,17,2049,20,1,1,1,16,3,21,9,1,16,2048,17,17,2049,21,0,5,1,4,3,1,513,1,1,0]

def active43613 : List Nat := [0,1,2,3,8,10]

def tree43613 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43613 : H12WitnessSearch.Good tree43613 := H12GlobalWitnessIndex.good

theorem leafIdentity43613 : H12AffineFastState.composeSystem env43613 rootObs = leafEnv43613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43613 rootObs == leafEnv43613) = true)

theorem terminalChecked43613 : H12PackedTerminal.terminalCheckFast leafEnv43613 active43613 tree43613 = true := by decide +kernel

def env43614 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,49,40,32,0,34,48,2049,53,1,33,33,16,3,41,16,2048,48,49,2049,20,32,37,33,32,513]

theorem envBound43614 : H12AffineFastState.Bounded env43614 := by
  intro p hp
  have h : env43614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43611_43614 : H12AffineEnvironment.transform 9 53 env43611 = env43614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43611 == env43614) = true)

theorem identity43614 : scanCanonicalize (H12AffineFastState.compose env43614 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound43614 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43615 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,49,40,32,0,34,48,2049,53,1,33,33,16,3,41,16,2048,48,49,2049,20,32,37,33,32,10]

theorem envBound43615 : H12AffineFastState.Bounded env43615 := by
  intro p hp
  have h : env43615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43614_43615 : H12AffineEnvironment.transform 8 11 env43614 = env43615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env43614 == env43615) = true)

def leafEnv43615 : List Nat := [2,4,8,16,32,16,9,37,11,53,2048,49,40,32,0,34,48,2049,53,1,33,33,16,3,20,41,1,16,2048,48,49,2049,20,32,37,33,4,35,32,10,1,33,0]

def active43615 : List Nat := [0,1,2,3,4,10]

def tree43615 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43615 : H12WitnessSearch.Good tree43615 := H12GlobalWitnessIndex.good

theorem leafIdentity43615 : H12AffineFastState.composeSystem env43615 rootObs = leafEnv43615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43615 rootObs == leafEnv43615) = true)

theorem terminalChecked43615 : H12PackedTerminal.terminalCheckFast leafEnv43615 active43615 tree43615 = true := by decide +kernel

def env43616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound43616 : H12AffineFastState.Bounded env43616 := by
  intro p hp
  have h : env43616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43387_43616 : H12AffineEnvironment.transform 18 1025 env43387 = env43616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env43387 == env43616) = true)

theorem identity43616 : scanCanonicalize (H12AffineFastState.compose env43616 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165337) := by decide +kernel

theorem selectedBound43616 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43617 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,8388608,16777216,8328,64,29868032,16974164,8573064,8830977,25265168,21225497,257,25379189,25403601,25207751]

theorem envBound43617 : H12AffineFastState.Bounded env43617 := by
  intro p hp
  have h : env43617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43616_43617 : H12AffineEnvironment.transform 20 165337 env43616 = env43617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env43616 == env43617) = true)

def env43618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,8388608,8590420,8328,64,4510804,8393984,8573064,8830977,168004,12645453,257,21793,46213,243603]

theorem envBound43618 : H12AffineFastState.Bounded env43618 := by
  intro p hp
  have h : env43618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43617_43618 : H12AffineEnvironment.transform 23 8590420 env43617 = env43618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590420 env43617 == env43618) = true)

def env43619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169352,98780,8328,64,4510804,163976,17664,284041,168004,4350405,257,21793,46213,243603]

theorem envBound43619 : H12AffineFastState.Bounded env43619 := by
  intro p hp
  have h : env43619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43618_43619 : H12AffineEnvironment.transform 22 169352 env43618 = env43619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env43618 == env43619) = true)

def env43620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169352,98780,8328,64,64724,163976,17664,284041,168004,411973,257,21793,46213,243603]

theorem envBound43620 : H12AffineFastState.Bounded env43620 := by
  intro p hp
  have h : env43620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43619_43620 : H12AffineEnvironment.transform 21 272512 env43619 = env43620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env43619 == env43620) = true)

theorem identity43620 : scanCanonicalize (H12AffineFastState.compose env43620 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound43620 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160013,272512,155996,95496,8328,64,2048,160860,17664,284041,156816,411973,257,21793,16465,213831]

theorem envBound43621 : H12AffineFastState.Bounded env43621 := by
  intro p hp
  have h : env43621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43620_43621 : H12AffineEnvironment.transform 14 29908 env43620 = env43621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env43620 == env43621) = true)

def env43622 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160013,272392,155996,95496,8192,64,2048,160860,17664,283905,156696,411973,257,21793,16465,213831]

theorem envBound43622 : H12AffineFastState.Bounded env43622 := by
  intro p hp
  have h : env43622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43621_43622 : H12AffineEnvironment.transform 6 8 env43621 = env43622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43621 == env43622) = true)

theorem identity43622 : scanCanonicalize (H12AffineFastState.compose env43622 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound43622 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env43623 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,223599,1025,29789,160013,213351,155996,95496,8192,64,2048,160860,17664,212078,156696,73770,257,21793,16465,213831]

theorem envBound43623 : H12AffineFastState.Bounded env43623 := by
  intro p hp
  have h : env43623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43622_43623 : H12AffineEnvironment.transform 17 223599 env43622 = env43623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env43622 == env43623) = true)

theorem identity43623 : scanCanonicalize (H12AffineFastState.compose env43623 (packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 90187) := by decide +kernel

theorem selectedBound43623 : packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43624 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,90187,2340,1025,29789,69958,8492,65815,95496,8192,64,2048,70679,17664,23589,66643,73770,257,21793,16465,8972]

theorem envBound43624 : H12AffineFastState.Bounded env43624 := by
  intro p hp
  have h : env43624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43623_43624 : H12AffineEnvironment.transform 16 90187 env43623 = env43624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90187 env43623 == env43624) = true)

theorem identity43624 : scanCanonicalize (H12AffineFastState.compose env43624 (packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43624 : packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env43625 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,65536,90139,2340,1025,29709,69910,8492,65815,95496,8192,16,2048,70679,17664,23589,66563,73770,257,21793,16385,8972]

theorem envBound43625 : H12AffineFastState.Bounded env43625 := by
  intro p hp
  have h : env43625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43624_43625 : H12AffineEnvironment.transform 5 16 env43624 = env43625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43624 == env43625) = true)

theorem identity43625 : scanCanonicalize (H12AffineFastState.compose env43625 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound43625 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env43626 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29708,29962,5393,2340,1025,29709,25628,8492,29725,2,8192,16,2048,24861,17664,23589,28937,21792,257,21793,16385,8972]

theorem envBound43626 : H12AffineFastState.Bounded env43626 := by
  intro p hp
  have h : env43626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43625_43626 : H12AffineEnvironment.transform 15 29962 env43625 = env43626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env43625 == env43626) = true)

theorem identity43626 : scanCanonicalize (H12AffineFastState.compose env43626 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43626 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env43627 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8461,8203,5393,2340,1025,8460,12573,8492,8476,2,8192,16,2048,13340,4097,2340,9224,33,257,32,5376,8972]

theorem envBound43627 : H12AffineFastState.Bounded env43627 := by
  intro p hp
  have h : env43627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43626_43627 : H12AffineEnvironment.transform 13 5377 env43626 = env43627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43626 == env43627) = true)

theorem identity43627 : scanCanonicalize (H12AffineFastState.compose env43627 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43627 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43628 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,293,35,5393,2340,1025,292,4405,260,308,2,40,16,2048,5172,4097,2340,1056,33,257,32,5376,804]

theorem envBound43628 : H12AffineFastState.Bounded env43628 := by
  intro p hp
  have h : env43628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43627_43628 : H12AffineEnvironment.transform 12 40 env43627 = env43628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43627 == env43628) = true)

theorem identity43628 : scanCanonicalize (H12AffineFastState.compose env43628 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43628 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env43629 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5173,2048,1025,0,4113,32,16,2,40,16,2048,5172,4097,2048,1056,33,37,32,5156,512]

theorem envBound43629 : H12AffineFastState.Bounded env43629 := by
  intro p hp
  have h : env43629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43628_43629 : H12AffineEnvironment.transform 7 36 env43628 = env43629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43628 == env43629) = true)

theorem identity43629 : scanCanonicalize (H12AffineFastState.compose env43629 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43629 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43630 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,8,5125,1,3,5141,2048,1025,0,4113,0,16,2,8,16,2048,5140,4097,2048,1024,1,5,0,5124,512]

theorem envBound43630 : H12AffineFastState.Bounded env43630 := by
  intro p hp
  have h : env43630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43629_43630 : H12AffineEnvironment.transform 4 0 env43629 = env43630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43629 == env43630) = true)

theorem identity43630 : scanCanonicalize (H12AffineFastState.compose env43630 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3076) := by decide +kernel

theorem selectedBound43630 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43631 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,3076,8,2049,1,3,2065,2048,1025,0,3093,0,16,2,8,16,2048,2064,3077,2048,1024,1,5,0,2048,512]

theorem envBound43631 : H12AffineFastState.Bounded env43631 := by
  intro p hp
  have h : env43631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43630_43631 : H12AffineEnvironment.transform 11 3076 env43630 = env43631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3076 env43630 == env43631) = true)

theorem identity43631 : scanCanonicalize (H12AffineFastState.compose env43631 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound43631 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43632 : List Nat := [2,4,8,16,0,16,8,4,512,20,2048,2064,8,2049,1,3,2065,2048,21,0,2049,0,16,2,8,16,2048,2064,2065,2048,20,1,5,0,2048,512]

theorem envBound43632 : H12AffineFastState.Bounded env43632 := by
  intro p hp
  have h : env43632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43631_43632 : H12AffineEnvironment.transform 9 20 env43631 = env43632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env43631 == env43632) = true)

theorem identity43632 : scanCanonicalize (H12AffineFastState.compose env43632 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound43632 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43633 : List Nat := [2,4,8,16,0,16,8,4,512,20,4,20,8,5,1,3,21,4,21,0,5,0,16,2,8,16,4,20,21,4,20,1,5,0,4,512]

theorem envBound43633 : H12AffineFastState.Bounded env43633 := by
  intro p hp
  have h : env43633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43632_43633 : H12AffineEnvironment.transform 10 4 env43632 = env43633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env43632 == env43633) = true)

def env43634 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160013,272393,155996,95496,8193,64,2048,160860,17664,283904,156697,411973,257,21793,16465,213831]

theorem envBound43634 : H12AffineFastState.Bounded env43634 := by
  intro p hp
  have h : env43634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43621_43634 : H12AffineEnvironment.transform 6 9 env43621 = env43634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43621 == env43634) = true)

theorem identity43634 : scanCanonicalize (H12AffineFastState.compose env43634 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound43634 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env43635 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,157752,1025,29788,160013,147505,155996,95496,8193,64,2048,160860,17664,146744,156697,8573,257,21793,16465,213831]

theorem envBound43635 : H12AffineFastState.Bounded env43635 := by
  intro p hp
  have h : env43635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43634_43635 : H12AffineEnvironment.transform 17 157752 env43634 = env43635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env43634 == env43635) = true)

theorem identity43635 : scanCanonicalize (H12AffineFastState.compose env43635 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound43635 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env43636 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,5393,32041,1025,29788,25628,21792,29773,95496,8193,64,2048,24909,17664,10281,28936,8573,257,21793,16465,87638]

theorem envBound43636 : H12AffineFastState.Bounded env43636 := by
  intro p hp
  have h : env43636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43635_43636 : H12AffineEnvironment.transform 16 5393 env43635 = env43636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env43635 == env43636) = true)

theorem identity43636 : scanCanonicalize (H12AffineFastState.compose env43636 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43636 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,65536,5393,23669,1025,21760,17728,21792,21777,87124,349,64,2048,16401,17664,2421,20564,33,257,21793,16465,87638]

theorem envBound43637 : H12AffineFastState.Bounded env43637 := by
  intro p hp
  have h : env43637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43636_43637 : H12AffineEnvironment.transform 12 348 env43636 = env43637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43636 == env43637) = true)

theorem identity43637 : scanCanonicalize (H12AffineFastState.compose env43637 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound43637 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env43638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21761,34,5393,23669,1025,21760,17728,21792,21777,21622,349,64,2048,16401,17664,2421,20564,33,257,21793,16465,22132]

theorem envBound43638 : H12AffineFastState.Bounded env43638 := by
  intro p hp
  have h : env43638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43637_43638 : H12AffineEnvironment.transform 15 34 env43637 = env43638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env43637 == env43638) = true)

theorem identity43638 : scanCanonicalize (H12AffineFastState.compose env43638 (packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43638 : packedSelected [1,2,5,6,8,9,11,14,18,22,24] rootPS < 2^1333 := by decide +kernel

def env43639 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,34,5393,23589,1025,21760,17680,21792,21777,21542,269,16,2048,16401,17664,2341,20484,33,257,21793,16385,22052]

theorem envBound43639 : H12AffineFastState.Bounded env43639 := by
  intro p hp
  have h : env43639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43638_43639 : H12AffineEnvironment.transform 5 16 env43638 = env43639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43638 == env43639) = true)

theorem identity43639 : scanCanonicalize (H12AffineFastState.compose env43639 (packedSelected [2,6,9,11,14,18,22] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound43639 : packedSelected [2,6,9,11,14,18,22] rootPS < 2^1333 := by decide +kernel

def env43640 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5156,293,34,5393,2049,1025,292,4404,260,309,2,269,16,2048,5173,4388,2341,1056,33,257,261,5157,512]

theorem envBound43640 : H12AffineFastState.Bounded env43640 := by
  intro p hp
  have h : env43640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43639_43640 : H12AffineEnvironment.transform 13 5156 env43639 = env43640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env43639 == env43640) = true)

theorem identity43640 : scanCanonicalize (H12AffineFastState.compose env43640 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43640 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43641 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5156,33,34,5141,2049,1025,32,4144,0,49,2,9,16,2048,5173,4128,2081,1056,33,5,1,5157,512]

theorem envBound43641 : H12AffineFastState.Bounded env43641 := by
  intro p hp
  have h : env43641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43640_43641 : H12AffineEnvironment.transform 7 4 env43640 = env43641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43640 == env43641) = true)

theorem identity43641 : scanCanonicalize (H12AffineFastState.compose env43641 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound43641 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43642 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,1029,8,33,33,34,16,2049,1025,32,1077,0,49,2,9,16,2048,48,1061,2081,1056,33,5,1,32,512]

theorem envBound43642 : H12AffineFastState.Bounded env43642 := by
  intro p hp
  have h : env43642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43641_43642 : H12AffineEnvironment.transform 11 1029 env43641 = env43642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env43641 == env43642) = true)

def env43643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169352,98780,8328,64,64725,163976,17664,284041,168004,411972,257,21793,46213,243603]

theorem envBound43643 : H12AffineFastState.Bounded env43643 := by
  intro p hp
  have h : env43643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43619_43643 : H12AffineEnvironment.transform 21 272513 env43619 = env43643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env43619 == env43643) = true)

theorem identity43643 : scanCanonicalize (H12AffineFastState.compose env43643 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound43643 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,58516,272513,62661,98780,8328,64,64725,57797,17664,284041,61705,272393,257,21793,46213,120542]

theorem envBound43644 : H12AffineFastState.Bounded env43644 := by
  intro p hp
  have h : env43644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43643_43644 : H12AffineEnvironment.transform 16 24909 env43643 = env43644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env43643 == env43644) = true)

def env43645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1025,32769,58516,169,62661,98780,8328,64,64725,57797,17664,32161,61705,33,257,21793,46213,120542]

theorem envBound43645 : H12AffineFastState.Bounded env43645 := by
  intro p hp
  have h : env43645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43644_43645 : H12AffineEnvironment.transform 17 10280 env43644 = env43645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43644 == env43645) = true)

theorem identity43645 : scanCanonicalize (H12AffineFastState.compose env43645 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29159) := by decide +kernel

theorem selectedBound43645 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29159,24909,10280,1025,32769,58516,169,62661,61499,8328,64,64725,57797,17664,32161,61705,33,257,21793,46213,42809]

theorem envBound43646 : H12AffineFastState.Bounded env43646 := by
  intro p hp
  have h : env43646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43645_43646 : H12AffineEnvironment.transform 15 29159 env43645 = env43646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29159 env43645 == env43646) = true)

theorem identity43646 : scanCanonicalize (H12AffineFastState.compose env43646 (packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS)) = affineNative (2^(12+1) ^^^ 1505) := by decide +kernel

theorem selectedBound43646 : packedSelected [3,5,8,11,15,18,19,23,26,28,32,38] rootPS < 2^1333 := by decide +kernel

def env43647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,16384,32768,21510,17580,3529,1025,32769,49525,169,53540,54746,1385,64,55604,50212,17664,22592,54504,33,257,21793,37220,33496]

theorem envBound43647 : H12AffineFastState.Bounded env43647 := by
  intro p hp
  have h : env43647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43646_43647 : H12AffineEnvironment.transform 12 1505 env43646 = env43647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1505 env43646 == env43647) = true)

theorem identity43647 : scanCanonicalize (H12AffineFastState.compose env43647 (packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 4540) := by decide +kernel

theorem selectedBound43647 : packedSelected [0,1,2,6,7,8,11,16,17,19,23] rootPS < 2^1333 := by decide +kernel

def env43648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1505,4540,32768,1466,5392,3529,1025,32769,37065,169,32920,33894,1385,64,34952,38296,5308,2556,34132,33,257,1181,37220,33496]

theorem envBound43648 : H12AffineFastState.Bounded env43648 := by
  intro p hp
  have h : env43648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43647_43648 : H12AffineEnvironment.transform 13 4540 env43647 = env43648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4540 env43647 == env43648) = true)

theorem identity43648 : scanCanonicalize (H12AffineFastState.compose env43648 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound43648 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43649 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,4096,268,4540,32768,343,4605,2340,236,32769,37065,169,32920,32907,388,64,34952,37237,4177,2556,33209,33,257,112,37220,33496]

theorem envBound43649 : H12AffineFastState.Bounded env43649 := by
  intro p hp
  have h : env43649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43648_43649 : H12AffineEnvironment.transform 9 237 env43648 = env43649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env43648 == env43649) = true)

theorem identity43649 : scanCanonicalize (H12AffineFastState.compose env43649 (packedSelected [0,1,7,8,10,12,17] rootPS)) = affineNative (2^(10+1) ^^^ 492) := by decide +kernel

theorem selectedBound43649 : packedSelected [0,1,7,8,10,12,17] rootPS < 2^1333 := by decide +kernel

def env43650 : List Nat := [2,4,8,16,32,64,128,256,512,237,492,4096,268,4540,32768,343,4605,200,236,32769,37065,169,32920,32907,388,64,33124,37237,4177,16,33209,33,257,112,37220,33496]

theorem envBound43650 : H12AffineFastState.Bounded env43650 := by
  intro p hp
  have h : env43650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43649_43650 : H12AffineEnvironment.transform 10 492 env43649 = env43650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 492 env43649 == env43650) = true)

theorem identity43650 : scanCanonicalize (H12AffineFastState.compose env43650 (packedSelected [0,1,3,5,7,8,11,15,18] rootPS)) = affineNative (2^(14+1) ^^^ 509) := by decide +kernel

theorem selectedBound43650 : packedSelected [0,1,3,5,7,8,11,15,18] rootPS < 2^1333 := by decide +kernel

def env43651 : List Nat := [2,4,8,16,32,64,128,256,512,237,492,4096,268,4540,509,343,4605,200,236,508,4404,169,357,374,388,64,153,4232,4177,16,68,33,257,112,4249,805]

theorem envBound43651 : H12AffineFastState.Bounded env43651 := by
  intro p hp
  have h : env43651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43650_43651 : H12AffineEnvironment.transform 14 509 env43650 = env43651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 509 env43650 == env43651) = true)

theorem identity43651 : scanCanonicalize (H12AffineFastState.compose env43651 (packedSelected [0,1,2,3,5,6,7,8,10,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43651 : packedSelected [0,1,2,3,5,6,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env43652 : List Nat := [2,4,8,16,32,64,8,256,512,101,356,4096,268,4404,373,343,4469,64,100,372,4404,33,357,374,268,64,17,4096,4177,16,68,33,257,112,4113,805]

theorem envBound43652 : H12AffineFastState.Bounded env43652 := by
  intro p hp
  have h : env43652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43651_43652 : H12AffineEnvironment.transform 6 8 env43651 = env43652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43651 == env43652) = true)

theorem identity43652 : scanCanonicalize (H12AffineFastState.compose env43652 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43652 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env43653 : List Nat := [2,4,8,16,32,64,8,117,512,101,17,4096,121,4161,0,34,4096,64,100,1,4161,33,16,3,121,64,17,4096,4177,16,68,33,116,112,4113,592]

theorem envBound43653 : H12AffineFastState.Bounded env43653 := by
  intro p hp
  have h : env43653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43652_43653 : H12AffineEnvironment.transform 7 117 env43652 = env43653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43652 == env43653) = true)

theorem identity43653 : scanCanonicalize (H12AffineFastState.compose env43653 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43653 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env43654 : List Nat := [2,4,8,16,32,16,8,37,512,53,17,4096,41,4113,0,34,4096,16,52,1,4113,33,16,3,41,16,17,4096,4097,16,20,33,36,32,4113,512]

theorem envBound43654 : H12AffineFastState.Bounded env43654 := by
  intro p hp
  have h : env43654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43653_43654 : H12AffineEnvironment.transform 5 16 env43653 = env43654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43653 == env43654) = true)

theorem identity43654 : scanCanonicalize (H12AffineFastState.compose env43654 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound43654 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43655 : List Nat := [2,4,8,16,32,16,8,37,20,53,17,4096,41,4113,0,34,4096,16,52,1,4113,33,16,3,41,16,17,4096,4097,16,20,33,36,32,4113,20]

theorem envBound43655 : H12AffineFastState.Bounded env43655 := by
  intro p hp
  have h : env43655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43654_43655 : H12AffineEnvironment.transform 8 20 env43654 = env43655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env43654 == env43655) = true)

theorem identity43655 : scanCanonicalize (H12AffineFastState.compose env43655 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43655 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43656 : List Nat := [1,4,8,16,32,16,8,37,20,53,17,4096,41,4113,0,33,4096,16,52,1,4113,33,16,0,41,16,17,4096,4097,16,20,33,36,32,4113,20]

theorem envBound43656 : H12AffineFastState.Bounded env43656 := by
  intro p hp
  have h : env43656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43655_43656 : H12AffineEnvironment.transform 0 1 env43655 = env43656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43655 == env43656) = true)

theorem identity43656 : scanCanonicalize (H12AffineFastState.compose env43656 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43656 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43657 : List Nat := [1,4,8,16,32,16,8,37,20,53,17,1,41,16,0,33,1,16,52,1,16,33,16,0,41,16,17,1,0,16,20,33,36,32,16,20]

theorem envBound43657 : H12AffineFastState.Bounded env43657 := by
  intro p hp
  have h : env43657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43656_43657 : H12AffineEnvironment.transform 11 1 env43656 = env43657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43656 == env43657) = true)

theorem identity43657 : scanCanonicalize (H12AffineFastState.compose env43657 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 25) := by decide +kernel

theorem selectedBound43657 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43658 : List Nat := [1,4,8,16,25,16,8,28,20,12,17,1,16,16,0,24,1,16,13,1,16,24,16,0,16,16,17,1,0,16,20,24,29,25,16,20]

theorem envBound43658 : H12AffineFastState.Bounded env43658 := by
  intro p hp
  have h : env43658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43657_43658 : H12AffineEnvironment.transform 4 25 env43657 = env43658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 25 env43657 == env43658) = true)

theorem identity43658 : scanCanonicalize (H12AffineFastState.compose env43658 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound43658 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env43659 : List Nat := [1,4,8,5,12,5,8,9,1,12,4,1,5,5,0,13,1,5,13,1,5,13,5,0,5,5,4,1,0,5,1,13,8,12,5,1]

theorem envBound43659 : H12AffineFastState.Bounded env43659 := by
  intro p hp
  have h : env43659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43658_43659 : H12AffineEnvironment.transform 3 5 env43658 = env43659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env43658 == env43659) = true)

theorem identity43659 : scanCanonicalize (H12AffineFastState.compose env43659 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound43659 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43660 : List Nat := [1,4,4,5,0,5,4,5,1,0,4,1,5,5,0,1,1,5,1,1,5,1,5,0,5,5,4,1,0,5,1,1,4,0,5,1]

theorem envBound43660 : H12AffineFastState.Bounded env43660 := by
  intro p hp
  have h : env43660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43659_43660 : H12AffineEnvironment.transform 2 4 env43659 = env43660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env43659 == env43660) = true)

def env43661 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1025,32769,58516,168,62661,98780,8328,64,64725,57797,17664,32160,61705,32,257,21793,46213,120542]

theorem envBound43661 : H12AffineFastState.Bounded env43661 := by
  intro p hp
  have h : env43661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43644_43661 : H12AffineEnvironment.transform 17 10281 env43644 = env43661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43644 == env43661) = true)

theorem identity43661 : scanCanonicalize (H12AffineFastState.compose env43661 (packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound43661 : packedSelected [1,2,3,5,6,7,9,10,11,18,19,20,22,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43662 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21726,24909,10281,1025,32769,58516,168,62661,54530,8328,64,64725,57797,17664,32160,61705,32,257,21793,46213,33280]

theorem envBound43662 : H12AffineFastState.Bounded env43662 := by
  intro p hp
  have h : env43662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43661_43662 : H12AffineEnvironment.transform 15 21726 env43661 = env43662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env43661 == env43662) = true)

theorem identity43662 : scanCanonicalize (H12AffineFastState.compose env43662 (packedSelected [0,2,6,7,8,10,11,16,17,18,28] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound43662 : packedSelected [0,2,6,7,8,10,11,16,17,18,28] rootPS < 2^1333 := by decide +kernel

def env43663 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,21726,24909,10281,1025,21761,12692,168,8645,2,8328,64,10709,13509,17664,32160,9225,32,257,21793,24965,22272]

theorem envBound43663 : H12AffineFastState.Bounded env43663 := by
  intro p hp
  have h : env43663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43662_43663 : H12AffineEnvironment.transform 14 21760 env43662 = env43663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env43662 == env43663) = true)

theorem identity43663 : scanCanonicalize (H12AffineFastState.compose env43663 (packedSelected [3,5,10,16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound43663 : packedSelected [3,5,10,16,17,20] rootPS < 2^1333 := by decide +kernel

def env43664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5513,137,343,13508,10281,1025,136,12692,168,8645,2,8328,64,10709,13509,4233,10281,9225,32,257,168,13324,649]

theorem envBound43664 : H12AffineFastState.Bounded env43664 := by
  intro p hp
  have h : env43664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43663_43664 : H12AffineEnvironment.transform 13 5513 env43663 = env43664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env43663 == env43664) = true)

theorem identity43664 : scanCanonicalize (H12AffineFastState.compose env43664 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound43664 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5513,137,343,5392,2557,1025,136,4160,168,17,2,348,64,2049,5393,4233,2557,1501,32,257,168,5592,649]

theorem envBound43665 : H12AffineFastState.Bounded env43665 := by
  intro p hp
  have h : env43665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43664_43665 : H12AffineEnvironment.transform 12 468 env43664 = env43665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env43664 == env43665) = true)

theorem identity43665 : scanCanonicalize (H12AffineFastState.compose env43665 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2184) := by decide +kernel

theorem selectedBound43665 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2184,468,3329,137,343,3480,2557,1025,136,2248,168,17,2,348,64,2049,3481,2049,2557,1501,32,257,168,3408,649]

theorem envBound43666 : H12AffineFastState.Bounded env43666 := by
  intro p hp
  have h : env43666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43665_43666 : H12AffineEnvironment.transform 11 2184 env43665 = env43666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2184 env43665 == env43666) = true)

theorem identity43666 : scanCanonicalize (H12AffineFastState.compose env43666 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43666 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env43667 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2184,389,3329,137,262,3480,2476,1025,136,2201,168,17,2,269,17,2049,3481,2049,2476,1420,32,257,168,3329,649]

theorem envBound43667 : H12AffineFastState.Bounded env43667 := by
  intro p hp
  have h : env43667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43666_43667 : H12AffineEnvironment.transform 5 17 env43666 = env43667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43666 == env43667) = true)

theorem identity43667 : scanCanonicalize (H12AffineFastState.compose env43667 (packedSelected [1,2,4,6,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound43667 : packedSelected [1,2,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env43668 : List Nat := [2,4,8,16,32,17,128,256,512,189,2048,2184,389,2492,137,262,2341,2476,188,136,2201,168,17,2,269,17,2049,2340,2049,2476,305,32,257,168,2492,649]

theorem envBound43668 : H12AffineFastState.Bounded env43668 := by
  intro p hp
  have h : env43668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43667_43668 : H12AffineEnvironment.transform 9 189 env43667 = env43668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env43667 == env43668) = true)

theorem identity43668 : scanCanonicalize (H12AffineFastState.compose env43668 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43668 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43669 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2049,268,2357,0,262,2341,2341,53,1,2064,33,17,2,269,17,2049,2340,2049,2341,305,32,257,33,2357,512]

theorem envBound43669 : H12AffineFastState.Bounded env43669 := by
  intro p hp
  have h : env43669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43668_43669 : H12AffineEnvironment.transform 6 9 env43668 = env43669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43668 == env43669) = true)

theorem identity43669 : scanCanonicalize (H12AffineFastState.compose env43669 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43669 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43670 : List Nat := [2,4,8,16,17,17,9,256,512,5,2048,2049,268,2308,0,262,2324,2324,4,1,2064,16,17,2,269,17,2049,2325,2049,2324,256,17,257,16,2308,512]

theorem envBound43670 : H12AffineFastState.Bounded env43670 := by
  intro p hp
  have h : env43670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43669_43670 : H12AffineEnvironment.transform 4 17 env43669 = env43670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43669 == env43670) = true)

theorem identity43670 : scanCanonicalize (H12AffineFastState.compose env43670 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43670 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43671 : List Nat := [2,4,3,16,17,17,2,256,512,5,2048,2049,263,2308,0,262,2324,2324,4,1,2064,16,17,2,262,17,2049,2325,2049,2324,256,17,257,16,2308,512]

theorem envBound43671 : H12AffineFastState.Bounded env43671 := by
  intro p hp
  have h : env43671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43670_43671 : H12AffineEnvironment.transform 2 3 env43670 = env43671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43670 == env43671) = true)

theorem identity43671 : scanCanonicalize (H12AffineFastState.compose env43671 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound43671 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43672 : List Nat := [2,4,3,2,3,3,2,256,512,5,2048,2049,263,2308,0,262,2310,2310,4,1,2050,2,3,2,262,3,2049,2311,2049,2310,256,3,257,2,2308,512]

theorem envBound43672 : H12AffineFastState.Bounded env43672 := by
  intro p hp
  have h : env43672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43671_43672 : H12AffineEnvironment.transform 3 2 env43671 = env43672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env43671 == env43672) = true)

theorem identity43672 : scanCanonicalize (H12AffineFastState.compose env43672 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43672 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43673 : List Nat := [2,4,3,2,3,3,2,4,512,5,2048,2049,3,2048,0,2,2050,2050,4,1,2050,2,3,2,2,3,2049,2051,2049,2050,4,3,5,2,2048,512]

theorem envBound43673 : H12AffineFastState.Bounded env43673 := by
  intro p hp
  have h : env43673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43672_43673 : H12AffineEnvironment.transform 7 4 env43672 = env43673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43672 == env43673) = true)

theorem identity43673 : scanCanonicalize (H12AffineFastState.compose env43673 (packedSelected [0,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43673 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env43674 : List Nat := [1,4,0,1,0,0,1,4,512,5,2048,2049,0,2048,0,1,2049,2049,4,1,2049,1,0,1,1,0,2049,2048,2049,2049,4,0,5,1,2048,512]

theorem envBound43674 : H12AffineFastState.Bounded env43674 := by
  intro p hp
  have h : env43674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43673_43674 : H12AffineEnvironment.transform 0 1 env43673 = env43674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43673 == env43674) = true)

theorem identity43674 : scanCanonicalize (H12AffineFastState.compose env43674 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound43674 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43675 : List Nat := [1,4,0,1,0,0,1,4,4,5,2048,2049,0,2048,0,1,2049,2049,4,1,2049,1,0,1,1,0,2049,2048,2049,2049,4,0,5,1,2048,4]

theorem envBound43675 : H12AffineFastState.Bounded env43675 := by
  intro p hp
  have h : env43675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43674_43675 : H12AffineEnvironment.transform 8 4 env43674 = env43675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env43674 == env43675) = true)

def env43676 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169353,98781,8328,64,4510804,163977,17665,284040,168004,4350404,257,21793,46213,243603]

theorem envBound43676 : H12AffineFastState.Bounded env43676 := by
  intro p hp
  have h : env43676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43618_43676 : H12AffineEnvironment.transform 22 169353 env43618 = env43676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env43618 == env43676) = true)

def env43677 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169353,98781,8328,64,64724,163977,17665,284040,168004,411972,257,21793,46213,243603]

theorem envBound43677 : H12AffineFastState.Bounded env43677 := by
  intro p hp
  have h : env43677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43676_43677 : H12AffineEnvironment.transform 21 272512 env43676 = env43677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env43676 == env43677) = true)

def env43678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272392,169217,98645,8192,64,64604,163841,17665,283904,168004,411972,257,21793,46093,243483]

theorem envBound43678 : H12AffineFastState.Bounded env43678 := by
  intro p hp
  have h : env43678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43677_43678 : H12AffineEnvironment.transform 6 8 env43677 = env43678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43677 == env43678) = true)

def env43679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272392,17,98645,8192,64,64604,5393,17665,283904,1364,318548,257,21793,46093,74251]

theorem envBound43679 : H12AffineFastState.Bounded env43679 := by
  intro p hp
  have h : env43679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43678_43679 : H12AffineEnvironment.transform 16 38160 env43678 = env43679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env43678 == env43679) = true)

theorem identity43679 : scanCanonicalize (H12AffineFastState.compose env43679 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43679 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43680 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4161,33,17,98645,8192,64,64604,5393,17665,32041,1364,62589,257,21793,46093,74251]

theorem envBound43680 : H12AffineFastState.Bounded env43680 := by
  intro p hp
  have h : env43680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43679_43680 : H12AffineEnvironment.transform 17 10281 env43679 = env43680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43679 == env43680) = true)

theorem identity43680 : scanCanonicalize (H12AffineFastState.compose env43680 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound43680 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env43681 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,24909,10281,1025,29788,4161,33,17,95496,8192,64,2049,5393,17665,32041,1364,32,257,21793,16464,74251]

theorem envBound43681 : H12AffineFastState.Bounded env43681 := by
  intro p hp
  have h : env43681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43680_43681 : H12AffineEnvironment.transform 14 29789 env43680 = env43681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env43680 == env43681) = true)

theorem identity43681 : scanCanonicalize (H12AffineFastState.compose env43681 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound43681 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env43682 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,343,24909,10281,1025,29788,4161,33,17,29791,8192,64,2049,5393,17665,32041,1364,32,257,21793,16464,9052]

theorem envBound43682 : H12AffineFastState.Bounded env43682 := by
  intro p hp
  have h : env43682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43681_43682 : H12AffineEnvironment.transform 15 343 env43681 = env43682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env43681 == env43682) = true)

theorem identity43682 : scanCanonicalize (H12AffineFastState.compose env43682 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound43682 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env43683 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,343,5392,10281,1025,1,4161,33,17,2,8192,64,2049,5393,12636,2420,1364,32,257,8572,13325,9052]

theorem envBound43683 : H12AffineFastState.Bounded env43683 := by
  intro p hp
  have h : env43683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43682_43683 : H12AffineEnvironment.transform 13 13405 env43682 = env43683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env43682 == env43683) = true)

theorem identity43683 : scanCanonicalize (H12AffineFastState.compose env43683 (packedSelected [0,1,3,5,6,7,8,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound43683 : packedSelected [0,1,3,5,6,7,8,14,15] rootPS < 2^1333 := by decide +kernel

def env43684 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,4096,8192,13405,0,343,5392,8201,1025,1,4161,33,17,2,8192,64,33,5393,12636,340,1364,32,257,8572,13325,9052]

theorem envBound43684 : H12AffineFastState.Bounded env43684 := by
  intro p hp
  have h : env43684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43683_43684 : H12AffineEnvironment.transform 10 32 env43683 = env43684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env43683 == env43684) = true)

theorem identity43684 : scanCanonicalize (H12AffineFastState.compose env43684 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43684 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env43685 : List Nat := [2,4,8,16,32,64,8,256,512,1024,32,4096,348,5377,0,343,5392,341,1025,1,4161,33,17,2,348,64,33,5393,4096,340,1364,32,257,32,5457,512]

theorem envBound43685 : H12AffineFastState.Bounded env43685 := by
  intro p hp
  have h : env43685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43684_43685 : H12AffineEnvironment.transform 12 348 env43684 = env43685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43684 == env43685) = true)

theorem identity43685 : scanCanonicalize (H12AffineFastState.compose env43685 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 795) := by decide +kernel

theorem selectedBound43685 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43686 : List Nat := [2,4,8,16,32,64,8,256,512,795,32,4096,348,4634,0,343,4619,341,794,1,4161,33,17,2,348,64,33,4618,4096,340,591,32,257,32,4682,512]

theorem envBound43686 : H12AffineFastState.Bounded env43686 := by
  intro p hp
  have h : env43686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43685_43686 : H12AffineEnvironment.transform 9 795 env43685 = env43686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 795 env43685 == env43686) = true)

theorem identity43686 : scanCanonicalize (H12AffineFastState.compose env43686 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound43686 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43687 : List Nat := [2,4,8,16,32,49,8,256,512,795,32,4096,301,4634,0,294,4619,292,794,1,4144,33,17,2,301,49,33,4618,4096,293,574,32,257,32,4667,512]

theorem envBound43687 : H12AffineFastState.Bounded env43687 := by
  intro p hp
  have h : env43687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43686_43687 : H12AffineEnvironment.transform 5 49 env43686 = env43687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env43686 == env43687) = true)

theorem identity43687 : scanCanonicalize (H12AffineFastState.compose env43687 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound43687 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43688 : List Nat := [2,4,8,16,32,49,8,256,303,52,32,4096,301,4405,0,294,4388,292,53,1,4144,33,17,2,301,49,33,4389,4096,293,273,32,257,32,4372,303]

theorem envBound43688 : H12AffineFastState.Bounded env43688 := by
  intro p hp
  have h : env43688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43687_43688 : H12AffineEnvironment.transform 8 303 env43687 = env43688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env43687 == env43688) = true)

theorem identity43688 : scanCanonicalize (H12AffineFastState.compose env43688 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43688 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43689 : List Nat := [2,4,8,16,32,49,8,37,10,52,32,4096,8,4112,0,3,4097,1,53,1,4144,33,17,2,8,49,33,4096,4096,0,52,32,36,32,4145,10]

theorem envBound43689 : H12AffineFastState.Bounded env43689 := by
  intro p hp
  have h : env43689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43688_43689 : H12AffineEnvironment.transform 7 37 env43688 = env43689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43688 == env43689) = true)

def env43690 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272392,16,98645,8192,64,64604,5392,17665,283904,1365,318549,257,21793,46093,74250]

theorem envBound43690 : H12AffineFastState.Bounded env43690 := by
  intro p hp
  have h : env43690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43678_43690 : H12AffineEnvironment.transform 16 38161 env43678 = env43690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env43678 == env43690) = true)

theorem identity43690 : scanCanonicalize (H12AffineFastState.compose env43690 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43690 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env43691 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4160,272392,16,41310,8192,64,64604,5392,17665,283904,1365,318549,257,21793,46093,513]

theorem envBound43691 : H12AffineFastState.Bounded env43691 := by
  intro p hp
  have h : env43691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43690_43691 : H12AffineEnvironment.transform 15 8203 env43690 = env43691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43690 == env43691) = true)

theorem identity43691 : scanCanonicalize (H12AffineFastState.compose env43691 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound43691 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43692 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8203,16401,262144,1025,21761,4160,272392,16,29790,8192,64,10588,5392,17665,283904,1365,264533,257,21793,24845,513]

theorem envBound43692 : H12AffineFastState.Bounded env43692 := by
  intro p hp
  have h : env43692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43691_43692 : H12AffineEnvironment.transform 14 21760 env43691 = env43692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env43691 == env43692) = true)

theorem identity43692 : scanCanonicalize (H12AffineFastState.compose env43692 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound43692 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43693 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,8203,13389,262144,1025,8541,4160,272392,16,2,8192,64,10588,5392,12637,270684,1365,264533,257,8573,5457,513]

theorem envBound43693 : H12AffineFastState.Bounded env43693 := by
  intro p hp
  have h : env43693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43692_43693 : H12AffineEnvironment.transform 13 13404 env43692 = env43693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env43692 == env43693) = true)

theorem identity43693 : scanCanonicalize (H12AffineFastState.compose env43693 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43693 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43694 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5457,81,262,5440,262144,1025,80,4160,264453,16,2,269,64,2129,5392,4176,262225,1365,264533,257,112,5457,513]

theorem envBound43694 : H12AffineFastState.Bounded env43694 := by
  intro p hp
  have h : env43694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43693_43694 : H12AffineEnvironment.transform 12 269 env43693 = env43694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43693 == env43694) = true)

theorem identity43694 : scanCanonicalize (H12AffineFastState.compose env43694 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43694 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43695 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,41,5237,81,34,5220,262144,1025,80,4160,264225,16,2,41,64,2129,5172,4176,262225,1137,264305,37,112,5237,513]

theorem envBound43695 : H12AffineFastState.Bounded env43695 := by
  intro p hp
  have h : env43695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43694_43695 : H12AffineEnvironment.transform 7 36 env43694 = env43695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43694 == env43695) = true)

theorem identity43695 : scanCanonicalize (H12AffineFastState.compose env43695 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43695 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43696 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,0,34,5173,262144,1025,1,4113,264225,16,2,41,17,2048,5172,4097,262144,1056,264224,37,33,5156,513]

theorem envBound43696 : H12AffineFastState.Bounded env43696 := by
  intro p hp
  have h : env43696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43695_43696 : H12AffineEnvironment.transform 5 17 env43695 = env43696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43695 == env43696) = true)

theorem identity43696 : scanCanonicalize (H12AffineFastState.compose env43696 (packedSelected [0,4] rootPS)) = affineNative (2^(17+1) ^^^ 2048) := by decide +kernel

theorem selectedBound43696 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43697 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5156,0,34,5173,2048,1025,1,4113,33,16,2,41,17,2048,5172,4097,2048,1056,32,37,33,5156,513]

theorem envBound43697 : H12AffineFastState.Bounded env43697 := by
  intro p hp
  have h : env43697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43696_43697 : H12AffineEnvironment.transform 17 2048 env43696 = env43697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2048 env43696 == env43697) = true)

def env43698 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1044,0,34,1029,2048,1025,1,33,33,16,2,41,17,2048,1028,49,2048,1056,32,37,33,1044,513]

theorem envBound43698 : H12AffineFastState.Bounded env43698 := by
  intro p hp
  have h : env43698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43697_43698 : H12AffineEnvironment.transform 11 48 env43697 = env43698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43697 == env43698) = true)

theorem identity43698 : scanCanonicalize (H12AffineFastState.compose env43698 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound43698 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43699 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1077,48,41,1044,0,34,1029,1077,1025,1,33,33,16,2,41,17,1077,1028,49,1077,1056,32,37,33,1044,513]

theorem envBound43699 : H12AffineFastState.Bounded env43699 := by
  intro p hp
  have h : env43699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43698_43699 : H12AffineEnvironment.transform 10 1077 env43698 = env43699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env43698 == env43699) = true)

def env43700 : List Nat := [2,4,8,16,32,17,8,36,512,52,1,48,41,32,0,34,49,1,53,1,33,33,16,2,41,17,1,48,49,1,20,32,37,33,32,513]

theorem envBound43700 : H12AffineFastState.Bounded env43700 := by
  intro p hp
  have h : env43700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43699_43700 : H12AffineEnvironment.transform 9 52 env43699 = env43700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43699 == env43700) = true)

theorem identity43700 : scanCanonicalize (H12AffineFastState.compose env43700 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43700 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43701 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,9,0,0,2,17,1,21,1,1,1,16,2,9,17,1,16,17,1,20,0,5,1,0,513]

theorem envBound43701 : H12AffineFastState.Bounded env43701 := by
  intro p hp
  have h : env43701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43700_43701 : H12AffineEnvironment.transform 4 0 env43700 = env43701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43700 == env43701) = true)

def leafEnv43701 : List Nat := [2,4,8,16,0,17,8,4,512,20,1,16,9,0,0,2,17,1,21,1,1,1,16,2,21,9,1,17,1,16,17,1,20,0,5,1,5,2,0,513,1,1,0]

def active43701 : List Nat := [0,1,2,3,8]

def tree43701 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43701 : H12WitnessSearch.Good tree43701 := H12GlobalWitnessIndex.good

theorem leafIdentity43701 : H12AffineFastState.composeSystem env43701 rootObs = leafEnv43701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43701 rootObs == leafEnv43701) = true)

theorem terminalChecked43701 : H12PackedTerminal.terminalCheckFast leafEnv43701 active43701 tree43701 = true := by decide +kernel

def env43702 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,33,0,34,48,0,52,1,33,33,16,2,41,17,0,49,49,0,21,32,37,33,33,513]

theorem envBound43702 : H12AffineFastState.Bounded env43702 := by
  intro p hp
  have h : env43702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43699_43702 : H12AffineEnvironment.transform 9 53 env43699 = env43702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43699 == env43702) = true)

theorem identity43702 : scanCanonicalize (H12AffineFastState.compose env43702 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound43702 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43703 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,41,33,0,34,48,0,52,1,33,33,16,2,41,17,0,49,49,0,21,32,37,33,33,11]

theorem envBound43703 : H12AffineFastState.Bounded env43703 := by
  intro p hp
  have h : env43703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43702_43703 : H12AffineEnvironment.transform 8 10 env43702 = env43703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env43702 == env43703) = true)

def leafEnv43703 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,48,41,33,0,34,48,0,52,1,33,33,16,2,20,41,1,17,0,49,49,0,21,32,37,33,5,34,33,11,1,33,0]

def active43703 : List Nat := [0,1,2,3,4]

def tree43703 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43703 : H12WitnessSearch.Good tree43703 := H12GlobalWitnessIndex.good

theorem leafIdentity43703 : H12AffineFastState.composeSystem env43703 rootObs = leafEnv43703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43703 rootObs == leafEnv43703) = true)

theorem terminalChecked43703 : H12PackedTerminal.terminalCheckFast leafEnv43703 active43703 tree43703 = true := by decide +kernel

def env43704 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1045,0,34,1028,2048,1025,1,32,33,16,2,41,17,2048,1029,48,2048,1056,32,37,33,1045,513]

theorem envBound43704 : H12AffineFastState.Bounded env43704 := by
  intro p hp
  have h : env43704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43697_43704 : H12AffineEnvironment.transform 11 49 env43697 = env43704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43697 == env43704) = true)

theorem identity43704 : scanCanonicalize (H12AffineFastState.compose env43704 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound43704 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43705 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,49,41,1045,0,34,1028,0,1025,1,32,33,16,2,41,17,0,1029,48,0,1056,32,37,33,1045,513]

theorem envBound43705 : H12AffineFastState.Bounded env43705 := by
  intro p hp
  have h : env43705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43704_43705 : H12AffineEnvironment.transform 10 0 env43704 = env43705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env43704 == env43705) = true)

def env43706 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,33,0,34,48,0,53,1,32,33,16,2,41,17,0,49,48,0,20,32,37,33,33,513]

theorem envBound43706 : H12AffineFastState.Bounded env43706 := by
  intro p hp
  have h : env43706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43705_43706 : H12AffineEnvironment.transform 9 52 env43705 = env43706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43705 == env43706) = true)

theorem identity43706 : scanCanonicalize (H12AffineFastState.compose env43706 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43706 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43707 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,9,1,0,2,16,0,21,1,0,1,16,2,9,17,0,17,16,0,20,0,5,1,1,513]

theorem envBound43707 : H12AffineFastState.Bounded env43707 := by
  intro p hp
  have h : env43707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43706_43707 : H12AffineEnvironment.transform 4 0 env43706 = env43707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43706 == env43707) = true)

def leafEnv43707 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,17,9,1,0,2,16,0,21,1,0,1,16,2,21,9,1,17,0,17,16,0,20,0,5,1,5,2,1,513,1,0,0]

def active43707 : List Nat := [0,1,2,3,8]

def tree43707 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43707 : H12WitnessSearch.Good tree43707 := H12GlobalWitnessIndex.good

theorem leafIdentity43707 : H12AffineFastState.composeSystem env43707 rootObs = leafEnv43707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43707 rootObs == leafEnv43707) = true)

theorem terminalChecked43707 : H12PackedTerminal.terminalCheckFast leafEnv43707 active43707 tree43707 = true := by decide +kernel

def env43708 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,49,41,32,0,34,49,0,52,1,32,33,16,2,41,17,0,48,48,0,21,32,37,33,32,513]

theorem envBound43708 : H12AffineFastState.Bounded env43708 := by
  intro p hp
  have h : env43708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43705_43708 : H12AffineEnvironment.transform 9 53 env43705 = env43708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43705 == env43708) = true)

theorem identity43708 : scanCanonicalize (H12AffineFastState.compose env43708 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound43708 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43709 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,41,32,0,34,49,0,52,1,32,33,16,2,41,17,0,48,48,0,21,32,37,33,32,11]

theorem envBound43709 : H12AffineFastState.Bounded env43709 := by
  intro p hp
  have h : env43709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43708_43709 : H12AffineEnvironment.transform 8 10 env43708 = env43709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env43708 == env43709) = true)

def leafEnv43709 : List Nat := [2,4,8,16,32,17,8,36,10,53,0,49,41,32,0,34,49,0,52,1,32,33,16,2,20,41,1,17,0,48,48,0,21,32,37,33,5,34,32,11,1,32,0]

def active43709 : List Nat := [0,1,2,3,4]

def tree43709 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43709 : H12WitnessSearch.Good tree43709 := H12GlobalWitnessIndex.good

theorem leafIdentity43709 : H12AffineFastState.composeSystem env43709 rootObs = leafEnv43709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43709 rootObs == leafEnv43709) = true)

theorem terminalChecked43709 : H12PackedTerminal.terminalCheckFast leafEnv43709 active43709 tree43709 = true := by decide +kernel

def env43710 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272393,169216,98644,8193,64,64605,163840,17665,283905,168004,411972,257,21793,46092,243482]

theorem envBound43710 : H12AffineFastState.Bounded env43710 := by
  intro p hp
  have h : env43710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43677_43710 : H12AffineEnvironment.transform 6 9 env43677 = env43710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43677 == env43710) = true)

theorem identity43710 : scanCanonicalize (H12AffineFastState.compose env43710 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound43710 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env43711 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,131072,262144,1025,32769,165200,272393,169216,29790,8193,64,64605,163840,17665,283905,168004,411972,257,21793,46092,147984]

theorem envBound43711 : H12AffineFastState.Bounded env43711 := by
  intro p hp
  have h : env43711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43710_43711 : H12AffineEnvironment.transform 15 62730 env43710 = env43711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env43710 == env43711) = true)

theorem identity43711 : scanCanonicalize (H12AffineFastState.compose env43711 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound43711 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43712 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,57677,262144,1025,32769,25629,272393,29773,29790,8193,64,64605,24909,17665,283905,28937,305161,257,21793,46092,41821]

theorem envBound43712 : H12AffineFastState.Bounded env43712 := by
  intro p hp
  have h : env43712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43711_43712 : H12AffineEnvironment.transform 16 57677 env43711 = env43712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env43711 == env43712) = true)

theorem identity43712 : scanCanonicalize (H12AffineFastState.compose env43712 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43712 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env43713 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21590,16401,262144,1025,8541,25629,272393,29773,29790,8193,64,23809,24909,17665,283905,28937,264533,257,21793,5456,513]

theorem envBound43713 : H12AffineFastState.Bounded env43713 := by
  intro p hp
  have h : env43713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43712_43713 : H12AffineEnvironment.transform 14 8540 env43712 = env43713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43712 == env43713) = true)

theorem identity43713 : scanCanonicalize (H12AffineFastState.compose env43713 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound43713 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43714 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,21590,16401,11576,1025,8541,25629,1329,29773,29790,8193,64,23809,24909,17665,30777,28937,9325,257,21793,5456,513]

theorem envBound43714 : H12AffineFastState.Bounded env43714 := by
  intro p hp
  have h : env43714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43713_43714 : H12AffineEnvironment.transform 17 11576 env43713 = env43714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env43713 == env43714) = true)

theorem identity43714 : scanCanonicalize (H12AffineFastState.compose env43714 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound43714 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env43715 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8203,13388,11576,1025,8541,4160,1329,16,3,8193,64,10588,5392,12636,3172,1364,9325,257,8572,5456,513]

theorem envBound43715 : H12AffineFastState.Bounded env43715 := by
  intro p hp
  have h : env43715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43714_43715 : H12AffineEnvironment.transform 13 13405 env43714 = env43715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env43714 == env43715) = true)

theorem identity43715 : scanCanonicalize (H12AffineFastState.compose env43715 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound43715 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43716 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1384,4405,1076,1379,4388,2128,1025,1077,4160,1329,16,3,1385,64,3124,5392,5172,3172,1364,261,257,1044,5456,513]

theorem envBound43716 : H12AffineFastState.Bounded env43716 := by
  intro p hp
  have h : env43716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43715_43716 : H12AffineEnvironment.transform 12 1384 env43715 = env43716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env43715 == env43716) = true)

theorem identity43716 : scanCanonicalize (H12AffineFastState.compose env43716 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43716 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env43717 : List Nat := [2,4,8,16,32,64,9,256,512,53,2048,4096,349,4405,1,342,4388,2128,52,0,4160,260,16,3,348,64,2049,4389,4097,2129,353,261,257,33,4453,513]

theorem envBound43717 : H12AffineFastState.Bounded env43717 := by
  intro p hp
  have h : env43717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43716_43717 : H12AffineEnvironment.transform 9 53 env43716 = env43717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43716 == env43717) = true)

def env43718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169353,98781,8328,64,64725,163977,17665,284040,168004,411973,257,21793,46213,243603]

theorem envBound43718 : H12AffineFastState.Bounded env43718 := by
  intro p hp
  have h : env43718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43676_43718 : H12AffineEnvironment.transform 21 272513 env43676 = env43718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env43676 == env43718) = true)

theorem identity43718 : scanCanonicalize (H12AffineFastState.compose env43718 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38296) := by decide +kernel

theorem selectedBound43718 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4161,272513,17,98781,8328,64,64725,5393,17665,284040,1500,318685,257,21793,46213,74251]

theorem envBound43719 : H12AffineFastState.Bounded env43719 := by
  intro p hp
  have h : env43719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43718_43719 : H12AffineEnvironment.transform 16 38296 env43718 = env43719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env43718 == env43719) = true)

theorem identity43719 : scanCanonicalize (H12AffineFastState.compose env43719 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43719 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env43720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38296,262144,1025,32769,4161,272513,17,41431,8328,64,64725,5393,17665,284040,1500,318685,257,21793,46213,513]

theorem envBound43720 : H12AffineFastState.Bounded env43720 := by
  intro p hp
  have h : env43720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43719_43720 : H12AffineEnvironment.transform 15 8202 env43719 = env43720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43719 == env43720) = true)

def env43721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,8388608,8590421,8328,64,4510805,8393985,8573064,8830977,168005,12645452,257,21792,46212,243602]

theorem envBound43721 : H12AffineFastState.Bounded env43721 := by
  intro p hp
  have h : env43721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43617_43721 : H12AffineEnvironment.transform 23 8590421 env43617 = env43721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590421 env43617 == env43721) = true)

def env43722 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169352,98781,8328,64,4510805,163977,17664,284041,168005,4350404,257,21792,46212,243602]

theorem envBound43722 : H12AffineFastState.Bounded env43722 := by
  intro p hp
  have h : env43722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43721_43722 : H12AffineEnvironment.transform 22 169352 env43721 = env43722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env43721 == env43722) = true)

def env43723 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169352,98781,8328,64,64725,163977,17664,284041,168005,411972,257,21792,46212,243602]

theorem envBound43723 : H12AffineFastState.Bounded env43723 := by
  intro p hp
  have h : env43723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43722_43723 : H12AffineEnvironment.transform 21 272512 env43722 = env43723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env43722 == env43723) = true)

theorem identity43723 : scanCanonicalize (H12AffineFastState.compose env43723 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound43723 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43724 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,77898,272512,73755,98781,8328,64,64725,79130,17664,284041,75222,392407,257,21792,46212,513]

theorem envBound43724 : H12AffineFastState.Bounded env43724 := by
  intro p hp
  have h : env43724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43723_43724 : H12AffineEnvironment.transform 16 112019 env43723 = env43724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env43723 == env43724) = true)

def env43725 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90259,262144,1025,21761,77898,272512,73755,87261,8328,64,10709,79130,17664,284041,75222,338391,257,21792,24964,513]

theorem envBound43725 : H12AffineFastState.Bounded env43725 := by
  intro p hp
  have h : env43725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43724_43725 : H12AffineEnvironment.transform 14 21760 env43724 = env43725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env43724 == env43725) = true)

theorem identity43725 : scanCanonicalize (H12AffineFastState.compose env43725 (packedSelected [4,9,12,14,15,16,17,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound43725 : packedSelected [4,9,12,14,15,16,17,38,41] rootPS < 2^1333 := by decide +kernel

def env43726 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8322,16401,262144,1025,21761,4296,272512,153,29791,8328,64,10709,5528,17664,284041,1364,264533,257,21792,24964,513]

theorem envBound43726 : H12AffineFastState.Bounded env43726 := by
  intro p hp
  have h : env43726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43725_43726 : H12AffineEnvironment.transform 15 8322 env43725 = env43726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env43725 == env43726) = true)

theorem identity43726 : scanCanonicalize (H12AffineFastState.compose env43726 (packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43726 : packedSelected [1,2,4,5,6,8,9,11,14,17,19,20,24,26,32] rootPS < 2^1333 := by decide +kernel

def env43727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,0,8322,5393,262144,1025,1,4296,272512,153,8543,8328,64,10709,5528,4096,262281,1364,264533,257,32,13444,513]

theorem envBound43727 : H12AffineFastState.Bounded env43727 := by
  intro p hp
  have h : env43727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43726_43727 : H12AffineEnvironment.transform 13 5376 env43726 = env43727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43726 == env43727) = true)

theorem identity43727 : scanCanonicalize (H12AffineFastState.compose env43727 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound43727 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env43728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,343,5393,262144,1025,1,4296,264533,153,138,349,64,2048,5528,4096,262281,1364,264533,257,32,5457,513]

theorem envBound43728 : H12AffineFastState.Bounded env43728 := by
  intro p hp
  have h : env43728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43727_43728 : H12AffineEnvironment.transform 12 469 env43727 = env43728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env43727 == env43728) = true)

theorem identity43728 : scanCanonicalize (H12AffineFastState.compose env43728 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2556) := by decide +kernel

theorem selectedBound43728 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5376,0,343,5393,2556,1025,1,4296,169,153,138,349,64,2048,5528,4096,2421,1364,169,257,32,5457,513]

theorem envBound43729 : H12AffineFastState.Bounded env43729 := by
  intro p hp
  have h : env43729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43728_43729 : H12AffineEnvironment.transform 17 2556 env43728 = env43729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2556 env43728 == env43729) = true)

theorem identity43729 : scanCanonicalize (H12AffineFastState.compose env43729 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43729 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env43730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5393,2421,1025,1,4161,32,16,3,349,64,2048,5393,4096,2421,1364,32,257,32,5457,513]

theorem envBound43730 : H12AffineFastState.Bounded env43730 := by
  intro p hp
  have h : env43730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43729_43730 : H12AffineEnvironment.transform 6 9 env43729 = env43730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43729 == env43730) = true)

theorem identity43730 : scanCanonicalize (H12AffineFastState.compose env43730 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43730 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43731 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4112,0,343,4097,2421,273,1,4161,32,16,3,349,64,2048,4097,4096,2421,68,32,257,32,4161,513]

theorem envBound43731 : H12AffineFastState.Bounded env43731 := by
  intro p hp
  have h : env43731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43730_43731 : H12AffineEnvironment.transform 9 272 env43730 = env43731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43730 == env43731) = true)

theorem identity43731 : scanCanonicalize (H12AffineFastState.compose env43731 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43731 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43732 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4112,0,263,4097,2341,273,1,4113,32,16,3,269,16,2048,4097,4096,2341,20,32,257,32,4113,513]

theorem envBound43732 : H12AffineFastState.Bounded env43732 := by
  intro p hp
  have h : env43732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43731_43732 : H12AffineEnvironment.transform 5 16 env43731 = env43732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43731 == env43732) = true)

theorem identity43732 : scanCanonicalize (H12AffineFastState.compose env43732 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound43732 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43733 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,309,268,293,0,263,308,2341,273,1,292,32,16,3,269,16,2048,308,309,2341,20,32,257,32,292,513]

theorem envBound43733 : H12AffineFastState.Bounded env43733 := by
  intro p hp
  have h : env43733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43732_43733 : H12AffineEnvironment.transform 11 309 env43732 = env43733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env43732 == env43733) = true)

theorem identity43733 : scanCanonicalize (H12AffineFastState.compose env43733 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound43733 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43734 : List Nat := [2,4,8,16,32,16,9,256,512,272,293,309,268,293,0,263,308,0,273,1,292,32,16,3,269,16,293,308,309,0,20,32,257,32,292,513]

theorem envBound43734 : H12AffineFastState.Bounded env43734 := by
  intro p hp
  have h : env43734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43733_43734 : H12AffineEnvironment.transform 10 293 env43733 = env43734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env43733 == env43734) = true)

theorem identity43734 : scanCanonicalize (H12AffineFastState.compose env43734 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound43734 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43735 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,40,1,0,35,16,0,53,1,0,32,16,3,41,16,1,16,17,0,20,32,37,32,0,513]

theorem envBound43735 : H12AffineFastState.Bounded env43735 := by
  intro p hp
  have h : env43735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43734_43735 : H12AffineEnvironment.transform 7 36 env43734 = env43735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env43734 == env43735) = true)

theorem identity43735 : scanCanonicalize (H12AffineFastState.compose env43735 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43735 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43736 : List Nat := [2,4,8,16,1,16,9,5,512,21,1,17,9,1,0,2,16,0,20,1,0,1,16,3,8,16,1,16,17,0,20,1,4,1,0,513]

theorem envBound43736 : H12AffineFastState.Bounded env43736 := by
  intro p hp
  have h : env43736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43735_43736 : H12AffineEnvironment.transform 4 1 env43735 = env43736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43735 == env43736) = true)

theorem identity43736 : scanCanonicalize (H12AffineFastState.compose env43736 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43736 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43737 : List Nat := [2,4,8,16,1,16,9,5,17,21,1,17,9,1,0,2,16,0,20,1,0,1,16,3,8,16,1,16,17,0,20,1,4,1,0,16]

theorem envBound43737 : H12AffineFastState.Bounded env43737 := by
  intro p hp
  have h : env43737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43736_43737 : H12AffineEnvironment.transform 8 17 env43736 = env43737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43736 == env43737) = true)

def env43738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90258,262144,1025,21760,77898,272512,73755,87260,8328,64,10708,79130,17664,284041,75222,338390,257,21792,24965,513]

theorem envBound43738 : H12AffineFastState.Bounded env43738 := by
  intro p hp
  have h : env43738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43724_43738 : H12AffineEnvironment.transform 14 21761 env43724 = env43738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env43724 == env43738) = true)

theorem identity43738 : scanCanonicalize (H12AffineFastState.compose env43738 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43738 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,90138,262144,1025,21760,77898,272392,73755,87124,8192,64,10588,79130,17664,283905,75102,338270,257,21792,24845,513]

theorem envBound43739 : H12AffineFastState.Bounded env43739 := by
  intro p hp
  have h : env43739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43738_43739 : H12AffineEnvironment.transform 6 8 env43738 = env43739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43738 == env43739) = true)

theorem identity43739 : scanCanonicalize (H12AffineFastState.compose env43739 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43739 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env43740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,90138,10281,1025,21760,77898,33,73755,87124,8192,64,10588,79130,17664,32040,75102,65911,257,21792,24845,513]

theorem envBound43740 : H12AffineFastState.Bounded env43740 := by
  intro p hp
  have h : env43740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43739_43740 : H12AffineEnvironment.transform 17 10281 env43739 = env43740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43739 == env43740) = true)

theorem identity43740 : scanCanonicalize (H12AffineFastState.compose env43740 (packedSelected [0,3,5,7,10,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43740 : packedSelected [0,3,5,7,10,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env43741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,65536,82246,2421,1025,21760,69910,33,65863,87124,348,64,2048,70726,17664,23668,66562,65911,257,21792,16465,513]

theorem envBound43741 : H12AffineFastState.Bounded env43741 := by
  intro p hp
  have h : env43741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43740_43741 : H12AffineEnvironment.transform 12 348 env43740 = env43741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43740 == env43741) = true)

theorem identity43741 : scanCanonicalize (H12AffineFastState.compose env43741 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound43741 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21761,21590,5392,2421,1025,21760,17728,33,21777,2,348,64,2048,16400,17664,23668,20564,21793,257,21792,16465,513]

theorem envBound43742 : H12AffineFastState.Bounded env43742 := by
  intro p hp
  have h : env43742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43741_43742 : H12AffineEnvironment.transform 15 21590 env43741 = env43742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env43741 == env43742) = true)

theorem identity43742 : scanCanonicalize (H12AffineFastState.compose env43742 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43742 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43743 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21761,21511,5392,2340,1025,21760,17681,33,21777,2,269,17,2048,16400,17664,23589,20485,21793,257,21792,16384,513]

theorem envBound43743 : H12AffineFastState.Bounded env43743 := by
  intro p hp
  have h : env43743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43742_43743 : H12AffineEnvironment.transform 5 17 env43742 = env43743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43742 == env43743) = true)

theorem identity43743 : scanCanonicalize (H12AffineFastState.compose env43743 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43743 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43744 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,0,262,5392,2340,1025,1,4112,33,16,2,269,17,2048,5393,4097,2340,1284,32,257,33,5377,513]

theorem envBound43744 : H12AffineFastState.Bounded env43744 := by
  intro p hp
  have h : env43744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43743_43744 : H12AffineEnvironment.transform 13 5377 env43743 = env43744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43743 == env43744) = true)

theorem identity43744 : scanCanonicalize (H12AffineFastState.compose env43744 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43744 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43745 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5156,0,35,5173,2049,1025,1,4112,33,16,2,40,17,2048,5172,4097,2049,1057,32,36,33,5156,513]

theorem envBound43745 : H12AffineFastState.Bounded env43745 := by
  intro p hp
  have h : env43745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43744_43745 : H12AffineEnvironment.transform 7 37 env43744 = env43745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43744 == env43745) = true)

def env43746 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1044,0,35,1029,2049,1025,1,32,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,513]

theorem envBound43746 : H12AffineFastState.Bounded env43746 := by
  intro p hp
  have h : env43746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43745_43746 : H12AffineEnvironment.transform 11 48 env43745 = env43746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env43745 == env43746) = true)

theorem identity43746 : scanCanonicalize (H12AffineFastState.compose env43746 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43746 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43747 : List Nat := [2,4,8,16,32,17,8,37,17,1024,2048,48,40,1044,0,35,1029,2049,1025,1,32,33,16,2,40,17,2048,1028,49,2049,1057,32,36,33,1044,16]

theorem envBound43747 : H12AffineFastState.Bounded env43747 := by
  intro p hp
  have h : env43747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43746_43747 : H12AffineEnvironment.transform 8 17 env43746 = env43747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43746 == env43747) = true)

def env43748 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,48,40,32,0,35,49,2049,53,1,32,33,16,2,40,17,2048,48,49,2049,21,32,36,33,32,16]

theorem envBound43748 : H12AffineFastState.Bounded env43748 := by
  intro p hp
  have h : env43748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43747_43748 : H12AffineEnvironment.transform 9 52 env43747 = env43748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43747 == env43748) = true)

theorem identity43748 : scanCanonicalize (H12AffineFastState.compose env43748 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound43748 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43749 : List Nat := [2,4,8,16,32,17,8,37,17,52,33,48,40,32,0,35,49,32,53,1,32,33,16,2,40,17,33,48,49,32,21,32,36,33,32,16]

theorem envBound43749 : H12AffineFastState.Bounded env43749 := by
  intro p hp
  have h : env43749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43748_43749 : H12AffineEnvironment.transform 10 33 env43748 = env43749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env43748 == env43749) = true)

def leafEnv43749 : List Nat := [2,4,8,16,32,17,8,37,17,52,33,48,40,32,0,35,49,32,53,1,32,33,16,2,20,40,1,17,33,48,49,32,21,32,36,33,5,35,32,16,1,32,0]

def active43749 : List Nat := [0,1,2,3,4]

def tree43749 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43749 : H12WitnessSearch.Good tree43749 := H12GlobalWitnessIndex.good

theorem leafIdentity43749 : H12AffineFastState.composeSystem env43749 rootObs = leafEnv43749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43749 rootObs == leafEnv43749) = true)

theorem terminalChecked43749 : H12PackedTerminal.terminalCheckFast leafEnv43749 active43749 tree43749 = true := by decide +kernel

def env43750 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,48,40,33,0,35,48,2049,52,1,32,33,16,2,40,17,2048,49,49,2049,20,32,36,33,33,16]

theorem envBound43750 : H12AffineFastState.Bounded env43750 := by
  intro p hp
  have h : env43750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43747_43750 : H12AffineEnvironment.transform 9 53 env43747 = env43750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43747 == env43750) = true)

theorem identity43750 : scanCanonicalize (H12AffineFastState.compose env43750 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound43750 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43751 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,48,40,33,0,35,48,27,52,1,32,33,16,2,40,17,26,49,49,27,20,32,36,33,33,16]

theorem envBound43751 : H12AffineFastState.Bounded env43751 := by
  intro p hp
  have h : env43751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43750_43751 : H12AffineEnvironment.transform 10 26 env43750 = env43751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env43750 == env43751) = true)

def leafEnv43751 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,48,40,33,0,35,48,27,52,1,32,33,16,2,21,40,1,17,26,49,49,27,20,32,36,33,5,35,33,16,1,32,0]

def active43751 : List Nat := [0,1,2,3,4]

def tree43751 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43751 : H12WitnessSearch.Good tree43751 := H12GlobalWitnessIndex.good

theorem leafIdentity43751 : H12AffineFastState.composeSystem env43751 rootObs = leafEnv43751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43751 rootObs == leafEnv43751) = true)

theorem terminalChecked43751 : H12PackedTerminal.terminalCheckFast leafEnv43751 active43751 tree43751 = true := by decide +kernel

def env43752 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1045,0,35,1028,2049,1025,1,33,33,16,2,40,17,2048,1029,48,2049,1057,32,36,33,1045,513]

theorem envBound43752 : H12AffineFastState.Bounded env43752 := by
  intro p hp
  have h : env43752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43745_43752 : H12AffineEnvironment.transform 11 49 env43745 = env43752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43745 == env43752) = true)

theorem identity43752 : scanCanonicalize (H12AffineFastState.compose env43752 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound43752 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43753 : List Nat := [2,4,8,16,32,17,8,37,512,548,2048,49,40,561,0,35,544,2049,549,1,33,33,16,2,40,17,2048,545,48,2049,517,32,36,33,561,513]

theorem envBound43753 : H12AffineFastState.Bounded env43753 := by
  intro p hp
  have h : env43753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43752_43753 : H12AffineEnvironment.transform 9 548 env43752 = env43753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env43752 == env43753) = true)

def env43754 : List Nat := [2,4,8,16,32,17,8,37,16,52,2048,49,40,33,0,35,48,2049,53,1,33,33,16,2,40,17,2048,49,48,2049,21,32,36,33,33,17]

theorem envBound43754 : H12AffineFastState.Bounded env43754 := by
  intro p hp
  have h : env43754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43753_43754 : H12AffineEnvironment.transform 8 16 env43753 = env43754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43753 == env43754) = true)

theorem identity43754 : scanCanonicalize (H12AffineFastState.compose env43754 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound43754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43755 : List Nat := [2,4,8,16,32,17,8,37,16,52,32,49,40,33,0,35,48,33,53,1,33,33,16,2,40,17,32,49,48,33,21,32,36,33,33,17]

theorem envBound43755 : H12AffineFastState.Bounded env43755 := by
  intro p hp
  have h : env43755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43754_43755 : H12AffineEnvironment.transform 10 32 env43754 = env43755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env43754 == env43755) = true)

def leafEnv43755 : List Nat := [2,4,8,16,32,17,8,37,16,52,32,49,40,33,0,35,48,33,53,1,33,33,16,2,20,40,1,17,32,49,48,33,21,32,36,33,5,35,33,17,1,33,0]

def active43755 : List Nat := [0,1,2,3,4]

def tree43755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43755 : H12WitnessSearch.Good tree43755 := H12GlobalWitnessIndex.good

theorem leafIdentity43755 : H12AffineFastState.composeSystem env43755 rootObs = leafEnv43755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43755 rootObs == leafEnv43755) = true)

theorem terminalChecked43755 : H12PackedTerminal.terminalCheckFast leafEnv43755 active43755 tree43755 = true := by decide +kernel

def env43756 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,49,40,32,0,35,49,2049,52,1,33,33,16,2,40,17,2048,48,48,2049,20,32,36,33,32,16]

theorem envBound43756 : H12AffineFastState.Bounded env43756 := by
  intro p hp
  have h : env43756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43753_43756 : H12AffineEnvironment.transform 8 17 env43753 = env43756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43753 == env43756) = true)

theorem identity43756 : scanCanonicalize (H12AffineFastState.compose env43756 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound43756 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43757 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,49,40,32,0,35,49,27,52,1,33,33,16,2,40,17,26,48,48,27,20,32,36,33,32,16]

theorem envBound43757 : H12AffineFastState.Bounded env43757 := by
  intro p hp
  have h : env43757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43756_43757 : H12AffineEnvironment.transform 10 26 env43756 = env43757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env43756 == env43757) = true)

def leafEnv43757 : List Nat := [2,4,8,16,32,17,8,37,17,53,26,49,40,32,0,35,49,27,52,1,33,33,16,2,21,40,1,17,26,48,48,27,20,32,36,33,5,35,32,16,1,33,0]

def active43757 : List Nat := [0,1,2,3,4]

def tree43757 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43757 : H12WitnessSearch.Good tree43757 := H12GlobalWitnessIndex.good

theorem leafIdentity43757 : H12AffineFastState.composeSystem env43757 rootObs = leafEnv43757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43757 rootObs == leafEnv43757) = true)

theorem terminalChecked43757 : H12PackedTerminal.terminalCheckFast leafEnv43757 active43757 tree43757 = true := by decide +kernel

def env43758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169352,98781,8328,64,64724,163977,17664,284041,168005,411973,257,21792,46212,243602]

theorem envBound43758 : H12AffineFastState.Bounded env43758 := by
  intro p hp
  have h : env43758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43722_43758 : H12AffineEnvironment.transform 21 272513 env43722 = env43758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env43722 == env43758) = true)

theorem identity43758 : scanCanonicalize (H12AffineFastState.compose env43758 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43758 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165337,272513,169352,41431,8328,64,64724,163977,17664,284041,168005,411973,257,21792,46212,169880]

theorem envBound43759 : H12AffineFastState.Bounded env43759 := by
  intro p hp
  have h : env43759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43758_43759 : H12AffineEnvironment.transform 15 8202 env43758 = env43759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43758 == env43759) = true)

def env43760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165201,272393,169216,41311,8192,64,64604,163841,17664,283905,168005,411973,257,21792,46092,169744]

theorem envBound43760 : H12AffineFastState.Bounded env43760 := by
  intro p hp
  have h : env43760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43759_43760 : H12AffineEnvironment.transform 6 8 env43759 = env43760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43759 == env43760) = true)

theorem identity43760 : scanCanonicalize (H12AffineFastState.compose env43760 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound43760 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1025,32769,165201,169264,169216,41311,8192,64,64604,163841,17664,190520,168005,62588,257,21792,46092,169744]

theorem envBound43761 : H12AffineFastState.Bounded env43761 := by
  intro p hp
  have h : env43761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43760_43761 : H12AffineEnvironment.transform 17 179513 env43760 = env43761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env43760 == env43761) = true)

theorem identity43761 : scanCanonicalize (H12AffineFastState.compose env43761 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound43761 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38160,10281,1025,32769,4161,32,16,41311,8192,64,64604,5393,17664,32040,1365,62588,257,21792,46092,512]

theorem envBound43762 : H12AffineFastState.Bounded env43762 := by
  intro p hp
  have h : env43762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43761_43762 : H12AffineEnvironment.transform 16 38160 env43761 = env43762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env43761 == env43762) = true)

theorem identity43762 : scanCanonicalize (H12AffineFastState.compose env43762 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1296) := by decide +kernel

theorem selectedBound43762 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env43763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,32768,8202,38160,10281,1025,32769,4161,32,16,41311,8192,64,47436,5393,16,14392,1365,45420,257,4144,46092,512]

theorem envBound43763 : H12AffineFastState.Bounded env43763 := by
  intro p hp
  have h : env43763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43762_43763 : H12AffineEnvironment.transform 13 1296 env43762 = env43763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1296 env43762 == env43763) = true)

theorem identity43763 : scanCanonicalize (H12AffineFastState.compose env43763 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12345) := by decide +kernel

theorem selectedBound43763 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,1296,12345,8202,9513,10281,1025,12344,4161,32,16,4454,8192,64,2421,5393,16,14392,1365,341,257,4144,1077,512]

theorem envBound43764 : H12AffineFastState.Bounded env43764 := by
  intro p hp
  have h : env43764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43763_43764 : H12AffineEnvironment.transform 14 12345 env43763 = env43764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12345 env43763 == env43764) = true)

theorem identity43764 : scanCanonicalize (H12AffineFastState.compose env43764 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound43764 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env43765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,1296,4193,82,1393,2161,1025,4192,4161,32,16,4454,88,64,2421,5393,16,6240,1365,341,257,4144,1077,512]

theorem envBound43765 : H12AffineFastState.Bounded env43765 := by
  intro p hp
  have h : env43765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43764_43765 : H12AffineEnvironment.transform 12 88 env43764 = env43765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env43764 == env43765) = true)

def env43766 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,165200,272392,169217,41310,8193,64,64605,163840,17664,283904,168005,411973,257,21792,46093,169745]

theorem envBound43766 : H12AffineFastState.Bounded env43766 := by
  intro p hp
  have h : env43766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43759_43766 : H12AffineEnvironment.transform 6 9 env43759 = env43766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43759 == env43766) = true)

theorem identity43766 : scanCanonicalize (H12AffineFastState.compose env43766 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138341) := by decide +kernel

theorem selectedBound43766 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env43767 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,138341,1025,32769,165200,144493,169217,41310,8193,64,64605,163840,17664,149861,168005,21792,257,21792,46093,169745]

theorem envBound43767 : H12AffineFastState.Bounded env43767 := by
  intro p hp
  have h : env43767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43766_43767 : H12AffineEnvironment.transform 17 138341 env43766 = env43767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138341 env43766 == env43767) = true)

theorem identity43767 : scanCanonicalize (H12AffineFastState.compose env43767 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 16741) := by decide +kernel

theorem selectedBound43767 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43768 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16741,23808,1025,32769,50229,29960,54372,41310,8193,64,64605,49509,17664,2048,53536,21792,257,21792,46093,54900]

theorem envBound43768 : H12AffineFastState.Bounded env43768 := by
  intro p hp
  have h : env43768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43767_43768 : H12AffineEnvironment.transform 16 16741 env43767 = env43768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16741 env43767 == env43768) = true)

theorem identity43768 : scanCanonicalize (H12AffineFastState.compose env43768 (packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound43768 : packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env43769 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,32768,8202,5392,2421,1025,32769,36928,8573,32785,41310,8193,64,43048,38160,4469,2048,34133,341,257,341,46093,33281]

theorem envBound43769 : H12AffineFastState.Bounded env43769 := by
  intro p hp
  have h : env43769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43768_43769 : H12AffineEnvironment.transform 13 5237 env43768 = env43769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env43768 == env43769) = true)

theorem identity43769 : scanCanonicalize (H12AffineFastState.compose env43769 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43769 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43770 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,0,8202,5392,2421,1025,1,4160,8573,17,8542,8193,64,10280,5392,4469,2048,1365,341,257,341,13325,513]

theorem envBound43770 : H12AffineFastState.Bounded env43770 := by
  intro p hp
  have h : env43770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43769_43770 : H12AffineEnvironment.transform 14 0 env43769 = env43770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43769 == env43770) = true)

def env43771 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,4194304,169353,98780,8328,64,4510805,163976,17665,284040,168005,4350405,257,21792,46212,243602]

theorem envBound43771 : H12AffineFastState.Bounded env43771 := by
  intro p hp
  have h : env43771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43721_43771 : H12AffineEnvironment.transform 22 169353 env43721 = env43771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env43721 == env43771) = true)

def env43772 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272512,169353,98780,8328,64,64725,163976,17665,284040,168005,411973,257,21792,46212,243602]

theorem envBound43772 : H12AffineFastState.Bounded env43772 := by
  intro p hp
  have h : env43772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43771_43772 : H12AffineEnvironment.transform 21 272512 env43771 = env43772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env43771 == env43772) = true)

theorem identity43772 : scanCanonicalize (H12AffineFastState.compose env43772 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound43772 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43773 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115871,272512,120015,98780,8328,64,64725,115150,17665,284040,119043,329731,257,21792,46212,63188]

theorem envBound43773 : H12AffineFastState.Bounded env43773 := by
  intro p hp
  have h : env43773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43772_43773 : H12AffineEnvironment.transform 16 82246 env43772 = env43773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env43772 == env43773) = true)

def env43774 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,262144,1025,32769,115871,272512,119967,98700,8328,16,64645,115102,17665,284040,119043,329731,257,21792,46212,63108]

theorem envBound43774 : H12AffineFastState.Bounded env43774 := by
  intro p hp
  have h : env43774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43773_43774 : H12AffineEnvironment.transform 5 16 env43773 = env43774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43773 == env43774) = true)

theorem identity43774 : scanCanonicalize (H12AffineFastState.compose env43774 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 23588) := by decide +kernel

theorem selectedBound43774 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env43775 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82198,23588,1025,32769,115871,29860,119967,98700,8328,16,64645,115102,17665,2476,119043,87079,257,21792,46212,63108]

theorem envBound43775 : H12AffineFastState.Bounded env43775 := by
  intro p hp
  have h : env43775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43774_43775 : H12AffineEnvironment.transform 17 23588 env43774 = env43775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23588 env43774 == env43775) = true)

theorem identity43775 : scanCanonicalize (H12AffineFastState.compose env43775 (packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound43775 : packedSelected [0,1,4,5,7,8,10,11,16,20,22,24,31,32] rootPS < 2^1333 := by decide +kernel

def env43776 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,65536,82198,23588,1025,32769,115871,21793,119967,98700,269,16,56576,115102,17665,2476,119043,87079,257,21792,38145,55041]

theorem envBound43776 : H12AffineFastState.Bounded env43776 := by
  intro p hp
  have h : env43776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43775_43776 : H12AffineEnvironment.transform 12 389 env43775 = env43776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env43775 == env43776) = true)

theorem identity43776 : scanCanonicalize (H12AffineFastState.compose env43776 (packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound43776 : packedSelected [0,1,4,5,7,8,16,20,22,24] rootPS < 2^1333 := by decide +kernel

def env43777 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21896,65536,82198,23588,1025,21897,69911,21793,65815,87044,269,16,2184,70678,17665,2476,66699,87079,257,21792,16521,649]

theorem envBound43777 : H12AffineFastState.Bounded env43777 := by
  intro p hp
  have h : env43777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43776_43777 : H12AffineEnvironment.transform 14 21896 env43776 = env43777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env43776 == env43777) = true)

theorem identity43777 : scanCanonicalize (H12AffineFastState.compose env43777 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound43777 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env43778 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21896,398,16536,23588,1025,21897,4249,21793,153,21898,269,16,2184,5528,17665,2476,1285,21929,257,21792,16521,649]

theorem envBound43778 : H12AffineFastState.Bounded env43778 := by
  intro p hp
  have h : env43778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43777_43778 : H12AffineEnvironment.transform 15 398 env43777 = env43778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env43777 == env43778) = true)

theorem identity43778 : scanCanonicalize (H12AffineFastState.compose env43778 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound43778 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env43779 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5512,0,398,5392,2476,1025,1,4249,169,153,2,269,16,2184,5528,4233,2476,1285,33,257,168,5377,649]

theorem envBound43779 : H12AffineFastState.Bounded env43779 := by
  intro p hp
  have h : env43779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43778_43779 : H12AffineEnvironment.transform 13 5512 env43778 = env43779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env43778 == env43779) = true)

theorem identity43779 : scanCanonicalize (H12AffineFastState.compose env43779 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43779 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env43780 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,129,5260,0,138,5140,2216,1025,1,4249,169,153,2,9,16,2184,5276,4233,2216,1025,33,5,168,5125,649]

theorem envBound43780 : H12AffineFastState.Bounded env43780 := by
  intro p hp
  have h : env43780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43779_43780 : H12AffineEnvironment.transform 7 4 env43779 = env43780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43779 == env43780) = true)

theorem identity43780 : scanCanonicalize (H12AffineFastState.compose env43780 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43780 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env43781 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,4096,8,5125,0,3,5140,2081,1025,1,4112,32,16,2,9,16,2049,5141,4096,2081,1025,33,5,33,5125,512]

theorem envBound43781 : H12AffineFastState.Bounded env43781 := by
  intro p hp
  have h : env43781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43780_43781 : H12AffineEnvironment.transform 6 9 env43780 = env43781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43780 == env43781) = true)

theorem identity43781 : scanCanonicalize (H12AffineFastState.compose env43781 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound43781 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43782 : List Nat := [2,4,8,16,32,16,9,4,512,1024,2048,1,8,1028,0,3,1045,2081,1025,1,17,32,16,2,9,16,2049,1044,1,2081,1025,33,5,33,1028,512]

theorem envBound43782 : H12AffineFastState.Bounded env43782 := by
  intro p hp
  have h : env43782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43781_43782 : H12AffineEnvironment.transform 11 1 env43781 = env43782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env43781 == env43782) = true)

theorem identity43782 : scanCanonicalize (H12AffineFastState.compose env43782 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound43782 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43783 : List Nat := [2,4,8,16,32,16,9,4,512,1024,1038,1,8,1028,0,3,1045,1071,1025,1,17,32,16,2,9,16,1039,1044,1,1071,1025,33,5,33,1028,512]

theorem envBound43783 : H12AffineFastState.Bounded env43783 := by
  intro p hp
  have h : env43783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43782_43783 : H12AffineEnvironment.transform 10 1038 env43782 = env43783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env43782 == env43783) = true)

theorem identity43783 : scanCanonicalize (H12AffineFastState.compose env43783 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43783 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43784 : List Nat := [2,4,8,16,11,16,9,4,512,1024,1038,1,8,1028,0,3,1045,1028,1025,1,17,11,16,2,9,16,1039,1044,1,1028,1025,10,5,10,1028,512]

theorem envBound43784 : H12AffineFastState.Bounded env43784 := by
  intro p hp
  have h : env43784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43783_43784 : H12AffineEnvironment.transform 4 11 env43783 = env43784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43783 == env43784) = true)

theorem identity43784 : scanCanonicalize (H12AffineFastState.compose env43784 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 14) := by decide +kernel

theorem selectedBound43784 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43785 : List Nat := [2,4,8,16,11,16,9,4,512,14,0,1,8,10,0,3,27,10,15,1,17,11,16,2,9,16,1,26,1,10,15,10,5,10,10,512]

theorem envBound43785 : H12AffineFastState.Bounded env43785 := by
  intro p hp
  have h : env43785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43784_43785 : H12AffineEnvironment.transform 9 14 env43784 = env43785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 14 env43784 == env43785) = true)

theorem identity43785 : scanCanonicalize (H12AffineFastState.compose env43785 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43785 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env43786 : List Nat := [2,4,2,16,1,16,3,4,512,4,0,1,2,0,0,3,17,0,5,1,17,1,16,2,3,16,1,16,1,0,5,0,5,0,0,512]

theorem envBound43786 : H12AffineFastState.Bounded env43786 := by
  intro p hp
  have h : env43786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43785_43786 : H12AffineEnvironment.transform 2 2 env43785 = env43786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43785 == env43786) = true)

theorem identity43786 : scanCanonicalize (H12AffineFastState.compose env43786 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43786 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43787 : List Nat := [2,1,2,16,1,16,3,1,512,1,0,1,2,0,0,3,17,0,0,1,17,1,16,2,3,16,1,16,1,0,0,0,0,0,0,512]

theorem envBound43787 : H12AffineFastState.Bounded env43787 := by
  intro p hp
  have h : env43787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43786_43787 : H12AffineEnvironment.transform 1 1 env43786 = env43787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43786 == env43787) = true)

theorem identity43787 : scanCanonicalize (H12AffineFastState.compose env43787 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43787 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43788 : List Nat := [2,1,2,0,1,0,3,1,512,1,0,1,2,0,0,3,1,0,0,1,1,1,0,2,3,0,1,0,1,0,0,0,0,0,0,512]

theorem envBound43788 : H12AffineFastState.Bounded env43788 := by
  intro p hp
  have h : env43788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43787_43788 : H12AffineEnvironment.transform 3 0 env43787 = env43788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43787 == env43788) = true)

theorem identity43788 : scanCanonicalize (H12AffineFastState.compose env43788 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43788 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43789 : List Nat := [1,1,1,0,1,0,0,1,512,1,0,1,1,0,0,0,1,0,0,1,1,1,0,1,0,0,1,0,1,0,0,0,0,0,0,512]

theorem envBound43789 : H12AffineFastState.Bounded env43789 := by
  intro p hp
  have h : env43789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43788_43789 : H12AffineEnvironment.transform 0 1 env43788 = env43789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43788 == env43789) = true)

def env43790 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115871,272512,119966,98701,8328,17,64644,115103,17665,284040,119043,329731,257,21792,46212,63109]

theorem envBound43790 : H12AffineFastState.Bounded env43790 := by
  intro p hp
  have h : env43790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43773_43790 : H12AffineEnvironment.transform 5 17 env43773 = env43790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43773 == env43790) = true)

theorem identity43790 : scanCanonicalize (H12AffineFastState.compose env43790 (packedSelected [1,14,16,19,20,28,31,35] rootPS)) = affineNative (2^(17+1) ^^^ 97327) := by decide +kernel

theorem selectedBound43790 : packedSelected [1,14,16,19,20,28,31,35] rootPS < 2^1333 := by decide +kernel

def env43791 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82199,97327,1025,32769,115871,87215,119966,98701,8328,17,64644,115103,17665,76199,119043,29740,257,21792,46212,63109]

theorem envBound43791 : H12AffineFastState.Bounded env43791 := by
  intro p hp
  have h : env43791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43790_43791 : H12AffineEnvironment.transform 17 97327 env43790 = env43791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97327 env43790 == env43791) = true)

theorem identity43791 : scanCanonicalize (H12AffineFastState.compose env43791 (packedSelected [5,8,19,24,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound43791 : packedSelected [5,8,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env43792 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,65536,70814,76198,1025,32769,102678,65830,98583,98701,8328,17,43277,103446,4232,76199,99466,8613,257,169,46212,41740]

theorem envBound43792 : H12AffineFastState.Bounded env43792 := by
  intro p hp
  have h : env43792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43791_43792 : H12AffineEnvironment.transform 13 5513 env43791 = env43792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env43791 == env43792) = true)

theorem identity43792 : scanCanonicalize (H12AffineFastState.compose env43792 (packedSelected [3,10,16,18,20,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound43792 : packedSelected [3,10,16,18,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43793 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,263,5529,10401,1025,32769,36881,33,32784,32906,8328,17,43277,38161,4232,10400,34189,8613,257,169,46212,41740]

theorem envBound43793 : H12AffineFastState.Bounded env43793 := by
  intro p hp
  have h : env43793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43792_43793 : H12AffineEnvironment.transform 15 263 env43792 = env43793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env43792 == env43793) = true)

theorem identity43793 : scanCanonicalize (H12AffineFastState.compose env43793 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound43793 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,17,18,19,20] rootPS < 2^1333 := by decide +kernel

def env43794 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8460,263,5529,10401,1025,8461,12573,33,8476,8582,8328,17,2049,13341,4232,10400,9345,8613,257,169,5512,512]

theorem envBound43794 : H12AffineFastState.Bounded env43794 := by
  intro p hp
  have h : env43794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43793_43794 : H12AffineEnvironment.transform 14 8460 env43793 = env43794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env43793 == env43794) = true)

theorem identity43794 : scanCanonicalize (H12AffineFastState.compose env43794 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43794 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43795 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,8192,5513,8460,263,5529,10369,1025,8461,12573,1,8476,8582,8328,17,2049,13341,4232,10368,9345,8581,257,137,5512,512]

theorem envBound43795 : H12AffineFastState.Bounded env43795 := by
  intro p hp
  have h : env43795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43794_43795 : H12AffineEnvironment.transform 4 0 env43794 = env43795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43794 == env43795) = true)

theorem identity43795 : scanCanonicalize (H12AffineFastState.compose env43795 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7300) := by decide +kernel

theorem selectedBound43795 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env43796 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,4096,7300,5513,7560,263,5529,5125,1025,7561,3481,1,7576,7426,7180,17,2049,2201,4232,5124,6149,7425,257,137,5512,512]

theorem envBound43796 : H12AffineFastState.Bounded env43796 := by
  intro p hp
  have h : env43796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43795_43796 : H12AffineEnvironment.transform 12 7300 env43795 = env43796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7300 env43795 == env43796) = true)

theorem identity43796 : scanCanonicalize (H12AffineFastState.compose env43796 (packedSelected [1,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 412) := by decide +kernel

theorem selectedBound43796 : packedSelected [1,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env43797 : List Nat := [2,4,8,16,0,17,128,256,512,1024,2048,412,3352,1045,3092,263,1029,1433,1025,3093,3481,1,3076,3230,3472,17,2049,2201,276,1432,2457,3229,257,137,1044,512]

theorem envBound43797 : H12AffineFastState.Bounded env43797 := by
  intro p hp
  have h : env43797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43796_43797 : H12AffineEnvironment.transform 11 412 env43796 = env43797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 412 env43796 == env43797) = true)

theorem identity43797 : scanCanonicalize (H12AffineFastState.compose env43797 (packedSelected [0,2,3,4,5,7,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound43797 : packedSelected [0,2,3,4,5,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env43798 : List Nat := [2,4,8,16,0,17,128,256,512,1024,260,412,1052,1045,1296,263,1029,1433,1025,1297,1181,1,1280,1434,1172,17,261,413,276,1432,157,1433,257,137,1044,512]

theorem envBound43798 : H12AffineFastState.Bounded env43798 := by
  intro p hp
  have h : env43798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43797_43798 : H12AffineEnvironment.transform 10 260 env43797 = env43798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env43797 == env43798) = true)

theorem identity43798 : scanCanonicalize (H12AffineFastState.compose env43798 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43798 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env43799 : List Nat := [2,4,8,16,0,17,128,256,512,272,260,412,268,261,0,263,277,137,273,1,397,1,16,138,388,17,261,413,276,136,157,137,257,137,260,512]

theorem envBound43799 : H12AffineFastState.Bounded env43799 := by
  intro p hp
  have h : env43799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43798_43799 : H12AffineEnvironment.transform 9 272 env43798 = env43799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43798 == env43799) = true)

theorem identity43799 : scanCanonicalize (H12AffineFastState.compose env43799 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43799 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43800 : List Nat := [2,4,8,16,0,17,8,256,512,272,260,276,268,261,0,263,277,1,273,1,261,1,16,2,268,17,261,277,276,0,21,1,257,1,260,512]

theorem envBound43800 : H12AffineFastState.Bounded env43800 := by
  intro p hp
  have h : env43800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43799_43800 : H12AffineEnvironment.transform 6 8 env43799 = env43800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43799 == env43800) = true)

theorem identity43800 : scanCanonicalize (H12AffineFastState.compose env43800 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43800 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43801 : List Nat := [2,4,8,16,0,17,8,4,512,20,0,16,8,1,0,3,17,1,21,1,1,1,16,2,8,17,1,17,16,0,21,1,5,1,0,512]

theorem envBound43801 : H12AffineFastState.Bounded env43801 := by
  intro p hp
  have h : env43801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43800_43801 : H12AffineEnvironment.transform 7 4 env43800 = env43801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43800 == env43801) = true)

theorem identity43801 : scanCanonicalize (H12AffineFastState.compose env43801 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound43801 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43802 : List Nat := [2,0,8,16,0,17,8,0,512,16,0,16,8,1,0,3,17,1,17,1,1,1,16,2,8,17,1,17,16,0,17,1,1,1,0,512]

theorem envBound43802 : H12AffineFastState.Bounded env43802 := by
  intro p hp
  have h : env43802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43801_43802 : H12AffineEnvironment.transform 1 0 env43801 = env43802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env43801 == env43802) = true)

def env43803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,272513,169353,98780,8328,64,64724,163976,17665,284040,168005,411972,257,21792,46212,243602]

theorem envBound43803 : H12AffineFastState.Bounded env43803 := by
  intro p hp
  have h : env43803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43771_43803 : H12AffineEnvironment.transform 21 272513 env43771 = env43803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env43771 == env43803) = true)

theorem identity43803 : scanCanonicalize (H12AffineFastState.compose env43803 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound43803 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43804 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,165337,272513,169353,21762,8328,64,64724,163976,17665,284040,168005,411972,257,21792,46212,156492]

theorem envBound43804 : H12AffineFastState.Bounded env43804 := by
  intro p hp
  have h : env43804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43803_43804 : H12AffineEnvironment.transform 15 54494 env43803 = env43804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env43803 == env43804) = true)

def env43805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165201,272393,169217,21762,8192,64,64604,163840,17665,283904,168005,411972,257,21792,46092,156492]

theorem envBound43805 : H12AffineFastState.Bounded env43805 := by
  intro p hp
  have h : env43805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43804_43805 : H12AffineEnvironment.transform 6 8 env43804 = env43805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43804 == env43805) = true)

theorem identity43805 : scanCanonicalize (H12AffineFastState.compose env43805 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43805 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env43806 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,165201,32,169217,21762,8192,64,64604,163840,17665,32041,168005,156013,257,21792,46092,156492]

theorem envBound43806 : H12AffineFastState.Bounded env43806 := by
  intro p hp
  have h : env43806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43805_43806 : H12AffineEnvironment.transform 17 10281 env43805 = env43806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43805 == env43806) = true)

theorem identity43806 : scanCanonicalize (H12AffineFastState.compose env43806 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound43806 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env43807 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,49169,10281,1025,32769,17728,32,21776,21762,8192,64,64604,16401,17665,32041,20564,41340,257,21792,46092,41821]

theorem envBound43807 : H12AffineFastState.Bounded env43807 := by
  intro p hp
  have h : env43807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43806_43807 : H12AffineEnvironment.transform 16 49169 env43806 = env43807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43806 == env43807) = true)

theorem identity43807 : scanCanonicalize (H12AffineFastState.compose env43807 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43807 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29962,24909,10281,1025,8541,17728,32,21776,21762,8192,64,23808,16401,17665,32041,20564,32,257,21792,5456,513]

theorem envBound43808 : H12AffineFastState.Bounded env43808 := by
  intro p hp
  have h : env43808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43807_43808 : H12AffineEnvironment.transform 14 8540 env43807 = env43808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43807 == env43808) = true)

theorem identity43808 : scanCanonicalize (H12AffineFastState.compose env43808 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43808 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env43809 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8460,29962,24861,10281,1025,8461,17680,32,21776,21762,8192,16,23808,16401,17665,32041,20484,32,257,21792,5376,513]

theorem envBound43809 : H12AffineFastState.Bounded env43809 := by
  intro p hp
  have h : env43809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43808_43809 : H12AffineEnvironment.transform 5 16 env43808 = env43809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43808 == env43809) = true)

theorem identity43809 : scanCanonicalize (H12AffineFastState.compose env43809 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43809 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env43810 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,0,21510,16401,2341,1025,1,17680,32,21776,21762,268,16,23808,16401,17665,23589,20484,32,257,21792,5376,513]

theorem envBound43810 : H12AffineFastState.Bounded env43810 := by
  intro p hp
  have h : env43810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43809_43810 : H12AffineEnvironment.transform 12 268 env43809 = env43810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43809 == env43810) = true)

def env43811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165200,272392,169216,21762,8193,64,64605,163841,17665,283905,168005,411972,257,21792,46093,156492]

theorem envBound43811 : H12AffineFastState.Bounded env43811 := by
  intro p hp
  have h : env43811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43804_43811 : H12AffineEnvironment.transform 6 9 env43804 = env43811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43804 == env43811) = true)

theorem identity43811 : scanCanonicalize (H12AffineFastState.compose env43811 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound43811 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env43812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,2420,1025,32769,165200,8572,169216,21762,8193,64,64605,163841,17665,23669,168005,147504,257,21792,46093,156492]

theorem envBound43812 : H12AffineFastState.Bounded env43812 := by
  intro p hp
  have h : env43812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43811_43812 : H12AffineEnvironment.transform 17 2420 env43811 = env43812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env43811 == env43812) = true)

theorem identity43812 : scanCanonicalize (H12AffineFastState.compose env43812 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound43812 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49169,2420,1025,32769,17729,8572,21777,21762,8193,64,64605,16400,17665,23669,20564,32801,257,21792,46093,41821]

theorem envBound43813 : H12AffineFastState.Bounded env43813 := by
  intro p hp
  have h : env43813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43812_43813 : H12AffineEnvironment.transform 16 49169 env43812 = env43813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43812 == env43813) = true)

theorem identity43813 : scanCanonicalize (H12AffineFastState.compose env43813 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound43813 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env43814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,343,5393,2420,1025,21761,17729,8572,21777,21762,8193,64,10589,16400,17665,23669,20564,21793,257,21792,24845,30301]

theorem envBound43814 : H12AffineFastState.Bounded env43814 := by
  intro p hp
  have h : env43814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43813_43814 : H12AffineEnvironment.transform 14 21760 env43813 = env43814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env43813 == env43814) = true)

theorem identity43814 : scanCanonicalize (H12AffineFastState.compose env43814 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound43814 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env43815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8540,343,5393,2420,1025,8541,12573,8572,8525,8542,8193,64,10589,13388,12637,10281,9224,8573,257,8572,5457,513]

theorem envBound43815 : H12AffineFastState.Bounded env43815 := by
  intro p hp
  have h : env43815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43814_43815 : H12AffineEnvironment.transform 13 13404 env43814 = env43815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env43814 == env43815) = true)

theorem identity43815 : scanCanonicalize (H12AffineFastState.compose env43815 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43815 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43816 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8461,262,5393,2341,1025,8460,12573,8493,8476,8463,8193,17,10508,13341,12556,10281,9224,8492,257,8493,5376,513]

theorem envBound43816 : H12AffineFastState.Bounded env43816 := by
  intro p hp
  have h : env43816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43815_43816 : H12AffineEnvironment.transform 5 17 env43815 = env43816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43815 == env43816) = true)

theorem identity43816 : scanCanonicalize (H12AffineFastState.compose env43816 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 781) := by decide +kernel

theorem selectedBound43816 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43817 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,781,5888,512,262,5393,2341,1025,513,4624,544,529,514,780,17,2561,5904,4609,2852,1797,545,257,544,5376,513]

theorem envBound43817 : H12AffineFastState.Bounded env43817 := by
  intro p hp
  have h : env43817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43816_43817 : H12AffineEnvironment.transform 12 781 env43816 = env43817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 781 env43816 == env43817) = true)

theorem identity43817 : scanCanonicalize (H12AffineFastState.compose env43817 (packedSelected [1,7,8,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 3125) := by decide +kernel

theorem selectedBound43817 : packedSelected [1,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env43818 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3125,781,2869,512,262,2340,2341,1025,513,3621,544,529,514,780,17,2561,2853,3636,2852,1797,545,257,544,2357,513]

theorem envBound43818 : H12AffineFastState.Bounded env43818 := by
  intro p hp
  have h : env43818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43817_43818 : H12AffineEnvironment.transform 11 3125 env43817 = env43818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3125 env43817 == env43818) = true)

theorem identity43818 : scanCanonicalize (H12AffineFastState.compose env43818 (packedSelected [1,4,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound43818 : packedSelected [1,4,8,9] rootPS < 2^1333 := by decide +kernel

def env43819 : List Nat := [2,4,8,16,32,17,9,256,512,257,2048,2356,781,2869,512,262,2340,2341,256,513,2852,544,529,514,780,17,2561,2853,2869,2852,516,545,257,544,2357,513]

theorem envBound43819 : H12AffineFastState.Bounded env43819 := by
  intro p hp
  have h : env43819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43818_43819 : H12AffineEnvironment.transform 9 257 env43818 = env43819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env43818 == env43819) = true)

theorem identity43819 : scanCanonicalize (H12AffineFastState.compose env43819 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound43819 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env43820 : List Nat := [2,4,8,16,32,17,9,256,512,257,528,804,781,293,512,262,820,821,256,513,308,544,529,514,780,17,17,309,293,308,516,545,257,544,805,513]

theorem envBound43820 : H12AffineFastState.Bounded env43820 := by
  intro p hp
  have h : env43820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43819_43820 : H12AffineEnvironment.transform 10 528 env43819 = env43820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env43819 == env43820) = true)

theorem identity43820 : scanCanonicalize (H12AffineFastState.compose env43820 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound43820 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43821 : List Nat := [2,4,8,16,32,17,9,256,309,257,293,17,56,293,309,262,1,0,256,308,308,277,292,311,57,17,17,309,293,308,305,276,257,277,16,308]

theorem envBound43821 : H12AffineFastState.Bounded env43821 := by
  intro p hp
  have h : env43821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43820_43821 : H12AffineEnvironment.transform 8 309 env43820 = env43821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env43820 == env43821) = true)

theorem identity43821 : scanCanonicalize (H12AffineFastState.compose env43821 (packedSelected [0,4,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43821 : packedSelected [0,4,11] rootPS < 2^1333 := by decide +kernel

def env43822 : List Nat := [2,4,8,16,32,17,9,37,16,36,0,17,56,0,16,35,1,0,37,17,17,48,1,18,57,17,17,16,0,17,20,49,36,48,16,17]

theorem envBound43822 : H12AffineFastState.Bounded env43822 := by
  intro p hp
  have h : env43822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43821_43822 : H12AffineEnvironment.transform 7 37 env43821 = env43822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43821 == env43822) = true)

theorem identity43822 : scanCanonicalize (H12AffineFastState.compose env43822 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43822 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43823 : List Nat := [2,4,8,16,1,17,9,4,16,5,0,17,25,0,16,2,1,0,4,17,17,17,1,18,24,17,17,16,0,17,20,16,5,17,16,17]

theorem envBound43823 : H12AffineFastState.Bounded env43823 := by
  intro p hp
  have h : env43823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43822_43823 : H12AffineEnvironment.transform 4 1 env43822 = env43823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43822 == env43823) = true)

def env43824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254785,25265169,145662401,525568,140903596,27337992,25733062]

theorem envBound43824 : H12AffineFastState.Bounded env43824 := by
  intro p hp
  have h : env43824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42970_43824 : H12AffineEnvironment.transform 25 65 env42970 = env43824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env42970 == env43824) = true)

def env43825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356289,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound43825 : H12AffineFastState.Bounded env43825 := by
  intro p hp
  have h : env43825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43824_43825 : H12AffineEnvironment.transform 26 30393344 env43824 = env43825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env43824 == env43825) = true)

def env43826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830977,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound43826 : H12AffineFastState.Bounded env43826 := by
  intro p hp
  have h : env43826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43825_43826 : H12AffineEnvironment.transform 18 1024 env43825 = env43826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env43825 == env43826) = true)

theorem identity43826 : scanCanonicalize (H12AffineFastState.compose env43826 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510137) := by decide +kernel

theorem selectedBound43826 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510137,8328,65,12585145,2509877,10507600,8830977,8801448,6729080,256,10882069,10939825,8874879]

theorem envBound43827 : H12AffineFastState.Bounded env43827 := by
  intro p hp
  have h : env43827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43826_43827 : H12AffineEnvironment.transform 23 510137 env43826 = env43827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510137 env43826 == env43827) = true)

def env43828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513204,510137,8328,65,6705549,2509877,396388,2136373,2102684,6729080,256,21793,46213,2175563]

theorem envBound43828 : H12AffineFastState.Bounded env43828 := by
  intro p hp
  have h : env43828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43827_43828 : H12AffineEnvironment.transform 22 2513204 env43827 = env43828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513204 env43827 == env43828) = true)

def env43829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513204,510137,8328,65,2409661,2509877,396388,2136373,2102684,2373704,256,21793,46213,2175563]

theorem envBound43829 : H12AffineFastState.Bounded env43829 := by
  intro p hp
  have h : env43829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43828_43829 : H12AffineEnvironment.transform 21 169264 env43828 = env43829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env43828 == env43829) = true)

def env43830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,510137,8328,65,316669,416885,396388,35189,1500,272392,256,21793,46213,74251]

theorem envBound43830 : H12AffineFastState.Bounded env43830 := by
  intro p hp
  have h : env43830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43829_43830 : H12AffineEnvironment.transform 20 4160 env43829 = env43830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43829 == env43830) = true)

theorem identity43830 : scanCanonicalize (H12AffineFastState.compose env43830 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound43830 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4160,169264,73754,41431,8328,65,245139,79131,91402,35189,1500,213350,256,21793,46213,74251]

theorem envBound43831 : H12AffineFastState.Bounded env43831 := by
  intro p hp
  have h : env43831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43830_43831 : H12AffineEnvironment.transform 17 223598 env43830 = env43831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env43830 == env43831) = true)

def env43832 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4112,169264,73754,41351,8328,17,245139,79131,91402,35109,1420,213302,256,21793,46213,74251]

theorem envBound43832 : H12AffineFastState.Bounded env43832 := by
  intro p hp
  have h : env43832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43831_43832 : H12AffineEnvironment.transform 5 16 env43831 = env43832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43831 == env43832) = true)

theorem identity43832 : scanCanonicalize (H12AffineFastState.compose env43832 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 49304) := by decide +kernel

theorem selectedBound43832 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env43833 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,49304,108966,1024,32769,4112,21928,73754,41351,8328,17,97547,79131,91402,35109,1420,98734,256,21793,46213,74251]

theorem envBound43833 : H12AffineFastState.Bounded env43833 := by
  intro p hp
  have h : env43833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43832_43833 : H12AffineEnvironment.transform 16 49304 env43832 = env43833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49304 env43832 == env43833) = true)

theorem identity43833 : scanCanonicalize (H12AffineFastState.compose env43833 (packedSelected [0,1,4,7,11,16,17,20,22,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound43833 : packedSelected [0,1,4,7,11,16,17,20,22,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env43834 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,40971,49304,2477,1024,32769,4112,21928,32785,41351,8328,17,56576,38160,50433,35109,1420,8613,256,21793,46213,33280]

theorem envBound43834 : H12AffineFastState.Bounded env43834 := by
  intro p hp
  have h : env43834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43833_43834 : H12AffineEnvironment.transform 15 40971 env43833 = env43834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env43833 == env43834) = true)

theorem identity43834 : scanCanonicalize (H12AffineFastState.compose env43834 (packedSelected [1,5,8,16,18,19,20,23,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound43834 : packedSelected [1,5,8,16,18,19,20,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43835 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,21647,13340,2477,1024,29829,4112,21928,29845,21763,8328,17,10628,24980,12677,32161,1420,8613,256,21793,16385,30340]

theorem envBound43835 : H12AffineFastState.Bounded env43835 := by
  intro p hp
  have h : env43835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43834_43835 : H12AffineEnvironment.transform 14 29828 env43834 = env43835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env43834 == env43835) = true)

theorem identity43835 : scanCanonicalize (H12AffineFastState.compose env43835 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 13477) := by decide +kernel

theorem selectedBound43835 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env43836 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13477,33,8234,13340,2477,1024,32,4112,8461,48,8614,8328,17,10628,5425,12677,2308,1420,8613,256,8580,13476,545]

theorem envBound43836 : H12AffineFastState.Bounded env43836 := by
  intro p hp
  have h : env43836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43835_43836 : H12AffineEnvironment.transform 13 13477 env43835 = env43836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13477 env43835 == env43836) = true)

theorem identity43836 : scanCanonicalize (H12AffineFastState.compose env43836 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43836 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env43837 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5545,33,294,5392,2477,1024,32,4112,1,48,170,388,17,2184,5425,4233,2308,1420,169,256,136,5544,545]

theorem envBound43837 : H12AffineFastState.Bounded env43837 := by
  intro p hp
  have h : env43837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43836_43837 : H12AffineEnvironment.transform 12 268 env43836 = env43837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43836 == env43837) = true)

theorem identity43837 : scanCanonicalize (H12AffineFastState.compose env43837 (packedSelected [0,3,5,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2609) := by decide +kernel

theorem selectedBound43837 : packedSelected [0,3,5,9,10,11] rootPS < 2^1333 := by decide +kernel

def env43838 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,2609,268,3992,33,294,3873,2477,1024,32,2593,1,48,170,388,17,2184,3840,2744,2308,1420,169,256,136,3993,545]

theorem envBound43838 : H12AffineFastState.Bounded env43838 := by
  intro p hp
  have h : env43838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43837_43838 : H12AffineEnvironment.transform 11 2609 env43837 = env43838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2609 env43837 == env43838) = true)

theorem identity43838 : scanCanonicalize (H12AffineFastState.compose env43838 (packedSelected [3,5,6,7,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 668) := by decide +kernel

theorem selectedBound43838 : packedSelected [3,5,6,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env43839 : List Nat := [2,4,8,16,32,16,128,256,512,668,2048,2609,268,2308,33,294,2493,2477,668,32,2593,1,48,170,388,17,2184,2460,2744,2308,784,169,256,136,2309,545]

theorem envBound43839 : H12AffineFastState.Bounded env43839 := by
  intro p hp
  have h : env43839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43838_43839 : H12AffineEnvironment.transform 9 668 env43838 = env43839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 668 env43838 == env43839) = true)

theorem identity43839 : scanCanonicalize (H12AffineFastState.compose env43839 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 820) := by decide +kernel

theorem selectedBound43839 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env43840 : List Nat := [2,4,8,16,32,16,128,256,512,668,820,261,268,560,33,294,649,665,668,32,277,1,48,170,388,17,956,680,396,560,784,169,256,136,561,545]

theorem envBound43840 : H12AffineFastState.Bounded env43840 := by
  intro p hp
  have h : env43840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43839_43840 : H12AffineEnvironment.transform 10 820 env43839 = env43840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 820 env43839 == env43840) = true)

theorem identity43840 : scanCanonicalize (H12AffineFastState.compose env43840 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(8+1) ^^^ 184) := by decide +kernel

theorem selectedBound43840 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env43841 : List Nat := [2,4,8,16,32,16,128,256,184,36,396,261,268,136,33,294,49,33,36,32,277,1,48,170,388,17,260,16,396,136,424,169,256,136,137,153]

theorem envBound43841 : H12AffineFastState.Bounded env43841 := by
  intro p hp
  have h : env43841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43840_43841 : H12AffineEnvironment.transform 8 184 env43840 = env43841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 184 env43840 == env43841) = true)

theorem identity43841 : scanCanonicalize (H12AffineFastState.compose env43841 (packedSelected [0,1,3,4,5,8,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound43841 : packedSelected [0,1,3,4,5,8,10,14] rootPS < 2^1333 := by decide +kernel

def env43842 : List Nat := [2,4,8,16,32,16,128,172,184,36,32,169,160,136,33,138,49,33,36,32,185,1,48,170,40,17,168,16,32,136,4,169,172,136,137,153]

theorem envBound43842 : H12AffineFastState.Bounded env43842 := by
  intro p hp
  have h : env43842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43841_43842 : H12AffineEnvironment.transform 7 172 env43841 = env43842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env43841 == env43842) = true)

def env43843 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4113,169264,73754,41350,8328,16,245139,79131,91402,35108,1421,213303,256,21793,46213,74251]

theorem envBound43843 : H12AffineFastState.Bounded env43843 := by
  intro p hp
  have h : env43843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43831_43843 : H12AffineEnvironment.transform 5 17 env43831 = env43843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43831 == env43843) = true)

theorem identity43843 : scanCanonicalize (H12AffineFastState.compose env43843 (packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS)) = affineNative (2^(16+1) ^^^ 82335) := by decide +kernel

theorem selectedBound43843 : packedSelected [0,1,9,10,12,14,19,22,27,28,35,41] rootPS < 2^1333 := by decide +kernel

def env43844 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,10400,1024,32769,4113,119983,73754,41350,8328,16,64524,79131,91402,35108,1421,168,256,21793,46213,74251]

theorem envBound43844 : H12AffineFastState.Bounded env43844 := by
  intro p hp
  have h : env43844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43843_43844 : H12AffineEnvironment.transform 16 82335 env43843 = env43844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82335 env43843 == env43844) = true)

theorem identity43844 : scanCanonicalize (H12AffineFastState.compose env43844 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound43844 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env43845 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,65536,82335,10400,1024,8581,4113,95531,73754,2,8328,16,23944,79131,91402,10400,1421,168,256,21793,5377,74251]

theorem envBound43845 : H12AffineFastState.Bounded env43845 := by
  intro p hp
  have h : env43845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43844_43845 : H12AffineEnvironment.transform 14 8580 env43844 = env43845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env43844 == env43845) = true)

theorem identity43845 : scanCanonicalize (H12AffineFastState.compose env43845 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43845 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43846 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,8203,24980,10400,1024,8581,4113,21792,17,2,8328,16,23944,5392,17665,10400,1421,168,256,21793,5377,512]

theorem envBound43846 : H12AffineFastState.Bounded env43846 := by
  intro p hp
  have h : env43846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43845_43846 : H12AffineEnvironment.transform 15 8203 env43845 = env43846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43845 == env43846) = true)

theorem identity43846 : scanCanonicalize (H12AffineFastState.compose env43846 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43846 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env43847 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,40,16384,428,35,16828,2184,1024,429,4113,21792,17,2,160,16,23944,5392,17665,2184,1421,168,256,21793,5377,512]

theorem envBound43847 : H12AffineFastState.Bounded env43847 := by
  intro p hp
  have h : env43847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43846_43847 : H12AffineEnvironment.transform 12 40 env43846 = env43847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43846 == env43847) = true)

theorem identity43847 : scanCanonicalize (H12AffineFastState.compose env43847 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43847 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env43848 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,9,16384,397,2,16797,2184,1024,396,4113,21761,17,2,129,16,23944,5392,17665,2184,1421,137,256,21760,5377,512]

theorem envBound43848 : H12AffineFastState.Bounded env43848 := by
  intro p hp
  have h : env43848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43847_43848 : H12AffineEnvironment.transform 4 1 env43847 = env43848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43847 == env43848) = true)

theorem identity43848 : scanCanonicalize (H12AffineFastState.compose env43848 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(13+1) ^^^ 5125) := by decide +kernel

theorem selectedBound43848 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env43849 : List Nat := [2,4,8,16,1,17,128,256,512,1024,2048,4096,9,5125,397,2,5528,2184,1024,396,4113,260,17,2,129,16,2445,5392,4356,2184,1421,137,256,261,5377,512]

theorem envBound43849 : H12AffineFastState.Bounded env43849 := by
  intro p hp
  have h : env43849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43848_43849 : H12AffineEnvironment.transform 13 5125 env43848 = env43849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5125 env43848 == env43849) = true)

theorem identity43849 : scanCanonicalize (H12AffineFastState.compose env43849 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 141) := by decide +kernel

theorem selectedBound43849 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43850 : List Nat := [2,4,8,16,1,17,128,141,512,1024,2048,4096,9,5125,0,2,5141,2184,1024,1,4113,137,17,2,129,16,2048,5277,4233,2184,1024,137,141,136,5260,512]

theorem envBound43850 : H12AffineFastState.Bounded env43850 := by
  intro p hp
  have h : env43850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43849_43850 : H12AffineEnvironment.transform 7 141 env43849 = env43850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 141 env43849 == env43850) = true)

theorem identity43850 : scanCanonicalize (H12AffineFastState.compose env43850 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound43850 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43851 : List Nat := [2,4,8,16,1,17,128,141,512,1024,2048,136,9,1165,0,2,1181,2184,1024,1,153,137,17,2,129,16,2048,1045,1,2184,1024,137,141,136,1028,512]

theorem envBound43851 : H12AffineFastState.Bounded env43851 := by
  intro p hp
  have h : env43851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43850_43851 : H12AffineEnvironment.transform 11 136 env43850 = env43851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env43850 == env43851) = true)

theorem identity43851 : scanCanonicalize (H12AffineFastState.compose env43851 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1054) := by decide +kernel

theorem selectedBound43851 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env43852 : List Nat := [2,4,8,16,1,17,128,141,512,1024,1054,136,9,1165,0,2,1181,1174,1024,1,153,137,17,2,129,16,1054,1045,1,1174,1024,137,141,136,1028,512]

theorem envBound43852 : H12AffineFastState.Bounded env43852 := by
  intro p hp
  have h : env43852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43851_43852 : H12AffineEnvironment.transform 10 1054 env43851 = env43852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1054 env43851 == env43852) = true)

def env43853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412021,510137,8328,65,316668,416884,396388,35188,1501,272393,256,21793,46213,74250]

theorem envBound43853 : H12AffineFastState.Bounded env43853 := by
  intro p hp
  have h : env43853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43829_43853 : H12AffineEnvironment.transform 20 4161 env43829 = env43853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43829 == env43853) = true)

theorem identity43853 : scanCanonicalize (H12AffineFastState.compose env43853 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound43853 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4161,169264,412021,400486,8328,65,316668,416884,396388,35188,1501,272393,256,21793,46213,63189]

theorem envBound43854 : H12AffineFastState.Bounded env43854 := by
  intro p hp
  have h : env43854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43853_43854 : H12AffineEnvironment.transform 15 54495 env43853 = env43854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env43853 == env43854) = true)

def env43855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,262144,1024,32769,4161,54640,264501,285734,8328,65,316668,269364,281636,35188,1501,272393,256,21793,46213,63189]

theorem envBound43855 : H12AffineFastState.Bounded env43855 := by
  intro p hp
  have h : env43855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43854_43855 : H12AffineEnvironment.transform 16 16448 env43854 = env43855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16448 env43854 == env43855) = true)

theorem identity43855 : scanCanonicalize (H12AffineFastState.compose env43855 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 56437) := by decide +kernel

theorem selectedBound43855 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,16448,56437,1024,32769,4161,54640,54592,32851,8328,65,2185,49217,36945,35188,1501,62588,256,21793,46213,63189]

theorem envBound43856 : H12AffineFastState.Bounded env43856 := by
  intro p hp
  have h : env43856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43855_43856 : H12AffineEnvironment.transform 17 56437 env43855 = env43856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env43855 == env43856) = true)

theorem identity43856 : scanCanonicalize (H12AffineFastState.compose env43856 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound43856 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,23] rootPS < 2^1333 := by decide +kernel

def env43857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,21510,16448,23724,1024,216,4161,21929,21913,138,8328,65,2185,16536,4232,2477,1501,29861,256,21793,13404,30220]

theorem envBound43857 : H12AffineFastState.Bounded env43857 := by
  intro p hp
  have h : env43857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43856_43857 : H12AffineEnvironment.transform 14 217 env43856 = env43857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env43856 == env43857) = true)

theorem identity43857 : scanCanonicalize (H12AffineFastState.compose env43857 (packedSelected [3,5,9,12,18,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43857 : packedSelected [3,5,9,12,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env43858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,217,262,5440,2476,1024,216,4161,169,153,138,8328,65,2185,5528,4232,2477,1501,8613,256,33,13404,8972]

theorem envBound43858 : H12AffineFastState.Bounded env43858 := by
  intro p hp
  have h : env43858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43857_43858 : H12AffineEnvironment.transform 13 5376 env43857 = env43858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43857 == env43858) = true)

theorem identity43858 : scanCanonicalize (H12AffineFastState.compose env43858 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

end H12CloudChart1