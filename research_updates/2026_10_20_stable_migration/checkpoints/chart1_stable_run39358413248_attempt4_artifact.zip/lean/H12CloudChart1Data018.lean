import H12CloudChart1Data017

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound4436 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4437 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1212,8192,16384,8201,25735,1028,262144,1025,8201,1212,4194304,4194456,35,8329,4194457,279604,16384,16569,19613,16557,17412,20,17596,4195484,4194865]

theorem envBound4437 : H12AffineFastState.Bounded env4437 := by
  intro p hp
  have h : env4437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4436_4437 : H12AffineEnvironment.transform 7 21 env4436 = env4437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env4436 == env4437) = true)

theorem identity4437 : scanCanonicalize (H12AffineFastState.compose env4437 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4437 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4438 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1212,8192,16384,8201,25735,1028,262144,1025,8201,1212,32,184,35,8329,185,279604,16384,16569,19613,16557,17412,20,17596,1212,529]

theorem envBound4438 : H12AffineFastState.Bounded env4438 := by
  intro p hp
  have h : env4438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4437_4438 : H12AffineEnvironment.transform 21 32 env4437 = env4438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4437 == env4438) = true)

theorem identity4438 : scanCanonicalize (H12AffineFastState.compose env4438 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4438 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4439 : List Nat := [2,4,8,16,32,17,128,21,512,1024,2048,1212,8192,16384,8201,25735,1028,2080,1025,8201,1212,32,184,35,8329,185,19476,16384,16569,19613,16557,17412,20,17596,1212,529]

theorem envBound4439 : H12AffineFastState.Bounded env4439 := by
  intro p hp
  have h : env4439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4438_4439 : H12AffineEnvironment.transform 17 2080 env4438 = env4439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4438 == env4439) = true)

theorem identity4439 : scanCanonicalize (H12AffineFastState.compose env4439 (packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 56) := by decide +kernel

theorem selectedBound4439 : packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS < 2^1333 := by decide +kernel

def env4440 : List Nat := [2,4,8,16,32,17,56,21,512,1024,2048,1028,8192,16384,8201,25663,1028,2080,1025,8201,1028,32,0,35,8241,1,19476,16384,16385,19493,16405,17412,20,17412,1028,529]

theorem envBound4440 : H12AffineFastState.Bounded env4440 := by
  intro p hp
  have h : env4440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4439_4440 : H12AffineEnvironment.transform 6 56 env4439 = env4440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 56 env4439 == env4440) = true)

theorem identity4440 : scanCanonicalize (H12AffineFastState.compose env4440 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4440 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env4441 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,16384,8201,25647,1028,2080,1025,8201,1028,32,0,35,8225,1,19460,16384,16385,19493,16389,17412,4,17412,1028,513]

theorem envBound4441 : H12AffineFastState.Bounded env4441 := by
  intro p hp
  have h : env4441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4440_4441 : H12AffineEnvironment.transform 3 0 env4440 = env4441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4440 == env4441) = true)

theorem identity4441 : scanCanonicalize (H12AffineFastState.compose env4441 (packedSelected [0,1,4] rootPS)) = affineNative (2^(13+1) ^^^ 9250) := by decide +kernel

theorem selectedBound4441 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env4442 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,8192,9250,8201,13,1028,2080,1025,8201,1028,32,0,35,8225,1,10278,9250,9251,10247,9255,8230,4,8230,1028,513]

theorem envBound4442 : H12AffineFastState.Bounded env4442 := by
  intro p hp
  have h : env4442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4441_4442 : H12AffineEnvironment.transform 13 9250 env4441 = env4442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9250 env4441 == env4442) = true)

theorem identity4442 : scanCanonicalize (H12AffineFastState.compose env4442 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 3081) := by decide +kernel

theorem selectedBound4442 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4443 : List Nat := [2,4,8,0,32,1,40,5,512,1024,2048,1028,3081,2091,3072,13,1028,2080,1025,3072,1028,32,0,35,3112,1,1071,2091,2090,1038,2094,3119,4,3119,1028,513]

theorem envBound4443 : H12AffineFastState.Bounded env4443 := by
  intro p hp
  have h : env4443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4442_4443 : H12AffineEnvironment.transform 12 3081 env4442 = env4443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3081 env4442 == env4443) = true)

theorem identity4443 : scanCanonicalize (H12AffineFastState.compose env4443 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 1582) := by decide +kernel

theorem selectedBound4443 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4444 : List Nat := [2,4,8,0,32,1,40,5,512,1024,1582,1028,551,1541,558,13,1028,1550,1025,558,1028,32,0,35,518,1,1071,1541,1540,1038,1536,513,4,513,1028,513]

theorem envBound4444 : H12AffineFastState.Bounded env4444 := by
  intro p hp
  have h : env4444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4443_4444 : H12AffineEnvironment.transform 10 1582 env4443 = env4444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1582 env4443 == env4444) = true)

theorem identity4444 : scanCanonicalize (H12AffineFastState.compose env4444 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4444 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4445 : List Nat := [2,4,8,0,32,1,40,5,32,1024,1038,1028,7,1061,14,13,1028,1070,1025,14,1028,32,0,35,38,1,1071,1061,1060,1038,1056,33,4,33,1028,33]

theorem envBound4445 : H12AffineFastState.Bounded env4445 := by
  intro p hp
  have h : env4445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4444_4445 : H12AffineEnvironment.transform 8 32 env4444 = env4445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4444 == env4445) = true)

theorem identity4445 : scanCanonicalize (H12AffineFastState.compose env4445 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4445 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4446 : List Nat := [2,4,6,0,32,1,38,5,32,1024,1024,1028,7,1061,0,3,1028,1056,1025,0,1028,32,0,35,38,1,1057,1061,1060,1024,1056,33,4,33,1028,33]

theorem envBound4446 : H12AffineFastState.Bounded env4446 := by
  intro p hp
  have h : env4446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4445_4446 : H12AffineEnvironment.transform 2 6 env4445 = env4446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4445 == env4446) = true)

theorem identity4446 : scanCanonicalize (H12AffineFastState.compose env4446 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 32) := by decide +kernel

theorem selectedBound4446 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4447 : List Nat := [2,4,6,0,32,1,38,5,32,32,32,36,7,5,0,3,36,0,33,0,36,32,0,35,38,1,1,5,4,32,0,33,4,33,36,33]

theorem envBound4447 : H12AffineFastState.Bounded env4447 := by
  intro p hp
  have h : env4447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4446_4447 : H12AffineEnvironment.transform 9 32 env4446 = env4447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 32 env4446 == env4447) = true)

theorem identity4447 : scanCanonicalize (H12AffineFastState.compose env4447 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound4447 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4448 : List Nat := [2,4,6,0,5,1,3,5,5,5,5,1,7,5,0,3,1,0,4,0,1,5,0,6,3,1,1,5,4,5,0,4,4,4,1,4]

theorem envBound4448 : H12AffineFastState.Bounded env4448 := by
  intro p hp
  have h : env4448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4447_4448 : H12AffineEnvironment.transform 4 5 env4447 = env4448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env4447 == env4448) = true)

def leafEnv4448 : List Nat := [2,4,6,0,5,1,3,5,5,5,5,1,7,5,0,3,1,0,4,0,1,5,0,6,0,3,1,1,1,5,4,5,0,4,4,4,4,6,1,4,1,4,0]

def active4448 : List Nat := [0,1]

def tree4448 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4448 : H12WitnessSearch.Good tree4448 := H12GlobalWitnessIndex.good

theorem leafIdentity4448 : H12AffineFastState.composeSystem env4448 rootObs = leafEnv4448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4448 rootObs == leafEnv4448) = true)

theorem terminalChecked4448 : H12PackedTerminal.terminalCheckFast leafEnv4448 active4448 tree4448 = true := by decide +kernel

def env4449 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,26002,4525,262144,1025,32768,4096,4194304,4240697,41002,8329,4240696,323713,16384,16812,22561,16824,17413,257,20480,4239677,4241029]

theorem envBound4449 : H12AffineFastState.Bounded env4449 := by
  intro p hp
  have h : env4449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4422_4449 : H12AffineEnvironment.transform 22 4240697 env4422 = env4449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240697 env4422 == env4449) = true)

theorem identity4449 : scanCanonicalize (H12AffineFastState.compose env4449 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13577) := by decide +kernel

theorem selectedBound4449 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4450 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,13577,26002,4525,262144,1025,13577,4096,4194304,4194352,5411,8329,4194353,279944,16384,16812,22561,16824,17413,257,20480,4195380,4195212]

theorem envBound4450 : H12AffineFastState.Bounded env4450 := by
  intro p hp
  have h : env4450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4449_4450 : H12AffineEnvironment.transform 14 13577 env4449 = env4450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13577 env4449 == env4450) = true)

def env4451 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13577,25986,4525,262144,1025,13577,4096,4194304,4194336,5411,8329,4194337,279944,16384,16812,22561,16808,17413,257,20480,4195364,4195212]

theorem envBound4451 : H12AffineFastState.Bounded env4451 := by
  intro p hp
  have h : env4451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4450_4451 : H12AffineEnvironment.transform 3 0 env4450 = env4451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4450 == env4451) = true)

def env4452 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13577,25986,4525,262144,1025,13577,4096,32,0,5411,8329,1,279944,16384,16812,22561,16808,17413,257,20480,1028,940]

theorem envBound4452 : H12AffineFastState.Bounded env4452 := by
  intro p hp
  have h : env4452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4451_4452 : H12AffineEnvironment.transform 21 32 env4451 = env4452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4451 == env4452) = true)

theorem identity4452 : scanCanonicalize (H12AffineFastState.compose env4452 (packedSelected [0,3,7,9,10,20,22,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4452 : packedSelected [0,3,7,9,10,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env4453 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,25646,4097,262144,1025,13477,4096,32,0,5263,8329,1,279588,16384,16384,22561,16388,17413,173,20480,1028,512]

theorem envBound4453 : H12AffineFastState.Bounded env4453 := by
  intro p hp
  have h : env4453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4452_4453 : H12AffineEnvironment.transform 7 172 env4452 = env4453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4452 == env4453) = true)

theorem identity4453 : scanCanonicalize (H12AffineFastState.compose env4453 (packedSelected [6] rootPS)) = affineNative (2^(17+1) ^^^ 21671) := by decide +kernel

theorem selectedBound4453 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4454 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,16384,13477,25646,4097,21671,1025,13477,4096,32,0,5263,8329,1,4227,16384,16384,22561,16388,17413,173,20480,1028,512]

theorem envBound4454 : H12AffineFastState.Bounded env4454 := by
  intro p hp
  have h : env4454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4453_4454 : H12AffineEnvironment.transform 17 21671 env4453 = env4454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 21671 env4453 == env4454) = true)

theorem identity4454 : scanCanonicalize (H12AffineFastState.compose env4454 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 1677) := by decide +kernel

theorem selectedBound4454 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4455 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,4096,8192,1677,13477,8867,4097,4650,1025,13477,4096,32,0,5263,8329,1,4227,1677,1677,7852,1673,648,173,5773,1028,512]

theorem envBound4455 : H12AffineFastState.Bounded env4455 := by
  intro p hp
  have h : env4455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4454_4455 : H12AffineEnvironment.transform 13 1677 env4454 = env4455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1677 env4454 == env4455) = true)

theorem identity4455 : scanCanonicalize (H12AffineFastState.compose env4455 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound4455 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env4456 : List Nat := [2,4,8,0,32,1,128,172,512,1024,2048,1196,8192,1677,8201,8867,1197,1670,1025,8201,1196,32,0,35,8329,1,1071,1677,1677,2560,1673,648,173,545,1028,512]

theorem envBound4456 : H12AffineFastState.Bounded env4456 := by
  intro p hp
  have h : env4456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4455_4456 : H12AffineEnvironment.transform 11 1196 env4455 = env4456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env4455 == env4456) = true)

theorem identity4456 : scanCanonicalize (H12AffineFastState.compose env4456 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4456 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env4457 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1028,8192,1573,8201,8715,1029,1582,1025,8201,1028,32,0,35,8225,1,1071,1573,1573,2560,1569,544,5,545,1028,512]

theorem envBound4457 : H12AffineFastState.Bounded env4457 := by
  intro p hp
  have h : env4457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4456_4457 : H12AffineEnvironment.transform 6 40 env4456 = env4457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4456 == env4457) = true)

theorem identity4457 : scanCanonicalize (H12AffineFastState.compose env4457 (packedSelected [5] rootPS)) = affineNative (2^(12+1) ^^^ 3085) := by decide +kernel

theorem selectedBound4457 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4458 : List Nat := [2,4,8,0,32,1,40,4,512,1024,2048,1028,3085,1573,3076,3590,1029,1582,1025,3076,1028,32,0,35,3116,1,1071,1573,1573,2560,1569,544,5,545,1028,512]

theorem envBound4458 : H12AffineFastState.Bounded env4458 := by
  intro p hp
  have h : env4458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4457_4458 : H12AffineEnvironment.transform 12 3085 env4457 = env4458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3085 env4457 == env4458) = true)

theorem identity4458 : scanCanonicalize (H12AffineFastState.compose env4458 (packedSelected [8] rootPS)) = affineNative (2^(10+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4458 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4459 : List Nat := [2,4,8,0,32,1,40,4,512,1024,1038,1028,3,1573,10,520,1029,1582,1025,10,1028,32,0,35,34,1,1071,1573,1573,1550,1569,544,5,545,1028,512]

theorem envBound4459 : H12AffineFastState.Bounded env4459 := by
  intro p hp
  have h : env4459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4458_4459 : H12AffineEnvironment.transform 10 1038 env4458 = env4459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1038 env4458 == env4459) = true)

theorem identity4459 : scanCanonicalize (H12AffineFastState.compose env4459 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound4459 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4460 : List Nat := [2,4,8,0,32,1,40,4,512,36,42,32,3,513,10,520,33,522,37,10,32,32,0,35,34,1,11,513,513,554,517,544,5,545,32,512]

theorem envBound4460 : H12AffineFastState.Bounded env4460 := by
  intro p hp
  have h : env4460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4459_4460 : H12AffineEnvironment.transform 9 36 env4459 = env4460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env4459 == env4460) = true)

theorem identity4460 : scanCanonicalize (H12AffineFastState.compose env4460 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound4460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4461 : List Nat := [2,4,8,0,32,1,40,4,11,36,42,32,3,10,10,3,33,1,37,10,32,32,0,35,34,1,11,10,10,33,14,43,5,42,32,11]

theorem envBound4461 : H12AffineFastState.Bounded env4461 := by
  intro p hp
  have h : env4461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4460_4461 : H12AffineEnvironment.transform 8 11 env4460 = env4461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env4460 == env4461) = true)

theorem identity4461 : scanCanonicalize (H12AffineFastState.compose env4461 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4461 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env4462 : List Nat := [2,4,8,0,10,1,2,4,11,14,0,10,3,10,10,3,11,1,15,10,10,10,0,9,8,1,11,10,10,11,14,1,5,0,10,11]

theorem envBound4462 : H12AffineFastState.Bounded env4462 := by
  intro p hp
  have h : env4462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4461_4462 : H12AffineEnvironment.transform 4 10 env4461 = env4462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4461 == env4462) = true)

theorem identity4462 : scanCanonicalize (H12AffineFastState.compose env4462 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4462 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4463 : List Nat := [2,4,2,0,0,1,2,4,1,4,0,0,3,0,0,3,1,1,5,0,0,0,0,3,2,1,1,0,0,1,4,1,5,0,0,1]

theorem envBound4463 : H12AffineFastState.Bounded env4463 := by
  intro p hp
  have h : env4463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4462_4463 : H12AffineEnvironment.transform 2 2 env4462 = env4463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4462 == env4463) = true)

def env4464 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,13577,25986,4525,262144,1025,13577,4096,33,1,5411,8329,0,279944,16384,16812,22561,16808,17413,257,20480,1029,941]

theorem envBound4464 : H12AffineFastState.Bounded env4464 := by
  intro p hp
  have h : env4464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4451_4464 : H12AffineEnvironment.transform 21 33 env4451 = env4464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env4451 == env4464) = true)

def env4465 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,13577,25987,4525,262144,1025,13577,4096,4194304,4194337,5411,8329,4194336,279944,16384,16812,22561,16809,17413,257,20480,4195365,4195212]

theorem envBound4465 : H12AffineFastState.Bounded env4465 := by
  intro p hp
  have h : env4465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4450_4465 : H12AffineEnvironment.transform 3 1 env4450 = env4465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4450 == env4465) = true)

theorem identity4465 : scanCanonicalize (H12AffineFastState.compose env4465 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound4465 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4466 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1029,8192,16384,8460,25987,1448,262144,1025,8460,1029,4194304,4194337,294,8329,4194336,279944,16384,16812,19492,16809,17413,257,17413,4195365,4195212]

theorem envBound4466 : H12AffineFastState.Bounded env4466 := by
  intro p hp
  have h : env4466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4465_4466 : H12AffineEnvironment.transform 11 1029 env4465 = env4466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env4465 == env4466) = true)

theorem identity4466 : scanCanonicalize (H12AffineFastState.compose env4466 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4466 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4467 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1029,8192,16384,8201,25734,1197,262144,1025,8201,1029,4194304,4194337,35,8329,4194336,279693,16384,16553,19492,16556,17413,4,17413,4195365,4194953]

theorem envBound4467 : H12AffineFastState.Bounded env4467 := by
  intro p hp
  have h : env4467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4466_4467 : H12AffineEnvironment.transform 7 5 env4466 = env4467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4466 == env4467) = true)

def env4468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4096,4194304,8388608,41002,8329,8914001,849105,16385,16892,547953,598059,12644668,525568,545872,8479126,8914924]

theorem envBound4468 : H12AffineFastState.Bounded env4468 := by
  intro p hp
  have h : env4468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4340_4468 : H12AffineEnvironment.transform 27 16385 env4340 = env4468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16385 env4340 == env4468) = true)

def env4469 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,4194304,8388608,41002,8329,8388689,323793,16385,16892,22641,74795,12644668,256,20560,8479126,8389612]

theorem envBound4469 : H12AffineFastState.Bounded env4469 := by
  intro p hp
  have h : env4469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4468_4469 : H12AffineEnvironment.transform 18 1024 env4468 = env4469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4468 == env4469) = true)

theorem identity4469 : scanCanonicalize (H12AffineFastState.compose env4469 (packedSelected [14] rootPS)) = affineNative (2^(21+1) ^^^ 98387) := by decide +kernel

theorem selectedBound4469 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4096,98387,8388608,41002,8329,8388689,323793,16385,16892,22641,74795,8483183,256,20560,8479126,8389612]

theorem envBound4470 : H12AffineFastState.Bounded env4470 := by
  intro p hp
  have h : env4470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4469_4470 : H12AffineEnvironment.transform 21 98387 env4469 = env4470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98387 env4469 == env4470) = true)

def env4471 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,98307,8388608,41002,8329,8388609,323713,16385,16812,22561,74795,8483135,256,20480,8479126,8389564]

theorem envBound4471 : H12AffineFastState.Bounded env4471 := by
  intro p hp
  have h : env4471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4470_4471 : H12AffineEnvironment.transform 5 16 env4470 = env4471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4470 == env4471) = true)

theorem identity4471 : scanCanonicalize (H12AffineFastState.compose env4471 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 444) := by decide +kernel

theorem selectedBound4471 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4472 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1024,32768,4096,98307,444,41002,8329,445,323713,16385,16812,22561,74795,94339,256,20480,90154,512]

theorem envBound4472 : H12AffineFastState.Bounded env4472 := by
  intro p hp
  have h : env4472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4471_4472 : H12AffineEnvironment.transform 22 444 env4471 = env4472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 444 env4471 == env4472) = true)

theorem identity4472 : scanCanonicalize (H12AffineFastState.compose env4472 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8582) := by decide +kernel

theorem selectedBound4472 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4473 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8582,4524,262144,1024,32768,4096,41349,444,41002,8329,445,323713,16385,16812,22561,1453,20741,256,20480,16812,512]

theorem envBound4473 : H12AffineFastState.Bounded env4473 := by
  intro p hp
  have h : env4473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4472_4473 : H12AffineEnvironment.transform 15 8582 env4472 = env4473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8582 env4472 == env4473) = true)

theorem identity4473 : scanCanonicalize (H12AffineFastState.compose env4473 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4473 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4474 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13884,8582,4524,262144,1024,13884,4096,6073,444,5654,8329,445,280253,16385,16812,22561,1453,20741,256,20480,16812,512]

theorem envBound4474 : H12AffineFastState.Bounded env4474 := by
  intro p hp
  have h : env4474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4473_4474 : H12AffineEnvironment.transform 14 13884 env4473 = env4474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4473 == env4474) = true)

theorem identity4474 : scanCanonicalize (H12AffineFastState.compose env4474 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound4474 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4475 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,13884,8582,4524,262144,1024,13884,4096,6073,444,5654,8329,445,268216,4356,4265,2340,1453,0,256,261,4265,512]

theorem envBound4475 : H12AffineFastState.Bounded env4475 := by
  intro p hp
  have h : env4475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4474_4475 : H12AffineEnvironment.transform 13 4357 env4474 = env4475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env4474 == env4475) = true)

theorem identity4475 : scanCanonicalize (H12AffineFastState.compose env4475 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound4475 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env4476 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,13884,8582,4524,2340,1024,13884,4096,6073,444,5654,8329,445,7836,4356,4265,2340,1453,0,256,261,4265,512]

theorem envBound4476 : H12AffineFastState.Bounded env4476 := by
  intro p hp
  have h : env4476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4475_4476 : H12AffineEnvironment.transform 17 2340 env4475 = env4476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env4475 == env4476) = true)

theorem identity4476 : scanCanonicalize (H12AffineFastState.compose env4476 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4476 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4477 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13884,8322,4264,2080,1024,13884,4096,5821,184,5654,8329,185,7836,4096,4265,2080,1193,0,4,1,4265,512]

theorem envBound4477 : H12AffineFastState.Bounded env4477 := by
  intro p hp
  have h : env4477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4476_4477 : H12AffineEnvironment.transform 7 4 env4476 = env4477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4476 == env4477) = true)

theorem identity4477 : scanCanonicalize (H12AffineFastState.compose env4477 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1692) := by decide +kernel

theorem selectedBound4477 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4478 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,1692,8192,1693,8352,8322,1588,2080,1024,8352,1692,33,184,138,8329,185,2048,1692,1589,2080,1193,0,4,1,1589,512]

theorem envBound4478 : H12AffineFastState.Bounded env4478 := by
  intro p hp
  have h : env4478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4477_4478 : H12AffineEnvironment.transform 11 1692 env4477 = env4478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1692 env4477 == env4478) = true)

theorem identity4478 : scanCanonicalize (H12AffineFastState.compose env4478 (packedSelected [3,5] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound4478 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4479 : List Nat := [2,4,8,16,32,16,128,4,512,188,2048,544,8192,545,8352,8322,648,2080,188,8352,544,33,184,138,8329,185,2048,544,649,2080,21,0,4,1,649,512]

theorem envBound4479 : H12AffineFastState.Bounded env4479 := by
  intro p hp
  have h : env4479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4478_4479 : H12AffineEnvironment.transform 9 188 env4478 = env4479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env4478 == env4479) = true)

theorem identity4479 : scanCanonicalize (H12AffineFastState.compose env4479 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 51) := by decide +kernel

theorem selectedBound4479 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4480 : List Nat := [2,4,8,16,32,16,51,4,512,15,2048,544,8192,545,8211,8241,571,2080,15,8211,544,33,11,57,8250,10,2048,544,570,2080,21,0,4,1,570,512]

theorem envBound4480 : H12AffineFastState.Bounded env4480 := by
  intro p hp
  have h : env4480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4479_4480 : H12AffineEnvironment.transform 6 51 env4479 = env4480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 51 env4479 == env4480) = true)

theorem identity4480 : scanCanonicalize (H12AffineFastState.compose env4480 (packedSelected [10] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound4480 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env4481 : List Nat := [2,4,8,11,32,11,40,4,512,15,2048,544,8192,545,8200,8234,544,2080,15,8200,544,33,11,34,8225,10,2048,544,545,2080,14,0,4,1,545,512]

theorem envBound4481 : H12AffineFastState.Bounded env4481 := by
  intro p hp
  have h : env4481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4480_4481 : H12AffineEnvironment.transform 3 11 env4480 = env4481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env4480 == env4481) = true)

theorem identity4481 : scanCanonicalize (H12AffineFastState.compose env4481 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound4481 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4482 : List Nat := [2,4,8,11,32,11,40,4,512,15,522,544,8192,545,8200,8234,544,554,15,8200,544,33,11,34,8225,10,522,544,545,554,14,0,4,1,545,512]

theorem envBound4482 : H12AffineFastState.Bounded env4482 := by
  intro p hp
  have h : env4482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4481_4482 : H12AffineEnvironment.transform 10 522 env4481 = env4482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env4481 == env4482) = true)

theorem identity4482 : scanCanonicalize (H12AffineFastState.compose env4482 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 547) := by decide +kernel

theorem selectedBound4482 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4483 : List Nat := [2,4,8,11,32,11,40,4,512,15,522,544,547,545,555,521,544,554,15,555,544,33,11,34,514,10,522,544,545,554,14,0,4,1,545,512]

theorem envBound4483 : H12AffineFastState.Bounded env4483 := by
  intro p hp
  have h : env4483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4482_4483 : H12AffineEnvironment.transform 12 547 env4482 = env4483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 547 env4482 == env4483) = true)

def env4484 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98306,8388608,41002,8329,8388608,323712,16385,16813,22560,74795,8483134,256,20481,8479126,8389565]

theorem envBound4484 : H12AffineFastState.Bounded env4484 := by
  intro p hp
  have h : env4484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4470_4484 : H12AffineEnvironment.transform 5 17 env4470 = env4484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4470 == env4484) = true)

def env4485 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98306,8388608,41002,8329,8388608,323712,16385,16813,22560,74795,8483118,256,20481,8479110,8389549]

theorem envBound4485 : H12AffineFastState.Bounded env4485 := by
  intro p hp
  have h : env4485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4484_4485 : H12AffineEnvironment.transform 3 0 env4484 = env4485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4484 == env4485) = true)

theorem identity4485 : scanCanonicalize (H12AffineFastState.compose env4485 (packedSelected [0,2,9,11,18,22,27] rootPS)) = affineNative (2^(22+1) ^^^ 284808) := by decide +kernel

theorem selectedBound4485 : packedSelected [0,2,9,11,18,22,27] rootPS < 2^1333 := by decide +kernel

def env4486 : List Nat := [2,4,8,0,32,1,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98306,284808,41002,8329,284808,323712,16385,16813,22560,74795,338342,256,20481,342286,285477]

theorem envBound4486 : H12AffineFastState.Bounded env4486 := by
  intro p hp
  have h : env4486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4485_4486 : H12AffineEnvironment.transform 22 284808 env4485 = env4486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 284808 env4485 == env4486) = true)

def env4487 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,65536,4357,262144,1024,32768,4096,98306,284704,41002,8225,284704,323624,16385,16645,22560,74795,338190,256,20481,342286,285477]

theorem envBound4487 : H12AffineFastState.Bounded env4487 := by
  intro p hp
  have h : env4487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4486_4487 : H12AffineEnvironment.transform 6 40 env4486 = env4487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4486 == env4487) = true)

theorem identity4487 : scanCanonicalize (H12AffineFastState.compose env4487 (packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound4487 : packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env4488 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,8494,4357,262144,1024,32768,4096,41260,284704,41002,8225,284704,323624,16385,16645,22560,1285,264224,256,20481,268320,285477]

theorem envBound4488 : H12AffineFastState.Bounded env4488 := by
  intro p hp
  have h : env4488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4487_4488 : H12AffineEnvironment.transform 15 8494 env4487 = env4488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env4487 == env4488) = true)

theorem identity4488 : scanCanonicalize (H12AffineFastState.compose env4488 (packedSelected [2,11,18] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound4488 : packedSelected [2,11,18] rootPS < 2^1333 := by decide +kernel

def env4489 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,32768,8494,4357,2341,1024,32768,4096,41260,20741,41002,8225,20741,63757,16385,16645,22560,1285,261,256,20481,4357,20992]

theorem envBound4489 : H12AffineFastState.Bounded env4489 := by
  intro p hp
  have h : env4489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4488_4489 : H12AffineEnvironment.transform 17 2341 env4488 = env4489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env4488 == env4489) = true)

theorem identity4489 : scanCanonicalize (H12AffineFastState.compose env4489 (packedSelected [0,3,4,7,8,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 23040) := by decide +kernel

theorem selectedBound4489 : packedSelected [0,3,4,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env4490 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,4096,8192,16384,23040,8494,4357,2341,1024,23040,4096,31532,20741,31274,8225,20741,8973,16385,16645,22560,1285,261,256,20481,4357,20992]

theorem envBound4490 : H12AffineFastState.Bounded env4490 := by
  intro p hp
  have h : env4490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4489_4490 : H12AffineEnvironment.transform 14 23040 env4489 = env4490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 23040 env4489 == env4490) = true)

theorem identity4490 : scanCanonicalize (H12AffineFastState.compose env4490 (packedSelected [0,4,5,6,7,8,9,12,13,15] rootPS)) = affineNative (2^(11+1) ^^^ 2351) := by decide +kernel

theorem selectedBound4490 : packedSelected [0,4,5,6,7,8,9,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4491 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,2351,8192,16384,17199,8494,2090,2341,1024,17199,2351,25091,18474,25349,8225,18474,8973,16385,16645,16655,1285,261,256,18734,2090,19247]

theorem envBound4491 : H12AffineFastState.Bounded env4491 := by
  intro p hp
  have h : env4491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4490_4491 : H12AffineEnvironment.transform 11 2351 env4490 = env4491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2351 env4490 == env4491) = true)

theorem identity4491 : scanCanonicalize (H12AffineFastState.compose env4491 (packedSelected [6,13,17] rootPS)) = affineNative (2^(13+1) ^^^ 2350) := by decide +kernel

theorem selectedBound4491 : packedSelected [6,13,17] rootPS < 2^1333 := by decide +kernel

def env4492 : List Nat := [2,4,8,0,32,1,40,256,512,1024,2048,2351,8192,2350,2561,8494,2090,2341,1024,2561,2351,11053,260,10795,8225,260,8973,2351,2091,2081,1285,261,256,0,2090,513]

theorem envBound4492 : H12AffineFastState.Bounded env4492 := by
  intro p hp
  have h : env4492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4491_4492 : H12AffineEnvironment.transform 13 2350 env4491 = env4492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2350 env4491 == env4492) = true)

theorem identity4492 : scanCanonicalize (H12AffineFastState.compose env4492 (packedSelected [5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound4492 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env4493 : List Nat := [2,4,8,0,32,1,40,256,512,1024,1802,1573,8192,1572,1291,8494,1824,1583,1024,1291,1573,9255,260,9505,8225,260,8973,1573,1825,1835,1285,261,256,0,1824,513]

theorem envBound4493 : H12AffineFastState.Bounded env4493 := by
  intro p hp
  have h : env4493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4492_4493 : H12AffineEnvironment.transform 10 1802 env4492 = env4493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env4492 == env4493) = true)

theorem identity4493 : scanCanonicalize (H12AffineFastState.compose env4493 (packedSelected [0,1,2,4,7,11,12,13] rootPS)) = affineNative (2^(12+1) ^^^ 1064) := by decide +kernel

theorem selectedBound4493 : packedSelected [0,1,2,4,7,11,12,13] rootPS < 2^1333 := by decide +kernel

def env4494 : List Nat := [2,4,8,0,32,1,40,256,512,1024,1802,1573,1064,1572,1291,1286,1824,1583,1024,1291,1573,15,260,265,1033,260,1829,1573,1825,1835,1285,261,256,0,1824,513]

theorem envBound4494 : H12AffineFastState.Bounded env4494 := by
  intro p hp
  have h : env4494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4493_4494 : H12AffineEnvironment.transform 12 1064 env4493 = env4494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1064 env4493 == env4494) = true)

theorem identity4494 : scanCanonicalize (H12AffineFastState.compose env4494 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4494 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4495 : List Nat := [2,4,8,0,32,1,40,5,512,1024,1551,1573,1064,1572,1038,1027,1573,1583,1024,1038,1573,15,1,12,1033,1,1568,1573,1572,1582,1024,0,5,0,1573,513]

theorem envBound4495 : H12AffineFastState.Bounded env4495 := by
  intro p hp
  have h : env4495.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4494_4495 : H12AffineEnvironment.transform 7 5 env4494 = env4495 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4494 == env4495) = true)

theorem identity4495 : scanCanonicalize (H12AffineFastState.compose env4495 (packedSelected [0,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4495 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env4496 : List Nat := [2,4,8,0,10,1,2,5,512,1024,1551,1551,1026,1550,1038,1027,1551,1541,1024,1038,1551,15,1,12,1033,1,1546,1551,1550,1540,1024,0,5,0,1551,513]

theorem envBound4496 : H12AffineFastState.Bounded env4496 := by
  intro p hp
  have h : env4496.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4495_4496 : H12AffineEnvironment.transform 4 10 env4495 = env4496 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4495 == env4496) = true)

theorem identity4496 : scanCanonicalize (H12AffineFastState.compose env4496 (packedSelected [1,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4496 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env4497 : List Nat := [2,0,8,0,10,1,2,1,512,1024,1547,1547,1026,1546,1034,1027,1547,1537,1024,1034,1547,11,1,8,1033,1,1546,1547,1546,1536,1024,0,1,0,1547,513]

theorem envBound4497 : H12AffineFastState.Bounded env4497 := by
  intro p hp
  have h : env4497.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4496_4497 : H12AffineEnvironment.transform 1 0 env4496 = env4497 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4496 == env4497) = true)

theorem identity4497 : scanCanonicalize (H12AffineFastState.compose env4497 (packedSelected [11] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4497 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env4498 : List Nat := [2,0,8,0,10,1,2,1,0,1024,1035,1035,1026,1034,1034,1027,1035,1025,1024,1034,1035,11,1,8,1033,1,1034,1035,1034,1024,1024,0,1,0,1035,1]

theorem envBound4498 : H12AffineFastState.Bounded env4498 := by
  intro p hp
  have h : env4498.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4497_4498 : H12AffineEnvironment.transform 8 0 env4497 = env4498 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4497 == env4498) = true)

theorem identity4498 : scanCanonicalize (H12AffineFastState.compose env4498 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 10) := by decide +kernel

theorem selectedBound4498 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4499 : List Nat := [2,0,8,0,10,1,2,1,0,10,1,1,8,0,0,9,1,11,10,0,1,11,1,8,3,1,0,1,0,10,10,0,1,0,1,1]

theorem envBound4499 : H12AffineFastState.Bounded env4499 := by
  intro p hp
  have h : env4499.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4498_4499 : H12AffineEnvironment.transform 9 10 env4498 = env4499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 10 env4498 == env4499) = true)

def leafEnv4499 : List Nat := [2,0,8,0,10,1,2,1,0,10,1,1,8,0,0,9,1,11,10,0,1,11,1,8,10,3,1,1,0,1,0,10,10,0,1,0,0,2,1,1,1,0,0]

def active4499 : List Nat := [0,2]

def tree4499 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4499 : H12WitnessSearch.Good tree4499 := H12GlobalWitnessIndex.good

theorem leafIdentity4499 : H12AffineFastState.composeSystem env4499 rootObs = leafEnv4499 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4499 rootObs == leafEnv4499) = true)

theorem terminalChecked4499 : H12PackedTerminal.terminalCheckFast leafEnv4499 active4499 tree4499 = true := by decide +kernel

def env4500 : List Nat := [2,4,8,0,32,1,41,256,512,1024,2048,4096,8192,16384,32768,65536,4356,262144,1024,32768,4096,98306,284705,41002,8224,284705,323625,16385,16644,22560,74795,338191,256,20481,342286,285477]

theorem envBound4500 : H12AffineFastState.Bounded env4500 := by
  intro p hp
  have h : env4500.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4486_4500 : H12AffineEnvironment.transform 6 41 env4486 = env4500 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4486 == env4500) = true)

theorem identity4500 : scanCanonicalize (H12AffineFastState.compose env4500 (packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4500 : packedSelected [0,4,5,7,17,18,21,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env4501 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,65536,4097,262144,1024,32768,4096,98306,284705,41002,8224,284705,323625,16385,16385,22560,74795,337930,5,20481,342027,285216]

theorem envBound4501 : H12AffineFastState.Bounded env4501 := by
  intro p hp
  have h : env4501.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4500_4501 : H12AffineEnvironment.transform 7 5 env4500 = env4501 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4500 == env4501) = true)

theorem identity4501 : scanCanonicalize (H12AffineFastState.compose env4501 (packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4501 : packedSelected [0,2,3,4,5,7,10,11,17,18,21,22] rootPS < 2^1333 := by decide +kernel

def env4502 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,65536,4097,2081,1024,32768,4096,98306,20480,41002,8224,20480,63496,16385,16385,22560,74795,73771,5,20481,77866,20993]

theorem envBound4502 : H12AffineFastState.Bounded env4502 := by
  intro p hp
  have h : env4502.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4501_4502 : H12AffineEnvironment.transform 17 2081 env4501 = env4502 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4501 == env4502) = true)

theorem identity4502 : scanCanonicalize (H12AffineFastState.compose env4502 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 38920) := by decide +kernel

theorem selectedBound4502 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env4503 : List Nat := [2,4,8,0,32,1,41,5,512,1024,2048,4096,8192,16384,32768,38920,4097,2081,1024,32768,4096,6154,20480,41002,8224,20480,63496,16385,16385,22560,48163,47139,5,20481,43042,20993]

theorem envBound4503 : H12AffineFastState.Bounded env4503 := by
  intro p hp
  have h : env4503.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4502_4503 : H12AffineEnvironment.transform 15 38920 env4502 = env4503 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38920 env4502 == env4503) = true)

theorem identity4503 : scanCanonicalize (H12AffineFastState.compose env4503 (packedSelected [0,1,4,5,6,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 1583) := by decide +kernel

theorem selectedBound4503 : packedSelected [0,1,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env4504 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1583,4096,8192,16384,32768,38439,4097,1550,1024,32768,4096,5669,20480,41002,8224,20480,63015,16385,16385,22031,45580,46604,5,20481,42509,20993]

theorem envBound4504 : H12AffineFastState.Bounded env4504 := by
  intro p hp
  have h : env4504.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4503_4504 : H12AffineEnvironment.transform 10 1583 env4503 = env4504 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1583 env4503 == env4504) = true)

theorem identity4504 : scanCanonicalize (H12AffineFastState.compose env4504 (packedSelected [1,8,13,15] rootPS)) = affineNative (2^(14+1) ^^^ 16906) := by decide +kernel

theorem selectedBound4504 : packedSelected [1,8,13,15] rootPS < 2^1333 := by decide +kernel

def env4505 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1583,4096,8192,16384,16906,21549,4097,1550,1024,16906,4096,5669,20480,25120,8224,20480,13357,16385,16385,22031,28678,29702,5,20481,25607,20993]

theorem envBound4505 : H12AffineFastState.Bounded env4505 := by
  intro p hp
  have h : env4505.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4504_4505 : H12AffineEnvironment.transform 14 16906 env4504 = env4505 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 16906 env4504 == env4505) = true)

theorem identity4505 : scanCanonicalize (H12AffineFastState.compose env4505 (packedSelected [1,3,4,7,11,13] rootPS)) = affineNative (2^(12+1) ^^^ 4642) := by decide +kernel

theorem selectedBound4505 : packedSelected [1,3,4,7,11,13] rootPS < 2^1333 := by decide +kernel

def env4506 : List Nat := [2,4,8,0,32,1,41,5,512,1024,1583,4096,4642,16384,16906,21549,4097,1550,1024,16906,4096,5669,20480,20482,4610,20480,1551,16385,16385,22031,16932,17956,5,20481,22053,20993]

theorem envBound4506 : H12AffineFastState.Bounded env4506 := by
  intro p hp
  have h : env4506.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4505_4506 : H12AffineEnvironment.transform 12 4642 env4505 = env4506 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4642 env4505 == env4506) = true)

theorem identity4506 : scanCanonicalize (H12AffineFastState.compose env4506 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4506 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4507 : List Nat := [2,4,3,0,32,1,34,5,512,1024,1572,4096,4642,16384,16897,21542,4097,1541,1024,16897,4096,5669,20480,20482,4610,20480,1540,16385,16385,22020,16932,17956,5,20481,22053,20993]

theorem envBound4507 : H12AffineFastState.Bounded env4507 := by
  intro p hp
  have h : env4507.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4506_4507 : H12AffineEnvironment.transform 2 3 env4506 = env4507 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4506 == env4507) = true)

theorem identity4507 : scanCanonicalize (H12AffineFastState.compose env4507 (packedSelected [0,3,8,9] rootPS)) = affineNative (2^(13+1) ^^^ 4097) := by decide +kernel

theorem selectedBound4507 : packedSelected [0,3,8,9] rootPS < 2^1333 := by decide +kernel

def env4508 : List Nat := [2,4,3,0,32,1,34,5,512,1024,1572,4096,4642,4097,4608,1063,4097,1541,1024,4608,4096,5669,1,3,4610,1,1540,4096,4096,1541,4645,5669,5,0,1572,512]

theorem envBound4508 : H12AffineFastState.Bounded env4508 := by
  intro p hp
  have h : env4508.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4507_4508 : H12AffineEnvironment.transform 13 4097 env4507 = env4508 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4097 env4507 == env4508) = true)

theorem identity4508 : scanCanonicalize (H12AffineFastState.compose env4508 (packedSelected [0,1,3,6,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4508 : packedSelected [0,1,3,6,7] rootPS < 2^1333 := by decide +kernel

def env4509 : List Nat := [2,4,3,0,0,1,2,5,512,1024,1540,4096,4610,4097,4608,1031,4097,1541,1024,4608,4096,5637,1,3,4610,1,1540,4096,4096,1541,4613,5637,5,0,1540,512]

theorem envBound4509 : H12AffineFastState.Bounded env4509 := by
  intro p hp
  have h : env4509.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4508_4509 : H12AffineEnvironment.transform 4 0 env4508 = env4509 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4508 == env4509) = true)

theorem identity4509 : scanCanonicalize (H12AffineFastState.compose env4509 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1541) := by decide +kernel

theorem selectedBound4509 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4510 : List Nat := [2,4,3,0,0,1,2,5,512,1024,1540,1541,1031,1540,1029,1031,1540,1541,1024,1029,1541,0,1,3,1031,1,1540,1541,1541,1541,1024,0,5,0,1540,512]

theorem envBound4510 : H12AffineFastState.Bounded env4510 := by
  intro p hp
  have h : env4510.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4509_4510 : H12AffineEnvironment.transform 11 1541 env4509 = env4510 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1541 env4509 == env4510) = true)

theorem identity4510 : scanCanonicalize (H12AffineFastState.compose env4510 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound4510 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4511 : List Nat := [2,4,3,0,0,1,2,5,512,517,1,0,514,1,512,514,1,0,517,512,0,0,1,3,514,1,1,0,0,0,517,0,5,0,1,512]

theorem envBound4511 : H12AffineFastState.Bounded env4511 := by
  intro p hp
  have h : env4511.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4510_4511 : H12AffineEnvironment.transform 9 517 env4510 = env4511 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env4510 == env4511) = true)

theorem identity4511 : scanCanonicalize (H12AffineFastState.compose env4511 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4511 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4512 : List Nat := [2,4,3,0,0,1,2,5,0,5,1,0,2,1,0,2,1,0,5,0,0,0,1,3,2,1,1,0,0,0,5,0,5,0,1,0]

theorem envBound4512 : H12AffineFastState.Bounded env4512 := by
  intro p hp
  have h : env4512.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4511_4512 : H12AffineEnvironment.transform 8 0 env4511 = env4512 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4511 == env4512) = true)

def env4513 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1024,32768,4096,98306,8388608,41002,8329,8388608,323712,16385,16813,22560,74795,8483119,256,20481,8479111,8389548]

theorem envBound4513 : H12AffineFastState.Bounded env4513 := by
  intro p hp
  have h : env4513.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4484_4513 : H12AffineEnvironment.transform 3 1 env4484 = env4513 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4484 == env4513) = true)

theorem identity4513 : scanCanonicalize (H12AffineFastState.compose env4513 (packedSelected [0,2,9,11,18,22,27] rootPS)) = affineNative (2^(17+1) ^^^ 2445) := by decide +kernel

theorem selectedBound4513 : packedSelected [0,2,9,11,18,22,27] rootPS < 2^1333 := by decide +kernel

def env4514 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2445,1024,32768,4096,98306,8388608,41002,8329,8388608,63757,16385,16813,22560,74795,8483119,256,20481,8479111,8389548]

theorem envBound4514 : H12AffineFastState.Bounded env4514 := by
  intro p hp
  have h : env4514.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4513_4514 : H12AffineEnvironment.transform 17 2445 env4513 = env4514 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2445 env4513 == env4514) = true)

def env4515 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2445,1024,32768,4096,98306,61600,41002,8329,61600,63757,16385,16813,22560,74795,98703,256,20481,102695,62220]

theorem envBound4515 : H12AffineFastState.Bounded env4515 := by
  intro p hp
  have h : env4515.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4514_4515 : H12AffineEnvironment.transform 22 61600 env4514 = env4515 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61600 env4514 == env4515) = true)

theorem identity4515 : scanCanonicalize (H12AffineFastState.compose env4515 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 28803) := by decide +kernel

theorem selectedBound4515 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4516 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,28803,4525,2445,1024,32768,4096,61569,61600,41002,8329,61600,63757,16385,16813,22560,21672,61708,256,20481,57764,62220]

theorem envBound4516 : H12AffineFastState.Bounded env4516 := by
  intro p hp
  have h : env4516.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4515_4516 : H12AffineEnvironment.transform 15 28803 env4515 = env4516 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28803 env4515 == env4516) = true)

theorem identity4516 : scanCanonicalize (H12AffineFastState.compose env4516 (packedSelected [2,4,9,11,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound4516 : packedSelected [2,4,9,11,20,23] rootPS < 2^1333 := by decide +kernel

def env4517 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,8461,28803,4525,2445,1024,8461,4096,20876,20909,295,8329,20909,22528,16385,16813,22560,21672,20481,256,20481,16553,20993]

theorem envBound4517 : H12AffineFastState.Bounded env4517 := by
  intro p hp
  have h : env4517.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4516_4517 : H12AffineEnvironment.transform 14 8461 env4516 = env4517 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env4516 == env4517) = true)

theorem identity4517 : scanCanonicalize (H12AffineFastState.compose env4517 (packedSelected [0,3,4,5,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 7821) := by decide +kernel

theorem selectedBound4517 : packedSelected [0,3,4,5,7,9] rootPS < 2^1333 := by decide +kernel

def env4518 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,7821,8461,11790,4525,2445,1024,8461,4096,3841,3872,295,8329,3872,1677,7820,7968,1709,2597,3724,256,3724,7716,3212]

theorem envBound4518 : H12AffineFastState.Bounded env4518 := by
  intro p hp
  have h : env4518.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4517_4518 : H12AffineEnvironment.transform 13 7821 env4517 = env4518 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7821 env4517 == env4518) = true)

theorem identity4518 : scanCanonicalize (H12AffineFastState.compose env4518 (packedSelected [3,8,11,12,13,15] rootPS)) = affineNative (2^(12+1) ^^^ 4397) := by decide +kernel

theorem selectedBound4518 : packedSelected [3,8,11,12,13,15] rootPS < 2^1333 := by decide +kernel

def env4519 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,4397,7821,4128,7971,4525,2445,1024,4128,4096,3841,3872,295,4516,3872,1677,7820,7968,1709,2597,3724,256,3724,7716,3212]

theorem envBound4519 : H12AffineFastState.Bounded env4519 := by
  intro p hp
  have h : env4519.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4518_4519 : H12AffineEnvironment.transform 12 4397 env4518 = env4519 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4397 env4518 == env4519) = true)

theorem identity4519 : scanCanonicalize (H12AffineFastState.compose env4519 (packedSelected [6,10,11,13,17] rootPS)) = affineNative (2^(11+1) ^^^ 1038) := by decide +kernel

theorem selectedBound4519 : packedSelected [6,10,11,13,17] rootPS < 2^1333 := by decide +kernel

def env4520 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1038,1315,2691,1070,2861,1443,2445,1024,1070,1038,3841,3872,295,1450,3872,1677,2690,2862,1709,2597,3724,256,3724,2602,3212]

theorem envBound4520 : H12AffineFastState.Bounded env4520 := by
  intro p hp
  have h : env4520.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4519_4520 : H12AffineEnvironment.transform 11 1038 env4519 = env4520 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1038 env4519 == env4520) = true)

theorem identity4520 : scanCanonicalize (H12AffineFastState.compose env4520 (packedSelected [2,3,5,10,11,18] rootPS)) = affineNative (2^(10+1) ^^^ 1676) := by decide +kernel

theorem selectedBound4520 : packedSelected [2,3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env4521 : List Nat := [2,4,8,1,32,0,128,256,512,1024,1676,1038,1315,1039,1070,1441,1443,1793,1024,1070,1038,397,428,295,1450,428,1677,1038,1442,1709,1193,0,256,0,1190,512]

theorem envBound4521 : H12AffineFastState.Bounded env4521 := by
  intro p hp
  have h : env4521.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4520_4521 : H12AffineEnvironment.transform 10 1676 env4520 = env4521 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1676 env4520 == env4521) = true)

theorem identity4521 : scanCanonicalize (H12AffineFastState.compose env4521 (packedSelected [3,5] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound4521 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env4522 : List Nat := [2,4,8,1,32,0,128,256,42,1024,1190,1038,1315,1039,1070,1441,1443,1323,1024,1070,1038,397,428,295,1450,428,1191,1038,1442,1159,1193,0,256,0,1190,42]

theorem envBound4522 : H12AffineFastState.Bounded env4522 := by
  intro p hp
  have h : env4522.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4521_4522 : H12AffineEnvironment.transform 8 42 env4521 = env4522 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env4521 == env4522) = true)

theorem identity4522 : scanCanonicalize (H12AffineFastState.compose env4522 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4522 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4523 : List Nat := [2,4,8,1,32,0,41,256,42,1024,1039,1038,1315,1039,1070,1288,1290,1323,1024,1070,1038,292,261,295,1283,261,1038,1038,1291,1070,1024,0,256,0,1039,42]

theorem envBound4523 : H12AffineFastState.Bounded env4523 := by
  intro p hp
  have h : env4523.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4522_4523 : H12AffineEnvironment.transform 6 41 env4522 = env4523 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4522 == env4523) = true)

theorem identity4523 : scanCanonicalize (H12AffineFastState.compose env4523 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound4523 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4524 : List Nat := [2,4,8,1,32,0,41,256,42,288,303,302,3,303,270,40,42,11,288,270,302,292,261,295,35,261,302,302,43,270,288,0,256,0,303,42]

theorem envBound4524 : H12AffineFastState.Bounded env4524 := by
  intro p hp
  have h : env4524.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4523_4524 : H12AffineEnvironment.transform 9 288 env4523 = env4524 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env4523 == env4524) = true)

theorem identity4524 : scanCanonicalize (H12AffineFastState.compose env4524 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound4524 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4525 : List Nat := [2,4,8,1,11,0,2,256,1,267,260,261,3,260,270,3,1,11,267,270,261,271,261,268,8,261,261,261,0,270,267,0,256,0,260,1]

theorem envBound4525 : H12AffineFastState.Bounded env4525 := by
  intro p hp
  have h : env4525.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4524_4525 : H12AffineEnvironment.transform 4 11 env4524 = env4525 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env4524 == env4525) = true)

theorem identity4525 : scanCanonicalize (H12AffineFastState.compose env4525 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4525 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4526 : List Nat := [2,4,8,1,11,0,2,5,1,14,1,0,3,1,11,3,1,11,14,11,0,10,0,9,8,0,0,0,0,11,14,0,5,0,1,1]

theorem envBound4526 : H12AffineFastState.Bounded env4526 := by
  intro p hp
  have h : env4526.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4525_4526 : H12AffineEnvironment.transform 7 5 env4525 = env4526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4525 == env4526) = true)

theorem identity4526 : scanCanonicalize (H12AffineFastState.compose env4526 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4526 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4527 : List Nat := [2,4,2,1,1,0,2,5,1,4,1,0,3,1,1,3,1,1,4,1,0,0,0,3,2,0,0,0,0,1,4,0,5,0,1,1]

theorem envBound4527 : H12AffineFastState.Bounded env4527 := by
  intro p hp
  have h : env4527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4526_4527 : H12AffineEnvironment.transform 2 2 env4526 = env4527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4526 == env4527) = true)

def env4528 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,2445,1024,32768,4096,98306,61601,41002,8329,61601,63757,16385,16813,22560,74795,98702,256,20481,102694,62221]

theorem envBound4528 : H12AffineFastState.Bounded env4528 := by
  intro p hp
  have h : env4528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4514_4528 : H12AffineEnvironment.transform 22 61601 env4514 = env4528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 61601 env4514 == env4528) = true)

theorem identity4528 : scanCanonicalize (H12AffineFastState.compose env4528 (packedSelected [4,9,13,20,21] rootPS)) = affineNative (2^(15+1) ^^^ 29063) := by decide +kernel

theorem selectedBound4528 : packedSelected [4,9,13,20,21] rootPS < 2^1333 := by decide +kernel

def env4529 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,32768,29063,4525,2445,1024,32768,4096,61829,61601,41002,8329,61601,63757,16385,16813,22560,21932,61449,256,20481,57505,62221]

theorem envBound4529 : H12AffineFastState.Bounded env4529 := by
  intro p hp
  have h : env4529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4528_4529 : H12AffineEnvironment.transform 15 29063 env4528 = env4529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29063 env4528 == env4529) = true)

theorem identity4529 : scanCanonicalize (H12AffineFastState.compose env4529 (packedSelected [0,3,5,7,10,13,17,18,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 13869) := by decide +kernel

theorem selectedBound4529 : packedSelected [0,3,5,7,10,13,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env4530 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,4096,8192,16384,13869,29063,4525,2445,1024,13869,4096,18344,18060,5639,8329,18060,20256,16385,16813,22560,21932,17956,256,20481,22156,17696]

theorem envBound4530 : H12AffineFastState.Bounded env4530 := by
  intro p hp
  have h : env4530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4529_4530 : H12AffineEnvironment.transform 14 13869 env4529 = env4530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13869 env4529 == env4530) = true)

theorem identity4530 : scanCanonicalize (H12AffineFastState.compose env4530 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(11+1) ^^^ 1928) := by decide +kernel

theorem selectedBound4530 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env4531 : List Nat := [2,4,8,1,32,0,128,256,512,1024,2048,1928,8192,16384,8613,26127,1573,2445,1024,8613,1928,18344,18060,399,8329,18060,20256,16385,16813,20392,16932,17956,256,18313,16644,17696]

theorem envBound4531 : H12AffineFastState.Bounded env4531 := by
  intro p hp
  have h : env4531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4530_4531 : H12AffineEnvironment.transform 11 1928 env4530 = env4531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1928 env4530 == env4531) = true)

theorem identity4531 : scanCanonicalize (H12AffineFastState.compose env4531 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4531 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4532 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1677,8192,16384,8352,26127,1573,2184,1024,8352,1677,18093,18060,138,8329,18060,20005,16385,16552,20141,16932,17956,5,18060,16385,17445]

theorem envBound4532 : H12AffineFastState.Bounded env4532 := by
  intro p hp
  have h : env4532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4531_4532 : H12AffineEnvironment.transform 7 5 env4531 = env4532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4531 == env4532) = true)

theorem identity4532 : scanCanonicalize (H12AffineFastState.compose env4532 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 1551) := by decide +kernel

theorem selectedBound4532 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env4533 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1677,8192,1551,8352,8192,1573,2184,1024,8352,1677,162,131,138,8329,131,2090,1550,1703,2210,1067,43,5,131,1550,554]

theorem envBound4533 : H12AffineFastState.Bounded env4533 := by
  intro p hp
  have h : env4533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4532_4533 : H12AffineEnvironment.transform 13 1551 env4532 = env4533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1551 env4532 == env4533) = true)

theorem identity4533 : scanCanonicalize (H12AffineFastState.compose env4533 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 2721) := by decide +kernel

theorem selectedBound4533 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4534 : List Nat := [2,4,8,1,32,0,128,5,512,1024,2048,1677,2721,1551,2561,2721,1573,2184,1024,2561,1677,162,131,138,2600,131,2090,1550,1703,2210,1067,43,5,131,1550,554]

theorem envBound4534 : H12AffineFastState.Bounded env4534 := by
  intro p hp
  have h : env4534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4533_4534 : H12AffineEnvironment.transform 12 2721 env4533 = env4534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2721 env4533 == env4534) = true)

theorem identity4534 : scanCanonicalize (H12AffineFastState.compose env4534 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound4534 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env4535 : List Nat := [2,4,8,1,32,0,128,5,512,1024,1572,1677,1157,1551,1061,1157,1573,1708,1024,1061,1677,162,131,138,1036,131,1550,1550,1703,1670,1067,43,5,131,1550,554]

theorem envBound4535 : H12AffineFastState.Bounded env4535 := by
  intro p hp
  have h : env4535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4534_4535 : H12AffineEnvironment.transform 10 1572 env4534 = env4535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env4534 == env4535) = true)

theorem identity4535 : scanCanonicalize (H12AffineFastState.compose env4535 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound4535 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env4536 : List Nat := [2,4,8,1,32,0,40,5,512,1024,1572,1573,1069,1551,1061,1069,1573,1540,1024,1061,1573,10,43,34,1036,43,1550,1550,1551,1582,1067,43,5,43,1550,554]

theorem envBound4536 : H12AffineFastState.Bounded env4536 := by
  intro p hp
  have h : env4536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4535_4536 : H12AffineEnvironment.transform 6 40 env4535 = env4536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env4535 == env4536) = true)

def env4537 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,8388608,41002,8329,8388688,323792,16385,16892,22640,74794,12644668,257,20561,8479126,8389613]

theorem envBound4537 : H12AffineFastState.Bounded env4537 := by
  intro p hp
  have h : env4537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4468_4537 : H12AffineEnvironment.transform 18 1025 env4468 = env4537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4468 == env4537) = true)

theorem identity4537 : scanCanonicalize (H12AffineFastState.compose env4537 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 4310355) := by decide +kernel

theorem selectedBound4537 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4096,4194304,4310355,41002,8329,4310275,323792,16385,16892,22640,74794,78959,257,20561,4236485,4310718]

theorem envBound4538 : H12AffineFastState.Bounded env4538 := by
  intro p hp
  have h : env4538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4537_4538 : H12AffineEnvironment.transform 22 4310355 env4537 = env4538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4310355 env4537 == env4538) = true)

def env4539 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4096,4194304,4310275,41002,8329,4310275,323712,16385,16812,22560,74794,78911,257,20481,4236437,4310718]

theorem envBound4539 : H12AffineFastState.Bounded env4539 := by
  intro p hp
  have h : env4539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4538_4539 : H12AffineEnvironment.transform 5 16 env4538 = env4539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4538 == env4539) = true)

def env4540 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,65536,1028,262144,1025,32768,1448,4194304,4310275,41002,8329,4310275,320808,16385,16812,19848,74794,74135,257,17833,4236437,4310718]

theorem envBound4540 : H12AffineFastState.Bounded env4540 := by
  intro p hp
  have h : env4540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4539_4540 : H12AffineEnvironment.transform 11 1448 env4539 = env4540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1448 env4539 == env4540) = true)

theorem identity4540 : scanCanonicalize (H12AffineFastState.compose env4540 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50483) := by decide +kernel

theorem selectedBound4540 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4541 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1448,8192,16384,32768,50483,1028,262144,1025,32768,1448,4194304,4194352,41002,8329,4194352,320808,16385,16812,19848,57625,58532,257,17833,4236437,4195213]

theorem envBound4541 : H12AffineFastState.Bounded env4541 := by
  intro p hp
  have h : env4541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4540_4541 : H12AffineEnvironment.transform 15 50483 env4540 = env4541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50483 env4540 == env4541) = true)

def env4542 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,32768,50467,1028,262144,1025,32768,1448,4194304,4194336,41002,8329,4194336,320808,16385,16812,19848,57609,58532,257,17833,4236421,4195213]

theorem envBound4542 : H12AffineFastState.Bounded env4542 := by
  intro p hp
  have h : env4542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4541_4542 : H12AffineEnvironment.transform 3 0 env4541 = env4542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4541 == env4542) = true)

theorem identity4542 : scanCanonicalize (H12AffineFastState.compose env4542 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound4542 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4543 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1448,8192,16384,8461,25646,1028,262144,1025,8461,1448,4194304,4194336,295,8329,4194336,279589,16385,16812,19848,16388,17833,257,17833,4195720,4195213]

theorem envBound4543 : H12AffineFastState.Bounded env4543 := by
  intro p hp
  have h : env4543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4542_4543 : H12AffineEnvironment.transform 14 8461 env4542 = env4543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env4542 == env4543) = true)

theorem identity4543 : scanCanonicalize (H12AffineFastState.compose env4543 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4543 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4544 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1196,8192,16384,8201,25646,1028,262144,1025,8201,1196,4194304,4194336,35,8329,4194336,279589,16385,16552,19596,16388,17581,5,17581,4195468,4194953]

theorem envBound4544 : H12AffineFastState.Bounded env4544 := by
  intro p hp
  have h : env4544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4543_4544 : H12AffineEnvironment.transform 7 4 env4543 = env4544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4543 == env4544) = true)

def env4545 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50466,1028,262144,1025,32768,1448,4194304,4194337,41002,8329,4194337,320808,16385,16812,19848,57608,58532,257,17833,4236420,4195213]

theorem envBound4545 : H12AffineFastState.Bounded env4545 := by
  intro p hp
  have h : env4545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4541_4545 : H12AffineEnvironment.transform 3 1 env4541 = env4545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4541 == env4545) = true)

def env4546 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50466,1028,262144,1025,32768,1448,41088,41121,41002,8329,41121,320808,16385,16812,19848,57608,58532,257,17833,1028,41741]

theorem envBound4546 : H12AffineFastState.Bounded env4546 := by
  intro p hp
  have h : env4546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4545_4546 : H12AffineEnvironment.transform 21 41088 env4545 = env4546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41088 env4545 == env4546) = true)

theorem identity4546 : scanCanonicalize (H12AffineFastState.compose env4546 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4546 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4547 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,32768,50214,1028,262144,1025,32768,1196,41088,41121,41002,8329,41121,320556,16385,16552,19596,57356,58532,5,17581,1028,41481]

theorem envBound4547 : H12AffineFastState.Bounded env4547 := by
  intro p hp
  have h : env4547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4546_4547 : H12AffineEnvironment.transform 7 4 env4546 = env4547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4546 == env4547) = true)

theorem identity4547 : scanCanonicalize (H12AffineFastState.compose env4547 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 60548) := by decide +kernel

theorem selectedBound4547 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4548 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,32768,50214,1028,60548,1025,32768,1196,41088,41121,41002,8329,41121,2216,16385,16552,19596,57356,58532,5,17581,1028,41481]

theorem envBound4548 : H12AffineFastState.Bounded env4548 := by
  intro p hp
  have h : env4548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4547_4548 : H12AffineEnvironment.transform 17 60548 env4547 = env4548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 60548 env4547 == env4548) = true)

theorem identity4548 : scanCanonicalize (H12AffineFastState.compose env4548 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 26245) := by decide +kernel

theorem selectedBound4548 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env4549 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,16384,26245,8867,1028,2561,1025,26245,1196,17925,17956,18095,8329,17956,2216,16385,16552,19596,1673,545,5,17581,1028,17548]

theorem envBound4549 : H12AffineFastState.Bounded env4549 := by
  intro p hp
  have h : env4549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4548_4549 : H12AffineEnvironment.transform 14 26245 env4548 = env4549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 26245 env4548 == env4549) = true)

theorem identity4549 : scanCanonicalize (H12AffineFastState.compose env4549 (packedSelected [1,3,4,9,12,13,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 1197) := by decide +kernel

theorem selectedBound4549 : packedSelected [1,3,4,9,12,13,15,17,20] rootPS < 2^1333 := by decide +kernel

def env4550 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,8192,1197,8744,8867,1028,2561,1025,8744,1196,680,649,514,8329,649,2216,1196,1029,2081,1673,545,5,0,1028,33]

theorem envBound4550 : H12AffineFastState.Bounded env4550 := by
  intro p hp
  have h : env4550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4549_4550 : H12AffineEnvironment.transform 13 1197 env4549 = env4550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1197 env4549 == env4550) = true)

theorem identity4550 : scanCanonicalize (H12AffineFastState.compose env4550 (packedSelected [0,3,4,5,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 2731) := by decide +kernel

theorem selectedBound4550 : packedSelected [0,3,4,5,6,7,9] rootPS < 2^1333 := by decide +kernel

def env4551 : List Nat := [2,4,8,1,32,1,128,4,512,1024,2048,1196,2731,1197,2179,2056,1028,2561,1025,2179,1196,680,649,514,2594,649,2216,1196,1029,2081,1673,545,5,0,1028,33]

theorem envBound4551 : H12AffineFastState.Bounded env4551 := by
  intro p hp
  have h : env4551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4550_4551 : H12AffineEnvironment.transform 12 2731 env4550 = env4551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2731 env4550 == env4551) = true)

theorem identity4551 : scanCanonicalize (H12AffineFastState.compose env4551 (packedSelected [0,1,2,6,7,8,11,12] rootPS)) = affineNative (2^(8+1) ^^^ 131) := by decide +kernel

theorem selectedBound4551 : packedSelected [0,1,2,6,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env4552 : List Nat := [2,4,8,1,32,1,128,4,131,1024,2048,1196,2088,1197,2179,2056,1028,2178,1025,2179,1196,43,10,129,2209,10,2216,1196,1029,2081,1034,162,5,0,1028,33]

theorem envBound4552 : H12AffineFastState.Bounded env4552 := by
  intro p hp
  have h : env4552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4551_4552 : H12AffineEnvironment.transform 8 131 env4551 = env4552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 131 env4551 == env4552) = true)

theorem identity4552 : scanCanonicalize (H12AffineFastState.compose env4552 (packedSelected [3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound4552 : packedSelected [3,5,7] rootPS < 2^1333 := by decide +kernel

def env4553 : List Nat := [2,4,8,1,32,1,128,4,131,1024,32,1196,8,1197,163,40,1028,162,1025,163,1196,43,10,129,129,10,136,1196,1029,1,1034,162,5,0,1028,33]

theorem envBound4553 : H12AffineFastState.Bounded env4553 := by
  intro p hp
  have h : env4553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4552_4553 : H12AffineEnvironment.transform 10 32 env4552 = env4553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env4552 == env4553) = true)

theorem identity4553 : scanCanonicalize (H12AffineFastState.compose env4553 (packedSelected [0,3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound4553 : packedSelected [0,3,5,6] rootPS < 2^1333 := by decide +kernel

def env4554 : List Nat := [2,4,8,1,32,1,128,4,131,167,32,11,8,10,163,40,163,162,166,163,11,43,10,129,129,10,136,11,162,1,173,162,5,0,163,33]

theorem envBound4554 : H12AffineFastState.Bounded env4554 := by
  intro p hp
  have h : env4554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4553_4554 : H12AffineEnvironment.transform 9 167 env4553 = env4554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env4553 == env4554) = true)

theorem identity4554 : scanCanonicalize (H12AffineFastState.compose env4554 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4554 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env4555 : List Nat := [2,4,8,1,0,1,128,4,131,135,0,11,8,10,131,8,131,130,134,131,11,11,10,129,129,10,136,11,130,1,141,130,5,0,131,1]

theorem envBound4555 : H12AffineFastState.Bounded env4555 := by
  intro p hp
  have h : env4555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4554_4555 : H12AffineEnvironment.transform 4 0 env4554 = env4555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4554 == env4555) = true)

theorem identity4555 : scanCanonicalize (H12AffineFastState.compose env4555 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4555 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4556 : List Nat := [2,4,8,1,0,1,3,4,0,4,0,11,8,10,0,8,0,1,5,0,11,11,10,2,2,10,11,11,1,1,14,1,5,0,0,1]

theorem envBound4556 : H12AffineFastState.Bounded env4556 := by
  intro p hp
  have h : env4556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4555_4556 : H12AffineEnvironment.transform 6 3 env4555 = env4556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4555 == env4556) = true)

theorem identity4556 : scanCanonicalize (H12AffineFastState.compose env4556 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4556 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4557 : List Nat := [2,0,8,1,0,1,3,0,0,0,0,11,8,10,0,8,0,1,1,0,11,11,10,2,2,10,11,11,1,1,10,1,1,0,0,1]

theorem envBound4557 : H12AffineFastState.Bounded env4557 := by
  intro p hp
  have h : env4557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4556_4557 : H12AffineEnvironment.transform 1 0 env4556 = env4557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4556 == env4557) = true)

theorem identity4557 : scanCanonicalize (H12AffineFastState.compose env4557 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4557 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4558 : List Nat := [2,0,3,1,0,1,3,0,0,0,0,0,3,1,0,3,0,1,1,0,0,0,1,2,2,1,0,0,1,1,1,1,1,0,0,1]

theorem envBound4558 : H12AffineFastState.Bounded env4558 := by
  intro p hp
  have h : env4558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4557_4558 : H12AffineEnvironment.transform 2 3 env4557 = env4558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4557 == env4558) = true)

def env4559 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,32768,50466,1028,262144,1025,32768,1448,41089,41120,41002,8329,41120,320808,16385,16812,19848,57608,58532,257,17833,1029,41740]

theorem envBound4559 : H12AffineFastState.Bounded env4559 := by
  intro p hp
  have h : env4559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4545_4559 : H12AffineEnvironment.transform 21 41089 env4545 = env4559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41089 env4545 == env4559) = true)

theorem identity4559 : scanCanonicalize (H12AffineFastState.compose env4559 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8201) := by decide +kernel

theorem selectedBound4559 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4560 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,8201,25899,1028,262144,1025,8201,1448,136,169,35,8329,169,279841,16385,16812,19848,16641,17581,257,17833,1029,773]

theorem envBound4560 : H12AffineFastState.Bounded env4560 := by
  intro p hp
  have h : env4560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4559_4560 : H12AffineEnvironment.transform 14 8201 env4559 = env4560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8201 env4559 == env4560) = true)

theorem identity4560 : scanCanonicalize (H12AffineFastState.compose env4560 (packedSelected [0,7,13,17,20] rootPS)) = affineNative (2^(17+1) ^^^ 20392) := by decide +kernel

theorem selectedBound4560 : packedSelected [0,7,13,17,20] rootPS < 2^1333 := by decide +kernel

def env4561 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,16384,8201,25899,1028,20392,1025,8201,1448,136,169,35,8329,169,2697,16385,16812,19848,16641,17581,257,17833,1029,773]

theorem envBound4561 : H12AffineFastState.Bounded env4561 := by
  intro p hp
  have h : env4561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4560_4561 : H12AffineEnvironment.transform 17 20392 env4560 = env4561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20392 env4560 == env4561) = true)

theorem identity4561 : scanCanonicalize (H12AffineFastState.compose env4561 (packedSelected [1,10,12,15,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 1929) := by decide +kernel

theorem selectedBound4561 : packedSelected [1,10,12,15,24,26] rootPS < 2^1333 := by decide +kernel

def env4562 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,8192,1929,8201,8866,1028,2081,1025,8201,1448,136,169,35,8329,169,2697,1928,1573,2561,1672,804,257,544,1029,773]

theorem envBound4562 : H12AffineFastState.Bounded env4562 := by
  intro p hp
  have h : env4562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4561_4562 : H12AffineEnvironment.transform 13 1929 env4561 = env4562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1929 env4561 == env4562) = true)

theorem identity4562 : scanCanonicalize (H12AffineFastState.compose env4562 (packedSelected [0,3,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2601) := by decide +kernel

theorem selectedBound4562 : packedSelected [0,3,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4563 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1448,2601,1929,2592,2187,1028,2081,1025,2592,1448,136,169,35,2720,169,2697,1928,1573,2561,1672,804,257,544,1029,773]

theorem envBound4563 : H12AffineFastState.Bounded env4563 := by
  intro p hp
  have h : env4563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4562_4563 : H12AffineEnvironment.transform 12 2601 env4562 = env4563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2601 env4562 == env4563) = true)

theorem identity4563 : scanCanonicalize (H12AffineFastState.compose env4563 (packedSelected [2,3,4,5,6,7,13] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4563 : packedSelected [2,3,4,5,6,7,13] rootPS < 2^1333 := by decide +kernel

def env4564 : List Nat := [2,4,8,1,32,1,41,256,512,1024,2048,1281,2601,1824,2592,2082,1028,2081,1025,2592,1281,33,0,35,2569,0,2592,1825,1573,2561,1569,804,257,544,1029,773]

theorem envBound4564 : H12AffineFastState.Bounded env4564 := by
  intro p hp
  have h : env4564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4563_4564 : H12AffineEnvironment.transform 6 41 env4563 = env4564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4563 == env4564) = true)

theorem identity4564 : scanCanonicalize (H12AffineFastState.compose env4564 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4564 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env4565 : List Nat := [2,4,8,1,0,1,9,256,512,1024,2048,1281,2569,1792,2560,2050,1028,2049,1025,2560,1281,1,0,3,2569,0,2560,1793,1541,2561,1537,772,257,512,1029,773]

theorem envBound4565 : H12AffineFastState.Bounded env4565 := by
  intro p hp
  have h : env4565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4564_4565 : H12AffineEnvironment.transform 4 0 env4564 = env4565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4564 == env4565) = true)

theorem identity4565 : scanCanonicalize (H12AffineFastState.compose env4565 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 779) := by decide +kernel

theorem selectedBound4565 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env4566 : List Nat := [2,4,8,1,0,1,9,256,512,779,2048,522,2569,11,2560,2050,783,2049,778,2560,522,1,0,3,2569,0,2560,10,270,2561,266,772,257,512,782,773]

theorem envBound4566 : H12AffineFastState.Bounded env4566 := by
  intro p hp
  have h : env4566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4565_4566 : H12AffineEnvironment.transform 9 779 env4565 = env4566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 779 env4565 == env4566) = true)

theorem identity4566 : scanCanonicalize (H12AffineFastState.compose env4566 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound4566 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env4567 : List Nat := [2,4,8,1,0,1,9,256,512,779,271,522,774,11,783,269,783,270,778,783,522,1,0,3,774,0,783,10,270,782,266,772,257,512,782,773]

theorem envBound4567 : H12AffineFastState.Bounded env4567 := by
  intro p hp
  have h : env4567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4566_4567 : H12AffineEnvironment.transform 10 271 env4566 = env4567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env4566 == env4567) = true)

theorem identity4567 : scanCanonicalize (H12AffineFastState.compose env4567 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound4567 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env4568 : List Nat := [2,4,8,1,0,1,9,14,512,517,1,522,520,11,513,3,513,0,516,513,522,1,0,3,520,0,513,10,0,512,4,522,15,512,512,523]

theorem envBound4568 : H12AffineFastState.Bounded env4568 := by
  intro p hp
  have h : env4568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4567_4568 : H12AffineEnvironment.transform 7 14 env4567 = env4568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env4567 == env4568) = true)

theorem identity4568 : scanCanonicalize (H12AffineFastState.compose env4568 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4568 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4569 : List Nat := [2,4,8,1,0,1,9,14,1,4,1,11,9,11,0,3,0,0,5,0,11,1,0,3,9,0,0,10,0,1,4,11,15,1,1,10]

theorem envBound4569 : H12AffineFastState.Bounded env4569 := by
  intro p hp
  have h : env4569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4568_4569 : H12AffineEnvironment.transform 8 1 env4568 = env4569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4568 == env4569) = true)

theorem identity4569 : scanCanonicalize (H12AffineFastState.compose env4569 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4569 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env4570 : List Nat := [2,4,2,1,0,1,3,4,1,4,1,1,3,1,0,3,0,0,5,0,1,1,0,3,3,0,0,0,0,1,4,1,5,1,1,0]

theorem envBound4570 : H12AffineFastState.Bounded env4570 := by
  intro p hp
  have h : env4570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4569_4570 : H12AffineEnvironment.transform 2 2 env4569 = env4570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4569 == env4570) = true)

theorem identity4570 : scanCanonicalize (H12AffineFastState.compose env4570 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound4570 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4571 : List Nat := [2,0,2,1,0,1,3,0,1,0,1,1,3,1,0,3,0,0,1,0,1,1,0,3,3,0,0,0,0,1,0,1,1,1,1,0]

theorem envBound4571 : H12AffineFastState.Bounded env4571 := by
  intro p hp
  have h : env4571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4570_4571 : H12AffineEnvironment.transform 1 0 env4570 = env4571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env4570 == env4571) = true)

def env4572 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,65536,1029,262144,1025,32768,1449,4194304,4310275,41002,8329,4310275,320809,16385,16812,19849,74794,74134,257,17832,4236437,4310718]

theorem envBound4572 : H12AffineFastState.Bounded env4572 := by
  intro p hp
  have h : env4572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4539_4572 : H12AffineEnvironment.transform 11 1449 env4539 = env4572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env4539 == env4572) = true)

theorem identity4572 : scanCanonicalize (H12AffineFastState.compose env4572 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 50318) := by decide +kernel

theorem selectedBound4572 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4573 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1449,8192,16384,32768,50318,1029,262144,1025,32768,1449,4194304,4194701,41002,8329,4194701,320809,16385,16812,19849,57508,58648,257,17832,4236437,4194864]

theorem envBound4573 : H12AffineFastState.Bounded env4573 := by
  intro p hp
  have h : env4573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4572_4573 : H12AffineEnvironment.transform 15 50318 env4572 = env4573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 50318 env4572 == env4573) = true)

def env4574 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1449,8192,16384,32768,50318,1029,262144,1025,32768,1449,4194304,4194701,41002,8329,4194701,320809,16385,16812,19849,57508,58632,257,17832,4236421,4194848]

theorem envBound4574 : H12AffineFastState.Bounded env4574 := by
  intro p hp
  have h : env4574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4573_4574 : H12AffineEnvironment.transform 3 0 env4573 = env4574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4573 == env4574) = true)

theorem identity4574 : scanCanonicalize (H12AffineFastState.compose env4574 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4574 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4575 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,16384,32768,50215,1029,262144,1025,32768,1280,4194304,4194596,41002,8224,4194596,320809,16385,16645,19744,57357,58632,257,17665,4236332,4194848]

theorem envBound4575 : H12AffineFastState.Bounded env4575 := by
  intro p hp
  have h : env4575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4574_4575 : H12AffineEnvironment.transform 6 41 env4574 = env4575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4574 == env4575) = true)

theorem identity4575 : scanCanonicalize (H12AffineFastState.compose env4575 (packedSelected [3,5,10,17,21] rootPS)) = affineNative (2^(17+1) ^^^ 19493) := by decide +kernel

theorem selectedBound4575 : packedSelected [3,5,10,17,21] rootPS < 2^1333 := by decide +kernel

def env4576 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,16384,32768,50215,1029,19493,1025,32768,1280,4194304,4194596,41002,8224,4194596,43276,16385,16645,19744,57357,58632,257,17665,4236332,4194848]

theorem envBound4576 : H12AffineFastState.Bounded env4576 := by
  intro p hp
  have h : env4576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4575_4576 : H12AffineEnvironment.transform 17 19493 env4575 = env4576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19493 env4575 == env4576) = true)

theorem identity4576 : scanCanonicalize (H12AffineFastState.compose env4576 (packedSelected [0,3,4,5,7,10,13,17,22] rootPS)) = affineNative (2^(21+1) ^^^ 41001) := by decide +kernel

theorem selectedBound4576 : packedSelected [0,3,4,5,7,10,13,17,22] rootPS < 2^1333 := by decide +kernel

def env4577 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,16384,32768,50215,1029,19493,1025,32768,1280,41001,41229,41002,8224,41229,43276,16385,16645,19744,57357,58632,257,17665,1029,41481]

theorem envBound4577 : H12AffineFastState.Bounded env4577 := by
  intro p hp
  have h : env4577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4576_4577 : H12AffineEnvironment.transform 21 41001 env4576 = env4577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41001 env4576 == env4577) = true)

theorem identity4577 : scanCanonicalize (H12AffineFastState.compose env4577 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound4577 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4578 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,1572,32768,33283,1029,2561,1025,32768,1280,41001,41229,41002,8224,41229,43276,1573,1825,2820,42537,41772,257,805,1029,41481]

theorem envBound4578 : H12AffineFastState.Bounded env4578 := by
  intro p hp
  have h : env4578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4577_4578 : H12AffineEnvironment.transform 13 1572 env4577 = env4578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env4577 == env4578) = true)

theorem identity4578 : scanCanonicalize (H12AffineFastState.compose env4578 (packedSelected [1,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8744) := by decide +kernel

theorem selectedBound4578 : packedSelected [1,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env4579 : List Nat := [2,4,8,0,32,0,41,256,512,1024,2048,1280,8192,1572,8744,8235,1029,2561,1025,8744,1280,513,805,514,8224,805,2852,1573,1825,2820,1025,260,257,805,1029,33]

theorem envBound4579 : H12AffineFastState.Bounded env4579 := by
  intro p hp
  have h : env4579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4578_4579 : H12AffineEnvironment.transform 14 8744 env4578 = env4579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8744 env4578 == env4579) = true)

theorem identity4579 : scanCanonicalize (H12AffineFastState.compose env4579 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4579 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4580 : List Nat := [2,4,8,0,32,0,41,4,512,1024,2048,1028,8192,1572,8744,8235,1029,2561,1025,8744,1028,513,545,514,8224,545,2592,1573,1573,2560,1025,0,5,545,1029,33]

theorem envBound4580 : H12AffineFastState.Bounded env4580 := by
  intro p hp
  have h : env4580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4579_4580 : H12AffineEnvironment.transform 7 4 env4579 = env4580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4579 == env4580) = true)

theorem identity4580 : scanCanonicalize (H12AffineFastState.compose env4580 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound4580 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4581 : List Nat := [2,4,8,0,32,0,41,4,512,1024,1071,1028,8192,1572,8744,8235,1029,1582,1025,8744,1028,513,545,514,8224,545,1551,1573,1573,1583,1025,0,5,545,1029,33]

theorem envBound4581 : H12AffineFastState.Bounded env4581 := by
  intro p hp
  have h : env4581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4580_4581 : H12AffineEnvironment.transform 10 1071 env4580 = env4581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env4580 == env4581) = true)

theorem identity4581 : scanCanonicalize (H12AffineFastState.compose env4581 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound4581 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env4582 : List Nat := [2,4,8,0,10,0,3,4,512,1024,1029,1028,8192,1550,8706,8193,1029,1540,1025,8706,1028,513,523,514,8202,523,1551,1551,1551,1541,1025,0,5,523,1029,11]

theorem envBound4582 : H12AffineFastState.Bounded env4582 := by
  intro p hp
  have h : env4582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4581_4582 : H12AffineEnvironment.transform 4 10 env4581 = env4582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env4581 == env4582) = true)

theorem identity4582 : scanCanonicalize (H12AffineFastState.compose env4582 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(12+1) ^^^ 1548) := by decide +kernel

theorem selectedBound4582 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env4583 : List Nat := [2,4,8,0,10,0,3,4,512,1024,1029,1028,1548,1550,1038,1549,1029,1540,1025,1038,1028,513,523,514,1542,523,1551,1551,1551,1541,1025,0,5,523,1029,11]

theorem envBound4583 : H12AffineFastState.Bounded env4583 := by
  intro p hp
  have h : env4583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4582_4583 : H12AffineEnvironment.transform 12 1548 env4582 = env4583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1548 env4582 == env4583) = true)

theorem identity4583 : scanCanonicalize (H12AffineFastState.compose env4583 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound4583 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env4584 : List Nat := [2,4,8,0,10,0,3,4,512,5,0,1,521,523,11,520,0,513,4,11,1,513,523,514,515,523,522,522,522,512,4,0,5,523,0,11]

theorem envBound4584 : H12AffineFastState.Bounded env4584 := by
  intro p hp
  have h : env4584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4583_4584 : H12AffineEnvironment.transform 9 5 env4583 = env4584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env4583 == env4584) = true)

theorem identity4584 : scanCanonicalize (H12AffineFastState.compose env4584 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound4584 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4585 : List Nat := [2,4,8,0,10,0,3,4,10,5,0,1,3,1,11,2,0,11,4,11,1,11,1,8,9,1,0,0,0,10,4,0,5,1,0,11]

theorem envBound4585 : H12AffineFastState.Bounded env4585 := by
  intro p hp
  have h : env4585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4584_4585 : H12AffineEnvironment.transform 8 10 env4584 = env4585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env4584 == env4585) = true)

theorem identity4585 : scanCanonicalize (H12AffineFastState.compose env4585 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound4585 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4586 : List Nat := [2,4,6,0,4,0,3,4,4,5,0,1,3,1,5,2,0,5,4,5,1,5,1,6,7,1,0,0,0,4,4,0,5,1,0,5]

theorem envBound4586 : H12AffineFastState.Bounded env4586 := by
  intro p hp
  have h : env4586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4585_4586 : H12AffineEnvironment.transform 2 6 env4585 = env4586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env4585 == env4586) = true)

theorem identity4586 : scanCanonicalize (H12AffineFastState.compose env4586 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound4586 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env4587 : List Nat := [2,1,3,0,1,0,3,1,1,0,0,1,3,1,0,2,0,0,1,0,1,0,1,3,2,1,0,0,0,1,1,0,0,1,0,0]

theorem envBound4587 : H12AffineFastState.Bounded env4587 := by
  intro p hp
  have h : env4587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4586_4587 : H12AffineEnvironment.transform 1 1 env4586 = env4587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env4586 == env4587) = true)

def env4588 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,32768,50318,1029,262144,1025,32768,1449,4194304,4194701,41002,8329,4194701,320809,16385,16812,19849,57508,58633,257,17832,4236420,4194849]

theorem envBound4588 : H12AffineFastState.Bounded env4588 := by
  intro p hp
  have h : env4588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4573_4588 : H12AffineEnvironment.transform 3 1 env4573 = env4588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4573 == env4588) = true)

theorem identity4588 : scanCanonicalize (H12AffineFastState.compose env4588 (packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8612) := by decide +kernel

theorem selectedBound4588 : packedSelected [2,3,7,10,11,13,17,18,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4589 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8612,25898,1029,262144,1025,8612,1449,4194304,4194701,398,8329,4194701,279693,16385,16812,19849,16640,17581,257,17832,4195616,4194849]

theorem envBound4589 : H12AffineFastState.Bounded env4589 := by
  intro p hp
  have h : env4589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4588_4589 : H12AffineEnvironment.transform 14 8612 env4588 = env4589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8612 env4588 == env4589) = true)

theorem identity4589 : scanCanonicalize (H12AffineFastState.compose env4589 (packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 17444) := by decide +kernel

theorem selectedBound4589 : packedSelected [0,3,5,7,9,10,13,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4590 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8612,25898,1029,262144,1025,8612,1449,17444,17833,398,8329,17833,279693,16385,16812,19849,16640,17581,257,17832,16644,17925]

theorem envBound4590 : H12AffineFastState.Bounded env4590 := by
  intro p hp
  have h : env4590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4589_4590 : H12AffineEnvironment.transform 21 17444 env4589 = env4590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 17444 env4589 == env4590) = true)

theorem identity4590 : scanCanonicalize (H12AffineFastState.compose env4590 (packedSelected [3,5,10,13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2081) := by decide +kernel

theorem selectedBound4590 : packedSelected [3,5,10,13,17] rootPS < 2^1333 := by decide +kernel

def env4591 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,16384,8612,25898,1029,2081,1025,8612,1449,17444,17833,398,8329,17833,19628,16385,16812,19849,16640,17581,257,17832,16644,17925]

theorem envBound4591 : H12AffineFastState.Bounded env4591 := by
  intro p hp
  have h : env4591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4590_4591 : H12AffineEnvironment.transform 17 2081 env4590 = env4591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2081 env4590 == env4591) = true)

theorem identity4591 : scanCanonicalize (H12AffineFastState.compose env4591 (packedSelected [0,1,6,7,8,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 12171) := by decide +kernel

theorem selectedBound4591 : packedSelected [0,1,6,7,8,12,15] rootPS < 2^1333 := by decide +kernel

def env4592 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,8192,12171,8612,2721,1029,2081,1025,8612,1449,11183,10786,398,8329,10786,8999,12170,11815,8706,11915,11046,257,10787,11919,10638]

theorem envBound4592 : H12AffineFastState.Bounded env4592 := by
  intro p hp
  have h : env4592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4591_4592 : H12AffineEnvironment.transform 13 12171 env4591 = env4592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12171 env4591 == env4592) = true)

theorem identity4592 : scanCanonicalize (H12AffineFastState.compose env4592 (packedSelected [0,2,4,7,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 2219) := by decide +kernel

theorem selectedBound4592 : packedSelected [0,2,4,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env4593 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1449,2219,1824,2319,2721,1029,2081,1025,2319,1449,772,649,398,2082,649,2956,1825,1676,2729,1568,909,257,648,1572,293]

theorem envBound4593 : H12AffineFastState.Bounded env4593 := by
  intro p hp
  have h : env4593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4592_4593 : H12AffineEnvironment.transform 12 2219 env4592 = env4593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2219 env4592 == env4593) = true)

theorem identity4593 : scanCanonicalize (H12AffineFastState.compose env4593 (packedSelected [0,5,6,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound4593 : packedSelected [0,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env4594 : List Nat := [2,4,8,1,32,1,128,5,512,1024,2048,1196,2219,1573,2058,2721,1029,2081,1025,2058,1196,513,649,139,2082,649,2697,1572,1676,2729,1568,648,4,648,1572,32]

theorem envBound4594 : H12AffineFastState.Bounded env4594 := by
  intro p hp
  have h : env4594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4593_4594 : H12AffineEnvironment.transform 7 5 env4593 = env4594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env4593 == env4594) = true)

theorem identity4594 : scanCanonicalize (H12AffineFastState.compose env4594 (packedSelected [0,2,7] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound4594 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4595 : List Nat := [2,4,8,1,32,1,128,5,169,1024,2048,1196,2219,1164,2058,2056,1029,2081,1025,2058,1196,168,32,139,2082,32,2080,1165,1061,2048,1161,33,4,33,1165,32]

theorem envBound4595 : H12AffineFastState.Bounded env4595 := by
  intro p hp
  have h : env4595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4594_4595 : H12AffineEnvironment.transform 8 169 env4594 = env4595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env4594 == env4595) = true)

theorem identity4595 : scanCanonicalize (H12AffineFastState.compose env4595 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound4595 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4596 : List Nat := [2,4,8,1,32,1,128,5,169,173,2048,1,2219,33,2058,2056,168,2081,172,2058,1,168,32,139,2082,32,2080,32,136,2048,36,33,4,33,32,32]

theorem envBound4596 : H12AffineFastState.Bounded env4596 := by
  intro p hp
  have h : env4596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4595_4596 : H12AffineEnvironment.transform 9 173 env4595 = env4596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env4595 == env4596) = true)

theorem identity4596 : scanCanonicalize (H12AffineFastState.compose env4596 (packedSelected [3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound4596 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env4597 : List Nat := [2,4,8,1,32,1,128,5,169,173,137,1,34,33,131,129,168,168,172,131,1,168,32,139,171,32,169,32,136,137,36,33,4,33,32,32]

theorem envBound4597 : H12AffineFastState.Bounded env4597 := by
  intro p hp
  have h : env4597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4596_4597 : H12AffineEnvironment.transform 10 137 env4596 = env4597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env4596 == env4597) = true)

theorem identity4597 : scanCanonicalize (H12AffineFastState.compose env4597 (packedSelected [6] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4597 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4598 : List Nat := [2,4,2,1,32,1,128,5,163,167,131,1,34,33,131,129,162,162,166,131,1,162,32,129,161,32,163,32,130,131,36,33,4,33,32,32]

theorem envBound4598 : H12AffineFastState.Bounded env4598 := by
  intro p hp
  have h : env4598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4597_4598 : H12AffineEnvironment.transform 2 2 env4597 = env4598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4597 == env4598) = true)

theorem identity4598 : scanCanonicalize (H12AffineFastState.compose env4598 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound4598 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4599 : List Nat := [2,4,2,1,32,1,35,5,0,4,32,1,34,33,32,34,1,1,5,32,1,1,32,34,2,32,0,32,33,32,36,33,4,33,32,32]

theorem envBound4599 : H12AffineFastState.Bounded env4599 := by
  intro p hp
  have h : env4599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4598_4599 : H12AffineEnvironment.transform 6 35 env4598 = env4599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env4598 == env4599) = true)

def env4600 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,4194304,4310274,41002,8329,4310275,323713,16385,16813,22561,74794,78910,257,20480,4236436,4310718]

theorem envBound4600 : H12AffineFastState.Bounded env4600 := by
  intro p hp
  have h : env4600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4538_4600 : H12AffineEnvironment.transform 5 17 env4538 = env4600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4538 == env4600) = true)

theorem identity4600 : scanCanonicalize (H12AffineFastState.compose env4600 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 115902) := by decide +kernel

theorem selectedBound4600 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4601 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,4525,262144,1025,32768,4096,115902,444,41002,8329,445,323713,16385,16813,22561,74794,78910,257,20480,90154,512]

theorem envBound4601 : H12AffineFastState.Bounded env4601 := by
  intro p hp
  have h : env4601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4600_4601 : H12AffineEnvironment.transform 21 115902 env4600 = env4601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 115902 env4600 == env4601) = true)

theorem identity4601 : scanCanonicalize (H12AffineFastState.compose env4601 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound4601 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4602 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1025,32768,4096,41348,444,41002,8329,445,323713,16385,16813,22561,16656,20740,257,20480,1296,512]

theorem envBound4602 : H12AffineFastState.Bounded env4602 := by
  intro p hp
  have h : env4602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4601_4602 : H12AffineEnvironment.transform 15 25914 env4601 = env4602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env4601 == env4602) = true)

theorem identity4602 : scanCanonicalize (H12AffineFastState.compose env4602 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29312) := by decide +kernel

theorem selectedBound4602 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4603 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29312,25914,4525,262144,1025,29312,4096,21252,444,21162,8329,445,262657,16385,16813,22561,16656,20740,257,20480,1296,512]

theorem envBound4603 : H12AffineFastState.Bounded env4603 := by
  intro p hp
  have h : env4603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4602_4603 : H12AffineEnvironment.transform 14 29312 env4602 = env4603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29312 env4602 == env4603) = true)

theorem identity4603 : scanCanonicalize (H12AffineFastState.compose env4603 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1465) := by decide +kernel

theorem selectedBound4603 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4604 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1465,8192,16384,26425,25914,1044,262144,1025,26425,1465,18109,444,18195,8329,445,262657,16385,16813,19864,16656,17597,257,17849,1296,512]

theorem envBound4604 : H12AffineFastState.Bounded env4604 := by
  intro p hp
  have h : env4604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4603_4604 : H12AffineEnvironment.transform 11 1465 env4603 = env4604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1465 env4603 == env4604) = true)

theorem identity4604 : scanCanonicalize (H12AffineFastState.compose env4604 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4604 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4605 : List Nat := [2,4,8,16,32,17,41,256,512,1024,2048,1296,8192,16384,26425,25914,1044,262144,1025,26425,1296,17940,277,18195,8224,276,262657,16385,16644,19761,16656,17428,257,17680,1296,512]

theorem envBound4605 : H12AffineFastState.Bounded env4605 := by
  intro p hp
  have h : env4605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4604_4605 : H12AffineEnvironment.transform 6 41 env4604 = env4605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4604 == env4605) = true)

def env4606 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849105,268435456,268435965,547953,598058,12644668,525568,545872,8479126,8914924]

theorem envBound4606 : H12AffineFastState.Bounded env4606 := by
  intro p hp
  have h : env4606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4339_4606 : H12AffineEnvironment.transform 20 4097 env4339 = env4606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4097 env4339 == env4606) = true)

def env4607 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,524288,32768,4097,4194304,8388608,41002,8329,8914000,849105,16384,16893,547953,598058,12644668,525568,545872,8479126,8914924]

theorem envBound4607 : H12AffineFastState.Bounded env4607 := by
  intro p hp
  have h : env4607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4606_4607 : H12AffineEnvironment.transform 27 16384 env4606 = env4607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env4606 == env4607) = true)

def env4608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323793,16384,16893,22641,74794,12644668,256,20560,8479126,8389612]

theorem envBound4608 : H12AffineFastState.Bounded env4608 := by
  intro p hp
  have h : env4608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4607_4608 : H12AffineEnvironment.transform 18 1024 env4607 = env4608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env4607 == env4608) = true)

theorem identity4608 : scanCanonicalize (H12AffineFastState.compose env4608 (packedSelected [14] rootPS)) = affineNative (2^(15+1) ^^^ 25914) := by decide +kernel

theorem selectedBound4608 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,25914,4604,262144,1024,32768,4097,4194304,8388608,41002,8329,8388688,323793,16384,16893,22641,16656,12644668,256,20560,8389804,8389612]

theorem envBound4609 : H12AffineFastState.Bounded env4609 := by
  intro p hp
  have h : env4609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4608_4609 : H12AffineEnvironment.transform 15 25914 env4608 = env4609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 25914 env4608 == env4609) = true)

def env4610 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4097,4194304,8388608,41002,8329,8388608,323713,16384,16813,22561,16656,12644668,256,20480,8389804,8389564]

theorem envBound4610 : H12AffineFastState.Bounded env4610 := by
  intro p hp
  have h : env4610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4609_4610 : H12AffineEnvironment.transform 5 16 env4609 = env4610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4609 == env4610) = true)

def env4611 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4097,4194304,4240784,41002,8329,4240784,323713,16384,16813,22561,16656,17580,256,20480,4239676,4240940]

theorem envBound4611 : H12AffineFastState.Bounded env4611 := by
  intro p hp
  have h : env4611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4610_4611 : H12AffineEnvironment.transform 22 4240784 env4610 = env4611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240784 env4610 == env4611) = true)

theorem identity4611 : scanCanonicalize (H12AffineFastState.compose env4611 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13340) := by decide +kernel

theorem selectedBound4611 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4612 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13340,25914,4524,262144,1024,13340,4097,4194304,4194700,5174,8329,4194700,279709,16384,16813,22561,16656,17580,256,20480,4195616,4194864]

theorem envBound4612 : H12AffineFastState.Bounded env4612 := by
  intro p hp
  have h : env4612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4611_4612 : H12AffineEnvironment.transform 14 13340 env4611 = env4612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13340 env4611 == env4612) = true)

def env4613 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1280,8192,16384,8476,25914,1196,262144,1024,8476,1281,4194304,4194700,310,8329,4194700,279709,16384,16813,19745,16656,17580,256,17664,4195616,4194864]

theorem envBound4613 : H12AffineFastState.Bounded env4613 := by
  intro p hp
  have h : env4613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4612_4613 : H12AffineEnvironment.transform 11 1280 env4612 = env4613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env4612 == env4613) = true)

theorem identity4613 : scanCanonicalize (H12AffineFastState.compose env4613 (packedSelected [3,7,10,20,24,26,27] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound4613 : packedSelected [3,7,10,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env4614 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1045,8192,16384,8201,25647,1196,262144,1024,8201,1044,4194304,4194457,35,8329,4194457,279709,16384,16568,19508,16389,17580,21,17429,4195381,4194864]

theorem envBound4614 : H12AffineFastState.Bounded env4614 := by
  intro p hp
  have h : env4614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4613_4614 : H12AffineEnvironment.transform 7 21 env4613 = env4614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env4613 == env4614) = true)

theorem identity4614 : scanCanonicalize (H12AffineFastState.compose env4614 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4614 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env4615 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1045,8192,16384,8201,25647,1196,262144,1024,8201,1044,32,185,35,8329,185,279709,16384,16568,19508,16389,17580,21,17429,1045,528]

theorem envBound4615 : H12AffineFastState.Bounded env4615 := by
  intro p hp
  have h : env4615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4614_4615 : H12AffineEnvironment.transform 21 32 env4614 = env4615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4614 == env4615) = true)

theorem identity4615 : scanCanonicalize (H12AffineFastState.compose env4615 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4615 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4616 : List Nat := [2,4,8,16,32,16,128,21,512,1024,2048,1045,8192,16384,8201,25647,1196,2080,1024,8201,1044,32,185,35,8329,185,19645,16384,16568,19508,16389,17580,21,17429,1045,528]

theorem envBound4616 : H12AffineFastState.Bounded env4616 := by
  intro p hp
  have h : env4616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4615_4616 : H12AffineEnvironment.transform 17 2080 env4615 = env4616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4615 == env4616) = true)

theorem identity4616 : scanCanonicalize (H12AffineFastState.compose env4616 (packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS)) = affineNative (2^(6+1) ^^^ 57) := by decide +kernel

theorem selectedBound4616 : packedSelected [2,3,4,5,6,7,11,12,20,21] rootPS < 2^1333 := by decide +kernel

def env4617 : List Nat := [2,4,8,16,32,16,57,21,512,1024,2048,1045,8192,16384,8201,25647,1045,2080,1024,8201,1044,32,0,35,8240,0,19460,16384,16385,19508,16389,17429,21,17429,1045,528]

theorem envBound4617 : H12AffineFastState.Bounded env4617 := by
  intro p hp
  have h : env4617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4616_4617 : H12AffineEnvironment.transform 6 57 env4616 = env4617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 57 env4616 == env4617) = true)

theorem identity4617 : scanCanonicalize (H12AffineFastState.compose env4617 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound4617 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env4618 : List Nat := [2,4,8,1,32,1,40,4,512,1024,2048,1028,8192,16384,8201,25647,1028,2080,1024,8201,1029,32,0,35,8225,0,19460,16384,16385,19493,16389,17412,4,17412,1028,513]

theorem envBound4618 : H12AffineFastState.Bounded env4618 := by
  intro p hp
  have h : env4618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4617_4618 : H12AffineEnvironment.transform 3 1 env4617 = env4618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4617 == env4618) = true)

theorem identity4618 : scanCanonicalize (H12AffineFastState.compose env4618 (packedSelected [0,1,4] rootPS)) = affineNative (2^(10+1) ^^^ 47) := by decide +kernel

theorem selectedBound4618 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env4619 : List Nat := [2,4,8,1,32,1,40,4,512,1024,47,1028,8192,16384,8201,25647,1028,15,1024,8201,1029,32,0,35,8225,0,17451,16384,16385,17418,16389,17412,4,17412,1028,513]

theorem envBound4619 : H12AffineFastState.Bounded env4619 := by
  intro p hp
  have h : env4619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4618_4619 : H12AffineEnvironment.transform 10 47 env4618 = env4619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 47 env4618 == env4619) = true)

theorem identity4619 : scanCanonicalize (H12AffineFastState.compose env4619 (packedSelected [5] rootPS)) = affineNative (2^(13+1) ^^^ 5) := by decide +kernel

theorem selectedBound4619 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env4620 : List Nat := [2,4,8,1,32,1,40,4,512,1024,47,1028,8192,5,8201,9258,1028,15,1024,8201,1029,32,0,35,8225,0,1070,5,4,1039,0,1025,4,1025,1028,513]

theorem envBound4620 : H12AffineFastState.Bounded env4620 := by
  intro p hp
  have h : env4620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4619_4620 : H12AffineEnvironment.transform 13 5 env4619 = env4620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5 env4619 == env4620) = true)

theorem identity4620 : scanCanonicalize (H12AffineFastState.compose env4620 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 512) := by decide +kernel

theorem selectedBound4620 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env4621 : List Nat := [2,4,8,1,32,1,40,4,512,512,47,516,8192,5,8201,8746,516,15,512,8201,517,32,0,35,8225,0,558,5,4,527,0,513,4,513,516,513]

theorem envBound4621 : H12AffineFastState.Bounded env4621 := by
  intro p hp
  have h : env4621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4620_4621 : H12AffineEnvironment.transform 9 512 env4620 = env4621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 512 env4620 == env4621) = true)

theorem identity4621 : scanCanonicalize (H12AffineFastState.compose env4621 (packedSelected [8] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound4621 : packedSelected [8] rootPS < 2^1333 := by decide +kernel

def env4622 : List Nat := [2,4,8,1,32,1,40,4,33,33,47,37,8192,5,8201,8203,37,15,33,8201,36,32,0,35,8225,0,15,5,4,46,0,32,4,32,37,32]

theorem envBound4622 : H12AffineFastState.Bounded env4622 := by
  intro p hp
  have h : env4622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4621_4622 : H12AffineEnvironment.transform 8 33 env4621 = env4622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env4621 == env4622) = true)

theorem identity4622 : scanCanonicalize (H12AffineFastState.compose env4622 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 14) := by decide +kernel

theorem selectedBound4622 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4623 : List Nat := [2,4,8,1,14,1,6,4,15,15,1,11,8192,5,8201,8203,11,15,15,8201,10,14,0,13,8207,0,15,5,4,0,0,14,4,14,11,14]

theorem envBound4623 : H12AffineFastState.Bounded env4623 := by
  intro p hp
  have h : env4623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4622_4623 : H12AffineEnvironment.transform 4 14 env4622 = env4623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 14 env4622 == env4623) = true)

theorem identity4623 : scanCanonicalize (H12AffineFastState.compose env4623 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 6) := by decide +kernel

theorem selectedBound4623 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4624 : List Nat := [2,4,8,1,14,1,6,4,15,15,1,11,6,5,15,13,11,15,15,15,10,14,0,13,9,0,15,5,4,0,0,14,4,14,11,14]

theorem envBound4624 : H12AffineFastState.Bounded env4624 := by
  intro p hp
  have h : env4624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4623_4624 : H12AffineEnvironment.transform 12 6 env4623 = env4624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6 env4623 == env4624) = true)

theorem identity4624 : scanCanonicalize (H12AffineFastState.compose env4624 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound4624 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4625 : List Nat := [2,4,3,1,5,1,6,4,4,4,1,0,6,5,4,6,0,4,4,4,1,5,0,6,2,0,4,5,4,0,0,5,4,5,0,5]

theorem envBound4625 : H12AffineFastState.Bounded env4625 := by
  intro p hp
  have h : env4625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4624_4625 : H12AffineEnvironment.transform 2 3 env4624 = env4625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env4624 == env4625) = true)

def leafEnv4625 : List Nat := [2,4,3,1,5,1,6,4,4,4,1,0,6,5,4,6,0,4,4,4,1,5,0,6,1,2,1,0,4,5,4,0,0,5,4,5,5,3,0,5,1,5,0]

def active4625 : List Nat := [0,1]

def tree4625 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood4625 : H12WitnessSearch.Good tree4625 := H12GlobalWitnessIndex.good

theorem leafIdentity4625 : H12AffineFastState.composeSystem env4625 rootObs = leafEnv4625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env4625 rootObs == leafEnv4625) = true)

theorem terminalChecked4625 : H12PackedTerminal.terminalCheckFast leafEnv4625 active4625 tree4625 = true := by decide +kernel

def env4626 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1281,8192,16384,8477,25914,1197,262144,1024,8477,1280,4194304,4194700,311,8329,4194700,279709,16384,16813,19744,16656,17580,256,17665,4195616,4194864]

theorem envBound4626 : H12AffineFastState.Bounded env4626 := by
  intro p hp
  have h : env4626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4612_4626 : H12AffineEnvironment.transform 11 1281 env4612 = env4626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env4612 == env4626) = true)

theorem identity4626 : scanCanonicalize (H12AffineFastState.compose env4626 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4626 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4627 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1196,8192,16384,8368,25751,1197,262144,1024,8368,1197,4194304,4194337,154,8329,4194337,279709,16384,16384,19597,16573,17580,173,17580,4195469,4194864]

theorem envBound4627 : H12AffineFastState.Bounded env4627 := by
  intro p hp
  have h : env4627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4626_4627 : H12AffineEnvironment.transform 7 173 env4626 = env4627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4626 == env4627) = true)

theorem identity4627 : scanCanonicalize (H12AffineFastState.compose env4627 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4627 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4628 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,16384,8217,25662,1028,262144,1024,8217,1028,4194304,4194337,51,8224,4194337,279604,16384,16384,19492,16404,17413,4,17413,4195364,4194864]

theorem envBound4628 : H12AffineFastState.Bounded env4628 := by
  intro p hp
  have h : env4628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4627_4628 : H12AffineEnvironment.transform 6 41 env4627 = env4628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4627 == env4628) = true)

theorem identity4628 : scanCanonicalize (H12AffineFastState.compose env4628 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound4628 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4629 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,16384,8217,25662,1028,262144,1024,8217,1028,32,1,51,8224,1,279604,16384,16384,19492,16404,17413,4,17413,1028,528]

theorem envBound4629 : H12AffineFastState.Bounded env4629 := by
  intro p hp
  have h : env4629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4628_4629 : H12AffineEnvironment.transform 21 32 env4628 = env4629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env4628 == env4629) = true)

theorem identity4629 : scanCanonicalize (H12AffineFastState.compose env4629 (packedSelected [13,17] rootPS)) = affineNative (2^(17+1) ^^^ 19508) := by decide +kernel

theorem selectedBound4629 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env4630 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,16384,8217,25662,1028,19508,1024,8217,1028,32,1,51,8224,1,2048,16384,16384,19492,16404,17413,4,17413,1028,528]

theorem envBound4630 : H12AffineFastState.Bounded env4630 := by
  intro p hp
  have h : env4630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4629_4630 : H12AffineEnvironment.transform 17 19508 env4629 = env4630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 19508 env4629 == env4630) = true)

theorem identity4630 : scanCanonicalize (H12AffineFastState.compose env4630 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 1572) := by decide +kernel

theorem selectedBound4630 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env4631 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,8192,1572,8217,8730,1028,2576,1024,8217,1028,32,1,51,8224,1,2048,1572,1572,2560,1584,545,4,545,1028,528]

theorem envBound4631 : H12AffineFastState.Bounded env4631 := by
  intro p hp
  have h : env4631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4630_4631 : H12AffineEnvironment.transform 13 1572 env4630 = env4631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1572 env4630 == env4631) = true)

theorem identity4631 : scanCanonicalize (H12AffineFastState.compose env4631 (packedSelected [1,2,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1549) := by decide +kernel

theorem selectedBound4631 : packedSelected [1,2,5,10] rootPS < 2^1333 := by decide +kernel

def env4632 : List Nat := [2,4,8,16,32,16,41,4,512,1024,2048,1029,1549,1572,1556,1047,1028,2576,1024,1556,1028,32,1,51,1581,1,2048,1572,1572,2560,1584,545,4,545,1028,528]

theorem envBound4632 : H12AffineFastState.Bounded env4632 := by
  intro p hp
  have h : env4632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4631_4632 : H12AffineEnvironment.transform 12 1549 env4631 = env4632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1549 env4631 == env4632) = true)

theorem identity4632 : scanCanonicalize (H12AffineFastState.compose env4632 (packedSelected [1,2,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound4632 : packedSelected [1,2,6,8,11] rootPS < 2^1333 := by decide +kernel

def env4633 : List Nat := [2,4,8,16,32,16,41,4,512,1024,1567,1029,1549,1572,1556,1047,1028,1039,1024,1556,1028,32,1,51,1581,1,1567,1572,1572,1055,1584,545,4,545,1028,528]

theorem envBound4633 : H12AffineFastState.Bounded env4633 := by
  intro p hp
  have h : env4633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4632_4633 : H12AffineEnvironment.transform 10 1567 env4632 = env4633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env4632 == env4633) = true)

theorem identity4633 : scanCanonicalize (H12AffineFastState.compose env4633 (packedSelected [0,2,5,6,7,8,13] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound4633 : packedSelected [0,2,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env4634 : List Nat := [2,4,8,16,32,16,41,4,512,565,42,560,56,17,33,546,561,570,565,33,561,32,1,51,24,1,42,17,17,554,5,545,4,545,561,528]

theorem envBound4634 : H12AffineFastState.Bounded env4634 := by
  intro p hp
  have h : env4634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4633_4634 : H12AffineEnvironment.transform 9 565 env4633 = env4634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env4633 == env4634) = true)

theorem identity4634 : scanCanonicalize (H12AffineFastState.compose env4634 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound4634 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env4635 : List Nat := [2,4,8,16,32,16,41,4,32,21,42,16,56,17,33,2,17,26,21,33,17,32,1,51,24,1,42,17,17,10,5,1,4,1,17,48]

theorem envBound4635 : H12AffineFastState.Bounded env4635 := by
  intro p hp
  have h : env4635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4634_4635 : H12AffineEnvironment.transform 8 32 env4634 = env4635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env4634 == env4635) = true)

theorem identity4635 : scanCanonicalize (H12AffineFastState.compose env4635 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4635 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4636 : List Nat := [2,4,2,16,32,16,35,4,32,21,32,16,50,17,33,2,17,16,21,33,17,32,1,51,18,1,32,17,17,0,5,1,4,1,17,48]

theorem envBound4636 : H12AffineFastState.Bounded env4636 := by
  intro p hp
  have h : env4636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4635_4636 : H12AffineEnvironment.transform 2 2 env4635 = env4636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4635 == env4636) = true)

theorem identity4636 : scanCanonicalize (H12AffineFastState.compose env4636 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound4636 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env4637 : List Nat := [2,4,2,0,32,0,35,4,32,5,32,0,34,1,33,2,1,0,5,33,1,32,1,35,2,1,32,1,1,0,5,1,4,1,1,32]

theorem envBound4637 : H12AffineFastState.Bounded env4637 := by
  intro p hp
  have h : env4637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4636_4637 : H12AffineEnvironment.transform 3 0 env4636 = env4637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4636 == env4637) = true)

theorem identity4637 : scanCanonicalize (H12AffineFastState.compose env4637 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4637 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4638 : List Nat := [2,4,2,0,0,0,3,4,0,5,0,0,2,1,1,2,1,0,5,1,1,0,1,3,2,1,0,1,1,0,5,1,4,1,1,0]

theorem envBound4638 : H12AffineFastState.Bounded env4638 := by
  intro p hp
  have h : env4638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4637_4638 : H12AffineEnvironment.transform 4 0 env4637 = env4638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4637 == env4638) = true)

def env4639 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,25914,4524,262144,1024,32768,4097,4194304,4240785,41002,8329,4240785,323713,16384,16813,22561,16656,17581,256,20480,4239677,4240941]

theorem envBound4639 : H12AffineFastState.Bounded env4639 := by
  intro p hp
  have h : env4639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4610_4639 : H12AffineEnvironment.transform 22 4240785 env4610 = env4639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4240785 env4610 == env4639) = true)

theorem identity4639 : scanCanonicalize (H12AffineFastState.compose env4639 (packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 13728) := by decide +kernel

theorem selectedBound4639 : packedSelected [0,2,3,7,9,10,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env4640 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13728,25914,4524,262144,1024,13728,4097,4194304,4194353,5514,8329,4194353,279841,16384,16813,22561,16656,17581,256,20480,4195485,4195213]

theorem envBound4640 : H12AffineFastState.Bounded env4640 := by
  intro p hp
  have h : env4640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4639_4640 : H12AffineEnvironment.transform 14 13728 env4639 = env4640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13728 env4639 == env4640) = true)

def env4641 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,4096,8192,16384,13728,25898,4524,262144,1024,13728,4097,4194304,4194337,5514,8329,4194337,279841,16384,16813,22561,16640,17581,256,20480,4195469,4195213]

theorem envBound4641 : H12AffineFastState.Bounded env4641 := by
  intro p hp
  have h : env4641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4640_4641 : H12AffineEnvironment.transform 3 0 env4640 = env4641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env4640 == env4641) = true)

theorem identity4641 : scanCanonicalize (H12AffineFastState.compose env4641 (packedSelected [2,11,13,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1197) := by decide +kernel

theorem selectedBound4641 : packedSelected [2,11,13,17,18] rootPS < 2^1333 := by decide +kernel

def env4642 : List Nat := [2,4,8,0,32,0,128,256,512,1024,2048,1197,8192,16384,8461,25898,1281,262144,1024,8461,1196,4194304,4194337,295,8329,4194337,279841,16384,16813,19596,16640,17581,256,17581,4195469,4195213]

theorem envBound4642 : H12AffineFastState.Bounded env4642 := by
  intro p hp
  have h : env4642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4641_4642 : H12AffineEnvironment.transform 11 1197 env4641 = env4642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1197 env4641 == env4642) = true)

theorem identity4642 : scanCanonicalize (H12AffineFastState.compose env4642 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4642 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4643 : List Nat := [2,4,8,0,32,0,128,4,512,1024,2048,1197,8192,16384,8201,25646,1029,262144,1024,8201,1196,4194304,4194337,35,8329,4194337,279589,16384,16553,19596,16388,17581,4,17581,4195469,4194953]

theorem envBound4643 : H12AffineFastState.Bounded env4643 := by
  intro p hp
  have h : env4643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4642_4643 : H12AffineEnvironment.transform 7 4 env4642 = env4643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4642 == env4643) = true)

def env4644 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,4096,8192,16384,13728,25899,4524,262144,1024,13728,4097,4194304,4194336,5514,8329,4194336,279841,16384,16813,22561,16641,17581,256,20480,4195468,4195213]

theorem envBound4644 : H12AffineFastState.Bounded env4644 := by
  intro p hp
  have h : env4644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4640_4644 : H12AffineEnvironment.transform 3 1 env4640 = env4644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env4640 == env4644) = true)

def env4645 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1280,8192,16384,8352,25899,1196,262144,1024,8352,1281,4194304,4194336,138,8329,4194336,279841,16384,16813,19745,16641,17581,256,17664,4195468,4195213]

theorem envBound4645 : H12AffineFastState.Bounded env4645 := by
  intro p hp
  have h : env4645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4644_4645 : H12AffineEnvironment.transform 11 1280 env4644 = env4645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env4644 == env4645) = true)

theorem identity4645 : scanCanonicalize (H12AffineFastState.compose env4645 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(21+1) ^^^ 282024) := by decide +kernel

theorem selectedBound4645 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4646 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1280,8192,16384,8352,25899,1196,262144,1024,8352,1281,282024,281992,138,8329,281992,279841,16384,16813,19745,16641,17581,256,17664,280868,282149]

theorem envBound4646 : H12AffineFastState.Bounded env4646 := by
  intro p hp
  have h : env4646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4645_4646 : H12AffineEnvironment.transform 21 282024 env4645 = env4646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 282024 env4645 == env4646) = true)

theorem identity4646 : scanCanonicalize (H12AffineFastState.compose env4646 (packedSelected [2,3,4,5,6,9,10,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 2310) := by decide +kernel

theorem selectedBound4646 : packedSelected [2,3,4,5,6,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env4647 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1280,2310,16384,2470,19501,1196,262144,1024,2470,1281,282024,281992,138,2447,281992,279841,16384,16813,19745,16641,17581,256,17664,280868,282149]

theorem envBound4647 : H12AffineFastState.Bounded env4647 := by
  intro p hp
  have h : env4647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4646_4647 : H12AffineEnvironment.transform 12 2310 env4646 = env4647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2310 env4646 == env4647) = true)

theorem identity4647 : scanCanonicalize (H12AffineFastState.compose env4647 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound4647 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env4648 : List Nat := [2,4,8,1,32,1,41,256,512,1024,2048,1280,2310,16384,2319,19501,1029,262144,1024,2319,1281,281857,281889,35,2342,281889,279841,16384,16644,19745,16641,17412,256,17664,280868,282149]

theorem envBound4648 : H12AffineFastState.Bounded env4648 := by
  intro p hp
  have h : env4648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4647_4648 : H12AffineEnvironment.transform 6 41 env4647 = env4648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env4647 == env4648) = true)

theorem identity4648 : scanCanonicalize (H12AffineFastState.compose env4648 (packedSelected [1,4,6,8,9,13,15] rootPS)) = affineNative (2^(13+1) ^^^ 261) := by decide +kernel

theorem selectedBound4648 : packedSelected [1,4,6,8,9,13,15] rootPS < 2^1333 := by decide +kernel

def env4649 : List Nat := [2,4,8,1,32,1,41,256,512,1024,2048,1280,2310,261,2319,3368,1029,262144,1024,2319,1281,265220,265252,35,2342,265252,263204,261,1,3108,4,1281,256,1029,264225,266016]

theorem envBound4649 : H12AffineFastState.Bounded env4649 := by
  intro p hp
  have h : env4649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4648_4649 : H12AffineEnvironment.transform 13 261 env4648 = env4649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 261 env4648 == env4649) = true)

theorem identity4649 : scanCanonicalize (H12AffineFastState.compose env4649 (packedSelected [0,1,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound4649 : packedSelected [0,1,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env4650 : List Nat := [2,4,8,1,32,1,41,256,512,549,2048,805,2310,261,2319,2829,544,262144,549,2319,804,264737,264705,35,2342,264705,262657,261,1,2561,4,804,256,544,264225,264453]

theorem envBound4650 : H12AffineFastState.Bounded env4650 := by
  intro p hp
  have h : env4650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4649_4650 : H12AffineEnvironment.transform 9 549 env4649 = env4650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env4649 == env4650) = true)

theorem identity4650 : scanCanonicalize (H12AffineFastState.compose env4650 (packedSelected [0,2,3,6,7,8,12] rootPS)) = affineNative (2^(17+1) ^^^ 555) := by decide +kernel

theorem selectedBound4650 : packedSelected [0,2,3,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env4651 : List Nat := [2,4,8,1,32,1,41,256,512,549,2048,805,2310,261,2319,2829,544,555,549,2319,804,2058,2090,35,2342,2090,42,261,1,2561,4,804,256,544,2570,2862]

theorem envBound4651 : H12AffineFastState.Bounded env4651 := by
  intro p hp
  have h : env4651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4650_4651 : H12AffineEnvironment.transform 17 555 env4650 = env4651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 555 env4650 == env4651) = true)

theorem identity4651 : scanCanonicalize (H12AffineFastState.compose env4651 (packedSelected [1,2,3,4,6,9] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound4651 : packedSelected [1,2,3,4,6,9] rootPS < 2^1333 := by decide +kernel

def env4652 : List Nat := [2,4,8,1,32,1,41,256,512,549,522,805,780,261,773,263,544,555,549,773,804,512,544,35,812,544,42,261,1,11,4,804,256,544,0,292]

theorem envBound4652 : H12AffineFastState.Bounded env4652 := by
  intro p hp
  have h : env4652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4651_4652 : H12AffineEnvironment.transform 10 522 env4651 = env4652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env4651 == env4652) = true)

theorem identity4652 : scanCanonicalize (H12AffineFastState.compose env4652 (packedSelected [2,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound4652 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env4653 : List Nat := [2,4,8,1,1,1,8,256,512,516,522,772,780,261,773,263,513,522,516,773,773,512,513,2,781,513,11,261,1,11,4,773,256,513,0,261]

theorem envBound4653 : H12AffineFastState.Bounded env4653 := by
  intro p hp
  have h : env4653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4652_4653 : H12AffineEnvironment.transform 4 1 env4652 = env4653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env4652 == env4653) = true)

theorem identity4653 : scanCanonicalize (H12AffineFastState.compose env4653 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4653 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4654 : List Nat := [2,4,8,1,1,1,8,4,512,516,522,512,520,1,513,3,513,522,516,513,513,512,513,2,521,513,11,1,1,11,4,513,4,513,0,1]

theorem envBound4654 : H12AffineFastState.Bounded env4654 := by
  intro p hp
  have h : env4654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4653_4654 : H12AffineEnvironment.transform 7 4 env4653 = env4654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4653 == env4654) = true)

theorem identity4654 : scanCanonicalize (H12AffineFastState.compose env4654 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4654 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4655 : List Nat := [2,4,2,1,1,1,2,4,512,516,512,512,514,1,513,3,513,512,516,513,513,512,513,2,515,513,1,1,1,1,4,513,4,513,0,1]

theorem envBound4655 : H12AffineFastState.Bounded env4655 := by
  intro p hp
  have h : env4655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4654_4655 : H12AffineEnvironment.transform 2 2 env4654 = env4655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4654 == env4655) = true)

theorem identity4655 : scanCanonicalize (H12AffineFastState.compose env4655 (packedSelected [6] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound4655 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4656 : List Nat := [2,4,2,1,1,1,2,4,1,5,1,1,3,1,0,3,0,1,5,0,0,1,0,2,2,0,1,1,1,1,4,0,4,0,0,1]

theorem envBound4656 : H12AffineFastState.Bounded env4656 := by
  intro p hp
  have h : env4656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4655_4656 : H12AffineEnvironment.transform 8 1 env4655 = env4656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env4655 == env4656) = true)

def env4657 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1281,8192,16384,8353,25899,1197,262144,1024,8353,1280,4194304,4194336,139,8329,4194336,279841,16384,16813,19744,16641,17581,256,17665,4195468,4195213]

theorem envBound4657 : H12AffineFastState.Bounded env4657 := by
  intro p hp
  have h : env4657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4644_4657 : H12AffineEnvironment.transform 11 1281 env4644 = env4657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1281 env4644 == env4657) = true)

theorem identity4657 : scanCanonicalize (H12AffineFastState.compose env4657 (packedSelected [0,7,9,17,20,21,22] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound4657 : packedSelected [0,7,9,17,20,21,22] rootPS < 2^1333 := by decide +kernel

def env4658 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1281,8192,16384,8353,25899,1197,2080,1024,8353,1280,4194304,4194336,139,8329,4194336,19713,16384,16813,19744,16641,17581,256,17665,4195468,4195213]

theorem envBound4658 : H12AffineFastState.Bounded env4658 := by
  intro p hp
  have h : env4658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4657_4658 : H12AffineEnvironment.transform 17 2080 env4657 = env4658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env4657 == env4658) = true)

theorem identity4658 : scanCanonicalize (H12AffineFastState.compose env4658 (packedSelected [0,1,7,8,10,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 11529) := by decide +kernel

theorem selectedBound4658 : packedSelected [0,1,7,8,10,11,15] rootPS < 2^1333 := by decide +kernel

def env4659 : List Nat := [2,4,8,1,32,1,128,256,512,1024,2048,1281,8192,11529,8353,2082,1197,2080,1024,8353,1280,4194304,4194336,139,8329,4194336,8200,11529,11428,8233,11272,10660,256,10248,4195468,4195213]

theorem envBound4659 : H12AffineFastState.Bounded env4659 := by
  intro p hp
  have h : env4659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4658_4659 : H12AffineEnvironment.transform 13 11529 env4658 = env4659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11529 env4658 == env4659) = true)

theorem identity4659 : scanCanonicalize (H12AffineFastState.compose env4659 (packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound4659 : packedSelected [0,2,3,4,5,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env4660 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1196,8192,11428,8353,2082,1197,2080,1024,8353,1197,4194304,4194336,139,8329,4194336,8200,11428,11428,8233,11272,10249,173,10248,4195468,4194848]

theorem envBound4660 : H12AffineFastState.Bounded env4660 := by
  intro p hp
  have h : env4660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4659_4660 : H12AffineEnvironment.transform 7 173 env4659 = env4660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env4659 == env4660) = true)

theorem identity4660 : scanCanonicalize (H12AffineFastState.compose env4660 (packedSelected [1,2,3] rootPS)) = affineNative (2^(21+1) ^^^ 10249) := by decide +kernel

theorem selectedBound4660 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env4661 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1196,8192,11428,8353,2082,1197,2080,1024,8353,1197,10249,10281,139,8329,10281,8200,11428,11428,8233,11272,10249,173,10248,11397,10793]

theorem envBound4661 : H12AffineFastState.Bounded env4661 := by
  intro p hp
  have h : env4661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4660_4661 : H12AffineEnvironment.transform 21 10249 env4660 = env4661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 10249 env4660 == env4661) = true)

theorem identity4661 : scanCanonicalize (H12AffineFastState.compose env4661 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound4661 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env4662 : List Nat := [2,4,8,1,32,1,128,173,512,1024,2048,1196,2089,1165,2184,2082,1197,2080,1024,2184,1197,32,0,139,2208,0,2081,1165,1165,2048,1057,32,173,33,1196,512]

theorem envBound4662 : H12AffineFastState.Bounded env4662 := by
  intro p hp
  have h : env4662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4661_4662 : H12AffineEnvironment.transform 12 2089 env4661 = env4662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env4661 == env4662) = true)

theorem identity4662 : scanCanonicalize (H12AffineFastState.compose env4662 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound4662 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env4663 : List Nat := [2,4,8,1,0,1,128,141,512,1024,2048,1164,2057,1165,2184,2050,1165,2048,1024,2184,1165,0,0,139,2176,0,2049,1165,1165,2048,1025,0,141,1,1164,512]

theorem envBound4663 : H12AffineFastState.Bounded env4663 := by
  intro p hp
  have h : env4663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4662_4663 : H12AffineEnvironment.transform 4 0 env4662 = env4663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env4662 == env4663) = true)

theorem identity4663 : scanCanonicalize (H12AffineFastState.compose env4663 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1039) := by decide +kernel

theorem selectedBound4663 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env4664 : List Nat := [2,4,8,1,0,1,128,141,512,1024,1039,1164,1030,1165,1159,1037,1165,1039,1024,1159,1165,0,0,139,1167,0,1038,1165,1165,1039,1025,0,141,1,1164,512]

theorem envBound4664 : H12AffineFastState.Bounded env4664 := by
  intro p hp
  have h : env4664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4663_4664 : H12AffineEnvironment.transform 10 1039 env4663 = env4664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1039 env4663 == env4664) = true)

theorem identity4664 : scanCanonicalize (H12AffineFastState.compose env4664 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound4664 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env4665 : List Nat := [2,4,8,1,0,1,128,141,0,1024,1039,1164,1030,1165,1159,1037,1165,1039,1024,1159,1165,0,0,139,1167,0,1038,1165,1165,1039,1025,0,141,1,1164,0]

theorem envBound4665 : H12AffineFastState.Bounded env4665 := by
  intro p hp
  have h : env4665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4664_4665 : H12AffineEnvironment.transform 8 0 env4664 = env4665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env4664 == env4665) = true)

theorem identity4665 : scanCanonicalize (H12AffineFastState.compose env4665 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 15) := by decide +kernel

theorem selectedBound4665 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env4666 : List Nat := [2,4,8,1,0,1,128,141,0,15,0,131,9,130,136,2,130,0,15,136,130,0,0,139,128,0,1,130,130,0,14,0,141,1,131,0]

theorem envBound4666 : H12AffineFastState.Bounded env4666 := by
  intro p hp
  have h : env4666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4665_4666 : H12AffineEnvironment.transform 9 15 env4665 = env4666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 15 env4665 == env4666) = true)

theorem identity4666 : scanCanonicalize (H12AffineFastState.compose env4666 (packedSelected [1,4] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound4666 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env4667 : List Nat := [2,4,8,1,0,1,3,14,0,15,0,0,9,1,11,2,1,0,15,11,1,0,0,8,3,0,1,1,1,0,14,0,14,1,0,0]

theorem envBound4667 : H12AffineFastState.Bounded env4667 := by
  intro p hp
  have h : env4667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4666_4667 : H12AffineEnvironment.transform 6 3 env4666 = env4667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env4666 == env4667) = true)

theorem identity4667 : scanCanonicalize (H12AffineFastState.compose env4667 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound4667 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env4668 : List Nat := [2,4,2,1,0,1,3,4,0,5,0,0,3,1,1,2,1,0,5,1,1,0,0,2,3,0,1,1,1,0,4,0,4,1,0,0]

theorem envBound4668 : H12AffineFastState.Bounded env4668 := by
  intro p hp
  have h : env4668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4667_4668 : H12AffineEnvironment.transform 2 2 env4667 = env4668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env4667 == env4668) = true)

def env4669 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4097,4194304,8388608,41002,8329,8388609,323712,16384,16812,22560,16656,12644668,256,20481,8389804,8389565]

theorem envBound4669 : H12AffineFastState.Bounded env4669 := by
  intro p hp
  have h : env4669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4609_4669 : H12AffineEnvironment.transform 5 17 env4609 = env4669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env4609 == env4669) = true)

theorem identity4669 : scanCanonicalize (H12AffineFastState.compose env4669 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(22+1) ^^^ 445) := by decide +kernel

theorem selectedBound4669 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4670 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4097,4194304,445,41002,8329,444,323712,16384,16812,22560,16656,4255873,256,20481,1297,512]

theorem envBound4670 : H12AffineFastState.Bounded env4670 := by
  intro p hp
  have h : env4670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4669_4670 : H12AffineEnvironment.transform 22 445 env4669 = env4670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 445 env4669 == env4670) = true)

theorem identity4670 : scanCanonicalize (H12AffineFastState.compose env4670 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41348) := by decide +kernel

theorem selectedBound4670 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4671 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,25914,4525,262144,1024,32768,4097,41348,445,41002,8329,444,323712,16384,16812,22560,16656,20741,256,20481,1297,512]

theorem envBound4671 : H12AffineFastState.Bounded env4671 := by
  intro p hp
  have h : env4671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4670_4671 : H12AffineEnvironment.transform 21 41348 env4670 = env4671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41348 env4670 == env4671) = true)

theorem identity4671 : scanCanonicalize (H12AffineFastState.compose env4671 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29313) := by decide +kernel

theorem selectedBound4671 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4672 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29313,25914,4525,262144,1024,29313,4097,21253,445,21163,8329,444,262657,16384,16812,22560,16656,20741,256,20481,1297,512]

theorem envBound4672 : H12AffineFastState.Bounded env4672 := by
  intro p hp
  have h : env4672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4671_4672 : H12AffineEnvironment.transform 14 29313 env4671 = env4672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29313 env4671 == env4672) = true)

theorem identity4672 : scanCanonicalize (H12AffineFastState.compose env4672 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(11+1) ^^^ 1464) := by decide +kernel

theorem selectedBound4672 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4673 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26425,25914,1045,262144,1024,26425,1465,18109,445,18195,8329,444,262657,16384,16812,19864,16656,17597,256,17849,1297,512]

theorem envBound4673 : H12AffineFastState.Bounded env4673 := by
  intro p hp
  have h : env4673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4672_4673 : H12AffineEnvironment.transform 11 1464 env4672 = env4673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1464 env4672 == env4673) = true)

theorem identity4673 : scanCanonicalize (H12AffineFastState.compose env4673 (packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 20156) := by decide +kernel

theorem selectedBound4673 : packedSelected [0,8,10,11,12,13,15,17,24,27,32] rootPS < 2^1333 := by decide +kernel

def env4674 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,16384,26425,25914,1045,20156,1024,26425,1465,18109,445,18195,8329,444,19645,16384,16812,19864,16656,17597,256,17849,1297,512]

theorem envBound4674 : H12AffineFastState.Bounded env4674 := by
  intro p hp
  have h : env4674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4673_4674 : H12AffineEnvironment.transform 17 20156 env4673 = env4674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 20156 env4673 == env4674) = true)

theorem identity4674 : scanCanonicalize (H12AffineFastState.compose env4674 (packedSelected [1,3,8,10,18,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 1841) := by decide +kernel

theorem selectedBound4674 : packedSelected [1,3,8,10,18,23,24] rootPS < 2^1333 := by decide +kernel

def env4675 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1464,8192,1841,8200,8715,1045,2445,1024,8200,1465,396,445,34,8329,444,2956,1841,1693,2729,1569,908,256,648,1297,512]

theorem envBound4675 : H12AffineFastState.Bounded env4675 := by
  intro p hp
  have h : env4675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4674_4675 : H12AffineEnvironment.transform 13 1841 env4674 = env4675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1841 env4674 == env4675) = true)

theorem identity4675 : scanCanonicalize (H12AffineFastState.compose env4675 (packedSelected [0,4,7,9,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound4675 : packedSelected [0,4,7,9,13,17] rootPS < 2^1333 := by decide +kernel

def env4676 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,1044,8192,1693,8200,8715,1045,2081,1024,8200,1045,32,17,34,8329,16,2592,1693,1693,2729,1569,544,172,648,1213,512]

theorem envBound4676 : H12AffineFastState.Bounded env4676 := by
  intro p hp
  have h : env4676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4675_4676 : H12AffineEnvironment.transform 7 172 env4675 = env4676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env4675 == env4676) = true)

theorem identity4676 : scanCanonicalize (H12AffineFastState.compose env4676 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 1550) := by decide +kernel

theorem selectedBound4676 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env4677 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1550,1044,8192,1693,8200,8715,1045,1583,1024,8200,1045,32,17,34,8329,16,1070,1693,1693,1191,1569,544,172,648,1213,512]

theorem envBound4677 : H12AffineFastState.Bounded env4677 := by
  intro p hp
  have h : env4677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4676_4677 : H12AffineEnvironment.transform 10 1550 env4676 = env4677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1550 env4676 == env4677) = true)

theorem identity4677 : scanCanonicalize (H12AffineFastState.compose env4677 (packedSelected [1,2,4,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1031) := by decide +kernel

theorem selectedBound4677 : packedSelected [1,2,4,5,7] rootPS < 2^1333 := by decide +kernel

def env4678 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1550,1044,1031,1693,1039,1548,1045,1583,1024,1039,1045,32,17,34,1166,16,1070,1693,1693,1191,1569,544,172,648,1213,512]

theorem envBound4678 : H12AffineFastState.Bounded env4678 := by
  intro p hp
  have h : env4678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4677_4678 : H12AffineEnvironment.transform 12 1031 env4677 = env4678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1031 env4677 == env4678) = true)

theorem identity4678 : scanCanonicalize (H12AffineFastState.compose env4678 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound4678 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env4679 : List Nat := [2,4,8,16,32,17,128,172,169,1024,1191,1044,1031,1076,1039,1189,1045,1158,1024,1039,1045,32,17,34,1166,16,1070,1076,1076,1191,1160,137,172,33,1213,169]

theorem envBound4679 : H12AffineFastState.Bounded env4679 := by
  intro p hp
  have h : env4679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4678_4679 : H12AffineEnvironment.transform 8 169 env4678 = env4679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env4678 == env4679) = true)

theorem identity4679 : scanCanonicalize (H12AffineFastState.compose env4679 (packedSelected [2,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 50) := by decide +kernel

theorem selectedBound4679 : packedSelected [2,3,4] rootPS < 2^1333 := by decide +kernel

def env4680 : List Nat := [2,4,8,16,32,17,50,30,27,1024,1045,1044,1031,1076,1039,1047,1045,1076,1024,1039,1045,32,17,34,1084,16,1070,1076,1076,1045,1082,59,30,33,1039,27]

theorem envBound4680 : H12AffineFastState.Bounded env4680 := by
  intro p hp
  have h : env4680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4679_4680 : H12AffineEnvironment.transform 6 50 env4679 = env4680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 50 env4679 == env4680) = true)

theorem identity4680 : scanCanonicalize (H12AffineFastState.compose env4680 (packedSelected [3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound4680 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env4681 : List Nat := [2,4,8,16,32,17,50,30,27,46,59,58,41,26,33,57,59,26,46,33,59,32,17,34,18,16,0,26,26,59,20,59,30,33,33,27]

theorem envBound4681 : H12AffineFastState.Bounded env4681 := by
  intro p hp
  have h : env4681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4680_4681 : H12AffineEnvironment.transform 9 46 env4680 = env4681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env4680 == env4681) = true)

def env4682 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,8388608,41002,8329,8388689,323792,16384,16893,22640,74795,12644668,257,20561,8479126,8389613]

theorem envBound4682 : H12AffineFastState.Bounded env4682 := by
  intro p hp
  have h : env4682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4607_4682 : H12AffineEnvironment.transform 18 1025 env4607 = env4682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env4607 == env4682) = true)

theorem identity4682 : scanCanonicalize (H12AffineFastState.compose env4682 (packedSelected [14] rootPS)) = affineNative (2^(22+1) ^^^ 73786) := by decide +kernel

theorem selectedBound4682 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env4683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,4604,262144,1025,32768,4097,4194304,73786,41002,8329,73835,323792,16384,16893,22640,74795,4313350,257,20561,16812,74711]

theorem envBound4683 : H12AffineFastState.Bounded env4683 := by
  intro p hp
  have h : env4683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4682_4683 : H12AffineEnvironment.transform 22 73786 env4682 = env4683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73786 env4682 == env4683) = true)

def env4684 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,4524,262144,1025,32768,4097,4194304,73786,41002,8329,73787,323712,16384,16813,22560,74795,4313350,257,20481,16812,74631]

theorem envBound4684 : H12AffineFastState.Bounded env4684 := by
  intro p hp
  have h : env4684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4683_4684 : H12AffineEnvironment.transform 5 16 env4683 = env4684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env4683 == env4684) = true)

theorem identity4684 : scanCanonicalize (H12AffineFastState.compose env4684 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8583) := by decide +kernel

theorem selectedBound4684 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env4685 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4524,262144,1025,32768,4097,4194304,445,41002,8329,444,323712,16384,16813,22560,1452,4255873,257,20481,16812,512]

theorem envBound4685 : H12AffineFastState.Bounded env4685 := by
  intro p hp
  have h : env4685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4684_4685 : H12AffineEnvironment.transform 15 8583 env4684 = env4685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8583 env4684 == env4685) = true)

theorem identity4685 : scanCanonicalize (H12AffineFastState.compose env4685 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 41349) := by decide +kernel

theorem selectedBound4685 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env4686 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8583,4524,262144,1025,32768,4097,41349,445,41002,8329,444,323712,16384,16813,22560,1452,20740,257,20481,16812,512]

theorem envBound4686 : H12AffineFastState.Bounded env4686 := by
  intro p hp
  have h : env4686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4685_4686 : H12AffineEnvironment.transform 21 41349 env4685 = env4686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41349 env4685 == env4686) = true)

theorem identity4686 : scanCanonicalize (H12AffineFastState.compose env4686 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 13884) := by decide +kernel

theorem selectedBound4686 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env4687 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,13884,8583,4524,262144,1025,13884,4097,6073,445,5654,8329,444,280252,16384,16813,22560,1452,20740,257,20481,16812,512]

theorem envBound4687 : H12AffineFastState.Bounded env4687 := by
  intro p hp
  have h : env4687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4686_4687 : H12AffineEnvironment.transform 14 13884 env4686 = env4687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13884 env4686 == env4687) = true)

theorem identity4687 : scanCanonicalize (H12AffineFastState.compose env4687 (packedSelected [3,5,10,13,21] rootPS)) = affineNative (2^(13+1) ^^^ 4357) := by decide +kernel

theorem selectedBound4687 : packedSelected [3,5,10,13,21] rootPS < 2^1333 := by decide +kernel

def env4688 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,4357,13884,8583,4524,262144,1025,13884,4097,6073,445,5654,8329,444,268217,4357,4264,2341,1452,1,257,260,4265,512]

theorem envBound4688 : H12AffineFastState.Bounded env4688 := by
  intro p hp
  have h : env4688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4687_4688 : H12AffineEnvironment.transform 13 4357 env4687 = env4688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4357 env4687 == env4688) = true)

theorem identity4688 : scanCanonicalize (H12AffineFastState.compose env4688 (packedSelected [3,5,8,28] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound4688 : packedSelected [3,5,8,28] rootPS < 2^1333 := by decide +kernel

def env4689 : List Nat := [2,4,8,16,32,16,128,4,512,1024,2048,4096,8192,4097,13884,8323,4264,262144,1025,13884,4097,5821,185,5654,8329,184,267965,4097,4264,2081,1192,1,5,0,4265,512]

theorem envBound4689 : H12AffineFastState.Bounded env4689 := by
  intro p hp
  have h : env4689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans4688_4689 : H12AffineEnvironment.transform 7 4 env4688 = env4689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env4688 == env4689) = true)

end H12CloudChart1