import H12CloudChart1Data058

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound14834 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env14835 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5457,0,262,5392,2341,1025,1,4161,32,17,82,269,64,2049,5393,4177,2420,1365,33,257,112,5376,513]

theorem envBound14835 : H12AffineFastState.Bounded env14835 := by
  intro p hp
  have h : env14835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14834_14835 : H12AffineEnvironment.transform 12 268 env14834 = env14835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14834 == env14835) = true)

theorem identity14835 : scanCanonicalize (H12AffineFastState.compose env14835 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14835 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14836 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,0,262,5392,2341,1025,1,4112,32,17,3,269,17,2049,5393,4096,2341,1284,33,257,33,5376,513]

theorem envBound14836 : H12AffineFastState.Bounded env14836 := by
  intro p hp
  have h : env14836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14835_14836 : H12AffineEnvironment.transform 5 17 env14835 = env14836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14835 == env14836) = true)

theorem identity14836 : scanCanonicalize (H12AffineFastState.compose env14836 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14836 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14837 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,4096,268,5376,0,262,5392,2309,1025,1,4112,0,17,3,269,17,2049,5393,4096,2309,1284,1,257,1,5376,513]

theorem envBound14837 : H12AffineFastState.Bounded env14837 := by
  intro p hp
  have h : env14837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14836_14837 : H12AffineEnvironment.transform 4 0 env14836 = env14837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14836 == env14837) = true)

theorem identity14837 : scanCanonicalize (H12AffineFastState.compose env14837 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2846) := by decide +kernel

theorem selectedBound14837 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14838 : List Nat := [2,4,8,16,0,17,9,256,512,1024,2048,2846,268,3614,0,262,3598,2309,1025,1,2830,0,17,3,269,17,2049,3599,2846,2309,1284,1,257,1,3614,513]

theorem envBound14838 : H12AffineFastState.Bounded env14838 := by
  intro p hp
  have h : env14838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14837_14838 : H12AffineEnvironment.transform 11 2846 env14837 = env14838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2846 env14837 == env14838) = true)

theorem identity14838 : scanCanonicalize (H12AffineFastState.compose env14838 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound14838 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14839 : List Nat := [2,4,8,16,0,17,9,256,512,1024,10,788,268,1556,0,262,1540,271,1025,1,772,0,17,3,269,17,11,1541,788,271,1284,1,257,1,1556,513]

theorem envBound14839 : H12AffineFastState.Bounded env14839 := by
  intro p hp
  have h : env14839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14838_14839 : H12AffineEnvironment.transform 10 10 env14838 = env14839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env14838 == env14839) = true)

theorem identity14839 : scanCanonicalize (H12AffineFastState.compose env14839 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound14839 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14840 : List Nat := [2,4,8,11,0,10,9,256,512,1024,10,783,268,1551,0,262,1540,271,1025,1,772,0,10,3,269,10,11,1541,783,271,1284,1,257,1,1551,513]

theorem envBound14840 : H12AffineFastState.Bounded env14840 := by
  intro p hp
  have h : env14840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14839_14840 : H12AffineEnvironment.transform 3 11 env14839 = env14840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env14839 == env14840) = true)

theorem identity14840 : scanCanonicalize (H12AffineFastState.compose env14840 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound14840 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14841 : List Nat := [2,4,8,11,0,10,9,256,512,256,10,783,268,783,0,262,772,271,257,1,772,0,10,3,269,10,11,773,783,271,4,1,257,1,783,513]

theorem envBound14841 : H12AffineFastState.Bounded env14841 := by
  intro p hp
  have h : env14841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14840_14841 : H12AffineEnvironment.transform 9 256 env14840 = env14841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env14840 == env14841) = true)

theorem identity14841 : scanCanonicalize (H12AffineFastState.compose env14841 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound14841 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14842 : List Nat := [2,4,8,11,0,10,9,256,261,256,10,10,268,10,0,262,1,271,257,1,1,0,10,3,269,10,11,0,10,271,4,1,257,1,10,260]

theorem envBound14842 : H12AffineFastState.Bounded env14842 := by
  intro p hp
  have h : env14842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14841_14842 : H12AffineEnvironment.transform 8 261 env14841 = env14842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env14841 == env14842) = true)

theorem identity14842 : scanCanonicalize (H12AffineFastState.compose env14842 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 11) := by decide +kernel

theorem selectedBound14842 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14843 : List Nat := [2,4,8,11,0,10,9,11,14,11,10,10,7,10,0,13,1,4,10,1,1,0,10,3,6,10,11,0,10,4,4,1,10,1,10,15]

theorem envBound14843 : H12AffineFastState.Bounded env14843 := by
  intro p hp
  have h : env14843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14842_14843 : H12AffineEnvironment.transform 7 11 env14842 = env14843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 11 env14842 == env14843) = true)

theorem identity14843 : scanCanonicalize (H12AffineFastState.compose env14843 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound14843 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14844 : List Nat := [2,4,5,6,0,7,4,6,3,6,7,7,7,7,0,0,1,4,7,1,1,0,7,3,6,7,6,0,7,4,4,1,7,1,7,2]

theorem envBound14844 : H12AffineFastState.Bounded env14844 := by
  intro p hp
  have h : env14844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14843_14844 : H12AffineEnvironment.transform 2 5 env14843 = env14844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env14843 == env14844) = true)

theorem identity14844 : scanCanonicalize (H12AffineFastState.compose env14844 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14844 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env14845 : List Nat := [0,4,5,4,0,5,4,4,1,4,5,5,5,5,0,0,1,4,5,1,1,0,5,1,4,5,4,0,5,4,4,1,5,1,5,0]

theorem envBound14845 : H12AffineFastState.Bounded env14845 := by
  intro p hp
  have h : env14845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14844_14845 : H12AffineEnvironment.transform 0 0 env14844 = env14845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14844 == env14845) = true)

def env14846 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169217,98781,8328,64,64605,163841,17664,283904,168140,412109,257,21793,46213,243483]

theorem envBound14846 : H12AffineFastState.Bounded env14846 := by
  intro p hp
  have h : env14846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14814_14846 : H12AffineEnvironment.transform 21 272513 env14814 = env14846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env14814 == env14846) = true)

theorem identity14846 : scanCanonicalize (H12AffineFastState.compose env14846 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound14846 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14847 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,115871,272513,120015,98781,8328,64,64605,115151,17664,283904,119042,329731,257,21793,46213,63189]

theorem envBound14847 : H12AffineFastState.Bounded env14847 := by
  intro p hp
  have h : env14847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14846_14847 : H12AffineEnvironment.transform 16 82382 env14846 = env14847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env14846 == env14847) = true)

def env14848 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115871,272513,119967,98701,8328,16,64525,115103,17664,283904,119042,329731,257,21793,46213,63109]

theorem envBound14848 : H12AffineFastState.Bounded env14848 := by
  intro p hp
  have h : env14848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14847_14848 : H12AffineEnvironment.transform 5 16 env14847 = env14848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14847 == env14848) = true)

theorem identity14848 : scanCanonicalize (H12AffineFastState.compose env14848 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14848 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env14849 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,82199,262144,1025,32769,115734,272392,119830,98564,8193,16,64525,114966,17664,283904,119042,329731,257,21793,46092,62988]

theorem envBound14849 : H12AffineFastState.Bounded env14849 := by
  intro p hp
  have h : env14849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14848_14849 : H12AffineEnvironment.transform 6 9 env14848 = env14849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14848 == env14849) = true)

theorem identity14849 : scanCanonicalize (H12AffineFastState.compose env14849 (packedSelected [5,8,19,24,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound14849 : packedSelected [5,8,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env14850 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,82199,43049,1025,32769,115734,32801,119830,98564,8193,16,64525,114966,17664,64809,119042,106538,257,21793,46092,62988]

theorem envBound14850 : H12AffineFastState.Bounded env14850 := by
  intro p hp
  have h : env14850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14849_14850 : H12AffineEnvironment.transform 17 43049 env14849 = env14850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env14849 == env14850) = true)

theorem identity14850 : scanCanonicalize (H12AffineFastState.compose env14850 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound14850 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env14851 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,0,65536,82199,10281,1025,1,82966,33,87062,65796,8193,16,31757,82198,17664,32041,86274,73770,257,21793,13324,30220]

theorem envBound14851 : H12AffineFastState.Bounded env14851 := by
  intro p hp
  have h : env14851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14850_14851 : H12AffineEnvironment.transform 14 0 env14850 = env14851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env14850 == env14851) = true)

theorem identity14851 : scanCanonicalize (H12AffineFastState.compose env14851 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound14851 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14852 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,65536,79130,10281,1025,1,77851,33,73755,65796,8193,16,2048,79131,12557,2340,75023,73770,257,8492,13324,513]

theorem envBound14852 : H12AffineFastState.Bounded env14852 := by
  intro p hp
  have h : env14852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14851_14852 : H12AffineEnvironment.transform 13 13325 env14851 = env14852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env14851 == env14852) = true)

theorem identity14852 : scanCanonicalize (H12AffineFastState.compose env14852 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound14852 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env14853 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,0,262,13340,10281,1025,1,12573,33,8477,2,8193,16,2048,13341,12557,2340,9225,8492,257,8492,13324,513]

theorem envBound14853 : H12AffineFastState.Bounded env14853 := by
  intro p hp
  have h : env14853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14852_14853 : H12AffineEnvironment.transform 15 262 env14852 = env14853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env14852 == env14853) = true)

theorem identity14853 : scanCanonicalize (H12AffineFastState.compose env14853 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14853 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14854 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5392,2341,1025,1,4113,33,17,2,269,16,2048,5393,4097,2340,1285,32,257,32,5376,513]

theorem envBound14854 : H12AffineFastState.Bounded env14854 := by
  intro p hp
  have h : env14854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14853_14854 : H12AffineEnvironment.transform 12 268 env14853 = env14854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14853 == env14854) = true)

theorem identity14854 : scanCanonicalize (H12AffineFastState.compose env14854 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound14854 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14855 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1,268,1280,0,262,1297,2341,1025,1,16,33,17,2,269,16,2048,1296,0,2340,1285,32,257,32,1281,513]

theorem envBound14855 : H12AffineFastState.Bounded env14855 := by
  intro p hp
  have h : env14855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14854_14855 : H12AffineEnvironment.transform 11 1 env14854 = env14855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env14854 == env14855) = true)

theorem identity14855 : scanCanonicalize (H12AffineFastState.compose env14855 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound14855 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14856 : List Nat := [2,4,8,16,32,16,9,256,512,768,2048,1,268,512,0,262,529,2341,769,1,16,33,17,2,269,16,2048,528,0,2340,517,32,257,32,513,513]

theorem envBound14856 : H12AffineFastState.Bounded env14856 := by
  intro p hp
  have h : env14856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14855_14856 : H12AffineEnvironment.transform 9 768 env14855 = env14856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env14855 == env14856) = true)

theorem identity14856 : scanCanonicalize (H12AffineFastState.compose env14856 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound14856 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14857 : List Nat := [2,4,8,16,32,16,9,256,512,768,512,1,268,512,0,262,529,805,769,1,16,33,17,2,269,16,512,528,0,804,517,32,257,32,513,513]

theorem envBound14857 : H12AffineFastState.Bounded env14857 := by
  intro p hp
  have h : env14857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14856_14857 : H12AffineEnvironment.transform 10 512 env14856 = env14857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env14856 == env14857) = true)

theorem identity14857 : scanCanonicalize (H12AffineFastState.compose env14857 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound14857 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env14858 : List Nat := [2,4,8,16,32,16,9,256,0,256,0,1,268,0,0,262,17,293,257,1,16,33,17,2,269,16,0,16,0,292,5,32,257,32,1,1]

theorem envBound14858 : H12AffineFastState.Bounded env14858 := by
  intro p hp
  have h : env14858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14857_14858 : H12AffineEnvironment.transform 8 0 env14857 = env14858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env14857 == env14858) = true)

theorem identity14858 : scanCanonicalize (H12AffineFastState.compose env14858 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14858 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env14859 : List Nat := [2,4,8,16,32,16,9,37,0,37,0,1,41,0,0,35,17,0,36,1,16,33,17,2,40,16,0,16,0,1,5,32,36,32,1,1]

theorem envBound14859 : H12AffineFastState.Bounded env14859 := by
  intro p hp
  have h : env14859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14858_14859 : H12AffineEnvironment.transform 7 37 env14858 = env14859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14858 == env14859) = true)

theorem identity14859 : scanCanonicalize (H12AffineFastState.compose env14859 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound14859 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env14860 : List Nat := [2,4,8,0,32,0,9,37,0,37,0,1,41,0,0,35,1,0,36,1,0,33,1,2,40,0,0,0,0,1,5,32,36,32,1,1]

theorem envBound14860 : H12AffineFastState.Bounded env14860 := by
  intro p hp
  have h : env14860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14859_14860 : H12AffineEnvironment.transform 3 0 env14859 = env14860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env14859 == env14860) = true)

theorem identity14860 : scanCanonicalize (H12AffineFastState.compose env14860 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14860 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14861 : List Nat := [2,4,8,0,0,0,9,5,0,5,0,1,9,0,0,3,1,0,4,1,0,1,1,2,8,0,0,0,0,1,5,0,4,0,1,1]

theorem envBound14861 : H12AffineFastState.Bounded env14861 := by
  intro p hp
  have h : env14861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14860_14861 : H12AffineEnvironment.transform 4 0 env14860 = env14861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14860 == env14861) = true)

def env14862 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115871,272513,119966,98700,8328,17,64524,115102,17664,283904,119042,329731,257,21793,46213,63108]

theorem envBound14862 : H12AffineFastState.Bounded env14862 := by
  intro p hp
  have h : env14862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14847_14862 : H12AffineEnvironment.transform 5 17 env14847 = env14862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14847 == env14862) = true)

theorem identity14862 : scanCanonicalize (H12AffineFastState.compose env14862 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14862 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env14863 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,13460,262144,1025,32769,45460,272513,41365,62599,8328,17,64524,46229,17664,283904,41993,294152,257,21793,46213,63108]

theorem envBound14863 : H12AffineFastState.Bounded env14863 := by
  intro p hp
  have h : env14863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14862_14863 : H12AffineEnvironment.transform 15 29963 env14862 = env14863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14862 == env14863) = true)

theorem identity14863 : scanCanonicalize (H12AffineFastState.compose env14863 (packedSelected [0,1,3,9,16,17,18,20,22,23,24,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound14863 : packedSelected [0,1,3,9,16,17,18,20,22,23,24,27,28] rootPS < 2^1333 := by decide +kernel

def env14864 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,13460,2340,1025,32769,45460,8613,41365,62599,8328,17,64524,46229,17664,23588,41993,29740,257,21793,46213,63108]

theorem envBound14864 : H12AffineFastState.Bounded env14864 := by
  intro p hp
  have h : env14864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14863_14864 : H12AffineEnvironment.transform 17 2340 env14863 = env14864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env14863 == env14864) = true)

theorem identity14864 : scanCanonicalize (H12AffineFastState.compose env14864 (packedSelected [0,1,3,4,5,7,8,10,16,17,18,19,20,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 29828) := by decide +kernel

theorem selectedBound14864 : packedSelected [0,1,3,4,5,7,8,10,16,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env14865 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29828,29963,13460,2340,1025,29829,17680,8613,21777,3,8328,17,2184,16401,17664,23588,20621,29740,257,21793,16385,512]

theorem envBound14865 : H12AffineFastState.Bounded env14865 := by
  intro p hp
  have h : env14865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14864_14865 : H12AffineEnvironment.transform 14 29828 env14864 = env14865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29828 env14864 == env14865) = true)

theorem identity14865 : scanCanonicalize (H12AffineFastState.compose env14865 (packedSelected [1,2,3,5,6,8,10,17,19] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound14865 : packedSelected [1,2,3,5,6,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env14866 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,301,16384,21929,21542,5561,2340,1025,21928,17680,136,21777,3,421,17,2184,16401,17664,23588,20621,21761,257,21793,16385,512]

theorem envBound14866 : H12AffineFastState.Bounded env14866 := by
  intro p hp
  have h : env14866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14865_14866 : H12AffineEnvironment.transform 12 301 env14865 = env14866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env14865 == env14866) = true)

theorem identity14866 : scanCanonicalize (H12AffineFastState.compose env14866 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound14866 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env14867 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,16384,21792,21542,5424,2340,1025,21793,17680,1,21777,3,300,17,2049,16401,17664,23588,20484,21761,257,21793,16385,512]

theorem envBound14867 : H12AffineFastState.Bounded env14867 := by
  intro p hp
  have h : env14867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14866_14867 : H12AffineEnvironment.transform 6 9 env14866 = env14867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14866 == env14867) = true)

theorem identity14867 : scanCanonicalize (H12AffineFastState.compose env14867 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5408) := by decide +kernel

theorem selectedBound14867 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14868 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,301,5408,0,262,5424,2340,1025,1,4144,1,49,3,300,17,2049,5425,4128,2308,1316,33,257,1,5409,512]

theorem envBound14868 : H12AffineFastState.Bounded env14868 := by
  intro p hp
  have h : env14868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14867_14868 : H12AffineEnvironment.transform 13 5408 env14867 = env14868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5408 env14867 == env14868) = true)

theorem identity14868 : scanCanonicalize (H12AffineFastState.compose env14868 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14868 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14869 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8,5125,0,35,5141,2049,1025,1,4144,1,49,3,9,17,2049,5140,4128,2081,1025,33,36,1,5124,512]

theorem envBound14869 : H12AffineFastState.Bounded env14869 := by
  intro p hp
  have h : env14869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14868_14869 : H12AffineEnvironment.transform 7 37 env14868 = env14869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14868 == env14869) = true)

def env14870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,8388608,8590557,8328,64,4510941,8393985,8572929,8830977,168141,12645452,257,21792,46212,243482]

theorem envBound14870 : H12AffineFastState.Bounded env14870 := by
  intro p hp
  have h : env14870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14754_14870 : H12AffineEnvironment.transform 23 8590557 env14754 = env14870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590557 env14754 == env14870) = true)

def env14871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169216,98781,8328,64,4510941,163841,17665,283905,168141,4350284,257,21792,46212,243482]

theorem envBound14871 : H12AffineFastState.Bounded env14871 := by
  intro p hp
  have h : env14871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14870_14871 : H12AffineEnvironment.transform 22 169216 env14870 = env14871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env14870 == env14871) = true)

def env14872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169216,98781,8328,64,64605,163841,17665,283905,168141,412108,257,21792,46212,243482]

theorem envBound14872 : H12AffineFastState.Bounded env14872 := by
  intro p hp
  have h : env14872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14871_14872 : H12AffineEnvironment.transform 21 272512 env14871 = env14872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env14871 == env14872) = true)

theorem identity14872 : scanCanonicalize (H12AffineFastState.compose env14872 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound14872 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,58517,272512,62660,98781,8328,64,64605,57797,17665,283905,61705,272392,257,21792,46212,120542]

theorem envBound14873 : H12AffineFastState.Bounded env14873 := by
  intro p hp
  have h : env14873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14872_14873 : H12AffineEnvironment.transform 16 25028 env14872 = env14873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env14872 == env14873) = true)

def env14874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10280,1025,32769,58517,168,62660,98781,8328,64,64605,57797,17665,32041,61705,32,257,21792,46212,120542]

theorem envBound14874 : H12AffineFastState.Bounded env14874 := by
  intro p hp
  have h : env14874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14873_14874 : H12AffineEnvironment.transform 17 10280 env14873 = env14874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14873 == env14874) = true)

theorem identity14874 : scanCanonicalize (H12AffineFastState.compose env14874 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 28729) := by decide +kernel

theorem selectedBound14874 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env14875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,28729,65536,25028,10280,1025,28728,5292,168,1277,94692,8328,64,3172,4604,17665,32041,304,32,257,21792,17597,75495]

theorem envBound14875 : H12AffineFastState.Bounded env14875 := by
  intro p hp
  have h : env14875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14874_14875 : H12AffineEnvironment.transform 14 28729 env14874 = env14875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28729 env14874 == env14875) = true)

theorem identity14875 : scanCanonicalize (H12AffineFastState.compose env14875 (packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound14875 : packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env14876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,1261,65536,5392,10280,1025,1260,5292,168,1277,66864,8328,64,3172,4604,12757,2557,304,32,257,8692,12393,75495]

theorem envBound14876 : H12AffineFastState.Bounded env14876 := by
  intro p hp
  have h : env14876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14875_14876 : H12AffineEnvironment.transform 13 13524 env14875 = env14876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env14875 == env14876) = true)

theorem identity14876 : scanCanonicalize (H12AffineFastState.compose env14876 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound14876 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env14877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,4589,1261,65536,5392,3345,1025,1260,5292,168,1277,66864,1457,64,3172,4604,5356,2557,304,32,257,1229,5456,66526]

theorem envBound14877 : H12AffineFastState.Bounded env14877 := by
  intro p hp
  have h : env14877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14876_14877 : H12AffineEnvironment.transform 12 1337 env14876 = env14877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env14876 == env14877) = true)

theorem identity14877 : scanCanonicalize (H12AffineFastState.compose env14877 (packedSelected [0,3,4,5,7,10,22] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound14877 : packedSelected [0,3,4,5,7,10,22] rootPS < 2^1333 := by decide +kernel

def env14878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1337,4589,1261,35,5392,3345,1025,1260,5292,168,1277,1299,1457,64,3172,4604,5356,2557,304,32,257,1229,5456,1021]

theorem envBound14878 : H12AffineFastState.Bounded env14878 := by
  intro p hp
  have h : env14878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14877_14878 : H12AffineEnvironment.transform 15 35 env14877 = env14878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env14877 == env14878) = true)

theorem identity14878 : scanCanonicalize (H12AffineFastState.compose env14878 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound14878 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env14879 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,1221,4113,1261,35,5356,3309,1025,1260,5292,168,1277,1263,1101,64,3172,4096,5356,2049,204,32,253,1229,5292,513]

theorem envBound14879 : H12AffineFastState.Bounded env14879 := by
  intro p hp
  have h : env14879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14878_14879 : H12AffineEnvironment.transform 7 252 env14878 = env14879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env14878 == env14879) = true)

theorem identity14879 : scanCanonicalize (H12AffineFastState.compose env14879 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound14879 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14880 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,4096,41,4113,1,35,4096,2049,237,0,4160,168,17,3,161,64,2184,4096,4096,2049,204,32,253,33,4160,513]

theorem envBound14880 : H12AffineFastState.Bounded env14880 := by
  intro p hp
  have h : env14880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14879_14880 : H12AffineEnvironment.transform 9 236 env14879 = env14880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env14879 == env14880) = true)

theorem identity14880 : scanCanonicalize (H12AffineFastState.compose env14880 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 249) := by decide +kernel

theorem selectedBound14880 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14881 : List Nat := [2,4,8,16,32,64,128,252,512,236,2048,249,41,232,1,35,249,2049,237,0,185,168,17,3,161,64,2184,249,249,2049,204,32,253,33,185,513]

theorem envBound14881 : H12AffineFastState.Bounded env14881 := by
  intro p hp
  have h : env14881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14880_14881 : H12AffineEnvironment.transform 11 249 env14880 = env14881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 249 env14880 == env14881) = true)

theorem identity14881 : scanCanonicalize (H12AffineFastState.compose env14881 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 169) := by decide +kernel

theorem selectedBound14881 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env14882 : List Nat := [2,4,8,16,32,64,128,252,169,236,2048,249,41,232,1,35,249,2049,237,0,185,168,17,3,161,64,2184,249,249,2049,204,32,253,33,185,168]

theorem envBound14882 : H12AffineFastState.Bounded env14882 := by
  intro p hp
  have h : env14882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14881_14882 : H12AffineEnvironment.transform 8 169 env14881 = env14882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 169 env14881 == env14882) = true)

theorem identity14882 : scanCanonicalize (H12AffineFastState.compose env14882 (packedSelected [6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound14882 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14883 : List Nat := [2,4,8,16,32,64,88,36,113,52,2048,33,41,48,1,35,33,2049,53,0,97,112,17,3,121,64,2128,33,33,2049,20,32,37,33,97,112]

theorem envBound14883 : H12AffineFastState.Bounded env14883 := by
  intro p hp
  have h : env14883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14882_14883 : H12AffineEnvironment.transform 6 88 env14882 = env14883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env14882 == env14883) = true)

theorem identity14883 : scanCanonicalize (H12AffineFastState.compose env14883 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound14883 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14884 : List Nat := [2,4,8,16,32,32,56,36,17,52,2048,33,41,48,1,35,33,2049,53,0,1,16,17,3,25,32,2096,33,33,2049,20,32,37,33,1,16]

theorem envBound14884 : H12AffineFastState.Bounded env14884 := by
  intro p hp
  have h : env14884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14883_14884 : H12AffineEnvironment.transform 5 32 env14883 = env14884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env14883 == env14884) = true)

theorem identity14884 : scanCanonicalize (H12AffineFastState.compose env14884 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14884 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14885 : List Nat := [2,4,8,16,0,0,24,4,17,20,2048,1,9,16,1,3,1,2049,21,0,1,16,17,3,25,0,2064,1,1,2049,20,0,5,1,1,16]

theorem envBound14885 : H12AffineFastState.Bounded env14885 := by
  intro p hp
  have h : env14885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14884_14885 : H12AffineEnvironment.transform 4 0 env14884 = env14885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14884 == env14885) = true)

def env14886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10281,1025,32769,58517,169,62660,98781,8328,64,64605,57797,17665,32040,61705,33,257,21792,46212,120542]

theorem envBound14886 : H12AffineFastState.Bounded env14886 := by
  intro p hp
  have h : env14886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14873_14886 : H12AffineEnvironment.transform 17 10281 env14873 = env14886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env14873 == env14886) = true)

theorem identity14886 : scanCanonicalize (H12AffineFastState.compose env14886 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound14886 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env14887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,29963,25028,10281,1025,32769,58517,169,62660,62678,8328,64,64605,57797,17665,32040,61705,33,257,21792,46212,41941]

theorem envBound14887 : H12AffineFastState.Bounded env14887 := by
  intro p hp
  have h : env14887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14886_14887 : H12AffineEnvironment.transform 15 29963 env14886 = env14887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env14886 == env14887) = true)

theorem identity14887 : scanCanonicalize (H12AffineFastState.compose env14887 (packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound14887 : packedSelected [0,2,3,4,5,6,9,10,11,16,17,18,27] rootPS < 2^1333 := by decide +kernel

def env14888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29963,25028,10281,1025,8540,17864,169,21913,21899,8328,64,23808,16536,17665,32040,20564,33,257,21792,5593,648]

theorem envBound14888 : H12AffineFastState.Bounded env14888 := by
  intro p hp
  have h : env14888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14887_14888 : H12AffineEnvironment.transform 14 8541 env14887 = env14888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env14887 == env14888) = true)

theorem identity14888 : scanCanonicalize (H12AffineFastState.compose env14888 (packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14888 : packedSelected [0,1,2,3,5,6,7,8,12,16] rootPS < 2^1333 := by decide +kernel

def env14889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,0,21590,16537,2420,1025,1,17864,169,21913,21899,469,64,23808,16536,17665,23669,20564,33,257,21792,5593,648]

theorem envBound14889 : H12AffineFastState.Bounded env14889 := by
  intro p hp
  have h : env14889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14888_14889 : H12AffineEnvironment.transform 12 349 env14888 = env14889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14888 == env14889) = true)

theorem identity14889 : scanCanonicalize (H12AffineFastState.compose env14889 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound14889 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env14890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5457,0,263,5576,2420,1025,1,4249,169,200,218,469,64,2129,5577,4176,2340,1285,33,257,113,5593,648]

theorem envBound14890 : H12AffineFastState.Bounded env14890 := by
  intro p hp
  have h : env14890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14889_14890 : H12AffineEnvironment.transform 13 5457 env14889 = env14890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env14889 == env14890) = true)

def env14891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169216,98781,8328,64,64604,163841,17665,283905,168141,412109,257,21792,46212,243482]

theorem envBound14891 : H12AffineFastState.Bounded env14891 := by
  intro p hp
  have h : env14891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14871_14891 : H12AffineEnvironment.transform 21 272513 env14871 = env14891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env14871 == env14891) = true)

theorem identity14891 : scanCanonicalize (H12AffineFastState.compose env14891 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound14891 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1025,29908,160132,272513,156117,95496,8328,64,2185,160980,17665,283905,156696,412109,257,21792,16465,213967]

theorem envBound14892 : H12AffineFastState.Bounded env14892 := by
  intro p hp
  have h : env14892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14891_14892 : H12AffineEnvironment.transform 14 29909 env14891 = env14892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env14891 == env14892) = true)

def env14893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160012,272393,155997,95496,8192,64,2049,160860,17665,283905,156696,411973,257,21792,16465,213831]

theorem envBound14893 : H12AffineFastState.Bounded env14893 := by
  intro p hp
  have h : env14893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14892_14893 : H12AffineEnvironment.transform 6 8 env14892 = env14893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14892 == env14893) = true)

theorem identity14893 : scanCanonicalize (H12AffineFastState.compose env14893 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 97406) := by decide +kernel

theorem selectedBound14893 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env14894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,97406,1025,29788,160012,87159,155997,95496,8192,64,2049,160860,17665,76159,156696,210235,257,21792,16465,213831]

theorem envBound14894 : H12AffineFastState.Bounded env14894 := by
  intro p hp
  have h : env14894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14893_14894 : H12AffineEnvironment.transform 17 97406 env14893 = env14894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97406 env14893 == env14894) = true)

theorem identity14894 : scanCanonicalize (H12AffineFastState.compose env14894 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound14894 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env14895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,131072,89379,1025,21761,151633,87159,147456,87125,349,64,2049,152833,17665,67618,148805,201830,257,21792,16465,213831]

theorem envBound14895 : H12AffineFastState.Bounded env14895 := by
  intro p hp
  have h : env14895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14894_14895 : H12AffineEnvironment.transform 12 349 env14894 = env14895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env14894 == env14895) = true)

theorem identity14895 : scanCanonicalize (H12AffineFastState.compose env14895 (packedSelected [1,7,8,12,14,15,16,19,27] rootPS)) = affineNative (2^(16+1) ^^^ 82019) := by decide +kernel

theorem selectedBound14895 : packedSelected [1,7,8,12,14,15,16,19,27] rootPS < 2^1333 := by decide +kernel

def env14896 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,65536,82019,89379,1025,21761,69682,87159,65635,87125,349,64,2049,71010,17665,67618,66854,21509,257,21792,16465,804]

theorem envBound14896 : H12AffineFastState.Bounded env14896 := by
  intro p hp
  have h : env14896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14895_14896 : H12AffineEnvironment.transform 16 82019 env14895 = env14896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82019 env14895 == env14896) = true)

theorem identity14896 : scanCanonicalize (H12AffineFastState.compose env14896 (packedSelected [3,5,10,12,15,16,17,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound14896 : packedSelected [3,5,10,12,15,16,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env14897 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,373,65536,70678,67926,1025,372,69682,65538,65635,65568,349,64,2049,71010,4468,67618,66854,112,257,341,5156,804]

theorem envBound14897 : H12AffineFastState.Bounded env14897 := by
  intro p hp
  have h : env14897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14896_14897 : H12AffineEnvironment.transform 13 5237 env14896 = env14897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env14896 == env14897) = true)

theorem identity14897 : scanCanonicalize (H12AffineFastState.compose env14897 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14897 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env14898 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,121,5237,81,65536,70678,67698,1025,80,69682,65538,65635,65568,121,64,2049,70726,4176,67618,66562,112,37,113,5156,512]

theorem envBound14898 : H12AffineFastState.Bounded env14898 := by
  intro p hp
  have h : env14898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14897_14898 : H12AffineEnvironment.transform 7 36 env14897 = env14898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14897 == env14898) = true)

theorem identity14898 : scanCanonicalize (H12AffineFastState.compose env14898 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14898 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14899 : List Nat := [2,4,8,16,1,64,8,5,512,1024,2048,4096,88,5204,81,65536,70678,67667,1025,80,69651,65538,65602,65537,88,64,2049,70726,4176,67587,66562,81,4,80,5125,512]

theorem envBound14899 : H12AffineFastState.Bounded env14899 := by
  intro p hp
  have h : env14899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14898_14899 : H12AffineEnvironment.transform 4 1 env14898 = env14899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14898 == env14899) = true)

theorem identity14899 : scanCanonicalize (H12AffineFastState.compose env14899 (packedSelected [3,5,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14899 : packedSelected [3,5,10,11,12] rootPS < 2^1333 := by decide +kernel

def env14900 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,5125,0,65536,70678,67586,1025,1,69651,65538,65555,65537,9,17,2049,70679,4097,67587,66562,0,4,1,5125,512]

theorem envBound14900 : H12AffineFastState.Bounded env14900 := by
  intro p hp
  have h : env14900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14899_14900 : H12AffineEnvironment.transform 5 17 env14899 = env14900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14899 == env14900) = true)

theorem identity14900 : scanCanonicalize (H12AffineFastState.compose env14900 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(15+1) ^^^ 2) := by decide +kernel

theorem selectedBound14900 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env14901 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,5125,0,2,5140,2048,1025,1,4113,0,17,3,9,17,2049,5141,4097,2049,1024,0,4,1,5125,512]

theorem envBound14901 : H12AffineFastState.Bounded env14901 := by
  intro p hp
  have h : env14901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14900_14901 : H12AffineEnvironment.transform 15 2 env14900 = env14901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2 env14900 == env14901) = true)

theorem identity14901 : scanCanonicalize (H12AffineFastState.compose env14901 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound14901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14902 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1028,9,1,0,2,16,2048,1025,1,1045,0,17,3,9,17,2049,17,1029,2049,1024,0,4,1,1,512]

theorem envBound14902 : H12AffineFastState.Bounded env14902 := by
  intro p hp
  have h : env14902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14901_14902 : H12AffineEnvironment.transform 11 1028 env14901 = env14902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env14901 == env14902) = true)

theorem identity14902 : scanCanonicalize (H12AffineFastState.compose env14902 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound14902 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14903 : List Nat := [2,4,8,16,1,17,8,5,16,1024,2048,1028,9,1,0,2,16,2048,1025,1,1045,0,17,3,9,17,2049,17,1029,2049,1024,0,4,1,1,16]

theorem envBound14903 : H12AffineFastState.Bounded env14903 := by
  intro p hp
  have h : env14903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14902_14903 : H12AffineEnvironment.transform 8 16 env14902 = env14903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env14902 == env14903) = true)

theorem identity14903 : scanCanonicalize (H12AffineFastState.compose env14903 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound14903 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14904 : List Nat := [2,4,8,16,1,17,8,5,16,20,2048,16,9,1,0,2,16,2048,21,1,1,0,17,3,9,17,2049,17,17,2049,20,0,4,1,1,16]

theorem envBound14904 : H12AffineFastState.Bounded env14904 := by
  intro p hp
  have h : env14904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14903_14904 : H12AffineEnvironment.transform 9 20 env14903 = env14904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env14903 == env14904) = true)

theorem identity14904 : scanCanonicalize (H12AffineFastState.compose env14904 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14904 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14905 : List Nat := [2,4,8,4,1,5,8,5,4,0,2048,4,9,1,0,2,4,2048,1,1,1,0,5,3,9,5,2049,5,5,2049,0,0,4,1,1,4]

theorem envBound14905 : H12AffineFastState.Bounded env14905 := by
  intro p hp
  have h : env14905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14904_14905 : H12AffineEnvironment.transform 3 4 env14904 = env14905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14904 == env14905) = true)

theorem identity14905 : scanCanonicalize (H12AffineFastState.compose env14905 (packedSelected [4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound14905 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env14906 : List Nat := [2,1,8,1,1,0,8,0,1,0,2048,1,9,1,0,2,1,2048,1,1,1,0,0,3,9,0,2049,0,0,2049,0,0,1,1,1,1]

theorem envBound14906 : H12AffineFastState.Bounded env14906 := by
  intro p hp
  have h : env14906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14905_14906 : H12AffineEnvironment.transform 1 1 env14905 = env14906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env14905 == env14906) = true)

theorem identity14906 : scanCanonicalize (H12AffineFastState.compose env14906 (packedSelected [5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound14906 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14907 : List Nat := [2,1,8,1,1,0,8,0,1,0,0,1,9,1,0,2,1,0,1,1,1,0,0,3,9,0,1,0,0,1,0,0,1,1,1,1]

theorem envBound14907 : H12AffineFastState.Bounded env14907 := by
  intro p hp
  have h : env14907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14906_14907 : H12AffineEnvironment.transform 10 0 env14906 = env14907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14906 == env14907) = true)

def env14908 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160013,272392,155996,95496,8193,64,2048,160861,17665,283905,156696,411972,257,21792,16465,213830]

theorem envBound14908 : H12AffineFastState.Bounded env14908 := by
  intro p hp
  have h : env14908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14892_14908 : H12AffineEnvironment.transform 6 9 env14892 = env14908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14892 == env14908) = true)

theorem identity14908 : scanCanonicalize (H12AffineFastState.compose env14908 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound14908 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env14909 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,131072,10280,1025,29789,160013,32,155996,95496,8193,64,2048,160861,17665,32041,156696,156012,257,21792,16465,213830]

theorem envBound14909 : H12AffineFastState.Bounded env14909 := by
  intro p hp
  have h : env14909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14908_14909 : H12AffineEnvironment.transform 17 10280 env14908 = env14909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env14908 == env14909) = true)

theorem identity14909 : scanCanonicalize (H12AffineFastState.compose env14909 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14909 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14910 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,10280,1025,29789,160013,32,155996,21763,8193,64,2048,160861,17665,32041,156696,156012,257,21792,16465,156493]

theorem envBound14910 : H12AffineFastState.Bounded env14910 := by
  intro p hp
  have h : env14910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14909_14910 : H12AffineEnvironment.transform 15 8203 env14909 = env14910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14909 == env14910) = true)

theorem identity14910 : scanCanonicalize (H12AffineFastState.compose env14910 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 25693) := by decide +kernel

theorem selectedBound14910 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env14911 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,25693,10280,1025,29789,5456,32,1281,21763,8193,64,2048,4096,17665,32041,69,1329,257,21792,16465,1808]

theorem envBound14911 : H12AffineFastState.Bounded env14911 := by
  intro p hp
  have h : env14911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14910_14911 : H12AffineEnvironment.transform 16 25693 env14910 = env14911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25693 env14910 == env14911) = true)

theorem identity14911 : scanCanonicalize (H12AffineFastState.compose env14911 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound14911 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env14912 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8233,8203,12328,10280,1025,8232,5456,32,1281,374,8193,64,2048,4096,4468,10588,69,1329,257,341,5156,1808]

theorem envBound14912 : H12AffineFastState.Bounded env14912 := by
  intro p hp
  have h : env14912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14911_14912 : H12AffineEnvironment.transform 13 5237 env14911 = env14912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env14911 == env14912) = true)

theorem identity14912 : scanCanonicalize (H12AffineFastState.compose env14912 (packedSelected [1,4,8,9,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound14912 : packedSelected [1,4,8,9,14,16,19] rootPS < 2^1333 := by decide +kernel

def env14913 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5237,1124,1094,5221,3173,1025,1125,5456,32,1281,374,1100,64,2048,4096,4468,3345,69,1329,257,341,5156,1808]

theorem envBound14913 : H12AffineFastState.Bounded env14913 := by
  intro p hp
  have h : env14913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14912_14913 : H12AffineEnvironment.transform 12 1101 env14912 = env14913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env14912 == env14913) = true)

theorem identity14913 : scanCanonicalize (H12AffineFastState.compose env14913 (packedSelected [2,6,12,14,15] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound14913 : packedSelected [2,6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env14914 : List Nat := [2,4,8,16,32,64,9,100,512,1024,2048,4096,1101,5237,1124,1094,5221,3173,1025,1125,5172,32,1125,18,1100,64,2048,4096,4112,3189,69,1109,101,49,5156,1652]

theorem envBound14914 : H12AffineFastState.Bounded env14914 := by
  intro p hp
  have h : env14914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14913_14914 : H12AffineEnvironment.transform 7 100 env14913 = env14914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env14913 == env14914) = true)

theorem identity14914 : scanCanonicalize (H12AffineFastState.compose env14914 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14914 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env14915 : List Nat := [2,4,8,16,1,64,9,69,512,1024,2048,4096,1101,5204,1093,1094,5188,3140,1025,1092,5141,1,1092,18,1100,64,2048,4096,4112,3156,69,1109,68,16,5125,1621]

theorem envBound14915 : H12AffineFastState.Bounded env14915 := by
  intro p hp
  have h : env14915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14914_14915 : H12AffineEnvironment.transform 4 1 env14914 = env14915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14914 == env14915) = true)

theorem identity14915 : scanCanonicalize (H12AffineFastState.compose env14915 (packedSelected [6,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound14915 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env14916 : List Nat := [2,4,8,16,1,64,9,69,512,69,2048,4096,8,4113,0,3,4097,2049,68,1,4176,1,1,18,9,64,2048,4096,4112,2065,69,16,68,16,4160,528]

theorem envBound14916 : H12AffineFastState.Bounded env14916 := by
  intro p hp
  have h : env14916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14915_14916 : H12AffineEnvironment.transform 9 69 env14915 = env14916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env14915 == env14916) = true)

theorem identity14916 : scanCanonicalize (H12AffineFastState.compose env14916 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14916 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env14917 : List Nat := [2,4,8,16,1,16,9,21,512,21,2048,4096,8,4113,0,3,4097,2049,20,1,4096,1,1,18,9,16,2048,4096,4112,2065,21,16,20,16,4112,528]

theorem envBound14917 : H12AffineFastState.Bounded env14917 := by
  intro p hp
  have h : env14917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14916_14917 : H12AffineEnvironment.transform 5 16 env14916 = env14917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14916 == env14917) = true)

theorem identity14917 : scanCanonicalize (H12AffineFastState.compose env14917 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound14917 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env14918 : List Nat := [2,4,8,16,1,16,9,21,512,21,2048,512,8,529,0,3,513,2049,20,1,512,1,1,18,9,16,2048,512,528,2065,21,16,20,16,528,528]

theorem envBound14918 : H12AffineFastState.Bounded env14918 := by
  intro p hp
  have h : env14918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14917_14918 : H12AffineEnvironment.transform 11 512 env14917 = env14918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env14917 == env14918) = true)

theorem identity14918 : scanCanonicalize (H12AffineFastState.compose env14918 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound14918 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env14919 : List Nat := [2,4,8,16,1,16,9,21,17,21,2048,17,8,0,0,3,16,2049,20,1,17,1,1,18,9,16,2048,17,1,2065,21,16,20,16,1,1]

theorem envBound14919 : H12AffineFastState.Bounded env14919 := by
  intro p hp
  have h : env14919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14918_14919 : H12AffineEnvironment.transform 8 17 env14918 = env14919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env14918 == env14919) = true)

theorem identity14919 : scanCanonicalize (H12AffineFastState.compose env14919 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound14919 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14920 : List Nat := [2,4,8,16,1,16,9,21,17,21,1,17,8,0,0,3,16,0,20,1,17,1,1,18,9,16,1,17,1,16,21,16,20,16,1,1]

theorem envBound14920 : H12AffineFastState.Bounded env14920 := by
  intro p hp
  have h : env14920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14919_14920 : H12AffineEnvironment.transform 10 1 env14919 = env14920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env14919 == env14920) = true)

def env14921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,4194304,169217,98780,8328,64,4510941,163840,17664,283904,168141,4350285,257,21792,46212,243482]

theorem envBound14921 : H12AffineFastState.Bounded env14921 := by
  intro p hp
  have h : env14921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14870_14921 : H12AffineEnvironment.transform 22 169217 env14870 = env14921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env14870 == env14921) = true)

def env14922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272512,169217,98780,8328,64,64605,163840,17664,283904,168141,412109,257,21792,46212,243482]

theorem envBound14922 : H12AffineFastState.Bounded env14922 := by
  intro p hp
  have h : env14922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14921_14922 : H12AffineEnvironment.transform 21 272512 env14921 = env14922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env14921 == env14922) = true)

theorem identity14922 : scanCanonicalize (H12AffineFastState.compose env14922 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound14922 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4161,272512,17,98780,8328,64,64605,5392,17664,283904,1501,318685,257,21792,46212,74250]

theorem envBound14923 : H12AffineFastState.Bounded env14923 := by
  intro p hp
  have h : env14923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14922_14923 : H12AffineEnvironment.transform 16 38160 env14922 = env14923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env14922 == env14923) = true)

theorem identity14923 : scanCanonicalize (H12AffineFastState.compose env14923 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound14923 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env14924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4161,272512,17,41431,8328,64,64605,5392,17664,283904,1501,318685,257,21792,46212,513]

theorem envBound14924 : H12AffineFastState.Bounded env14924 := by
  intro p hp
  have h : env14924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14923_14924 : H12AffineEnvironment.transform 15 8203 env14923 = env14924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env14923 == env14924) = true)

def env14925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272513,169217,98780,8328,64,64604,163840,17664,283904,168141,412108,257,21792,46212,243482]

theorem envBound14925 : H12AffineFastState.Bounded env14925 := by
  intro p hp
  have h : env14925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14921_14925 : H12AffineEnvironment.transform 21 272513 env14921 = env14925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env14921 == env14925) = true)

def env14926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272393,169217,98644,8192,64,64604,163840,17664,283904,168005,411972,257,21792,46092,243482]

theorem envBound14926 : H12AffineFastState.Bounded env14926 := by
  intro p hp
  have h : env14926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14925_14926 : H12AffineEnvironment.transform 6 8 env14925 = env14926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env14925 == env14926) = true)

theorem identity14926 : scanCanonicalize (H12AffineFastState.compose env14926 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound14926 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env14927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,50496,272393,54544,98644,8192,64,64604,49169,17664,283904,53332,264533,257,21792,46092,128779]

theorem envBound14927 : H12AffineFastState.Bounded env14927 := by
  intro p hp
  have h : env14927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14926_14927 : H12AffineEnvironment.transform 16 16401 env14926 = env14927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env14926 == env14927) = true)

def env14928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,16401,262144,1025,21761,4160,272393,16,87124,8192,64,10588,5393,17664,283904,1364,264533,257,21792,24844,74251]

theorem envBound14928 : H12AffineFastState.Bounded env14928 := by
  intro p hp
  have h : env14928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14927_14928 : H12AffineEnvironment.transform 14 21760 env14927 = env14928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env14927 == env14928) = true)

theorem identity14928 : scanCanonicalize (H12AffineFastState.compose env14928 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound14928 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21590,16401,262144,1025,21761,4160,272393,16,2,8192,64,10588,5393,17664,283904,1364,264533,257,21792,24844,30301]

theorem envBound14929 : H12AffineFastState.Bounded env14929 := by
  intro p hp
  have h : env14929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14928_14929 : H12AffineEnvironment.transform 15 21590 env14928 = env14929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env14928 == env14929) = true)

theorem identity14929 : scanCanonicalize (H12AffineFastState.compose env14929 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound14929 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env14930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,21590,16401,2421,1025,21761,4160,8572,16,2,8192,64,10588,5393,17664,23669,1364,32,257,21792,24844,30301]

theorem envBound14930 : H12AffineFastState.Bounded env14930 := by
  intro p hp
  have h : env14930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14929_14930 : H12AffineEnvironment.transform 17 2421 env14929 = env14930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env14929 == env14930) = true)

theorem identity14930 : scanCanonicalize (H12AffineFastState.compose env14930 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound14930 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env14931 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,16384,21540,21590,16401,2129,1025,21541,4160,8280,16,2,8192,64,10360,5173,17444,23669,1136,32,37,21508,24616,30301]

theorem envBound14931 : H12AffineFastState.Bounded env14931 := by
  intro p hp
  have h : env14931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14930_14931 : H12AffineEnvironment.transform 7 36 env14930 = env14931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env14930 == env14931) = true)

theorem identity14931 : scanCanonicalize (H12AffineFastState.compose env14931 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound14931 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env14932 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13405,8313,8203,13388,2129,1025,8312,4160,8280,16,2,8192,64,10360,5173,12409,10280,1136,32,37,8281,5237,512]

theorem envBound14932 : H12AffineFastState.Bounded env14932 := by
  intro p hp
  have h : env14932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14931_14932 : H12AffineEnvironment.transform 13 13405 env14931 = env14932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env14931 == env14932) = true)

theorem identity14932 : scanCanonicalize (H12AffineFastState.compose env14932 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound14932 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14933 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8,5205,113,3,5188,2129,1025,112,4160,80,16,2,8,64,2160,5173,4209,2080,1136,32,37,81,5237,512]

theorem envBound14933 : H12AffineFastState.Bounded env14933 := by
  intro p hp
  have h : env14933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14932_14933 : H12AffineEnvironment.transform 12 8 env14932 = env14933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env14932 == env14933) = true)

theorem identity14933 : scanCanonicalize (H12AffineFastState.compose env14933 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1605) := by decide +kernel

theorem selectedBound14933 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env14934 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1605,8,528,113,3,513,2129,1025,112,1541,80,16,2,8,64,2160,624,1588,2080,1136,32,37,81,560,512]

theorem envBound14934 : H12AffineFastState.Bounded env14934 := by
  intro p hp
  have h : env14934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14933_14934 : H12AffineEnvironment.transform 11 1605 env14933 = env14934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1605 env14933 == env14934) = true)

theorem identity14934 : scanCanonicalize (H12AffineFastState.compose env14934 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound14934 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env14935 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,1556,8,528,32,3,513,2048,1025,33,1541,1,16,2,8,17,2081,545,1588,2080,1057,32,37,0,560,512]

theorem envBound14935 : H12AffineFastState.Bounded env14935 := by
  intro p hp
  have h : env14935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14934_14935 : H12AffineEnvironment.transform 5 17 env14934 = env14935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env14934 == env14935) = true)

theorem identity14935 : scanCanonicalize (H12AffineFastState.compose env14935 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14935 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env14936 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1556,8,528,1,3,513,2048,1025,0,1541,1,16,2,8,17,2048,512,1557,2049,1024,1,4,0,529,512]

theorem envBound14936 : H12AffineFastState.Bounded env14936 := by
  intro p hp
  have h : env14936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14935_14936 : H12AffineEnvironment.transform 4 1 env14935 = env14936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14935 == env14936) = true)

theorem identity14936 : scanCanonicalize (H12AffineFastState.compose env14936 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14936 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14937 : List Nat := [2,4,8,1,1,0,8,5,512,1024,2048,1541,8,513,1,3,513,2048,1025,0,1541,1,1,2,8,0,2048,512,1540,2049,1024,1,4,0,512,512]

theorem envBound14937 : H12AffineFastState.Bounded env14937 := by
  intro p hp
  have h : env14937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14936_14937 : H12AffineEnvironment.transform 3 1 env14936 = env14937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14936 == env14937) = true)

theorem identity14937 : scanCanonicalize (H12AffineFastState.compose env14937 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound14937 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env14938 : List Nat := [2,4,8,1,1,0,8,5,512,4,2048,513,8,513,1,3,513,2048,5,0,513,1,1,2,8,0,2048,512,512,2049,4,1,4,0,512,512]

theorem envBound14938 : H12AffineFastState.Bounded env14938 := by
  intro p hp
  have h : env14938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14937_14938 : H12AffineEnvironment.transform 9 4 env14937 = env14938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env14937 == env14938) = true)

theorem identity14938 : scanCanonicalize (H12AffineFastState.compose env14938 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14938 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14939 : List Nat := [2,4,8,1,1,0,8,5,1,4,2048,0,8,0,1,3,0,2048,5,0,0,1,1,2,8,0,2048,1,1,2049,4,1,4,0,1,1]

theorem envBound14939 : H12AffineFastState.Bounded env14939 := by
  intro p hp
  have h : env14939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14938_14939 : H12AffineEnvironment.transform 8 1 env14938 = env14939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14938 == env14939) = true)

theorem identity14939 : scanCanonicalize (H12AffineFastState.compose env14939 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound14939 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14940 : List Nat := [2,4,6,1,1,0,6,5,1,4,2048,0,6,0,1,3,0,2048,5,0,0,1,1,2,6,0,2048,1,1,2049,4,1,4,0,1,1]

theorem envBound14940 : H12AffineFastState.Bounded env14940 := by
  intro p hp
  have h : env14940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14939_14940 : H12AffineEnvironment.transform 2 6 env14939 = env14940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env14939 == env14940) = true)

theorem identity14940 : scanCanonicalize (H12AffineFastState.compose env14940 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound14940 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env14941 : List Nat := [2,4,6,1,1,0,6,5,1,4,0,0,6,0,1,3,0,0,5,0,0,1,1,2,6,0,0,1,1,1,4,1,4,0,1,1]

theorem envBound14941 : H12AffineFastState.Bounded env14941 := by
  intro p hp
  have h : env14941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14940_14941 : H12AffineEnvironment.transform 10 0 env14940 = env14941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14940 == env14941) = true)

def env14942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,262144,1025,21760,4161,272393,17,87125,8192,64,10589,5392,17664,283904,1365,264533,257,21792,24845,74250]

theorem envBound14942 : H12AffineFastState.Bounded env14942 := by
  intro p hp
  have h : env14942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14927_14942 : H12AffineEnvironment.transform 14 21761 env14927 = env14942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env14927 == env14942) = true)

theorem identity14942 : scanCanonicalize (H12AffineFastState.compose env14942 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97406) := by decide +kernel

theorem selectedBound14942 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env14943 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,65536,16401,97406,1025,21760,4161,87159,17,87125,8192,64,10589,5392,17664,76158,1365,95531,257,21792,24845,74250]

theorem envBound14943 : H12AffineFastState.Bounded env14943 := by
  intro p hp
  have h : env14943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14942_14943 : H12AffineEnvironment.transform 17 97406 env14942 = env14943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97406 env14942 == env14943) = true)

theorem identity14943 : scanCanonicalize (H12AffineFastState.compose env14943 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14943 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env14944 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21761,8202,16401,23668,1025,21760,4161,29821,17,29791,8192,64,10589,5392,17664,2420,1365,21793,257,21792,24845,512]

theorem envBound14944 : H12AffineFastState.Bounded env14944 := by
  intro p hp
  have h : env14944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14943_14944 : H12AffineEnvironment.transform 15 8202 env14943 = env14944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14943 == env14944) = true)

theorem identity14944 : scanCanonicalize (H12AffineFastState.compose env14944 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound14944 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env14945 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,121,16384,21761,115,16401,23668,1025,21760,4161,21508,17,21542,121,64,2340,5392,17664,2420,1365,21793,257,21792,16756,512]

theorem envBound14945 : H12AffineFastState.Bounded env14945 := by
  intro p hp
  have h : env14945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14944_14945 : H12AffineEnvironment.transform 12 121 env14944 = env14945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env14944 == env14945) = true)

theorem identity14945 : scanCanonicalize (H12AffineFastState.compose env14945 (packedSelected [0,2,4,5,6,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound14945 : packedSelected [0,2,4,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env14946 : List Nat := [2,4,8,16,32,64,8,256,512,1024,555,4096,121,16384,21761,115,16401,22111,1025,21760,4161,21508,17,21542,121,64,783,5392,17664,863,1365,21793,257,21792,16756,512]

theorem envBound14946 : H12AffineFastState.Bounded env14946 := by
  intro p hp
  have h : env14946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14945_14946 : H12AffineEnvironment.transform 10 555 env14945 = env14946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env14945 == env14946) = true)

theorem identity14946 : scanCanonicalize (H12AffineFastState.compose env14946 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound14946 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env14947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,555,4096,121,5236,373,115,5221,555,1025,372,4161,112,17,82,121,64,783,5392,4468,863,1365,341,257,340,5376,512]

theorem envBound14947 : H12AffineFastState.Bounded env14947 := by
  intro p hp
  have h : env14947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14946_14947 : H12AffineEnvironment.transform 13 5236 env14946 = env14947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env14946 == env14947) = true)

theorem identity14947 : scanCanonicalize (H12AffineFastState.compose env14947 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound14947 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env14948 : List Nat := [2,4,8,16,32,64,8,116,512,1024,555,4096,121,5236,1,115,5221,555,1025,0,4161,112,17,82,121,64,635,5220,4096,555,1057,33,117,32,5236,512]

theorem envBound14948 : H12AffineFastState.Bounded env14948 := by
  intro p hp
  have h : env14948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14947_14948 : H12AffineEnvironment.transform 7 116 env14947 = env14948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env14947 == env14948) = true)

theorem identity14948 : scanCanonicalize (H12AffineFastState.compose env14948 (packedSelected [0,2,4] rootPS)) = affineNative (2^(11+1) ^^^ 586) := by decide +kernel

theorem selectedBound14948 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14949 : List Nat := [2,4,8,16,32,64,8,116,512,1024,555,586,121,1598,1,115,1583,555,1025,0,523,112,17,82,121,64,635,1582,586,555,1057,33,117,32,1598,512]

theorem envBound14949 : H12AffineFastState.Bounded env14949 := by
  intro p hp
  have h : env14949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14948_14949 : H12AffineEnvironment.transform 11 586 env14948 = env14949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 586 env14948 == env14949) = true)

theorem identity14949 : scanCanonicalize (H12AffineFastState.compose env14949 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound14949 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env14950 : List Nat := [2,4,8,16,32,49,8,5,512,1024,555,571,8,1598,1,2,1583,555,1025,0,523,1,17,35,8,49,522,1582,571,555,1057,33,4,32,1598,512]

theorem envBound14950 : H12AffineFastState.Bounded env14950 := by
  intro p hp
  have h : env14950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14949_14950 : H12AffineEnvironment.transform 5 49 env14949 = env14950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env14949 == env14950) = true)

theorem identity14950 : scanCanonicalize (H12AffineFastState.compose env14950 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 541) := by decide +kernel

theorem selectedBound14950 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env14951 : List Nat := [2,4,8,16,32,49,8,5,512,541,555,571,8,35,1,2,50,555,540,0,523,1,17,35,8,49,522,51,571,555,572,33,4,32,35,512]

theorem envBound14951 : H12AffineFastState.Bounded env14951 := by
  intro p hp
  have h : env14951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14950_14951 : H12AffineEnvironment.transform 9 541 env14950 = env14951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 541 env14950 == env14951) = true)

theorem identity14951 : scanCanonicalize (H12AffineFastState.compose env14951 (packedSelected [0,2,8] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound14951 : packedSelected [0,2,8] rootPS < 2^1333 := by decide +kernel

def env14952 : List Nat := [2,4,8,16,32,49,8,5,8,21,35,51,8,35,1,2,50,35,20,0,3,1,17,35,8,49,2,51,51,35,52,33,4,32,35,8]

theorem envBound14952 : H12AffineFastState.Bounded env14952 := by
  intro p hp
  have h : env14952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14951_14952 : H12AffineEnvironment.transform 8 8 env14951 = env14952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env14951 == env14952) = true)

theorem identity14952 : scanCanonicalize (H12AffineFastState.compose env14952 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound14952 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14953 : List Nat := [2,4,8,16,1,16,8,5,8,21,2,18,8,2,1,2,19,2,20,0,3,1,17,2,8,16,2,18,18,2,21,0,4,1,2,8]

theorem envBound14953 : H12AffineFastState.Bounded env14953 := by
  intro p hp
  have h : env14953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14952_14953 : H12AffineEnvironment.transform 4 1 env14952 = env14953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env14952 == env14953) = true)

theorem identity14953 : scanCanonicalize (H12AffineFastState.compose env14953 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound14953 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14954 : List Nat := [2,4,8,4,1,4,8,5,8,1,2,6,8,2,1,2,7,2,0,0,3,1,5,2,8,4,2,6,6,2,1,0,4,1,2,8]

theorem envBound14954 : H12AffineFastState.Bounded env14954 := by
  intro p hp
  have h : env14954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14953_14954 : H12AffineEnvironment.transform 3 4 env14953 = env14954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env14953 == env14954) = true)

def env14955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,272392,169217,98645,8193,64,64604,163840,17664,283904,168004,411973,257,21792,46093,243482]

theorem envBound14955 : H12AffineFastState.Bounded env14955 := by
  intro p hp
  have h : env14955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14925_14955 : H12AffineEnvironment.transform 6 9 env14925 = env14955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env14925 == env14955) = true)

theorem identity14955 : scanCanonicalize (H12AffineFastState.compose env14955 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound14955 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env14956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,77898,272392,73754,98645,8193,64,64604,79131,17664,283904,75103,392286,257,21792,46093,513]

theorem envBound14956 : H12AffineFastState.Bounded env14956 := by
  intro p hp
  have h : env14956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14955_14956 : H12AffineEnvironment.transform 16 111899 env14955 = env14956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env14955 == env14956) = true)

theorem identity14956 : scanCanonicalize (H12AffineFastState.compose env14956 (packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound14956 : packedSelected [0,2,3,4,6,9,10,11,17,20,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env14957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,4160,272392,16,41311,8193,64,64604,5393,17664,283904,1365,318548,257,21792,46093,513]

theorem envBound14957 : H12AffineFastState.Bounded env14957 := by
  intro p hp
  have h : env14957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14956_14957 : H12AffineEnvironment.transform 15 8202 env14956 = env14957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env14956 == env14957) = true)

theorem identity14957 : scanCanonicalize (H12AffineFastState.compose env14957 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound14957 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env14958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8202,16401,262144,1025,21761,4160,272392,16,29791,8193,64,10588,5393,17664,283904,1365,264532,257,21792,24845,513]

theorem envBound14958 : H12AffineFastState.Bounded env14958 := by
  intro p hp
  have h : env14958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14957_14958 : H12AffineEnvironment.transform 14 21760 env14957 = env14958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env14957 == env14958) = true)

theorem identity14958 : scanCanonicalize (H12AffineFastState.compose env14958 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound14958 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env14959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8202,13388,262144,1025,8540,4160,272392,16,2,8193,64,10588,5393,12637,270685,1365,264532,257,8573,5456,513]

theorem envBound14959 : H12AffineFastState.Bounded env14959 := by
  intro p hp
  have h : env14959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14958_14959 : H12AffineEnvironment.transform 13 13405 env14958 = env14959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env14958 == env14959) = true)

theorem identity14959 : scanCanonicalize (H12AffineFastState.compose env14959 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 10508) := by decide +kernel

theorem selectedBound14959 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env14960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8541,8202,13388,10508,1025,8540,4160,260,16,2,8193,64,10588,5393,12637,2129,1365,8280,257,8573,5456,513]

theorem envBound14960 : H12AffineFastState.Bounded env14960 := by
  intro p hp
  have h : env14960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14959_14960 : H12AffineEnvironment.transform 17 10508 env14959 = env14960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10508 env14959 == env14960) = true)

theorem identity14960 : scanCanonicalize (H12AffineFastState.compose env14960 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound14960 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env14961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1100,4113,1297,1094,4096,3392,1025,1296,4160,260,16,2,1101,64,3344,5393,5393,2129,1365,1044,257,1329,5456,513]

theorem envBound14961 : H12AffineFastState.Bounded env14961 := by
  intro p hp
  have h : env14961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14960_14961 : H12AffineEnvironment.transform 12 1100 env14960 = env14961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env14960 == env14961) = true)

theorem identity14961 : scanCanonicalize (H12AffineFastState.compose env14961 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 356) := by decide +kernel

theorem selectedBound14961 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env14962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,356,1100,373,1297,1094,356,3392,1025,1296,292,260,16,2,1101,64,3344,1141,1141,2129,1365,1044,257,1329,1076,513]

theorem envBound14962 : H12AffineFastState.Bounded env14962 := by
  intro p hp
  have h : env14962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14961_14962 : H12AffineEnvironment.transform 11 356 env14961 = env14962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 356 env14961 == env14962) = true)

theorem identity14962 : scanCanonicalize (H12AffineFastState.compose env14962 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound14962 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env14963 : List Nat := [2,4,8,16,32,64,9,256,512,1024,80,356,1100,373,1297,1094,356,1296,1025,1296,292,260,16,2,1101,64,1344,1141,1141,1,1365,1044,257,1329,1076,513]

theorem envBound14963 : H12AffineFastState.Bounded env14963 := by
  intro p hp
  have h : env14963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14962_14963 : H12AffineEnvironment.transform 10 80 env14962 = env14963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env14962 == env14963) = true)

theorem identity14963 : scanCanonicalize (H12AffineFastState.compose env14963 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound14963 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env14964 : List Nat := [2,4,8,16,32,64,9,256,512,53,80,356,121,373,292,115,356,293,52,293,292,260,16,2,120,64,373,64,64,1,352,33,257,260,1,513]

theorem envBound14964 : H12AffineFastState.Bounded env14964 := by
  intro p hp
  have h : env14964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14963_14964 : H12AffineEnvironment.transform 9 53 env14963 = env14964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env14963 == env14964) = true)

theorem identity14964 : scanCanonicalize (H12AffineFastState.compose env14964 (packedSelected [1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound14964 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env14965 : List Nat := [2,4,8,16,32,64,9,37,512,53,80,65,121,80,1,115,65,0,52,0,1,33,16,2,120,64,80,64,64,1,69,33,36,33,1,513]

theorem envBound14965 : H12AffineFastState.Bounded env14965 := by
  intro p hp
  have h : env14965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14964_14965 : H12AffineEnvironment.transform 7 37 env14964 = env14965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env14964 == env14965) = true)

theorem identity14965 : scanCanonicalize (H12AffineFastState.compose env14965 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14965 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14966 : List Nat := [2,4,8,16,32,16,9,37,512,53,0,17,41,0,1,35,17,0,52,0,1,33,16,2,40,16,0,16,16,1,21,33,36,33,1,513]

theorem envBound14966 : H12AffineFastState.Bounded env14966 := by
  intro p hp
  have h : env14966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14965_14966 : H12AffineEnvironment.transform 5 16 env14965 = env14966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14965 == env14966) = true)

theorem identity14966 : scanCanonicalize (H12AffineFastState.compose env14966 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound14966 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env14967 : List Nat := [2,4,8,16,32,16,9,37,1,53,0,17,41,0,1,35,17,0,52,0,1,33,16,2,40,16,0,16,16,1,21,33,36,33,1,0]

theorem envBound14967 : H12AffineFastState.Bounded env14967 := by
  intro p hp
  have h : env14967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14966_14967 : H12AffineEnvironment.transform 8 1 env14966 = env14967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env14966 == env14967) = true)

theorem identity14967 : scanCanonicalize (H12AffineFastState.compose env14967 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound14967 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env14968 : List Nat := [2,4,2,16,32,16,3,37,1,53,0,17,35,0,1,35,17,0,52,0,1,33,16,2,34,16,0,16,16,1,21,33,36,33,1,0]

theorem envBound14968 : H12AffineFastState.Bounded env14968 := by
  intro p hp
  have h : env14968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14967_14968 : H12AffineEnvironment.transform 2 2 env14967 = env14968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env14967 == env14968) = true)

def env14969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507601,155254785,25265169,145662401,525568,140903596,27337992,25733062]

theorem envBound14969 : H12AffineFastState.Bounded env14969 := by
  intro p hp
  have h : env14969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14276_14969 : H12AffineEnvironment.transform 25 65 env14276 = env14969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env14276 == env14969) = true)

def env14970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507601,9356289,25265169,23160257,525568,27902124,27337992,25733062]

theorem envBound14970 : H12AffineFastState.Bounded env14970 := by
  intro p hp
  have h : env14970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14969_14970 : H12AffineEnvironment.transform 26 30393344 env14969 = env14970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env14969 == env14970) = true)

def env14971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830977,25265169,23160257,256,27378860,27337992,25207750]

theorem envBound14971 : H12AffineFastState.Bounded env14971 := by
  intro p hp
  have h : env14971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14970_14971 : H12AffineEnvironment.transform 18 1024 env14970 = env14971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env14970 == env14971) = true)

theorem identity14971 : scanCanonicalize (H12AffineFastState.compose env14971 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 510001) := by decide +kernel

theorem selectedBound14971 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env14972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,510001,8328,65,12585009,2510013,10507601,8830977,8801312,6729200,256,10882205,10939705,8874999]

theorem envBound14972 : H12AffineFastState.Bounded env14972 := by
  intro p hp
  have h : env14972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14971_14972 : H12AffineEnvironment.transform 23 510001 env14971 = env14972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 510001 env14971 == env14972) = true)

def env14973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513340,510001,8328,65,6705549,2510013,396525,2136509,2102684,6729200,256,21793,46213,2175563]

theorem envBound14973 : H12AffineFastState.Bounded env14973 := by
  intro p hp
  have h : env14973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14972_14973 : H12AffineEnvironment.transform 22 2513340 env14972 = env14973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513340 env14972 == env14973) = true)

def env14974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169400,2513340,510001,8328,65,2409525,2510013,396525,2136509,2102684,2373704,256,21793,46213,2175563]

theorem envBound14974 : H12AffineFastState.Bounded env14974 := by
  intro p hp
  have h : env14974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14973_14974 : H12AffineEnvironment.transform 21 169400 env14973 = env14974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env14973 == env14974) = true)

def env14975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169400,412156,510001,8328,65,316533,417021,396525,35325,1500,272392,256,21793,46213,74251]

theorem envBound14975 : H12AffineFastState.Bounded env14975 := by
  intro p hp
  have h : env14975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14974_14975 : H12AffineEnvironment.transform 20 4160 env14974 = env14975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env14974 == env14975) = true)

theorem identity14975 : scanCanonicalize (H12AffineFastState.compose env14975 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound14975 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env14976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,156012,412156,474341,8328,65,270497,417021,396525,32041,1500,272392,256,21793,16465,74251]

theorem envBound14976 : H12AffineFastState.Bounded env14976 := by
  intro p hp
  have h : env14976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14975_14976 : H12AffineEnvironment.transform 14 29908 env14975 = env14976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env14975 == env14976) = true)

def env14977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32240,1024,29909,4160,156012,144396,213269,8328,65,23889,139533,160029,32041,1500,22008,256,21793,16465,74251]

theorem envBound14977 : H12AffineFastState.Bounded env14977 := by
  intro p hp
  have h : env14977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14976_14977 : H12AffineEnvironment.transform 17 32240 env14976 = env14977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32240 env14976 == env14977) = true)

theorem identity14977 : scanCanonicalize (H12AffineFastState.compose env14977 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound14977 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env14978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79130,32240,1024,29909,4160,87158,65814,29711,8328,65,23889,70679,82951,32041,1500,22008,256,21793,16465,74251]

theorem envBound14978 : H12AffineFastState.Bounded env14978 := by
  intro p hp
  have h : env14978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14977_14978 : H12AffineEnvironment.transform 16 79130 env14977 = env14978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env14977 == env14978) = true)

theorem identity14978 : scanCanonicalize (H12AffineFastState.compose env14978 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 30162) := by decide +kernel

theorem selectedBound14978 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env14979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30162,16584,32240,1024,29909,4160,8612,29892,29711,8328,65,23889,25029,12757,32041,1500,22008,256,21793,16465,22489]

theorem envBound14979 : H12AffineFastState.Bounded env14979 := by
  intro p hp
  have h : env14979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14978_14979 : H12AffineEnvironment.transform 15 30162 env14978 = env14979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30162 env14978 == env14979) = true)

theorem identity14979 : scanCanonicalize (H12AffineFastState.compose env14979 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound14979 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env14980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5592,8460,8202,5392,10280,1024,8461,4160,8612,8476,8663,8328,65,2185,13341,12757,10481,1500,32,256,249,5513,513]

theorem envBound14980 : H12AffineFastState.Bounded env14980 := by
  intro p hp
  have h : env14980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14979_14980 : H12AffineEnvironment.transform 13 5592 env14979 = env14980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env14979 == env14980) = true)

theorem identity14980 : scanCanonicalize (H12AffineFastState.compose env14980 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound14980 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env14981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1053,5592,1297,1047,5392,3125,1024,1296,4160,1465,1281,1482,1173,65,2185,4096,5576,3308,1500,32,256,249,5513,513]

theorem envBound14981 : H12AffineFastState.Bounded env14981 := by
  intro p hp
  have h : env14981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14980_14981 : H12AffineEnvironment.transform 12 1053 env14980 = env14981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env14980 == env14981) = true)

theorem identity14981 : scanCanonicalize (H12AffineFastState.compose env14981 (packedSelected [0,7,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound14981 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env14982 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,1053,5377,1297,1047,5392,3125,1024,1296,4160,1376,1281,1299,1100,65,2128,4096,5393,3125,1285,32,256,32,5456,513]

theorem envBound14982 : H12AffineFastState.Bounded env14982 := by
  intro p hp
  have h : env14982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14981_14982 : H12AffineEnvironment.transform 6 89 env14981 = env14982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env14981 == env14982) = true)

theorem identity14982 : scanCanonicalize (H12AffineFastState.compose env14982 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2138) := by decide +kernel

theorem selectedBound14982 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env14983 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2138,1053,3419,1297,1047,3402,3125,1024,1296,2074,1376,1281,1299,1100,65,2128,2138,3403,3125,1285,32,256,32,3338,513]

theorem envBound14983 : H12AffineFastState.Bounded env14983 := by
  intro p hp
  have h : env14983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14982_14983 : H12AffineEnvironment.transform 11 2138 env14982 = env14983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2138 env14982 == env14983) = true)

theorem identity14983 : scanCanonicalize (H12AffineFastState.compose env14983 (packedSelected [0,2,3,4,5,6,7,9,11] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound14983 : packedSelected [0,2,3,4,5,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env14984 : List Nat := [2,4,8,16,32,64,89,95,512,1024,2048,2138,1053,3076,1102,1047,3093,3125,1024,1103,2074,1087,1118,1100,1100,65,2128,2138,3092,3125,1114,32,95,32,3157,513]

theorem envBound14984 : H12AffineFastState.Bounded env14984 := by
  intro p hp
  have h : env14984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14983_14984 : H12AffineEnvironment.transform 7 95 env14983 = env14984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env14983 == env14984) = true)

theorem identity14984 : scanCanonicalize (H12AffineFastState.compose env14984 (packedSelected [1,2,5,6,7,9,12] rootPS)) = affineNative (2^(10+1) ^^^ 74) := by decide +kernel

theorem selectedBound14984 : packedSelected [1,2,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env14985 : List Nat := [2,4,8,16,32,64,89,95,512,1024,74,16,1053,1102,1102,1047,1119,1151,1024,1103,80,1087,1118,1100,1100,65,26,16,1118,1151,1114,32,95,32,1055,513]

theorem envBound14985 : H12AffineFastState.Bounded env14985 := by
  intro p hp
  have h : env14985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14984_14985 : H12AffineEnvironment.transform 10 74 env14984 = env14985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 74 env14984 == env14985) = true)

theorem identity14985 : scanCanonicalize (H12AffineFastState.compose env14985 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound14985 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env14986 : List Nat := [2,4,8,16,32,64,89,95,512,4,74,16,25,74,74,19,91,123,4,75,80,59,90,72,72,65,26,16,90,123,94,32,95,32,27,513]

theorem envBound14986 : H12AffineFastState.Bounded env14986 := by
  intro p hp
  have h : env14986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14985_14986 : H12AffineEnvironment.transform 9 4 env14985 = env14986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env14985 == env14986) = true)

theorem identity14986 : scanCanonicalize (H12AffineFastState.compose env14986 (packedSelected [0,1,2,3,6,9] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound14986 : packedSelected [0,1,2,3,6,9] rootPS < 2^1333 := by decide +kernel

def env14987 : List Nat := [2,4,8,16,32,58,35,37,512,4,48,16,25,48,48,19,33,1,4,49,42,59,32,50,50,59,26,16,32,1,36,32,37,32,27,513]

theorem envBound14987 : H12AffineFastState.Bounded env14987 := by
  intro p hp
  have h : env14987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14986_14987 : H12AffineEnvironment.transform 5 58 env14986 = env14987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env14986 == env14987) = true)

theorem identity14987 : scanCanonicalize (H12AffineFastState.compose env14987 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound14987 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env14988 : List Nat := [2,4,8,16,0,26,3,5,512,4,16,16,25,16,16,19,1,1,4,17,10,27,0,18,18,27,26,16,0,1,4,0,5,0,27,513]

theorem envBound14988 : H12AffineFastState.Bounded env14988 := by
  intro p hp
  have h : env14988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14987_14988 : H12AffineEnvironment.transform 4 0 env14987 = env14988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env14987 == env14988) = true)

theorem identity14988 : scanCanonicalize (H12AffineFastState.compose env14988 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound14988 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env14989 : List Nat := [2,4,8,16,0,26,3,5,15,4,16,16,25,16,16,19,1,1,4,17,10,27,0,18,18,27,26,16,0,1,4,0,5,0,27,14]

theorem envBound14989 : H12AffineFastState.Bounded env14989 := by
  intro p hp
  have h : env14989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14988_14989 : H12AffineEnvironment.transform 8 15 env14988 = env14989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env14988 == env14989) = true)

theorem identity14989 : scanCanonicalize (H12AffineFastState.compose env14989 (packedSelected [0,1,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound14989 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env14990 : List Nat := [0,4,8,16,0,24,1,5,13,4,16,16,25,16,16,17,1,1,4,17,8,25,0,16,16,25,24,16,0,1,4,0,5,0,25,12]

theorem envBound14990 : H12AffineFastState.Bounded env14990 := by
  intro p hp
  have h : env14990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14989_14990 : H12AffineEnvironment.transform 0 0 env14989 = env14990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env14989 == env14990) = true)

theorem identity14990 : scanCanonicalize (H12AffineFastState.compose env14990 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound14990 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env14991 : List Nat := [0,4,8,1,0,9,1,5,13,4,1,1,8,1,1,0,1,1,4,0,8,8,0,1,1,8,9,1,0,1,4,0,5,0,8,12]

theorem envBound14991 : H12AffineFastState.Bounded env14991 := by
  intro p hp
  have h : env14991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14990_14991 : H12AffineEnvironment.transform 3 1 env14990 = env14991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env14990 == env14991) = true)

def env14992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32241,1024,29909,4160,156012,144397,213268,8328,65,23888,139532,160028,32041,1500,22009,256,21793,16465,74251]

theorem envBound14992 : H12AffineFastState.Bounded env14992 := by
  intro p hp
  have h : env14992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14976_14992 : H12AffineEnvironment.transform 17 32241 env14976 = env14992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32241 env14976 == env14992) = true)

theorem identity14992 : scanCanonicalize (H12AffineFastState.compose env14992 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound14992 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env14993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79250,32241,1024,29909,4160,87294,65951,29830,8328,65,23888,70814,83086,32041,1500,22009,256,21793,16465,74251]

theorem envBound14993 : H12AffineFastState.Bounded env14993 := by
  intro p hp
  have h : env14993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14992_14993 : H12AffineEnvironment.transform 16 79250 env14992 = env14993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env14992 == env14993) = true)

theorem identity14993 : scanCanonicalize (H12AffineFastState.compose env14993 (packedSelected [0,1,3,4,5,7,8,16,17,18,19,20,22,23,31] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound14993 : packedSelected [0,1,3,4,5,7,8,16,17,18,19,20,22,23,31] rootPS < 2^1333 := by decide +kernel

def env14994 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,30042,16584,32241,1024,29909,4160,8612,29893,29830,8328,65,23888,25028,12756,32041,1500,22009,256,21793,16465,22353]

theorem envBound14994 : H12AffineFastState.Bounded env14994 := by
  intro p hp
  have h : env14994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14993_14994 : H12AffineEnvironment.transform 15 30042 env14993 = env14994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env14993 == env14994) = true)

theorem identity14994 : scanCanonicalize (H12AffineFastState.compose env14994 (packedSelected [3,5,9,11,15,19,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 11460) := by decide +kernel

theorem selectedBound14994 : packedSelected [3,5,9,11,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env14995 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,11460,6160,6558,11276,4405,1024,6161,4160,8612,6145,6210,8328,65,12692,3328,12756,4589,1500,14653,256,14821,11413,15253]

theorem envBound14995 : H12AffineFastState.Bounded env14995 := by
  intro p hp
  have h : env14995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14994_14995 : H12AffineEnvironment.transform 13 11460 env14994 = env14995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11460 env14994 == env14995) = true)

theorem identity14995 : scanCanonicalize (H12AffineFastState.compose env14995 (packedSelected [0,2,6,7,10,11,12,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 445) := by decide +kernel

theorem selectedBound14995 : packedSelected [0,2,6,7,10,11,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env14996 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,445,8192,11460,2477,2083,11276,136,1024,2476,509,8612,2492,2559,8328,65,8233,3328,8297,80,1500,10368,256,10328,11413,10792]

theorem envBound14996 : H12AffineFastState.Bounded env14996 := by
  intro p hp
  have h : env14996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14995_14996 : H12AffineEnvironment.transform 11 445 env14995 = env14996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 445 env14995 == env14996) = true)

theorem identity14996 : scanCanonicalize (H12AffineFastState.compose env14996 (packedSelected [3,5,15,18,19,23] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound14996 : packedSelected [3,5,15,18,19,23] rootPS < 2^1333 := by decide +kernel

def env14997 : List Nat := [2,4,8,16,32,64,128,256,512,1024,0,445,8192,9412,429,35,9228,136,1024,428,509,8612,444,511,8328,65,8233,1280,8297,80,1500,8320,256,8280,9365,8744]

theorem envBound14997 : H12AffineFastState.Bounded env14997 := by
  intro p hp
  have h : env14997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14996_14997 : H12AffineEnvironment.transform 10 0 env14996 = env14997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env14996 == env14997) = true)

theorem identity14997 : scanCanonicalize (H12AffineFastState.compose env14997 (packedSelected [0,2,6,7,12,15,16,17] rootPS)) = affineNative (2^(9+1) ^^^ 456) := by decide +kernel

theorem selectedBound14997 : packedSelected [0,2,6,7,12,15,16,17] rootPS < 2^1333 := by decide +kernel

def env14998 : List Nat := [2,4,8,16,32,64,128,256,512,456,0,445,8192,8460,429,35,8644,136,456,428,509,8612,444,511,8328,65,8233,200,8297,80,20,8320,256,8280,8541,8744]

theorem envBound14998 : H12AffineFastState.Bounded env14998 := by
  intro p hp
  have h : env14998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14997_14998 : H12AffineEnvironment.transform 9 456 env14997 = env14998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 456 env14997 == env14998) = true)

theorem identity14998 : scanCanonicalize (H12AffineFastState.compose env14998 (packedSelected [2,3,4,5,6,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound14998 : packedSelected [2,3,4,5,6,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env14999 : List Nat := [2,4,8,16,32,16,128,256,512,408,0,445,8192,8460,429,35,8596,136,408,428,429,8612,444,431,8328,17,8233,152,8249,0,20,8320,256,8200,8461,8744]

theorem envBound14999 : H12AffineFastState.Bounded env14999 := by
  intro p hp
  have h : env14999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14998_14999 : H12AffineEnvironment.transform 5 16 env14998 = env14999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env14998 == env14999) = true)

theorem identity14999 : scanCanonicalize (H12AffineFastState.compose env14999 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound14999 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15000 : List Nat := [2,4,8,16,32,16,128,256,512,408,0,445,268,0,429,35,152,136,408,428,429,168,444,431,388,17,293,152,309,0,20,396,256,260,1,804]

theorem envBound15000 : H12AffineFastState.Bounded env15000 := by
  intro p hp
  have h : env15000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14999_15000 : H12AffineEnvironment.transform 12 268 env14999 = env15000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env14999 == env15000) = true)

theorem identity15000 : scanCanonicalize (H12AffineFastState.compose env15000 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15000 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env15001 : List Nat := [2,4,8,16,32,16,128,37,512,189,0,152,41,0,136,35,152,136,189,137,136,168,153,138,161,17,0,152,16,0,20,169,37,33,1,513]

theorem envBound15001 : H12AffineFastState.Bounded env15001 := by
  intro p hp
  have h : env15001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15000_15001 : H12AffineEnvironment.transform 7 37 env15000 = env15001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15000 == env15001) = true)

def env15002 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169400,412157,510001,8328,65,316532,417020,396525,35324,1501,272393,256,21793,46213,74250]

theorem envBound15002 : H12AffineFastState.Bounded env15002 := by
  intro p hp
  have h : env15002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14974_15002 : H12AffineEnvironment.transform 20 4161 env14974 = env15002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env14974 == env15002) = true)

theorem identity15002 : scanCanonicalize (H12AffineFastState.compose env15002 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149997) := by decide +kernel

theorem selectedBound15002 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15003 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149997,1024,32769,4161,169400,16,98780,8328,65,171417,5393,17664,35324,1501,156132,256,21793,46213,74250]

theorem envBound15003 : H12AffineFastState.Bounded env15003 := by
  intro p hp
  have h : env15003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15002_15003 : H12AffineEnvironment.transform 17 149997 env15002 = env15003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149997 env15002 == env15003) = true)

def env15004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169264,16,98644,8192,65,171281,5393,17664,35188,1365,156012,256,21793,46093,74250]

theorem envBound15004 : H12AffineFastState.Bounded env15004 := by
  intro p hp
  have h : env15004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15003_15004 : H12AffineEnvironment.transform 6 8 env15003 = env15004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15003 == env15004) = true)

theorem identity15004 : scanCanonicalize (H12AffineFastState.compose env15004 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound15004 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,108927,1024,32769,4161,95530,16,98644,8192,65,97547,5393,17664,35188,1365,98678,256,21793,46093,74250]

theorem envBound15005 : H12AffineFastState.Bounded env15005 := by
  intro p hp
  have h : env15005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15004_15005 : H12AffineEnvironment.transform 16 122906 env15004 = env15005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env15004 == env15005) = true)

theorem identity15005 : scanCanonicalize (H12AffineFastState.compose env15005 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound15005 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env15006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33030,24860,10361,1024,32769,4161,62508,16,82,8192,65,64525,5393,17664,35188,1365,112,256,21793,46093,41740]

theorem envBound15006 : H12AffineFastState.Bounded env15006 := by
  intro p hp
  have h : env15006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15005_15006 : H12AffineEnvironment.transform 15 33030 env15005 = env15006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env15005 == env15006) = true)

theorem identity15006 : scanCanonicalize (H12AffineFastState.compose env15006 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15006 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env15007 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,32768,32803,24633,10361,1024,32769,4161,62508,16,82,8192,65,64525,5172,17445,34897,1136,112,37,21508,46093,41513]

theorem envBound15007 : H12AffineFastState.Bounded env15007 := by
  intro p hp
  have h : env15007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15006_15007 : H12AffineEnvironment.transform 7 37 env15006 = env15007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15006 == env15007) = true)

theorem identity15007 : scanCanonicalize (H12AffineFastState.compose env15007 (packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21541) := by decide +kernel

theorem selectedBound15007 : packedSelected [0,1,2,3,5,6,7,8,10,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env15008 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,8192,16384,21541,21510,24633,10361,1024,21540,4161,8201,16,82,8192,65,10280,5172,17445,23668,1136,112,37,21508,24616,30220]

theorem envBound15008 : H12AffineFastState.Bounded env15008 := by
  intro p hp
  have h : env15008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15007_15008 : H12AffineEnvironment.transform 14 21541 env15007 = env15008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21541 env15007 == env15008) = true)

theorem identity15008 : scanCanonicalize (H12AffineFastState.compose env15008 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound15008 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env15009 : List Nat := [2,4,8,16,32,64,8,37,512,1024,2048,4096,41,16384,21541,21510,16400,2128,1024,21540,4161,32,16,82,41,65,2049,5172,17445,23668,1136,112,37,21508,16385,22053]

theorem envBound15009 : H12AffineFastState.Bounded env15009 := by
  intro p hp
  have h : env15009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15008_15009 : H12AffineEnvironment.transform 12 41 env15008 = env15009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env15008 == env15009) = true)

def env15010 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,169265,16,98645,8193,65,171280,5393,17664,35189,1364,156013,256,21793,46092,74250]

theorem envBound15010 : H12AffineFastState.Bounded env15010 := by
  intro p hp
  have h : env15010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15003_15010 : H12AffineEnvironment.transform 6 9 env15003 = env15010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env15003 == env15010) = true)

theorem identity15010 : scanCanonicalize (H12AffineFastState.compose env15010 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound15010 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15011 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67618,1024,32769,4161,119927,16,98645,8193,65,121942,5393,17664,35189,1364,73771,256,21793,46092,74250]

theorem envBound15011 : H12AffineFastState.Bounded env15011 := by
  intro p hp
  have h : env15011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15010_15011 : H12AffineEnvironment.transform 16 82246 env15010 = env15011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env15010 == env15011) = true)

theorem identity15011 : scanCanonicalize (H12AffineFastState.compose env15011 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound15011 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env15012 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,46156,64808,1024,32769,4161,8573,16,29791,8193,65,10588,5393,17664,35189,1364,54561,256,21793,46092,55040]

theorem envBound15012 : H12AffineFastState.Bounded env15012 := by
  intro p hp
  have h : env15012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15011_15012 : H12AffineEnvironment.transform 15 62730 env15011 = env15012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env15011 == env15012) = true)

theorem identity15012 : scanCanonicalize (H12AffineFastState.compose env15012 (packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound15012 : packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env15013 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,16400,2420,1024,29789,4161,8573,16,29791,8193,65,10588,5393,17664,32041,1364,8573,256,21793,16464,9052]

theorem envBound15013 : H12AffineFastState.Bounded env15013 := by
  intro p hp
  have h : env15013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15012_15013 : H12AffineEnvironment.transform 14 29788 env15012 = env15013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env15012 == env15013) = true)

def env15014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169401,2513340,510001,8328,65,2409524,2510013,396525,2136509,2102684,2373705,256,21793,46213,2175563]

theorem envBound15014 : H12AffineFastState.Bounded env15014 := by
  intro p hp
  have h : env15014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans14973_15014 : H12AffineEnvironment.transform 21 169401 env14973 = env15014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env14973 == env15014) = true)

def env15015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169401,412156,510001,8328,65,316532,417021,396525,35325,1500,272393,256,21793,46213,74251]

theorem envBound15015 : H12AffineFastState.Bounded env15015 := by
  intro p hp
  have h : env15015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15014_15015 : H12AffineEnvironment.transform 20 4160 env15014 = env15015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env15014 == env15015) = true)

theorem identity15015 : scanCanonicalize (H12AffineFastState.compose env15015 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179512) := by decide +kernel

theorem selectedBound15015 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env15016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,169401,62660,95497,8328,65,158028,57797,45525,35325,1500,169265,256,21793,46213,74251]

theorem envBound15016 : H12AffineFastState.Bounded env15016 := by
  intro p hp
  have h : env15016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15015_15016 : H12AffineEnvironment.transform 17 179512 env15015 = env15016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179512 env15015 == env15016) = true)

theorem identity15016 : scanCanonicalize (H12AffineFastState.compose env15016 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound15016 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env15017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179512,1024,32769,4160,169401,62660,21763,8328,65,158028,57797,45525,35325,1500,169265,256,21793,46213,513]

theorem envBound15017 : H12AffineFastState.Bounded env15017 := by
  intro p hp
  have h : env15017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15016_15017 : H12AffineEnvironment.transform 15 8202 env15016 = env15017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env15016 == env15017) = true)

theorem identity15017 : scanCanonicalize (H12AffineFastState.compose env15017 (packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46157) := by decide +kernel

theorem selectedBound15017 : packedSelected [11,12,15,16,18,20,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env15018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46157,2421,1024,32769,4160,8692,62660,21763,8328,65,56577,57797,45525,35325,1500,8572,256,21793,46213,513]

theorem envBound15018 : H12AffineFastState.Bounded env15018 := by
  intro p hp
  have h : env15018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15017_15018 : H12AffineEnvironment.transform 16 46157 env15017 = env15018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46157 env15017 == env15018) = true)

theorem identity15018 : scanCanonicalize (H12AffineFastState.compose env15018 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound15018 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env15019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,8202,16400,2421,1024,29788,4160,8692,153,21763,8328,65,10588,5528,17800,32160,1500,8572,256,21793,16600,513]

theorem envBound15019 : H12AffineFastState.Bounded env15019 := by
  intro p hp
  have h : env15019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15018_15019 : H12AffineEnvironment.transform 14 29789 env15018 = env15019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env15018 == env15019) = true)

theorem identity15019 : scanCanonicalize (H12AffineFastState.compose env15019 (packedSelected [2,4,6,9,14,17,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound15019 : packedSelected [2,4,6,9,14,17,18,20,23] rootPS < 2^1333 := by decide +kernel

def env15020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21897,478,16400,2421,1024,21896,4160,32,153,21763,348,65,2184,5528,17800,23668,1500,168,256,21793,16600,513]

theorem envBound15020 : H12AffineFastState.Bounded env15020 := by
  intro p hp
  have h : env15020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15019_15020 : H12AffineEnvironment.transform 12 468 env15019 = env15020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env15019 == env15020) = true)

theorem identity15020 : scanCanonicalize (H12AffineFastState.compose env15020 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound15020 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env15021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3408,468,16384,18649,478,16400,2421,1024,18648,3344,32,153,18515,348,65,2184,2248,17800,16676,1500,168,256,18545,16600,513]

theorem envBound15021 : H12AffineFastState.Bounded env15021 := by
  intro p hp
  have h : env15021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15020_15021 : H12AffineEnvironment.transform 11 3408 env15020 = env15021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env15020 == env15021) = true)

theorem identity15021 : scanCanonicalize (H12AffineFastState.compose env15021 (packedSelected [0,3,4,5,7,9,10,14,17] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound15021 : packedSelected [0,3,4,5,7,9,10,14,17] rootPS < 2^1333 := by decide +kernel

def env15022 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2113,468,16384,18649,478,16400,2421,273,18648,2049,32,153,18515,348,65,2184,2248,16537,16676,205,168,256,18545,16600,513]

theorem envBound15022 : H12AffineFastState.Bounded env15022 := by
  intro p hp
  have h : env15022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15021_15022 : H12AffineEnvironment.transform 9 273 env15021 = env15022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env15021 == env15022) = true)

theorem identity15022 : scanCanonicalize (H12AffineFastState.compose env15022 (packedSelected [0,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 2557) := by decide +kernel

theorem selectedBound15022 : packedSelected [0,9,10] rootPS < 2^1333 := by decide +kernel

def env15023 : List Nat := [2,4,8,16,32,64,128,256,512,273,2048,2113,468,2557,292,478,2541,2421,273,293,2049,32,153,430,348,65,2184,2248,2404,2265,205,168,256,396,2341,513]

theorem envBound15023 : H12AffineFastState.Bounded env15023 := by
  intro p hp
  have h : env15023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15022_15023 : H12AffineEnvironment.transform 13 2557 env15022 = env15023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2557 env15022 == env15023) = true)

theorem identity15023 : scanCanonicalize (H12AffineFastState.compose env15023 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound15023 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env15024 : List Nat := [2,4,8,16,32,64,89,256,512,273,2048,2113,269,2340,292,263,2356,2421,273,293,2049,32,64,375,348,65,2129,2065,2404,2048,20,113,256,341,2341,513]

theorem envBound15024 : H12AffineFastState.Bounded env15024 := by
  intro p hp
  have h : env15024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15023_15024 : H12AffineEnvironment.transform 6 89 env15023 = env15024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env15023 == env15024) = true)

theorem identity15024 : scanCanonicalize (H12AffineFastState.compose env15024 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound15024 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env15025 : List Nat := [2,4,8,16,32,64,89,37,512,52,2048,2113,40,2049,1,34,2065,2128,52,0,2049,32,64,82,121,65,2129,2065,2113,2048,20,113,37,112,2048,513]

theorem envBound15025 : H12AffineFastState.Bounded env15025 := by
  intro p hp
  have h : env15025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15024_15025 : H12AffineEnvironment.transform 7 37 env15024 = env15025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env15024 == env15025) = true)

theorem identity15025 : scanCanonicalize (H12AffineFastState.compose env15025 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 625) := by decide +kernel

theorem selectedBound15025 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env15026 : List Nat := [2,4,8,16,32,64,89,37,512,52,625,560,40,624,1,34,608,545,52,0,624,32,64,82,121,65,544,608,560,625,20,113,37,112,625,513]

theorem envBound15026 : H12AffineFastState.Bounded env15026 := by
  intro p hp
  have h : env15026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15025_15026 : H12AffineEnvironment.transform 10 625 env15025 = env15026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 625 env15025 == env15026) = true)

theorem identity15026 : scanCanonicalize (H12AffineFastState.compose env15026 (packedSelected [1,2,4] rootPS)) = affineNative (2^(8+1) ^^^ 97) := by decide +kernel

theorem selectedBound15026 : packedSelected [1,2,4] rootPS < 2^1333 := by decide +kernel

def env15027 : List Nat := [2,4,8,16,32,64,89,37,97,52,16,81,40,17,1,34,1,64,52,0,17,32,64,82,121,65,65,1,81,16,20,113,37,112,16,96]

theorem envBound15027 : H12AffineFastState.Bounded env15027 := by
  intro p hp
  have h : env15027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15026_15027 : H12AffineEnvironment.transform 8 97 env15026 = env15027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 97 env15026 == env15027) = true)

theorem identity15027 : scanCanonicalize (H12AffineFastState.compose env15027 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound15027 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env15028 : List Nat := [2,4,8,16,32,1,24,37,32,52,16,16,40,17,1,34,1,1,52,0,17,32,1,19,56,0,0,1,16,16,20,48,37,49,16,33]

theorem envBound15028 : H12AffineFastState.Bounded env15028 := by
  intro p hp
  have h : env15028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15027_15028 : H12AffineEnvironment.transform 5 1 env15027 = env15028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env15027 == env15028) = true)

theorem identity15028 : scanCanonicalize (H12AffineFastState.compose env15028 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15028 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15029 : List Nat := [2,4,8,1,32,1,9,37,32,37,1,1,40,0,1,34,1,1,37,0,0,32,1,2,41,0,0,1,1,1,5,33,37,32,1,33]

theorem envBound15029 : H12AffineFastState.Bounded env15029 := by
  intro p hp
  have h : env15029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15028_15029 : H12AffineEnvironment.transform 3 1 env15028 = env15029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15028 == env15029) = true)

theorem identity15029 : scanCanonicalize (H12AffineFastState.compose env15029 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound15029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15030 : List Nat := [2,4,8,1,1,1,9,4,1,4,1,1,9,0,1,3,1,1,4,0,0,1,1,2,8,0,0,1,1,1,5,0,4,1,1,0]

theorem envBound15030 : H12AffineFastState.Bounded env15030 := by
  intro p hp
  have h : env15030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15029_15030 : H12AffineEnvironment.transform 4 1 env15029 = env15030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env15029 == env15030) = true)

def env15031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169401,412157,510001,8328,65,316533,417020,396525,35324,1501,272392,256,21793,46213,74250]

theorem envBound15031 : H12AffineFastState.Bounded env15031 := by
  intro p hp
  have h : env15031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15014_15031 : H12AffineEnvironment.transform 20 4161 env15014 = env15031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env15014 == env15031) = true)

def env15032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4161,169401,156117,253977,8328,65,64605,160980,140485,35324,1501,32,256,21793,46213,74250]

theorem envBound15032 : H12AffineFastState.Bounded env15032 := by
  intro p hp
  have h : env15032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15031_15032 : H12AffineEnvironment.transform 17 10280 env15031 = env15032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env15031 == env15032) = true)

def env15033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4161,21929,41413,73737,8328,65,64605,46276,58581,35324,1501,32,256,21793,46213,74250]

theorem envBound15033 : H12AffineFastState.Bounded env15033 := by
  intro p hp
  have h : env15033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15032_15033 : H12AffineEnvironment.transform 16 49168 env15032 = env15033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env15032 == env15033) = true)

theorem identity15033 : scanCanonicalize (H12AffineFastState.compose env15033 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound15033 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,49168,10280,1024,32769,4161,21929,41413,41430,8328,65,64605,46276,58581,35324,1501,32,256,21793,46213,41941]

theorem envBound15034 : H12AffineFastState.Bounded env15034 := by
  intro p hp
  have h : env15034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15033_15034 : H12AffineEnvironment.transform 15 33247 env15033 = env15034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env15033 == env15034) = true)

theorem identity15034 : scanCanonicalize (H12AffineFastState.compose env15034 (packedSelected [1,3,8,10,16,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound15034 : packedSelected [1,3,8,10,16,20,24] rootPS < 2^1333 := by decide +kernel

def env15035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12620,32768,33247,45404,10280,1024,32769,4161,9445,41413,41430,8328,65,36113,46276,38297,35324,1501,32,256,9325,46213,41941]

theorem envBound15035 : H12AffineFastState.Bounded env15035 := by
  intro p hp
  have h : env15035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15034_15035 : H12AffineEnvironment.transform 13 12620 env15034 = env15035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env15034 == env15035) = true)

theorem identity15035 : scanCanonicalize (H12AffineFastState.compose env15035 (packedSelected [0,9,11,18,19,22,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound15035 : packedSelected [0,9,11,18,19,22,26,27] rootPS < 2^1333 := by decide +kernel

def env15036 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12620,1076,1515,13672,10280,1024,1077,4161,9445,9713,9698,8328,65,2341,12528,4525,3528,1501,32,256,9325,12465,10209]

theorem envBound15036 : H12AffineFastState.Bounded env15036 := by
  intro p hp
  have h : env15036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15035_15036 : H12AffineEnvironment.transform 14 1076 env15035 = env15036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env15035 == env15036) = true)

theorem identity15036 : scanCanonicalize (H12AffineFastState.compose env15036 (packedSelected [0,2,4,6,7,9,11,14,16,18,19,20,26] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound15036 : packedSelected [0,2,4,6,7,9,11,14,16,18,19,20,26] rootPS < 2^1333 := by decide +kernel

def env15037 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,4161,1076,1515,5221,2341,1024,1077,4161,1512,1276,1263,389,65,2341,4605,4525,3528,1501,32,256,1376,4540,1772]

theorem envBound15037 : H12AffineFastState.Bounded env15037 := by
  intro p hp
  have h : env15037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15036_15037 : H12AffineEnvironment.transform 12 269 env15036 = env15037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env15036 == env15037) = true)

theorem identity15037 : scanCanonicalize (H12AffineFastState.compose env15037 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound15037 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env15038 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,269,4161,428,115,4605,2341,408,429,4161,112,356,375,389,65,2341,4605,4525,2128,69,32,256,248,4540,884]

theorem envBound15038 : H12AffineFastState.Bounded env15038 := by
  intro p hp
  have h : env15038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15037_15038 : H12AffineEnvironment.transform 9 408 env15037 = env15038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env15037 == env15038) = true)

theorem identity15038 : scanCanonicalize (H12AffineFastState.compose env15038 (packedSelected [0,1,2,7,8,14] rootPS)) = affineNative (2^(11+1) ^^^ 429) := by decide +kernel

theorem selectedBound15038 : packedSelected [0,1,2,7,8,14] rootPS < 2^1333 := by decide +kernel

def env15039 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,429,269,492,428,115,80,2341,408,429,492,112,356,375,389,65,2341,80,0,2128,69,32,256,248,17,884]

theorem envBound15039 : H12AffineFastState.Bounded env15039 := by
  intro p hp
  have h : env15039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15038_15039 : H12AffineEnvironment.transform 11 429 env15038 = env15039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 429 env15038 == env15039) = true)

theorem identity15039 : scanCanonicalize (H12AffineFastState.compose env15039 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound15039 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env15040 : List Nat := [2,4,8,16,32,64,128,252,512,100,2048,81,241,16,80,115,80,2265,100,81,16,112,152,139,121,65,2265,80,0,2128,69,32,252,248,17,648]

theorem envBound15040 : H12AffineFastState.Bounded env15040 := by
  intro p hp
  have h : env15040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15039_15040 : H12AffineEnvironment.transform 7 252 env15039 = env15040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env15039 == env15040) = true)

theorem identity15040 : scanCanonicalize (H12AffineFastState.compose env15040 (packedSelected [1,4,6,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound15040 : packedSelected [1,4,6,8,9] rootPS < 2^1333 := by decide +kernel

def env15041 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,1,161,16,0,35,0,2185,52,1,16,32,152,139,41,17,2185,0,0,2048,21,32,172,168,17,648]

theorem envBound15041 : H12AffineFastState.Bounded env15041 := by
  intro p hp
  have h : env15041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15040_15041 : H12AffineEnvironment.transform 5 16 env15040 = env15041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env15040 == env15041) = true)

theorem identity15041 : scanCanonicalize (H12AffineFastState.compose env15041 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 162) := by decide +kernel

theorem selectedBound15041 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env15042 : List Nat := [2,4,8,16,32,16,128,172,512,52,162,1,161,16,0,35,0,43,52,1,16,32,152,139,41,17,43,0,0,162,21,32,172,168,17,648]

theorem envBound15042 : H12AffineFastState.Bounded env15042 := by
  intro p hp
  have h : env15042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15041_15042 : H12AffineEnvironment.transform 10 162 env15041 = env15042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 162 env15041 == env15042) = true)

theorem identity15042 : scanCanonicalize (H12AffineFastState.compose env15042 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound15042 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env15043 : List Nat := [2,4,8,16,32,16,128,172,33,52,162,1,161,16,0,35,0,43,52,1,16,32,152,139,41,17,43,0,0,162,21,32,172,168,17,169]

theorem envBound15043 : H12AffineFastState.Bounded env15043 := by
  intro p hp
  have h : env15043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15042_15043 : H12AffineEnvironment.transform 8 33 env15042 = env15043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env15042 == env15043) = true)

theorem identity15043 : scanCanonicalize (H12AffineFastState.compose env15043 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound15043 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15044 : List Nat := [2,4,8,16,30,16,128,146,31,10,156,1,159,16,0,29,0,21,10,1,16,30,152,139,23,17,21,0,0,156,21,30,146,150,17,151]

theorem envBound15044 : H12AffineFastState.Bounded env15044 := by
  intro p hp
  have h : env15044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15043_15044 : H12AffineEnvironment.transform 4 30 env15043 = env15044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env15043 == env15044) = true)

theorem identity15044 : scanCanonicalize (H12AffineFastState.compose env15044 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 20) := by decide +kernel

theorem selectedBound15044 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env15045 : List Nat := [2,4,8,16,30,16,20,6,31,10,8,1,11,16,0,29,0,21,10,1,16,30,12,31,23,17,21,0,0,8,21,30,6,2,17,3]

theorem envBound15045 : H12AffineFastState.Bounded env15045 := by
  intro p hp
  have h : env15045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15044_15045 : H12AffineEnvironment.transform 6 20 env15044 = env15045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 20 env15044 == env15045) = true)

theorem identity15045 : scanCanonicalize (H12AffineFastState.compose env15045 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound15045 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env15046 : List Nat := [2,4,8,12,2,12,8,6,3,10,8,1,11,12,0,1,0,9,10,1,12,2,12,3,11,13,9,0,0,8,9,2,6,2,13,3]

theorem envBound15046 : H12AffineFastState.Bounded env15046 := by
  intro p hp
  have h : env15046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15045_15046 : H12AffineEnvironment.transform 3 12 env15045 = env15046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env15045 == env15046) = true)

theorem identity15046 : scanCanonicalize (H12AffineFastState.compose env15046 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound15046 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15047 : List Nat := [1,4,8,12,1,12,8,5,0,9,8,1,8,12,0,1,0,9,9,1,12,1,12,0,8,13,9,0,0,8,9,1,5,1,13,0]

theorem envBound15047 : H12AffineFastState.Bounded env15047 := by
  intro p hp
  have h : env15047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15046_15047 : H12AffineEnvironment.transform 0 1 env15046 = env15047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env15046 == env15047) = true)

def env15048 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4161,21928,41412,73736,8328,65,64605,46277,58580,35324,1501,32,256,21793,46213,74250]

theorem envBound15048 : H12AffineFastState.Bounded env15048 := by
  intro p hp
  have h : env15048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15032_15048 : H12AffineEnvironment.transform 16 49169 env15032 = env15048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env15032 == env15048) = true)

theorem identity15048 : scanCanonicalize (H12AffineFastState.compose env15048 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound15048 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,49169,10280,1024,32769,4161,21928,41412,41311,8328,65,64605,46277,58580,35324,1501,32,256,21793,46213,41821]

theorem envBound15049 : H12AffineFastState.Bounded env15049 := by
  intro p hp
  have h : env15049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15048_15049 : H12AffineEnvironment.transform 15 33111 env15048 = env15049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env15048 == env15049) = true)

theorem identity15049 : scanCanonicalize (H12AffineFastState.compose env15049 (packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 30072) := by decide +kernel

theorem selectedBound15049 : packedSelected [2,3,6,7,9,10,11,19,20,22,23,24,27] rootPS < 2^1333 := by decide +kernel

def env15050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30072,29743,13673,10280,1024,30073,4161,21928,21692,21543,8328,65,2341,16829,4524,31876,1501,32,256,21793,16893,22053]

theorem envBound15050 : H12AffineFastState.Bounded env15050 := by
  intro p hp
  have h : env15050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15049_15050 : H12AffineEnvironment.transform 14 30072 env15049 = env15050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30072 env15049 == env15050) = true)

theorem identity15050 : scanCanonicalize (H12AffineFastState.compose env15050 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,19,20,23,26] rootPS)) = affineNative (2^(12+1) ^^^ 1504) := by decide +kernel

theorem selectedBound15050 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env15051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1504,16384,20632,20943,4233,3528,1024,20633,4161,21928,21692,21543,1384,65,2341,16829,4524,22884,1501,32,256,21793,16893,22053]

theorem envBound15051 : H12AffineFastState.Bounded env15051 := by
  intro p hp
  have h : env15051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15050_15051 : H12AffineEnvironment.transform 12 1504 env15050 = env15051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1504 env15050 == env15051) = true)

theorem identity15051 : scanCanonicalize (H12AffineFastState.compose env15051 (packedSelected [1,2,4,5,6,8,16,22,24] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound15051 : packedSelected [1,2,4,5,6,8,16,22,24] rootPS < 2^1333 := by decide +kernel

def env15052 : List Nat := [2,4,8,16,32,64,128,256,512,52,2048,4096,468,16384,20632,20943,4233,2556,52,20633,4161,20892,20616,20499,348,65,2341,16829,4524,22884,489,32,256,20757,16893,21009]

theorem envBound15052 : H12AffineFastState.Bounded env15052 := by
  intro p hp
  have h : env15052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15051_15052 : H12AffineEnvironment.transform 9 52 env15051 = env15052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env15051 == env15052) = true)

theorem identity15052 : scanCanonicalize (H12AffineFastState.compose env15052 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound15052 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env15053 : List Nat := [2,4,8,16,32,64,128,36,512,52,2048,4096,240,16384,20632,20715,4233,2264,52,20633,4161,20664,20616,20499,120,65,2049,16537,4232,22592,205,32,36,20529,16601,21009]

theorem envBound15053 : H12AffineFastState.Bounded env15053 := by
  intro p hp
  have h : env15053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15052_15053 : H12AffineEnvironment.transform 7 36 env15052 = env15053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env15052 == env15053) = true)

theorem identity15053 : scanCanonicalize (H12AffineFastState.compose env15053 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound15053 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env15054 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,4096,41,16384,20545,20530,4176,2049,52,20544,4161,20577,20561,20499,120,65,2049,16448,4177,22592,20,32,36,20529,16384,21009]

theorem envBound15054 : H12AffineFastState.Bounded env15054 := by
  intro p hp
  have h : env15054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15053_15054 : H12AffineEnvironment.transform 6 89 env15053 = env15054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env15053 == env15054) = true)

theorem identity15054 : scanCanonicalize (H12AffineFastState.compose env15054 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound15054 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env15055 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,4096,41,4113,80,35,4176,2049,52,81,4161,112,64,2,120,65,2049,4177,4177,2129,20,32,36,32,4113,512]

theorem envBound15055 : H12AffineFastState.Bounded env15055 := by
  intro p hp
  have h : env15055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15054_15055 : H12AffineEnvironment.transform 13 4113 env15054 = env15055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env15054 == env15055) = true)

theorem identity15055 : scanCanonicalize (H12AffineFastState.compose env15055 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 112) := by decide +kernel

theorem selectedBound15055 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env15056 : List Nat := [2,4,8,16,32,64,89,36,512,52,2048,112,41,97,80,35,32,2049,52,81,49,112,64,2,120,65,2049,33,33,2129,20,32,36,32,97,512]

theorem envBound15056 : H12AffineFastState.Bounded env15056 := by
  intro p hp
  have h : env15056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15055_15056 : H12AffineEnvironment.transform 11 112 env15055 = env15056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 112 env15055 == env15056) = true)

theorem identity15056 : scanCanonicalize (H12AffineFastState.compose env15056 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound15056 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env15057 : List Nat := [2,4,8,16,32,48,41,36,512,52,2048,0,41,17,32,35,32,2049,52,33,49,0,48,2,8,49,2049,33,33,2081,20,32,36,32,17,512]

theorem envBound15057 : H12AffineFastState.Bounded env15057 := by
  intro p hp
  have h : env15057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15056_15057 : H12AffineEnvironment.transform 5 48 env15056 = env15057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env15056 == env15057) = true)

theorem identity15057 : scanCanonicalize (H12AffineFastState.compose env15057 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound15057 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env15058 : List Nat := [2,4,8,16,32,48,41,36,512,52,32,0,41,17,32,35,32,33,52,33,49,0,48,2,8,49,33,33,33,1,20,32,36,32,17,512]

theorem envBound15058 : H12AffineFastState.Bounded env15058 := by
  intro p hp
  have h : env15058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15057_15058 : H12AffineEnvironment.transform 10 32 env15057 = env15058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env15057 == env15058) = true)

theorem identity15058 : scanCanonicalize (H12AffineFastState.compose env15058 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound15058 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env15059 : List Nat := [2,4,8,1,32,33,41,36,512,37,32,0,41,0,32,35,32,33,37,33,32,0,33,2,8,32,33,33,33,1,5,32,36,32,0,512]

theorem envBound15059 : H12AffineFastState.Bounded env15059 := by
  intro p hp
  have h : env15059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15058_15059 : H12AffineEnvironment.transform 3 1 env15058 = env15059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env15058 == env15059) = true)

theorem identity15059 : scanCanonicalize (H12AffineFastState.compose env15059 (packedSelected [11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15059 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env15060 : List Nat := [2,4,8,1,0,1,9,4,512,5,0,0,9,0,0,3,0,1,5,1,0,0,1,2,8,0,1,1,1,1,5,0,4,0,0,512]

theorem envBound15060 : H12AffineFastState.Bounded env15060 := by
  intro p hp
  have h : env15060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15059_15060 : H12AffineEnvironment.transform 4 0 env15059 = env15060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15059 == env15060) = true)

theorem identity15060 : scanCanonicalize (H12AffineFastState.compose env15060 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound15060 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15061 : List Nat := [2,4,8,1,0,1,9,4,0,5,0,0,9,0,0,3,0,1,5,1,0,0,1,2,8,0,1,1,1,1,5,0,4,0,0,0]

theorem envBound15061 : H12AffineFastState.Bounded env15061 := by
  intro p hp
  have h : env15061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15060_15061 : H12AffineEnvironment.transform 8 0 env15060 = env15061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env15060 == env15061) = true)

theorem identity15061 : scanCanonicalize (H12AffineFastState.compose env15061 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound15061 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15062 : List Nat := [2,1,8,1,0,1,9,1,0,0,0,0,9,0,0,3,0,1,0,1,0,0,1,2,8,0,1,1,1,1,0,0,1,0,0,0]

theorem envBound15062 : H12AffineFastState.Bounded env15062 := by
  intro p hp
  have h : env15062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15061_15062 : H12AffineEnvironment.transform 1 1 env15061 = env15062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env15061 == env15062) = true)

def env15063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4161,169401,156116,253976,8328,65,64604,160981,140484,35324,1501,33,256,21793,46213,74250]

theorem envBound15063 : H12AffineFastState.Bounded env15063 := by
  intro p hp
  have h : env15063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15031_15063 : H12AffineEnvironment.transform 17 10281 env15031 = env15063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env15031 == env15063) = true)

def env15064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,21929,41412,73736,8328,65,64604,46277,58580,35324,1501,33,256,21793,46213,74250]

theorem envBound15064 : H12AffineFastState.Bounded env15064 := by
  intro p hp
  have h : env15064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15063_15064 : H12AffineEnvironment.transform 16 49168 env15063 = env15064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env15063 == env15064) = true)

theorem identity15064 : scanCanonicalize (H12AffineFastState.compose env15064 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound15064 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10281,1024,32769,4161,21929,41412,138,8328,65,64604,46277,58580,35324,1501,33,256,21793,46213,648]

theorem envBound15065 : H12AffineFastState.Bounded env15065 := by
  intro p hp
  have h : env15065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15064_15065 : H12AffineEnvironment.transform 15 8322 env15064 = env15065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env15064 == env15065) = true)

theorem identity15065 : scanCanonicalize (H12AffineFastState.compose env15065 (packedSelected [10,12,18,19,23] rootPS)) = affineNative (2^(14+1) ^^^ 8581) := by decide +kernel

theorem selectedBound15065 : packedSelected [10,12,18,19,23] rootPS < 2^1333 := by decide +kernel

def env15066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8581,8322,24981,10281,1024,8580,4161,21929,65,138,8328,65,24025,5440,17745,10361,1501,33,256,21793,5376,648]

theorem envBound15066 : H12AffineFastState.Bounded env15066 := by
  intro p hp
  have h : env15066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15065_15066 : H12AffineEnvironment.transform 14 8581 env15065 = env15066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8581 env15065 == env15066) = true)

theorem identity15066 : scanCanonicalize (H12AffineFastState.compose env15066 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound15066 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env15067 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,217,478,16585,2421,1024,216,4161,21929,65,138,468,65,24025,5440,17745,2341,1501,33,256,21793,5376,648]

theorem envBound15067 : H12AffineFastState.Bounded env15067 := by
  intro p hp
  have h : env15067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15066_15067 : H12AffineEnvironment.transform 12 348 env15066 = env15067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env15066 == env15067) = true)

theorem identity15067 : scanCanonicalize (H12AffineFastState.compose env15067 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound15067 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env15068 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,16384,136,399,16536,2340,1024,137,4112,21929,16,138,389,16,23944,5393,17664,2341,1420,33,256,21793,5376,648]

theorem envBound15068 : H12AffineFastState.Bounded env15068 := by
  intro p hp
  have h : env15068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15067_15068 : H12AffineEnvironment.transform 5 17 env15067 = env15068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env15067 == env15068) = true)

theorem identity15068 : scanCanonicalize (H12AffineFastState.compose env15068 (packedSelected [12,15] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound15068 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env15069 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,263,16400,2340,1024,1,4112,21793,16,2,269,16,23808,5393,17664,2341,1284,33,256,21793,5376,512]

theorem envBound15069 : H12AffineFastState.Bounded env15069 := by
  intro p hp
  have h : env15069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15068_15069 : H12AffineEnvironment.transform 6 8 env15068 = env15069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env15068 == env15069) = true)

theorem identity15069 : scanCanonicalize (H12AffineFastState.compose env15069 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound15069 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env15070 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,16384,0,263,16400,2308,1024,1,4112,21761,16,2,269,16,23808,5393,17664,2309,1284,1,256,21761,5376,512]

theorem envBound15070 : H12AffineFastState.Bounded env15070 := by
  intro p hp
  have h : env15070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15069_15070 : H12AffineEnvironment.transform 4 0 env15069 = env15070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env15069 == env15070) = true)

theorem identity15070 : scanCanonicalize (H12AffineFastState.compose env15070 (packedSelected [5,8] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound15070 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env15071 : List Nat := [2,4,8,16,0,17,8,256,512,1024,522,4096,269,16384,0,263,16400,782,1024,1,4112,21761,16,2,269,16,22282,5393,17664,783,1284,1,256,21761,5376,512]

theorem envBound15071 : H12AffineFastState.Bounded env15071 := by
  intro p hp
  have h : env15071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15070_15071 : H12AffineEnvironment.transform 10 522 env15070 = env15071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env15070 == env15071) = true)

theorem identity15071 : scanCanonicalize (H12AffineFastState.compose env15071 (packedSelected [1,3,12] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound15071 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env15072 : List Nat := [2,4,8,16,0,17,8,256,512,1024,522,4096,269,5377,0,263,5393,782,1024,1,4112,0,16,2,269,16,523,5393,4097,783,1284,1,256,0,5376,512]

theorem envBound15072 : H12AffineFastState.Bounded env15072 := by
  intro p hp
  have h : env15072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15071_15072 : H12AffineEnvironment.transform 13 5377 env15071 = env15072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env15071 == env15072) = true)

theorem identity15072 : scanCanonicalize (H12AffineFastState.compose env15072 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound15072 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env15073 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,4096,8,5124,0,2,5140,523,1024,1,4112,0,16,2,8,16,523,5140,4097,522,1025,1,5,0,5125,512]

theorem envBound15073 : H12AffineFastState.Bounded env15073 := by
  intro p hp
  have h : env15073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15072_15073 : H12AffineEnvironment.transform 7 5 env15072 = env15073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env15072 == env15073) = true)

def env15074 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,16,8,1044,0,2,1028,523,1024,1,0,0,16,2,8,16,523,1028,17,522,1025,1,5,0,1045,512]

theorem envBound15074 : H12AffineFastState.Bounded env15074 := by
  intro p hp
  have h : env15074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15073_15074 : H12AffineEnvironment.transform 11 16 env15073 = env15074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env15073 == env15074) = true)

theorem identity15074 : scanCanonicalize (H12AffineFastState.compose env15074 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 522) := by decide +kernel

theorem selectedBound15074 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15075 : List Nat := [2,4,8,16,0,17,8,5,512,522,522,16,8,542,0,2,526,523,522,1,0,0,16,2,8,16,523,526,17,522,523,1,5,0,543,512]

theorem envBound15075 : H12AffineFastState.Bounded env15075 := by
  intro p hp
  have h : env15075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15074_15075 : H12AffineEnvironment.transform 9 522 env15074 = env15075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 522 env15074 == env15075) = true)

def env15076 : List Nat := [2,4,8,4,0,5,8,5,512,522,522,4,8,522,0,2,526,523,522,1,0,0,4,2,8,4,523,526,5,522,523,1,5,0,523,512]

theorem envBound15076 : H12AffineFastState.Bounded env15076 := by
  intro p hp
  have h : env15076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15075_15076 : H12AffineEnvironment.transform 3 4 env15075 = env15076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env15075 == env15076) = true)

theorem identity15076 : scanCanonicalize (H12AffineFastState.compose env15076 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound15076 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15077 : List Nat := [0,4,8,4,0,5,8,5,512,520,520,4,8,520,0,0,524,521,520,1,0,0,4,0,8,4,521,524,5,520,521,1,5,0,521,512]

theorem envBound15077 : H12AffineFastState.Bounded env15077 := by
  intro p hp
  have h : env15077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15076_15077 : H12AffineEnvironment.transform 0 0 env15076 = env15077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env15076 == env15077) = true)

def leafEnv15077 : List Nat := [0,4,8,4,0,5,8,5,512,520,520,4,8,520,0,0,524,521,520,1,0,0,4,0,520,8,1,4,521,524,5,520,521,1,5,0,5,0,521,512,1,1,0]

def active15077 : List Nat := [1,2,8]

def tree15077 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15077 : H12WitnessSearch.Good tree15077 := H12GlobalWitnessIndex.good

theorem leafIdentity15077 : H12AffineFastState.composeSystem env15077 rootObs = leafEnv15077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15077 rootObs == leafEnv15077) = true)

theorem terminalChecked15077 : H12PackedTerminal.terminalCheckFast leafEnv15077 active15077 tree15077 = true := by decide +kernel

def env15078 : List Nat := [2,4,8,5,0,4,8,5,512,522,522,5,8,523,0,2,526,523,522,1,0,0,5,2,8,5,523,526,4,522,523,1,5,0,522,512]

theorem envBound15078 : H12AffineFastState.Bounded env15078 := by
  intro p hp
  have h : env15078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15075_15078 : H12AffineEnvironment.transform 3 5 env15075 = env15078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env15075 == env15078) = true)

theorem identity15078 : scanCanonicalize (H12AffineFastState.compose env15078 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound15078 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15079 : List Nat := [2,4,8,5,0,4,8,5,9,3,3,5,8,2,0,2,7,2,3,1,0,0,5,2,8,5,2,7,4,3,2,1,5,0,3,9]

theorem envBound15079 : H12AffineFastState.Bounded env15079 := by
  intro p hp
  have h : env15079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15078_15079 : H12AffineEnvironment.transform 8 9 env15078 = env15079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env15078 == env15079) = true)

def leafEnv15079 : List Nat := [2,4,8,5,0,4,8,5,9,3,3,5,8,2,0,2,7,2,3,1,0,0,5,2,3,8,1,5,2,7,4,3,2,1,5,0,5,2,3,9,1,1,0]

def active15079 : List Nat := [0,1,2]

def tree15079 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15079 : H12WitnessSearch.Good tree15079 := H12GlobalWitnessIndex.good

theorem leafIdentity15079 : H12AffineFastState.composeSystem env15079 rootObs = leafEnv15079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15079 rootObs == leafEnv15079) = true)

theorem terminalChecked15079 : H12PackedTerminal.terminalCheckFast leafEnv15079 active15079 tree15079 = true := by decide +kernel

def env15080 : List Nat := [2,4,8,16,0,17,8,5,512,1024,522,17,8,1045,0,2,1029,523,1024,1,1,0,16,2,8,16,523,1029,16,522,1025,1,5,0,1044,512]

theorem envBound15080 : H12AffineFastState.Bounded env15080 := by
  intro p hp
  have h : env15080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15073_15080 : H12AffineEnvironment.transform 11 17 env15073 = env15080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env15073 == env15080) = true)

theorem identity15080 : scanCanonicalize (H12AffineFastState.compose env15080 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound15080 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env15081 : List Nat := [2,4,8,16,0,17,8,5,30,1024,20,17,8,1045,0,2,1029,21,1024,1,1,0,16,2,8,16,21,1029,16,20,1025,1,5,0,1044,30]

theorem envBound15081 : H12AffineFastState.Bounded env15081 := by
  intro p hp
  have h : env15081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15080_15081 : H12AffineEnvironment.transform 8 30 env15080 = env15081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env15080 == env15081) = true)

def env15082 : List Nat := [2,4,8,16,0,17,8,5,30,0,20,17,8,21,0,2,5,21,0,1,1,0,16,2,8,16,21,5,16,20,1,1,5,0,20,30]

theorem envBound15082 : H12AffineFastState.Bounded env15082 := by
  intro p hp
  have h : env15082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15081_15082 : H12AffineEnvironment.transform 9 0 env15081 = env15082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env15081 == env15082) = true)

theorem identity15082 : scanCanonicalize (H12AffineFastState.compose env15082 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound15082 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15083 : List Nat := [2,4,8,6,0,7,8,5,8,0,2,7,8,3,0,2,5,3,0,1,1,0,6,2,8,6,3,5,6,2,1,1,5,0,2,8]

theorem envBound15083 : H12AffineFastState.Bounded env15083 := by
  intro p hp
  have h : env15083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15082_15083 : H12AffineEnvironment.transform 3 6 env15082 = env15083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env15082 == env15083) = true)

def leafEnv15083 : List Nat := [2,4,8,6,0,7,8,5,8,0,2,7,8,3,0,2,5,3,0,1,1,0,6,2,0,8,1,6,3,5,6,2,1,1,5,0,5,2,2,8,1,0,0]

def active15083 : List Nat := [0,1,2]

def tree15083 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15083 : H12WitnessSearch.Good tree15083 := H12GlobalWitnessIndex.good

theorem leafIdentity15083 : H12AffineFastState.composeSystem env15083 rootObs = leafEnv15083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15083 rootObs == leafEnv15083) = true)

theorem terminalChecked15083 : H12PackedTerminal.terminalCheckFast leafEnv15083 active15083 tree15083 = true := by decide +kernel

def env15084 : List Nat := [2,4,8,16,0,17,8,5,30,1,20,17,8,20,0,2,4,21,1,1,1,0,16,2,8,16,21,4,16,20,0,1,5,0,21,30]

theorem envBound15084 : H12AffineFastState.Bounded env15084 := by
  intro p hp
  have h : env15084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15081_15084 : H12AffineEnvironment.transform 9 1 env15081 = env15084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env15081 == env15084) = true)

theorem identity15084 : scanCanonicalize (H12AffineFastState.compose env15084 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound15084 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env15085 : List Nat := [0,4,8,16,0,17,8,5,28,1,20,17,8,20,0,0,4,21,1,1,1,0,16,0,8,16,21,4,16,20,0,1,5,0,21,28]

theorem envBound15085 : H12AffineFastState.Bounded env15085 := by
  intro p hp
  have h : env15085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15084_15085 : H12AffineEnvironment.transform 0 0 env15084 = env15085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env15084 == env15085) = true)

def leafEnv15085 : List Nat := [0,4,8,16,0,17,8,5,28,1,20,17,8,20,0,0,4,21,1,1,1,0,16,0,1,8,1,16,21,4,16,20,0,1,5,0,5,0,21,28,1,0,0]

def active15085 : List Nat := [1,2,3]

def tree15085 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood15085 : H12WitnessSearch.Good tree15085 := H12GlobalWitnessIndex.good

theorem leafIdentity15085 : H12AffineFastState.composeSystem env15085 rootObs = leafEnv15085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env15085 rootObs == leafEnv15085) = true)

theorem terminalChecked15085 : H12PackedTerminal.terminalCheckFast leafEnv15085 active15085 tree15085 = true := by decide +kernel

def env15086 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4161,21928,41413,73737,8328,65,64604,46276,58581,35324,1501,33,256,21793,46213,74250]

theorem envBound15086 : H12AffineFastState.Bounded env15086 := by
  intro p hp
  have h : env15086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15063_15086 : H12AffineEnvironment.transform 16 49169 env15063 = env15086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env15063 == env15086) = true)

theorem identity15086 : scanCanonicalize (H12AffineFastState.compose env15086 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound15086 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env15087 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,49169,10281,1024,32769,4161,21928,41413,2,8328,65,64604,46276,58581,35324,1501,33,256,21793,46213,513]

theorem envBound15087 : H12AffineFastState.Bounded env15087 := by
  intro p hp
  have h : env15087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans15086_15087 : H12AffineEnvironment.transform 15 8203 env15086 = env15087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env15086 == env15087) = true)

end H12CloudChart1