import H12CloudChart1Data089

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans22779_22780 : H12AffineEnvironment.transform 7 62 env22779 = env22780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env22779 == env22780) = true)

theorem identity22780 : scanCanonicalize (H12AffineFastState.compose env22780 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound22780 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env22781 : List Nat := [2,4,8,16,27,17,8,5,512,30,27,27,8,27,1,3,11,1,31,0,16,26,16,3,8,17,26,11,26,1,31,26,4,26,27,513]

theorem envBound22781 : H12AffineFastState.Bounded env22781 := by
  intro p hp
  have h : env22781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22780_22781 : H12AffineEnvironment.transform 4 27 env22780 = env22781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env22780 == env22781) = true)

def env22782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165201,411973,213335,253976,8193,64,75786,57676,102742,360790,75103,411972,257,254010,196886,513]

theorem envBound22782 : H12AffineFastState.Bounded env22782 := by
  intro p hp
  have h : env22782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22768_22782 : H12AffineEnvironment.transform 6 9 env22768 = env22782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22768 == env22782) = true)

theorem identity22782 : scanCanonicalize (H12AffineFastState.compose env22782 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound22782 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env22783 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,262144,1025,32769,124235,338271,8525,32770,8193,64,75786,57676,102742,360790,75103,338270,257,32800,24844,513]

theorem envBound22783 : H12AffineFastState.Bounded env22783 := by
  intro p hp
  have h : env22783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22782_22783 : H12AffineEnvironment.transform 16 90138 env22782 = env22783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env22782 == env22783) = true)

theorem identity22783 : scanCanonicalize (H12AffineFastState.compose env22783 (packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 53527) := by decide +kernel

theorem selectedBound22783 : packedSelected [0,3,5,7,8,11,17,20,28,32] rootPS < 2^1333 := by decide +kernel

def env22784 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53527,45325,262144,1025,32769,13404,325704,8525,32770,8193,64,63773,57676,16449,282689,62536,325705,257,32800,24844,513]

theorem envBound22784 : H12AffineFastState.Bounded env22784 := by
  intro p hp
  have h : env22784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22783_22784 : H12AffineEnvironment.transform 15 53527 env22783 = env22784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53527 env22783 == env22784) = true)

theorem identity22784 : scanCanonicalize (H12AffineFastState.compose env22784 (packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound22784 : packedSelected [0,1,3,7,8,10,15,17,18,20,23,24,38] rootPS < 2^1333 := by decide +kernel

def env22785 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53527,45325,2420,1025,32769,13404,61756,8525,32770,8193,64,63773,57676,16449,22837,62536,61757,257,32800,24844,513]

theorem envBound22785 : H12AffineFastState.Bounded env22785 := by
  intro p hp
  have h : env22785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22784_22785 : H12AffineEnvironment.transform 17 2420 env22784 = env22785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env22784 == env22785) = true)

theorem identity22785 : scanCanonicalize (H12AffineFastState.compose env22785 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound22785 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22786 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,28747,4177,2420,1025,8541,13404,20576,8525,8542,8193,64,22593,16400,16449,22837,21780,20577,257,8572,24844,513]

theorem envBound22786 : H12AffineFastState.Bounded env22786 := by
  intro p hp
  have h : env22786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22785_22786 : H12AffineEnvironment.transform 14 8540 env22785 = env22786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env22785 == env22786) = true)

theorem identity22786 : scanCanonicalize (H12AffineFastState.compose env22786 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 12572) := by decide +kernel

theorem selectedBound22786 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env22787 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12572,8540,343,4177,2420,1025,8541,13404,8572,8525,8542,8193,64,10589,12556,12637,10281,9224,8573,257,8572,4112,513]

theorem envBound22787 : H12AffineFastState.Bounded env22787 := by
  intro p hp
  have h : env22787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22786_22787 : H12AffineEnvironment.transform 13 12572 env22786 = env22787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12572 env22786 == env22787) = true)

theorem identity22787 : scanCanonicalize (H12AffineFastState.compose env22787 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound22787 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22788 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,4112,80,343,4177,2420,1025,81,5456,112,65,82,269,64,2129,4096,4177,2341,1284,113,257,112,4112,513]

theorem envBound22788 : H12AffineFastState.Bounded env22788 := by
  intro p hp
  have h : env22788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22787_22788 : H12AffineEnvironment.transform 12 268 env22787 = env22788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env22787 == env22788) = true)

def env22789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213335,16777216,8328,64,16959643,16974165,102878,360790,16958791,17148372,257,16777251,16834950,17031824]

theorem envBound22789 : H12AffineFastState.Bounded env22789 := by
  intro p hp
  have h : env22789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22749_22789 : H12AffineEnvironment.transform 20 165337 env22749 = env22789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env22749 == env22789) = true)

theorem identity22789 : scanCanonicalize (H12AffineFastState.compose env22789 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188871) := by decide +kernel

theorem selectedBound22789 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env22790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412108,213335,188871,8328,64,10588,123026,102878,360790,9344,477203,257,188900,131137,66391]

theorem envBound22790 : H12AffineFastState.Bounded env22790 := by
  intro p hp
  have h : env22790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22789_22790 : H12AffineEnvironment.transform 23 188871 env22789 = env22790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188871 env22789 == env22790) = true)

def env22791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38296,262144,1025,32769,4161,318548,120015,29791,8328,64,10588,123026,102878,360790,9344,384395,257,29820,38361,66391]

theorem envBound22791 : H12AffineFastState.Bounded env22791 := by
  intro p hp
  have h : env22791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22790_22791 : H12AffineEnvironment.transform 16 38296 env22790 = env22791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38296 env22790 == env22791) = true)

theorem identity22791 : scanCanonicalize (H12AffineFastState.compose env22791 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound22791 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24908,262144,1025,29909,4161,272512,73755,29791,8328,64,10588,70726,91402,357762,9344,338271,257,29820,24845,66391]

theorem envBound22792 : H12AffineFastState.Bounded env22792 := by
  intro p hp
  have h : env22792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22791_22792 : H12AffineEnvironment.transform 14 29908 env22791 = env22792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env22791 == env22792) = true)

def env22793 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24908,262144,1025,29909,4161,272512,73755,29791,8328,64,10588,70726,91402,357762,9344,338271,257,29788,24845,66391]

theorem envBound22793 : H12AffineFastState.Bounded env22793 := by
  intro p hp
  have h : env22793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22792_22793 : H12AffineEnvironment.transform 4 0 env22792 = env22793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22792 == env22793) = true)

theorem identity22793 : scanCanonicalize (H12AffineFastState.compose env22793 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 10368) := by decide +kernel

theorem selectedBound22793 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env22794 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24908,10368,1025,29909,4161,0,73755,29791,8328,64,10588,70726,91402,89346,9344,66015,257,29788,24845,66391]

theorem envBound22794 : H12AffineFastState.Bounded env22794 := by
  intro p hp
  have h : env22794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22793_22794 : H12AffineEnvironment.transform 17 10368 env22793 = env22794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10368 env22793 == env22794) = true)

theorem identity22794 : scanCanonicalize (H12AffineFastState.compose env22794 (packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound22794 : packedSelected [3,4,5,7,8,9,16,17,20,27,28] rootPS < 2^1333 := by decide +kernel

def env22795 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,16384,29908,478,24908,10368,1025,29909,4161,0,8645,29791,8328,64,10588,5528,25812,23772,9344,1,257,29788,24845,649]

theorem envBound22795 : H12AffineFastState.Bounded env22795 := by
  intro p hp
  have h : env22795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22794_22795 : H12AffineEnvironment.transform 15 478 env22794 = env22795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env22794 == env22795) = true)

theorem identity22795 : scanCanonicalize (H12AffineFastState.compose env22795 (packedSelected [0,7,16,17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound22795 : packedSelected [0,7,16,17] rootPS < 2^1333 := by decide +kernel

def env22796 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,8192,5376,8660,478,13388,10368,1025,8661,4161,0,8645,8543,8328,64,10588,5528,12756,2524,9344,1,257,8540,13325,649]

theorem envBound22796 : H12AffineFastState.Bounded env22796 := by
  intro p hp
  have h : env22796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22795_22796 : H12AffineEnvironment.transform 13 5376 env22795 = env22796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env22795 == env22796) = true)

theorem identity22796 : scanCanonicalize (H12AffineFastState.compose env22796 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22796 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22797 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,4096,349,5376,137,478,5393,2525,1025,136,4161,0,152,2,469,64,2049,5528,4233,2524,1501,1,257,1,5456,649]

theorem envBound22797 : H12AffineFastState.Bounded env22797 := by
  intro p hp
  have h : env22797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22796_22797 : H12AffineEnvironment.transform 12 349 env22796 = env22797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22796 == env22797) = true)

theorem identity22797 : scanCanonicalize (H12AffineFastState.compose env22797 (packedSelected [0,1,2,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 205) := by decide +kernel

theorem selectedBound22797 : packedSelected [0,1,2,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22798 : List Nat := [2,4,8,16,0,64,128,256,512,205,2048,4096,349,4557,137,478,4572,2525,204,136,4161,0,152,2,469,64,2049,4437,4233,2524,272,1,257,1,4509,649]

theorem envBound22798 : H12AffineFastState.Bounded env22798 := by
  intro p hp
  have h : env22798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22797_22798 : H12AffineEnvironment.transform 9 205 env22797 = env22798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 205 env22797 == env22798) = true)

theorem identity22798 : scanCanonicalize (H12AffineFastState.compose env22798 (packedSelected [0,1,3,7,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2461) := by decide +kernel

theorem selectedBound22798 : packedSelected [0,1,3,7,11,12] rootPS < 2^1333 := by decide +kernel

def env22799 : List Nat := [2,4,8,16,0,64,128,256,512,205,2048,2461,349,2128,137,478,2113,2525,204,136,2524,0,152,2,469,64,2049,2248,2324,2524,272,1,257,1,2048,649]

theorem envBound22799 : H12AffineFastState.Bounded env22799 := by
  intro p hp
  have h : env22799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22798_22799 : H12AffineEnvironment.transform 11 2461 env22798 = env22799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2461 env22798 == env22799) = true)

theorem identity22799 : scanCanonicalize (H12AffineFastState.compose env22799 (packedSelected [0,2,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound22799 : packedSelected [0,2,5,7,8] rootPS < 2^1333 := by decide +kernel

def env22800 : List Nat := [2,4,8,16,0,64,9,256,512,68,2048,2324,349,2128,0,343,2113,2388,69,1,2389,0,17,2,348,64,2049,2113,2324,2389,272,1,257,1,2048,512]

theorem envBound22800 : H12AffineFastState.Bounded env22800 := by
  intro p hp
  have h : env22800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22799_22800 : H12AffineEnvironment.transform 6 9 env22799 = env22800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22799 == env22800) = true)

theorem identity22800 : scanCanonicalize (H12AffineFastState.compose env22800 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound22800 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22801 : List Nat := [2,4,8,16,0,64,9,84,512,68,2048,2112,9,2128,0,3,2113,2048,69,1,2049,0,17,2,8,64,2049,2113,2112,2049,68,1,85,1,2048,512]

theorem envBound22801 : H12AffineFastState.Bounded env22801 := by
  intro p hp
  have h : env22801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22800_22801 : H12AffineEnvironment.transform 7 84 env22800 = env22801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env22800 == env22801) = true)

theorem identity22801 : scanCanonicalize (H12AffineFastState.compose env22801 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound22801 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22802 : List Nat := [2,4,8,16,0,64,9,84,30,68,2048,2112,9,2128,0,3,2113,2048,69,1,2049,0,17,2,8,64,2049,2113,2112,2049,68,1,85,1,2048,30]

theorem envBound22802 : H12AffineFastState.Bounded env22802 := by
  intro p hp
  have h : env22802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22801_22802 : H12AffineEnvironment.transform 8 30 env22801 = env22802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env22801 == env22802) = true)

theorem identity22802 : scanCanonicalize (H12AffineFastState.compose env22802 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound22802 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22803 : List Nat := [2,4,8,16,0,64,9,84,30,68,80,16,9,0,0,3,17,80,69,1,81,0,17,2,8,64,81,17,16,81,68,1,85,1,80,30]

theorem envBound22803 : H12AffineFastState.Bounded env22803 := by
  intro p hp
  have h : env22803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22802_22803 : H12AffineEnvironment.transform 10 80 env22802 = env22803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env22802 == env22803) = true)

theorem identity22803 : scanCanonicalize (H12AffineFastState.compose env22803 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22803 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22804 : List Nat := [2,4,8,1,0,64,9,69,15,68,65,1,9,0,0,3,0,65,69,1,64,0,0,2,8,64,64,0,1,64,68,1,68,1,65,15]

theorem envBound22804 : H12AffineFastState.Bounded env22804 := by
  intro p hp
  have h : env22804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22803_22804 : H12AffineEnvironment.transform 3 1 env22803 = env22804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22803 == env22804) = true)

theorem identity22804 : scanCanonicalize (H12AffineFastState.compose env22804 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 14) := by decide +kernel

theorem selectedBound22804 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22805 : List Nat := [2,4,8,1,0,14,9,11,15,10,15,1,9,0,0,3,0,15,11,1,14,0,0,2,8,14,14,0,1,14,10,1,10,1,15,15]

theorem envBound22805 : H12AffineFastState.Bounded env22805 := by
  intro p hp
  have h : env22805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22804_22805 : H12AffineEnvironment.transform 5 14 env22804 = env22805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 14 env22804 == env22805) = true)

def env22806 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24908,262144,1025,29909,4161,272512,73755,29791,8328,64,10588,70726,91402,357762,9344,338271,257,29789,24845,66391]

theorem envBound22806 : H12AffineFastState.Bounded env22806 := by
  intro p hp
  have h : env22806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22792_22806 : H12AffineEnvironment.transform 4 1 env22792 = env22806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22792 == env22806) = true)

theorem identity22806 : scanCanonicalize (H12AffineFastState.compose env22806 (packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS)) = affineNative (2^(17+1) ^^^ 76247) := by decide +kernel

theorem selectedBound22806 : packedSelected [0,2,3,4,5,6,7,8,14,22,28,35] rootPS < 2^1333 := by decide +kernel

def env22807 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,24908,76247,1025,29909,4161,65879,73755,29791,8328,64,10588,70726,91402,23637,9344,136,257,29789,24845,66391]

theorem envBound22807 : H12AffineFastState.Bounded env22807 := by
  intro p hp
  have h : env22807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22806_22807 : H12AffineEnvironment.transform 17 76247 env22806 = env22807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76247 env22806 == env22807) = true)

theorem identity22807 : scanCanonicalize (H12AffineFastState.compose env22807 (packedSelected [1,2,3,5,6,8,10,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound22807 : packedSelected [1,2,3,5,6,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env22808 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,8192,16384,29908,478,24908,10249,1025,29909,4161,137,8645,29791,8328,64,10588,5528,25812,23637,9344,136,257,29789,24845,649]

theorem envBound22808 : H12AffineFastState.Bounded env22808 := by
  intro p hp
  have h : env22808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22807_22808 : H12AffineEnvironment.transform 15 478 env22807 = env22808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env22807 == env22808) = true)

theorem identity22808 : scanCanonicalize (H12AffineFastState.compose env22808 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1221) := by decide +kernel

theorem selectedBound22808 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22809 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,1221,16384,20497,478,17801,3276,1025,20496,4161,137,1280,20634,1101,64,3481,5528,16401,23637,69,136,257,20632,17864,649]

theorem envBound22809 : H12AffineFastState.Bounded env22809 := by
  intro p hp
  have h : env22809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22808_22809 : H12AffineEnvironment.transform 12 1221 env22808 = env22809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1221 env22808 == env22809) = true)

theorem identity22809 : scanCanonicalize (H12AffineFastState.compose env22809 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 1416) := by decide +kernel

theorem selectedBound22809 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env22810 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,1416,1221,16384,17817,478,17801,3276,1025,17816,1481,137,1280,17682,1101,64,3481,16,16401,18909,69,136,257,17680,17864,649]

theorem envBound22810 : H12AffineFastState.Bounded env22810 := by
  intro p hp
  have h : env22810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22809_22810 : H12AffineEnvironment.transform 11 1416 env22809 = env22810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1416 env22809 == env22810) = true)

theorem identity22810 : scanCanonicalize (H12AffineFastState.compose env22810 (packedSelected [0,4,7,9,11,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 3140) := by decide +kernel

theorem selectedBound22810 : packedSelected [0,4,7,9,11,14,16] rootPS < 2^1333 := by decide +kernel

def env22811 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,1416,1221,3140,2525,478,2509,3276,1025,2524,1481,137,1280,2390,1101,64,3481,16,3157,1433,69,136,257,2388,2444,649]

theorem envBound22811 : H12AffineFastState.Bounded env22811 := by
  intro p hp
  have h : env22811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22810_22811 : H12AffineEnvironment.transform 13 3140 env22810 = env22811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3140 env22810 == env22811) = true)

theorem identity22811 : scanCanonicalize (H12AffineFastState.compose env22811 (packedSelected [0,1,2,4,7,8,9,11,19] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22811 : packedSelected [0,1,2,4,7,8,9,11,19] rootPS < 2^1333 := by decide +kernel

def env22812 : List Nat := [2,4,8,16,1,64,128,256,512,272,2048,152,469,2388,2525,478,2509,2524,273,2524,217,137,16,2390,349,64,2185,16,2373,137,69,136,257,2388,2444,649]

theorem envBound22812 : H12AffineFastState.Bounded env22812 := by
  intro p hp
  have h : env22812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22811_22812 : H12AffineEnvironment.transform 9 272 env22811 = env22812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22811 == env22812) = true)

theorem identity22812 : scanCanonicalize (H12AffineFastState.compose env22812 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22812 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env22813 : List Nat := [2,4,8,16,1,64,128,5,512,21,2048,152,208,2129,2264,219,2248,2265,20,2265,217,137,16,2131,88,64,2185,16,2112,137,69,136,4,2129,2185,649]

theorem envBound22813 : H12AffineFastState.Bounded env22813 := by
  intro p hp
  have h : env22813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22812_22813 : H12AffineEnvironment.transform 7 5 env22812 = env22813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22812 == env22813) = true)

theorem identity22813 : scanCanonicalize (H12AffineFastState.compose env22813 (packedSelected [2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound22813 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env22814 : List Nat := [2,4,8,16,1,64,88,5,512,21,2048,64,8,2129,2048,3,2064,2049,20,2049,1,81,16,2131,88,64,2129,16,2112,81,69,80,4,2129,2129,593]

theorem envBound22814 : H12AffineFastState.Bounded env22814 := by
  intro p hp
  have h : env22814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22813_22814 : H12AffineEnvironment.transform 6 88 env22813 = env22814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env22813 == env22814) = true)

theorem identity22814 : scanCanonicalize (H12AffineFastState.compose env22814 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound22814 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22815 : List Nat := [2,4,8,16,1,64,88,5,512,21,80,64,8,1,80,3,64,81,20,81,1,81,16,3,88,64,1,16,16,81,69,80,4,1,1,593]

theorem envBound22815 : H12AffineFastState.Bounded env22815 := by
  intro p hp
  have h : env22815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22814_22815 : H12AffineEnvironment.transform 10 80 env22814 = env22815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env22814 == env22815) = true)

def env22816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,4160,318549,120014,29790,8328,64,10588,123026,102878,360790,9344,384394,257,29821,38360,66391]

theorem envBound22816 : H12AffineFastState.Bounded env22816 := by
  intro p hp
  have h : env22816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22790_22816 : H12AffineEnvironment.transform 16 38297 env22790 = env22816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env22790 == env22816) = true)

theorem identity22816 : scanCanonicalize (H12AffineFastState.compose env22816 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound22816 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,38297,262144,1025,32769,4160,318549,8525,29790,8328,64,10588,5393,25693,292053,9344,272393,257,29821,38360,63188]

theorem envBound22817 : H12AffineFastState.Bounded env22817 := by
  intro p hp
  have h : env22817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22816_22817 : H12AffineEnvironment.transform 15 62851 env22816 = env22817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env22816 == env22817) = true)

def env22818 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,38161,262144,1025,32769,4160,318549,8525,29790,8192,64,10588,5393,25693,291933,9224,272393,257,29821,38224,63068]

theorem envBound22818 : H12AffineFastState.Bounded env22818 := by
  intro p hp
  have h : env22818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22817_22818 : H12AffineEnvironment.transform 6 8 env22817 = env22818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22817 == env22818) = true)

theorem identity22818 : scanCanonicalize (H12AffineFastState.compose env22818 (packedSelected [1,10,14,19,28,35] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22818 : packedSelected [1,10,14,19,28,35] rootPS < 2^1333 := by decide +kernel

def env22819 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,54358,38161,262144,1025,32769,4160,318549,16,21763,349,64,2049,5393,17664,283904,1365,264532,257,21792,38224,55041]

theorem envBound22819 : H12AffineFastState.Bounded env22819 := by
  intro p hp
  have h : env22819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22818_22819 : H12AffineEnvironment.transform 12 349 env22818 = env22819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22818 == env22819) = true)

theorem identity22819 : scanCanonicalize (H12AffineFastState.compose env22819 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound22819 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22820 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,342,16401,262144,1025,21761,4160,264533,16,21763,349,64,2049,5393,17664,283904,1365,264532,257,21792,16464,513]

theorem envBound22820 : H12AffineFastState.Bounded env22820 := by
  intro p hp
  have h : env22820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22819_22820 : H12AffineEnvironment.transform 14 21760 env22819 = env22820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env22819 == env22820) = true)

theorem identity22820 : scanCanonicalize (H12AffineFastState.compose env22820 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound22820 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22821 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21760,342,16401,23668,1025,21761,4160,21793,16,21763,349,64,2049,5393,17664,2420,1365,21792,257,21792,16464,513]

theorem envBound22821 : H12AffineFastState.Bounded env22821 := by
  intro p hp
  have h : env22821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22820_22821 : H12AffineEnvironment.transform 17 23668 env22820 = env22821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env22820 == env22821) = true)

theorem identity22821 : scanCanonicalize (H12AffineFastState.compose env22821 (packedSelected [2,5,8,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 3172) := by decide +kernel

theorem selectedBound22821 : packedSelected [2,5,8,11,12] rootPS < 2^1333 := by decide +kernel

def env22822 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,3172,6500,342,3189,4112,1025,6501,4160,6469,16,6503,349,64,2049,5393,2404,2420,1365,6468,257,6468,3124,513]

theorem envBound22822 : H12AffineFastState.Bounded env22822 := by
  intro p hp
  have h : env22822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22821_22822 : H12AffineEnvironment.transform 13 3172 env22821 = env22822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3172 env22821 == env22822) = true)

theorem identity22822 : scanCanonicalize (H12AffineFastState.compose env22822 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound22822 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env22823 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,3172,6160,34,3189,4112,1025,6161,4160,6193,16,6163,41,64,2049,5221,2064,2048,1057,6192,117,6192,3124,513]

theorem envBound22823 : H12AffineFastState.Bounded env22823 := by
  intro p hp
  have h : env22823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22822_22823 : H12AffineEnvironment.transform 7 116 env22822 = env22823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env22822 == env22823) = true)

theorem identity22823 : scanCanonicalize (H12AffineFastState.compose env22823 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22823 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env22824 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,3125,6160,34,3108,4112,1025,6161,4113,6193,16,6163,41,17,2049,5172,2064,2048,1057,6192,36,6192,3124,513]

theorem envBound22824 : H12AffineFastState.Bounded env22824 := by
  intro p hp
  have h : env22824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22823_22824 : H12AffineEnvironment.transform 5 17 env22823 = env22824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22823 == env22824) = true)

theorem identity22824 : scanCanonicalize (H12AffineFastState.compose env22824 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound22824 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env22825 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,3108,41,3125,1076,34,3108,3124,1025,1077,3125,1045,16,1079,41,17,2049,2064,2064,2048,1057,1044,36,1044,3124,513]

theorem envBound22825 : H12AffineFastState.Bounded env22825 := by
  intro p hp
  have h : env22825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22824_22825 : H12AffineEnvironment.transform 11 3108 env22824 = env22825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env22824 == env22825) = true)

def env22826 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,38160,262144,1025,32769,4160,318549,8525,29790,8193,64,10588,5393,25693,291932,9225,272393,257,29821,38225,63069]

theorem envBound22826 : H12AffineFastState.Bounded env22826 := by
  intro p hp
  have h : env22826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22817_22826 : H12AffineEnvironment.transform 6 9 env22817 = env22826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22817 == env22826) = true)

theorem identity22826 : scanCanonicalize (H12AffineFastState.compose env22826 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound22826 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env22827 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,24908,262144,1025,29789,4160,272393,8525,29790,8193,64,10588,5393,25693,291932,9225,272393,257,29821,24845,513]

theorem envBound22827 : H12AffineFastState.Bounded env22827 := by
  intro p hp
  have h : env22827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22826_22827 : H12AffineEnvironment.transform 14 29788 env22826 = env22827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env22826 == env22827) = true)

theorem identity22827 : scanCanonicalize (H12AffineFastState.compose env22827 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11576) := by decide +kernel

theorem selectedBound22827 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22828 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,24908,11576,1025,29789,4160,1329,8525,29790,8193,64,10588,5393,25693,22884,9225,1329,257,29821,24845,513]

theorem envBound22828 : H12AffineFastState.Bounded env22828 := by
  intro p hp
  have h : env22828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22827_22828 : H12AffineEnvironment.transform 17 11576 env22827 = env22828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11576 env22827 == env22828) = true)

theorem identity22828 : scanCanonicalize (H12AffineFastState.compose env22828 (packedSelected [0,2,6,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound22828 : packedSelected [0,2,6,7,20] rootPS < 2^1333 := by decide +kernel

def env22829 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,342,5392,11576,1025,1,4160,1329,8525,2,8193,64,10588,5393,4097,11576,9225,1329,257,33,5457,513]

theorem envBound22829 : H12AffineFastState.Bounded env22829 := by
  intro p hp
  have h : env22829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22828_22829 : H12AffineEnvironment.transform 13 13404 env22828 = env22829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env22828 == env22829) = true)

theorem identity22829 : scanCanonicalize (H12AffineFastState.compose env22829 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound22829 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22830 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,4113,0,342,5392,2421,1025,1,4160,1329,1280,2,1100,64,3345,5393,4097,2421,68,1329,257,33,5457,513]

theorem envBound22830 : H12AffineFastState.Bounded env22830 := by
  intro p hp
  have h : env22830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22829_22830 : H12AffineEnvironment.transform 12 1101 env22829 = env22830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env22829 == env22830) = true)

theorem identity22830 : scanCanonicalize (H12AffineFastState.compose env22830 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22830 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22831 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,349,4113,0,342,4096,2421,273,1,4160,33,16,2,348,64,2049,4097,4097,2421,68,33,257,33,4161,513]

theorem envBound22831 : H12AffineFastState.Bounded env22831 := by
  intro p hp
  have h : env22831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22830_22831 : H12AffineEnvironment.transform 9 272 env22830 = env22831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22830 == env22831) = true)

theorem identity22831 : scanCanonicalize (H12AffineFastState.compose env22831 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22831 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22832 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,40,4113,0,35,4096,2048,100,1,4160,33,16,2,41,64,2049,4097,4097,2048,68,33,116,33,4161,513]

theorem envBound22832 : H12AffineFastState.Bounded env22832 := by
  intro p hp
  have h : env22832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22831_22832 : H12AffineEnvironment.transform 7 117 env22831 = env22832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22831 == env22832) = true)

theorem identity22832 : scanCanonicalize (H12AffineFastState.compose env22832 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound22832 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22833 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,65,40,80,0,35,65,2048,100,1,1,33,16,2,41,64,2049,64,64,2048,68,33,116,33,0,513]

theorem envBound22833 : H12AffineFastState.Bounded env22833 := by
  intro p hp
  have h : env22833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22832_22833 : H12AffineEnvironment.transform 11 65 env22832 = env22833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env22832 == env22833) = true)

theorem identity22833 : scanCanonicalize (H12AffineFastState.compose env22833 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound22833 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22834 : List Nat := [2,4,8,16,32,64,9,117,512,101,80,65,40,80,0,35,65,80,100,1,1,33,16,2,41,64,81,64,64,80,68,33,116,33,0,513]

theorem envBound22834 : H12AffineFastState.Bounded env22834 := by
  intro p hp
  have h : env22834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22833_22834 : H12AffineEnvironment.transform 10 80 env22833 = env22834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env22833 == env22834) = true)

theorem identity22834 : scanCanonicalize (H12AffineFastState.compose env22834 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound22834 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22835 : List Nat := [2,4,8,16,10,64,9,95,512,79,80,65,2,80,0,9,65,80,78,1,1,11,16,2,3,64,81,64,64,80,68,11,94,11,0,513]

theorem envBound22835 : H12AffineFastState.Bounded env22835 := by
  intro p hp
  have h : env22835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22834_22835 : H12AffineEnvironment.transform 4 10 env22834 = env22835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env22834 == env22835) = true)

theorem identity22835 : scanCanonicalize (H12AffineFastState.compose env22835 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22835 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env22836 : List Nat := [2,4,8,16,10,16,9,15,512,31,0,17,2,0,0,9,17,0,30,1,1,11,16,2,3,16,1,16,16,0,20,11,14,11,0,513]

theorem envBound22836 : H12AffineFastState.Bounded env22836 := by
  intro p hp
  have h : env22836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22835_22836 : H12AffineEnvironment.transform 5 16 env22835 = env22836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22835 == env22836) = true)

def env22837 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,412109,213335,16777216,8328,64,16959642,18973836,2298887,360790,16958791,19344396,257,19039738,19031135,17031824]

theorem envBound22837 : H12AffineFastState.Bounded env22837 := by
  intro p hp
  have h : env22837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22748_22837 : H12AffineEnvironment.transform 21 412109 env22748 = env22837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 412109 env22748 == env22837) = true)

def env22838 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165336,412109,213335,16777216,8328,64,16959642,16974164,102879,360790,16958791,17148372,257,16777250,16834951,17031824]

theorem envBound22838 : H12AffineFastState.Bounded env22838 := by
  intro p hp
  have h : env22838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22837_22838 : H12AffineEnvironment.transform 20 165336 env22837 = env22838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165336 env22837 == env22838) = true)

theorem identity22838 : scanCanonicalize (H12AffineFastState.compose env22838 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound22838 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env22839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115870,329867,17,16777216,8328,64,16878044,16793618,102879,360790,16876545,17148372,257,16777250,16834951,16819158]

theorem envBound22839 : H12AffineFastState.Bounded env22839 := by
  intro p hp
  have h : env22839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22838_22839 : H12AffineEnvironment.transform 16 82246 env22838 = env22839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env22838 == env22839) = true)

def env22840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115870,329867,17,95496,8328,64,64724,79130,102879,360790,61705,318684,257,95530,103567,120542]

theorem envBound22840 : H12AffineFastState.Bounded env22840 := by
  intro p hp
  have h : env22840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22839_22840 : H12AffineEnvironment.transform 23 95496 env22839 = env22840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env22839 == env22840) = true)

def env22841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115734,329731,17,95496,8192,64,64604,79130,102743,360790,61705,318548,257,95530,103431,120406]

theorem envBound22841 : H12AffineFastState.Bounded env22841 := by
  intro p hp
  have h : env22841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22840_22841 : H12AffineEnvironment.transform 6 8 env22840 = env22841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22840 == env22841) = true)

theorem identity22841 : scanCanonicalize (H12AffineFastState.compose env22841 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound22841 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,130174,1025,32769,115734,62589,17,95496,8192,64,64604,79130,102743,32040,61705,73770,257,95530,103431,120406]

theorem envBound22842 : H12AffineFastState.Bounded env22842 := by
  intro p hp
  have h : env22842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22841_22842 : H12AffineEnvironment.transform 17 130174 env22841 = env22842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env22841 == env22842) = true)

theorem identity22842 : scanCanonicalize (H12AffineFastState.compose env22842 (packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22842 : packedSelected [1,2,3,6,8,11,12,14,19,20,24] rootPS < 2^1333 := by decide +kernel

def env22843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,65536,82246,122227,1025,32769,115734,54640,17,87045,269,64,56657,70679,102743,23589,53252,65831,257,87079,103431,120406]

theorem envBound22843 : H12AffineFastState.Bounded env22843 := by
  intro p hp
  have h : env22843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22842_22843 : H12AffineEnvironment.transform 12 269 env22842 = env22843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22842 == env22843) = true)

theorem identity22843 : scanCanonicalize (H12AffineFastState.compose env22843 (packedSelected [1,2,4,6,8,16,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22843 : packedSelected [1,2,4,6,8,16,19,22] rootPS < 2^1333 := by decide +kernel

def env22844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,65536,82246,89458,1025,0,82967,21873,17,87045,269,64,23888,70679,69974,23589,20485,65831,257,87079,70662,87639]

theorem envBound22844 : H12AffineFastState.Bounded env22844 := by
  intro p hp
  have h : env22844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22843_22844 : H12AffineEnvironment.transform 14 1 env22843 = env22844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22843 == env22844) = true)

theorem identity22844 : scanCanonicalize (H12AffineFastState.compose env22844 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound22844 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,1,21510,5440,2420,1025,0,4113,21873,17,3,269,64,23888,16401,17744,23589,20485,21793,257,33,16384,593]

theorem envBound22845 : H12AffineFastState.Bounded env22845 := by
  intro p hp
  have h : env22845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22844_22845 : H12AffineEnvironment.transform 15 21510 env22844 = env22845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env22844 == env22845) = true)

theorem identity22845 : scanCanonicalize (H12AffineFastState.compose env22845 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound22845 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env22846 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,269,16384,1,19479,3409,2420,1025,0,2048,19808,17,3,269,64,17729,16401,17744,17460,18452,19760,257,33,16384,593]

theorem envBound22846 : H12AffineFastState.Bounded env22846 := by
  intro p hp
  have h : env22846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22845_22846 : H12AffineEnvironment.transform 11 2065 env22845 = env22846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env22845 == env22846) = true)

theorem identity22846 : scanCanonicalize (H12AffineFastState.compose env22846 (packedSelected [2,4,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound22846 : packedSelected [2,4,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22847 : List Nat := [2,4,8,16,32,64,8,256,512,1024,112,97,269,16384,1,17511,1313,260,1025,0,112,17680,17,3,269,64,17729,16401,17744,17460,16484,17728,257,33,16384,593]

theorem envBound22847 : H12AffineFastState.Bounded env22847 := by
  intro p hp
  have h : env22847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22846_22847 : H12AffineEnvironment.transform 10 112 env22846 = env22847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env22846 == env22847) = true)

theorem identity22847 : scanCanonicalize (H12AffineFastState.compose env22847 (packedSelected [0,2,3,4,5,6,12] rootPS)) = affineNative (2^(13+1) ^^^ 261) := by decide +kernel

theorem selectedBound22847 : packedSelected [0,2,3,4,5,6,12] rootPS < 2^1333 := by decide +kernel

def env22848 : List Nat := [2,4,8,16,32,64,8,256,512,1024,112,97,269,261,1,1378,1313,260,1025,0,112,1045,17,3,269,64,1092,276,1109,1329,353,1093,257,33,261,593]

theorem envBound22848 : H12AffineFastState.Bounded env22848 := by
  intro p hp
  have h : env22848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22847_22848 : H12AffineEnvironment.transform 13 261 env22847 = env22848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 261 env22847 == env22848) = true)

theorem identity22848 : scanCanonicalize (H12AffineFastState.compose env22848 (packedSelected [0,1,2,3,4,5,6,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound22848 : packedSelected [0,1,2,3,4,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env22849 : List Nat := [2,4,8,16,32,64,8,256,512,101,112,97,269,261,1,263,324,260,100,0,112,112,17,3,269,64,33,276,48,340,353,32,257,33,261,593]

theorem envBound22849 : H12AffineFastState.Bounded env22849 := by
  intro p hp
  have h : env22849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22848_22849 : H12AffineEnvironment.transform 9 101 env22848 = env22849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env22848 == env22849) = true)

theorem identity22849 : scanCanonicalize (H12AffineFastState.compose env22849 (packedSelected [1,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound22849 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env22850 : List Nat := [2,4,8,16,32,10,8,256,512,47,58,43,269,261,1,263,270,260,46,0,58,58,17,3,269,10,33,276,48,286,299,32,257,33,261,539]

theorem envBound22850 : H12AffineFastState.Bounded env22850 := by
  intro p hp
  have h : env22850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22849_22850 : H12AffineEnvironment.transform 5 10 env22849 = env22850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env22849 == env22850) = true)

theorem identity22850 : scanCanonicalize (H12AffineFastState.compose env22850 (packedSelected [0,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22850 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env22851 : List Nat := [2,4,8,0,32,10,8,256,512,47,42,43,269,261,1,263,270,260,46,0,42,42,1,3,269,10,33,260,32,270,299,32,257,33,261,523]

theorem envBound22851 : H12AffineFastState.Bounded env22851 := by
  intro p hp
  have h : env22851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22850_22851 : H12AffineEnvironment.transform 3 0 env22850 = env22851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22850 == env22851) = true)

theorem identity22851 : scanCanonicalize (H12AffineFastState.compose env22851 (packedSelected [1,2,5] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22851 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env22852 : List Nat := [2,4,3,0,32,1,3,256,512,36,33,32,262,261,1,263,261,260,37,0,33,33,1,3,262,1,33,260,32,261,288,32,257,33,261,512]

theorem envBound22852 : H12AffineFastState.Bounded env22852 := by
  intro p hp
  have h : env22852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22851_22852 : H12AffineEnvironment.transform 2 3 env22851 = env22852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22851 == env22852) = true)

theorem identity22852 : scanCanonicalize (H12AffineFastState.compose env22852 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 294) := by decide +kernel

theorem selectedBound22852 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env22853 : List Nat := [2,4,3,0,32,1,3,256,294,36,33,32,262,261,1,263,261,260,37,0,33,33,1,3,262,1,33,260,32,261,288,32,257,33,261,294]

theorem envBound22853 : H12AffineFastState.Bounded env22853 := by
  intro p hp
  have h : env22853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22852_22853 : H12AffineEnvironment.transform 8 294 env22852 = env22853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 294 env22852 == env22853) = true)

theorem identity22853 : scanCanonicalize (H12AffineFastState.compose env22853 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22853 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22854 : List Nat := [2,4,3,0,1,1,3,256,263,5,0,1,262,261,1,263,261,260,4,0,0,0,1,3,262,1,0,260,1,261,257,1,257,0,261,263]

theorem envBound22854 : H12AffineFastState.Bounded env22854 := by
  intro p hp
  have h : env22854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22853_22854 : H12AffineEnvironment.transform 4 1 env22853 = env22854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22853 == env22854) = true)

def env22855 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115735,329730,17,95496,8193,64,64605,79130,102742,360790,61705,318549,257,95530,103430,120407]

theorem envBound22855 : H12AffineFastState.Bounded env22855 := by
  intro p hp
  have h : env22855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22840_22855 : H12AffineEnvironment.transform 6 9 env22840 = env22855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22840 == env22855) = true)

theorem identity22855 : scanCanonicalize (H12AffineFastState.compose env22855 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound22855 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,89378,1025,32769,115735,21792,17,95496,8193,64,64605,79130,102742,56436,61705,98679,257,95530,103430,120407]

theorem envBound22856 : H12AffineFastState.Bounded env22856 := by
  intro p hp
  have h : env22856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22855_22856 : H12AffineEnvironment.transform 17 89378 env22855 = env22856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env22855 == env22856) = true)

theorem identity22856 : scanCanonicalize (H12AffineFastState.compose env22856 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22856 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env22857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,89378,1025,32769,115735,21792,17,87124,349,64,56577,70726,102742,56436,53333,98679,257,87158,103430,120407]

theorem envBound22857 : H12AffineFastState.Bounded env22857 := by
  intro p hp
  have h : env22857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22856_22857 : H12AffineEnvironment.transform 12 348 env22856 = env22857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22856 == env22857) = true)

theorem identity22857 : scanCanonicalize (H12AffineFastState.compose env22857 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound22857 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env22858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,21591,5393,2421,1025,32769,36928,21792,17,3,349,64,56577,16401,50433,56436,53333,54560,257,33,49233,33280]

theorem envBound22858 : H12AffineFastState.Bounded env22858 := by
  intro p hp
  have h : env22858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22857_22858 : H12AffineEnvironment.transform 15 21591 env22857 = env22858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env22857 == env22858) = true)

theorem identity22858 : scanCanonicalize (H12AffineFastState.compose env22858 (packedSelected [4,9,12,14,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22858 : packedSelected [4,9,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env22859 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,32768,21591,5220,2048,1025,32769,36928,21589,17,3,40,64,56436,16401,50292,56436,53333,54357,116,33,49233,33280]

theorem envBound22859 : H12AffineFastState.Bounded env22859 := by
  intro p hp
  have h : env22859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22858_22859 : H12AffineEnvironment.transform 7 117 env22858 = env22859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22858 == env22859) = true)

theorem identity22859 : scanCanonicalize (H12AffineFastState.compose env22859 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound22859 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22860 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,21621,21591,5220,2048,1025,21620,17461,21589,17,3,40,64,2049,16401,4097,2049,1056,32,116,33,5156,22133]

theorem envBound22860 : H12AffineFastState.Bounded env22860 := by
  intro p hp
  have h : env22860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22859_22860 : H12AffineEnvironment.transform 14 21621 env22859 = env22860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env22859 == env22860) = true)

theorem identity22860 : scanCanonicalize (H12AffineFastState.compose env22860 (packedSelected [4,6,9,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound22860 : packedSelected [4,6,9,12] rootPS < 2^1333 := by decide +kernel

def env22861 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,0,34,5220,2048,1025,1,4160,32,17,3,40,64,2049,5220,4097,2049,1056,32,116,33,5156,512]

theorem envBound22861 : H12AffineFastState.Bounded env22861 := by
  intro p hp
  have h : env22861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22860_22861 : H12AffineEnvironment.transform 13 5237 env22860 = env22861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env22860 == env22861) = true)

theorem identity22861 : scanCanonicalize (H12AffineFastState.compose env22861 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound22861 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22862 : List Nat := [2,4,8,16,32,64,9,117,512,1024,555,4096,41,5237,0,34,5220,555,1025,1,4160,32,17,3,40,64,554,5220,4097,554,1056,32,116,33,5156,512]

theorem envBound22862 : H12AffineFastState.Bounded env22862 := by
  intro p hp
  have h : env22862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22861_22862 : H12AffineEnvironment.transform 10 555 env22861 = env22862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env22861 == env22862) = true)

theorem identity22862 : scanCanonicalize (H12AffineFastState.compose env22862 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound22862 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22863 : List Nat := [2,4,8,16,32,49,9,4,512,1024,555,4096,41,5124,0,34,5141,555,1025,1,4145,32,17,3,40,49,554,5141,4097,554,1056,32,5,33,5156,512]

theorem envBound22863 : H12AffineFastState.Bounded env22863 := by
  intro p hp
  have h : env22863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22862_22863 : H12AffineEnvironment.transform 5 49 env22862 = env22863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env22862 == env22863) = true)

theorem identity22863 : scanCanonicalize (H12AffineFastState.compose env22863 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22863 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env22864 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,4096,8,5124,0,3,5141,522,1025,1,4112,1,17,3,9,16,523,5141,4097,523,1025,1,5,0,5125,512]

theorem envBound22864 : H12AffineFastState.Bounded env22864 := by
  intro p hp
  have h : env22864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22863_22864 : H12AffineEnvironment.transform 4 1 env22863 = env22864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22863 == env22864) = true)

def env22865 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,16,8,1044,0,3,1029,522,1025,1,0,1,17,3,9,16,523,1029,17,523,1025,1,5,0,1045,512]

theorem envBound22865 : H12AffineFastState.Bounded env22865 := by
  intro p hp
  have h : env22865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22864_22865 : H12AffineEnvironment.transform 11 16 env22864 = env22865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22864 == env22865) = true)

theorem identity22865 : scanCanonicalize (H12AffineFastState.compose env22865 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound22865 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22866 : List Nat := [2,4,8,5,1,5,9,4,512,1024,522,5,8,1025,0,3,1029,522,1025,1,0,1,4,3,9,5,523,1029,4,523,1025,1,5,0,1024,512]

theorem envBound22866 : H12AffineFastState.Bounded env22866 := by
  intro p hp
  have h : env22866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22865_22866 : H12AffineEnvironment.transform 3 5 env22865 = env22866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env22865 == env22866) = true)

def env22867 : List Nat := [2,4,8,5,1,5,9,4,512,0,522,5,8,1,0,3,5,522,1,1,0,1,4,3,9,5,523,5,4,523,1,1,5,0,0,512]

theorem envBound22867 : H12AffineFastState.Bounded env22867 := by
  intro p hp
  have h : env22867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22866_22867 : H12AffineEnvironment.transform 9 0 env22866 = env22867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env22866 == env22867) = true)

theorem identity22867 : scanCanonicalize (H12AffineFastState.compose env22867 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22867 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22868 : List Nat := [1,4,8,5,1,5,9,4,512,0,521,5,8,1,0,0,5,521,1,1,0,1,4,0,9,5,520,5,4,520,1,1,5,0,0,512]

theorem envBound22868 : H12AffineFastState.Bounded env22868 := by
  intro p hp
  have h : env22868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22867_22868 : H12AffineEnvironment.transform 0 1 env22867 = env22868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22867 == env22868) = true)

def leafEnv22868 : List Nat := [1,4,8,5,1,5,9,4,512,0,521,5,8,1,0,0,5,521,1,1,0,1,4,0,1,9,1,5,520,5,4,520,1,1,5,0,4,1,0,512,1,1,0]

def active22868 : List Nat := [1,2,8]

def tree22868 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22868 : H12WitnessSearch.Good tree22868 := H12GlobalWitnessIndex.good

theorem leafIdentity22868 : H12AffineFastState.composeSystem env22868 rootObs = leafEnv22868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22868 rootObs == leafEnv22868) = true)

theorem terminalChecked22868 : H12PackedTerminal.terminalCheckFast leafEnv22868 active22868 tree22868 = true := by decide +kernel

def env22869 : List Nat := [2,4,8,5,1,5,9,4,512,1,522,5,8,0,0,3,4,522,0,1,0,1,4,3,9,5,523,4,4,523,0,1,5,0,1,512]

theorem envBound22869 : H12AffineFastState.Bounded env22869 := by
  intro p hp
  have h : env22869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22866_22869 : H12AffineEnvironment.transform 9 1 env22866 = env22869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env22866 == env22869) = true)

theorem identity22869 : scanCanonicalize (H12AffineFastState.compose env22869 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound22869 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22870 : List Nat := [2,4,8,5,1,5,9,4,9,1,3,5,8,0,0,3,4,3,0,1,0,1,4,3,9,5,2,4,4,2,0,1,5,0,1,9]

theorem envBound22870 : H12AffineFastState.Bounded env22870 := by
  intro p hp
  have h : env22870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22869_22870 : H12AffineEnvironment.transform 8 9 env22869 = env22870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env22869 == env22870) = true)

def leafEnv22870 : List Nat := [2,4,8,5,1,5,9,4,9,1,3,5,8,0,0,3,4,3,0,1,0,1,4,3,0,9,1,5,2,4,4,2,0,1,5,0,4,2,1,9,1,1,0]

def active22870 : List Nat := [0,1,2]

def tree22870 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22870 : H12WitnessSearch.Good tree22870 := H12GlobalWitnessIndex.good

theorem leafIdentity22870 : H12AffineFastState.composeSystem env22870 rootObs = leafEnv22870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22870 rootObs == leafEnv22870) = true)

theorem terminalChecked22870 : H12PackedTerminal.terminalCheckFast leafEnv22870 active22870 tree22870 = true := by decide +kernel

def env22871 : List Nat := [2,4,8,16,1,16,9,4,512,1024,522,17,8,1045,0,3,1028,522,1025,1,1,1,17,3,9,16,523,1028,16,523,1025,1,5,0,1044,512]

theorem envBound22871 : H12AffineFastState.Bounded env22871 := by
  intro p hp
  have h : env22871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22864_22871 : H12AffineEnvironment.transform 11 17 env22864 = env22871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env22864 == env22871) = true)

theorem identity22871 : scanCanonicalize (H12AffineFastState.compose env22871 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 1) := by decide +kernel

theorem selectedBound22871 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22872 : List Nat := [2,4,8,16,1,16,9,4,512,1,522,17,8,20,0,3,5,522,0,1,1,1,17,3,9,16,523,5,16,523,0,1,5,0,21,512]

theorem envBound22872 : H12AffineFastState.Bounded env22872 := by
  intro p hp
  have h : env22872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22871_22872 : H12AffineEnvironment.transform 9 1 env22871 = env22872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env22871 == env22872) = true)

def env22873 : List Nat := [2,4,8,4,1,4,9,4,512,1,522,5,8,0,0,3,5,522,0,1,1,1,5,3,9,4,523,5,4,523,0,1,5,0,1,512]

theorem envBound22873 : H12AffineFastState.Bounded env22873 := by
  intro p hp
  have h : env22873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22872_22873 : H12AffineEnvironment.transform 3 4 env22872 = env22873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env22872 == env22873) = true)

theorem identity22873 : scanCanonicalize (H12AffineFastState.compose env22873 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22873 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22874 : List Nat := [1,4,8,4,1,4,9,4,512,1,521,5,8,0,0,0,5,521,0,1,1,1,5,0,9,4,520,5,4,520,0,1,5,0,1,512]

theorem envBound22874 : H12AffineFastState.Bounded env22874 := by
  intro p hp
  have h : env22874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22873_22874 : H12AffineEnvironment.transform 0 1 env22873 = env22874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22873 == env22874) = true)

def leafEnv22874 : List Nat := [1,4,8,4,1,4,9,4,512,1,521,5,8,0,0,0,5,521,0,1,1,1,5,0,0,9,1,4,520,5,4,520,0,1,5,0,4,1,1,512,1,0,0]

def active22874 : List Nat := [1,2,8]

def tree22874 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22874 : H12WitnessSearch.Good tree22874 := H12GlobalWitnessIndex.good

theorem leafIdentity22874 : H12AffineFastState.composeSystem env22874 rootObs = leafEnv22874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22874 rootObs == leafEnv22874) = true)

theorem terminalChecked22874 : H12PackedTerminal.terminalCheckFast leafEnv22874 active22874 tree22874 = true := by decide +kernel

def env22875 : List Nat := [2,4,8,5,1,5,9,4,512,1,522,4,8,1,0,3,5,522,0,1,1,1,4,3,9,5,523,5,5,523,0,1,5,0,0,512]

theorem envBound22875 : H12AffineFastState.Bounded env22875 := by
  intro p hp
  have h : env22875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22872_22875 : H12AffineEnvironment.transform 3 5 env22872 = env22875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env22872 == env22875) = true)

theorem identity22875 : scanCanonicalize (H12AffineFastState.compose env22875 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound22875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22876 : List Nat := [2,4,8,5,1,5,9,4,8,1,2,4,8,1,0,3,5,2,0,1,1,1,4,3,9,5,3,5,5,3,0,1,5,0,0,8]

theorem envBound22876 : H12AffineFastState.Bounded env22876 := by
  intro p hp
  have h : env22876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22875_22876 : H12AffineEnvironment.transform 8 8 env22875 = env22876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env22875 == env22876) = true)

def leafEnv22876 : List Nat := [2,4,8,5,1,5,9,4,8,1,2,4,8,1,0,3,5,2,0,1,1,1,4,3,0,9,1,5,3,5,5,3,0,1,5,0,4,2,0,8,1,0,0]

def active22876 : List Nat := [0,1,2]

def tree22876 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood22876 : H12WitnessSearch.Good tree22876 := H12GlobalWitnessIndex.good

theorem leafIdentity22876 : H12AffineFastState.composeSystem env22876 rootObs = leafEnv22876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env22876 rootObs == leafEnv22876) = true)

theorem terminalChecked22876 : H12PackedTerminal.terminalCheckFast leafEnv22876 active22876 tree22876 = true := by decide +kernel

def env22877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,115870,329867,17,95497,8328,64,64725,79131,102879,360790,61704,318685,257,95531,103566,120543]

theorem envBound22877 : H12AffineFastState.Bounded env22877 := by
  intro p hp
  have h : env22877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22839_22877 : H12AffineEnvironment.transform 23 95497 env22839 = env22877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env22839 == env22877) = true)

theorem identity22877 : scanCanonicalize (H12AffineFastState.compose env22877 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound22877 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,38296,262144,1025,32769,4160,318549,17,41431,8328,64,64725,57797,17665,284040,61704,318685,257,41461,16464,513]

theorem envBound22878 : H12AffineFastState.Bounded env22878 := by
  intro p hp
  have h : env22878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22877_22878 : H12AffineEnvironment.transform 15 54494 env22877 = env22878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env22877 == env22878) = true)

def env22879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,262144,1025,32769,4160,318549,17,41311,8192,64,64605,57677,17665,283904,61704,318549,257,41341,16464,513]

theorem envBound22879 : H12AffineFastState.Bounded env22879 := by
  intro p hp
  have h : env22879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22878_22879 : H12AffineEnvironment.transform 6 8 env22878 = env22879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22878 == env22879) = true)

theorem identity22879 : scanCanonicalize (H12AffineFastState.compose env22879 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound22879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,38160,10281,1025,32769,4160,62588,17,41311,8192,64,64605,57677,17665,32041,61704,62588,257,41341,16464,513]

theorem envBound22880 : H12AffineFastState.Bounded env22880 := by
  intro p hp
  have h : env22880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22879_22880 : H12AffineEnvironment.transform 17 10281 env22879 = env22880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env22879 == env22880) = true)

theorem identity22880 : scanCanonicalize (H12AffineFastState.compose env22880 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound22880 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env22881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,38160,10281,1025,32769,4160,41341,17,41311,8192,64,43356,46156,4096,10280,41993,41341,257,41341,5457,513]

theorem envBound22881 : H12AffineFastState.Bounded env22881 := by
  intro p hp
  have h : env22881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22880_22881 : H12AffineEnvironment.transform 13 5377 env22880 = env22881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env22880 == env22881) = true)

theorem identity22881 : scanCanonicalize (H12AffineFastState.compose env22881 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound22881 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env22882 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,32768,32802,37989,10281,1025,32769,4160,40968,17,41002,8192,64,43049,46156,4096,10280,41993,40968,116,40968,5156,513]

theorem envBound22882 : H12AffineFastState.Bounded env22882 := by
  intro p hp
  have h : env22882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22881_22882 : H12AffineEnvironment.transform 7 117 env22881 = env22882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env22881 == env22882) = true)

theorem identity22882 : scanCanonicalize (H12AffineFastState.compose env22882 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound22882 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env22883 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,5236,81,115,5172,10281,1025,80,4160,8281,17,8315,8192,64,10360,13341,4096,10280,9304,8281,116,8281,5156,513]

theorem envBound22883 : H12AffineFastState.Bounded env22883 := by
  intro p hp
  have h : env22883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22882_22883 : H12AffineEnvironment.transform 14 81 env22882 = env22883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env22882 == env22883) = true)

theorem identity22883 : scanCanonicalize (H12AffineFastState.compose env22883 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound22883 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env22884 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,5236,81,115,5172,2128,1025,80,4160,32,17,2,121,64,2049,5220,4096,2129,1057,32,116,32,5156,513]

theorem envBound22884 : H12AffineFastState.Bounded env22884 := by
  intro p hp
  have h : env22884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22883_22884 : H12AffineEnvironment.transform 12 121 env22883 = env22884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env22883 == env22884) = true)

theorem identity22884 : scanCanonicalize (H12AffineFastState.compose env22884 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound22884 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env22885 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,16,121,1124,81,115,1060,2128,1025,80,80,32,17,2,121,64,2049,1140,16,2129,1057,32,116,32,1076,513]

theorem envBound22885 : H12AffineFastState.Bounded env22885 := by
  intro p hp
  have h : env22885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22884_22885 : H12AffineEnvironment.transform 11 16 env22884 = env22885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22884 == env22885) = true)

theorem identity22885 : scanCanonicalize (H12AffineFastState.compose env22885 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound22885 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env22886 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1125,16,121,1124,81,115,1060,1077,1025,80,80,32,17,2,121,64,1124,1140,16,1076,1057,32,116,32,1076,513]

theorem envBound22886 : H12AffineFastState.Bounded env22886 := by
  intro p hp
  have h : env22886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22885_22886 : H12AffineEnvironment.transform 10 1125 env22885 = env22886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env22885 == env22886) = true)

theorem identity22886 : scanCanonicalize (H12AffineFastState.compose env22886 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound22886 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env22887 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,16,40,1077,0,34,1060,1077,1025,1,1,32,17,2,40,17,1077,1061,16,1076,1057,32,37,32,1076,513]

theorem envBound22887 : H12AffineFastState.Bounded env22887 := by
  intro p hp
  have h : env22887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22886_22887 : H12AffineEnvironment.transform 5 17 env22886 = env22887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22886 == env22887) = true)

theorem identity22887 : scanCanonicalize (H12AffineFastState.compose env22887 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound22887 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22888 : List Nat := [2,4,8,1,32,0,8,36,512,1024,1061,1,40,1060,0,34,1060,1060,1025,1,1,32,0,2,40,0,1060,1061,1,1061,1057,32,37,32,1061,513]

theorem envBound22888 : H12AffineFastState.Bounded env22888 := by
  intro p hp
  have h : env22888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22887_22888 : H12AffineEnvironment.transform 3 1 env22887 = env22888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env22887 == env22888) = true)

theorem identity22888 : scanCanonicalize (H12AffineFastState.compose env22888 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 46) := by decide +kernel

theorem selectedBound22888 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22889 : List Nat := [2,4,8,1,32,0,8,36,512,46,11,1,40,10,0,34,10,10,47,1,1,32,0,2,40,0,10,11,1,11,15,32,37,32,11,513]

theorem envBound22889 : H12AffineFastState.Bounded env22889 := by
  intro p hp
  have h : env22889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22888_22889 : H12AffineEnvironment.transform 9 46 env22888 = env22889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 46 env22888 == env22889) = true)

theorem identity22889 : scanCanonicalize (H12AffineFastState.compose env22889 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound22889 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22890 : List Nat := [2,4,8,1,11,0,8,15,512,5,11,1,3,10,0,9,10,10,4,1,1,11,0,2,3,0,10,11,1,11,15,11,14,11,11,513]

theorem envBound22890 : H12AffineFastState.Bounded env22890 := by
  intro p hp
  have h : env22890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22889_22890 : H12AffineEnvironment.transform 4 11 env22889 = env22890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env22889 == env22890) = true)

theorem identity22890 : scanCanonicalize (H12AffineFastState.compose env22890 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound22890 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22891 : List Nat := [2,0,8,1,11,0,8,11,512,1,11,1,3,10,0,9,10,10,0,1,1,11,0,2,3,0,10,11,1,11,11,11,10,11,11,513]

theorem envBound22891 : H12AffineFastState.Bounded env22891 := by
  intro p hp
  have h : env22891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22890_22891 : H12AffineEnvironment.transform 1 0 env22890 = env22891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env22890 == env22891) = true)

theorem identity22891 : scanCanonicalize (H12AffineFastState.compose env22891 (packedSelected [7] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound22891 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22892 : List Nat := [2,0,2,1,1,0,2,1,512,1,1,1,3,0,0,3,0,0,0,1,1,1,0,2,3,0,0,1,1,1,1,1,0,1,1,513]

theorem envBound22892 : H12AffineFastState.Bounded env22892 := by
  intro p hp
  have h : env22892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22891_22892 : H12AffineEnvironment.transform 2 2 env22891 = env22892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env22891 == env22892) = true)

theorem identity22892 : scanCanonicalize (H12AffineFastState.compose env22892 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound22892 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22893 : List Nat := [1,0,1,1,1,0,1,1,512,1,1,1,0,0,0,0,0,0,0,1,1,1,0,1,0,0,0,1,1,1,1,1,0,1,1,513]

theorem envBound22893 : H12AffineFastState.Bounded env22893 := by
  intro p hp
  have h : env22893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22892_22893 : H12AffineEnvironment.transform 0 1 env22892 = env22893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env22892 == env22893) = true)

def env22894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,262144,1025,32769,4160,318549,17,41310,8193,64,64604,57676,17665,283905,61704,318548,257,41340,16464,513]

theorem envBound22894 : H12AffineFastState.Bounded env22894 := by
  intro p hp
  have h : env22894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22878_22894 : H12AffineEnvironment.transform 6 9 env22878 = env22894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22878 == env22894) = true)

theorem identity22894 : scanCanonicalize (H12AffineFastState.compose env22894 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound22894 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,38161,35188,1025,32769,4160,21793,17,41310,8193,64,64604,57676,17665,56437,61704,21792,257,41340,16464,513]

theorem envBound22895 : H12AffineFastState.Bounded env22895 := by
  intro p hp
  have h : env22895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22894_22895 : H12AffineEnvironment.transform 17 35188 env22894 = env22895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env22894 == env22895) = true)

theorem identity22895 : scanCanonicalize (H12AffineFastState.compose env22895 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound22895 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env22896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,9293,28698,12636,11577,1025,9292,4160,21793,17,1299,8193,64,22545,17665,17665,30776,21829,21792,257,1329,16464,513]

theorem envBound22896 : H12AffineFastState.Bounded env22896 := by
  intro p hp
  have h : env22896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22895_22896 : H12AffineEnvironment.transform 14 9293 env22895 = env22896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env22895 == env22896) = true)

theorem identity22896 : scanCanonicalize (H12AffineFastState.compose env22896 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound22896 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env22897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1297,20806,4096,3173,1025,1296,4160,21793,17,1299,349,64,22545,17665,17665,22884,21829,21792,257,1329,16464,513]

theorem envBound22897 : H12AffineFastState.Bounded env22897 := by
  intro p hp
  have h : env22897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22896_22897 : H12AffineEnvironment.transform 12 348 env22896 = env22897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env22896 == env22897) = true)

theorem identity22897 : scanCanonicalize (H12AffineFastState.compose env22897 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22897 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env22898 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,16384,1,20806,4096,2421,273,0,4160,20529,17,3,349,64,22545,16401,16401,22884,20565,20528,257,33,16464,513]

theorem envBound22898 : H12AffineFastState.Bounded env22898 := by
  intro p hp
  have h : env22898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22897_22898 : H12AffineEnvironment.transform 9 272 env22897 = env22898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22897 == env22898) = true)

theorem identity22898 : scanCanonicalize (H12AffineFastState.compose env22898 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound22898 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env22899 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,16,348,16384,1,16726,16,2421,273,0,80,16417,17,3,349,64,18433,16401,16401,18804,16453,16416,257,33,16464,513]

theorem envBound22899 : H12AffineFastState.Bounded env22899 := by
  intro p hp
  have h : env22899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22898_22899 : H12AffineEnvironment.transform 11 16 env22898 = env22899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env22898 == env22899) = true)

theorem identity22899 : scanCanonicalize (H12AffineFastState.compose env22899 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound22899 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env22900 : List Nat := [2,4,8,16,32,64,9,37,512,53,2048,16,121,16384,1,16499,16,2128,52,0,80,16417,17,3,120,64,18433,16401,16401,18513,16453,16416,36,33,16464,513]

theorem envBound22900 : H12AffineFastState.Bounded env22900 := by
  intro p hp
  have h : env22900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22899_22900 : H12AffineEnvironment.transform 7 37 env22899 = env22900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env22899 == env22900) = true)

def env22901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213335,16777216,8328,64,16959642,16974165,102878,360790,16958791,17148373,257,16777251,16834950,17031824]

theorem envBound22901 : H12AffineFastState.Bounded env22901 := by
  intro p hp
  have h : env22901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22837_22901 : H12AffineEnvironment.transform 20 165337 env22837 = env22901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165337 env22837 == env22901) = true)

theorem identity22901 : scanCanonicalize (H12AffineFastState.compose env22901 (packedSelected [1,19,21,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 106625) := by decide +kernel

theorem selectedBound22901 : packedSelected [1,19,21,28,31] rootPS < 2^1333 := by decide +kernel

def env22902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165337,412109,213335,106625,8328,64,223259,172500,102878,360790,222662,264532,257,106658,82183,147985]

theorem envBound22902 : H12AffineFastState.Bounded env22902 := by
  intro p hp
  have h : env22902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22901_22902 : H12AffineEnvironment.transform 23 106625 env22901 = env22902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 106625 env22901 == env22902) = true)

def env22903 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,50633,264669,65863,106625,8328,64,75787,57796,102878,360790,75222,264532,257,106658,82183,513]

theorem envBound22903 : H12AffineFastState.Bounded env22903 := by
  intro p hp
  have h : env22903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22902_22903 : H12AffineEnvironment.transform 16 16400 env22902 = env22903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env22902 == env22903) = true)

theorem identity22903 : scanCanonicalize (H12AffineFastState.compose env22903 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22903 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22904 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,50633,264669,8525,32907,8328,64,2049,57796,45524,303452,1500,264532,257,32936,24845,513]

theorem envBound22904 : H12AffineFastState.Bounded env22904 := by
  intro p hp
  have h : env22904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22903_22904 : H12AffineEnvironment.transform 15 8202 env22903 = env22904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22903 == env22904) = true)

theorem identity22904 : scanCanonicalize (H12AffineFastState.compose env22904 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound22904 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env22905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10401,1025,32769,50633,8572,8525,32907,8328,64,2049,57796,45524,35325,1500,8693,257,32936,24845,513]

theorem envBound22905 : H12AffineFastState.Bounded env22905 := by
  intro p hp
  have h : env22905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22904_22905 : H12AffineEnvironment.transform 17 10401 env22904 = env22905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env22904 == env22905) = true)

theorem identity22905 : scanCanonicalize (H12AffineFastState.compose env22905 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22905 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env22906 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,1,8202,16400,10401,1025,0,17864,8572,8525,138,8328,64,2049,25029,12757,2556,1500,8693,257,169,24845,513]

theorem envBound22906 : H12AffineFastState.Bounded env22906 := by
  intro p hp
  have h : env22906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22905_22906 : H12AffineEnvironment.transform 14 1 env22905 = env22906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22905 == env22906) = true)

theorem identity22906 : scanCanonicalize (H12AffineFastState.compose env22906 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound22906 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env22907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,1,399,16400,2340,1025,0,17864,249,200,138,269,64,2049,16448,4176,2556,1500,112,257,169,16520,513]

theorem envBound22907 : H12AffineFastState.Bounded env22907 := by
  intro p hp
  have h : env22907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22906_22907 : H12AffineEnvironment.transform 12 389 env22906 = env22907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env22906 == env22907) = true)

theorem identity22907 : scanCanonicalize (H12AffineFastState.compose env22907 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22907 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env22908 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,1,399,16400,2340,1025,0,17816,169,152,138,269,16,2049,16400,4096,2476,1420,32,257,169,16520,513]

theorem envBound22908 : H12AffineFastState.Bounded env22908 := by
  intro p hp
  have h : env22908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22907_22908 : H12AffineEnvironment.transform 5 16 env22907 = env22908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22907 == env22908) = true)

theorem identity22908 : scanCanonicalize (H12AffineFastState.compose env22908 (packedSelected [5,7,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3244) := by decide +kernel

theorem selectedBound22908 : packedSelected [5,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22909 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3244,389,16384,1,399,16400,2340,1025,0,17816,169,152,138,269,16,2049,16400,3244,2476,1420,32,257,169,16520,513]

theorem envBound22909 : H12AffineFastState.Bounded env22909 := by
  intro p hp
  have h : env22909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22908_22909 : H12AffineEnvironment.transform 11 3244 env22908 = env22909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3244 env22908 == env22909) = true)

theorem identity22909 : scanCanonicalize (H12AffineFastState.compose env22909 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound22909 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env22910 : List Nat := [2,4,8,16,32,16,128,256,512,189,2048,2065,389,16384,1,399,16400,2340,188,0,16677,169,152,138,269,16,2049,16400,2065,2476,305,32,257,169,16520,513]

theorem envBound22910 : H12AffineFastState.Bounded env22910 := by
  intro p hp
  have h : env22910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22909_22910 : H12AffineEnvironment.transform 9 189 env22909 = env22910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env22909 == env22910) = true)

theorem identity22910 : scanCanonicalize (H12AffineFastState.compose env22910 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22910 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env22911 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2065,269,16384,1,263,16400,2340,52,0,16677,33,16,2,269,16,2049,16400,2065,2340,305,32,257,33,16384,513]

theorem envBound22911 : H12AffineFastState.Bounded env22911 := by
  intro p hp
  have h : env22911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22910_22911 : H12AffineEnvironment.transform 6 8 env22910 = env22911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22910 == env22911) = true)

theorem identity22911 : scanCanonicalize (H12AffineFastState.compose env22911 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound22911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22912 : List Nat := [2,4,8,16,32,16,8,21,512,53,2048,2065,24,16384,1,18,16400,2097,52,0,16432,33,16,2,24,16,2049,16400,2065,2097,36,32,20,33,16384,513]

theorem envBound22912 : H12AffineFastState.Bounded env22912 := by
  intro p hp
  have h : env22912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22911_22912 : H12AffineEnvironment.transform 7 21 env22911 = env22912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env22911 == env22912) = true)

theorem identity22912 : scanCanonicalize (H12AffineFastState.compose env22912 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 513) := by decide +kernel

theorem selectedBound22912 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env22913 : List Nat := [2,4,8,16,32,16,8,21,512,53,2048,2065,24,513,1,18,529,2097,52,0,561,33,16,2,24,16,2049,529,2065,2097,36,32,20,33,513,513]

theorem envBound22913 : H12AffineFastState.Bounded env22913 := by
  intro p hp
  have h : env22913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22912_22913 : H12AffineEnvironment.transform 13 513 env22912 = env22913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 513 env22912 == env22913) = true)

theorem identity22913 : scanCanonicalize (H12AffineFastState.compose env22913 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound22913 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22914 : List Nat := [2,4,8,16,32,16,8,21,512,53,49,32,24,513,1,18,529,0,52,0,561,33,16,2,24,16,48,529,32,0,36,32,20,33,513,513]

theorem envBound22914 : H12AffineFastState.Bounded env22914 := by
  intro p hp
  have h : env22914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22913_22914 : H12AffineEnvironment.transform 10 49 env22913 = env22914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env22913 == env22914) = true)

theorem identity22914 : scanCanonicalize (H12AffineFastState.compose env22914 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound22914 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env22915 : List Nat := [2,4,8,16,1,16,8,21,512,20,16,1,24,513,1,18,529,0,21,0,528,0,16,2,24,16,17,529,1,0,5,1,20,0,513,513]

theorem envBound22915 : H12AffineFastState.Bounded env22915 := by
  intro p hp
  have h : env22915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22914_22915 : H12AffineEnvironment.transform 4 1 env22914 = env22915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env22914 == env22915) = true)

theorem identity22915 : scanCanonicalize (H12AffineFastState.compose env22915 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound22915 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22916 : List Nat := [2,4,8,16,1,16,8,21,16,20,16,1,24,17,1,18,1,0,21,0,0,0,16,2,24,16,17,1,1,0,5,1,20,0,17,17]

theorem envBound22916 : H12AffineFastState.Bounded env22916 := by
  intro p hp
  have h : env22916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22915_22916 : H12AffineEnvironment.transform 8 16 env22915 = env22916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env22915 == env22916) = true)

theorem identity22916 : scanCanonicalize (H12AffineFastState.compose env22916 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22916 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22917 : List Nat := [2,4,3,16,1,16,3,21,16,20,16,1,19,17,1,18,1,0,21,0,0,0,16,2,19,16,17,1,1,0,5,1,20,0,17,17]

theorem envBound22917 : H12AffineFastState.Bounded env22917 := by
  intro p hp
  have h : env22917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22916_22917 : H12AffineEnvironment.transform 2 3 env22916 = env22917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22916 == env22917) = true)

theorem identity22917 : scanCanonicalize (H12AffineFastState.compose env22917 (packedSelected [7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22917 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env22918 : List Nat := [2,4,3,0,1,0,3,5,0,4,0,1,3,1,1,2,1,0,5,0,0,0,0,2,3,0,1,1,1,0,5,1,4,0,1,1]

theorem envBound22918 : H12AffineFastState.Bounded env22918 := by
  intro p hp
  have h : env22918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22917_22918 : H12AffineEnvironment.transform 3 0 env22917 = env22918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22917 == env22918) = true)

def env22919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,50632,264668,65862,106625,8328,64,75786,57797,102878,360790,75223,264532,257,106658,82183,512]

theorem envBound22919 : H12AffineFastState.Bounded env22919 := by
  intro p hp
  have h : env22919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22902_22919 : H12AffineEnvironment.transform 16 16401 env22902 = env22919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env22902 == env22919) = true)

theorem identity22919 : scanCanonicalize (H12AffineFastState.compose env22919 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 62851) := by decide +kernel

theorem selectedBound22919 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62851,16401,262144,1025,32769,50632,264668,62661,21762,8328,64,56713,57797,25693,292053,53332,264532,257,21793,46212,512]

theorem envBound22920 : H12AffineFastState.Bounded env22920 := by
  intro p hp
  have h : env22920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22919_22920 : H12AffineEnvironment.transform 15 62851 env22919 = env22920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62851 env22919 == env22920) = true)

theorem identity22920 : scanCanonicalize (H12AffineFastState.compose env22920 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound22920 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env22921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,16401,262144,1025,29909,12572,264668,17,21762,8328,64,10589,5393,25693,292053,9344,264532,257,21793,16464,512]

theorem envBound22921 : H12AffineFastState.Bounded env22921 := by
  intro p hp
  have h : env22921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22920_22921 : H12AffineEnvironment.transform 14 29908 env22920 = env22921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env22920 == env22921) = true)

theorem identity22921 : scanCanonicalize (H12AffineFastState.compose env22921 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10708) := by decide +kernel

theorem selectedBound22921 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env22922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,16401,10708,1025,29909,12572,8200,17,21762,8328,64,10589,5393,25693,23809,9344,8320,257,21793,16464,512]

theorem envBound22922 : H12AffineFastState.Bounded env22922 := by
  intro p hp
  have h : env22922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22921_22922 : H12AffineEnvironment.transform 17 10708 env22921 = env22922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10708 env22921 == env22922) = true)

theorem identity22922 : scanCanonicalize (H12AffineFastState.compose env22922 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound22922 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env22923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,21756,343,16401,2556,1025,21757,4404,32,17,21762,160,64,2421,5393,17525,23809,1192,168,257,21793,16464,512]

theorem envBound22923 : H12AffineFastState.Bounded env22923 := by
  intro p hp
  have h : env22923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22922_22923 : H12AffineEnvironment.transform 12 40 env22922 = env22923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env22922 == env22923) = true)

theorem identity22923 : scanCanonicalize (H12AffineFastState.compose env22923 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound22923 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env22924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,136,343,5221,2556,1025,137,4404,32,17,374,160,64,2421,5393,4097,2421,1192,168,257,341,5156,512]

theorem envBound22924 : H12AffineFastState.Bounded env22924 := by
  intro p hp
  have h : env22924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22923_22924 : H12AffineEnvironment.transform 13 5236 env22923 = env22924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env22923 == env22924) = true)

theorem identity22924 : scanCanonicalize (H12AffineFastState.compose env22924 (packedSelected [0,2,7,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound22924 : packedSelected [0,2,7,12,14] rootPS < 2^1333 := by decide +kernel

def env22925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3464,40,2556,136,343,2541,2556,1025,137,3260,32,17,374,160,64,2421,2201,3465,2421,1192,168,257,341,2476,512]

theorem envBound22925 : H12AffineFastState.Bounded env22925 := by
  intro p hp
  have h : env22925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22924_22925 : H12AffineEnvironment.transform 11 3464 env22924 = env22925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env22924 == env22925) = true)

theorem identity22925 : scanCanonicalize (H12AffineFastState.compose env22925 (packedSelected [2,6,7,9,10,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound22925 : packedSelected [2,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22926 : List Nat := [2,4,8,16,0,64,128,256,512,1024,2048,3464,8,2524,136,343,2509,2524,1025,137,3228,0,17,342,128,64,2389,2201,3465,2389,1160,136,257,341,2444,512]

theorem envBound22926 : H12AffineFastState.Bounded env22926 := by
  intro p hp
  have h : env22926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22925_22926 : H12AffineEnvironment.transform 4 0 env22925 = env22926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env22925 == env22926) = true)

theorem identity22926 : scanCanonicalize (H12AffineFastState.compose env22926 (packedSelected [0,1,6,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound22926 : packedSelected [0,1,6,8,9,12] rootPS < 2^1333 := by decide +kernel

def env22927 : List Nat := [2,4,8,16,0,64,128,5,512,1024,2048,3213,8,2265,136,82,2248,2265,1025,137,3228,0,17,83,128,64,2128,2201,3212,2128,1160,136,4,80,2185,512]

theorem envBound22927 : H12AffineFastState.Bounded env22927 := by
  intro p hp
  have h : env22927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22926_22927 : H12AffineEnvironment.transform 7 5 env22926 = env22927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env22926 == env22927) = true)

theorem identity22927 : scanCanonicalize (H12AffineFastState.compose env22927 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound22927 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env22928 : List Nat := [2,4,8,16,0,64,89,5,512,1024,2048,3156,8,2048,81,82,2065,2048,1025,80,3141,0,17,83,89,64,2128,2112,3157,2128,1105,81,4,80,2128,512]

theorem envBound22928 : H12AffineFastState.Bounded env22928 := by
  intro p hp
  have h : env22928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22927_22928 : H12AffineEnvironment.transform 6 89 env22927 = env22928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env22927 == env22928) = true)

theorem identity22928 : scanCanonicalize (H12AffineFastState.compose env22928 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22928 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env22929 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3076,8,2048,1,2,2065,2048,1025,0,3093,0,17,3,9,16,2048,2064,3077,2048,1025,1,4,0,2048,512]

theorem envBound22929 : H12AffineFastState.Bounded env22929 := by
  intro p hp
  have h : env22929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22928_22929 : H12AffineEnvironment.transform 5 16 env22928 = env22929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22928 == env22929) = true)

theorem identity22929 : scanCanonicalize (H12AffineFastState.compose env22929 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound22929 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22930 : List Nat := [2,4,8,16,0,16,9,5,512,1024,1045,17,8,1045,1,2,1028,1045,1025,0,0,0,17,3,9,16,1045,1029,16,1045,1025,1,4,0,1045,512]

theorem envBound22930 : H12AffineFastState.Bounded env22930 := by
  intro p hp
  have h : env22930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22929_22930 : H12AffineEnvironment.transform 10 1045 env22929 = env22930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env22929 == env22930) = true)

theorem identity22930 : scanCanonicalize (H12AffineFastState.compose env22930 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound22930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22931 : List Nat := [2,4,8,16,0,16,9,5,1,1024,1045,17,8,1045,1,2,1028,1045,1025,0,0,0,17,3,9,16,1045,1029,16,1045,1025,1,4,0,1045,1]

theorem envBound22931 : H12AffineFastState.Bounded env22931 := by
  intro p hp
  have h : env22931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22930_22931 : H12AffineEnvironment.transform 8 1 env22930 = env22931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env22930 == env22931) = true)

def env22932 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254785,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound22932 : H12AffineFastState.Bounded env22932 := by
  intro p hp
  have h : env22932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22189_22932 : H12AffineEnvironment.transform 25 65 env22189 = env22932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env22189 == env22932) = true)

def env22933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356289,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound22933 : H12AffineFastState.Bounded env22933 := by
  intro p hp
  have h : env22933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22932_22933 : H12AffineEnvironment.transform 26 30393344 env22932 = env22933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env22932 == env22933) = true)

def env22934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound22934 : H12AffineFastState.Bounded env22934 := by
  intro p hp
  have h : env22934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22933_22934 : H12AffineEnvironment.transform 18 1024 env22933 = env22934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env22933 == env22934) = true)

theorem identity22934 : scanCanonicalize (H12AffineFastState.compose env22934 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10882102) := by decide +kernel

theorem selectedBound22934 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env22935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10882102,8328,65,6409270,8882363,10507601,8830977,2590759,13068790,256,510107,469310,2535408]

theorem envBound22935 : H12AffineFastState.Bounded env22935 := by
  intro p hp
  have h : env22935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22934_22935 : H12AffineEnvironment.transform 23 10882102 env22934 = env22935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10882102 env22934 == env22935) = true)

def env22936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412020,2114882,8328,65,6409270,115151,2497573,35189,2590759,4268162,256,510107,469310,2535408]

theorem envBound22936 : H12AffineFastState.Bounded env22936 := by
  intro p hp
  have h : env22936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22935_22936 : H12AffineEnvironment.transform 22 412020 env22935 = env22936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412020 env22935 == env22936) = true)

def env22937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412020,2114882,8328,65,215366,115151,2497573,35189,2590759,2336242,256,510107,469310,2535408]

theorem envBound22937 : H12AffineFastState.Bounded env22937 := by
  intro p hp
  have h : env22937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22936_22937 : H12AffineEnvironment.transform 21 2262384 env22936 = env22937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env22936 == env22937) = true)

def env22938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412020,21762,8328,65,215366,115151,396389,35189,497767,243122,256,510107,469310,442288]

theorem envBound22938 : H12AffineFastState.Bounded env22938 := by
  intro p hp
  have h : env22938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22937_22938 : H12AffineEnvironment.transform 20 4160 env22937 = env22938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22937 == env22938) = true)

theorem identity22938 : scanCanonicalize (H12AffineFastState.compose env22938 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 236987) := by decide +kernel

theorem selectedBound22938 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,236987,1024,32769,4160,169264,120015,21762,8328,65,215366,115151,102878,35189,1500,243122,256,21792,46213,74251]

theorem envBound22939 : H12AffineFastState.Bounded env22939 := by
  intro p hp
  have h : env22939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22938_22939 : H12AffineEnvironment.transform 17 236987 env22938 = env22939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 236987 env22938 == env22939) = true)

def env22940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,130175,1024,32769,4160,62708,120015,21762,8328,65,75906,115151,102878,35189,1500,119926,256,21792,46213,74251]

theorem envBound22940 : H12AffineFastState.Bounded env22940 := by
  intro p hp
  have h : env22940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22939_22940 : H12AffineEnvironment.transform 16 25028 env22939 = env22940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env22939 == env22940) = true)

theorem identity22940 : scanCanonicalize (H12AffineFastState.compose env22940 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound22940 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env22941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,25028,76158,1024,21760,4160,8693,65998,21762,8328,65,75906,70862,83167,23668,1500,65911,256,21792,24964,74251]

theorem envBound22941 : H12AffineFastState.Bounded env22941 := by
  intro p hp
  have h : env22941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22940_22941 : H12AffineEnvironment.transform 14 21761 env22940 = env22941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env22940 == env22941) = true)

theorem identity22941 : scanCanonicalize (H12AffineFastState.compose env22941 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22941 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env22942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8202,25028,2420,1024,21760,4160,8693,8644,21762,8328,65,2184,13508,25813,23668,1500,8573,256,21792,24964,513]

theorem envBound22942 : H12AffineFastState.Bounded env22942 := by
  intro p hp
  have h : env22942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22941_22942 : H12AffineEnvironment.transform 15 8202 env22941 = env22942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22941 == env22942) = true)

theorem identity22942 : scanCanonicalize (H12AffineFastState.compose env22942 (packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound22942 : packedSelected [0,1,3,5,7,8,9,10,14,19,20,22] rootPS < 2^1333 := by decide +kernel

def env22943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,21761,479,16401,2420,1024,21760,4160,32,17,21762,349,65,2184,5393,17664,23668,1500,168,256,21792,16465,513]

theorem envBound22943 : H12AffineFastState.Bounded env22943 := by
  intro p hp
  have h : env22943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22942_22943 : H12AffineEnvironment.transform 12 469 env22942 = env22943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env22942 == env22943) = true)

theorem identity22943 : scanCanonicalize (H12AffineFastState.compose env22943 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound22943 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env22944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,5457,80,479,5440,2420,1024,81,4160,32,17,83,349,65,2184,5393,4177,2341,1500,168,256,113,5376,513]

theorem envBound22944 : H12AffineFastState.Bounded env22944 := by
  intro p hp
  have h : env22944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22943_22944 : H12AffineEnvironment.transform 13 5457 env22943 = env22944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env22943 == env22944) = true)

theorem identity22944 : scanCanonicalize (H12AffineFastState.compose env22944 (packedSelected [2,5,8,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1636) := by decide +kernel

theorem selectedBound22944 : packedSelected [2,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env22945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1636,469,821,80,479,804,2420,1024,81,1572,32,17,83,349,65,2184,885,1589,2341,1500,168,256,113,868,513]

theorem envBound22945 : H12AffineFastState.Bounded env22945 := by
  intro p hp
  have h : env22945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22944_22945 : H12AffineEnvironment.transform 11 1636 env22944 = env22945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1636 env22944 == env22945) = true)

theorem identity22945 : scanCanonicalize (H12AffineFastState.compose env22945 (packedSelected [0,3,8,9,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound22945 : packedSelected [0,3,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env22946 : List Nat := [2,4,8,16,32,64,128,256,512,256,2048,868,469,821,80,479,804,2420,256,81,804,32,17,83,349,65,2184,885,821,2341,220,168,256,113,868,513]

theorem envBound22946 : H12AffineFastState.Bounded env22946 := by
  intro p hp
  have h : env22946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22945_22946 : H12AffineEnvironment.transform 9 256 env22945 = env22946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env22945 == env22946) = true)

theorem identity22946 : scanCanonicalize (H12AffineFastState.compose env22946 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound22946 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env22947 : List Nat := [2,4,8,16,32,64,128,236,512,236,2048,648,57,729,80,51,712,2200,236,81,712,32,17,83,177,65,2184,665,729,2249,220,168,236,113,648,513]

theorem envBound22947 : H12AffineFastState.Bounded env22947 := by
  intro p hp
  have h : env22947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22946_22947 : H12AffineEnvironment.transform 7 236 env22946 = env22947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env22946 == env22947) = true)

theorem identity22947 : scanCanonicalize (H12AffineFastState.compose env22947 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound22947 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env22948 : List Nat := [2,4,8,16,32,64,88,52,512,52,2048,592,57,513,80,51,528,2112,52,81,528,32,17,83,105,65,2128,577,513,2065,4,112,52,113,592,513]

theorem envBound22948 : H12AffineFastState.Bounded env22948 := by
  intro p hp
  have h : env22948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22947_22948 : H12AffineEnvironment.transform 6 88 env22947 = env22948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env22947 == env22948) = true)

theorem identity22948 : scanCanonicalize (H12AffineFastState.compose env22948 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound22948 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22949 : List Nat := [2,4,8,16,32,16,8,52,512,52,2048,512,57,513,0,51,528,2064,52,1,528,32,17,3,57,17,2048,529,513,2065,4,32,52,33,512,513]

theorem envBound22949 : H12AffineFastState.Bounded env22949 := by
  intro p hp
  have h : env22949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22948_22949 : H12AffineEnvironment.transform 5 16 env22948 = env22949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22948 == env22949) = true)

def env22950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,130174,1024,32769,4160,62709,120015,21762,8328,65,75907,115151,102878,35189,1500,119927,256,21792,46213,74251]

theorem envBound22950 : H12AffineFastState.Bounded env22950 := by
  intro p hp
  have h : env22950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22939_22950 : H12AffineEnvironment.transform 16 25029 env22939 = env22950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env22939 == env22950) = true)

theorem identity22950 : scanCanonicalize (H12AffineFastState.compose env22950 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound22950 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env22951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,25029,2420,1024,32769,4160,62709,8645,21762,8328,65,56713,13509,25812,35189,1500,8573,256,21792,46213,55041]

theorem envBound22951 : H12AffineFastState.Bounded env22951 := by
  intro p hp
  have h : env22951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22950_22951 : H12AffineEnvironment.transform 15 62730 env22950 = env22951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env22950 == env22951) = true)

def env22952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,24909,2420,1024,32769,4160,62589,8525,21762,8192,65,56577,13389,25692,35189,1364,8573,256,21792,46093,55041]

theorem envBound22952 : H12AffineFastState.Bounded env22952 := by
  intro p hp
  have h : env22952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22951_22952 : H12AffineEnvironment.transform 6 8 env22951 = env22952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22951 == env22952) = true)

theorem identity22952 : scanCanonicalize (H12AffineFastState.compose env22952 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound22952 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,8202,24909,2420,1024,21761,4160,8573,8525,21762,8192,65,2049,13389,25692,23669,1364,8573,256,21792,24845,513]

theorem envBound22953 : H12AffineFastState.Bounded env22953 := by
  intro p hp
  have h : env22953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22952_22953 : H12AffineEnvironment.transform 14 21760 env22952 = env22953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env22952 == env22953) = true)

theorem identity22953 : scanCanonicalize (H12AffineFastState.compose env22953 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound22953 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env22954 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,8202,5393,2420,1024,8541,4160,8573,8525,8542,8192,65,2049,13389,4096,10281,1364,8573,256,8572,5457,513]

theorem envBound22954 : H12AffineFastState.Bounded env22954 := by
  intro p hp
  have h : env22954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22953_22954 : H12AffineEnvironment.transform 13 13404 env22953 = env22954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env22953 == env22954) = true)

theorem identity22954 : scanCanonicalize (H12AffineFastState.compose env22954 (packedSelected [0,2,3,4,5,6,7,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound22954 : packedSelected [0,2,3,4,5,6,7,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2048,8192,11356,8540,8202,3345,2420,1024,8541,2112,8573,8525,8542,8192,65,2049,11341,2048,10281,1364,8573,256,8572,3409,513]

theorem envBound22955 : H12AffineFastState.Bounded env22955 := by
  intro p hp
  have h : env22955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22954_22955 : H12AffineEnvironment.transform 11 2048 env22954 = env22955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env22954 == env22955) = true)

theorem identity22955 : scanCanonicalize (H12AffineFastState.compose env22955 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound22955 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env22956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2048,269,3409,81,263,3345,2420,1024,80,2112,112,64,83,269,65,2049,3392,2048,2340,1364,112,256,113,3409,513]

theorem envBound22956 : H12AffineFastState.Bounded env22956 := by
  intro p hp
  have h : env22956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22955_22956 : H12AffineEnvironment.transform 12 269 env22955 = env22956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env22955 == env22956) = true)

def env22957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24908,2420,1024,32769,4160,62588,8524,21762,8193,65,56576,13388,25693,35189,1365,8573,256,21792,46092,55041]

theorem envBound22957 : H12AffineFastState.Bounded env22957 := by
  intro p hp
  have h : env22957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22951_22957 : H12AffineEnvironment.transform 6 9 env22951 = env22957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env22951 == env22957) = true)

theorem identity22957 : scanCanonicalize (H12AffineFastState.compose env22957 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound22957 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env22958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,32768,33110,5392,2420,1024,32769,4160,32800,8524,8542,8193,65,43356,13388,4097,35189,1365,8573,256,8572,46092,41821]

theorem envBound22958 : H12AffineFastState.Bounded env22958 := by
  intro p hp
  have h : env22958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22957_22958 : H12AffineEnvironment.transform 13 13404 env22957 = env22958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env22957 == env22958) = true)

theorem identity22958 : scanCanonicalize (H12AffineFastState.compose env22958 (packedSelected [2,4,9,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound22958 : packedSelected [2,4,9,11,16,18] rootPS < 2^1333 := by decide +kernel

def env22959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,343,5392,2420,1024,0,4160,33,8524,8542,8193,65,10589,13388,4097,2420,1365,8573,256,8572,13325,9052]

theorem envBound22959 : H12AffineFastState.Bounded env22959 := by
  intro p hp
  have h : env22959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22958_22959 : H12AffineEnvironment.transform 14 1 env22958 = env22959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env22958 == env22959) = true)

theorem identity22959 : scanCanonicalize (H12AffineFastState.compose env22959 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound22959 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env22960 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,8192,11624,1,343,3108,2420,1024,0,2420,33,8524,8542,8193,65,10589,11640,2357,2420,1365,8573,256,8572,11577,9052]

theorem envBound22960 : H12AffineFastState.Bounded env22960 := by
  intro p hp
  have h : env22960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22959_22960 : H12AffineEnvironment.transform 11 2356 env22959 = env22960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env22959 == env22960) = true)

theorem identity22960 : scanCanonicalize (H12AffineFastState.compose env22960 (packedSelected [1,3,5,6,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound22960 : packedSelected [1,3,5,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env22961 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,1101,2341,1,343,3108,2420,1024,0,2420,33,1281,1299,1100,65,3344,2357,2357,2420,1365,1328,256,1329,2420,1809]

theorem envBound22961 : H12AffineFastState.Bounded env22961 := by
  intro p hp
  have h : env22961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22960_22961 : H12AffineEnvironment.transform 12 1101 env22960 = env22961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env22960 == env22961) = true)

theorem identity22961 : scanCanonicalize (H12AffineFastState.compose env22961 (packedSelected [0,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound22961 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env22962 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1124,1360,1101,1345,1,343,64,1296,1024,0,1296,33,1281,1299,1100,65,372,1361,1361,1296,1365,1328,256,1329,1296,1809]

theorem envBound22962 : H12AffineFastState.Bounded env22962 := by
  intro p hp
  have h : env22962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22961_22962 : H12AffineEnvironment.transform 10 1124 env22961 = env22962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env22961 == env22962) = true)

theorem identity22962 : scanCanonicalize (H12AffineFastState.compose env22962 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound22962 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env22963 : List Nat := [2,4,8,16,32,64,9,256,512,52,80,356,121,373,1,343,64,292,52,0,292,33,309,295,120,65,372,357,357,292,353,260,256,261,292,805]

theorem envBound22963 : H12AffineFastState.Bounded env22963 := by
  intro p hp
  have h : env22963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22962_22963 : H12AffineEnvironment.transform 9 52 env22962 = env22963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env22962 == env22963) = true)

theorem identity22963 : scanCanonicalize (H12AffineFastState.compose env22963 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound22963 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env22964 : List Nat := [2,4,8,16,32,64,9,36,512,52,80,64,121,81,1,115,64,0,52,0,0,33,17,3,120,65,80,65,65,0,69,32,36,33,0,513]

theorem envBound22964 : H12AffineFastState.Bounded env22964 := by
  intro p hp
  have h : env22964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22963_22964 : H12AffineEnvironment.transform 7 36 env22963 = env22964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env22963 == env22964) = true)

theorem identity22964 : scanCanonicalize (H12AffineFastState.compose env22964 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound22964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env22965 : List Nat := [2,4,8,0,32,64,9,36,512,36,64,64,105,65,1,99,64,0,36,0,0,33,1,3,104,65,64,65,65,0,69,32,36,33,0,513]

theorem envBound22965 : H12AffineFastState.Bounded env22965 := by
  intro p hp
  have h : env22965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22964_22965 : H12AffineEnvironment.transform 3 0 env22964 = env22965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env22964 == env22965) = true)

theorem identity22965 : scanCanonicalize (H12AffineFastState.compose env22965 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound22965 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env22966 : List Nat := [2,4,8,0,32,64,9,36,10,36,64,64,105,65,1,99,64,0,36,0,0,33,1,3,104,65,64,65,65,0,69,32,36,33,0,11]

theorem envBound22966 : H12AffineFastState.Bounded env22966 := by
  intro p hp
  have h : env22966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22965_22966 : H12AffineEnvironment.transform 8 10 env22965 = env22966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env22965 == env22966) = true)

theorem identity22966 : scanCanonicalize (H12AffineFastState.compose env22966 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound22966 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env22967 : List Nat := [2,4,8,0,32,10,9,36,10,36,10,10,35,11,1,41,10,0,36,0,0,33,1,3,34,11,10,11,11,0,15,32,36,33,0,11]

theorem envBound22967 : H12AffineFastState.Bounded env22967 := by
  intro p hp
  have h : env22967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22966_22967 : H12AffineEnvironment.transform 5 10 env22966 = env22967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env22966 == env22967) = true)

theorem identity22967 : scanCanonicalize (H12AffineFastState.compose env22967 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound22967 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env22968 : List Nat := [2,4,3,0,32,1,2,36,1,36,1,1,35,0,1,34,1,0,36,0,0,33,1,3,34,0,1,0,0,0,4,32,36,33,0,0]

theorem envBound22968 : H12AffineFastState.Bounded env22968 := by
  intro p hp
  have h : env22968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22967_22968 : H12AffineEnvironment.transform 2 3 env22967 = env22968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env22967 == env22968) = true)

def env22969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,21763,8328,65,215366,115151,396388,35189,497766,243123,256,510107,469310,442289]

theorem envBound22969 : H12AffineFastState.Bounded env22969 := by
  intro p hp
  have h : env22969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22937_22969 : H12AffineEnvironment.transform 20 4161 env22937 = env22969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22937 == env22969) = true)

theorem identity22969 : scanCanonicalize (H12AffineFastState.compose env22969 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound22969 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22970 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,4161,169265,412020,21763,8328,65,158028,57797,396388,35189,440428,169401,256,452753,395572,442289]

theorem envBound22970 : H12AffineFastState.Bounded env22970 := by
  intro p hp
  have h : env22970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22969_22970 : H12AffineEnvironment.transform 15 8202 env22969 = env22970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env22969 == env22970) = true)

theorem identity22970 : scanCanonicalize (H12AffineFastState.compose env22970 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound22970 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env22971 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179632,1024,32769,4161,169265,62660,21763,8328,65,158028,57797,45524,35189,1500,169401,256,21793,46212,513]

theorem envBound22971 : H12AffineFastState.Bounded env22971 := by
  intro p hp
  have h : env22971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22970_22971 : H12AffineEnvironment.transform 17 179632 env22970 = env22971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env22970 == env22971) = true)

theorem identity22971 : scanCanonicalize (H12AffineFastState.compose env22971 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound22971 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env22972 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,46276,2420,1024,32769,4161,8693,62660,21763,8328,65,56712,57797,45524,35189,1500,8573,256,21793,46212,513]

theorem envBound22972 : H12AffineFastState.Bounded env22972 := by
  intro p hp
  have h : env22972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22971_22972 : H12AffineEnvironment.transform 16 46276 env22971 = env22972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env22971 == env22972) = true)

theorem identity22972 : scanCanonicalize (H12AffineFastState.compose env22972 (packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound22972 : packedSelected [1,3,5,8,10,12,15,17,19,38,41] rootPS < 2^1333 := by decide +kernel

def env22973 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,343,38297,2420,1024,32769,4161,168,54681,21763,469,65,56712,49304,37001,35189,1500,32,256,21793,38361,513]

theorem envBound22973 : H12AffineFastState.Bounded env22973 := by
  intro p hp
  have h : env22973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22972_22973 : H12AffineEnvironment.transform 12 349 env22972 = env22973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env22972 == env22973) = true)

def env22974 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262385,412020,2114882,8328,65,215367,115151,2497573,35189,2590759,2336243,256,510107,469310,2535408]

theorem envBound22974 : H12AffineFastState.Bounded env22974 := by
  intro p hp
  have h : env22974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22936_22974 : H12AffineEnvironment.transform 21 2262385 env22936 = env22974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262385 env22936 == env22974) = true)

def env22975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412020,21762,8328,65,215367,115151,396389,35189,497767,243123,256,510107,469310,442288]

theorem envBound22975 : H12AffineFastState.Bounded env22975 := by
  intro p hp
  have h : env22975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22974_22975 : H12AffineEnvironment.transform 20 4160 env22974 = env22975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env22974 == env22975) = true)

theorem identity22975 : scanCanonicalize (H12AffineFastState.compose env22975 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound22975 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,4160,169265,412020,21762,8328,65,171416,5392,396389,35189,412856,156012,256,400452,458209,442288]

theorem envBound22976 : H12AffineFastState.Bounded env22976 := by
  intro p hp
  have h : env22976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22975_22976 : H12AffineEnvironment.transform 15 54495 env22975 = env22976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env22975 == env22976) = true)

def env22977 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1024,32769,4112,169265,411940,21762,8328,17,171416,5392,396341,35109,412856,155964,256,400404,458161,442288]

theorem envBound22977 : H12AffineFastState.Bounded env22977 := by
  intro p hp
  have h : env22977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22976_22977 : H12AffineEnvironment.transform 5 16 env22976 = env22977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22976 == env22977) = true)

theorem identity22977 : scanCanonicalize (H12AffineFastState.compose env22977 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57628) := by decide +kernel

theorem selectedBound22977 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env22978 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,57628,262144,1024,32769,4112,29741,305208,21762,8328,17,31876,5392,322857,35109,306596,32800,256,326920,269485,286380]

theorem envBound22978 : H12AffineFastState.Bounded env22978 := by
  intro p hp
  have h : env22978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22977_22978 : H12AffineEnvironment.transform 16 57628 env22977 = env22978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57628 env22977 == env22978) = true)

theorem identity22978 : scanCanonicalize (H12AffineFastState.compose env22978 (packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound22978 : packedSelected [5,8,10,16,18,19,20,23,24,28] rootPS < 2^1333 := by decide +kernel

def env22979 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,57628,2341,1024,32769,4112,29741,41245,21762,8328,17,31876,5392,58380,35109,42113,32800,256,62509,5512,22409]

theorem envBound22979 : H12AffineFastState.Bounded env22979 := by
  intro p hp
  have h : env22979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22978_22979 : H12AffineEnvironment.transform 17 2341 env22978 = env22979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env22978 == env22979) = true)

theorem identity22979 : scanCanonicalize (H12AffineFastState.compose env22979 (packedSelected [0,1,3,5,8,9,10,16,17,19,20,22,27] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22979 : packedSelected [0,1,3,5,8,9,10,16,17,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env22980 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,54279,57628,2341,1024,32769,4112,29741,41245,21762,8192,17,31756,5392,58380,35109,41993,32800,256,62509,5376,22273]

theorem envBound22980 : H12AffineFastState.Bounded env22980 := by
  intro p hp
  have h : env22980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22979_22980 : H12AffineEnvironment.transform 6 8 env22979 = env22980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22979 == env22980) = true)

def env22981 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1024,32769,4113,169265,411941,21762,8328,16,171416,5392,396340,35108,412856,155965,256,400405,458160,442288]

theorem envBound22981 : H12AffineFastState.Bounded env22981 := by
  intro p hp
  have h : env22981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22976_22981 : H12AffineEnvironment.transform 5 17 env22976 = env22981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22976 == env22981) = true)

theorem identity22981 : scanCanonicalize (H12AffineFastState.compose env22981 (packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 43168) := by decide +kernel

theorem selectedBound22981 : packedSelected [3,10,12,15,17,18,23,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env22982 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,43168,1024,32769,4113,169265,188805,21762,8328,16,171416,5392,173204,35108,189464,155965,256,177333,152848,136976]

theorem envBound22982 : H12AffineFastState.Bounded env22982 := by
  intro p hp
  have h : env22982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22981_22982 : H12AffineEnvironment.transform 17 43168 env22981 = env22982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43168 env22981 == env22982) = true)

theorem identity22982 : scanCanonicalize (H12AffineFastState.compose env22982 (packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57629) := by decide +kernel

theorem selectedBound22982 : packedSelected [1,3,4,7,9,10,16,18,19,20,23,24,26,27,28,31] rootPS < 2^1333 := by decide +kernel

def env22983 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,57629,43168,1024,32769,4113,29740,152,21762,8328,16,31877,5392,17801,35108,1285,32800,256,21928,46093,62989]

theorem envBound22983 : H12AffineFastState.Bounded env22983 := by
  intro p hp
  have h : env22983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22982_22983 : H12AffineEnvironment.transform 16 57629 env22982 = env22983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57629 env22982 == env22983) = true)

theorem identity22983 : scanCanonicalize (H12AffineFastState.compose env22983 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 29708) := by decide +kernel

theorem selectedBound22983 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env22984 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29708,8322,5393,23724,1024,29709,4113,29740,152,21762,8328,16,31877,5392,17801,32040,1285,29740,256,21928,16385,513]

theorem envBound22984 : H12AffineFastState.Bounded env22984 := by
  intro p hp
  have h : env22984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22983_22984 : H12AffineEnvironment.transform 14 29708 env22983 = env22984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29708 env22983 == env22984) = true)

theorem identity22984 : scanCanonicalize (H12AffineFastState.compose env22984 (packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound22984 : packedSelected [1,2,3,4,5,6,8,9,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env22985 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,0,8322,5393,10400,1024,1,4113,32,152,8462,8328,16,2185,5392,12677,2340,1285,32,256,8612,13325,513]

theorem envBound22985 : H12AffineFastState.Bounded env22985 := by
  intro p hp
  have h : env22985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22984_22985 : H12AffineEnvironment.transform 13 13324 env22984 = env22985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env22984 == env22985) = true)

theorem identity22985 : scanCanonicalize (H12AffineFastState.compose env22985 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound22985 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env22986 : List Nat := [2,4,8,16,32,17,128,256,512,272,2048,4096,8192,12572,0,8322,4097,10400,272,1,4113,32,152,8462,8328,16,2185,4096,12677,2340,21,32,256,8612,12573,513]

theorem envBound22986 : H12AffineFastState.Bounded env22986 := by
  intro p hp
  have h : env22986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22985_22986 : H12AffineEnvironment.transform 9 272 env22985 = env22986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env22985 == env22986) = true)

def env22987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,21763,8328,65,215367,115151,396388,35189,497766,243122,256,510107,469310,442289]

theorem envBound22987 : H12AffineFastState.Bounded env22987 := by
  intro p hp
  have h : env22987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22974_22987 : H12AffineEnvironment.transform 20 4161 env22974 = env22987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env22974 == env22987) = true)

theorem identity22987 : scanCanonicalize (H12AffineFastState.compose env22987 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 223598) := by decide +kernel

theorem selectedBound22987 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env22988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223598,1024,32769,4161,169264,73754,21763,8328,65,215367,115151,91402,35189,61704,243122,256,41461,16464,120543]

theorem envBound22988 : H12AffineFastState.Bounded env22988 := by
  intro p hp
  have h : env22988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22987_22988 : H12AffineEnvironment.transform 17 223598 env22987 = env22988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223598 env22987 == env22988) = true)

def env22989 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223550,1024,32769,4113,169264,73754,21763,8328,17,215319,115103,91402,35109,61704,243122,256,41381,16384,120463]

theorem envBound22989 : H12AffineFastState.Bounded env22989 := by
  intro p hp
  have h : env22989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22988_22989 : H12AffineEnvironment.transform 5 16 env22988 = env22989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env22988 == env22989) = true)

theorem identity22989 : scanCanonicalize (H12AffineFastState.compose env22989 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound22989 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env22990 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,79130,23588,1024,32769,4113,106538,73754,21763,8328,17,31757,115103,91402,35109,61704,32936,256,41381,16384,120463]

theorem envBound22990 : H12AffineFastState.Bounded env22990 := by
  intro p hp
  have h : env22990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22989_22990 : H12AffineEnvironment.transform 16 79130 env22989 = env22990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env22989 == env22990) = true)

theorem identity22990 : scanCanonicalize (H12AffineFastState.compose env22990 (packedSelected [0,3,5,8,9,16,20,22,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound22990 : packedSelected [0,3,5,8,9,16,20,22,27,28] rootPS < 2^1333 := by decide +kernel

def env22991 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,8460,65536,79130,23588,1024,8461,4113,65830,73754,21763,8328,17,31757,90259,91402,10281,20484,8612,256,169,16384,96131]

theorem envBound22991 : H12AffineFastState.Bounded env22991 := by
  intro p hp
  have h : env22991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22990_22991 : H12AffineEnvironment.transform 14 8460 env22990 = env22991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env22990 == env22991) = true)

theorem identity22991 : scanCanonicalize (H12AffineFastState.compose env22991 (packedSelected [1,3,5,8,10,16,17,20,26] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound22991 : packedSelected [1,3,5,8,10,16,17,20,26] rootPS < 2^1333 := by decide +kernel

def env22992 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8460,65536,79130,2477,1024,8461,4113,65830,73754,138,8328,17,10628,79130,77955,10281,1421,8612,256,169,5513,74250]

theorem envBound22992 : H12AffineFastState.Bounded env22992 := by
  intro p hp
  have h : env22992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22991_22992 : H12AffineEnvironment.transform 13 5513 env22991 = env22992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env22991 == env22992) = true)

theorem identity22992 : scanCanonicalize (H12AffineFastState.compose env22992 (packedSelected [1,6,7,8,9,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1466) := by decide +kernel

theorem selectedBound22992 : packedSelected [1,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env22993 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5513,8460,1466,12448,2477,1024,8461,4113,1180,9632,138,8328,17,10628,12448,13625,10281,1421,8612,256,169,5513,10160]

theorem envBound22993 : H12AffineFastState.Bounded env22993 := by
  intro p hp
  have h : env22993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22992_22993 : H12AffineEnvironment.transform 15 1466 env22992 = env22993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1466 env22992 == env22993) = true)

theorem identity22993 : scanCanonicalize (H12AffineFastState.compose env22993 (packedSelected [0,1,3,5,8,9,10,11,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound22993 : packedSelected [0,1,3,5,8,9,10,11,14,15,16] rootPS < 2^1333 := by decide +kernel

def env22994 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,1337,5513,1077,1466,5529,2477,1024,1076,4113,1180,153,138,1457,17,3261,5529,4096,3344,1421,1181,256,169,5513,649]

theorem envBound22994 : H12AffineFastState.Bounded env22994 := by
  intro p hp
  have h : env22994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22993_22994 : H12AffineEnvironment.transform 12 1337 env22993 = env22994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env22993 == env22994) = true)

theorem identity22994 : scanCanonicalize (H12AffineFastState.compose env22994 (packedSelected [3,4,5,6,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound22994 : packedSelected [3,4,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env22995 : List Nat := [2,4,8,16,32,16,128,256,512,53,2048,4096,268,4540,0,399,4524,2477,53,1,4113,169,153,138,388,17,2184,4524,4096,2341,440,168,256,169,4540,649]

theorem envBound22995 : H12AffineFastState.Bounded env22995 := by
  intro p hp
  have h : env22995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22994_22995 : H12AffineEnvironment.transform 9 53 env22994 = env22995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env22994 == env22995) = true)

theorem identity22995 : scanCanonicalize (H12AffineFastState.compose env22995 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound22995 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env22996 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,268,4404,0,263,4388,2341,53,1,4113,33,17,2,268,17,2048,4388,4096,2341,304,32,256,33,4404,513]

theorem envBound22996 : H12AffineFastState.Bounded env22996 := by
  intro p hp
  have h : env22996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22995_22996 : H12AffineEnvironment.transform 6 8 env22995 = env22996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env22995 == env22996) = true)

def env22997 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,223551,1024,32769,4112,169264,73754,21763,8328,16,215318,115102,91402,35108,61704,243122,256,41380,16385,120462]

theorem envBound22997 : H12AffineFastState.Bounded env22997 := by
  intro p hp
  have h : env22997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22988_22997 : H12AffineEnvironment.transform 5 17 env22988 = env22997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env22988 == env22997) = true)

theorem identity22997 : scanCanonicalize (H12AffineFastState.compose env22997 (packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound22997 : packedSelected [1,4,7,9,11,12,15,17,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env22998 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,5392,97327,1024,32769,4112,32800,73754,21763,8328,16,89094,115102,91402,35108,61704,106658,256,41380,16385,120462]

theorem envBound22998 : H12AffineFastState.Bounded env22998 := by
  intro p hp
  have h : env22998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22997_22998 : H12AffineEnvironment.transform 16 5392 env22997 = env22998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env22997 == env22998) = true)

theorem identity22998 : scanCanonicalize (H12AffineFastState.compose env22998 (packedSelected [1,3,5,8,10,16,20,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound22998 : packedSelected [1,3,5,8,10,16,20,26] rootPS < 2^1333 := by decide +kernel

def env22999 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,29963,5392,2340,1024,32769,4112,32800,21777,21763,8328,16,10509,46229,4097,35108,61704,54697,256,41380,16385,41861]

theorem envBound22999 : H12AffineFastState.Bounded env22999 := by
  intro p hp
  have h : env22999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22998_22999 : H12AffineEnvironment.transform 15 29963 env22998 = env22999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env22998 == env22999) = true)

theorem identity22999 : scanCanonicalize (H12AffineFastState.compose env22999 (packedSelected [0,9,18,22,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound22999 : packedSelected [0,9,18,22,23,27] rootPS < 2^1333 := by decide +kernel

def env23000 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29709,29963,5392,2340,1024,29708,4112,29741,21777,21763,8328,16,10509,16536,4097,32041,1285,8612,256,21929,16385,22408]

theorem envBound23000 : H12AffineFastState.Bounded env23000 := by
  intro p hp
  have h : env23000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22999_23000 : H12AffineEnvironment.transform 14 29709 env22999 = env23000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env22999 == env23000) = true)

theorem identity23000 : scanCanonicalize (H12AffineFastState.compose env23000 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound23000 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env23001 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,8580,8322,5392,2340,1024,8581,4112,8612,152,138,8328,16,10509,5393,4097,10400,1285,8612,256,32,5512,513]

theorem envBound23001 : H12AffineFastState.Bounded env23001 := by
  intro p hp
  have h : env23001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23000_23001 : H12AffineEnvironment.transform 13 5513 env23000 = env23001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env23000 == env23001) = true)

theorem identity23001 : scanCanonicalize (H12AffineFastState.compose env23001 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound23001 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23002 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5513,0,262,5392,2340,1024,1,4112,32,152,138,268,16,2185,5393,4097,2340,1285,32,256,32,5512,513]

theorem envBound23002 : H12AffineFastState.Bounded env23002 := by
  intro p hp
  have h : env23002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23001_23002 : H12AffineEnvironment.transform 12 388 env23001 = env23002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env23001 == env23002) = true)

theorem identity23002 : scanCanonicalize (H12AffineFastState.compose env23002 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound23002 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env23003 : List Nat := [2,4,8,16,32,17,128,173,512,1024,2048,4096,41,5156,0,171,5309,2185,1024,1,4112,32,152,138,161,16,2185,5308,4097,2185,1192,32,173,32,5157,513]

theorem envBound23003 : H12AffineFastState.Bounded env23003 := by
  intro p hp
  have h : env23003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23002_23003 : H12AffineEnvironment.transform 7 173 env23002 = env23003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env23002 == env23003) = true)

theorem identity23003 : scanCanonicalize (H12AffineFastState.compose env23003 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 189) := by decide +kernel

theorem selectedBound23003 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env23004 : List Nat := [2,4,8,16,32,17,128,173,512,189,2048,4096,41,4249,0,171,4096,2185,189,1,4112,32,152,138,161,16,2185,4097,4097,2185,21,32,173,32,4248,513]

theorem envBound23004 : H12AffineFastState.Bounded env23004 := by
  intro p hp
  have h : env23004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23003_23004 : H12AffineEnvironment.transform 9 189 env23003 = env23004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 189 env23003 == env23004) = true)

theorem identity23004 : scanCanonicalize (H12AffineFastState.compose env23004 (packedSelected [0,1,2,3,4,7] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound23004 : packedSelected [0,1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env23005 : List Nat := [2,4,8,16,32,17,128,173,512,189,513,4096,41,4249,0,171,4096,648,189,1,4112,32,152,138,161,16,648,4097,4097,648,21,32,173,32,4248,513]

theorem envBound23005 : H12AffineFastState.Bounded env23005 := by
  intro p hp
  have h : env23005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23004_23005 : H12AffineEnvironment.transform 10 513 env23004 = env23005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env23004 == env23005) = true)

theorem identity23005 : scanCanonicalize (H12AffineFastState.compose env23005 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound23005 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env23006 : List Nat := [2,4,8,16,32,17,128,173,512,189,513,17,41,136,0,171,17,648,189,1,1,32,152,138,161,16,648,16,16,648,21,32,173,32,137,513]

theorem envBound23006 : H12AffineFastState.Bounded env23006 := by
  intro p hp
  have h : env23006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23005_23006 : H12AffineEnvironment.transform 11 17 env23005 = env23006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env23005 == env23006) = true)

def env23007 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,412021,2114883,8328,65,6409270,115150,2497572,35188,2590759,4268163,256,510107,469310,2535408]

theorem envBound23007 : H12AffineFastState.Bounded env23007 := by
  intro p hp
  have h : env23007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans22935_23007 : H12AffineEnvironment.transform 22 412021 env22935 = env23007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 412021 env22935 == env23007) = true)

def env23008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2262384,412021,2114883,8328,65,215366,115150,2497572,35188,2590759,2336243,256,510107,469310,2535408]

theorem envBound23008 : H12AffineFastState.Bounded env23008 := by
  intro p hp
  have h : env23008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23007_23008 : H12AffineEnvironment.transform 21 2262384 env23007 = env23008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2262384 env23007 == env23008) = true)

def env23009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,21763,8328,65,215366,115150,396388,35188,497767,243123,256,510107,469310,442288]

theorem envBound23009 : H12AffineFastState.Bounded env23009 := by
  intro p hp
  have h : env23009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23008_23009 : H12AffineEnvironment.transform 20 4160 env23008 = env23009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env23008 == env23009) = true)

theorem identity23009 : scanCanonicalize (H12AffineFastState.compose env23009 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound23009 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env23010 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,21763,8328,65,215366,115150,17665,35188,119042,243123,256,98814,90203,63189]

theorem envBound23010 : H12AffineFastState.Bounded env23010 := by
  intro p hp
  have h : env23010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23009_23010 : H12AffineEnvironment.transform 17 149861 env23009 = env23010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env23009 == env23010) = true)

def env23011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,21763,8192,65,215366,115014,17665,35188,119042,243003,256,98678,90203,63069]

theorem envBound23011 : H12AffineFastState.Bounded env23011 := by
  intro p hp
  have h : env23011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23010_23011 : H12AffineEnvironment.transform 6 8 env23010 = env23011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env23010 == env23011) = true)

theorem identity23011 : scanCanonicalize (H12AffineFastState.compose env23011 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound23011 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,56437,1024,32769,4160,32,16,21763,8192,65,121942,115014,17665,35188,119042,73771,256,98678,90203,63069]

theorem envBound23012 : H12AffineFastState.Bounded env23012 := by
  intro p hp
  have h : env23012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23011_23012 : H12AffineEnvironment.transform 16 38160 env23011 = env23012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env23011 == env23012) = true)

theorem identity23012 : scanCanonicalize (H12AffineFastState.compose env23012 (packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 30043) := by decide +kernel

theorem selectedBound23012 : packedSelected [1,2,3,4,5,6,8,9,12,16,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env23013 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,30043,38160,56437,1024,32769,4160,32,16,21763,8192,65,43277,46109,17665,35188,42073,21872,256,62509,5376,63069]

theorem envBound23013 : H12AffineFastState.Bounded env23013 := by
  intro p hp
  have h : env23013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23012_23013 : H12AffineEnvironment.transform 15 30043 env23012 = env23013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30043 env23012 == env23013) = true)

theorem identity23013 : scanCanonicalize (H12AffineFastState.compose env23013 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound23013 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env23014 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,30043,5392,23669,1024,1,4160,32,16,21763,8192,65,10509,13341,17665,2420,9305,21872,256,29741,5376,30301]

theorem envBound23014 : H12AffineFastState.Bounded env23014 := by
  intro p hp
  have h : env23014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23013_23014 : H12AffineEnvironment.transform 14 0 env23013 = env23014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env23013 == env23014) = true)

theorem identity23014 : scanCanonicalize (H12AffineFastState.compose env23014 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound23014 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env23015 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,263,5392,10281,1024,1,4160,32,16,8543,8192,65,10509,13341,12637,2420,9305,8492,256,113,5376,513]

theorem envBound23015 : H12AffineFastState.Bounded env23015 := by
  intro p hp
  have h : env23015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23014_23015 : H12AffineEnvironment.transform 13 13404 env23014 = env23015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env23014 == env23015) = true)

theorem identity23015 : scanCanonicalize (H12AffineFastState.compose env23015 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound23015 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env23016 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,0,263,5392,2341,1024,1,4160,32,16,83,268,65,2049,5393,4177,2420,1365,32,256,113,5376,513]

theorem envBound23016 : H12AffineFastState.Bounded env23016 := by
  intro p hp
  have h : env23016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23015_23016 : H12AffineEnvironment.transform 12 268 env23015 = env23016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env23015 == env23016) = true)

theorem identity23016 : scanCanonicalize (H12AffineFastState.compose env23016 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound23016 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env23017 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,263,5392,2341,1024,1,4112,32,16,3,268,17,2049,5393,4097,2340,1285,32,256,33,5376,513]

theorem envBound23017 : H12AffineFastState.Bounded env23017 := by
  intro p hp
  have h : env23017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23016_23017 : H12AffineEnvironment.transform 5 16 env23016 = env23017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env23016 == env23017) = true)

theorem identity23017 : scanCanonicalize (H12AffineFastState.compose env23017 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1044) := by decide +kernel

theorem selectedBound23017 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23018 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1044,268,276,0,263,260,2341,1024,1,1028,32,16,3,268,17,2049,261,1045,2340,1285,32,256,33,276,513]

theorem envBound23018 : H12AffineFastState.Bounded env23018 := by
  intro p hp
  have h : env23018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23017_23018 : H12AffineEnvironment.transform 11 1044 env23017 = env23018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env23017 == env23018) = true)

theorem identity23018 : scanCanonicalize (H12AffineFastState.compose env23018 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound23018 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23019 : List Nat := [2,4,8,16,32,16,8,256,512,785,2048,773,268,276,0,263,260,2341,785,1,789,32,16,3,268,17,2049,261,772,2340,532,32,256,33,276,513]

theorem envBound23019 : H12AffineFastState.Bounded env23019 := by
  intro p hp
  have h : env23019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23018_23019 : H12AffineEnvironment.transform 9 785 env23018 = env23019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env23018 == env23019) = true)

theorem identity23019 : scanCanonicalize (H12AffineFastState.compose env23019 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound23019 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env23020 : List Nat := [2,4,8,16,32,16,8,256,512,785,805,773,268,276,0,263,260,512,785,1,789,32,16,3,268,17,804,261,772,513,532,32,256,33,276,513]

theorem envBound23020 : H12AffineFastState.Bounded env23020 := by
  intro p hp
  have h : env23020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23019_23020 : H12AffineEnvironment.transform 10 805 env23019 = env23020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env23019 == env23020) = true)

theorem identity23020 : scanCanonicalize (H12AffineFastState.compose env23020 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound23020 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23021 : List Nat := [2,4,8,1,32,1,8,256,512,768,805,773,268,261,0,263,260,512,768,1,772,32,1,3,268,0,804,261,772,513,517,32,256,33,261,513]

theorem envBound23021 : H12AffineFastState.Bounded env23021 := by
  intro p hp
  have h : env23021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23020_23021 : H12AffineEnvironment.transform 3 1 env23020 = env23021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env23020 == env23021) = true)

theorem identity23021 : scanCanonicalize (H12AffineFastState.compose env23021 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound23021 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env23022 : List Nat := [2,4,8,1,32,1,8,256,261,5,32,0,268,261,0,263,260,261,5,1,1,32,1,3,268,0,33,261,1,260,256,32,256,33,261,260]

theorem envBound23022 : H12AffineFastState.Bounded env23022 := by
  intro p hp
  have h : env23022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23021_23022 : H12AffineEnvironment.transform 8 261 env23021 = env23022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env23021 == env23022) = true)

def env23023 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169264,16,21763,8193,65,215366,115015,17665,35188,119042,243002,256,98679,90203,63068]

theorem envBound23023 : H12AffineFastState.Bounded env23023 := by
  intro p hp
  have h : env23023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23010_23023 : H12AffineEnvironment.transform 6 9 env23010 = env23023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env23010 == env23023) = true)

theorem identity23023 : scanCanonicalize (H12AffineFastState.compose env23023 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound23023 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env23024 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,32041,1024,32769,4160,41340,16,21763,8193,65,97546,115015,17665,35188,119042,98678,256,98679,90203,63068]

theorem envBound23024 : H12AffineFastState.Bounded env23024 := by
  intro p hp
  have h : env23024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23023_23024 : H12AffineEnvironment.transform 16 13388 env23023 = env23024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env23023 == env23024) = true)

theorem identity23024 : scanCanonicalize (H12AffineFastState.compose env23024 (packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound23024 : packedSelected [0,3,5,7,9,10,12,14,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env23025 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,32768,65536,13388,31756,1024,32769,4160,41049,16,21542,8193,65,97327,114786,17444,34897,118823,98387,37,98386,90203,63068]

theorem envBound23025 : H12AffineFastState.Bounded env23025 := by
  intro p hp
  have h : env23025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23024_23025 : H12AffineEnvironment.transform 7 37 env23024 = env23025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env23024 == env23025) = true)

theorem identity23025 : scanCanonicalize (H12AffineFastState.compose env23025 (packedSelected [0,4,7,19,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 8313) := by decide +kernel

theorem selectedBound23025 : packedSelected [0,4,7,19,22,26] rootPS < 2^1333 := by decide +kernel

def env23026 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8313,65536,13388,31756,1024,8312,4160,32,16,21542,8193,65,97327,90139,17444,10280,94302,73770,37,73771,90203,22053]

theorem envBound23026 : H12AffineFastState.Bounded env23026 := by
  intro p hp
  have h : env23026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23025_23026 : H12AffineEnvironment.transform 14 8313 env23025 = env23026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8313 env23025 == env23026) = true)

theorem identity23026 : scanCanonicalize (H12AffineFastState.compose env23026 (packedSelected [0,1,2,3,5,6,7,8,10,12,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound23026 : packedSelected [0,1,2,3,5,6,7,8,10,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env23027 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,8192,16384,8313,8282,13388,31756,1024,8312,4160,32,16,21542,8193,65,23669,16449,17444,10280,20484,112,37,113,16385,22053]

theorem envBound23027 : H12AffineFastState.Bounded env23027 := by
  intro p hp
  have h : env23027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23026_23027 : H12AffineEnvironment.transform 15 8282 env23026 = env23027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env23026 == env23027) = true)

theorem identity23027 : scanCanonicalize (H12AffineFastState.compose env23027 (packedSelected [16,20] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound23027 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env23028 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,8192,16384,8232,8203,13341,31756,1024,8233,4113,32,16,21542,8193,16,23588,16400,17444,10280,20484,33,37,32,16385,22053]

theorem envBound23028 : H12AffineFastState.Bounded env23028 := by
  intro p hp
  have h : env23028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23027_23028 : H12AffineEnvironment.transform 5 17 env23027 = env23028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env23027 == env23028) = true)

theorem identity23028 : scanCanonicalize (H12AffineFastState.compose env23028 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound23028 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env23029 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,8192,16384,8200,8203,13341,31756,1024,8201,4113,0,16,21510,8193,16,23556,16400,17412,10248,20484,1,5,0,16385,22021]

theorem envBound23029 : H12AffineFastState.Bounded env23029 := by
  intro p hp
  have h : env23029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23028_23029 : H12AffineEnvironment.transform 4 0 env23028 = env23029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env23028 == env23029) = true)

theorem identity23029 : scanCanonicalize (H12AffineFastState.compose env23029 (packedSelected [4,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound23029 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env23030 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,9,16384,1,2,5140,23557,1024,0,4113,0,16,21510,8,16,23556,16400,17412,2049,20484,1,5,0,16385,22021]

theorem envBound23030 : H12AffineFastState.Bounded env23030 := by
  intro p hp
  have h : env23030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23029_23030 : H12AffineEnvironment.transform 12 9 env23029 = env23030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env23029 == env23030) = true)

theorem identity23030 : scanCanonicalize (H12AffineFastState.compose env23030 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1028) := by decide +kernel

theorem selectedBound23030 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env23031 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,4096,9,1028,1,2,5140,6145,1024,0,4113,0,16,4098,8,16,6144,1044,0,2049,5120,1,5,0,1029,4609]

theorem envBound23031 : H12AffineFastState.Bounded env23031 := by
  intro p hp
  have h : env23031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23030_23031 : H12AffineEnvironment.transform 13 1028 env23030 = env23031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1028 env23030 == env23031) = true)

theorem identity23031 : scanCanonicalize (H12AffineFastState.compose env23031 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2560) := by decide +kernel

theorem selectedBound23031 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env23032 : List Nat := [2,4,8,16,0,17,9,5,512,1024,2048,2560,9,1028,1,2,3604,513,1024,0,2577,0,16,2562,8,16,512,1044,0,2049,3584,1,5,0,1029,2049]

theorem envBound23032 : H12AffineFastState.Bounded env23032 := by
  intro p hp
  have h : env23032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23031_23032 : H12AffineEnvironment.transform 11 2560 env23031 = env23032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2560 env23031 == env23032) = true)

theorem identity23032 : scanCanonicalize (H12AffineFastState.compose env23032 (packedSelected [6] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound23032 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env23033 : List Nat := [2,4,8,16,0,17,9,5,512,1024,512,0,9,1028,1,2,1044,513,1024,0,17,0,16,2,8,16,512,1044,0,513,1024,1,5,0,1029,513]

theorem envBound23033 : H12AffineFastState.Bounded env23033 := by
  intro p hp
  have h : env23033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23032_23033 : H12AffineEnvironment.transform 10 512 env23032 = env23033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env23032 == env23033) = true)

theorem identity23033 : scanCanonicalize (H12AffineFastState.compose env23033 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 533) := by decide +kernel

theorem selectedBound23033 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env23034 : List Nat := [2,4,8,16,0,17,9,5,512,533,512,0,9,529,1,2,513,513,533,0,17,0,16,2,8,16,512,513,0,513,533,1,5,0,528,513]

theorem envBound23034 : H12AffineFastState.Bounded env23034 := by
  intro p hp
  have h : env23034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans23033_23034 : H12AffineEnvironment.transform 9 533 env23033 = env23034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 533 env23033 == env23034) = true)

theorem identity23034 : scanCanonicalize (H12AffineFastState.compose env23034 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

end H12CloudChart1