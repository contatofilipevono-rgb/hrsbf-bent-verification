import H12CloudChart1Data193

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans49145_49146 : H12AffineEnvironment.transform 6 8 env49145 = env49146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49145 == env49146) = true)

theorem identity49146 : scanCanonicalize (H12AffineFastState.compose env49146 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound49146 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env49147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,372,21795,131072,262144,1024,373,4160,147781,400500,412007,8192,65,262144,395637,416101,23809,1365,272393,256,21793,13689,30505]

theorem envBound49147 : H12AffineFastState.Bounded env49147 := by
  intro p hp
  have h : env49147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49146_49147 : H12AffineEnvironment.transform 14 372 env49146 = env49147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env49146 == env49147) = true)

theorem identity49147 : scanCanonicalize (H12AffineFastState.compose env49147 (packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,20,24,26,27,28] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49147 : packedSelected [0,2,3,6,8,11,12,14,15,16,17,18,20,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env49148 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,293,21795,131072,262144,1024,292,4113,147732,400421,411958,8192,16,262144,395556,416052,23809,1284,272393,256,21793,13608,30505]

theorem envBound49148 : H12AffineFastState.Bounded env49148 := by
  intro p hp
  have h : env49148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49147_49148 : H12AffineEnvironment.transform 5 17 env49147 = env49148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49147 == env49148) = true)

theorem identity49148 : scanCanonicalize (H12AffineFastState.compose env49148 (packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound49148 : packedSelected [1,2,4,6,8,11,12,15,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env49149 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,293,21795,131072,23808,1024,292,4113,147732,147749,136246,8192,16,23808,152612,132148,23809,1284,29961,256,21793,13608,30505]

theorem envBound49149 : H12AffineFastState.Bounded env49149 := by
  intro p hp
  have h : env49149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49148_49149 : H12AffineEnvironment.transform 17 23808 env49148 = env49149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env49148 == env49149) = true)

theorem identity49149 : scanCanonicalize (H12AffineFastState.compose env49149 (packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound49149 : packedSelected [3,4,5,9,10,12,14,15,16,17] rootPS < 2^1333 := by decide +kernel

def env49150 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,293,21795,5172,23808,1024,292,4113,21792,21777,2,8192,16,23808,16400,4096,23809,1284,29961,256,21793,13608,30505]

theorem envBound49150 : H12AffineFastState.Bounded env49150 := by
  intro p hp
  have h : env49150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49149_49150 : H12AffineEnvironment.transform 16 5172 env49149 = env49150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env49149 == env49150) = true)

theorem identity49150 : scanCanonicalize (H12AffineFastState.compose env49150 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound49150 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env49151 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,2340,293,7175,5172,5156,1024,292,4113,7172,7221,2,8192,16,5156,2356,4096,5157,1284,15405,256,7173,13608,15885]

theorem envBound49151 : H12AffineFastState.Bounded env49151 := by
  intro p hp
  have h : env49151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49150_49151 : H12AffineEnvironment.transform 13 2340 env49150 = env49151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env49150 == env49151) = true)

theorem identity49151 : scanCanonicalize (H12AffineFastState.compose env49151 (packedSelected [2,3,5,6,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound49151 : packedSelected [2,3,5,6,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49152 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3108,8192,2340,293,35,2064,2048,1024,292,3125,32,17,2,8192,16,2048,2356,3108,2049,1284,8201,256,33,10508,8745]

theorem envBound49152 : H12AffineFastState.Bounded env49152 := by
  intro p hp
  have h : env49152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49151_49152 : H12AffineEnvironment.transform 11 3108 env49151 = env49152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env49151 == env49152) = true)

theorem identity49152 : scanCanonicalize (H12AffineFastState.compose env49152 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49152 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env49153 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,3108,8192,2081,32,35,2064,2048,1024,33,3125,32,17,2,8192,16,2048,2097,3108,2049,1025,8201,5,33,10249,8745]

theorem envBound49153 : H12AffineFastState.Bounded env49153 := by
  intro p hp
  have h : env49153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49152_49153 : H12AffineEnvironment.transform 7 5 env49152 = env49153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49152 == env49153) = true)

theorem identity49153 : scanCanonicalize (H12AffineFastState.compose env49153 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound49153 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49154 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,3108,9,2081,32,35,2064,2048,1024,33,3125,32,17,2,9,16,2048,2097,3108,2049,1025,0,5,33,2048,544]

theorem envBound49154 : H12AffineFastState.Bounded env49154 := by
  intro p hp
  have h : env49154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49153_49154 : H12AffineEnvironment.transform 12 9 env49153 = env49154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env49153 == env49154) = true)

theorem identity49154 : scanCanonicalize (H12AffineFastState.compose env49154 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound49154 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env49155 : List Nat := [2,4,8,16,32,17,8,5,512,1024,1557,561,9,1588,32,35,1541,1557,1024,33,544,32,17,2,9,16,1557,1572,561,1556,1025,0,5,33,1557,544]

theorem envBound49155 : H12AffineFastState.Bounded env49155 := by
  intro p hp
  have h : env49155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49154_49155 : H12AffineEnvironment.transform 10 1557 env49154 = env49155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env49154 == env49155) = true)

theorem identity49155 : scanCanonicalize (H12AffineFastState.compose env49155 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49155 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49156 : List Nat := [2,4,8,16,1,17,8,5,512,1024,1557,528,9,1557,1,2,1541,1557,1024,0,513,1,17,2,9,16,1557,1541,528,1556,1025,0,5,0,1557,513]

theorem envBound49156 : H12AffineFastState.Bounded env49156 := by
  intro p hp
  have h : env49156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49155_49156 : H12AffineEnvironment.transform 4 1 env49155 = env49156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49155 == env49156) = true)

theorem identity49156 : scanCanonicalize (H12AffineFastState.compose env49156 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound49156 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49157 : List Nat := [2,4,8,16,1,17,8,5,512,4,529,528,9,529,1,2,513,529,4,0,513,1,17,2,9,16,529,513,528,528,5,0,5,0,529,513]

theorem envBound49157 : H12AffineFastState.Bounded env49157 := by
  intro p hp
  have h : env49157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49156_49157 : H12AffineEnvironment.transform 9 4 env49156 = env49157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env49156 == env49157) = true)

theorem identity49157 : scanCanonicalize (H12AffineFastState.compose env49157 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49157 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49158 : List Nat := [2,4,8,1,1,0,8,5,512,4,512,513,9,512,1,2,513,512,4,0,513,1,0,2,9,1,512,513,513,513,5,0,5,0,512,513]

theorem envBound49158 : H12AffineFastState.Bounded env49158 := by
  intro p hp
  have h : env49158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49157_49158 : H12AffineEnvironment.transform 3 1 env49157 = env49158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49157 == env49158) = true)

theorem identity49158 : scanCanonicalize (H12AffineFastState.compose env49158 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49158 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49159 : List Nat := [2,4,8,1,1,0,8,5,0,4,0,1,9,0,1,2,1,0,4,0,1,1,0,2,9,1,0,1,1,1,5,0,5,0,0,1]

theorem envBound49159 : H12AffineFastState.Bounded env49159 := by
  intro p hp
  have h : env49159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49158_49159 : H12AffineEnvironment.transform 8 0 env49158 = env49159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49158 == env49159) = true)

theorem identity49159 : scanCanonicalize (H12AffineFastState.compose env49159 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound49159 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49160 : List Nat := [2,4,2,1,1,0,2,5,0,4,0,1,3,0,1,2,1,0,4,0,1,1,0,2,3,1,0,1,1,1,5,0,5,0,0,1]

theorem envBound49160 : H12AffineFastState.Bounded env49160 := by
  intro p hp
  have h : env49160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49159_49160 : H12AffineEnvironment.transform 2 2 env49159 = env49160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env49159 == env49160) = true)

def env49161 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,4160,180273,400500,412007,8193,65,295285,395637,416101,56437,1364,272393,256,21793,46092,63068]

theorem envBound49161 : H12AffineFastState.Bounded env49161 := by
  intro p hp
  have h : env49161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49145_49161 : H12AffineEnvironment.transform 6 9 env49145 = env49161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49145 == env49161) = true)

theorem identity49161 : scanCanonicalize (H12AffineFastState.compose env49161 (packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound49161 : packedSelected [0,1,7,8,9,10,12,14,15,16,17,18,19,22,23,31] rootPS < 2^1333 := by decide +kernel

def env49162 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,131072,262144,1024,21761,4160,136497,400500,412007,8193,65,283765,395637,416101,2421,1364,272393,256,21793,24844,9052]

theorem envBound49162 : H12AffineFastState.Bounded env49162 := by
  intro p hp
  have h : env49162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49161_49162 : H12AffineEnvironment.transform 14 21760 env49161 = env49162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env49161 == env49162) = true)

theorem identity49162 : scanCanonicalize (H12AffineFastState.compose env49162 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound49162 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env49163 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,131072,146745,1024,21761,4160,136497,8525,29790,8193,65,158028,13388,25692,2421,1364,136496,256,21793,24844,9052]

theorem envBound49163 : H12AffineFastState.Bounded env49163 := by
  intro p hp
  have h : env49163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49162_49163 : H12AffineEnvironment.transform 17 146745 env49162 = env49163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env49162 == env49163) = true)

theorem identity49163 : scanCanonicalize (H12AffineFastState.compose env49163 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound49163 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49164 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,24908,23669,1024,21761,4160,29821,8525,29790,8193,65,2048,13388,25692,2421,1364,29820,256,21793,24844,9052]

theorem envBound49164 : H12AffineFastState.Bounded env49164 := by
  intro p hp
  have h : env49164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49163_49164 : H12AffineEnvironment.transform 16 24908 env49163 = env49164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env49163 == env49164) = true)

theorem identity49164 : scanCanonicalize (H12AffineFastState.compose env49164 (packedSelected [6,11,14,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49164 : packedSelected [6,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env49165 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,16384,21760,342,16741,23669,1024,21761,4160,21588,356,21623,40,65,2048,5221,17525,2421,1364,21589,256,21793,16677,885]

theorem envBound49165 : H12AffineFastState.Bounded env49165 := by
  intro p hp
  have h : env49165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49164_49165 : H12AffineEnvironment.transform 12 41 env49164 = env49165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49164 == env49165) = true)

theorem identity49165 : scanCanonicalize (H12AffineFastState.compose env49165 (packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound49165 : packedSelected [0,2,3,5,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env49166 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5237,373,342,5392,2048,1024,372,4160,33,356,2,40,65,2048,5221,4096,2421,1364,32,256,340,5456,885]

theorem envBound49166 : H12AffineFastState.Bounded env49166 := by
  intro p hp
  have h : env49166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49165_49166 : H12AffineEnvironment.transform 13 5237 env49165 = env49166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env49165 == env49166) = true)

theorem identity49166 : scanCanonicalize (H12AffineFastState.compose env49166 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound49166 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49167 : List Nat := [2,4,8,16,32,64,9,256,512,273,2048,4096,41,4452,373,342,4097,2048,273,372,4160,33,356,2,40,65,2048,4468,4096,2421,69,32,256,340,4161,885]

theorem envBound49167 : H12AffineFastState.Bounded env49167 := by
  intro p hp
  have h : env49167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49166_49167 : H12AffineEnvironment.transform 9 273 env49166 = env49167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env49166 == env49167) = true)

theorem identity49167 : scanCanonicalize (H12AffineFastState.compose env49167 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49167 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49168 : List Nat := [2,4,8,16,32,64,9,37,512,52,2048,4096,41,4161,80,115,4097,2048,52,81,4160,33,65,2,40,65,2048,4177,4096,2128,69,32,37,113,4161,592]

theorem envBound49168 : H12AffineFastState.Bounded env49168 := by
  intro p hp
  have h : env49168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49167_49168 : H12AffineEnvironment.transform 7 37 env49167 = env49168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49167 == env49168) = true)

theorem identity49168 : scanCanonicalize (H12AffineFastState.compose env49168 (packedSelected [3,5,6] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound49168 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env49169 : List Nat := [2,4,8,16,16,64,9,21,512,4,2048,4096,25,4161,80,67,4097,2048,4,81,4160,17,65,2,24,65,2048,4177,4096,2128,69,16,21,65,4161,592]

theorem envBound49169 : H12AffineFastState.Bounded env49169 := by
  intro p hp
  have h : env49169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49168_49169 : H12AffineEnvironment.transform 4 16 env49168 = env49169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env49168 == env49169) = true)

theorem identity49169 : scanCanonicalize (H12AffineFastState.compose env49169 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49169 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49170 : List Nat := [2,4,8,16,16,0,9,21,512,4,2048,4096,25,4097,16,3,4097,2048,4,17,4096,17,1,2,24,1,2048,4113,4096,2064,5,16,21,1,4097,528]

theorem envBound49170 : H12AffineFastState.Bounded env49170 := by
  intro p hp
  have h : env49170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49169_49170 : H12AffineEnvironment.transform 5 0 env49169 = env49170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49169 == env49170) = true)

theorem identity49170 : scanCanonicalize (H12AffineFastState.compose env49170 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49170 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49171 : List Nat := [2,4,8,0,0,0,9,5,512,4,2048,4096,9,4097,0,3,4097,2048,4,1,4096,1,1,2,8,1,2048,4097,4096,2048,5,0,5,1,4097,512]

theorem envBound49171 : H12AffineFastState.Bounded env49171 := by
  intro p hp
  have h : env49171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49170_49171 : H12AffineEnvironment.transform 3 0 env49170 = env49171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49170 == env49171) = true)

theorem identity49171 : scanCanonicalize (H12AffineFastState.compose env49171 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound49171 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49172 : List Nat := [2,4,8,0,0,0,9,5,512,4,512,4096,9,4097,0,3,4097,512,4,1,4096,1,1,2,8,1,512,4097,4096,512,5,0,5,1,4097,512]

theorem envBound49172 : H12AffineFastState.Bounded env49172 := by
  intro p hp
  have h : env49172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49171_49172 : H12AffineEnvironment.transform 10 512 env49171 = env49172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env49171 == env49172) = true)

theorem identity49172 : scanCanonicalize (H12AffineFastState.compose env49172 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 517) := by decide +kernel

theorem selectedBound49172 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49173 : List Nat := [2,4,8,0,0,0,9,5,512,4,512,517,9,516,0,3,516,512,4,1,517,1,1,2,8,1,512,516,517,512,5,0,5,1,516,512]

theorem envBound49173 : H12AffineFastState.Bounded env49173 := by
  intro p hp
  have h : env49173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49172_49173 : H12AffineEnvironment.transform 11 517 env49172 = env49173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 517 env49172 == env49173) = true)

theorem identity49173 : scanCanonicalize (H12AffineFastState.compose env49173 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49173 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env49174 : List Nat := [2,1,8,0,0,0,9,0,512,1,512,512,9,513,0,3,513,512,1,1,512,1,1,2,8,1,512,513,512,512,0,0,0,1,513,512]

theorem envBound49174 : H12AffineFastState.Bounded env49174 := by
  intro p hp
  have h : env49174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49173_49174 : H12AffineEnvironment.transform 1 1 env49173 = env49174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49173 == env49174) = true)

def env49175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510123,499128,8328,65,349475,395636,495035,67754,119042,272392,256,98815,90203,63189]

theorem envBound49175 : H12AffineFastState.Bounded env49175 := by
  intro p hp
  have h : env49175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49143_49175 : H12AffineEnvironment.transform 20 4161 env49143 = env49175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49143 == env49175) = true)

theorem identity49175 : scanCanonicalize (H12AffineFastState.compose env49175 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound49175 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212079,1024,32769,4161,180273,62660,41431,8328,65,158028,79131,45524,67754,119042,201831,256,98815,90203,63189]

theorem envBound49176 : H12AffineFastState.Bounded env49176 := by
  intro p hp
  have h : env49176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49175_49176 : H12AffineEnvironment.transform 17 212079 env49175 = env49176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env49175 == env49176) = true)

theorem identity49176 : scanCanonicalize (H12AffineFastState.compose env49176 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound49176 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env49177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212079,1024,29909,4161,144613,16,21763,8328,65,158028,79131,17664,67754,75222,201831,256,95531,90203,513]

theorem envBound49177 : H12AffineFastState.Bounded env49177 := by
  intro p hp
  have h : env49177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49176_49177 : H12AffineEnvironment.transform 14 29908 env49176 = env49177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env49176 == env49177) = true)

theorem identity49177 : scanCanonicalize (H12AffineFastState.compose env49177 (packedSelected [4,9,11,14,17,18,20,23,32] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49177 : packedSelected [4,9,11,14,17,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env49178 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,65536,131072,204083,1024,21897,4161,136633,16,21763,468,65,149520,70727,17664,67754,66698,201831,256,87159,82183,513]

theorem envBound49178 : H12AffineFastState.Bounded env49178 := by
  intro p hp
  have h : env49178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49177_49178 : H12AffineEnvironment.transform 12 348 env49177 = env49178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49177 == env49178) = true)

theorem identity49178 : scanCanonicalize (H12AffineFastState.compose env49178 (packedSelected [0,1,3,7,9,14,15,17,18,19,20,22,23,24,26,28,38] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound49178 : packedSelected [0,1,3,7,9,14,15,17,18,19,20,22,23,24,26,28,38] rootPS < 2^1333 := by decide +kernel

def env49179 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21896,479,131072,138476,1024,21897,4161,136633,16,21763,468,65,149520,5528,17664,2421,1365,136632,256,21928,16600,513]

theorem envBound49179 : H12AffineFastState.Bounded env49179 := by
  intro p hp
  have h : env49179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49178_49179 : H12AffineEnvironment.transform 15 479 env49178 = env49179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env49178 == env49179) = true)

theorem identity49179 : scanCanonicalize (H12AffineFastState.compose env49179 (packedSelected [1,3,5,8,10,17,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound49179 : packedSelected [1,3,5,8,10,17,18,19,23] rootPS < 2^1333 := by decide +kernel

def env49180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5456,216,479,131072,138476,1024,217,4161,136633,16,83,468,65,138560,5528,4176,2421,1365,136632,256,248,5512,513]

theorem envBound49180 : H12AffineFastState.Bounded env49180 := by
  intro p hp
  have h : env49180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49179_49180 : H12AffineEnvironment.transform 13 5456 env49179 = env49180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env49179 == env49180) = true)

theorem identity49180 : scanCanonicalize (H12AffineFastState.compose env49180 (packedSelected [0,1,2,3,4,5,6,7,8,10,17,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound49180 : packedSelected [0,1,2,3,4,5,6,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env49181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5456,216,479,5528,2420,1024,217,4161,33,16,83,468,65,2264,5528,4176,2421,1365,32,256,248,5512,513]

theorem envBound49181 : H12AffineFastState.Bounded env49181 := by
  intro p hp
  have h : env49181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49180_49181 : H12AffineEnvironment.transform 16 5528 env49180 = env49181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env49180 == env49181) = true)

theorem identity49181 : scanCanonicalize (H12AffineFastState.compose env49181 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49181 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,81,342,5393,2420,1024,80,4161,33,16,83,349,65,2129,5393,4176,2421,1365,32,256,113,5377,513]

theorem envBound49182 : H12AffineFastState.Bounded env49182 := by
  intro p hp
  have h : env49182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49181_49182 : H12AffineEnvironment.transform 6 9 env49181 = env49182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49181 == env49182) = true)

theorem identity49182 : scanCanonicalize (H12AffineFastState.compose env49182 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49182 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49183 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,1,262,5393,2340,1024,0,4113,33,16,3,269,17,2049,5393,4096,2341,1285,32,256,33,5377,513]

theorem envBound49183 : H12AffineFastState.Bounded env49183 := by
  intro p hp
  have h : env49183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49182_49183 : H12AffineEnvironment.transform 5 16 env49182 = env49183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49182 == env49183) = true)

theorem identity49183 : scanCanonicalize (H12AffineFastState.compose env49183 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound49183 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49184 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,292,268,1060,1,262,1077,2340,1024,0,309,33,16,3,269,17,2049,1077,292,2341,1285,32,256,33,1061,513]

theorem envBound49184 : H12AffineFastState.Bounded env49184 := by
  intro p hp
  have h : env49184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49183_49184 : H12AffineEnvironment.transform 11 292 env49183 = env49184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env49183 == env49184) = true)

theorem identity49184 : scanCanonicalize (H12AffineFastState.compose env49184 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound49184 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49185 : List Nat := [2,4,8,16,32,16,9,256,512,564,2048,292,268,528,1,262,513,2340,564,0,309,33,16,3,269,17,2049,513,292,2341,817,32,256,33,529,513]

theorem envBound49185 : H12AffineFastState.Bounded env49185 := by
  intro p hp
  have h : env49185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49184_49185 : H12AffineEnvironment.transform 9 564 env49184 = env49185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env49184 == env49185) = true)

theorem identity49185 : scanCanonicalize (H12AffineFastState.compose env49185 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound49185 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49186 : List Nat := [2,4,8,16,32,16,9,256,512,564,821,292,268,528,1,262,513,529,564,0,309,33,16,3,269,17,820,513,292,528,817,32,256,33,529,513]

theorem envBound49186 : H12AffineFastState.Bounded env49186 := by
  intro p hp
  have h : env49186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49185_49186 : H12AffineEnvironment.transform 10 821 env49185 = env49186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env49185 == env49186) = true)

def env49187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,180273,510123,499129,8328,65,349474,2496820,2596346,67754,119043,2373704,256,2199999,2191387,63188]

theorem envBound49187 : H12AffineFastState.Bounded env49187 := by
  intro p hp
  have h : env49187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49142_49187 : H12AffineEnvironment.transform 23 499129 env49142 = env49187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 499129 env49142 == env49187) = true)

def env49188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,180273,510123,499129,8328,65,349474,395636,495034,67754,119043,272392,256,98815,90203,63188]

theorem envBound49188 : H12AffineFastState.Bounded env49188 := by
  intro p hp
  have h : env49188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49187_49188 : H12AffineEnvironment.transform 20 4160 env49187 = env49188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49187 == env49188) = true)

theorem identity49188 : scanCanonicalize (H12AffineFastState.compose env49188 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound49188 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,4160,180273,16,21762,8328,65,171417,115151,17665,67754,119043,254131,256,98815,90203,63188]

theorem envBound49189 : H12AffineFastState.Bounded env49189 := by
  intro p hp
  have h : env49189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49188_49189 : H12AffineEnvironment.transform 17 247995 env49188 = env49189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env49188 == env49189) = true)

def env49190 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,180273,16,21762,8192,65,171281,115015,17665,67618,119043,254011,256,98679,90203,63068]

theorem envBound49190 : H12AffineFastState.Bounded env49190 := by
  intro p hp
  have h : env49190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49189_49190 : H12AffineEnvironment.transform 6 8 env49189 = env49190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49189 == env49190) = true)

theorem identity49190 : scanCanonicalize (H12AffineFastState.compose env49190 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound49190 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49191 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,35189,1024,32769,4160,98679,16,21762,8192,65,121943,115015,17665,67618,119043,41341,256,98679,90203,63068]

theorem envBound49191 : H12AffineFastState.Bounded env49191 := by
  intro p hp
  have h : env49191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49190_49191 : H12AffineEnvironment.transform 16 82246 env49190 = env49191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env49190 == env49191) = true)

theorem identity49191 : scanCanonicalize (H12AffineFastState.compose env49191 (packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound49191 : packedSelected [0,1,4,8,12,14,15,16,18,19,22,23,27] rootPS < 2^1333 := by decide +kernel

def env49192 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,65536,78911,35189,1024,32769,4160,98679,16,8315,8192,65,108846,111678,12408,67618,107642,41341,256,98679,70946,33573]

theorem envBound49192 : H12AffineFastState.Bounded env49192 := by
  intro p hp
  have h : env49192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49191_49192 : H12AffineEnvironment.transform 13 13689 env49191 = env49192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env49191 == env49192) = true)

theorem identity49192 : scanCanonicalize (H12AffineFastState.compose env49192 (packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound49192 : packedSelected [0,2,4,5,6,7,9,11,12,14,15,16,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env49193 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13689,32768,33111,46440,35189,1024,32769,4160,32,16,8315,8192,65,10361,13673,12408,35189,9517,41341,256,32,38005,33573]

theorem envBound49193 : H12AffineFastState.Bounded env49193 := by
  intro p hp
  have h : env49193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49192_49193 : H12AffineEnvironment.transform 15 33111 env49192 = env49193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env49192 == env49193) = true)

theorem identity49193 : scanCanonicalize (H12AffineFastState.compose env49193 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound49193 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env49194 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5457,32768,33111,38208,35189,1024,32769,4160,32,16,83,40,65,2129,5441,4176,35189,1285,33109,256,32,38005,33573]

theorem envBound49194 : H12AffineFastState.Bounded env49194 := by
  intro p hp
  have h : env49194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49193_49194 : H12AffineEnvironment.transform 12 40 env49193 = env49194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env49193 == env49194) = true)

theorem identity49194 : scanCanonicalize (H12AffineFastState.compose env49194 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49194 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49195 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,32768,33031,38160,35109,1024,32769,4112,32,16,3,40,17,2049,5393,4096,35109,1285,33029,256,32,37925,33573]

theorem envBound49195 : H12AffineFastState.Bounded env49195 := by
  intro p hp
  have h : env49195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49194_49195 : H12AffineEnvironment.transform 5 16 env49194 = env49195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49194 == env49195) = true)

theorem identity49195 : scanCanonicalize (H12AffineFastState.compose env49195 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound49195 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env49196 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,293,34,5173,2048,1024,292,4112,32,16,3,40,17,2049,5393,4096,2048,1285,32,256,32,5376,512]

theorem envBound49196 : H12AffineFastState.Bounded env49196 := by
  intro p hp
  have h : env49196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49195_49196 : H12AffineEnvironment.transform 14 293 env49195 = env49196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env49195 == env49196) = true)

theorem identity49196 : scanCanonicalize (H12AffineFastState.compose env49196 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49196 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49197 : List Nat := [2,4,8,16,1,16,8,256,512,1024,2048,4096,9,5377,260,3,5140,2048,1024,261,4112,1,16,3,9,17,2049,5393,4096,2048,1285,1,256,1,5376,512]

theorem envBound49197 : H12AffineFastState.Bounded env49197 := by
  intro p hp
  have h : env49197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49196_49197 : H12AffineEnvironment.transform 4 1 env49196 = env49197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49196 == env49197) = true)

theorem identity49197 : scanCanonicalize (H12AffineFastState.compose env49197 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 260) := by decide +kernel

theorem selectedBound49197 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env49198 : List Nat := [2,4,8,16,1,16,8,256,512,1024,260,4096,9,5377,260,3,5140,260,1024,261,4112,1,16,3,9,17,261,5393,4096,260,1285,1,256,1,5376,512]

theorem envBound49198 : H12AffineFastState.Bounded env49198 := by
  intro p hp
  have h : env49198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49197_49198 : H12AffineEnvironment.transform 10 260 env49197 = env49198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 260 env49197 == env49198) = true)

theorem identity49198 : scanCanonicalize (H12AffineFastState.compose env49198 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound49198 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env49199 : List Nat := [2,4,8,16,1,16,8,4,512,1024,0,4096,9,5125,0,3,5140,0,1024,1,4112,1,16,3,9,17,1,5141,4096,0,1025,1,4,1,5124,512]

theorem envBound49199 : H12AffineFastState.Bounded env49199 := by
  intro p hp
  have h : env49199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49198_49199 : H12AffineEnvironment.transform 7 4 env49198 = env49199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env49198 == env49199) = true)

theorem identity49199 : scanCanonicalize (H12AffineFastState.compose env49199 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1550) := by decide +kernel

theorem selectedBound49199 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49200 : List Nat := [2,4,8,16,1,16,8,4,512,1024,0,1550,9,523,0,3,538,0,1024,1,1566,1,16,3,9,17,1,539,1550,0,1025,1,4,1,522,512]

theorem envBound49200 : H12AffineFastState.Bounded env49200 := by
  intro p hp
  have h : env49200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49199_49200 : H12AffineEnvironment.transform 11 1550 env49199 = env49200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1550 env49199 == env49200) = true)

theorem identity49200 : scanCanonicalize (H12AffineFastState.compose env49200 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound49200 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49201 : List Nat := [2,4,8,2,1,2,8,4,512,1024,0,1550,9,523,0,3,520,0,1024,1,1548,1,2,3,9,3,1,521,1550,0,1025,1,4,1,522,512]

theorem envBound49201 : H12AffineFastState.Bounded env49201 := by
  intro p hp
  have h : env49201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49200_49201 : H12AffineEnvironment.transform 3 2 env49200 = env49201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env49200 == env49201) = true)

def env49202 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,4160,180273,16,21762,8193,65,171280,115014,17665,67619,119043,254010,256,98678,90203,63069]

theorem envBound49202 : H12AffineFastState.Bounded env49202 := by
  intro p hp
  have h : env49202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49189_49202 : H12AffineEnvironment.transform 6 9 env49189 = env49202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49189 == env49202) = true)

theorem identity49202 : scanCanonicalize (H12AffineFastState.compose env49202 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound49202 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49203 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10280,1024,32769,4160,73771,16,21762,8193,65,97546,115014,17665,67619,119043,32,256,98678,90203,63069]

theorem envBound49203 : H12AffineFastState.Bounded env49203 := by
  intro p hp
  have h : env49203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49202_49203 : H12AffineEnvironment.transform 16 122906 env49202 = env49203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env49202 == env49203) = true)

theorem identity49203 : scanCanonicalize (H12AffineFastState.compose env49203 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound49203 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env49204 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10280,1024,32769,4160,32800,16,21762,8193,65,56577,24909,17665,43048,28936,32,256,8573,49232,63069]

theorem envBound49204 : H12AffineFastState.Bounded env49204 := by
  intro p hp
  have h : env49204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49203_49204 : H12AffineEnvironment.transform 15 40971 env49203 = env49204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env49203 == env49204) = true)

theorem identity49204 : scanCanonicalize (H12AffineFastState.compose env49204 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound49204 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8202,16401,10280,1024,0,4160,33,16,21762,8193,65,23808,24909,17665,10281,28936,32,256,8573,16465,30300]

theorem envBound49205 : H12AffineFastState.Bounded env49205 := by
  intro p hp
  have h : env49205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49204_49205 : H12AffineEnvironment.transform 14 1 env49204 = env49205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env49204 == env49205) = true)

theorem identity49205 : scanCanonicalize (H12AffineFastState.compose env49205 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound49205 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env49206 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,1,8202,13340,10280,1024,0,4160,33,16,8463,8193,65,10509,5440,12556,10281,1285,32,256,8573,13404,593]

theorem envBound49206 : H12AffineFastState.Bounded env49206 := by
  intro p hp
  have h : env49206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49205_49206 : H12AffineEnvironment.transform 13 13325 env49205 = env49206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env49205 == env49206) = true)

theorem identity49206 : scanCanonicalize (H12AffineFastState.compose env49206 (packedSelected [0,1,6,7,8,11] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound49206 : packedSelected [0,1,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env49207 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6429,3344,1,6423,3329,4405,1024,0,4160,33,16,6162,6428,65,4112,5440,2065,4404,1285,32,256,6240,3393,593]

theorem envBound49207 : H12AffineFastState.Bounded env49207 := by
  intro p hp
  have h : env49207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49206_49207 : H12AffineEnvironment.transform 12 6429 env49206 = env49207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env49206 == env49207) = true)

theorem identity49207 : scanCanonicalize (H12AffineFastState.compose env49207 (packedSelected [3,5,6,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound49207 : packedSelected [3,5,6,12,14] rootPS < 2^1333 := by decide +kernel

def env49208 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,348,3344,1,342,3329,2420,1024,0,2049,33,16,83,349,65,2129,3329,2065,2421,1285,32,256,33,3393,593]

theorem envBound49208 : H12AffineFastState.Bounded env49208 := by
  intro p hp
  have h : env49208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49207_49208 : H12AffineEnvironment.transform 11 2113 env49207 = env49208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env49207 == env49208) = true)

theorem identity49208 : scanCanonicalize (H12AffineFastState.compose env49208 (packedSelected [4,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound49208 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env49209 : List Nat := [2,4,8,16,32,64,9,256,512,320,2048,2113,348,2128,1,342,2113,2420,320,0,2049,33,16,83,349,65,2129,2113,2065,2421,69,32,256,33,2049,593]

theorem envBound49209 : H12AffineFastState.Bounded env49209 := by
  intro p hp
  have h : env49209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49208_49209 : H12AffineEnvironment.transform 9 320 env49208 = env49209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env49208 == env49209) = true)

theorem identity49209 : scanCanonicalize (H12AffineFastState.compose env49209 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound49209 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env49210 : List Nat := [2,4,8,16,32,64,9,116,512,52,2048,2113,40,2128,1,34,2113,2048,52,0,2049,33,16,83,41,65,2129,2113,2065,2049,69,32,116,33,2049,593]

theorem envBound49210 : H12AffineFastState.Bounded env49210 := by
  intro p hp
  have h : env49210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49209_49210 : H12AffineEnvironment.transform 7 116 env49209 = env49210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env49209 == env49210) = true)

theorem identity49210 : scanCanonicalize (H12AffineFastState.compose env49210 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49210 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env49211 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2064,40,2049,1,34,2064,2048,52,0,2049,33,16,2,41,16,2048,2064,2065,2049,20,32,37,33,2049,512]

theorem envBound49211 : H12AffineFastState.Bounded env49211 := by
  intro p hp
  have h : env49211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49210_49211 : H12AffineEnvironment.transform 5 17 env49210 = env49211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49210 == env49211) = true)

theorem identity49211 : scanCanonicalize (H12AffineFastState.compose env49211 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 564) := by decide +kernel

theorem selectedBound49211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49212 : List Nat := [2,4,8,16,32,17,9,37,512,52,564,548,40,565,1,34,548,564,52,0,565,33,16,2,41,16,564,548,549,565,20,32,37,33,565,512]

theorem envBound49212 : H12AffineFastState.Bounded env49212 := by
  intro p hp
  have h : env49212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49211_49212 : H12AffineEnvironment.transform 10 564 env49211 = env49212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 564 env49211 == env49212) = true)

theorem identity49212 : scanCanonicalize (H12AffineFastState.compose env49212 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 12) := by decide +kernel

theorem selectedBound49212 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49213 : List Nat := [2,4,8,16,12,17,9,9,512,24,536,520,4,537,1,14,520,536,24,0,537,13,16,2,5,16,536,520,521,537,20,12,9,13,537,512]

theorem envBound49213 : H12AffineFastState.Bounded env49213 := by
  intro p hp
  have h : env49213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49212_49213 : H12AffineEnvironment.transform 4 12 env49212 = env49213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env49212 == env49213) = true)

theorem identity49213 : scanCanonicalize (H12AffineFastState.compose env49213 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound49213 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49214 : List Nat := [2,4,5,16,1,17,4,4,512,21,533,517,4,532,1,3,517,533,21,0,532,0,16,2,5,16,533,517,516,532,20,1,4,0,532,512]

theorem envBound49214 : H12AffineFastState.Bounded env49214 := by
  intro p hp
  have h : env49214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49213_49214 : H12AffineEnvironment.transform 2 5 env49213 = env49214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env49213 == env49214) = true)

theorem identity49214 : scanCanonicalize (H12AffineFastState.compose env49214 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound49214 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env49215 : List Nat := [2,4,5,16,1,17,4,4,7,21,18,2,4,19,1,3,2,18,21,0,19,0,16,2,5,16,18,2,3,19,20,1,4,0,19,7]

theorem envBound49215 : H12AffineFastState.Bounded env49215 := by
  intro p hp
  have h : env49215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49214_49215 : H12AffineEnvironment.transform 8 7 env49214 = env49215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env49214 == env49215) = true)

theorem identity49215 : scanCanonicalize (H12AffineFastState.compose env49215 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound49215 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49216 : List Nat := [2,4,5,3,1,2,4,4,7,6,1,2,4,0,1,3,2,1,6,0,0,0,3,2,5,3,1,2,3,0,7,1,4,0,0,7]

theorem envBound49216 : H12AffineFastState.Bounded env49216 := by
  intro p hp
  have h : env49216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49215_49216 : H12AffineEnvironment.transform 3 3 env49215 = env49216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env49215 == env49216) = true)

def env49217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,180273,510123,499129,8328,65,349474,395637,495035,67754,119043,272393,256,98814,90202,63188]

theorem envBound49217 : H12AffineFastState.Bounded env49217 := by
  intro p hp
  have h : env49217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49187_49217 : H12AffineEnvironment.transform 20 4161 env49187 = env49217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49187 == env49217) = true)

theorem identity49217 : scanCanonicalize (H12AffineFastState.compose env49217 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49217 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,4161,180273,452768,441778,8328,65,292137,395637,437680,10401,61704,272393,256,41461,16465,63188]

theorem envBound49218 : H12AffineFastState.Bounded env49218 := by
  intro p hp
  have h : env49218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49217_49218 : H12AffineEnvironment.transform 15 8203 env49217 = env49218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49217 == env49218) = true)

theorem identity49218 : scanCanonicalize (H12AffineFastState.compose env49218 (packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 146744) := by decide +kernel

theorem selectedBound49218 : packedSelected [1,4,7,9,11,12,15,18,19,23,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env49219 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,146744,1024,32769,4161,180273,54680,32906,8328,65,149521,13389,37000,10401,61704,136497,256,41461,16465,63188]

theorem envBound49219 : H12AffineFastState.Bounded env49219 := by
  intro p hp
  have h : env49219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49218_49219 : H12AffineEnvironment.transform 17 146744 env49218 = env49219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146744 env49218 == env49219) = true)

theorem identity49219 : scanCanonicalize (H12AffineFastState.compose env49219 (packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound49219 : packedSelected [0,5,8,9,11,17,18,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env49220 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,131072,146744,1024,32769,4161,169401,32784,32906,8328,65,138649,13389,37000,10401,42112,136497,256,41461,5593,41820]

theorem envBound49220 : H12AffineFastState.Bounded env49220 := by
  intro p hp
  have h : env49220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49219_49220 : H12AffineEnvironment.transform 13 5512 env49219 = env49220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env49219 == env49220) = true)

theorem identity49220 : scanCanonicalize (H12AffineFastState.compose env49220 (packedSelected [3,4,7,9,10,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound49220 : packedSelected [3,4,7,9,10,24,26,27] rootPS < 2^1333 := by decide +kernel

def env49221 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,8203,46276,35324,1024,32769,4161,8573,32784,32906,8328,65,43357,13389,37000,10401,42112,41461,256,41461,5593,41820]

theorem envBound49221 : H12AffineFastState.Bounded env49221 := by
  intro p hp
  have h : env49221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49220_49221 : H12AffineEnvironment.transform 16 46276 env49220 = env49221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env49220 == env49221) = true)

theorem identity49221 : scanCanonicalize (H12AffineFastState.compose env49221 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49221 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env49222 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8541,8203,5529,10401,1024,8540,4161,8573,8525,8663,8328,65,2048,13389,12757,10401,1501,168,256,168,5593,513]

theorem envBound49222 : H12AffineFastState.Bounded env49222 := by
  intro p hp
  have h : env49222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49221_49222 : H12AffineEnvironment.transform 14 8541 env49221 = env49222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49221 == env49222) = true)

theorem identity49222 : scanCanonicalize (H12AffineFastState.compose env49222 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49222 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49223 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,0,342,5529,2556,1024,1,4161,32,16,138,469,65,2048,5392,4232,2556,1501,168,256,168,5593,513]

theorem envBound49223 : H12AffineFastState.Bounded env49223 := by
  intro p hp
  have h : env49223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49222_49223 : H12AffineEnvironment.transform 12 349 env49222 = env49223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49222 == env49223) = true)

theorem identity49223 : scanCanonicalize (H12AffineFastState.compose env49223 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49223 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49224 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5393,2420,1024,1,4161,32,16,2,349,65,2048,5392,4096,2420,1365,32,256,32,5457,513]

theorem envBound49224 : H12AffineFastState.Bounded env49224 := by
  intro p hp
  have h : env49224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49223_49224 : H12AffineEnvironment.transform 6 8 env49223 = env49224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49223 == env49224) = true)

theorem identity49224 : scanCanonicalize (H12AffineFastState.compose env49224 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 383) := by decide +kernel

theorem selectedBound49224 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49225 : List Nat := [2,4,8,16,32,64,8,256,512,1024,383,4096,349,5376,0,342,5393,11,1024,1,4161,32,16,2,349,65,383,5392,4096,11,1365,32,256,32,5457,513]

theorem envBound49225 : H12AffineFastState.Bounded env49225 := by
  intro p hp
  have h : env49225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49224_49225 : H12AffineEnvironment.transform 10 383 env49224 = env49225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 383 env49224 == env49225) = true)

theorem identity49225 : scanCanonicalize (H12AffineFastState.compose env49225 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 373) := by decide +kernel

theorem selectedBound49225 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49226 : List Nat := [2,4,8,16,32,64,8,256,512,1024,383,373,349,1141,0,342,1124,11,1024,1,308,32,16,2,349,65,383,1125,373,11,1365,32,256,32,1060,513]

theorem envBound49226 : H12AffineFastState.Bounded env49226 := by
  intro p hp
  have h : env49226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49225_49226 : H12AffineEnvironment.transform 11 373 env49225 = env49226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 373 env49225 == env49226) = true)

def env49227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507601,8830976,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound49227 : H12AffineFastState.Bounded env49227 := by
  intro p hp
  have h : env49227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49004_49227 : H12AffineEnvironment.transform 18 1025 env49004 = env49227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env49004 == env49227) = true)

theorem identity49227 : scanCanonicalize (H12AffineFastState.compose env49227 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound49227 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,272426,8328,65,12838954,2469030,10507601,8830976,8760379,6639082,257,10873990,10816803,8686573]

theorem envBound49228 : H12AffineFastState.Bounded env49228 := by
  intro p hp
  have h : env49228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49227_49228 : H12AffineEnvironment.transform 23 272426 env49227 = env49228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env49227 == env49228) = true)

def env49229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147592,272426,8328,65,4303010,2469030,2233817,295048,519347,6639082,257,2599950,2575787,445285]

theorem envBound49229 : H12AffineFastState.Bounded env49229 := by
  intro p hp
  have h : env49229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49228_49229 : H12AffineEnvironment.transform 22 147592 env49228 = env49229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env49228 == env49229) = true)

def env49230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303010,2469030,2119113,295048,371875,6639082,257,2485278,2428347,297845]

theorem envBound49230 : H12AffineFastState.Bounded env49230 := by
  intro p hp
  have h : env49230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49229_49230 : H12AffineEnvironment.transform 16 16400 env49229 = env49230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49229 == env49230) = true)

theorem identity49230 : scanCanonicalize (H12AffineFastState.compose env49230 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound49230 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1025,32769,2097152,4194304,152,138,8328,65,4303010,2196486,2119113,43048,99331,6382922,257,2213054,2172187,41941]

theorem envBound49231 : H12AffineFastState.Bounded env49231 := by
  intro p hp
  have h : env49231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49230_49231 : H12AffineEnvironment.transform 17 10400 env49230 = env49231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49230 == env49231) = true)

def env49232 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,2097152,4194304,16,2,8192,65,4302890,2196486,2118977,43048,99331,6382922,257,2212918,2172187,41821]

theorem envBound49232 : H12AffineFastState.Bounded env49232 := by
  intro p hp
  have h : env49232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49231_49232 : H12AffineEnvironment.transform 6 8 env49231 = env49232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49231 == env49232) = true)

theorem identity49232 : scanCanonicalize (H12AffineFastState.compose env49232 (packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound49232 : packedSelected [0,3,7,8,9,11,12,14,15,17,18,19,20,22,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env49233 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,16400,10280,1025,32769,2097152,4194304,16,2,8192,65,4196384,2106380,2118977,43048,9225,6341952,257,2122812,2131217,41821]

theorem envBound49233 : H12AffineFastState.Bounded env49233 := by
  intro p hp
  have h : env49233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49232_49233 : H12AffineEnvironment.transform 15 40970 env49232 = env49233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env49232 == env49233) = true)

theorem identity49233 : scanCanonicalize (H12AffineFastState.compose env49233 (packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49233 : packedSelected [0,1,2,3,5,6,11,12,14,15,16,19,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env49234 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33110,16400,2420,1025,32769,2097152,4194304,16,2,348,65,4196384,2098512,2118977,35188,1365,6341952,257,2114912,2131217,33281]

theorem envBound49234 : H12AffineFastState.Bounded env49234 := by
  intro p hp
  have h : env49234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49233_49234 : H12AffineEnvironment.transform 12 348 env49233 = env49234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49233 == env49234) = true)

theorem identity49234 : scanCanonicalize (H12AffineFastState.compose env49234 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(20+1) ^^^ 17729) := by decide +kernel

theorem selectedBound49234 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env49235 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33110,16400,2420,1025,32769,17729,4194304,16,2,348,65,4196384,16401,4096,35188,1365,4227073,257,33,49232,33281]

theorem envBound49235 : H12AffineFastState.Bounded env49235 := by
  intro p hp
  have h : env49235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49234_49235 : H12AffineEnvironment.transform 20 17729 env49234 = env49235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env49234 == env49235) = true)

theorem identity49235 : scanCanonicalize (H12AffineFastState.compose env49235 (packedSelected [1,8,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound49235 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env49236 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,33110,16400,2420,1025,32769,17729,33,16,2,348,65,2049,16401,4096,35188,1365,32800,257,33,49232,33281]

theorem envBound49236 : H12AffineFastState.Bounded env49236 := by
  intro p hp
  have h : env49236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49235_49236 : H12AffineEnvironment.transform 21 33 env49235 = env49236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env49235 == env49236) = true)

theorem identity49236 : scanCanonicalize (H12AffineFastState.compose env49236 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21873) := by decide +kernel

theorem selectedBound49236 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env49237 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21873,21543,16400,2420,1025,21872,17729,33,16,2,348,65,2049,16401,4096,23557,1365,21841,257,33,5409,22384]

theorem envBound49237 : H12AffineFastState.Bounded env49237 := by
  intro p hp
  have h : env49237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49236_49237 : H12AffineEnvironment.transform 14 21873 env49236 = env49237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21873 env49236 == env49237) = true)

theorem identity49237 : scanCanonicalize (H12AffineFastState.compose env49237 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49237 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env49238 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21793,21543,16400,2340,1025,21792,17681,33,16,2,268,17,2049,16401,4096,23557,1285,21761,257,33,5409,22304]

theorem envBound49238 : H12AffineFastState.Bounded env49238 := by
  intro p hp
  have h : env49238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49237_49238 : H12AffineEnvironment.transform 5 16 env49237 = env49238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49237 == env49238) = true)

theorem identity49238 : scanCanonicalize (H12AffineFastState.compose env49238 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(13+1) ^^^ 6714) := by decide +kernel

theorem selectedBound49238 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env49239 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,6714,3867,3613,6698,2340,1025,3866,7979,33,16,2,268,17,2049,6699,4096,1599,1285,3899,257,33,5409,3354]

theorem envBound49239 : H12AffineFastState.Bounded env49239 := by
  intro p hp
  have h : env49239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49238_49239 : H12AffineEnvironment.transform 13 6714 env49238 = env49239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6714 env49238 == env49239) = true)

theorem identity49239 : scanCanonicalize (H12AffineFastState.compose env49239 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1566) := by decide +kernel

theorem selectedBound49239 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env49240 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1566,4096,268,5156,261,3,5172,1850,1025,260,4405,33,16,2,268,17,1567,5173,4096,1599,1285,293,257,33,5409,772]

theorem envBound49240 : H12AffineFastState.Bounded env49240 := by
  intro p hp
  have h : env49240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49239_49240 : H12AffineEnvironment.transform 10 1566 env49239 = env49240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1566 env49239 == env49240) = true)

theorem identity49240 : scanCanonicalize (H12AffineFastState.compose env49240 (packedSelected [2,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound49240 : packedSelected [2,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env49241 : List Nat := [2,4,8,16,32,16,8,5,512,1024,1566,4096,9,5156,0,3,5172,1599,1025,1,4144,33,16,2,9,17,1567,5173,4096,1599,1024,32,4,33,5156,513]

theorem envBound49241 : H12AffineFastState.Bounded env49241 := by
  intro p hp
  have h : env49241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49240_49241 : H12AffineEnvironment.transform 7 5 env49240 = env49241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env49240 == env49241) = true)

theorem identity49241 : scanCanonicalize (H12AffineFastState.compose env49241 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49241 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49242 : List Nat := [2,4,8,16,17,16,8,5,512,1024,1566,4096,9,5141,0,3,5125,1550,1025,1,4097,16,16,2,9,17,1567,5124,4096,1550,1024,17,4,16,5141,513]

theorem envBound49242 : H12AffineFastState.Bounded env49242 := by
  intro p hp
  have h : env49242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49241_49242 : H12AffineEnvironment.transform 4 17 env49241 = env49242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49241 == env49242) = true)

theorem identity49242 : scanCanonicalize (H12AffineFastState.compose env49242 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 529) := by decide +kernel

theorem selectedBound49242 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49243 : List Nat := [2,4,8,16,17,16,8,5,512,1024,1566,529,9,1540,0,3,1556,1550,1025,1,528,16,16,2,9,17,1567,1557,529,1550,1024,17,4,16,1540,513]

theorem envBound49243 : H12AffineFastState.Bounded env49243 := by
  intro p hp
  have h : env49243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49242_49243 : H12AffineEnvironment.transform 11 529 env49242 = env49243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 529 env49242 == env49243) = true)

def env49244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,2097152,4194304,17,3,8193,65,4302891,2196486,2118976,43048,99331,6382922,257,2212919,2172187,41820]

theorem envBound49244 : H12AffineFastState.Bounded env49244 := by
  intro p hp
  have h : env49244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49231_49244 : H12AffineEnvironment.transform 6 9 env49231 = env49244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49231 == env49244) = true)

theorem identity49244 : scanCanonicalize (H12AffineFastState.compose env49244 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49244 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env49245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,2097152,4194304,17,3,8193,65,4262262,2172251,2118976,2421,75102,6382922,257,2188650,2172187,513]

theorem envBound49245 : H12AffineFastState.Bounded env49245 := by
  intro p hp
  have h : env49245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49244_49245 : H12AffineEnvironment.transform 14 8541 env49244 = env49245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49244 == env49245) = true)

theorem identity49245 : scanCanonicalize (H12AffineFastState.compose env49245 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49245 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env49246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10281,1025,8540,2097152,4194304,17,3,8193,65,4204925,2098512,2118976,2421,1365,6309185,257,2114913,2098448,513]

theorem envBound49246 : H12AffineFastState.Bounded env49246 := by
  intro p hp
  have h : env49246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49245_49246 : H12AffineEnvironment.transform 15 8203 env49245 = env49246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49245 == env49246) = true)

theorem identity49246 : scanCanonicalize (H12AffineFastState.compose env49246 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound49246 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4096,10281,1025,8540,2097152,4194304,17,3,8193,65,4204925,2098512,2098512,2421,1365,6296913,257,2102641,2098448,513]

theorem envBound49247 : H12AffineFastState.Bounded env49247 := by
  intro p hp
  have h : env49247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49246_49247 : H12AffineEnvironment.transform 13 4112 env49246 = env49247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env49246 == env49247) = true)

theorem identity49247 : scanCanonicalize (H12AffineFastState.compose env49247 (packedSelected [4,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 2100577) := by decide +kernel

theorem selectedBound49247 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env49248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4096,10281,1025,8540,2097152,2100577,17,3,8193,65,2106396,2098512,2098512,2421,1365,6192,257,2102641,2098448,513]

theorem envBound49248 : H12AffineFastState.Bounded env49248 := by
  intro p hp
  have h : env49248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49247_49248 : H12AffineEnvironment.transform 21 2100577 env49247 = env49248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2100577 env49247 == env49248) = true)

theorem identity49248 : scanCanonicalize (H12AffineFastState.compose env49248 (packedSelected [0,7,14,18] rootPS)) = affineNative (2^(20+1) ^^^ 12392) := by decide +kernel

theorem selectedBound49248 : packedSelected [0,7,14,18] rootPS < 2^1333 := by decide +kernel

def env49249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8203,4096,10281,1025,8540,12392,15625,17,3,8193,65,5236,13624,13624,2421,1365,6192,257,9497,13688,513]

theorem envBound49249 : H12AffineFastState.Bounded env49249 := by
  intro p hp
  have h : env49249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49248_49249 : H12AffineEnvironment.transform 20 12392 env49248 = env49249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 12392 env49248 == env49249) = true)

theorem identity49249 : scanCanonicalize (H12AffineFastState.compose env49249 (packedSelected [0,7,20] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound49249 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env49250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,4112,1125,1331,4096,3345,1025,1124,5456,6193,17,3,1337,65,5236,4096,4096,2421,1365,6192,257,33,4160,513]

theorem envBound49250 : H12AffineFastState.Bounded env49250 := by
  intro p hp
  have h : env49250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49249_49250 : H12AffineEnvironment.transform 12 1336 env49249 = env49250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env49249 == env49250) = true)

theorem identity49250 : scanCanonicalize (H12AffineFastState.compose env49250 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound49250 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2113,1336,2129,1125,1331,2113,3345,1025,1124,3345,112,17,3,1337,65,3125,2113,2113,2421,1365,113,257,33,2049,513]

theorem envBound49251 : H12AffineFastState.Bounded env49251 := by
  intro p hp
  have h : env49251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49250_49251 : H12AffineEnvironment.transform 11 2113 env49250 = env49251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env49250 == env49251) = true)

theorem identity49251 : scanCanonicalize (H12AffineFastState.compose env49251 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound49251 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env49252 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2113,349,2129,0,342,2113,2420,100,1,2420,112,17,3,348,65,2128,2113,2113,2421,304,113,257,33,2049,513]

theorem envBound49252 : H12AffineFastState.Bounded env49252 := by
  intro p hp
  have h : env49252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49251_49252 : H12AffineEnvironment.transform 9 101 env49251 = env49252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env49251 == env49252) = true)

theorem identity49252 : scanCanonicalize (H12AffineFastState.compose env49252 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49252 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env49253 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2064,268,2048,0,263,2064,2341,53,1,2341,33,17,3,269,16,2049,2064,2064,2340,304,32,257,33,2049,513]

theorem envBound49253 : H12AffineFastState.Bounded env49253 := by
  intro p hp
  have h : env49253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49252_49253 : H12AffineEnvironment.transform 5 17 env49252 = env49253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49252 == env49253) = true)

theorem identity49253 : scanCanonicalize (H12AffineFastState.compose env49253 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49253 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49254 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2064,41,2048,0,34,2064,2048,53,1,2048,33,17,3,40,16,2049,2064,2064,2049,21,32,36,33,2049,513]

theorem envBound49254 : H12AffineFastState.Bounded env49254 := by
  intro p hp
  have h : env49254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49253_49254 : H12AffineEnvironment.transform 7 37 env49253 = env49254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49253 == env49254) = true)

theorem identity49254 : scanCanonicalize (H12AffineFastState.compose env49254 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound49254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49255 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,41,48,0,34,32,48,53,1,48,33,17,3,40,16,49,32,32,49,21,32,36,33,49,513]

theorem envBound49255 : H12AffineFastState.Bounded env49255 := by
  intro p hp
  have h : env49255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49254_49255 : H12AffineEnvironment.transform 10 48 env49254 = env49255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env49254 == env49255) = true)

def leafEnv49255 : List Nat := [2,4,8,16,32,17,9,37,512,52,48,32,41,48,0,34,32,48,53,1,48,33,17,3,20,40,1,16,49,32,32,49,21,32,36,33,5,35,49,513,1,49,0]

def active49255 : List Nat := [0,1,2,3,4,8]

def tree49255 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49255 : H12WitnessSearch.Good tree49255 := H12GlobalWitnessIndex.good

theorem leafIdentity49255 : H12AffineFastState.composeSystem env49255 rootObs = leafEnv49255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49255 rootObs == leafEnv49255) = true)

theorem terminalChecked49255 : H12PackedTerminal.terminalCheckFast leafEnv49255 active49255 tree49255 = true := by decide +kernel

def env49256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303010,2469030,2119112,295048,371874,6639082,257,2485279,2428346,297844]

theorem envBound49256 : H12AffineFastState.Bounded env49256 := by
  intro p hp
  have h : env49256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49229_49256 : H12AffineEnvironment.transform 16 16401 env49229 = env49256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49229 == env49256) = true)

theorem identity49256 : scanCanonicalize (H12AffineFastState.compose env49256 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49256 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49257 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,17,272426,8192,65,4302890,2468910,2118976,294912,371754,6638946,257,2485279,2428210,297844]

theorem envBound49257 : H12AffineFastState.Bounded env49257 := by
  intro p hp
  have h : env49257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49256_49257 : H12AffineEnvironment.transform 6 8 env49256 = env49257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49256 == env49257) = true)

theorem identity49257 : scanCanonicalize (H12AffineFastState.compose env49257 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound49257 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env49258 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,2097152,4194304,17,41311,8192,65,4302890,2172251,2118976,2421,75103,6407191,257,2188650,2196551,513]

theorem envBound49258 : H12AffineFastState.Bounded env49258 := by
  intro p hp
  have h : env49258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49257_49258 : H12AffineEnvironment.transform 17 35189 env49257 = env49258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env49257 == env49258) = true)

theorem identity49258 : scanCanonicalize (H12AffineFastState.compose env49258 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound49258 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env49259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1025,32769,115735,4194304,17,41311,8192,65,4302890,57676,102743,2421,75103,4194304,257,41341,16464,513]

theorem envBound49259 : H12AffineFastState.Bounded env49259 := by
  intro p hp
  have h : env49259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49258_49259 : H12AffineEnvironment.transform 20 115735 env49258 = env49259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env49258 == env49259) = true)

theorem identity49259 : scanCanonicalize (H12AffineFastState.compose env49259 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49259 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env49260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91466,4194304,17,2,8192,65,4262263,16401,77834,2421,75103,4194304,257,32,16464,513]

theorem envBound49260 : H12AffineFastState.Bounded env49260 := by
  intro p hp
  have h : env49260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49259_49260 : H12AffineEnvironment.transform 14 8541 env49259 = env49260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49259 == env49260) = true)

theorem identity49260 : scanCanonicalize (H12AffineFastState.compose env49260 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound49260 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env49261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10280,1025,8540,17729,4194304,17,2,8192,65,4204924,16401,4097,2421,1364,4194304,257,32,16464,513]

theorem envBound49261 : H12AffineFastState.Bounded env49261 := by
  intro p hp
  have h : env49261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49260_49261 : H12AffineEnvironment.transform 15 8203 env49260 = env49261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env49260 == env49261) = true)

theorem identity49261 : scanCanonicalize (H12AffineFastState.compose env49261 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49261 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49262 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,8460,8203,16401,10280,1025,8461,17680,4194304,17,2,8192,16,4204845,16401,4097,2340,1285,4194304,257,32,16385,513]

theorem envBound49262 : H12AffineFastState.Bounded env49262 := by
  intro p hp
  have h : env49262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49261_49262 : H12AffineEnvironment.transform 5 17 env49261 = env49262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49261 == env49262) = true)

theorem identity49262 : scanCanonicalize (H12AffineFastState.compose env49262 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15366) := by decide +kernel

theorem selectedBound49262 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49263 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,15366,8460,8203,15383,10280,1025,8461,14614,4194304,17,2,8192,16,4204845,15383,4097,2340,1285,4194304,257,32,15367,513]

theorem envBound49263 : H12AffineFastState.Bounded env49263 := by
  intro p hp
  have h : env49263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49262_49263 : H12AffineEnvironment.transform 13 15366 env49262 = env49263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15366 env49262 == env49263) = true)

theorem identity49263 : scanCanonicalize (H12AffineFastState.compose env49263 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound49263 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49264 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,7435,1,262,7450,2341,1025,0,6171,4194304,17,2,269,16,4196384,7450,4097,2340,1285,4194304,257,32,7434,513]

theorem envBound49264 : H12AffineFastState.Bounded env49264 := by
  intro p hp
  have h : env49264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49263_49264 : H12AffineEnvironment.transform 12 269 env49263 = env49264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env49263 == env49264) = true)

theorem identity49264 : scanCanonicalize (H12AffineFastState.compose env49264 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 5141) := by decide +kernel

theorem selectedBound49264 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49265 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,7435,1,262,7450,2341,1025,0,6171,5141,17,2,269,16,7221,7450,4097,2340,1285,5141,257,32,7434,513]

theorem envBound49265 : H12AffineFastState.Bounded env49265 := by
  intro p hp
  have h : env49265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49264_49265 : H12AffineEnvironment.transform 21 5141 env49264 = env49265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5141 env49264 == env49265) = true)

theorem identity49265 : scanCanonicalize (H12AffineFastState.compose env49265 (packedSelected [1,3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound49265 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env49266 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1077,269,2366,1,262,2351,2341,1025,0,3118,32,17,2,269,16,2048,2351,1076,2340,1285,32,257,32,2367,513]

theorem envBound49266 : H12AffineFastState.Bounded env49266 := by
  intro p hp
  have h : env49266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49265_49266 : H12AffineEnvironment.transform 11 1077 env49265 = env49266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env49265 == env49266) = true)

theorem identity49266 : scanCanonicalize (H12AffineFastState.compose env49266 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 270) := by decide +kernel

theorem selectedBound49266 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49267 : List Nat := [2,4,8,16,32,17,8,256,512,1024,270,1077,269,48,1,262,33,43,1025,0,1312,32,17,2,269,16,270,33,1076,42,1285,32,257,32,49,513]

theorem envBound49267 : H12AffineFastState.Bounded env49267 := by
  intro p hp
  have h : env49267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49266_49267 : H12AffineEnvironment.transform 10 270 env49266 = env49267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 270 env49266 == env49267) = true)

theorem identity49267 : scanCanonicalize (H12AffineFastState.compose env49267 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound49267 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49268 : List Nat := [2,4,8,16,32,17,8,20,512,1024,26,1077,25,48,1,18,33,43,1025,0,1076,32,17,2,25,16,26,33,1076,42,1041,32,21,32,49,513]

theorem envBound49268 : H12AffineFastState.Bounded env49268 := by
  intro p hp
  have h : env49268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49267_49268 : H12AffineEnvironment.transform 7 20 env49267 = env49268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env49267 == env49268) = true)

theorem identity49268 : scanCanonicalize (H12AffineFastState.compose env49268 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound49268 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49269 : List Nat := [2,4,8,16,32,17,8,20,10,1024,26,1077,25,48,1,18,33,43,1025,0,1076,32,17,2,25,16,26,33,1076,42,1041,32,21,32,49,11]

theorem envBound49269 : H12AffineFastState.Bounded env49269 := by
  intro p hp
  have h : env49269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49268_49269 : H12AffineEnvironment.transform 8 10 env49268 = env49269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env49268 == env49269) = true)

theorem identity49269 : scanCanonicalize (H12AffineFastState.compose env49269 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound49269 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env49270 : List Nat := [2,4,8,13,32,12,8,9,10,1024,7,1064,4,45,1,15,33,43,1025,0,1065,32,12,2,4,13,7,33,1065,42,1036,32,8,32,44,11]

theorem envBound49270 : H12AffineFastState.Bounded env49270 := by
  intro p hp
  have h : env49270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49269_49270 : H12AffineEnvironment.transform 3 13 env49269 = env49270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env49269 == env49270) = true)

theorem identity49270 : scanCanonicalize (H12AffineFastState.compose env49270 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 3) := by decide +kernel

theorem selectedBound49270 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49271 : List Nat := [2,4,8,13,32,12,8,9,10,3,7,43,4,45,1,15,33,43,2,0,42,32,12,2,4,13,7,33,42,42,15,32,8,32,44,11]

theorem envBound49271 : H12AffineFastState.Bounded env49271 := by
  intro p hp
  have h : env49271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49270_49271 : H12AffineEnvironment.transform 9 3 env49270 = env49271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 3 env49270 == env49271) = true)

def env49272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,147593,272426,8328,65,4303011,2469030,2233816,295049,519346,6639082,257,2599951,2575786,445284]

theorem envBound49272 : H12AffineFastState.Bounded env49272 := by
  intro p hp
  have h : env49272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49228_49272 : H12AffineEnvironment.transform 22 147593 env49228 = env49272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env49228 == env49272) = true)

def env49273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,153,272426,8328,65,4303011,2469030,2119112,295049,371874,6639082,257,2485279,2428346,297844]

theorem envBound49273 : H12AffineFastState.Bounded env49273 := by
  intro p hp
  have h : env49273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49272_49273 : H12AffineEnvironment.transform 16 16400 env49272 = env49273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env49272 == env49273) = true)

theorem identity49273 : scanCanonicalize (H12AffineFastState.compose env49273 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 35325) := by decide +kernel

theorem selectedBound49273 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35325,1025,32769,2097152,4194304,153,41431,8328,65,4303011,2172251,2119112,2420,75103,6407191,257,2188770,2196551,649]

theorem envBound49274 : H12AffineFastState.Bounded env49274 := by
  intro p hp
  have h : env49274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49273_49274 : H12AffineEnvironment.transform 17 35325 env49273 = env49274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35325 env49273 == env49274) = true)

def env49275 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,2097152,4194304,17,41311,8192,65,4302891,2172251,2118976,2420,75103,6407191,257,2188650,2196551,513]

theorem envBound49275 : H12AffineFastState.Bounded env49275 := by
  intro p hp
  have h : env49275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49274_49275 : H12AffineEnvironment.transform 6 8 env49274 = env49275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49274 == env49275) = true)

theorem identity49275 : scanCanonicalize (H12AffineFastState.compose env49275 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound49275 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49276 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1025,32769,115735,4194304,17,41311,8192,65,4302891,57676,102743,2420,75103,4194304,257,41341,16464,513]

theorem envBound49276 : H12AffineFastState.Bounded env49276 := by
  intro p hp
  have h : env49276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49275_49276 : H12AffineEnvironment.transform 20 115735 env49275 = env49276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env49275 == env49276) = true)

def env49277 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,65536,16400,10589,1025,8233,91199,4194304,17,375,8192,65,4261891,16740,78207,2420,75103,4194304,257,341,16464,513]

theorem envBound49277 : H12AffineFastState.Bounded env49277 := by
  intro p hp
  have h : env49277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49276_49277 : H12AffineEnvironment.transform 14 8232 env49276 = env49277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env49276 == env49277) = true)

theorem identity49277 : scanCanonicalize (H12AffineFastState.compose env49277 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound49277 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env49278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,34,16400,10589,1025,8233,25629,4194304,17,375,8192,65,4196385,16740,12637,2420,9597,4194304,257,341,16464,513]

theorem envBound49278 : H12AffineFastState.Bounded env49278 := by
  intro p hp
  have h : env49278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49277_49278 : H12AffineEnvironment.transform 15 34 env49277 = env49278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env49277 == env49278) = true)

theorem identity49278 : scanCanonicalize (H12AffineFastState.compose env49278 (packedSelected [1,2,5,6,8,24] rootPS)) = affineNative (2^(21+1) ^^^ 8280) := by decide +kernel

theorem selectedBound49278 : packedSelected [1,2,5,6,8,24] rootPS < 2^1333 := by decide +kernel

def env49279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,34,16400,10589,1025,8233,25629,8280,17,375,8192,65,10361,16740,12637,2420,9597,8280,257,341,16464,513]

theorem envBound49279 : H12AffineFastState.Bounded env49279 := by
  intro p hp
  have h : env49279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49278_49279 : H12AffineEnvironment.transform 21 8280 env49278 = env49279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8280 env49278 == env49279) = true)

theorem identity49279 : scanCanonicalize (H12AffineFastState.compose env49279 (packedSelected [4,7,9,27] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49279 : packedSelected [4,7,9,27] rootPS < 2^1333 := by decide +kernel

def env49280 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,8192,16384,8232,34,16400,10280,1025,8233,25629,8280,17,2,8192,65,10361,16401,12328,2049,9224,8280,116,32,16464,513]

theorem envBound49280 : H12AffineFastState.Bounded env49280 := by
  intro p hp
  have h : env49280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49279_49280 : H12AffineEnvironment.transform 7 117 env49279 = env49280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49279 == env49280) = true)

theorem identity49280 : scanCanonicalize (H12AffineFastState.compose env49280 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49280 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49281 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,16384,8232,34,16400,10280,1025,8233,25629,8200,17,2,8192,17,10281,16401,12328,2049,9224,8200,36,32,16384,513]

theorem envBound49281 : H12AffineFastState.Bounded env49281 := by
  intro p hp
  have h : env49281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49280_49281 : H12AffineEnvironment.transform 5 16 env49280 = env49281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49280 == env49281) = true)

theorem identity49281 : scanCanonicalize (H12AffineFastState.compose env49281 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound49281 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49282 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,8192,13325,8232,34,13341,10280,1025,8233,4112,8200,17,2,8192,17,10281,13340,12328,2049,9224,8200,36,32,13325,513]

theorem envBound49282 : H12AffineFastState.Bounded env49282 := by
  intro p hp
  have h : env49282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49281_49282 : H12AffineEnvironment.transform 13 13325 env49281 = env49282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env49281 == env49282) = true)

theorem identity49282 : scanCanonicalize (H12AffineFastState.compose env49282 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49282 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49283 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,41,5156,1,34,5172,2049,1025,0,4112,33,17,2,41,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound49283 : H12AffineFastState.Bounded env49283 := by
  intro p hp
  have h : env49283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49282_49283 : H12AffineEnvironment.transform 12 41 env49282 = env49283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49282 == env49283) = true)

def env49284 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,48,41,1044,1,34,1028,2049,1025,0,32,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound49284 : H12AffineFastState.Bounded env49284 := by
  intro p hp
  have h : env49284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49283_49284 : H12AffineEnvironment.transform 11 48 env49283 = env49284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49283 == env49284) = true)

theorem identity49284 : scanCanonicalize (H12AffineFastState.compose env49284 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound49284 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49285 : List Nat := [2,4,8,16,32,16,8,37,48,1024,2048,48,41,1044,1,34,1028,2049,1025,0,32,33,17,2,41,17,2048,1029,49,2049,1057,33,36,32,1044,49]

theorem envBound49285 : H12AffineFastState.Bounded env49285 := by
  intro p hp
  have h : env49285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49284_49285 : H12AffineEnvironment.transform 8 48 env49284 = env49285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env49284 == env49285) = true)

def env49286 : List Nat := [2,4,8,16,32,16,8,37,48,52,2048,48,41,32,1,34,48,2049,53,0,32,33,17,2,41,17,2048,49,49,2049,21,33,36,32,32,49]

theorem envBound49286 : H12AffineFastState.Bounded env49286 := by
  intro p hp
  have h : env49286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49285_49286 : H12AffineEnvironment.transform 9 52 env49285 = env49286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49285 == env49286) = true)

def env49287 : List Nat := [2,4,8,16,32,16,8,37,48,53,2048,48,41,33,1,34,49,2049,52,0,32,33,17,2,41,17,2048,48,49,2049,20,33,36,32,33,49]

theorem envBound49287 : H12AffineFastState.Bounded env49287 := by
  intro p hp
  have h : env49287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49285_49287 : H12AffineEnvironment.transform 9 53 env49285 = env49287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49285 == env49287) = true)

theorem identity49287 : scanCanonicalize (H12AffineFastState.compose env49287 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49287 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49288 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,43,41,33,1,34,42,2049,47,0,32,33,10,2,41,10,2048,43,42,2049,15,33,36,32,33,42]

theorem envBound49288 : H12AffineFastState.Bounded env49288 := by
  intro p hp
  have h : env49288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49287_49288 : H12AffineEnvironment.transform 3 11 env49287 = env49288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49287 == env49288) = true)

def leafEnv49288 : List Nat := [2,4,8,11,32,11,8,37,43,46,2048,43,41,33,1,34,42,2049,47,0,32,33,10,2,14,41,1,10,2048,43,42,2049,15,33,36,32,5,34,33,42,1,32,0]

def active49288 : List Nat := [0,1,2,4,10]

def tree49288 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49288 : H12WitnessSearch.Good tree49288 := H12GlobalWitnessIndex.good

theorem leafIdentity49288 : H12AffineFastState.composeSystem env49288 rootObs = leafEnv49288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49288 rootObs == leafEnv49288) = true)

theorem terminalChecked49288 : H12PackedTerminal.terminalCheckFast leafEnv49288 active49288 tree49288 = true := by decide +kernel

def env49289 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,49,41,1045,1,34,1029,2049,1025,0,33,33,17,2,41,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound49289 : H12AffineFastState.Bounded env49289 := by
  intro p hp
  have h : env49289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49283_49289 : H12AffineEnvironment.transform 11 49 env49283 = env49289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49283 == env49289) = true)

theorem identity49289 : scanCanonicalize (H12AffineFastState.compose env49289 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound49289 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49290 : List Nat := [2,4,8,16,32,16,8,37,512,516,2048,49,41,529,1,34,513,2049,517,0,33,33,17,2,41,17,2048,512,48,2049,549,33,36,32,529,513]

theorem envBound49290 : H12AffineFastState.Bounded env49290 := by
  intro p hp
  have h : env49290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49289_49290 : H12AffineEnvironment.transform 9 516 env49289 = env49290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env49289 == env49290) = true)

def env49291 : List Nat := [2,4,8,16,32,16,8,37,48,52,2048,49,41,33,1,34,49,2049,53,0,33,33,17,2,41,17,2048,48,48,2049,21,33,36,32,33,49]

theorem envBound49291 : H12AffineFastState.Bounded env49291 := by
  intro p hp
  have h : env49291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49290_49291 : H12AffineEnvironment.transform 8 48 env49290 = env49291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env49290 == env49291) = true)

def env49292 : List Nat := [2,4,8,16,32,16,8,37,49,53,2048,49,41,32,1,34,48,2049,52,0,33,33,17,2,41,17,2048,49,48,2049,20,33,36,32,32,48]

theorem envBound49292 : H12AffineFastState.Bounded env49292 := by
  intro p hp
  have h : env49292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49290_49292 : H12AffineEnvironment.transform 8 49 env49290 = env49292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env49290 == env49292) = true)

theorem identity49292 : scanCanonicalize (H12AffineFastState.compose env49292 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound49292 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49293 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,42,41,32,1,34,43,2049,47,0,33,33,10,2,41,10,2048,42,43,2049,15,33,36,32,32,43]

theorem envBound49293 : H12AffineFastState.Bounded env49293 := by
  intro p hp
  have h : env49293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49292_49293 : H12AffineEnvironment.transform 3 11 env49292 = env49293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env49292 == env49293) = true)

def leafEnv49293 : List Nat := [2,4,8,11,32,11,8,37,42,46,2048,42,41,32,1,34,43,2049,47,0,33,33,10,2,14,41,1,10,2048,42,43,2049,15,33,36,32,5,34,32,43,1,33,0]

def active49293 : List Nat := [0,1,2,4,10]

def tree49293 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49293 : H12WitnessSearch.Good tree49293 := H12GlobalWitnessIndex.good

theorem leafIdentity49293 : H12AffineFastState.composeSystem env49293 rootObs = leafEnv49293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49293 rootObs == leafEnv49293) = true)

theorem terminalChecked49293 : H12PackedTerminal.terminalCheckFast leafEnv49293 active49293 tree49293 = true := by decide +kernel

def env49294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,65536,16400,10588,1025,8232,91198,4194304,17,374,8192,65,4261890,16741,78206,2420,75103,4194304,257,340,16464,513]

theorem envBound49294 : H12AffineFastState.Bounded env49294 := by
  intro p hp
  have h : env49294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49276_49294 : H12AffineEnvironment.transform 14 8233 env49276 = env49294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8233 env49276 == env49294) = true)

theorem identity49294 : scanCanonicalize (H12AffineFastState.compose env49294 (packedSelected [2,6,11,23] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound49294 : packedSelected [2,6,11,23] rootPS < 2^1333 := by decide +kernel

def env49295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,343,16400,10588,1025,8232,25961,4194304,17,374,8192,65,4196693,16741,12329,2420,9224,4194304,257,340,16464,513]

theorem envBound49295 : H12AffineFastState.Bounded env49295 := by
  intro p hp
  have h : env49295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49294_49295 : H12AffineEnvironment.transform 15 343 env49294 = env49295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env49294 == env49295) = true)

theorem identity49295 : scanCanonicalize (H12AffineFastState.compose env49295 (packedSelected [1,3,5,8,10,11,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound49295 : packedSelected [1,3,5,8,10,11,18,19] rootPS < 2^1333 := by decide +kernel

def env49296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8233,343,16400,10588,1025,8232,25961,8201,17,374,8192,65,10588,16741,12329,2420,9224,8201,257,340,16464,513]

theorem envBound49296 : H12AffineFastState.Bounded env49296 := by
  intro p hp
  have h : env49296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49295_49296 : H12AffineEnvironment.transform 21 8201 env49295 = env49296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env49295 == env49296) = true)

theorem identity49296 : scanCanonicalize (H12AffineFastState.compose env49296 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49296 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env49297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,373,343,16400,2048,1025,372,17461,341,17,374,348,65,2048,16741,4469,2420,1364,341,257,340,16464,513]

theorem envBound49297 : H12AffineFastState.Bounded env49297 := by
  intro p hp
  have h : env49297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49296_49297 : H12AffineEnvironment.transform 12 348 env49296 = env49297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49296 == env49297) = true)

theorem identity49297 : scanCanonicalize (H12AffineFastState.compose env49297 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49297 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49298 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,293,263,16400,2048,1025,292,17461,261,17,294,268,17,2048,16693,4389,2340,1284,261,257,260,16384,513]

theorem envBound49298 : H12AffineFastState.Bounded env49298 := by
  intro p hp
  have h : env49298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49297_49298 : H12AffineEnvironment.transform 5 16 env49297 = env49298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49297 == env49298) = true)

theorem identity49298 : scanCanonicalize (H12AffineFastState.compose env49298 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound49298 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env49299 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,16384,1,35,16400,2048,1025,0,17461,33,17,2,40,17,2048,16401,4097,2048,1056,33,37,32,16384,513]

theorem envBound49299 : H12AffineFastState.Bounded env49299 := by
  intro p hp
  have h : env49299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49298_49299 : H12AffineEnvironment.transform 7 36 env49298 = env49299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env49298 == env49299) = true)

theorem identity49299 : scanCanonicalize (H12AffineFastState.compose env49299 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound49299 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49300 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5156,1,35,5172,2048,1025,0,4113,33,17,2,40,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound49300 : H12AffineFastState.Bounded env49300 := by
  intro p hp
  have h : env49300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49299_49300 : H12AffineEnvironment.transform 13 5156 env49299 = env49300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env49299 == env49300) = true)

def env49301 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,40,1044,1,35,1028,2048,1025,0,33,33,17,2,40,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound49301 : H12AffineFastState.Bounded env49301 := by
  intro p hp
  have h : env49301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49300_49301 : H12AffineEnvironment.transform 11 48 env49300 = env49301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env49300 == env49301) = true)

theorem identity49301 : scanCanonicalize (H12AffineFastState.compose env49301 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound49301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49302 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1044,48,40,1044,1,35,1028,1044,1025,0,33,33,17,2,40,17,1044,1029,49,1044,1056,33,37,32,1044,513]

theorem envBound49302 : H12AffineFastState.Bounded env49302 := by
  intro p hp
  have h : env49302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49301_49302 : H12AffineEnvironment.transform 10 1044 env49301 = env49302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env49301 == env49302) = true)

def env49303 : List Nat := [2,4,8,16,32,16,8,36,512,52,32,48,40,32,1,35,48,32,53,0,33,33,17,2,40,17,32,49,49,32,20,33,37,32,32,513]

theorem envBound49303 : H12AffineFastState.Bounded env49303 := by
  intro p hp
  have h : env49303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49302_49303 : H12AffineEnvironment.transform 9 52 env49302 = env49303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49302 == env49303) = true)

def env49304 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,48,40,33,1,35,49,33,52,0,33,33,17,2,40,17,33,48,49,33,21,33,37,32,33,513]

theorem envBound49304 : H12AffineFastState.Bounded env49304 := by
  intro p hp
  have h : env49304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49302_49304 : H12AffineEnvironment.transform 9 53 env49302 = env49304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49302 == env49304) = true)

theorem identity49304 : scanCanonicalize (H12AffineFastState.compose env49304 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound49304 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49305 : List Nat := [2,4,8,16,32,16,8,36,42,53,33,48,40,33,1,35,49,33,52,0,33,33,17,2,40,17,33,48,49,33,21,33,37,32,33,43]

theorem envBound49305 : H12AffineFastState.Bounded env49305 := by
  intro p hp
  have h : env49305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49304_49305 : H12AffineEnvironment.transform 8 42 env49304 = env49305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env49304 == env49305) = true)

def leafEnv49305 : List Nat := [2,4,8,16,32,16,8,36,42,53,33,48,40,33,1,35,49,33,52,0,33,33,17,2,20,40,1,17,33,48,49,33,21,33,37,32,5,35,33,43,1,33,0]

def active49305 : List Nat := [0,1,2,3,4]

def tree49305 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49305 : H12WitnessSearch.Good tree49305 := H12GlobalWitnessIndex.good

theorem leafIdentity49305 : H12AffineFastState.composeSystem env49305 rootObs = leafEnv49305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49305 rootObs == leafEnv49305) = true)

theorem terminalChecked49305 : H12PackedTerminal.terminalCheckFast leafEnv49305 active49305 tree49305 = true := by decide +kernel

def env49306 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,40,1045,1,35,1029,2048,1025,0,32,33,17,2,40,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound49306 : H12AffineFastState.Bounded env49306 := by
  intro p hp
  have h : env49306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49300_49306 : H12AffineEnvironment.transform 11 49 env49300 = env49306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env49300 == env49306) = true)

theorem identity49306 : scanCanonicalize (H12AffineFastState.compose env49306 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound49306 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49307 : List Nat := [2,4,8,16,32,16,8,36,512,1024,32,49,40,1045,1,35,1029,32,1025,0,32,33,17,2,40,17,32,1028,48,32,1056,33,37,32,1045,513]

theorem envBound49307 : H12AffineFastState.Bounded env49307 := by
  intro p hp
  have h : env49307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49306_49307 : H12AffineEnvironment.transform 10 32 env49306 = env49307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env49306 == env49307) = true)

def env49308 : List Nat := [2,4,8,16,32,16,8,36,512,52,32,49,40,33,1,35,49,32,53,0,32,33,17,2,40,17,32,48,48,32,20,33,37,32,33,513]

theorem envBound49308 : H12AffineFastState.Bounded env49308 := by
  intro p hp
  have h : env49308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49307_49308 : H12AffineEnvironment.transform 9 52 env49307 = env49308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env49307 == env49308) = true)

def env49309 : List Nat := [2,4,8,16,32,16,8,36,512,53,32,49,40,32,1,35,48,32,52,0,32,33,17,2,40,17,32,49,48,32,21,33,37,32,32,513]

theorem envBound49309 : H12AffineFastState.Bounded env49309 := by
  intro p hp
  have h : env49309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49307_49309 : H12AffineEnvironment.transform 9 53 env49307 = env49309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49307 == env49309) = true)

theorem identity49309 : scanCanonicalize (H12AffineFastState.compose env49309 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound49309 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49310 : List Nat := [2,4,8,16,32,16,8,36,43,53,32,49,40,32,1,35,48,32,52,0,32,33,17,2,40,17,32,49,48,32,21,33,37,32,32,42]

theorem envBound49310 : H12AffineFastState.Bounded env49310 := by
  intro p hp
  have h : env49310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49309_49310 : H12AffineEnvironment.transform 8 43 env49309 = env49310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env49309 == env49310) = true)

def leafEnv49310 : List Nat := [2,4,8,16,32,16,8,36,43,53,32,49,40,32,1,35,48,32,52,0,32,33,17,2,20,40,1,17,32,49,48,32,21,33,37,32,5,35,32,42,1,32,0]

def active49310 : List Nat := [0,1,2,3,4]

def tree49310 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood49310 : H12WitnessSearch.Good tree49310 := H12GlobalWitnessIndex.good

theorem leafIdentity49310 : H12AffineFastState.composeSystem env49310 rootObs = leafEnv49310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env49310 rootObs == leafEnv49310) = true)

theorem terminalChecked49310 : H12PackedTerminal.terminalCheckFast leafEnv49310 active49310 tree49310 = true := by decide +kernel

def env49311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,41310,8193,65,4302890,2172251,2118977,2420,75103,6407191,257,2188651,2196551,512]

theorem envBound49311 : H12AffineFastState.Bounded env49311 := by
  intro p hp
  have h : env49311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49274_49311 : H12AffineEnvironment.transform 6 9 env49274 = env49311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49274 == env49311) = true)

theorem identity49311 : scanCanonicalize (H12AffineFastState.compose env49311 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 17461) := by decide +kernel

theorem selectedBound49311 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49312 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,17461,4194304,16,41310,8193,65,4302890,90478,4468,2420,75103,4292642,257,74078,114802,512]

theorem envBound49312 : H12AffineFastState.Bounded env49312 := by
  intro p hp
  have h : env49312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49311_49312 : H12AffineEnvironment.transform 20 17461 env49311 = env49312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17461 env49311 == env49312) = true)

theorem identity49312 : scanCanonicalize (H12AffineFastState.compose env49312 (packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8573) := by decide +kernel

theorem selectedBound49312 : packedSelected [0,1,3,5,7,8,10,17,19,20] rootPS < 2^1333 := by decide +kernel

def env49313 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8573,65536,16400,10249,1025,8572,17461,4194304,16,35,8193,65,4262231,90478,4468,2420,75103,4268383,257,74078,90383,512]

theorem envBound49313 : H12AffineFastState.Bounded env49313 := by
  intro p hp
  have h : env49313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49312_49313 : H12AffineEnvironment.transform 14 8573 env49312 = env49313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8573 env49312 == env49313) = true)

theorem identity49313 : scanCanonicalize (H12AffineFastState.compose env49313 (packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS)) = affineNative (2^(21+1) ^^^ 0) := by decide +kernel

theorem selectedBound49313 : packedSelected [1,3,5,8,9,10,14,17,19,22] rootPS < 2^1333 := by decide +kernel

def env49314 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8573,65536,16400,10249,1025,8572,17461,0,16,35,8193,65,67927,90478,4468,2420,75103,74079,257,74078,90383,512]

theorem envBound49314 : H12AffineFastState.Bounded env49314 := by
  intro p hp
  have h : env49314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49313_49314 : H12AffineEnvironment.transform 21 0 env49313 = env49314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 0 env49313 == env49314) = true)

theorem identity49314 : scanCanonicalize (H12AffineFastState.compose env49314 (packedSelected [3,5,6,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound49314 : packedSelected [3,5,6,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env49315 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8573,262,16400,10249,1025,8572,17461,0,16,35,8193,65,2129,24680,4468,2420,9305,8281,257,8280,24585,512]

theorem envBound49315 : H12AffineFastState.Bounded env49315 := by
  intro p hp
  have h : env49315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49314_49315 : H12AffineEnvironment.transform 15 262 env49314 = env49315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env49314 == env49315) = true)

theorem identity49315 : scanCanonicalize (H12AffineFastState.compose env49315 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound49315 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env49316 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8573,262,5220,10249,1025,8572,4161,0,16,35,8193,65,2129,13340,4468,2420,9305,8281,257,8280,13437,512]

theorem envBound49316 : H12AffineFastState.Bounded env49316 := by
  intro p hp
  have h : env49316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49315_49316 : H12AffineEnvironment.transform 13 5236 env49315 = env49316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env49315 == env49316) = true)

theorem identity49316 : scanCanonicalize (H12AffineFastState.compose env49316 (packedSelected [1,3,5,6,8,10,14,19] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound49316 : packedSelected [1,3,5,6,8,10,14,19] rootPS < 2^1333 := by decide +kernel

def env49317 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5236,80,262,5220,2340,1025,81,4161,0,16,35,300,65,2129,5425,4468,2420,1396,372,257,373,5456,512]

theorem envBound49317 : H12AffineFastState.Bounded env49317 := by
  intro p hp
  have h : env49317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49316_49317 : H12AffineEnvironment.transform 12 301 env49316 = env49317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env49316 == env49317) = true)

theorem identity49317 : scanCanonicalize (H12AffineFastState.compose env49317 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound49317 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env49318 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,268,5205,80,262,5189,2309,1025,81,4161,0,16,2,269,65,2129,5392,4437,2389,1365,341,257,340,5456,512]

theorem envBound49318 : H12AffineFastState.Bounded env49318 := by
  intro p hp
  have h : env49318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49317_49318 : H12AffineEnvironment.transform 4 1 env49317 = env49318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env49317 == env49318) = true)

theorem identity49318 : scanCanonicalize (H12AffineFastState.compose env49318 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound49318 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49319 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,88,5205,80,82,5189,2129,1025,81,4161,0,16,2,89,65,2129,5188,4097,2049,1025,1,85,0,5124,512]

theorem envBound49319 : H12AffineFastState.Bounded env49319 := by
  intro p hp
  have h : env49319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49318_49319 : H12AffineEnvironment.transform 7 84 env49318 = env49319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env49318 == env49319) = true)

theorem identity49319 : scanCanonicalize (H12AffineFastState.compose env49319 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound49319 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49320 : List Nat := [2,4,8,16,1,64,9,84,512,20,2048,4096,88,4161,80,82,4177,2129,21,81,4161,0,16,2,89,65,2129,4176,4097,2049,21,1,85,0,4112,512]

theorem envBound49320 : H12AffineFastState.Bounded env49320 := by
  intro p hp
  have h : env49320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49319_49320 : H12AffineEnvironment.transform 9 20 env49319 = env49320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env49319 == env49320) = true)

theorem identity49320 : scanCanonicalize (H12AffineFastState.compose env49320 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 65) := by decide +kernel

theorem selectedBound49320 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49321 : List Nat := [2,4,8,16,1,64,9,84,65,20,2048,4096,88,4161,80,82,4177,2129,21,81,4161,0,16,2,89,65,2129,4176,4097,2049,21,1,85,0,4112,65]

theorem envBound49321 : H12AffineFastState.Bounded env49321 := by
  intro p hp
  have h : env49321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49320_49321 : H12AffineEnvironment.transform 8 65 env49320 = env49321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 65 env49320 == env49321) = true)

theorem identity49321 : scanCanonicalize (H12AffineFastState.compose env49321 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound49321 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49322 : List Nat := [2,4,8,16,1,64,9,84,65,20,2048,65,88,0,80,82,16,2129,21,81,0,0,16,2,89,65,2129,17,64,2049,21,1,85,0,81,65]

theorem envBound49322 : H12AffineFastState.Bounded env49322 := by
  intro p hp
  have h : env49322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49321_49322 : H12AffineEnvironment.transform 11 65 env49321 = env49322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env49321 == env49322) = true)

theorem identity49322 : scanCanonicalize (H12AffineFastState.compose env49322 (packedSelected [1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound49322 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env49323 : List Nat := [2,4,8,16,1,64,9,84,65,20,81,65,88,0,80,82,16,0,21,81,0,0,16,2,89,65,0,17,64,80,21,1,85,0,81,65]

theorem envBound49323 : H12AffineFastState.Bounded env49323 := by
  intro p hp
  have h : env49323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49322_49323 : H12AffineEnvironment.transform 10 81 env49322 = env49323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env49322 == env49323) = true)

theorem identity49323 : scanCanonicalize (H12AffineFastState.compose env49323 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49323 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env49324 : List Nat := [2,4,8,16,1,17,9,5,16,20,0,16,9,0,1,3,16,0,21,0,0,0,16,2,8,16,0,17,17,1,21,1,4,0,0,16]

theorem envBound49324 : H12AffineFastState.Bounded env49324 := by
  intro p hp
  have h : env49324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49323_49324 : H12AffineEnvironment.transform 5 17 env49323 = env49324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49323 == env49324) = true)

theorem identity49324 : scanCanonicalize (H12AffineFastState.compose env49324 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound49324 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49325 : List Nat := [2,4,7,16,1,17,6,5,16,20,0,16,6,0,1,3,16,0,21,0,0,0,16,2,7,16,0,17,17,1,21,1,4,0,0,16]

theorem envBound49325 : H12AffineFastState.Bounded env49325 := by
  intro p hp
  have h : env49325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49324_49325 : H12AffineEnvironment.transform 2 7 env49324 = env49325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env49324 == env49325) = true)

def env49326 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,152,272426,8328,65,4303011,2469030,2119113,295049,371875,6639082,257,2485278,2428347,297845]

theorem envBound49326 : H12AffineFastState.Bounded env49326 := by
  intro p hp
  have h : env49326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49272_49326 : H12AffineEnvironment.transform 16 16401 env49272 = env49326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env49272 == env49326) = true)

theorem identity49326 : scanCanonicalize (H12AffineFastState.compose env49326 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound49326 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env49327 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16401,262144,1025,8661,2097152,4194304,152,272426,8328,65,4262263,2428274,2119113,270685,331127,6639082,257,2444746,2428347,273057]

theorem envBound49327 : H12AffineFastState.Bounded env49327 := by
  intro p hp
  have h : env49327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49326_49327 : H12AffineEnvironment.transform 14 8660 env49326 = env49327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env49326 == env49327) = true)

def env49328 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16401,10400,1025,8661,2097152,4194304,152,138,8328,65,4262263,2172370,2119113,2557,75223,6382922,257,2188650,2172187,513]

theorem envBound49328 : H12AffineFastState.Bounded env49328 := by
  intro p hp
  have h : env49328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49327_49328 : H12AffineEnvironment.transform 17 10400 env49327 = env49328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49327 == env49328) = true)

theorem identity49328 : scanCanonicalize (H12AffineFastState.compose env49328 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49328 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env49329 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16401,10400,1025,8661,2097152,4194304,152,138,8328,65,4204925,2098648,2119113,2557,1501,6309184,257,2114912,2098449,513]

theorem envBound49329 : H12AffineFastState.Bounded env49329 := by
  intro p hp
  have h : env49329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49328_49329 : H12AffineEnvironment.transform 15 8202 env49328 = env49329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49328 == env49329) = true)

theorem identity49329 : scanCanonicalize (H12AffineFastState.compose env49329 (packedSelected [0,3,5,10,14,17,27] rootPS)) = affineNative (2^(21+1) ^^^ 2114912) := by decide +kernel

theorem selectedBound49329 : packedSelected [0,3,5,10,14,17,27] rootPS < 2^1333 := by decide +kernel

def env49330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16401,10400,1025,8661,2097152,2114912,152,138,8328,65,2124829,2098648,2119113,2557,1501,32,257,2114912,2098449,513]

theorem envBound49330 : H12AffineFastState.Bounded env49330 := by
  intro p hp
  have h : env49330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49329_49330 : H12AffineEnvironment.transform 21 2114912 env49329 = env49330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env49329 == env49330) = true)

theorem identity49330 : scanCanonicalize (H12AffineFastState.compose env49330 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 17864) := by decide +kernel

theorem selectedBound49330 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,8202,16401,10400,1025,8661,17864,168,152,138,8328,65,10709,16400,4097,2557,1501,32,257,168,16601,513]

theorem envBound49331 : H12AffineFastState.Bounded env49331 := by
  intro p hp
  have h : env49331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49330_49331 : H12AffineEnvironment.transform 20 17864 env49330 = env49331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17864 env49330 == env49331) = true)

theorem identity49331 : scanCanonicalize (H12AffineFastState.compose env49331 (packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound49331 : packedSelected [0,1,2,6,7,8,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env49332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,137,343,16401,2557,1025,136,17864,168,152,138,469,65,2184,16400,4097,2557,1501,32,257,168,16601,513]

theorem envBound49332 : H12AffineFastState.Bounded env49332 := by
  intro p hp
  have h : env49332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49331_49332 : H12AffineEnvironment.transform 12 349 env49331 = env49332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env49331 == env49332) = true)

theorem identity49332 : scanCanonicalize (H12AffineFastState.compose env49332 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49332 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env49333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,0,343,16401,2420,1025,1,17729,33,17,3,348,65,2049,16400,4097,2420,1364,32,257,33,16464,513]

theorem envBound49333 : H12AffineFastState.Bounded env49333 := by
  intro p hp
  have h : env49333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49332_49333 : H12AffineEnvironment.transform 6 9 env49332 = env49333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49332 == env49333) = true)

theorem identity49333 : scanCanonicalize (H12AffineFastState.compose env49333 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound49333 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,821,349,16384,0,343,16401,2420,1025,1,17729,33,17,3,348,65,2049,16400,820,2420,1364,32,257,33,16464,513]

theorem envBound49334 : H12AffineFastState.Bounded env49334 := by
  intro p hp
  have h : env49334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49333_49334 : H12AffineEnvironment.transform 11 821 env49333 = env49334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env49333 == env49334) = true)

theorem identity49334 : scanCanonicalize (H12AffineFastState.compose env49334 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 3328) := by decide +kernel

theorem selectedBound49334 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,821,349,3328,0,343,3345,2420,1025,1,2113,33,17,3,348,65,2049,3344,820,2420,1364,32,257,33,3408,513]

theorem envBound49335 : H12AffineFastState.Bounded env49335 := by
  intro p hp
  have h : env49335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49334_49335 : H12AffineEnvironment.transform 13 3328 env49334 = env49335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3328 env49334 == env49335) = true)

theorem identity49335 : scanCanonicalize (H12AffineFastState.compose env49335 (packedSelected [2,4,9] rootPS)) = affineNative (2^(10+1) ^^^ 609) := by decide +kernel

theorem selectedBound49335 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env49336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,609,821,349,1889,0,343,1904,789,1025,1,544,33,17,3,348,65,608,1905,820,789,1364,32,257,33,1841,513]

theorem envBound49336 : H12AffineFastState.Bounded env49336 := by
  intro p hp
  have h : env49336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49335_49336 : H12AffineEnvironment.transform 10 609 env49335 = env49336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 609 env49335 == env49336) = true)

theorem identity49336 : scanCanonicalize (H12AffineFastState.compose env49336 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound49336 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env49337 : List Nat := [2,4,8,16,32,64,9,256,512,69,609,821,349,804,0,343,821,789,68,1,544,33,17,3,348,65,608,820,820,789,273,32,257,33,884,513]

theorem envBound49337 : H12AffineFastState.Bounded env49337 := by
  intro p hp
  have h : env49337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49336_49337 : H12AffineEnvironment.transform 9 69 env49336 = env49337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env49336 == env49337) = true)

theorem identity49337 : scanCanonicalize (H12AffineFastState.compose env49337 (packedSelected [2,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound49337 : packedSelected [2,4,8] rootPS < 2^1333 := by decide +kernel

def env49338 : List Nat := [2,4,8,0,32,64,9,256,512,69,609,805,333,804,0,327,805,773,68,1,544,33,1,3,332,65,608,804,804,773,257,32,257,33,868,513]

theorem envBound49338 : H12AffineFastState.Bounded env49338 := by
  intro p hp
  have h : env49338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49337_49338 : H12AffineEnvironment.transform 3 0 env49337 = env49338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env49337 == env49338) = true)

theorem identity49338 : scanCanonicalize (H12AffineFastState.compose env49338 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound49338 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env49339 : List Nat := [2,4,8,0,32,64,9,100,512,69,609,577,41,576,0,35,577,609,68,1,544,33,1,3,40,65,608,576,576,609,101,32,101,33,512,513]

theorem envBound49339 : H12AffineFastState.Bounded env49339 := by
  intro p hp
  have h : env49339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49338_49339 : H12AffineEnvironment.transform 7 100 env49338 = env49339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env49338 == env49339) = true)

theorem identity49339 : scanCanonicalize (H12AffineFastState.compose env49339 (packedSelected [0,1,2] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound49339 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env49340 : List Nat := [2,4,8,0,32,0,9,36,512,5,545,513,41,512,0,35,513,545,4,1,544,33,1,3,40,1,544,512,512,545,37,32,37,33,512,513]

theorem envBound49340 : H12AffineFastState.Bounded env49340 := by
  intro p hp
  have h : env49340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49339_49340 : H12AffineEnvironment.transform 5 0 env49339 = env49340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env49339 == env49340) = true)

theorem identity49340 : scanCanonicalize (H12AffineFastState.compose env49340 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound49340 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49341 : List Nat := [2,4,8,0,32,0,9,36,0,5,33,1,41,0,0,35,1,33,4,1,32,33,1,3,40,1,32,0,0,33,37,32,37,33,0,1]

theorem envBound49341 : H12AffineFastState.Bounded env49341 := by
  intro p hp
  have h : env49341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49340_49341 : H12AffineEnvironment.transform 8 0 env49340 = env49341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env49340 == env49341) = true)

theorem identity49341 : scanCanonicalize (H12AffineFastState.compose env49341 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49341 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49342 : List Nat := [2,4,8,0,0,0,9,4,0,5,1,1,9,0,0,3,1,1,4,1,0,1,1,3,8,1,0,0,0,1,5,0,5,1,0,1]

theorem envBound49342 : H12AffineFastState.Bounded env49342 := by
  intro p hp
  have h : env49342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49341_49342 : H12AffineEnvironment.transform 4 0 env49341 = env49342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49341 == env49342) = true)

def env49343 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,16401,10401,1025,8661,2097152,4194304,152,139,8328,65,4262263,2172371,2119113,2556,75222,6382923,257,2188651,2172186,512]

theorem envBound49343 : H12AffineFastState.Bounded env49343 := by
  intro p hp
  have h : env49343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49327_49343 : H12AffineEnvironment.transform 17 10401 env49327 = env49343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env49327 == env49343) = true)

theorem identity49343 : scanCanonicalize (H12AffineFastState.compose env49343 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound49343 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env49344 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,2097152,4194304,17,2,8193,65,4262263,2172250,2118976,2421,75103,6382923,257,2188651,2172186,512]

theorem envBound49344 : H12AffineFastState.Bounded env49344 := by
  intro p hp
  have h : env49344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49343_49344 : H12AffineEnvironment.transform 6 9 env49343 = env49344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49343 == env49344) = true)

theorem identity49344 : scanCanonicalize (H12AffineFastState.compose env49344 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound49344 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49345 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91198,4194304,17,2,8193,65,4262263,16740,78206,2421,75103,4194677,257,341,16676,512]

theorem envBound49345 : H12AffineFastState.Bounded env49345 := by
  intro p hp
  have h : env49345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49344_49345 : H12AffineEnvironment.transform 20 91198 env49344 = env49345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env49344 == env49345) = true)

theorem identity49345 : scanCanonicalize (H12AffineFastState.compose env49345 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound49345 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env49346 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1025,8540,91198,372,17,2,8193,65,67587,16740,78206,2421,75103,1,257,341,16676,512]

theorem envBound49346 : H12AffineFastState.Bounded env49346 := by
  intro p hp
  have h : env49346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49345_49346 : H12AffineEnvironment.transform 21 372 env49345 = env49346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env49345 == env49346) = true)

theorem identity49346 : scanCanonicalize (H12AffineFastState.compose env49346 (packedSelected [0,3,5,6,7,10,11,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound49346 : packedSelected [0,3,5,6,7,10,11,17] rootPS < 2^1333 := by decide +kernel

def env49347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1025,8540,17460,372,17,2,8193,65,10249,16740,4468,2421,1365,1,257,341,16676,512]

theorem envBound49347 : H12AffineFastState.Bounded env49347 := by
  intro p hp
  have h : env49347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49346_49347 : H12AffineEnvironment.transform 15 8202 env49346 = env49347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env49346 == env49347) = true)

theorem identity49347 : scanCanonicalize (H12AffineFastState.compose env49347 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound49347 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env49348 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,8202,16401,10280,1025,8233,17460,1,17,2,8193,65,10249,16401,4097,2048,1056,1,116,32,16465,512]

theorem envBound49348 : H12AffineFastState.Bounded env49348 := by
  intro p hp
  have h : env49348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49347_49348 : H12AffineEnvironment.transform 7 117 env49347 = env49348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env49347 == env49348) = true)

theorem identity49348 : scanCanonicalize (H12AffineFastState.compose env49348 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound49348 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49349 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,1,35,16401,2049,1025,0,17460,1,17,2,40,65,2080,16401,4097,2048,1056,1,116,32,16465,512]

theorem envBound49349 : H12AffineFastState.Bounded env49349 := by
  intro p hp
  have h : env49349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49348_49349 : H12AffineEnvironment.transform 12 41 env49348 = env49349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env49348 == env49349) = true)

theorem identity49349 : scanCanonicalize (H12AffineFastState.compose env49349 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound49349 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env49350 : List Nat := [2,4,8,16,32,64,9,117,42,1024,2048,4096,41,16384,1,35,16401,2049,1025,0,17460,1,17,2,40,65,2080,16401,4097,2048,1056,1,116,32,16465,42]

theorem envBound49350 : H12AffineFastState.Bounded env49350 := by
  intro p hp
  have h : env49350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49349_49350 : H12AffineEnvironment.transform 8 42 env49349 = env49350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env49349 == env49350) = true)

theorem identity49350 : scanCanonicalize (H12AffineFastState.compose env49350 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound49350 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env49351 : List Nat := [2,4,8,16,32,64,9,117,42,1024,2048,4096,41,5236,1,35,5221,2049,1025,0,4160,1,17,2,40,65,2080,5221,4097,2048,1056,1,116,32,5157,42]

theorem envBound49351 : H12AffineFastState.Bounded env49351 := by
  intro p hp
  have h : env49351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49350_49351 : H12AffineEnvironment.transform 13 5236 env49350 = env49351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env49350 == env49351) = true)

def env49352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254785,92374096,145662401,525568,140903596,27337993,25733062]

theorem envBound49352 : H12AffineFastState.Bounded env49352 := by
  intro p hp
  have h : env49352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47755_49352 : H12AffineEnvironment.transform 29 155254785 env47755 = env49352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env47755 == env49352) = true)

def env49353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254785,25265168,145662401,525568,140903596,27337993,25733062]

theorem envBound49353 : H12AffineFastState.Bounded env49353 := by
  intro p hp
  have h : env49353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49352_49353 : H12AffineEnvironment.transform 25 64 env49352 = env49353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env49352 == env49353) = true)

def env49354 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356289,25265168,23160257,525568,27902124,27337993,25733062]

theorem envBound49354 : H12AffineFastState.Bounded env49354 := by
  intro p hp
  have h : env49354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49353_49354 : H12AffineEnvironment.transform 26 30393344 env49353 = env49354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env49353 == env49354) = true)

def env49355 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830977,25265168,23160257,256,27378860,27337993,25207750]

theorem envBound49355 : H12AffineFastState.Bounded env49355 := by
  intro p hp
  have h : env49355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49354_49355 : H12AffineEnvironment.transform 18 1024 env49354 = env49355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env49354 == env49355) = true)

theorem identity49355 : scanCanonicalize (H12AffineFastState.compose env49355 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2188635) := by decide +kernel

theorem selectedBound49355 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env49356 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2188635,16777216,8328,64,23504219,18973837,77835,2598234,18932043,23160257,256,16818679,16793682,18990749]

theorem envBound49356 : H12AffineFastState.Bounded env49356 := by
  intro p hp
  have h : env49356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49355_49356 : H12AffineEnvironment.transform 22 2188635 env49355 = env49356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2188635 env49355 == env49356) = true)

def env49357 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,16777216,8328,64,17227835,18973837,77835,2598234,18932043,16851105,256,16818679,16793682,18990749]

theorem envBound49357 : H12AffineFastState.Bounded env49357 := by
  intro p hp
  have h : env49357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49356_49357 : H12AffineEnvironment.transform 21 2114912 env49356 = env49357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2114912 env49356 == env49357) = true)

def env49358 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,2114912,2188635,2175168,8328,64,2609403,46157,77835,2598234,119179,2101345,256,2199863,2191506,63069]

theorem envBound49358 : H12AffineFastState.Bounded env49358 := by
  intro p hp
  have h : env49358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49357_49358 : H12AffineEnvironment.transform 23 2175168 env49357 = env49358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2175168 env49357 == env49358) = true)

def env49359 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,21792,95515,73856,8328,64,508091,46157,77835,505114,119179,33,256,98679,90322,63069]

theorem envBound49359 : H12AffineFastState.Bounded env49359 := by
  intro p hp
  have h : env49359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49358_49359 : H12AffineEnvironment.transform 20 4160 env49358 = env49359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env49358 == env49359) = true)

theorem identity49359 : scanCanonicalize (H12AffineFastState.compose env49359 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound49359 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49360 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4160,21792,95515,73856,8328,64,472175,16537,77835,475598,75103,33,256,95651,90322,649]

theorem envBound49360 : H12AffineFastState.Bounded env49360 := by
  intro p hp
  have h : env49360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49359_49360 : H12AffineEnvironment.transform 14 29908 env49359 = env49360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env49359 == env49360) = true)

def env49361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1024,29789,4160,21792,95515,73736,8192,64,472175,16401,77835,475462,75103,33,256,95531,90202,513]

theorem envBound49361 : H12AffineFastState.Bounded env49361 := by
  intro p hp
  have h : env49361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49360_49361 : H12AffineEnvironment.transform 6 8 env49360 = env49361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49360 == env49361) = true)

theorem identity49361 : scanCanonicalize (H12AffineFastState.compose env49361 (packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound49361 : packedSelected [0,2,3,4,6,7,9,10,11,14,15,16,18,20,21,23,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env49362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,2340,1024,29789,4160,21792,95515,73736,8192,64,212299,16401,77835,215138,75103,33,256,95531,90202,513]

theorem envBound49362 : H12AffineFastState.Bounded env49362 := by
  intro p hp
  have h : env49362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49361_49362 : H12AffineEnvironment.transform 17 2340 env49361 = env49362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env49361 == env49362) = true)

theorem identity49362 : scanCanonicalize (H12AffineFastState.compose env49362 (packedSelected [0,2,6,7,18,20,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound49362 : packedSelected [0,2,6,7,18,20,21,23] rootPS < 2^1333 := by decide +kernel

def env49363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,13340,2340,1024,29789,4160,21792,95515,73736,8192,64,67927,16401,77835,97406,75103,33,256,95531,90202,513]

theorem envBound49363 : H12AffineFastState.Bounded env49363 := by
  intro p hp
  have h : env49363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49362_49363 : H12AffineEnvironment.transform 16 13340 env49362 = env49363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env49362 == env49363) = true)

theorem identity49363 : scanCanonicalize (H12AffineFastState.compose env49363 (packedSelected [0,1,7,8,12,15,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound49363 : packedSelected [0,1,7,8,12,15,16,19] rootPS < 2^1333 := by decide +kernel

def env49364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,65536,5440,2340,1024,21761,4160,21792,87111,65876,348,64,67927,16401,69975,89378,66563,33,256,87159,82182,513]

theorem envBound49364 : H12AffineFastState.Bounded env49364 := by
  intro p hp
  have h : env49364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49363_49364 : H12AffineEnvironment.transform 12 348 env49363 = env49364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env49363 == env49364) = true)

theorem identity49364 : scanCanonicalize (H12AffineFastState.compose env49364 (packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound49364 : packedSelected [0,2,3,4,5,6,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env49365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,342,5440,2340,1024,21761,4160,21792,21777,2,348,64,2049,16401,4097,23668,1365,33,256,21793,16464,513]

theorem envBound49365 : H12AffineFastState.Bounded env49365 := by
  intro p hp
  have h : env49365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49364_49365 : H12AffineEnvironment.transform 15 342 env49364 = env49365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env49364 == env49365) = true)

theorem identity49365 : scanCanonicalize (H12AffineFastState.compose env49365 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound49365 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env49366 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,21760,262,5392,2340,1024,21761,4112,21792,21777,2,268,16,2049,16401,4097,23588,1285,33,256,21793,16384,513]

theorem envBound49366 : H12AffineFastState.Bounded env49366 := by
  intro p hp
  have h : env49366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49365_49366 : H12AffineEnvironment.transform 5 16 env49365 = env49366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env49365 == env49366) = true)

theorem identity49366 : scanCanonicalize (H12AffineFastState.compose env49366 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound49366 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49367 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,0,262,5392,2340,1024,1,4112,32,17,2,268,16,2049,5393,4097,2340,1285,33,256,33,5376,513]

theorem envBound49367 : H12AffineFastState.Bounded env49367 := by
  intro p hp
  have h : env49367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49366_49367 : H12AffineEnvironment.transform 13 5376 env49366 = env49367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env49366 == env49367) = true)

theorem identity49367 : scanCanonicalize (H12AffineFastState.compose env49367 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound49367 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49368 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,277,268,1045,0,262,1029,2340,1024,1,261,32,17,2,268,16,2049,1028,276,2340,1285,33,256,33,1045,513]

theorem envBound49368 : H12AffineFastState.Bounded env49368 := by
  intro p hp
  have h : env49368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49367_49368 : H12AffineEnvironment.transform 11 277 env49367 = env49368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env49367 == env49368) = true)

theorem identity49368 : scanCanonicalize (H12AffineFastState.compose env49368 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound49368 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env49369 : List Nat := [2,4,8,16,32,16,8,256,512,21,2048,277,268,0,0,262,16,2340,21,1,261,32,17,2,268,16,2049,17,276,2340,272,33,256,33,0,513]

theorem envBound49369 : H12AffineFastState.Bounded env49369 := by
  intro p hp
  have h : env49369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49368_49369 : H12AffineEnvironment.transform 9 21 env49368 = env49369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env49368 == env49369) = true)

theorem identity49369 : scanCanonicalize (H12AffineFastState.compose env49369 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound49369 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env49370 : List Nat := [2,4,8,16,32,16,8,256,32,21,2048,277,268,0,0,262,16,2340,21,1,261,32,17,2,268,16,2049,17,276,2340,272,33,256,33,0,33]

theorem envBound49370 : H12AffineFastState.Bounded env49370 := by
  intro p hp
  have h : env49370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49369_49370 : H12AffineEnvironment.transform 8 32 env49369 = env49370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env49369 == env49370) = true)

theorem identity49370 : scanCanonicalize (H12AffineFastState.compose env49370 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 309) := by decide +kernel

theorem selectedBound49370 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env49371 : List Nat := [2,4,8,16,32,16,8,256,32,21,309,277,268,0,0,262,16,17,21,1,261,32,17,2,268,16,308,17,276,17,272,33,256,33,0,33]

theorem envBound49371 : H12AffineFastState.Bounded env49371 := by
  intro p hp
  have h : env49371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49370_49371 : H12AffineEnvironment.transform 10 309 env49370 = env49371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 309 env49370 == env49371) = true)

theorem identity49371 : scanCanonicalize (H12AffineFastState.compose env49371 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound49371 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49372 : List Nat := [2,4,8,16,32,16,8,53,32,21,0,32,57,0,0,51,16,17,21,1,48,32,17,2,57,16,1,17,33,17,37,33,53,33,0,33]

theorem envBound49372 : H12AffineFastState.Bounded env49372 := by
  intro p hp
  have h : env49372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49371_49372 : H12AffineEnvironment.transform 7 53 env49371 = env49372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env49371 == env49372) = true)

theorem identity49372 : scanCanonicalize (H12AffineFastState.compose env49372 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound49372 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env49373 : List Nat := [2,4,8,16,17,16,8,4,17,21,0,17,8,0,0,2,16,17,21,1,1,17,17,2,8,16,1,17,16,17,20,16,4,16,0,16]

theorem envBound49373 : H12AffineFastState.Bounded env49373 := by
  intro p hp
  have h : env49373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49372_49373 : H12AffineEnvironment.transform 4 17 env49372 = env49373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env49372 == env49373) = true)

theorem identity49373 : scanCanonicalize (H12AffineFastState.compose env49373 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound49373 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49374 : List Nat := [2,4,8,1,0,1,8,4,0,4,0,0,8,0,0,2,1,0,4,1,1,0,0,2,8,1,1,0,1,0,5,1,4,1,0,1]

theorem envBound49374 : H12AffineFastState.Bounded env49374 := by
  intro p hp
  have h : env49374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49373_49374 : H12AffineEnvironment.transform 3 1 env49373 = env49374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env49373 == env49374) = true)

def env49375 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,4160,21792,95515,73737,8193,64,472175,16400,77835,475463,75103,33,256,95530,90203,512]

theorem envBound49375 : H12AffineFastState.Bounded env49375 := by
  intro p hp
  have h : env49375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49360_49375 : H12AffineEnvironment.transform 6 9 env49360 = env49375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env49360 == env49375) = true)

theorem identity49375 : scanCanonicalize (H12AffineFastState.compose env49375 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound49375 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env49376 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,131072,262144,1024,29788,4160,21792,17,21763,8193,64,409957,16400,17665,406605,20565,33,256,32,5457,512]

theorem envBound49376 : H12AffineFastState.Bounded env49376 := by
  intro p hp
  have h : env49376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49375_49376 : H12AffineEnvironment.transform 15 29962 env49375 = env49376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env49375 == env49376) = true)

theorem identity49376 : scanCanonicalize (H12AffineFastState.compose env49376 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(17+1) ^^^ 10588) := by decide +kernel

theorem selectedBound49376 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49377 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,131072,10588,1024,29788,4160,21792,17,21763,8193,64,157753,16400,17665,138513,20565,33,256,32,5457,512]

theorem envBound49377 : H12AffineFastState.Bounded env49377 := by
  intro p hp
  have h : env49377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49376_49377 : H12AffineEnvironment.transform 17 10588 env49376 = env49377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10588 env49376 == env49377) = true)

theorem identity49377 : scanCanonicalize (H12AffineFastState.compose env49377 (packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 13640) := by decide +kernel

theorem selectedBound49377 : packedSelected [0,1,3,4,5,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env49378 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,29962,13640,10588,1024,29788,4160,21792,17,21763,8193,64,23921,16400,17665,10329,20565,33,256,32,5457,512]

theorem envBound49378 : H12AffineFastState.Bounded env49378 := by
  intro p hp
  have h : env49378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49377_49378 : H12AffineEnvironment.transform 16 13640 env49377 = env49378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13640 env49377 == env49378) = true)

theorem identity49378 : scanCanonicalize (H12AffineFastState.compose env49378 (packedSelected [21] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound49378 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49379 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5236,8233,8574,13640,10588,1024,8232,4160,340,17,375,8193,64,2309,5220,4469,10329,1057,33,256,32,5457,512]

theorem envBound49379 : H12AffineFastState.Bounded env49379 := by
  intro p hp
  have h : env49379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49378_49379 : H12AffineEnvironment.transform 13 5236 env49378 = env49379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env49378 == env49379) = true)

theorem identity49379 : scanCanonicalize (H12AffineFastState.compose env49379 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound49379 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env49380 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5236,81,262,5424,2340,1024,80,4160,340,17,375,121,64,2309,5220,4469,2081,1057,33,256,32,5457,512]

theorem envBound49380 : H12AffineFastState.Bounded env49380 := by
  intro p hp
  have h : env49380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49379_49380 : H12AffineEnvironment.transform 12 120 env49379 = env49380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env49379 == env49380) = true)

theorem identity49380 : scanCanonicalize (H12AffineFastState.compose env49380 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound49380 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49381 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,120,5236,81,35,5141,2049,1024,80,4160,113,17,82,121,64,2080,5220,4176,2081,1057,33,37,32,5236,512]

theorem envBound49381 : H12AffineFastState.Bounded env49381 := by
  intro p hp
  have h : env49381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49380_49381 : H12AffineEnvironment.transform 7 37 env49380 = env49381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env49380 == env49381) = true)

theorem identity49381 : scanCanonicalize (H12AffineFastState.compose env49381 (packedSelected [0,1,2,7,8,10,12] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound49381 : packedSelected [0,1,2,7,8,10,12] rootPS < 2^1333 := by decide +kernel

def env49382 : List Nat := [2,4,8,16,32,64,9,37,512,68,2048,4096,120,4144,81,35,4177,2049,68,80,4160,113,17,82,121,64,2080,4128,4176,2081,101,33,37,32,4144,512]

theorem envBound49382 : H12AffineFastState.Bounded env49382 := by
  intro p hp
  have h : env49382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49381_49382 : H12AffineEnvironment.transform 9 68 env49381 = env49382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env49381 == env49382) = true)

theorem identity49382 : scanCanonicalize (H12AffineFastState.compose env49382 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound49382 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env49383 : List Nat := [2,4,8,16,32,48,9,37,512,52,2048,4096,8,4144,33,35,4129,2049,52,32,4144,1,17,34,9,48,2080,4128,4128,2081,21,33,37,32,4144,512]

theorem envBound49383 : H12AffineFastState.Bounded env49383 := by
  intro p hp
  have h : env49383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49382_49383 : H12AffineEnvironment.transform 5 48 env49382 = env49383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env49382 == env49383) = true)

theorem identity49383 : scanCanonicalize (H12AffineFastState.compose env49383 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound49383 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49384 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8,4112,1,3,4097,2049,20,0,4112,1,17,2,9,16,2048,4096,4096,2049,21,1,5,0,4112,512]

theorem envBound49384 : H12AffineFastState.Bounded env49384 := by
  intro p hp
  have h : env49384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49383_49384 : H12AffineEnvironment.transform 4 0 env49383 = env49384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env49383 == env49384) = true)

theorem identity49384 : scanCanonicalize (H12AffineFastState.compose env49384 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound49384 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49385 : List Nat := [2,1,8,16,0,16,9,0,512,17,2048,4096,8,4112,1,3,4097,2049,17,0,4112,1,17,2,9,16,2048,4096,4096,2049,16,1,0,0,4112,512]

theorem envBound49385 : H12AffineFastState.Bounded env49385 := by
  intro p hp
  have h : env49385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49384_49385 : H12AffineEnvironment.transform 1 1 env49384 = env49385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env49384 == env49385) = true)

theorem identity49385 : scanCanonicalize (H12AffineFastState.compose env49385 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 25) := by decide +kernel

theorem selectedBound49385 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env49386 : List Nat := [2,1,8,16,0,16,9,0,512,17,25,4096,8,4112,1,3,4097,24,17,0,4112,1,17,2,9,16,25,4096,4096,24,16,1,0,0,4112,512]

theorem envBound49386 : H12AffineFastState.Bounded env49386 := by
  intro p hp
  have h : env49386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49385_49386 : H12AffineEnvironment.transform 10 25 env49385 = env49386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 25 env49385 == env49386) = true)

def env49387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,21793,95514,73857,8328,64,508090,46157,77835,505115,119179,32,256,98678,90323,63069]

theorem envBound49387 : H12AffineFastState.Bounded env49387 := by
  intro p hp
  have h : env49387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49358_49387 : H12AffineEnvironment.transform 20 4161 env49358 = env49387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env49358 == env49387) = true)

theorem identity49387 : scanCanonicalize (H12AffineFastState.compose env49387 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound49387 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env49388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,4161,21793,95514,73857,8328,64,483815,5392,77835,463942,94422,32,256,73771,90323,22272]

theorem envBound49388 : H12AffineFastState.Bounded env49388 := by
  intro p hp
  have h : env49388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49387_49388 : H12AffineEnvironment.transform 14 8541 env49387 = env49388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env49387 == env49388) = true)

def env49389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,4161,21793,95514,73857,8328,64,215367,5392,77835,212198,94422,32,256,73771,90323,22272]

theorem envBound49389 : H12AffineFastState.Bounded env49389 := by
  intro p hp
  have h : env49389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49388_49389 : H12AffineEnvironment.transform 17 10400 env49388 = env49389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env49388 == env49389) = true)

theorem identity49389 : scanCanonicalize (H12AffineFastState.compose env49389 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound49389 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env49390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,131072,10400,1024,8540,4161,21793,16,21899,8328,64,146509,5392,17665,149996,1500,32,256,21793,5593,22272]

theorem envBound49390 : H12AffineFastState.Bounded env49390 := by
  intro p hp
  have h : env49390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49389_49390 : H12AffineEnvironment.transform 15 29962 env49389 = env49390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env49389 == env49390) = true)

theorem identity49390 : scanCanonicalize (H12AffineFastState.compose env49390 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound49390 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env49391 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,29962,5392,10400,1024,8540,4161,21793,16,21899,8328,64,10589,5392,17665,23804,1500,32,256,21793,5593,22272]

theorem envBound49391 : H12AffineFastState.Bounded env49391 := by
  intro p hp
  have h : env49391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49390_49391 : H12AffineEnvironment.transform 16 5392 env49390 = env49391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env49390 == env49391) = true)

theorem identity49391 : scanCanonicalize (H12AffineFastState.compose env49391 (packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound49391 : packedSelected [0,2,4,7,11,14,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env49392 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,8541,8694,5392,10400,1024,8540,4161,477,16,375,8328,64,10589,5392,4605,2048,1500,32,256,477,5593,1020]

theorem envBound49392 : H12AffineFastState.Bounded env49392 := by
  intro p hp
  have h : env49392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49391_49392 : H12AffineEnvironment.transform 13 5372 env49391 = env49392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env49391 == env49392) = true)

theorem identity49392 : scanCanonicalize (H12AffineFastState.compose env49392 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound49392 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env49393 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,5372,8352,8203,5357,10400,1024,8353,4161,32,16,138,8328,64,10400,5357,4096,2048,1057,32,253,32,5156,513]

theorem envBound49393 : H12AffineFastState.Bounded env49393 := by
  intro p hp
  have h : env49393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49392_49393 : H12AffineEnvironment.transform 7 253 env49392 = env49393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env49392 == env49393) = true)

theorem identity49393 : scanCanonicalize (H12AffineFastState.compose env49393 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound49393 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env49394 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,8192,5293,8352,8203,5308,10400,1024,8353,4112,32,16,138,8328,17,10400,5308,4096,2048,1057,32,172,32,5156,513]

theorem envBound49394 : H12AffineFastState.Bounded env49394 := by
  intro p hp
  have h : env49394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49393_49394 : H12AffineEnvironment.transform 5 17 env49393 = env49394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env49393 == env49394) = true)

theorem identity49394 : scanCanonicalize (H12AffineFastState.compose env49394 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound49394 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env49395 : List Nat := [2,4,8,16,32,17,128,172,512,1024,2048,4096,161,5293,1,170,5308,2049,1024,0,4112,32,16,138,41,17,2049,5308,4096,2048,1057,32,172,32,5156,513]

theorem envBound49395 : H12AffineFastState.Bounded env49395 := by
  intro p hp
  have h : env49395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49394_49395 : H12AffineEnvironment.transform 12 161 env49394 = env49395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env49394 == env49395) = true)

theorem identity49395 : scanCanonicalize (H12AffineFastState.compose env49395 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound49395 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env49396 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5157,1,34,5172,2049,1024,0,4112,32,16,2,41,17,2049,5172,4096,2048,1057,32,36,32,5156,513]

theorem envBound49396 : H12AffineFastState.Bounded env49396 := by
  intro p hp
  have h : env49396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49395_49396 : H12AffineEnvironment.transform 6 8 env49395 = env49396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env49395 == env49396) = true)

theorem identity49396 : scanCanonicalize (H12AffineFastState.compose env49396 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound49396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env49397 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,4096,41,4112,1,34,4097,2049,53,0,4112,32,16,2,41,17,2049,4097,4096,2048,20,32,36,32,4113,513]

theorem envBound49397 : H12AffineFastState.Bounded env49397 := by
  intro p hp
  have h : env49397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans49396_49397 : H12AffineEnvironment.transform 9 53 env49396 = env49397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env49396 == env49397) = true)

theorem identity49397 : scanCanonicalize (H12AffineFastState.compose env49397 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound49397 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env49398 : List Nat := [2,4,8,16,32,17,8,36,512,53,2048,2065,41,2049,1,34,2064,2049,53,0,2049,32,16,2,41,17,2049,2064,2065,2048,20,32,36,32,2048,513]

theorem envBound49398 : H12AffineFastState.Bounded env49398 := by
  intro p hp
  have h : env49398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1