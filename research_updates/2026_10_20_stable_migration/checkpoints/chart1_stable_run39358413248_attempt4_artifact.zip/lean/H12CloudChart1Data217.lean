import H12CloudChart1Data216

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env54946 : List Nat := [2,4,8,16,32,64,89,256,74,298,64,32,349,90,1,262,75,309,298,0,96,33,65,82,268,65,16,75,33,357,47,33,256,112,10,26]

theorem envBound54946 : H12AffineFastState.Bounded env54946 := by
  intro p hp
  have h : env54946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54945_54946 : H12AffineEnvironment.transform 10 64 env54945 = env54946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 64 env54945 == env54946) = true)

theorem identity54946 : scanCanonicalize (H12AffineFastState.compose env54946 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound54946 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env54947 : List Nat := [2,4,8,16,32,64,89,85,74,127,64,32,8,90,1,83,75,96,127,0,96,33,65,82,89,65,16,75,33,48,47,33,85,112,10,26]

theorem envBound54947 : H12AffineFastState.Bounded env54947 := by
  intro p hp
  have h : env54947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54946_54947 : H12AffineEnvironment.transform 7 85 env54946 = env54947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env54946 == env54947) = true)

def env54948 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4160,4194304,4363553,21762,8328,65,215366,115151,4378673,4332612,4408370,4268162,256,4396238,4453739,4350949]

theorem envBound54948 : H12AffineFastState.Bounded env54948 := by
  intro p hp
  have h : env54948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54912_54948 : H12AffineEnvironment.transform 22 4363553 env54912 = env54948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env54912 == env54948) = true)

theorem identity54948 : scanCanonicalize (H12AffineFastState.compose env54948 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound54948 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54949 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4160,4194304,4363553,21762,8328,65,158028,57797,4378673,4332612,4351032,4194440,256,4338884,4380001,4350949]

theorem envBound54949 : H12AffineFastState.Bounded env54949 := by
  intro p hp
  have h : env54949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54948_54949 : H12AffineEnvironment.transform 15 8202 env54948 = env54949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env54948 == env54949) = true)

theorem identity54949 : scanCanonicalize (H12AffineFastState.compose env54949 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound54949 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env54950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,149860,1024,32769,4160,156132,62661,21762,8328,65,158028,57797,45525,32160,1500,156012,256,21792,46213,513]

theorem envBound54950 : H12AffineFastState.Bounded env54950 := by
  intro p hp
  have h : env54950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54949_54950 : H12AffineEnvironment.transform 21 156132 env54949 = env54950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env54949 == env54950) = true)

theorem identity54950 : scanCanonicalize (H12AffineFastState.compose env54950 (packedSelected [7,11,14,16,18,23,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound54950 : packedSelected [7,11,14,16,18,23,27,32] rootPS < 2^1333 := by decide +kernel

def env54951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,5529,23805,1024,32769,4160,29821,62661,21762,8328,65,31957,57797,45525,32160,1500,29941,256,21792,46213,513]

theorem envBound54951 : H12AffineFastState.Bounded env54951 := by
  intro p hp
  have h : env54951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54950_54951 : H12AffineEnvironment.transform 16 5529 env54950 = env54951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env54950 == env54951) = true)

theorem identity54951 : scanCanonicalize (H12AffineFastState.compose env54951 (packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound54951 : packedSelected [1,3,4,5,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env54952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13404,32768,8202,5529,10401,1024,32769,4160,33,32921,8542,8328,65,2185,38297,45525,2556,1500,169,256,8572,46213,513]

theorem envBound54952 : H12AffineFastState.Bounded env54952 := by
  intro p hp
  have h : env54952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54951_54952 : H12AffineEnvironment.transform 13 13404 env54951 = env54952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env54951 == env54952) = true)

theorem identity54952 : scanCanonicalize (H12AffineFastState.compose env54952 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(12+1) ^^^ 7301) := by decide +kernel

theorem selectedBound54952 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env54953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,7301,2265,32768,7311,5529,5156,1024,32769,4160,33,32921,7643,7181,65,2185,38297,36176,2556,1500,169,256,7673,34816,513]

theorem envBound54953 : H12AffineFastState.Bounded env54953 := by
  intro p hp
  have h : env54953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54952_54953 : H12AffineEnvironment.transform 12 7301 env54952 = env54953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7301 env54952 == env54953) = true)

theorem identity54953 : scanCanonicalize (H12AffineFastState.compose env54953 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound54953 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env54954 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,6428,2265,32768,6422,4096,4541,409,32769,4160,33,32921,6210,6548,65,2185,36864,35017,2556,69,169,256,6240,34816,513]

theorem envBound54954 : H12AffineFastState.Bounded env54954 := by
  intro p hp
  have h : env54954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54953_54954 : H12AffineEnvironment.transform 9 409 env54953 = env54954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env54953 == env54954) = true)

theorem identity54954 : scanCanonicalize (H12AffineFastState.compose env54954 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound54954 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env54955 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,4096,6428,2265,136,6422,4096,4541,409,137,4160,33,17,6210,6548,65,2185,4232,2113,2556,69,169,256,6240,2184,513]

theorem envBound54955 : H12AffineFastState.Bounded env54955 := by
  intro p hp
  have h : env54955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54954_54955 : H12AffineEnvironment.transform 14 136 env54954 = env54955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env54954 == env54955) = true)

theorem identity54955 : scanCanonicalize (H12AffineFastState.compose env54955 (packedSelected [0,2,3,5,6,9] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound54955 : packedSelected [0,2,3,5,6,9] rootPS < 2^1333 := by decide +kernel

def env54956 : List Nat := [2,4,8,16,32,64,128,256,512,409,2048,2493,161,2265,136,171,2493,2048,409,137,2557,33,17,511,41,65,2185,2357,2113,2556,69,169,256,477,2184,513]

theorem envBound54956 : H12AffineFastState.Bounded env54956 := by
  intro p hp
  have h : env54956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54955_54956 : H12AffineEnvironment.transform 11 2493 env54955 = env54956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env54955 == env54956) = true)

theorem identity54956 : scanCanonicalize (H12AffineFastState.compose env54956 (packedSelected [3,4,5,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound54956 : packedSelected [3,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env54957 : List Nat := [2,4,8,16,32,64,128,172,512,53,2048,2065,161,2265,136,171,2065,2048,53,137,2129,33,17,83,41,65,2185,2201,2113,2128,69,169,172,113,2184,513]

theorem envBound54957 : H12AffineFastState.Bounded env54957 := by
  intro p hp
  have h : env54957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54956_54957 : H12AffineEnvironment.transform 7 172 env54956 = env54957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env54956 == env54957) = true)

theorem identity54957 : scanCanonicalize (H12AffineFastState.compose env54957 (packedSelected [0,1,2,4,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54957 : packedSelected [0,1,2,4,6,8] rootPS < 2^1333 := by decide +kernel

def env54958 : List Nat := [2,4,8,16,32,17,128,172,512,53,2048,2065,161,2184,136,171,2065,2048,53,137,2048,33,17,2,41,16,2185,2201,2064,2049,20,169,172,32,2184,513]

theorem envBound54958 : H12AffineFastState.Bounded env54958 := by
  intro p hp
  have h : env54958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54957_54958 : H12AffineEnvironment.transform 5 17 env54957 = env54958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54957 == env54958) = true)

def env54959 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,8388608,21763,8328,65,12704870,115151,8406289,8423781,8507666,4268162,256,8487407,8478794,8451781]

theorem envBound54959 : H12AffineFastState.Bounded env54959 := by
  intro p hp
  have h : env54959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54911_54959 : H12AffineEnvironment.transform 20 4161 env54911 = env54959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env54911 == env54959) = true)

def env54960 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363552,21763,8328,65,215366,115151,4378673,4332613,4408370,4268162,256,4396239,4453738,4350949]

theorem envBound54960 : H12AffineFastState.Bounded env54960 := by
  intro p hp
  have h : env54960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54959_54960 : H12AffineEnvironment.transform 22 4363552 env54959 = env54960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env54959 == env54960) = true)

theorem identity54960 : scanCanonicalize (H12AffineFastState.compose env54960 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213486) := by decide +kernel

theorem selectedBound54960 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54961 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,213486,120014,21763,8328,65,215366,115151,102879,89515,1500,156012,256,21793,46212,74251]

theorem envBound54961 : H12AffineFastState.Bounded env54961 := by
  intro p hp
  have h : env54961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54960_54961 : H12AffineEnvironment.transform 21 213486 env54960 = env54961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213486 env54960 == env54961) = true)

def env54962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,10400,1024,32769,4161,73770,120014,21763,8328,65,75906,115151,102879,89515,1500,168,256,21793,46212,74251]

theorem envBound54962 : H12AffineFastState.Bounded env54962 := by
  intro p hp
  have h : env54962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54961_54962 : H12AffineEnvironment.transform 16 25028 env54961 = env54962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env54961 == env54962) = true)

theorem identity54962 : scanCanonicalize (H12AffineFastState.compose env54962 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound54962 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env54963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,25028,10400,1024,32769,4161,54561,8645,21763,8328,65,56713,13508,25812,43168,1500,168,256,21793,46212,55040]

theorem envBound54963 : H12AffineFastState.Bounded env54963 := by
  intro p hp
  have h : env54963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54962_54963 : H12AffineEnvironment.transform 15 62731 env54962 = env54963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env54962 == env54963) = true)

theorem identity54963 : scanCanonicalize (H12AffineFastState.compose env54963 (packedSelected [0,2,3,6,8,12,14,15,18,19,24,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13524) := by decide +kernel

theorem selectedBound54963 : packedSelected [0,2,3,6,8,12,14,15,18,19,24,27,28,32] rootPS < 2^1333 := by decide +kernel

def env54964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,32768,33247,5392,10400,1024,32769,4161,41461,8645,8663,8328,65,43357,13508,4096,43168,1500,168,256,8693,46212,41940]

theorem envBound54964 : H12AffineFastState.Bounded env54964 := by
  intro p hp
  have h : env54964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54963_54964 : H12AffineEnvironment.transform 13 13524 env54963 = env54964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13524 env54963 == env54964) = true)

theorem identity54964 : scanCanonicalize (H12AffineFastState.compose env54964 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54964 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env54965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13524,8540,8323,5392,10400,1024,8541,4161,169,8645,8663,8328,65,2049,13508,4096,2556,1500,168,256,8693,5592,648]

theorem envBound54965 : H12AffineFastState.Bounded env54965 := by
  intro p hp
  have h : env54965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54964_54965 : H12AffineEnvironment.transform 14 8540 env54964 = env54965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54964 == env54965) = true)

theorem identity54965 : scanCanonicalize (H12AffineFastState.compose env54965 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound54965 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env54966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5513,1,478,5392,2557,1024,0,4161,169,152,138,469,65,2049,5529,4096,2556,1500,168,256,168,5592,648]

theorem envBound54966 : H12AffineFastState.Bounded env54966 := by
  intro p hp
  have h : env54966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54965_54966 : H12AffineEnvironment.transform 12 349 env54965 = env54966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env54965 == env54966) = true)

theorem identity54966 : scanCanonicalize (H12AffineFastState.compose env54966 (packedSelected [2,3,5,10,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound54966 : packedSelected [2,3,5,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env54967 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,349,4589,1,478,4468,2557,100,0,4161,169,152,138,469,65,2049,4605,4096,2556,440,168,256,168,4540,648]

theorem envBound54967 : H12AffineFastState.Bounded env54967 := by
  intro p hp
  have h : env54967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54966_54967 : H12AffineEnvironment.transform 9 100 env54966 = env54967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env54966 == env54967) = true)

theorem identity54967 : scanCanonicalize (H12AffineFastState.compose env54967 (packedSelected [2,6,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 2493) := by decide +kernel

theorem selectedBound54967 : packedSelected [2,6,11,12] rootPS < 2^1333 := by decide +kernel

def env54968 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,2493,349,2128,1,478,2249,2557,100,0,2556,169,152,138,469,65,2049,2112,2493,2556,440,168,256,168,2049,648]

theorem envBound54968 : H12AffineFastState.Bounded env54968 := by
  intro p hp
  have h : env54968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54967_54968 : H12AffineEnvironment.transform 11 2493 env54967 = env54968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2493 env54967 == env54968) = true)

theorem identity54968 : scanCanonicalize (H12AffineFastState.compose env54968 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound54968 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env54969 : List Nat := [2,4,8,16,32,64,128,252,512,100,2048,2113,161,2128,1,34,2249,2049,100,0,2048,169,152,138,41,65,2049,2112,2113,2048,68,168,252,168,2049,648]

theorem envBound54969 : H12AffineFastState.Bounded env54969 := by
  intro p hp
  have h : env54969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54968_54969 : H12AffineEnvironment.transform 7 252 env54968 = env54969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env54968 == env54969) = true)

theorem identity54969 : scanCanonicalize (H12AffineFastState.compose env54969 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54969 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54970 : List Nat := [2,4,8,16,32,16,128,172,512,52,2048,2065,161,2048,1,34,2201,2049,52,0,2048,169,152,138,41,17,2049,2064,2065,2048,20,168,172,168,2049,648]

theorem envBound54970 : H12AffineFastState.Bounded env54970 := by
  intro p hp
  have h : env54970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54969_54970 : H12AffineEnvironment.transform 5 16 env54969 = env54970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54969 == env54970) = true)

theorem identity54970 : scanCanonicalize (H12AffineFastState.compose env54970 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound54970 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env54971 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,2065,41,2048,1,34,2065,2049,52,0,2048,33,16,2,41,17,2049,2064,2065,2048,20,32,36,32,2049,512]

theorem envBound54971 : H12AffineFastState.Bounded env54971 := by
  intro p hp
  have h : env54971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54970_54971 : H12AffineEnvironment.transform 6 8 env54970 = env54971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env54970 == env54971) = true)

theorem identity54971 : scanCanonicalize (H12AffineFastState.compose env54971 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 20) := by decide +kernel

theorem selectedBound54971 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54972 : List Nat := [2,4,8,16,20,16,8,16,512,0,2048,2065,29,2048,1,22,2065,2049,0,0,2048,21,16,2,29,17,2049,2064,2065,2048,20,20,16,20,2049,512]

theorem envBound54972 : H12AffineFastState.Bounded env54972 := by
  intro p hp
  have h : env54972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54971_54972 : H12AffineEnvironment.transform 4 20 env54971 = env54972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 20 env54971 == env54972) = true)

theorem identity54972 : scanCanonicalize (H12AffineFastState.compose env54972 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 525) := by decide +kernel

theorem selectedBound54972 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54973 : List Nat := [2,4,8,16,20,16,8,16,512,0,525,540,29,525,1,22,540,524,0,0,525,21,16,2,29,17,524,541,540,525,20,20,16,20,524,512]

theorem envBound54973 : H12AffineFastState.Bounded env54973 := by
  intro p hp
  have h : env54973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54972_54973 : H12AffineEnvironment.transform 10 525 env54972 = env54973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 525 env54972 == env54973) = true)

theorem identity54973 : scanCanonicalize (H12AffineFastState.compose env54973 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound54973 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54974 : List Nat := [2,4,8,5,1,5,8,5,512,0,525,521,8,525,1,3,521,524,0,0,525,0,5,2,8,4,524,520,521,525,1,1,5,1,524,512]

theorem envBound54974 : H12AffineFastState.Bounded env54974 := by
  intro p hp
  have h : env54974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54973_54974 : H12AffineEnvironment.transform 3 5 env54973 = env54974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env54973 == env54974) = true)

theorem identity54974 : scanCanonicalize (H12AffineFastState.compose env54974 (packedSelected [3] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound54974 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env54975 : List Nat := [2,3,8,2,1,2,8,2,512,0,522,521,8,522,1,3,521,523,0,0,522,0,2,2,8,3,523,520,521,522,1,1,2,1,523,512]

theorem envBound54975 : H12AffineFastState.Bounded env54975 := by
  intro p hp
  have h : env54975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54974_54975 : H12AffineEnvironment.transform 1 3 env54974 = env54975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env54974 == env54975) = true)

def env54976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10401,1024,32769,4161,73771,120014,21763,8328,65,75907,115151,102879,89515,1500,169,256,21793,46212,74251]

theorem envBound54976 : H12AffineFastState.Bounded env54976 := by
  intro p hp
  have h : env54976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54961_54976 : H12AffineEnvironment.transform 16 25029 env54961 = env54976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env54961 == env54976) = true)

theorem identity54976 : scanCanonicalize (H12AffineFastState.compose env54976 (packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS)) = affineNative (2^(15+1) ^^^ 62590) := by decide +kernel

theorem selectedBound54976 : packedSelected [0,2,5,6,14,15,17,23,24,26,27,32,41] rootPS < 2^1333 := by decide +kernel

def env54977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62590,25029,10401,1024,32769,4161,54357,8368,21763,8328,65,56573,13745,26017,43477,1500,169,256,21793,46212,54901]

theorem envBound54977 : H12AffineFastState.Bounded env54977 := by
  intro p hp
  have h : env54977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54976_54977 : H12AffineEnvironment.transform 15 62590 env54976 = env54977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62590 env54976 == env54977) = true)

theorem identity54977 : scanCanonicalize (H12AffineFastState.compose env54977 (packedSelected [1,2,3,5,12,14,15,18,26,28,32] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound54977 : packedSelected [1,2,3,5,12,14,15,18,26,28,32] rootPS < 2^1333 := by decide +kernel

def env54978 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,32768,62590,24860,10360,1024,32769,4161,54357,8297,21763,8273,65,56356,13672,25976,43276,1285,112,256,21793,46173,54901]

theorem envBound54978 : H12AffineFastState.Bounded env54978 := by
  intro p hp
  have h : env54978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54977_54978 : H12AffineEnvironment.transform 6 89 env54977 = env54978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env54977 == env54978) = true)

theorem identity54978 : scanCanonicalize (H12AffineFastState.compose env54978 (packedSelected [0,1,2,4,5,6,7,8,9,11,14,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21621) := by decide +kernel

theorem selectedBound54978 : packedSelected [0,1,2,4,5,6,7,8,9,11,14,23,24] rootPS < 2^1333 := by decide +kernel

def env54979 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,21621,8203,24860,10360,1024,21620,4161,32,8297,21763,8273,65,2129,13672,25976,32121,1285,112,256,21793,24616,512]

theorem envBound54979 : H12AffineFastState.Bounded env54979 := by
  intro p hp
  have h : env54979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54978_54979 : H12AffineEnvironment.transform 14 21621 env54978 = env54979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21621 env54978 == env54979) = true)

theorem identity54979 : scanCanonicalize (H12AffineFastState.compose env54979 (packedSelected [0,1,3,5,6,7,8,11,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound54979 : packedSelected [0,1,3,5,6,7,8,11,15] rootPS < 2^1333 := by decide +kernel

def env54980 : List Nat := [2,4,8,16,32,64,89,4,512,1024,2048,4096,8192,16384,21621,8203,24600,10360,1024,21620,4161,32,8297,21511,8273,65,2129,13420,25724,31869,1025,112,4,21541,24616,512]

theorem envBound54980 : H12AffineFastState.Bounded env54980 := by
  intro p hp
  have h : env54980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54979_54980 : H12AffineEnvironment.transform 7 4 env54979 = env54980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env54979 == env54980) = true)

theorem identity54980 : scanCanonicalize (H12AffineFastState.compose env54980 (packedSelected [0,4,6,7,9,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound54980 : packedSelected [0,4,6,7,9,17] rootPS < 2^1333 := by decide +kernel

def env54981 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,8192,16384,21540,8203,24600,10281,1024,21541,4112,32,8248,21511,8192,16,2048,13373,25645,31788,1025,33,4,21541,24616,512]

theorem envBound54981 : H12AffineFastState.Bounded env54981 := by
  intro p hp
  have h : env54981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54980_54981 : H12AffineEnvironment.transform 5 17 env54980 = env54981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env54980 == env54981) = true)

theorem identity54981 : scanCanonicalize (H12AffineFastState.compose env54981 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54981 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env54982 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,41,16384,21540,34,16433,2048,1024,21541,4112,32,17,21511,41,16,2048,5140,17412,23557,1025,33,4,21541,16385,512]

theorem envBound54982 : H12AffineFastState.Bounded env54982 := by
  intro p hp
  have h : env54982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54981_54982 : H12AffineEnvironment.transform 12 41 env54981 = env54982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54981 == env54982) = true)

theorem identity54982 : scanCanonicalize (H12AffineFastState.compose env54982 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound54982 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env54983 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,4096,41,4145,1045,34,4096,2048,1024,1044,4112,32,17,1078,41,16,2048,5140,5173,3124,1025,33,4,1044,4144,512]

theorem envBound54983 : H12AffineFastState.Bounded env54983 := by
  intro p hp
  have h : env54983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54982_54983 : H12AffineEnvironment.transform 13 4145 env54982 = env54983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env54982 == env54983) = true)

theorem identity54983 : scanCanonicalize (H12AffineFastState.compose env54983 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2097) := by decide +kernel

theorem selectedBound54983 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env54984 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,2097,41,2048,1045,34,2097,2048,1024,1044,2081,32,17,1078,41,16,2048,3109,3076,3124,1025,33,4,1044,2049,512]

theorem envBound54984 : H12AffineFastState.Bounded env54984 := by
  intro p hp
  have h : env54984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54983_54984 : H12AffineEnvironment.transform 11 2097 env54983 = env54984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2097 env54983 == env54984) = true)

theorem identity54984 : scanCanonicalize (H12AffineFastState.compose env54984 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound54984 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env54985 : List Nat := [2,4,8,16,32,17,8,4,512,52,2048,2097,41,2048,33,34,2097,2048,52,32,2081,32,17,2,41,16,2048,2065,2096,2048,53,33,4,32,2049,512]

theorem envBound54985 : H12AffineFastState.Bounded env54985 := by
  intro p hp
  have h : env54985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54984_54985 : H12AffineEnvironment.transform 9 52 env54984 = env54985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env54984 == env54985) = true)

theorem identity54985 : scanCanonicalize (H12AffineFastState.compose env54985 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound54985 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env54986 : List Nat := [2,4,8,16,1,17,8,4,512,21,2048,2064,8,2048,0,3,2064,2048,21,1,2048,1,17,2,8,16,2048,2065,2065,2048,20,0,4,1,2049,512]

theorem envBound54986 : H12AffineFastState.Bounded env54986 := by
  intro p hp
  have h : env54986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54985_54986 : H12AffineEnvironment.transform 4 1 env54985 = env54986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env54985 == env54986) = true)

theorem identity54986 : scanCanonicalize (H12AffineFastState.compose env54986 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound54986 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env54987 : List Nat := [2,4,8,16,1,17,8,4,15,21,2048,2064,8,2048,0,3,2064,2048,21,1,2048,1,17,2,8,16,2048,2065,2065,2048,20,0,4,1,2049,15]

theorem envBound54987 : H12AffineFastState.Bounded env54987 := by
  intro p hp
  have h : env54987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54986_54987 : H12AffineEnvironment.transform 8 15 env54986 = env54987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env54986 == env54987) = true)

def env54988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149860,1024,32769,4161,4194304,4363553,21763,8328,65,215367,115151,4378672,4332612,4408371,4268162,256,4396238,4453739,4350948]

theorem envBound54988 : H12AffineFastState.Bounded env54988 := by
  intro p hp
  have h : env54988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54959_54988 : H12AffineEnvironment.transform 22 4363553 env54959 = env54988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env54959 == env54988) = true)

theorem identity54988 : scanCanonicalize (H12AffineFastState.compose env54988 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound54988 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env54989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149860,1024,32769,4161,4194304,4363553,21763,8328,65,171417,5393,4378672,4332612,4362477,4256860,256,4374544,4334005,4350948]

theorem envBound54989 : H12AffineFastState.Bounded env54989 := by
  intro p hp
  have h : env54989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54988_54989 : H12AffineEnvironment.transform 15 54494 env54988 = env54989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env54988 == env54989) = true)

def env54990 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149860,1024,32769,4161,169400,153,21763,8328,65,171417,5393,17800,35324,1365,156132,256,21928,46093,63068]

theorem envBound54990 : H12AffineFastState.Bounded env54990 := by
  intro p hp
  have h : env54990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54989_54990 : H12AffineEnvironment.transform 21 169400 env54989 = env54990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env54989 == env54990) = true)

theorem identity54990 : scanCanonicalize (H12AffineFastState.compose env54990 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound54990 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env54991 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33167,131072,138293,1024,32769,4161,169400,153,82,8328,65,171417,5393,4313,35324,1365,144565,256,249,46093,41741]

theorem envBound54991 : H12AffineFastState.Bounded env54991 := by
  intro p hp
  have h : env54991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54990_54991 : H12AffineEnvironment.transform 13 5457 env54990 = env54991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env54990 == env54991) = true)

theorem identity54991 : scanCanonicalize (H12AffineFastState.compose env54991 (packedSelected [0,1,4,7,18,22,23,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound54991 : packedSelected [0,1,4,7,18,22,23,26,28,31] rootPS < 2^1333 := by decide +kernel

def env54992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,32768,33167,46156,43129,1024,32769,4161,8692,153,82,8328,65,10709,5393,4313,35324,1365,33017,256,249,46093,41741]

theorem envBound54992 : H12AffineFastState.Bounded env54992 := by
  intro p hp
  have h : env54992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54991_54992 : H12AffineEnvironment.transform 16 46156 env54991 = env54992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env54991 == env54992) = true)

theorem identity54992 : scanCanonicalize (H12AffineFastState.compose env54992 (packedSelected [1,4,5,7,8,9,24,27] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound54992 : packedSelected [1,4,5,7,8,9,24,27] rootPS < 2^1333 := by decide +kernel

def env54993 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,32768,33111,46156,43129,1024,32769,4161,8492,65,82,8272,65,10509,5393,4097,35108,1365,32801,256,33,46093,41741]

theorem envBound54993 : H12AffineFastState.Bounded env54993 := by
  intro p hp
  have h : env54993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54992_54993 : H12AffineEnvironment.transform 6 88 env54992 = env54993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env54992 == env54993) = true)

theorem identity54993 : scanCanonicalize (H12AffineFastState.compose env54993 (packedSelected [0,4,7,17,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound54993 : packedSelected [0,4,7,17,22] rootPS < 2^1333 := by decide +kernel

def env54994 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,8192,5457,8540,8203,5392,2341,1024,8541,4161,8492,65,82,8272,65,10509,5393,4097,10360,1365,8573,256,33,5457,593]

theorem envBound54994 : H12AffineFastState.Bounded env54994 := by
  intro p hp
  have h : env54994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54993_54994 : H12AffineEnvironment.transform 14 8540 env54993 = env54994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env54993 == env54994) = true)

theorem identity54994 : scanCanonicalize (H12AffineFastState.compose env54994 (packedSelected [0,4,7,9,10,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound54994 : packedSelected [0,4,7,9,10,12] rootPS < 2^1333 := by decide +kernel

def env54995 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5377,8460,8203,5392,2341,1024,8461,4113,8492,17,2,8192,17,10509,5393,4097,10280,1285,8493,256,33,5377,513]

theorem envBound54995 : H12AffineFastState.Bounded env54995 := by
  intro p hp
  have h : env54995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54994_54995 : H12AffineEnvironment.transform 5 16 env54994 = env54995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env54994 == env54995) = true)

theorem identity54995 : scanCanonicalize (H12AffineFastState.compose env54995 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound54995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env54996 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5157,8232,8203,5172,2049,1024,8233,4113,8200,17,2,8192,17,10281,5173,4097,10280,1057,8201,36,33,5157,513]

theorem envBound54996 : H12AffineFastState.Bounded env54996 := by
  intro p hp
  have h : env54996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54995_54996 : H12AffineEnvironment.transform 7 36 env54995 = env54996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env54995 == env54996) = true)

theorem identity54996 : scanCanonicalize (H12AffineFastState.compose env54996 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound54996 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env54997 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5157,1,34,5172,2049,1024,0,4113,33,17,2,41,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound54997 : H12AffineFastState.Bounded env54997 := by
  intro p hp
  have h : env54997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54996_54997 : H12AffineEnvironment.transform 12 41 env54996 = env54997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env54996 == env54997) = true)

def env54998 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1045,1,34,1028,2049,1024,0,33,33,17,2,41,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound54998 : H12AffineFastState.Bounded env54998 := by
  intro p hp
  have h : env54998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54997_54998 : H12AffineEnvironment.transform 11 48 env54997 = env54998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env54997 == env54998) = true)

theorem identity54998 : scanCanonicalize (H12AffineFastState.compose env54998 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound54998 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env54999 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,48,41,529,1,34,512,2049,516,0,33,33,17,2,41,17,2048,513,49,2049,549,32,36,33,529,513]

theorem envBound54999 : H12AffineFastState.Bounded env54999 := by
  intro p hp
  have h : env54999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54998_54999 : H12AffineEnvironment.transform 9 516 env54998 = env54999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env54998 == env54999) = true)

def env55000 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,41,33,1,34,48,2049,52,0,33,33,17,2,41,17,2048,49,49,2049,21,32,36,33,33,49]

theorem envBound55000 : H12AffineFastState.Bounded env55000 := by
  intro p hp
  have h : env55000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54999_55000 : H12AffineEnvironment.transform 8 48 env54999 = env55000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env54999 == env55000) = true)

theorem identity55000 : scanCanonicalize (H12AffineFastState.compose env55000 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55000 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55001 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,42,41,33,1,34,42,2049,46,0,33,33,11,2,41,11,2048,43,43,2049,15,32,36,33,33,43]

theorem envBound55001 : H12AffineFastState.Bounded env55001 := by
  intro p hp
  have h : env55001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55000_55001 : H12AffineEnvironment.transform 3 10 env55000 = env55001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55000 == env55001) = true)

def leafEnv55001 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,42,41,33,1,34,42,2049,46,0,33,33,11,2,15,41,1,11,2048,43,43,2049,15,32,36,33,4,34,33,43,1,33,0]

def active55001 : List Nat := [0,1,2,4,10]

def tree55001 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55001 : H12WitnessSearch.Good tree55001 := H12GlobalWitnessIndex.good

theorem leafIdentity55001 : H12AffineFastState.composeSystem env55001 rootObs = leafEnv55001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55001 rootObs == leafEnv55001) = true)

theorem terminalChecked55001 : H12PackedTerminal.terminalCheckFast leafEnv55001 active55001 tree55001 = true := by decide +kernel

def env55002 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,41,32,1,34,49,2049,53,0,33,33,17,2,41,17,2048,48,49,2049,20,32,36,33,32,48]

theorem envBound55002 : H12AffineFastState.Bounded env55002 := by
  intro p hp
  have h : env55002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54999_55002 : H12AffineEnvironment.transform 8 49 env54999 = env55002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env54999 == env55002) = true)

def env55003 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1044,1,34,1029,2049,1024,0,32,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound55003 : H12AffineFastState.Bounded env55003 := by
  intro p hp
  have h : env55003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54997_55003 : H12AffineEnvironment.transform 11 49 env54997 = env55003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env54997 == env55003) = true)

theorem identity55003 : scanCanonicalize (H12AffineFastState.compose env55003 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound55003 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55004 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,49,41,1044,1,34,1029,2049,1024,0,32,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1044,48]

theorem envBound55004 : H12AffineFastState.Bounded env55004 := by
  intro p hp
  have h : env55004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55003_55004 : H12AffineEnvironment.transform 8 49 env55003 = env55004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env55003 == env55004) = true)

def env55005 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,41,32,1,34,49,2049,52,0,32,33,17,2,41,17,2048,48,48,2049,21,32,36,33,32,48]

theorem envBound55005 : H12AffineFastState.Bounded env55005 := by
  intro p hp
  have h : env55005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55004_55005 : H12AffineEnvironment.transform 9 52 env55004 = env55005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55004 == env55005) = true)

theorem identity55005 : scanCanonicalize (H12AffineFastState.compose env55005 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55005 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55006 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,43,41,32,1,34,43,2049,46,0,32,33,11,2,41,11,2048,42,42,2049,15,32,36,33,32,42]

theorem envBound55006 : H12AffineFastState.Bounded env55006 := by
  intro p hp
  have h : env55006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55005_55006 : H12AffineEnvironment.transform 3 10 env55005 = env55006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55005 == env55006) = true)

def leafEnv55006 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,43,41,32,1,34,43,2049,46,0,32,33,11,2,15,41,1,11,2048,42,42,2049,15,32,36,33,4,34,32,42,1,32,0]

def active55006 : List Nat := [0,1,2,4,10]

def tree55006 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55006 : H12WitnessSearch.Good tree55006 := H12GlobalWitnessIndex.good

theorem leafIdentity55006 : H12AffineFastState.composeSystem env55006 rootObs = leafEnv55006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55006 rootObs == leafEnv55006) = true)

theorem terminalChecked55006 : H12PackedTerminal.terminalCheckFast leafEnv55006 active55006 tree55006 = true := by decide +kernel

def env55007 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,41,33,1,34,48,2049,53,0,32,33,17,2,41,17,2048,49,48,2049,20,32,36,33,33,48]

theorem envBound55007 : H12AffineFastState.Bounded env55007 := by
  intro p hp
  have h : env55007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55004_55007 : H12AffineEnvironment.transform 9 53 env55004 = env55007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55004 == env55007) = true)

def env55008 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,149860,1024,32769,4161,169401,152,21763,8328,65,171417,5393,17801,35325,1364,156133,256,21929,46092,63069]

theorem envBound55008 : H12AffineFastState.Bounded env55008 := by
  intro p hp
  have h : env55008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54989_55008 : H12AffineEnvironment.transform 21 169401 env54989 = env55008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env54989 == env55008) = true)

theorem identity55008 : scanCanonicalize (H12AffineFastState.compose env55008 (packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 46276) := by decide +kernel

theorem selectedBound55008 : packedSelected [0,1,3,9,10,14,17,18,19,22,23,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env55009 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,46276,64928,1024,32769,4161,8573,152,21763,8328,65,10589,5393,17801,35325,1364,54561,256,21929,46092,63069]

theorem envBound55009 : H12AffineFastState.Bounded env55009 := by
  intro p hp
  have h : env55009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55008_55009 : H12AffineEnvironment.transform 16 46276 env55008 = env55009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46276 env55008 == env55009) = true)

def env55010 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,46156,64808,1024,32769,4161,8573,16,21763,8192,65,10589,5393,17665,35189,1364,54561,256,21793,46092,63069]

theorem envBound55010 : H12AffineFastState.Bounded env55010 := by
  intro p hp
  have h : env55010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55009_55010 : H12AffineEnvironment.transform 6 8 env55009 = env55010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55009 == env55010) = true)

theorem identity55010 : scanCanonicalize (H12AffineFastState.compose env55010 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound55010 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55011 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,342,24908,10280,1024,21761,4161,8573,16,21763,8192,65,10589,5393,17665,23669,1364,33,256,21793,24844,9053]

theorem envBound55011 : H12AffineFastState.Bounded env55011 := by
  intro p hp
  have h : env55011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55010_55011 : H12AffineEnvironment.transform 14 21760 env55010 = env55011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env55010 == env55011) = true)

theorem identity55011 : scanCanonicalize (H12AffineFastState.compose env55011 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55011 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env55012 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,342,16400,2420,1024,21761,4161,33,16,21763,348,65,2049,5393,17665,23669,1364,33,256,21793,16464,513]

theorem envBound55012 : H12AffineFastState.Bounded env55012 := by
  intro p hp
  have h : env55012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55011_55012 : H12AffineEnvironment.transform 12 348 env55011 = env55012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55011 == env55012) = true)

theorem identity55012 : scanCanonicalize (H12AffineFastState.compose env55012 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55012 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55013 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21760,263,16400,2341,1024,21761,4112,33,16,21763,269,16,2049,5393,17665,23588,1285,33,256,21793,16385,513]

theorem envBound55013 : H12AffineFastState.Bounded env55013 := by
  intro p hp
  have h : env55013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55012_55013 : H12AffineEnvironment.transform 5 17 env55012 = env55013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55012 == env55013) = true)

theorem identity55013 : scanCanonicalize (H12AffineFastState.compose env55013 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3856) := by decide +kernel

theorem selectedBound55013 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55014 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3856,269,16384,18960,263,16400,2341,1024,18961,3840,33,16,18963,269,16,2049,2561,17665,17204,1285,33,256,18993,16385,513]

theorem envBound55014 : H12AffineFastState.Bounded env55014 := by
  intro p hp
  have h : env55014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55013_55014 : H12AffineEnvironment.transform 11 3856 env55013 = env55014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3856 env55013 == env55014) = true)

theorem identity55014 : scanCanonicalize (H12AffineFastState.compose env55014 (packedSelected [2,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound55014 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env55015 : List Nat := [2,4,8,16,32,17,8,256,512,517,2048,2325,269,16384,18960,263,16400,2341,517,18961,2309,33,16,18963,269,16,2049,2561,17156,17204,768,33,256,18993,16385,513]

theorem envBound55015 : H12AffineFastState.Bounded env55015 := by
  intro p hp
  have h : env55015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55014_55015 : H12AffineEnvironment.transform 9 517 env55014 = env55015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env55014 == env55015) = true)

theorem identity55015 : scanCanonicalize (H12AffineFastState.compose env55015 (packedSelected [0,2,9] rootPS)) = affineNative (2^(13+1) ^^^ 2357) := by decide +kernel

theorem selectedBound55015 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env55016 : List Nat := [2,4,8,16,32,17,8,256,512,517,2048,2325,269,2357,805,263,2341,2341,517,804,2309,33,16,806,269,16,2049,2561,2609,2561,768,33,256,772,2356,513]

theorem envBound55016 : H12AffineFastState.Bounded env55016 := by
  intro p hp
  have h : env55016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55015_55016 : H12AffineEnvironment.transform 13 2357 env55015 = env55016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2357 env55015 == env55016) = true)

theorem identity55016 : scanCanonicalize (H12AffineFastState.compose env55016 (packedSelected [0,2,4,11] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound55016 : packedSelected [0,2,4,11] rootPS < 2^1333 := by decide +kernel

def env55017 : List Nat := [2,4,8,16,32,17,8,256,293,288,2048,2325,269,2357,0,263,2341,2341,288,1,2309,33,16,3,269,16,2049,2340,2324,2340,37,33,256,33,2356,292]

theorem envBound55017 : H12AffineFastState.Bounded env55017 := by
  intro p hp
  have h : env55017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55016_55017 : H12AffineEnvironment.transform 8 293 env55016 = env55017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env55016 == env55017) = true)

theorem identity55017 : scanCanonicalize (H12AffineFastState.compose env55017 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound55017 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55018 : List Nat := [2,4,8,16,32,17,8,256,293,288,292,49,269,17,0,263,1,1,288,1,33,33,16,3,269,16,293,0,48,0,37,33,256,33,16,292]

theorem envBound55018 : H12AffineFastState.Bounded env55018 := by
  intro p hp
  have h : env55018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55017_55018 : H12AffineEnvironment.transform 10 292 env55017 = env55018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env55017 == env55018) = true)

def env55019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,46157,64809,1024,32769,4161,8573,17,21763,8193,65,10589,5393,17664,35188,1364,54561,256,21792,46092,63069]

theorem envBound55019 : H12AffineFastState.Bounded env55019 := by
  intro p hp
  have h : env55019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55009_55019 : H12AffineEnvironment.transform 6 9 env55009 = env55019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55009 == env55019) = true)

theorem identity55019 : scanCanonicalize (H12AffineFastState.compose env55019 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55019 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55020 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29963,5393,23669,1024,8541,4161,8573,17,21763,8193,65,10589,5393,17664,10280,1364,29821,256,21792,5456,22273]

theorem envBound55020 : H12AffineFastState.Bounded env55020 := by
  intro p hp
  have h : env55020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55019_55020 : H12AffineEnvironment.transform 14 8540 env55019 = env55020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55019 == env55020) = true)

theorem identity55020 : scanCanonicalize (H12AffineFastState.compose env55020 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound55020 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55021 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,8203,5393,2421,1024,8541,4161,8573,17,3,8193,65,10589,5393,4096,10280,1364,8573,256,32,5456,513]

theorem envBound55021 : H12AffineFastState.Bounded env55021 := by
  intro p hp
  have h : env55021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55020_55021 : H12AffineEnvironment.transform 13 5376 env55020 = env55021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env55020 == env55021) = true)

theorem identity55021 : scanCanonicalize (H12AffineFastState.compose env55021 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55021 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55022 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,343,5393,2421,1024,1,4161,33,17,3,349,65,2049,5393,4096,2420,1364,33,256,32,5456,513]

theorem envBound55022 : H12AffineFastState.Bounded env55022 := by
  intro p hp
  have h : env55022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55021_55022 : H12AffineEnvironment.transform 12 348 env55021 = env55022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55021 == env55022) = true)

theorem identity55022 : scanCanonicalize (H12AffineFastState.compose env55022 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55022 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55023 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,262,5393,2340,1024,1,4112,33,17,3,268,16,2049,5393,4096,2341,1285,33,256,32,5377,513]

theorem envBound55023 : H12AffineFastState.Bounded env55023 := by
  intro p hp
  have h : env55023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55022_55023 : H12AffineEnvironment.transform 5 17 env55022 = env55023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55022 == env55023) = true)

theorem identity55023 : scanCanonicalize (H12AffineFastState.compose env55023 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound55023 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55024 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,0,262,4096,2340,273,1,4112,33,17,3,268,16,2049,4096,4096,2341,20,33,256,32,4112,513]

theorem envBound55024 : H12AffineFastState.Bounded env55024 := by
  intro p hp
  have h : env55024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55023_55024 : H12AffineEnvironment.transform 9 273 env55023 = env55024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55023 == env55024) = true)

theorem identity55024 : scanCanonicalize (H12AffineFastState.compose env55024 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound55024 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55025 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2064,269,2049,0,262,2064,2340,273,1,2048,33,17,3,268,16,2049,2064,2064,2341,20,33,256,32,2048,513]

theorem envBound55025 : H12AffineFastState.Bounded env55025 := by
  intro p hp
  have h : env55025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55024_55025 : H12AffineEnvironment.transform 11 2064 env55024 = env55025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env55024 == env55025) = true)

theorem identity55025 : scanCanonicalize (H12AffineFastState.compose env55025 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55025 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55026 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2064,41,2049,0,34,2064,2048,53,1,2048,33,17,3,40,16,2049,2064,2064,2049,20,33,36,32,2048,513]

theorem envBound55026 : H12AffineFastState.Bounded env55026 := by
  intro p hp
  have h : env55026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55025_55026 : H12AffineEnvironment.transform 7 36 env55025 = env55026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55025 == env55026) = true)

theorem identity55026 : scanCanonicalize (H12AffineFastState.compose env55026 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55026 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55027 : List Nat := [2,4,8,11,32,10,9,36,512,46,2048,2059,41,2049,0,34,2059,2048,46,1,2048,33,10,3,40,11,2049,2059,2059,2049,15,33,36,32,2048,513]

theorem envBound55027 : H12AffineFastState.Bounded env55027 := by
  intro p hp
  have h : env55027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55026_55027 : H12AffineEnvironment.transform 3 11 env55026 = env55027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55026 == env55027) = true)

def env55028 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,2097152,4194304,8388608,2114883,8328,65,14797863,115150,10507600,8423780,10600786,4268163,256,8487406,8478795,10544773]

theorem envBound55028 : H12AffineFastState.Bounded env55028 := by
  intro p hp
  have h : env55028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54910_55028 : H12AffineEnvironment.transform 17 149861 env54910 = env55028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env54910 == env55028) = true)

def env55029 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,8388608,21763,8328,65,12704871,115150,8406288,8423780,8507666,4268163,256,8487406,8478795,8451781]

theorem envBound55029 : H12AffineFastState.Bounded env55029 := by
  intro p hp
  have h : env55029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55028_55029 : H12AffineEnvironment.transform 20 4160 env55028 = env55029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55028 == env55029) = true)

def env55030 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363552,21763,8328,65,215367,115150,4378672,4332612,4408370,4268163,256,4396238,4453739,4350949]

theorem envBound55030 : H12AffineFastState.Bounded env55030 := by
  intro p hp
  have h : env55030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55029_55030 : H12AffineEnvironment.transform 22 4363552 env55029 = env55030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env55029 == env55030) = true)

theorem identity55030 : scanCanonicalize (H12AffineFastState.compose env55030 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 156132) := by decide +kernel

theorem selectedBound55030 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55031 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156132,62660,21763,8328,65,215367,115150,45524,32160,75222,213351,256,95530,103567,513]

theorem envBound55031 : H12AffineFastState.Bounded env55031 := by
  intro p hp
  have h : env55031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55030_55031 : H12AffineEnvironment.transform 21 156132 env55030 = env55031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 156132 env55030 == env55031) = true)

def env55032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156012,62540,21763,8192,65,215367,115014,45404,32040,75102,213351,256,95530,103431,513]

theorem envBound55032 : H12AffineFastState.Bounded env55032 := by
  intro p hp
  have h : env55032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55031_55032 : H12AffineEnvironment.transform 6 8 env55031 = env55032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55031 == env55032) = true)

theorem identity55032 : scanCanonicalize (H12AffineFastState.compose env55032 (packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound55032 : packedSelected [1,3,4,7,8,9,10,12,16,17,18,19,20,23,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env55033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,13389,32040,1024,32769,4160,21793,62540,21763,8192,65,97546,115014,45404,32040,75102,95530,256,95530,103431,513]

theorem envBound55033 : H12AffineFastState.Bounded env55033 := by
  intro p hp
  have h : env55033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55032_55033 : H12AffineEnvironment.transform 16 13389 env55032 = env55033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env55032 == env55033) = true)

theorem identity55033 : scanCanonicalize (H12AffineFastState.compose env55033 (packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound55033 : packedSelected [3,4,5,9,10,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env55034 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13389,32040,1024,32769,4160,21793,62540,21763,8192,65,43356,5392,45404,32040,61704,41340,256,41340,16465,513]

theorem envBound55034 : H12AffineFastState.Bounded env55034 := by
  intro p hp
  have h : env55034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55033_55034 : H12AffineEnvironment.transform 15 54358 env55033 = env55034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env55033 == env55034) = true)

theorem identity55034 : scanCanonicalize (H12AffineFastState.compose env55034 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound55034 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55035 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,13389,32040,1024,29788,4160,21793,17,21763,8192,65,23809,5392,17665,32040,1365,21793,256,21793,16465,513]

theorem envBound55035 : H12AffineFastState.Bounded env55035 := by
  intro p hp
  have h : env55035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55034_55035 : H12AffineEnvironment.transform 14 29789 env55034 = env55035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env55034 == env55035) = true)

theorem identity55035 : scanCanonicalize (H12AffineFastState.compose env55035 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55035 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55036 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,21841,263,5441,23588,1024,21840,4160,21793,17,21763,268,65,23809,5392,17665,23588,1365,21793,256,21793,16465,513]

theorem envBound55036 : H12AffineFastState.Bounded env55036 := by
  intro p hp
  have h : env55036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55035_55036 : H12AffineEnvironment.transform 12 268 env55035 = env55036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55035 == env55036) = true)

theorem identity55036 : scanCanonicalize (H12AffineFastState.compose env55036 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(13+1) ^^^ 6161) := by decide +kernel

theorem selectedBound55036 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env55037 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,6161,3392,263,5441,1077,1024,3393,4160,3376,17,3346,268,65,1296,5392,7440,1077,1365,3376,256,3376,6208,513]

theorem envBound55037 : H12AffineFastState.Bounded env55037 := by
  intro p hp
  have h : env55037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55036_55037 : H12AffineEnvironment.transform 13 6161 env55036 = env55037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6161 env55036 == env55037) = true)

theorem identity55037 : scanCanonicalize (H12AffineFastState.compose env55037 (packedSelected [6,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound55037 : packedSelected [6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env55038 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,4096,268,5457,0,263,5441,1077,1024,1,4160,112,17,82,268,65,1296,5392,4176,1077,1365,112,256,112,5376,513]

theorem envBound55038 : H12AffineFastState.Bounded env55038 := by
  intro p hp
  have h : env55038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55037_55038 : H12AffineEnvironment.transform 10 1344 env55037 = env55038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env55037 == env55038) = true)

theorem identity55038 : scanCanonicalize (H12AffineFastState.compose env55038 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 42) := by decide +kernel

theorem selectedBound55038 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env55039 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1344,42,268,1403,0,263,1387,1077,1024,1,106,112,17,82,268,65,1296,1338,122,1077,1365,112,256,112,1322,513]

theorem envBound55039 : H12AffineFastState.Bounded env55039 := by
  intro p hp
  have h : env55039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55038_55039 : H12AffineEnvironment.transform 11 42 env55038 = env55039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 42 env55038 == env55039) = true)

def env55040 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,156013,62541,21763,8193,65,215367,115015,45405,32041,75103,213351,256,95530,103430,513]

theorem envBound55040 : H12AffineFastState.Bounded env55040 := by
  intro p hp
  have h : env55040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55031_55040 : H12AffineEnvironment.transform 6 9 env55031 = env55040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55031 == env55040) = true)

theorem identity55040 : scanCanonicalize (H12AffineFastState.compose env55040 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound55040 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55041 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,90138,76159,1024,32769,4160,65911,62541,21763,8193,65,10589,115015,45405,32041,75103,8573,256,95530,103430,513]

theorem envBound55041 : H12AffineFastState.Bounded env55041 := by
  intro p hp
  have h : env55041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55040_55041 : H12AffineEnvironment.transform 16 90138 env55040 = env55041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env55040 == env55041) = true)

theorem identity55041 : scanCanonicalize (H12AffineFastState.compose env55041 (packedSelected [0,4,7,9,11,14,18,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 53574) := by decide +kernel

theorem selectedBound55041 : packedSelected [0,4,7,9,11,14,18,23,32] rootPS < 2^1333 := by decide +kernel

def env55042 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,53574,45404,63545,1024,32769,4160,53297,62541,21763,8193,65,10589,4097,45405,32041,62489,8573,256,42092,17728,513]

theorem envBound55042 : H12AffineFastState.Bounded env55042 := by
  intro p hp
  have h : env55042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55041_55042 : H12AffineEnvironment.transform 15 53574 env55041 = env55042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 53574 env55041 == env55042) = true)

theorem identity55042 : scanCanonicalize (H12AffineFastState.compose env55042 (packedSelected [0,1,4,5,8,9,12,15,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 28729) := by decide +kernel

theorem selectedBound55042 : packedSelected [0,1,4,5,8,9,12,15,20,24,27] rootPS < 2^1333 := by decide +kernel

def env55043 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,28729,8575,16741,2048,1024,28728,4160,8200,1140,21763,8193,65,10589,4097,16740,32041,1056,8573,256,21589,17728,513]

theorem envBound55043 : H12AffineFastState.Bounded env55043 := by
  intro p hp
  have h : env55043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55042_55043 : H12AffineEnvironment.transform 14 28729 env55042 = env55043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 28729 env55042 == env55043) = true)

theorem identity55043 : scanCanonicalize (H12AffineFastState.compose env55043 (packedSelected [0,1,3,4,7,8,9,10,14,15,17,18,23,24,38] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound55043 : packedSelected [0,1,3,4,7,8,9,10,14,15,17,18,23,24,38] rootPS < 2^1333 := by decide +kernel

def env55044 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,16384,28729,8575,16741,2048,321,28728,4160,8200,309,20546,8193,65,10589,4097,16740,30824,353,8573,256,20756,16385,513]

theorem envBound55044 : H12AffineFastState.Bounded env55044 := by
  intro p hp
  have h : env55044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55043_55044 : H12AffineEnvironment.transform 9 321 env55043 = env55044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env55043 == env55044) = true)

theorem identity55044 : scanCanonicalize (H12AffineFastState.compose env55044 (packedSelected [0,3,5,7,10,12,15,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound55044 : packedSelected [0,3,5,7,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env55045 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,12392,81,8575,12557,2048,321,80,4160,8200,309,8234,8193,65,10589,4097,12556,2048,353,8573,256,8572,12393,513]

theorem envBound55045 : H12AffineFastState.Bounded env55045 := by
  intro p hp
  have h : env55045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55044_55045 : H12AffineEnvironment.transform 13 12392 env55044 = env55045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env55044 == env55045) = true)

theorem identity55045 : scanCanonicalize (H12AffineFastState.compose env55045 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55045 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env55046 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,269,4453,81,114,4096,2048,321,80,4160,261,309,295,268,65,2128,4097,4097,2048,353,112,256,113,4452,513]

theorem envBound55046 : H12AffineFastState.Bounded env55046 := by
  intro p hp
  have h : env55046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55045_55046 : H12AffineEnvironment.transform 12 269 env55045 = env55046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55045 == env55046) = true)

theorem identity55046 : scanCanonicalize (H12AffineFastState.compose env55046 (packedSelected [11,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55046 : packedSelected [11,15] rootPS < 2^1333 := by decide +kernel

def env55047 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,4096,120,4112,81,114,4096,2048,52,80,4160,112,64,82,121,65,2128,4097,4097,2048,20,112,117,113,4113,513]

theorem envBound55047 : H12AffineFastState.Bounded env55047 := by
  intro p hp
  have h : env55047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55046_55047 : H12AffineEnvironment.transform 7 117 env55046 = env55047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55046 == env55047) = true)

theorem identity55047 : scanCanonicalize (H12AffineFastState.compose env55047 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 577) := by decide +kernel

theorem selectedBound55047 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55048 : List Nat := [2,4,8,16,32,64,9,117,512,52,2048,577,120,593,81,114,577,2048,52,80,513,112,64,82,121,65,2128,576,576,2048,20,112,117,113,592,513]

theorem envBound55048 : H12AffineFastState.Bounded env55048 := by
  intro p hp
  have h : env55048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55047_55048 : H12AffineEnvironment.transform 11 577 env55047 = env55048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 577 env55047 == env55048) = true)

def env55049 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,4194304,4363553,21763,8328,65,215366,115150,4378673,4332613,4408371,4268163,256,4396239,4453738,4350948]

theorem envBound55049 : H12AffineFastState.Bounded env55049 := by
  intro p hp
  have h : env55049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55029_55049 : H12AffineEnvironment.transform 22 4363553 env55029 = env55049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env55029 == env55049) = true)

theorem identity55049 : scanCanonicalize (H12AffineFastState.compose env55049 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound55049 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55050 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149861,1024,29909,4160,4194304,4350453,21763,8328,65,215366,79130,4334821,4332613,4408371,4268163,256,4396239,4391358,4350948]

theorem envBound55050 : H12AffineFastState.Bounded env55050 := by
  intro p hp
  have h : env55050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55049_55050 : H12AffineEnvironment.transform 14 29908 env55049 = env55050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env55049 == env55050) = true)

def env55051 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149861,1024,29909,4160,32,156117,21763,8328,65,215366,79130,140485,138341,214035,73891,256,201967,197022,156612]

theorem envBound55051 : H12AffineFastState.Bounded env55051 := by
  intro p hp
  have h : env55051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55050_55051 : H12AffineEnvironment.transform 21 32 env55050 = env55051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env55050 == env55051) = true)

theorem identity55051 : scanCanonicalize (H12AffineFastState.compose env55051 (packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound55051 : packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS < 2^1333 := by decide +kernel

def env55052 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,82382,67755,1024,29909,4160,32,73755,21763,8328,65,2184,79130,91403,89515,1501,73891,256,21793,16464,74250]

theorem envBound55052 : H12AffineFastState.Bounded env55052 := by
  intro p hp
  have h : env55052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55051_55052 : H12AffineEnvironment.transform 16 82382 env55051 = env55052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env55051 == env55052) = true)

theorem identity55052 : scanCanonicalize (H12AffineFastState.compose env55052 (packedSelected [0,2,3,5,6,7,10,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound55052 : packedSelected [0,2,3,5,6,7,10,20] rootPS < 2^1333 := by decide +kernel

def env55053 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29709,65536,82199,67698,1024,29708,4160,32,73755,21763,8273,65,2129,79130,91403,89458,1284,73850,256,21793,16464,74250]

theorem envBound55053 : H12AffineFastState.Bounded env55053 := by
  intro p hp
  have h : env55053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55052_55053 : H12AffineEnvironment.transform 6 89 env55052 = env55053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env55052 == env55053) = true)

theorem identity55053 : scanCanonicalize (H12AffineFastState.compose env55053 (packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound55053 : packedSelected [0,3,4,5,7,9,12,16,18,19] rootPS < 2^1333 := by decide +kernel

def env55054 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,29709,342,16449,2340,1024,29708,4160,32,8525,21763,8273,65,2129,13388,25693,23588,1284,8492,256,21793,16464,9052]

theorem envBound55054 : H12AffineFastState.Bounded env55054 := by
  intro p hp
  have h : env55054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55053_55054 : H12AffineEnvironment.transform 15 342 env55053 = env55054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env55053 == env55054) = true)

theorem identity55054 : scanCanonicalize (H12AffineFastState.compose env55054 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound55054 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env55055 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8541,342,5393,2340,1024,8540,4160,32,8525,83,8273,65,2129,13388,12557,2420,1284,8492,256,113,5376,9052]

theorem envBound55055 : H12AffineFastState.Bounded env55055 := by
  intro p hp
  have h : env55055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55054_55055 : H12AffineEnvironment.transform 13 5456 env55054 = env55055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env55054 == env55055) = true)

theorem identity55055 : scanCanonicalize (H12AffineFastState.compose env55055 (packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound55055 : packedSelected [0,1,2,4,7,8,9,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env55056 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,88,5456,261,342,5393,2340,1024,260,4160,32,277,83,9,65,2129,5140,4437,2420,1284,372,256,113,5376,772]

theorem envBound55056 : H12AffineFastState.Bounded env55056 := by
  intro p hp
  have h : env55056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55055_55056 : H12AffineEnvironment.transform 12 88 env55055 = env55056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env55055 == env55056) = true)

theorem identity55056 : scanCanonicalize (H12AffineFastState.compose env55056 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55056 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env55057 : List Nat := [2,4,8,16,32,64,89,4,512,1024,2048,4096,88,5204,1,82,5141,2080,1024,0,4160,32,17,83,9,65,2129,5140,4177,2160,1024,112,4,113,5124,512]

theorem envBound55057 : H12AffineFastState.Bounded env55057 := by
  intro p hp
  have h : env55057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55056_55057 : H12AffineEnvironment.transform 7 4 env55056 = env55057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55056 == env55057) = true)

theorem identity55057 : scanCanonicalize (H12AffineFastState.compose env55057 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound55057 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55058 : List Nat := [2,4,8,16,32,49,40,4,512,1024,2048,4096,41,5157,1,35,5141,2080,1024,0,4145,32,17,34,9,48,2080,5140,4128,2049,1024,1,4,0,5124,512]

theorem envBound55058 : H12AffineFastState.Bounded env55058 := by
  intro p hp
  have h : env55058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55057_55058 : H12AffineEnvironment.transform 5 49 env55057 = env55058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env55057 == env55058) = true)

theorem identity55058 : scanCanonicalize (H12AffineFastState.compose env55058 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55058 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55059 : List Nat := [2,4,8,16,1,16,9,4,512,1024,2048,4096,8,5124,1,2,5141,2049,1024,0,4112,1,17,3,9,17,2049,5140,4097,2049,1024,1,4,0,5124,512]

theorem envBound55059 : H12AffineFastState.Bounded env55059 := by
  intro p hp
  have h : env55059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55058_55059 : H12AffineEnvironment.transform 4 1 env55058 = env55059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55058 == env55059) = true)

theorem identity55059 : scanCanonicalize (H12AffineFastState.compose env55059 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55059 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55060 : List Nat := [2,4,8,1,1,1,9,4,512,1024,2048,4096,8,5124,1,2,5124,2049,1024,0,4097,1,0,3,9,0,2049,5125,4097,2049,1024,1,4,0,5124,512]

theorem envBound55060 : H12AffineFastState.Bounded env55060 := by
  intro p hp
  have h : env55060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55059_55060 : H12AffineEnvironment.transform 3 1 env55059 = env55060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55059 == env55060) = true)

theorem identity55060 : scanCanonicalize (H12AffineFastState.compose env55060 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound55060 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55061 : List Nat := [2,4,8,1,1,1,9,4,512,1024,2048,513,8,1541,1,2,1541,2049,1024,0,512,1,0,3,9,0,2049,1540,512,2049,1024,1,4,0,1541,512]

theorem envBound55061 : H12AffineFastState.Bounded env55061 := by
  intro p hp
  have h : env55061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55060_55061 : H12AffineEnvironment.transform 11 513 env55060 = env55061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env55060 == env55061) = true)

theorem identity55061 : scanCanonicalize (H12AffineFastState.compose env55061 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound55061 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55062 : List Nat := [2,4,8,1,1,1,9,4,512,1024,512,513,8,1541,1,2,1541,513,1024,0,512,1,0,3,9,0,513,1540,512,513,1024,1,4,0,1541,512]

theorem envBound55062 : H12AffineFastState.Bounded env55062 := by
  intro p hp
  have h : env55062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55061_55062 : H12AffineEnvironment.transform 10 512 env55061 = env55062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env55061 == env55062) = true)

def env55063 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,149861,1024,29909,4160,33,156116,21763,8328,65,215366,79130,140484,138340,214034,73890,256,201966,197023,156613]

theorem envBound55063 : H12AffineFastState.Bounded env55063 := by
  intro p hp
  have h : env55063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55050_55063 : H12AffineEnvironment.transform 21 33 env55050 = env55063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55050 == env55063) = true)

theorem identity55063 : scanCanonicalize (H12AffineFastState.compose env55063 (packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 79251) := by decide +kernel

theorem selectedBound55063 : packedSelected [0,3,4,5,7,8,10,17,22,28,31] rootPS < 2^1333 := by decide +kernel

def env55064 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,79251,97526,1024,29909,4160,33,87111,21763,8328,65,31957,79130,69975,76279,29057,73890,256,8573,13324,87638]

theorem envBound55064 : H12AffineFastState.Bounded env55064 := by
  intro p hp
  have h : env55064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55063_55064 : H12AffineEnvironment.transform 16 79251 env55063 = env55064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79251 env55063 == env55064) = true)

theorem identity55064 : scanCanonicalize (H12AffineFastState.compose env55064 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound55064 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env55065 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,343,13508,32161,1024,29909,4160,33,21776,21763,8328,65,31957,13389,4096,10400,29057,8693,256,8573,13324,22273]

theorem envBound55065 : H12AffineFastState.Bounded env55065 := by
  intro p hp
  have h : env55065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55064_55065 : H12AffineEnvironment.transform 15 343 env55064 = env55065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env55064 == env55065) = true)

theorem identity55065 : scanCanonicalize (H12AffineFastState.compose env55065 (packedSelected [2,4,6,9,10,11,15,19] rootPS)) = affineNative (2^(13+1) ^^^ 2185) := by decide +kernel

theorem selectedBound55065 : packedSelected [2,4,6,9,10,11,15,19] rootPS < 2^1333 := by decide +kernel

def env55066 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,2185,15453,343,13508,13608,1024,15452,4160,33,7577,7562,8328,65,13404,13389,4096,10400,14600,8693,256,8573,13324,8072]

theorem envBound55066 : H12AffineFastState.Bounded env55066 := by
  intro p hp
  have h : env55066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55065_55066 : H12AffineEnvironment.transform 13 2185 env55065 = env55066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2185 env55065 == env55066) = true)

theorem identity55066 : scanCanonicalize (H12AffineFastState.compose env55066 (packedSelected [2,3,4,6,9,11,15,17,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55066 : packedSelected [2,3,4,6,9,11,15,17,24] rootPS < 2^1333 := by decide +kernel

def env55067 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,2185,15372,262,13461,13608,1024,15373,4113,33,7577,7562,8328,16,13325,13340,4096,10400,14600,8612,256,8492,13324,8072]

theorem envBound55067 : H12AffineFastState.Bounded env55067 := by
  intro p hp
  have h : env55067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55066_55067 : H12AffineEnvironment.transform 5 17 env55066 = env55067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55066 == env55067) = true)

theorem identity55067 : scanCanonicalize (H12AffineFastState.compose env55067 (packedSelected [0,1,2,6,7,8,10,15,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 3220) := by decide +kernel

theorem selectedBound55067 : packedSelected [0,1,2,6,7,8,10,15,16,17] rootPS < 2^1333 := by decide +kernel

def env55068 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,3220,2185,4248,262,6145,6588,1024,4249,4113,33,7577,7562,3100,16,6297,6280,4096,1076,5532,3376,256,3512,6296,8072]

theorem envBound55068 : H12AffineFastState.Bounded env55068 := by
  intro p hp
  have h : env55068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55067_55068 : H12AffineEnvironment.transform 12 3220 env55067 = env55068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3220 env55067 == env55068) = true)

theorem identity55068 : scanCanonicalize (H12AffineFastState.compose env55068 (packedSelected [1,3,5,8,11,12,18] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound55068 : packedSelected [1,3,5,8,11,12,18] rootPS < 2^1333 := by decide +kernel

def env55069 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3245,3220,2185,3125,262,1196,1297,1024,3124,3260,33,308,295,3100,16,1076,1061,3245,1076,2353,3376,256,3512,1077,805]

theorem envBound55069 : H12AffineFastState.Bounded env55069 := by
  intro p hp
  have h : env55069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55068_55069 : H12AffineEnvironment.transform 11 3245 env55068 = env55069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env55068 == env55069) = true)

theorem identity55069 : scanCanonicalize (H12AffineFastState.compose env55069 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(10+1) ^^^ 428) := by decide +kernel

theorem selectedBound55069 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env55070 : List Nat := [2,4,8,16,32,17,128,256,512,1024,428,1281,1336,293,1433,262,1196,1297,1024,1432,1296,33,308,295,1456,16,1076,1061,1281,1076,157,1180,256,1044,1077,805]

theorem envBound55070 : H12AffineFastState.Bounded env55070 := by
  intro p hp
  have h : env55070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55069_55070 : H12AffineEnvironment.transform 10 428 env55069 = env55070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 428 env55069 == env55070) = true)

theorem identity55070 : scanCanonicalize (H12AffineFastState.compose env55070 (packedSelected [1,2,3,4,5,6,8,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55070 : packedSelected [1,2,3,4,5,6,8,9,11] rootPS < 2^1333 := by decide +kernel

def env55071 : List Nat := [2,4,8,16,32,17,128,256,512,52,428,309,268,293,429,262,152,293,52,428,292,33,308,295,388,16,0,17,309,0,157,168,256,32,1,805]

theorem envBound55071 : H12AffineFastState.Bounded env55071 := by
  intro p hp
  have h : env55071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55070_55071 : H12AffineEnvironment.transform 9 52 env55070 = env55071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55070 == env55071) = true)

theorem identity55071 : scanCanonicalize (H12AffineFastState.compose env55071 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55071 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env55072 : List Nat := [2,4,8,16,32,17,128,36,512,52,136,17,40,1,137,34,152,1,52,136,0,33,16,3,160,16,0,17,17,0,157,168,36,32,1,513]

theorem envBound55072 : H12AffineFastState.Bounded env55072 := by
  intro p hp
  have h : env55072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55071_55072 : H12AffineEnvironment.transform 7 36 env55071 = env55072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55071 == env55072) = true)

theorem identity55072 : scanCanonicalize (H12AffineFastState.compose env55072 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55072 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55073 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,17,40,1,1,34,16,1,52,0,0,33,16,3,40,16,0,17,17,0,21,32,36,32,1,513]

theorem envBound55073 : H12AffineFastState.Bounded env55073 := by
  intro p hp
  have h : env55073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55072_55073 : H12AffineEnvironment.transform 6 8 env55072 = env55073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55072 == env55073) = true)

theorem identity55073 : scanCanonicalize (H12AffineFastState.compose env55073 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound55073 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55074 : List Nat := [2,4,8,16,32,17,8,36,4,52,0,17,40,1,1,34,16,1,52,0,0,33,16,3,40,16,0,17,17,0,21,32,36,32,1,5]

theorem envBound55074 : H12AffineFastState.Bounded env55074 := by
  intro p hp
  have h : env55074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55073_55074 : H12AffineEnvironment.transform 8 4 env55073 = env55074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env55073 == env55074) = true)

theorem identity55074 : scanCanonicalize (H12AffineFastState.compose env55074 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound55074 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55075 : List Nat := [2,4,8,2,32,3,8,36,4,38,0,3,40,1,1,34,2,1,38,0,0,33,2,3,40,2,0,3,3,0,7,32,36,32,1,5]

theorem envBound55075 : H12AffineFastState.Bounded env55075 := by
  intro p hp
  have h : env55075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55074_55075 : H12AffineEnvironment.transform 3 2 env55074 = env55075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env55074 == env55075) = true)

theorem identity55075 : scanCanonicalize (H12AffineFastState.compose env55075 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55075 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55076 : List Nat := [0,4,8,0,32,1,8,36,4,36,0,1,40,1,1,32,0,1,36,0,0,33,0,1,40,0,0,1,1,0,5,32,36,32,1,5]

theorem envBound55076 : H12AffineFastState.Bounded env55076 := by
  intro p hp
  have h : env55076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55075_55076 : H12AffineEnvironment.transform 0 0 env55075 = env55076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55075 == env55076) = true)

theorem identity55076 : scanCanonicalize (H12AffineFastState.compose env55076 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound55076 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55077 : List Nat := [0,4,1,0,32,1,1,36,4,36,0,1,33,1,1,32,0,1,36,0,0,33,0,1,33,0,0,1,1,0,5,32,36,32,1,5]

theorem envBound55077 : H12AffineFastState.Bounded env55077 := by
  intro p hp
  have h : env55077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55076_55077 : H12AffineEnvironment.transform 2 1 env55076 = env55077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env55076 == env55077) = true)

theorem identity55077 : scanCanonicalize (H12AffineFastState.compose env55077 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55077 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55078 : List Nat := [0,4,1,0,0,1,1,4,4,4,0,1,1,1,1,0,0,1,4,0,0,1,0,1,1,0,0,1,1,0,5,0,4,0,1,5]

theorem envBound55078 : H12AffineFastState.Bounded env55078 := by
  intro p hp
  have h : env55078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55077_55078 : H12AffineEnvironment.transform 4 0 env55077 = env55078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55077 == env55078) = true)

def env55079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,8388608,21762,8328,65,12704870,115150,8406289,8423780,8507667,4268163,256,8487406,8478795,8451780]

theorem envBound55079 : H12AffineFastState.Bounded env55079 := by
  intro p hp
  have h : env55079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55028_55079 : H12AffineEnvironment.transform 20 4161 env55028 = env55079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55028 == env55079) = true)

def env55080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363552,21762,8328,65,215366,115150,4378673,4332612,4408371,4268163,256,4396238,4453739,4350948]

theorem envBound55080 : H12AffineFastState.Bounded env55080 := by
  intro p hp
  have h : env55080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55079_55080 : H12AffineEnvironment.transform 22 4363552 env55079 = env55080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363552 env55079 == env55080) = true)

theorem identity55080 : scanCanonicalize (H12AffineFastState.compose env55080 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound55080 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169264,16,21762,8328,65,215366,115150,17665,35188,119043,243123,256,98814,90203,63188]

theorem envBound55081 : H12AffineFastState.Bounded env55081 := by
  intro p hp
  have h : env55081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55080_55081 : H12AffineEnvironment.transform 21 169264 env55080 = env55081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env55080 == env55081) = true)

def env55082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169264,16,21762,8192,65,215366,115014,17665,35188,119043,243003,256,98678,90203,63068]

theorem envBound55082 : H12AffineFastState.Bounded env55082 := by
  intro p hp
  have h : env55082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55081_55082 : H12AffineEnvironment.transform 6 8 env55081 = env55082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55081 == env55082) = true)

theorem identity55082 : scanCanonicalize (H12AffineFastState.compose env55082 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 24909) := by decide +kernel

theorem selectedBound55082 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10280,1024,32769,4161,62589,16,21762,8192,65,75787,115014,17665,35188,119043,119926,256,98678,90203,63068]

theorem envBound55083 : H12AffineFastState.Bounded env55083 := by
  intro p hp
  have h : env55083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55082_55083 : H12AffineEnvironment.transform 16 24909 env55082 = env55083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24909 env55082 == env55083) = true)

theorem identity55083 : scanCanonicalize (H12AffineFastState.compose env55083 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound55083 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55084 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,24909,10280,1024,32769,4161,62589,16,21762,8192,65,64605,5392,17665,35188,1365,32,256,21792,46093,63068]

theorem envBound55084 : H12AffineFastState.Bounded env55084 := by
  intro p hp
  have h : env55084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55083_55084 : H12AffineEnvironment.transform 15 54358 env55083 = env55084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env55083 == env55084) = true)

theorem identity55084 : scanCanonicalize (H12AffineFastState.compose env55084 (packedSelected [16,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound55084 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55085 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,24909,10280,1024,29788,4161,32,16,21762,8192,65,2048,5392,17665,32041,1365,32,256,21792,16464,513]

theorem envBound55085 : H12AffineFastState.Bounded env55085 := by
  intro p hp
  have h : env55085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55084_55085 : H12AffineEnvironment.transform 14 29789 env55084 = env55085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env55084 == env55085) = true)

theorem identity55085 : scanCanonicalize (H12AffineFastState.compose env55085 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55085 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env55086 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,8203,24860,10280,1024,29709,4112,32,16,21762,8192,16,2048,5392,17665,32041,1284,32,256,21792,16385,513]

theorem envBound55086 : H12AffineFastState.Bounded env55086 := by
  intro p hp
  have h : env55086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55085_55086 : H12AffineEnvironment.transform 5 17 env55085 = env55086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55085 == env55086) = true)

theorem identity55086 : scanCanonicalize (H12AffineFastState.compose env55086 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55086 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55087 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,16384,21760,263,16400,2340,1024,21761,4112,32,16,21762,268,16,2048,5392,17665,23589,1284,32,256,21792,16385,513]

theorem envBound55087 : H12AffineFastState.Bounded env55087 := by
  intro p hp
  have h : env55087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55086_55087 : H12AffineEnvironment.transform 12 268 env55086 = env55087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55086 == env55087) = true)

theorem identity55087 : scanCanonicalize (H12AffineFastState.compose env55087 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55087 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55088 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,268,5377,1,263,5393,2340,1024,0,4112,32,16,3,268,16,2048,5392,4096,2340,1284,32,256,33,5376,513]

theorem envBound55088 : H12AffineFastState.Bounded env55088 := by
  intro p hp
  have h : env55088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55087_55088 : H12AffineEnvironment.transform 13 5377 env55087 = env55088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55087 == env55088) = true)

theorem identity55088 : scanCanonicalize (H12AffineFastState.compose env55088 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound55088 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55089 : List Nat := [2,4,8,16,32,17,8,256,512,21,2048,4096,268,4372,1,263,4356,2340,21,0,4112,32,16,3,268,16,2048,4357,4096,2340,273,32,256,33,4373,513]

theorem envBound55089 : H12AffineFastState.Bounded env55089 := by
  intro p hp
  have h : env55089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55088_55089 : H12AffineEnvironment.transform 9 21 env55088 = env55089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55088 == env55089) = true)

theorem identity55089 : scanCanonicalize (H12AffineFastState.compose env55089 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 814) := by decide +kernel

theorem selectedBound55089 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55090 : List Nat := [2,4,8,16,32,17,8,256,512,21,814,4096,268,4372,1,263,4356,522,21,0,4112,32,16,3,268,16,814,4357,4096,522,273,32,256,33,4373,513]

theorem envBound55090 : H12AffineFastState.Bounded env55090 := by
  intro p hp
  have h : env55090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55089_55090 : H12AffineEnvironment.transform 10 814 env55089 = env55090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 814 env55089 == env55090) = true)

theorem identity55090 : scanCanonicalize (H12AffineFastState.compose env55090 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound55090 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55091 : List Nat := [2,4,8,16,32,17,8,256,292,21,10,4096,268,4372,1,263,4356,302,21,0,4112,32,16,3,268,16,10,4357,4096,302,273,32,256,33,4373,293]

theorem envBound55091 : H12AffineFastState.Bounded env55091 := by
  intro p hp
  have h : env55091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55090_55091 : H12AffineEnvironment.transform 8 292 env55090 = env55091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env55090 == env55091) = true)

theorem identity55091 : scanCanonicalize (H12AffineFastState.compose env55091 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound55091 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55092 : List Nat := [2,4,8,16,32,17,8,256,292,21,10,292,268,48,1,263,32,302,21,0,308,32,16,3,268,16,10,33,292,302,273,32,256,33,49,293]

theorem envBound55092 : H12AffineFastState.Bounded env55092 := by
  intro p hp
  have h : env55092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55091_55092 : H12AffineEnvironment.transform 11 292 env55091 = env55092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env55091 == env55092) = true)

theorem identity55092 : scanCanonicalize (H12AffineFastState.compose env55092 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55092 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55093 : List Nat := [2,4,8,16,0,17,8,256,260,21,10,260,268,16,1,263,0,270,21,0,276,0,16,3,268,16,10,1,260,270,273,0,256,1,17,261]

theorem envBound55093 : H12AffineFastState.Bounded env55093 := by
  intro p hp
  have h : env55093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55092_55093 : H12AffineEnvironment.transform 4 0 env55092 = env55093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55092 == env55093) = true)

theorem identity55093 : scanCanonicalize (H12AffineFastState.compose env55093 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound55093 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env55094 : List Nat := [2,4,8,7,0,6,8,256,260,2,10,260,268,7,1,263,0,270,2,0,259,0,7,3,268,7,10,1,260,270,262,0,256,1,6,261]

theorem envBound55094 : H12AffineFastState.Bounded env55094 := by
  intro p hp
  have h : env55094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55093_55094 : H12AffineEnvironment.transform 3 7 env55093 = env55094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env55093 == env55094) = true)

def env55095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169264,16,21762,8193,65,215366,115015,17665,35188,119043,243002,256,98679,90203,63069]

theorem envBound55095 : H12AffineFastState.Bounded env55095 := by
  intro p hp
  have h : env55095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55081_55095 : H12AffineEnvironment.transform 6 9 env55081 = env55095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55081 == env55095) = true)

theorem identity55095 : scanCanonicalize (H12AffineFastState.compose env55095 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound55095 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55096 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,4161,21792,16,21762,8193,65,100694,115015,17665,35188,119043,95530,256,98679,90203,63069]

theorem envBound55096 : H12AffineFastState.Bounded env55096 := by
  intro p hp
  have h : env55096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55095_55096 : H12AffineEnvironment.transform 16 49168 env55095 = env55096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55095 == env55096) = true)

theorem identity55096 : scanCanonicalize (H12AffineFastState.compose env55096 (packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS)) = affineNative (2^(15+1) ^^^ 41343) := by decide +kernel

theorem selectedBound55096 : packedSelected [3,5,7,10,11,12,14,15,18,20,23,27,32] rootPS < 2^1333 := by decide +kernel

def env55097 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,41343,49168,35189,1024,32769,4161,21792,16,21762,8193,65,10281,24632,17665,35188,28796,54357,256,8200,49444,63069]

theorem envBound55097 : H12AffineFastState.Bounded env55097 := by
  intro p hp
  have h : env55097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55096_55097 : H12AffineEnvironment.transform 15 41343 env55096 = env55097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41343 env55096 == env55097) = true)

theorem identity55097 : scanCanonicalize (H12AffineFastState.compose env55097 (packedSelected [2,6,9,11,14,16,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 13609) := by decide +kernel

theorem selectedBound55097 : packedSelected [2,6,9,11,14,16,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env55098 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13609,32768,41343,46393,35189,1024,32769,4161,8201,16,8235,8193,65,10281,5393,12328,35188,1365,41340,256,8200,46093,33652]

theorem envBound55098 : H12AffineFastState.Bounded env55098 := by
  intro p hp
  have h : env55098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55097_55098 : H12AffineEnvironment.transform 13 13609 env55097 = env55098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13609 env55097 == env55098) = true)

theorem identity55098 : scanCanonicalize (H12AffineFastState.compose env55098 (packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55098 : packedSelected [0,3,5,6,7,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env55099 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13404,32768,40970,46156,34816,1024,32769,4161,8201,16,8235,8193,65,10281,5220,12328,34817,1056,40969,117,8200,46093,33281]

theorem envBound55099 : H12AffineFastState.Bounded env55099 := by
  intro p hp
  have h : env55099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55098_55099 : H12AffineEnvironment.transform 7 117 env55098 = env55099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55098 == env55099) = true)

theorem identity55099 : scanCanonicalize (H12AffineFastState.compose env55099 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55099 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env55100 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,32768,32803,37989,34816,1024,32769,4161,32,16,2,40,65,2048,5220,4097,34817,1056,32800,117,33,37924,33281]

theorem envBound55100 : H12AffineFastState.Bounded env55100 := by
  intro p hp
  have h : env55100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55099_55100 : H12AffineEnvironment.transform 12 41 env55099 = env55100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55099 == env55100) = true)

theorem identity55100 : scanCanonicalize (H12AffineFastState.compose env55100 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(14+1) ^^^ 2048) := by decide +kernel

theorem selectedBound55100 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env55101 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,2048,2083,7269,0,1024,2049,4161,32,16,2,40,65,2048,5220,4097,1,1056,2080,117,33,7204,2561]

theorem envBound55101 : H12AffineFastState.Bounded env55101 := by
  intro p hp
  have h : env55101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55100_55101 : H12AffineEnvironment.transform 14 2048 env55100 = env55101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2048 env55100 == env55101) = true)

theorem identity55101 : scanCanonicalize (H12AffineFastState.compose env55101 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1060) := by decide +kernel

theorem selectedBound55101 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env55102 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,1060,41,81,2048,2083,2113,0,1024,2049,1125,32,16,2,40,65,2048,64,1061,1,1056,2080,117,33,2048,2561]

theorem envBound55102 : H12AffineFastState.Bounded env55102 := by
  intro p hp
  have h : env55102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55101_55102 : H12AffineEnvironment.transform 11 1060 env55101 = env55102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1060 env55101 == env55102) = true)

theorem identity55102 : scanCanonicalize (H12AffineFastState.compose env55102 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound55102 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env55103 : List Nat := [2,4,8,16,32,64,9,117,512,1024,1,1060,41,81,1,34,64,0,1024,0,1125,32,16,2,40,65,1,64,1061,1,1056,33,117,33,1,512]

theorem envBound55103 : H12AffineFastState.Bounded env55103 := by
  intro p hp
  have h : env55103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55102_55103 : H12AffineEnvironment.transform 10 1 env55102 = env55103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env55102 == env55103) = true)

theorem identity55103 : scanCanonicalize (H12AffineFastState.compose env55103 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 590) := by decide +kernel

theorem selectedBound55103 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55104 : List Nat := [2,4,8,16,32,64,9,117,512,590,1,618,41,81,1,34,64,0,590,0,555,32,16,2,40,65,1,64,619,1,622,33,117,33,1,512]

theorem envBound55104 : H12AffineFastState.Bounded env55104 := by
  intro p hp
  have h : env55104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55103_55104 : H12AffineEnvironment.transform 9 590 env55103 = env55104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 590 env55103 == env55104) = true)

theorem identity55104 : scanCanonicalize (H12AffineFastState.compose env55104 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 119) := by decide +kernel

theorem selectedBound55104 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55105 : List Nat := [2,4,8,16,32,64,9,117,119,57,1,29,41,81,1,34,64,0,57,0,92,32,16,2,40,65,1,64,28,1,25,33,117,33,1,119]

theorem envBound55105 : H12AffineFastState.Bounded env55105 := by
  intro p hp
  have h : env55105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55104_55105 : H12AffineEnvironment.transform 8 119 env55104 = env55105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 119 env55104 == env55105) = true)

def env55106 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,4194304,4363553,21762,8328,65,215367,115150,4378672,4332613,4408370,4268163,256,4396239,4453738,4350949]

theorem envBound55106 : H12AffineFastState.Bounded env55106 := by
  intro p hp
  have h : env55106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55079_55106 : H12AffineEnvironment.transform 22 4363553 env55079 = env55106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 4363553 env55079 == env55106) = true)

def env55107 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169400,153,21762,8328,65,215367,115150,17800,35325,119178,243003,256,98679,90322,63069]

theorem envBound55107 : H12AffineFastState.Bounded env55107 := by
  intro p hp
  have h : env55107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55106_55107 : H12AffineEnvironment.transform 21 169400 env55106 = env55107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169400 env55106 == env55107) = true)

def env55108 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,4161,21928,153,21762,8328,65,100695,115150,17800,35325,119178,95531,256,98679,90322,63069]

theorem envBound55108 : H12AffineFastState.Bounded env55108 := by
  intro p hp
  have h : env55108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55107_55108 : H12AffineEnvironment.transform 16 49168 env55107 = env55108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55107 == env55108) = true)

def env55109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,136,65536,16536,2557,1024,137,4161,21928,153,21762,8328,65,68063,82246,17800,2421,86274,95531,256,66047,90322,30421]

theorem envBound55109 : H12AffineFastState.Bounded env55109 := by
  intro p hp
  have h : env55109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55108_55109 : H12AffineEnvironment.transform 14 136 env55108 = env55109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env55108 == env55109) = true)

theorem identity55109 : scanCanonicalize (H12AffineFastState.compose env55109 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(12+1) ^^^ 469) := by decide +kernel

theorem selectedBound55109 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env55110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,136,65536,16536,2557,1024,137,4161,21928,153,21762,349,65,68063,82246,17800,2421,86274,87294,256,66047,82183,22272]

theorem envBound55110 : H12AffineFastState.Bounded env55110 := by
  intro p hp
  have h : env55110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55109_55110 : H12AffineEnvironment.transform 12 469 env55109 = env55110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env55109 == env55110) = true)

theorem identity55110 : scanCanonicalize (H12AffineFastState.compose env55110 (packedSelected [1,8,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound55110 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env55111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,136,21590,16536,2557,1024,137,4161,21928,153,21762,349,65,23945,5392,17800,2421,1364,168,256,21929,5457,22272]

theorem envBound55111 : H12AffineFastState.Bounded env55111 := by
  intro p hp
  have h : env55111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55110_55111 : H12AffineEnvironment.transform 15 21590 env55110 = env55111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env55110 == env55111) = true)

theorem identity55111 : scanCanonicalize (H12AffineFastState.compose env55111 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55111 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env55112 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21590,16400,2421,1024,1,4161,21792,17,21762,349,65,23809,5392,17664,2421,1364,32,256,21793,5457,22272]

theorem envBound55112 : H12AffineFastState.Bounded env55112 := by
  intro p hp
  have h : env55112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55111_55112 : H12AffineEnvironment.transform 6 8 env55111 = env55112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55111 == env55112) = true)

theorem identity55112 : scanCanonicalize (H12AffineFastState.compose env55112 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55112 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,0,343,5393,2421,1024,1,4161,33,17,3,349,65,2048,5392,4097,2421,1364,32,256,32,5457,513]

theorem envBound55113 : H12AffineFastState.Bounded env55113 := by
  intro p hp
  have h : env55113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55112_55113 : H12AffineEnvironment.transform 13 5377 env55112 = env55113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55112 == env55113) = true)

theorem identity55113 : scanCanonicalize (H12AffineFastState.compose env55113 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 613) := by decide +kernel

theorem selectedBound55113 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55114 : List Nat := [2,4,8,16,32,64,8,256,512,613,2048,4096,349,4964,0,343,4980,2421,613,1,4161,33,17,3,349,65,2048,4981,4097,2421,817,32,256,32,4916,513]

theorem envBound55114 : H12AffineFastState.Bounded env55114 := by
  intro p hp
  have h : env55114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55113_55114 : H12AffineEnvironment.transform 9 613 env55113 = env55114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 613 env55113 == env55114) = true)

theorem identity55114 : scanCanonicalize (H12AffineFastState.compose env55114 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55114 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55115 : List Nat := [2,4,8,16,32,16,8,256,512,565,2048,4096,269,4916,0,263,4900,2341,565,1,4113,33,17,3,269,17,2048,4901,4097,2341,817,32,256,32,4916,513]

theorem envBound55115 : H12AffineFastState.Bounded env55115 := by
  intro p hp
  have h : env55115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55114_55115 : H12AffineEnvironment.transform 5 16 env55114 = env55115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55114 == env55115) = true)

theorem identity55115 : scanCanonicalize (H12AffineFastState.compose env55115 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound55115 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55116 : List Nat := [2,4,8,16,16,16,8,256,512,517,2048,4096,269,4868,0,263,4884,2325,517,1,4113,17,17,3,269,17,2048,4885,4097,2325,769,16,256,16,4868,513]

theorem envBound55116 : H12AffineFastState.Bounded env55116 := by
  intro p hp
  have h : env55116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55115_55116 : H12AffineEnvironment.transform 4 16 env55115 = env55116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env55115 == env55116) = true)

theorem identity55116 : scanCanonicalize (H12AffineFastState.compose env55116 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound55116 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55117 : List Nat := [2,4,8,16,16,16,8,256,277,272,2048,4096,269,4113,0,263,4097,2325,272,1,4113,17,17,3,269,17,2048,4096,4097,2325,20,16,256,16,4113,276]

theorem envBound55117 : H12AffineFastState.Bounded env55117 := by
  intro p hp
  have h : env55117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55116_55117 : H12AffineEnvironment.transform 8 277 env55116 = env55117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env55116 == env55117) = true)

theorem identity55117 : scanCanonicalize (H12AffineFastState.compose env55117 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 2048) := by decide +kernel

theorem selectedBound55117 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55118 : List Nat := [2,4,8,16,16,16,8,256,277,272,2048,2048,269,2065,0,263,2049,2325,272,1,2065,17,17,3,269,17,2048,2048,2049,2325,20,16,256,16,2065,276]

theorem envBound55118 : H12AffineFastState.Bounded env55118 := by
  intro p hp
  have h : env55118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55117_55118 : H12AffineEnvironment.transform 11 2048 env55117 = env55118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2048 env55117 == env55118) = true)

theorem identity55118 : scanCanonicalize (H12AffineFastState.compose env55118 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound55118 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55119 : List Nat := [2,4,8,16,16,16,8,256,277,272,277,277,269,260,0,263,276,0,272,1,260,17,17,3,269,17,277,277,276,0,20,16,256,16,260,276]

theorem envBound55119 : H12AffineFastState.Bounded env55119 := by
  intro p hp
  have h : env55119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55118_55119 : H12AffineEnvironment.transform 10 277 env55118 = env55119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env55118 == env55119) = true)

def env55120 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,137,65536,16537,2556,1024,136,4161,21928,153,21762,8328,65,68062,82247,17800,2420,86275,95531,256,66046,90322,30420]

theorem envBound55120 : H12AffineFastState.Bounded env55120 := by
  intro p hp
  have h : env55120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55108_55120 : H12AffineEnvironment.transform 14 137 env55108 = env55120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env55108 == env55120) = true)

theorem identity55120 : scanCanonicalize (H12AffineFastState.compose env55120 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound55120 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55121 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,137,65536,13388,2556,1024,136,4161,8573,153,8663,8328,65,68062,79250,12637,2420,75222,66046,256,66046,70663,513]

theorem envBound55121 : H12AffineFastState.Bounded env55121 := by
  intro p hp
  have h : env55121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55120_55121 : H12AffineEnvironment.transform 13 13525 env55120 = env55121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env55120 == env55121) = true)

theorem identity55121 : scanCanonicalize (H12AffineFastState.compose env55121 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound55121 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env55122 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,137,8323,13388,2556,1024,136,4161,8573,153,8663,8328,65,10589,5393,12637,2420,1365,8573,256,8573,13444,513]

theorem envBound55122 : H12AffineFastState.Bounded env55122 := by
  intro p hp
  have h : env55122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55121_55122 : H12AffineEnvironment.transform 15 8323 env55121 = env55122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env55121 == env55122) = true)

theorem identity55122 : scanCanonicalize (H12AffineFastState.compose env55122 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound55122 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55123 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,137,343,5528,2556,1024,136,4161,169,153,3,348,65,2185,5393,4233,2420,1365,169,256,169,5456,513]

theorem envBound55123 : H12AffineFastState.Bounded env55123 := by
  intro p hp
  have h : env55123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55122_55123 : H12AffineEnvironment.transform 12 468 env55122 = env55123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env55122 == env55123) = true)

theorem identity55123 : scanCanonicalize (H12AffineFastState.compose env55123 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55123 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,0,343,5393,2421,1024,1,4161,32,16,3,348,65,2048,5393,4096,2420,1365,32,256,32,5456,513]

theorem envBound55124 : H12AffineFastState.Bounded env55124 := by
  intro p hp
  have h : env55124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55123_55124 : H12AffineEnvironment.transform 6 9 env55123 = env55124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55123 == env55124) = true)

theorem identity55124 : scanCanonicalize (H12AffineFastState.compose env55124 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound55124 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env55125 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,349,373,0,343,357,2421,1024,1,1077,32,16,3,348,65,2048,357,1140,2420,1365,32,256,32,292,513]

theorem envBound55125 : H12AffineFastState.Bounded env55125 := by
  intro p hp
  have h : env55125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55124_55125 : H12AffineEnvironment.transform 11 1140 env55124 = env55125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env55124 == env55125) = true)

theorem identity55125 : scanCanonicalize (H12AffineFastState.compose env55125 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound55125 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55126 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,1140,349,373,0,343,357,0,1024,1,1077,32,16,3,348,65,373,357,1140,1,1365,32,256,32,292,513]

theorem envBound55126 : H12AffineFastState.Bounded env55126 := by
  intro p hp
  have h : env55126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55125_55126 : H12AffineEnvironment.transform 10 373 env55125 = env55126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env55125 == env55126) = true)

theorem identity55126 : scanCanonicalize (H12AffineFastState.compose env55126 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound55126 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55127 : List Nat := [2,4,8,16,32,64,9,256,17,1024,373,1140,349,373,0,343,357,0,1024,1,1077,32,16,3,348,65,373,357,1140,1,1365,32,256,32,292,16]

theorem envBound55127 : H12AffineFastState.Bounded env55127 := by
  intro p hp
  have h : env55127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55126_55127 : H12AffineEnvironment.transform 8 17 env55126 = env55127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env55126 == env55127) = true)

theorem identity55127 : scanCanonicalize (H12AffineFastState.compose env55127 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 53) := by decide +kernel

theorem selectedBound55127 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55128 : List Nat := [2,4,8,16,32,64,9,53,17,1024,64,1140,104,64,0,98,80,0,1024,1,1077,32,16,3,105,65,64,80,1140,1,1120,32,53,32,17,16]

theorem envBound55128 : H12AffineFastState.Bounded env55128 := by
  intro p hp
  have h : env55128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55127_55128 : H12AffineEnvironment.transform 7 53 env55127 = env55128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 53 env55127 == env55128) = true)

theorem identity55128 : scanCanonicalize (H12AffineFastState.compose env55128 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound55128 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env55129 : List Nat := [2,4,8,16,32,32,9,53,17,1024,32,1044,8,32,0,2,48,0,1024,1,1077,32,16,3,9,33,32,48,1044,1,1024,32,53,32,17,16]

theorem envBound55129 : H12AffineFastState.Bounded env55129 := by
  intro p hp
  have h : env55129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55128_55129 : H12AffineEnvironment.transform 5 32 env55128 = env55129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env55128 == env55129) = true)

theorem identity55129 : scanCanonicalize (H12AffineFastState.compose env55129 (packedSelected [2,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55129 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env55130 : List Nat := [2,4,8,16,0,0,9,21,17,1024,0,1044,8,0,0,2,16,0,1024,1,1045,0,16,3,9,1,0,16,1044,1,1024,0,21,0,17,16]

theorem envBound55130 : H12AffineFastState.Bounded env55130 := by
  intro p hp
  have h : env55130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55129_55130 : H12AffineEnvironment.transform 4 0 env55129 = env55130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55129 == env55130) = true)

theorem identity55130 : scanCanonicalize (H12AffineFastState.compose env55130 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55130 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55131 : List Nat := [2,4,8,16,0,0,9,21,17,5,0,17,8,0,0,2,16,0,5,1,16,0,16,3,9,1,0,16,17,1,5,0,21,0,17,16]

theorem envBound55131 : H12AffineFastState.Bounded env55131 := by
  intro p hp
  have h : env55131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55130_55131 : H12AffineEnvironment.transform 9 5 env55130 = env55131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55130 == env55131) = true)

theorem identity55131 : scanCanonicalize (H12AffineFastState.compose env55131 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55131 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55132 : List Nat := [2,4,3,16,0,0,2,21,17,5,0,17,3,0,0,2,16,0,5,1,16,0,16,3,2,1,0,16,17,1,5,0,21,0,17,16]

theorem envBound55132 : H12AffineFastState.Bounded env55132 := by
  intro p hp
  have h : env55132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55131_55132 : H12AffineEnvironment.transform 2 3 env55131 = env55132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55131 == env55132) = true)

theorem identity55132 : scanCanonicalize (H12AffineFastState.compose env55132 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55132 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55133 : List Nat := [2,4,3,0,0,0,2,5,1,5,0,1,3,0,0,2,0,0,5,1,0,0,0,3,2,1,0,0,1,1,5,0,5,0,1,0]

theorem envBound55133 : H12AffineFastState.Bounded env55133 := by
  intro p hp
  have h : env55133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55132_55133 : H12AffineEnvironment.transform 3 0 env55132 = env55133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55132 == env55133) = true)

def env55134 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,4161,21929,153,21762,8328,65,100694,115150,17800,35325,119178,95530,256,98679,90322,63069]

theorem envBound55134 : H12AffineFastState.Bounded env55134 := by
  intro p hp
  have h : env55134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55107_55134 : H12AffineEnvironment.transform 16 49169 env55107 = env55134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55107 == env55134) = true)

theorem identity55134 : scanCanonicalize (H12AffineFastState.compose env55134 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55134 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,4161,21793,17,21762,8192,65,100694,115014,17664,35189,119042,95530,256,98679,90202,63069]

theorem envBound55135 : H12AffineFastState.Bounded env55135 := by
  intro p hp
  have h : env55135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55134_55135 : H12AffineEnvironment.transform 6 8 env55134 = env55135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55134 == env55135) = true)

theorem identity55135 : scanCanonicalize (H12AffineFastState.compose env55135 (packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound55135 : packedSelected [1,3,4,7,9,10,16,18,20,23,24,27,28,31] rootPS < 2^1333 := by decide +kernel

def env55136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,65536,24861,10360,1024,8461,4161,21793,17,21762,8192,65,75866,90186,17664,10361,94222,95530,256,73851,90202,22353]

theorem envBound55136 : H12AffineFastState.Bounded env55136 := by
  intro p hp
  have h : env55136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55135_55136 : H12AffineEnvironment.transform 14 8460 env55135 = env55136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env55135 == env55136) = true)

theorem identity55136 : scanCanonicalize (H12AffineFastState.compose env55136 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound55136 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env55137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,29962,24861,10360,1024,8461,4161,21793,17,21762,8192,65,23888,5440,17664,10361,1284,32,256,21873,5456,22353]

theorem envBound55137 : H12AffineFastState.Bounded env55137 := by
  intro p hp
  have h : env55137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55136_55137 : H12AffineEnvironment.transform 15 29962 env55136 = env55137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env55136 == env55137) = true)

theorem identity55137 : scanCanonicalize (H12AffineFastState.compose env55137 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound55137 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env55138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8460,342,5441,10360,1024,8461,4161,8573,17,8542,8192,65,10508,5440,12636,10361,1284,32,256,8493,5456,8973]

theorem envBound55138 : H12AffineFastState.Bounded env55138 := by
  intro p hp
  have h : env55138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55137_55138 : H12AffineEnvironment.transform 13 13404 env55137 = env55138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env55137 == env55138) = true)

theorem identity55138 : scanCanonicalize (H12AffineFastState.compose env55138 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55138 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5377,81,342,5441,2341,1024,80,4161,32,17,3,349,65,2129,5440,4097,2340,1284,32,256,112,5456,592]

theorem envBound55139 : H12AffineFastState.Bounded env55139 := by
  intro p hp
  have h : env55139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55138_55139 : H12AffineEnvironment.transform 12 349 env55138 = env55139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55138 == env55139) = true)

theorem identity55139 : scanCanonicalize (H12AffineFastState.compose env55139 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55139 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55140 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5237,81,34,5173,2129,1024,80,4161,32,17,3,41,65,2129,5172,4097,2128,1136,32,116,112,5156,592]

theorem envBound55140 : H12AffineFastState.Bounded env55140 := by
  intro p hp
  have h : env55140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55139_55140 : H12AffineEnvironment.transform 7 116 env55139 = env55140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55139 == env55140) = true)

theorem identity55140 : scanCanonicalize (H12AffineFastState.compose env55140 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55140 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55141 : List Nat := [2,4,8,16,32,64,8,116,512,52,2048,4096,41,4161,81,34,4097,2129,52,80,4161,32,17,3,41,65,2129,4096,4097,2128,68,32,116,112,4112,592]

theorem envBound55141 : H12AffineFastState.Bounded env55141 := by
  intro p hp
  have h : env55141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55140_55141 : H12AffineEnvironment.transform 9 52 env55140 = env55141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55140 == env55141) = true)

theorem identity55141 : scanCanonicalize (H12AffineFastState.compose env55141 (packedSelected [0,1,5,6] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound55141 : packedSelected [0,1,5,6] rootPS < 2^1333 := by decide +kernel

def env55142 : List Nat := [2,4,8,16,32,32,8,20,512,52,2048,4096,41,4129,49,34,4097,2097,52,48,4129,32,17,3,41,33,2097,4096,4097,2096,36,32,20,16,4112,560]

theorem envBound55142 : H12AffineFastState.Bounded env55142 := by
  intro p hp
  have h : env55142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55141_55142 : H12AffineEnvironment.transform 5 32 env55141 = env55142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env55141 == env55142) = true)

theorem identity55142 : scanCanonicalize (H12AffineFastState.compose env55142 (packedSelected [0,1,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2080) := by decide +kernel

theorem selectedBound55142 : packedSelected [0,1,5,7] rootPS < 2^1333 := by decide +kernel

def env55143 : List Nat := [2,4,8,16,32,32,8,20,512,52,2048,2080,41,2049,49,34,2081,2097,52,48,2049,32,17,3,41,33,2097,2080,2081,2096,36,32,20,16,2096,560]

theorem envBound55143 : H12AffineFastState.Bounded env55143 := by
  intro p hp
  have h : env55143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55142_55143 : H12AffineEnvironment.transform 11 2080 env55142 = env55143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2080 env55142 == env55143) = true)

theorem identity55143 : scanCanonicalize (H12AffineFastState.compose env55143 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound55143 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env55144 : List Nat := [2,4,8,16,16,16,8,20,512,4,2048,2064,25,2049,1,18,2065,2049,4,0,2049,16,17,3,25,17,2049,2064,2065,2048,20,16,20,16,2048,512]

theorem envBound55144 : H12AffineFastState.Bounded env55144 := by
  intro p hp
  have h : env55144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55143_55144 : H12AffineEnvironment.transform 4 16 env55143 = env55144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env55143 == env55144) = true)

theorem identity55144 : scanCanonicalize (H12AffineFastState.compose env55144 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55144 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55145 : List Nat := [2,4,8,0,0,0,8,4,512,4,2048,2048,9,2049,1,2,2049,2049,4,0,2049,0,1,3,9,1,2049,2048,2049,2048,4,0,4,0,2048,512]

theorem envBound55145 : H12AffineFastState.Bounded env55145 := by
  intro p hp
  have h : env55145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55144_55145 : H12AffineEnvironment.transform 3 0 env55144 = env55145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55144 == env55145) = true)

theorem identity55145 : scanCanonicalize (H12AffineFastState.compose env55145 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound55145 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55146 : List Nat := [2,4,8,0,0,0,8,4,4,4,2048,2048,9,2049,1,2,2049,2049,4,0,2049,0,1,3,9,1,2049,2048,2049,2048,4,0,4,0,2048,4]

theorem envBound55146 : H12AffineFastState.Bounded env55146 := by
  intro p hp
  have h : env55146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55145_55146 : H12AffineEnvironment.transform 8 4 env55145 = env55146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env55145 == env55146) = true)

theorem identity55146 : scanCanonicalize (H12AffineFastState.compose env55146 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound55146 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env55147 : List Nat := [2,4,8,0,0,0,8,4,4,4,5,5,9,4,1,2,4,4,4,0,4,0,1,3,9,1,4,5,4,5,4,0,4,0,5,4]

theorem envBound55147 : H12AffineFastState.Bounded env55147 := by
  intro p hp
  have h : env55147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55146_55147 : H12AffineEnvironment.transform 10 5 env55146 = env55147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env55146 == env55147) = true)

theorem identity55147 : scanCanonicalize (H12AffineFastState.compose env55147 (packedSelected [11] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound55147 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env55148 : List Nat := [2,0,8,0,0,0,8,0,0,0,1,1,9,0,1,2,0,0,0,0,0,0,1,3,9,1,0,1,0,1,0,0,0,0,1,0]

theorem envBound55148 : H12AffineFastState.Bounded env55148 := by
  intro p hp
  have h : env55148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55147_55148 : H12AffineEnvironment.transform 1 0 env55147 = env55148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env55147 == env55148) = true)

def env55149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4161,169401,152,21762,8328,65,215367,115150,17801,35324,119179,243002,256,98678,90323,63068]

theorem envBound55149 : H12AffineFastState.Bounded env55149 := by
  intro p hp
  have h : env55149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55106_55149 : H12AffineEnvironment.transform 21 169401 env55106 = env55149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169401 env55106 == env55149) = true)

def env55150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,35189,1024,32769,4161,21929,152,21762,8328,65,100695,115150,17801,35324,119179,95530,256,98678,90323,63068]

theorem envBound55150 : H12AffineFastState.Bounded env55150 := by
  intro p hp
  have h : env55150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55149_55150 : H12AffineEnvironment.transform 16 49168 env55149 = env55150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env55149 == env55150) = true)

theorem identity55150 : scanCanonicalize (H12AffineFastState.compose env55150 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound55150 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,10400,1024,8660,4161,21929,152,21762,8328,65,75906,90139,17801,10281,94302,95530,256,73891,90323,22409]

theorem envBound55151 : H12AffineFastState.Bounded env55151 := by
  intro p hp
  have h : env55151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55150_55151 : H12AffineEnvironment.transform 14 8661 env55150 = env55151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env55150 == env55151) = true)

theorem identity55151 : scanCanonicalize (H12AffineFastState.compose env55151 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30082) := by decide +kernel

theorem selectedBound55151 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,30082,25029,10400,1024,8660,4161,21929,152,21762,8328,65,23808,5529,17801,10281,1500,168,256,21793,5457,22409]

theorem envBound55152 : H12AffineFastState.Bounded env55152 := by
  intro p hp
  have h : env55152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55151_55152 : H12AffineEnvironment.transform 15 30082 env55151 = env55152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30082 env55151 == env55152) = true)

theorem identity55152 : scanCanonicalize (H12AffineFastState.compose env55152 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound55152 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,8661,8202,13389,10400,1024,8660,4161,33,152,138,8328,65,2184,5529,4097,10281,1500,168,256,169,5457,513]

theorem envBound55153 : H12AffineFastState.Bounded env55153 := by
  intro p hp
  have h : env55153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55152_55153 : H12AffineEnvironment.transform 13 5512 env55152 = env55153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env55152 == env55153) = true)

theorem identity55153 : scanCanonicalize (H12AffineFastState.compose env55153 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound55153 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env55154 : List Nat := [2,4,8,16,32,64,121,256,512,1024,2048,4096,8192,5489,8492,8202,13389,10329,1024,8493,4161,33,97,115,8305,65,2161,5472,4097,10281,1317,81,256,80,5457,513]

theorem envBound55154 : H12AffineFastState.Bounded env55154 := by
  intro p hp
  have h : env55154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55153_55154 : H12AffineEnvironment.transform 6 121 env55153 = env55154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env55153 == env55154) = true)

theorem identity55154 : scanCanonicalize (H12AffineFastState.compose env55154 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound55154 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env55155 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,8192,5377,8492,8202,13373,10281,1024,8493,4145,33,17,3,8193,49,2049,5392,4097,10281,1317,33,256,32,5409,513]

theorem envBound55155 : H12AffineFastState.Bounded env55155 := by
  intro p hp
  have h : env55155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55154_55155 : H12AffineEnvironment.transform 5 48 env55154 = env55155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env55154 == env55155) = true)

theorem identity55155 : scanCanonicalize (H12AffineFastState.compose env55155 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55155 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55156 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,4096,269,5377,33,263,5424,2340,1024,32,4145,33,17,3,268,49,2049,5392,4097,2340,1317,33,256,32,5409,513]

theorem envBound55156 : H12AffineFastState.Bounded env55156 := by
  intro p hp
  have h : env55156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55155_55156 : H12AffineEnvironment.transform 12 269 env55155 = env55156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55155 == env55156) = true)

theorem identity55156 : scanCanonicalize (H12AffineFastState.compose env55156 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound55156 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55157 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,513,269,1792,33,263,1841,2340,1024,32,560,33,17,3,268,49,2049,1809,512,2340,1317,33,256,32,1824,513]

theorem envBound55157 : H12AffineFastState.Bounded env55157 := by
  intro p hp
  have h : env55157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55156_55157 : H12AffineEnvironment.transform 11 513 env55156 = env55157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env55156 == env55157) = true)

theorem identity55157 : scanCanonicalize (H12AffineFastState.compose env55157 (packedSelected [1,8] rootPS)) = affineNative (2^(10+1) ^^^ 1841) := by decide +kernel

theorem selectedBound55157 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env55158 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1841,513,269,1792,33,263,1841,1557,1024,32,560,33,17,3,268,49,1840,1809,512,1557,1317,33,256,32,1824,513]

theorem envBound55158 : H12AffineFastState.Bounded env55158 := by
  intro p hp
  have h : env55158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55157_55158 : H12AffineEnvironment.transform 10 1841 env55157 = env55158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1841 env55157 == env55158) = true)

theorem identity55158 : scanCanonicalize (H12AffineFastState.compose env55158 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound55158 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55159 : List Nat := [2,4,8,16,32,48,9,4,512,1024,1589,513,9,1540,33,3,1589,1557,1024,32,560,33,17,3,8,49,1588,1557,512,1557,1057,33,4,32,1572,513]

theorem envBound55159 : H12AffineFastState.Bounded env55159 := by
  intro p hp
  have h : env55159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55158_55159 : H12AffineEnvironment.transform 7 4 env55158 = env55159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env55158 == env55159) = true)

theorem identity55159 : scanCanonicalize (H12AffineFastState.compose env55159 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound55159 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55160 : List Nat := [2,4,8,16,32,48,9,4,512,5,560,513,9,513,33,3,560,528,5,32,560,33,17,3,8,49,561,528,512,528,36,33,4,32,545,513]

theorem envBound55160 : H12AffineFastState.Bounded env55160 := by
  intro p hp
  have h : env55160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55159_55160 : H12AffineEnvironment.transform 9 5 env55159 = env55160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env55159 == env55160) = true)

theorem identity55160 : scanCanonicalize (H12AffineFastState.compose env55160 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound55160 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env55161 : List Nat := [2,4,8,16,17,1,9,4,512,5,513,513,9,513,16,3,513,528,5,17,513,16,17,3,8,0,512,528,512,528,21,16,4,17,528,513]

theorem envBound55161 : H12AffineFastState.Bounded env55161 := by
  intro p hp
  have h : env55161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55160_55161 : H12AffineEnvironment.transform 4 17 env55160 = env55161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env55160 == env55161) = true)

theorem identity55161 : scanCanonicalize (H12AffineFastState.compose env55161 (packedSelected [0,2,7] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55161 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55162 : List Nat := [2,4,8,0,1,1,9,4,512,5,513,513,9,513,0,3,513,512,5,1,513,0,1,3,8,0,512,512,512,512,5,0,4,1,512,513]

theorem envBound55162 : H12AffineFastState.Bounded env55162 := by
  intro p hp
  have h : env55162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55161_55162 : H12AffineEnvironment.transform 3 0 env55161 = env55162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55161 == env55162) = true)

theorem identity55162 : scanCanonicalize (H12AffineFastState.compose env55162 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound55162 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55163 : List Nat := [2,4,8,0,1,1,9,4,0,5,1,1,9,1,0,3,1,0,5,1,1,0,1,3,8,0,0,0,0,0,5,0,4,1,0,1]

theorem envBound55163 : H12AffineFastState.Bounded env55163 := by
  intro p hp
  have h : env55163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55162_55163 : H12AffineEnvironment.transform 8 0 env55162 = env55163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env55162 == env55163) = true)

theorem identity55163 : scanCanonicalize (H12AffineFastState.compose env55163 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound55163 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55164 : List Nat := [2,4,3,0,1,1,2,4,0,5,1,1,2,1,0,3,1,0,5,1,1,0,1,3,3,0,0,0,0,0,5,0,4,1,0,1]

theorem envBound55164 : H12AffineFastState.Bounded env55164 := by
  intro p hp
  have h : env55164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55163_55164 : H12AffineEnvironment.transform 2 3 env55163 = env55164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env55163 == env55164) = true)

def env55165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,35188,1024,32769,4161,21928,152,21762,8328,65,100694,115150,17801,35324,119179,95531,256,98678,90323,63068]

theorem envBound55165 : H12AffineFastState.Bounded env55165 := by
  intro p hp
  have h : env55165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55149_55165 : H12AffineEnvironment.transform 16 49169 env55149 = env55165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env55149 == env55165) = true)

theorem identity55165 : scanCanonicalize (H12AffineFastState.compose env55165 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55165 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24909,10280,1024,8541,4161,21928,152,21762,8328,65,75786,90258,17801,10400,94423,95531,256,73770,90323,22272]

theorem envBound55166 : H12AffineFastState.Bounded env55166 := by
  intro p hp
  have h : env55166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55165_55166 : H12AffineEnvironment.transform 14 8540 env55165 = env55166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55165 == env55166) = true)

theorem identity55166 : scanCanonicalize (H12AffineFastState.compose env55166 (packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound55166 : packedSelected [0,1,2,5,6,7,8,11,20,23,24] rootPS < 2^1333 := by decide +kernel

def env55167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,21726,24909,10280,1024,8541,4161,21928,152,21762,8328,65,31956,13388,17801,10400,9225,8693,256,29940,13325,22272]

theorem envBound55167 : H12AffineFastState.Bounded env55167 := by
  intro p hp
  have h : env55167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55166_55167 : H12AffineEnvironment.transform 15 21726 env55166 = env55167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env55166 == env55167) = true)

theorem identity55167 : scanCanonicalize (H12AffineFastState.compose env55167 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound55167 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,0,21726,16401,2420,1024,1,4161,21928,152,21762,468,65,23944,5392,17801,2556,1365,169,256,21928,5457,22272]

theorem envBound55168 : H12AffineFastState.Bounded env55168 := by
  intro p hp
  have h : env55168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55167_55168 : H12AffineEnvironment.transform 12 348 env55167 = env55168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env55167 == env55168) = true)

theorem identity55168 : scanCanonicalize (H12AffineFastState.compose env55168 (packedSelected [3,5,10,18,23] rootPS)) = affineNative (2^(13+1) ^^^ 5592) := by decide +kernel

theorem selectedBound55168 : packedSelected [3,5,10,18,23] rootPS < 2^1333 := by decide +kernel

def env55169 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5592,0,262,5577,2420,1024,1,4161,112,152,218,468,65,2128,5392,4177,2556,1365,169,256,112,5457,728]

theorem envBound55169 : H12AffineFastState.Bounded env55169 := by
  intro p hp
  have h : env55169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55168_55169 : H12AffineEnvironment.transform 13 5592 env55168 = env55169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5592 env55168 == env55169) = true)

def env55170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265169,23160256,257,27378860,27337992,25207751]

theorem envBound55170 : H12AffineFastState.Bounded env55170 := by
  intro p hp
  have h : env55170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans54908_55170 : H12AffineEnvironment.transform 18 1025 env54908 = env55170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env54908 == env55170) = true)

theorem identity55170 : scanCanonicalize (H12AffineFastState.compose env55170 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2485414) := by decide +kernel

theorem selectedBound55170 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2485414,16777216,8328,65,23211174,18973836,375286,2305190,19163319,23160256,257,17049610,17090990,19222369]

theorem envBound55171 : H12AffineFastState.Bounded env55171 := by
  intro p hp
  have h : env55171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55170_55171 : H12AffineEnvironment.transform 22 2485414 env55170 = env55171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2485414 env55170 == env55171) = true)

def env55172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485414,16777216,8328,65,16959642,18973836,375286,2305190,19163319,16876028,257,17049610,17090990,19222369]

theorem envBound55172 : H12AffineFastState.Bounded env55172 := by
  intro p hp
  have h : env55172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55171_55172 : H12AffineEnvironment.transform 21 2155580 env55171 = env55172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155580 env55171 == env55172) = true)

def env55173 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485294,16777216,8192,65,16959506,18973700,375166,2305070,19163199,16875892,257,17049610,17090854,19222369]

theorem envBound55173 : H12AffineFastState.Bounded env55173 := by
  intro p hp
  have h : env55173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55172_55173 : H12AffineEnvironment.transform 6 8 env55172 = env55173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55172 == env55173) = true)

theorem identity55173 : scanCanonicalize (H12AffineFastState.compose env55173 (packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound55173 : packedSelected [4,5,7,8,9,12,14,15,16,17,20,24,26,27,28,31,35,38,41] rootPS < 2^1333 := by decide +kernel

def env55174 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,388158,329730,16,16777216,8192,65,16959506,17066042,375166,442384,16876545,16875892,257,17049610,17090854,16819039]

theorem envBound55174 : H12AffineFastState.Bounded env55174 := by
  intro p hp
  have h : env55174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55173_55174 : H12AffineEnvironment.transform 20 388158 env55173 = env55174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env55173 == env55174) = true)

theorem identity55174 : scanCanonicalize (H12AffineFastState.compose env55174 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound55174 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env55175 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,91466,98678,16,16777216,8192,65,16959506,16834894,77834,149860,16876545,16875892,257,16818558,16793682,16819039]

theorem envBound55175 : H12AffineFastState.Bounded env55175 := by
  intro p hp
  have h : env55175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55174_55175 : H12AffineEnvironment.transform 17 35188 env55174 = env55175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env55174 == env55175) = true)

theorem identity55175 : scanCanonicalize (H12AffineFastState.compose env55175 (packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 246084) := by decide +kernel

theorem selectedBound55175 : packedSelected [0,1,3,4,7,10,16,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env55176 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,91466,98678,16,246084,8192,65,67926,204810,77834,149860,148805,147504,257,221242,229654,221723]

theorem envBound55176 : H12AffineFastState.Bounded env55176 := by
  intro p hp
  have h : env55176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55175_55176 : H12AffineEnvironment.transform 23 246084 env55175 = env55176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 246084 env55175 == env55176) = true)

theorem identity55176 : scanCanonicalize (H12AffineFastState.compose env55176 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound55176 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env55177 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1025,32769,91466,98678,16,73736,8192,65,67926,115014,77834,43048,41993,41340,257,98678,90202,99159]

theorem envBound55177 : H12AffineFastState.Bounded env55177 := by
  intro p hp
  have h : env55177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55176_55177 : H12AffineEnvironment.transform 16 57676 env55176 = env55177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env55176 == env55177) = true)

theorem identity55177 : scanCanonicalize (H12AffineFastState.compose env55177 (packedSelected [6,7,9,14,17,20,22,27] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound55177 : packedSelected [6,7,9,14,17,20,22,27] rootPS < 2^1333 := by decide +kernel

def env55178 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,65536,46393,35188,1025,32769,78143,98678,16,73736,8192,65,67926,103731,77834,43048,41993,41340,257,98678,78895,99159]

theorem envBound55178 : H12AffineFastState.Bounded env55178 := by
  intro p hp
  have h : env55178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55177_55178 : H12AffineEnvironment.transform 13 5237 env55177 = env55178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env55177 == env55178) = true)

theorem identity55178 : scanCanonicalize (H12AffineFastState.compose env55178 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound55178 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env55179 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,32768,33110,46393,35188,1025,32769,45161,32,16,41310,8192,65,34816,5221,45404,43048,41993,41340,257,32,46457,513]

theorem envBound55179 : H12AffineFastState.Bounded env55179 := by
  intro p hp
  have h : env55179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55178_55179 : H12AffineEnvironment.transform 15 33110 env55178 = env55179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env55178 == env55179) = true)

theorem identity55179 : scanCanonicalize (H12AffineFastState.compose env55179 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound55179 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55180 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,80,262,13673,2340,1025,81,12345,32,16,8462,8192,65,2128,5221,12556,10360,9305,8492,257,32,13609,513]

theorem envBound55180 : H12AffineFastState.Bounded env55180 := by
  intro p hp
  have h : env55180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55179_55180 : H12AffineEnvironment.transform 14 80 env55179 = env55180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env55179 == env55180) = true)

theorem identity55180 : scanCanonicalize (H12AffineFastState.compose env55180 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55180 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55181 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5237,80,262,5220,2340,1025,81,4404,32,16,3,269,65,2128,5221,4097,2421,1364,33,257,32,5156,513]

theorem envBound55181 : H12AffineFastState.Bounded env55181 := by
  intro p hp
  have h : env55181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55180_55181 : H12AffineEnvironment.transform 12 269 env55180 = env55181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55180 == env55181) = true)

theorem identity55181 : scanCanonicalize (H12AffineFastState.compose env55181 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound55181 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55182 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,269,4405,80,262,4388,2340,321,81,4404,32,16,3,269,65,2128,4389,4097,2421,20,33,257,32,4452,513]

theorem envBound55182 : H12AffineFastState.Bounded env55182 := by
  intro p hp
  have h : env55182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55181_55182 : H12AffineEnvironment.transform 9 320 env55181 = env55182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env55181 == env55182) = true)

theorem identity55182 : scanCanonicalize (H12AffineFastState.compose env55182 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound55182 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55183 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,65,269,372,80,262,357,2340,321,81,373,32,16,3,269,65,2128,356,64,2421,20,33,257,32,293,513]

theorem envBound55183 : H12AffineFastState.Bounded env55183 := by
  intro p hp
  have h : env55183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55182_55183 : H12AffineEnvironment.transform 11 65 env55182 = env55183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env55182 == env55183) = true)

theorem identity55183 : scanCanonicalize (H12AffineFastState.compose env55183 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound55183 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env55184 : List Nat := [2,4,8,16,32,64,8,256,512,320,0,65,269,372,80,262,357,292,321,81,373,32,16,3,269,65,80,356,64,373,20,33,257,32,293,513]

theorem envBound55184 : H12AffineFastState.Bounded env55184 := by
  intro p hp
  have h : env55184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55183_55184 : H12AffineEnvironment.transform 10 0 env55183 = env55184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env55183 == env55184) = true)

theorem identity55184 : scanCanonicalize (H12AffineFastState.compose env55184 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound55184 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env55185 : List Nat := [2,4,8,16,32,64,8,117,512,53,0,65,120,1,80,115,16,81,52,81,0,32,16,3,120,65,80,17,64,0,20,33,116,32,80,513]

theorem envBound55185 : H12AffineFastState.Bounded env55185 := by
  intro p hp
  have h : env55185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55184_55185 : H12AffineEnvironment.transform 7 117 env55184 = env55185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env55184 == env55185) = true)

def env55186 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2155580,2485295,16777216,8193,65,16959507,18973701,375167,2305071,19163198,16875893,257,17049610,17090855,19222369]

theorem envBound55186 : H12AffineFastState.Bounded env55186 := by
  intro p hp
  have h : env55186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55172_55186 : H12AffineEnvironment.transform 6 9 env55172 = env55186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55172 == env55186) = true)

def env55187 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,2097152,2155580,2212871,16777216,8193,65,16959507,18973701,102743,2305071,18890774,16875893,257,16777250,16834831,18966345]

theorem envBound55187 : H12AffineFastState.Bounded env55187 := by
  intro p hp
  have h : env55187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55186_55187 : H12AffineEnvironment.transform 17 10280 env55186 = env55187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55186 == env55187) = true)

def env55188 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62588,119879,16777216,8193,65,16959507,16880709,102743,212079,16797782,16875893,257,16777250,16834831,16873225]

theorem envBound55188 : H12AffineFastState.Bounded env55188 := by
  intro p hp
  have h : env55188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55187_55188 : H12AffineEnvironment.transform 20 4160 env55187 = env55188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55187 == env55188) = true)

def env55189 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62588,119879,95496,8193,65,245019,57677,102743,212079,75102,62589,257,95530,103431,513]

theorem envBound55189 : H12AffineFastState.Bounded env55189 := by
  intro p hp
  have h : env55189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55188_55189 : H12AffineEnvironment.transform 23 95496 env55188 = env55189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95496 env55188 == env55189) = true)

theorem identity55189 : scanCanonicalize (H12AffineFastState.compose env55189 (packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55189 : packedSelected [1,2,3,4,6,9,16,18,20,24,28] rootPS < 2^1333 := by decide +kernel

def env55190 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,10280,1025,8541,4160,21792,95515,95496,8193,65,203847,16401,77835,212079,75102,21793,257,95530,79195,513]

theorem envBound55190 : H12AffineFastState.Bounded env55190 := by
  intro p hp
  have h : env55190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55189_55190 : H12AffineEnvironment.transform 14 8540 env55189 = env55190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55189 == env55190) = true)

theorem identity55190 : scanCanonicalize (H12AffineFastState.compose env55190 (packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound55190 : packedSelected [1,2,4,6,8,9,10,14,15,20] rootPS < 2^1333 := by decide +kernel

def env55191 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,65536,131072,10280,1025,8541,4160,112,73803,73816,8193,65,203847,5441,77835,212079,75102,113,257,73850,79195,513]

theorem envBound55191 : H12AffineFastState.Bounded env55191 := by
  intro p hp
  have h : env55191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55190_55191 : H12AffineEnvironment.transform 13 5456 env55190 = env55191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env55190 == env55191) = true)

theorem identity55191 : scanCanonicalize (H12AffineFastState.compose env55191 (packedSelected [0,2,6,7,12,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55191 : packedSelected [0,2,6,7,12,15,16] rootPS < 2^1333 := by decide +kernel

def env55192 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,65536,131072,10280,1025,8460,4113,33,73754,73737,8193,16,203798,5392,77835,212030,75023,32,257,73771,79114,513]

theorem envBound55192 : H12AffineFastState.Bounded env55192 := by
  intro p hp
  have h : env55192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55191_55192 : H12AffineEnvironment.transform 5 17 env55191 = env55192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55191 == env55192) = true)

theorem identity55192 : scanCanonicalize (H12AffineFastState.compose env55192 (packedSelected [4,9,11] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound55192 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55193 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,65536,70679,10280,1025,8460,4113,33,73754,73737,8193,16,2049,5392,77835,10281,75023,32,257,73771,79114,513]

theorem envBound55193 : H12AffineFastState.Bounded env55193 := by
  intro p hp
  have h : env55193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55192_55193 : H12AffineEnvironment.transform 16 70679 env55192 = env55193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env55192 == env55193) = true)

theorem identity55193 : scanCanonicalize (H12AffineFastState.compose env55193 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55193 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55194 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8461,8203,13340,10280,1025,8460,4113,33,17,2,8193,16,2049,5392,4096,10281,1284,32,257,32,5377,513]

theorem envBound55194 : H12AffineFastState.Bounded env55194 := by
  intro p hp
  have h : env55194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55193_55194 : H12AffineEnvironment.transform 15 8203 env55193 = env55194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55193 == env55194) = true)

def env55195 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4160,62588,119879,95497,8193,65,245018,57676,102743,212079,75103,62588,257,95531,103430,512]

theorem envBound55195 : H12AffineFastState.Bounded env55195 := by
  intro p hp
  have h : env55195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55188_55195 : H12AffineEnvironment.transform 23 95497 env55188 = env55195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 95497 env55188 == env55195) = true)

theorem identity55195 : scanCanonicalize (H12AffineFastState.compose env55195 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound55195 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55196 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,131072,10280,1025,32769,4160,62588,41293,3,8193,65,182288,57676,58461,149861,20565,62588,257,33,57612,512]

theorem envBound55196 : H12AffineFastState.Bounded env55196 := by
  intro p hp
  have h : env55196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55195_55196 : H12AffineEnvironment.transform 15 29962 env55195 = env55196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env55195 == env55196) = true)

theorem identity55196 : scanCanonicalize (H12AffineFastState.compose env55196 (packedSelected [4,9,11,12,14,15,16,18] rootPS)) = affineNative (2^(16+1) ^^^ 58380) := by decide +kernel

theorem selectedBound55196 : packedSelected [4,9,11,12,14,15,16,18] rootPS < 2^1333 := by decide +kernel

def env55197 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,29962,58380,10280,1025,32769,4160,62588,41293,3,8193,65,11292,57676,58461,44393,20565,62588,257,33,57612,512]

theorem envBound55197 : H12AffineFastState.Bounded env55197 := by
  intro p hp
  have h : env55197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55196_55197 : H12AffineEnvironment.transform 16 58380 env55196 = env55197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 58380 env55196 == env55197) = true)

theorem identity55197 : scanCanonicalize (H12AffineFastState.compose env55197 (packedSelected [1,2,6,8,10,12,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 22805) := by decide +kernel

theorem selectedBound55197 : packedSelected [1,2,6,8,10,12,16,20] rootPS < 2^1333 := by decide +kernel

def env55198 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,22805,29962,15641,10280,1025,22804,4160,11625,30808,3,8193,65,11292,14425,15688,29820,20565,11625,257,33,14361,512]

theorem envBound55198 : H12AffineFastState.Bounded env55198 := by
  intro p hp
  have h : env55198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55197_55198 : H12AffineEnvironment.transform 14 22805 env55197 = env55198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22805 env55197 == env55198) = true)

theorem identity55198 : scanCanonicalize (H12AffineFastState.compose env55198 (packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound55198 : packedSelected [0,1,2,4,6,7,8,10,12,22] rootPS < 2^1333 := by decide +kernel

def env55199 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,4096,8192,16384,22805,28747,14424,10280,320,22804,4160,10280,30808,3,8193,65,10589,14425,14345,28989,20565,10280,257,33,14361,512]

theorem envBound55199 : H12AffineFastState.Bounded env55199 := by
  intro p hp
  have h : env55199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55198_55199 : H12AffineEnvironment.transform 9 321 env55198 = env55199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env55198 == env55199) = true)

theorem identity55199 : scanCanonicalize (H12AffineFastState.compose env55199 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound55199 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env55200 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,17,8192,16384,18692,24666,10313,10280,320,18693,81,10280,26697,3,8193,65,10589,10312,10264,24876,16452,10280,257,33,10248,512]

theorem envBound55200 : H12AffineFastState.Bounded env55200 := by
  intro p hp
  have h : env55200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55199_55200 : H12AffineEnvironment.transform 11 17 env55199 = env55200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env55199 == env55200) = true)

theorem identity55200 : scanCanonicalize (H12AffineFastState.compose env55200 (packedSelected [0,2,3,5,6,7,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 10328) := by decide +kernel

theorem selectedBound55200 : packedSelected [0,2,3,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env55201 : List Nat := [2,4,8,16,32,64,9,256,512,321,2048,17,8192,10328,8540,2050,10313,10280,320,8541,81,10280,17,3,8193,65,10589,10312,10264,2420,10268,10280,257,33,10248,512]

theorem envBound55201 : H12AffineFastState.Bounded env55201 := by
  intro p hp
  have h : env55201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55200_55201 : H12AffineEnvironment.transform 13 10328 env55200 = env55201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10328 env55200 == env55201) = true)

end H12CloudChart1