import H12CloudChart1Data235

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans59869_59870 : H12AffineEnvironment.transform 7 182 env59869 = env59870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59869 == env59870) = true)

theorem identity59870 : scanCanonicalize (H12AffineFastState.compose env59870 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59870 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59871 : List Nat := [2,4,8,16,32,64,114,68,0,30,48,123,41,43,97,89,43,81,31,97,26,32,65,120,82,16,48,42,123,80,95,32,68,33,43,0]

theorem envBound59871 : H12AffineFastState.Bounded env59871 := by
  intro p hp
  have h : env59871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59870_59871 : H12AffineEnvironment.transform 6 114 env59870 = env59871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59870 == env59871) = true)

def env59872 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1288,9617,2365813,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59872 : H12AffineFastState.Bounded env59872 := by
  intro p hp
  have h : env59872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59848_59872 : H12AffineEnvironment.transform 8 1 env59848 = env59872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59848 == env59872) = true)

theorem identity59872 : scanCanonicalize (H12AffineFastState.compose env59872 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 8580) := by decide +kernel

theorem selectedBound59872 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59873 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,8580,1416,9664,3159,1288,9617,276721,4177,77954,66898,65542,68094,256,65674,78034,9600]

theorem envBound59873 : H12AffineFastState.Bounded env59873 := by
  intro p hp
  have h : env59873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59872_59873 : H12AffineEnvironment.transform 20 8580 env59872 = env59873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 8580 env59872 == env59873) = true)

def env59874 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,1028,1416,64,3159,1288,17,269681,4177,70914,66898,65542,68094,256,65674,70994,0]

theorem envBound59874 : H12AffineFastState.Bounded env59874 := by
  intro p hp
  have h : env59874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59873_59874 : H12AffineEnvironment.transform 12 1408 env59873 = env59874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59873 == env59874) = true)

theorem identity59874 : scanCanonicalize (H12AffineFastState.compose env59874 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 3576) := by decide +kernel

theorem selectedBound59874 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59875 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3576,1408,3496,2128,65536,67754,262144,1025,2128,1028,1416,64,3159,1288,17,262281,3497,67834,66898,65542,68094,256,65674,67754,0]

theorem envBound59875 : H12AffineFastState.Bounded env59875 := by
  intro p hp
  have h : env59875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59874_59875 : H12AffineEnvironment.transform 11 3576 env59874 = env59875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3576 env59874 == env59875) = true)

theorem identity59875 : scanCanonicalize (H12AffineFastState.compose env59875 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59875 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59876 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,0,1408,80,1448,65536,66898,262144,1025,1448,1028,1416,64,431,1288,17,262281,81,66818,66898,65542,66566,256,65674,66898,0]

theorem envBound59876 : H12AffineFastState.Bounded env59876 := by
  intro p hp
  have h : env59876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59875_59876 : H12AffineEnvironment.transform 10 1528 env59875 = env59876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59875 == env59876) = true)

theorem identity59876 : scanCanonicalize (H12AffineFastState.compose env59876 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66799) := by decide +kernel

theorem selectedBound59876 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59877 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,0,1408,80,1448,65536,66898,66799,1025,1448,1028,1416,64,431,1288,17,66662,81,66818,66898,65542,66566,256,65674,66898,0]

theorem envBound59877 : H12AffineFastState.Bounded env59877 := by
  intro p hp
  have h : env59877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59876_59877 : H12AffineEnvironment.transform 17 66799 env59876 = env59877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66799 env59876 == env59877) = true)

theorem identity59877 : scanCanonicalize (H12AffineFastState.compose env59877 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59877 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59878 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,0,1408,80,1448,1062,372,201,1025,1448,1028,1416,64,431,1288,17,64,81,292,372,1056,32,256,1196,372,0]

theorem envBound59878 : H12AffineFastState.Bounded env59878 := by
  intro p hp
  have h : env59878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59877_59878 : H12AffineEnvironment.transform 15 1062 env59877 = env59878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59877 == env59878) = true)

theorem identity59878 : scanCanonicalize (H12AffineFastState.compose env59878 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59878 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59879 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,0,1149,80,1109,1062,137,201,1025,1109,1028,1141,64,82,1269,17,64,81,217,137,1056,32,253,1196,137,0]

theorem envBound59879 : H12AffineFastState.Bounded env59879 := by
  intro p hp
  have h : env59879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59878_59879 : H12AffineEnvironment.transform 7 253 env59878 = env59879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59878 == env59879) = true)

theorem identity59879 : scanCanonicalize (H12AffineFastState.compose env59879 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound59879 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59880 : List Nat := [2,4,8,16,32,64,128,253,1,140,137,0,241,80,217,170,137,201,141,217,136,249,64,82,121,17,64,81,217,137,172,32,253,32,137,0]

theorem envBound59880 : H12AffineFastState.Bounded env59880 := by
  intro p hp
  have h : env59880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59879_59880 : H12AffineEnvironment.transform 9 140 env59879 = env59880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env59879 == env59880) = true)

theorem identity59880 : scanCanonicalize (H12AffineFastState.compose env59880 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound59880 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env59881 : List Nat := [2,4,8,16,32,64,89,36,1,85,80,0,40,80,0,115,80,16,84,0,81,32,64,82,121,17,64,81,0,80,117,32,36,32,80,0]

theorem envBound59881 : H12AffineFastState.Bounded env59881 := by
  intro p hp
  have h : env59881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59880_59881 : H12AffineEnvironment.transform 6 89 env59880 = env59881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env59880 == env59881) = true)

theorem identity59881 : scanCanonicalize (H12AffineFastState.compose env59881 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound59881 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59882 : List Nat := [2,4,8,16,32,1,24,36,1,20,17,0,40,17,0,50,17,16,21,0,16,32,1,19,56,17,1,16,0,17,52,32,36,32,17,0]

theorem envBound59882 : H12AffineFastState.Bounded env59882 := by
  intro p hp
  have h : env59882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59881_59882 : H12AffineEnvironment.transform 5 1 env59881 = env59882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env59881 == env59882) = true)

theorem identity59882 : scanCanonicalize (H12AffineFastState.compose env59882 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59882 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59883 : List Nat := [0,4,8,16,32,1,24,36,1,20,17,0,40,17,0,48,17,16,21,0,16,32,1,17,56,17,1,16,0,17,52,32,36,32,17,0]

theorem envBound59883 : H12AffineFastState.Bounded env59883 := by
  intro p hp
  have h : env59883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59882_59883 : H12AffineEnvironment.transform 0 0 env59882 = env59883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59882 == env59883) = true)

theorem identity59883 : scanCanonicalize (H12AffineFastState.compose env59883 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59883 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59884 : List Nat := [0,4,0,16,32,1,16,36,1,20,17,0,32,17,0,48,17,16,21,0,16,32,1,17,48,17,1,16,0,17,52,32,36,32,17,0]

theorem envBound59884 : H12AffineFastState.Bounded env59884 := by
  intro p hp
  have h : env59884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59883_59884 : H12AffineEnvironment.transform 2 0 env59883 = env59884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59883 == env59884) = true)

theorem identity59884 : scanCanonicalize (H12AffineFastState.compose env59884 (packedSelected [0,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound59884 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59885 : List Nat := [0,4,0,16,16,1,16,20,1,20,17,0,16,17,0,0,17,16,21,0,16,16,1,17,0,17,1,16,0,17,4,16,20,16,17,0]

theorem envBound59885 : H12AffineFastState.Bounded env59885 := by
  intro p hp
  have h : env59885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59884_59885 : H12AffineEnvironment.transform 4 16 env59884 = env59885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env59884 == env59885) = true)

def env59886 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,1029,1416,65,3159,1288,16,269680,4177,70915,66898,65542,68094,256,65674,70995,1]

theorem envBound59886 : H12AffineFastState.Bounded env59886 := by
  intro p hp
  have h : env59886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59873_59886 : H12AffineEnvironment.transform 12 1409 env59873 = env59886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59873 == env59886) = true)

theorem identity59886 : scanCanonicalize (H12AffineFastState.compose env59886 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 7422) := by decide +kernel

theorem selectedBound59886 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59887 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7422,2477,262144,1025,2128,1029,1416,65,3159,1288,16,269680,4177,2557,6572,7416,5376,256,7284,2477,1]

theorem envBound59887 : H12AffineFastState.Bounded env59887 := by
  intro p hp
  have h : env59887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59886_59887 : H12AffineEnvironment.transform 15 7422 env59886 = env59887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7422 env59886 == env59887) = true)

theorem identity59887 : scanCanonicalize (H12AffineFastState.compose env59887 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 3529) := by decide +kernel

theorem selectedBound59887 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59888 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,7422,2477,3529,1025,2128,1029,1416,65,3159,1288,16,4281,4177,2557,6572,7416,5376,256,7284,2477,1]

theorem envBound59888 : H12AffineFastState.Bounded env59888 := by
  intro p hp
  have h : env59888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59887_59888 : H12AffineEnvironment.transform 17 3529 env59887 = env59888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3529 env59887 == env59888) = true)

theorem identity59888 : scanCanonicalize (H12AffineFastState.compose env59888 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59888 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59889 : List Nat := [2,4,8,16,32,64,128,256,1,1024,49,4096,1409,4176,97,5327,412,1528,1025,97,1029,1416,65,1126,1288,16,4281,4177,460,4509,5321,5376,256,5189,412,1]

theorem envBound59889 : H12AffineFastState.Bounded env59889 := by
  intro p hp
  have h : env59889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59888_59889 : H12AffineEnvironment.transform 10 49 env59888 = env59889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59888 == env59889) = true)

theorem identity59889 : scanCanonicalize (H12AffineFastState.compose env59889 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound59889 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59890 : List Nat := [2,4,8,16,32,64,128,256,1,1024,49,1312,1409,1392,97,495,412,1528,1025,97,1029,1416,65,1126,1288,16,1433,1393,460,1213,489,32,256,357,412,1]

theorem envBound59890 : H12AffineFastState.Bounded env59890 := by
  intro p hp
  have h : env59890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59889_59890 : H12AffineEnvironment.transform 11 1312 env59889 = env59890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env59889 == env59890) = true)

theorem identity59890 : scanCanonicalize (H12AffineFastState.compose env59890 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound59890 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59891 : List Nat := [2,4,8,16,32,64,128,256,1,236,49,460,365,412,97,495,412,276,237,97,233,356,65,138,484,16,373,413,460,81,489,32,256,357,412,1]

theorem envBound59891 : H12AffineFastState.Bounded env59891 := by
  intro p hp
  have h : env59891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59890_59891 : H12AffineEnvironment.transform 9 236 env59890 = env59891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env59890 == env59891) = true)

theorem identity59891 : scanCanonicalize (H12AffineFastState.compose env59891 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59891 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59892 : List Nat := [2,4,8,16,32,64,128,182,1,236,49,122,219,42,97,89,42,162,237,97,233,210,65,138,82,16,195,43,122,81,95,32,182,211,42,1]

theorem envBound59892 : H12AffineFastState.Bounded env59892 := by
  intro p hp
  have h : env59892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59891_59892 : H12AffineEnvironment.transform 7 182 env59891 = env59892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59891 == env59892) = true)

theorem identity59892 : scanCanonicalize (H12AffineFastState.compose env59892 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59892 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59893 : List Nat := [2,4,8,16,32,64,114,68,1,30,49,122,41,42,97,89,42,80,31,97,27,32,65,120,82,16,49,43,122,81,95,32,68,33,42,1]

theorem envBound59893 : H12AffineFastState.Bounded env59893 := by
  intro p hp
  have h : env59893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59892_59893 : H12AffineEnvironment.transform 6 114 env59892 = env59893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59892 == env59893) = true)

def env59894 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3671,1289,9616,2366324,4177,77954,67411,65543,68606,256,65674,78034,10112]

theorem envBound59894 : H12AffineFastState.Bounded env59894 := by
  intro p hp
  have h : env59894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59847_59894 : H12AffineEnvironment.transform 22 9665 env59847 = env59894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59847 == env59894) = true)

def env59895 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1289,9616,2365812,4177,77954,66899,65543,68094,256,65674,78034,9600]

theorem envBound59895 : H12AffineFastState.Bounded env59895 := by
  intro p hp
  have h : env59895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59894_59895 : H12AffineEnvironment.transform 8 0 env59894 = env59895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59894 == env59895) = true)

theorem identity59895 : scanCanonicalize (H12AffineFastState.compose env59895 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 6612) := by decide +kernel

theorem selectedBound59895 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59896 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,6612,4176,2129,65536,67846,262144,1025,2129,2097152,1416,7189,3159,1289,7236,2365812,4177,67926,66899,65543,68094,256,65674,67846,7252]

theorem envBound59896 : H12AffineFastState.Bounded env59896 := by
  intro p hp
  have h : env59896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59895_59896 : H12AffineEnvironment.transform 12 6612 env59895 = env59896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6612 env59895 == env59896) = true)

def env59897 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,2097152,1416,65,3159,1289,16,2360608,3077,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59897 : H12AffineFastState.Bounded env59897 := by
  intro p hp
  have h : env59897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59896_59897 : H12AffineEnvironment.transform 11 3156 env59896 = env59897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59896 == env59897) = true)

theorem identity59897 : scanCanonicalize (H12AffineFastState.compose env59897 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66735) := by decide +kernel

theorem selectedBound59897 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59898 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,65536,67846,262144,1025,2129,66735,1416,65,3159,1289,16,328079,3077,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59898 : H12AffineFastState.Bounded env59898 := by
  intro p hp
  have h : env59898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59897_59898 : H12AffineEnvironment.transform 20 66735 env59897 = env59898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66735 env59897 == env59898) = true)

theorem identity59898 : scanCanonicalize (H12AffineFastState.compose env59898 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59898 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59899 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,65536,67846,68963,1025,2129,66735,1416,65,3159,1289,16,3308,3077,67926,66899,65543,68094,256,65674,67846,0]

theorem envBound59899 : H12AffineFastState.Bounded env59899 := by
  intro p hp
  have h : env59899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59898_59899 : H12AffineEnvironment.transform 17 68963 env59898 = env59899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59898 == env59899) = true)

theorem identity59899 : scanCanonicalize (H12AffineFastState.compose env59899 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2203) := by decide +kernel

theorem selectedBound59899 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59900 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3156,1408,3076,2129,2203,413,1528,1025,2129,3124,1416,65,3159,1289,16,3308,3077,461,3528,2204,357,256,2065,413,0]

theorem envBound59900 : H12AffineFastState.Bounded env59900 := by
  intro p hp
  have h : env59900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59899_59900 : H12AffineEnvironment.transform 15 2203 env59899 = env59900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2203 env59899 == env59900) = true)

theorem identity59900 : scanCanonicalize (H12AffineFastState.compose env59900 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1433) := by decide +kernel

theorem selectedBound59900 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59901 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1433,461,1408,413,1480,1282,413,1528,1025,1480,429,1416,65,462,1289,16,373,412,461,81,1285,357,256,1416,413,0]

theorem envBound59901 : H12AffineFastState.Bounded env59901 := by
  intro p hp
  have h : env59901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59900_59901 : H12AffineEnvironment.transform 10 1433 env59900 = env59901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1433 env59900 == env59901) = true)

theorem identity59901 : scanCanonicalize (H12AffineFastState.compose env59901 (packedSelected [0,5] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59901 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59902 : List Nat := [2,4,8,16,32,64,128,182,0,1024,1071,123,1078,43,1150,1204,43,1102,1025,1150,27,1086,65,120,1215,16,195,42,123,81,1203,211,182,1086,43,0]

theorem envBound59902 : H12AffineFastState.Bounded env59902 := by
  intro p hp
  have h : env59902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59901_59902 : H12AffineEnvironment.transform 7 182 env59901 = env59902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59901 == env59902) = true)

theorem identity59902 : scanCanonicalize (H12AffineFastState.compose env59902 (packedSelected [0,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59902 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env59903 : List Nat := [2,4,8,16,32,64,114,68,0,1024,1071,123,1078,43,1150,1094,43,1102,1025,1150,27,1086,65,120,1101,16,49,42,123,81,1089,33,68,1086,43,0]

theorem envBound59903 : H12AffineFastState.Bounded env59903 := by
  intro p hp
  have h : env59903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59902_59903 : H12AffineEnvironment.transform 6 114 env59902 = env59903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59902 == env59903) = true)

theorem identity59903 : scanCanonicalize (H12AffineFastState.compose env59903 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound59903 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59904 : List Nat := [2,4,8,16,32,64,114,68,0,30,49,123,40,43,96,88,43,80,31,96,27,32,65,120,83,16,49,42,123,81,95,33,68,32,43,0]

theorem envBound59904 : H12AffineFastState.Bounded env59904 := by
  intro p hp
  have h : env59904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59903_59904 : H12AffineEnvironment.transform 9 30 env59903 = env59904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env59903 == env59904) = true)

def env59905 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3157,1409,3077,2129,65536,67846,262144,1025,2129,2097152,1416,64,3159,1289,17,2360609,3076,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59905 : H12AffineFastState.Bounded env59905 := by
  intro p hp
  have h : env59905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59896_59905 : H12AffineEnvironment.transform 11 3157 env59896 = env59905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3157 env59896 == env59905) = true)

theorem identity59905 : scanCanonicalize (H12AffineFastState.compose env59905 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59905 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59906 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,3157,1409,3077,2129,65536,67846,262144,1025,2129,1448,1416,64,3159,1289,17,262281,3076,67926,66899,65543,68094,256,65674,67846,1]

theorem envBound59906 : H12AffineFastState.Bounded env59906 := by
  intro p hp
  have h : env59906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59905_59906 : H12AffineEnvironment.transform 20 1448 env59905 = env59906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59905 == env59906) = true)

theorem identity59906 : scanCanonicalize (H12AffineFastState.compose env59906 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59906 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59907 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,428,1409,508,1448,65536,66815,262144,1025,1448,1448,1416,64,430,1289,17,262281,509,66735,66899,65543,66567,256,65674,66815,1]

theorem envBound59907 : H12AffineFastState.Bounded env59907 := by
  intro p hp
  have h : env59907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59906_59907 : H12AffineEnvironment.transform 10 1529 env59906 = env59907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59906 == env59907) = true)

theorem identity59907 : scanCanonicalize (H12AffineFastState.compose env59907 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66882) := by decide +kernel

theorem selectedBound59907 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59908 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,428,1409,508,1448,65536,66815,66882,1025,1448,1448,1416,64,430,1289,17,67019,509,66735,66899,65543,66567,256,65674,66815,1]

theorem envBound59908 : H12AffineFastState.Bounded env59908 := by
  intro p hp
  have h : env59908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59907_59908 : H12AffineEnvironment.transform 17 66882 env59907 = env59908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66882 env59907 == env59908) = true)

theorem identity59908 : scanCanonicalize (H12AffineFastState.compose env59908 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59908 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59909 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,428,1409,508,1448,1062,217,356,1025,1448,1448,1416,64,430,1289,17,493,509,137,373,1057,33,256,1196,217,1]

theorem envBound59909 : H12AffineFastState.Bounded env59909 := by
  intro p hp
  have h : env59909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59908_59909 : H12AffineEnvironment.transform 15 1062 env59908 = env59909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59908 == env59909) = true)

theorem identity59909 : scanCanonicalize (H12AffineFastState.compose env59909 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59909 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59910 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,81,1148,1,1109,1062,217,153,1025,1109,1109,1141,64,83,1268,17,16,0,137,136,1057,33,253,1196,217,1]

theorem envBound59910 : H12AffineFastState.Bounded env59910 := by
  intro p hp
  have h : env59910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59909_59910 : H12AffineEnvironment.transform 7 253 env59909 = env59910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59909 == env59910) = true)

theorem identity59910 : scanCanonicalize (H12AffineFastState.compose env59910 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59910 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59911 : List Nat := [2,4,8,16,32,64,128,253,0,141,137,81,241,1,216,171,217,153,140,216,216,248,64,83,121,17,16,0,137,136,172,33,253,33,217,1]

theorem envBound59911 : H12AffineFastState.Bounded env59911 := by
  intro p hp
  have h : env59911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59910_59911 : H12AffineEnvironment.transform 9 141 env59910 = env59911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59910 == env59911) = true)

theorem identity59911 : scanCanonicalize (H12AffineFastState.compose env59911 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 105) := by decide +kernel

theorem selectedBound59911 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env59912 : List Nat := [2,4,8,16,32,64,105,20,0,100,96,81,24,1,49,66,48,112,101,49,49,17,64,83,121,17,16,0,96,97,69,33,20,33,48,1]

theorem envBound59912 : H12AffineFastState.Bounded env59912 := by
  intro p hp
  have h : env59912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59911_59912 : H12AffineEnvironment.transform 6 105 env59911 = env59912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 105 env59911 == env59912) = true)

theorem identity59912 : scanCanonicalize (H12AffineFastState.compose env59912 (packedSelected [1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound59912 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env59913 : List Nat := [2,4,8,16,32,18,59,20,0,54,50,3,24,1,49,16,48,34,55,49,49,17,18,1,43,17,16,0,50,51,23,33,20,33,48,1]

theorem envBound59913 : H12AffineFastState.Bounded env59913 := by
  intro p hp
  have h : env59913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59912_59913 : H12AffineEnvironment.transform 5 18 env59912 = env59913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env59912 == env59913) = true)

theorem identity59913 : scanCanonicalize (H12AffineFastState.compose env59913 (packedSelected [4,7] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound59913 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env59914 : List Nat := [2,4,8,8,32,10,35,12,0,46,42,3,0,1,41,8,40,34,47,41,41,9,10,1,43,9,8,0,42,43,15,33,12,33,40,1]

theorem envBound59914 : H12AffineFastState.Bounded env59914 := by
  intro p hp
  have h : env59914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59913_59914 : H12AffineEnvironment.transform 3 8 env59913 = env59914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env59913 == env59914) = true)

theorem identity59914 : scanCanonicalize (H12AffineFastState.compose env59914 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound59914 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59915 : List Nat := [2,4,2,2,32,0,35,6,0,36,32,3,0,1,35,2,34,34,37,35,35,3,0,1,33,3,2,0,32,33,5,33,6,33,34,1]

theorem envBound59915 : H12AffineFastState.Bounded env59915 := by
  intro p hp
  have h : env59915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59914_59915 : H12AffineEnvironment.transform 2 2 env59914 = env59915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env59914 == env59915) = true)

theorem identity59915 : scanCanonicalize (H12AffineFastState.compose env59915 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound59915 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env59916 : List Nat := [0,4,0,0,32,0,33,4,0,36,32,1,0,1,33,0,32,32,37,33,33,1,0,1,33,1,0,0,32,33,5,33,4,33,32,1]

theorem envBound59916 : H12AffineFastState.Bounded env59916 := by
  intro p hp
  have h : env59916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59915_59916 : H12AffineEnvironment.transform 0 0 env59915 = env59916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env59915 == env59916) = true)

def env59917 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2365813,4177,77954,66898,65543,68095,256,65674,78034,9601]

theorem envBound59917 : H12AffineFastState.Bounded env59917 := by
  intro p hp
  have h : env59917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59894_59917 : H12AffineEnvironment.transform 8 1 env59894 = env59917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59894 == env59917) = true)

theorem identity59917 : scanCanonicalize (H12AffineFastState.compose env59917 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound59917 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59918 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,8192,3076,2128,65536,76934,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2360609,3077,77014,66898,65543,68095,256,65674,76934,9601]

theorem envBound59918 : H12AffineFastState.Bounded env59918 := by
  intro p hp
  have h : env59918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59917_59918 : H12AffineEnvironment.transform 11 3156 env59917 = env59918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env59917 == env59918) = true)

def env59919 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,2097152,1416,65,3158,1289,16,2360609,3077,67926,66898,65543,68095,256,65674,67846,1]

theorem envBound59919 : H12AffineFastState.Bounded env59919 := by
  intro p hp
  have h : env59919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59918_59919 : H12AffineEnvironment.transform 12 1408 env59918 = env59919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59918 == env59919) = true)

theorem identity59919 : scanCanonicalize (H12AffineFastState.compose env59919 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 66734) := by decide +kernel

theorem selectedBound59919 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59920 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,65536,67846,262144,1025,2128,66734,1416,65,3158,1289,16,328079,3077,67926,66898,65543,68095,256,65674,67846,1]

theorem envBound59920 : H12AffineFastState.Bounded env59920 := by
  intro p hp
  have h : env59920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59919_59920 : H12AffineEnvironment.transform 20 66734 env59919 = env59920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 66734 env59919 == env59920) = true)

theorem identity59920 : scanCanonicalize (H12AffineFastState.compose env59920 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 68963) := by decide +kernel

theorem selectedBound59920 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59921 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,65536,67846,68963,1025,2128,66734,1416,65,3158,1289,16,3308,3077,67926,66898,65543,68095,256,65674,67846,1]

theorem envBound59921 : H12AffineFastState.Bounded env59921 := by
  intro p hp
  have h : env59921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59920_59921 : H12AffineEnvironment.transform 17 68963 env59920 = env59921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 68963 env59920 == env59921) = true)

theorem identity59921 : scanCanonicalize (H12AffineFastState.compose env59921 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 2202) := by decide +kernel

theorem selectedBound59921 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59922 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1408,3076,2128,2202,412,1529,1025,2128,3124,1416,65,3158,1289,16,3308,3077,460,3528,2205,357,256,2064,412,1]

theorem envBound59922 : H12AffineFastState.Bounded env59922 := by
  intro p hp
  have h : env59922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59921_59922 : H12AffineEnvironment.transform 15 2202 env59921 = env59922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 2202 env59921 == env59922) = true)

theorem identity59922 : scanCanonicalize (H12AffineFastState.compose env59922 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound59922 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59923 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1244,136,1408,216,1164,1094,412,1529,1025,1164,232,1416,65,138,1289,16,48,217,460,276,1089,357,256,1228,412,1]

theorem envBound59923 : H12AffineFastState.Bounded env59923 := by
  intro p hp
  have h : env59923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59922_59923 : H12AffineEnvironment.transform 10 1244 env59922 = env59923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env59922 == env59923) = true)

theorem identity59923 : scanCanonicalize (H12AffineFastState.compose env59923 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound59923 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env59924 : List Nat := [2,4,8,16,32,64,128,256,1,424,372,136,40,216,292,494,412,81,425,292,232,32,65,138,161,16,48,217,460,276,489,357,256,356,412,1]

theorem envBound59924 : H12AffineFastState.Bounded env59924 := by
  intro p hp
  have h : env59924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59923_59924 : H12AffineEnvironment.transform 9 424 env59923 = env59924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env59923 == env59924) = true)

theorem identity59924 : scanCanonicalize (H12AffineFastState.compose env59924 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound59924 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env59925 : List Nat := [2,4,8,16,32,64,128,69,1,237,49,136,40,216,97,171,217,81,236,97,232,32,65,138,161,16,48,217,137,81,172,32,69,33,217,1]

theorem envBound59925 : H12AffineFastState.Bounded env59925 := by
  intro p hp
  have h : env59925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59924_59925 : H12AffineEnvironment.transform 7 69 env59924 = env59925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env59924 == env59925) = true)

theorem identity59925 : scanCanonicalize (H12AffineFastState.compose env59925 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound59925 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env59926 : List Nat := [2,4,8,16,32,58,128,63,1,151,49,136,40,162,27,171,163,43,150,27,146,32,59,138,161,16,48,163,137,43,172,32,63,33,163,1]

theorem envBound59926 : H12AffineFastState.Bounded env59926 := by
  intro p hp
  have h : env59926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59925_59926 : H12AffineEnvironment.transform 5 58 env59925 = env59926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env59925 == env59926) = true)

def env59927 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,2097152,1416,64,3158,1289,17,2360609,3077,67927,66898,65543,68095,256,65674,67847,0]

theorem envBound59927 : H12AffineFastState.Bounded env59927 := by
  intro p hp
  have h : env59927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59918_59927 : H12AffineEnvironment.transform 12 1409 env59918 = env59927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59918 == env59927) = true)

theorem identity59927 : scanCanonicalize (H12AffineFastState.compose env59927 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 1448) := by decide +kernel

theorem selectedBound59927 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59928 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,3156,1409,3076,2128,65536,67847,262144,1025,2128,1448,1416,64,3158,1289,17,262281,3077,67927,66898,65543,68095,256,65674,67847,0]

theorem envBound59928 : H12AffineFastState.Bounded env59928 := by
  intro p hp
  have h : env59928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59927_59928 : H12AffineEnvironment.transform 20 1448 env59927 = env59928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 1448 env59927 == env59928) = true)

theorem identity59928 : scanCanonicalize (H12AffineFastState.compose env59928 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59928 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59929 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,428,1409,508,1448,65536,66815,262144,1025,1448,1448,1416,64,430,1289,17,262281,509,66735,66898,65543,66567,256,65674,66815,0]

theorem envBound59929 : H12AffineFastState.Bounded env59929 := by
  intro p hp
  have h : env59929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59928_59929 : H12AffineEnvironment.transform 10 1528 env59928 = env59929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59928 == env59929) = true)

theorem identity59929 : scanCanonicalize (H12AffineFastState.compose env59929 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66882) := by decide +kernel

theorem selectedBound59929 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59930 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,428,1409,508,1448,65536,66815,66882,1025,1448,1448,1416,64,430,1289,17,67019,509,66735,66898,65543,66567,256,65674,66815,0]

theorem envBound59930 : H12AffineFastState.Bounded env59930 := by
  intro p hp
  have h : env59930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59929_59930 : H12AffineEnvironment.transform 17 66882 env59929 = env59930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66882 env59929 == env59930) = true)

theorem identity59930 : scanCanonicalize (H12AffineFastState.compose env59930 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59930 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59931 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,428,1409,508,1448,1062,217,356,1025,1448,1448,1416,64,430,1289,17,493,509,137,372,1057,33,256,1196,217,0]

theorem envBound59931 : H12AffineFastState.Bounded env59931 := by
  intro p hp
  have h : env59931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59930_59931 : H12AffineEnvironment.transform 15 1062 env59930 = env59931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59930 == env59931) = true)

theorem identity59931 : scanCanonicalize (H12AffineFastState.compose env59931 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59931 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59932 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,80,1149,0,1108,1062,217,152,1025,1108,1108,1140,64,82,1269,17,17,1,137,136,1057,33,252,1196,217,0]

theorem envBound59932 : H12AffineFastState.Bounded env59932 := by
  intro p hp
  have h : env59932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59931_59932 : H12AffineEnvironment.transform 7 252 env59931 = env59932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59931 == env59932) = true)

theorem identity59932 : scanCanonicalize (H12AffineFastState.compose env59932 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59932 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59933 : List Nat := [2,4,8,16,32,17,128,173,1,1024,1028,1,1068,0,1029,1062,136,152,1025,1029,1029,1061,17,3,1188,17,17,1,137,136,1057,33,173,1196,136,0]

theorem envBound59933 : H12AffineFastState.Bounded env59933 := by
  intro p hp
  have h : env59933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59932_59933 : H12AffineEnvironment.transform 5 17 env59932 = env59933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59932 == env59933) = true)

theorem identity59933 : scanCanonicalize (H12AffineFastState.compose env59933 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 175) := by decide +kernel

theorem selectedBound59933 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59934 : List Nat := [2,4,8,16,32,17,128,173,1,175,171,1,131,0,170,137,136,152,174,170,170,138,17,3,11,17,17,1,137,136,142,33,173,3,136,0]

theorem envBound59934 : H12AffineFastState.Bounded env59934 := by
  intro p hp
  have h : env59934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59933_59934 : H12AffineEnvironment.transform 9 175 env59933 = env59934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 175 env59933 == env59934) = true)

theorem identity59934 : scanCanonicalize (H12AffineFastState.compose env59934 (packedSelected [1,3,4,6,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 19) := by decide +kernel

theorem selectedBound59934 : packedSelected [1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env59935 : List Nat := [2,4,8,16,19,17,128,158,1,156,152,1,131,0,153,137,136,152,157,153,153,138,17,3,11,17,17,1,137,136,142,18,158,3,136,0]

theorem envBound59935 : H12AffineFastState.Bounded env59935 := by
  intro p hp
  have h : env59935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59934_59935 : H12AffineEnvironment.transform 4 19 env59934 = env59935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 19 env59934 == env59935) = true)

theorem identity59935 : scanCanonicalize (H12AffineFastState.compose env59935 (packedSelected [6,7] rootPS)) = affineNative (2^(6+1) ^^^ 27) := by decide +kernel

theorem selectedBound59935 : packedSelected [6,7] rootPS < 2^1333 := by decide +kernel

def env59936 : List Nat := [2,4,8,16,19,17,27,5,1,7,3,1,24,0,2,18,19,3,6,2,2,17,17,3,11,17,17,1,18,19,21,18,5,3,19,0]

theorem envBound59936 : H12AffineFastState.Bounded env59936 := by
  intro p hp
  have h : env59936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59935_59936 : H12AffineEnvironment.transform 6 27 env59935 = env59936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 27 env59935 == env59936) = true)

theorem identity59936 : scanCanonicalize (H12AffineFastState.compose env59936 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound59936 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env59937 : List Nat := [2,4,8,8,11,9,3,5,1,7,3,1,0,0,2,10,11,3,6,2,2,9,9,3,11,9,9,1,10,11,13,10,5,3,11,0]

theorem envBound59937 : H12AffineFastState.Bounded env59937 := by
  intro p hp
  have h : env59937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59936_59937 : H12AffineEnvironment.transform 3 8 env59936 = env59937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env59936 == env59937) = true)

theorem identity59937 : scanCanonicalize (H12AffineFastState.compose env59937 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound59937 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59938 : List Nat := [2,4,3,3,0,2,3,5,1,7,3,1,0,0,2,1,0,3,6,2,2,2,2,3,0,2,2,1,1,0,6,1,5,3,0,0]

theorem envBound59938 : H12AffineFastState.Bounded env59938 := by
  intro p hp
  have h : env59938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59937_59938 : H12AffineEnvironment.transform 2 3 env59937 = env59938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env59937 == env59938) = true)

def env59939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399766,8397000,8388689,2366325,4177,77954,67410,8463814,8465983,256,65675,78034,8389185]

theorem envBound59939 : H12AffineFastState.Bounded env59939 := by
  intro p hp
  have h : env59939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59846_59939 : H12AffineEnvironment.transform 21 1417 env59846 = env59939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env59846 == env59939) = true)

def env59940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3670,1288,9617,2366325,4177,77954,67410,65542,68607,256,65675,78034,10113]

theorem envBound59940 : H12AffineFastState.Bounded env59940 := by
  intro p hp
  have h : env59940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59939_59940 : H12AffineEnvironment.transform 22 9664 env59939 = env59940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env59939 == env59940) = true)

def env59941 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9664,3158,1288,9617,2365813,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59941 : H12AffineFastState.Bounded env59941 := by
  intro p hp
  have h : env59941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59940_59941 : H12AffineEnvironment.transform 8 0 env59940 = env59941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59940 == env59941) = true)

theorem identity59941 : scanCanonicalize (H12AffineFastState.compose env59941 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 11609) := by decide +kernel

theorem selectedBound59941 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59942 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,11609,1417,9664,3158,1288,9617,275500,4177,77954,66898,65542,68095,256,65675,78034,9601]

theorem envBound59942 : H12AffineFastState.Bounded env59942 := by
  intro p hp
  have h : env59942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59941_59942 : H12AffineEnvironment.transform 20 11609 env59941 = env59942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11609 env59941 == env59942) = true)

def env59943 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,2265,1417,64,3158,1288,17,266668,4177,70914,66898,65542,68095,256,65675,70994,1]

theorem envBound59943 : H12AffineFastState.Bounded env59943 := by
  intro p hp
  have h : env59943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59942_59943 : H12AffineEnvironment.transform 12 1408 env59942 = env59943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59942 == env59943) = true)

theorem identity59943 : scanCanonicalize (H12AffineFastState.compose env59943 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound59943 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59944 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,293,1408,373,2129,65536,66679,262144,1025,2129,2265,1417,64,3158,1288,17,262281,372,66599,66898,65542,68095,256,65675,66679,1]

theorem envBound59944 : H12AffineFastState.Bounded env59944 := by
  intro p hp
  have h : env59944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59943_59944 : H12AffineEnvironment.transform 11 293 env59943 = env59944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env59943 == env59944) = true)

theorem identity59944 : scanCanonicalize (H12AffineFastState.compose env59944 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59944 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59945 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,293,1408,373,1448,65536,66679,262144,1025,1448,1312,1417,64,431,1288,17,262281,372,66599,66898,65542,66566,256,65675,66679,1]

theorem envBound59945 : H12AffineFastState.Bounded env59945 := by
  intro p hp
  have h : env59945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59944_59945 : H12AffineEnvironment.transform 10 1529 env59944 = env59945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59944 == env59945) = true)

theorem identity59945 : scanCanonicalize (H12AffineFastState.compose env59945 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 67019) := by decide +kernel

theorem selectedBound59945 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59946 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,293,1408,373,1448,65536,66679,67019,1025,1448,1312,1417,64,431,1288,17,66882,372,66599,66898,65542,66566,256,65675,66679,1]

theorem envBound59946 : H12AffineFastState.Bounded env59946 := by
  intro p hp
  have h : env59946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59945_59946 : H12AffineEnvironment.transform 17 67019 env59945 = env59946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67019 env59945 == env59946) = true)

theorem identity59946 : scanCanonicalize (H12AffineFastState.compose env59946 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59946 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59947 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,293,1408,373,1448,1062,81,493,1025,1448,1312,1417,64,431,1288,17,356,372,1,372,1056,32,256,1197,81,1]

theorem envBound59947 : H12AffineFastState.Bounded env59947 := by
  intro p hp
  have h : env59947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59946_59947 : H12AffineEnvironment.transform 15 1062 env59946 = env59947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59946 == env59947) = true)

theorem identity59947 : scanCanonicalize (H12AffineFastState.compose env59947 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound59947 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59948 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1029,217,1148,137,1108,1062,81,17,1025,1108,1244,1141,64,83,1268,17,152,136,1,136,1056,32,252,1197,81,1]

theorem envBound59948 : H12AffineFastState.Bounded env59948 := by
  intro p hp
  have h : env59948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59947_59948 : H12AffineEnvironment.transform 7 252 env59947 = env59948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env59947 == env59948) = true)

theorem identity59948 : scanCanonicalize (H12AffineFastState.compose env59948 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound59948 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59949 : List Nat := [2,4,8,16,32,17,128,173,0,1024,1029,136,1069,137,1029,1062,0,17,1025,1029,1165,1060,17,2,1189,17,152,136,1,136,1056,32,173,1197,0,1]

theorem envBound59949 : H12AffineFastState.Bounded env59949 := by
  intro p hp
  have h : env59949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59948_59949 : H12AffineEnvironment.transform 5 17 env59948 = env59949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env59948 == env59949) = true)

theorem identity59949 : scanCanonicalize (H12AffineFastState.compose env59949 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 39) := by decide +kernel

theorem selectedBound59949 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59950 : List Nat := [2,4,8,16,32,17,128,173,0,39,34,136,10,137,34,1,0,17,38,34,170,3,17,2,130,17,152,136,1,136,7,32,173,138,0,1]

theorem envBound59950 : H12AffineFastState.Bounded env59950 := by
  intro p hp
  have h : env59950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59949_59950 : H12AffineEnvironment.transform 9 39 env59949 = env59950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 39 env59949 == env59950) = true)

theorem identity59950 : scanCanonicalize (H12AffineFastState.compose env59950 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound59950 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env59951 : List Nat := [2,4,8,16,32,17,42,7,0,39,34,34,10,35,34,1,0,17,38,34,0,3,17,2,40,17,50,34,1,34,7,32,7,32,0,1]

theorem envBound59951 : H12AffineFastState.Bounded env59951 := by
  intro p hp
  have h : env59951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59950_59951 : H12AffineEnvironment.transform 6 42 env59950 = env59951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env59950 == env59951) = true)

theorem identity59951 : scanCanonicalize (H12AffineFastState.compose env59951 (packedSelected [3,4,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59951 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59952 : List Nat := [1,4,8,16,32,17,41,4,0,36,33,33,9,32,33,1,0,17,37,33,0,0,17,1,40,17,49,33,1,33,4,32,4,32,0,1]

theorem envBound59952 : H12AffineFastState.Bounded env59952 := by
  intro p hp
  have h : env59952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59951_59952 : H12AffineEnvironment.transform 0 1 env59951 = env59952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59951 == env59952) = true)

theorem identity59952 : scanCanonicalize (H12AffineFastState.compose env59952 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound59952 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env59953 : List Nat := [1,4,8,16,8,17,1,4,0,12,9,9,9,8,9,1,0,17,13,9,0,0,17,1,0,17,25,9,1,9,4,8,4,8,0,1]

theorem envBound59953 : H12AffineFastState.Bounded env59953 := by
  intro p hp
  have h : env59953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59952_59953 : H12AffineEnvironment.transform 4 8 env59952 = env59953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env59952 == env59953) = true)

theorem identity59953 : scanCanonicalize (H12AffineFastState.compose env59953 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound59953 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59954 : List Nat := [1,4,8,1,8,0,1,4,0,12,9,9,9,8,9,1,0,0,13,9,0,0,0,1,0,0,8,9,1,9,4,8,4,8,0,1]

theorem envBound59954 : H12AffineFastState.Bounded env59954 := by
  intro p hp
  have h : env59954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59953_59954 : H12AffineEnvironment.transform 3 1 env59953 = env59954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env59953 == env59954) = true)

theorem identity59954 : scanCanonicalize (H12AffineFastState.compose env59954 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59954 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env59955 : List Nat := [1,4,0,1,0,0,1,4,0,4,1,1,1,0,1,1,0,0,5,1,0,0,0,1,0,0,0,1,1,1,4,0,4,0,0,1]

theorem envBound59955 : H12AffineFastState.Bounded env59955 := by
  intro p hp
  have h : env59955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59954_59955 : H12AffineEnvironment.transform 2 0 env59954 = env59955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59954 == env59955) = true)

def env59956 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,2264,1417,65,3158,1288,16,266669,4177,70915,66898,65542,68095,256,65675,70995,0]

theorem envBound59956 : H12AffineFastState.Bounded env59956 := by
  intro p hp
  have h : env59956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59942_59956 : H12AffineEnvironment.transform 12 1409 env59942 = env59956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59942 == env59956) = true)

theorem identity59956 : scanCanonicalize (H12AffineFastState.compose env59956 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound59956 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59957 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,2264,1417,65,3158,1288,16,266669,4177,1313,5488,4132,6621,256,4265,1393,0]

theorem envBound59957 : H12AffineFastState.Bounded env59957 := by
  intro p hp
  have h : env59957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59956_59957 : H12AffineEnvironment.transform 15 4130 env59956 = env59957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env59956 == env59957) = true)

theorem identity59957 : scanCanonicalize (H12AffineFastState.compose env59957 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound59957 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59958 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4130,1393,276,1025,2129,2264,1417,65,3158,1288,16,4281,4177,1313,5488,4132,6621,256,4265,1393,0]

theorem envBound59958 : H12AffineFastState.Bounded env59958 := by
  intro p hp
  have h : env59958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59957_59958 : H12AffineEnvironment.transform 17 276 env59957 = env59958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env59957 == env59958) = true)

theorem identity59958 : scanCanonicalize (H12AffineFastState.compose env59958 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59958 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59959 : List Nat := [2,4,8,16,32,64,128,256,0,237,2048,4096,364,4176,2129,4130,412,276,236,2129,2264,356,65,2235,485,16,4281,4177,460,4509,4132,6621,256,4265,412,0]

theorem envBound59959 : H12AffineFastState.Bounded env59959 := by
  intro p hp
  have h : env59959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59958_59959 : H12AffineEnvironment.transform 9 237 env59958 = env59959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59958 == env59959) = true)

theorem identity59959 : scanCanonicalize (H12AffineFastState.compose env59959 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound59959 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env59960 : List Nat := [2,4,8,16,32,64,128,256,0,237,49,4096,364,4176,96,4130,412,276,236,96,233,356,65,138,485,16,4281,4177,460,4509,4132,4588,256,4265,412,0]

theorem envBound59960 : H12AffineFastState.Bounded env59960 := by
  intro p hp
  have h : env59960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59959_59960 : H12AffineEnvironment.transform 10 49 env59959 = env59960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env59959 == env59960) = true)

theorem identity59960 : scanCanonicalize (H12AffineFastState.compose env59960 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 460) := by decide +kernel

theorem selectedBound59960 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env59961 : List Nat := [2,4,8,16,32,64,128,256,0,237,49,460,364,412,96,494,412,276,236,96,233,356,65,138,485,16,373,413,460,81,488,32,256,357,412,0]

theorem envBound59961 : H12AffineFastState.Bounded env59961 := by
  intro p hp
  have h : env59961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59960_59961 : H12AffineEnvironment.transform 11 460 env59960 = env59961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 460 env59960 == env59961) = true)

theorem identity59961 : scanCanonicalize (H12AffineFastState.compose env59961 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59961 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59962 : List Nat := [2,4,8,16,32,64,128,182,0,237,49,122,218,42,96,88,42,162,236,96,233,210,65,138,83,16,195,43,122,81,94,32,182,211,42,0]

theorem envBound59962 : H12AffineFastState.Bounded env59962 := by
  intro p hp
  have h : env59962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59961_59962 : H12AffineEnvironment.transform 7 182 env59961 = env59962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59961 == env59962) = true)

theorem identity59962 : scanCanonicalize (H12AffineFastState.compose env59962 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59962 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59963 : List Nat := [2,4,8,16,32,64,114,68,0,31,49,122,40,42,96,88,42,80,30,96,27,32,65,120,83,16,49,43,122,81,94,32,68,33,42,0]

theorem envBound59963 : H12AffineFastState.Bounded env59963 := by
  intro p hp
  have h : env59963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59962_59963 : H12AffineEnvironment.transform 6 114 env59962 = env59963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59962 == env59963) = true)

def env59964 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9664,3159,1288,9617,2365812,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59964 : H12AffineFastState.Bounded env59964 := by
  intro p hp
  have h : env59964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59940_59964 : H12AffineEnvironment.transform 8 1 env59940 = env59964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59940 == env59964) = true)

theorem identity59964 : scanCanonicalize (H12AffineFastState.compose env59964 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 2264) := by decide +kernel

theorem selectedBound59964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59965 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2264,1417,9664,3159,1288,9617,266668,4177,77954,66899,65542,68094,256,65675,78034,9600]

theorem envBound59965 : H12AffineFastState.Bounded env59965 := by
  intro p hp
  have h : env59965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59964_59965 : H12AffineEnvironment.transform 20 2264 env59964 = env59965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2264 env59964 == env59965) = true)

def env59966 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,2264,1417,64,3159,1288,17,266668,4177,70914,66899,65542,68094,256,65675,70994,0]

theorem envBound59966 : H12AffineFastState.Bounded env59966 := by
  intro p hp
  have h : env59966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59965_59966 : H12AffineEnvironment.transform 12 1408 env59965 = env59966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59965 == env59966) = true)

theorem identity59966 : scanCanonicalize (H12AffineFastState.compose env59966 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 293) := by decide +kernel

theorem selectedBound59966 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59967 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,293,1408,373,2128,65536,66679,262144,1025,2128,2264,1417,64,3159,1288,17,262281,372,66599,66899,65542,68094,256,65675,66679,0]

theorem envBound59967 : H12AffineFastState.Bounded env59967 := by
  intro p hp
  have h : env59967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59966_59967 : H12AffineEnvironment.transform 11 293 env59966 = env59967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 293 env59966 == env59967) = true)

theorem identity59967 : scanCanonicalize (H12AffineFastState.compose env59967 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound59967 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env59968 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,293,1408,373,1448,65536,66679,262144,1025,1448,1312,1417,64,431,1288,17,262281,372,66599,66899,65542,66566,256,65675,66679,0]

theorem envBound59968 : H12AffineFastState.Bounded env59968 := by
  intro p hp
  have h : env59968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59967_59968 : H12AffineEnvironment.transform 10 1528 env59967 = env59968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env59967 == env59968) = true)

theorem identity59968 : scanCanonicalize (H12AffineFastState.compose env59968 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 67019) := by decide +kernel

theorem selectedBound59968 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env59969 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,293,1408,373,1448,65536,66679,67019,1025,1448,1312,1417,64,431,1288,17,66882,372,66599,66899,65542,66566,256,65675,66679,0]

theorem envBound59969 : H12AffineFastState.Bounded env59969 := by
  intro p hp
  have h : env59969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59968_59969 : H12AffineEnvironment.transform 17 67019 env59968 = env59969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67019 env59968 == env59969) = true)

theorem identity59969 : scanCanonicalize (H12AffineFastState.compose env59969 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound59969 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env59970 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,293,1408,373,1448,1062,81,493,1025,1448,1312,1417,64,431,1288,17,356,372,1,373,1056,32,256,1197,81,0]

theorem envBound59970 : H12AffineFastState.Bounded env59970 := by
  intro p hp
  have h : env59970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59969_59970 : H12AffineEnvironment.transform 15 1062 env59969 = env59970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env59969 == env59970) = true)

theorem identity59970 : scanCanonicalize (H12AffineFastState.compose env59970 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound59970 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env59971 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1029,216,1149,136,1109,1062,81,16,1025,1109,1245,1140,64,82,1269,17,153,137,1,136,1056,32,253,1197,81,0]

theorem envBound59971 : H12AffineFastState.Bounded env59971 := by
  intro p hp
  have h : env59971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59970_59971 : H12AffineEnvironment.transform 7 253 env59970 = env59971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env59970 == env59971) = true)

theorem identity59971 : scanCanonicalize (H12AffineFastState.compose env59971 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound59971 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env59972 : List Nat := [2,4,8,16,32,64,128,253,1,141,136,216,240,136,216,171,81,16,140,216,80,249,64,82,120,17,153,137,1,136,173,32,253,32,81,0]

theorem envBound59972 : H12AffineFastState.Bounded env59972 := by
  intro p hp
  have h : env59972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59971_59972 : H12AffineEnvironment.transform 9 141 env59971 = env59972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env59971 == env59972) = true)

theorem identity59972 : scanCanonicalize (H12AffineFastState.compose env59972 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound59972 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env59973 : List Nat := [2,4,8,16,32,16,128,173,1,141,136,136,160,136,136,171,1,16,140,136,0,169,16,2,40,17,153,137,1,136,173,32,173,32,1,0]

theorem envBound59973 : H12AffineFastState.Bounded env59973 := by
  intro p hp
  have h : env59973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59972_59973 : H12AffineEnvironment.transform 5 16 env59972 = env59973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env59972 == env59973) = true)

theorem identity59973 : scanCanonicalize (H12AffineFastState.compose env59973 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound59973 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env59974 : List Nat := [2,4,8,3,32,3,128,173,1,141,136,136,160,136,136,171,1,3,140,136,0,169,3,2,40,2,138,137,1,136,173,32,173,32,1,0]

theorem envBound59974 : H12AffineFastState.Bounded env59974 := by
  intro p hp
  have h : env59974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59973_59974 : H12AffineEnvironment.transform 3 3 env59973 = env59974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env59973 == env59974) = true)

theorem identity59974 : scanCanonicalize (H12AffineFastState.compose env59974 (packedSelected [3,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound59974 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env59975 : List Nat := [2,4,8,3,32,3,42,7,1,39,34,34,10,34,34,1,1,3,38,34,0,3,3,2,40,2,32,35,1,34,7,32,7,32,1,0]

theorem envBound59975 : H12AffineFastState.Bounded env59975 := by
  intro p hp
  have h : env59975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59974_59975 : H12AffineEnvironment.transform 6 42 env59974 = env59975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env59974 == env59975) = true)

theorem identity59975 : scanCanonicalize (H12AffineFastState.compose env59975 (packedSelected [1,3,4] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound59975 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env59976 : List Nat := [2,4,0,3,32,3,34,7,1,39,34,34,2,34,34,1,1,3,38,34,0,3,3,2,32,2,32,35,1,34,7,32,7,32,1,0]

theorem envBound59976 : H12AffineFastState.Bounded env59976 := by
  intro p hp
  have h : env59976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59975_59976 : H12AffineEnvironment.transform 2 0 env59975 = env59976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env59975 == env59976) = true)

theorem identity59976 : scanCanonicalize (H12AffineFastState.compose env59976 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound59976 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env59977 : List Nat := [2,4,0,3,0,3,2,7,1,7,2,2,2,2,2,1,1,3,6,2,0,3,3,2,0,2,0,3,1,2,7,0,7,0,1,0]

theorem envBound59977 : H12AffineFastState.Bounded env59977 := by
  intro p hp
  have h : env59977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59976_59977 : H12AffineEnvironment.transform 4 0 env59976 = env59977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env59976 == env59977) = true)

theorem identity59977 : scanCanonicalize (H12AffineFastState.compose env59977 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound59977 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env59978 : List Nat := [1,4,0,0,0,0,1,4,1,4,1,1,1,1,1,1,1,0,5,1,0,0,0,1,0,1,0,0,1,1,4,0,4,0,1,0]

theorem envBound59978 : H12AffineFastState.Bounded env59978 := by
  intro p hp
  have h : env59978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59977_59978 : H12AffineEnvironment.transform 0 1 env59977 = env59978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env59977 == env59978) = true)

def env59979 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,2264,1417,65,3159,1288,16,266668,4177,70915,66899,65542,68094,256,65675,70995,1]

theorem envBound59979 : H12AffineFastState.Bounded env59979 := by
  intro p hp
  have h : env59979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59965_59979 : H12AffineEnvironment.transform 12 1409 env59965 = env59979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59965 == env59979) = true)

theorem identity59979 : scanCanonicalize (H12AffineFastState.compose env59979 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4131) := by decide +kernel

theorem selectedBound59979 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59980 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4131,1392,262144,1025,2128,2264,1417,65,3159,1288,16,266668,4177,1312,5488,4133,6621,256,4264,1392,1]

theorem envBound59980 : H12AffineFastState.Bounded env59980 := by
  intro p hp
  have h : env59980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59979_59980 : H12AffineEnvironment.transform 15 4131 env59979 = env59980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4131 env59979 == env59980) = true)

theorem identity59980 : scanCanonicalize (H12AffineFastState.compose env59980 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound59980 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59981 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4131,1392,277,1025,2128,2264,1417,65,3159,1288,16,4281,4177,1312,5488,4133,6621,256,4264,1392,1]

theorem envBound59981 : H12AffineFastState.Bounded env59981 := by
  intro p hp
  have h : env59981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59980_59981 : H12AffineEnvironment.transform 17 277 env59980 = env59981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env59980 == env59981) = true)

theorem identity59981 : scanCanonicalize (H12AffineFastState.compose env59981 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound59981 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59982 : List Nat := [2,4,8,16,32,64,128,256,1,237,2048,4096,364,4176,2128,4131,413,277,236,2128,2264,356,65,2234,485,16,4281,4177,461,4509,4133,6621,256,4264,413,1]

theorem envBound59982 : H12AffineFastState.Bounded env59982 := by
  intro p hp
  have h : env59982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59981_59982 : H12AffineEnvironment.transform 9 237 env59981 = env59982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env59981 == env59982) = true)

theorem identity59982 : scanCanonicalize (H12AffineFastState.compose env59982 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2557) := by decide +kernel

theorem selectedBound59982 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59983 : List Nat := [2,4,8,16,32,64,128,256,1,237,2048,2557,364,2477,2128,2526,413,277,236,2128,2264,356,65,2234,485,16,2372,2476,461,2144,2520,32,256,2389,413,1]

theorem envBound59983 : H12AffineFastState.Bounded env59983 := by
  intro p hp
  have h : env59983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59982_59983 : H12AffineEnvironment.transform 11 2557 env59982 = env59983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2557 env59982 == env59983) = true)

theorem identity59983 : scanCanonicalize (H12AffineFastState.compose env59983 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound59983 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env59984 : List Nat := [2,4,8,16,32,64,128,256,1,237,48,461,364,413,96,494,413,277,236,96,232,356,65,138,485,16,372,412,461,80,488,32,256,357,413,1]

theorem envBound59984 : H12AffineFastState.Bounded env59984 := by
  intro p hp
  have h : env59984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59983_59984 : H12AffineEnvironment.transform 10 48 env59983 = env59984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env59983 == env59984) = true)

theorem identity59984 : scanCanonicalize (H12AffineFastState.compose env59984 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound59984 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env59985 : List Nat := [2,4,8,16,32,64,128,182,1,237,48,123,218,43,96,88,43,163,236,96,232,210,65,138,83,16,194,42,123,80,94,32,182,211,43,1]

theorem envBound59985 : H12AffineFastState.Bounded env59985 := by
  intro p hp
  have h : env59985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59984_59985 : H12AffineEnvironment.transform 7 182 env59984 = env59985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env59984 == env59985) = true)

theorem identity59985 : scanCanonicalize (H12AffineFastState.compose env59985 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59985 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59986 : List Nat := [2,4,8,16,32,64,114,68,1,31,48,123,40,43,96,88,43,81,30,96,26,32,65,120,83,16,48,42,123,80,94,32,68,33,43,1]

theorem envBound59986 : H12AffineFastState.Bounded env59986 := by
  intro p hp
  have h : env59986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59985_59986 : H12AffineEnvironment.transform 6 114 env59985 = env59986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59985 == env59986) = true)

def env59987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9665,3671,1289,9616,2366325,4177,77954,67410,65543,68606,256,65675,78034,10112]

theorem envBound59987 : H12AffineFastState.Bounded env59987 := by
  intro p hp
  have h : env59987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59939_59987 : H12AffineEnvironment.transform 22 9665 env59939 = env59987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env59939 == env59987) = true)

def env59988 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2365813,4177,77954,66898,65543,68094,256,65675,78034,9600]

theorem envBound59988 : H12AffineFastState.Bounded env59988 := by
  intro p hp
  have h : env59988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59987_59988 : H12AffineEnvironment.transform 8 0 env59987 = env59988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env59987 == env59988) = true)

theorem identity59988 : scanCanonicalize (H12AffineFastState.compose env59988 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound59988 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env59989 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,8192,216,2129,65536,73818,262144,1025,2129,2097152,1417,9665,3159,1289,9616,2361853,217,73738,66898,65543,68094,256,65675,73818,9600]

theorem envBound59989 : H12AffineFastState.Bounded env59989 := by
  intro p hp
  have h : env59989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59988_59989 : H12AffineEnvironment.transform 11 136 env59988 = env59989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env59988 == env59989) = true)

def env59990 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2129,65536,67034,262144,1025,2129,2097152,1417,65,3159,1289,16,2361853,217,66954,66898,65543,68094,256,65675,67034,0]

theorem envBound59990 : H12AffineFastState.Bounded env59990 := by
  intro p hp
  have h : env59990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59989_59990 : H12AffineEnvironment.transform 12 1408 env59989 = env59990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env59989 == env59990) = true)

theorem identity59990 : scanCanonicalize (H12AffineFastState.compose env59990 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound59990 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59991 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2129,65536,67034,262144,1025,2129,67699,1417,65,3159,1289,16,328078,217,66954,66898,65543,68094,256,65675,67034,0]

theorem envBound59991 : H12AffineFastState.Bounded env59991 := by
  intro p hp
  have h : env59991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59990_59991 : H12AffineEnvironment.transform 20 67699 env59990 = env59991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env59990 == env59991) = true)

theorem identity59991 : scanCanonicalize (H12AffineFastState.compose env59991 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound59991 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env59992 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2129,65536,67034,65982,1025,2129,67699,1417,65,3159,1289,16,48,217,66954,66898,65543,68094,256,65675,67034,0]

theorem envBound59992 : H12AffineFastState.Bounded env59992 := by
  intro p hp
  have h : env59992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59991_59992 : H12AffineEnvironment.transform 17 65982 env59991 = env59992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env59991 == env59992) = true)

theorem identity59992 : scanCanonicalize (H12AffineFastState.compose env59992 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound59992 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env59993 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1408,216,2129,1094,412,1528,1025,2129,3125,1417,65,3159,1289,16,48,217,460,276,1089,3512,256,1229,412,0]

theorem envBound59993 : H12AffineFastState.Bounded env59993 := by
  intro p hp
  have h : env59993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59992_59993 : H12AffineEnvironment.transform 15 1094 env59992 = env59993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env59992 == env59993) = true)

theorem identity59993 : scanCanonicalize (H12AffineFastState.compose env59993 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound59993 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env59994 : List Nat := [2,4,8,16,32,64,128,68,0,1024,2048,136,1220,216,2129,1094,216,1212,1025,2129,3125,1229,65,3159,1101,16,48,217,136,80,1089,3324,68,1229,216,0]

theorem envBound59994 : H12AffineFastState.Bounded env59994 := by
  intro p hp
  have h : env59994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59993_59994 : H12AffineEnvironment.transform 7 68 env59993 = env59994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env59993 == env59994) = true)

theorem identity59994 : scanCanonicalize (H12AffineFastState.compose env59994 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound59994 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env59995 : List Nat := [2,4,8,16,32,64,114,68,0,1024,2048,122,1078,42,2129,1094,42,1102,1025,2129,3125,1087,65,3159,1101,16,48,43,122,80,1089,3086,68,1087,42,0]

theorem envBound59995 : H12AffineFastState.Bounded env59995 := by
  intro p hp
  have h : env59995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59994_59995 : H12AffineEnvironment.transform 6 114 env59994 = env59995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env59994 == env59995) = true)

theorem identity59995 : scanCanonicalize (H12AffineFastState.compose env59995 (packedSelected [0,3,10] rootPS)) = affineNative (2^(10+1) ^^^ 1071) := by decide +kernel

theorem selectedBound59995 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env59996 : List Nat := [2,4,8,16,32,64,114,68,0,1024,1071,122,1078,42,1150,1094,42,1102,1025,1150,26,1087,65,120,1101,16,48,43,122,80,1089,33,68,1087,42,0]

theorem envBound59996 : H12AffineFastState.Bounded env59996 := by
  intro p hp
  have h : env59996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59995_59996 : H12AffineEnvironment.transform 10 1071 env59995 = env59996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1071 env59995 == env59996) = true)

theorem identity59996 : scanCanonicalize (H12AffineFastState.compose env59996 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 31) := by decide +kernel

theorem selectedBound59996 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env59997 : List Nat := [2,4,8,16,32,64,114,68,0,31,48,122,41,42,97,89,42,81,30,97,26,32,65,120,82,16,48,43,122,80,94,33,68,32,42,0]

theorem envBound59997 : H12AffineFastState.Bounded env59997 := by
  intro p hp
  have h : env59997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59996_59997 : H12AffineEnvironment.transform 9 31 env59996 = env59997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 31 env59996 == env59997) = true)

def env59998 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2097152,1417,64,3159,1289,17,2361853,217,66955,66898,65543,68094,256,65675,67035,1]

theorem envBound59998 : H12AffineFastState.Bounded env59998 := by
  intro p hp
  have h : env59998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59989_59998 : H12AffineEnvironment.transform 12 1409 env59989 = env59998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env59989 == env59998) = true)

theorem identity59998 : scanCanonicalize (H12AffineFastState.compose env59998 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2420) := by decide +kernel

theorem selectedBound59998 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env59999 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,136,1409,216,2129,65536,67035,262144,1025,2129,2420,1417,64,3159,1289,17,262281,217,66955,66898,65543,68094,256,65675,67035,1]

theorem envBound59999 : H12AffineFastState.Bounded env59999 := by
  intro p hp
  have h : env59999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59998_59999 : H12AffineEnvironment.transform 20 2420 env59998 = env59999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2420 env59998 == env59999) = true)

theorem identity59999 : scanCanonicalize (H12AffineFastState.compose env59999 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound59999 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60000 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,136,1409,216,1448,65536,67035,262144,1025,1448,1165,1417,64,430,1289,17,262281,217,66955,66898,65543,66567,256,65675,67035,1]

theorem envBound60000 : H12AffineFastState.Bounded env60000 := by
  intro p hp
  have h : env60000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59999_60000 : H12AffineEnvironment.transform 10 1529 env59999 = env60000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env59999 == env60000) = true)

theorem identity60000 : scanCanonicalize (H12AffineFastState.compose env60000 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66663) := by decide +kernel

theorem selectedBound60000 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60001 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,136,1409,216,1448,65536,67035,66663,1025,1448,1165,1417,64,430,1289,17,66798,217,66955,66898,65543,66567,256,65675,67035,1]

theorem envBound60001 : H12AffineFastState.Bounded env60001 := by
  intro p hp
  have h : env60001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60000_60001 : H12AffineEnvironment.transform 17 66663 env60000 = env60001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66663 env60000 == env60001) = true)

theorem identity60001 : scanCanonicalize (H12AffineFastState.compose env60001 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound60001 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60002 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1529,136,1409,216,1448,1062,509,65,1025,1448,1165,1417,64,430,1289,17,200,217,429,372,1057,33,256,1197,509,1]

theorem envBound60002 : H12AffineFastState.Bounded env60002 := by
  intro p hp
  have h : env60002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60001_60002 : H12AffineEnvironment.transform 15 1062 env60001 = env60002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env60001 == env60002) = true)

theorem identity60002 : scanCanonicalize (H12AffineFastState.compose env60002 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60002 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60003 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1028,136,1148,216,1109,1062,0,65,1025,1109,1165,1140,64,83,1268,17,200,217,80,137,1057,33,253,1197,0,1]

theorem envBound60003 : H12AffineFastState.Bounded env60003 := by
  intro p hp
  have h : env60003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60002_60003 : H12AffineEnvironment.transform 7 253 env60002 = env60003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60002 == env60003) = true)

theorem identity60003 : scanCanonicalize (H12AffineFastState.compose env60003 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound60003 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60004 : List Nat := [2,4,8,16,32,64,128,253,0,140,136,136,240,216,217,170,0,65,141,217,1,248,64,83,120,17,200,217,80,137,173,33,253,33,0,1]

theorem envBound60004 : H12AffineFastState.Bounded env60004 := by
  intro p hp
  have h : env60004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60003_60004 : H12AffineEnvironment.transform 9 140 env60003 = env60004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env60003 == env60004) = true)

theorem identity60004 : scanCanonicalize (H12AffineFastState.compose env60004 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound60004 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60005 : List Nat := [2,4,8,16,32,64,40,85,0,36,32,32,88,112,113,2,0,65,37,113,1,80,64,83,120,17,96,113,80,33,5,33,85,33,0,1]

theorem envBound60005 : H12AffineFastState.Bounded env60005 := by
  intro p hp
  have h : env60005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60004_60005 : H12AffineEnvironment.transform 6 40 env60004 = env60005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env60004 == env60005) = true)

theorem identity60005 : scanCanonicalize (H12AffineFastState.compose env60005 (packedSelected [0,3,5] rootPS)) = affineNative (2^(4+1) ^^^ 24) := by decide +kernel

theorem selectedBound60005 : packedSelected [0,3,5] rootPS < 2^1333 := by decide +kernel

def env60006 : List Nat := [2,4,8,16,24,64,16,85,0,28,24,24,88,72,73,2,0,65,29,73,1,80,64,83,64,17,88,73,80,25,5,25,85,25,0,1]

theorem envBound60006 : H12AffineFastState.Bounded env60006 := by
  intro p hp
  have h : env60006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60005_60006 : H12AffineEnvironment.transform 4 24 env60005 = env60006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 24 env60005 == env60006) = true)

theorem identity60006 : scanCanonicalize (H12AffineFastState.compose env60006 (packedSelected [1,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound60006 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60007 : List Nat := [2,4,8,16,24,10,16,31,0,28,24,24,18,2,3,2,0,11,29,3,1,26,10,25,10,17,18,3,26,25,5,25,31,25,0,1]

theorem envBound60007 : H12AffineFastState.Bounded env60007 := by
  intro p hp
  have h : env60007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60006_60007 : H12AffineEnvironment.transform 5 10 env60006 = env60007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env60006 == env60007) = true)

theorem identity60007 : scanCanonicalize (H12AffineFastState.compose env60007 (packedSelected [0,1,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60007 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env60008 : List Nat := [1,4,8,16,24,9,16,28,0,28,24,24,17,1,0,1,0,8,29,0,1,25,9,25,9,17,17,0,25,25,5,25,28,25,0,1]

theorem envBound60008 : H12AffineFastState.Bounded env60008 := by
  intro p hp
  have h : env60008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60007_60008 : H12AffineEnvironment.transform 0 1 env60007 = env60008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60007 == env60008) = true)

theorem identity60008 : scanCanonicalize (H12AffineFastState.compose env60008 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60008 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60009 : List Nat := [1,4,8,0,8,9,0,12,0,12,8,8,1,1,0,1,0,8,13,0,1,9,9,9,9,1,1,0,9,9,5,9,12,9,0,1]

theorem envBound60009 : H12AffineFastState.Bounded env60009 := by
  intro p hp
  have h : env60009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60008_60009 : H12AffineEnvironment.transform 3 0 env60008 = env60009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60008 == env60009) = true)

def env60010 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1417,9665,3158,1289,9616,2365812,4177,77954,66899,65543,68095,256,65675,78034,9601]

theorem envBound60010 : H12AffineFastState.Bounded env60010 := by
  intro p hp
  have h : env60010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59987_60010 : H12AffineEnvironment.transform 8 1 env59987 = env60010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env59987 == env60010) = true)

theorem identity60010 : scanCanonicalize (H12AffineFastState.compose env60010 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 5385) := by decide +kernel

theorem selectedBound60010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60011 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,5385,4176,2128,65536,67035,262144,1025,2128,2097152,1417,4296,3158,1289,4249,2365812,4177,66955,66899,65543,68095,256,65675,67035,4232]

theorem envBound60011 : H12AffineFastState.Bounded env60011 := by
  intro p hp
  have h : env60011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60010_60011 : H12AffineEnvironment.transform 12 5385 env60010 = env60011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5385 env60010 == env60011) = true)

def env60012 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2097152,1417,64,3158,1289,17,2361852,217,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound60012 : H12AffineFastState.Bounded env60012 := by
  intro p hp
  have h : env60012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60011_60012 : H12AffineEnvironment.transform 11 136 env60011 = env60012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env60011 == env60012) = true)

theorem identity60012 : scanCanonicalize (H12AffineFastState.compose env60012 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2421) := by decide +kernel

theorem selectedBound60012 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60013 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,2421,1417,64,3158,1289,17,262281,217,66955,66899,65543,68095,256,65675,67035,0]

theorem envBound60013 : H12AffineFastState.Bounded env60013 := by
  intro p hp
  have h : env60013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60012_60013 : H12AffineEnvironment.transform 20 2421 env60012 = env60013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2421 env60012 == env60013) = true)

theorem identity60013 : scanCanonicalize (H12AffineFastState.compose env60013 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60013 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60014 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,136,1409,216,1448,65536,67035,262144,1025,1448,1165,1417,64,430,1289,17,262281,217,66955,66899,65543,66567,256,65675,67035,0]

theorem envBound60014 : H12AffineFastState.Bounded env60014 := by
  intro p hp
  have h : env60014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60013_60014 : H12AffineEnvironment.transform 10 1528 env60013 = env60014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60013 == env60014) = true)

theorem identity60014 : scanCanonicalize (H12AffineFastState.compose env60014 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 66663) := by decide +kernel

theorem selectedBound60014 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60015 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,136,1409,216,1448,65536,67035,66663,1025,1448,1165,1417,64,430,1289,17,66798,217,66955,66899,65543,66567,256,65675,67035,0]

theorem envBound60015 : H12AffineFastState.Bounded env60015 := by
  intro p hp
  have h : env60015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60014_60015 : H12AffineEnvironment.transform 17 66663 env60014 = env60015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 66663 env60014 == env60015) = true)

theorem identity60015 : scanCanonicalize (H12AffineFastState.compose env60015 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(15+1) ^^^ 1062) := by decide +kernel

theorem selectedBound60015 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60016 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1528,136,1409,216,1448,1062,509,65,1025,1448,1165,1417,64,430,1289,17,200,217,429,373,1057,33,256,1197,509,0]

theorem envBound60016 : H12AffineFastState.Bounded env60016 := by
  intro p hp
  have h : env60016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60015_60016 : H12AffineEnvironment.transform 15 1062 env60015 = env60016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1062 env60015 == env60016) = true)

theorem identity60016 : scanCanonicalize (H12AffineFastState.compose env60016 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60016 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60017 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1028,136,1149,216,1108,1062,1,65,1025,1108,1165,1141,64,82,1269,17,200,217,81,137,1057,33,252,1197,1,0]

theorem envBound60017 : H12AffineFastState.Bounded env60017 := by
  intro p hp
  have h : env60017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60016_60017 : H12AffineEnvironment.transform 7 252 env60016 = env60017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60016 == env60017) = true)

theorem identity60017 : scanCanonicalize (H12AffineFastState.compose env60017 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound60017 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60018 : List Nat := [2,4,8,16,32,17,128,173,1,1024,1028,136,1068,137,1029,1062,1,16,1025,1029,1165,1060,17,3,1188,17,153,136,0,137,1057,33,173,1197,1,0]

theorem envBound60018 : H12AffineFastState.Bounded env60018 := by
  intro p hp
  have h : env60018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60017_60018 : H12AffineEnvironment.transform 5 17 env60017 = env60018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env60017 == env60018) = true)

theorem identity60018 : scanCanonicalize (H12AffineFastState.compose env60018 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 175) := by decide +kernel

theorem selectedBound60018 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60019 : List Nat := [2,4,8,16,32,17,128,173,1,175,171,136,131,137,170,137,1,16,174,170,34,139,17,3,11,17,153,136,0,137,142,33,173,2,1,0]

theorem envBound60019 : H12AffineFastState.Bounded env60019 := by
  intro p hp
  have h : env60019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60018_60019 : H12AffineEnvironment.transform 9 175 env60018 = env60019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 175 env60018 == env60019) = true)

theorem identity60019 : scanCanonicalize (H12AffineFastState.compose env60019 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound60019 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60020 : List Nat := [2,4,8,16,3,17,128,142,1,140,136,136,131,137,137,137,1,16,141,137,1,139,17,3,11,17,153,136,0,137,142,2,142,2,1,0]

theorem envBound60020 : H12AffineFastState.Bounded env60020 := by
  intro p hp
  have h : env60020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60019_60020 : H12AffineEnvironment.transform 4 3 env60019 = env60020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env60019 == env60020) = true)

theorem identity60020 : scanCanonicalize (H12AffineFastState.compose env60020 (packedSelected [3,4,5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60020 : packedSelected [3,4,5] rootPS < 2^1333 := by decide +kernel

def env60021 : List Nat := [1,4,8,16,0,17,128,141,1,140,136,136,128,137,137,137,1,16,141,137,1,136,17,0,8,17,153,136,0,137,141,1,141,1,1,0]

theorem envBound60021 : H12AffineFastState.Bounded env60021 := by
  intro p hp
  have h : env60021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60020_60021 : H12AffineEnvironment.transform 0 1 env60020 = env60021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60020 == env60021) = true)

theorem identity60021 : scanCanonicalize (H12AffineFastState.compose env60021 (packedSelected [4] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound60021 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60022 : List Nat := [1,4,8,16,0,17,16,29,1,28,24,24,16,25,25,25,1,16,29,25,1,24,17,0,8,17,9,24,0,25,29,1,29,1,1,0]

theorem envBound60022 : H12AffineFastState.Bounded env60022 := by
  intro p hp
  have h : env60022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60021_60022 : H12AffineEnvironment.transform 6 16 env60021 = env60022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env60021 == env60022) = true)

theorem identity60022 : scanCanonicalize (H12AffineFastState.compose env60022 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60022 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60023 : List Nat := [1,4,8,0,0,1,0,13,1,12,8,8,0,9,9,9,1,0,13,9,1,8,1,0,8,1,9,8,0,9,13,1,13,1,1,0]

theorem envBound60023 : H12AffineFastState.Bounded env60023 := by
  intro p hp
  have h : env60023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60022_60023 : H12AffineEnvironment.transform 3 0 env60022 = env60023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60022 == env60023) = true)

theorem identity60023 : scanCanonicalize (H12AffineFastState.compose env60023 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound60023 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env60024 : List Nat := [1,4,0,0,0,1,0,5,1,4,0,0,0,1,1,1,1,0,5,1,1,0,1,0,0,1,1,0,0,1,5,1,5,1,1,0]

theorem envBound60024 : H12AffineFastState.Bounded env60024 := by
  intro p hp
  have h : env60024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60023_60024 : H12AffineEnvironment.transform 2 0 env60023 = env60024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env60023 == env60024) = true)

def env60025 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2128,65536,67035,262144,1025,2128,2097152,1417,65,3158,1289,16,2361853,216,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound60025 : H12AffineFastState.Bounded env60025 := by
  intro p hp
  have h : env60025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60011_60025 : H12AffineEnvironment.transform 11 137 env60011 = env60025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env60011 == env60025) = true)

theorem identity60025 : scanCanonicalize (H12AffineFastState.compose env60025 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 67699) := by decide +kernel

theorem selectedBound60025 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60026 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2128,65536,67035,262144,1025,2128,67699,1417,65,3158,1289,16,328078,216,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound60026 : H12AffineFastState.Bounded env60026 := by
  intro p hp
  have h : env60026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60025_60026 : H12AffineEnvironment.transform 20 67699 env60025 = env60026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67699 env60025 == env60026) = true)

theorem identity60026 : scanCanonicalize (H12AffineFastState.compose env60026 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound60026 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60027 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2128,65536,67035,65983,1025,2128,67699,1417,65,3158,1289,16,49,216,66955,66899,65543,68095,256,65675,67035,1]

theorem envBound60027 : H12AffineFastState.Bounded env60027 := by
  intro p hp
  have h : env60027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60026_60027 : H12AffineEnvironment.transform 17 65983 env60026 = env60027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env60026 == env60027) = true)

theorem identity60027 : scanCanonicalize (H12AffineFastState.compose env60027 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1094) := by decide +kernel

theorem selectedBound60027 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60028 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,137,1408,217,2128,1094,413,1529,1025,2128,3125,1417,65,3158,1289,16,49,216,461,277,1089,3513,256,1229,413,1]

theorem envBound60028 : H12AffineFastState.Bounded env60028 := by
  intro p hp
  have h : env60028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60027_60028 : H12AffineEnvironment.transform 15 1094 env60027 = env60028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1094 env60027 == env60028) = true)

theorem identity60028 : scanCanonicalize (H12AffineFastState.compose env60028 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1244) := by decide +kernel

theorem selectedBound60028 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60029 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1244,137,1408,217,1164,1094,413,1529,1025,1164,233,1417,65,138,1289,16,49,216,461,277,1089,357,256,1229,413,1]

theorem envBound60029 : H12AffineFastState.Bounded env60029 := by
  intro p hp
  have h : env60029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60028_60029 : H12AffineEnvironment.transform 10 1244 env60028 = env60029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1244 env60028 == env60029) = true)

theorem identity60029 : scanCanonicalize (H12AffineFastState.compose env60029 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 425) := by decide +kernel

theorem selectedBound60029 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env60030 : List Nat := [2,4,8,16,32,64,128,256,1,425,373,137,41,217,293,495,413,80,424,293,233,32,65,138,160,16,49,216,461,277,488,357,256,356,413,1]

theorem envBound60030 : H12AffineFastState.Bounded env60030 := by
  intro p hp
  have h : env60030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60029_60030 : H12AffineEnvironment.transform 9 425 env60029 = env60030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 425 env60029 == env60030) = true)

theorem identity60030 : scanCanonicalize (H12AffineFastState.compose env60030 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound60030 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60031 : List Nat := [2,4,8,16,32,64,128,69,1,236,48,137,41,217,96,170,216,80,237,96,233,32,65,138,160,16,49,216,136,80,173,32,69,33,216,1]

theorem envBound60031 : H12AffineFastState.Bounded env60031 := by
  intro p hp
  have h : env60031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60030_60031 : H12AffineEnvironment.transform 7 69 env60030 = env60031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env60030 == env60031) = true)

theorem identity60031 : scanCanonicalize (H12AffineFastState.compose env60031 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60031 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60032 : List Nat := [2,4,8,16,32,58,128,63,1,150,48,137,41,163,26,170,162,42,151,26,147,32,59,138,160,16,49,162,136,42,173,32,63,33,162,1]

theorem envBound60032 : H12AffineFastState.Bounded env60032 := by
  intro p hp
  have h : env60032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60031_60032 : H12AffineEnvironment.transform 5 58 env60031 = env60032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60031 == env60032) = true)

def env60033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,4194304,8388608,8399766,8397000,8388689,6561533,4177,77954,4260571,8463814,8465982,256,4261123,78034,8389185]

theorem envBound60033 : H12AffineFastState.Bounded env60033 := by
  intro p hp
  have h : env60033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans59845_60033 : H12AffineEnvironment.transform 26 6561533 env59845 = env60033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 6561533 env59845 == env60033) = true)

def env60034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,8388608,8399766,8397000,8388689,2366325,4177,77954,67411,8463814,8465982,256,65675,78034,8389185]

theorem envBound60034 : H12AffineFastState.Bounded env60034 := by
  intro p hp
  have h : env60034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60033_60034 : H12AffineEnvironment.transform 21 1416 env60033 = env60034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1416 env60033 == env60034) = true)

def env60035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9664,3670,1288,9617,2366325,4177,77954,67411,65542,68606,256,65675,78034,10113]

theorem envBound60035 : H12AffineFastState.Bounded env60035 := by
  intro p hp
  have h : env60035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60034_60035 : H12AffineEnvironment.transform 22 9664 env60034 = env60035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60034 == env60035) = true)

def env60036 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9664,3158,1288,9617,2365813,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound60036 : H12AffineFastState.Bounded env60036 := by
  intro p hp
  have h : env60036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60035_60036 : H12AffineEnvironment.transform 8 0 env60035 = env60036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60035 == env60036) = true)

theorem identity60036 : scanCanonicalize (H12AffineFastState.compose env60036 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 67698) := by decide +kernel

theorem selectedBound60036 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60037 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,67698,1416,9664,3158,1288,9617,332039,4177,77954,66899,65542,68094,256,65675,78034,9601]

theorem envBound60037 : H12AffineFastState.Bounded env60037 := by
  intro p hp
  have h : env60037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60036_60037 : H12AffineEnvironment.transform 20 67698 env60036 = env60037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 67698 env60036 == env60037) = true)

def env60038 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,65536,70994,262144,1025,2129,67698,1416,64,3158,1288,17,332039,4177,70914,66899,65542,68094,256,65675,70994,1]

theorem envBound60038 : H12AffineFastState.Bounded env60038 := by
  intro p hp
  have h : env60038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60037_60038 : H12AffineEnvironment.transform 12 1408 env60037 = env60038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60037 == env60038) = true)

theorem identity60038 : scanCanonicalize (H12AffineFastState.compose env60038 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound60038 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60039 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4494,1244,262144,1025,2129,6652,1416,64,3158,1288,17,262281,4177,1164,5341,4488,6256,256,4357,1244,1]

theorem envBound60039 : H12AffineFastState.Bounded env60039 := by
  intro p hp
  have h : env60039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60038_60039 : H12AffineEnvironment.transform 15 4494 env60038 = env60039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env60038 == env60039) = true)

theorem identity60039 : scanCanonicalize (H12AffineFastState.compose env60039 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60039 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60040 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,4494,1244,262144,1025,1449,5124,1416,64,430,1288,17,262281,4177,1164,5341,4488,5512,256,4357,1244,1]

theorem envBound60040 : H12AffineFastState.Bounded env60040 := by
  intro p hp
  have h : env60040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60039_60040 : H12AffineEnvironment.transform 10 1528 env60039 = env60040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60039 == env60040) = true)

theorem identity60040 : scanCanonicalize (H12AffineFastState.compose env60040 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound60040 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60041 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1408,4176,1449,4494,1244,1377,1025,1449,5124,1416,64,430,1288,17,1512,4177,1164,5341,4488,5512,256,4357,1244,1]

theorem envBound60041 : H12AffineFastState.Bounded env60041 := by
  intro p hp
  have h : env60041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60040_60041 : H12AffineEnvironment.transform 17 1377 env60040 = env60041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env60040 == env60041) = true)

theorem identity60041 : scanCanonicalize (H12AffineFastState.compose env60041 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound60041 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60042 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1449,1408,1529,1449,1063,1244,1377,1025,1449,429,1416,64,430,1288,17,1512,1528,1164,372,1057,33,256,1196,1244,1]

theorem envBound60042 : H12AffineFastState.Bounded env60042 := by
  intro p hp
  have h : env60042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60041_60042 : H12AffineEnvironment.transform 11 1449 env60041 = env60042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env60041 == env60042) = true)

theorem identity60042 : scanCanonicalize (H12AffineFastState.compose env60042 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60042 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60043 : List Nat := [2,4,8,16,32,64,128,253,0,1024,1029,1108,1149,1028,1108,1063,1244,1180,1025,1108,80,1141,64,83,1269,17,1045,1029,1164,137,1057,33,253,1196,1244,1]

theorem envBound60043 : H12AffineFastState.Bounded env60043 := by
  intro p hp
  have h : env60043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60042_60043 : H12AffineEnvironment.transform 7 253 env60042 = env60043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60042 == env60043) = true)

theorem identity60043 : scanCanonicalize (H12AffineFastState.compose env60043 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60043 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60044 : List Nat := [2,4,8,16,32,16,128,173,0,1024,1029,1028,1069,1028,1028,1063,1164,1180,1025,1028,0,1061,16,3,1189,17,1045,1029,1164,137,1057,33,173,1196,1164,1]

theorem envBound60044 : H12AffineFastState.Bounded env60044 := by
  intro p hp
  have h : env60044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60043_60044 : H12AffineEnvironment.transform 5 16 env60043 = env60044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60043 == env60044) = true)

theorem identity60044 : scanCanonicalize (H12AffineFastState.compose env60044 (packedSelected [0,6] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60044 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60045 : List Nat := [0,4,8,16,32,16,128,173,0,1024,1029,1028,1069,1028,1028,1061,1164,1180,1025,1028,0,1061,16,1,1189,17,1045,1029,1164,137,1057,33,173,1196,1164,1]

theorem envBound60045 : H12AffineFastState.Bounded env60045 := by
  intro p hp
  have h : env60045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60044_60045 : H12AffineEnvironment.transform 0 0 env60044 = env60045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60044 == env60045) = true)

theorem identity60045 : scanCanonicalize (H12AffineFastState.compose env60045 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound60045 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60046 : List Nat := [0,4,8,16,32,16,128,173,0,5,0,1,40,1,1,32,137,153,4,1,0,32,16,1,160,17,16,0,137,137,36,33,173,169,137,1]

theorem envBound60046 : H12AffineFastState.Bounded env60046 := by
  intro p hp
  have h : env60046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60045_60046 : H12AffineEnvironment.transform 9 5 env60045 = env60046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env60045 == env60046) = true)

theorem identity60046 : scanCanonicalize (H12AffineFastState.compose env60046 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound60046 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60047 : List Nat := [0,4,8,1,32,1,128,173,0,5,0,1,40,1,1,32,137,136,4,1,0,32,1,1,160,0,1,0,137,137,36,33,173,169,137,1]

theorem envBound60047 : H12AffineFastState.Bounded env60047 := by
  intro p hp
  have h : env60047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60046_60047 : H12AffineEnvironment.transform 3 1 env60046 = env60047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env60046 == env60047) = true)

theorem identity60047 : scanCanonicalize (H12AffineFastState.compose env60047 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound60047 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60048 : List Nat := [0,4,8,1,32,1,8,37,0,5,0,1,40,1,1,32,1,0,4,1,0,32,1,1,40,0,1,0,1,1,36,33,37,33,1,1]

theorem envBound60048 : H12AffineFastState.Bounded env60048 := by
  intro p hp
  have h : env60048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60047_60048 : H12AffineEnvironment.transform 6 8 env60047 = env60048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env60047 == env60048) = true)

theorem identity60048 : scanCanonicalize (H12AffineFastState.compose env60048 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound60048 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env60049 : List Nat := [0,4,8,1,0,1,8,5,0,5,0,1,8,1,1,0,1,0,4,1,0,0,1,1,8,0,1,0,1,1,4,1,5,1,1,1]

theorem envBound60049 : H12AffineFastState.Bounded env60049 := by
  intro p hp
  have h : env60049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60048_60049 : H12AffineEnvironment.transform 4 0 env60048 = env60049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env60048 == env60049) = true)

theorem identity60049 : scanCanonicalize (H12AffineFastState.compose env60049 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60049 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60050 : List Nat := [0,4,1,1,0,1,1,5,0,5,0,1,1,1,1,0,1,0,4,1,0,0,1,1,1,0,1,0,1,1,4,1,5,1,1,1]

theorem envBound60050 : H12AffineFastState.Bounded env60050 := by
  intro p hp
  have h : env60050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60049_60050 : H12AffineEnvironment.transform 2 1 env60049 = env60050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60049 == env60050) = true)

def env60051 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,65536,70995,262144,1025,2129,67698,1416,65,3158,1288,16,332039,4177,70915,66899,65542,68094,256,65675,70995,0]

theorem envBound60051 : H12AffineFastState.Bounded env60051 := by
  intro p hp
  have h : env60051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60037_60051 : H12AffineEnvironment.transform 12 1409 env60037 = env60051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60037 == env60051) = true)

theorem identity60051 : scanCanonicalize (H12AffineFastState.compose env60051 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 137) := by decide +kernel

theorem selectedBound60051 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60052 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1409,217,2129,65536,67034,262144,1025,2129,67698,1416,65,3158,1288,16,328078,216,66954,66899,65542,68094,256,65675,67034,0]

theorem envBound60052 : H12AffineFastState.Bounded env60052 := by
  intro p hp
  have h : env60052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60051_60052 : H12AffineEnvironment.transform 11 137 env60051 = env60052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 137 env60051 == env60052) = true)

theorem identity60052 : scanCanonicalize (H12AffineFastState.compose env60052 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65982) := by decide +kernel

theorem selectedBound60052 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60053 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1409,217,2129,65536,67034,65982,1025,2129,67698,1416,65,3158,1288,16,48,216,66954,66899,65542,68094,256,65675,67034,0]

theorem envBound60053 : H12AffineFastState.Bounded env60053 := by
  intro p hp
  have h : env60053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60052_60053 : H12AffineEnvironment.transform 17 65982 env60052 = env60053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65982 env60052 == env60053) = true)

theorem identity60053 : scanCanonicalize (H12AffineFastState.compose env60053 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound60053 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60054 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,137,1409,217,2129,1095,413,1529,1025,2129,3125,1416,65,3158,1288,16,48,216,461,276,1089,3513,256,1228,413,0]

theorem envBound60054 : H12AffineFastState.Bounded env60054 := by
  intro p hp
  have h : env60054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60053_60054 : H12AffineEnvironment.transform 15 1095 env60053 = env60054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env60053 == env60054) = true)

theorem identity60054 : scanCanonicalize (H12AffineFastState.compose env60054 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound60054 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env60055 : List Nat := [2,4,8,16,32,64,128,68,0,1024,2048,137,1221,217,2129,1095,217,1213,1025,2129,3125,1228,65,3158,1100,16,48,216,137,80,1089,3325,68,1228,217,0]

theorem envBound60055 : H12AffineFastState.Bounded env60055 := by
  intro p hp
  have h : env60055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60054_60055 : H12AffineEnvironment.transform 7 68 env60054 = env60055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env60054 == env60055) = true)

theorem identity60055 : scanCanonicalize (H12AffineFastState.compose env60055 (packedSelected [0,5] rootPS)) = affineNative (2^(10+1) ^^^ 1070) := by decide +kernel

theorem selectedBound60055 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60056 : List Nat := [2,4,8,16,32,64,128,68,0,1024,1070,137,1221,217,1151,1095,217,1213,1025,1151,27,1228,65,120,1100,16,48,216,137,80,1089,211,68,1228,217,0]

theorem envBound60056 : H12AffineFastState.Bounded env60056 := by
  intro p hp
  have h : env60056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60055_60056 : H12AffineEnvironment.transform 10 1070 env60055 = env60056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1070 env60055 == env60056) = true)

theorem identity60056 : scanCanonicalize (H12AffineFastState.compose env60056 (packedSelected [0,3,10] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60056 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env60057 : List Nat := [2,4,8,16,32,64,114,68,0,1024,1070,123,1079,43,1151,1095,43,1103,1025,1151,27,1086,65,120,1100,16,48,42,123,80,1089,33,68,1086,43,0]

theorem envBound60057 : H12AffineFastState.Bounded env60057 := by
  intro p hp
  have h : env60057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60056_60057 : H12AffineEnvironment.transform 6 114 env60056 = env60057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60056 == env60057) = true)

theorem identity60057 : scanCanonicalize (H12AffineFastState.compose env60057 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 30) := by decide +kernel

theorem selectedBound60057 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60058 : List Nat := [2,4,8,16,32,64,114,68,0,30,48,123,41,43,97,89,43,81,31,97,27,32,65,120,82,16,48,42,123,80,95,33,68,32,43,0]

theorem envBound60058 : H12AffineFastState.Bounded env60058 := by
  intro p hp
  have h : env60058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60057_60058 : H12AffineEnvironment.transform 9 30 env60057 = env60058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 30 env60057 == env60058) = true)

def env60059 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9664,3159,1288,9617,2365812,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60059 : H12AffineFastState.Bounded env60059 := by
  intro p hp
  have h : env60059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60035_60059 : H12AffineEnvironment.transform 8 1 env60035 = env60059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60035 == env60059) = true)

theorem identity60059 : scanCanonicalize (H12AffineFastState.compose env60059 (packedSelected [2] rootPS)) = affineNative (2^(20+1) ^^^ 77299) := by decide +kernel

theorem selectedBound60059 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60060 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,77299,1416,9664,3159,1288,9617,341127,4177,77954,66898,65542,68095,256,65675,78034,9600]

theorem envBound60060 : H12AffineFastState.Bounded env60060 := by
  intro p hp
  have h : env60060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60059_60060 : H12AffineEnvironment.transform 20 77299 env60059 = env60060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77299 env60059 == env60060) = true)

def env60061 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,65536,70994,262144,1025,2128,67699,1416,64,3159,1288,17,332039,4177,70914,66898,65542,68095,256,65675,70994,0]

theorem envBound60061 : H12AffineFastState.Bounded env60061 := by
  intro p hp
  have h : env60061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60060_60061 : H12AffineEnvironment.transform 12 1408 env60060 = env60061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60060 == env60061) = true)

theorem identity60061 : scanCanonicalize (H12AffineFastState.compose env60061 (packedSelected [4,9,16] rootPS)) = affineNative (2^(15+1) ^^^ 4494) := by decide +kernel

theorem selectedBound60061 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60062 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4494,1244,262144,1025,2128,6653,1416,64,3159,1288,17,262281,4177,1164,5340,4488,6257,256,4357,1244,0]

theorem envBound60062 : H12AffineFastState.Bounded env60062 := by
  intro p hp
  have h : env60062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60061_60062 : H12AffineEnvironment.transform 15 4494 env60061 = env60062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4494 env60061 == env60062) = true)

theorem identity60062 : scanCanonicalize (H12AffineFastState.compose env60062 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60062 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60063 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,4494,1244,262144,1025,1449,5124,1416,64,430,1288,17,262281,4177,1164,5340,4488,5512,256,4357,1244,0]

theorem envBound60063 : H12AffineFastState.Bounded env60063 := by
  intro p hp
  have h : env60063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60062_60063 : H12AffineEnvironment.transform 10 1529 env60062 = env60063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60062 == env60063) = true)

theorem identity60063 : scanCanonicalize (H12AffineFastState.compose env60063 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1377) := by decide +kernel

theorem selectedBound60063 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60064 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1408,4176,1449,4494,1244,1377,1025,1449,5124,1416,64,430,1288,17,1512,4177,1164,5340,4488,5512,256,4357,1244,0]

theorem envBound60064 : H12AffineFastState.Bounded env60064 := by
  intro p hp
  have h : env60064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60063_60064 : H12AffineEnvironment.transform 17 1377 env60063 = env60064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1377 env60063 == env60064) = true)

theorem identity60064 : scanCanonicalize (H12AffineFastState.compose env60064 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1449) := by decide +kernel

theorem selectedBound60064 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60065 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1449,1408,1529,1449,1063,1244,1377,1025,1449,429,1416,64,430,1288,17,1512,1528,1164,373,1057,33,256,1196,1244,0]

theorem envBound60065 : H12AffineFastState.Bounded env60065 := by
  intro p hp
  have h : env60065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60064_60065 : H12AffineEnvironment.transform 11 1449 env60064 = env60065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1449 env60064 == env60065) = true)

theorem identity60065 : scanCanonicalize (H12AffineFastState.compose env60065 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60065 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60066 : List Nat := [2,4,8,16,32,64,128,252,1,1024,1029,1109,1148,1029,1109,1063,1244,1181,1025,1109,81,1140,64,82,1268,17,1044,1028,1164,137,1057,33,252,1196,1244,0]

theorem envBound60066 : H12AffineFastState.Bounded env60066 := by
  intro p hp
  have h : env60066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60065_60066 : H12AffineEnvironment.transform 7 252 env60065 = env60066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60065 == env60066) = true)

theorem identity60066 : scanCanonicalize (H12AffineFastState.compose env60066 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 141) := by decide +kernel

theorem selectedBound60066 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60067 : List Nat := [2,4,8,16,32,64,128,252,1,141,136,216,241,136,216,170,81,16,140,216,81,249,64,82,121,17,153,137,1,137,172,33,252,33,81,0]

theorem envBound60067 : H12AffineFastState.Bounded env60067 := by
  intro p hp
  have h : env60067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60066_60067 : H12AffineEnvironment.transform 9 141 env60066 = env60067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 141 env60066 == env60067) = true)

theorem identity60067 : scanCanonicalize (H12AffineFastState.compose env60067 (packedSelected [1,4,5,6,7] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound60067 : packedSelected [1,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env60068 : List Nat := [2,4,8,16,32,64,89,37,1,84,81,1,40,81,1,115,81,16,85,1,81,32,64,82,121,17,64,80,1,80,117,33,37,33,81,0]

theorem envBound60068 : H12AffineFastState.Bounded env60068 := by
  intro p hp
  have h : env60068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60067_60068 : H12AffineEnvironment.transform 6 89 env60067 = env60068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env60067 == env60068) = true)

theorem identity60068 : scanCanonicalize (H12AffineFastState.compose env60068 (packedSelected [1,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound60068 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60069 : List Nat := [2,4,8,9,32,64,64,37,1,77,72,1,40,72,1,106,72,9,76,1,72,32,64,75,96,8,64,73,1,73,108,33,37,33,72,0]

theorem envBound60069 : H12AffineFastState.Bounded env60069 := by
  intro p hp
  have h : env60069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60068_60069 : H12AffineEnvironment.transform 3 9 env60068 = env60069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env60068 == env60069) = true)

theorem identity60069 : scanCanonicalize (H12AffineFastState.compose env60069 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound60069 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env60070 : List Nat := [2,4,8,9,10,64,64,15,1,77,72,1,2,72,1,64,72,9,76,1,72,10,64,75,74,8,64,73,1,73,70,11,15,11,72,0]

theorem envBound60070 : H12AffineFastState.Bounded env60070 := by
  intro p hp
  have h : env60070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60069_60070 : H12AffineEnvironment.transform 4 10 env60069 = env60070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env60069 == env60070) = true)

theorem identity60070 : scanCanonicalize (H12AffineFastState.compose env60070 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound60070 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env60071 : List Nat := [2,4,8,9,10,1,1,15,1,12,9,1,2,9,1,1,9,9,13,1,9,10,1,10,11,8,1,8,1,8,7,11,15,11,9,0]

theorem envBound60071 : H12AffineFastState.Bounded env60071 := by
  intro p hp
  have h : env60071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60070_60071 : H12AffineEnvironment.transform 5 1 env60070 = env60071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env60070 == env60071) = true)

theorem identity60071 : scanCanonicalize (H12AffineFastState.compose env60071 (packedSelected [0,1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound60071 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60072 : List Nat := [0,4,8,9,8,1,1,13,1,12,9,1,0,9,1,1,9,9,13,1,9,8,1,8,9,8,1,8,1,8,5,9,13,9,9,0]

theorem envBound60072 : H12AffineFastState.Bounded env60072 := by
  intro p hp
  have h : env60072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60071_60072 : H12AffineEnvironment.transform 0 0 env60071 = env60072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env60071 == env60072) = true)

theorem identity60072 : scanCanonicalize (H12AffineFastState.compose env60072 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound60072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60073 : List Nat := [0,4,1,0,1,1,1,4,1,5,0,1,0,0,1,1,0,0,4,1,0,1,1,1,0,1,1,1,1,1,5,0,4,0,0,0]

theorem envBound60073 : H12AffineFastState.Bounded env60073 := by
  intro p hp
  have h : env60073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60072_60073 : H12AffineEnvironment.transform 2 1 env60072 = env60073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env60072 == env60073) = true)

def env60074 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,65536,70995,262144,1025,2128,67698,1416,65,3159,1288,16,332038,4177,70915,66898,65542,68095,256,65675,70995,1]

theorem envBound60074 : H12AffineFastState.Bounded env60074 := by
  intro p hp
  have h : env60074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60060_60074 : H12AffineEnvironment.transform 12 1409 env60060 = env60074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60060 == env60074) = true)

theorem identity60074 : scanCanonicalize (H12AffineFastState.compose env60074 (packedSelected [4,9,16] rootPS)) = affineNative (2^(11+1) ^^^ 136) := by decide +kernel

theorem selectedBound60074 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60075 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2128,65536,67035,262144,1025,2128,67698,1416,65,3159,1288,16,328078,217,66955,66898,65542,68095,256,65675,67035,1]

theorem envBound60075 : H12AffineFastState.Bounded env60075 := by
  intro p hp
  have h : env60075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60074_60075 : H12AffineEnvironment.transform 11 136 env60074 = env60075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 136 env60074 == env60075) = true)

theorem identity60075 : scanCanonicalize (H12AffineFastState.compose env60075 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 65983) := by decide +kernel

theorem selectedBound60075 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60076 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2128,65536,67035,65983,1025,2128,67698,1416,65,3159,1288,16,49,217,66955,66898,65542,68095,256,65675,67035,1]

theorem envBound60076 : H12AffineFastState.Bounded env60076 := by
  intro p hp
  have h : env60076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60075_60076 : H12AffineEnvironment.transform 17 65983 env60075 = env60076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 65983 env60075 == env60076) = true)

theorem identity60076 : scanCanonicalize (H12AffineFastState.compose env60076 (packedSelected [0,7,20] rootPS)) = affineNative (2^(15+1) ^^^ 1095) := by decide +kernel

theorem selectedBound60076 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60077 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,136,1409,216,2128,1095,412,1528,1025,2128,3125,1416,65,3159,1288,16,49,217,460,277,1089,3512,256,1228,412,1]

theorem envBound60077 : H12AffineFastState.Bounded env60077 := by
  intro p hp
  have h : env60077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60076_60077 : H12AffineEnvironment.transform 15 1095 env60076 = env60077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1095 env60076 == env60077) = true)

theorem identity60077 : scanCanonicalize (H12AffineFastState.compose env60077 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 1245) := by decide +kernel

theorem selectedBound60077 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60078 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1245,136,1409,216,1165,1095,412,1528,1025,1165,232,1416,65,138,1288,16,49,217,460,277,1089,357,256,1228,412,1]

theorem envBound60078 : H12AffineFastState.Bounded env60078 := by
  intro p hp
  have h : env60078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60077_60078 : H12AffineEnvironment.transform 10 1245 env60077 = env60078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1245 env60077 == env60078) = true)

theorem identity60078 : scanCanonicalize (H12AffineFastState.compose env60078 (packedSelected [0,1,5,7,10] rootPS)) = affineNative (2^(9+1) ^^^ 424) := by decide +kernel

theorem selectedBound60078 : packedSelected [0,1,5,7,10] rootPS < 2^1333 := by decide +kernel

def env60079 : List Nat := [2,4,8,16,32,64,128,256,1,424,373,136,41,216,293,495,412,80,425,293,232,32,65,138,160,16,49,217,460,277,489,357,256,356,412,1]

theorem envBound60079 : H12AffineFastState.Bounded env60079 := by
  intro p hp
  have h : env60079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60078_60079 : H12AffineEnvironment.transform 9 424 env60078 = env60079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 424 env60078 == env60079) = true)

theorem identity60079 : scanCanonicalize (H12AffineFastState.compose env60079 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 69) := by decide +kernel

theorem selectedBound60079 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60080 : List Nat := [2,4,8,16,32,64,128,69,1,237,48,136,41,216,96,170,217,80,236,96,232,32,65,138,160,16,49,217,137,80,172,32,69,33,217,1]

theorem envBound60080 : H12AffineFastState.Bounded env60080 := by
  intro p hp
  have h : env60080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60079_60080 : H12AffineEnvironment.transform 7 69 env60079 = env60080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 69 env60079 == env60080) = true)

theorem identity60080 : scanCanonicalize (H12AffineFastState.compose env60080 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 58) := by decide +kernel

theorem selectedBound60080 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60081 : List Nat := [2,4,8,16,32,58,128,63,1,151,48,136,41,162,26,170,163,42,150,26,146,32,59,138,160,16,49,163,137,42,172,32,63,33,163,1]

theorem envBound60081 : H12AffineFastState.Bounded env60081 := by
  intro p hp
  have h : env60081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60080_60081 : H12AffineEnvironment.transform 5 58 env60080 = env60081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 58 env60080 == env60081) = true)

def env60082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1416,9665,3671,1289,9616,2366325,4177,77954,67411,65543,68607,256,65675,78034,10112]

theorem envBound60082 : H12AffineFastState.Bounded env60082 := by
  intro p hp
  have h : env60082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60034_60082 : H12AffineEnvironment.transform 22 9665 env60034 = env60082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9665 env60034 == env60082) = true)

def env60083 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,65536,78034,262144,1025,2129,2097152,1416,9665,3159,1289,9616,2365813,4177,77954,66899,65543,68095,256,65675,78034,9600]

theorem envBound60083 : H12AffineFastState.Bounded env60083 := by
  intro p hp
  have h : env60083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60082_60083 : H12AffineEnvironment.transform 8 0 env60082 = env60083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env60082 == env60083) = true)

theorem identity60083 : scanCanonicalize (H12AffineFastState.compose env60083 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 13731) := by decide +kernel

theorem selectedBound60083 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60084 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,8192,4176,2129,13731,1393,262144,1025,2129,2097152,1416,9665,3159,1289,9616,2365813,4177,1313,12528,13732,15452,256,13608,1393,9600]

theorem envBound60084 : H12AffineFastState.Bounded env60084 := by
  intro p hp
  have h : env60084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60083_60084 : H12AffineEnvironment.transform 15 13731 env60083 = env60084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13731 env60083 == env60084) = true)

def env60085 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4131,1393,262144,1025,2129,2097152,1416,65,3159,1289,16,2365813,4177,1313,5488,4132,6620,256,4264,1393,0]

theorem envBound60085 : H12AffineFastState.Bounded env60085 := by
  intro p hp
  have h : env60085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60084_60085 : H12AffineEnvironment.transform 12 1408 env60084 = env60085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60084 == env60085) = true)

theorem identity60085 : scanCanonicalize (H12AffineFastState.compose env60085 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound60085 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60086 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4131,1393,262144,1025,2129,2265,1416,65,3159,1289,16,266668,4177,1313,5488,4132,6620,256,4264,1393,0]

theorem envBound60086 : H12AffineFastState.Bounded env60086 := by
  intro p hp
  have h : env60086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60085_60086 : H12AffineEnvironment.transform 20 2265 env60085 = env60086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env60085 == env60086) = true)

theorem identity60086 : scanCanonicalize (H12AffineFastState.compose env60086 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 276) := by decide +kernel

theorem selectedBound60086 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60087 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1408,4176,2129,4131,1393,276,1025,2129,2265,1416,65,3159,1289,16,4280,4177,1313,5488,4132,6620,256,4264,1393,0]

theorem envBound60087 : H12AffineFastState.Bounded env60087 := by
  intro p hp
  have h : env60087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60086_60087 : H12AffineEnvironment.transform 17 276 env60086 = env60087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 276 env60086 == env60087) = true)

theorem identity60087 : scanCanonicalize (H12AffineFastState.compose env60087 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound60087 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60088 : List Nat := [2,4,8,16,32,64,128,256,0,236,2048,4096,364,4176,2129,4131,413,276,237,2129,2265,356,65,2235,485,16,4280,4177,461,4508,4132,6620,256,4264,413,0]

theorem envBound60088 : H12AffineFastState.Bounded env60088 := by
  intro p hp
  have h : env60088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60087_60088 : H12AffineEnvironment.transform 9 236 env60087 = env60088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env60087 == env60088) = true)

theorem identity60088 : scanCanonicalize (H12AffineFastState.compose env60088 (packedSelected [1,3,10,11,13] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound60088 : packedSelected [1,3,10,11,13] rootPS < 2^1333 := by decide +kernel

def env60089 : List Nat := [2,4,8,16,32,64,128,256,0,236,49,4096,364,4176,96,4131,413,276,237,96,232,356,65,138,485,16,4280,4177,461,4508,4132,4589,256,4264,413,0]

theorem envBound60089 : H12AffineFastState.Bounded env60089 := by
  intro p hp
  have h : env60089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60088_60089 : H12AffineEnvironment.transform 10 49 env60088 = env60089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env60088 == env60089) = true)

theorem identity60089 : scanCanonicalize (H12AffineFastState.compose env60089 (packedSelected [0,4,6,11] rootPS)) = affineNative (2^(11+1) ^^^ 461) := by decide +kernel

theorem selectedBound60089 : packedSelected [0,4,6,11] rootPS < 2^1333 := by decide +kernel

def env60090 : List Nat := [2,4,8,16,32,64,128,256,0,236,49,461,364,413,96,494,413,276,237,96,232,356,65,138,485,16,373,412,461,81,489,32,256,357,413,0]

theorem envBound60090 : H12AffineFastState.Bounded env60090 := by
  intro p hp
  have h : env60090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60089_60090 : H12AffineEnvironment.transform 11 461 env60089 = env60090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 461 env60089 == env60090) = true)

theorem identity60090 : scanCanonicalize (H12AffineFastState.compose env60090 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound60090 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60091 : List Nat := [2,4,8,16,32,64,128,182,0,236,49,123,218,43,96,88,43,162,237,96,232,210,65,138,83,16,195,42,123,81,95,32,182,211,43,0]

theorem envBound60091 : H12AffineFastState.Bounded env60091 := by
  intro p hp
  have h : env60091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60090_60091 : H12AffineEnvironment.transform 7 182 env60090 = env60091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env60090 == env60091) = true)

theorem identity60091 : scanCanonicalize (H12AffineFastState.compose env60091 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60091 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60092 : List Nat := [2,4,8,16,32,64,114,68,0,30,49,123,40,43,96,88,43,80,31,96,26,32,65,120,83,16,49,42,123,81,95,32,68,33,43,0]

theorem envBound60092 : H12AffineFastState.Bounded env60092 := by
  intro p hp
  have h : env60092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60091_60092 : H12AffineEnvironment.transform 6 114 env60091 = env60092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60091 == env60092) = true)

def env60093 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,2097152,1416,64,3159,1289,17,2365813,4177,1313,5489,4133,6621,256,4265,1393,1]

theorem envBound60093 : H12AffineFastState.Bounded env60093 := by
  intro p hp
  have h : env60093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60084_60093 : H12AffineEnvironment.transform 12 1409 env60084 = env60093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60084 == env60093) = true)

theorem identity60093 : scanCanonicalize (H12AffineFastState.compose env60093 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6652) := by decide +kernel

theorem selectedBound60093 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60094 : List Nat := [2,4,8,16,32,64,128,256,0,1024,2048,4096,1409,4176,2129,4130,1393,262144,1025,2129,6652,1416,64,3159,1289,17,262281,4177,1313,5489,4133,6621,256,4265,1393,1]

theorem envBound60094 : H12AffineFastState.Bounded env60094 := by
  intro p hp
  have h : env60094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60093_60094 : H12AffineEnvironment.transform 20 6652 env60093 = env60094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6652 env60093 == env60094) = true)

theorem identity60094 : scanCanonicalize (H12AffineFastState.compose env60094 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1528) := by decide +kernel

theorem selectedBound60094 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60095 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,4130,1393,262144,1025,1449,5124,1416,64,431,1289,17,262281,4177,1313,5489,4133,5157,256,4265,1393,1]

theorem envBound60095 : H12AffineFastState.Bounded env60095 := by
  intro p hp
  have h : env60095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60094_60095 : H12AffineEnvironment.transform 10 1528 env60094 = env60095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1528 env60094 == env60095) = true)

theorem identity60095 : scanCanonicalize (H12AffineFastState.compose env60095 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound60095 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60096 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,4096,1409,4176,1449,4130,1393,1228,1025,1449,5124,1416,64,431,1289,17,1093,4177,1313,5489,4133,5157,256,4265,1393,1]

theorem envBound60096 : H12AffineFastState.Bounded env60096 := by
  intro p hp
  have h : env60096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60095_60096 : H12AffineEnvironment.transform 17 1228 env60095 = env60096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env60095 == env60096) = true)

theorem identity60096 : scanCanonicalize (H12AffineFastState.compose env60096 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound60096 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60097 : List Nat := [2,4,8,16,32,64,128,256,0,1024,1528,1029,1409,1109,1449,1063,1393,1228,1025,1449,1,1416,64,431,1289,17,1093,1108,1313,372,1056,32,256,1196,1393,1]

theorem envBound60097 : H12AffineFastState.Bounded env60097 := by
  intro p hp
  have h : env60097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60096_60097 : H12AffineEnvironment.transform 11 1029 env60096 = env60097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env60096 == env60097) = true)

theorem identity60097 : scanCanonicalize (H12AffineFastState.compose env60097 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound60097 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60098 : List Nat := [2,4,8,16,32,64,128,252,0,1024,1028,1029,1149,1109,1109,1063,1165,1228,1025,1109,1,1140,64,83,1269,17,1093,1108,1245,136,1056,32,252,1196,1165,1]

theorem envBound60098 : H12AffineFastState.Bounded env60098 := by
  intro p hp
  have h : env60098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60097_60098 : H12AffineEnvironment.transform 7 252 env60097 = env60098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env60097 == env60098) = true)

theorem identity60098 : scanCanonicalize (H12AffineFastState.compose env60098 (packedSelected [5,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 140) := by decide +kernel

theorem selectedBound60098 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60099 : List Nat := [2,4,8,16,32,64,128,252,0,140,136,137,241,217,217,171,1,64,141,217,1,248,64,83,121,17,201,216,81,136,172,32,252,32,1,1]

theorem envBound60099 : H12AffineFastState.Bounded env60099 := by
  intro p hp
  have h : env60099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60098_60099 : H12AffineEnvironment.transform 9 140 env60098 = env60099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 140 env60098 == env60099) = true)

theorem identity60099 : scanCanonicalize (H12AffineFastState.compose env60099 (packedSelected [0,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound60099 : packedSelected [0,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env60100 : List Nat := [2,4,8,16,32,64,121,5,0,117,113,112,8,32,32,82,1,64,116,32,1,1,64,83,121,17,48,33,81,113,85,32,5,32,1,1]

theorem envBound60100 : H12AffineFastState.Bounded env60100 := by
  intro p hp
  have h : env60100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60099_60100 : H12AffineEnvironment.transform 6 121 env60099 = env60100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env60099 == env60100) = true)

theorem identity60100 : scanCanonicalize (H12AffineFastState.compose env60100 (packedSelected [4] rootPS)) = affineNative (2^(5+1) ^^^ 24) := by decide +kernel

theorem selectedBound60100 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env60101 : List Nat := [2,4,8,16,32,24,33,5,0,45,41,40,8,32,32,10,1,24,44,32,1,1,24,11,33,17,48,33,9,41,13,32,5,32,1,1]

theorem envBound60101 : H12AffineFastState.Bounded env60101 := by
  intro p hp
  have h : env60101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60100_60101 : H12AffineEnvironment.transform 5 24 env60100 = env60101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 24 env60100 == env60101) = true)

theorem identity60101 : scanCanonicalize (H12AffineFastState.compose env60101 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound60101 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env60102 : List Nat := [2,4,8,16,18,24,19,5,0,31,27,26,8,18,18,10,1,24,30,18,1,1,24,11,19,17,2,19,9,27,13,18,5,18,1,1]

theorem envBound60102 : H12AffineFastState.Bounded env60102 := by
  intro p hp
  have h : env60102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60101_60102 : H12AffineEnvironment.transform 4 18 env60101 = env60102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env60101 == env60102) = true)

theorem identity60102 : scanCanonicalize (H12AffineFastState.compose env60102 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60102 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env60103 : List Nat := [2,4,8,0,2,8,3,5,0,15,11,10,8,2,2,10,1,8,14,2,1,1,8,11,3,1,2,3,9,11,13,2,5,2,1,1]

theorem envBound60103 : H12AffineFastState.Bounded env60103 := by
  intro p hp
  have h : env60103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60102_60103 : H12AffineEnvironment.transform 3 0 env60102 = env60103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60102 == env60103) = true)

theorem identity60103 : scanCanonicalize (H12AffineFastState.compose env60103 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound60103 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60104 : List Nat := [2,4,3,0,2,3,3,5,0,4,0,1,3,2,2,1,1,3,5,2,1,1,3,0,3,1,2,3,2,0,6,2,5,2,1,1]

theorem envBound60104 : H12AffineFastState.Bounded env60104 := by
  intro p hp
  have h : env60104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60103_60104 : H12AffineEnvironment.transform 2 3 env60103 = env60104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env60103 == env60104) = true)

def env60105 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,65536,78034,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2365812,4177,77954,66898,65543,68094,256,65675,78034,9601]

theorem envBound60105 : H12AffineFastState.Bounded env60105 := by
  intro p hp
  have h : env60105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60082_60105 : H12AffineEnvironment.transform 8 1 env60082 = env60105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env60082 == env60105) = true)

theorem identity60105 : scanCanonicalize (H12AffineFastState.compose env60105 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 4130) := by decide +kernel

theorem selectedBound60105 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env60106 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,8192,4176,2128,4130,8432,262144,1025,2128,2097152,1416,9665,3158,1289,9616,2365812,4177,8352,5488,4133,6620,256,4265,8432,9601]

theorem envBound60106 : H12AffineFastState.Bounded env60106 := by
  intro p hp
  have h : env60106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60105_60106 : H12AffineEnvironment.transform 15 4130 env60105 = env60106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4130 env60105 == env60106) = true)

def env60107 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4130,1392,262144,1025,2128,2097152,1416,65,3158,1289,16,2365812,4177,1312,5488,4133,6620,256,4265,1392,1]

theorem envBound60107 : H12AffineFastState.Bounded env60107 := by
  intro p hp
  have h : env60107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60106_60107 : H12AffineEnvironment.transform 12 1408 env60106 = env60107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1408 env60106 == env60107) = true)

theorem identity60107 : scanCanonicalize (H12AffineFastState.compose env60107 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 2265) := by decide +kernel

theorem selectedBound60107 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60108 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4130,1392,262144,1025,2128,2265,1416,65,3158,1289,16,266669,4177,1312,5488,4133,6620,256,4265,1392,1]

theorem envBound60108 : H12AffineFastState.Bounded env60108 := by
  intro p hp
  have h : env60108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60107_60108 : H12AffineEnvironment.transform 20 2265 env60107 = env60108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 2265 env60107 == env60108) = true)

theorem identity60108 : scanCanonicalize (H12AffineFastState.compose env60108 (packedSelected [5,8] rootPS)) = affineNative (2^(17+1) ^^^ 277) := by decide +kernel

theorem selectedBound60108 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env60109 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1408,4176,2128,4130,1392,277,1025,2128,2265,1416,65,3158,1289,16,4280,4177,1312,5488,4133,6620,256,4265,1392,1]

theorem envBound60109 : H12AffineFastState.Bounded env60109 := by
  intro p hp
  have h : env60109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60108_60109 : H12AffineEnvironment.transform 17 277 env60108 = env60109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 277 env60108 == env60109) = true)

theorem identity60109 : scanCanonicalize (H12AffineFastState.compose env60109 (packedSelected [0,7,20] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound60109 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env60110 : List Nat := [2,4,8,16,32,64,128,256,1,236,2048,4096,364,4176,2128,4130,412,277,237,2128,2265,356,65,2234,485,16,4280,4177,460,4508,4133,6620,256,4265,412,1]

theorem envBound60110 : H12AffineFastState.Bounded env60110 := by
  intro p hp
  have h : env60110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60109_60110 : H12AffineEnvironment.transform 9 236 env60109 = env60110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env60109 == env60110) = true)

theorem identity60110 : scanCanonicalize (H12AffineFastState.compose env60110 (packedSelected [1,3,6,7,9,10,11,15,17] rootPS)) = affineNative (2^(11+1) ^^^ 2556) := by decide +kernel

theorem selectedBound60110 : packedSelected [1,3,6,7,9,10,11,15,17] rootPS < 2^1333 := by decide +kernel

def env60111 : List Nat := [2,4,8,16,32,64,128,256,1,236,2048,2556,364,2476,2128,2526,412,277,237,2128,2265,356,65,2234,485,16,2372,2477,460,2144,2521,32,256,2389,412,1]

theorem envBound60111 : H12AffineFastState.Bounded env60111 := by
  intro p hp
  have h : env60111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60110_60111 : H12AffineEnvironment.transform 11 2556 env60110 = env60111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2556 env60110 == env60111) = true)

theorem identity60111 : scanCanonicalize (H12AffineFastState.compose env60111 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound60111 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env60112 : List Nat := [2,4,8,16,32,64,128,256,1,236,48,460,364,412,96,494,412,277,237,96,233,356,65,138,485,16,372,413,460,80,489,32,256,357,412,1]

theorem envBound60112 : H12AffineFastState.Bounded env60112 := by
  intro p hp
  have h : env60112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60111_60112 : H12AffineEnvironment.transform 10 48 env60111 = env60112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env60111 == env60112) = true)

theorem identity60112 : scanCanonicalize (H12AffineFastState.compose env60112 (packedSelected [1,4] rootPS)) = affineNative (2^(7+1) ^^^ 182) := by decide +kernel

theorem selectedBound60112 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env60113 : List Nat := [2,4,8,16,32,64,128,182,1,236,48,122,218,42,96,88,42,163,237,96,233,210,65,138,83,16,194,43,122,80,95,32,182,211,42,1]

theorem envBound60113 : H12AffineFastState.Bounded env60113 := by
  intro p hp
  have h : env60113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60112_60113 : H12AffineEnvironment.transform 7 182 env60112 = env60113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 182 env60112 == env60113) = true)

theorem identity60113 : scanCanonicalize (H12AffineFastState.compose env60113 (packedSelected [0,5] rootPS)) = affineNative (2^(6+1) ^^^ 114) := by decide +kernel

theorem selectedBound60113 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env60114 : List Nat := [2,4,8,16,32,64,114,68,1,30,48,122,40,42,96,88,42,81,31,96,27,32,65,120,83,16,48,43,122,80,95,32,68,33,42,1]

theorem envBound60114 : H12AffineFastState.Bounded env60114 := by
  intro p hp
  have h : env60114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60113_60114 : H12AffineEnvironment.transform 6 114 env60113 = env60114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 114 env60113 == env60114) = true)

def env60115 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,2097152,1416,64,3158,1289,17,2365812,4177,1313,5488,4133,6620,256,4265,1393,0]

theorem envBound60115 : H12AffineFastState.Bounded env60115 := by
  intro p hp
  have h : env60115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60106_60115 : H12AffineEnvironment.transform 12 1409 env60106 = env60115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1409 env60106 == env60115) = true)

theorem identity60115 : scanCanonicalize (H12AffineFastState.compose env60115 (packedSelected [4,9,16] rootPS)) = affineNative (2^(20+1) ^^^ 6653) := by decide +kernel

theorem selectedBound60115 : packedSelected [4,9,16] rootPS < 2^1333 := by decide +kernel

def env60116 : List Nat := [2,4,8,16,32,64,128,256,1,1024,2048,4096,1409,4176,2128,4130,1393,262144,1025,2128,6653,1416,64,3158,1289,17,262281,4177,1313,5488,4133,6620,256,4265,1393,0]

theorem envBound60116 : H12AffineFastState.Bounded env60116 := by
  intro p hp
  have h : env60116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60115_60116 : H12AffineEnvironment.transform 20 6653 env60115 = env60116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 6653 env60115 == env60116) = true)

theorem identity60116 : scanCanonicalize (H12AffineFastState.compose env60116 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(10+1) ^^^ 1529) := by decide +kernel

theorem selectedBound60116 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env60117 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,4130,1393,262144,1025,1449,5124,1416,64,431,1289,17,262281,4177,1313,5488,4133,5157,256,4265,1393,0]

theorem envBound60117 : H12AffineFastState.Bounded env60117 := by
  intro p hp
  have h : env60117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60116_60117 : H12AffineEnvironment.transform 10 1529 env60116 = env60117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1529 env60116 == env60117) = true)

theorem identity60117 : scanCanonicalize (H12AffineFastState.compose env60117 (packedSelected [0,5,7,8,20] rootPS)) = affineNative (2^(17+1) ^^^ 1228) := by decide +kernel

theorem selectedBound60117 : packedSelected [0,5,7,8,20] rootPS < 2^1333 := by decide +kernel

def env60118 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,4096,1409,4176,1449,4130,1393,1228,1025,1449,5124,1416,64,431,1289,17,1093,4177,1313,5488,4133,5157,256,4265,1393,0]

theorem envBound60118 : H12AffineFastState.Bounded env60118 := by
  intro p hp
  have h : env60118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60117_60118 : H12AffineEnvironment.transform 17 1228 env60117 = env60118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1228 env60117 == env60118) = true)

theorem identity60118 : scanCanonicalize (H12AffineFastState.compose env60118 (packedSelected [5,8,9,22] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound60118 : packedSelected [5,8,9,22] rootPS < 2^1333 := by decide +kernel

def env60119 : List Nat := [2,4,8,16,32,64,128,256,1,1024,1529,1029,1409,1109,1449,1063,1393,1228,1025,1449,1,1416,64,431,1289,17,1093,1108,1313,373,1056,32,256,1196,1393,0]

theorem envBound60119 : H12AffineFastState.Bounded env60119 := by
  intro p hp
  have h : env60119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60118_60119 : H12AffineEnvironment.transform 11 1029 env60118 = env60119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env60118 == env60119) = true)

theorem identity60119 : scanCanonicalize (H12AffineFastState.compose env60119 (packedSelected [5,8,13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound60119 : packedSelected [5,8,13,17] rootPS < 2^1333 := by decide +kernel

def env60120 : List Nat := [2,4,8,16,32,64,128,253,1,1024,1028,1029,1148,1109,1108,1063,1164,1228,1025,1108,1,1141,64,82,1268,17,1093,1108,1244,136,1056,32,253,1196,1164,0]

theorem envBound60120 : H12AffineFastState.Bounded env60120 := by
  intro p hp
  have h : env60120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60119_60120 : H12AffineEnvironment.transform 7 253 env60119 = env60120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env60119 == env60120) = true)

theorem identity60120 : scanCanonicalize (H12AffineFastState.compose env60120 (packedSelected [5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound60120 : packedSelected [5,6,8] rootPS < 2^1333 := by decide +kernel

def env60121 : List Nat := [2,4,8,16,32,16,128,173,1,1024,1028,1029,1068,1029,1028,1063,1164,1180,1025,1028,1,1061,16,2,1188,17,1045,1028,1164,136,1056,32,173,1196,1164,0]

theorem envBound60121 : H12AffineFastState.Bounded env60121 := by
  intro p hp
  have h : env60121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60120_60121 : H12AffineEnvironment.transform 5 16 env60120 = env60121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env60120 == env60121) = true)

theorem identity60121 : scanCanonicalize (H12AffineFastState.compose env60121 (packedSelected [0,6] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound60121 : packedSelected [0,6] rootPS < 2^1333 := by decide +kernel

def env60122 : List Nat := [2,4,8,16,32,16,10,39,1,1024,1028,1029,1068,1029,1028,1063,1030,1046,1025,1028,1,1061,16,2,1070,17,1045,1028,1030,2,1056,32,39,1062,1030,0]

theorem envBound60122 : H12AffineFastState.Bounded env60122 := by
  intro p hp
  have h : env60122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60121_60122 : H12AffineEnvironment.transform 6 10 env60121 = env60122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env60121 == env60122) = true)

theorem identity60122 : scanCanonicalize (H12AffineFastState.compose env60122 (packedSelected [1,3,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound60122 : packedSelected [1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env60123 : List Nat := [2,4,8,16,32,16,10,39,1,5,1,0,41,0,1,34,3,19,4,1,1,32,16,2,43,17,16,1,3,2,37,32,39,35,3,0]

theorem envBound60123 : H12AffineFastState.Bounded env60123 := by
  intro p hp
  have h : env60123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60122_60123 : H12AffineEnvironment.transform 9 5 env60122 = env60123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env60122 == env60123) = true)

theorem identity60123 : scanCanonicalize (H12AffineFastState.compose env60123 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound60123 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env60124 : List Nat := [2,4,8,0,32,0,10,39,1,5,1,0,41,0,1,34,3,3,4,1,1,32,0,2,43,1,0,1,3,2,37,32,39,35,3,0]

theorem envBound60124 : H12AffineFastState.Bounded env60124 := by
  intro p hp
  have h : env60124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60123_60124 : H12AffineEnvironment.transform 3 0 env60123 = env60124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env60123 == env60124) = true)

theorem identity60124 : scanCanonicalize (H12AffineFastState.compose env60124 (packedSelected [1,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound60124 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env60125 : List Nat := [1,4,8,0,32,0,9,36,1,5,1,0,41,0,1,33,0,0,4,1,1,32,0,1,40,1,0,1,0,1,37,32,36,32,0,0]

theorem envBound60125 : H12AffineFastState.Bounded env60125 := by
  intro p hp
  have h : env60125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60124_60125 : H12AffineEnvironment.transform 0 1 env60124 = env60125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env60124 == env60125) = true)

def env60126 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,8388608,8399766,8397000,8388689,2366324,4177,77954,67410,8463814,8465982,256,65674,78034,8389185]

theorem envBound60126 : H12AffineFastState.Bounded env60126 := by
  intro p hp
  have h : env60126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60033_60126 : H12AffineEnvironment.transform 21 1417 env60033 = env60126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1417 env60033 == env60126) = true)

def env60127 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4176,2641,65536,78034,262144,1025,2641,2097152,1417,9664,3670,1288,9617,2366324,4177,77954,67410,65542,68606,256,65674,78034,10113]

theorem envBound60127 : H12AffineFastState.Bounded env60127 := by
  intro p hp
  have h : env60127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans60126_60127 : H12AffineEnvironment.transform 22 9664 env60126 = env60127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 9664 env60126 == env60127) = true)

end H12CloudChart1