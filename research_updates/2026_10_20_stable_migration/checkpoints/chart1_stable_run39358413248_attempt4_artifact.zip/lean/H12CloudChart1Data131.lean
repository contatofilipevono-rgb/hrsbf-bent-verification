import H12CloudChart1Data130

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity33243 : scanCanonicalize (H12AffineFastState.compose env33243 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1124) := by decide +kernel

theorem selectedBound33243 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env33244 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,1124,8202,131072,10280,1025,1125,4160,33,16,9530,8193,65,146508,5392,4096,145757,1365,9496,257,33,12393,512]

theorem envBound33244 : H12AffineFastState.Bounded env33244 := by
  intro p hp
  have h : env33244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33243_33244 : H12AffineEnvironment.transform 14 1124 env33243 = env33244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1124 env33243 == env33244) = true)

theorem identity33244 : scanCanonicalize (H12AffineFastState.compose env33244 (packedSelected [2,4,6,9,11,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 1140) := by decide +kernel

theorem selectedBound33244 : packedSelected [2,4,6,9,11,12,15] rootPS < 2^1333 := by decide +kernel

def env33245 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,8192,373,1124,8202,131072,10280,1025,1125,1076,33,16,9530,8193,65,141368,356,1140,142633,1365,9496,257,33,9245,512]

theorem envBound33245 : H12AffineFastState.Bounded env33245 := by
  intro p hp
  have h : env33245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33244_33245 : H12AffineEnvironment.transform 11 1140 env33244 = env33245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1140 env33244 == env33245) = true)

theorem identity33245 : scanCanonicalize (H12AffineFastState.compose env33245 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound33245 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env33246 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,1100,373,1124,1094,131072,3172,1025,1125,1076,33,16,374,1101,65,134260,356,1140,133477,1365,340,257,33,81,512]

theorem envBound33246 : H12AffineFastState.Bounded env33246 := by
  intro p hp
  have h : env33246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33245_33246 : H12AffineEnvironment.transform 12 1100 env33245 = env33246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env33245 == env33246) = true)

theorem identity33246 : scanCanonicalize (H12AffineFastState.compose env33246 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 2356) := by decide +kernel

theorem selectedBound33246 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env33247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1140,1100,373,1124,1094,2356,3172,1025,1125,1076,33,16,374,1101,65,1344,356,1140,81,1365,340,257,33,81,512]

theorem envBound33247 : H12AffineFastState.Bounded env33247 := by
  intro p hp
  have h : env33247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33246_33247 : H12AffineEnvironment.transform 16 2356 env33246 = env33247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2356 env33246 == env33247) = true)

theorem identity33247 : scanCanonicalize (H12AffineFastState.compose env33247 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33247 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env33248 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1060,1052,293,1076,1046,2356,3124,1025,1077,1076,33,16,294,1053,17,1296,308,1060,1,1285,260,257,33,1,512]

theorem envBound33248 : H12AffineFastState.Bounded env33248 := by
  intro p hp
  have h : env33248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33247_33248 : H12AffineEnvironment.transform 5 16 env33247 = env33248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33247 == env33248) = true)

theorem identity33248 : scanCanonicalize (H12AffineFastState.compose env33248 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound33248 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env33249 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1077,1060,1052,293,1076,1046,1281,1,1025,1077,1076,33,16,294,1053,17,1296,308,1060,1,1285,260,257,33,1,512]

theorem envBound33249 : H12AffineFastState.Bounded env33249 := by
  intro p hp
  have h : env33249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33248_33249 : H12AffineEnvironment.transform 10 1077 env33248 = env33249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env33248 == env33249) = true)

theorem identity33249 : scanCanonicalize (H12AffineFastState.compose env33249 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound33249 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33250 : List Nat := [2,4,8,16,32,16,9,256,512,304,261,276,300,293,260,294,49,1,305,261,260,33,16,294,301,17,32,308,276,1,53,260,257,33,1,512]

theorem envBound33250 : H12AffineFastState.Bounded env33250 := by
  intro p hp
  have h : env33250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33249_33250 : H12AffineEnvironment.transform 9 304 env33249 = env33250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env33249 == env33250) = true)

theorem identity33250 : scanCanonicalize (H12AffineFastState.compose env33250 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33250 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33251 : List Nat := [2,4,8,16,32,16,9,4,512,52,1,16,40,33,0,34,49,1,53,1,0,33,16,34,41,17,32,48,16,1,53,0,5,33,1,512]

theorem envBound33251 : H12AffineFastState.Bounded env33251 := by
  intro p hp
  have h : env33251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33250_33251 : H12AffineEnvironment.transform 7 4 env33250 = env33251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33250 == env33251) = true)

theorem identity33251 : scanCanonicalize (H12AffineFastState.compose env33251 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33251 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33252 : List Nat := [2,4,8,16,0,16,9,4,512,20,1,16,8,1,0,2,17,1,21,1,0,1,16,2,9,17,0,16,16,1,21,0,5,1,1,512]

theorem envBound33252 : H12AffineFastState.Bounded env33252 := by
  intro p hp
  have h : env33252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33251_33252 : H12AffineEnvironment.transform 4 0 env33251 = env33252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33251 == env33252) = true)

theorem identity33252 : scanCanonicalize (H12AffineFastState.compose env33252 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound33252 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33253 : List Nat := [2,4,8,5,0,5,9,4,512,1,1,5,8,1,0,2,4,1,0,1,0,1,5,2,9,4,0,5,5,1,0,0,5,1,1,512]

theorem envBound33253 : H12AffineFastState.Bounded env33253 := by
  intro p hp
  have h : env33253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33252_33253 : H12AffineEnvironment.transform 3 5 env33252 = env33253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env33252 == env33253) = true)

theorem identity33253 : scanCanonicalize (H12AffineFastState.compose env33253 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33253 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33254 : List Nat := [2,4,0,5,0,5,1,4,512,1,1,5,0,1,0,2,4,1,0,1,0,1,5,2,1,4,0,5,5,1,0,0,5,1,1,512]

theorem envBound33254 : H12AffineFastState.Bounded env33254 := by
  intro p hp
  have h : env33254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33253_33254 : H12AffineEnvironment.transform 2 0 env33253 = env33254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33253 == env33254) = true)

theorem identity33254 : scanCanonicalize (H12AffineFastState.compose env33254 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound33254 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33255 : List Nat := [2,4,0,5,0,5,1,4,3,1,1,5,0,1,0,2,4,1,0,1,0,1,5,2,1,4,0,5,5,1,0,0,5,1,1,3]

theorem envBound33255 : H12AffineFastState.Bounded env33255 := by
  intro p hp
  have h : env33255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33254_33255 : H12AffineEnvironment.transform 8 3 env33254 = env33255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env33254 == env33255) = true)

def env33256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,17,98781,8328,65,4340844,5393,17665,179633,1501,4256861,257,21792,46212,74251]

theorem envBound33256 : H12AffineFastState.Bounded env33256 := by
  intro p hp
  have h : env33256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33229_33256 : H12AffineEnvironment.transform 20 4161 env33229 = env33256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33229 == env33256) = true)

theorem identity33256 : scanCanonicalize (H12AffineFastState.compose env33256 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33256 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,4194304,17,41431,8328,65,4340844,5393,17665,179633,1501,4256861,257,21792,46212,513]

theorem envBound33257 : H12AffineFastState.Bounded env33257 := by
  intro p hp
  have h : env33257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33256_33257 : H12AffineEnvironment.transform 15 8202 env33256 = env33257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33256 == env33257) = true)

theorem identity33257 : scanCanonicalize (H12AffineFastState.compose env33257 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 41261) := by decide +kernel

theorem selectedBound33257 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env33258 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32160,1025,32769,4161,41261,17,41431,8328,65,171329,5393,17665,179633,1501,21872,257,21792,46212,513]

theorem envBound33258 : H12AffineFastState.Bounded env33258 := by
  intro p hp
  have h : env33258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33257_33258 : H12AffineEnvironment.transform 21 41261 env33257 = env33258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41261 env33257 == env33258) = true)

def env33259 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4161,41261,17,41311,8192,65,171329,5393,17665,179513,1365,21872,257,21792,46092,513]

theorem envBound33259 : H12AffineFastState.Bounded env33259 := by
  intro p hp
  have h : env33259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33258_33259 : H12AffineEnvironment.transform 6 8 env33258 = env33259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33258 == env33259) = true)

theorem identity33259 : scanCanonicalize (H12AffineFastState.compose env33259 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33259 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33260 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,131072,32040,1025,8540,4161,112,17,2,8192,65,146460,5393,17665,138340,1365,21872,257,21792,5457,513]

theorem envBound33260 : H12AffineFastState.Bounded env33260 := by
  intro p hp
  have h : env33260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33259_33260 : H12AffineEnvironment.transform 14 8541 env33259 = env33260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33259 == env33260) = true)

theorem identity33260 : scanCanonicalize (H12AffineFastState.compose env33260 (packedSelected [0,7,20] rootPS)) = affineNative (2^(16+1) ^^^ 17664) := by decide +kernel

theorem selectedBound33260 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env33261 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,17664,32040,1025,8540,4161,112,17,2,8192,65,31004,5393,17665,22884,1365,21872,257,21792,5457,513]

theorem envBound33261 : H12AffineFastState.Bounded env33261 := by
  intro p hp
  have h : env33261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33260_33261 : H12AffineEnvironment.transform 16 17664 env33260 = env33261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 17664 env33260 == env33261) = true)

theorem identity33261 : scanCanonicalize (H12AffineFastState.compose env33261 (packedSelected [9,14,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound33261 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env33262 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,16384,8541,8202,16400,30776,273,8540,4161,112,17,2,8192,65,31004,4097,16401,22884,69,20576,257,20528,4161,513]

theorem envBound33262 : H12AffineFastState.Bounded env33262 := by
  intro p hp
  have h : env33262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33261_33262 : H12AffineEnvironment.transform 9 272 env33261 = env33262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env33261 == env33262) = true)

theorem identity33262 : scanCanonicalize (H12AffineFastState.compose env33262 (packedSelected [14] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound33262 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env33263 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,8192,4404,8541,8202,4388,10508,273,8540,4161,112,17,2,8192,65,10280,4097,4389,2128,69,340,257,260,4161,513]

theorem envBound33263 : H12AffineFastState.Bounded env33263 := by
  intro p hp
  have h : env33263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33262_33263 : H12AffineEnvironment.transform 13 4404 env33262 = env33263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env33262 == env33263) = true)

theorem identity33263 : scanCanonicalize (H12AffineFastState.compose env33263 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound33263 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env33264 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,40,4404,373,34,4388,2340,273,372,4161,112,17,2,40,65,2048,4097,4389,2128,69,340,257,260,4161,513]

theorem envBound33264 : H12AffineFastState.Bounded env33264 := by
  intro p hp
  have h : env33264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33263_33264 : H12AffineEnvironment.transform 12 40 env33263 = env33264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env33263 == env33264) = true)

theorem identity33264 : scanCanonicalize (H12AffineFastState.compose env33264 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33264 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33265 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,4096,40,4112,81,34,4096,2048,53,80,4161,112,17,2,40,65,2048,4097,4097,2128,69,112,37,32,4161,513]

theorem envBound33265 : H12AffineFastState.Bounded env33265 := by
  intro p hp
  have h : env33265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33264_33265 : H12AffineEnvironment.transform 7 36 env33264 = env33265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33264 == env33265) = true)

theorem identity33265 : scanCanonicalize (H12AffineFastState.compose env33265 (packedSelected [1,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound33265 : packedSelected [1,3,5] rootPS < 2^1333 := by decide +kernel

def env33266 : List Nat := [2,4,8,16,32,64,8,36,512,52,2048,512,40,528,81,34,512,2048,53,80,577,112,17,2,40,65,2048,513,513,2128,69,112,37,32,577,513]

theorem envBound33266 : H12AffineFastState.Bounded env33266 := by
  intro p hp
  have h : env33266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33265_33266 : H12AffineEnvironment.transform 11 512 env33265 = env33266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env33265 == env33266) = true)

theorem identity33266 : scanCanonicalize (H12AffineFastState.compose env33266 (packedSelected [0,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound33266 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env33267 : List Nat := [2,4,8,16,32,64,8,36,512,52,576,512,40,528,81,34,512,576,53,80,577,112,17,2,40,65,576,513,513,528,69,112,37,32,577,513]

theorem envBound33267 : H12AffineFastState.Bounded env33267 := by
  intro p hp
  have h : env33267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33266_33267 : H12AffineEnvironment.transform 10 576 env33266 = env33267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env33266 == env33267) = true)

theorem identity33267 : scanCanonicalize (H12AffineFastState.compose env33267 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33267 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33268 : List Nat := [2,4,8,16,1,64,8,5,512,21,576,512,9,528,81,3,512,576,20,80,577,81,17,2,9,65,576,513,513,528,69,81,4,1,577,513]

theorem envBound33268 : H12AffineFastState.Bounded env33268 := by
  intro p hp
  have h : env33268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33267_33268 : H12AffineEnvironment.transform 4 1 env33267 = env33268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33267 == env33268) = true)

def env33269 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32041,1025,32769,4161,41261,17,41310,8193,65,171329,5393,17665,179512,1364,21872,257,21792,46093,513]

theorem envBound33269 : H12AffineFastState.Bounded env33269 := by
  intro p hp
  have h : env33269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33258_33269 : H12AffineEnvironment.transform 6 9 env33258 = env33269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33258 == env33269) = true)

theorem identity33269 : scanCanonicalize (H12AffineFastState.compose env33269 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33269 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env33270 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,4161,21873,17,21762,8193,65,157981,5393,17665,149860,1364,21872,257,21792,16465,513]

theorem envBound33270 : H12AffineFastState.Bounded env33270 := by
  intro p hp
  have h : env33270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33269_33270 : H12AffineEnvironment.transform 14 29788 env33269 = env33270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33269 == env33270) = true)

theorem identity33270 : scanCanonicalize (H12AffineFastState.compose env33270 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33270 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env33271 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,131072,10280,1025,8540,4161,112,17,3,8193,65,146460,5393,4096,138341,1364,113,257,33,5456,513]

theorem envBound33271 : H12AffineFastState.Bounded env33271 := by
  intro p hp
  have h : env33271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33270_33271 : H12AffineEnvironment.transform 13 5377 env33270 = env33271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33270 == env33271) = true)

theorem identity33271 : scanCanonicalize (H12AffineFastState.compose env33271 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33271 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33272 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,131072,10280,1025,8461,4112,33,17,3,8193,16,146460,5393,4096,138292,1285,32,257,33,5377,513]

theorem envBound33272 : H12AffineFastState.Bounded env33272 := by
  intro p hp
  have h : env33272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33271_33272 : H12AffineEnvironment.transform 5 17 env33271 = env33272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33271 == env33272) = true)

theorem identity33272 : scanCanonicalize (H12AffineFastState.compose env33272 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13340) := by decide +kernel

theorem selectedBound33272 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33273 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5377,8460,8202,13340,10280,1025,8461,4112,33,17,3,8193,16,2048,5393,4096,10280,1285,32,257,33,5377,513]

theorem envBound33273 : H12AffineFastState.Bounded env33273 := by
  intro p hp
  have h : env33273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33272_33273 : H12AffineEnvironment.transform 16 13340 env33272 = env33273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13340 env33272 == env33273) = true)

theorem identity33273 : scanCanonicalize (H12AffineFastState.compose env33273 (packedSelected [0,2,7] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33273 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33274 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5393,2341,1025,0,4112,33,17,3,268,16,2048,5393,4096,2341,1285,32,257,33,5377,513]

theorem envBound33274 : H12AffineFastState.Bounded env33274 := by
  intro p hp
  have h : env33274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33273_33274 : H12AffineEnvironment.transform 12 269 env33273 = env33274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33273 == env33274) = true)

theorem identity33274 : scanCanonicalize (H12AffineFastState.compose env33274 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33274 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33275 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,1,35,5173,2049,1025,0,4112,33,17,3,40,16,2048,5173,4096,2049,1057,32,37,33,5157,513]

theorem envBound33275 : H12AffineFastState.Bounded env33275 := by
  intro p hp
  have h : env33275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33274_33275 : H12AffineEnvironment.transform 7 36 env33274 = env33275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33274 == env33275) = true)

def env33276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,2097152,4194304,2101329,98780,8328,65,6433837,2098513,17664,2272753,2102684,6349853,257,21792,46212,2175562]

theorem envBound33276 : H12AffineFastState.Bounded env33276 := by
  intro p hp
  have h : env33276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33228_33276 : H12AffineEnvironment.transform 22 2101329 env33228 = env33276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env33228 == env33276) = true)

def env33277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4160,4194304,17,98780,8328,65,4340845,5393,17664,179633,1500,4256861,257,21792,46212,74250]

theorem envBound33277 : H12AffineFastState.Bounded env33277 := by
  intro p hp
  have h : env33277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33276_33277 : H12AffineEnvironment.transform 20 4160 env33276 = env33277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33276 == env33277) = true)

theorem identity33277 : scanCanonicalize (H12AffineFastState.compose env33277 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound33277 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,32160,1025,32769,4160,4194304,17,21762,8328,65,4340845,5393,17664,179633,1500,4256861,257,21792,46212,63188]

theorem envBound33278 : H12AffineFastState.Bounded env33278 := by
  intro p hp
  have h : env33278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33277_33278 : H12AffineEnvironment.transform 15 54494 env33277 = env33278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env33277 == env33278) = true)

def env33279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32040,1025,32769,4160,4194304,17,21762,8192,65,4340845,5393,17664,179513,1364,4256861,257,21792,46092,63068]

theorem envBound33279 : H12AffineFastState.Bounded env33279 := by
  intro p hp
  have h : env33279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33278_33279 : H12AffineEnvironment.transform 6 8 env33278 = env33279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33278 == env33279) = true)

theorem identity33279 : scanCanonicalize (H12AffineFastState.compose env33279 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33279 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,131072,32040,1025,8540,4160,4194304,17,21762,8192,65,4340845,5393,17664,138340,1364,4216064,257,21792,5457,22273]

theorem envBound33280 : H12AffineFastState.Bounded env33280 := by
  intro p hp
  have h : env33280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33279_33280 : H12AffineEnvironment.transform 14 8541 env33279 = env33280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33279 == env33280) = true)

theorem identity33280 : scanCanonicalize (H12AffineFastState.compose env33280 (packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,19,20,22,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 29740) := by decide +kernel

theorem selectedBound33280 : packedSelected [1,2,3,4,5,6,7,8,10,11,14,16,19,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env33281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29963,131072,32040,1025,8540,4160,29740,17,21762,8192,65,149569,5393,17664,138340,1364,8492,257,21792,5457,22273]

theorem envBound33281 : H12AffineFastState.Bounded env33281 := by
  intro p hp
  have h : env33281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33280_33281 : H12AffineEnvironment.transform 21 29740 env33280 = env33281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 29740 env33280 == env33281) = true)

theorem identity33281 : scanCanonicalize (H12AffineFastState.compose env33281 (packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound33281 : packedSelected [0,3,4,5,7,9,12,18,19,20] rootPS < 2^1333 := by decide +kernel

def env33282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,8192,16384,8541,27007,131072,24924,1025,8540,3124,26712,17,18806,8192,65,149569,2405,17664,131088,1364,8492,257,18772,2341,19317]

theorem envBound33282 : H12AffineFastState.Bounded env33282 := by
  intro p hp
  have h : env33282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33281_33282 : H12AffineEnvironment.transform 11 3188 env33281 = env33282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env33281 == env33282) = true)

theorem identity33282 : scanCanonicalize (H12AffineFastState.compose env33282 (packedSelected [0,2,3,4,5,6,7,11,12,14,16,19,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33282 : packedSelected [0,2,3,4,5,6,7,11,12,14,16,19,22] rootPS < 2^1333 := by decide +kernel

def env33283 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,16384,8460,26926,131072,24845,1025,8461,3124,26633,17,18727,8192,16,149520,2356,17664,131088,1285,8492,257,18693,2341,19236]

theorem envBound33283 : H12AffineFastState.Bounded env33283 := by
  intro p hp
  have h : env33283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33282_33283 : H12AffineEnvironment.transform 5 17 env33282 = env33283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33282 == env33283) = true)

theorem identity33283 : scanCanonicalize (H12AffineFastState.compose env33283 (packedSelected [0,1,2,4,6,7,8,9,10,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 27661) := by decide +kernel

theorem selectedBound33283 : packedSelected [0,1,2,4,6,7,8,9,10,14,15] rootPS < 2^1333 := by decide +kernel

def env33284 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,16384,8460,26926,27661,24845,1025,8461,3124,26633,17,18727,8192,16,9245,2356,17664,27677,1285,8492,257,18693,2341,19236]

theorem envBound33284 : H12AffineFastState.Bounded env33284 := by
  intro p hp
  have h : env33284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33283_33284 : H12AffineEnvironment.transform 16 27661 env33283 = env33284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 27661 env33283 == env33284) = true)

theorem identity33284 : scanCanonicalize (H12AffineFastState.compose env33284 (packedSelected [2,6,11,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 3345) := by decide +kernel

theorem selectedBound33284 : packedSelected [2,6,11,14,16] rootPS < 2^1333 := by decide +kernel

def env33285 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3109,8192,3345,8460,9279,8476,11292,1025,8461,3124,9496,17,1078,8192,16,9245,2356,2065,8460,1285,8492,257,1044,2341,1589]

theorem envBound33285 : H12AffineFastState.Bounded env33285 := by
  intro p hp
  have h : env33285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33284_33285 : H12AffineEnvironment.transform 13 3345 env33284 = env33285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3345 env33284 == env33285) = true)

theorem identity33285 : scanCanonicalize (H12AffineFastState.compose env33285 (packedSelected [2,3,4,5,6,9,10,18] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33285 : packedSelected [2,3,4,5,6,9,10,18] rootPS < 2^1333 := by decide +kernel

def env33286 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,17,8192,293,8460,9279,8476,8232,1025,8461,0,9496,17,1078,8192,16,9245,1280,1061,8460,1285,8492,257,1044,1297,1589]

theorem envBound33286 : H12AffineFastState.Bounded env33286 := by
  intro p hp
  have h : env33286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33285_33286 : H12AffineEnvironment.transform 10 1076 env33285 = env33286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env33285 == env33286) = true)

theorem identity33286 : scanCanonicalize (H12AffineFastState.compose env33286 (packedSelected [2,3,5,6,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound33286 : packedSelected [2,3,5,6,10,11] rootPS < 2^1333 := by decide +kernel

def env33287 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1076,17,1336,293,1076,263,1060,1296,1025,1077,0,32,17,1078,1336,16,293,1280,1061,1076,1285,1044,257,1044,1297,1589]

theorem envBound33287 : H12AffineFastState.Bounded env33287 := by
  intro p hp
  have h : env33287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33286_33287 : H12AffineEnvironment.transform 12 1336 env33286 = env33287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env33286 == env33287) = true)

theorem identity33287 : scanCanonicalize (H12AffineFastState.compose env33287 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound33287 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env33288 : List Nat := [2,4,8,16,32,17,8,256,16,1024,1076,17,1336,293,1076,263,1060,1296,1025,1077,0,32,17,1078,1336,16,293,1280,1061,1076,1285,1044,257,1044,1297,1061]

theorem envBound33288 : H12AffineFastState.Bounded env33288 := by
  intro p hp
  have h : env33288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33287_33288 : H12AffineEnvironment.transform 8 16 env33287 = env33288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env33287 == env33288) = true)

theorem identity33288 : scanCanonicalize (H12AffineFastState.compose env33288 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound33288 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env33289 : List Nat := [2,4,8,16,32,17,8,4,16,1024,1076,17,1084,33,1076,3,1060,1044,1025,1077,0,32,17,1078,1084,16,33,1028,1061,1076,1025,1044,5,1044,1045,1061]

theorem envBound33289 : H12AffineFastState.Bounded env33289 := by
  intro p hp
  have h : env33289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33288_33289 : H12AffineEnvironment.transform 7 4 env33288 = env33289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env33288 == env33289) = true)

theorem identity33289 : scanCanonicalize (H12AffineFastState.compose env33289 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33289 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33290 : List Nat := [2,4,8,0,32,1,8,4,0,1024,1060,1,1068,33,1060,3,1060,1028,1025,1061,0,32,1,1062,1068,0,33,1028,1061,1060,1025,1028,5,1028,1029,1061]

theorem envBound33290 : H12AffineFastState.Bounded env33290 := by
  intro p hp
  have h : env33290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33289_33290 : H12AffineEnvironment.transform 3 0 env33289 = env33290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33289 == env33290) = true)

def env33291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,32041,1025,32769,4160,4194304,17,21762,8193,65,4340845,5393,17664,179512,1365,4256861,257,21792,46093,63069]

theorem envBound33291 : H12AffineFastState.Bounded env33291 := by
  intro p hp
  have h : env33291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33278_33291 : H12AffineEnvironment.transform 6 9 env33278 = env33291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33278 == env33291) = true)

theorem identity33291 : scanCanonicalize (H12AffineFastState.compose env33291 (packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33291 : packedSelected [0,3,9,10,14,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env33292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4160,4194304,17,21762,8193,65,4340845,5393,17664,149860,1365,4194305,257,21792,16465,513]

theorem envBound33292 : H12AffineFastState.Bounded env33292 := by
  intro p hp
  have h : env33292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33291_33292 : H12AffineEnvironment.transform 14 29788 env33291 = env33292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33291 == env33292) = true)

theorem identity33292 : scanCanonicalize (H12AffineFastState.compose env33292 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 147505) := by decide +kernel

theorem selectedBound33292 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env33293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,8203,131072,32041,1025,29789,4160,147505,17,21762,8193,65,31836,5393,17664,149860,1365,147504,257,21792,16465,513]

theorem envBound33293 : H12AffineFastState.Bounded env33293 := by
  intro p hp
  have h : env33293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33292_33293 : H12AffineEnvironment.transform 21 147505 env33292 = env33293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 147505 env33292 == env33293) = true)

def env33294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,4194304,16,98780,8328,65,4340844,5392,17664,179632,1501,4256860,257,21792,46212,74251]

theorem envBound33294 : H12AffineFastState.Bounded env33294 := by
  intro p hp
  have h : env33294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33276_33294 : H12AffineEnvironment.transform 20 4161 env33276 = env33294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33276 == env33294) = true)

theorem identity33294 : scanCanonicalize (H12AffineFastState.compose env33294 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 98814) := by decide +kernel

theorem selectedBound33294 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32160,1025,32769,4161,98814,16,98780,8328,65,245138,5392,17664,179632,1501,95650,257,21792,46212,74251]

theorem envBound33295 : H12AffineFastState.Bounded env33295 := by
  intro p hp
  have h : env33295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33294_33295 : H12AffineEnvironment.transform 21 98814 env33294 = env33295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98814 env33294 == env33295) = true)

def env33296 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,98678,16,98644,8192,65,245018,5392,17664,179512,1365,95530,257,21792,46092,74251]

theorem envBound33296 : H12AffineFastState.Bounded env33296 := by
  intro p hp
  have h : env33296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33295_33296 : H12AffineEnvironment.transform 6 8 env33295 = env33296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33295 == env33296) = true)

theorem identity33296 : scanCanonicalize (H12AffineFastState.compose env33296 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound33296 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33297 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,32040,1025,29789,4161,95530,16,95496,8192,65,215366,5392,17664,149860,1365,95530,257,21792,16464,74251]

theorem envBound33297 : H12AffineFastState.Bounded env33297 := by
  intro p hp
  have h : env33297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33296_33297 : H12AffineEnvironment.transform 14 29788 env33296 = env33297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env33296 == env33297) = true)

theorem identity33297 : scanCanonicalize (H12AffineFastState.compose env33297 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33297 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33298 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29788,65536,131072,31836,1025,29789,4161,95326,16,95356,8192,65,215090,5220,17524,149520,1057,95326,117,21588,16464,74251]

theorem envBound33298 : H12AffineFastState.Bounded env33298 := by
  intro p hp
  have h : env33298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33297_33298 : H12AffineEnvironment.transform 7 116 env33297 = env33298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33297 == env33298) = true)

theorem identity33298 : scanCanonicalize (H12AffineFastState.compose env33298 (packedSelected [0,1,3,5,6,8,10,19,27] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33298 : packedSelected [0,1,3,5,6,8,10,19,27] rootPS < 2^1333 := by decide +kernel

def env33299 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29788,8203,131072,31836,1025,29789,4161,21589,16,21623,8192,65,157753,5220,17524,149520,1057,21589,117,21588,16464,512]

theorem envBound33299 : H12AffineFastState.Bounded env33299 := by
  intro p hp
  have h : env33299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33298_33299 : H12AffineEnvironment.transform 15 8203 env33298 = env33299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33298 == env33299) = true)

theorem identity33299 : scanCanonicalize (H12AffineFastState.compose env33299 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 24648) := by decide +kernel

theorem selectedBound33299 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33300 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,29788,8203,24648,31836,1025,29789,4161,21589,16,21623,8192,65,2161,5220,17524,10328,1057,21589,117,21588,16464,512]

theorem envBound33300 : H12AffineFastState.Bounded env33300 := by
  intro p hp
  have h : env33300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33299_33300 : H12AffineEnvironment.transform 16 24648 env33299 = env33300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24648 env33299 == env33300) = true)

theorem identity33300 : scanCanonicalize (H12AffineFastState.compose env33300 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound33300 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env33301 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,16384,21540,115,16432,23588,1025,21541,4161,21589,16,21623,120,65,2161,5220,17524,2080,1057,21589,117,21588,16464,512]

theorem envBound33301 : H12AffineFastState.Bounded env33301 := by
  intro p hp
  have h : env33301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33300_33301 : H12AffineEnvironment.transform 12 120 env33300 = env33301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env33300 == env33301) = true)

theorem identity33301 : scanCanonicalize (H12AffineFastState.compose env33301 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound33301 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env33302 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,120,5236,80,115,5188,2128,1025,81,4161,33,16,3,120,65,2161,5220,4096,2080,1057,33,117,32,5156,512]

theorem envBound33302 : H12AffineFastState.Bounded env33302 := by
  intro p hp
  have h : env33302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33301_33302 : H12AffineEnvironment.transform 13 5236 env33301 = env33302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env33301 == env33302) = true)

theorem identity33302 : scanCanonicalize (H12AffineFastState.compose env33302 (packedSelected [0,1,3,4,5,8,19] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33302 : packedSelected [0,1,3,4,5,8,19] rootPS < 2^1333 := by decide +kernel

def env33303 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,4096,88,5204,80,83,5188,2128,1025,81,4161,1,16,3,88,65,2129,5188,4096,2048,1025,1,85,0,5124,512]

theorem envBound33303 : H12AffineFastState.Bounded env33303 := by
  intro p hp
  have h : env33303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33302_33303 : H12AffineEnvironment.transform 4 0 env33302 = env33303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33302 == env33303) = true)

theorem identity33303 : scanCanonicalize (H12AffineFastState.compose env33303 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound33303 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33304 : List Nat := [2,4,8,16,0,64,8,84,512,1024,80,4096,88,5204,80,83,5188,0,1025,81,4161,1,16,3,88,65,1,5188,4096,80,1025,1,85,0,5124,512]

theorem envBound33304 : H12AffineFastState.Bounded env33304 := by
  intro p hp
  have h : env33304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33303_33304 : H12AffineEnvironment.transform 10 80 env33303 = env33304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env33303 == env33304) = true)

def env33305 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4161,98679,16,98645,8193,65,245019,5392,17664,179513,1364,95531,257,21792,46093,74251]

theorem envBound33305 : H12AffineFastState.Bounded env33305 := by
  intro p hp
  have h : env33305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33295_33305 : H12AffineEnvironment.transform 6 9 env33295 = env33305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33295 == env33305) = true)

theorem identity33305 : scanCanonicalize (H12AffineFastState.compose env33305 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound33305 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33306 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10280,1025,32769,4161,98679,16,98645,8193,65,245019,5392,4097,179513,1364,73770,257,33,46093,74251]

theorem envBound33306 : H12AffineFastState.Bounded env33306 := by
  intro p hp
  have h : env33306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33305_33306 : H12AffineEnvironment.transform 13 5377 env33305 = env33306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33305 == env33306) = true)

theorem identity33306 : scanCanonicalize (H12AffineFastState.compose env33306 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5441) := by decide +kernel

theorem selectedBound33306 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env33307 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5441,10280,1025,32769,4161,98679,16,98645,8193,65,108634,5392,4097,43128,1364,73770,257,33,46093,74251]

theorem envBound33307 : H12AffineFastState.Bounded env33307 := by
  intro p hp
  have h : env33307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33306_33307 : H12AffineEnvironment.transform 16 5441 env33306 = env33307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5441 env33306 == env33307) = true)

theorem identity33307 : scanCanonicalize (H12AffineFastState.compose env33307 (packedSelected [4,9,12,14,15,16,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound33307 : packedSelected [4,9,12,14,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env33308 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,65536,5441,10280,1025,8461,4161,73851,16,73817,8193,65,67926,5392,4097,2420,1364,73770,257,33,5377,74251]

theorem envBound33308 : H12AffineFastState.Bounded env33308 := by
  intro p hp
  have h : env33308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33307_33308 : H12AffineEnvironment.transform 14 8460 env33307 = env33308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env33307 == env33308) = true)

theorem identity33308 : scanCanonicalize (H12AffineFastState.compose env33308 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 8282) := by decide +kernel

theorem selectedBound33308 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env33309 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,8282,5441,10280,1025,8461,4161,33,16,3,8193,65,10508,5392,4097,2420,1364,112,257,33,5377,593]

theorem envBound33309 : H12AffineFastState.Bounded env33309 := by
  intro p hp
  have h : env33309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33308_33309 : H12AffineEnvironment.transform 15 8282 env33308 = env33309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8282 env33308 == env33309) = true)

theorem identity33309 : scanCanonicalize (H12AffineFastState.compose env33309 (packedSelected [4,9,11,14] rootPS)) = affineNative (2^(12+1) ^^^ 5481) := by decide +kernel

theorem selectedBound33309 : packedSelected [4,9,11,14] rootPS < 2^1333 := by decide +kernel

def env33310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5481,5377,5221,5427,5441,7489,1025,5220,4161,33,16,3,5480,65,7269,5392,4097,2420,1364,112,257,33,5377,593]

theorem envBound33310 : H12AffineFastState.Bounded env33310 := by
  intro p hp
  have h : env33310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33309_33310 : H12AffineEnvironment.transform 12 5481 env33309 = env33310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5481 env33309 == env33310) = true)

theorem identity33310 : scanCanonicalize (H12AffineFastState.compose env33310 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33310 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env33311 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,5433,5377,5173,5427,5393,7441,1025,5172,4113,33,16,3,5432,17,7221,5392,4097,2340,1284,32,257,33,5377,513]

theorem envBound33311 : H12AffineFastState.Bounded env33311 := by
  intro p hp
  have h : env33311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33310_33311 : H12AffineEnvironment.transform 5 16 env33310 = env33311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33310 == env33311) = true)

theorem identity33311 : scanCanonicalize (H12AffineFastState.compose env33311 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33312 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1076,269,309,1,263,293,2341,1025,0,1061,33,16,3,268,17,2049,292,1077,2340,1284,32,257,33,309,513]

theorem envBound33312 : H12AffineFastState.Bounded env33312 := by
  intro p hp
  have h : env33312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33311_33312 : H12AffineEnvironment.transform 11 1076 env33311 = env33312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env33311 == env33312) = true)

theorem identity33312 : scanCanonicalize (H12AffineFastState.compose env33312 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound33312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33313 : List Nat := [2,4,8,16,32,16,9,256,512,785,2048,805,269,309,1,263,293,2341,784,0,820,33,16,3,268,17,2049,292,804,2340,533,32,257,33,309,513]

theorem envBound33313 : H12AffineFastState.Bounded env33313 := by
  intro p hp
  have h : env33313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33312_33313 : H12AffineEnvironment.transform 9 785 env33312 = env33313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env33312 == env33313) = true)

theorem identity33313 : scanCanonicalize (H12AffineFastState.compose env33313 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound33313 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33314 : List Nat := [2,4,8,16,32,16,9,256,512,785,293,805,269,309,1,263,293,0,784,0,820,33,16,3,268,17,292,292,804,1,533,32,257,33,309,513]

theorem envBound33314 : H12AffineFastState.Bounded env33314 := by
  intro p hp
  have h : env33314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33313_33314 : H12AffineEnvironment.transform 10 293 env33313 = env33314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env33313 == env33314) = true)

theorem identity33314 : scanCanonicalize (H12AffineFastState.compose env33314 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound33314 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33315 : List Nat := [2,4,8,16,32,16,9,52,512,549,17,529,57,1,1,51,17,0,548,0,512,33,16,3,56,17,16,16,528,1,533,32,53,33,1,513]

theorem envBound33315 : H12AffineFastState.Bounded env33315 := by
  intro p hp
  have h : env33315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33314_33315 : H12AffineEnvironment.transform 7 52 env33314 = env33315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env33314 == env33315) = true)

def env33316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,8388608,10588556,8328,65,6433837,8393985,10507601,8568225,2102685,12645453,257,21793,46213,2175563]

theorem envBound33316 : H12AffineFastState.Bounded env33316 := by
  intro p hp
  have h : env33316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33227_33316 : H12AffineEnvironment.transform 17 32161 env33227 = env33316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32161 env33227 == env33316) = true)

def env33317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101328,98780,8328,65,6433837,2098513,17665,2272753,2102685,6349853,257,21793,46213,2175563]

theorem envBound33317 : H12AffineFastState.Bounded env33317 := by
  intro p hp
  have h : env33317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33316_33317 : H12AffineEnvironment.transform 22 2101328 env33316 = env33317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env33316 == env33317) = true)

def env33318 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,16,98780,8328,65,4340845,5393,17665,179633,1501,4256861,257,21793,46213,74251]

theorem envBound33318 : H12AffineFastState.Bounded env33318 := by
  intro p hp
  have h : env33318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33317_33318 : H12AffineEnvironment.transform 20 4160 env33317 = env33318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33317 == env33318) = true)

theorem identity33318 : scanCanonicalize (H12AffineFastState.compose env33318 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41460) := by decide +kernel

theorem selectedBound33318 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33319 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,41460,16,98780,8328,65,171417,5393,17665,179633,1501,21929,257,21793,46213,74251]

theorem envBound33319 : H12AffineFastState.Bounded env33319 := by
  intro p hp
  have h : env33319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33318_33319 : H12AffineEnvironment.transform 21 41460 env33318 = env33319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41460 env33318 == env33319) = true)

def env33320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,41340,16,98644,8192,65,171281,5393,17665,179513,1365,21793,257,21793,46093,74251]

theorem envBound33320 : H12AffineFastState.Bounded env33320 := by
  intro p hp
  have h : env33320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33319_33320 : H12AffineEnvironment.transform 6 8 env33319 = env33320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33319 == env33320) = true)

theorem identity33320 : scanCanonicalize (H12AffineFastState.compose env33320 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound33320 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,32041,1025,29788,4160,21793,16,95497,8192,65,158028,5393,17665,149860,1365,21793,257,21793,16464,74251]

theorem envBound33321 : H12AffineFastState.Bounded env33321 := by
  intro p hp
  have h : env33321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33320_33321 : H12AffineEnvironment.transform 14 29789 env33320 = env33321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env33320 == env33321) = true)

theorem identity33321 : scanCanonicalize (H12AffineFastState.compose env33321 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound33321 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,131072,32041,1025,29788,4160,21793,16,29791,8192,65,158028,5393,17665,149860,1365,21793,257,21793,16464,9053]

theorem envBound33322 : H12AffineFastState.Bounded env33322 := by
  intro p hp
  have h : env33322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33321_33322 : H12AffineEnvironment.transform 15 342 env33321 = env33322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env33321 == env33322) = true)

theorem identity33322 : scanCanonicalize (H12AffineFastState.compose env33322 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound33322 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env33323 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,342,5393,32041,1025,29788,4160,21793,16,29791,8192,65,31837,5393,17665,23669,1365,21793,257,21793,16464,9053]

theorem envBound33323 : H12AffineFastState.Bounded env33323 := by
  intro p hp
  have h : env33323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33322_33323 : H12AffineEnvironment.transform 16 5393 env33322 = env33323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env33322 == env33323) = true)

theorem identity33323 : scanCanonicalize (H12AffineFastState.compose env33323 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound33323 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env33324 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,0,342,5393,2420,1025,1,4160,8572,16,2,8192,65,2048,5393,12636,10280,1365,8572,257,8572,13325,9053]

theorem envBound33324 : H12AffineFastState.Bounded env33324 := by
  intro p hp
  have h : env33324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33323_33324 : H12AffineEnvironment.transform 13 13405 env33323 = env33324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env33323 == env33324) = true)

theorem identity33324 : scanCanonicalize (H12AffineFastState.compose env33324 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(11+1) ^^^ 2357) := by decide +kernel

theorem selectedBound33324 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33325 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,8192,11624,0,342,3108,2420,1025,1,2421,8572,16,2,8192,65,2048,3108,10345,10280,1365,8572,257,8572,11576,9053]

theorem envBound33325 : H12AffineFastState.Bounded env33325 := by
  intro p hp
  have h : env33325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33324_33325 : H12AffineEnvironment.transform 11 2357 env33324 = env33325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2357 env33324 == env33325) = true)

theorem identity33325 : scanCanonicalize (H12AffineFastState.compose env33325 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 2089) := by decide +kernel

theorem selectedBound33325 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env33326 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2357,2089,1345,0,342,3108,2420,1025,1,2421,2389,16,2,2089,65,2048,3108,64,1,1365,2389,257,2389,1297,2932]

theorem envBound33326 : H12AffineFastState.Bounded env33326 := by
  intro p hp
  have h : env33326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33325_33326 : H12AffineEnvironment.transform 12 2089 env33325 = env33326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2089 env33325 == env33326) = true)

theorem identity33326 : scanCanonicalize (H12AffineFastState.compose env33326 (packedSelected [2,3,4,5,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound33326 : packedSelected [2,3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env33327 : List Nat := [2,4,8,16,32,1,8,256,512,1024,2048,2357,2089,1280,0,279,3108,2357,1025,1,2356,2324,16,2,2089,0,2048,3108,1,1,1300,2324,257,2324,1297,2869]

theorem envBound33327 : H12AffineFastState.Bounded env33327 := by
  intro p hp
  have h : env33327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33326_33327 : H12AffineEnvironment.transform 5 1 env33326 = env33327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env33326 == env33327) = true)

theorem identity33327 : scanCanonicalize (H12AffineFastState.compose env33327 (packedSelected [0,1,2,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound33327 : packedSelected [0,1,2,6,7,8] rootPS < 2^1333 := by decide +kernel

def env33328 : List Nat := [2,4,8,16,32,1,8,256,512,1024,1281,1076,1320,1280,0,279,293,1076,1025,1,1077,1045,16,2,1320,0,1281,293,1,1,1300,1045,257,1045,1297,1588]

theorem envBound33328 : H12AffineFastState.Bounded env33328 := by
  intro p hp
  have h : env33328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33327_33328 : H12AffineEnvironment.transform 10 1281 env33327 = env33328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env33327 == env33328) = true)

theorem identity33328 : scanCanonicalize (H12AffineFastState.compose env33328 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound33328 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env33329 : List Nat := [2,4,8,16,32,1,8,256,512,53,308,1,285,309,0,279,293,1,52,1,0,32,16,2,285,0,308,293,1,1,289,32,257,32,292,513]

theorem envBound33329 : H12AffineFastState.Bounded env33329 := by
  intro p hp
  have h : env33329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33328_33329 : H12AffineEnvironment.transform 9 53 env33328 = env33329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env33328 == env33329) = true)

theorem identity33329 : scanCanonicalize (H12AffineFastState.compose env33329 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound33329 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33330 : List Nat := [2,4,8,16,32,1,8,256,16,53,308,1,285,309,0,279,293,1,52,1,0,32,16,2,285,0,308,293,1,1,289,32,257,32,292,17]

theorem envBound33330 : H12AffineFastState.Bounded env33330 := by
  intro p hp
  have h : env33330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33329_33330 : H12AffineEnvironment.transform 8 16 env33329 = env33330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env33329 == env33330) = true)

theorem identity33330 : scanCanonicalize (H12AffineFastState.compose env33330 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33330 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env33331 : List Nat := [2,4,8,16,32,1,8,37,16,53,17,1,56,16,0,50,0,1,52,1,0,32,16,2,56,0,17,0,1,1,4,32,36,32,1,17]

theorem envBound33331 : H12AffineFastState.Bounded env33331 := by
  intro p hp
  have h : env33331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33330_33331 : H12AffineEnvironment.transform 7 37 env33330 = env33331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33330 == env33331) = true)

theorem identity33331 : scanCanonicalize (H12AffineFastState.compose env33331 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound33331 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33332 : List Nat := [2,4,8,16,17,1,8,20,16,4,17,1,9,16,0,3,0,1,5,1,0,17,16,2,9,0,17,0,1,1,4,17,21,17,1,17]

theorem envBound33332 : H12AffineFastState.Bounded env33332 := by
  intro p hp
  have h : env33332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33331_33332 : H12AffineEnvironment.transform 4 17 env33331 = env33332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env33331 == env33332) = true)

def env33333 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,41341,16,98645,8193,65,171280,5393,17665,179512,1364,21792,257,21793,46092,74251]

theorem envBound33333 : H12AffineFastState.Bounded env33333 := by
  intro p hp
  have h : env33333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33319_33333 : H12AffineEnvironment.transform 6 9 env33319 = env33333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33319 == env33333) = true)

theorem identity33333 : scanCanonicalize (H12AffineFastState.compose env33333 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33333 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33334 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10280,1025,32769,4160,41341,16,98645,8193,65,171280,5393,4097,179512,1364,32,257,33,46092,74251]

theorem envBound33334 : H12AffineFastState.Bounded env33334 := by
  intro p hp
  have h : env33334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33333_33334 : H12AffineEnvironment.transform 13 5376 env33333 = env33334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33333 == env33334) = true)

theorem identity33334 : scanCanonicalize (H12AffineFastState.compose env33334 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound33334 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env33335 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,262,131072,10280,1025,32769,4160,41341,16,32851,8193,65,171280,5393,4097,179512,1364,32,257,33,46092,8973]

theorem envBound33335 : H12AffineFastState.Bounded env33335 := by
  intro p hp
  have h : env33335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33334_33335 : H12AffineEnvironment.transform 15 262 env33334 = env33335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env33334 == env33335) = true)

theorem identity33335 : scanCanonicalize (H12AffineFastState.compose env33335 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound33335 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env33336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,1,262,131072,10280,1025,0,4160,8572,16,82,8193,65,138513,5393,4097,146745,1364,32,257,33,13325,8973]

theorem envBound33336 : H12AffineFastState.Bounded env33336 := by
  intro p hp
  have h : env33336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33335_33336 : H12AffineEnvironment.transform 14 1 env33335 = env33336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env33335 == env33336) = true)

theorem identity33336 : scanCanonicalize (H12AffineFastState.compose env33336 (packedSelected [4,9,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33336 : packedSelected [4,9,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env33337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,1,262,131072,2341,1025,0,4160,113,16,82,268,65,138513,5393,4097,138292,1364,32,257,33,5376,512]

theorem envBound33337 : H12AffineFastState.Bounded env33337 := by
  intro p hp
  have h : env33337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33336_33337 : H12AffineEnvironment.transform 12 269 env33336 = env33337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33336 == env33337) = true)

theorem identity33337 : scanCanonicalize (H12AffineFastState.compose env33337 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(16+1) ^^^ 5425) := by decide +kernel

theorem selectedBound33337 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env33338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,1,262,5425,2341,1025,0,4160,113,16,82,268,65,2080,5393,4097,2309,1364,32,257,33,5376,512]

theorem envBound33338 : H12AffineFastState.Bounded env33338 := by
  intro p hp
  have h : env33338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33337_33338 : H12AffineEnvironment.transform 16 5425 env33337 = env33338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5425 env33337 == env33338) = true)

theorem identity33338 : scanCanonicalize (H12AffineFastState.compose env33338 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 1280) := by decide +kernel

theorem selectedBound33338 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env33339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1280,269,0,1,262,49,2341,1025,0,1344,113,16,82,268,65,2080,17,1281,2309,1364,32,257,33,0,512]

theorem envBound33339 : H12AffineFastState.Bounded env33339 := by
  intro p hp
  have h : env33339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33338_33339 : H12AffineEnvironment.transform 11 1280 env33338 = env33339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1280 env33338 == env33339) = true)

theorem identity33339 : scanCanonicalize (H12AffineFastState.compose env33339 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound33339 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env33340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,373,1280,269,0,1,262,49,80,1025,0,1344,113,16,82,268,65,341,17,1281,112,1364,32,257,33,0,512]

theorem envBound33340 : H12AffineFastState.Bounded env33340 := by
  intro p hp
  have h : env33340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33339_33340 : H12AffineEnvironment.transform 10 373 env33339 = env33340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env33339 == env33340) = true)

theorem identity33340 : scanCanonicalize (H12AffineFastState.compose env33340 (packedSelected [6,14] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33340 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env33341 : List Nat := [2,4,8,16,32,64,9,256,512,52,373,308,269,0,1,262,49,80,53,0,372,113,16,82,268,65,341,17,309,112,352,32,257,33,0,512]

theorem envBound33341 : H12AffineFastState.Bounded env33341 := by
  intro p hp
  have h : env33341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33340_33341 : H12AffineEnvironment.transform 9 52 env33340 = env33341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33340 == env33341) = true)

theorem identity33341 : scanCanonicalize (H12AffineFastState.compose env33341 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33341 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env33342 : List Nat := [2,4,8,16,32,64,9,37,512,52,80,17,40,0,1,35,49,80,53,0,81,113,16,82,41,65,112,17,16,112,69,32,36,33,0,512]

theorem envBound33342 : H12AffineFastState.Bounded env33342 := by
  intro p hp
  have h : env33342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33341_33342 : H12AffineEnvironment.transform 7 37 env33341 = env33342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33341 == env33342) = true)

theorem identity33342 : scanCanonicalize (H12AffineFastState.compose env33342 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound33342 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env33343 : List Nat := [2,4,8,16,32,48,9,37,512,52,32,17,40,0,1,35,49,32,53,0,33,1,16,34,41,49,0,17,16,0,53,32,36,33,0,512]

theorem envBound33343 : H12AffineFastState.Bounded env33343 := by
  intro p hp
  have h : env33343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33342_33343 : H12AffineEnvironment.transform 5 48 env33342 = env33343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env33342 == env33343) = true)

def env33344 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,17,98780,8328,65,4340844,5392,17665,179632,1500,4256860,257,21793,46213,74250]

theorem envBound33344 : H12AffineFastState.Bounded env33344 := by
  intro p hp
  have h : env33344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33317_33344 : H12AffineEnvironment.transform 20 4161 env33317 = env33344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33317 == env33344) = true)

theorem identity33344 : scanCanonicalize (H12AffineFastState.compose env33344 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound33344 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33345 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,32161,1025,29909,4161,4194304,17,95496,8328,65,4340844,5392,17665,149860,1500,4194440,257,21793,16465,74250]

theorem envBound33345 : H12AffineFastState.Bounded env33345 := by
  intro p hp
  have h : env33345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33344_33345 : H12AffineEnvironment.transform 14 29908 env33344 = env33345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env33344 == env33345) = true)

def env33346 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,10401,1025,8661,4161,4194304,17,73736,8328,65,4340844,5392,4097,138340,1500,4194440,257,33,5457,74250]

theorem envBound33346 : H12AffineFastState.Bounded env33346 := by
  intro p hp
  have h : env33346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33345_33346 : H12AffineEnvironment.transform 13 5376 env33345 = env33346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33345 == env33346) = true)

theorem identity33346 : scanCanonicalize (H12AffineFastState.compose env33346 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33346 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33347 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1025,8540,4161,4194304,17,73736,8193,65,4340844,5392,4097,138340,1365,4194305,257,33,5457,74250]

theorem envBound33347 : H12AffineFastState.Bounded env33347 := by
  intro p hp
  have h : env33347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33346_33347 : H12AffineEnvironment.transform 6 9 env33346 = env33347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33346 == env33347) = true)

theorem identity33347 : scanCanonicalize (H12AffineFastState.compose env33347 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 210234) := by decide +kernel

theorem selectedBound33347 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env33348 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10280,1025,8540,4161,210234,17,73736,8193,65,67926,5392,4097,138340,1365,210235,257,33,5457,74250]

theorem envBound33348 : H12AffineFastState.Bounded env33348 := by
  intro p hp
  have h : env33348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33347_33348 : H12AffineEnvironment.transform 21 210234 env33347 = env33348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210234 env33347 == env33348) = true)

theorem identity33348 : scanCanonicalize (H12AffineFastState.compose env33348 (packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33348 : packedSelected [0,2,3,4,5,6,9,10,11,16,18,27] rootPS < 2^1333 := by decide +kernel

def env33349 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,131072,10280,1025,8540,4161,136496,17,2,8193,65,10588,5392,4097,138340,1365,136497,257,33,5457,512]

theorem envBound33349 : H12AffineFastState.Bounded env33349 := by
  intro p hp
  have h : env33349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33348_33349 : H12AffineEnvironment.transform 15 8202 env33348 = env33349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33348 == env33349) = true)

theorem identity33349 : scanCanonicalize (H12AffineFastState.compose env33349 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 301) := by decide +kernel

theorem selectedBound33349 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33350 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,301,5376,112,295,131072,2309,1025,113,4161,136496,17,2,300,65,2161,5392,4097,138340,1365,136497,257,33,5457,512]

theorem envBound33350 : H12AffineFastState.Bounded env33350 := by
  intro p hp
  have h : env33350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33349_33350 : H12AffineEnvironment.transform 12 301 env33349 = env33350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 301 env33349 == env33350) = true)

theorem identity33350 : scanCanonicalize (H12AffineFastState.compose env33350 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound33350 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env33351 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1361,301,81,112,295,131072,2309,1025,113,1296,131169,17,2,300,65,2161,65,1360,133429,1365,131168,257,33,0,512]

theorem envBound33351 : H12AffineFastState.Bounded env33351 := by
  intro p hp
  have h : env33351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33350_33351 : H12AffineEnvironment.transform 11 1361 env33350 = env33351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env33350 == env33351) = true)

theorem identity33351 : scanCanonicalize (H12AffineFastState.compose env33351 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound33351 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env33352 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,276,301,81,112,295,131072,2309,68,113,341,131169,17,2,300,65,2161,65,277,133429,272,131168,257,33,0,512]

theorem envBound33352 : H12AffineFastState.Bounded env33352 := by
  intro p hp
  have h : env33352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33351_33352 : H12AffineEnvironment.transform 9 69 env33351 = env33352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env33351 == env33352) = true)

theorem identity33352 : scanCanonicalize (H12AffineFastState.compose env33352 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 2113) := by decide +kernel

theorem selectedBound33352 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env33353 : List Nat := [2,4,8,16,32,64,9,256,512,69,2048,276,301,81,112,295,2113,2309,68,113,341,2080,17,2,300,65,2161,65,277,372,272,2081,257,33,0,512]

theorem envBound33353 : H12AffineFastState.Bounded env33353 := by
  intro p hp
  have h : env33353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33352_33353 : H12AffineEnvironment.transform 16 2113 env33352 = env33353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 2113 env33352 == env33353) = true)

theorem identity33353 : scanCanonicalize (H12AffineFastState.compose env33353 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound33353 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env33354 : List Nat := [2,4,8,16,32,64,9,256,512,69,373,276,301,81,112,295,308,112,68,113,341,341,17,2,300,65,260,65,277,372,272,340,257,33,0,512]

theorem envBound33354 : H12AffineFastState.Bounded env33354 := by
  intro p hp
  have h : env33354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33353_33354 : H12AffineEnvironment.transform 10 373 env33353 = env33354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env33353 == env33354) = true)

theorem identity33354 : scanCanonicalize (H12AffineFastState.compose env33354 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33354 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env33355 : List Nat := [2,4,8,16,32,17,9,256,512,20,292,276,301,0,33,295,308,33,21,32,260,260,17,2,300,16,260,16,277,293,272,261,257,33,0,512]

theorem envBound33355 : H12AffineFastState.Bounded env33355 := by
  intro p hp
  have h : env33355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33354_33355 : H12AffineEnvironment.transform 5 17 env33354 = env33355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33354 == env33355) = true)

theorem identity33355 : scanCanonicalize (H12AffineFastState.compose env33355 (packedSelected [2,3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33355 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env33356 : List Nat := [2,4,8,16,32,17,9,5,512,20,33,17,40,0,33,34,49,33,21,32,1,1,17,2,41,16,1,16,16,32,21,0,4,33,0,512]

theorem envBound33356 : H12AffineFastState.Bounded env33356 := by
  intro p hp
  have h : env33356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33355_33356 : H12AffineEnvironment.transform 7 5 env33355 = env33356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33355 == env33356) = true)

theorem identity33356 : scanCanonicalize (H12AffineFastState.compose env33356 (packedSelected [0,2,7] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33356 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33357 : List Nat := [2,4,8,16,1,17,9,5,512,20,0,17,9,0,0,3,16,0,21,1,1,1,17,2,8,16,1,16,16,1,21,0,4,0,0,512]

theorem envBound33357 : H12AffineFastState.Bounded env33357 := by
  intro p hp
  have h : env33357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33356_33357 : H12AffineEnvironment.transform 4 1 env33356 = env33357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33356 == env33357) = true)

theorem identity33357 : scanCanonicalize (H12AffineFastState.compose env33357 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound33357 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33358 : List Nat := [2,1,8,16,1,17,9,0,512,17,0,17,9,0,0,3,16,0,16,1,1,1,17,2,8,16,1,16,16,1,16,0,1,0,0,512]

theorem envBound33358 : H12AffineFastState.Bounded env33358 := by
  intro p hp
  have h : env33358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33357_33358 : H12AffineEnvironment.transform 1 1 env33357 = env33358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env33357 == env33358) = true)

theorem identity33358 : scanCanonicalize (H12AffineFastState.compose env33358 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound33358 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33359 : List Nat := [1,1,8,16,1,17,9,0,512,17,0,17,9,0,0,0,16,0,16,1,1,1,17,1,8,16,1,16,16,1,16,0,1,0,0,512]

theorem envBound33359 : H12AffineFastState.Bounded env33359 := by
  intro p hp
  have h : env33359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33358_33359 : H12AffineEnvironment.transform 0 1 env33358 = env33359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env33358 == env33359) = true)

theorem identity33359 : scanCanonicalize (H12AffineFastState.compose env33359 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33359 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33360 : List Nat := [1,1,8,0,1,1,9,0,512,1,0,1,9,0,0,0,0,0,0,1,1,1,1,1,8,0,1,0,0,1,0,0,1,0,0,512]

theorem envBound33360 : H12AffineFastState.Bounded env33360 := by
  intro p hp
  have h : env33360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33359_33360 : H12AffineEnvironment.transform 3 0 env33359 = env33360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33359 == env33360) = true)

theorem identity33360 : scanCanonicalize (H12AffineFastState.compose env33360 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound33360 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env33361 : List Nat := [1,1,0,0,1,1,1,0,512,1,0,1,1,0,0,0,0,0,0,1,1,1,1,1,0,0,1,0,0,1,0,0,1,0,0,512]

theorem envBound33361 : H12AffineFastState.Bounded env33361 := by
  intro p hp
  have h : env33361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33360_33361 : H12AffineEnvironment.transform 2 0 env33360 = env33361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env33360 == env33361) = true)

theorem identity33361 : scanCanonicalize (H12AffineFastState.compose env33361 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound33361 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env33362 : List Nat := [1,1,0,0,1,1,1,0,1,1,0,1,1,0,0,0,0,0,0,1,1,1,1,1,0,0,1,0,0,1,0,0,1,0,0,1]

theorem envBound33362 : H12AffineFastState.Bounded env33362 := by
  intro p hp
  have h : env33362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33361_33362 : H12AffineEnvironment.transform 8 1 env33361 = env33362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env33361 == env33362) = true)

def env33363 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1025,8660,4161,4194304,17,73737,8328,65,4340844,5392,4096,138341,1500,4194440,257,32,5456,74250]

theorem envBound33363 : H12AffineFastState.Bounded env33363 := by
  intro p hp
  have h : env33363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33345_33363 : H12AffineEnvironment.transform 13 5377 env33345 = env33363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env33345 == env33363) = true)

theorem identity33363 : scanCanonicalize (H12AffineFastState.compose env33363 (packedSelected [0,3,4,5,7,8,10,11,12,15,16,18,20,22,23,28,31,32,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 210355) := by decide +kernel

theorem selectedBound33363 : packedSelected [0,3,4,5,7,8,10,11,12,15,16,18,20,22,23,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env33364 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,10400,1025,8660,4161,210355,17,73737,8328,65,68063,5392,4096,138341,1500,210235,257,32,5456,74250]

theorem envBound33364 : H12AffineFastState.Bounded env33364 := by
  intro p hp
  have h : env33364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33363_33364 : H12AffineEnvironment.transform 21 210355 env33363 = env33364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 210355 env33363 == env33364) = true)

theorem identity33364 : scanCanonicalize (H12AffineFastState.compose env33364 (packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound33364 : packedSelected [0,3,4,5,7,8,10,16,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env33365 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,5392,10400,1025,8660,4161,73891,17,73737,8328,65,68063,5392,4096,2421,1500,73771,257,32,5456,74250]

theorem envBound33365 : H12AffineFastState.Bounded env33365 := by
  intro p hp
  have h : env33365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33364_33365 : H12AffineEnvironment.transform 16 5392 env33364 = env33365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env33364 == env33365) = true)

theorem identity33365 : scanCanonicalize (H12AffineFastState.compose env33365 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound33365 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env33366 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,399,5392,10400,1025,8660,4161,8492,17,8582,8328,65,2128,5392,4096,2421,1500,8612,257,32,5456,9093]

theorem envBound33366 : H12AffineFastState.Bounded env33366 := by
  intro p hp
  have h : env33366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33365_33366 : H12AffineEnvironment.transform 15 399 env33365 = env33366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env33365 == env33366) = true)

theorem identity33366 : scanCanonicalize (H12AffineFastState.compose env33366 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33366 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env33367 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,137,399,5392,2556,1025,136,4161,112,17,218,468,65,2128,5392,4096,2421,1500,248,257,32,5456,729]

theorem envBound33367 : H12AffineFastState.Bounded env33367 := by
  intro p hp
  have h : env33367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33366_33367 : H12AffineEnvironment.transform 12 348 env33366 = env33367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33366 == env33367) = true)

theorem identity33367 : scanCanonicalize (H12AffineFastState.compose env33367 (packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound33367 : packedSelected [0,1,4,7,8,9,10,11,12,14] rootPS < 2^1333 := by decide +kernel

def env33368 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,41,5236,137,250,5221,2185,1025,136,4161,112,17,218,161,65,2128,5221,4096,2048,1193,248,116,32,5157,729]

theorem envBound33368 : H12AffineFastState.Bounded env33368 := by
  intro p hp
  have h : env33368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33367_33368 : H12AffineEnvironment.transform 7 117 env33367 = env33368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env33367 == env33368) = true)

theorem identity33368 : scanCanonicalize (H12AffineFastState.compose env33368 (packedSelected [2,4,6,9,12,18] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33368 : packedSelected [2,4,6,9,12,18] rootPS < 2^1333 := by decide +kernel

def env33369 : List Nat := [2,4,8,16,32,64,128,117,512,100,2048,4096,41,4112,137,250,4097,2185,101,136,4161,112,17,218,161,65,2128,4097,4096,2048,205,248,116,32,4161,729]

theorem envBound33369 : H12AffineFastState.Bounded env33369 := by
  intro p hp
  have h : env33369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33368_33369 : H12AffineEnvironment.transform 9 100 env33368 = env33369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33368 == env33369) = true)

theorem identity33369 : scanCanonicalize (H12AffineFastState.compose env33369 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33369 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env33370 : List Nat := [2,4,8,16,32,16,128,37,512,52,2048,4096,41,4112,137,170,4097,2185,53,136,4113,32,17,138,161,17,2048,4097,4096,2048,157,168,36,32,4113,649]

theorem envBound33370 : H12AffineFastState.Bounded env33370 := by
  intro p hp
  have h : env33370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33369_33370 : H12AffineEnvironment.transform 5 16 env33369 = env33370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33369 == env33370) = true)

theorem identity33370 : scanCanonicalize (H12AffineFastState.compose env33370 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound33370 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env33371 : List Nat := [2,4,8,16,32,16,128,37,0,52,2048,4096,41,4112,137,170,4097,2185,53,136,4113,32,17,138,161,17,2048,4097,4096,2048,157,168,36,32,4113,137]

theorem envBound33371 : H12AffineFastState.Bounded env33371 := by
  intro p hp
  have h : env33371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33370_33371 : H12AffineEnvironment.transform 8 0 env33370 = env33371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env33370 == env33371) = true)

theorem identity33371 : scanCanonicalize (H12AffineFastState.compose env33371 (packedSelected [0,1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound33371 : packedSelected [0,1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env33372 : List Nat := [2,4,8,16,32,16,128,37,0,52,2048,2201,41,2185,137,170,2200,2185,53,136,2184,32,17,138,161,17,2048,2200,2201,2048,157,168,36,32,2184,137]

theorem envBound33372 : H12AffineFastState.Bounded env33372 := by
  intro p hp
  have h : env33372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33371_33372 : H12AffineEnvironment.transform 11 2201 env33371 = env33372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env33371 == env33372) = true)

theorem identity33372 : scanCanonicalize (H12AffineFastState.compose env33372 (packedSelected [0,2,3,5] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound33372 : packedSelected [0,2,3,5] rootPS < 2^1333 := by decide +kernel

def env33373 : List Nat := [2,4,8,16,32,16,40,37,0,52,2048,2097,41,2081,33,2,2096,2081,53,32,2080,32,17,34,9,17,2048,2096,2097,2048,53,0,36,32,2080,33]

theorem envBound33373 : H12AffineFastState.Bounded env33373 := by
  intro p hp
  have h : env33373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33372_33373 : H12AffineEnvironment.transform 6 40 env33372 = env33373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env33372 == env33373) = true)

theorem identity33373 : scanCanonicalize (H12AffineFastState.compose env33373 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33373 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env33374 : List Nat := [2,4,8,16,1,16,9,4,0,21,2048,2064,8,2048,0,2,2065,2048,20,1,2049,1,17,3,9,17,2048,2065,2064,2048,20,0,5,1,2049,0]

theorem envBound33374 : H12AffineFastState.Bounded env33374 := by
  intro p hp
  have h : env33374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33373_33374 : H12AffineEnvironment.transform 4 1 env33373 = env33374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33373 == env33374) = true)

theorem identity33374 : scanCanonicalize (H12AffineFastState.compose env33374 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 31) := by decide +kernel

theorem selectedBound33374 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33375 : List Nat := [2,4,8,16,1,16,9,4,0,21,31,15,8,31,0,2,14,31,20,1,30,1,17,3,9,17,31,14,15,31,20,0,5,1,30,0]

theorem envBound33375 : H12AffineFastState.Bounded env33375 := by
  intro p hp
  have h : env33375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33374_33375 : H12AffineEnvironment.transform 10 31 env33374 = env33375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env33374 == env33375) = true)

def leafEnv33375 : List Nat := [2,4,8,16,1,16,9,4,0,21,31,15,8,31,0,2,14,31,20,1,30,1,17,3,21,9,1,17,31,14,15,31,20,0,5,1,5,3,30,0,1,31,0]

def active33375 : List Nat := [0,1,2,3]

def tree33375 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33375 : H12WitnessSearch.Good tree33375 := H12GlobalWitnessIndex.good

theorem leafIdentity33375 : H12AffineFastState.composeSystem env33375 rootObs = leafEnv33375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33375 rootObs == leafEnv33375) = true)

theorem terminalChecked33375 : H12PackedTerminal.terminalCheckFast leafEnv33375 active33375 tree33375 = true := by decide +kernel

def env33376 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,2097152,4194304,2101329,98781,8328,65,6433837,2098512,17664,2272752,2102685,6349852,257,21793,46213,2175563]

theorem envBound33376 : H12AffineFastState.Bounded env33376 := by
  intro p hp
  have h : env33376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33316_33376 : H12AffineEnvironment.transform 22 2101329 env33316 = env33376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env33316 == env33376) = true)

def env33377 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4160,4194304,17,98781,8328,65,4340845,5392,17664,179632,1501,4256860,257,21793,46213,74251]

theorem envBound33377 : H12AffineFastState.Bounded env33377 := by
  intro p hp
  have h : env33377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33376_33377 : H12AffineEnvironment.transform 20 4160 env33376 = env33377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env33376 == env33377) = true)

def env33378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32041,1025,32769,4160,4194304,17,98645,8192,65,4340845,5392,17664,179512,1365,4256860,257,21793,46093,74251]

theorem envBound33378 : H12AffineFastState.Bounded env33378 := by
  intro p hp
  have h : env33378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33377_33378 : H12AffineEnvironment.transform 6 8 env33377 = env33378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33377 == env33378) = true)

theorem identity33378 : scanCanonicalize (H12AffineFastState.compose env33378 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33378 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,32041,1025,8540,4160,4194304,17,73736,8192,65,4340845,5392,17664,138341,1365,4216065,257,21793,5456,74251]

theorem envBound33379 : H12AffineFastState.Bounded env33379 := by
  intro p hp
  have h : env33379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33378_33379 : H12AffineEnvironment.transform 14 8541 env33378 = env33379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33378 == env33379) = true)

theorem identity33379 : scanCanonicalize (H12AffineFastState.compose env33379 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound33379 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env33380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,32041,1025,8540,4160,4194304,17,73736,8192,65,4283511,5392,17664,97407,1365,4216065,257,21793,5456,74251]

theorem envBound33380 : H12AffineFastState.Bounded env33380 := by
  intro p hp
  have h : env33380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33379_33380 : H12AffineEnvironment.transform 16 90138 env33379 = env33380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env33379 == env33380) = true)

theorem identity33380 : scanCanonicalize (H12AffineFastState.compose env33380 (packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS)) = affineNative (2^(21+1) ^^^ 21589) := by decide +kernel

theorem selectedBound33380 : packedSelected [0,3,5,7,9,10,12,14,20,22,38] rootPS < 2^1333 := by decide +kernel

def env33381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,32041,1025,8540,4160,21589,17,73736,8192,65,67618,5392,17664,97407,1365,340,257,21793,5456,74251]

theorem envBound33381 : H12AffineFastState.Bounded env33381 := by
  intro p hp
  have h : env33381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33380_33381 : H12AffineEnvironment.transform 21 21589 env33380 = env33381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21589 env33380 == env33381) = true)

theorem identity33381 : scanCanonicalize (H12AffineFastState.compose env33381 (packedSelected [3,4,5,9,10,14,15,16,41] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound33381 : packedSelected [3,4,5,9,10,14,15,16,41] rootPS < 2^1333 := by decide +kernel

def env33382 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8574,16740,32041,1025,8540,4160,21589,17,374,8192,65,10588,5392,17664,23809,1365,340,257,21793,5456,885]

theorem envBound33382 : H12AffineFastState.Bounded env33382 := by
  intro p hp
  have h : env33382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33381_33382 : H12AffineEnvironment.transform 15 8574 env33381 = env33382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env33381 == env33382) = true)

theorem identity33382 : scanCanonicalize (H12AffineFastState.compose env33382 (packedSelected [2,11,14,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound33382 : packedSelected [2,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33383 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8233,8202,16400,31837,1025,8232,4160,21589,17,2,8192,65,10280,5220,17524,23669,1057,32,117,21589,5156,513]

theorem envBound33383 : H12AffineFastState.Bounded env33383 := by
  intro p hp
  have h : env33383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33382_33383 : H12AffineEnvironment.transform 7 116 env33382 = env33383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env33382 == env33383) = true)

theorem identity33383 : scanCanonicalize (H12AffineFastState.compose env33383 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound33383 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33384 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,5157,8233,8202,5173,10360,1025,8232,4160,112,17,2,8192,65,10280,5220,4177,2128,1057,32,117,112,5156,513]

theorem envBound33384 : H12AffineFastState.Bounded env33384 := by
  intro p hp
  have h : env33384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33383_33384 : H12AffineEnvironment.transform 13 5157 env33383 = env33384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env33383 == env33384) = true)

theorem identity33384 : scanCanonicalize (H12AffineFastState.compose env33384 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound33384 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33385 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,8192,4161,8233,8202,4177,10360,101,8232,4160,112,17,2,8192,65,10280,4096,4177,2128,69,32,117,112,4160,513]

theorem envBound33385 : H12AffineFastState.Bounded env33385 := by
  intro p hp
  have h : env33385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33384_33385 : H12AffineEnvironment.transform 9 100 env33384 = env33385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env33384 == env33385) = true)

theorem identity33385 : scanCanonicalize (H12AffineFastState.compose env33385 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound33385 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33386 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,4096,40,4161,1,34,4177,2128,101,0,4160,112,17,2,40,65,2048,4096,4177,2128,69,32,117,112,4160,513]

theorem envBound33386 : H12AffineFastState.Bounded env33386 := by
  intro p hp
  have h : env33386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33385_33386 : H12AffineEnvironment.transform 12 40 env33385 = env33386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env33385 == env33386) = true)

theorem identity33386 : scanCanonicalize (H12AffineFastState.compose env33386 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound33386 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33387 : List Nat := [2,4,8,16,32,64,8,116,512,100,2048,17,40,80,1,34,64,2128,101,0,81,112,17,2,40,65,2048,17,64,2128,69,32,117,112,81,513]

theorem envBound33387 : H12AffineFastState.Bounded env33387 := by
  intro p hp
  have h : env33387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33386_33387 : H12AffineEnvironment.transform 11 17 env33386 = env33387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env33386 == env33387) = true)

theorem identity33387 : scanCanonicalize (H12AffineFastState.compose env33387 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33387 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33388 : List Nat := [2,4,8,16,32,64,8,116,512,100,0,17,40,80,1,34,64,80,101,0,81,112,17,2,40,65,0,17,64,80,69,32,117,112,81,513]

theorem envBound33388 : H12AffineFastState.Bounded env33388 := by
  intro p hp
  have h : env33388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33387_33388 : H12AffineEnvironment.transform 10 0 env33387 = env33388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33387 == env33388) = true)

def env33389 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98644,8193,65,4340845,5392,17664,179513,1364,4256860,257,21793,46092,74251]

theorem envBound33389 : H12AffineFastState.Bounded env33389 := by
  intro p hp
  have h : env33389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33377_33389 : H12AffineEnvironment.transform 6 9 env33377 = env33389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33377 == env33389) = true)

theorem identity33389 : scanCanonicalize (H12AffineFastState.compose env33389 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound33389 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env33390 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,32040,1025,32769,4160,4194304,17,41310,8193,65,4340845,5392,17664,179513,1364,4256860,257,21793,46092,513]

theorem envBound33390 : H12AffineFastState.Bounded env33390 := by
  intro p hp
  have h : env33390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33389_33390 : H12AffineEnvironment.transform 15 8202 env33389 = env33390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env33389 == env33390) = true)

theorem identity33390 : scanCanonicalize (H12AffineFastState.compose env33390 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound33390 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env33391 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4160,4194304,17,21763,8193,65,4340845,5392,17664,149860,1364,4194305,257,21793,16465,513]

theorem envBound33391 : H12AffineFastState.Bounded env33391 := by
  intro p hp
  have h : env33391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33390_33391 : H12AffineEnvironment.transform 14 29789 env33390 = env33391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env33390 == env33391) = true)

theorem identity33391 : scanCanonicalize (H12AffineFastState.compose env33391 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound33391 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env33392 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8202,131072,32040,1025,29788,4160,21872,17,21763,8193,65,157981,5392,17664,149860,1364,21873,257,21793,16465,513]

theorem envBound33392 : H12AffineFastState.Bounded env33392 := by
  intro p hp
  have h : env33392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33391_33392 : H12AffineEnvironment.transform 21 21872 env33391 = env33392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env33391 == env33392) = true)

theorem identity33392 : scanCanonicalize (H12AffineFastState.compose env33392 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound33392 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env33393 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,8202,131072,10280,1025,8540,4160,112,17,3,8193,65,146461,5392,4096,138340,1364,113,257,33,5457,513]

theorem envBound33393 : H12AffineFastState.Bounded env33393 := by
  intro p hp
  have h : env33393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33392_33393 : H12AffineEnvironment.transform 13 5376 env33392 = env33393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env33392 == env33393) = true)

theorem identity33393 : scanCanonicalize (H12AffineFastState.compose env33393 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound33393 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33394 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5376,8460,8202,131072,10280,1025,8461,4113,33,17,3,8193,16,146461,5392,4096,138293,1285,32,257,33,5376,513]

theorem envBound33394 : H12AffineFastState.Bounded env33394 := by
  intro p hp
  have h : env33394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33393_33394 : H12AffineEnvironment.transform 5 17 env33393 = env33394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33393 == env33394) = true)

theorem identity33394 : scanCanonicalize (H12AffineFastState.compose env33394 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33394 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33395 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,263,131072,2341,1025,0,4113,33,17,3,268,16,138512,5392,4096,138293,1285,32,257,33,5376,513]

theorem envBound33395 : H12AffineFastState.Bounded env33395 := by
  intro p hp
  have h : env33395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33394_33395 : H12AffineEnvironment.transform 12 269 env33394 = env33395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33394 == env33395) = true)

theorem identity33395 : scanCanonicalize (H12AffineFastState.compose env33395 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound33395 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env33396 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,1,263,5172,2341,1025,0,4113,33,17,3,268,16,2340,5392,4096,2049,1285,32,257,33,5376,513]

theorem envBound33396 : H12AffineFastState.Bounded env33396 := by
  intro p hp
  have h : env33396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33395_33396 : H12AffineEnvironment.transform 16 5172 env33395 = env33396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env33395 == env33396) = true)

theorem identity33396 : scanCanonicalize (H12AffineFastState.compose env33396 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33396 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env33397 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,1,35,5172,2049,1025,0,4113,33,17,3,40,16,2048,5172,4096,2049,1057,32,37,33,5156,513]

theorem envBound33397 : H12AffineFastState.Bounded env33397 := by
  intro p hp
  have h : env33397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33396_33397 : H12AffineEnvironment.transform 7 36 env33396 = env33397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33396 == env33397) = true)

def env33398 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,1,35,1028,2049,1025,0,33,33,17,3,40,16,2048,1028,48,2049,1057,32,37,33,1044,513]

theorem envBound33398 : H12AffineFastState.Bounded env33398 := by
  intro p hp
  have h : env33398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33397_33398 : H12AffineEnvironment.transform 11 48 env33397 = env33398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env33397 == env33398) = true)

theorem identity33398 : scanCanonicalize (H12AffineFastState.compose env33398 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound33398 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33399 : List Nat := [2,4,8,16,32,17,9,36,512,20,2048,48,41,0,1,35,16,2049,21,0,33,33,17,3,40,16,2048,16,48,2049,53,32,37,33,0,513]

theorem envBound33399 : H12AffineFastState.Bounded env33399 := by
  intro p hp
  have h : env33399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33398_33399 : H12AffineEnvironment.transform 9 20 env33398 = env33399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env33398 == env33399) = true)

def env33400 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,16,9,0,1,3,16,2049,21,0,1,1,17,3,8,16,2048,16,16,2049,21,0,5,1,0,513]

theorem envBound33400 : H12AffineFastState.Bounded env33400 := by
  intro p hp
  have h : env33400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33399_33400 : H12AffineEnvironment.transform 4 0 env33399 = env33400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33399 == env33400) = true)

theorem identity33400 : scanCanonicalize (H12AffineFastState.compose env33400 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound33400 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33401 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,0,1,3,16,0,21,0,1,1,17,3,8,16,1,16,16,0,21,0,5,1,0,513]

theorem envBound33401 : H12AffineFastState.Bounded env33401 := by
  intro p hp
  have h : env33401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33400_33401 : H12AffineEnvironment.transform 10 1 env33400 = env33401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env33400 == env33401) = true)

def leafEnv33401 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,0,1,3,16,0,21,0,1,1,17,3,20,8,1,16,1,16,16,0,21,0,5,1,5,2,0,513,1,1,0]

def active33401 : List Nat := [0,1,2,3,8]

def tree33401 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33401 : H12WitnessSearch.Good tree33401 := H12GlobalWitnessIndex.good

theorem leafIdentity33401 : H12AffineFastState.composeSystem env33401 rootObs = leafEnv33401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33401 rootObs == leafEnv33401) = true)

theorem terminalChecked33401 : H12PackedTerminal.terminalCheckFast leafEnv33401 active33401 tree33401 = true := by decide +kernel

def env33402 : List Nat := [2,4,8,16,1,17,9,5,512,20,2048,17,8,0,1,2,16,2049,21,0,0,0,17,3,9,16,2048,16,17,2049,20,1,4,0,0,513]

theorem envBound33402 : H12AffineFastState.Bounded env33402 := by
  intro p hp
  have h : env33402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33399_33402 : H12AffineEnvironment.transform 4 1 env33399 = env33402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33399 == env33402) = true)

theorem identity33402 : scanCanonicalize (H12AffineFastState.compose env33402 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound33402 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33403 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,17,8,0,1,2,16,523,21,0,0,0,17,3,9,16,522,16,17,523,20,1,4,0,0,513]

theorem envBound33403 : H12AffineFastState.Bounded env33403 := by
  intro p hp
  have h : env33403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33402_33403 : H12AffineEnvironment.transform 10 522 env33402 = env33403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env33402 == env33403) = true)

def leafEnv33403 : List Nat := [2,4,8,16,1,17,9,5,512,20,522,17,8,0,1,2,16,523,21,0,0,0,17,3,21,9,1,16,522,16,17,523,20,1,4,0,5,3,0,513,1,0,0]

def active33403 : List Nat := [0,1,2,3,8]

def tree33403 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33403 : H12WitnessSearch.Good tree33403 := H12GlobalWitnessIndex.good

theorem leafIdentity33403 : H12AffineFastState.composeSystem env33403 rootObs = leafEnv33403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33403 rootObs == leafEnv33403) = true)

theorem terminalChecked33403 : H12PackedTerminal.terminalCheckFast leafEnv33403 active33403 tree33403 = true := by decide +kernel

def env33404 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,1,35,1029,2049,1025,0,32,33,17,3,40,16,2048,1029,49,2049,1057,32,37,33,1045,513]

theorem envBound33404 : H12AffineFastState.Bounded env33404 := by
  intro p hp
  have h : env33404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33397_33404 : H12AffineEnvironment.transform 11 49 env33397 = env33404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env33397 == env33404) = true)

theorem identity33404 : scanCanonicalize (H12AffineFastState.compose env33404 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33405 : List Nat := [2,4,8,16,0,17,9,4,512,1024,2048,17,9,1045,1,3,1029,2049,1025,0,0,1,17,3,8,16,2048,1029,17,2049,1025,0,5,1,1045,513]

theorem envBound33405 : H12AffineFastState.Bounded env33405 := by
  intro p hp
  have h : env33405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33404_33405 : H12AffineEnvironment.transform 4 0 env33404 = env33405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33404 == env33405) = true)

def env33406 : List Nat := [2,4,8,16,0,17,9,4,512,20,2048,17,9,1,1,3,17,2049,21,0,0,1,17,3,8,16,2048,17,17,2049,21,0,5,1,1,513]

theorem envBound33406 : H12AffineFastState.Bounded env33406 := by
  intro p hp
  have h : env33406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33405_33406 : H12AffineEnvironment.transform 9 20 env33405 = env33406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env33405 == env33406) = true)

theorem identity33406 : scanCanonicalize (H12AffineFastState.compose env33406 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound33406 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33407 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,1,1,3,17,1,21,0,0,1,17,3,8,16,0,17,17,1,21,0,5,1,1,513]

theorem envBound33407 : H12AffineFastState.Bounded env33407 := by
  intro p hp
  have h : env33407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33406_33407 : H12AffineEnvironment.transform 10 0 env33406 = env33407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env33406 == env33407) = true)

def leafEnv33407 : List Nat := [2,4,8,16,0,17,9,4,512,20,0,17,9,1,1,3,17,1,21,0,0,1,17,3,20,8,1,16,0,17,17,1,21,0,5,1,5,2,1,513,1,0,0]

def active33407 : List Nat := [0,1,2,3,8]

def tree33407 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33407 : H12WitnessSearch.Good tree33407 := H12GlobalWitnessIndex.good

theorem leafIdentity33407 : H12AffineFastState.composeSystem env33407 rootObs = leafEnv33407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33407 rootObs == leafEnv33407) = true)

theorem terminalChecked33407 : H12PackedTerminal.terminalCheckFast leafEnv33407 active33407 tree33407 = true := by decide +kernel

def env33408 : List Nat := [2,4,8,16,0,17,9,4,512,21,2048,17,9,0,1,3,16,2049,20,0,0,1,17,3,8,16,2048,16,17,2049,20,0,5,1,0,513]

theorem envBound33408 : H12AffineFastState.Bounded env33408 := by
  intro p hp
  have h : env33408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33405_33408 : H12AffineEnvironment.transform 9 21 env33405 = env33408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33405 == env33408) = true)

theorem identity33408 : scanCanonicalize (H12AffineFastState.compose env33408 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound33408 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33409 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,17,9,0,1,3,16,522,20,0,0,1,17,3,8,16,523,16,17,522,20,0,5,1,0,513]

theorem envBound33409 : H12AffineFastState.Bounded env33409 := by
  intro p hp
  have h : env33409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33408_33409 : H12AffineEnvironment.transform 10 523 env33408 = env33409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env33408 == env33409) = true)

def leafEnv33409 : List Nat := [2,4,8,16,0,17,9,4,512,21,523,17,9,0,1,3,16,522,20,0,0,1,17,3,21,8,1,16,523,16,17,522,20,0,5,1,5,2,0,513,1,0,0]

def active33409 : List Nat := [0,1,2,3,8]

def tree33409 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood33409 : H12WitnessSearch.Good tree33409 := H12GlobalWitnessIndex.good

theorem leafIdentity33409 : H12AffineFastState.composeSystem env33409 rootObs = leafEnv33409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env33409 rootObs == leafEnv33409) = true)

theorem terminalChecked33409 : H12PackedTerminal.terminalCheckFast leafEnv33409 active33409 tree33409 = true := by decide +kernel

def env33410 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,4194304,16,98781,8328,65,4340844,5393,17664,179633,1500,4256861,257,21793,46213,74250]

theorem envBound33410 : H12AffineFastState.Bounded env33410 := by
  intro p hp
  have h : env33410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33376_33410 : H12AffineEnvironment.transform 20 4161 env33376 = env33410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env33376 == env33410) = true)

theorem identity33410 : scanCanonicalize (H12AffineFastState.compose env33410 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 21792) := by decide +kernel

theorem selectedBound33410 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env33411 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32161,1025,32769,4161,21792,16,98781,8328,65,158028,5393,17664,179633,1500,41341,257,21793,46213,74250]

theorem envBound33411 : H12AffineFastState.Bounded env33411 := by
  intro p hp
  have h : env33411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33410_33411 : H12AffineEnvironment.transform 21 21792 env33410 = env33411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21792 env33410 == env33411) = true)

theorem identity33411 : scanCanonicalize (H12AffineFastState.compose env33411 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33411 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env33412 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32161,1025,32769,4161,21792,16,41430,8328,65,158028,5393,17664,179633,1500,41341,257,21793,46213,513]

theorem envBound33412 : H12AffineFastState.Bounded env33412 := by
  intro p hp
  have h : env33412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33411_33412 : H12AffineEnvironment.transform 15 8203 env33411 = env33412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33411 == env33412) = true)

theorem identity33412 : scanCanonicalize (H12AffineFastState.compose env33412 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound33412 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env33413 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,32161,1025,32769,4161,21792,16,41430,8328,65,10589,5393,17664,64928,1500,41341,257,21793,46213,513]

theorem envBound33413 : H12AffineFastState.Bounded env33413 := by
  intro p hp
  have h : env33413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33412_33413 : H12AffineEnvironment.transform 16 16401 env33412 = env33413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env33412 == env33413) = true)

theorem identity33413 : scanCanonicalize (H12AffineFastState.compose env33413 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 217) := by decide +kernel

theorem selectedBound33413 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env33414 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,217,8203,16401,32161,1025,216,4161,21792,16,8463,8328,65,10589,5393,17664,32121,1500,8612,257,21793,13404,513]

theorem envBound33414 : H12AffineFastState.Bounded env33414 := by
  intro p hp
  have h : env33414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33413_33414 : H12AffineEnvironment.transform 14 217 env33413 = env33414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 217 env33413 == env33414) = true)

theorem identity33414 : scanCanonicalize (H12AffineFastState.compose env33414 (packedSelected [1,5,8,18,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33414 : packedSelected [1,5,8,18,23,24] rootPS < 2^1333 := by decide +kernel

def env33415 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,137,8203,16401,32161,1025,136,4113,21792,16,8463,8328,17,10509,5393,17664,32041,1420,8612,257,21793,13324,513]

theorem envBound33415 : H12AffineFastState.Bounded env33415 := by
  intro p hp
  have h : env33415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33414_33415 : H12AffineEnvironment.transform 5 16 env33414 = env33415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33414 == env33415) = true)

theorem identity33415 : scanCanonicalize (H12AffineFastState.compose env33415 (packedSelected [0,1,4,5,6,7,9,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 11413) := by decide +kernel

theorem selectedBound33415 : packedSelected [0,1,4,5,6,7,9,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env33416 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,11413,137,8203,11396,4404,1025,136,4113,14773,16,8463,8328,17,10509,5393,10645,4540,1420,8612,257,14772,13324,513]

theorem envBound33416 : H12AffineFastState.Bounded env33416 := by
  intro p hp
  have h : env33416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33415_33416 : H12AffineEnvironment.transform 13 11413 env33415 = env33416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11413 env33415 == env33416) = true)

theorem identity33416 : scanCanonicalize (H12AffineFastState.compose env33416 (packedSelected [1,4,5,6,7,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound33416 : packedSelected [1,4,5,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env33417 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1196,8192,11413,137,8203,11396,1432,1025,136,1213,11545,16,8463,8328,17,10509,445,10645,1296,1420,8612,257,11544,8352,513]

theorem envBound33417 : H12AffineFastState.Bounded env33417 := by
  intro p hp
  have h : env33417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33416_33417 : H12AffineEnvironment.transform 11 1196 env33416 = env33417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env33416 == env33417) = true)

theorem identity33417 : scanCanonicalize (H12AffineFastState.compose env33417 (packedSelected [0,5,6,7,8,10] rootPS)) = affineNative (2^(12+1) ^^^ 2316) := by decide +kernel

theorem selectedBound33417 : packedSelected [0,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env33418 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,1196,2316,1433,137,2311,1416,1432,1025,136,1213,1045,16,2051,2436,17,1,445,153,1296,1420,2216,257,1044,2476,513]

theorem envBound33418 : H12AffineFastState.Bounded env33418 := by
  intro p hp
  have h : env33418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33417_33418 : H12AffineEnvironment.transform 12 2316 env33417 = env33418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2316 env33417 == env33418) = true)

theorem identity33418 : scanCanonicalize (H12AffineFastState.compose env33418 (packedSelected [1,2,3,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound33418 : packedSelected [1,2,3,4,7] rootPS < 2^1333 := by decide +kernel

def env33419 : List Nat := [2,4,8,16,32,16,128,173,512,1024,2048,1196,2209,1076,137,2218,1061,1077,1025,136,1213,1045,16,2051,2089,17,1,16,153,1213,1057,2216,172,1044,2049,513]

theorem envBound33419 : H12AffineFastState.Bounded env33419 := by
  intro p hp
  have h : env33419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33418_33419 : H12AffineEnvironment.transform 7 173 env33418 = env33419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env33418 == env33419) = true)

theorem identity33419 : scanCanonicalize (H12AffineFastState.compose env33419 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1213) := by decide +kernel

theorem selectedBound33419 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env33420 : List Nat := [2,4,8,16,32,16,128,173,512,1024,1213,1196,1052,1076,137,1047,1061,1077,1025,136,1213,1045,16,1214,1172,17,1,16,153,1213,1057,1045,172,1044,1212,513]

theorem envBound33420 : H12AffineFastState.Bounded env33420 := by
  intro p hp
  have h : env33420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33419_33420 : H12AffineEnvironment.transform 10 1213 env33419 = env33420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1213 env33419 == env33420) = true)

theorem identity33420 : scanCanonicalize (H12AffineFastState.compose env33420 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 188) := by decide +kernel

theorem selectedBound33420 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33421 : List Nat := [2,4,8,16,32,16,128,173,512,188,1,16,160,136,137,171,153,137,189,136,1,169,16,2,40,17,1,16,153,1,157,169,172,168,0,513]

theorem envBound33421 : H12AffineFastState.Bounded env33421 := by
  intro p hp
  have h : env33421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33420_33421 : H12AffineEnvironment.transform 9 188 env33420 = env33421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 188 env33420 == env33421) = true)

def env33422 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254785,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound33422 : H12AffineFastState.Bounded env33422 := by
  intro p hp
  have h : env33422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31962_33422 : H12AffineEnvironment.transform 29 155254785 env31962 = env33422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254785 env31962 == env33422) = true)

def env33423 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254785,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound33423 : H12AffineFastState.Bounded env33423 := by
  intro p hp
  have h : env33423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33422_33423 : H12AffineEnvironment.transform 25 64 env33422 = env33423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env33422 == env33423) = true)

def env33424 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356289,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound33424 : H12AffineFastState.Bounded env33424 := by
  intro p hp
  have h : env33424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33423_33424 : H12AffineEnvironment.transform 26 30393344 env33423 = env33424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env33423 == env33424) = true)

def env33425 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830977,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound33425 : H12AffineFastState.Bounded env33425 := by
  intro p hp
  have h : env33425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33424_33425 : H12AffineEnvironment.transform 18 1024 env33424 = env33425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env33424 == env33425) = true)

theorem identity33425 : scanCanonicalize (H12AffineFastState.compose env33425 (packedSelected [13] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound33425 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env33426 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,8388608,16777216,8328,64,29843805,18949585,10507600,8806748,25240909,23160256,256,27354608,27337993,25166491]

theorem envBound33426 : H12AffineFastState.Bounded env33426 := by
  intro p hp
  have h : env33426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33425_33426 : H12AffineEnvironment.transform 14 8541 env33425 = env33426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env33425 == env33426) = true)

def env33427 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,147456,16777216,8328,64,21307741,18949585,2233680,270684,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound33427 : H12AffineFastState.Bounded env33427 := by
  intro p hp
  have h : env33427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33426_33427 : H12AffineEnvironment.transform 22 147456 env33426 = env33427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env33426 == env33427) = true)

def env33428 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147456,16777216,8328,64,21039613,18949585,2233680,2556,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound33428 : H12AffineFastState.Bounded env33428 := by
  intro p hp
  have h : env33428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33427_33428 : H12AffineEnvironment.transform 17 10400 env33427 = env33428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env33427 == env33428) = true)

def env33429 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147456,73856,8328,64,4204925,2098513,2233680,2556,148941,6309184,256,2229616,2246025,221723]

theorem envBound33429 : H12AffineFastState.Bounded env33429 := by
  intro p hp
  have h : env33429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33428_33429 : H12AffineEnvironment.transform 23 73856 env33428 = env33429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73856 env33428 == env33429) = true)

theorem identity33429 : scanCanonicalize (H12AffineFastState.compose env33429 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound33429 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env33430 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10281,1024,8540,2097152,4194304,147456,73737,8193,64,4204925,2098513,2233680,2421,148804,6309184,256,2229616,2245888,221723]

theorem envBound33430 : H12AffineFastState.Bounded env33430 := by
  intro p hp
  have h : env33430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33429_33430 : H12AffineEnvironment.transform 6 9 env33429 = env33430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env33429 == env33430) = true)

def env33431 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,2097152,4194304,147456,73737,8193,16,4204845,2098433,2233600,2341,148756,6309136,256,2229536,2245888,221723]

theorem envBound33431 : H12AffineFastState.Bounded env33431 := by
  intro p hp
  have h : env33431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33430_33431 : H12AffineEnvironment.transform 5 16 env33430 = env33431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33430 == env33431) = true)

theorem identity33431 : scanCanonicalize (H12AffineFastState.compose env33431 (packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound33431 : packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env33432 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,131072,10281,1024,8460,17680,4194304,147456,73737,8193,16,4204845,16401,151568,2341,148756,4194304,256,147504,131088,221723]

theorem envBound33432 : H12AffineFastState.Bounded env33432 := by
  intro p hp
  have h : env33432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33431_33432 : H12AffineEnvironment.transform 20 17680 env33431 = env33432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env33431 == env33432) = true)

theorem identity33432 : scanCanonicalize (H12AffineFastState.compose env33432 (packedSelected [3,5,10,17] rootPS)) = affineNative (2^(16+1) ^^^ 24860) := by decide +kernel

theorem selectedBound33432 : packedSelected [3,5,10,17] rootPS < 2^1333 := by decide +kernel

def env33433 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,24860,10281,1024,8460,17680,4194304,8476,73737,8193,16,4204845,16401,12556,2341,9224,4194304,256,8492,24844,66311]

theorem envBound33433 : H12AffineFastState.Bounded env33433 := by
  intro p hp
  have h : env33433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33432_33433 : H12AffineEnvironment.transform 16 24860 env33432 = env33433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24860 env33432 == env33433) = true)

theorem identity33433 : scanCanonicalize (H12AffineFastState.compose env33433 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound33433 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env33434 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,65536,24860,10281,1024,8460,17680,33,8476,73737,8193,16,10508,16401,12556,2341,9224,33,256,8492,24844,66311]

theorem envBound33434 : H12AffineFastState.Bounded env33434 := by
  intro p hp
  have h : env33434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33433_33434 : H12AffineEnvironment.transform 21 33 env33433 = env33434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env33433 == env33434) = true)

theorem identity33434 : scanCanonicalize (H12AffineFastState.compose env33434 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33434 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env33435 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,65536,16401,2340,1024,1,17680,33,17,65796,268,16,2049,16401,4097,2341,1285,33,256,33,16385,66311]

theorem envBound33435 : H12AffineFastState.Bounded env33435 := by
  intro p hp
  have h : env33435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33434_33435 : H12AffineEnvironment.transform 12 269 env33434 = env33435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33434 == env33435) = true)

theorem identity33435 : scanCanonicalize (H12AffineFastState.compose env33435 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 23356) := by decide +kernel

theorem selectedBound33435 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env33436 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,0,23356,16401,2340,1024,1,17680,33,17,23096,268,16,2049,16401,4097,2341,1285,33,256,33,16385,22587]

theorem envBound33436 : H12AffineFastState.Bounded env33436 := by
  intro p hp
  have h : env33436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33435_33436 : H12AffineEnvironment.transform 15 23356 env33435 = env33436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 23356 env33435 == env33436) = true)

theorem identity33436 : scanCanonicalize (H12AffineFastState.compose env33436 (packedSelected [1,3,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound33436 : packedSelected [1,3,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33437 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,16384,0,23097,16401,2081,1024,1,17429,33,17,23096,9,16,2049,16401,4097,2080,1024,33,5,33,16385,22587]

theorem envBound33437 : H12AffineFastState.Bounded env33437 := by
  intro p hp
  have h : env33437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33436_33437 : H12AffineEnvironment.transform 7 5 env33436 = env33437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env33436 == env33437) = true)

theorem identity33437 : scanCanonicalize (H12AffineFastState.compose env33437 (packedSelected [11] rootPS)) = affineNative (2^(13+1) ^^^ 3614) := by decide +kernel

theorem selectedBound33437 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env33438 : List Nat := [2,4,8,16,32,16,9,5,512,1024,2048,4096,8,3614,0,5159,3599,2081,1024,1,2571,33,17,5158,9,16,2049,3599,4097,2080,1024,33,5,33,3615,5669]

theorem envBound33438 : H12AffineFastState.Bounded env33438 := by
  intro p hp
  have h : env33438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33437_33438 : H12AffineEnvironment.transform 13 3614 env33437 = env33438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3614 env33437 == env33438) = true)

theorem identity33438 : scanCanonicalize (H12AffineFastState.compose env33438 (packedSelected [2,6,12] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound33438 : packedSelected [2,6,12] rootPS < 2^1333 := by decide +kernel

def env33439 : List Nat := [2,4,8,16,32,16,9,5,512,543,2048,4096,8,2049,0,4664,2064,2081,543,1,2571,33,17,4665,9,16,2049,2064,4097,2080,543,33,5,33,2048,4154]

theorem envBound33439 : H12AffineFastState.Bounded env33439 := by
  intro p hp
  have h : env33439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33438_33439 : H12AffineEnvironment.transform 9 543 env33438 = env33439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env33438 == env33439) = true)

def env33440 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,4194304,147456,73737,8193,17,4204844,2098432,2233601,2340,148757,6309137,256,2229537,2245888,221723]

theorem envBound33440 : H12AffineFastState.Bounded env33440 := by
  intro p hp
  have h : env33440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33430_33440 : H12AffineEnvironment.transform 5 17 env33430 = env33440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env33430 == env33440) = true)

theorem identity33440 : scanCanonicalize (H12AffineFastState.compose env33440 (packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 2303274) := by decide +kernel

theorem selectedBound33440 : packedSelected [1,2,6,8,9,11,12,14,15,19,22,23] rootPS < 2^1333 := by decide +kernel

def env33441 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,65536,131072,10281,1024,8461,2097152,2303274,147456,73737,8193,17,2296838,2098432,2233601,2340,148757,221243,256,2229537,2245888,221723]

theorem envBound33441 : H12AffineFastState.Bounded env33441 := by
  intro p hp
  have h : env33441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33440_33441 : H12AffineEnvironment.transform 21 2303274 env33440 = env33441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2303274 env33440 == env33441) = true)

theorem identity33441 : scanCanonicalize (H12AffineFastState.compose env33441 (packedSelected [2,6,9,11,12,14,15,16,18,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound33441 : packedSelected [2,6,9,11,12,14,15,16,18,20,22] rootPS < 2^1333 := by decide +kernel

def env33442 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,263,131072,10281,1024,8461,2097152,2237485,147456,8462,8193,17,2231553,2098432,2233601,2340,148757,155964,256,2229537,2245888,156444]

theorem envBound33442 : H12AffineFastState.Bounded env33442 := by
  intro p hp
  have h : env33442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33441_33442 : H12AffineEnvironment.transform 15 263 env33441 = env33442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env33441 == env33442) = true)

theorem identity33442 : scanCanonicalize (H12AffineFastState.compose env33442 (packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound33442 : packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env33443 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,263,24861,10281,1024,8461,2097152,2114864,8477,8462,8193,17,2124828,2098432,2126876,2340,9224,33,256,2122812,2106397,513]

theorem envBound33443 : H12AffineFastState.Bounded env33443 := by
  intro p hp
  have h : env33443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33442_33443 : H12AffineEnvironment.transform 16 24861 env33442 = env33443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env33442 == env33443) = true)

theorem identity33443 : scanCanonicalize (H12AffineFastState.compose env33443 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 17681) := by decide +kernel

theorem selectedBound33443 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33444 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,263,24861,10281,1024,8461,17681,33,8477,8462,8193,17,10509,16401,12557,2340,9224,33,256,8493,24844,513]

theorem envBound33444 : H12AffineFastState.Bounded env33444 := by
  intro p hp
  have h : env33444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33443_33444 : H12AffineEnvironment.transform 20 17681 env33443 = env33444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17681 env33443 == env33444) = true)

theorem identity33444 : scanCanonicalize (H12AffineFastState.compose env33444 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound33444 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33445 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,16384,1,263,16400,2340,1024,0,17681,33,16,3,268,17,2048,16401,4096,2340,1285,33,256,32,16385,513]

theorem envBound33445 : H12AffineFastState.Bounded env33445 := by
  intro p hp
  have h : env33445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33444_33445 : H12AffineEnvironment.transform 12 269 env33444 = env33445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env33444 == env33445) = true)

theorem identity33445 : scanCanonicalize (H12AffineFastState.compose env33445 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound33445 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33446 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1076,269,16384,1,263,16400,2340,1024,0,17681,33,16,3,268,17,2048,16401,1076,2340,1285,33,256,32,16385,513]

theorem envBound33446 : H12AffineFastState.Bounded env33446 := by
  intro p hp
  have h : env33446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33445_33446 : H12AffineEnvironment.transform 11 1076 env33445 = env33446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env33445 == env33446) = true)

theorem identity33446 : scanCanonicalize (H12AffineFastState.compose env33446 (packedSelected [1,3] rootPS)) = affineNative (2^(13+1) ^^^ 2367) := by decide +kernel

theorem selectedBound33446 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33447 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1076,269,2367,1,263,2351,2340,1024,0,3118,33,16,3,268,17,2048,2350,1076,2340,1285,33,256,32,2366,513]

theorem envBound33447 : H12AffineFastState.Bounded env33447 := by
  intro p hp
  have h : env33447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33446_33447 : H12AffineEnvironment.transform 13 2367 env33446 = env33447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2367 env33446 == env33447) = true)

theorem identity33447 : scanCanonicalize (H12AffineFastState.compose env33447 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 43) := by decide +kernel

theorem selectedBound33447 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33448 : List Nat := [2,4,8,16,32,17,9,256,512,1024,43,1076,269,276,1,263,260,271,1024,0,1029,33,16,3,268,17,43,261,1076,271,1285,33,256,32,277,513]

theorem envBound33448 : H12AffineFastState.Bounded env33448 := by
  intro p hp
  have h : env33448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33447_33448 : H12AffineEnvironment.transform 10 43 env33447 = env33448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 43 env33447 == env33448) = true)

theorem identity33448 : scanCanonicalize (H12AffineFastState.compose env33448 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound33448 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env33449 : List Nat := [2,4,8,16,32,17,9,36,512,1024,43,1076,41,48,1,35,32,43,1024,0,1029,33,16,3,40,17,43,33,1076,43,1057,33,36,32,49,513]

theorem envBound33449 : H12AffineFastState.Bounded env33449 := by
  intro p hp
  have h : env33449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33448_33449 : H12AffineEnvironment.transform 7 36 env33448 = env33449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env33448 == env33449) = true)

theorem identity33449 : scanCanonicalize (H12AffineFastState.compose env33449 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound33449 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env33450 : List Nat := [2,4,8,16,32,17,9,36,512,21,43,33,41,48,1,35,32,43,21,0,16,33,16,3,40,17,43,33,33,43,52,33,36,32,49,513]

theorem envBound33450 : H12AffineFastState.Bounded env33450 := by
  intro p hp
  have h : env33450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33449_33450 : H12AffineEnvironment.transform 9 21 env33449 = env33450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env33449 == env33450) = true)

theorem identity33450 : scanCanonicalize (H12AffineFastState.compose env33450 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33450 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env33451 : List Nat := [2,4,8,16,0,17,9,4,512,21,11,1,9,16,1,3,0,11,21,0,16,1,16,3,8,17,11,1,1,11,20,1,4,0,17,513]

theorem envBound33451 : H12AffineFastState.Bounded env33451 := by
  intro p hp
  have h : env33451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33450_33451 : H12AffineEnvironment.transform 4 0 env33450 = env33451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33450 == env33451) = true)

theorem identity33451 : scanCanonicalize (H12AffineFastState.compose env33451 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound33451 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33452 : List Nat := [2,4,8,16,0,17,9,4,30,21,11,1,9,16,1,3,0,11,21,0,16,1,16,3,8,17,11,1,1,11,20,1,4,0,17,31]

theorem envBound33452 : H12AffineFastState.Bounded env33452 := by
  intro p hp
  have h : env33452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33451_33452 : H12AffineEnvironment.transform 8 30 env33451 = env33452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env33451 == env33452) = true)

theorem identity33452 : scanCanonicalize (H12AffineFastState.compose env33452 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound33452 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33453 : List Nat := [2,4,8,7,0,6,9,4,9,2,11,1,9,7,1,3,0,11,2,0,7,1,7,3,8,6,11,1,1,11,3,1,4,0,6,8]

theorem envBound33453 : H12AffineFastState.Bounded env33453 := by
  intro p hp
  have h : env33453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33452_33453 : H12AffineEnvironment.transform 3 7 env33452 = env33453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env33452 == env33453) = true)

def env33454 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10400,1024,8540,2097152,4194304,147456,73857,8328,64,4204924,2098512,2233680,2556,148940,6309185,256,2229617,2246024,221722]

theorem envBound33454 : H12AffineFastState.Bounded env33454 := by
  intro p hp
  have h : env33454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33428_33454 : H12AffineEnvironment.transform 23 73857 env33428 = env33454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 73857 env33428 == env33454) = true)

theorem identity33454 : scanCanonicalize (H12AffineFastState.compose env33454 (packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound33454 : packedSelected [0,4,7,11,12,15,16,18,20,22,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env33455 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10400,1024,8540,2097152,4194304,73755,73857,8328,64,4204924,2098512,2192715,2556,75223,6309185,256,2188650,2172307,513]

theorem envBound33455 : H12AffineFastState.Bounded env33455 := by
  intro p hp
  have h : env33455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33454_33455 : H12AffineEnvironment.transform 16 90139 env33454 = env33455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env33454 == env33455) = true)

def env33456 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10400,1024,8540,2097152,32,73755,73857,8328,64,10588,2098512,2192715,2556,75223,2114913,256,2188650,2172307,513]

theorem envBound33456 : H12AffineFastState.Bounded env33456 := by
  intro p hp
  have h : env33456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33455_33456 : H12AffineEnvironment.transform 21 32 env33455 = env33456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env33455 == env33456) = true)

theorem identity33456 : scanCanonicalize (H12AffineFastState.compose env33456 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 91586) := by decide +kernel

theorem selectedBound33456 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33457 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10400,1024,8540,91586,32,73755,73857,8328,64,10588,90258,4233,2556,75223,73891,256,168,16465,513]

theorem envBound33457 : H12AffineFastState.Bounded env33457 := by
  intro p hp
  have h : env33457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33456_33457 : H12AffineEnvironment.transform 20 91586 env33456 = env33457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91586 env33456 == env33457) = true)

theorem identity33457 : scanCanonicalize (H12AffineFastState.compose env33457 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33457 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,23] rootPS < 2^1333 := by decide +kernel

def env33458 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10400,1024,8540,17865,32,16,138,8328,64,10588,16537,4233,2556,1500,168,256,168,16465,513]

theorem envBound33458 : H12AffineFastState.Bounded env33458 := by
  intro p hp
  have h : env33458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33457_33458 : H12AffineEnvironment.transform 15 8203 env33457 = env33458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33457 == env33458) = true)

theorem identity33458 : scanCanonicalize (H12AffineFastState.compose env33458 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound33458 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env33459 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,1,343,16400,2556,1024,0,17865,32,16,138,468,64,2048,16537,4233,2556,1500,168,256,168,16465,513]

theorem envBound33459 : H12AffineFastState.Bounded env33459 := by
  intro p hp
  have h : env33459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33458_33459 : H12AffineEnvironment.transform 12 348 env33458 = env33459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env33458 == env33459) = true)

theorem identity33459 : scanCanonicalize (H12AffineFastState.compose env33459 (packedSelected [0,1,2,4,5,7,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 5100) := by decide +kernel

theorem selectedBound33459 : packedSelected [0,1,2,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env33460 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5100,1,343,5116,2556,1024,0,5669,32,16,138,468,64,2048,4981,4233,2556,1500,168,256,168,5053,513]

theorem envBound33460 : H12AffineFastState.Bounded env33460 := by
  intro p hp
  have h : env33460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33459_33460 : H12AffineEnvironment.transform 13 5100 env33459 = env33460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5100 env33459 == env33460) = true)

theorem identity33460 : scanCanonicalize (H12AffineFastState.compose env33460 (packedSelected [1,3,4,5,8,9,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound33460 : packedSelected [1,3,4,5,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env33461 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,348,4916,1,343,4900,2340,1024,0,5669,32,16,82,268,64,2048,4981,4177,2340,1284,112,256,112,4965,513]

theorem envBound33461 : H12AffineFastState.Bounded env33461 := by
  intro p hp
  have h : env33461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33460_33461 : H12AffineEnvironment.transform 6 88 env33460 = env33461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env33460 == env33461) = true)

theorem identity33461 : scanCanonicalize (H12AffineFastState.compose env33461 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound33461 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env33462 : List Nat := [2,4,8,16,32,64,88,256,16,1024,2048,4096,348,4388,1,343,4404,2340,1024,0,5173,32,16,82,268,64,2048,4453,4177,2340,1284,112,256,112,4469,17]

theorem envBound33462 : H12AffineFastState.Bounded env33462 := by
  intro p hp
  have h : env33462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33461_33462 : H12AffineEnvironment.transform 8 16 env33461 = env33462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env33461 == env33462) = true)

theorem identity33462 : scanCanonicalize (H12AffineFastState.compose env33462 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound33462 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env33463 : List Nat := [2,4,8,16,32,64,88,256,16,1024,1281,4096,348,4388,1,343,4404,1061,1024,0,5173,32,16,82,268,64,1281,4453,4177,1061,1284,112,256,112,4469,17]

theorem envBound33463 : H12AffineFastState.Bounded env33463 := by
  intro p hp
  have h : env33463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33462_33463 : H12AffineEnvironment.transform 10 1281 env33462 = env33463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env33462 == env33463) = true)

theorem identity33463 : scanCanonicalize (H12AffineFastState.compose env33463 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33463 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env33464 : List Nat := [2,4,8,16,32,64,88,256,16,52,309,4096,348,4388,1,343,4404,17,52,0,4097,32,16,82,268,64,309,4453,4177,17,304,112,256,112,4469,17]

theorem envBound33464 : H12AffineFastState.Bounded env33464 := by
  intro p hp
  have h : env33464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33463_33464 : H12AffineEnvironment.transform 9 52 env33463 = env33464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33463 == env33464) = true)

theorem identity33464 : scanCanonicalize (H12AffineFastState.compose env33464 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound33464 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env33465 : List Nat := [2,4,8,16,32,64,88,256,16,52,309,16,348,308,1,343,292,17,52,0,17,32,16,82,268,64,309,373,65,17,304,112,256,112,357,17]

theorem envBound33465 : H12AffineFastState.Bounded env33465 := by
  intro p hp
  have h : env33465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33464_33465 : H12AffineEnvironment.transform 11 16 env33464 = env33465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env33464 == env33465) = true)

theorem identity33465 : scanCanonicalize (H12AffineFastState.compose env33465 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound33465 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env33466 : List Nat := [2,4,8,16,32,16,8,256,16,52,309,16,268,308,1,263,292,17,52,0,17,32,16,2,268,16,309,293,17,17,304,32,256,32,309,17]

theorem envBound33466 : H12AffineFastState.Bounded env33466 := by
  intro p hp
  have h : env33466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33465_33466 : H12AffineEnvironment.transform 5 16 env33465 = env33466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env33465 == env33466) = true)

theorem identity33466 : scanCanonicalize (H12AffineFastState.compose env33466 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound33466 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env33467 : List Nat := [2,4,8,16,32,16,8,37,16,52,16,16,41,17,1,34,1,17,52,0,17,32,16,2,41,16,16,0,17,17,21,32,37,32,16,17]

theorem envBound33467 : H12AffineFastState.Bounded env33467 := by
  intro p hp
  have h : env33467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33466_33467 : H12AffineEnvironment.transform 7 37 env33466 = env33467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env33466 == env33467) = true)

theorem identity33467 : scanCanonicalize (H12AffineFastState.compose env33467 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound33467 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env33468 : List Nat := [2,4,8,1,32,1,8,37,1,37,1,1,41,0,1,34,1,0,37,0,0,32,1,2,41,1,1,0,0,0,4,32,37,32,1,0]

theorem envBound33468 : H12AffineFastState.Bounded env33468 := by
  intro p hp
  have h : env33468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33467_33468 : H12AffineEnvironment.transform 3 1 env33467 = env33468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env33467 == env33468) = true)

theorem identity33468 : scanCanonicalize (H12AffineFastState.compose env33468 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33468 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33469 : List Nat := [2,4,8,1,1,1,8,4,1,4,1,1,8,0,1,3,1,0,4,0,0,1,1,2,8,1,1,0,0,0,4,1,4,1,1,0]

theorem envBound33469 : H12AffineFastState.Bounded env33469 := by
  intro p hp
  have h : env33469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33468_33469 : H12AffineEnvironment.transform 4 1 env33468 = env33469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33468 == env33469) = true)

def env33470 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10400,1024,8540,2097152,33,73755,73857,8328,64,10589,2098512,2192715,2556,75223,2114912,256,2188650,2172307,513]

theorem envBound33470 : H12AffineFastState.Bounded env33470 := by
  intro p hp
  have h : env33470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33455_33470 : H12AffineEnvironment.transform 21 33 env33455 = env33470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env33455 == env33470) = true)

theorem identity33470 : scanCanonicalize (H12AffineFastState.compose env33470 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 17865) := by decide +kernel

theorem selectedBound33470 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env33471 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,90139,10400,1024,8540,17865,33,73755,73857,8328,64,10589,16537,77954,2556,75223,169,256,73891,90202,513]

theorem envBound33471 : H12AffineFastState.Bounded env33471 := by
  intro p hp
  have h : env33471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33470_33471 : H12AffineEnvironment.transform 20 17865 env33470 = env33471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17865 env33470 == env33471) = true)

theorem identity33471 : scanCanonicalize (H12AffineFastState.compose env33471 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33471 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env33472 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10400,1024,8540,17865,33,16,138,8328,64,10589,16537,4233,2556,1500,169,256,168,16465,513]

theorem envBound33472 : H12AffineFastState.Bounded env33472 := by
  intro p hp
  have h : env33472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33471_33472 : H12AffineEnvironment.transform 15 8203 env33471 = env33472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33471 == env33472) = true)

theorem identity33472 : scanCanonicalize (H12AffineFastState.compose env33472 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound33472 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1024,8540,17729,33,16,2,8192,64,10589,16401,4097,2420,1364,33,256,32,16465,513]

theorem envBound33473 : H12AffineFastState.Bounded env33473 := by
  intro p hp
  have h : env33473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33472_33473 : H12AffineEnvironment.transform 6 8 env33472 = env33473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33472 == env33473) = true)

theorem identity33473 : scanCanonicalize (H12AffineFastState.compose env33473 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 13576) := by decide +kernel

theorem selectedBound33473 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env33474 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13576,8541,8203,13592,10280,1024,8540,12361,33,16,2,8192,64,10589,13593,4097,2420,1364,33,256,32,13657,513]

theorem envBound33474 : H12AffineFastState.Bounded env33474 := by
  intro p hp
  have h : env33474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33473_33474 : H12AffineEnvironment.transform 13 13576 env33473 = env33474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13576 env33473 == env33474) = true)

theorem identity33474 : scanCanonicalize (H12AffineFastState.compose env33474 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1304) := by decide +kernel

theorem selectedBound33474 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env33475 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1304,4112,1093,1299,4096,3376,1024,1092,5457,33,16,2,1304,64,3141,4097,4097,2420,1364,33,256,32,4161,513]

theorem envBound33475 : H12AffineFastState.Bounded env33475 := by
  intro p hp
  have h : env33475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33474_33475 : H12AffineEnvironment.transform 12 1304 env33474 = env33475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1304 env33474 == env33475) = true)

theorem identity33475 : scanCanonicalize (H12AffineFastState.compose env33475 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(11+1) ^^^ 2113) := by decide +kernel

theorem selectedBound33475 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env33476 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2113,1304,2129,1093,1299,2113,3376,1024,1092,3344,33,16,2,1304,64,3141,2112,2112,2420,1364,33,256,32,2048,513]

theorem envBound33476 : H12AffineFastState.Bounded env33476 := by
  intro p hp
  have h : env33476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33475_33476 : H12AffineEnvironment.transform 11 2113 env33475 = env33476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2113 env33475 == env33476) = true)

theorem identity33476 : scanCanonicalize (H12AffineFastState.compose env33476 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound33476 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env33477 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,2096,1304,2080,1076,1299,2096,3376,1024,1077,3344,33,16,2,1304,49,3124,2097,2097,2309,1317,33,256,32,2048,513]

theorem envBound33477 : H12AffineFastState.Bounded env33477 := by
  intro p hp
  have h : env33477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33476_33477 : H12AffineEnvironment.transform 5 49 env33476 = env33477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env33476 == env33477) = true)

theorem identity33477 : scanCanonicalize (H12AffineFastState.compose env33477 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound33477 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env33478 : List Nat := [2,4,8,16,32,49,8,256,512,1024,1572,1556,1304,1540,1076,1299,1556,788,1024,1077,820,33,16,2,1304,49,528,1557,1557,1825,1317,33,256,32,1572,513]

theorem envBound33478 : H12AffineFastState.Bounded env33478 := by
  intro p hp
  have h : env33478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33477_33478 : H12AffineEnvironment.transform 10 1572 env33477 = env33478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env33477 == env33478) = true)

theorem identity33478 : scanCanonicalize (H12AffineFastState.compose env33478 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound33478 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env33479 : List Nat := [2,4,8,16,32,49,8,256,512,52,528,544,300,560,0,295,544,788,52,1,820,33,16,2,300,49,528,545,545,789,273,33,256,32,528,513]

theorem envBound33479 : H12AffineFastState.Bounded env33479 := by
  intro p hp
  have h : env33479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33478_33479 : H12AffineEnvironment.transform 9 52 env33478 = env33479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env33478 == env33479) = true)

theorem identity33479 : scanCanonicalize (H12AffineFastState.compose env33479 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound33479 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env33480 : List Nat := [2,4,8,16,32,49,8,256,32,52,48,0,300,16,0,295,0,308,52,1,276,33,16,2,300,49,48,1,1,309,273,33,256,32,48,33]

theorem envBound33480 : H12AffineFastState.Bounded env33480 := by
  intro p hp
  have h : env33480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33479_33480 : H12AffineEnvironment.transform 8 32 env33479 = env33480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env33479 == env33480) = true)

theorem identity33480 : scanCanonicalize (H12AffineFastState.compose env33480 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound33480 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env33481 : List Nat := [2,4,8,16,0,17,8,256,0,20,16,0,268,16,0,263,0,276,20,1,276,1,16,2,268,17,16,1,1,277,273,1,256,0,16,1]

theorem envBound33481 : H12AffineFastState.Bounded env33481 := by
  intro p hp
  have h : env33481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33480_33481 : H12AffineEnvironment.transform 4 0 env33480 = env33481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env33480 == env33481) = true)

theorem identity33481 : scanCanonicalize (H12AffineFastState.compose env33481 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound33481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env33482 : List Nat := [2,4,8,0,0,1,8,256,0,4,0,0,268,0,0,263,0,260,4,1,260,1,0,2,268,1,0,1,1,261,257,1,256,0,0,1]

theorem envBound33482 : H12AffineFastState.Bounded env33482 := by
  intro p hp
  have h : env33482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33481_33482 : H12AffineEnvironment.transform 3 0 env33481 = env33482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env33481 == env33482) = true)

def env33483 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,10401,1024,8540,2097152,4194304,147456,16777216,8328,64,21039612,18949585,2233680,2557,16999757,23160256,256,19080688,19096841,16925339]

theorem envBound33483 : H12AffineFastState.Bounded env33483 := by
  intro p hp
  have h : env33483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33427_33483 : H12AffineEnvironment.transform 17 10401 env33427 = env33483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env33427 == env33483) = true)

theorem identity33483 : scanCanonicalize (H12AffineFastState.compose env33483 (packedSelected [17,21] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound33483 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env33484 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10401,1024,8540,2097152,4194304,16,16777216,8328,64,21039612,18949585,2118976,2557,16852317,23160256,256,18965984,18949401,16777867]

theorem envBound33484 : H12AffineFastState.Bounded env33484 := by
  intro p hp
  have h : env33484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33483_33484 : H12AffineEnvironment.transform 16 16400 env33483 = env33484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env33483 == env33484) = true)

def env33485 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,2097152,4194304,16,16777216,8192,64,21039476,18949465,2118976,2421,16852317,23160136,256,18965864,18949401,16777731]

theorem envBound33485 : H12AffineFastState.Bounded env33485 := by
  intro p hp
  have h : env33485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33484_33485 : H12AffineEnvironment.transform 6 8 env33484 = env33485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env33484 == env33485) = true)

theorem identity33485 : scanCanonicalize (H12AffineFastState.compose env33485 (packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound33485 : packedSelected [1,4,5,9,10,11,12,14,15,16,18,23,24,28,32] rootPS < 2^1333 := by decide +kernel

def env33486 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,91198,4194304,16,16777216,8192,64,21039476,16793959,78206,2421,16852317,20971894,256,16777558,16793895,16777731]

theorem envBound33486 : H12AffineFastState.Bounded env33486 := by
  intro p hp
  have h : env33486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33485_33486 : H12AffineEnvironment.transform 20 91198 env33485 = env33486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env33485 == env33486) = true)

theorem identity33486 : scanCanonicalize (H12AffineFastState.compose env33486 (packedSelected [0,9,14,22,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound33486 : packedSelected [0,9,14,22,27,35] rootPS < 2^1333 := by decide +kernel

def env33487 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10281,1024,8540,17461,4194304,16,16777216,8192,64,20982143,16793959,4469,2421,16778582,20971894,256,16777558,16793895,16777731]

theorem envBound33487 : H12AffineFastState.Bounded env33487 := by
  intro p hp
  have h : env33487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33486_33487 : H12AffineEnvironment.transform 15 8203 env33486 = env33487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env33486 == env33487) = true)

theorem identity33487 : scanCanonicalize (H12AffineFastState.compose env33487 (packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound33487 : packedSelected [1,3,5,7,8,10,14,17,19,20,27] rootPS < 2^1333 := by decide +kernel

def env33488 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10281,1024,8540,17461,32,16,16777216,8192,64,16787807,16793959,4469,2421,16778582,16777558,256,16777558,16793895,16777731]

theorem envBound33488 : H12AffineFastState.Bounded env33488 := by
  intro p hp
  have h : env33488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33487_33488 : H12AffineEnvironment.transform 21 32 env33487 = env33488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env33487 == env33488) = true)

theorem identity33488 : scanCanonicalize (H12AffineFastState.compose env33488 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound33488 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env33489 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,8203,13624,10281,1024,8540,12573,32,16,16777216,8192,64,16787807,16790607,4469,2421,16778582,16777558,256,16777558,16790543,16777731]

theorem envBound33489 : H12AffineFastState.Bounded env33489 := by
  intro p hp
  have h : env33489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33488_33489 : H12AffineEnvironment.transform 13 13608 env33488 = env33489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env33488 == env33489) = true)

theorem identity33489 : scanCanonicalize (H12AffineFastState.compose env33489 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(23+1) ^^^ 34) := by decide +kernel

theorem selectedBound33489 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env33490 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,8541,8203,13624,10281,1024,8540,12573,32,16,34,8192,64,10621,13421,4469,2421,1396,372,256,372,13357,545]

theorem envBound33490 : H12AffineFastState.Bounded env33490 := by
  intro p hp
  have h : env33490.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33489_33490 : H12AffineEnvironment.transform 23 34 env33489 = env33490 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 34 env33489 == env33490) = true)

theorem identity33490 : scanCanonicalize (H12AffineFastState.compose env33490 (packedSelected [2,6,17] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound33490 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env33491 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,8192,13577,8541,8203,13593,10248,1024,8540,12573,1,16,3,8192,64,10588,13388,4436,2388,1365,341,256,341,13324,512]

theorem envBound33491 : H12AffineFastState.Bounded env33491 := by
  intro p hp
  have h : env33491.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33490_33491 : H12AffineEnvironment.transform 4 1 env33490 = env33491 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env33490 == env33491) = true)

theorem identity33491 : scanCanonicalize (H12AffineFastState.compose env33491 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound33491 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env33492 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,349,5204,0,342,5188,2389,1024,1,4160,1,16,3,349,64,2049,5393,4436,2388,1365,341,256,341,5457,512]

theorem envBound33492 : H12AffineFastState.Bounded env33492 := by
  intro p hp
  have h : env33492.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33491_33492 : H12AffineEnvironment.transform 12 349 env33491 = env33492 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env33491 == env33492) = true)

theorem identity33492 : scanCanonicalize (H12AffineFastState.compose env33492 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1819) := by decide +kernel

theorem selectedBound33492 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env33493 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1819,4096,349,5204,0,342,5188,1614,1024,1,4160,1,16,3,349,64,1818,5393,4436,1615,1365,341,256,341,5457,512]

theorem envBound33493 : H12AffineFastState.Bounded env33493 := by
  intro p hp
  have h : env33493.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33492_33493 : H12AffineEnvironment.transform 10 1819 env33492 = env33493 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1819 env33492 == env33493) = true)

theorem identity33493 : scanCanonicalize (H12AffineFastState.compose env33493 (packedSelected [1,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound33493 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env33494 : List Nat := [2,4,8,16,1,64,8,85,512,1024,1614,4096,8,5204,0,3,5188,1614,1024,1,4160,1,16,3,8,64,1615,5188,4097,1615,1024,0,85,0,5124,512]

theorem envBound33494 : H12AffineFastState.Bounded env33494 := by
  intro p hp
  have h : env33494.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans33493_33494 : H12AffineEnvironment.transform 7 85 env33493 = env33494 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env33493 == env33494) = true)

theorem identity33494 : scanCanonicalize (H12AffineFastState.compose env33494 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 90) := by decide +kernel

end H12CloudChart1