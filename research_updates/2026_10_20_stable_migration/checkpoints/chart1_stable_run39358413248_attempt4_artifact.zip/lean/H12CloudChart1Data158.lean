import H12CloudChart1Data157

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans40067_40068 : H12AffineEnvironment.transform 12 41 env40067 = env40068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40067 == env40068) = true)

theorem identity40068 : scanCanonicalize (H12AffineFastState.compose env40068 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40068 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40069 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,4096,9,5125,1,3,5140,2049,1025,0,4112,0,16,3,8,16,2048,5141,4097,2049,1025,0,4,1,5124,512]

theorem envBound40069 : H12AffineFastState.Bounded env40069 := by
  intro p hp
  have h : env40069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40068_40069 : H12AffineEnvironment.transform 4 0 env40068 = env40069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40068 == env40069) = true)

theorem identity40069 : scanCanonicalize (H12AffineFastState.compose env40069 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 3077) := by decide +kernel

theorem selectedBound40069 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40070 : List Nat := [2,4,8,16,0,16,9,5,512,1024,2048,3077,9,2048,1,3,2065,2049,1025,0,3093,0,16,3,8,16,2048,2064,3076,2049,1025,0,4,1,2049,512]

theorem envBound40070 : H12AffineFastState.Bounded env40070 := by
  intro p hp
  have h : env40070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40069_40070 : H12AffineEnvironment.transform 11 3077 env40069 = env40070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3077 env40069 == env40070) = true)

theorem identity40070 : scanCanonicalize (H12AffineFastState.compose env40070 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound40070 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40071 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2065,9,2048,1,3,2065,2049,21,0,2049,0,16,3,8,16,2048,2064,2064,2049,21,0,4,1,2049,512]

theorem envBound40071 : H12AffineFastState.Bounded env40071 := by
  intro p hp
  have h : env40071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40070_40071 : H12AffineEnvironment.transform 9 20 env40070 = env40071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env40070 == env40071) = true)

def env40072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169217,98780,8328,64,4510940,163841,17664,283905,168141,4350284,257,21793,46213,243482]

theorem envBound40072 : H12AffineFastState.Bounded env40072 := by
  intro p hp
  have h : env40072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40014_40072 : H12AffineEnvironment.transform 22 169217 env40014 = env40072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env40014 == env40072) = true)

def env40073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169217,98780,8328,64,64604,163841,17664,283905,168141,412108,257,21793,46213,243482]

theorem envBound40073 : H12AffineFastState.Bounded env40073 := by
  intro p hp
  have h : env40073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40072_40073 : H12AffineEnvironment.transform 21 272512 env40072 = env40073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env40072 == env40073) = true)

theorem identity40073 : scanCanonicalize (H12AffineFastState.compose env40073 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound40073 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272512,17,98780,8328,64,64604,5393,17664,283905,1501,318684,257,21793,46213,74250]

theorem envBound40074 : H12AffineFastState.Bounded env40074 := by
  intro p hp
  have h : env40074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40073_40074 : H12AffineEnvironment.transform 16 38160 env40073 = env40074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env40073 == env40074) = true)

theorem identity40074 : scanCanonicalize (H12AffineFastState.compose env40074 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound40074 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38160,262144,1025,32769,4160,272512,17,41431,8328,64,64604,5393,17664,283905,1501,318684,257,21793,46213,513]

theorem envBound40075 : H12AffineFastState.Bounded env40075 := by
  intro p hp
  have h : env40075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40074_40075 : H12AffineEnvironment.transform 15 8203 env40074 = env40075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env40074 == env40075) = true)

def env40076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169217,98780,8328,64,64605,163841,17664,283905,168141,412109,257,21793,46213,243482]

theorem envBound40076 : H12AffineFastState.Bounded env40076 := by
  intro p hp
  have h : env40076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40072_40076 : H12AffineEnvironment.transform 21 272513 env40072 = env40076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env40072 == env40076) = true)

def env40077 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272393,169217,98644,8192,64,64605,163841,17664,283905,168005,411973,257,21793,46093,243482]

theorem envBound40077 : H12AffineFastState.Bounded env40077 := by
  intro p hp
  have h : env40077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40076_40077 : H12AffineEnvironment.transform 6 8 env40076 = env40077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40076 == env40077) = true)

theorem identity40077 : scanCanonicalize (H12AffineFastState.compose env40077 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound40077 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env40078 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,131072,262144,1025,32769,165200,272393,169217,29791,8192,64,64605,163841,17664,283905,168005,411973,257,21793,46093,147985]

theorem envBound40078 : H12AffineFastState.Bounded env40078 := by
  intro p hp
  have h : env40078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40077_40078 : H12AffineEnvironment.transform 15 62731 env40077 = env40078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env40077 == env40078) = true)

theorem identity40078 : scanCanonicalize (H12AffineFastState.compose env40078 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound40078 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40079 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62731,57676,262144,1025,32769,25628,272393,29773,29791,8192,64,64605,24909,17664,283905,28937,305161,257,21793,46093,41821]

theorem envBound40079 : H12AffineFastState.Bounded env40079 := by
  intro p hp
  have h : env40079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40078_40079 : H12AffineEnvironment.transform 16 57676 env40078 = env40079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env40078 == env40079) = true)

theorem identity40079 : scanCanonicalize (H12AffineFastState.compose env40079 (packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound40079 : packedSelected [0,3,5,8,9,10,14,17,22,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env40080 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21591,16400,262144,1025,8541,25628,272393,29773,29791,8192,64,23809,24909,17664,283905,28937,264533,257,21793,5457,513]

theorem envBound40080 : H12AffineFastState.Bounded env40080 := by
  intro p hp
  have h : env40080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40079_40080 : H12AffineEnvironment.transform 14 8540 env40079 = env40080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env40079 == env40080) = true)

theorem identity40080 : scanCanonicalize (H12AffineFastState.compose env40080 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 11577) := by decide +kernel

theorem selectedBound40080 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40081 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,21591,16400,11577,1025,8541,25628,1328,29773,29791,8192,64,23809,24909,17664,30776,28937,9324,257,21793,5457,513]

theorem envBound40081 : H12AffineFastState.Bounded env40081 := by
  intro p hp
  have h : env40081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40080_40081 : H12AffineEnvironment.transform 17 11577 env40080 = env40081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 11577 env40080 == env40081) = true)

theorem identity40081 : scanCanonicalize (H12AffineFastState.compose env40081 (packedSelected [1,2,6,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40081 : packedSelected [1,2,6,8,19] rootPS < 2^1333 := by decide +kernel

def env40082 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8540,8202,13389,11577,1025,8541,4161,1328,16,2,8192,64,10588,5392,12637,3173,1364,9324,257,8572,5457,513]

theorem envBound40082 : H12AffineFastState.Bounded env40082 := by
  intro p hp
  have h : env40082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40081_40082 : H12AffineEnvironment.transform 13 13405 env40081 = env40082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40081 == env40082) = true)

theorem identity40082 : scanCanonicalize (H12AffineFastState.compose env40082 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound40082 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40083 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1384,4405,1076,1378,4389,2129,1025,1077,4161,1328,16,2,1384,64,3124,5392,5173,3173,1364,260,257,1044,5457,513]

theorem envBound40083 : H12AffineFastState.Bounded env40083 := by
  intro p hp
  have h : env40083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40082_40083 : H12AffineEnvironment.transform 12 1384 env40082 = env40083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env40082 == env40083) = true)

theorem identity40083 : scanCanonicalize (H12AffineFastState.compose env40083 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40083 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env40084 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1336,4405,1076,1330,4389,2049,1025,1077,4113,1328,16,2,1336,16,3124,5392,5173,3125,1284,260,257,1044,5377,513]

theorem envBound40084 : H12AffineFastState.Bounded env40084 := by
  intro p hp
  have h : env40084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40083_40084 : H12AffineEnvironment.transform 5 16 env40083 = env40084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40083 == env40084) = true)

theorem identity40084 : scanCanonicalize (H12AffineFastState.compose env40084 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40084 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env40085 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,1052,4113,1076,1046,4097,2049,1025,1077,4113,1044,16,2,1052,16,3124,5172,5173,3125,1056,32,37,1044,5157,513]

theorem envBound40085 : H12AffineFastState.Bounded env40085 := by
  intro p hp
  have h : env40085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40084_40085 : H12AffineEnvironment.transform 7 36 env40084 = env40085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40084 == env40085) = true)

theorem identity40085 : scanCanonicalize (H12AffineFastState.compose env40085 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40085 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40086 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,4096,41,4113,1,35,4097,2049,52,0,4113,33,16,2,41,16,2049,4097,4096,2048,21,32,37,33,4112,513]

theorem envBound40086 : H12AffineFastState.Bounded env40086 := by
  intro p hp
  have h : env40086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40085_40086 : H12AffineEnvironment.transform 9 53 env40085 = env40086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40085 == env40086) = true)

theorem identity40086 : scanCanonicalize (H12AffineFastState.compose env40086 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound40086 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40087 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,4096,41,4113,1,35,4097,49,52,0,4113,33,16,2,41,16,49,4097,4096,48,21,32,37,33,4112,513]

theorem envBound40087 : H12AffineFastState.Bounded env40087 := by
  intro p hp
  have h : env40087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40086_40087 : H12AffineEnvironment.transform 10 48 env40086 = env40087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env40086 == env40087) = true)

theorem identity40087 : scanCanonicalize (H12AffineFastState.compose env40087 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound40087 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40088 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,41,49,1,35,33,49,52,0,49,33,16,2,41,16,49,33,32,48,21,32,37,33,48,513]

theorem envBound40088 : H12AffineFastState.Bounded env40088 := by
  intro p hp
  have h : env40088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40087_40088 : H12AffineEnvironment.transform 11 32 env40087 = env40088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env40087 == env40088) = true)

def leafEnv40088 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,32,41,49,1,35,33,49,52,0,49,33,16,2,20,41,1,16,49,33,32,48,21,32,37,33,5,35,48,513,1,48,0]

def active40088 : List Nat := [0,1,2,3,4,8]

def tree40088 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40088 : H12WitnessSearch.Good tree40088 := H12GlobalWitnessIndex.good

theorem leafIdentity40088 : H12AffineFastState.composeSystem env40088 rootObs = leafEnv40088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40088 rootObs == leafEnv40088) = true)

theorem terminalChecked40088 : H12PackedTerminal.terminalCheckFast leafEnv40088 active40088 tree40088 = true := by decide +kernel

def env40089 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272392,169217,98645,8193,64,64605,163841,17664,283905,168004,411972,257,21793,46092,243482]

theorem envBound40089 : H12AffineFastState.Bounded env40089 := by
  intro p hp
  have h : env40089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40076_40089 : H12AffineEnvironment.transform 6 9 env40076 = env40089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40076 == env40089) = true)

def env40090 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,262144,1025,32769,4160,272392,17,98645,8193,64,64605,5393,17664,283905,1364,318548,257,21793,46092,74250]

theorem envBound40090 : H12AffineFastState.Bounded env40090 := by
  intro p hp
  have h : env40090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40089_40090 : H12AffineEnvironment.transform 16 38160 env40089 = env40090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env40089 == env40090) = true)

theorem identity40090 : scanCanonicalize (H12AffineFastState.compose env40090 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40090 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40091 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,4160,33,17,98645,8193,64,64605,5393,17664,32040,1364,62589,257,21793,46092,74250]

theorem envBound40091 : H12AffineFastState.Bounded env40091 := by
  intro p hp
  have h : env40091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40090_40091 : H12AffineEnvironment.transform 17 10281 env40090 = env40091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40090 == env40091) = true)

theorem identity40091 : scanCanonicalize (H12AffineFastState.compose env40091 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound40091 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env40092 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,24908,10281,1025,29789,4160,33,17,95497,8193,64,2049,5393,17664,32040,1364,33,257,21793,16464,74250]

theorem envBound40092 : H12AffineFastState.Bounded env40092 := by
  intro p hp
  have h : env40092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40091_40092 : H12AffineEnvironment.transform 14 29788 env40091 = env40092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env40091 == env40092) = true)

theorem identity40092 : scanCanonicalize (H12AffineFastState.compose env40092 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound40092 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40093 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,342,24908,10281,1025,29789,4160,33,17,29791,8193,64,2049,5393,17664,32040,1364,33,257,21793,16464,9052]

theorem envBound40093 : H12AffineFastState.Bounded env40093 := by
  intro p hp
  have h : env40093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40092_40093 : H12AffineEnvironment.transform 15 342 env40092 = env40093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env40092 == env40093) = true)

theorem identity40093 : scanCanonicalize (H12AffineFastState.compose env40093 (packedSelected [1,8,19] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound40093 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env40094 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,342,13389,10281,1025,8540,4160,33,17,8542,8193,64,2049,5393,4097,10281,1364,33,257,32,5457,9052]

theorem envBound40094 : H12AffineFastState.Bounded env40094 := by
  intro p hp
  have h : env40094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40093_40094 : H12AffineEnvironment.transform 13 5377 env40093 = env40094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env40093 == env40094) = true)

theorem identity40094 : scanCanonicalize (H12AffineFastState.compose env40094 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound40094 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40095 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,2396,5377,2049,342,7441,373,1025,2048,4160,33,17,2050,2397,64,2049,5393,4097,373,1364,33,257,32,5457,2560]

theorem envBound40095 : H12AffineFastState.Bounded env40095 := by
  intro p hp
  have h : env40095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40094_40095 : H12AffineEnvironment.transform 12 2396 env40094 = env40095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env40094 == env40095) = true)

theorem identity40095 : scanCanonicalize (H12AffineFastState.compose env40095 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40095 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40096 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,2396,5377,2049,342,7441,340,1025,2048,4160,0,17,2050,2397,64,2049,5393,4097,340,1364,0,257,1,5457,2560]

theorem envBound40096 : H12AffineFastState.Bounded env40096 := by
  intro p hp
  have h : env40096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40095_40096 : H12AffineEnvironment.transform 4 1 env40095 = env40096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40095 == env40096) = true)

theorem identity40096 : scanCanonicalize (H12AffineFastState.compose env40096 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40096 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40097 : List Nat := [2,4,8,16,1,64,9,256,512,1024,1,4096,349,5377,0,342,5392,340,1025,1,4160,0,17,3,348,64,0,5393,4097,340,1364,0,257,1,5457,513]

theorem envBound40097 : H12AffineFastState.Bounded env40097 := by
  intro p hp
  have h : env40097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40096_40097 : H12AffineEnvironment.transform 10 1 env40096 = env40097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40096 == env40097) = true)

theorem identity40097 : scanCanonicalize (H12AffineFastState.compose env40097 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1360) := by decide +kernel

theorem selectedBound40097 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40098 : List Nat := [2,4,8,16,1,64,9,256,512,1024,1,1360,349,81,0,342,64,340,1025,1,1296,0,17,3,348,64,0,65,1361,340,1364,0,257,1,1,513]

theorem envBound40098 : H12AffineFastState.Bounded env40098 := by
  intro p hp
  have h : env40098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40097_40098 : H12AffineEnvironment.transform 11 1360 env40097 = env40098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1360 env40097 == env40098) = true)

theorem identity40098 : scanCanonicalize (H12AffineFastState.compose env40098 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 785) := by decide +kernel

theorem selectedBound40098 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40099 : List Nat := [2,4,8,16,1,64,9,256,512,785,1,577,349,81,0,342,64,340,784,1,513,0,17,3,348,64,0,65,576,340,581,0,257,1,1,513]

theorem envBound40099 : H12AffineFastState.Bounded env40099 := by
  intro p hp
  have h : env40099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40098_40099 : H12AffineEnvironment.transform 9 785 env40098 = env40099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 785 env40098 == env40099) = true)

theorem identity40099 : scanCanonicalize (H12AffineFastState.compose env40099 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound40099 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env40100 : List Nat := [2,4,8,16,1,64,9,256,17,256,1,80,349,81,0,342,64,340,257,1,16,0,17,3,348,64,0,65,81,340,84,0,257,1,1,16]

theorem envBound40100 : H12AffineFastState.Bounded env40100 := by
  intro p hp
  have h : env40100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40099_40100 : H12AffineEnvironment.transform 8 17 env40099 = env40100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env40099 == env40100) = true)

theorem identity40100 : scanCanonicalize (H12AffineFastState.compose env40100 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound40100 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40101 : List Nat := [2,4,8,16,1,64,9,85,17,85,1,80,8,81,0,3,64,1,84,1,16,0,17,3,9,64,0,65,81,1,84,0,84,1,1,16]

theorem envBound40101 : H12AffineFastState.Bounded env40101 := by
  intro p hp
  have h : env40101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40100_40101 : H12AffineEnvironment.transform 7 85 env40100 = env40101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env40100 == env40101) = true)

def env40102 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4161,272392,16,98645,8193,64,64605,5392,17664,283905,1365,318549,257,21793,46092,74251]

theorem envBound40102 : H12AffineFastState.Bounded env40102 := by
  intro p hp
  have h : env40102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40089_40102 : H12AffineEnvironment.transform 16 38161 env40089 = env40102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env40089 == env40102) = true)

theorem identity40102 : scanCanonicalize (H12AffineFastState.compose env40102 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40102 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env40103 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,4161,272392,16,41311,8193,64,64605,5392,17664,283905,1365,318549,257,21793,46092,513]

theorem envBound40103 : H12AffineFastState.Bounded env40103 := by
  intro p hp
  have h : env40103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40102_40103 : H12AffineEnvironment.transform 15 8202 env40102 = env40103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40102 == env40103) = true)

theorem identity40103 : scanCanonicalize (H12AffineFastState.compose env40103 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound40103 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env40104 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8202,16400,262144,1025,21760,4161,272392,16,29790,8193,64,10588,5392,17664,283905,1365,264532,257,21793,24845,513]

theorem envBound40104 : H12AffineFastState.Bounded env40104 := by
  intro p hp
  have h : env40104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40103_40104 : H12AffineEnvironment.transform 14 21761 env40103 = env40104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env40103 == env40104) = true)

theorem identity40104 : scanCanonicalize (H12AffineFastState.compose env40104 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40104 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40105 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,8540,8202,13389,262144,1025,8541,4161,272392,16,3,8193,64,10588,5392,12637,270684,1365,264532,257,8572,5456,513]

theorem envBound40105 : H12AffineFastState.Bounded env40105 := by
  intro p hp
  have h : env40105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40104_40105 : H12AffineEnvironment.transform 13 13405 env40104 = env40105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40104 == env40105) = true)

theorem identity40105 : scanCanonicalize (H12AffineFastState.compose env40105 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound40105 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env40106 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,81,263,5440,262144,1025,80,4161,264453,16,3,268,64,2129,5392,4176,262225,1365,264532,257,113,5456,513]

theorem envBound40106 : H12AffineFastState.Bounded env40106 := by
  intro p hp
  have h : env40106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40105_40106 : H12AffineEnvironment.transform 12 269 env40105 = env40106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env40105 == env40106) = true)

theorem identity40106 : scanCanonicalize (H12AffineFastState.compose env40106 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40106 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40107 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5237,81,34,5221,262144,1025,80,4161,264224,16,3,41,64,2129,5173,4176,262225,1136,264305,36,113,5237,513]

theorem envBound40107 : H12AffineFastState.Bounded env40107 := by
  intro p hp
  have h : env40107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40106_40107 : H12AffineEnvironment.transform 7 37 env40106 = env40107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40106 == env40107) = true)

theorem identity40107 : scanCanonicalize (H12AffineFastState.compose env40107 (packedSelected [0,2,7] rootPS)) = affineNative (2^(17+1) ^^^ 2049) := by decide +kernel

theorem selectedBound40107 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env40108 : List Nat := [2,4,8,16,32,64,9,37,512,1024,2048,4096,40,5237,81,34,5221,2049,1025,80,4161,33,16,3,41,64,2129,5173,4176,2128,1136,112,36,113,5237,513]

theorem envBound40108 : H12AffineFastState.Bounded env40108 := by
  intro p hp
  have h : env40108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40107_40108 : H12AffineEnvironment.transform 17 2049 env40107 = env40108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2049 env40107 == env40108) = true)

theorem identity40108 : scanCanonicalize (H12AffineFastState.compose env40108 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40108 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40109 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5156,0,34,5172,2049,1025,1,4112,33,16,3,41,17,2048,5173,4097,2049,1057,33,36,32,5156,513]

theorem envBound40109 : H12AffineFastState.Bounded env40109 := by
  intro p hp
  have h : env40109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40108_40109 : H12AffineEnvironment.transform 5 17 env40108 = env40109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40108 == env40109) = true)

def env40110 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1044,0,34,1028,2049,1025,1,32,33,16,3,41,17,2048,1029,49,2049,1057,33,36,32,1044,513]

theorem envBound40110 : H12AffineFastState.Bounded env40110 := by
  intro p hp
  have h : env40110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40109_40110 : H12AffineEnvironment.transform 11 48 env40109 = env40110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env40109 == env40110) = true)

def env40111 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,40,32,0,34,48,2049,53,1,32,33,16,3,41,17,2048,49,49,2049,21,33,36,32,32,513]

theorem envBound40111 : H12AffineFastState.Bounded env40111 := by
  intro p hp
  have h : env40111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40110_40111 : H12AffineEnvironment.transform 9 52 env40110 = env40111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40110 == env40111) = true)

theorem identity40111 : scanCanonicalize (H12AffineFastState.compose env40111 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound40111 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40112 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,48,40,32,0,34,48,2049,53,1,32,33,16,3,41,17,2048,49,49,2049,21,33,36,32,32,43]

theorem envBound40112 : H12AffineFastState.Bounded env40112 := by
  intro p hp
  have h : env40112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40111_40112 : H12AffineEnvironment.transform 8 42 env40111 = env40112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env40111 == env40112) = true)

def leafEnv40112 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,48,40,32,0,34,48,2049,53,1,32,33,16,3,20,41,1,17,2048,49,49,2049,21,33,36,32,5,35,32,43,1,32,0]

def active40112 : List Nat := [0,1,2,3,4,10]

def tree40112 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40112 : H12WitnessSearch.Good tree40112 := H12GlobalWitnessIndex.good

theorem leafIdentity40112 : H12AffineFastState.composeSystem env40112 rootObs = leafEnv40112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40112 rootObs == leafEnv40112) = true)

theorem terminalChecked40112 : H12PackedTerminal.terminalCheckFast leafEnv40112 active40112 tree40112 = true := by decide +kernel

def env40113 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,33,0,34,49,2049,52,1,32,33,16,3,41,17,2048,48,49,2049,20,33,36,32,33,513]

theorem envBound40113 : H12AffineFastState.Bounded env40113 := by
  intro p hp
  have h : env40113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40110_40113 : H12AffineEnvironment.transform 9 53 env40110 = env40113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40110 == env40113) = true)

def env40114 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1045,0,34,1029,2049,1025,1,33,33,16,3,41,17,2048,1028,48,2049,1057,33,36,32,1045,513]

theorem envBound40114 : H12AffineFastState.Bounded env40114 := by
  intro p hp
  have h : env40114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40109_40114 : H12AffineEnvironment.transform 11 49 env40109 = env40114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env40109 == env40114) = true)

theorem identity40114 : scanCanonicalize (H12AffineFastState.compose env40114 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40114 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40115 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,33,0,34,49,2049,53,1,33,33,16,3,41,17,2048,48,48,2049,21,33,36,32,33,513]

theorem envBound40115 : H12AffineFastState.Bounded env40115 := by
  intro p hp
  have h : env40115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40114_40115 : H12AffineEnvironment.transform 9 52 env40114 = env40115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40114 == env40115) = true)

theorem identity40115 : scanCanonicalize (H12AffineFastState.compose env40115 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound40115 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40116 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,49,40,33,0,34,49,2049,53,1,33,33,16,3,41,17,2048,48,48,2049,21,33,36,32,33,42]

theorem envBound40116 : H12AffineFastState.Bounded env40116 := by
  intro p hp
  have h : env40116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40115_40116 : H12AffineEnvironment.transform 8 43 env40115 = env40116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env40115 == env40116) = true)

def leafEnv40116 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,49,40,33,0,34,49,2049,53,1,33,33,16,3,20,41,1,17,2048,48,48,2049,21,33,36,32,5,35,33,42,1,33,0]

def active40116 : List Nat := [0,1,2,3,4,10]

def tree40116 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40116 : H12WitnessSearch.Good tree40116 := H12GlobalWitnessIndex.good

theorem leafIdentity40116 : H12AffineFastState.composeSystem env40116 rootObs = leafEnv40116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40116 rootObs == leafEnv40116) = true)

theorem terminalChecked40116 : H12PackedTerminal.terminalCheckFast leafEnv40116 active40116 tree40116 = true := by decide +kernel

def env40117 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507601,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound40117 : H12AffineFastState.Bounded env40117 := by
  intro p hp
  have h : env40117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39728_40117 : H12AffineEnvironment.transform 26 30393345 env39728 = env40117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env39728 == env40117) = true)

def env40118 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507601,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound40118 : H12AffineFastState.Bounded env40118 := by
  intro p hp
  have h : env40118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40117_40118 : H12AffineEnvironment.transform 18 1024 env40117 = env40118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env40117 == env40118) = true)

theorem identity40118 : scanCanonicalize (H12AffineFastState.compose env40118 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound40118 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40119 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8328,64,21479441,18973836,2118977,442384,16876544,23160257,256,18990268,18949400,16819158]

theorem envBound40119 : H12AffineFastState.Bounded env40119 := by
  intro p hp
  have h : env40119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40118_40119 : H12AffineEnvironment.transform 22 16 env40118 = env40119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env40118 == env40119) = true)

def env40120 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21479441,18973700,2118977,442384,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound40120 : H12AffineFastState.Bounded env40120 := by
  intro p hp
  have h : env40120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40119_40120 : H12AffineEnvironment.transform 6 8 env40119 = env40120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40119 == env40120) = true)

theorem identity40120 : scanCanonicalize (H12AffineFastState.compose env40120 (packedSelected [17,21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40120 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env40121 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,262144,1024,8540,2097152,4194304,16,16777216,8192,64,21455180,18949465,2118977,418125,16852317,23160137,256,18965865,18949400,16777731]

theorem envBound40121 : H12AffineFastState.Bounded env40121 := by
  intro p hp
  have h : env40121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40120_40121 : H12AffineEnvironment.transform 14 8541 env40120 = env40121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40120 == env40121) = true)

def env40122 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1024,8540,2097152,4194304,16,16777216,8192,64,21307740,18949465,2118977,270685,16852317,23160137,256,18965865,18949400,16777731]

theorem envBound40122 : H12AffineFastState.Bounded env40122 := by
  intro p hp
  have h : env40122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40121_40122 : H12AffineEnvironment.transform 16 16400 env40121 = env40122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40121 == env40122) = true)

theorem identity40122 : scanCanonicalize (H12AffineFastState.compose env40122 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound40122 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40123 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1024,8540,2097152,4194304,16,2,8192,64,4530526,2172251,2118977,270685,75103,6382923,256,2188651,2172186,513]

theorem envBound40123 : H12AffineFastState.Bounded env40123 := by
  intro p hp
  have h : env40123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40122_40123 : H12AffineEnvironment.transform 23 2 env40122 = env40123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env40122 == env40123) = true)

theorem identity40123 : scanCanonicalize (H12AffineFastState.compose env40123 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 5457) := by decide +kernel

theorem selectedBound40123 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40124 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,262144,1024,8540,5457,4194304,16,2,8192,64,4530526,77834,16400,270685,75103,4288538,256,94266,77899,513]

theorem envBound40124 : H12AffineFastState.Bounded env40124 := by
  intro p hp
  have h : env40124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40123_40124 : H12AffineEnvironment.transform 20 5457 env40123 = env40124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5457 env40123 == env40124) = true)

theorem identity40124 : scanCanonicalize (H12AffineFastState.compose env40124 (packedSelected [9,14,22] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40124 : packedSelected [9,14,22] rootPS < 2^1333 := by decide +kernel

def env40125 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,262144,1024,8540,5457,4194304,16,2,8192,64,4456788,4096,16400,270685,1365,4214800,256,20528,4161,513]

theorem envBound40125 : H12AffineFastState.Bounded env40125 := by
  intro p hp
  have h : env40125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40124_40125 : H12AffineEnvironment.transform 15 8202 env40124 = env40125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40124 == env40125) = true)

theorem identity40125 : scanCanonicalize (H12AffineFastState.compose env40125 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 292937) := by decide +kernel

theorem selectedBound40125 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env40126 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,262144,1024,8540,5457,292937,16,2,8192,64,31005,4096,16400,270685,1365,272473,256,20528,4161,513]

theorem envBound40126 : H12AffineFastState.Bounded env40126 := by
  intro p hp
  have h : env40126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40125_40126 : H12AffineEnvironment.transform 21 292937 env40125 = env40126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 292937 env40125 == env40126) = true)

theorem identity40126 : scanCanonicalize (H12AffineFastState.compose env40126 (packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS)) = affineNative (2^(17+1) ^^^ 30824) := by decide +kernel

theorem selectedBound40126 : packedSelected [0,1,2,3,4,6,7,8,9,10,14,24] rootPS < 2^1333 := by decide +kernel

def env40127 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16400,30824,1024,8540,5457,33,16,2,8192,64,31005,4096,16400,22837,1365,20529,256,20528,4161,513]

theorem envBound40127 : H12AffineFastState.Bounded env40127 := by
  intro p hp
  have h : env40127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40126_40127 : H12AffineEnvironment.transform 17 30824 env40126 = env40127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 30824 env40126 == env40127) = true)

theorem identity40127 : scanCanonicalize (H12AffineFastState.compose env40127 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40127 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40128 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,8202,16400,30776,1024,8460,5377,33,16,2,8192,16,31005,4096,16400,22837,1285,20529,256,20528,4113,513]

theorem envBound40128 : H12AffineFastState.Bounded env40128 := by
  intro p hp
  have h : env40128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40127_40128 : H12AffineEnvironment.transform 5 16 env40127 = env40128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40127 == env40128) = true)

theorem identity40128 : scanCanonicalize (H12AffineFastState.compose env40128 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound40128 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40129 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,5157,8461,8202,5173,11293,1024,8460,5377,33,16,2,8192,16,11576,4096,5173,3344,1285,1044,256,1045,4113,513]

theorem envBound40129 : H12AffineFastState.Bounded env40129 := by
  intro p hp
  have h : env40129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40128_40129 : H12AffineEnvironment.transform 13 5157 env40128 = env40129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env40128 == env40129) = true)

theorem identity40129 : scanCanonicalize (H12AffineFastState.compose env40129 (packedSelected [0,4,7,9,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40129 : packedSelected [0,4,7,9,11,15] rootPS < 2^1333 := by decide +kernel

def env40130 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,4096,8192,4112,8461,8202,4096,10280,53,8460,4404,33,16,2,8192,16,10509,4096,4096,2341,304,33,256,32,4113,513]

theorem envBound40130 : H12AffineFastState.Bounded env40130 := by
  intro p hp
  have h : env40130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40129_40130 : H12AffineEnvironment.transform 9 53 env40129 = env40130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40129 == env40130) = true)

theorem identity40130 : scanCanonicalize (H12AffineFastState.compose env40130 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40130 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40131 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,8192,4112,8232,8202,4096,10280,53,8233,4113,33,16,2,8192,16,10280,4096,4096,2048,21,33,37,32,4113,513]

theorem envBound40131 : H12AffineFastState.Bounded env40131 := by
  intro p hp
  have h : env40131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40130_40131 : H12AffineEnvironment.transform 7 37 env40130 = env40131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40130 == env40131) = true)

theorem identity40131 : scanCanonicalize (H12AffineFastState.compose env40131 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound40131 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40132 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,4096,8192,4112,8232,8202,4096,8217,53,8233,4113,33,16,2,8192,16,8217,4096,4096,49,21,33,37,32,4113,513]

theorem envBound40132 : H12AffineFastState.Bounded env40132 := by
  intro p hp
  have h : env40132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40131_40132 : H12AffineEnvironment.transform 10 49 env40131 = env40132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env40131 == env40132) = true)

theorem identity40132 : scanCanonicalize (H12AffineFastState.compose env40132 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40132 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40133 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,4096,41,4112,1,35,4096,48,53,0,4113,33,16,2,41,16,48,4096,4096,49,21,33,37,32,4113,513]

theorem envBound40133 : H12AffineFastState.Bounded env40133 := by
  intro p hp
  have h : env40133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40132_40133 : H12AffineEnvironment.transform 12 41 env40132 = env40133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40132 == env40133) = true)

theorem identity40133 : scanCanonicalize (H12AffineFastState.compose env40133 (packedSelected [4] rootPS)) = affineNative (2^(11+1) ^^^ 33) := by decide +kernel

theorem selectedBound40133 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env40134 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,41,49,1,35,33,48,53,0,48,33,16,2,41,16,48,33,33,49,21,33,37,32,48,513]

theorem envBound40134 : H12AffineFastState.Bounded env40134 := by
  intro p hp
  have h : env40134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40133_40134 : H12AffineEnvironment.transform 11 33 env40133 = env40134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 33 env40133 == env40134) = true)

def leafEnv40134 : List Nat := [2,4,8,16,32,16,8,37,512,53,49,33,41,49,1,35,33,48,53,0,48,33,16,2,21,41,1,16,48,33,33,49,21,33,37,32,4,35,48,513,1,49,0]

def active40134 : List Nat := [0,1,2,3,4,8]

def tree40134 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40134 : H12WitnessSearch.Good tree40134 := H12GlobalWitnessIndex.good

theorem leafIdentity40134 : H12AffineFastState.composeSystem env40134 rootObs = leafEnv40134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40134 rootObs == leafEnv40134) = true)

theorem terminalChecked40134 : H12PackedTerminal.terminalCheckFast leafEnv40134 active40134 tree40134 = true := by decide +kernel

def env40135 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,2097152,4194304,16,16777216,8192,64,21307741,18949465,2118977,270684,16852317,23160137,256,18965865,18949400,16777731]

theorem envBound40135 : H12AffineFastState.Bounded env40135 := by
  intro p hp
  have h : env40135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40121_40135 : H12AffineEnvironment.transform 16 16401 env40121 = env40135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40121 == env40135) = true)

theorem identity40135 : scanCanonicalize (H12AffineFastState.compose env40135 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound40135 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env40136 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,2097152,33,16,16777216,8192,64,17113468,18949465,2118977,270684,16852317,18965864,256,18965865,18949400,16777731]

theorem envBound40136 : H12AffineFastState.Bounded env40136 := by
  intro p hp
  have h : env40136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40135_40136 : H12AffineEnvironment.transform 21 33 env40135 = env40136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env40135 == env40136) = true)

theorem identity40136 : scanCanonicalize (H12AffineFastState.compose env40136 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(23+1) ^^^ 272426) := by decide +kernel

theorem selectedBound40136 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env40137 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,2097152,33,16,272426,8192,64,67926,2428275,2118977,270684,331127,2444610,256,2444611,2428210,272937]

theorem envBound40137 : H12AffineFastState.Bounded env40137 := by
  intro p hp
  have h : env40137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40136_40137 : H12AffineEnvironment.transform 23 272426 env40136 = env40137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272426 env40136 == env40137) = true)

theorem identity40137 : scanCanonicalize (H12AffineFastState.compose env40137 (packedSelected [0,2,3,4,5,6,9,10,11,12,15,20,23,27] rootPS)) = affineNative (2^(20+1) ^^^ 355438) := by decide +kernel

theorem selectedBound40137 : packedSelected [0,2,3,4,5,6,9,10,11,12,15,20,23,27] rootPS < 2^1333 := by decide +kernel

def env40138 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,262144,1024,8540,355438,33,16,272426,8192,64,67926,24861,342319,270684,331127,8492,256,8493,24924,272937]

theorem envBound40138 : H12AffineFastState.Bounded env40138 := by
  intro p hp
  have h : env40138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40137_40138 : H12AffineEnvironment.transform 20 355438 env40137 = env40138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 355438 env40137 == env40138) = true)

theorem identity40138 : scanCanonicalize (H12AffineFastState.compose env40138 (packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound40138 : packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env40139 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,83015,33,16,3,8192,64,67926,24861,69894,2421,75102,8492,256,8493,24924,512]

theorem envBound40139 : H12AffineFastState.Bounded env40139 := by
  intro p hp
  have h : env40139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40138_40139 : H12AffineEnvironment.transform 17 10281 env40138 = env40139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40138 == env40139) = true)

theorem identity40139 : scanCanonicalize (H12AffineFastState.compose env40139 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 21543) := by decide +kernel

theorem selectedBound40139 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env40140 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,21543,16401,10281,1024,8540,4192,33,16,3,8192,64,23921,24861,17697,2421,29049,8492,256,8493,24924,512]

theorem envBound40140 : H12AffineFastState.Bounded env40140 := by
  intro p hp
  have h : env40140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40139_40140 : H12AffineEnvironment.transform 15 21543 env40139 = env40140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21543 env40139 == env40140) = true)

theorem identity40140 : scanCanonicalize (H12AffineFastState.compose env40140 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40140 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env40141 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8541,8314,13388,10281,1024,8540,4192,33,16,3,8192,64,10540,5440,12668,2421,1316,8492,256,8493,5377,512]

theorem envBound40141 : H12AffineFastState.Bounded env40141 := by
  intro p hp
  have h : env40141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40140_40141 : H12AffineEnvironment.transform 13 13405 env40140 = env40141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40140 == env40141) = true)

theorem identity40141 : scanCanonicalize (H12AffineFastState.compose env40141 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40141 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40142 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,8192,13405,8313,8314,13388,10281,1024,8312,4192,33,16,3,8192,64,10248,5220,12376,2129,1024,8200,36,8201,5157,512]

theorem envBound40142 : H12AffineFastState.Bounded env40142 := by
  intro p hp
  have h : env40142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40141_40142 : H12AffineEnvironment.transform 7 36 env40141 = env40142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40141 == env40142) = true)

def env40143 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21479441,18973701,2118977,442384,16876544,23160136,256,18990133,18949400,16819039]

theorem envBound40143 : H12AffineFastState.Bounded env40143 := by
  intro p hp
  have h : env40143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40119_40143 : H12AffineEnvironment.transform 6 9 env40119 = env40143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40119 == env40143) = true)

def env40144 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331969,18973701,2118977,294912,16876544,23160136,256,18990133,18949400,16819039]

theorem envBound40144 : H12AffineFastState.Bounded env40144 := by
  intro p hp
  have h : env40144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40143_40144 : H12AffineEnvironment.transform 16 16400 env40143 = env40144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40143 == env40144) = true)

theorem identity40144 : scanCanonicalize (H12AffineFastState.compose env40144 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound40144 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env40145 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,41310,8193,64,4530527,2172251,2118977,294912,75102,6407190,256,2188651,2196550,513]

theorem envBound40145 : H12AffineFastState.Bounded env40145 := by
  intro p hp
  have h : env40145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40144_40145 : H12AffineEnvironment.transform 23 41310 env40144 = env40145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env40144 == env40145) = true)

def env40146 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41310,8193,64,4530527,115015,45405,294912,75102,4268042,256,98679,90202,513]

theorem envBound40146 : H12AffineFastState.Bounded env40146 := by
  intro p hp
  have h : env40146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40145_40146 : H12AffineEnvironment.transform 20 58396 env40145 = env40146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env40145 == env40146) = true)

def env40147 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41230,8193,16,4530447,114967,45325,294912,75022,4268042,256,98599,90122,513]

theorem envBound40147 : H12AffineFastState.Bounded env40147 := by
  intro p hp
  have h : env40147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40146_40147 : H12AffineEnvironment.transform 5 16 env40146 = env40147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40146 == env40147) = true)

theorem identity40147 : scanCanonicalize (H12AffineFastState.compose env40147 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound40147 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env40148 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,272393,16,41230,8193,16,67846,114967,45325,294912,75022,329731,256,98599,90122,513]

theorem envBound40148 : H12AffineFastState.Bounded env40148 := by
  intro p hp
  have h : env40148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40147_40148 : H12AffineEnvironment.transform 21 272393 env40147 = env40148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env40147 == env40148) = true)

theorem identity40148 : scanCanonicalize (H12AffineFastState.compose env40148 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 33030) := by decide +kernel

theorem selectedBound40148 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env40149 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33030,16400,262144,1024,32769,58396,272393,16,41230,8193,16,34816,16401,45325,294912,41992,297221,256,33,57612,513]

theorem envBound40149 : H12AffineFastState.Bounded env40149 := by
  intro p hp
  have h : env40149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40148_40149 : H12AffineEnvironment.transform 15 33030 env40148 = env40149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33030 env40148 == env40149) = true)

theorem identity40149 : scanCanonicalize (H12AffineFastState.compose env40149 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound40149 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40150 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,32768,33030,16400,2341,1024,32769,58396,8492,16,41230,8193,16,34816,16401,45325,35109,41992,32800,256,33,57612,513]

theorem envBound40150 : H12AffineFastState.Bounded env40150 := by
  intro p hp
  have h : env40150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40149_40150 : H12AffineEnvironment.transform 17 2341 env40149 = env40150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env40149 == env40150) = true)

theorem identity40150 : scanCanonicalize (H12AffineFastState.compose env40150 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound40150 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40151 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,8203,16400,2341,1024,8460,17681,8492,16,3,8193,16,10509,16401,4096,10280,1285,8493,256,33,16385,513]

theorem envBound40151 : H12AffineFastState.Bounded env40151 := by
  intro p hp
  have h : env40151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40150_40151 : H12AffineEnvironment.transform 14 8461 env40150 = env40151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env40150 == env40151) = true)

theorem identity40151 : scanCanonicalize (H12AffineFastState.compose env40151 (packedSelected [2] rootPS)) = affineNative (2^(12+1) ^^^ 4380) := by decide +kernel

theorem selectedBound40151 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40152 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,4380,16384,4113,4375,16400,2341,1024,4112,17681,4144,16,3,4381,16,6161,16401,4096,6452,1285,4145,256,33,16385,513]

theorem envBound40152 : H12AffineFastState.Bounded env40152 := by
  intro p hp
  have h : env40152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40151_40152 : H12AffineEnvironment.transform 12 4380 env40151 = env40152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4380 env40151 == env40152) = true)

theorem identity40152 : scanCanonicalize (H12AffineFastState.compose env40152 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound40152 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40153 : List Nat := [2,4,8,16,32,16,9,256,512,1024,32,4096,4380,16384,4113,4375,16400,261,1024,4112,17681,4144,16,3,4381,16,4145,16401,4096,4372,1285,4145,256,33,16385,513]

theorem envBound40153 : H12AffineFastState.Bounded env40153 := by
  intro p hp
  have h : env40153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40152_40153 : H12AffineEnvironment.transform 10 32 env40152 = env40153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env40152 == env40153) = true)

theorem identity40153 : scanCanonicalize (H12AffineFastState.compose env40153 (packedSelected [3,8] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound40153 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env40154 : List Nat := [2,4,8,16,32,16,9,256,512,1024,32,1583,1843,16384,1598,1848,16400,261,1024,1599,17681,1567,16,3,1842,16,1566,16401,1583,1851,1285,1566,256,33,16385,513]

theorem envBound40154 : H12AffineFastState.Bounded env40154 := by
  intro p hp
  have h : env40154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40153_40154 : H12AffineEnvironment.transform 11 1583 env40153 = env40154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env40153 == env40154) = true)

theorem identity40154 : scanCanonicalize (H12AffineFastState.compose env40154 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40154 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env40155 : List Nat := [2,4,8,16,32,16,9,36,512,1024,32,1583,1559,16384,1598,1564,16400,33,1024,1599,17461,1567,16,3,1558,16,1566,16401,1583,1567,1057,1566,36,33,16385,513]

theorem envBound40155 : H12AffineFastState.Bounded env40155 := by
  intro p hp
  have h : env40155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40154_40155 : H12AffineEnvironment.transform 7 36 env40154 = env40155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40154 == env40155) = true)

theorem identity40155 : scanCanonicalize (H12AffineFastState.compose env40155 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 1076) := by decide +kernel

theorem selectedBound40155 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40156 : List Nat := [2,4,8,16,32,16,9,36,512,1024,32,1583,1559,1076,1598,1564,1060,33,1024,1599,1,1567,16,3,1558,16,1566,1061,1583,1567,1057,1566,36,33,1077,513]

theorem envBound40156 : H12AffineFastState.Bounded env40156 := by
  intro p hp
  have h : env40156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40155_40156 : H12AffineEnvironment.transform 13 1076 env40155 = env40156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1076 env40155 == env40156) = true)

theorem identity40156 : scanCanonicalize (H12AffineFastState.compose env40156 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound40156 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40157 : List Nat := [2,4,8,16,32,16,9,36,22,1024,32,1081,1025,1076,1064,1034,1060,33,1024,1065,1,1033,16,3,1024,16,1032,1061,1081,1033,1057,1032,36,33,1077,23]

theorem envBound40157 : H12AffineFastState.Bounded env40157 := by
  intro p hp
  have h : env40157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40156_40157 : H12AffineEnvironment.transform 8 22 env40156 = env40157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env40156 == env40157) = true)

theorem identity40157 : scanCanonicalize (H12AffineFastState.compose env40157 (packedSelected [0,3,10] rootPS)) = affineNative (2^(4+1) ^^^ 28) := by decide +kernel

theorem selectedBound40157 : packedSelected [0,3,10] rootPS < 2^1333 := by decide +kernel

def env40158 : List Nat := [2,4,8,16,28,16,9,24,22,1024,28,1029,1025,1032,1044,1034,1048,29,1024,1045,1,1033,16,3,1024,16,1032,1049,1029,1033,1053,1032,24,29,1033,23]

theorem envBound40158 : H12AffineFastState.Bounded env40158 := by
  intro p hp
  have h : env40158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40157_40158 : H12AffineEnvironment.transform 4 28 env40157 = env40158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 28 env40157 == env40158) = true)

theorem identity40158 : scanCanonicalize (H12AffineFastState.compose env40158 (packedSelected [3,4] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound40158 : packedSelected [3,4] rootPS < 2^1333 := by decide +kernel

def env40159 : List Nat := [2,4,8,12,0,12,9,4,10,1024,0,1029,1025,1032,1032,1034,1028,1,1024,1033,1,1033,12,3,1024,12,1032,1029,1029,1033,1025,1032,4,1,1033,11]

theorem envBound40159 : H12AffineFastState.Bounded env40159 := by
  intro p hp
  have h : env40159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40158_40159 : H12AffineEnvironment.transform 3 12 env40158 = env40159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env40158 == env40159) = true)

theorem identity40159 : scanCanonicalize (H12AffineFastState.compose env40159 (packedSelected [0,3] rootPS)) = affineNative (2^(9+1) ^^^ 9) := by decide +kernel

theorem selectedBound40159 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env40160 : List Nat := [2,4,8,12,0,12,9,4,10,9,0,12,8,1,1,3,13,1,9,0,1,0,12,3,9,12,1,12,12,0,8,1,4,1,0,11]

theorem envBound40160 : H12AffineFastState.Bounded env40160 := by
  intro p hp
  have h : env40160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40159_40160 : H12AffineEnvironment.transform 9 9 env40159 = env40160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 9 env40159 == env40160) = true)

theorem identity40160 : scanCanonicalize (H12AffineFastState.compose env40160 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound40160 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40161 : List Nat := [0,4,8,12,0,12,9,4,8,9,0,12,8,1,1,1,13,1,9,0,1,0,12,1,9,12,1,12,12,0,8,1,4,1,0,9]

theorem envBound40161 : H12AffineFastState.Bounded env40161 := by
  intro p hp
  have h : env40161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40160_40161 : H12AffineEnvironment.transform 0 0 env40160 = env40161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env40160 == env40161) = true)

def env40162 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41231,8193,17,4530446,114966,45324,294912,75023,4268042,256,98598,90123,513]

theorem envBound40162 : H12AffineFastState.Bounded env40162 := by
  intro p hp
  have h : env40162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40146_40162 : H12AffineEnvironment.transform 5 17 env40146 = env40162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40146 == env40162) = true)

theorem identity40162 : scanCanonicalize (H12AffineFastState.compose env40162 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329730) := by decide +kernel

theorem selectedBound40162 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env40163 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,329730,16,41231,8193,17,10508,114966,45324,294912,75023,272392,256,98598,90123,513]

theorem envBound40163 : H12AffineFastState.Bounded env40163 := by
  intro p hp
  have h : env40163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40162_40163 : H12AffineEnvironment.transform 21 329730 env40162 = env40163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329730 env40162 == env40163) = true)

theorem identity40163 : scanCanonicalize (H12AffineFastState.compose env40163 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40163 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env40164 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16400,262144,1024,32769,50448,329730,16,32771,269,17,2048,114966,36864,294912,66563,264452,256,98598,82183,513]

theorem envBound40164 : H12AffineFastState.Bounded env40164 := by
  intro p hp
  have h : env40164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40163_40164 : H12AffineEnvironment.transform 12 268 env40163 = env40164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40163 == env40164) = true)

theorem identity40164 : scanCanonicalize (H12AffineFastState.compose env40164 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound40164 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env40165 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,65536,16400,35108,1024,32769,50448,98598,16,32771,269,17,2048,114966,36864,2340,66563,32800,256,98598,82183,513]

theorem envBound40165 : H12AffineFastState.Bounded env40165 := by
  intro p hp
  have h : env40165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40164_40165 : H12AffineEnvironment.transform 17 35108 env40164 = env40165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env40164 == env40165) = true)

theorem identity40165 : scanCanonicalize (H12AffineFastState.compose env40165 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound40165 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40166 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,32768,263,16400,35108,1024,32769,50448,32801,16,32771,269,17,2048,49169,36864,2340,1284,32800,256,32801,16384,513]

theorem envBound40166 : H12AffineFastState.Bounded env40166 := by
  intro p hp
  have h : env40166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40165_40166 : H12AffineEnvironment.transform 15 263 env40165 = env40166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env40165 == env40166) = true)

theorem identity40166 : scanCanonicalize (H12AffineFastState.compose env40166 (packedSelected [2,3,5] rootPS)) = affineNative (2^(14+1) ^^^ 5409) := by decide +kernel

theorem selectedBound40166 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env40167 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,5409,263,16400,7173,1024,5408,20529,5376,16,5410,269,17,2048,21808,1313,2340,1284,5377,256,5376,16384,513]

theorem envBound40167 : H12AffineFastState.Bounded env40167 := by
  intro p hp
  have h : env40167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40166_40167 : H12AffineEnvironment.transform 14 5409 env40166 = env40167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 5409 env40166 == env40167) = true)

theorem identity40167 : scanCanonicalize (H12AffineFastState.compose env40167 (packedSelected [4,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40167 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env40168 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,268,16384,4145,263,16400,6421,272,4144,20529,4112,16,4146,269,17,2048,20512,49,2340,20,4113,256,4112,16384,513]

theorem envBound40168 : H12AffineFastState.Bounded env40168 := by
  intro p hp
  have h : env40168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40167_40168 : H12AffineEnvironment.transform 9 272 env40167 = env40168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40167 == env40168) = true)

theorem identity40168 : scanCanonicalize (H12AffineFastState.compose env40168 (packedSelected [3,8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound40168 : packedSelected [3,8] rootPS < 2^1333 := by decide +kernel

def env40169 : List Nat := [2,4,8,16,32,17,9,256,42,272,2048,4096,268,16384,4145,263,16400,6421,272,4144,20529,4112,16,4146,269,17,2048,20512,49,2340,20,4113,256,4112,16384,43]

theorem envBound40169 : H12AffineFastState.Bounded env40169 := by
  intro p hp
  have h : env40169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40168_40169 : H12AffineEnvironment.transform 8 42 env40168 = env40169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env40168 == env40169) = true)

theorem identity40169 : scanCanonicalize (H12AffineFastState.compose env40169 (packedSelected [0,9] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound40169 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env40170 : List Nat := [2,4,8,16,32,17,9,256,42,272,2048,309,268,16384,260,263,16400,2080,272,261,16644,293,16,263,269,17,2048,16661,49,2340,20,292,256,293,16384,43]

theorem envBound40170 : H12AffineFastState.Bounded env40170 := by
  intro p hp
  have h : env40170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40169_40170 : H12AffineEnvironment.transform 11 309 env40169 = env40170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env40169 == env40170) = true)

theorem identity40170 : scanCanonicalize (H12AffineFastState.compose env40170 (packedSelected [1,2,3,10] rootPS)) = affineNative (2^(13+1) ^^^ 2308) := by decide +kernel

theorem selectedBound40170 : packedSelected [1,2,3,10] rootPS < 2^1333 := by decide +kernel

def env40171 : List Nat := [2,4,8,16,32,17,9,256,42,272,2048,309,268,2308,260,263,2324,2080,272,261,2048,293,16,263,269,17,2048,2065,49,2340,20,292,256,293,2308,43]

theorem envBound40171 : H12AffineFastState.Bounded env40171 := by
  intro p hp
  have h : env40171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40170_40171 : H12AffineEnvironment.transform 13 2308 env40170 = env40171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2308 env40170 == env40171) = true)

theorem identity40171 : scanCanonicalize (H12AffineFastState.compose env40171 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound40171 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env40172 : List Nat := [2,4,8,16,32,17,9,256,42,272,292,309,268,32,260,263,48,260,272,261,292,293,16,263,269,17,292,309,49,0,20,292,256,293,32,43]

theorem envBound40172 : H12AffineFastState.Bounded env40172 := by
  intro p hp
  have h : env40172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40171_40172 : H12AffineEnvironment.transform 10 292 env40171 = env40172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env40171 == env40172) = true)

def env40173 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41310,8193,64,4530527,115014,45404,294912,75102,4268043,256,98678,90203,513]

theorem envBound40173 : H12AffineFastState.Bounded env40173 := by
  intro p hp
  have h : env40173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40145_40173 : H12AffineEnvironment.transform 20 58397 env40145 = env40173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env40145 == env40173) = true)

theorem identity40173 : scanCanonicalize (H12AffineFastState.compose env40173 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40173 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40174 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,58397,4194304,16,41310,8193,64,4456789,57676,45404,294912,1364,4194305,256,41340,16465,513]

theorem envBound40174 : H12AffineFastState.Bounded env40174 := by
  intro p hp
  have h : env40174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40173_40174 : H12AffineEnvironment.transform 15 8202 env40173 = env40174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40173 == env40174) = true)

theorem identity40174 : scanCanonicalize (H12AffineFastState.compose env40174 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272473) := by decide +kernel

theorem selectedBound40174 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env40175 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1024,32769,58397,272473,16,41310,8193,64,10508,57676,45404,294912,1364,272472,256,41340,16465,513]

theorem envBound40175 : H12AffineFastState.Bounded env40175 := by
  intro p hp
  have h : env40175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40174_40175 : H12AffineEnvironment.transform 21 272473 env40174 = env40175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272473 env40174 == env40175) = true)

theorem identity40175 : scanCanonicalize (H12AffineFastState.compose env40175 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound40175 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env40176 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43049,1024,32769,58397,32880,16,41310,8193,64,10508,57676,45404,10281,1364,32881,256,41340,16465,513]

theorem envBound40176 : H12AffineFastState.Bounded env40176 := by
  intro p hp
  have h : env40176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40175_40176 : H12AffineEnvironment.transform 17 43049 env40175 = env40176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env40175 == env40176) = true)

theorem identity40176 : scanCanonicalize (H12AffineFastState.compose env40176 (packedSelected [11,32] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound40176 : packedSelected [11,32] rootPS < 2^1333 := by decide +kernel

def env40177 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,2420,1024,8540,17728,8493,16,3,8193,64,10508,16401,4097,10281,1364,8492,256,33,16465,513]

theorem envBound40177 : H12AffineFastState.Bounded env40177 := by
  intro p hp
  have h : env40177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40176_40177 : H12AffineEnvironment.transform 14 8541 env40176 = env40177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env40176 == env40177) = true)

theorem identity40177 : scanCanonicalize (H12AffineFastState.compose env40177 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40177 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40178 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,16384,8460,8202,16400,2341,1024,8461,17681,8493,16,3,8193,17,10508,16401,4097,10281,1285,8492,256,33,16384,513]

theorem envBound40178 : H12AffineFastState.Bounded env40178 := by
  intro p hp
  have h : env40178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40177_40178 : H12AffineEnvironment.transform 5 17 env40177 = env40178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40177 == env40178) = true)

theorem identity40178 : scanCanonicalize (H12AffineFastState.compose env40178 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound40178 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40179 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,5157,8460,8202,5173,2341,1024,8461,4404,8493,16,3,8193,17,10508,5172,4097,10281,1285,8492,256,33,5157,513]

theorem envBound40179 : H12AffineFastState.Bounded env40179 := by
  intro p hp
  have h : env40179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40178_40179 : H12AffineEnvironment.transform 13 5157 env40178 = env40179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env40178 == env40179) = true)

theorem identity40179 : scanCanonicalize (H12AffineFastState.compose env40179 (packedSelected [5,8] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound40179 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40180 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5157,0,262,5173,2341,1024,1,4404,33,16,3,269,17,2048,5172,4097,2341,1285,32,256,33,5157,513]

theorem envBound40180 : H12AffineFastState.Bounded env40180 := by
  intro p hp
  have h : env40180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40179_40180 : H12AffineEnvironment.transform 12 268 env40179 = env40180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env40179 == env40180) = true)

def env40181 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3888,268,2837,0,262,2821,2341,1024,1,3588,33,16,3,269,17,2048,2820,3889,2341,1285,32,256,33,2837,513]

theorem envBound40181 : H12AffineFastState.Bounded env40181 := by
  intro p hp
  have h : env40181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40180_40181 : H12AffineEnvironment.transform 11 3888 env40180 = env40181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env40180 == env40181) = true)

def env40182 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,48,268,1045,0,262,1029,1573,1024,1,260,33,16,3,269,17,1792,1028,49,1573,1285,32,256,33,1045,513]

theorem envBound40182 : H12AffineFastState.Bounded env40182 := by
  intro p hp
  have h : env40182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40181_40182 : H12AffineEnvironment.transform 10 1792 env40181 = env40182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env40181 == env40182) = true)

theorem identity40182 : scanCanonicalize (H12AffineFastState.compose env40182 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40182 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40183 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,48,40,1045,0,34,1029,1573,1024,1,32,33,16,3,41,17,1572,1028,49,1573,1057,32,36,33,1045,513]

theorem envBound40183 : H12AffineFastState.Bounded env40183 := by
  intro p hp
  have h : env40183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40182_40183 : H12AffineEnvironment.transform 7 36 env40182 = env40183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40182 == env40183) = true)

def env40184 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,40,33,0,34,49,529,52,1,32,33,16,3,41,17,528,48,49,529,21,32,36,33,33,513]

theorem envBound40184 : H12AffineFastState.Bounded env40184 := by
  intro p hp
  have h : env40184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40183_40184 : H12AffineEnvironment.transform 9 52 env40183 = env40184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40183 == env40184) = true)

theorem identity40184 : scanCanonicalize (H12AffineFastState.compose env40184 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound40184 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40185 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,48,40,33,0,34,49,59,52,1,32,33,16,3,41,17,58,48,49,59,21,32,36,33,33,43]

theorem envBound40185 : H12AffineFastState.Bounded env40185 := by
  intro p hp
  have h : env40185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40184_40185 : H12AffineEnvironment.transform 8 42 env40184 = env40185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env40184 == env40185) = true)

def leafEnv40185 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,48,40,33,0,34,49,59,52,1,32,33,16,3,21,41,1,17,58,48,49,59,21,32,36,33,4,35,33,43,1,32,0]

def active40185 : List Nat := [0,1,2,3,4]

def tree40185 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40185 : H12WitnessSearch.Good tree40185 := H12GlobalWitnessIndex.good

theorem leafIdentity40185 : H12AffineFastState.composeSystem env40185 rootObs = leafEnv40185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40185 rootObs == leafEnv40185) = true)

theorem terminalChecked40185 : H12PackedTerminal.terminalCheckFast leafEnv40185 active40185 tree40185 = true := by decide +kernel

def env40186 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,40,32,0,34,48,528,53,1,32,33,16,3,41,17,529,49,49,528,20,32,36,33,32,513]

theorem envBound40186 : H12AffineFastState.Bounded env40186 := by
  intro p hp
  have h : env40186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40183_40186 : H12AffineEnvironment.transform 9 53 env40183 = env40186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40183 == env40186) = true)

def env40187 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,49,268,1044,0,262,1028,1572,1024,1,261,33,16,3,269,17,1793,1029,48,1572,1285,32,256,33,1044,513]

theorem envBound40187 : H12AffineFastState.Bounded env40187 := by
  intro p hp
  have h : env40187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40181_40187 : H12AffineEnvironment.transform 10 1793 env40181 = env40187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env40181 == env40187) = true)

theorem identity40187 : scanCanonicalize (H12AffineFastState.compose env40187 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40187 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40188 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,49,268,32,0,262,48,528,52,1,261,33,16,3,269,17,821,49,48,528,305,32,256,33,32,513]

theorem envBound40188 : H12AffineFastState.Bounded env40188 := by
  intro p hp
  have h : env40188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40187_40188 : H12AffineEnvironment.transform 9 52 env40187 = env40188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40187 == env40188) = true)

theorem identity40188 : scanCanonicalize (H12AffineFastState.compose env40188 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound40188 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40189 : List Nat := [2,4,8,16,32,17,9,256,271,52,58,49,268,32,0,262,48,287,52,1,261,33,16,3,269,17,58,49,48,287,305,32,256,33,32,270]

theorem envBound40189 : H12AffineFastState.Bounded env40189 := by
  intro p hp
  have h : env40189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40188_40189 : H12AffineEnvironment.transform 8 271 env40188 = env40189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env40188 == env40189) = true)

def leafEnv40189 : List Nat := [2,4,8,16,32,17,9,256,271,52,58,49,268,32,0,262,48,287,52,1,261,33,16,3,305,269,1,17,58,49,48,287,305,32,256,33,4,263,32,270,1,261,0]

def active40189 : List Nat := [0,1,2,3,4,7]

def tree40189 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40189 : H12WitnessSearch.Good tree40189 := H12GlobalWitnessIndex.good

theorem leafIdentity40189 : H12AffineFastState.composeSystem env40189 rootObs = leafEnv40189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40189 rootObs == leafEnv40189) = true)

theorem terminalChecked40189 : H12PackedTerminal.terminalCheckFast leafEnv40189 active40189 tree40189 = true := by decide +kernel

def env40190 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3889,268,2836,0,262,2820,2341,1024,1,3589,33,16,3,269,17,2048,2821,3888,2341,1285,32,256,33,2836,513]

theorem envBound40190 : H12AffineFastState.Bounded env40190 := by
  intro p hp
  have h : env40190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40180_40190 : H12AffineEnvironment.transform 11 3889 env40180 = env40190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env40180 == env40190) = true)

def env40191 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1792,49,268,1044,0,262,1028,1573,1024,1,261,33,16,3,269,17,1792,1029,48,1573,1285,32,256,33,1044,513]

theorem envBound40191 : H12AffineFastState.Bounded env40191 := by
  intro p hp
  have h : env40191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40190_40191 : H12AffineEnvironment.transform 10 1792 env40190 = env40191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env40190 == env40191) = true)

theorem identity40191 : scanCanonicalize (H12AffineFastState.compose env40191 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40191 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40192 : List Nat := [2,4,8,16,32,17,9,256,512,272,528,49,268,260,0,262,276,821,272,1,261,33,16,3,269,17,528,277,48,821,21,32,256,33,260,513]

theorem envBound40192 : H12AffineFastState.Bounded env40192 := by
  intro p hp
  have h : env40192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40191_40192 : H12AffineEnvironment.transform 9 272 env40191 = env40192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40191 == env40192) = true)

def env40193 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,40,32,0,34,48,529,52,1,33,33,16,3,41,17,528,49,48,529,21,32,36,33,32,513]

theorem envBound40193 : H12AffineFastState.Bounded env40193 := by
  intro p hp
  have h : env40193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40192_40193 : H12AffineEnvironment.transform 7 36 env40192 = env40193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40192 == env40193) = true)

theorem identity40193 : scanCanonicalize (H12AffineFastState.compose env40193 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound40193 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40194 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,49,40,32,0,34,48,58,52,1,33,33,16,3,41,17,59,49,48,58,21,32,36,33,32,42]

theorem envBound40194 : H12AffineFastState.Bounded env40194 := by
  intro p hp
  have h : env40194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40193_40194 : H12AffineEnvironment.transform 8 43 env40193 = env40194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env40193 == env40194) = true)

def leafEnv40194 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,49,40,32,0,34,48,58,52,1,33,33,16,3,21,41,1,17,59,49,48,58,21,32,36,33,4,35,32,42,1,33,0]

def active40194 : List Nat := [0,1,2,3,4]

def tree40194 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40194 : H12WitnessSearch.Good tree40194 := H12GlobalWitnessIndex.good

theorem leafIdentity40194 : H12AffineFastState.composeSystem env40194 rootObs = leafEnv40194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40194 rootObs == leafEnv40194) = true)

theorem terminalChecked40194 : H12PackedTerminal.terminalCheckFast leafEnv40194 active40194 tree40194 = true := by decide +kernel

def env40195 : List Nat := [2,4,8,16,32,17,9,37,512,53,528,49,41,33,0,35,49,528,53,1,32,33,16,3,40,17,528,48,48,528,21,32,37,33,33,513]

theorem envBound40195 : H12AffineFastState.Bounded env40195 := by
  intro p hp
  have h : env40195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40192_40195 : H12AffineEnvironment.transform 7 37 env40192 = env40195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40192 == env40195) = true)

def env40196 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1793,48,268,1045,0,262,1029,1572,1024,1,260,33,16,3,269,17,1793,1028,49,1572,1285,32,256,33,1045,513]

theorem envBound40196 : H12AffineFastState.Bounded env40196 := by
  intro p hp
  have h : env40196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40190_40196 : H12AffineEnvironment.transform 10 1793 env40190 = env40196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env40190 == env40196) = true)

def env40197 : List Nat := [2,4,8,16,32,17,9,256,512,52,821,48,268,33,0,262,49,528,52,1,260,33,16,3,269,17,821,48,49,528,305,32,256,33,33,513]

theorem envBound40197 : H12AffineFastState.Bounded env40197 := by
  intro p hp
  have h : env40197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40196_40197 : H12AffineEnvironment.transform 9 52 env40196 = env40197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40196 == env40197) = true)

theorem identity40197 : scanCanonicalize (H12AffineFastState.compose env40197 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 270) := by decide +kernel

theorem selectedBound40197 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40198 : List Nat := [2,4,8,16,32,17,9,256,270,52,59,48,268,33,0,262,49,286,52,1,260,33,16,3,269,17,59,48,49,286,305,32,256,33,33,271]

theorem envBound40198 : H12AffineFastState.Bounded env40198 := by
  intro p hp
  have h : env40198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40197_40198 : H12AffineEnvironment.transform 8 270 env40197 = env40198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 270 env40197 == env40198) = true)

def leafEnv40198 : List Nat := [2,4,8,16,32,17,9,256,270,52,59,48,268,33,0,262,49,286,52,1,260,33,16,3,305,269,1,17,59,48,49,286,305,32,256,33,4,263,33,271,1,260,0]

def active40198 : List Nat := [0,1,2,3,4,7]

def tree40198 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40198 : H12WitnessSearch.Good tree40198 := H12GlobalWitnessIndex.good

theorem leafIdentity40198 : H12AffineFastState.composeSystem env40198 rootObs = leafEnv40198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40198 rootObs == leafEnv40198) = true)

theorem terminalChecked40198 : H12PackedTerminal.terminalCheckFast leafEnv40198 active40198 tree40198 = true := by decide +kernel

def env40199 : List Nat := [2,4,8,16,32,17,9,256,512,53,820,48,268,32,0,262,48,529,53,1,260,33,16,3,269,17,820,49,49,529,304,32,256,33,32,513]

theorem envBound40199 : H12AffineFastState.Bounded env40199 := by
  intro p hp
  have h : env40199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40196_40199 : H12AffineEnvironment.transform 9 53 env40196 = env40199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40196 == env40199) = true)

def env40200 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331968,18973701,2118977,294913,16876544,23160136,256,18990133,18949400,16819039]

theorem envBound40200 : H12AffineFastState.Bounded env40200 := by
  intro p hp
  have h : env40200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40143_40200 : H12AffineEnvironment.transform 16 16401 env40143 = env40200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env40143 == env40200) = true)

def env40201 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331968,18973701,2118709,294913,16876544,23159868,116,18990133,18949228,16818731]

theorem envBound40201 : H12AffineFastState.Bounded env40201 := by
  intro p hp
  have h : env40201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40200_40201 : H12AffineEnvironment.transform 7 116 env40200 = env40201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env40200 == env40201) = true)

theorem identity40201 : scanCanonicalize (H12AffineFastState.compose env40201 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(23+1) ^^^ 2444308) := by decide +kernel

theorem selectedBound40201 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env40202 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,2444308,8193,64,6343700,313361,2118709,294913,2410516,4466728,116,296993,288888,2485823]

theorem envBound40202 : H12AffineFastState.Bounded env40202 := by
  intro p hp
  have h : env40202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40201_40202 : H12AffineEnvironment.transform 23 2444308 env40201 = env40202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2444308 env40201 == env40202) = true)

def env40203 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56436,1024,32769,2097152,4194304,16,2199648,8193,64,6343700,5221,2118709,23669,2102368,4256860,116,21589,46092,2175563]

theorem envBound40203 : H12AffineFastState.Bounded env40203 := by
  intro p hp
  have h : env40203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40202_40203 : H12AffineEnvironment.transform 17 56436 env40202 = env40203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56436 env40202 == env40203) = true)

def env40204 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56436,1024,32769,4160,4194304,16,98336,8193,64,4250708,5221,17525,23669,1056,4256860,116,21589,46092,74251]

theorem envBound40204 : H12AffineFastState.Bounded env40204 := by
  intro p hp
  have h : env40204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40203_40204 : H12AffineEnvironment.transform 20 4160 env40203 = env40204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40203 == env40204) = true)

theorem identity40204 : scanCanonicalize (H12AffineFastState.compose env40204 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40204 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40205 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,8202,16401,56436,1024,32769,4160,4194304,16,41002,8193,64,4250708,5221,17525,23669,1056,4256860,116,21589,46092,513]

theorem envBound40205 : H12AffineFastState.Bounded env40205 := by
  intro p hp
  have h : env40205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40204_40205 : H12AffineEnvironment.transform 15 8202 env40204 = env40205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40204 == env40205) = true)

theorem identity40205 : scanCanonicalize (H12AffineFastState.compose env40205 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound40205 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env40206 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,8202,5220,34817,1024,32769,4160,4194304,16,41002,8193,64,4229153,5221,4096,2048,1056,4235305,116,32,46092,513]

theorem envBound40206 : H12AffineFastState.Bounded env40206 := by
  intro p hp
  have h : env40206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40205_40206 : H12AffineEnvironment.transform 13 5237 env40205 = env40206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env40205 == env40206) = true)

theorem identity40206 : scanCanonicalize (H12AffineFastState.compose env40206 (packedSelected [3,8,10] rootPS)) = affineNative (2^(21+1) ^^^ 44134) := by decide +kernel

theorem selectedBound40206 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env40207 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,8202,5220,34817,1024,32769,4160,44134,16,41002,8193,64,9287,5221,4096,2048,1056,3151,116,32,46092,513]

theorem envBound40207 : H12AffineFastState.Bounded env40207 := by
  intro p hp
  have h : env40207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40206_40207 : H12AffineEnvironment.transform 21 44134 env40206 = env40207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 44134 env40206 == env40207) = true)

theorem identity40207 : scanCanonicalize (H12AffineFastState.compose env40207 (packedSelected [0,2,4,6,7,9,14,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40207 : packedSelected [0,2,4,6,7,9,14,18,23] rootPS < 2^1333 := by decide +kernel

def env40208 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,32768,35,5220,34817,1024,32769,4160,35919,16,32771,40,64,1134,5221,4096,2048,1056,3151,116,32,37925,513]

theorem envBound40208 : H12AffineFastState.Bounded env40208 := by
  intro p hp
  have h : env40208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40207_40208 : H12AffineEnvironment.transform 12 41 env40207 = env40208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40207 == env40208) = true)

theorem identity40208 : scanCanonicalize (H12AffineFastState.compose env40208 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1087) := by decide +kernel

theorem selectedBound40208 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40209 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1087,4096,41,5237,32768,35,5220,33854,1024,32769,4160,32880,16,32771,40,64,1134,5221,4096,1087,1056,112,116,32,37925,513]

theorem envBound40209 : H12AffineFastState.Bounded env40209 := by
  intro p hp
  have h : env40209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40208_40209 : H12AffineEnvironment.transform 10 1087 env40208 = env40209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1087 env40208 == env40209) = true)

theorem identity40209 : scanCanonicalize (H12AffineFastState.compose env40209 (packedSelected [5,8,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound40209 : packedSelected [5,8,12,15] rootPS < 2^1333 := by decide +kernel

def env40210 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1087,4096,41,5237,80,35,5220,1134,1024,81,4160,32,16,83,40,64,1134,5221,4096,1087,1056,112,116,32,5237,513]

theorem envBound40210 : H12AffineFastState.Bounded env40210 := by
  intro p hp
  have h : env40210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40209_40210 : H12AffineEnvironment.transform 14 80 env40209 = env40210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env40209 == env40210) = true)

theorem identity40210 : scanCanonicalize (H12AffineFastState.compose env40210 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 80) := by decide +kernel

theorem selectedBound40210 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env40211 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1087,80,41,1061,80,35,1076,1134,1024,81,16,32,16,83,40,64,1134,1077,80,1087,1056,112,116,32,1061,513]

theorem envBound40211 : H12AffineFastState.Bounded env40211 := by
  intro p hp
  have h : env40211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40210_40211 : H12AffineEnvironment.transform 11 80 env40210 = env40211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 80 env40210 == env40211) = true)

theorem identity40211 : scanCanonicalize (H12AffineFastState.compose env40211 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound40211 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env40212 : List Nat := [2,4,8,16,32,64,9,116,512,52,11,80,41,17,80,35,0,90,52,81,16,32,16,83,40,64,90,1,80,11,20,112,116,32,17,513]

theorem envBound40212 : H12AffineFastState.Bounded env40212 := by
  intro p hp
  have h : env40212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40211_40212 : H12AffineEnvironment.transform 9 52 env40211 = env40212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env40211 == env40212) = true)

theorem identity40212 : scanCanonicalize (H12AffineFastState.compose env40212 (packedSelected [0,2] rootPS)) = affineNative (2^(8+1) ^^^ 46) := by decide +kernel

theorem selectedBound40212 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env40213 : List Nat := [2,4,8,16,32,64,9,116,46,52,11,80,41,17,80,35,0,90,52,81,16,32,16,83,40,64,90,1,80,11,20,112,116,32,17,47]

theorem envBound40213 : H12AffineFastState.Bounded env40213 := by
  intro p hp
  have h : env40213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40212_40213 : H12AffineEnvironment.transform 8 46 env40212 = env40213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 46 env40212 == env40213) = true)

theorem identity40213 : scanCanonicalize (H12AffineFastState.compose env40213 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40213 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40214 : List Nat := [2,4,8,16,32,16,9,36,46,52,11,0,41,17,0,35,0,10,52,1,16,32,16,3,40,16,10,1,0,11,20,32,36,32,17,47]

theorem envBound40214 : H12AffineFastState.Bounded env40214 := by
  intro p hp
  have h : env40214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40213_40214 : H12AffineEnvironment.transform 5 16 env40213 = env40214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40213 == env40214) = true)

def env40215 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56436,1024,32769,4161,4194304,16,98337,8193,64,4250709,5221,17524,23669,1057,4256860,116,21589,46092,74250]

theorem envBound40215 : H12AffineFastState.Bounded env40215 := by
  intro p hp
  have h : env40215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40203_40215 : H12AffineEnvironment.transform 20 4161 env40203 = env40215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40203 == env40215) = true)

theorem identity40215 : scanCanonicalize (H12AffineFastState.compose env40215 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound40215 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40216 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54358,16401,56436,1024,32769,4161,4194304,16,21623,8193,64,4250709,5221,17524,23669,1057,4256860,116,21589,46092,63068]

theorem envBound40216 : H12AffineFastState.Bounded env40216 := by
  intro p hp
  have h : env40216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40215_40216 : H12AffineEnvironment.transform 15 54358 env40215 = env40216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env40215 == env40216) = true)

theorem identity40216 : scanCanonicalize (H12AffineFastState.compose env40216 (packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound40216 : packedSelected [0,1,3,4,5,8,9,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env40217 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,54358,16401,56436,1024,32769,4161,8201,16,21623,8193,64,64604,5221,17524,23669,1057,54357,116,21589,46092,63068]

theorem envBound40217 : H12AffineFastState.Bounded env40217 := by
  intro p hp
  have h : env40217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40216_40217 : H12AffineEnvironment.transform 21 8201 env40216 = env40217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env40216 == env40217) = true)

theorem identity40217 : scanCanonicalize (H12AffineFastState.compose env40217 (packedSelected [2,3,4,5,6,9,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound40217 : packedSelected [2,3,4,5,6,9,15,18,19] rootPS < 2^1333 := by decide +kernel

def env40218 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,32768,32803,5220,34817,1024,32769,4161,8201,16,2,8193,64,43049,5221,4097,2048,1057,32800,116,32,46092,41513]

theorem envBound40218 : H12AffineFastState.Bounded env40218 := by
  intro p hp
  have h : env40218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40217_40218 : H12AffineEnvironment.transform 13 5237 env40217 = env40218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env40217 == env40218) = true)

theorem identity40218 : scanCanonicalize (H12AffineFastState.compose env40218 (packedSelected [3,5,10,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound40218 : packedSelected [3,5,10,11,18] rootPS < 2^1333 := by decide +kernel

def env40219 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5237,8232,8203,5220,10281,1024,8233,4161,8201,16,2,8193,64,2049,5221,4097,2048,1057,8200,116,32,5156,513]

theorem envBound40219 : H12AffineFastState.Bounded env40219 := by
  intro p hp
  have h : env40219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40218_40219 : H12AffineEnvironment.transform 14 8232 env40218 = env40219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env40218 == env40219) = true)

theorem identity40219 : scanCanonicalize (H12AffineFastState.compose env40219 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40219 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40220 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,41,5237,1,34,5220,2048,1024,0,4161,32,16,2,40,64,2049,5221,4097,2048,1057,33,116,32,5156,513]

theorem envBound40220 : H12AffineFastState.Bounded env40220 := by
  intro p hp
  have h : env40220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40219_40220 : H12AffineEnvironment.transform 12 41 env40219 = env40220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40219 == env40220) = true)

theorem identity40220 : scanCanonicalize (H12AffineFastState.compose env40220 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1573) := by decide +kernel

theorem selectedBound40220 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40221 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,1573,41,592,1,34,577,2048,1024,0,1636,32,16,2,40,64,2049,576,1572,2048,1057,33,116,32,513,513]

theorem envBound40221 : H12AffineFastState.Bounded env40221 := by
  intro p hp
  have h : env40221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40220_40221 : H12AffineEnvironment.transform 11 1573 env40220 = env40221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1573 env40220 == env40221) = true)

theorem identity40221 : scanCanonicalize (H12AffineFastState.compose env40221 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 576) := by decide +kernel

theorem selectedBound40221 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env40222 : List Nat := [2,4,8,16,32,64,9,116,512,1024,576,1573,41,592,1,34,577,576,1024,0,1636,32,16,2,40,64,577,576,1572,576,1057,33,116,32,513,513]

theorem envBound40222 : H12AffineFastState.Bounded env40222 := by
  intro p hp
  have h : env40222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40221_40222 : H12AffineEnvironment.transform 10 576 env40221 = env40222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 576 env40221 == env40222) = true)

theorem identity40222 : scanCanonicalize (H12AffineFastState.compose env40222 (packedSelected [5,8] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound40222 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env40223 : List Nat := [2,4,8,16,32,1,9,53,512,1024,513,1573,41,529,1,34,512,513,1024,0,1573,32,16,2,40,1,512,513,1572,513,1057,33,53,32,513,513]

theorem envBound40223 : H12AffineFastState.Bounded env40223 := by
  intro p hp
  have h : env40223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40222_40223 : H12AffineEnvironment.transform 5 1 env40222 = env40223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env40222 == env40223) = true)

theorem identity40223 : scanCanonicalize (H12AffineFastState.compose env40223 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound40223 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env40224 : List Nat := [2,4,8,16,32,1,9,53,512,37,513,512,41,529,1,34,512,513,37,0,512,32,16,2,40,1,512,513,513,513,4,33,53,32,513,513]

theorem envBound40224 : H12AffineFastState.Bounded env40224 := by
  intro p hp
  have h : env40224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40223_40224 : H12AffineEnvironment.transform 9 37 env40223 = env40224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env40223 == env40224) = true)

theorem identity40224 : scanCanonicalize (H12AffineFastState.compose env40224 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound40224 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env40225 : List Nat := [2,4,8,16,17,1,9,4,512,20,513,512,24,529,1,19,512,513,20,0,512,17,16,2,25,1,512,513,513,513,4,16,4,17,513,513]

theorem envBound40225 : H12AffineFastState.Bounded env40225 := by
  intro p hp
  have h : env40225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40224_40225 : H12AffineEnvironment.transform 4 17 env40224 = env40225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env40224 == env40225) = true)

theorem identity40225 : scanCanonicalize (H12AffineFastState.compose env40225 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40225 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40226 : List Nat := [2,4,8,0,1,1,9,4,512,4,513,512,8,513,1,3,512,513,4,0,512,1,0,2,9,1,512,513,513,513,4,0,4,1,513,513]

theorem envBound40226 : H12AffineFastState.Bounded env40226 := by
  intro p hp
  have h : env40226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40225_40226 : H12AffineEnvironment.transform 3 0 env40225 = env40226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40225 == env40226) = true)

theorem identity40226 : scanCanonicalize (H12AffineFastState.compose env40226 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40226 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40227 : List Nat := [2,4,8,0,1,1,9,4,1,4,0,1,8,0,1,3,1,0,4,0,1,1,0,2,9,1,1,0,0,0,4,0,4,1,0,0]

theorem envBound40227 : H12AffineFastState.Bounded env40227 := by
  intro p hp
  have h : env40227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40226_40227 : H12AffineEnvironment.transform 8 1 env40226 = env40227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40226 == env40227) = true)

def env40228 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56437,1024,32769,2097152,4194304,16,2199649,8193,64,6343700,5220,2118709,23668,2102369,4256861,116,21588,46093,2175562]

theorem envBound40228 : H12AffineFastState.Bounded env40228 := by
  intro p hp
  have h : env40228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40202_40228 : H12AffineEnvironment.transform 17 56437 env40202 = env40228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56437 env40202 == env40228) = true)

theorem identity40228 : scanCanonicalize (H12AffineFastState.compose env40228 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(20+1) ^^^ 77899) := by decide +kernel

theorem selectedBound40228 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40229 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16401,56437,1024,32769,77899,4194304,16,41002,8193,64,4324447,5220,91262,23668,74794,4256861,116,21588,46093,513]

theorem envBound40229 : H12AffineFastState.Bounded env40229 := by
  intro p hp
  have h : env40229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40228_40229 : H12AffineEnvironment.transform 20 77899 env40228 = env40229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77899 env40228 == env40229) = true)

theorem identity40229 : scanCanonicalize (H12AffineFastState.compose env40229 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound40229 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env40230 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29788,65536,16401,10281,1024,29789,77899,4194304,16,21622,8193,64,4261891,5220,91262,23668,74794,4194305,116,21588,16465,513]

theorem envBound40230 : H12AffineFastState.Bounded env40230 := by
  intro p hp
  have h : env40230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40229_40230 : H12AffineEnvironment.transform 14 29788 env40229 = env40230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env40229 == env40230) = true)

theorem identity40230 : scanCanonicalize (H12AffineFastState.compose env40230 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8201) := by decide +kernel

theorem selectedBound40230 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env40231 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29788,65536,16401,10281,1024,29789,77899,8201,16,21622,8193,64,75786,5220,91262,23668,74794,8200,116,21588,16465,513]

theorem envBound40231 : H12AffineFastState.Bounded env40231 := by
  intro p hp
  have h : env40231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40230_40231 : H12AffineEnvironment.transform 21 8201 env40230 = env40231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8201 env40230 == env40231) = true)

theorem identity40231 : scanCanonicalize (H12AffineFastState.compose env40231 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound40231 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env40232 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,29788,21590,16401,10281,1024,29789,25629,8201,16,21622,8193,64,31836,5220,12328,23668,28796,8200,116,21588,16465,513]

theorem envBound40232 : H12AffineFastState.Bounded env40232 := by
  intro p hp
  have h : env40232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40231_40232 : H12AffineEnvironment.transform 15 21590 env40231 = env40232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env40231 == env40232) = true)

theorem identity40232 : scanCanonicalize (H12AffineFastState.compose env40232 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40232 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40233 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,8192,16384,29708,21510,16401,10281,1024,29709,25629,8201,16,21542,8193,16,31756,5172,12328,23588,28716,8200,36,21508,16385,513]

theorem envBound40233 : H12AffineFastState.Bounded env40233 := by
  intro p hp
  have h : env40233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40232_40233 : H12AffineEnvironment.transform 5 16 env40232 = env40233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40232 == env40233) = true)

theorem identity40233 : scanCanonicalize (H12AffineFastState.compose env40233 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40233 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40234 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,16384,21541,21510,16401,2048,1024,21540,17460,32,16,21542,40,16,23589,5172,4097,23588,20485,33,36,21508,16385,513]

theorem envBound40234 : H12AffineFastState.Bounded env40234 := by
  intro p hp
  have h : env40234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40233_40234 : H12AffineEnvironment.transform 12 41 env40233 = env40234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env40233 == env40234) = true)

theorem identity40234 : scanCanonicalize (H12AffineFastState.compose env40234 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound40234 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40235 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,4096,41,5156,1,34,5173,2048,1024,0,4112,32,16,2,40,16,2049,5172,4097,2048,1057,33,36,32,5157,513]

theorem envBound40235 : H12AffineFastState.Bounded env40235 := by
  intro p hp
  have h : env40235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40234_40235 : H12AffineEnvironment.transform 13 5156 env40234 = env40235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env40234 == env40235) = true)

theorem identity40235 : scanCanonicalize (H12AffineFastState.compose env40235 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound40235 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40236 : List Nat := [2,4,8,16,32,16,9,36,512,37,2048,4096,41,4097,1,34,4112,2048,37,0,4112,32,16,2,40,16,2049,4113,4097,2048,4,33,36,32,4096,513]

theorem envBound40236 : H12AffineFastState.Bounded env40236 := by
  intro p hp
  have h : env40236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40235_40236 : H12AffineEnvironment.transform 9 37 env40235 = env40236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env40235 == env40236) = true)

theorem identity40236 : scanCanonicalize (H12AffineFastState.compose env40236 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound40236 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40237 : List Nat := [2,4,8,16,32,16,9,36,512,37,2048,513,41,512,1,34,529,2048,37,0,529,32,16,2,40,16,2049,528,512,2048,4,33,36,32,513,513]

theorem envBound40237 : H12AffineFastState.Bounded env40237 := by
  intro p hp
  have h : env40237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40236_40237 : H12AffineEnvironment.transform 11 513 env40236 = env40237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env40236 == env40237) = true)

theorem identity40237 : scanCanonicalize (H12AffineFastState.compose env40237 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40237 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40238 : List Nat := [2,4,8,16,32,16,9,36,0,37,2048,1,41,0,1,34,17,2048,37,0,17,32,16,2,40,16,2049,16,0,2048,4,33,36,32,1,1]

theorem envBound40238 : H12AffineFastState.Bounded env40238 := by
  intro p hp
  have h : env40238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40237_40238 : H12AffineEnvironment.transform 8 0 env40237 = env40238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40237 == env40238) = true)

theorem identity40238 : scanCanonicalize (H12AffineFastState.compose env40238 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound40238 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40239 : List Nat := [2,4,8,0,32,0,9,36,0,37,2048,1,41,0,1,34,1,2048,37,0,1,32,0,2,40,0,2049,0,0,2048,4,33,36,32,1,1]

theorem envBound40239 : H12AffineFastState.Bounded env40239 := by
  intro p hp
  have h : env40239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40238_40239 : H12AffineEnvironment.transform 3 0 env40238 = env40239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env40238 == env40239) = true)

theorem identity40239 : scanCanonicalize (H12AffineFastState.compose env40239 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound40239 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40240 : List Nat := [2,4,8,0,32,0,9,36,0,37,32,1,41,0,1,34,1,32,37,0,1,32,0,2,40,0,33,0,0,32,4,33,36,32,1,1]

theorem envBound40240 : H12AffineFastState.Bounded env40240 := by
  intro p hp
  have h : env40240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40239_40240 : H12AffineEnvironment.transform 10 32 env40239 = env40240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env40239 == env40240) = true)

theorem identity40240 : scanCanonicalize (H12AffineFastState.compose env40240 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40240 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40241 : List Nat := [2,4,8,0,1,0,9,5,0,4,1,1,8,0,1,3,1,1,4,0,1,1,0,2,9,0,0,0,0,1,4,0,5,1,1,1]

theorem envBound40241 : H12AffineFastState.Bounded env40241 := by
  intro p hp
  have h : env40241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40240_40241 : H12AffineEnvironment.transform 4 1 env40240 = env40241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40240 == env40241) = true)

def env40242 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8193,64,21331968,18973701,2118708,294913,16876544,23159869,117,18990133,18949229,16818730]

theorem envBound40242 : H12AffineFastState.Bounded env40242 := by
  intro p hp
  have h : env40242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40200_40242 : H12AffineEnvironment.transform 7 117 env40200 = env40242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40200 == env40242) = true)

theorem identity40242 : scanCanonicalize (H12AffineFastState.compose env40242 (packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 388158) := by decide +kernel

theorem selectedBound40242 : packedSelected [1,3,5,7,8,10,12,15,17,19,20,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env40243 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,388158,4194304,16,16777216,8193,64,21331968,17066043,374794,294913,16876544,21268483,117,17049611,17090643,16818730]

theorem envBound40243 : H12AffineFastState.Bounded env40243 := by
  intro p hp
  have h : env40243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40242_40243 : H12AffineEnvironment.transform 20 388158 env40242 = env40243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 388158 env40242 == env40243) = true)

def env40244 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,388158,4194304,16,351316,8193,64,4250708,78959,374794,294913,317524,4314199,117,95327,103431,392830]

theorem envBound40244 : H12AffineFastState.Bounded env40244 := by
  intro p hp
  have h : env40244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40243_40244 : H12AffineEnvironment.transform 23 351316 env40243 = env40244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351316 env40243 == env40244) = true)

def env40245 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115734,4194304,16,95356,8193,64,4250708,78959,102434,43049,61564,4314199,117,95327,103431,120406]

theorem envBound40245 : H12AffineFastState.Bounded env40245 := by
  intro p hp
  have h : env40245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40244_40245 : H12AffineEnvironment.transform 17 10280 env40244 = env40245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40244 == env40245) = true)

theorem identity40245 : scanCanonicalize (H12AffineFastState.compose env40245 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40245 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40246 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,8202,16401,10280,1024,32769,58396,4194304,16,21622,8193,64,4250708,5221,45096,43049,61564,4256861,117,21589,46093,63068]

theorem envBound40246 : H12AffineFastState.Bounded env40246 := by
  intro p hp
  have h : env40246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40245_40246 : H12AffineEnvironment.transform 15 8202 env40245 = env40246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40245 == env40246) = true)

theorem identity40246 : scanCanonicalize (H12AffineFastState.compose env40246 (packedSelected [3,10,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound40246 : packedSelected [3,10,24,26] rootPS < 2^1333 := by decide +kernel

def env40247 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,29788,8202,16401,10280,1024,29789,4160,4194304,16,21622,8193,64,4204552,5221,17524,23669,1056,4194305,117,21589,16465,512]

theorem envBound40247 : H12AffineFastState.Bounded env40247 := by
  intro p hp
  have h : env40247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40246_40247 : H12AffineEnvironment.transform 14 29788 env40246 = env40247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env40246 == env40247) = true)

theorem identity40247 : scanCanonicalize (H12AffineFastState.compose env40247 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound40247 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40248 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,16384,28728,8202,16401,10280,100,28729,4160,4194304,16,20498,8193,64,4204552,4097,16400,22545,68,4194305,117,20529,16465,512]

theorem envBound40248 : H12AffineFastState.Bounded env40248 := by
  intro p hp
  have h : env40248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40247_40248 : H12AffineEnvironment.transform 9 100 env40247 = env40248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env40247 == env40248) = true)

theorem identity40248 : scanCanonicalize (H12AffineFastState.compose env40248 (packedSelected [2,4,6,9,11,14] rootPS)) = affineNative (2^(13+1) ^^^ 10249) := by decide +kernel

theorem selectedBound40248 : packedSelected [2,4,6,9,11,14] rootPS < 2^1333 := by decide +kernel

def env40249 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,8192,10249,6193,8202,10264,10280,100,6192,4160,4194304,16,14363,8193,64,4204552,4097,10265,12312,68,4194305,117,14392,10328,512]

theorem envBound40249 : H12AffineFastState.Bounded env40249 := by
  intro p hp
  have h : env40249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40248_40249 : H12AffineEnvironment.transform 13 10249 env40248 = env40249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10249 env40248 == env40249) = true)

theorem identity40249 : scanCanonicalize (H12AffineFastState.compose env40249 (packedSelected [1,2,3,6,15] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound40249 : packedSelected [1,2,3,6,15] rootPS < 2^1333 := by decide +kernel

def env40250 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,88,2129,6193,82,2112,2160,100,6192,4160,4194304,16,6211,89,64,4196432,4097,2113,4160,68,4194305,117,6240,2048,512]

theorem envBound40250 : H12AffineFastState.Bounded env40250 := by
  intro p hp
  have h : env40250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40249_40250 : H12AffineEnvironment.transform 12 88 env40249 = env40250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env40249 == env40250) = true)

theorem identity40250 : scanCanonicalize (H12AffineFastState.compose env40250 (packedSelected [1,3,4,5,6,8,9,11,12] rootPS)) = affineNative (2^(21+1) ^^^ 80) := by decide +kernel

theorem selectedBound40250 : packedSelected [1,3,4,5,6,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env40251 : List Nat := [2,4,8,16,32,64,9,117,512,100,2048,4096,88,2129,6193,82,2112,2160,100,6192,4160,80,16,6211,89,64,2048,4097,2113,4160,68,81,117,6240,2048,512]

theorem envBound40251 : H12AffineFastState.Bounded env40251 := by
  intro p hp
  have h : env40251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40250_40251 : H12AffineEnvironment.transform 21 80 env40250 = env40251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 80 env40250 == env40251) = true)

theorem identity40251 : scanCanonicalize (H12AffineFastState.compose env40251 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound40251 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env40252 : List Nat := [2,4,8,16,32,48,9,5,512,20,2048,4096,40,2081,6193,34,2096,2048,20,6192,4144,32,16,6195,41,48,2048,4097,2097,4144,52,33,5,6160,2048,512]

theorem envBound40252 : H12AffineFastState.Bounded env40252 := by
  intro p hp
  have h : env40252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40251_40252 : H12AffineEnvironment.transform 5 48 env40251 = env40252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env40251 == env40252) = true)

theorem identity40252 : scanCanonicalize (H12AffineFastState.compose env40252 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound40252 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40253 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,4096,8,2049,6161,2,2064,2048,20,6160,4112,0,16,6163,9,16,2048,4097,2065,4112,20,1,5,6160,2048,512]

theorem envBound40253 : H12AffineFastState.Bounded env40253 := by
  intro p hp
  have h : env40253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40252_40253 : H12AffineEnvironment.transform 4 0 env40252 = env40253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env40252 == env40253) = true)

theorem identity40253 : scanCanonicalize (H12AffineFastState.compose env40253 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound40253 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40254 : List Nat := [2,4,8,16,0,16,9,5,512,20,2048,2064,8,2049,1,2,2064,2048,20,0,2048,0,16,3,9,16,2048,2065,2065,2048,20,1,5,0,2048,512]

theorem envBound40254 : H12AffineFastState.Bounded env40254 := by
  intro p hp
  have h : env40254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40253_40254 : H12AffineEnvironment.transform 11 2064 env40253 = env40254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env40253 == env40254) = true)

theorem identity40254 : scanCanonicalize (H12AffineFastState.compose env40254 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40254 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40255 : List Nat := [2,4,8,16,0,16,9,5,1,20,2048,2064,8,2049,1,2,2064,2048,20,0,2048,0,16,3,9,16,2048,2065,2065,2048,20,1,5,0,2048,1]

theorem envBound40255 : H12AffineFastState.Bounded env40255 := by
  intro p hp
  have h : env40255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40254_40255 : H12AffineEnvironment.transform 8 1 env40254 = env40255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40254 == env40255) = true)

theorem identity40255 : scanCanonicalize (H12AffineFastState.compose env40255 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound40255 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40256 : List Nat := [2,4,8,4,0,4,9,5,1,0,2048,2052,8,2049,1,2,2052,2048,0,0,2048,0,4,3,9,4,2048,2053,2053,2048,0,1,5,0,2048,1]

theorem envBound40256 : H12AffineFastState.Bounded env40256 := by
  intro p hp
  have h : env40256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40255_40256 : H12AffineEnvironment.transform 3 4 env40255 = env40256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env40255 == env40256) = true)

def leafEnv40256 : List Nat := [2,4,8,4,0,4,9,5,1,0,2048,2052,8,2049,1,2,2052,2048,0,0,2048,0,4,3,0,9,1,4,2048,2053,2053,2048,0,1,5,0,4,3,2048,1,1,2049,0]

def active40256 : List Nat := [0,1,2,10]

def tree40256 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood40256 : H12WitnessSearch.Good tree40256 := H12GlobalWitnessIndex.good

theorem leafIdentity40256 : H12AffineFastState.composeSystem env40256 rootObs = leafEnv40256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env40256 rootObs == leafEnv40256) = true)

theorem terminalChecked40256 : H12PackedTerminal.terminalCheckFast leafEnv40256 active40256 tree40256 = true := by decide +kernel

def env40257 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1024,32769,115735,4194304,16,95357,8193,64,4250708,78959,102435,43048,61565,4314199,117,95327,103431,120407]

theorem envBound40257 : H12AffineFastState.Bounded env40257 := by
  intro p hp
  have h : env40257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40244_40257 : H12AffineEnvironment.transform 17 10281 env40244 = env40257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40244 == env40257) = true)

theorem identity40257 : scanCanonicalize (H12AffineFastState.compose env40257 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound40257 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40258 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54358,16401,10281,1024,32769,4161,4194304,16,41003,8193,64,4250708,57401,17525,43048,61565,4194305,117,40969,16465,513]

theorem envBound40258 : H12AffineFastState.Bounded env40258 := by
  intro p hp
  have h : env40258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40257_40258 : H12AffineEnvironment.transform 15 54358 env40257 = env40258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env40257 == env40258) = true)

theorem identity40258 : scanCanonicalize (H12AffineFastState.compose env40258 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound40258 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env40259 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54358,16401,10281,1024,32769,4161,8200,16,41003,8193,64,64604,57401,17525,43048,61565,8201,117,40969,16465,513]

theorem envBound40259 : H12AffineFastState.Bounded env40259 := by
  intro p hp
  have h : env40259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40258_40259 : H12AffineEnvironment.transform 21 8200 env40258 = env40259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env40258 == env40259) = true)

theorem identity40259 : scanCanonicalize (H12AffineFastState.compose env40259 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound40259 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env40260 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13404,32768,40970,13389,10281,1024,32769,4161,8200,16,41003,8193,64,34816,37989,12329,43048,33825,8201,117,40969,13325,513]

theorem envBound40260 : H12AffineFastState.Bounded env40260 := by
  intro p hp
  have h : env40260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40259_40260 : H12AffineEnvironment.transform 13 13404 env40259 = env40260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env40259 == env40260) = true)

theorem identity40260 : scanCanonicalize (H12AffineFastState.compose env40260 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40260 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40261 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13324,32768,40970,13341,10281,1024,32769,4113,8200,16,41003,8193,16,34816,37941,12329,43048,33825,8201,37,40969,13325,513]

theorem envBound40261 : H12AffineFastState.Bounded env40261 := by
  intro p hp
  have h : env40261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40260_40261 : H12AffineEnvironment.transform 5 16 env40260 = env40261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40260 == env40261) = true)

theorem identity40261 : scanCanonicalize (H12AffineFastState.compose env40261 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40261 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40262 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,32768,32802,5173,2049,1024,32769,4113,32,16,32771,41,16,34816,37941,4097,34816,33825,33,37,32801,5157,513]

theorem envBound40262 : H12AffineFastState.Bounded env40262 := by
  intro p hp
  have h : env40262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40261_40262 : H12AffineEnvironment.transform 12 40 env40261 = env40262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40261 == env40262) = true)

theorem identity40262 : scanCanonicalize (H12AffineFastState.compose env40262 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40262 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40263 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5156,1,35,5173,2049,1024,0,4113,32,16,2,41,16,2049,5172,4097,2049,1056,33,37,32,5157,513]

theorem envBound40263 : H12AffineFastState.Bounded env40263 := by
  intro p hp
  have h : env40263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40262_40263 : H12AffineEnvironment.transform 14 1 env40262 = env40263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40262 == env40263) = true)

theorem identity40263 : scanCanonicalize (H12AffineFastState.compose env40263 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound40263 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40264 : List Nat := [2,4,8,16,32,16,9,37,512,36,2048,4096,40,4096,1,35,4113,2049,36,0,4113,32,16,2,41,16,2049,4112,4097,2049,4,33,37,32,4097,513]

theorem envBound40264 : H12AffineFastState.Bounded env40264 := by
  intro p hp
  have h : env40264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40263_40264 : H12AffineEnvironment.transform 9 36 env40263 = env40264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env40263 == env40264) = true)

theorem identity40264 : scanCanonicalize (H12AffineFastState.compose env40264 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound40264 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40265 : List Nat := [2,4,8,16,32,16,9,37,512,36,2048,513,40,513,1,35,528,2049,36,0,528,32,16,2,41,16,2049,529,512,2049,4,33,37,32,512,513]

theorem envBound40265 : H12AffineFastState.Bounded env40265 := by
  intro p hp
  have h : env40265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40264_40265 : H12AffineEnvironment.transform 11 513 env40264 = env40265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env40264 == env40265) = true)

theorem identity40265 : scanCanonicalize (H12AffineFastState.compose env40265 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40265 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40266 : List Nat := [2,4,8,16,32,16,9,37,0,36,2048,1,40,1,1,35,16,2049,36,0,16,32,16,2,41,16,2049,17,0,2049,4,33,37,32,0,1]

theorem envBound40266 : H12AffineFastState.Bounded env40266 := by
  intro p hp
  have h : env40266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40265_40266 : H12AffineEnvironment.transform 8 0 env40265 = env40266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40265 == env40266) = true)

theorem identity40266 : scanCanonicalize (H12AffineFastState.compose env40266 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40266 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40267 : List Nat := [2,4,8,1,32,1,9,37,0,36,2048,1,40,1,1,35,1,2049,36,0,1,32,1,2,41,1,2049,0,0,2049,4,33,37,32,0,1]

theorem envBound40267 : H12AffineFastState.Bounded env40267 := by
  intro p hp
  have h : env40267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40266_40267 : H12AffineEnvironment.transform 3 1 env40266 = env40267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40266 == env40267) = true)

theorem identity40267 : scanCanonicalize (H12AffineFastState.compose env40267 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40267 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40268 : List Nat := [2,4,8,1,1,1,9,4,0,5,2048,1,9,1,1,2,1,2049,5,0,1,1,1,2,8,1,2049,0,0,2049,4,0,4,1,0,1]

theorem envBound40268 : H12AffineFastState.Bounded env40268 := by
  intro p hp
  have h : env40268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40267_40268 : H12AffineEnvironment.transform 4 1 env40267 = env40268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40267 == env40268) = true)

theorem identity40268 : scanCanonicalize (H12AffineFastState.compose env40268 (packedSelected [7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40268 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40269 : List Nat := [2,4,8,1,1,1,9,4,0,5,0,1,9,1,1,2,1,1,5,0,1,1,1,2,8,1,1,0,0,1,4,0,4,1,0,1]

theorem envBound40269 : H12AffineFastState.Bounded env40269 := by
  intro p hp
  have h : env40269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40268_40269 : H12AffineEnvironment.transform 10 0 env40268 = env40269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40268 == env40269) = true)

def env40270 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,388158,4194304,16,351317,8193,64,4250709,78958,374794,294913,317525,4314198,117,95326,103430,392831]

theorem envBound40270 : H12AffineFastState.Bounded env40270 := by
  intro p hp
  have h : env40270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40243_40270 : H12AffineEnvironment.transform 23 351317 env40243 = env40270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 351317 env40243 == env40270) = true)

theorem identity40270 : scanCanonicalize (H12AffineFastState.compose env40270 (packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 130174) := by decide +kernel

theorem selectedBound40270 : packedSelected [0,1,3,5,8,9,10,14,19,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40271 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16401,130174,1024,32769,4160,4194304,16,41003,8193,64,4250709,78958,17524,97407,74795,4314198,117,95326,103430,513]

theorem envBound40271 : H12AffineFastState.Bounded env40271 := by
  intro p hp
  have h : env40271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40270_40271 : H12AffineEnvironment.transform 17 130174 env40270 = env40271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130174 env40270 == env40271) = true)

theorem identity40271 : scanCanonicalize (H12AffineFastState.compose env40271 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound40271 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env40272 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54359,16401,10281,1024,32769,4160,4194304,16,41003,8193,64,4250709,57401,17524,43048,61564,4194305,117,40969,16465,513]

theorem envBound40272 : H12AffineFastState.Bounded env40272 := by
  intro p hp
  have h : env40272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40271_40272 : H12AffineEnvironment.transform 15 54359 env40271 = env40272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env40271 == env40272) = true)

theorem identity40272 : scanCanonicalize (H12AffineFastState.compose env40272 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 8200) := by decide +kernel

theorem selectedBound40272 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env40273 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,54359,16401,10281,1024,32769,4160,8200,16,41003,8193,64,64605,57401,17524,43048,61564,8201,117,40969,16465,513]

theorem envBound40273 : H12AffineFastState.Bounded env40273 := by
  intro p hp
  have h : env40273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40272_40273 : H12AffineEnvironment.transform 21 8200 env40272 = env40273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8200 env40272 == env40273) = true)

theorem identity40273 : scanCanonicalize (H12AffineFastState.compose env40273 (packedSelected [1,3,4,5,8,9,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound40273 : packedSelected [1,3,4,5,8,9,15,18] rootPS < 2^1333 := by decide +kernel

def env40274 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,13405,32768,40970,13388,10281,1024,32769,4160,8200,16,41003,8193,64,34816,37988,12329,43048,33825,8201,117,40969,13324,513]

theorem envBound40274 : H12AffineFastState.Bounded env40274 := by
  intro p hp
  have h : env40274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40273_40274 : H12AffineEnvironment.transform 13 13405 env40273 = env40274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env40273 == env40274) = true)

theorem identity40274 : scanCanonicalize (H12AffineFastState.compose env40274 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40274 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env40275 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,32768,40970,13340,10281,1024,32769,4112,8200,16,41003,8193,16,34816,37940,12329,43048,33825,8201,37,40969,13324,513]

theorem envBound40275 : H12AffineFastState.Bounded env40275 := by
  intro p hp
  have h : env40275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40274_40275 : H12AffineEnvironment.transform 5 16 env40274 = env40275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40274 == env40275) = true)

theorem identity40275 : scanCanonicalize (H12AffineFastState.compose env40275 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound40275 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40276 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,32768,32802,5172,2049,1024,32769,4112,32,16,32771,41,16,34816,37940,4097,34816,33825,33,37,32801,5156,513]

theorem envBound40276 : H12AffineFastState.Bounded env40276 := by
  intro p hp
  have h : env40276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40275_40276 : H12AffineEnvironment.transform 12 40 env40275 = env40276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env40275 == env40276) = true)

theorem identity40276 : scanCanonicalize (H12AffineFastState.compose env40276 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40276 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40277 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,40,5157,1,35,5172,2049,1024,0,4112,32,16,2,41,16,2049,5173,4097,2049,1056,33,37,32,5156,513]

theorem envBound40277 : H12AffineFastState.Bounded env40277 := by
  intro p hp
  have h : env40277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40276_40277 : H12AffineEnvironment.transform 14 1 env40276 = env40277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40276 == env40277) = true)

theorem identity40277 : scanCanonicalize (H12AffineFastState.compose env40277 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound40277 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40278 : List Nat := [2,4,8,16,32,16,9,37,512,37,2048,4096,40,4096,1,35,4113,2049,37,0,4112,32,16,2,41,16,2049,4112,4097,2049,5,33,37,32,4097,513]

theorem envBound40278 : H12AffineFastState.Bounded env40278 := by
  intro p hp
  have h : env40278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40277_40278 : H12AffineEnvironment.transform 9 37 env40277 = env40278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env40277 == env40278) = true)

theorem identity40278 : scanCanonicalize (H12AffineFastState.compose env40278 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound40278 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40279 : List Nat := [2,4,8,16,32,16,9,37,512,37,2048,513,40,513,1,35,528,2049,37,0,529,32,16,2,41,16,2049,529,512,2049,5,33,37,32,512,513]

theorem envBound40279 : H12AffineFastState.Bounded env40279 := by
  intro p hp
  have h : env40279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40278_40279 : H12AffineEnvironment.transform 11 513 env40278 = env40279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env40278 == env40279) = true)

theorem identity40279 : scanCanonicalize (H12AffineFastState.compose env40279 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound40279 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40280 : List Nat := [2,4,8,16,32,16,9,37,1,37,2048,0,40,0,1,35,17,2049,37,0,16,32,16,2,41,16,2049,16,1,2049,5,33,37,32,1,0]

theorem envBound40280 : H12AffineFastState.Bounded env40280 := by
  intro p hp
  have h : env40280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40279_40280 : H12AffineEnvironment.transform 8 1 env40279 = env40280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env40279 == env40280) = true)

theorem identity40280 : scanCanonicalize (H12AffineFastState.compose env40280 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40280 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40281 : List Nat := [2,4,8,1,32,1,9,37,1,37,2048,0,40,0,1,35,0,2049,37,0,1,32,1,2,41,1,2049,1,1,2049,5,33,37,32,1,0]

theorem envBound40281 : H12AffineFastState.Bounded env40281 := by
  intro p hp
  have h : env40281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40280_40281 : H12AffineEnvironment.transform 3 1 env40280 = env40281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40280 == env40281) = true)

theorem identity40281 : scanCanonicalize (H12AffineFastState.compose env40281 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40281 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40282 : List Nat := [2,4,8,1,1,1,9,4,1,4,2048,0,9,0,1,2,0,2049,4,0,1,1,1,2,8,1,2049,1,1,2049,5,0,4,1,1,0]

theorem envBound40282 : H12AffineFastState.Bounded env40282 := by
  intro p hp
  have h : env40282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40281_40282 : H12AffineEnvironment.transform 4 1 env40281 = env40282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40281 == env40282) = true)

theorem identity40282 : scanCanonicalize (H12AffineFastState.compose env40282 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound40282 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40283 : List Nat := [2,4,8,1,1,1,9,4,1,4,1,0,9,0,1,2,0,0,4,0,1,1,1,2,8,1,0,1,1,0,5,0,4,1,1,0]

theorem envBound40283 : H12AffineFastState.Bounded env40283 := by
  intro p hp
  have h : env40283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40282_40283 : H12AffineEnvironment.transform 10 1 env40282 = env40283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env40282 == env40283) = true)

def env40284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507601,8830977,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound40284 : H12AffineFastState.Bounded env40284 := by
  intro p hp
  have h : env40284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40117_40284 : H12AffineEnvironment.transform 18 1025 env40117 = env40284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env40117 == env40284) = true)

theorem identity40284 : scanCanonicalize (H12AffineFastState.compose env40284 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 254097) := by decide +kernel

theorem selectedBound40284 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env40285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,254097,8328,64,12853393,2253852,10507601,8830977,8545409,6456656,257,10626108,10667417,8602454]

theorem envBound40285 : H12AffineFastState.Bounded env40285 := by
  intro p hp
  have h : env40285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40284_40285 : H12AffineEnvironment.transform 23 254097 env40284 = env40285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 254097 env40284 == env40285) = true)

def env40286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257180,254097,8328,64,6705549,2253852,140365,2404637,2102685,6456656,257,21792,46213,2175562]

theorem envBound40286 : H12AffineFastState.Bounded env40286 := by
  intro p hp
  have h : env40286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40285_40286 : H12AffineEnvironment.transform 22 2257180 env40285 = env40286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257180 env40285 == env40286) = true)

def env40287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441624,2257180,254097,8328,64,2157717,2253852,140365,2404637,2102685,2373704,257,21792,46213,2175562]

theorem envBound40287 : H12AffineFastState.Bounded env40287 := by
  intro p hp
  have h : env40287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40286_40287 : H12AffineEnvironment.transform 21 441624 env40286 = env40287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441624 env40286 == env40287) = true)

def env40288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441624,155996,254097,8328,64,64725,160860,140365,303453,1501,272392,257,21792,46213,74250]

theorem envBound40288 : H12AffineFastState.Bounded env40288 := by
  intro p hp
  have h : env40288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40287_40288 : H12AffineEnvironment.transform 20 4160 env40287 = env40288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env40287 == env40288) = true)

theorem identity40288 : scanCanonicalize (H12AffineFastState.compose env40288 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound40288 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,4160,329867,120015,21762,8328,64,64725,115151,102878,303453,1501,272392,257,21792,46213,74250]

theorem envBound40289 : H12AffineFastState.Bounded env40289 := by
  intro p hp
  have h : env40289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40288_40289 : H12AffineEnvironment.transform 16 112019 env40288 = env40289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env40288 == env40289) = true)

def env40290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10400,1025,32769,4160,73771,120015,21762,8328,64,64725,115151,102878,35325,1501,168,257,21792,46213,74250]

theorem envBound40290 : H12AffineFastState.Bounded env40290 := by
  intro p hp
  have h : env40290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40289_40290 : H12AffineEnvironment.transform 17 10400 env40289 = env40290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env40289 == env40290) = true)

theorem identity40290 : scanCanonicalize (H12AffineFastState.compose env40290 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound40290 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40291 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4160,73771,119879,21762,8192,64,64605,115015,102742,35189,1365,32,257,21792,46093,74250]

theorem envBound40291 : H12AffineFastState.Bounded env40291 := by
  intro p hp
  have h : env40291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40290_40291 : H12AffineEnvironment.transform 6 8 env40290 = env40291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40290 == env40291) = true)

theorem identity40291 : scanCanonicalize (H12AffineFastState.compose env40291 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound40291 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env40292 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,24908,10280,1025,32769,4160,62588,16,21762,8192,64,64605,5392,17665,35189,1365,32,257,21792,46093,63069]

theorem envBound40292 : H12AffineFastState.Bounded env40292 := by
  intro p hp
  have h : env40292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40291_40292 : H12AffineEnvironment.transform 15 54359 env40291 = env40292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env40291 == env40292) = true)

theorem identity40292 : scanCanonicalize (H12AffineFastState.compose env40292 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound40292 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40293 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,32768,42267,4096,10280,1025,32769,4160,34096,16,9294,8192,64,36113,5392,13389,35189,1365,32,257,9324,46093,34577]

theorem envBound40293 : H12AffineFastState.Bounded env40293 := by
  intro p hp
  have h : env40293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40292_40293 : H12AffineEnvironment.transform 13 12620 env40292 = env40293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env40292 == env40293) = true)

theorem identity40293 : scanCanonicalize (H12AffineFastState.compose env40293 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40293 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env40294 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,32768,33862,4096,2421,1025,32769,4160,34096,16,1299,349,64,36113,5392,5392,35189,1365,32,257,1329,38224,34577]

theorem envBound40294 : H12AffineFastState.Bounded env40294 := by
  intro p hp
  have h : env40294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40293_40294 : H12AffineEnvironment.transform 12 349 env40293 = env40294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40293 == env40294) = true)

theorem identity40294 : scanCanonicalize (H12AffineFastState.compose env40294 (packedSelected [1,8,11,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 1077) := by decide +kernel

theorem selectedBound40294 : packedSelected [1,8,11,18,19] rootPS < 2^1333 := by decide +kernel

def env40295 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1077,115,4096,2421,1025,1076,4160,261,16,1299,349,64,2340,5392,5392,3392,1365,32,257,1329,4453,804]

theorem envBound40295 : H12AffineFastState.Bounded env40295 := by
  intro p hp
  have h : env40295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40294_40295 : H12AffineEnvironment.transform 14 1077 env40294 = env40295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1077 env40294 == env40295) = true)

theorem identity40295 : scanCanonicalize (H12AffineFastState.compose env40295 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound40295 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env40296 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,349,4113,292,115,4096,2421,272,293,4160,261,16,2,349,64,2340,4097,4097,2129,68,32,257,32,4453,804]

theorem envBound40296 : H12AffineFastState.Bounded env40296 := by
  intro p hp
  have h : env40296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40295_40296 : H12AffineEnvironment.transform 9 273 env40295 = env40296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env40295 == env40296) = true)

theorem identity40296 : scanCanonicalize (H12AffineFastState.compose env40296 (packedSelected [0,2,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound40296 : packedSelected [0,2,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env40297 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,4096,349,4113,292,115,4096,373,272,293,4160,261,16,2,349,64,292,4097,4097,81,68,32,257,32,4453,804]

theorem envBound40297 : H12AffineFastState.Bounded env40297 := by
  intro p hp
  have h : env40297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40296_40297 : H12AffineEnvironment.transform 10 0 env40296 = env40297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env40296 == env40297) = true)

theorem identity40297 : scanCanonicalize (H12AffineFastState.compose env40297 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound40297 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env40298 : List Nat := [2,4,8,16,32,64,8,256,512,273,0,65,349,80,292,115,65,373,272,293,1,261,16,2,349,64,292,64,64,81,68,32,257,32,292,804]

theorem envBound40298 : H12AffineFastState.Bounded env40298 := by
  intro p hp
  have h : env40298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40297_40298 : H12AffineEnvironment.transform 11 65 env40297 = env40298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env40297 == env40298) = true)

theorem identity40298 : scanCanonicalize (H12AffineFastState.compose env40298 (packedSelected [2,4,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound40298 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env40299 : List Nat := [2,4,8,16,32,64,8,117,512,100,0,65,40,80,81,115,65,0,101,80,1,112,16,2,40,64,81,64,64,81,68,32,116,32,81,593]

theorem envBound40299 : H12AffineFastState.Bounded env40299 := by
  intro p hp
  have h : env40299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40298_40299 : H12AffineEnvironment.transform 7 117 env40298 = env40299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env40298 == env40299) = true)

theorem identity40299 : scanCanonicalize (H12AffineFastState.compose env40299 (packedSelected [1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound40299 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env40300 : List Nat := [2,4,8,16,32,64,8,117,80,100,0,65,40,80,81,115,65,0,101,80,1,112,16,2,40,64,81,64,64,81,68,32,116,32,81,1]

theorem envBound40300 : H12AffineFastState.Bounded env40300 := by
  intro p hp
  have h : env40300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40299_40300 : H12AffineEnvironment.transform 8 80 env40299 = env40300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env40299 == env40300) = true)

theorem identity40300 : scanCanonicalize (H12AffineFastState.compose env40300 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound40300 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env40301 : List Nat := [2,4,8,16,32,17,8,36,1,53,0,16,40,1,0,34,16,0,52,1,1,33,16,2,40,17,0,17,17,0,21,32,37,32,0,1]

theorem envBound40301 : H12AffineFastState.Bounded env40301 := by
  intro p hp
  have h : env40301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40300_40301 : H12AffineEnvironment.transform 5 17 env40300 = env40301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env40300 == env40301) = true)

theorem identity40301 : scanCanonicalize (H12AffineFastState.compose env40301 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound40301 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40302 : List Nat := [2,4,8,16,30,17,8,26,1,11,0,16,22,1,0,28,16,0,10,1,1,31,16,2,22,17,0,17,17,0,21,30,27,30,0,1]

theorem envBound40302 : H12AffineFastState.Bounded env40302 := by
  intro p hp
  have h : env40302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40301_40302 : H12AffineEnvironment.transform 4 30 env40301 = env40302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env40301 == env40302) = true)

theorem identity40302 : scanCanonicalize (H12AffineFastState.compose env40302 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound40302 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40303 : List Nat := [2,4,7,16,17,17,7,21,1,4,0,16,22,1,0,19,16,0,5,1,1,16,16,2,22,17,0,17,17,0,21,17,20,17,0,1]

theorem envBound40303 : H12AffineFastState.Bounded env40303 := by
  intro p hp
  have h : env40303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40302_40303 : H12AffineEnvironment.transform 2 7 env40302 = env40303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env40302 == env40303) = true)

theorem identity40303 : scanCanonicalize (H12AffineFastState.compose env40303 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40303 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env40304 : List Nat := [2,4,7,1,0,0,7,4,1,4,0,1,7,1,0,2,1,0,5,1,1,1,1,2,7,0,0,0,0,0,4,0,5,0,0,1]

theorem envBound40304 : H12AffineFastState.Bounded env40304 := by
  intro p hp
  have h : env40304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40303_40304 : H12AffineEnvironment.transform 3 1 env40303 = env40304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40303 == env40304) = true)

def env40305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,10401,1025,32769,4160,73770,120015,21762,8328,64,64725,115151,102878,35324,1501,169,257,21792,46213,74250]

theorem envBound40305 : H12AffineFastState.Bounded env40305 := by
  intro p hp
  have h : env40305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40289_40305 : H12AffineEnvironment.transform 17 10401 env40289 = env40305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env40289 == env40305) = true)

theorem identity40305 : scanCanonicalize (H12AffineFastState.compose env40305 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62731) := by decide +kernel

theorem selectedBound40305 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env40306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62731,16536,10401,1025,32769,4160,54561,8644,21762,8328,64,64725,13508,25813,35324,1501,169,257,21792,46213,55041]

theorem envBound40306 : H12AffineFastState.Bounded env40306 := by
  intro p hp
  have h : env40306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40305_40306 : H12AffineEnvironment.transform 15 62731 env40305 = env40306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62731 env40305 == env40306) = true)

theorem identity40306 : scanCanonicalize (H12AffineFastState.compose env40306 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound40306 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env40307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16536,10401,1025,21761,4160,33,8644,21762,8328,64,10709,13508,25813,23804,1501,169,257,21792,24965,513]

theorem envBound40307 : H12AffineFastState.Bounded env40307 := by
  intro p hp
  have h : env40307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40306_40307 : H12AffineEnvironment.transform 14 21760 env40306 = env40307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env40306 == env40307) = true)

theorem identity40307 : scanCanonicalize (H12AffineFastState.compose env40307 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound40307 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env40308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,81,8203,5577,10401,1025,80,4160,33,8644,83,8328,64,10709,13508,12676,2477,1501,169,257,113,13524,513]

theorem envBound40308 : H12AffineFastState.Bounded env40308 := by
  intro p hp
  have h : env40308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40307_40308 : H12AffineEnvironment.transform 13 5457 env40307 = env40308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env40307 == env40308) = true)

theorem identity40308 : scanCanonicalize (H12AffineFastState.compose env40308 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound40308 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,388,5457,81,399,5577,2341,1025,80,4160,33,64,83,268,64,2129,5440,4096,2477,1501,169,257,113,5456,513]

theorem envBound40309 : H12AffineFastState.Bounded env40309 := by
  intro p hp
  have h : env40309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40308_40309 : H12AffineEnvironment.transform 12 388 env40308 = env40309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env40308 == env40309) = true)

theorem identity40309 : scanCanonicalize (H12AffineFastState.compose env40309 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40309 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env40310 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5457,81,262,5440,2341,1025,80,4160,33,64,83,268,64,2129,5440,4096,2340,1364,32,257,113,5456,513]

theorem envBound40310 : H12AffineFastState.Bounded env40310 := by
  intro p hp
  have h : env40310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40309_40310 : H12AffineEnvironment.transform 6 9 env40309 = env40310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40309 == env40310) = true)

theorem identity40310 : scanCanonicalize (H12AffineFastState.compose env40310 (packedSelected [0,1,2,4,7,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound40310 : packedSelected [0,1,2,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env40311 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2356,269,3173,81,262,3188,2341,1025,80,2420,33,64,83,268,64,2129,3188,2356,2340,1364,32,257,113,3172,513]

theorem envBound40311 : H12AffineFastState.Bounded env40311 := by
  intro p hp
  have h : env40311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40310_40311 : H12AffineEnvironment.transform 11 2356 env40310 = env40311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env40310 == env40311) = true)

theorem identity40311 : scanCanonicalize (H12AffineFastState.compose env40311 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40311 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env40312 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2356,269,3125,1,262,3108,2341,1025,0,2340,33,16,3,268,16,2049,3108,2356,2340,1284,32,257,33,3124,513]

theorem envBound40312 : H12AffineFastState.Bounded env40312 := by
  intro p hp
  have h : env40312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40311_40312 : H12AffineEnvironment.transform 5 16 env40311 = env40312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40311 == env40312) = true)

theorem identity40312 : scanCanonicalize (H12AffineFastState.compose env40312 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40312 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40313 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,2356,269,2341,1,262,2356,2341,273,0,2340,33,16,3,268,16,2049,2356,2356,2340,20,32,257,33,2340,513]

theorem envBound40313 : H12AffineFastState.Bounded env40313 := by
  intro p hp
  have h : env40313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40312_40313 : H12AffineEnvironment.transform 9 272 env40312 = env40313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40312 == env40313) = true)

def env40314 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441624,155997,254097,8328,64,64724,160861,140365,303452,1500,272393,257,21792,46213,74251]

theorem envBound40314 : H12AffineFastState.Bounded env40314 := by
  intro p hp
  have h : env40314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40287_40314 : H12AffineEnvironment.transform 20 4161 env40287 = env40314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env40287 == env40314) = true)

theorem identity40314 : scanCanonicalize (H12AffineFastState.compose env40314 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound40314 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40315 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,4161,441624,155997,180379,8328,64,64724,160861,140365,303452,1500,272393,257,21792,46213,513]

theorem envBound40315 : H12AffineFastState.Bounded env40315 := by
  intro p hp
  have h : env40315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40314_40315 : H12AffineEnvironment.transform 15 8202 env40314 = env40315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env40314 == env40315) = true)

def env40316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,326920,8525,32907,8328,64,64724,13389,25693,303452,1500,272393,257,21792,46213,513]

theorem envBound40316 : H12AffineFastState.Bounded env40316 := by
  intro p hp
  have h : env40316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40315_40316 : H12AffineEnvironment.transform 16 16400 env40315 = env40316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env40315 == env40316) = true)

def env40317 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,326920,8525,32771,8192,64,64604,13389,25693,303452,1364,272393,257,21792,46093,513]

theorem envBound40317 : H12AffineFastState.Bounded env40317 := by
  intro p hp
  have h : env40317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40316_40317 : H12AffineEnvironment.transform 6 8 env40316 = env40317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40316 == env40317) = true)

def env40318 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,262144,1025,32769,4161,326920,8525,32770,8193,64,64605,13389,25693,303452,1365,272393,257,21792,46092,513]

theorem envBound40318 : H12AffineFastState.Bounded env40318 := by
  intro p hp
  have h : env40318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40316_40318 : H12AffineEnvironment.transform 6 9 env40316 = env40318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40316 == env40318) = true)

theorem identity40318 : scanCanonicalize (H12AffineFastState.compose env40318 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound40318 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env40319 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,12621,32768,8202,12637,262144,1025,32769,4161,298053,8525,32770,8193,64,36112,13389,5392,303452,1365,272393,257,9325,46092,513]

theorem envBound40319 : H12AffineFastState.Bounded env40319 := by
  intro p hp
  have h : env40319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40318_40319 : H12AffineEnvironment.transform 13 12621 env40318 = env40319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env40318 == env40319) = true)

end H12CloudChart1