import H12CloudChart1Data156

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env39812 : List Nat := [2,4,8,16,32,64,8,256,80,1024,2048,4096,348,5376,0,342,5392,2421,1024,1,4161,33,16,3,348,64,2049,5392,4096,2420,1365,33,256,33,5456,81]

theorem envBound39812 : H12AffineFastState.Bounded env39812 := by
  intro p hp
  have h : env39812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39811_39812 : H12AffineEnvironment.transform 8 80 env39811 = env39812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env39811 == env39812) = true)

theorem identity39812 : scanCanonicalize (H12AffineFastState.compose env39812 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound39812 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39813 : List Nat := [2,4,8,16,32,64,8,256,80,1024,2048,1297,348,17,0,342,1,2421,1024,1,1360,33,16,3,348,64,2049,1,1297,2420,1365,33,256,33,65,81]

theorem envBound39813 : H12AffineFastState.Bounded env39813 := by
  intro p hp
  have h : env39813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39812_39813 : H12AffineEnvironment.transform 11 1297 env39812 = env39813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env39812 == env39813) = true)

theorem identity39813 : scanCanonicalize (H12AffineFastState.compose env39813 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound39813 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env39814 : List Nat := [2,4,8,16,32,64,8,84,80,1024,2048,1093,8,17,0,2,1,2081,1024,1,1028,33,16,3,8,64,2049,1,1093,2080,1025,33,84,33,65,81]

theorem envBound39814 : H12AffineFastState.Bounded env39814 := by
  intro p hp
  have h : env39814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39813_39814 : H12AffineEnvironment.transform 7 84 env39813 = env39814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env39813 == env39814) = true)

def env39815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,131072,262144,1024,8540,4160,4194304,16,138,8328,64,4592845,5392,4096,406605,1500,4194304,256,32,5593,513]

theorem envBound39815 : H12AffineFastState.Bounded env39815 := by
  intro p hp
  have h : env39815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39805_39815 : H12AffineEnvironment.transform 13 5377 env39805 = env39815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39805 == env39815) = true)

theorem identity39815 : scanCanonicalize (H12AffineFastState.compose env39815 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10481) := by decide +kernel

theorem selectedBound39815 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10481,1024,8540,4160,4194304,16,138,8328,64,4340796,5392,4096,138428,1500,4194304,256,32,5593,513]

theorem envBound39816 : H12AffineFastState.Bounded env39816 := by
  intro p hp
  have h : env39816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39815_39816 : H12AffineEnvironment.transform 17 10481 env39815 = env39816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10481 env39815 == env39816) = true)

theorem identity39816 : scanCanonicalize (H12AffineFastState.compose env39816 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound39816 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env39817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,131072,10481,1024,8540,4160,33,16,138,8328,64,146461,5392,4096,138428,1500,33,256,32,5593,513]

theorem envBound39817 : H12AffineFastState.Bounded env39817 := by
  intro p hp
  have h : env39817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39816_39817 : H12AffineEnvironment.transform 21 33 env39816 = env39817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39816 == env39817) = true)

theorem identity39817 : scanCanonicalize (H12AffineFastState.compose env39817 (packedSelected [1,3,15,18,23,24,28,38] rootPS)) = affineNative (2^(16+1) ^^^ 13461) := by decide +kernel

theorem selectedBound39817 : packedSelected [1,3,15,18,23,24,28,38] rootPS < 2^1333 := by decide +kernel

def env39818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8541,8203,13461,10481,1024,8540,4160,33,16,138,8328,64,2184,5392,4096,10281,1500,33,256,32,5593,513]

theorem envBound39818 : H12AffineFastState.Bounded env39818 := by
  intro p hp
  have h : env39818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39817_39818 : H12AffineEnvironment.transform 16 13461 env39817 = env39818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13461 env39817 == env39818) = true)

theorem identity39818 : scanCanonicalize (H12AffineFastState.compose env39818 (packedSelected [18,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39818 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env39819 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8461,8203,13461,10401,1024,8460,4112,33,16,138,8328,16,2184,5392,4096,10281,1420,33,256,32,5513,513]

theorem envBound39819 : H12AffineFastState.Bounded env39819 := by
  intro p hp
  have h : env39819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39818_39819 : H12AffineEnvironment.transform 5 16 env39818 = env39819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39818 == env39819) = true)

theorem identity39819 : scanCanonicalize (H12AffineFastState.compose env39819 (packedSelected [0,2,3,5,7,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39819 : packedSelected [0,2,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env39820 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,0,262,5528,2476,1024,1,4112,33,16,138,389,16,2184,5392,4096,2340,1420,33,256,32,5513,513]

theorem envBound39820 : H12AffineFastState.Bounded env39820 := by
  intro p hp
  have h : env39820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39819_39820 : H12AffineEnvironment.transform 12 269 env39819 = env39820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39819 == env39820) = true)

theorem identity39820 : scanCanonicalize (H12AffineFastState.compose env39820 (packedSelected [1,2,4,7,8,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39820 : packedSelected [1,2,4,7,8,11] rootPS < 2^1333 := by decide +kernel

def env39821 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5156,0,35,5309,2185,1024,1,4112,33,16,138,160,16,2184,5173,4096,2049,1193,33,37,32,5292,513]

theorem envBound39821 : H12AffineFastState.Bounded env39821 := by
  intro p hp
  have h : env39821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39820_39821 : H12AffineEnvironment.transform 7 37 env39820 = env39821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39820 == env39821) = true)

theorem identity39821 : scanCanonicalize (H12AffineFastState.compose env39821 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39821 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env39822 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,35,5173,2049,1024,1,4112,33,16,2,40,16,2048,5173,4096,2049,1057,33,37,32,5156,513]

theorem envBound39822 : H12AffineFastState.Bounded env39822 := by
  intro p hp
  have h : env39822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39821_39822 : H12AffineEnvironment.transform 6 8 env39821 = env39822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39821 == env39822) = true)

def env39823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,8388608,10577360,8328,64,6705549,8393985,10507601,8795228,2102685,12582928,256,21792,16600,2175563]

theorem envBound39823 : H12AffineFastState.Bounded env39823 := by
  intro p hp
  have h : env39823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39731_39823 : H12AffineEnvironment.transform 14 29789 env39731 = env39823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env39731 == env39823) = true)

def env39824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114896,73856,8328,64,6705549,2117713,4097,2519308,2102685,6309184,256,21792,16600,2175563]

theorem envBound39824 : H12AffineFastState.Bounded env39824 := by
  intro p hp
  have h : env39824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39823_39824 : H12AffineEnvironment.transform 22 2114896 env39823 = env39824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114896 env39823 == env39824) = true)

def env39825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,16,73856,8328,64,4592845,5393,4097,406604,20701,4194304,256,21792,16600,96011]

theorem envBound39825 : H12AffineFastState.Bounded env39825 := by
  intro p hp
  have h : env39825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39824_39825 : H12AffineEnvironment.transform 20 17728 env39824 = env39825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env39824 == env39825) = true)

theorem identity39825 : scanCanonicalize (H12AffineFastState.compose env39825 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39825 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39826 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,16,73736,8192,64,4592709,5393,4097,406604,20565,4194304,256,21792,16464,96011]

theorem envBound39826 : H12AffineFastState.Bounded env39826 := by
  intro p hp
  have h : env39826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39825_39826 : H12AffineEnvironment.transform 6 8 env39825 = env39826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39825 == env39826) = true)

def env39827 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,16400,262144,1024,29788,17728,4194304,16,73736,8192,64,4478037,5393,4097,291932,20565,4194304,256,21792,16464,96011]

theorem envBound39827 : H12AffineFastState.Bounded env39827 := by
  intro p hp
  have h : env39827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39826_39827 : H12AffineEnvironment.transform 16 16400 env39826 = env39827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39826 == env39827) = true)

def env39828 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,65536,16400,262144,1024,29708,17680,4194304,16,73736,8192,16,4477957,5393,4097,291852,20485,4194304,256,21792,16384,96011]

theorem envBound39828 : H12AffineFastState.Bounded env39828 := by
  intro p hp
  have h : env39828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39827_39828 : H12AffineEnvironment.transform 5 16 env39827 = env39828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39827 == env39828) = true)

theorem identity39828 : scanCanonicalize (H12AffineFastState.compose env39828 (packedSelected [0,4,7,14,16,20,22,35] rootPS)) = affineNative (2^(21+1) ^^^ 294153) := by decide +kernel

theorem selectedBound39828 : packedSelected [0,4,7,14,16,20,22,35] rootPS < 2^1333 := by decide +kernel

def env39829 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,65536,16400,262144,1024,29708,17680,294153,16,73736,8192,16,10508,5393,4097,291852,20485,294153,256,21792,16384,96011]

theorem envBound39829 : H12AffineFastState.Bounded env39829 := by
  intro p hp
  have h : env39829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39828_39829 : H12AffineEnvironment.transform 21 294153 env39828 = env39829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 294153 env39828 == env39829) = true)

theorem identity39829 : scanCanonicalize (H12AffineFastState.compose env39829 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound39829 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39830 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,35,16400,262144,1024,29708,17680,294153,16,8235,8192,16,10508,5393,4097,291852,20485,294153,256,21792,16384,30504]

theorem envBound39830 : H12AffineFastState.Bounded env39830 := by
  intro p hp
  have h : env39830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39829_39830 : H12AffineEnvironment.transform 15 35 env39829 = env39830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env39829 == env39830) = true)

theorem identity39830 : scanCanonicalize (H12AffineFastState.compose env39830 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(17+1) ^^^ 31756) := by decide +kernel

theorem selectedBound39830 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env39831 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29709,35,16400,31756,1024,29708,17680,261,16,8235,8192,16,10508,5393,4097,2048,20485,261,256,21792,16384,30504]

theorem envBound39831 : H12AffineFastState.Bounded env39831 := by
  intro p hp
  have h : env39831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39830_39831 : H12AffineEnvironment.transform 17 31756 env39830 = env39831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 31756 env39830 == env39831) = true)

theorem identity39831 : scanCanonicalize (H12AffineFastState.compose env39831 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound39831 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env39832 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13325,0,35,13341,2049,1024,1,12573,261,16,8235,8192,16,10508,5393,4097,2048,9224,261,256,8493,13325,805]

theorem envBound39832 : H12AffineFastState.Bounded env39832 := by
  intro p hp
  have h : env39832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39831_39832 : H12AffineEnvironment.transform 13 13325 env39831 = env39832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env39831 == env39832) = true)

def env39833 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,16400,262144,1024,29709,17681,4194304,16,73736,8192,17,4477956,5393,4097,291853,20484,4194304,256,21792,16385,96011]

theorem envBound39833 : H12AffineFastState.Bounded env39833 := by
  intro p hp
  have h : env39833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39827_39833 : H12AffineEnvironment.transform 5 17 env39827 = env39833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39827 == env39833) = true)

theorem identity39833 : scanCanonicalize (H12AffineFastState.compose env39833 (packedSelected [0,4,7,14,16,20,22,35] rootPS)) = affineNative (2^(21+1) ^^^ 351491) := by decide +kernel

theorem selectedBound39833 : packedSelected [0,4,7,14,16,20,22,35] rootPS < 2^1333 := by decide +kernel

def env39834 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,16400,262144,1024,29709,17681,351491,16,73736,8192,17,67847,5393,4097,291853,20484,351491,256,21792,16385,96011]

theorem envBound39834 : H12AffineFastState.Bounded env39834 := by
  intro p hp
  have h : env39834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39833_39834 : H12AffineEnvironment.transform 21 351491 env39833 = env39834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 351491 env39833 == env39834) = true)

theorem identity39834 : scanCanonicalize (H12AffineFastState.compose env39834 (packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound39834 : packedSelected [0,5,7,9,12,14,15,16,19,22,24] rootPS < 2^1333 := by decide +kernel

def env39835 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,65536,16400,89378,1024,29709,17681,33,16,73736,8192,17,67847,5393,4097,76079,20484,33,256,21792,16385,96011]

theorem envBound39835 : H12AffineFastState.Bounded env39835 := by
  intro p hp
  have h : env39835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39834_39835 : H12AffineEnvironment.transform 17 89378 env39834 = env39835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env39834 == env39835) = true)

theorem identity39835 : scanCanonicalize (H12AffineFastState.compose env39835 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound39835 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env39836 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,29708,35,16400,23809,1024,29709,17681,33,16,8235,8192,17,2340,5393,4097,10508,20484,33,256,21792,16385,30504]

theorem envBound39836 : H12AffineFastState.Bounded env39836 := by
  intro p hp
  have h : env39836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39835_39836 : H12AffineEnvironment.transform 15 35 env39835 = env39836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env39835 == env39836) = true)

theorem identity39836 : scanCanonicalize (H12AffineFastState.compose env39836 (packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS)) = affineNative (2^(11+1) ^^^ 2356) := by decide +kernel

theorem selectedBound39836 : packedSelected [0,1,3,4,5,7,8,9,11,12,16] rootPS < 2^1333 := by decide +kernel

def env39837 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2356,8192,16384,27960,35,16400,17461,1024,27961,17681,33,16,8235,8192,17,2340,3109,2357,10508,18736,33,256,19476,16385,28188]

theorem envBound39837 : H12AffineFastState.Bounded env39837 := by
  intro p hp
  have h : env39837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39836_39837 : H12AffineEnvironment.transform 11 2356 env39836 = env39837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2356 env39836 == env39837) = true)

theorem identity39837 : scanCanonicalize (H12AffineFastState.compose env39837 (packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound39837 : packedSelected [0,1,2,4,6,7,8,9,10,12,14] rootPS < 2^1333 := by decide +kernel

def env39838 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,2356,8192,1,11577,35,17,1076,1024,11576,1296,33,16,8235,8192,17,2340,3109,2357,10508,2353,33,256,3093,0,11805]

theorem envBound39838 : H12AffineFastState.Bounded env39838 := by
  intro p hp
  have h : env39838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39837_39838 : H12AffineEnvironment.transform 13 1 env39837 = env39838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env39837 == env39838) = true)

theorem identity39838 : scanCanonicalize (H12AffineFastState.compose env39838 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound39838 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env39839 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,308,8192,1,9529,35,17,1076,1024,9528,1296,33,16,8235,8192,17,292,1061,309,8460,305,33,256,1045,0,9757]

theorem envBound39839 : H12AffineFastState.Bounded env39839 := by
  intro p hp
  have h : env39839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39838_39839 : H12AffineEnvironment.transform 10 0 env39838 = env39839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env39838 == env39839) = true)

theorem identity39839 : scanCanonicalize (H12AffineFastState.compose env39839 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound39839 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env39840 : List Nat := [2,4,8,16,32,17,8,256,512,1024,0,308,269,1,1076,35,17,1076,1024,1077,1296,33,16,294,269,17,292,1061,309,1,305,33,256,1045,0,1808]

theorem envBound39840 : H12AffineFastState.Bounded env39840 := by
  intro p hp
  have h : env39840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39839_39840 : H12AffineEnvironment.transform 12 269 env39839 = env39840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env39839 == env39840) = true)

theorem identity39840 : scanCanonicalize (H12AffineFastState.compose env39840 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound39840 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env39841 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,16,41,1,1076,35,17,1076,1024,1077,1076,33,16,2,41,17,0,1061,17,1,21,33,36,1045,0,1588]

theorem envBound39841 : H12AffineFastState.Bounded env39841 := by
  intro p hp
  have h : env39841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39840_39841 : H12AffineEnvironment.transform 7 36 env39840 = env39841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env39840 == env39841) = true)

theorem identity39841 : scanCanonicalize (H12AffineFastState.compose env39841 (packedSelected [3,5,6] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound39841 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env39842 : List Nat := [2,4,8,16,32,17,8,36,512,37,0,16,41,1,17,35,17,17,37,16,17,33,16,2,41,17,0,0,17,1,21,33,36,48,0,529]

theorem envBound39842 : H12AffineFastState.Bounded env39842 := by
  intro p hp
  have h : env39842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39841_39842 : H12AffineEnvironment.transform 9 37 env39841 = env39842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env39841 == env39842) = true)

theorem identity39842 : scanCanonicalize (H12AffineFastState.compose env39842 (packedSelected [3,5,10] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39842 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39843 : List Nat := [2,4,8,1,32,0,8,36,512,37,0,1,41,1,0,35,0,0,37,1,0,33,1,2,41,0,0,0,0,1,4,33,36,33,0,512]

theorem envBound39843 : H12AffineFastState.Bounded env39843 := by
  intro p hp
  have h : env39843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39842_39843 : H12AffineEnvironment.transform 3 1 env39842 = env39843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39842 == env39843) = true)

theorem identity39843 : scanCanonicalize (H12AffineFastState.compose env39843 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound39843 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39844 : List Nat := [2,1,8,1,32,0,8,33,512,32,0,1,41,1,0,35,0,0,32,1,0,33,1,2,41,0,0,0,0,1,1,33,33,33,0,512]

theorem envBound39844 : H12AffineFastState.Bounded env39844 := by
  intro p hp
  have h : env39844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39843_39844 : H12AffineEnvironment.transform 1 1 env39843 = env39844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env39843 == env39844) = true)

theorem identity39844 : scanCanonicalize (H12AffineFastState.compose env39844 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound39844 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39845 : List Nat := [2,1,8,1,32,0,8,33,34,32,0,1,41,1,0,35,0,0,32,1,0,33,1,2,41,0,0,0,0,1,1,33,33,33,0,34]

theorem envBound39845 : H12AffineFastState.Bounded env39845 := by
  intro p hp
  have h : env39845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39844_39845 : H12AffineEnvironment.transform 8 34 env39844 = env39845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env39844 == env39845) = true)

theorem identity39845 : scanCanonicalize (H12AffineFastState.compose env39845 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound39845 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env39846 : List Nat := [2,1,0,1,32,0,0,33,34,32,0,1,33,1,0,35,0,0,32,1,0,33,1,2,33,0,0,0,0,1,1,33,33,33,0,34]

theorem envBound39846 : H12AffineFastState.Bounded env39846 := by
  intro p hp
  have h : env39846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39845_39846 : H12AffineEnvironment.transform 2 0 env39845 = env39846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env39845 == env39846) = true)

theorem identity39846 : scanCanonicalize (H12AffineFastState.compose env39846 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound39846 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39847 : List Nat := [2,1,0,1,2,0,0,3,0,2,0,1,3,1,0,1,0,0,2,1,0,3,1,2,3,0,0,0,0,1,1,3,3,3,0,0]

theorem envBound39847 : H12AffineFastState.Bounded env39847 := by
  intro p hp
  have h : env39847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39846_39847 : H12AffineEnvironment.transform 4 2 env39846 = env39847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env39846 == env39847) = true)

theorem identity39847 : scanCanonicalize (H12AffineFastState.compose env39847 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39847 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env39848 : List Nat := [1,1,0,1,1,0,0,0,0,1,0,1,0,1,0,1,0,0,1,1,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0,0]

theorem envBound39848 : H12AffineFastState.Bounded env39848 := by
  intro p hp
  have h : env39848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39847_39848 : H12AffineEnvironment.transform 0 1 env39847 = env39848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39847 == env39848) = true)

def env39849 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,65536,16401,262144,1024,29788,17728,4194304,16,73736,8192,64,4478036,5393,4097,291933,20565,4194304,256,21792,16464,96011]

theorem envBound39849 : H12AffineFastState.Bounded env39849 := by
  intro p hp
  have h : env39849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39826_39849 : H12AffineEnvironment.transform 16 16401 env39826 = env39849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env39826 == env39849) = true)

theorem identity39849 : scanCanonicalize (H12AffineFastState.compose env39849 (packedSelected [1,19,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound39849 : packedSelected [1,19,28,31] rootPS < 2^1333 := by decide +kernel

def env39850 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,29962,16401,262144,1024,29788,17728,4194304,16,21762,8192,64,4478036,5393,4097,291933,20565,4194304,256,21792,16464,513]

theorem envBound39850 : H12AffineFastState.Bounded env39850 := by
  intro p hp
  have h : env39850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39849_39850 : H12AffineEnvironment.transform 15 29962 env39849 = env39850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env39849 == env39850) = true)

theorem identity39850 : scanCanonicalize (H12AffineFastState.compose env39850 (packedSelected [0,7,20] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39850 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39851 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5392,262144,1024,8541,4161,4194304,16,3,8192,64,4456789,5393,4097,270684,1364,4194304,256,33,5457,513]

theorem envBound39851 : H12AffineFastState.Bounded env39851 := by
  intro p hp
  have h : env39851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39850_39851 : H12AffineEnvironment.transform 13 5377 env39850 = env39851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39850 == env39851) = true)

theorem identity39851 : scanCanonicalize (H12AffineFastState.compose env39851 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 8492) := by decide +kernel

theorem selectedBound39851 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39852 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5392,262144,1024,8541,4161,8492,16,3,8192,64,270457,5393,4097,270684,1364,8492,256,33,5457,513]

theorem envBound39852 : H12AffineFastState.Bounded env39852 := by
  intro p hp
  have h : env39852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39851_39852 : H12AffineEnvironment.transform 21 8492 env39851 = env39852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8492 env39851 == env39852) = true)

theorem identity39852 : scanCanonicalize (H12AffineFastState.compose env39852 (packedSelected [3,5,10,12,15,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound39852 : packedSelected [3,5,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env39853 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5392,2341,1024,8541,4161,8492,16,3,8192,64,10588,5393,4097,10361,1364,8492,256,33,5457,513]

theorem envBound39853 : H12AffineFastState.Bounded env39853 := by
  intro p hp
  have h : env39853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39852_39853 : H12AffineEnvironment.transform 17 2341 env39852 = env39853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env39852 == env39853) = true)

theorem identity39853 : scanCanonicalize (H12AffineFastState.compose env39853 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 381) := by decide +kernel

theorem selectedBound39853 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,381,5377,33,374,5392,2341,1024,32,4161,81,16,3,381,64,2081,5393,4097,2308,1364,81,256,33,5457,513]

theorem envBound39854 : H12AffineFastState.Bounded env39854 := by
  intro p hp
  have h : env39854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39853_39854 : H12AffineEnvironment.transform 12 381 env39853 = env39854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 381 env39853 == env39854) = true)

theorem identity39854 : scanCanonicalize (H12AffineFastState.compose env39854 (packedSelected [0,4,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 1857) := by decide +kernel

theorem selectedBound39854 : packedSelected [0,4,10,11,12] rootPS < 2^1333 := by decide +kernel

def env39855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1857,381,576,33,374,593,2341,1024,32,1792,81,16,3,381,64,2081,592,1856,2308,1364,81,256,33,528,513]

theorem envBound39855 : H12AffineFastState.Bounded env39855 := by
  intro p hp
  have h : env39855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39854_39855 : H12AffineEnvironment.transform 11 1857 env39854 = env39855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1857 env39854 == env39855) = true)

theorem identity39855 : scanCanonicalize (H12AffineFastState.compose env39855 (packedSelected [2,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39855 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env39856 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,1808,300,529,33,295,512,2341,1024,32,1792,0,16,3,300,17,2081,513,1809,2308,1285,0,256,33,528,513]

theorem envBound39856 : H12AffineFastState.Bounded env39856 := by
  intro p hp
  have h : env39856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39855_39856 : H12AffineEnvironment.transform 5 17 env39855 = env39856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39855 == env39856) = true)

theorem identity39856 : scanCanonicalize (H12AffineFastState.compose env39856 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound39856 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39857 : List Nat := [2,4,8,16,32,17,8,4,512,1024,2048,1556,40,529,33,35,512,2081,1024,32,1540,0,16,3,40,17,2081,513,1557,2048,1025,0,4,33,528,513]

theorem envBound39857 : H12AffineFastState.Bounded env39857 := by
  intro p hp
  have h : env39857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39856_39857 : H12AffineEnvironment.transform 7 4 env39856 = env39857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env39856 == env39857) = true)

theorem identity39857 : scanCanonicalize (H12AffineFastState.compose env39857 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound39857 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39858 : List Nat := [2,4,8,16,32,17,8,4,512,21,2048,513,40,529,33,35,512,2081,21,32,529,0,16,3,40,17,2081,513,512,2048,20,0,4,33,528,513]

theorem envBound39858 : H12AffineFastState.Bounded env39858 := by
  intro p hp
  have h : env39858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39857_39858 : H12AffineEnvironment.transform 9 21 env39857 = env39858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env39857 == env39858) = true)

theorem identity39858 : scanCanonicalize (H12AffineFastState.compose env39858 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound39858 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39859 : List Nat := [2,4,8,16,32,17,8,4,512,21,48,513,40,529,33,35,512,17,21,32,529,0,16,3,40,17,17,513,512,48,20,0,4,33,528,513]

theorem envBound39859 : H12AffineFastState.Bounded env39859 := by
  intro p hp
  have h : env39859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39858_39859 : H12AffineEnvironment.transform 10 48 env39858 = env39859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env39858 == env39859) = true)

def env39860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,17,73856,8328,64,4592844,5392,4097,406605,20700,4194305,256,21792,16600,96010]

theorem envBound39860 : H12AffineFastState.Bounded env39860 := by
  intro p hp
  have h : env39860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39824_39860 : H12AffineEnvironment.transform 20 17729 env39824 = env39860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env39824 == env39860) = true)

theorem identity39860 : scanCanonicalize (H12AffineFastState.compose env39860 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 168) := by decide +kernel

theorem selectedBound39860 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,168,17,73856,8328,64,398436,5392,4097,406605,20700,169,256,21792,16600,96010]

theorem envBound39861 : H12AffineFastState.Bounded env39861 := by
  intro p hp
  have h : env39861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39860_39861 : H12AffineEnvironment.transform 21 168 env39860 = env39861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 168 env39860 == env39861) = true)

theorem identity39861 : scanCanonicalize (H12AffineFastState.compose env39861 (packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39861 : packedSelected [0,1,4,7,16,19,20,22,28,31] rootPS < 2^1333 := by decide +kernel

def env39862 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,5393,262144,1024,29788,17729,168,17,73856,8328,64,262517,5392,4097,270684,20700,169,256,21792,16600,96010]

theorem envBound39862 : H12AffineFastState.Bounded env39862 := by
  intro p hp
  have h : env39862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39861_39862 : H12AffineEnvironment.transform 16 5393 env39861 = env39862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39861 == env39862) = true)

theorem identity39862 : scanCanonicalize (H12AffineFastState.compose env39862 (packedSelected [0,4,7,11,16,18,20,21,22,23,32] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound39862 : packedSelected [0,4,7,11,16,18,20,21,22,23,32] rootPS < 2^1333 := by decide +kernel

def env39863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,30083,5393,262144,1024,29788,17729,168,17,21763,8328,64,262517,5392,4097,270684,20700,169,256,21792,16600,649]

theorem envBound39863 : H12AffineFastState.Bounded env39863 := by
  intro p hp
  have h : env39863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39862_39863 : H12AffineEnvironment.transform 15 30083 env39862 = env39863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env39862 == env39863) = true)

theorem identity39863 : scanCanonicalize (H12AffineFastState.compose env39863 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound39863 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21760,21726,5393,262144,1024,21761,17729,168,17,21763,469,64,262517,5392,4097,262145,20700,169,256,21792,16600,649]

theorem envBound39864 : H12AffineFastState.Bounded env39864 := by
  intro p hp
  have h : env39864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39863_39864 : H12AffineEnvironment.transform 12 349 env39863 = env39864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env39863 == env39864) = true)

theorem identity39864 : scanCanonicalize (H12AffineFastState.compose env39864 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound39864 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,136,342,5393,262144,1024,137,4297,168,17,139,469,64,262517,5392,4097,262145,1364,169,256,168,5456,649]

theorem envBound39865 : H12AffineFastState.Bounded env39865 := by
  intro p hp
  have h : env39865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39864_39865 : H12AffineEnvironment.transform 13 5512 env39864 = env39865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env39864 == env39865) = true)

theorem identity39865 : scanCanonicalize (H12AffineFastState.compose env39865 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound39865 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5512,136,342,5393,2420,1024,137,4297,168,17,139,469,64,2049,5392,4097,2421,1364,169,256,168,5456,649]

theorem envBound39866 : H12AffineFastState.Bounded env39866 := by
  intro p hp
  have h : env39866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39865_39866 : H12AffineEnvironment.transform 17 2420 env39865 = env39866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env39865 == env39866) = true)

theorem identity39866 : scanCanonicalize (H12AffineFastState.compose env39866 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound39866 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env39867 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,349,5488,112,342,5393,2420,1024,113,4145,80,17,115,301,64,2049,5392,4097,2421,1364,81,256,80,5456,625]

theorem envBound39867 : H12AffineFastState.Bounded env39867 := by
  intro p hp
  have h : env39867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39866_39867 : H12AffineEnvironment.transform 6 120 env39866 = env39867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env39866 == env39867) = true)

def env39868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,2097152,4194304,2114897,73857,8328,64,6705549,2117712,4096,2519309,2102685,6309185,256,21792,16600,2175563]

theorem envBound39868 : H12AffineFastState.Bounded env39868 := by
  intro p hp
  have h : env39868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39823_39868 : H12AffineEnvironment.transform 22 2114897 env39823 = env39868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2114897 env39823 == env39868) = true)

def env39869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,4194304,17,73857,8328,64,4592845,5392,4096,406605,20701,4194305,256,21792,16600,96011]

theorem envBound39869 : H12AffineFastState.Bounded env39869 := by
  intro p hp
  have h : env39869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39868_39869 : H12AffineEnvironment.transform 20 17728 env39868 = env39869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env39868 == env39869) = true)

theorem identity39869 : scanCanonicalize (H12AffineFastState.compose env39869 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound39869 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17728,32,17,73857,8328,64,398573,5392,4096,406605,20701,33,256,21792,16600,96011]

theorem envBound39870 : H12AffineFastState.Bounded env39870 := by
  intro p hp
  have h : env39870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39869_39870 : H12AffineEnvironment.transform 21 32 env39869 = env39870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env39869 == env39870) = true)

def env39871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4160,32,17,73857,8328,64,398573,5392,4096,406605,1501,33,256,32,5592,74251]

theorem envBound39871 : H12AffineFastState.Bounded env39871 := by
  intro p hp
  have h : env39871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39870_39871 : H12AffineEnvironment.transform 13 5376 env39870 = env39871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39870 == env39871) = true)

theorem identity39871 : scanCanonicalize (H12AffineFastState.compose env39871 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound39871 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,10401,1024,8540,4160,32,17,73857,8328,64,146508,5392,4096,138476,1501,33,256,32,5592,74251]

theorem envBound39872 : H12AffineFastState.Bounded env39872 := by
  intro p hp
  have h : env39872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39871_39872 : H12AffineEnvironment.transform 17 10401 env39871 = env39872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env39871 == env39872) = true)

def env39873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4161,32,17,73857,8328,64,398573,5392,4096,406605,1500,33,256,33,5593,74250]

theorem envBound39873 : H12AffineFastState.Bounded env39873 := by
  intro p hp
  have h : env39873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39870_39873 : H12AffineEnvironment.transform 13 5377 env39870 = env39873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39870 == env39873) = true)

theorem identity39873 : scanCanonicalize (H12AffineFastState.compose env39873 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39873 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,10281,1024,8541,4161,32,17,73857,8328,64,146628,5392,4096,138340,1500,33,256,33,5593,74250]

theorem envBound39874 : H12AffineFastState.Bounded env39874 := by
  intro p hp
  have h : env39874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39873_39874 : H12AffineEnvironment.transform 17 10281 env39873 = env39874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39873 == env39874) = true)

theorem identity39874 : scanCanonicalize (H12AffineFastState.compose env39874 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound39874 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env39875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,5392,10281,1024,8541,4161,32,17,73857,8328,64,10708,5392,4096,2420,1500,33,256,33,5593,74250]

theorem envBound39875 : H12AffineFastState.Bounded env39875 := by
  intro p hp
  have h : env39875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39874_39875 : H12AffineEnvironment.transform 16 5392 env39874 = env39875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env39874 == env39875) = true)

theorem identity39875 : scanCanonicalize (H12AffineFastState.compose env39875 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39875 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10281,1024,8541,4161,32,17,138,8328,64,10708,5392,4096,2420,1500,33,256,33,5593,513]

theorem envBound39876 : H12AffineFastState.Bounded env39876 := by
  intro p hp
  have h : env39876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39875_39876 : H12AffineEnvironment.transform 15 8203 env39875 = env39876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39875 == env39876) = true)

theorem identity39876 : scanCanonicalize (H12AffineFastState.compose env39876 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39876 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5392,10281,1024,8541,4161,32,17,2,8192,64,10588,5392,4096,2420,1364,33,256,33,5457,513]

theorem envBound39877 : H12AffineFastState.Bounded env39877 := by
  intro p hp
  have h : env39877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39876_39877 : H12AffineEnvironment.transform 6 8 env39876 = env39877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39876 == env39877) = true)

theorem identity39877 : scanCanonicalize (H12AffineFastState.compose env39877 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound39877 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,88,5377,260,83,5392,2161,1024,261,4161,32,17,2,88,64,2308,5392,4096,2420,1364,33,256,33,5457,513]

theorem envBound39878 : H12AffineFastState.Bounded env39878 := by
  intro p hp
  have h : env39878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39877_39878 : H12AffineEnvironment.transform 12 88 env39877 = env39878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env39877 == env39878) = true)

theorem identity39878 : scanCanonicalize (H12AffineFastState.compose env39878 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39878 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env39879 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,5377,260,2,5392,2080,1024,261,4112,32,17,2,9,17,2308,5392,4096,2341,1285,33,256,33,5376,513]

theorem envBound39879 : H12AffineFastState.Bounded env39879 := by
  intro p hp
  have h : env39879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39878_39879 : H12AffineEnvironment.transform 5 17 env39878 = env39879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39878 == env39879) = true)

theorem identity39879 : scanCanonicalize (H12AffineFastState.compose env39879 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound39879 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39880 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,292,9,1061,260,2,1076,2080,1024,261,308,32,17,2,9,17,2308,1076,292,2341,1285,33,256,33,1060,513]

theorem envBound39880 : H12AffineFastState.Bounded env39880 := by
  intro p hp
  have h : env39880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39879_39880 : H12AffineEnvironment.transform 11 292 env39879 = env39880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env39879 == env39880) = true)

theorem identity39880 : scanCanonicalize (H12AffineFastState.compose env39880 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39880 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env39881 : List Nat := [2,4,8,16,32,17,8,256,0,1024,2048,292,9,1061,260,2,1076,2080,1024,261,308,32,17,2,9,17,2308,1076,292,2341,1285,33,256,33,1060,1]

theorem envBound39881 : H12AffineFastState.Bounded env39881 := by
  intro p hp
  have h : env39881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39880_39881 : H12AffineEnvironment.transform 8 0 env39880 = env39881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39880 == env39881) = true)

def env39882 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1024,29788,17729,4194304,16,73857,8328,64,4592844,5393,4096,406604,20700,4194304,256,21792,16600,96010]

theorem envBound39882 : H12AffineFastState.Bounded env39882 := by
  intro p hp
  have h : env39882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39868_39882 : H12AffineEnvironment.transform 20 17729 env39868 = env39882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17729 env39868 == env39882) = true)

def env39883 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,4161,4194304,16,73857,8328,64,4592844,5393,4096,406604,1500,4194304,256,32,5592,74250]

theorem envBound39883 : H12AffineFastState.Bounded env39883 := by
  intro p hp
  have h : env39883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39882_39883 : H12AffineEnvironment.transform 13 5376 env39882 = env39883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39882 == env39883) = true)

def env39884 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5392,262144,1024,8540,4161,4194304,16,73857,8328,64,4456924,5393,4096,270684,1500,4194304,256,32,5592,74250]

theorem envBound39884 : H12AffineFastState.Bounded env39884 := by
  intro p hp
  have h : env39884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39883_39884 : H12AffineEnvironment.transform 16 5392 env39883 = env39884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env39883 == env39884) = true)

theorem identity39884 : scanCanonicalize (H12AffineFastState.compose env39884 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound39884 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5392,67754,1024,8540,4161,4194304,16,73857,8328,64,4262262,5393,4096,76278,1500,4194304,256,32,5592,74250]

theorem envBound39885 : H12AffineFastState.Bounded env39885 := by
  intro p hp
  have h : env39885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39884_39885 : H12AffineEnvironment.transform 17 67754 env39884 = env39885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env39884 == env39885) = true)

theorem identity39885 : scanCanonicalize (H12AffineFastState.compose env39885 (packedSelected [0,1,4,7,8,9,10,11,15,16,18,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39885 : packedSelected [0,1,4,7,8,9,10,11,15,16,18,23] rootPS < 2^1333 := by decide +kernel

def env39886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5376,81,65536,5392,67754,1024,80,4161,4194304,16,65933,388,64,4262262,5393,4096,67834,1500,4194304,256,32,5592,66310]

theorem envBound39886 : H12AffineFastState.Bounded env39886 := by
  intro p hp
  have h : env39886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39885_39886 : H12AffineEnvironment.transform 12 268 env39885 = env39886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39885 == env39886) = true)

def env39887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,65536,5393,262144,1024,8540,4161,4194304,16,73857,8328,64,4456925,5393,4096,270685,1500,4194304,256,32,5592,74250]

theorem envBound39887 : H12AffineFastState.Bounded env39887 := by
  intro p hp
  have h : env39887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39883_39887 : H12AffineEnvironment.transform 16 5393 env39883 = env39887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39883 == env39887) = true)

theorem identity39887 : scanCanonicalize (H12AffineFastState.compose env39887 (packedSelected [5,8,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39887 : packedSelected [5,8,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,5393,262144,1024,8540,4161,4194304,16,138,8328,64,4456925,5393,4096,270685,1500,4194304,256,32,5592,513]

theorem envBound39888 : H12AffineFastState.Bounded env39888 := by
  intro p hp
  have h : env39888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39887_39888 : H12AffineEnvironment.transform 15 8203 env39887 = env39888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39887 == env39888) = true)

theorem identity39888 : scanCanonicalize (H12AffineFastState.compose env39888 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 10481) := by decide +kernel

theorem selectedBound39888 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10481,1024,8540,4161,4194304,16,138,8328,64,4204844,5393,4096,2476,1500,4194304,256,32,5592,513]

theorem envBound39889 : H12AffineFastState.Bounded env39889 := by
  intro p hp
  have h : env39889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39888_39889 : H12AffineEnvironment.transform 17 10481 env39888 = env39889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10481 env39888 == env39889) = true)

theorem identity39889 : scanCanonicalize (H12AffineFastState.compose env39889 (packedSelected [1,11,23,24] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound39889 : packedSelected [1,11,23,24] rootPS < 2^1333 := by decide +kernel

def env39890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8541,8203,5393,10481,1024,8540,4161,8572,16,138,8328,64,2128,5393,4096,2476,1500,8572,256,32,5592,513]

theorem envBound39890 : H12AffineFastState.Bounded env39890 := by
  intro p hp
  have h : env39890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39889_39890 : H12AffineEnvironment.transform 21 8572 env39889 = env39890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env39889 == env39890) = true)

theorem identity39890 : scanCanonicalize (H12AffineFastState.compose env39890 (packedSelected [4,5,8,9,11,14,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39890 : packedSelected [4,5,8,9,11,14,20,23] rootPS < 2^1333 := by decide +kernel

def env39891 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5376,8461,8203,5393,10401,1024,8460,4113,8492,16,138,8328,16,2048,5393,4096,2476,1420,8492,256,32,5512,513]

theorem envBound39891 : H12AffineFastState.Bounded env39891 := by
  intro p hp
  have h : env39891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39890_39891 : H12AffineEnvironment.transform 5 16 env39890 = env39891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39890 == env39891) = true)

theorem identity39891 : scanCanonicalize (H12AffineFastState.compose env39891 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound39891 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env39892 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,8192,5292,8353,8203,5309,10401,1024,8352,4113,8320,16,138,8328,16,2048,5309,4096,2048,1056,8320,172,32,5156,513]

theorem envBound39892 : H12AffineFastState.Bounded env39892 := by
  intro p hp
  have h : env39892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39891_39892 : H12AffineEnvironment.transform 7 172 env39891 = env39892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39891 == env39892) = true)

theorem identity39892 : scanCanonicalize (H12AffineFastState.compose env39892 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39892 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env39893 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,8192,5156,8233,8203,5173,10281,1024,8232,4113,8200,16,2,8192,16,2048,5173,4096,2048,1056,8200,36,32,5156,513]

theorem envBound39893 : H12AffineFastState.Bounded env39893 := by
  intro p hp
  have h : env39893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39892_39893 : H12AffineEnvironment.transform 6 8 env39892 = env39893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39892 == env39893) = true)

theorem identity39893 : scanCanonicalize (H12AffineFastState.compose env39893 (packedSelected [0,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound39893 : packedSelected [0,7,11] rootPS < 2^1333 := by decide +kernel

def env39894 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,0,34,5173,2048,1024,1,4113,33,16,2,41,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound39894 : H12AffineFastState.Bounded env39894 := by
  intro p hp
  have h : env39894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39893_39894 : H12AffineEnvironment.transform 12 41 env39893 = env39894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env39893 == env39894) = true)

def env39895 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,0,34,1029,2048,1024,1,33,33,16,2,41,16,2048,1029,48,2048,1056,33,36,32,1044,513]

theorem envBound39895 : H12AffineFastState.Bounded env39895 := by
  intro p hp
  have h : env39895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39894_39895 : H12AffineEnvironment.transform 11 48 env39894 = env39895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39894 == env39895) = true)

theorem identity39895 : scanCanonicalize (H12AffineFastState.compose env39895 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39895 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39896 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1,48,41,1044,0,34,1029,1,1024,1,33,33,16,2,41,16,1,1029,48,1,1056,33,36,32,1044,513]

theorem envBound39896 : H12AffineFastState.Bounded env39896 := by
  intro p hp
  have h : env39896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39895_39896 : H12AffineEnvironment.transform 10 1 env39895 = env39896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39895 == env39896) = true)

def env39897 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,48,41,32,0,34,49,1,52,1,33,33,16,2,41,16,1,49,48,1,20,33,36,32,32,513]

theorem envBound39897 : H12AffineFastState.Bounded env39897 := by
  intro p hp
  have h : env39897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39896_39897 : H12AffineEnvironment.transform 9 52 env39896 = env39897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39896 == env39897) = true)

theorem identity39897 : scanCanonicalize (H12AffineFastState.compose env39897 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound39897 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39898 : List Nat := [2,4,8,16,32,16,8,36,43,52,1,48,41,32,0,34,49,1,52,1,33,33,16,2,41,16,1,49,48,1,20,33,36,32,32,42]

theorem envBound39898 : H12AffineFastState.Bounded env39898 := by
  intro p hp
  have h : env39898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39897_39898 : H12AffineEnvironment.transform 8 43 env39897 = env39898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env39897 == env39898) = true)

def leafEnv39898 : List Nat := [2,4,8,16,32,16,8,36,43,52,1,48,41,32,0,34,49,1,52,1,33,33,16,2,20,41,1,16,1,49,48,1,20,33,36,32,4,34,32,42,1,33,0]

def active39898 : List Nat := [0,1,2,3,4]

def tree39898 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39898 : H12WitnessSearch.Good tree39898 := H12GlobalWitnessIndex.good

theorem leafIdentity39898 : H12AffineFastState.composeSystem env39898 rootObs = leafEnv39898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39898 rootObs == leafEnv39898) = true)

theorem terminalChecked39898 : H12PackedTerminal.terminalCheckFast leafEnv39898 active39898 tree39898 = true := by decide +kernel

def env39899 : List Nat := [2,4,8,16,32,16,8,36,512,53,1,48,41,33,0,34,48,1,53,1,33,33,16,2,41,16,1,48,48,1,21,33,36,32,33,513]

theorem envBound39899 : H12AffineFastState.Bounded env39899 := by
  intro p hp
  have h : env39899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39896_39899 : H12AffineEnvironment.transform 9 53 env39896 = env39899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39896 == env39899) = true)

def env39900 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,0,34,1028,2048,1024,1,32,33,16,2,41,16,2048,1028,49,2048,1056,33,36,32,1045,513]

theorem envBound39900 : H12AffineFastState.Bounded env39900 := by
  intro p hp
  have h : env39900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39894_39900 : H12AffineEnvironment.transform 11 49 env39894 = env39900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env39894 == env39900) = true)

theorem identity39900 : scanCanonicalize (H12AffineFastState.compose env39900 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound39900 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39901 : List Nat := [2,4,8,16,32,16,8,36,512,1024,1077,49,41,1045,0,34,1028,1077,1024,1,32,33,16,2,41,16,1077,1028,49,1077,1056,33,36,32,1045,513]

theorem envBound39901 : H12AffineFastState.Bounded env39901 := by
  intro p hp
  have h : env39901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39900_39901 : H12AffineEnvironment.transform 10 1077 env39900 = env39901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env39900 == env39901) = true)

def env39902 : List Nat := [2,4,8,16,32,16,8,36,512,52,1,49,41,33,0,34,48,1,52,1,32,33,16,2,41,16,1,48,49,1,20,33,36,32,33,513]

theorem envBound39902 : H12AffineFastState.Bounded env39902 := by
  intro p hp
  have h : env39902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39901_39902 : H12AffineEnvironment.transform 9 52 env39901 = env39902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39901 == env39902) = true)

theorem identity39902 : scanCanonicalize (H12AffineFastState.compose env39902 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound39902 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39903 : List Nat := [2,4,8,16,32,16,8,36,43,52,1,49,41,33,0,34,48,1,52,1,32,33,16,2,41,16,1,48,49,1,20,33,36,32,33,42]

theorem envBound39903 : H12AffineFastState.Bounded env39903 := by
  intro p hp
  have h : env39903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39902_39903 : H12AffineEnvironment.transform 8 43 env39902 = env39903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env39902 == env39903) = true)

def leafEnv39903 : List Nat := [2,4,8,16,32,16,8,36,43,52,1,49,41,33,0,34,48,1,52,1,32,33,16,2,20,41,1,16,1,48,49,1,20,33,36,32,4,34,33,42,1,32,0]

def active39903 : List Nat := [0,1,2,3,4]

def tree39903 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39903 : H12WitnessSearch.Good tree39903 := H12GlobalWitnessIndex.good

theorem leafIdentity39903 : H12AffineFastState.composeSystem env39903 rootObs = leafEnv39903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39903 rootObs == leafEnv39903) = true)

theorem terminalChecked39903 : H12PackedTerminal.terminalCheckFast leafEnv39903 active39903 tree39903 = true := by decide +kernel

def env39904 : List Nat := [2,4,8,16,32,16,8,36,512,53,0,49,41,32,0,34,49,0,53,1,32,33,16,2,41,16,0,49,49,0,21,33,36,32,32,513]

theorem envBound39904 : H12AffineFastState.Bounded env39904 := by
  intro p hp
  have h : env39904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39901_39904 : H12AffineEnvironment.transform 9 53 env39901 = env39904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39901 == env39904) = true)

def env39905 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4160,4194304,16,73857,8328,64,4592844,5393,4096,406604,1501,4194304,256,33,5593,74251]

theorem envBound39905 : H12AffineFastState.Bounded env39905 := by
  intro p hp
  have h : env39905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39882_39905 : H12AffineEnvironment.transform 13 5377 env39882 = env39905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39882 == env39905) = true)

theorem identity39905 : scanCanonicalize (H12AffineFastState.compose env39905 (packedSelected [21] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39905 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,262144,1024,8541,4160,4194304,16,73737,8192,64,4592708,5393,4096,406604,1365,4194304,256,33,5457,74251]

theorem envBound39906 : H12AffineFastState.Bounded env39906 := by
  intro p hp
  have h : env39906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39905_39906 : H12AffineEnvironment.transform 6 8 env39905 = env39906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39905 == env39906) = true)

theorem identity39906 : scanCanonicalize (H12AffineFastState.compose env39906 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound39906 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env39907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,131072,67619,1024,8541,4160,4194304,16,73737,8192,64,4398183,5393,4096,212079,1365,4194304,256,33,5457,74251]

theorem envBound39907 : H12AffineFastState.Bounded env39907 := by
  intro p hp
  have h : env39907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39906_39907 : H12AffineEnvironment.transform 17 67619 env39906 = env39907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env39906 == env39907) = true)

theorem identity39907 : scanCanonicalize (H12AffineFastState.compose env39907 (packedSelected [0,2,6,11,14,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound39907 : packedSelected [0,2,6,11,14,23,27] rootPS < 2^1333 := by decide +kernel

def env39908 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,65536,5393,67619,1024,8541,4160,4194304,16,73737,8192,64,4262262,5393,4096,76158,1365,4194304,256,33,5457,74251]

theorem envBound39908 : H12AffineFastState.Bounded env39908 := by
  intro p hp
  have h : env39908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39907_39908 : H12AffineEnvironment.transform 16 5393 env39907 = env39908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env39907 == env39908) = true)

theorem identity39908 : scanCanonicalize (H12AffineFastState.compose env39908 (packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound39908 : packedSelected [0,3,5,7,9,10,11,14,16,18,22] rootPS < 2^1333 := by decide +kernel

def env39909 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,342,5393,2421,1024,8541,4160,4194304,16,8543,8192,64,4196384,5393,4096,10280,1365,4194304,256,33,5457,9053]

theorem envBound39909 : H12AffineFastState.Bounded env39909 := by
  intro p hp
  have h : env39909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39908_39909 : H12AffineEnvironment.transform 15 342 env39908 = env39909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env39908 == env39909) = true)

theorem identity39909 : scanCanonicalize (H12AffineFastState.compose env39909 (packedSelected [16,20] rootPS)) = affineNative (2^(21+1) ^^^ 8573) := by decide +kernel

theorem selectedBound39909 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env39910 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,342,5393,2421,1024,8541,4160,8573,16,8543,8192,64,10589,5393,4096,10280,1365,8573,256,33,5457,9053]

theorem envBound39910 : H12AffineFastState.Bounded env39910 := by
  intro p hp
  have h : env39910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39909_39910 : H12AffineEnvironment.transform 21 8573 env39909 = env39910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8573 env39909 == env39910) = true)

theorem identity39910 : scanCanonicalize (H12AffineFastState.compose env39910 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound39910 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39911 : List Nat := [2,4,8,16,32,64,8,84,512,1024,2048,4096,8192,5205,8200,2,5189,2081,1024,8201,4160,8233,16,8203,8192,64,10249,5189,4096,10280,1025,8233,84,33,5125,8713]

theorem envBound39911 : H12AffineFastState.Bounded env39911 := by
  intro p hp
  have h : env39911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39910_39911 : H12AffineEnvironment.transform 7 84 env39910 = env39911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env39910 == env39911) = true)

theorem identity39911 : scanCanonicalize (H12AffineFastState.compose env39911 (packedSelected [1,5,8,24] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39911 : packedSelected [1,5,8,24] rootPS < 2^1333 := by decide +kernel

def env39912 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,4096,8192,5124,8200,2,5140,2081,1024,8201,4113,8233,16,8203,8192,17,10249,5140,4096,10280,1025,8233,5,33,5125,8713]

theorem envBound39912 : H12AffineFastState.Bounded env39912 := by
  intro p hp
  have h : env39912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39911_39912 : H12AffineEnvironment.transform 5 17 env39911 = env39912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39911 == env39912) = true)

theorem identity39912 : scanCanonicalize (H12AffineFastState.compose env39912 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound39912 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env39913 : List Nat := [2,4,8,16,32,17,8,5,512,1024,2048,3108,8192,2080,8200,2,2096,2081,1024,8201,3125,8233,16,8203,8192,17,10249,2096,3108,10280,1025,8233,5,33,2081,8713]

theorem envBound39913 : H12AffineFastState.Bounded env39913 := by
  intro p hp
  have h : env39913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39912_39913 : H12AffineEnvironment.transform 11 3108 env39912 = env39913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env39912 == env39913) = true)

theorem identity39913 : scanCanonicalize (H12AffineFastState.compose env39913 (packedSelected [0,1,6,7,8,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39913 : packedSelected [0,1,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env39914 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,2065,8192,2080,8200,2,2096,2081,53,8201,2048,8233,16,8203,8192,17,10249,2096,2065,10280,52,8233,5,33,2081,8713]

theorem envBound39914 : H12AffineFastState.Bounded env39914 := by
  intro p hp
  have h : env39914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39913_39914 : H12AffineEnvironment.transform 9 53 env39913 = env39914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39913 == env39914) = true)

theorem identity39914 : scanCanonicalize (H12AffineFastState.compose env39914 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound39914 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env39915 : List Nat := [2,4,8,16,32,17,8,5,512,53,2048,2065,9,2080,1,2,2096,2081,53,0,2048,32,16,2,9,17,2048,2096,2065,2081,52,32,5,33,2081,512]

theorem envBound39915 : H12AffineFastState.Bounded env39915 := by
  intro p hp
  have h : env39915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39914_39915 : H12AffineEnvironment.transform 12 9 env39914 = env39915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env39914 == env39915) = true)

theorem identity39915 : scanCanonicalize (H12AffineFastState.compose env39915 (packedSelected [6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound39915 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39916 : List Nat := [2,4,8,16,0,17,8,5,512,21,2048,2065,9,2048,1,2,2064,2049,21,0,2048,0,16,2,9,17,2048,2064,2065,2049,20,0,5,1,2049,512]

theorem envBound39916 : H12AffineFastState.Bounded env39916 := by
  intro p hp
  have h : env39916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39915_39916 : H12AffineEnvironment.transform 4 0 env39915 = env39916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env39915 == env39916) = true)

theorem identity39916 : scanCanonicalize (H12AffineFastState.compose env39916 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound39916 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39917 : List Nat := [2,4,8,16,0,17,8,5,0,21,2048,2065,9,2048,1,2,2064,2049,21,0,2048,0,16,2,9,17,2048,2064,2065,2049,20,0,5,1,2049,0]

theorem envBound39917 : H12AffineFastState.Bounded env39917 := by
  intro p hp
  have h : env39917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39916_39917 : H12AffineEnvironment.transform 8 0 env39916 = env39917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env39916 == env39917) = true)

theorem identity39917 : scanCanonicalize (H12AffineFastState.compose env39917 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 30) := by decide +kernel

theorem selectedBound39917 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39918 : List Nat := [2,4,8,16,0,17,8,5,0,21,30,15,9,30,1,2,14,31,21,0,30,0,16,2,9,17,30,14,15,31,20,0,5,1,31,0]

theorem envBound39918 : H12AffineFastState.Bounded env39918 := by
  intro p hp
  have h : env39918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39917_39918 : H12AffineEnvironment.transform 10 30 env39917 = env39918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 30 env39917 == env39918) = true)

def leafEnv39918 : List Nat := [2,4,8,16,0,17,8,5,0,21,30,15,9,30,1,2,14,31,21,0,30,0,16,2,20,9,1,17,30,14,15,31,20,0,5,1,4,2,31,0,1,31,0]

def active39918 : List Nat := [0,1,2,3]

def tree39918 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39918 : H12WitnessSearch.Good tree39918 := H12GlobalWitnessIndex.good

theorem leafIdentity39918 : H12AffineFastState.composeSystem env39918 rootObs = leafEnv39918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39918 rootObs == leafEnv39918) = true)

theorem terminalChecked39918 : H12PackedTerminal.terminalCheckFast leafEnv39918 active39918 tree39918 = true := by decide +kernel

def env39919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound39919 : H12AffineFastState.Bounded env39919 := by
  intro p hp
  have h : env39919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39729_39919 : H12AffineEnvironment.transform 18 1025 env39729 = env39919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env39729 == env39919) = true)

theorem identity39919 : scanCanonicalize (H12AffineFastState.compose env39919 (packedSelected [13] rootPS)) = affineNative (2^(20+1) ^^^ 165200) := by decide +kernel

theorem selectedBound39919 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env39920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,8388608,16777216,8328,64,29868033,16974301,8572929,8830976,25265168,21225616,257,25379324,25403480,25207751]

theorem envBound39920 : H12AffineFastState.Bounded env39920 := by
  intro p hp
  have h : env39920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39919_39920 : H12AffineEnvironment.transform 20 165200 env39919 = env39920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 165200 env39919 == env39920) = true)

def env39921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,8388608,8590556,8328,64,4510941,8393985,8572929,8830976,168140,12645452,257,21792,46212,243483]

theorem envBound39921 : H12AffineFastState.Bounded env39921 := by
  intro p hp
  have h : env39921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39920_39921 : H12AffineEnvironment.transform 23 8590556 env39920 = env39921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590556 env39920 == env39921) = true)

def env39922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169216,98780,8328,64,4510941,163841,17665,283904,168140,4350284,257,21792,46212,243483]

theorem envBound39922 : H12AffineFastState.Bounded env39922 := by
  intro p hp
  have h : env39922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39921_39922 : H12AffineEnvironment.transform 22 169216 env39921 = env39922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env39921 == env39922) = true)

def env39923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169216,98780,8328,64,64605,163841,17665,283904,168140,412108,257,21792,46212,243483]

theorem envBound39923 : H12AffineFastState.Bounded env39923 := by
  intro p hp
  have h : env39923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39922_39923 : H12AffineEnvironment.transform 21 272512 env39922 = env39923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39922 == env39923) = true)

theorem identity39923 : scanCanonicalize (H12AffineFastState.compose env39923 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39923 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165200,272512,169216,41431,8328,64,64605,163841,17665,283904,168140,412108,257,21792,46212,169744]

theorem envBound39924 : H12AffineFastState.Bounded env39924 := by
  intro p hp
  have h : env39924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39923_39924 : H12AffineEnvironment.transform 15 8203 env39923 = env39924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39923 == env39924) = true)

def env39925 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165200,272392,169216,41311,8192,64,64605,163841,17665,283904,168004,411972,257,21792,46092,169744]

theorem envBound39925 : H12AffineFastState.Bounded env39925 := by
  intro p hp
  have h : env39925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39924_39925 : H12AffineEnvironment.transform 6 8 env39924 = env39925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39924 == env39925) = true)

theorem identity39925 : scanCanonicalize (H12AffineFastState.compose env39925 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound39925 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39926 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1025,32769,165200,144492,169216,41311,8192,64,64605,163841,17665,149860,168004,21792,257,21792,46092,169744]

theorem envBound39926 : H12AffineFastState.Bounded env39926 := by
  intro p hp
  have h : env39926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39925_39926 : H12AffineEnvironment.transform 17 138340 env39925 = env39926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env39925 == env39926) = true)

theorem identity39926 : scanCanonicalize (H12AffineFastState.compose env39926 (packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound39926 : packedSelected [0,2,3,7,9,10,11,16,18,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39927 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8203,131072,138340,1025,8233,140664,144492,144680,375,8192,64,23669,139305,17665,149860,143468,21792,257,21792,5156,145208]

theorem envBound39927 : H12AffineFastState.Bounded env39927 := by
  intro p hp
  have h : env39927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39926_39927 : H12AffineEnvironment.transform 14 8232 env39926 = env39927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env39926 == env39927) = true)

theorem identity39927 : scanCanonicalize (H12AffineFastState.compose env39927 (packedSelected [1,2,3,5,6,8,9,10,11,14,17,18,19,22] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound39927 : packedSelected [1,2,3,5,6,8,9,10,11,14,17,18,19,22] rootPS < 2^1333 := by decide +kernel

def env39928 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8232,8203,13389,10281,1025,8233,4405,33,357,375,8192,64,23669,5220,17665,32041,1057,21792,257,21792,5156,885]

theorem envBound39928 : H12AffineFastState.Bounded env39928 := by
  intro p hp
  have h : env39928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39927_39928 : H12AffineEnvironment.transform 16 13389 env39927 = env39928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env39927 == env39928) = true)

def env39929 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,165200,272393,169216,41310,8193,64,64605,163841,17665,283904,168005,411973,257,21792,46093,169744]

theorem envBound39929 : H12AffineFastState.Bounded env39929 := by
  intro p hp
  have h : env39929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39924_39929 : H12AffineEnvironment.transform 6 9 env39924 = env39929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39924 == env39929) = true)

theorem identity39929 : scanCanonicalize (H12AffineFastState.compose env39929 (packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 179513) := by decide +kernel

theorem selectedBound39929 : packedSelected [1,4,7,9,16,17,19,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env39930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179513,1025,32769,165200,169264,169216,41310,8193,64,64605,163841,17665,190521,168005,62588,257,21792,46093,169744]

theorem envBound39930 : H12AffineFastState.Bounded env39930 := by
  intro p hp
  have h : env39930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39929_39930 : H12AffineEnvironment.transform 17 179513 env39929 = env39930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179513 env39929 == env39930) = true)

theorem identity39930 : scanCanonicalize (H12AffineFastState.compose env39930 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound39930 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1025,32769,4160,32,16,41310,8193,64,64605,5393,17665,32041,1365,62588,257,21792,46093,512]

theorem envBound39931 : H12AffineFastState.Bounded env39931 := by
  intro p hp
  have h : env39931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39930_39931 : H12AffineEnvironment.transform 16 38160 env39930 = env39931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env39930 == env39931) = true)

theorem identity39931 : scanCanonicalize (H12AffineFastState.compose env39931 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound39931 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,32768,8203,38160,10281,1025,32769,4160,32,16,41310,8193,64,47436,5393,16,14392,1365,45421,257,4145,46093,512]

theorem envBound39932 : H12AffineFastState.Bounded env39932 := by
  intro p hp
  have h : env39932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39931_39932 : H12AffineEnvironment.transform 13 1297 env39931 = env39932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env39931 == env39932) = true)

theorem identity39932 : scanCanonicalize (H12AffineFastState.compose env39932 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 12344) := by decide +kernel

theorem selectedBound39932 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39933 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,1297,12344,8203,9512,10281,1025,12345,4160,32,16,4454,8193,64,2420,5393,16,14392,1365,341,257,4145,1077,512]

theorem envBound39933 : H12AffineFastState.Bounded env39933 := by
  intro p hp
  have h : env39933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39932_39933 : H12AffineEnvironment.transform 14 12344 env39932 = env39933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12344 env39932 == env39933) = true)

theorem identity39933 : scanCanonicalize (H12AffineFastState.compose env39933 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound39933 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env39934 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,8192,1297,12344,8203,9512,10281,1025,12345,4145,32,16,4375,8193,49,2309,5393,16,14392,1316,292,257,4145,1077,512]

theorem envBound39934 : H12AffineFastState.Bounded env39934 := by
  intro p hp
  have h : env39934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39933_39934 : H12AffineEnvironment.transform 5 49 env39933 = env39934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env39933 == env39934) = true)

def env39935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169216,98780,8328,64,64604,163841,17665,283904,168140,412109,257,21792,46212,243483]

theorem envBound39935 : H12AffineFastState.Bounded env39935 := by
  intro p hp
  have h : env39935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39922_39935 : H12AffineEnvironment.transform 21 272513 env39922 = env39935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39922 == env39935) = true)

theorem identity39935 : scanCanonicalize (H12AffineFastState.compose env39935 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound39935 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39936 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,77898,272513,73754,98780,8328,64,64604,79131,17665,283904,75222,392407,257,21792,46212,513]

theorem envBound39936 : H12AffineFastState.Bounded env39936 := by
  intro p hp
  have h : env39936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39935_39936 : H12AffineEnvironment.transform 16 111898 env39935 = env39936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env39935 == env39936) = true)

def env39937 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,90138,262144,1025,21761,77898,272513,73754,87260,8328,64,10588,79131,17665,283904,75222,338391,257,21792,24964,513]

theorem envBound39937 : H12AffineFastState.Bounded env39937 := by
  intro p hp
  have h : env39937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39936_39937 : H12AffineEnvironment.transform 14 21760 env39936 = env39937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env39936 == env39937) = true)

def env39938 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,65536,90138,262144,1025,21761,77898,272393,73754,87124,8192,64,10588,79131,17665,283904,75102,338271,257,21792,24844,513]

theorem envBound39938 : H12AffineFastState.Bounded env39938 := by
  intro p hp
  have h : env39938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39937_39938 : H12AffineEnvironment.transform 6 8 env39937 = env39938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39937 == env39938) = true)

theorem identity39938 : scanCanonicalize (H12AffineFastState.compose env39938 (packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound39938 : packedSelected [0,2,4,6,9,11,17,20,27,32] rootPS < 2^1333 := by decide +kernel

def env39939 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,16384,21760,65536,82951,262144,1025,21761,70743,265236,66567,87124,1053,64,3393,69894,17665,283904,65859,331074,257,21792,17681,513]

theorem envBound39939 : H12AffineFastState.Bounded env39939 := by
  intro p hp
  have h : env39939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39938_39939 : H12AffineEnvironment.transform 12 1053 env39938 = env39939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env39938 == env39939) = true)

theorem identity39939 : scanCanonicalize (H12AffineFastState.compose env39939 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound39939 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env39940 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4404,1076,65536,70963,262144,1025,1077,70743,265236,66567,66912,1053,64,3393,69894,5173,263220,65859,331074,257,1044,5157,513]

theorem envBound39940 : H12AffineFastState.Bounded env39940 := by
  intro p hp
  have h : env39940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39939_39940 : H12AffineEnvironment.transform 13 4404 env39939 = env39940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env39939 == env39940) = true)

theorem identity39940 : scanCanonicalize (H12AffineFastState.compose env39940 (packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 1047) := by decide +kernel

theorem selectedBound39940 : packedSelected [1,2,3,6,11,12,15,23,24,28] rootPS < 2^1333 := by decide +kernel

def env39941 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4404,1076,1047,4388,262144,1025,1077,4160,265236,16,375,1053,64,3393,5393,5173,263220,1364,264533,257,1044,5157,513]

theorem envBound39941 : H12AffineFastState.Bounded env39941 := by
  intro p hp
  have h : env39941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39940_39941 : H12AffineEnvironment.transform 15 1047 env39940 = env39941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1047 env39940 == env39941) = true)

theorem identity39941 : scanCanonicalize (H12AffineFastState.compose env39941 (packedSelected [14] rootPS)) = affineNative (2^(17+1) ^^^ 3173) := by decide +kernel

theorem selectedBound39941 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env39942 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,4404,1076,1047,4388,3173,1025,1077,4160,113,16,375,1053,64,3393,5393,5173,2129,1364,1328,257,1044,5157,513]

theorem envBound39942 : H12AffineFastState.Bounded env39942 := by
  intro p hp
  have h : env39942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39941_39942 : H12AffineEnvironment.transform 17 3173 env39941 = env39942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 3173 env39941 == env39942) = true)

theorem identity39942 : scanCanonicalize (H12AffineFastState.compose env39942 (packedSelected [3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound39942 : packedSelected [3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env39943 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,348,4404,373,342,4388,2340,320,372,4160,113,16,375,348,64,2048,4176,4468,2129,21,113,257,341,4452,513]

theorem envBound39943 : H12AffineFastState.Bounded env39943 := by
  intro p hp
  have h : env39943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39942_39943 : H12AffineEnvironment.transform 9 321 env39942 = env39943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env39942 == env39943) = true)

theorem identity39943 : scanCanonicalize (H12AffineFastState.compose env39943 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound39943 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39944 : List Nat := [2,4,8,16,32,64,8,37,512,100,2048,4096,121,4113,80,115,4097,2049,101,81,4160,113,16,82,121,64,2048,4176,4177,2129,21,113,36,112,4161,513]

theorem envBound39944 : H12AffineFastState.Bounded env39944 := by
  intro p hp
  have h : env39944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39943_39944 : H12AffineEnvironment.transform 7 37 env39943 = env39944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env39943 == env39944) = true)

def env39945 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,65536,90138,262144,1025,21761,77898,272392,73754,87125,8193,64,10588,79131,17665,283904,75103,338270,257,21792,24845,513]

theorem envBound39945 : H12AffineFastState.Bounded env39945 := by
  intro p hp
  have h : env39945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39937_39945 : H12AffineEnvironment.transform 6 9 env39937 = env39945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39937 == env39945) = true)

theorem identity39945 : scanCanonicalize (H12AffineFastState.compose env39945 (packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound39945 : packedSelected [2,3,4,5,6,9,10,12,14,20,38] rootPS < 2^1333 := by decide +kernel

def env39946 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,24908,262144,1025,21761,12572,272392,8524,21763,8193,64,10588,13389,17665,283904,9225,272392,257,21792,24845,513]

theorem envBound39946 : H12AffineFastState.Bounded env39946 := by
  intro p hp
  have h : env39946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39945_39946 : H12AffineEnvironment.transform 15 342 env39945 = env39946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env39945 == env39946) = true)

theorem identity39946 : scanCanonicalize (H12AffineFastState.compose env39946 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound39946 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env39947 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,342,24908,2421,1025,21761,12572,8573,8524,21763,8193,64,10588,13389,17665,23669,9225,8573,257,21792,24845,513]

theorem envBound39947 : H12AffineFastState.Bounded env39947 := by
  intro p hp
  have h : env39947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39946_39947 : H12AffineEnvironment.transform 17 2421 env39946 = env39947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env39946 == env39947) = true)

theorem identity39947 : scanCanonicalize (H12AffineFastState.compose env39947 (packedSelected [17] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39947 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39948 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21760,342,16400,2421,1025,21761,4160,33,16,21763,349,64,2048,5393,17665,23669,1365,33,257,21792,16465,513]

theorem envBound39948 : H12AffineFastState.Bounded env39948 := by
  intro p hp
  have h : env39948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39947_39948 : H12AffineEnvironment.transform 12 348 env39947 = env39948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39947 == env39948) = true)

theorem identity39948 : scanCanonicalize (H12AffineFastState.compose env39948 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound39948 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39949 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,0,342,5392,2421,1025,1,4160,33,16,3,349,64,2048,5393,4097,2421,1365,33,257,32,5457,513]

theorem envBound39949 : H12AffineFastState.Bounded env39949 := by
  intro p hp
  have h : env39949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39948_39949 : H12AffineEnvironment.transform 13 5376 env39948 = env39949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env39948 == env39949) = true)

theorem identity39949 : scanCanonicalize (H12AffineFastState.compose env39949 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39949 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39950 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,5237,0,35,5221,2048,1025,1,4160,33,16,3,40,64,2048,5220,4097,2048,1056,33,116,32,5156,513]

theorem envBound39950 : H12AffineFastState.Bounded env39950 := by
  intro p hp
  have h : env39950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39949_39950 : H12AffineEnvironment.transform 7 117 env39949 = env39950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39949 == env39950) = true)

theorem identity39950 : scanCanonicalize (H12AffineFastState.compose env39950 (packedSelected [0,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound39950 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39951 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5156,0,35,5172,2048,1025,1,4113,33,16,3,40,17,2048,5173,4097,2048,1056,33,37,32,5156,513]

theorem envBound39951 : H12AffineFastState.Bounded env39951 := by
  intro p hp
  have h : env39951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39950_39951 : H12AffineEnvironment.transform 5 17 env39950 = env39951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39950 == env39951) = true)

def env39952 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1044,0,35,1028,2048,1025,1,33,33,16,3,40,17,2048,1029,49,2048,1056,33,37,32,1044,513]

theorem envBound39952 : H12AffineFastState.Bounded env39952 := by
  intro p hp
  have h : env39952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39951_39952 : H12AffineEnvironment.transform 11 48 env39951 = env39952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env39951 == env39952) = true)

theorem identity39952 : scanCanonicalize (H12AffineFastState.compose env39952 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1573) := by decide +kernel

theorem selectedBound39952 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39953 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1573,48,41,1044,0,35,1028,1573,1025,1,33,33,16,3,40,17,1573,1029,49,1573,1056,33,37,32,1044,513]

theorem envBound39953 : H12AffineFastState.Bounded env39953 := by
  intro p hp
  have h : env39953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39952_39953 : H12AffineEnvironment.transform 10 1573 env39952 = env39953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1573 env39952 == env39953) = true)

def env39954 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,48,41,32,0,35,48,529,53,1,33,33,16,3,40,17,529,49,49,529,20,33,37,32,32,513]

theorem envBound39954 : H12AffineFastState.Bounded env39954 := by
  intro p hp
  have h : env39954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39953_39954 : H12AffineEnvironment.transform 9 52 env39953 = env39954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39953 == env39954) = true)

theorem identity39954 : scanCanonicalize (H12AffineFastState.compose env39954 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound39954 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39955 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,48,41,32,0,35,48,58,53,1,33,33,16,3,40,17,58,49,49,58,20,33,37,32,32,42]

theorem envBound39955 : H12AffineFastState.Bounded env39955 := by
  intro p hp
  have h : env39955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39954_39955 : H12AffineEnvironment.transform 8 43 env39954 = env39955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env39954 == env39955) = true)

def leafEnv39955 : List Nat := [2,4,8,16,32,17,9,36,43,52,58,48,41,32,0,35,48,58,53,1,33,33,16,3,21,40,1,17,58,49,49,58,20,33,37,32,5,34,32,42,1,33,0]

def active39955 : List Nat := [0,1,2,3,4]

def tree39955 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39955 : H12WitnessSearch.Good tree39955 := H12GlobalWitnessIndex.good

theorem leafIdentity39955 : H12AffineFastState.composeSystem env39955 rootObs = leafEnv39955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39955 rootObs == leafEnv39955) = true)

theorem terminalChecked39955 : H12PackedTerminal.terminalCheckFast leafEnv39955 active39955 tree39955 = true := by decide +kernel

def env39956 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,48,41,33,0,35,49,528,52,1,33,33,16,3,40,17,528,48,49,528,21,33,37,32,33,513]

theorem envBound39956 : H12AffineFastState.Bounded env39956 := by
  intro p hp
  have h : env39956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39953_39956 : H12AffineEnvironment.transform 9 53 env39953 = env39956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39953 == env39956) = true)

def env39957 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1045,0,35,1029,2048,1025,1,32,33,16,3,40,17,2048,1028,48,2048,1056,33,37,32,1045,513]

theorem envBound39957 : H12AffineFastState.Bounded env39957 := by
  intro p hp
  have h : env39957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39951_39957 : H12AffineEnvironment.transform 11 49 env39951 = env39957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env39951 == env39957) = true)

theorem identity39957 : scanCanonicalize (H12AffineFastState.compose env39957 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound39957 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39958 : List Nat := [2,4,8,16,32,17,9,36,512,1024,529,49,41,1045,0,35,1029,529,1025,1,32,33,16,3,40,17,529,1028,48,529,1056,33,37,32,1045,513]

theorem envBound39958 : H12AffineFastState.Bounded env39958 := by
  intro p hp
  have h : env39958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39957_39958 : H12AffineEnvironment.transform 10 529 env39957 = env39958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env39957 == env39958) = true)

def env39959 : List Nat := [2,4,8,16,32,17,9,36,512,52,529,49,41,33,0,35,49,529,53,1,32,33,16,3,40,17,529,48,48,529,20,33,37,32,33,513]

theorem envBound39959 : H12AffineFastState.Bounded env39959 := by
  intro p hp
  have h : env39959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39958_39959 : H12AffineEnvironment.transform 9 52 env39958 = env39959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env39958 == env39959) = true)

theorem identity39959 : scanCanonicalize (H12AffineFastState.compose env39959 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound39959 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39960 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,49,41,33,0,35,49,59,53,1,32,33,16,3,40,17,59,48,48,59,20,33,37,32,33,43]

theorem envBound39960 : H12AffineFastState.Bounded env39960 := by
  intro p hp
  have h : env39960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39959_39960 : H12AffineEnvironment.transform 8 42 env39959 = env39960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env39959 == env39960) = true)

def leafEnv39960 : List Nat := [2,4,8,16,32,17,9,36,42,52,59,49,41,33,0,35,49,59,53,1,32,33,16,3,21,40,1,17,59,48,48,59,20,33,37,32,5,34,33,43,1,32,0]

def active39960 : List Nat := [0,1,2,3,4]

def tree39960 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood39960 : H12WitnessSearch.Good tree39960 := H12GlobalWitnessIndex.good

theorem leafIdentity39960 : H12AffineFastState.composeSystem env39960 rootObs = leafEnv39960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env39960 rootObs == leafEnv39960) = true)

theorem terminalChecked39960 : H12PackedTerminal.terminalCheckFast leafEnv39960 active39960 tree39960 = true := by decide +kernel

def env39961 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,49,41,32,0,35,48,529,52,1,32,33,16,3,40,17,529,49,48,529,21,33,37,32,32,513]

theorem envBound39961 : H12AffineFastState.Bounded env39961 := by
  intro p hp
  have h : env39961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39958_39961 : H12AffineEnvironment.transform 9 53 env39958 = env39961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39958 == env39961) = true)

def env39962 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,65536,90139,262144,1025,21760,77898,272513,73754,87261,8328,64,10589,79131,17665,283904,75222,338390,257,21792,24965,513]

theorem envBound39962 : H12AffineFastState.Bounded env39962 := by
  intro p hp
  have h : env39962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39936_39962 : H12AffineEnvironment.transform 14 21761 env39936 = env39962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env39936 == env39962) = true)

theorem identity39962 : scanCanonicalize (H12AffineFastState.compose env39962 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39962 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39963 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16400,262144,1025,21760,4161,272513,17,29910,8328,64,10589,5392,17665,283904,1501,264669,257,21792,24965,513]

theorem envBound39963 : H12AffineFastState.Bounded env39963 := by
  intro p hp
  have h : env39963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39962_39963 : H12AffineEnvironment.transform 15 8203 env39962 = env39963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39962 == env39963) = true)

theorem identity39963 : scanCanonicalize (H12AffineFastState.compose env39963 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound39963 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39964 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21761,8203,16400,2557,1025,21760,4161,8572,17,29910,8328,64,10589,5392,17665,23805,1501,32,257,21792,24965,513]

theorem envBound39964 : H12AffineFastState.Bounded env39964 := by
  intro p hp
  have h : env39964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39963_39964 : H12AffineEnvironment.transform 17 2557 env39963 = env39964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env39963 == env39964) = true)

theorem identity39964 : scanCanonicalize (H12AffineFastState.compose env39964 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound39964 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39965 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,137,8203,5528,2557,1025,136,4161,8572,17,8542,8328,64,10589,5392,4233,2421,1501,32,257,168,13325,513]

theorem envBound39965 : H12AffineFastState.Bounded env39965 := by
  intro p hp
  have h : env39965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39964_39965 : H12AffineEnvironment.transform 13 5512 env39964 = env39965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env39964 == env39965) = true)

theorem identity39965 : scanCanonicalize (H12AffineFastState.compose env39965 (packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound39965 : packedSelected [2,3,5,10,11,12,14,15,17,18] rootPS < 2^1333 := by decide +kernel

def env39966 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,5512,137,431,5528,2557,1025,136,4161,216,17,250,300,64,2297,5392,4233,2421,1501,32,257,168,5545,513]

theorem envBound39966 : H12AffineFastState.Bounded env39966 := by
  intro p hp
  have h : env39966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39965_39966 : H12AffineEnvironment.transform 12 420 env39965 = env39966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env39965 == env39966) = true)

theorem identity39966 : scanCanonicalize (H12AffineFastState.compose env39966 (packedSelected [4,9,14,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound39966 : packedSelected [4,9,14,17,20] rootPS < 2^1333 := by decide +kernel

def env39967 : List Nat := [2,4,8,16,32,64,120,256,512,1024,2048,4096,348,5488,113,343,5472,2309,1025,112,4161,32,17,2,300,64,2049,5392,4209,2421,1317,32,257,80,5457,513]

theorem envBound39967 : H12AffineFastState.Bounded env39967 := by
  intro p hp
  have h : env39967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39966_39967 : H12AffineEnvironment.transform 6 120 env39966 = env39967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env39966 == env39967) = true)

theorem identity39967 : scanCanonicalize (H12AffineFastState.compose env39967 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound39967 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39968 : List Nat := [2,4,8,16,32,64,120,84,512,1024,2048,4096,8,5156,113,3,5172,2129,1025,112,4161,32,17,2,120,64,2049,5188,4209,2081,1137,32,85,80,5125,513]

theorem envBound39968 : H12AffineFastState.Bounded env39968 := by
  intro p hp
  have h : env39968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39967_39968 : H12AffineEnvironment.transform 7 84 env39967 = env39968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env39967 == env39968) = true)

theorem identity39968 : scanCanonicalize (H12AffineFastState.compose env39968 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1093) := by decide +kernel

theorem selectedBound39968 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env39969 : List Nat := [2,4,8,16,32,64,120,84,512,1024,2048,1093,8,97,113,3,113,2129,1025,112,1028,32,17,2,120,64,2049,1,1076,2081,1137,32,85,80,64,513]

theorem envBound39969 : H12AffineFastState.Bounded env39969 := by
  intro p hp
  have h : env39969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39968_39969 : H12AffineEnvironment.transform 11 1093 env39968 = env39969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1093 env39968 == env39969) = true)

theorem identity39969 : scanCanonicalize (H12AffineFastState.compose env39969 (packedSelected [0,3,5,7,10,12] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound39969 : packedSelected [0,3,5,7,10,12] rootPS < 2^1333 := by decide +kernel

def env39970 : List Nat := [2,4,8,16,32,64,120,84,512,1024,17,1093,8,97,113,3,113,64,1025,112,1028,32,17,2,120,64,16,1,1076,48,1137,32,85,80,64,513]

theorem envBound39970 : H12AffineFastState.Bounded env39970 := by
  intro p hp
  have h : env39970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39969_39970 : H12AffineEnvironment.transform 10 17 env39969 = env39970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env39969 == env39970) = true)

theorem identity39970 : scanCanonicalize (H12AffineFastState.compose env39970 (packedSelected [0,1,3,5,7,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39970 : packedSelected [0,1,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env39971 : List Nat := [2,4,8,1,32,64,105,69,512,1024,0,1093,8,97,96,3,96,64,1025,97,1028,32,0,2,105,64,1,1,1061,33,1120,32,68,65,64,513]

theorem envBound39971 : H12AffineFastState.Bounded env39971 := by
  intro p hp
  have h : env39971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39970_39971 : H12AffineEnvironment.transform 3 1 env39970 = env39971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39970 == env39971) = true)

theorem identity39971 : scanCanonicalize (H12AffineFastState.compose env39971 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 64) := by decide +kernel

theorem selectedBound39971 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env39972 : List Nat := [2,4,8,1,32,64,105,69,64,1024,0,1093,8,97,96,3,96,64,1025,97,1028,32,0,2,105,64,1,1,1061,33,1120,32,68,65,64,65]

theorem envBound39972 : H12AffineFastState.Bounded env39972 := by
  intro p hp
  have h : env39972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39971_39972 : H12AffineEnvironment.transform 8 64 env39971 = env39972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 64 env39971 == env39972) = true)

theorem identity39972 : scanCanonicalize (H12AffineFastState.compose env39972 (packedSelected [4] rootPS)) = affineNative (2^(9+1) ^^^ 0) := by decide +kernel

theorem selectedBound39972 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env39973 : List Nat := [2,4,8,1,32,64,105,69,64,0,0,69,8,97,96,3,96,64,1,97,4,32,0,2,105,64,1,1,37,33,96,32,68,65,64,65]

theorem envBound39973 : H12AffineFastState.Bounded env39973 := by
  intro p hp
  have h : env39973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39972_39973 : H12AffineEnvironment.transform 9 0 env39972 = env39973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env39972 == env39973) = true)

theorem identity39973 : scanCanonicalize (H12AffineFastState.compose env39973 (packedSelected [1,3,7] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound39973 : packedSelected [1,3,7] rootPS < 2^1333 := by decide +kernel

def env39974 : List Nat := [2,4,8,1,11,64,66,69,64,0,0,69,8,74,75,3,75,64,1,74,4,11,0,2,66,64,1,1,14,10,75,11,68,65,64,65]

theorem envBound39974 : H12AffineFastState.Bounded env39974 := by
  intro p hp
  have h : env39974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39973_39974 : H12AffineEnvironment.transform 4 11 env39973 = env39974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env39973 == env39974) = true)

theorem identity39974 : scanCanonicalize (H12AffineFastState.compose env39974 (packedSelected [0,2,3] rootPS)) = affineNative (2^(5+1) ^^^ 2) := by decide +kernel

theorem selectedBound39974 : packedSelected [0,2,3] rootPS < 2^1333 := by decide +kernel

def env39975 : List Nat := [2,4,8,1,11,2,0,7,2,0,0,7,8,8,9,3,9,2,1,8,4,11,0,2,0,2,1,1,14,10,9,11,6,3,2,3]

theorem envBound39975 : H12AffineFastState.Bounded env39975 := by
  intro p hp
  have h : env39975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39974_39975 : H12AffineEnvironment.transform 5 2 env39974 = env39975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 2 env39974 == env39975) = true)

theorem identity39975 : scanCanonicalize (H12AffineFastState.compose env39975 (packedSelected [0,1,2,10] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound39975 : packedSelected [0,1,2,10] rootPS < 2^1333 := by decide +kernel

def env39976 : List Nat := [2,3,8,1,11,2,0,0,2,0,0,0,8,8,9,3,9,2,1,8,3,11,0,2,0,2,1,1,9,10,9,11,1,3,2,3]

theorem envBound39976 : H12AffineFastState.Bounded env39976 := by
  intro p hp
  have h : env39976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39975_39976 : H12AffineEnvironment.transform 1 3 env39975 = env39976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env39975 == env39976) = true)

theorem identity39976 : scanCanonicalize (H12AffineFastState.compose env39976 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound39976 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39977 : List Nat := [2,3,3,1,0,2,0,0,2,0,0,0,3,3,2,3,2,2,1,3,3,0,0,2,0,2,1,1,2,1,2,0,1,3,2,3]

theorem envBound39977 : H12AffineFastState.Bounded env39977 := by
  intro p hp
  have h : env39977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39976_39977 : H12AffineEnvironment.transform 2 3 env39976 = env39977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env39976 == env39977) = true)

theorem identity39977 : scanCanonicalize (H12AffineFastState.compose env39977 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound39977 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39978 : List Nat := [1,0,0,1,0,1,0,0,1,0,0,0,0,0,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,1,1,0,1,0,1,0]

theorem envBound39978 : H12AffineFastState.Bounded env39978 := by
  intro p hp
  have h : env39978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39977_39978 : H12AffineEnvironment.transform 0 1 env39977 = env39978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env39977 == env39978) = true)

def env39979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169217,98781,8328,64,4510941,163840,17664,283905,168140,4350285,257,21792,46212,243483]

theorem envBound39979 : H12AffineFastState.Bounded env39979 := by
  intro p hp
  have h : env39979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39921_39979 : H12AffineEnvironment.transform 22 169217 env39921 = env39979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env39921 == env39979) = true)

def env39980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169217,98781,8328,64,64605,163840,17664,283905,168140,412109,257,21792,46212,243483]

theorem envBound39980 : H12AffineFastState.Bounded env39980 := by
  intro p hp
  have h : env39980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39979_39980 : H12AffineEnvironment.transform 21 272512 env39979 = env39980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env39979 == env39980) = true)

theorem identity39980 : scanCanonicalize (H12AffineFastState.compose env39980 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound39980 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,165200,272512,169217,21762,8328,64,64605,163840,17664,283905,168140,412109,257,21792,46212,156612]

theorem envBound39981 : H12AffineFastState.Bounded env39981 := by
  intro p hp
  have h : env39981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39980_39981 : H12AffineEnvironment.transform 15 54495 env39980 = env39981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env39980 == env39981) = true)

def env39982 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,165200,272392,169217,21762,8192,64,64605,163840,17664,283905,168004,411973,257,21792,46092,156492]

theorem envBound39982 : H12AffineFastState.Bounded env39982 := by
  intro p hp
  have h : env39982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39981_39982 : H12AffineEnvironment.transform 6 8 env39981 = env39982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39981 == env39982) = true)

theorem identity39982 : scanCanonicalize (H12AffineFastState.compose env39982 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 2421) := by decide +kernel

theorem selectedBound39982 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env39983 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,2421,1025,32769,165200,8573,169217,21762,8192,64,64605,163840,17664,23668,168004,147504,257,21792,46092,156492]

theorem envBound39983 : H12AffineFastState.Bounded env39983 := by
  intro p hp
  have h : env39983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39982_39983 : H12AffineEnvironment.transform 17 2421 env39982 = env39983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2421 env39982 == env39983) = true)

theorem identity39983 : scanCanonicalize (H12AffineFastState.compose env39983 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound39983 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env39984 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,49169,2421,1025,32769,17729,8573,21776,21762,8192,64,64605,16401,17664,23668,20565,32801,257,21792,46092,41821]

theorem envBound39984 : H12AffineFastState.Bounded env39984 := by
  intro p hp
  have h : env39984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39983_39984 : H12AffineEnvironment.transform 16 49169 env39983 = env39984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env39983 == env39984) = true)

theorem identity39984 : scanCanonicalize (H12AffineFastState.compose env39984 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound39984 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env39985 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21760,343,5393,2421,1025,21761,17729,8573,21776,21762,8192,64,10589,16401,17664,23668,20565,21793,257,21792,24844,30301]

theorem envBound39985 : H12AffineFastState.Bounded env39985 := by
  intro p hp
  have h : env39985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39984_39985 : H12AffineEnvironment.transform 14 21760 env39984 = env39985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env39984 == env39985) = true)

def env39986 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,165200,272393,169217,21762,8193,64,64605,163840,17664,283905,168005,411972,257,21792,46093,156493]

theorem envBound39986 : H12AffineFastState.Bounded env39986 := by
  intro p hp
  have h : env39986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39981_39986 : H12AffineEnvironment.transform 6 9 env39981 = env39986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39981 == env39986) = true)

theorem identity39986 : scanCanonicalize (H12AffineFastState.compose env39986 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound39986 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env39987 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,10281,1025,32769,165200,32,169217,21762,8193,64,64605,163840,17664,32040,168005,156013,257,21792,46093,156493]

theorem envBound39987 : H12AffineFastState.Bounded env39987 := by
  intro p hp
  have h : env39987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39986_39987 : H12AffineEnvironment.transform 17 10281 env39986 = env39987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env39986 == env39987) = true)

theorem identity39987 : scanCanonicalize (H12AffineFastState.compose env39987 (packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound39987 : packedSelected [3,4,8,9,12,14,15,16,19,24,28] rootPS < 2^1333 := by decide +kernel

def env39988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,10281,1025,32769,17728,32,21777,21762,8193,64,64605,16400,17664,32040,20565,41341,257,21792,46093,41821]

theorem envBound39988 : H12AffineFastState.Bounded env39988 := by
  intro p hp
  have h : env39988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39987_39988 : H12AffineEnvironment.transform 16 49168 env39987 = env39988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env39987 == env39988) = true)

theorem identity39988 : scanCanonicalize (H12AffineFastState.compose env39988 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound39988 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env39989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29962,24908,10281,1025,8541,17728,32,21777,21762,8193,64,23809,16400,17664,32040,20565,33,257,21792,5457,513]

theorem envBound39989 : H12AffineFastState.Bounded env39989 := by
  intro p hp
  have h : env39989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39988_39989 : H12AffineEnvironment.transform 14 8540 env39988 = env39989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env39988 == env39989) = true)

theorem identity39989 : scanCanonicalize (H12AffineFastState.compose env39989 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39989 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env39990 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8460,29962,24860,10281,1025,8461,17680,32,21777,21762,8193,16,23809,16400,17664,32040,20485,33,257,21792,5377,513]

theorem envBound39990 : H12AffineFastState.Bounded env39990 := by
  intro p hp
  have h : env39990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39989_39990 : H12AffineEnvironment.transform 5 16 env39989 = env39990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39989 == env39990) = true)

theorem identity39990 : scanCanonicalize (H12AffineFastState.compose env39990 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound39990 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env39991 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,21510,16400,2341,1025,1,17680,32,21777,21762,269,16,23809,16400,17664,23588,20485,33,257,21792,5377,513]

theorem envBound39991 : H12AffineFastState.Bounded env39991 := by
  intro p hp
  have h : env39991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39990_39991 : H12AffineEnvironment.transform 12 268 env39990 = env39991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env39990 == env39991) = true)

def env39992 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169217,98781,8328,64,64604,163840,17664,283905,168140,412108,257,21792,46212,243483]

theorem envBound39992 : H12AffineFastState.Bounded env39992 := by
  intro p hp
  have h : env39992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39979_39992 : H12AffineEnvironment.transform 21 272513 env39979 = env39992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env39979 == env39992) = true)

theorem identity39992 : scanCanonicalize (H12AffineFastState.compose env39992 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound39992 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39993 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,115871,272513,120014,98781,8328,64,64604,115151,17664,283905,119043,329731,257,21792,46212,63188]

theorem envBound39993 : H12AffineFastState.Bounded env39993 := by
  intro p hp
  have h : env39993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39992_39993 : H12AffineEnvironment.transform 16 82383 env39992 = env39993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env39992 == env39993) = true)

def env39994 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,115871,272513,119966,98701,8328,16,64524,115103,17664,283905,119043,329731,257,21792,46212,63108]

theorem envBound39994 : H12AffineFastState.Bounded env39994 := by
  intro p hp
  have h : env39994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39993_39994 : H12AffineEnvironment.transform 5 16 env39993 = env39994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39993 == env39994) = true)

theorem identity39994 : scanCanonicalize (H12AffineFastState.compose env39994 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound39994 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env39995 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54278,38297,262144,1025,32769,4249,272513,152,21899,8328,16,64524,5529,17664,283905,1285,318469,257,21792,46212,63108]

theorem envBound39995 : H12AffineFastState.Bounded env39995 := by
  intro p hp
  have h : env39995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39994_39995 : H12AffineEnvironment.transform 15 54278 env39994 = env39995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env39994 == env39995) = true)

theorem identity39995 : scanCanonicalize (H12AffineFastState.compose env39995 (packedSelected [5,8,17,19,24,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound39995 : packedSelected [5,8,17,19,24,28,31] rootPS < 2^1333 := by decide +kernel

def env39996 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,40970,38297,262144,1025,32769,4249,272513,152,8583,8328,16,34816,5529,12556,270605,1285,305161,257,8492,46212,33416]

theorem envBound39996 : H12AffineFastState.Bounded env39996 := by
  intro p hp
  have h : env39996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39995_39996 : H12AffineEnvironment.transform 13 13324 env39995 = env39996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env39995 == env39996) = true)

theorem identity39996 : scanCanonicalize (H12AffineFastState.compose env39996 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10400) := by decide +kernel

theorem selectedBound39996 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env39997 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,32768,40970,38297,10400,1025,32769,4249,33,152,8583,8328,16,34816,5529,12556,2477,1285,32937,257,8492,46212,33416]

theorem envBound39997 : H12AffineFastState.Bounded env39997 := by
  intro p hp
  have h : env39997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39996_39997 : H12AffineEnvironment.transform 17 10400 env39996 = env39997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env39996 == env39997) = true)

theorem identity39997 : scanCanonicalize (H12AffineFastState.compose env39997 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39997 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env39998 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,13324,0,8202,5529,10400,1025,1,4249,33,152,8583,8328,16,2048,5529,12556,2477,1285,169,257,8492,13444,648]

theorem envBound39998 : H12AffineFastState.Bounded env39998 := by
  intro p hp
  have h : env39998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39997_39998 : H12AffineEnvironment.transform 14 0 env39997 = env39998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39997 == env39998) = true)

theorem identity39998 : scanCanonicalize (H12AffineFastState.compose env39998 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound39998 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env39999 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,5512,0,398,5529,2340,1025,1,4249,33,152,3,268,16,2048,5529,4232,2477,1285,169,257,168,5376,648]

theorem envBound39999 : H12AffineFastState.Bounded env39999 := by
  intro p hp
  have h : env39999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39998_39999 : H12AffineEnvironment.transform 12 388 env39998 = env39999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env39998 == env39999) = true)

theorem identity39999 : scanCanonicalize (H12AffineFastState.compose env39999 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound39999 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40000 : List Nat := [2,4,8,16,32,16,128,172,512,1024,2048,4096,40,5156,0,34,5173,2184,1025,1,4249,33,152,3,160,16,2048,5173,4232,2049,1193,169,173,168,5292,648]

theorem envBound40000 : H12AffineFastState.Bounded env40000 := by
  intro p hp
  have h : env40000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39999_40000 : H12AffineEnvironment.transform 7 172 env39999 = env40000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env39999 == env40000) = true)

theorem identity40000 : scanCanonicalize (H12AffineFastState.compose env40000 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound40000 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40001 : List Nat := [2,4,8,16,32,16,41,5,512,1024,2048,4096,40,5156,0,34,5173,2081,1025,1,4144,33,49,3,9,16,2048,5173,4129,2049,1024,0,4,1,5125,545]

theorem envBound40001 : H12AffineFastState.Bounded env40001 := by
  intro p hp
  have h : env40001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40000_40001 : H12AffineEnvironment.transform 6 41 env40000 = env40001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env40000 == env40001) = true)

theorem identity40001 : scanCanonicalize (H12AffineFastState.compose env40001 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40001 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40002 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,4096,9,5125,0,3,5140,2048,1025,1,4113,0,16,3,9,16,2048,5140,4096,2049,1024,0,4,1,5125,512]

theorem envBound40002 : H12AffineFastState.Bounded env40002 := by
  intro p hp
  have h : env40002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40001_40002 : H12AffineEnvironment.transform 4 1 env40001 = env40002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40001 == env40002) = true)

theorem identity40002 : scanCanonicalize (H12AffineFastState.compose env40002 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound40002 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40003 : List Nat := [2,4,8,16,1,16,8,5,512,1024,2048,16,9,1045,0,3,1028,2048,1025,1,1,0,16,3,9,16,2048,1028,16,2049,1024,0,4,1,1045,512]

theorem envBound40003 : H12AffineFastState.Bounded env40003 := by
  intro p hp
  have h : env40003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40002_40003 : H12AffineEnvironment.transform 11 16 env40002 = env40003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env40002 == env40003) = true)

def env40004 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,115871,272513,119967,98700,8328,17,64525,115102,17664,283905,119043,329731,257,21792,46212,63109]

theorem envBound40004 : H12AffineFastState.Bounded env40004 := by
  intro p hp
  have h : env40004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39993_40004 : H12AffineEnvironment.transform 5 17 env39993 = env40004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env39993 == env40004) = true)

theorem identity40004 : scanCanonicalize (H12AffineFastState.compose env40004 (packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8580) := by decide +kernel

theorem selectedBound40004 : packedSelected [3,5,8,10,11,12,15,17,19,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env40005 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,65536,82334,262144,1025,8581,91419,272513,95515,73736,8328,17,23945,90138,17664,283905,94343,329731,257,21792,5376,22273]

theorem envBound40005 : H12AffineFastState.Bounded env40005 := by
  intro p hp
  have h : env40005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40004_40005 : H12AffineEnvironment.transform 14 8580 env40004 = env40005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8580 env40004 == env40005) = true)

theorem identity40005 : scanCanonicalize (H12AffineFastState.compose env40005 (packedSelected [4,7,9,16,18,20,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound40005 : packedSelected [4,7,9,16,18,20,23,27] rootPS < 2^1333 := by decide +kernel

def env40006 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,8580,65536,82334,32041,1025,8581,91419,21928,95515,73736,8328,17,23945,90138,17664,10280,94343,95530,257,21792,5376,22273]

theorem envBound40006 : H12AffineFastState.Bounded env40006 := by
  intro p hp
  have h : env40006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40005_40006 : H12AffineEnvironment.transform 17 32041 env40005 = env40006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env40005 == env40006) = true)

theorem identity40006 : scanCanonicalize (H12AffineFastState.compose env40006 (packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound40006 : packedSelected [0,2,4,6,7,9,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env40007 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13445,8580,65536,79131,2476,1025,8581,70046,8493,65950,73736,8328,17,10508,70815,12677,10280,66562,65967,257,8613,5376,9092]

theorem envBound40007 : H12AffineFastState.Bounded env40007 := by
  intro p hp
  have h : env40007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40006_40007 : H12AffineEnvironment.transform 13 13445 env40006 = env40007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env40006 == env40007) = true)

theorem identity40007 : scanCanonicalize (H12AffineFastState.compose env40007 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound40007 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env40008 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,65536,70814,2476,1025,0,70046,168,65950,65933,269,17,2185,70815,4096,2477,66562,65967,257,32,5376,513]

theorem envBound40008 : H12AffineFastState.Bounded env40008 := by
  intro p hp
  have h : env40008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40007_40008 : H12AffineEnvironment.transform 12 389 env40007 = env40008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env40007 == env40008) = true)

theorem identity40008 : scanCanonicalize (H12AffineFastState.compose env40008 (packedSelected [2,6] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound40008 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40009 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,399,5393,2476,1025,0,4113,168,17,2,269,17,2185,5392,4096,2477,1421,32,257,32,5376,513]

theorem envBound40009 : H12AffineFastState.Bounded env40009 := by
  intro p hp
  have h : env40009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40008_40009 : H12AffineEnvironment.transform 15 399 env40008 = env40009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env40008 == env40009) = true)

theorem identity40009 : scanCanonicalize (H12AffineFastState.compose env40009 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 1938) := by decide +kernel

theorem selectedBound40009 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env40010 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1938,4096,389,5376,1,399,5393,1598,1025,0,4113,168,17,2,269,17,1819,5392,4096,1599,1421,32,257,32,5376,513]

theorem envBound40010 : H12AffineFastState.Bounded env40010 := by
  intro p hp
  have h : env40010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40009_40010 : H12AffineEnvironment.transform 10 1938 env40009 = env40010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1938 env40009 == env40010) = true)

theorem identity40010 : scanCanonicalize (H12AffineFastState.compose env40010 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40010 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env40011 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1598,4096,41,5292,1,35,5309,1598,1025,0,4113,168,17,2,161,17,1719,5308,4096,1599,1057,32,173,32,5292,513]

theorem envBound40011 : H12AffineFastState.Bounded env40011 := by
  intro p hp
  have h : env40011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40010_40011 : H12AffineEnvironment.transform 7 172 env40010 = env40011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40010 == env40011) = true)

theorem identity40011 : scanCanonicalize (H12AffineFastState.compose env40011 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1670) := by decide +kernel

theorem selectedBound40011 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env40012 : List Nat := [2,4,8,16,32,17,128,172,512,1024,1598,1670,41,554,1,35,571,1598,1025,0,1687,168,17,2,161,17,1719,570,1670,1599,1057,32,173,32,554,513]

theorem envBound40012 : H12AffineFastState.Bounded env40012 := by
  intro p hp
  have h : env40012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40011_40012 : H12AffineEnvironment.transform 11 1670 env40011 = env40012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1670 env40011 == env40012) = true)

theorem identity40012 : scanCanonicalize (H12AffineFastState.compose env40012 (packedSelected [2,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40012 : packedSelected [2,7,9] rootPS < 2^1333 := by decide +kernel

def env40013 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1598,1551,41,554,1,35,571,1598,1025,0,1566,33,17,2,40,17,1598,570,1551,1599,1057,32,36,32,554,513]

theorem envBound40013 : H12AffineFastState.Bounded env40013 := by
  intro p hp
  have h : env40013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40012_40013 : H12AffineEnvironment.transform 6 9 env40012 = env40013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40012 == env40013) = true)

def env40014 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,8388608,8590557,8328,64,4510940,8393984,8572929,8830976,168141,12645453,257,21793,46213,243482]

theorem envBound40014 : H12AffineFastState.Bounded env40014 := by
  intro p hp
  have h : env40014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39920_40014 : H12AffineEnvironment.transform 23 8590557 env39920 = env40014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8590557 env39920 == env40014) = true)

def env40015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,4194304,169216,98781,8328,64,4510940,163840,17665,283904,168141,4350285,257,21793,46213,243482]

theorem envBound40015 : H12AffineFastState.Bounded env40015 := by
  intro p hp
  have h : env40015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40014_40015 : H12AffineEnvironment.transform 22 169216 env40014 = env40015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env40014 == env40015) = true)

def env40016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272512,169216,98781,8328,64,64604,163840,17665,283904,168141,412109,257,21793,46213,243482]

theorem envBound40016 : H12AffineFastState.Bounded env40016 := by
  intro p hp
  have h : env40016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40015_40016 : H12AffineEnvironment.transform 21 272512 env40015 = env40016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env40015 == env40016) = true)

theorem identity40016 : scanCanonicalize (H12AffineFastState.compose env40016 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25029) := by decide +kernel

theorem selectedBound40016 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,262144,1025,32769,58517,272512,62661,98781,8328,64,64604,57797,17665,283904,61704,272392,257,21793,46213,120543]

theorem envBound40017 : H12AffineFastState.Bounded env40017 := by
  intro p hp
  have h : env40017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40016_40017 : H12AffineEnvironment.transform 16 25029 env40016 = env40017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25029 env40016 == env40017) = true)

def env40018 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10280,1025,32769,58517,168,62661,98781,8328,64,64604,57797,17665,32040,61704,32,257,21793,46213,120543]

theorem envBound40018 : H12AffineFastState.Bounded env40018 := by
  intro p hp
  have h : env40018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40017_40018 : H12AffineEnvironment.transform 17 10280 env40017 = env40018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env40017 == env40018) = true)

theorem identity40018 : scanCanonicalize (H12AffineFastState.compose env40018 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(14+1) ^^^ 20973) := by decide +kernel

theorem selectedBound40018 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env40019 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20973,65536,25029,10280,1025,20972,13688,168,9512,86064,8328,64,11697,12328,17665,32040,8421,32,257,21793,25960,67378]

theorem envBound40019 : H12AffineFastState.Bounded env40019 := by
  intro p hp
  have h : env40019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40018_40019 : H12AffineEnvironment.transform 14 20973 env40018 = env40019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20973 env40018 == env40019) = true)

theorem identity40019 : scanCanonicalize (H12AffineFastState.compose env40019 (packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound40019 : packedSelected [0,1,2,4,5,6,9,11,12,15,16,17,18,19,24,26,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env40020 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,9528,65536,5392,10280,1025,9529,13688,168,9512,74981,8328,64,11697,12328,12756,2557,8421,32,257,8692,4541,67378]

theorem envBound40020 : H12AffineFastState.Bounded env40020 := by
  intro p hp
  have h : env40020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40019_40020 : H12AffineEnvironment.transform 13 13525 env40019 = env40020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env40019 == env40020) = true)

theorem identity40020 : scanCanonicalize (H12AffineFastState.compose env40020 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound40020 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env40021 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,9528,479,5392,10280,1025,9529,13688,168,9512,9530,8328,64,11697,12328,12756,2557,8421,32,257,8692,4541,1773]

theorem envBound40021 : H12AffineFastState.Bounded env40021 := by
  intro p hp
  have h : env40021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40020_40021 : H12AffineEnvironment.transform 15 479 env40020 = env40021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env40020 == env40021) = true)

theorem identity40021 : scanCanonicalize (H12AffineFastState.compose env40021 (packedSelected [1,2,4,6,8,9,10,11,14,15,18] rootPS)) = affineNative (2^(10+1) ^^^ 445) := by decide +kernel

theorem selectedBound40021 : packedSelected [1,2,4,6,8,9,10,11,14,15,18] rootPS < 2^1333 := by decide +kernel

def env40022 : List Nat := [2,4,8,16,32,64,128,256,512,1024,445,4096,8192,13525,9528,479,5392,8597,1025,9529,13688,168,9512,9530,8328,64,9228,12328,12756,64,8421,32,257,8692,4541,1773]

theorem envBound40022 : H12AffineFastState.Bounded env40022 := by
  intro p hp
  have h : env40022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40021_40022 : H12AffineEnvironment.transform 10 445 env40021 = env40022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 445 env40021 == env40022) = true)

theorem identity40022 : scanCanonicalize (H12AffineFastState.compose env40022 (packedSelected [0,3,4,5,7,10,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound40022 : packedSelected [0,3,4,5,7,10,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40023 : List Nat := [2,4,8,16,32,64,128,256,512,272,445,4096,8192,12741,8232,479,4096,8597,273,8233,12392,168,8248,8234,8328,64,8476,12328,12756,64,8421,32,257,8692,4541,1021]

theorem envBound40023 : H12AffineFastState.Bounded env40023 := by
  intro p hp
  have h : env40023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40022_40023 : H12AffineEnvironment.transform 9 272 env40022 = env40023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env40022 == env40023) = true)

theorem identity40023 : scanCanonicalize (H12AffineFastState.compose env40023 (packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 161) := by decide +kernel

theorem selectedBound40023 : packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS < 2^1333 := by decide +kernel

def env40024 : List Nat := [2,4,8,16,32,64,128,256,512,272,445,4096,161,4452,137,479,4096,308,273,136,4297,168,153,139,41,64,445,4233,4469,64,68,32,257,341,4541,1021]

theorem envBound40024 : H12AffineFastState.Bounded env40024 := by
  intro p hp
  have h : env40024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40023_40024 : H12AffineEnvironment.transform 12 161 env40023 = env40024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 161 env40023 == env40024) = true)

theorem identity40024 : scanCanonicalize (H12AffineFastState.compose env40024 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound40024 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env40025 : List Nat := [2,4,8,16,32,64,128,252,512,236,65,4096,161,4248,137,35,4096,200,237,136,4297,168,153,139,41,64,65,4233,4233,64,68,32,253,169,4161,513]

theorem envBound40025 : H12AffineFastState.Bounded env40025 := by
  intro p hp
  have h : env40025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40024_40025 : H12AffineEnvironment.transform 7 252 env40024 = env40025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env40024 == env40025) = true)

theorem identity40025 : scanCanonicalize (H12AffineFastState.compose env40025 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound40025 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40026 : List Nat := [2,4,8,16,32,64,89,37,512,53,65,4096,120,4161,80,35,4096,17,52,81,4112,113,64,82,41,64,65,4176,4176,64,68,32,36,112,4161,513]

theorem envBound40026 : H12AffineFastState.Bounded env40026 := by
  intro p hp
  have h : env40026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40025_40026 : H12AffineEnvironment.transform 6 89 env40025 = env40026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env40025 == env40026) = true)

theorem identity40026 : scanCanonicalize (H12AffineFastState.compose env40026 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 593) := by decide +kernel

theorem selectedBound40026 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env40027 : List Nat := [2,4,8,16,32,64,89,37,512,53,65,593,120,528,80,35,593,17,52,81,577,113,64,82,41,64,65,513,513,64,68,32,36,112,528,513]

theorem envBound40027 : H12AffineFastState.Bounded env40027 := by
  intro p hp
  have h : env40027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40026_40027 : H12AffineEnvironment.transform 11 593 env40026 = env40027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 593 env40026 == env40027) = true)

theorem identity40027 : scanCanonicalize (H12AffineFastState.compose env40027 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40027 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env40028 : List Nat := [2,4,8,16,32,16,9,37,512,53,17,513,40,528,0,35,513,17,52,1,529,33,16,2,41,16,17,513,513,16,20,32,36,32,528,513]

theorem envBound40028 : H12AffineFastState.Bounded env40028 := by
  intro p hp
  have h : env40028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40027_40028 : H12AffineEnvironment.transform 5 16 env40027 = env40028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40027 == env40028) = true)

theorem identity40028 : scanCanonicalize (H12AffineFastState.compose env40028 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound40028 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40029 : List Nat := [2,4,8,11,32,11,9,37,512,46,10,513,40,523,0,35,513,10,47,1,522,33,11,2,41,11,10,513,513,11,15,32,36,32,523,513]

theorem envBound40029 : H12AffineFastState.Bounded env40029 := by
  intro p hp
  have h : env40029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40028_40029 : H12AffineEnvironment.transform 3 11 env40028 = env40029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env40028 == env40029) = true)

theorem identity40029 : scanCanonicalize (H12AffineFastState.compose env40029 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound40029 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40030 : List Nat := [2,4,3,0,32,0,2,37,512,37,1,513,35,512,0,35,513,1,36,1,513,33,0,2,34,0,1,513,513,0,4,32,36,32,512,513]

theorem envBound40030 : H12AffineFastState.Bounded env40030 := by
  intro p hp
  have h : env40030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40029_40030 : H12AffineEnvironment.transform 2 3 env40029 = env40030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env40029 == env40030) = true)

theorem identity40030 : scanCanonicalize (H12AffineFastState.compose env40030 (packedSelected [7] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound40030 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env40031 : List Nat := [2,4,3,0,32,0,2,37,0,37,1,1,35,0,0,35,1,1,36,1,1,33,0,2,34,0,1,1,1,0,4,32,36,32,0,1]

theorem envBound40031 : H12AffineFastState.Bounded env40031 := by
  intro p hp
  have h : env40031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40030_40031 : H12AffineEnvironment.transform 8 0 env40030 = env40031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env40030 == env40031) = true)

def env40032 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25029,10281,1025,32769,58517,169,62661,98781,8328,64,64604,57797,17665,32041,61704,33,257,21793,46213,120543]

theorem envBound40032 : H12AffineFastState.Bounded env40032 := by
  intro p hp
  have h : env40032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40017_40032 : H12AffineEnvironment.transform 17 10281 env40017 = env40032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env40017 == env40032) = true)

theorem identity40032 : scanCanonicalize (H12AffineFastState.compose env40032 (packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 21727) := by decide +kernel

theorem selectedBound40032 : packedSelected [0,2,4,6,8,9,16,23,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env40033 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,21727,25029,10281,1025,32769,58517,169,62661,54530,8328,64,64604,57797,17665,32041,61704,33,257,21793,46213,33280]

theorem envBound40033 : H12AffineFastState.Bounded env40033 := by
  intro p hp
  have h : env40033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40032_40033 : H12AffineEnvironment.transform 15 21727 env40032 = env40033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21727 env40032 == env40033) = true)

theorem identity40033 : scanCanonicalize (H12AffineFastState.compose env40033 (packedSelected [0,2,4,6,8,9,11,17,18,20,27,28,31] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound40033 : packedSelected [0,2,4,6,8,9,11,17,18,20,27,28,31] rootPS < 2^1333 := by decide +kernel

def env40034 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,32768,21727,16537,2421,1025,32769,50633,169,54681,54530,468,64,56576,49305,17665,23669,53332,33,257,21793,38361,33280]

theorem envBound40034 : H12AffineFastState.Bounded env40034 := by
  intro p hp
  have h : env40034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40033_40034 : H12AffineEnvironment.transform 12 348 env40033 = env40034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env40033 == env40034) = true)

theorem identity40034 : scanCanonicalize (H12AffineFastState.compose env40034 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound40034 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env40035 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,1,21727,16537,2421,1025,0,17864,169,21912,21763,468,64,23809,16536,17665,23669,20565,33,257,21793,5592,513]

theorem envBound40035 : H12AffineFastState.Bounded env40035 := by
  intro p hp
  have h : env40035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40034_40035 : H12AffineEnvironment.transform 14 1 env40034 = env40035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env40034 == env40035) = true)

theorem identity40035 : scanCanonicalize (H12AffineFastState.compose env40035 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40035 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env40036 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,1,21647,16537,2341,1025,0,17816,169,21912,21763,388,16,23809,16536,17665,23589,20485,33,257,21793,5512,513]

theorem envBound40036 : H12AffineFastState.Bounded env40036 := by
  intro p hp
  have h : env40036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40035_40036 : H12AffineEnvironment.transform 5 16 env40035 = env40036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40035 == env40036) = true)

theorem identity40036 : scanCanonicalize (H12AffineFastState.compose env40036 (packedSelected [3,4,5,9,10,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound40036 : packedSelected [3,4,5,9,10,14,16] rootPS < 2^1333 := by decide +kernel

def env40037 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,5513,1,262,5392,2341,1025,0,4113,169,17,138,388,16,2184,5393,4232,2476,1420,33,257,168,5512,513]

theorem envBound40037 : H12AffineFastState.Bounded env40037 := by
  intro p hp
  have h : env40037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40036_40037 : H12AffineEnvironment.transform 13 5513 env40036 = env40037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env40036 == env40037) = true)

theorem identity40037 : scanCanonicalize (H12AffineFastState.compose env40037 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3857) := by decide +kernel

theorem selectedBound40037 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env40038 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3857,268,2712,1,262,2561,2341,1025,0,3840,169,17,138,388,16,2184,2560,3993,2476,1420,33,257,168,2713,513]

theorem envBound40038 : H12AffineFastState.Bounded env40038 := by
  intro p hp
  have h : env40038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40037_40038 : H12AffineEnvironment.transform 11 3857 env40037 = env40038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3857 env40037 == env40038) = true)

theorem identity40038 : scanCanonicalize (H12AffineFastState.compose env40038 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 168) := by decide +kernel

theorem selectedBound40038 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env40039 : List Nat := [2,4,8,16,32,16,128,256,512,1024,168,1977,268,560,1,262,681,397,1025,0,1960,169,17,138,388,16,32,680,1841,260,1420,33,257,168,561,513]

theorem envBound40039 : H12AffineFastState.Bounded env40039 := by
  intro p hp
  have h : env40039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40038_40039 : H12AffineEnvironment.transform 10 168 env40038 = env40039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 168 env40038 == env40039) = true)

theorem identity40039 : scanCanonicalize (H12AffineFastState.compose env40039 (packedSelected [1,8,11] rootPS)) = affineNative (2^(9+1) ^^^ 952) := by decide +kernel

theorem selectedBound40039 : packedSelected [1,8,11] rootPS < 2^1333 := by decide +kernel

def env40040 : List Nat := [2,4,8,16,32,16,128,256,512,952,168,1,268,560,1,262,681,397,953,0,16,169,17,138,388,16,32,680,137,260,564,33,257,168,561,513]

theorem envBound40040 : H12AffineFastState.Bounded env40040 := by
  intro p hp
  have h : env40040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40039_40040 : H12AffineEnvironment.transform 9 952 env40039 = env40040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 952 env40039 == env40040) = true)

theorem identity40040 : scanCanonicalize (H12AffineFastState.compose env40040 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound40040 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env40041 : List Nat := [2,4,8,16,32,16,128,172,512,532,168,1,160,560,1,170,681,33,533,0,16,169,17,138,40,16,32,680,137,168,564,33,173,168,561,513]

theorem envBound40041 : H12AffineFastState.Bounded env40041 := by
  intro p hp
  have h : env40041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40040_40041 : H12AffineEnvironment.transform 7 172 env40040 = env40041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env40040 == env40041) = true)

theorem identity40041 : scanCanonicalize (H12AffineFastState.compose env40041 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound40041 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env40042 : List Nat := [2,4,8,16,1,16,128,141,512,532,137,1,129,529,1,139,648,0,533,0,16,136,17,138,9,16,1,649,137,137,533,0,140,137,528,513]

theorem envBound40042 : H12AffineFastState.Bounded env40042 := by
  intro p hp
  have h : env40042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40041_40042 : H12AffineEnvironment.transform 4 1 env40041 = env40042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env40041 == env40042) = true)

theorem identity40042 : scanCanonicalize (H12AffineFastState.compose env40042 (packedSelected [0,1,4,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound40042 : packedSelected [0,1,4,8,12] rootPS < 2^1333 := by decide +kernel

def env40043 : List Nat := [2,4,8,16,1,16,9,4,512,532,0,1,8,529,1,2,513,0,533,0,16,1,17,3,9,16,1,512,0,0,533,0,5,0,528,513]

theorem envBound40043 : H12AffineFastState.Bounded env40043 := by
  intro p hp
  have h : env40043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40042_40043 : H12AffineEnvironment.transform 6 9 env40042 = env40043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40042 == env40043) = true)

theorem identity40043 : scanCanonicalize (H12AffineFastState.compose env40043 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound40043 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env40044 : List Nat := [2,4,8,16,1,16,9,4,17,5,0,1,8,0,1,2,16,0,4,0,16,1,17,3,9,16,1,17,0,0,4,0,5,0,1,16]

theorem envBound40044 : H12AffineFastState.Bounded env40044 := by
  intro p hp
  have h : env40044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40043_40044 : H12AffineEnvironment.transform 8 17 env40043 = env40044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env40043 == env40044) = true)

def env40045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,165200,272513,169216,98781,8328,64,64605,163840,17665,283904,168141,412108,257,21793,46213,243482]

theorem envBound40045 : H12AffineFastState.Bounded env40045 := by
  intro p hp
  have h : env40045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40015_40045 : H12AffineEnvironment.transform 21 272513 env40015 = env40045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env40015 == env40045) = true)

theorem identity40045 : scanCanonicalize (H12AffineFastState.compose env40045 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound40045 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env40046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,160132,272513,156116,95497,8328,64,2185,160980,17665,283904,156697,412108,257,21793,16465,213966]

theorem envBound40046 : H12AffineFastState.Bounded env40046 := by
  intro p hp
  have h : env40046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40045_40046 : H12AffineEnvironment.transform 14 29908 env40045 = env40046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env40045 == env40046) = true)

def env40047 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,262144,1025,29789,160012,272393,155996,95497,8192,64,2049,160860,17665,283904,156697,411972,257,21793,16465,213830]

theorem envBound40047 : H12AffineFastState.Bounded env40047 := by
  intro p hp
  have h : env40047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40046_40047 : H12AffineEnvironment.transform 6 8 env40046 = env40047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env40046 == env40047) = true)

theorem identity40047 : scanCanonicalize (H12AffineFastState.compose env40047 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound40047 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40048 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,65536,131072,146745,1025,29789,160012,136496,155996,95497,8192,64,2049,160860,17665,157753,156697,29821,257,21793,16465,213830]

theorem envBound40048 : H12AffineFastState.Bounded env40048 := by
  intro p hp
  have h : env40048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40047_40048 : H12AffineEnvironment.transform 17 146745 env40047 = env40048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env40047 == env40048) = true)

theorem identity40048 : scanCanonicalize (H12AffineFastState.compose env40048 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound40048 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env40049 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,65536,131072,138340,1025,21760,151633,136496,147457,87124,349,64,2049,152833,17665,149860,148804,21792,257,21793,16465,213830]

theorem envBound40049 : H12AffineFastState.Bounded env40049 := by
  intro p hp
  have h : env40049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40048_40049 : H12AffineEnvironment.transform 12 349 env40048 = env40049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env40048 == env40049) = true)

theorem identity40049 : scanCanonicalize (H12AffineFastState.compose env40049 (packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound40049 : packedSelected [3,4,5,9,10,12,14,15,16,17,18,23] rootPS < 2^1333 := by decide +kernel

def env40050 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,21761,114,131072,138340,1025,21760,151633,136496,147457,21542,349,64,2049,152833,17665,149860,148804,21792,257,21793,16465,148276]

theorem envBound40050 : H12AffineFastState.Bounded env40050 := by
  intro p hp
  have h : env40050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40049_40050 : H12AffineEnvironment.transform 15 114 env40049 = env40050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env40049 == env40050) = true)

theorem identity40050 : scanCanonicalize (H12AffineFastState.compose env40050 (packedSelected [0,1,2,5,6,7,8,11,18,20,24] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound40050 : packedSelected [0,1,2,5,6,7,8,11,18,20,24] rootPS < 2^1333 := by decide +kernel

def env40051 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,372,114,131072,138340,1025,373,132132,136496,136308,83,349,64,2049,131444,4468,138513,135473,341,257,340,5156,137025]

theorem envBound40051 : H12AffineFastState.Bounded env40051 := by
  intro p hp
  have h : env40051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40050_40051 : H12AffineEnvironment.transform 13 5237 env40050 = env40051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env40050 == env40051) = true)

theorem identity40051 : scanCanonicalize (H12AffineFastState.compose env40051 (packedSelected [3,5,10,12,15,17] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound40051 : packedSelected [3,5,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env40052 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5237,372,114,5172,2128,1025,373,4112,260,64,83,349,64,2049,5440,4468,2341,1285,341,257,340,5156,885]

theorem envBound40052 : H12AffineFastState.Bounded env40052 := by
  intro p hp
  have h : env40052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40051_40052 : H12AffineEnvironment.transform 16 5172 env40051 = env40052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env40051 == env40052) = true)

theorem identity40052 : scanCanonicalize (H12AffineFastState.compose env40052 (packedSelected [1,4,8,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound40052 : packedSelected [1,4,8,9,10,12] rootPS < 2^1333 := by decide +kernel

def env40053 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2065,349,3172,372,114,3109,2128,1025,373,2049,260,64,83,349,64,2049,3409,2405,2341,1285,341,257,340,3125,885]

theorem envBound40053 : H12AffineFastState.Bounded env40053 := by
  intro p hp
  have h : env40053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40052_40053 : H12AffineEnvironment.transform 11 2065 env40052 = env40053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env40052 == env40053) = true)

theorem identity40053 : scanCanonicalize (H12AffineFastState.compose env40053 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound40053 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env40054 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2065,349,2129,372,114,2064,2128,52,373,2049,260,64,83,349,64,2049,2404,2405,2341,304,341,257,340,2048,885]

theorem envBound40054 : H12AffineFastState.Bounded env40054 := by
  intro p hp
  have h : env40054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40053_40054 : H12AffineEnvironment.transform 9 53 env40053 = env40054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env40053 == env40054) = true)

theorem identity40054 : scanCanonicalize (H12AffineFastState.compose env40054 (packedSelected [0,2,3,7,8,9] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound40054 : packedSelected [0,2,3,7,8,9] rootPS < 2^1333 := by decide +kernel

def env40055 : List Nat := [2,4,8,16,32,64,8,256,373,53,2048,2065,349,2129,372,114,2064,2128,52,373,2049,260,64,83,349,64,2049,2404,2405,2341,304,341,257,340,2048,0]

theorem envBound40055 : H12AffineFastState.Bounded env40055 := by
  intro p hp
  have h : env40055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40054_40055 : H12AffineEnvironment.transform 8 373 env40054 = env40055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env40054 == env40055) = true)

theorem identity40055 : scanCanonicalize (H12AffineFastState.compose env40055 (packedSelected [0,1,2,3,4,5,6,8] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound40055 : packedSelected [0,1,2,3,4,5,6,8] rootPS < 2^1333 := by decide +kernel

def env40056 : List Nat := [2,4,8,16,32,64,8,256,373,53,293,308,349,372,372,114,309,373,52,373,292,260,64,83,349,64,292,65,64,0,304,341,257,340,293,0]

theorem envBound40056 : H12AffineFastState.Bounded env40056 := by
  intro p hp
  have h : env40056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40055_40056 : H12AffineEnvironment.transform 10 293 env40055 = env40056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env40055 == env40056) = true)

theorem identity40056 : scanCanonicalize (H12AffineFastState.compose env40056 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40056 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env40057 : List Nat := [2,4,8,16,32,16,8,256,293,53,293,308,269,292,292,34,309,293,52,293,292,260,16,3,269,16,292,17,16,0,304,261,257,260,293,0]

theorem envBound40057 : H12AffineFastState.Bounded env40057 := by
  intro p hp
  have h : env40057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40056_40057 : H12AffineEnvironment.transform 5 16 env40056 = env40057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40056 == env40057) = true)

theorem identity40057 : scanCanonicalize (H12AffineFastState.compose env40057 (packedSelected [0,2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound40057 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env40058 : List Nat := [2,4,8,16,32,16,8,36,1,53,1,16,41,0,0,34,17,1,52,1,0,32,16,3,41,16,0,17,16,0,20,33,37,32,1,0]

theorem envBound40058 : H12AffineFastState.Bounded env40058 := by
  intro p hp
  have h : env40058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40057_40058 : H12AffineEnvironment.transform 7 36 env40057 = env40058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env40057 == env40058) = true)

theorem identity40058 : scanCanonicalize (H12AffineFastState.compose env40058 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound40058 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env40059 : List Nat := [2,4,8,16,16,16,8,20,1,5,1,16,25,0,0,18,17,1,4,1,0,16,16,3,25,16,0,17,16,0,20,17,21,16,1,0]

theorem envBound40059 : H12AffineFastState.Bounded env40059 := by
  intro p hp
  have h : env40059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40058_40059 : H12AffineEnvironment.transform 4 16 env40058 = env40059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env40058 == env40059) = true)

theorem identity40059 : scanCanonicalize (H12AffineFastState.compose env40059 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound40059 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env40060 : List Nat := [2,4,8,1,1,1,8,5,1,5,1,1,8,0,0,3,0,1,4,1,0,1,1,3,8,1,0,0,1,0,5,0,4,1,1,0]

theorem envBound40060 : H12AffineFastState.Bounded env40060 := by
  intro p hp
  have h : env40060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40059_40060 : H12AffineEnvironment.transform 3 1 env40059 = env40060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env40059 == env40060) = true)

def env40061 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,262144,1025,29788,160013,272392,155997,95497,8193,64,2048,160861,17665,283904,156697,411973,257,21793,16465,213831]

theorem envBound40061 : H12AffineFastState.Bounded env40061 := by
  intro p hp
  have h : env40061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40046_40061 : H12AffineEnvironment.transform 6 9 env40046 = env40061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env40046 == env40061) = true)

theorem identity40061 : scanCanonicalize (H12AffineFastState.compose env40061 (packedSelected [0,9,14,16,20,22,27,35] rootPS)) = affineNative (2^(17+1) ^^^ 223599) := by decide +kernel

theorem selectedBound40061 : packedSelected [0,9,14,16,20,22,27,35] rootPS < 2^1333 := by decide +kernel

def env40062 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,223599,1025,29788,160013,213351,155997,95497,8193,64,2048,160861,17665,212079,156697,73770,257,21793,16465,213831]

theorem envBound40062 : H12AffineFastState.Bounded env40062 := by
  intro p hp
  have h : env40062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40061_40062 : H12AffineEnvironment.transform 17 223599 env40061 = env40062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223599 env40061 == env40062) = true)

theorem identity40062 : scanCanonicalize (H12AffineFastState.compose env40062 (packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 90187) := by decide +kernel

theorem selectedBound40062 : packedSelected [0,4,5,7,9,10,12,20,23,24] rootPS < 2^1333 := by decide +kernel

def env40063 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,90187,2340,1025,29788,69958,8492,65814,95497,8193,64,2048,70678,17665,23588,66642,73770,257,21793,16465,8972]

theorem envBound40063 : H12AffineFastState.Bounded env40063 := by
  intro p hp
  have h : env40063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40062_40063 : H12AffineEnvironment.transform 16 90187 env40062 = env40063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90187 env40062 == env40063) = true)

theorem identity40063 : scanCanonicalize (H12AffineFastState.compose env40063 (packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound40063 : packedSelected [0,2,4,6,7,9,12,14,15,16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env40064 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,65536,90139,2340,1025,29708,69910,8492,65814,95497,8193,16,2048,70678,17665,23588,66562,73770,257,21793,16385,8972]

theorem envBound40064 : H12AffineFastState.Bounded env40064 := by
  intro p hp
  have h : env40064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40063_40064 : H12AffineEnvironment.transform 5 16 env40063 = env40064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env40063 == env40064) = true)

theorem identity40064 : scanCanonicalize (H12AffineFastState.compose env40064 (packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound40064 : packedSelected [1,2,3,4,5,6,8,9,11,15,17] rootPS < 2^1333 := by decide +kernel

def env40065 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,29709,29962,5393,2340,1025,29708,25628,8492,29724,3,8193,16,2048,24860,17665,23588,28936,21792,257,21793,16385,8972]

theorem envBound40065 : H12AffineFastState.Bounded env40065 := by
  intro p hp
  have h : env40065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40064_40065 : H12AffineEnvironment.transform 15 29962 env40064 = env40065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env40064 == env40065) = true)

theorem identity40065 : scanCanonicalize (H12AffineFastState.compose env40065 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound40065 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env40066 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,5376,8461,8202,5393,2340,1025,8460,12572,8492,8476,3,8193,16,2048,13340,4097,2340,9224,32,257,33,5377,8972]

theorem envBound40066 : H12AffineFastState.Bounded env40066 := by
  intro p hp
  have h : env40066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40065_40066 : H12AffineEnvironment.transform 13 5376 env40065 = env40066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env40065 == env40066) = true)

theorem identity40066 : scanCanonicalize (H12AffineFastState.compose env40066 (packedSelected [6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound40066 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env40067 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,5157,8232,8202,5172,2049,1025,8233,12345,8201,8249,3,8193,16,2048,13340,4097,2049,9224,32,36,33,5156,8745]

theorem envBound40067 : H12AffineFastState.Bounded env40067 := by
  intro p hp
  have h : env40067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans40066_40067 : H12AffineEnvironment.transform 7 37 env40066 = env40067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env40066 == env40067) = true)

theorem identity40067 : scanCanonicalize (H12AffineFastState.compose env40067 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound40067 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env40068 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,41,5157,1,35,5172,2049,1025,0,4112,32,16,3,40,16,2048,5173,4097,2049,1057,32,36,33,5156,512]

theorem envBound40068 : H12AffineFastState.Bounded env40068 := by
  intro p hp
  have h : env40068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1