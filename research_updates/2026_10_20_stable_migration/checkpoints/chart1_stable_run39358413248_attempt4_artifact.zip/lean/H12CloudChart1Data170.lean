import H12CloudChart1Data169

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def leafEnv43101 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,42,268,33,0,263,43,293,46,1,261,33,11,2,299,268,1,10,0,42,43,293,299,33,256,32,4,263,33,302,1,261,0]

def active43101 : List Nat := [0,1,2,4,7]

def tree43101 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43101 : H12WitnessSearch.Good tree43101 := H12GlobalWitnessIndex.good

theorem leafIdentity43101 : H12AffineFastState.composeSystem env43101 rootObs = leafEnv43101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43101 rootObs == leafEnv43101) = true)

theorem terminalChecked43101 : H12PackedTerminal.terminalCheckFast leafEnv43101 active43101 tree43101 = true := by decide +kernel

def env43102 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,268,32,0,263,49,293,52,1,261,33,16,2,268,17,0,48,48,293,305,33,256,32,32,308]

theorem envBound43102 : H12AffineFastState.Bounded env43102 := by
  intro p hp
  have h : env43102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43099_43102 : H12AffineEnvironment.transform 8 309 env43099 = env43102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env43099 == env43102) = true)

theorem identity43102 : scanCanonicalize (H12AffineFastState.compose env43102 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43102 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43103 : List Nat := [2,4,8,16,0,17,8,256,277,20,0,17,268,0,0,263,17,261,20,1,261,1,16,2,268,17,0,16,16,261,273,1,256,0,0,276]

theorem envBound43103 : H12AffineFastState.Bounded env43103 := by
  intro p hp
  have h : env43103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43102_43103 : H12AffineEnvironment.transform 4 0 env43102 = env43103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43102 == env43103) = true)

def leafEnv43103 : List Nat := [2,4,8,16,0,17,8,256,277,20,0,17,268,0,0,263,17,261,20,1,261,1,16,2,273,268,1,17,0,16,16,261,273,1,256,0,4,263,0,276,1,261,0]

def active43103 : List Nat := [0,1,2,3,7]

def tree43103 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43103 : H12WitnessSearch.Good tree43103 := H12GlobalWitnessIndex.good

theorem leafIdentity43103 : H12AffineFastState.composeSystem env43103 rootObs = leafEnv43103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43103 rootObs == leafEnv43103) = true)

theorem terminalChecked43103 : H12PackedTerminal.terminalCheckFast leafEnv43103 active43103 tree43103 = true := by decide +kernel

def env43104 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,268,2836,0,263,2821,2341,1024,1,3589,33,16,2,268,17,2048,2820,3888,2341,1285,33,256,32,2836,513]

theorem envBound43104 : H12AffineFastState.Bounded env43104 := by
  intro p hp
  have h : env43104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43090_43104 : H12AffineEnvironment.transform 11 3889 env43090 = env43104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env43090 == env43104) = true)

def env43105 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,268,1044,0,263,1029,1573,1024,1,261,33,16,2,268,17,1792,1028,48,1573,1285,33,256,32,1044,513]

theorem envBound43105 : H12AffineFastState.Bounded env43105 := by
  intro p hp
  have h : env43105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43104_43105 : H12AffineEnvironment.transform 10 1792 env43104 = env43105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env43104 == env43105) = true)

theorem identity43105 : scanCanonicalize (H12AffineFastState.compose env43105 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound43105 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43106 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,49,268,561,0,263,544,0,549,1,261,33,16,2,268,17,293,545,48,0,800,33,256,32,561,513]

theorem envBound43106 : H12AffineFastState.Bounded env43106 := by
  intro p hp
  have h : env43106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43105_43106 : H12AffineEnvironment.transform 9 549 env43105 = env43106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env43105 == env43106) = true)

def env43107 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,49,268,33,0,263,48,0,53,1,261,33,16,2,268,17,293,49,48,0,304,33,256,32,33,17]

theorem envBound43107 : H12AffineFastState.Bounded env43107 := by
  intro p hp
  have h : env43107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43106_43107 : H12AffineEnvironment.transform 8 16 env43106 = env43107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env43106 == env43107) = true)

theorem identity43107 : scanCanonicalize (H12AffineFastState.compose env43107 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43107 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43108 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,268,33,0,263,42,0,47,1,261,33,10,2,268,11,293,43,42,0,298,33,256,32,33,11]

theorem envBound43108 : H12AffineFastState.Bounded env43108 := by
  intro p hp
  have h : env43108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43107_43108 : H12AffineEnvironment.transform 3 10 env43107 = env43108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43107 == env43108) = true)

def leafEnv43108 : List Nat := [2,4,8,10,32,11,8,256,10,47,293,43,268,33,0,263,42,0,47,1,261,33,10,2,298,268,1,11,293,43,42,0,298,33,256,32,4,263,33,11,1,261,0]

def active43108 : List Nat := [0,1,2,4,7]

def tree43108 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43108 : H12WitnessSearch.Good tree43108 := H12GlobalWitnessIndex.good

theorem leafIdentity43108 : H12AffineFastState.composeSystem env43108 rootObs = leafEnv43108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43108 rootObs == leafEnv43108) = true)

theorem terminalChecked43108 : H12PackedTerminal.terminalCheckFast leafEnv43108 active43108 tree43108 = true := by decide +kernel

def env43109 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,268,32,0,263,49,0,52,1,261,33,16,2,268,17,293,48,48,0,305,33,256,32,32,16]

theorem envBound43109 : H12AffineFastState.Bounded env43109 := by
  intro p hp
  have h : env43109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43106_43109 : H12AffineEnvironment.transform 8 17 env43106 = env43109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43106 == env43109) = true)

theorem identity43109 : scanCanonicalize (H12AffineFastState.compose env43109 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43109 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43110 : List Nat := [2,4,8,16,32,17,8,5,17,52,32,49,9,32,0,2,49,0,52,1,0,33,16,2,9,17,32,48,48,0,52,33,5,32,32,16]

theorem envBound43110 : H12AffineFastState.Bounded env43110 := by
  intro p hp
  have h : env43110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43109_43110 : H12AffineEnvironment.transform 7 5 env43109 = env43110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43109 == env43110) = true)

def leafEnv43110 : List Nat := [2,4,8,16,32,17,8,5,17,52,32,49,9,32,0,2,49,0,52,1,0,33,16,2,52,9,1,17,32,48,48,0,52,33,5,32,4,2,32,16,1,0,0]

def active43110 : List Nat := [0,1,2,3,4]

def tree43110 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43110 : H12WitnessSearch.Good tree43110 := H12GlobalWitnessIndex.good

theorem leafIdentity43110 : H12AffineFastState.composeSystem env43110 rootObs = leafEnv43110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43110 rootObs == leafEnv43110) = true)

theorem terminalChecked43110 : H12PackedTerminal.terminalCheckFast leafEnv43110 active43110 tree43110 = true := by decide +kernel

def env43111 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,268,1045,0,263,1028,1572,1024,1,260,33,16,2,268,17,1793,1029,49,1572,1285,33,256,32,1045,513]

theorem envBound43111 : H12AffineFastState.Bounded env43111 := by
  intro p hp
  have h : env43111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43104_43111 : H12AffineEnvironment.transform 10 1793 env43104 = env43111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env43104 == env43111) = true)

theorem identity43111 : scanCanonicalize (H12AffineFastState.compose env43111 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 308) := by decide +kernel

theorem selectedBound43111 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43112 : List Nat := [2,4,8,16,32,17,8,256,308,1024,1077,48,268,1045,0,263,1028,1296,1024,1,260,33,16,2,268,17,1077,1029,49,1296,1285,33,256,32,1045,309]

theorem envBound43112 : H12AffineFastState.Bounded env43112 := by
  intro p hp
  have h : env43112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43111_43112 : H12AffineEnvironment.transform 8 308 env43111 = env43112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env43111 == env43112) = true)

def env43113 : List Nat := [2,4,8,16,32,17,8,256,308,52,1,48,268,33,0,263,48,292,52,1,260,33,16,2,268,17,1,49,49,292,305,33,256,32,33,309]

theorem envBound43113 : H12AffineFastState.Bounded env43113 := by
  intro p hp
  have h : env43113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43112_43113 : H12AffineEnvironment.transform 9 52 env43112 = env43113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43112 == env43113) = true)

theorem identity43113 : scanCanonicalize (H12AffineFastState.compose env43113 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43113 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43114 : List Nat := [2,4,8,16,0,17,8,256,276,20,1,16,268,1,0,263,16,260,20,1,260,1,16,2,268,17,1,17,17,260,273,1,256,0,1,277]

theorem envBound43114 : H12AffineFastState.Bounded env43114 := by
  intro p hp
  have h : env43114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43113_43114 : H12AffineEnvironment.transform 4 0 env43113 = env43114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43113 == env43114) = true)

def leafEnv43114 : List Nat := [2,4,8,16,0,17,8,256,276,20,1,16,268,1,0,263,16,260,20,1,260,1,16,2,273,268,1,17,1,17,17,260,273,1,256,0,4,263,1,277,1,260,0]

def active43114 : List Nat := [0,1,2,3,7]

def tree43114 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43114 : H12WitnessSearch.Good tree43114 := H12GlobalWitnessIndex.good

theorem leafIdentity43114 : H12AffineFastState.composeSystem env43114 rootObs = leafEnv43114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43114 rootObs == leafEnv43114) = true)

theorem terminalChecked43114 : H12PackedTerminal.terminalCheckFast leafEnv43114 active43114 tree43114 = true := by decide +kernel

def env43115 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,268,32,0,263,49,293,53,1,260,33,16,2,268,17,0,48,49,293,304,33,256,32,32,309]

theorem envBound43115 : H12AffineFastState.Bounded env43115 := by
  intro p hp
  have h : env43115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43112_43115 : H12AffineEnvironment.transform 9 53 env43112 = env43115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43112 == env43115) = true)

theorem identity43115 : scanCanonicalize (H12AffineFastState.compose env43115 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43115 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43116 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,268,32,0,263,42,293,46,1,260,33,11,2,268,10,0,43,42,293,299,33,256,32,32,302]

theorem envBound43116 : H12AffineFastState.Bounded env43116 := by
  intro p hp
  have h : env43116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43115_43116 : H12AffineEnvironment.transform 3 11 env43115 = env43116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43115 == env43116) = true)

def leafEnv43116 : List Nat := [2,4,8,11,32,10,8,256,303,46,0,43,268,32,0,263,42,293,46,1,260,33,11,2,299,268,1,10,0,43,42,293,299,33,256,32,4,263,32,302,1,260,0]

def active43116 : List Nat := [0,1,2,4,7]

def tree43116 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood43116 : H12WitnessSearch.Good tree43116 := H12GlobalWitnessIndex.good

theorem leafIdentity43116 : H12AffineFastState.composeSystem env43116 rootObs = leafEnv43116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env43116 rootObs == leafEnv43116) = true)

theorem terminalChecked43116 : H12PackedTerminal.terminalCheckFast leafEnv43116 active43116 tree43116 = true := by decide +kernel

def env43117 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,17,16777216,8193,64,21479441,18973701,2118976,442384,16876545,23160136,256,18990132,18949401,16819038]

theorem envBound43117 : H12AffineFastState.Bounded env43117 := by
  intro p hp
  have h : env43117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42974_43117 : H12AffineEnvironment.transform 6 9 env42974 = env43117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env42974 == env43117) = true)

theorem identity43117 : scanCanonicalize (H12AffineFastState.compose env43117 (packedSelected [17,21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound43117 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env43118 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1024,32769,2097152,4194304,17,16777216,8193,64,21186916,18973701,2118976,149861,16876545,23160136,256,18990132,18949401,16819038]

theorem envBound43118 : H12AffineFastState.Bounded env43118 := by
  intro p hp
  have h : env43118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43117_43118 : H12AffineEnvironment.transform 17 35189 env43117 = env43118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env43117 == env43118) = true)

theorem identity43118 : scanCanonicalize (H12AffineFastState.compose env43118 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(23+1) ^^^ 246085) := by decide +kernel

theorem selectedBound43118 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env43119 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35189,1024,32769,2097152,4194304,17,246085,8193,64,4229153,2245952,2118976,149861,148804,6464525,256,2229617,2286684,221723]

theorem envBound43119 : H12AffineFastState.Bounded env43119 := by
  intro p hp
  have h : env43119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43118_43119 : H12AffineEnvironment.transform 23 246085 env43118 = env43119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 246085 env43118 == env43119) = true)

def env43120 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35189,1024,32769,2097152,4194304,17,98645,8193,64,4229153,2098512,2118976,2421,1364,6349853,256,2114913,2139212,74251]

theorem envBound43120 : H12AffineFastState.Bounded env43120 := by
  intro p hp
  have h : env43120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43119_43120 : H12AffineEnvironment.transform 16 16400 env43119 = env43120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env43119 == env43120) = true)

theorem identity43120 : scanCanonicalize (H12AffineFastState.compose env43120 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43120 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env43121 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1024,32769,2097152,4194304,17,41311,8193,64,4229153,2098512,2118976,2421,1364,6349853,256,2114913,2139212,513]

theorem envBound43121 : H12AffineFastState.Bounded env43121 := by
  intro p hp
  have h : env43121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43120_43121 : H12AffineEnvironment.transform 15 8202 env43120 = env43121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43120 == env43121) = true)

theorem identity43121 : scanCanonicalize (H12AffineFastState.compose env43121 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound43121 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43122 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1024,32769,2097152,41341,17,41311,8193,64,10588,2098512,2118976,2421,1364,2114912,256,2114913,2139212,513]

theorem envBound43122 : H12AffineFastState.Bounded env43122 := by
  intro p hp
  have h : env43122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43121_43122 : H12AffineEnvironment.transform 21 41341 env43121 = env43122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env43121 == env43122) = true)

theorem identity43122 : scanCanonicalize (H12AffineFastState.compose env43122 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(20+1) ^^^ 38144) := by decide +kernel

theorem selectedBound43122 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43123 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,35189,1024,32769,38144,41341,17,41311,8193,64,10588,36944,49216,2421,1364,53344,256,53345,12620,513]

theorem envBound43123 : H12AffineFastState.Bounded env43123 := by
  intro p hp
  have h : env43123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43122_43123 : H12AffineEnvironment.transform 20 38144 env43122 = env43123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 38144 env43122 == env43123) = true)

theorem identity43123 : scanCanonicalize (H12AffineFastState.compose env43123 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound43123 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env43124 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29005,8202,16400,30776,1024,29004,25677,20528,17,20498,8193,64,10588,24861,12557,2421,1364,8493,256,8492,12620,513]

theorem envBound43124 : H12AffineFastState.Bounded env43124 := by
  intro p hp
  have h : env43124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43123_43124 : H12AffineEnvironment.transform 14 29005 env43123 = env43124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env43123 == env43124) = true)

theorem identity43124 : scanCanonicalize (H12AffineFastState.compose env43124 (packedSelected [0,1,2,3,4,10,11,15] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound43124 : packedSelected [0,1,2,3,4,10,11,15] rootPS < 2^1333 := by decide +kernel

def env43125 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,16384,29005,8202,16400,30776,100,29004,24617,20528,17,20498,8193,64,10588,24861,12557,2421,304,8493,256,8492,12620,513]

theorem envBound43125 : H12AffineFastState.Bounded env43125 := by
  intro p hp
  have h : env43125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43124_43125 : H12AffineEnvironment.transform 9 100 env43124 = env43125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env43124 == env43125) = true)

theorem identity43125 : scanCanonicalize (H12AffineFastState.compose env43125 (packedSelected [2,5,8] rootPS)) = affineNative (2^(13+1) ^^^ 10588) := by decide +kernel

theorem selectedBound43125 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env43126 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,4096,8192,10588,6161,8202,10572,4452,100,6160,2421,14700,17,14670,8193,64,10588,2113,12557,2421,304,8493,256,8492,12620,513]

theorem envBound43126 : H12AffineFastState.Bounded env43126 := by
  intro p hp
  have h : env43126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43125_43126 : H12AffineEnvironment.transform 13 10588 env43125 = env43126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10588 env43125 == env43126) = true)

def env43127 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1024,32769,2097152,4194304,17,98644,8193,64,4229153,2098513,2118976,2420,1365,6349852,256,2114912,2139213,74250]

theorem envBound43127 : H12AffineFastState.Bounded env43127 := by
  intro p hp
  have h : env43127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43119_43127 : H12AffineEnvironment.transform 16 16401 env43119 = env43127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43119 == env43127) = true)

theorem identity43127 : scanCanonicalize (H12AffineFastState.compose env43127 (packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73771) := by decide +kernel

theorem selectedBound43127 : packedSelected [0,4,7,12,15,16,20,22,38,41] rootPS < 2^1333 := by decide +kernel

def env43128 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1024,32769,2097152,73771,17,98644,8193,64,108554,2098513,2118976,2420,1365,2212919,256,2114912,2139213,74250]

theorem envBound43128 : H12AffineFastState.Bounded env43128 := by
  intro p hp
  have h : env43128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43127_43128 : H12AffineEnvironment.transform 21 73771 env43127 = env43128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73771 env43127 == env43128) = true)

theorem identity43128 : scanCanonicalize (H12AffineFastState.compose env43128 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(20+1) ^^^ 124186) := by decide +kernel

theorem selectedBound43128 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env43129 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,35189,1024,32769,124186,73771,17,98644,8193,64,108554,122955,110682,2420,1365,8493,256,106618,82263,74250]

theorem envBound43129 : H12AffineFastState.Bounded env43129 := by
  intro p hp
  have h : env43129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43128_43129 : H12AffineEnvironment.transform 20 124186 env43128 = env43129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 124186 env43128 == env43129) = true)

theorem identity43129 : scanCanonicalize (H12AffineFastState.compose env43129 (packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound43129 : packedSelected [0,1,2,3,4,6,7,8,9,11,12,15,17,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env43130 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,263,16401,35189,1024,32769,58397,8492,17,32851,8193,64,43277,57676,45405,2420,1365,8493,256,41341,16464,8973]

theorem envBound43130 : H12AffineFastState.Bounded env43130 := by
  intro p hp
  have h : env43130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43129_43130 : H12AffineEnvironment.transform 15 263 env43129 = env43130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env43129 == env43130) = true)

theorem identity43130 : scanCanonicalize (H12AffineFastState.compose env43130 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43130 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env43131 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,263,16401,10281,1024,8541,17729,8492,17,8463,8193,64,2129,16400,4097,2420,1365,8493,256,33,16464,8973]

theorem envBound43131 : H12AffineFastState.Bounded env43131 := by
  intro p hp
  have h : env43131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43130_43131 : H12AffineEnvironment.transform 14 8540 env43130 = env43131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43130 == env43131) = true)

theorem identity43131 : scanCanonicalize (H12AffineFastState.compose env43131 (packedSelected [0,1,3,5,8,9,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound43131 : packedSelected [0,1,3,5,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43132 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5237,8540,263,5220,10281,1024,8541,4404,8492,17,8463,8193,64,2129,5221,4097,2420,1365,8493,256,33,5157,8973]

theorem envBound43132 : H12AffineFastState.Bounded env43132 := by
  intro p hp
  have h : env43132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43131_43132 : H12AffineEnvironment.transform 13 5237 env43131 = env43132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env43131 == env43132) = true)

theorem identity43132 : scanCanonicalize (H12AffineFastState.compose env43132 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43132 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43133 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5237,81,263,5220,2340,1024,80,4404,33,17,2,268,64,2129,5221,4097,2420,1365,32,256,33,5157,512]

theorem envBound43133 : H12AffineFastState.Bounded env43133 := by
  intro p hp
  have h : env43133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43132_43133 : H12AffineEnvironment.transform 12 269 env43132 = env43133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43132 == env43133) = true)

theorem identity43133 : scanCanonicalize (H12AffineFastState.compose env43133 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43133 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43134 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5237,81,114,5220,2129,1024,80,4161,33,17,2,121,64,2129,5221,4097,2049,1056,32,117,33,5157,512]

theorem envBound43134 : H12AffineFastState.Bounded env43134 := by
  intro p hp
  have h : env43134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43133_43134 : H12AffineEnvironment.transform 7 117 env43133 = env43134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43133 == env43134) = true)

theorem identity43134 : scanCanonicalize (H12AffineFastState.compose env43134 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43134 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env43135 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,88,5205,81,82,5188,2129,1024,80,4161,1,17,2,89,64,2129,5189,4097,2049,1024,0,85,1,5125,512]

theorem envBound43135 : H12AffineFastState.Bounded env43135 := by
  intro p hp
  have h : env43135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43134_43135 : H12AffineEnvironment.transform 4 0 env43134 = env43135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43134 == env43135) = true)

theorem identity43135 : scanCanonicalize (H12AffineFastState.compose env43135 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43135 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43136 : List Nat := [2,4,8,16,0,64,9,85,512,1024,1,4096,88,5205,81,82,5188,80,1024,80,4161,1,17,2,89,64,80,5189,4097,0,1024,0,85,1,5125,512]

theorem envBound43136 : H12AffineFastState.Bounded env43136 := by
  intro p hp
  have h : env43136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43135_43136 : H12AffineEnvironment.transform 10 1 env43135 = env43136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43135 == env43136) = true)

def env43137 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973837,10507601,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound43137 : H12AffineFastState.Bounded env43137 := by
  intro p hp
  have h : env43137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans42972_43137 : H12AffineEnvironment.transform 18 1025 env42972 = env43137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env42972 == env43137) = true)

theorem identity43137 : scanCanonicalize (H12AffineFastState.compose env43137 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 253976) := by decide +kernel

theorem selectedBound43137 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env43138 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,253976,8328,64,12853273,2253973,10507601,8830976,8545288,6456793,257,10626229,10667280,8602591]

theorem envBound43138 : H12AffineFastState.Bounded env43138 := by
  intro p hp
  have h : env43138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43137_43138 : H12AffineEnvironment.transform 23 253976 env43137 = env43138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 253976 env43137 == env43138) = true)

def env43139 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257300,253976,8328,64,6705549,2253973,140485,2404756,2102684,6456793,257,21793,46212,2175563]

theorem envBound43139 : H12AffineFastState.Bounded env43139 := by
  intro p hp
  have h : env43139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43138_43139 : H12AffineEnvironment.transform 22 2257300 env43138 = env43139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257300 env43138 == env43139) = true)

def env43140 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257300,253976,8328,64,2157597,2253973,140485,2404756,2102684,2373705,257,21793,46212,2175563]

theorem envBound43140 : H12AffineFastState.Bounded env43140 := by
  intro p hp
  have h : env43140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43139_43140 : H12AffineEnvironment.transform 21 441744 env43139 = env43140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env43139 == env43140) = true)

def env43141 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,253976,8328,64,64605,160981,140485,303572,1500,272393,257,21793,46212,74251]

theorem envBound43141 : H12AffineFastState.Bounded env43141 := by
  intro p hp
  have h : env43141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43140_43141 : H12AffineEnvironment.transform 20 4160 env43140 = env43141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43140 == env43141) = true)

theorem identity43141 : scanCanonicalize (H12AffineFastState.compose env43141 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound43141 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43142 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272513,62661,95497,8328,64,64605,57796,45524,303572,1500,272393,257,21793,46212,74251]

theorem envBound43142 : H12AffineFastState.Bounded env43142 := by
  intro p hp
  have h : env43142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43141_43142 : H12AffineEnvironment.transform 16 38161 env43141 = env43142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env43141 == env43142) = true)

theorem identity43142 : scanCanonicalize (H12AffineFastState.compose env43142 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound43142 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env43143 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,262144,1025,32769,4160,272513,62661,21763,8328,64,64605,57796,45524,303572,1500,272393,257,21793,46212,513]

theorem envBound43143 : H12AffineFastState.Bounded env43143 := by
  intro p hp
  have h : env43143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43142_43143 : H12AffineEnvironment.transform 15 8202 env43142 = env43143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env43142 == env43143) = true)

theorem identity43143 : scanCanonicalize (H12AffineFastState.compose env43143 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 64928) := by decide +kernel

theorem selectedBound43143 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env43144 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,38161,64928,1025,32769,4160,54561,62661,21763,8328,64,64605,57796,45524,23668,1500,54697,257,21793,46212,513]

theorem envBound43144 : H12AffineFastState.Bounded env43144 := by
  intro p hp
  have h : env43144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43143_43144 : H12AffineEnvironment.transform 17 64928 env43143 = env43144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64928 env43143 == env43144) = true)

theorem identity43144 : scanCanonicalize (H12AffineFastState.compose env43144 (packedSelected [2,3,4,5,6,7,8,9,11,16,20,27,28,32] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound43144 : packedSelected [2,3,4,5,6,7,8,9,11,16,20,27,28,32] rootPS < 2^1333 := by decide +kernel

def env43145 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,32768,8202,38161,35245,1025,32769,4160,41260,32968,8462,8328,64,34896,38345,45524,10361,1500,41380,257,8492,46212,513]

theorem envBound43145 : H12AffineFastState.Bounded env43145 := by
  intro p hp
  have h : env43145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43144_43145 : H12AffineEnvironment.transform 13 13325 env43144 = env43145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env43144 == env43145) = true)

theorem identity43145 : scanCanonicalize (H12AffineFastState.compose env43145 (packedSelected [2,4,6,9,14,16,17,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43145 : packedSelected [2,4,6,9,14,16,17,18,23] rootPS < 2^1333 := by decide +kernel

def env43146 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,8540,8202,13389,10481,1025,8541,4160,112,8596,8462,8328,64,10508,13461,4232,10361,1500,248,257,8492,5592,513]

theorem envBound43146 : H12AffineFastState.Bounded env43146 := by
  intro p hp
  have h : env43146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43145_43146 : H12AffineEnvironment.transform 14 8540 env43145 = env43146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43145 == env43146) = true)

theorem identity43146 : scanCanonicalize (H12AffineFastState.compose env43146 (packedSelected [2,4,6,9,14,16] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43146 : packedSelected [2,4,6,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43147 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13325,8540,8202,13389,10361,1025,8541,4160,112,8476,8462,8192,64,10508,13341,4096,10361,1364,112,257,8492,5456,513]

theorem envBound43147 : H12AffineFastState.Bounded env43147 := by
  intro p hp
  have h : env43147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43146_43147 : H12AffineEnvironment.transform 6 8 env43146 = env43147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43146 == env43147) = true)

theorem identity43147 : scanCanonicalize (H12AffineFastState.compose env43147 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound43147 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43148 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,8192,12620,8540,8202,12556,10361,320,8541,4160,112,8476,8462,8192,64,10508,12636,4096,10361,21,112,257,8492,4113,513]

theorem envBound43148 : H12AffineFastState.Bounded env43148 := by
  intro p hp
  have h : env43148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43147_43148 : H12AffineEnvironment.transform 9 321 env43147 = env43148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env43147 == env43148) = true)

theorem identity43148 : scanCanonicalize (H12AffineFastState.compose env43148 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43148 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env43149 : List Nat := [2,4,8,16,32,64,8,256,512,321,2048,4096,269,4161,81,263,4097,2420,320,80,4160,112,17,3,269,64,2049,4177,4096,2420,21,112,257,33,4113,513]

theorem envBound43149 : H12AffineFastState.Bounded env43149 := by
  intro p hp
  have h : env43149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43148_43149 : H12AffineEnvironment.transform 12 269 env43148 = env43149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43148 == env43149) = true)

theorem identity43149 : scanCanonicalize (H12AffineFastState.compose env43149 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 293) := by decide +kernel

theorem selectedBound43149 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env43150 : List Nat := [2,4,8,16,32,64,8,256,512,321,293,4096,269,4161,81,263,4097,81,320,80,4160,112,17,3,269,64,292,4177,4096,81,21,112,257,33,4113,513]

theorem envBound43150 : H12AffineFastState.Bounded env43150 := by
  intro p hp
  have h : env43150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43149_43150 : H12AffineEnvironment.transform 10 293 env43149 = env43150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 293 env43149 == env43150) = true)

def env43151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156117,253976,8328,64,64604,160980,140485,303573,1501,272392,257,21793,46212,74250]

theorem envBound43151 : H12AffineFastState.Bounded env43151 := by
  intro p hp
  have h : env43151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43140_43151 : H12AffineEnvironment.transform 20 4161 env43140 = env43151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43140 == env43151) = true)

def env43152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1025,32769,4161,169400,156117,253976,8328,64,64604,160980,140485,35325,1501,32,257,21793,46212,74250]

theorem envBound43152 : H12AffineFastState.Bounded env43152 := by
  intro p hp
  have h : env43152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43151_43152 : H12AffineEnvironment.transform 17 10280 env43151 = env43152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env43151 == env43152) = true)

def env43153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1025,32769,4161,21928,41413,73736,8328,64,64604,46276,58581,35325,1501,32,257,21793,46212,74250]

theorem envBound43153 : H12AffineFastState.Bounded env43153 := by
  intro p hp
  have h : env43153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43152_43153 : H12AffineEnvironment.transform 16 49168 env43152 = env43153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43152 == env43153) = true)

theorem identity43153 : scanCanonicalize (H12AffineFastState.compose env43153 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43153 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,24908,10280,1025,8541,4161,21928,153,73736,8328,64,23808,5528,17801,10401,1501,32,257,21793,5592,74250]

theorem envBound43154 : H12AffineFastState.Bounded env43154 := by
  intro p hp
  have h : env43154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43153_43154 : H12AffineEnvironment.transform 14 8540 env43153 = env43154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43153 == env43154) = true)

theorem identity43154 : scanCanonicalize (H12AffineFastState.compose env43154 (packedSelected [4,5,7,9,18,19,23,24,27] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound43154 : packedSelected [4,5,7,9,18,19,23,24,27] rootPS < 2^1333 := by decide +kernel

def env43155 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,16384,8540,65536,24908,10280,273,8541,4161,20664,153,73736,8328,64,22544,4232,16537,10401,205,32,257,20529,4296,74250]

theorem envBound43155 : H12AffineFastState.Bounded env43155 := by
  intro p hp
  have h : env43155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43154_43155 : H12AffineEnvironment.transform 9 272 env43154 = env43155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env43154 == env43155) = true)

theorem identity43155 : scanCanonicalize (H12AffineFastState.compose env43155 (packedSelected [11,23] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound43155 : packedSelected [11,23] rootPS < 2^1333 := by decide +kernel

def env43156 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4541,8540,65536,12529,10280,273,8541,4161,261,153,73736,8328,64,2477,4232,4388,10401,205,32,257,396,4296,74250]

theorem envBound43156 : H12AffineFastState.Bounded env43156 := by
  intro p hp
  have h : env43156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43155_43156 : H12AffineEnvironment.transform 13 4541 env43155 = env43156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env43155 == env43156) = true)

theorem identity43156 : scanCanonicalize (H12AffineFastState.compose env43156 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,14,18,19,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound43156 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,14,18,19,24,26] rootPS < 2^1333 := by decide +kernel

def env43157 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,8192,4453,8540,65536,12329,10280,273,8541,4161,261,65,73736,8272,64,2421,4176,4388,10361,21,32,257,340,4112,74250]

theorem envBound43157 : H12AffineFastState.Bounded env43157 := by
  intro p hp
  have h : env43157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43156_43157 : H12AffineEnvironment.transform 6 88 env43156 = env43157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env43156 == env43157) = true)

theorem identity43157 : scanCanonicalize (H12AffineFastState.compose env43157 (packedSelected [0,2,3,5,6,7,10,16] rootPS)) = affineNative (2^(15+1) ^^^ 8494) := by decide +kernel

theorem selectedBound43157 : packedSelected [0,2,3,5,6,7,10,16] rootPS < 2^1333 := by decide +kernel

def env43158 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,8192,4453,8540,8494,12329,10280,273,8541,4161,261,65,294,8272,64,2421,4176,4388,10361,21,32,257,340,4112,804]

theorem envBound43158 : H12AffineFastState.Bounded env43158 := by
  intro p hp
  have h : env43158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43157_43158 : H12AffineEnvironment.transform 15 8494 env43157 = env43158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8494 env43157 == env43158) = true)

theorem identity43158 : scanCanonicalize (H12AffineFastState.compose env43158 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound43158 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env43159 : List Nat := [2,4,8,16,32,64,88,256,512,272,2048,4096,40,4453,372,262,4097,2048,273,373,4161,261,65,294,120,64,2421,4176,4388,2129,21,32,257,340,4112,804]

theorem envBound43159 : H12AffineFastState.Bounded env43159 := by
  intro p hp
  have h : env43159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43158_43159 : H12AffineEnvironment.transform 12 40 env43158 = env43159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env43158 == env43159) = true)

theorem identity43159 : scanCanonicalize (H12AffineFastState.compose env43159 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43159 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43160 : List Nat := [2,4,8,16,32,17,9,256,512,272,2048,4096,40,4404,293,262,4097,2048,273,292,4112,261,16,294,41,17,2340,4097,4388,2048,21,32,257,261,4112,804]

theorem envBound43160 : H12AffineFastState.Bounded env43160 := by
  intro p hp
  have h : env43160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43159_43160 : H12AffineEnvironment.transform 5 17 env43159 = env43160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43159 == env43160) = true)

theorem identity43160 : scanCanonicalize (H12AffineFastState.compose env43160 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound43160 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env43161 : List Nat := [2,4,8,16,32,17,9,256,512,272,821,4096,40,4404,293,262,4097,821,273,292,4112,261,16,294,41,17,529,4097,4388,821,21,32,257,261,4112,804]

theorem envBound43161 : H12AffineFastState.Bounded env43161 := by
  intro p hp
  have h : env43161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43160_43161 : H12AffineEnvironment.transform 10 821 env43160 = env43161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env43160 == env43161) = true)

theorem identity43161 : scanCanonicalize (H12AffineFastState.compose env43161 (packedSelected [4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound43161 : packedSelected [4,7] rootPS < 2^1333 := by decide +kernel

def env43162 : List Nat := [2,4,8,16,16,17,9,256,512,272,773,4096,24,4356,277,262,4097,773,273,276,4112,261,16,278,25,17,529,4097,4372,773,21,16,257,261,4112,788]

theorem envBound43162 : H12AffineFastState.Bounded env43162 := by
  intro p hp
  have h : env43162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43161_43162 : H12AffineEnvironment.transform 4 16 env43161 = env43162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43161 == env43162) = true)

theorem identity43162 : scanCanonicalize (H12AffineFastState.compose env43162 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43162 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env43163 : List Nat := [2,4,8,16,16,17,9,4,512,20,513,4096,24,4096,17,2,4097,513,21,16,4112,1,16,18,25,17,529,4097,4112,513,21,16,5,1,4112,528]

theorem envBound43163 : H12AffineFastState.Bounded env43163 := by
  intro p hp
  have h : env43163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43162_43163 : H12AffineEnvironment.transform 7 4 env43162 = env43163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43162 == env43163) = true)

def env43164 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1025,32769,4161,21929,41412,73737,8328,64,64604,46277,58580,35325,1501,32,257,21793,46212,74250]

theorem envBound43164 : H12AffineFastState.Bounded env43164 := by
  intro p hp
  have h : env43164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43152_43164 : H12AffineEnvironment.transform 16 49169 env43152 = env43164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43152 == env43164) = true)

theorem identity43164 : scanCanonicalize (H12AffineFastState.compose env43164 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound43164 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43165 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,65536,25029,10280,1025,8661,4161,21929,16,73737,8328,64,23944,5393,17664,10281,1501,32,257,21793,5456,74250]

theorem envBound43165 : H12AffineFastState.Bounded env43165 := by
  intro p hp
  have h : env43165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43164_43165 : H12AffineEnvironment.transform 14 8660 env43164 = env43165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env43164 == env43165) = true)

theorem identity43165 : scanCanonicalize (H12AffineFastState.compose env43165 (packedSelected [4,5,7,9,19,24,27] rootPS)) = affineNative (2^(15+1) ^^^ 28866) := by decide +kernel

theorem selectedBound43165 : packedSelected [4,5,7,9,19,24,27] rootPS < 2^1333 := by decide +kernel

def env43166 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8660,28866,25029,10280,1025,8661,4161,21929,16,20683,8328,64,23944,5393,17664,10281,1501,32,257,21793,5456,21192]

theorem envBound43166 : H12AffineFastState.Bounded env43166 := by
  intro p hp
  have h : env43166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43165_43166 : H12AffineEnvironment.transform 15 28866 env43165 = env43166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 28866 env43165 == env43166) = true)

theorem identity43166 : scanCanonicalize (H12AffineFastState.compose env43166 (packedSelected [0,1,2,6,7,8,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 12692) := by decide +kernel

theorem selectedBound43166 : packedSelected [0,1,2,6,7,8,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env43167 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12692,8660,342,4177,10280,1025,8661,4161,9277,16,8543,8328,64,11292,5393,13460,10281,1501,32,257,9397,5456,9052]

theorem envBound43167 : H12AffineFastState.Bounded env43167 := by
  intro p hp
  have h : env43167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43166_43167 : H12AffineEnvironment.transform 13 12692 env43166 = env43167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12692 env43166 == env43167) = true)

theorem identity43167 : scanCanonicalize (H12AffineFastState.compose env43167 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43167 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env43168 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,4248,216,342,4177,2340,1025,217,4161,1329,16,83,388,64,3344,5393,5528,2341,1501,32,257,1465,5456,592]

theorem envBound43168 : H12AffineFastState.Bounded env43168 := by
  intro p hp
  have h : env43168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43167_43168 : H12AffineEnvironment.transform 12 268 env43167 = env43168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43167 == env43168) = true)

theorem identity43168 : scanCanonicalize (H12AffineFastState.compose env43168 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(7+1) ^^^ 173) := by decide +kernel

theorem selectedBound43168 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env43169 : List Nat := [2,4,8,16,32,64,128,173,512,1024,2048,4096,161,4248,216,251,4177,2185,1025,217,4161,1180,16,83,41,64,3261,5308,5173,2184,1136,32,172,1044,5373,592]

theorem envBound43169 : H12AffineFastState.Bounded env43169 := by
  intro p hp
  have h : env43169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43168_43169 : H12AffineEnvironment.transform 7 173 env43168 = env43169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 173 env43168 == env43169) = true)

theorem identity43169 : scanCanonicalize (H12AffineFastState.compose env43169 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound43169 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env43170 : List Nat := [2,4,8,16,32,64,89,116,512,1024,2048,4096,120,4161,1,34,4177,2128,1025,0,4161,1093,16,83,41,64,3172,5221,5173,2129,1136,32,117,1044,5156,592]

theorem envBound43170 : H12AffineFastState.Bounded env43170 := by
  intro p hp
  have h : env43170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43169_43170 : H12AffineEnvironment.transform 6 89 env43169 = env43170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env43169 == env43170) = true)

theorem identity43170 : scanCanonicalize (H12AffineFastState.compose env43170 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound43170 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43171 : List Nat := [2,4,8,16,32,64,89,116,512,101,2048,4096,120,4161,1,34,4177,2128,100,0,4161,32,16,83,41,64,2049,4096,4176,2129,21,32,117,113,4161,592]

theorem envBound43171 : H12AffineFastState.Bounded env43171 := by
  intro p hp
  have h : env43171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43170_43171 : H12AffineEnvironment.transform 9 101 env43170 = env43171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env43170 == env43171) = true)

theorem identity43171 : scanCanonicalize (H12AffineFastState.compose env43171 (packedSelected [4,6] rootPS)) = affineNative (2^(4+1) ^^^ 4) := by decide +kernel

theorem selectedBound43171 : packedSelected [4,6] rootPS < 2^1333 := by decide +kernel

def env43172 : List Nat := [2,4,8,16,4,64,89,80,512,65,2048,4096,92,4161,1,6,4177,2128,64,0,4161,4,16,83,13,64,2049,4096,4176,2129,21,4,81,85,4161,592]

theorem envBound43172 : H12AffineFastState.Bounded env43172 := by
  intro p hp
  have h : env43172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43171_43172 : H12AffineEnvironment.transform 4 4 env43171 = env43172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env43171 == env43172) = true)

theorem identity43172 : scanCanonicalize (H12AffineFastState.compose env43172 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound43172 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env43173 : List Nat := [2,4,8,16,4,64,89,80,512,65,2048,2065,92,2128,1,6,2112,2128,64,0,2128,4,16,83,13,64,2049,2065,2113,2129,21,4,81,85,2128,592]

theorem envBound43173 : H12AffineFastState.Bounded env43173 := by
  intro p hp
  have h : env43173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43172_43173 : H12AffineEnvironment.transform 11 2065 env43172 = env43173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env43172 == env43173) = true)

theorem identity43173 : scanCanonicalize (H12AffineFastState.compose env43173 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 4) := by decide +kernel

theorem selectedBound43173 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env43174 : List Nat := [2,4,8,16,4,64,89,80,512,65,4,21,92,84,1,6,68,84,64,0,84,4,16,83,13,64,5,21,69,85,21,4,81,85,84,592]

theorem envBound43174 : H12AffineFastState.Bounded env43174 := by
  intro p hp
  have h : env43174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43173_43174 : H12AffineEnvironment.transform 10 4 env43173 = env43174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 4 env43173 == env43174) = true)

theorem identity43174 : scanCanonicalize (H12AffineFastState.compose env43174 (packedSelected [0,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound43174 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43175 : List Nat := [2,1,8,16,1,64,89,80,512,65,1,16,89,81,1,3,65,81,64,0,81,1,16,83,8,64,0,16,64,80,16,1,81,80,81,592]

theorem envBound43175 : H12AffineFastState.Bounded env43175 := by
  intro p hp
  have h : env43175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43174_43175 : H12AffineEnvironment.transform 1 1 env43174 = env43175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env43174 == env43175) = true)

theorem identity43175 : scanCanonicalize (H12AffineFastState.compose env43175 (packedSelected [0,2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43175 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env43176 : List Nat := [2,1,8,16,1,16,9,0,512,17,1,16,9,1,1,3,17,1,16,0,1,1,16,3,8,16,0,16,16,0,16,1,1,0,1,512]

theorem envBound43176 : H12AffineFastState.Bounded env43176 := by
  intro p hp
  have h : env43176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43175_43176 : H12AffineEnvironment.transform 5 16 env43175 = env43176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43175 == env43176) = true)

theorem identity43176 : scanCanonicalize (H12AffineFastState.compose env43176 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound43176 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43177 : List Nat := [2,1,8,1,1,1,9,0,512,0,1,1,9,1,1,3,0,1,1,0,1,1,1,3,8,1,0,1,1,0,1,1,1,0,1,512]

theorem envBound43177 : H12AffineFastState.Bounded env43177 := by
  intro p hp
  have h : env43177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43176_43177 : H12AffineEnvironment.transform 3 1 env43176 = env43177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env43176 == env43177) = true)

theorem identity43177 : scanCanonicalize (H12AffineFastState.compose env43177 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound43177 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43178 : List Nat := [2,1,8,1,1,1,9,0,8,0,1,1,9,1,1,3,0,1,1,0,1,1,1,3,8,1,0,1,1,0,1,1,1,0,1,8]

theorem envBound43178 : H12AffineFastState.Bounded env43178 := by
  intro p hp
  have h : env43178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43177_43178 : H12AffineEnvironment.transform 8 8 env43177 = env43178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env43177 == env43178) = true)

theorem identity43178 : scanCanonicalize (H12AffineFastState.compose env43178 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43178 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env43179 : List Nat := [2,1,3,1,1,1,2,0,3,0,1,1,2,1,1,3,0,1,1,0,1,1,1,3,3,1,0,1,1,0,1,1,1,0,1,3]

theorem envBound43179 : H12AffineFastState.Bounded env43179 := by
  intro p hp
  have h : env43179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43178_43179 : H12AffineEnvironment.transform 2 3 env43178 = env43179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43178 == env43179) = true)

def env43180 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1025,32769,4161,169401,156117,253976,8328,64,64604,160980,140485,35324,1501,33,257,21793,46212,74250]

theorem envBound43180 : H12AffineFastState.Bounded env43180 := by
  intro p hp
  have h : env43180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43151_43180 : H12AffineEnvironment.transform 17 10281 env43151 = env43180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43151 == env43180) = true)

def env43181 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21929,41413,73736,8328,64,64604,46276,58581,35324,1501,33,257,21793,46212,74250]

theorem envBound43181 : H12AffineFastState.Bounded env43181 := by
  intro p hp
  have h : env43181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43180_43181 : H12AffineEnvironment.transform 16 49168 env43180 = env43181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env43180 == env43181) = true)

theorem identity43181 : scanCanonicalize (H12AffineFastState.compose env43181 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43181 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43182 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1025,32769,4161,21792,41292,73736,8193,64,64604,46157,58460,35189,1364,33,257,21793,46093,74250]

theorem envBound43182 : H12AffineFastState.Bounded env43182 := by
  intro p hp
  have h : env43182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43181_43182 : H12AffineEnvironment.transform 6 9 env43181 = env43182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43181 == env43182) = true)

theorem identity43182 : scanCanonicalize (H12AffineFastState.compose env43182 (packedSelected [0,3,4,7,10,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound43182 : packedSelected [0,3,4,7,10,22,24,26] rootPS < 2^1333 := by decide +kernel

def env43183 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29788,65536,13388,10281,1025,29789,4161,21792,21776,73736,8193,64,2048,16401,4096,32041,1364,33,257,21793,16465,74250]

theorem envBound43183 : H12AffineFastState.Bounded env43183 := by
  intro p hp
  have h : env43183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43182_43183 : H12AffineEnvironment.transform 14 29788 env43182 = env43183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env43182 == env43183) = true)

theorem identity43183 : scanCanonicalize (H12AffineFastState.compose env43183 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound43183 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env43184 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,13388,10281,1025,8540,4161,33,17,73736,8193,64,2048,5392,4096,10280,1364,33,257,32,5456,74250]

theorem envBound43184 : H12AffineFastState.Bounded env43184 := by
  intro p hp
  have h : env43184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43183_43184 : H12AffineEnvironment.transform 13 5377 env43183 = env43184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env43183 == env43184) = true)

theorem identity43184 : scanCanonicalize (H12AffineFastState.compose env43184 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 375) := by decide +kernel

theorem selectedBound43184 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43185 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,375,13388,10281,1025,8540,4161,33,17,8575,8193,64,2048,5392,4096,10280,1364,33,257,32,5456,9085]

theorem envBound43185 : H12AffineFastState.Bounded env43185 := by
  intro p hp
  have h : env43185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43184_43185 : H12AffineEnvironment.transform 15 375 env43184 = env43185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 375 env43184 == env43185) = true)

def env43186 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1025,32769,4161,21928,41412,73737,8328,64,64604,46277,58580,35324,1501,33,257,21793,46212,74250]

theorem envBound43186 : H12AffineFastState.Bounded env43186 := by
  intro p hp
  have h : env43186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43180_43186 : H12AffineEnvironment.transform 16 49169 env43180 = env43186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env43180 == env43186) = true)

def env43187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,65536,49169,2557,1025,32769,4161,21928,32784,66013,348,64,56712,38161,50432,35324,1501,33,257,21793,38224,66526]

theorem envBound43187 : H12AffineFastState.Bounded env43187 := by
  intro p hp
  have h : env43187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43186_43187 : H12AffineEnvironment.transform 12 468 env43186 = env43187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env43186 == env43187) = true)

theorem identity43187 : scanCanonicalize (H12AffineFastState.compose env43187 (packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound43187 : packedSelected [1,2,6,7,8,9,19,20,22,23,27,32] rootPS < 2^1333 := by decide +kernel

def env43188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,65536,5393,2557,1025,21761,4161,21928,21776,66013,348,64,2184,16401,4096,23804,1501,33,257,21793,16464,66526]

theorem envBound43188 : H12AffineFastState.Bounded env43188 := by
  intro p hp
  have h : env43188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43187_43188 : H12AffineEnvironment.transform 14 21760 env43187 = env43188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env43187 == env43188) = true)

theorem identity43188 : scanCanonicalize (H12AffineFastState.compose env43188 (packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound43188 : packedSelected [2,3,5,6,7,9,10,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env43189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,21590,5393,2557,1025,21761,4161,21928,21776,21899,348,64,2184,16401,4096,23804,1501,33,257,21793,16464,22408]

theorem envBound43189 : H12AffineFastState.Bounded env43189 := by
  intro p hp
  have h : env43189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43188_43189 : H12AffineEnvironment.transform 15 21590 env43188 = env43189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env43188 == env43189) = true)

theorem identity43189 : scanCanonicalize (H12AffineFastState.compose env43189 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound43189 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env43190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,136,478,5393,2557,1025,137,4161,32,152,3,348,64,2184,5529,4096,2420,1501,33,257,169,5592,512]

theorem envBound43190 : H12AffineFastState.Bounded env43190 := by
  intro p hp
  have h : env43190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43189_43190 : H12AffineEnvironment.transform 13 5512 env43189 = env43190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env43189 == env43190) = true)

theorem identity43190 : scanCanonicalize (H12AffineFastState.compose env43190 (packedSelected [2,4,6,9,12,14,15] rootPS)) = affineNative (2^(10+1) ^^^ 137) := by decide +kernel

theorem selectedBound43190 : packedSelected [2,4,6,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env43191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,137,4096,468,5512,136,478,5393,372,1025,137,4161,32,152,3,348,64,1,5529,4096,509,1501,33,257,169,5592,512]

theorem envBound43191 : H12AffineFastState.Bounded env43191 := by
  intro p hp
  have h : env43191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43190_43191 : H12AffineEnvironment.transform 10 137 env43190 = env43191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 137 env43190 == env43191) = true)

theorem identity43191 : scanCanonicalize (H12AffineFastState.compose env43191 (packedSelected [1,3,4,5,8,9,12,14] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound43191 : packedSelected [1,3,4,5,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env43192 : List Nat := [2,4,8,16,32,49,128,256,512,1024,137,4096,421,5512,136,431,5393,261,1025,137,4144,32,152,3,301,49,1,5529,4096,396,1452,33,257,169,5545,512]

theorem envBound43192 : H12AffineFastState.Bounded env43192 := by
  intro p hp
  have h : env43192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43191_43192 : H12AffineEnvironment.transform 5 49 env43191 = env43192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env43191 == env43192) = true)

theorem identity43192 : scanCanonicalize (H12AffineFastState.compose env43192 (packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43192 : packedSelected [0,1,3,4,5,6,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env43193 : List Nat := [2,4,8,16,32,49,128,37,512,1024,137,4096,128,5293,136,138,5172,32,1025,137,4144,32,152,3,8,49,1,5308,4096,169,1161,33,36,169,5260,512]

theorem envBound43193 : H12AffineFastState.Bounded env43193 := by
  intro p hp
  have h : env43193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43192_43193 : H12AffineEnvironment.transform 7 37 env43192 = env43193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43192 == env43193) = true)

theorem identity43193 : scanCanonicalize (H12AffineFastState.compose env43193 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(11+1) ^^^ 1196) := by decide +kernel

theorem selectedBound43193 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env43194 : List Nat := [2,4,8,16,32,49,128,37,512,1024,137,1196,128,1,136,138,152,32,1025,137,1180,32,152,3,8,49,1,16,1196,169,1161,33,36,169,32,512]

theorem envBound43194 : H12AffineFastState.Bounded env43194 := by
  intro p hp
  have h : env43194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43193_43194 : H12AffineEnvironment.transform 11 1196 env43193 = env43194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1196 env43193 == env43194) = true)

theorem identity43194 : scanCanonicalize (H12AffineFastState.compose env43194 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43194 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env43195 : List Nat := [2,4,8,16,32,49,9,37,512,1024,0,1061,9,1,1,3,17,32,1025,0,1045,32,17,3,8,49,1,16,1061,32,1024,33,36,32,32,512]

theorem envBound43195 : H12AffineFastState.Bounded env43195 := by
  intro p hp
  have h : env43195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43194_43195 : H12AffineEnvironment.transform 6 9 env43194 = env43195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43194 == env43195) = true)

theorem identity43195 : scanCanonicalize (H12AffineFastState.compose env43195 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound43195 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43196 : List Nat := [2,4,8,16,32,49,9,37,512,542,0,571,9,1,1,3,17,32,543,0,523,32,17,3,8,49,1,16,571,32,542,33,36,32,32,512]

theorem envBound43196 : H12AffineFastState.Bounded env43196 := by
  intro p hp
  have h : env43196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43195_43196 : H12AffineEnvironment.transform 9 542 env43195 = env43196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env43195 == env43196) = true)

theorem identity43196 : scanCanonicalize (H12AffineFastState.compose env43196 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound43196 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43197 : List Nat := [2,4,8,16,32,49,9,37,33,63,0,26,9,1,1,3,17,32,62,0,42,32,17,3,8,49,1,16,26,32,63,33,36,32,32,33]

theorem envBound43197 : H12AffineFastState.Bounded env43197 := by
  intro p hp
  have h : env43197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43196_43197 : H12AffineEnvironment.transform 8 33 env43196 = env43197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env43196 == env43197) = true)

theorem identity43197 : scanCanonicalize (H12AffineFastState.compose env43197 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound43197 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43198 : List Nat := [2,4,7,16,32,49,6,37,33,48,0,21,6,1,1,3,17,32,49,0,37,32,17,3,7,49,1,16,21,32,48,33,36,32,32,33]

theorem envBound43198 : H12AffineFastState.Bounded env43198 := by
  intro p hp
  have h : env43198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43197_43198 : H12AffineEnvironment.transform 2 7 env43197 = env43198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env43197 == env43198) = true)

theorem identity43198 : scanCanonicalize (H12AffineFastState.compose env43198 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound43198 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43199 : List Nat := [2,4,7,4,32,37,6,37,33,36,0,1,6,1,1,3,5,32,37,0,37,32,5,3,7,37,1,4,1,32,36,33,36,32,32,33]

theorem envBound43199 : H12AffineFastState.Bounded env43199 := by
  intro p hp
  have h : env43199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43198_43199 : H12AffineEnvironment.transform 3 4 env43198 = env43199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env43198 == env43199) = true)

theorem identity43199 : scanCanonicalize (H12AffineFastState.compose env43199 (packedSelected [1,2] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound43199 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env43200 : List Nat := [2,3,0,3,32,34,1,34,33,35,0,1,1,1,1,3,2,32,34,0,34,32,2,3,0,34,1,3,1,32,35,33,35,32,32,33]

theorem envBound43200 : H12AffineFastState.Bounded env43200 := by
  intro p hp
  have h : env43200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43199_43200 : H12AffineEnvironment.transform 1 3 env43199 = env43200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env43199 == env43200) = true)

theorem identity43200 : scanCanonicalize (H12AffineFastState.compose env43200 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43200 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env43201 : List Nat := [1,0,0,0,32,33,1,33,33,32,0,1,1,1,1,0,1,32,33,0,33,32,1,0,0,33,1,0,1,32,32,33,32,32,32,33]

theorem envBound43201 : H12AffineFastState.Bounded env43201 := by
  intro p hp
  have h : env43201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43200_43201 : H12AffineEnvironment.transform 0 1 env43200 = env43201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43200 == env43201) = true)

def env43202 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,65536,49169,2556,1025,32769,4161,21928,32785,66012,349,64,56713,38160,50433,35324,1501,33,257,21793,38225,66527]

theorem envBound43202 : H12AffineFastState.Bounded env43202 := by
  intro p hp
  have h : env43202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43186_43202 : H12AffineEnvironment.transform 12 469 env43186 = env43202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 469 env43186 == env43202) = true)

theorem identity43202 : scanCanonicalize (H12AffineFastState.compose env43202 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound43202 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env43203 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,32768,478,49169,2556,1025,32769,4161,21928,32785,2,349,64,56713,38160,50433,35324,1501,33,257,21793,38225,513]

theorem envBound43203 : H12AffineFastState.Bounded env43203 := by
  intro p hp
  have h : env43203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43202_43203 : H12AffineEnvironment.transform 15 478 env43202 = env43203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env43202 == env43203) = true)

theorem identity43203 : scanCanonicalize (H12AffineFastState.compose env43203 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound43203 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43204 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,469,16384,0,478,16401,2556,1025,1,4161,21928,17,2,349,64,23945,5392,17665,2556,1501,33,257,21793,5457,513]

theorem envBound43204 : H12AffineFastState.Bounded env43204 := by
  intro p hp
  have h : env43204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43203_43204 : H12AffineEnvironment.transform 14 0 env43203 = env43204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env43203 == env43204) = true)

theorem identity43204 : scanCanonicalize (H12AffineFastState.compose env43204 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43204 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43205 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,0,343,16401,2421,1025,1,4161,21793,17,2,349,64,23808,5392,17665,2421,1364,33,257,21793,5457,513]

theorem envBound43205 : H12AffineFastState.Bounded env43205 := by
  intro p hp
  have h : env43205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43204_43205 : H12AffineEnvironment.transform 6 9 env43204 = env43205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43204 == env43205) = true)

theorem identity43205 : scanCanonicalize (H12AffineFastState.compose env43205 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43205 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43206 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,263,16401,2341,1025,1,4113,21793,17,2,269,16,23808,5392,17665,2341,1284,33,257,21793,5377,513]

theorem envBound43206 : H12AffineFastState.Bounded env43206 := by
  intro p hp
  have h : env43206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43205_43206 : H12AffineEnvironment.transform 5 16 env43205 = env43206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43205 == env43206) = true)

theorem identity43206 : scanCanonicalize (H12AffineFastState.compose env43206 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 7204) := by decide +kernel

theorem selectedBound43206 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43207 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,7204,0,263,7221,2341,1025,1,4113,2309,17,2,269,16,292,5392,6437,2341,1284,33,257,2309,5377,513]

theorem envBound43207 : H12AffineFastState.Bounded env43207 := by
  intro p hp
  have h : env43207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43206_43207 : H12AffineEnvironment.transform 13 7204 env43206 = env43207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7204 env43206 == env43207) = true)

theorem identity43207 : scanCanonicalize (H12AffineFastState.compose env43207 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43207 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43208 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,268,6161,0,263,6144,2341,52,1,4113,2309,17,2,269,16,292,4389,6437,2341,305,33,257,2309,4404,513]

theorem envBound43208 : H12AffineFastState.Bounded env43208 := by
  intro p hp
  have h : env43208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43207_43208 : H12AffineEnvironment.transform 9 53 env43207 = env43208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43207 == env43208) = true)

theorem identity43208 : scanCanonicalize (H12AffineFastState.compose env43208 (packedSelected [4,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound43208 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env43209 : List Nat := [2,4,8,16,32,16,9,256,512,53,292,4096,268,4405,0,263,4388,1,52,1,4113,33,17,2,269,16,292,4389,4097,1,305,33,257,33,4404,513]

theorem envBound43209 : H12AffineFastState.Bounded env43209 := by
  intro p hp
  have h : env43209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43208_43209 : H12AffineEnvironment.transform 10 292 env43208 = env43209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env43208 == env43209) = true)

theorem identity43209 : scanCanonicalize (H12AffineFastState.compose env43209 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound43209 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43210 : List Nat := [2,4,8,16,32,16,9,256,512,53,292,49,268,260,0,263,277,1,52,1,32,33,17,2,269,16,292,276,48,1,305,33,257,33,261,513]

theorem envBound43210 : H12AffineFastState.Bounded env43210 := by
  intro p hp
  have h : env43210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43209_43210 : H12AffineEnvironment.transform 11 49 env43209 = env43210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env43209 == env43210) = true)

theorem identity43210 : scanCanonicalize (H12AffineFastState.compose env43210 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound43210 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43211 : List Nat := [2,4,8,16,32,16,9,37,512,53,1,49,41,33,0,34,48,1,52,1,32,33,17,2,40,16,1,49,48,1,20,33,36,33,32,513]

theorem envBound43211 : H12AffineFastState.Bounded env43211 := by
  intro p hp
  have h : env43211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43210_43211 : H12AffineEnvironment.transform 7 37 env43210 = env43211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env43210 == env43211) = true)

theorem identity43211 : scanCanonicalize (H12AffineFastState.compose env43211 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound43211 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43212 : List Nat := [2,4,8,16,32,16,9,37,32,53,1,49,41,33,0,34,48,1,52,1,32,33,17,2,40,16,1,49,48,1,20,33,36,33,32,33]

theorem envBound43212 : H12AffineFastState.Bounded env43212 := by
  intro p hp
  have h : env43212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43211_43212 : H12AffineEnvironment.transform 8 32 env43211 = env43212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env43211 == env43212) = true)

theorem identity43212 : scanCanonicalize (H12AffineFastState.compose env43212 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound43212 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43213 : List Nat := [2,4,8,16,11,16,9,14,11,30,1,26,2,10,0,9,27,1,31,1,11,10,17,2,3,16,1,26,27,1,20,10,15,10,11,10]

theorem envBound43213 : H12AffineFastState.Bounded env43213 := by
  intro p hp
  have h : env43213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43212_43213 : H12AffineEnvironment.transform 4 11 env43212 = env43213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env43212 == env43213) = true)

theorem identity43213 : scanCanonicalize (H12AffineFastState.compose env43213 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound43213 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43214 : List Nat := [2,4,8,10,11,10,9,14,11,4,1,0,2,10,0,9,1,1,5,1,11,10,11,2,3,10,1,0,1,1,14,10,15,10,11,10]

theorem envBound43214 : H12AffineFastState.Bounded env43214 := by
  intro p hp
  have h : env43214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43213_43214 : H12AffineEnvironment.transform 3 10 env43213 = env43214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env43213 == env43214) = true)

theorem identity43214 : scanCanonicalize (H12AffineFastState.compose env43214 (packedSelected [9] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43214 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env43215 : List Nat := [2,4,3,1,0,1,2,5,0,4,1,0,2,1,0,2,1,1,5,1,0,1,0,2,3,1,1,0,1,1,5,1,4,1,0,1]

theorem envBound43215 : H12AffineFastState.Bounded env43215 := by
  intro p hp
  have h : env43215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43214_43215 : H12AffineEnvironment.transform 2 3 env43214 = env43215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43214 == env43215) = true)

def env43216 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257300,253976,8328,64,2157596,2253973,140485,2404756,2102684,2373704,257,21793,46212,2175563]

theorem envBound43216 : H12AffineFastState.Bounded env43216 := by
  intro p hp
  have h : env43216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43139_43216 : H12AffineEnvironment.transform 21 441745 env43139 = env43216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env43139 == env43216) = true)

def env43217 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,253976,8328,64,64604,160981,140485,303572,1500,272392,257,21793,46212,74251]

theorem envBound43217 : H12AffineFastState.Bounded env43217 := by
  intro p hp
  have h : env43217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43216_43217 : H12AffineEnvironment.transform 20 4160 env43216 = env43217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43216 == env43217) = true)

theorem identity43217 : scanCanonicalize (H12AffineFastState.compose env43217 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound43217 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43218 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1025,29909,4160,411973,156116,201932,8328,64,2184,160981,140485,283904,1500,272392,257,21793,16464,74251]

theorem envBound43218 : H12AffineFastState.Bounded env43218 := by
  intro p hp
  have h : env43218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43217_43218 : H12AffineEnvironment.transform 14 29908 env43217 = env43218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env43217 == env43218) = true)

def env43219 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1025,29829,4112,411925,156036,201884,8328,16,2184,160901,140437,283904,1420,272392,257,21793,16384,74251]

theorem envBound43219 : H12AffineFastState.Bounded env43219 := by
  intro p hp
  have h : env43219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43218_43219 : H12AffineEnvironment.transform 5 16 env43218 = env43219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43218 == env43219) = true)

theorem identity43219 : scanCanonicalize (H12AffineFastState.compose env43219 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound43219 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env43220 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,215090,1025,29829,4112,65831,156036,201884,8328,16,2184,160901,140437,204082,1420,221242,257,21793,16384,74251]

theorem envBound43220 : H12AffineFastState.Bounded env43220 := by
  intro p hp
  have h : env43220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43219_43220 : H12AffineEnvironment.transform 17 215090 env43219 = env43220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env43219 == env43220) = true)

theorem identity43220 : scanCanonicalize (H12AffineFastState.compose env43220 (packedSelected [0,1,9,10,11,17,18,19,22,23,27,28,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound43220 : packedSelected [0,1,9,10,11,17,18,19,22,23,27,28,32] rootPS < 2^1333 := by decide +kernel

def env43221 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,5528,89514,1025,29829,4112,65831,29724,65796,8328,16,2184,24861,12557,67754,1420,95650,257,21793,16384,74251]

theorem envBound43221 : H12AffineFastState.Bounded env43221 := by
  intro p hp
  have h : env43221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43220_43221 : H12AffineEnvironment.transform 16 5528 env43220 = env43221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env43220 == env43221) = true)

theorem identity43221 : scanCanonicalize (H12AffineFastState.compose env43221 (packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound43221 : packedSelected [0,3,4,7,10,16,17,19,20,22,24] rootPS < 2^1333 := by decide +kernel

def env43222 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,263,5528,23725,1025,29829,4112,32,29724,3,8328,16,2184,24861,12557,2477,1420,29861,257,21793,16384,8972]

theorem envBound43222 : H12AffineFastState.Bounded env43222 := by
  intro p hp
  have h : env43222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43221_43222 : H12AffineEnvironment.transform 15 263 env43221 = env43222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env43221 == env43222) = true)

theorem identity43222 : scanCanonicalize (H12AffineFastState.compose env43222 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43222 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env43223 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21897,263,5528,23725,1025,21896,4112,32,21777,3,389,16,2184,16400,4096,2477,1420,21928,257,21793,16384,513]

theorem envBound43223 : H12AffineFastState.Bounded env43223 := by
  intro p hp
  have h : env43223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43222_43223 : H12AffineEnvironment.transform 12 269 env43222 = env43223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43222 == env43223) = true)

theorem identity43223 : scanCanonicalize (H12AffineFastState.compose env43223 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43223 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43224 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21760,263,5393,23588,1025,21761,4112,32,21777,3,268,16,2049,16400,4096,2340,1285,21793,257,21793,16384,513]

theorem envBound43224 : H12AffineFastState.Bounded env43224 := by
  intro p hp
  have h : env43224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43223_43224 : H12AffineEnvironment.transform 6 9 env43223 = env43224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43223 == env43224) = true)

theorem identity43224 : scanCanonicalize (H12AffineFastState.compose env43224 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound43224 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env43225 : List Nat := [2,4,8,16,32,16,9,256,512,52,2048,4096,269,16384,20788,263,4389,22544,53,20789,4112,32,20773,3,268,16,2049,16400,4096,2340,305,20757,257,20757,16384,513]

theorem envBound43225 : H12AffineFastState.Bounded env43225 := by
  intro p hp
  have h : env43225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43224_43225 : H12AffineEnvironment.transform 9 52 env43224 = env43225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env43224 == env43225) = true)

theorem identity43225 : scanCanonicalize (H12AffineFastState.compose env43225 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43225 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env43226 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,4096,269,16384,20788,263,4389,20497,53,20789,4112,32,20773,3,268,16,0,16400,4096,293,305,20757,257,20757,16384,513]

theorem envBound43226 : H12AffineFastState.Bounded env43226 := by
  intro p hp
  have h : env43226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43225_43226 : H12AffineEnvironment.transform 10 1 env43225 = env43226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43225 == env43226) = true)

theorem identity43226 : scanCanonicalize (H12AffineFastState.compose env43226 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound43226 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43227 : List Nat := [2,4,8,16,32,16,9,256,512,52,1,4096,269,4404,0,263,4389,293,53,1,4112,32,17,3,268,16,0,4388,4096,293,305,33,257,33,4404,513]

theorem envBound43227 : H12AffineFastState.Bounded env43227 := by
  intro p hp
  have h : env43227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43226_43227 : H12AffineEnvironment.transform 13 4404 env43226 = env43227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env43226 == env43227) = true)

theorem identity43227 : scanCanonicalize (H12AffineFastState.compose env43227 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43227 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43228 : List Nat := [2,4,8,16,32,16,9,5,512,52,1,4096,8,4145,0,2,4128,32,53,1,4112,32,17,3,9,16,0,4129,4096,32,52,33,4,33,4145,513]

theorem envBound43228 : H12AffineFastState.Bounded env43228 := by
  intro p hp
  have h : env43228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43227_43228 : H12AffineEnvironment.transform 7 5 env43227 = env43228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43227 == env43228) = true)

theorem identity43228 : scanCanonicalize (H12AffineFastState.compose env43228 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound43228 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43229 : List Nat := [2,4,8,16,32,16,9,5,512,52,1,571,8,522,0,2,539,32,53,1,555,32,17,3,9,16,0,538,571,32,52,33,4,33,522,513]

theorem envBound43229 : H12AffineFastState.Bounded env43229 := by
  intro p hp
  have h : env43229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43228_43229 : H12AffineEnvironment.transform 11 571 env43228 = env43229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env43228 == env43229) = true)

theorem identity43229 : scanCanonicalize (H12AffineFastState.compose env43229 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound43229 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43230 : List Nat := [2,4,3,16,32,16,2,5,512,52,1,560,3,513,0,2,528,32,53,1,544,32,17,3,2,16,0,529,560,32,52,33,4,33,513,513]

theorem envBound43230 : H12AffineFastState.Bounded env43230 := by
  intro p hp
  have h : env43230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43229_43230 : H12AffineEnvironment.transform 2 3 env43229 = env43230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env43229 == env43230) = true)

theorem identity43230 : scanCanonicalize (H12AffineFastState.compose env43230 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 4) := by decide +kernel

theorem selectedBound43230 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43231 : List Nat := [2,4,3,16,32,16,2,5,4,52,1,52,3,5,0,2,20,32,53,1,36,32,17,3,2,16,0,21,52,32,52,33,4,33,5,5]

theorem envBound43231 : H12AffineFastState.Bounded env43231 := by
  intro p hp
  have h : env43231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43230_43231 : H12AffineEnvironment.transform 8 4 env43230 = env43231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 4 env43230 == env43231) = true)

theorem identity43231 : scanCanonicalize (H12AffineFastState.compose env43231 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound43231 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43232 : List Nat := [2,4,3,16,16,16,2,5,4,4,1,4,3,5,0,2,20,16,5,1,20,16,17,3,2,16,0,21,4,16,4,17,4,17,5,5]

theorem envBound43232 : H12AffineFastState.Bounded env43232 := by
  intro p hp
  have h : env43232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43231_43232 : H12AffineEnvironment.transform 4 16 env43231 = env43232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env43231 == env43232) = true)

theorem identity43232 : scanCanonicalize (H12AffineFastState.compose env43232 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound43232 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43233 : List Nat := [2,4,3,5,5,5,2,5,4,4,1,4,3,5,0,2,1,5,5,1,1,5,4,3,2,5,0,0,4,5,4,4,4,4,5,5]

theorem envBound43233 : H12AffineFastState.Bounded env43233 := by
  intro p hp
  have h : env43233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43232_43233 : H12AffineEnvironment.transform 3 5 env43232 = env43233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env43232 == env43233) = true)

theorem identity43233 : scanCanonicalize (H12AffineFastState.compose env43233 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43233 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43234 : List Nat := [1,4,0,5,5,5,1,5,4,4,1,4,0,5,0,1,1,5,5,1,1,5,4,0,1,5,0,0,4,5,4,4,4,4,5,5]

theorem envBound43234 : H12AffineFastState.Bounded env43234 := by
  intro p hp
  have h : env43234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43233_43234 : H12AffineEnvironment.transform 0 1 env43233 = env43234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43233 == env43234) = true)

def env43235 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1025,29828,4113,411924,156037,201885,8328,17,2184,160900,140436,283904,1421,272392,257,21793,16385,74251]

theorem envBound43235 : H12AffineFastState.Bounded env43235 := by
  intro p hp
  have h : env43235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43218_43235 : H12AffineEnvironment.transform 5 17 env43218 = env43235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43218 == env43235) = true)

theorem identity43235 : scanCanonicalize (H12AffineFastState.compose env43235 (packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 204219) := by decide +kernel

theorem selectedBound43235 : packedSelected [4,5,7,8,9,11,12,15,16,17,19,20,24,27,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env43236 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,204219,1025,29828,4113,87215,156037,201885,8328,17,2184,160900,140436,215227,1421,210355,257,21793,16385,74251]

theorem envBound43236 : H12AffineFastState.Bounded env43236 := by
  intro p hp
  have h : env43236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43235_43236 : H12AffineEnvironment.transform 17 204219 env43235 = env43236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 204219 env43235 == env43236) = true)

theorem identity43236 : scanCanonicalize (H12AffineFastState.compose env43236 (packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 79250) := by decide +kernel

theorem selectedBound43236 : packedSelected [5,8,10,16,17,18,20,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env43237 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,79250,10281,1025,29828,4113,87215,87063,8463,8328,17,2184,82198,69894,32041,1421,33,257,21793,16385,74251]

theorem envBound43237 : H12AffineFastState.Bounded env43237 := by
  intro p hp
  have h : env43237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43236_43237 : H12AffineEnvironment.transform 16 79250 env43236 = env43237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79250 env43236 == env43237) = true)

theorem identity43237 : scanCanonicalize (H12AffineFastState.compose env43237 (packedSelected [0,2,3,5,6,7,10,11,17,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound43237 : packedSelected [0,2,3,5,6,7,10,11,17,20,23] rootPS < 2^1333 := by decide +kernel

def env43238 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,1,65536,79250,10281,1025,0,4113,73771,73875,8463,8328,17,2184,79250,69894,2477,1421,33,257,8613,13445,74251]

theorem envBound43238 : H12AffineFastState.Bounded env43238 := by
  intro p hp
  have h : env43238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43237_43238 : H12AffineEnvironment.transform 13 13444 env43237 = env43238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env43237 == env43238) = true)

theorem identity43238 : scanCanonicalize (H12AffineFastState.compose env43238 (packedSelected [1,8,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound43238 : packedSelected [1,8,17,19] rootPS < 2^1333 := by decide +kernel

def env43239 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13444,1,263,13461,10281,1025,0,4113,8492,8596,8463,8328,17,2184,13461,4097,2477,1421,33,257,8613,13445,8972]

theorem envBound43239 : H12AffineFastState.Bounded env43239 := by
  intro p hp
  have h : env43239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43238_43239 : H12AffineEnvironment.transform 15 263 env43238 = env43239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env43238 == env43239) = true)

theorem identity43239 : scanCanonicalize (H12AffineFastState.compose env43239 (packedSelected [2,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 6315) := by decide +kernel

theorem selectedBound43239 : packedSelected [2,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env43240 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,6315,3119,1,263,3134,4226,1025,0,4113,6535,6463,6564,6179,17,2184,3134,4097,2477,1421,33,257,6414,3118,7079]

theorem envBound43240 : H12AffineFastState.Bounded env43240 := by
  intro p hp
  have h : env43240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43239_43240 : H12AffineEnvironment.transform 12 6315 env43239 = env43240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6315 env43239 == env43240) = true)

theorem identity43240 : scanCanonicalize (H12AffineFastState.compose env43240 (packedSelected [0,1,5,9,11,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2200) := by decide +kernel

theorem selectedBound43240 : packedSelected [0,1,5,9,11,15,16] rootPS < 2^1333 := by decide +kernel

def env43241 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2200,51,3119,1,263,3134,2074,1025,0,2185,287,423,316,187,17,2184,3134,2201,2477,1421,33,257,406,3118,831]

theorem envBound43241 : H12AffineFastState.Bounded env43241 := by
  intro p hp
  have h : env43241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43240_43241 : H12AffineEnvironment.transform 11 2200 env43240 = env43241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2200 env43240 == env43241) = true)

theorem identity43241 : scanCanonicalize (H12AffineFastState.compose env43241 (packedSelected [0,2,6,7,10,11] rootPS)) = affineNative (2^(9+1) ^^^ 435) := by decide +kernel

theorem selectedBound43241 : packedSelected [0,2,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env43242 : List Nat := [2,4,8,16,32,17,128,256,512,435,2048,2200,51,2460,1,263,2445,2074,434,0,2185,287,423,316,187,17,2184,2445,2201,2477,62,33,257,406,2461,831]

theorem envBound43242 : H12AffineFastState.Bounded env43242 := by
  intro p hp
  have h : env43242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43241_43242 : H12AffineEnvironment.transform 9 435 env43241 = env43242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 435 env43241 == env43242) = true)

theorem identity43242 : scanCanonicalize (H12AffineFastState.compose env43242 (packedSelected [0,1,5,6,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound43242 : packedSelected [0,1,5,6,9,10] rootPS < 2^1333 := by decide +kernel

def env43243 : List Nat := [2,4,8,16,32,17,128,31,512,172,2048,2200,51,2179,1,24,2194,2074,173,0,2185,0,184,35,187,17,2184,2194,2201,2226,62,33,30,137,2178,544]

theorem envBound43243 : H12AffineFastState.Bounded env43243 := by
  intro p hp
  have h : env43243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43242_43243 : H12AffineEnvironment.transform 7 31 env43242 = env43243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env43242 == env43243) = true)

theorem identity43243 : scanCanonicalize (H12AffineFastState.compose env43243 (packedSelected [0,1,2,3,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound43243 : packedSelected [0,1,2,3,9] rootPS < 2^1333 := by decide +kernel

def env43244 : List Nat := [2,4,8,16,32,17,8,31,512,36,2048,2064,51,2059,1,24,2074,2074,37,0,2049,0,48,35,51,17,2048,2074,2065,2106,62,33,30,1,2058,544]

theorem envBound43244 : H12AffineFastState.Bounded env43244 := by
  intro p hp
  have h : env43244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43243_43244 : H12AffineEnvironment.transform 6 8 env43243 = env43244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43243 == env43244) = true)

theorem identity43244 : scanCanonicalize (H12AffineFastState.compose env43244 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound43244 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env43245 : List Nat := [2,4,8,16,32,17,8,31,17,36,2048,2064,51,2059,1,24,2074,2074,37,0,2049,0,48,35,51,17,2048,2074,2065,2106,62,33,30,1,2058,49]

theorem envBound43245 : H12AffineFastState.Bounded env43245 := by
  intro p hp
  have h : env43245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43244_43245 : H12AffineEnvironment.transform 8 17 env43244 = env43245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env43244 == env43245) = true)

theorem identity43245 : scanCanonicalize (H12AffineFastState.compose env43245 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43245 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43246 : List Nat := [2,4,8,16,1,17,8,31,17,5,2048,2064,18,2059,1,24,2074,2074,4,0,2049,0,17,2,18,17,2048,2074,2065,2075,31,0,30,1,2058,16]

theorem envBound43246 : H12AffineFastState.Bounded env43246 := by
  intro p hp
  have h : env43246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43245_43246 : H12AffineEnvironment.transform 4 1 env43245 = env43246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43245 == env43246) = true)

theorem identity43246 : scanCanonicalize (H12AffineFastState.compose env43246 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound43246 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43247 : List Nat := [2,4,8,2,1,3,8,13,3,5,2048,2050,0,2059,1,10,2056,2056,4,0,2049,0,3,2,0,3,2048,2056,2051,2057,13,0,12,1,2058,2]

theorem envBound43247 : H12AffineFastState.Bounded env43247 := by
  intro p hp
  have h : env43247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43246_43247 : H12AffineEnvironment.transform 3 2 env43246 = env43247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env43246 == env43247) = true)

theorem identity43247 : scanCanonicalize (H12AffineFastState.compose env43247 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound43247 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43248 : List Nat := [2,4,1,2,1,3,1,4,3,5,2048,2050,0,2050,1,3,2049,2049,4,0,2049,0,3,2,0,3,2048,2049,2051,2048,4,0,5,1,2051,2]

theorem envBound43248 : H12AffineFastState.Bounded env43248 := by
  intro p hp
  have h : env43248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43247_43248 : H12AffineEnvironment.transform 2 1 env43247 = env43248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env43247 == env43248) = true)

theorem identity43248 : scanCanonicalize (H12AffineFastState.compose env43248 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43248 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43249 : List Nat := [2,4,1,2,1,3,1,4,3,5,1,3,0,3,1,3,0,0,4,0,0,0,3,2,0,3,1,0,2,1,4,0,5,1,2,2]

theorem envBound43249 : H12AffineFastState.Bounded env43249 := by
  intro p hp
  have h : env43249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43248_43249 : H12AffineEnvironment.transform 10 1 env43248 = env43249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43248 == env43249) = true)

theorem identity43249 : scanCanonicalize (H12AffineFastState.compose env43249 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43249 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43250 : List Nat := [2,2,1,2,1,3,1,2,3,3,1,3,0,3,1,3,0,0,2,0,0,0,3,2,0,3,1,0,2,1,2,0,3,1,2,2]

theorem envBound43250 : H12AffineFastState.Bounded env43250 := by
  intro p hp
  have h : env43250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43249_43250 : H12AffineEnvironment.transform 1 2 env43249 = env43250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43249 == env43250) = true)

theorem identity43250 : scanCanonicalize (H12AffineFastState.compose env43250 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound43250 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env43251 : List Nat := [1,1,1,1,1,0,1,1,0,0,1,0,0,0,1,0,0,0,1,0,0,0,0,1,0,0,1,0,1,1,1,0,0,1,1,1]

theorem envBound43251 : H12AffineFastState.Bounded env43251 := by
  intro p hp
  have h : env43251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43250_43251 : H12AffineEnvironment.transform 0 1 env43250 = env43251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env43250 == env43251) = true)

def env43252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156117,253976,8328,64,64605,160980,140485,303573,1501,272393,257,21793,46212,74250]

theorem envBound43252 : H12AffineFastState.Bounded env43252 := by
  intro p hp
  have h : env43252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43216_43252 : H12AffineEnvironment.transform 20 4161 env43216 = env43252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43216 == env43252) = true)

theorem identity43252 : scanCanonicalize (H12AffineFastState.compose env43252 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 25028) := by decide +kernel

theorem selectedBound43252 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,25028,262144,1025,32769,4161,318549,17,98780,8328,64,64605,5392,17665,303573,1501,272393,257,21793,46212,74250]

theorem envBound43253 : H12AffineFastState.Bounded env43253 := by
  intro p hp
  have h : env43253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43252_43253 : H12AffineEnvironment.transform 16 25028 env43252 = env43253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 25028 env43252 == env43253) = true)

def env43254 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,262144,1025,32769,4161,318549,17,98644,8192,64,64605,5392,17665,303453,1365,272393,257,21793,46092,74250]

theorem envBound43254 : H12AffineFastState.Bounded env43254 := by
  intro p hp
  have h : env43254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43253_43254 : H12AffineEnvironment.transform 6 8 env43253 = env43254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43253 == env43254) = true)

theorem identity43254 : scanCanonicalize (H12AffineFastState.compose env43254 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound43254 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43255 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,24908,35188,1025,32769,4161,21793,17,98644,8192,64,64605,5392,17665,10281,1365,41341,257,21793,46092,74250]

theorem envBound43255 : H12AffineFastState.Bounded env43255 := by
  intro p hp
  have h : env43255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43254_43255 : H12AffineEnvironment.transform 17 35188 env43254 = env43255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env43254 == env43255) = true)

theorem identity43255 : scanCanonicalize (H12AffineFastState.compose env43255 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound43255 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43256 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,24860,35108,1025,32769,4113,21793,17,98564,8192,16,64525,5392,17665,10281,1285,41261,257,21793,46092,74250]

theorem envBound43256 : H12AffineFastState.Bounded env43256 := by
  intro p hp
  have h : env43256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43255_43256 : H12AffineEnvironment.transform 5 16 env43255 = env43256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43255 == env43256) = true)

theorem identity43256 : scanCanonicalize (H12AffineFastState.compose env43256 (packedSelected [4,5,9,12,14,15,19,20,24] rootPS)) = affineNative (2^(15+1) ^^^ 21795) := by decide +kernel

theorem selectedBound43256 : packedSelected [4,5,9,12,14,15,19,20,24] rootPS < 2^1333 := by decide +kernel

def env43257 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,21795,24860,35108,1025,32769,4113,21793,17,54311,8192,16,64525,5392,17665,10281,1285,41261,257,21793,46092,30505]

theorem envBound43257 : H12AffineFastState.Bounded env43257 := by
  intro p hp
  have h : env43257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43256_43257 : H12AffineEnvironment.transform 15 21795 env43256 = env43257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21795 env43256 == env43257) = true)

theorem identity43257 : scanCanonicalize (H12AffineFastState.compose env43257 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound43257 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43258 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,13608,32768,8203,5172,35108,1025,32769,4113,8201,17,41231,8192,16,35109,5392,12329,10281,1285,41261,257,8201,46092,513]

theorem envBound43258 : H12AffineFastState.Bounded env43258 := by
  intro p hp
  have h : env43258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43257_43258 : H12AffineEnvironment.transform 13 13608 env43257 = env43258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env43257 == env43258) = true)

theorem identity43258 : scanCanonicalize (H12AffineFastState.compose env43258 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound43258 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env43259 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,1337,4113,32768,1330,5172,35108,1025,32769,4113,1328,17,33846,1337,16,35109,5392,5392,3344,1285,33812,257,1328,37173,513]

theorem envBound43259 : H12AffineFastState.Bounded env43259 := by
  intro p hp
  have h : env43259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43258_43259 : H12AffineEnvironment.transform 12 1337 env43258 = env43259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env43258 == env43259) = true)

def env43260 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,262144,1025,32769,4161,318549,17,98645,8193,64,64605,5392,17665,303452,1364,272393,257,21793,46093,74250]

theorem envBound43260 : H12AffineFastState.Bounded env43260 := by
  intro p hp
  have h : env43260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43253_43260 : H12AffineEnvironment.transform 6 9 env43253 = env43260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43253 == env43260) = true)

theorem identity43260 : scanCanonicalize (H12AffineFastState.compose env43260 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound43260 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,24909,10281,1025,32769,4161,62588,17,98645,8193,64,64605,5392,17665,35189,1364,32,257,21793,46093,74250]

theorem envBound43261 : H12AffineFastState.Bounded env43261 := by
  intro p hp
  have h : env43261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43260_43261 : H12AffineEnvironment.transform 17 10281 env43260 = env43261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env43260 == env43261) = true)

theorem identity43261 : scanCanonicalize (H12AffineFastState.compose env43261 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound43261 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env43262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62730,24909,10281,1025,32769,4161,62588,17,29791,8193,64,64605,5392,17665,35189,1364,32,257,21793,46093,55040]

theorem envBound43262 : H12AffineFastState.Bounded env43262 := by
  intro p hp
  have h : env43262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43261_43262 : H12AffineEnvironment.transform 15 62730 env43261 = env43262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env43261 == env43262) = true)

theorem identity43262 : scanCanonicalize (H12AffineFastState.compose env43262 (packedSelected [0,1,4,7,8,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound43262 : packedSelected [0,1,4,7,8,19,22] rootPS < 2^1333 := by decide +kernel

def env43263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21591,24909,10281,1025,8540,4161,21793,17,29791,8193,64,23808,5392,17665,10280,1364,32,257,21793,5456,30301]

theorem envBound43263 : H12AffineFastState.Bounded env43263 := by
  intro p hp
  have h : env43263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43262_43263 : H12AffineEnvironment.transform 14 8541 env43262 = env43263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env43262 == env43263) = true)

theorem identity43263 : scanCanonicalize (H12AffineFastState.compose env43263 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound43263 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env43264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8203,5393,10281,1025,8540,4161,8573,17,3,8193,64,10588,5392,12637,10280,1364,32,257,8573,5456,513]

theorem envBound43264 : H12AffineFastState.Bounded env43264 := by
  intro p hp
  have h : env43264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43263_43264 : H12AffineEnvironment.transform 13 13404 env43263 = env43264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env43263 == env43264) = true)

theorem identity43264 : scanCanonicalize (H12AffineFastState.compose env43264 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound43264 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,1,343,5393,2421,1025,0,4161,33,17,3,349,64,2048,5392,4097,2420,1364,32,257,33,5456,513]

theorem envBound43265 : H12AffineFastState.Bounded env43265 := by
  intro p hp
  have h : env43265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43264_43265 : H12AffineEnvironment.transform 12 348 env43264 = env43265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env43264 == env43265) = true)

theorem identity43265 : scanCanonicalize (H12AffineFastState.compose env43265 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound43265 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,16,348,1296,1,343,1281,2421,1025,0,81,33,17,3,349,64,2048,1280,17,2420,1364,32,257,33,1344,513]

theorem envBound43266 : H12AffineFastState.Bounded env43266 := by
  intro p hp
  have h : env43266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43265_43266 : H12AffineEnvironment.transform 11 16 env43265 = env43266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env43265 == env43266) = true)

theorem identity43266 : scanCanonicalize (H12AffineFastState.compose env43266 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1557) := by decide +kernel

theorem selectedBound43266 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43267 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1557,16,348,1296,1,343,1281,1888,1025,0,81,33,17,3,349,64,1557,1280,17,1889,1364,32,257,33,1344,513]

theorem envBound43267 : H12AffineFastState.Bounded env43267 := by
  intro p hp
  have h : env43267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43266_43267 : H12AffineEnvironment.transform 10 1557 env43266 = env43267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1557 env43266 == env43267) = true)

theorem identity43267 : scanCanonicalize (H12AffineFastState.compose env43267 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 864) := by decide +kernel

theorem selectedBound43267 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43268 : List Nat := [2,4,8,16,32,64,9,256,512,864,373,16,348,624,1,343,609,0,865,0,81,33,17,3,349,64,373,608,17,1,564,32,257,33,544,513]

theorem envBound43268 : H12AffineFastState.Bounded env43268 := by
  intro p hp
  have h : env43268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43267_43268 : H12AffineEnvironment.transform 9 864 env43267 = env43268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 864 env43267 == env43268) = true)

theorem identity43268 : scanCanonicalize (H12AffineFastState.compose env43268 (packedSelected [1,8] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound43268 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43269 : List Nat := [2,4,8,16,32,64,9,256,276,116,373,16,348,356,1,343,373,0,117,0,81,33,17,3,349,64,373,372,17,1,288,32,257,33,308,277]

theorem envBound43269 : H12AffineFastState.Bounded env43269 := by
  intro p hp
  have h : env43269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43268_43269 : H12AffineEnvironment.transform 8 276 env43268 = env43269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env43268 == env43269) = true)

theorem identity43269 : scanCanonicalize (H12AffineFastState.compose env43269 (packedSelected [0,9] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43269 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env43270 : List Nat := [2,4,8,16,0,64,9,256,276,84,341,16,348,324,1,343,341,0,85,0,81,1,17,3,349,64,341,340,17,1,256,0,257,1,276,277]

theorem envBound43270 : H12AffineFastState.Bounded env43270 := by
  intro p hp
  have h : env43270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43269_43270 : H12AffineEnvironment.transform 4 0 env43269 = env43270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43269 == env43270) = true)

theorem identity43270 : scanCanonicalize (H12AffineFastState.compose env43270 (packedSelected [0,1,2,5] rootPS)) = affineNative (2^(7+1) ^^^ 68) := by decide +kernel

theorem selectedBound43270 : packedSelected [0,1,2,5] rootPS < 2^1333 := by decide +kernel

def env43271 : List Nat := [2,4,8,16,0,64,9,68,80,84,17,16,24,0,1,19,17,0,85,0,81,1,17,3,25,64,17,16,17,1,68,0,69,1,80,81]

theorem envBound43271 : H12AffineFastState.Bounded env43271 := by
  intro p hp
  have h : env43271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43270_43271 : H12AffineEnvironment.transform 7 68 env43270 = env43271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 68 env43270 == env43271) = true)

theorem identity43271 : scanCanonicalize (H12AffineFastState.compose env43271 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound43271 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43272 : List Nat := [2,4,8,16,0,10,9,14,26,30,17,16,24,0,1,19,17,0,31,0,27,1,17,3,25,10,17,16,17,1,14,0,15,1,26,27]

theorem envBound43272 : H12AffineFastState.Bounded env43272 := by
  intro p hp
  have h : env43272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43271_43272 : H12AffineEnvironment.transform 5 10 env43271 = env43272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env43271 == env43272) = true)

theorem identity43272 : scanCanonicalize (H12AffineFastState.compose env43272 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43272 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43273 : List Nat := [2,4,8,0,0,10,9,14,10,14,1,0,8,0,1,3,1,0,15,0,11,1,1,3,9,10,1,0,1,1,14,0,15,1,10,11]

theorem envBound43273 : H12AffineFastState.Bounded env43273 := by
  intro p hp
  have h : env43273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43272_43273 : H12AffineEnvironment.transform 3 0 env43272 = env43273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43272 == env43273) = true)

def env43274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,2257301,253976,8328,64,6705548,2253973,140484,2404757,2102685,6456793,257,21792,46213,2175562]

theorem envBound43274 : H12AffineFastState.Bounded env43274 := by
  intro p hp
  have h : env43274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43138_43274 : H12AffineEnvironment.transform 22 2257301 env43138 = env43274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2257301 env43138 == env43274) = true)

def env43275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441744,2257301,253976,8328,64,2157596,2253973,140484,2404757,2102685,2373705,257,21792,46213,2175562]

theorem envBound43275 : H12AffineFastState.Bounded env43275 := by
  intro p hp
  have h : env43275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43274_43275 : H12AffineEnvironment.transform 21 441744 env43274 = env43275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441744 env43274 == env43275) = true)

def env43276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,253976,8328,64,64604,160981,140484,303573,1501,272393,257,21792,46213,74250]

theorem envBound43276 : H12AffineFastState.Bounded env43276 := by
  intro p hp
  have h : env43276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43275_43276 : H12AffineEnvironment.transform 20 4160 env43275 = env43276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43275 == env43276) = true)

theorem identity43276 : scanCanonicalize (H12AffineFastState.compose env43276 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82383) := by decide +kernel

theorem selectedBound43276 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82383,262144,1025,32769,4160,392287,73754,41431,8328,64,64604,79130,91403,303573,1501,272393,257,21792,46213,74250]

theorem envBound43277 : H12AffineFastState.Bounded env43277 := by
  intro p hp
  have h : env43277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43276_43277 : H12AffineEnvironment.transform 16 82383 env43276 = env43277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82383 env43276 == env43277) = true)

def env43278 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,4160,392287,73754,41311,8192,64,64604,79130,91403,303453,1365,272393,257,21792,46093,74250]

theorem envBound43278 : H12AffineFastState.Bounded env43278 := by
  intro p hp
  have h : env43278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43277_43278 : H12AffineEnvironment.transform 6 8 env43277 = env43278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43277 == env43278) = true)

theorem identity43278 : scanCanonicalize (H12AffineFastState.compose env43278 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(14+1) ^^^ 8312) := by decide +kernel

theorem selectedBound43278 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env43279 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8312,65536,82247,262144,1025,8313,4160,351271,73754,295,8192,64,23588,79130,91403,262437,1365,272393,257,21792,5237,74250]

theorem envBound43279 : H12AffineFastState.Bounded env43279 := by
  intro p hp
  have h : env43279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43278_43279 : H12AffineEnvironment.transform 14 8312 env43278 = env43279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8312 env43278 == env43279) = true)

theorem identity43279 : scanCanonicalize (H12AffineFastState.compose env43279 (packedSelected [1,2,3,4,6,7,8,12,14,15,18,22,24,27,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 89378) := by decide +kernel

theorem selectedBound43279 : packedSelected [1,2,3,4,6,7,8,12,14,15,18,22,24,27,31,32] rootPS < 2^1333 := by decide +kernel

def env43280 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8312,65536,82247,89378,1025,8313,4160,261,73754,295,8192,64,23588,79130,91403,89095,1365,95531,257,21792,5237,74250]

theorem envBound43280 : H12AffineFastState.Bounded env43280 := by
  intro p hp
  have h : env43280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43279_43280 : H12AffineEnvironment.transform 17 89378 env43279 = env43280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89378 env43279 == env43280) = true)

theorem identity43280 : scanCanonicalize (H12AffineFastState.compose env43280 (packedSelected [0,1,4,7,8,12,15,17,18,19,22,23] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43280 : packedSelected [0,1,4,7,8,12,15,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env43281 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,372,65536,82247,89378,1025,373,4160,261,65814,295,268,64,23588,70678,82951,89095,1365,87079,257,21792,5237,66310]

theorem envBound43281 : H12AffineFastState.Bounded env43281 := by
  intro p hp
  have h : env43281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43280_43281 : H12AffineEnvironment.transform 12 268 env43280 = env43281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43280 == env43281) = true)

theorem identity43281 : scanCanonicalize (H12AffineFastState.compose env43281 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 115) := by decide +kernel

theorem selectedBound43281 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env43282 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,372,115,16692,23889,1025,373,4160,261,357,295,268,64,23588,5221,17524,23668,1365,21588,257,21792,5237,885]

theorem envBound43282 : H12AffineFastState.Bounded env43282 := by
  intro p hp
  have h : env43282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43281_43282 : H12AffineEnvironment.transform 15 115 env43281 = env43282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 115 env43281 == env43282) = true)

theorem identity43282 : scanCanonicalize (H12AffineFastState.compose env43282 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound43282 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env43283 : List Nat := [2,4,8,16,32,64,8,117,512,1024,2048,4096,121,16384,1,115,16449,23588,1025,0,4160,112,16,82,121,64,23588,5221,17524,23668,1056,21588,116,21589,5237,512]

theorem envBound43283 : H12AffineFastState.Bounded env43283 := by
  intro p hp
  have h : env43283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43282_43283 : H12AffineEnvironment.transform 7 117 env43282 = env43283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env43282 == env43283) = true)

theorem identity43283 : scanCanonicalize (H12AffineFastState.compose env43283 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43283 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43284 : List Nat := [2,4,8,16,1,64,8,84,512,1024,2048,4096,88,16384,1,82,16449,23557,1025,0,4160,81,16,82,88,64,23557,5188,17493,23637,1025,21588,85,21589,5204,512]

theorem envBound43284 : H12AffineFastState.Bounded env43284 := by
  intro p hp
  have h : env43284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43283_43284 : H12AffineEnvironment.transform 4 1 env43283 = env43284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43283 == env43284) = true)

theorem identity43284 : scanCanonicalize (H12AffineFastState.compose env43284 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43284 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env43285 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,16384,1,3,16400,23557,1025,0,4113,0,16,3,9,17,23557,5141,17412,23556,1025,21509,4,21508,5125,512]

theorem envBound43285 : H12AffineFastState.Bounded env43285 := by
  intro p hp
  have h : env43285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43284_43285 : H12AffineEnvironment.transform 5 17 env43284 = env43285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43284 == env43285) = true)

theorem identity43285 : scanCanonicalize (H12AffineFastState.compose env43285 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 6170) := by decide +kernel

theorem selectedBound43285 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env43286 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,4096,9,6170,1,3,6154,1055,1025,0,4113,0,16,3,9,17,1055,5141,7198,1054,1025,3103,4,3102,5125,512]

theorem envBound43286 : H12AffineFastState.Bounded env43286 := by
  intro p hp
  have h : env43286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43285_43286 : H12AffineEnvironment.transform 13 6170 env43285 = env43286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 6170 env43285 == env43286) = true)

theorem identity43286 : scanCanonicalize (H12AffineFastState.compose env43286 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(11+1) ^^^ 1045) := by decide +kernel

theorem selectedBound43286 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env43287 : List Nat := [2,4,8,16,1,17,8,5,512,1024,2048,1045,9,3087,1,3,3103,1055,1025,0,1028,0,16,3,9,17,1055,0,2059,1054,1025,3103,4,3102,16,512]

theorem envBound43287 : H12AffineFastState.Bounded env43287 := by
  intro p hp
  have h : env43287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43286_43287 : H12AffineEnvironment.transform 11 1045 env43286 = env43287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env43286 == env43287) = true)

theorem identity43287 : scanCanonicalize (H12AffineFastState.compose env43287 (packedSelected [2,11] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound43287 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env43288 : List Nat := [2,4,8,16,1,17,8,5,512,21,2048,0,9,2074,1,3,2058,10,20,0,17,0,16,3,9,17,10,0,2059,11,20,2058,4,2059,16,512]

theorem envBound43288 : H12AffineFastState.Bounded env43288 := by
  intro p hp
  have h : env43288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43287_43288 : H12AffineEnvironment.transform 9 21 env43287 = env43288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env43287 == env43288) = true)

theorem identity43288 : scanCanonicalize (H12AffineFastState.compose env43288 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound43288 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env43289 : List Nat := [2,4,8,9,1,8,8,5,512,12,2048,0,9,2051,1,3,2058,10,13,0,8,0,9,3,9,8,10,0,2059,11,13,2058,4,2059,9,512]

theorem envBound43289 : H12AffineFastState.Bounded env43289 := by
  intro p hp
  have h : env43289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43288_43289 : H12AffineEnvironment.transform 3 9 env43288 = env43289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env43288 == env43289) = true)

def env43290 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,4160,392287,73754,41310,8193,64,64604,79130,91403,303452,1364,272393,257,21792,46092,74250]

theorem envBound43290 : H12AffineFastState.Bounded env43290 := by
  intro p hp
  have h : env43290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43277_43290 : H12AffineEnvironment.transform 6 9 env43277 = env43290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43277 == env43290) = true)

theorem identity43290 : scanCanonicalize (H12AffineFastState.compose env43290 (packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound43290 : packedSelected [1,4,5,9,11,12,14,19,20,24,26,28,31,32,38] rootPS < 2^1333 := by decide +kernel

def env43291 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57677,262144,1025,32769,4160,285780,32785,41310,8193,64,64604,38161,50432,303452,1364,272393,257,21792,46092,33281]

theorem envBound43291 : H12AffineFastState.Bounded env43291 := by
  intro p hp
  have h : env43291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43290_43291 : H12AffineEnvironment.transform 15 40971 env43290 = env43291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env43290 == env43291) = true)

theorem identity43291 : scanCanonicalize (H12AffineFastState.compose env43291 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound43291 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env43292 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,57677,35188,1025,32769,4160,54560,32785,41310,8193,64,64604,38161,50432,10280,1364,41341,257,21792,46092,33281]

theorem envBound43292 : H12AffineFastState.Bounded env43292 := by
  intro p hp
  have h : env43292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43291_43292 : H12AffineEnvironment.transform 17 35188 env43291 = env43292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env43291 == env43292) = true)

theorem identity43292 : scanCanonicalize (H12AffineFastState.compose env43292 (packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound43292 : packedSelected [1,3,5,8,10,16,17,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env43293 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,40971,46157,35188,1025,32769,4160,32800,32785,41310,8193,64,43356,38161,36864,10280,1364,41341,257,32,46092,33281]

theorem envBound43293 : H12AffineFastState.Bounded env43293 := by
  intro p hp
  have h : env43293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43292_43293 : H12AffineEnvironment.transform 13 5376 env43292 = env43293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env43292 == env43293) = true)

theorem identity43293 : scanCanonicalize (H12AffineFastState.compose env43293 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound43293 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43294 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,343,5393,10280,1025,8541,4160,8572,8525,2,8193,64,2048,13389,12636,10280,1364,33,257,32,5456,9053]

theorem envBound43294 : H12AffineFastState.Bounded env43294 := by
  intro p hp
  have h : env43294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43293_43294 : H12AffineEnvironment.transform 14 8540 env43293 = env43294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env43293 == env43294) = true)

theorem identity43294 : scanCanonicalize (H12AffineFastState.compose env43294 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound43294 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43295 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1101,5376,1297,343,5393,3173,1025,1296,4160,1329,1280,2,1100,64,2048,4096,5393,3173,1364,33,257,32,5456,1808]

theorem envBound43295 : H12AffineFastState.Bounded env43295 := by
  intro p hp
  have h : env43295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43294_43295 : H12AffineEnvironment.transform 12 1101 env43294 = env43295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env43294 == env43295) = true)

theorem identity43295 : scanCanonicalize (H12AffineFastState.compose env43295 (packedSelected [4,6,9] rootPS)) = affineNative (2^(9+1) ^^^ 304) := by decide +kernel

theorem selectedBound43295 : packedSelected [4,6,9] rootPS < 2^1333 := by decide +kernel

def env43296 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,4096,381,4144,33,343,4129,2389,305,32,4160,1,48,2,380,64,2048,4096,4129,2389,100,33,257,32,4192,544]

theorem envBound43296 : H12AffineFastState.Bounded env43296 := by
  intro p hp
  have h : env43296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43295_43296 : H12AffineEnvironment.transform 9 304 env43295 = env43296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env43295 == env43296) = true)

theorem identity43296 : scanCanonicalize (H12AffineFastState.compose env43296 (packedSelected [1,3,11] rootPS)) = affineNative (2^(11+1) ^^^ 2404) := by decide +kernel

theorem selectedBound43296 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env43297 : List Nat := [2,4,8,16,32,64,9,256,512,304,2048,2404,381,2388,33,343,2373,2389,305,32,2340,1,48,2,380,64,2048,2404,2373,2389,100,33,257,32,2308,544]

theorem envBound43297 : H12AffineFastState.Bounded env43297 := by
  intro p hp
  have h : env43297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43296_43297 : H12AffineEnvironment.transform 11 2404 env43296 = env43297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2404 env43296 == env43297) = true)

theorem identity43297 : scanCanonicalize (H12AffineFastState.compose env43297 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 837) := by decide +kernel

theorem selectedBound43297 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env43298 : List Nat := [2,4,8,16,32,64,9,256,512,304,837,545,381,529,33,343,512,528,305,32,609,1,48,2,380,64,837,545,512,528,100,33,257,32,577,544]

theorem envBound43298 : H12AffineFastState.Bounded env43298 := by
  intro p hp
  have h : env43298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43297_43298 : H12AffineEnvironment.transform 10 837 env43297 = env43298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 837 env43297 == env43298) = true)

theorem identity43298 : scanCanonicalize (H12AffineFastState.compose env43298 (packedSelected [2,3,4,5,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound43298 : packedSelected [2,3,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env43299 : List Nat := [2,4,8,16,32,64,9,4,512,52,577,545,121,529,33,83,512,528,53,32,609,1,48,2,120,64,577,545,512,528,100,33,5,32,577,544]

theorem envBound43299 : H12AffineFastState.Bounded env43299 := by
  intro p hp
  have h : env43299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43298_43299 : H12AffineEnvironment.transform 7 4 env43298 = env43299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env43298 == env43299) = true)

theorem identity43299 : scanCanonicalize (H12AffineFastState.compose env43299 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43299 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43300 : List Nat := [2,4,8,16,32,17,9,4,512,52,528,545,40,529,33,2,512,528,53,32,560,1,48,2,41,17,528,545,512,528,53,33,5,32,528,544]

theorem envBound43300 : H12AffineFastState.Bounded env43300 := by
  intro p hp
  have h : env43300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43299_43300 : H12AffineEnvironment.transform 5 17 env43299 = env43300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43299 == env43300) = true)

theorem identity43300 : scanCanonicalize (H12AffineFastState.compose env43300 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound43300 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43301 : List Nat := [2,4,8,0,32,1,9,4,512,36,512,545,40,513,33,2,512,512,37,32,544,1,32,2,41,1,512,545,512,512,37,33,5,32,512,544]

theorem envBound43301 : H12AffineFastState.Bounded env43301 := by
  intro p hp
  have h : env43301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43300_43301 : H12AffineEnvironment.transform 3 0 env43300 = env43301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env43300 == env43301) = true)

theorem identity43301 : scanCanonicalize (H12AffineFastState.compose env43301 (packedSelected [2,4] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound43301 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env43302 : List Nat := [2,4,8,0,32,1,9,4,32,36,32,1,40,33,33,2,32,32,37,32,0,1,32,2,41,1,32,1,32,32,37,33,5,32,32,0]

theorem envBound43302 : H12AffineFastState.Bounded env43302 := by
  intro p hp
  have h : env43302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43301_43302 : H12AffineEnvironment.transform 8 32 env43301 = env43302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env43301 == env43302) = true)

def env43303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,253976,8328,64,64605,160980,140484,303572,1500,272392,257,21792,46213,74251]

theorem envBound43303 : H12AffineFastState.Bounded env43303 := by
  intro p hp
  have h : env43303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43275_43303 : H12AffineEnvironment.transform 20 4161 env43275 = env43303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env43275 == env43303) = true)

theorem identity43303 : scanCanonicalize (H12AffineFastState.compose env43303 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound43303 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1025,32769,4161,441744,156116,144583,8328,64,64605,160980,140484,303572,1500,272392,257,21792,46213,63188]

theorem envBound43304 : H12AffineFastState.Bounded env43304 := by
  intro p hp
  have h : env43304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43303_43304 : H12AffineEnvironment.transform 15 54495 env43303 = env43304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env43303 == env43304) = true)

def env43305 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,262144,1025,32769,4113,441744,156036,144535,8328,16,64525,160900,140436,303492,1420,272392,257,21792,46213,63108]

theorem envBound43305 : H12AffineFastState.Bounded env43305 := by
  intro p hp
  have h : env43305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43304_43305 : H12AffineEnvironment.transform 5 16 env43304 = env43305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env43304 == env43305) = true)

theorem identity43305 : scanCanonicalize (H12AffineFastState.compose env43305 (packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS)) = affineNative (2^(17+1) ^^^ 157752) := by decide +kernel

theorem selectedBound43305 : packedSelected [3,4,7,9,12,19,24,27,31,41] rootPS < 2^1333 := by decide +kernel

def env43306 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,131072,157752,1025,32769,4113,54696,156036,144535,8328,16,64525,160900,140436,182716,1420,147504,257,21792,46213,63108]

theorem envBound43306 : H12AffineFastState.Bounded env43306 := by
  intro p hp
  have h : env43306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43305_43306 : H12AffineEnvironment.transform 17 157752 env43305 = env43306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env43305 == env43306) = true)

theorem identity43306 : scanCanonicalize (H12AffineFastState.compose env43306 (packedSelected [0,1,3,4,5,7,8,14,18,22,23,26,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound43306 : packedSelected [0,1,3,4,5,7,8,14,18,22,23,26,31,35] rootPS < 2^1333 := by decide +kernel

def env43307 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,54415,5529,32161,1025,32769,4113,54696,29725,8462,8328,16,64525,24861,12557,56357,1420,21929,257,21792,46213,63108]

theorem envBound43307 : H12AffineFastState.Bounded env43307 := by
  intro p hp
  have h : env43307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43306_43307 : H12AffineEnvironment.transform 16 5529 env43306 = env43307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env43306 == env43307) = true)

theorem identity43307 : scanCanonicalize (H12AffineFastState.compose env43307 (packedSelected [0,1,4,5,7,8,16,17,18,20,22,23,24] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound43307 : packedSelected [0,1,4,5,7,8,16,17,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env43308 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21896,263,5529,32161,1025,21897,4113,32,29725,8462,8328,16,10629,24861,12557,2477,1420,21929,257,21792,24845,8972]

theorem envBound43308 : H12AffineFastState.Bounded env43308 := by
  intro p hp
  have h : env43308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43307_43308 : H12AffineEnvironment.transform 14 21896 env43307 = env43308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env43307 == env43308) = true)

theorem identity43308 : scanCanonicalize (H12AffineFastState.compose env43308 (packedSelected [16,17,20] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound43308 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env43309 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,16384,21896,263,5529,23724,1025,21897,4113,32,21776,3,389,16,2184,16400,4096,2477,1420,21929,257,21792,16384,513]

theorem envBound43309 : H12AffineFastState.Bounded env43309 := by
  intro p hp
  have h : env43309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43308_43309 : H12AffineEnvironment.transform 12 269 env43308 = env43309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env43308 == env43309) = true)

theorem identity43309 : scanCanonicalize (H12AffineFastState.compose env43309 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43309 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env43310 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,16384,21761,263,5392,23589,1025,21760,4113,32,21776,3,268,16,2049,16400,4096,2340,1285,21792,257,21792,16384,513]

theorem envBound43310 : H12AffineFastState.Bounded env43310 := by
  intro p hp
  have h : env43310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43309_43310 : H12AffineEnvironment.transform 6 9 env43309 = env43310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43309 == env43310) = true)

theorem identity43310 : scanCanonicalize (H12AffineFastState.compose env43310 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound43310 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env43311 : List Nat := [2,4,8,16,32,16,9,256,512,53,2048,4096,269,16384,20788,263,4389,22544,52,20789,4113,32,20773,3,268,16,2049,16400,4096,2340,304,20757,257,20757,16384,513]

theorem envBound43311 : H12AffineFastState.Bounded env43311 := by
  intro p hp
  have h : env43311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43310_43311 : H12AffineEnvironment.transform 9 53 env43310 = env43311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env43310 == env43311) = true)

theorem identity43311 : scanCanonicalize (H12AffineFastState.compose env43311 (packedSelected [0,4,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound43311 : packedSelected [0,4,7,9,11] rootPS < 2^1333 := by decide +kernel

def env43312 : List Nat := [2,4,8,16,32,16,9,256,512,53,1,4096,269,16384,20788,263,4389,20497,52,20789,4113,32,20773,3,268,16,0,16400,4096,293,304,20757,257,20757,16384,513]

theorem envBound43312 : H12AffineFastState.Bounded env43312 := by
  intro p hp
  have h : env43312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43311_43312 : H12AffineEnvironment.transform 10 1 env43311 = env43312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env43311 == env43312) = true)

theorem identity43312 : scanCanonicalize (H12AffineFastState.compose env43312 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound43312 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env43313 : List Nat := [2,4,8,16,32,16,9,256,512,53,1,4096,269,4404,0,263,4389,293,52,1,4113,32,17,3,268,16,0,4388,4096,293,304,33,257,33,4404,513]

theorem envBound43313 : H12AffineFastState.Bounded env43313 := by
  intro p hp
  have h : env43313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43312_43313 : H12AffineEnvironment.transform 13 4404 env43312 = env43313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env43312 == env43313) = true)

theorem identity43313 : scanCanonicalize (H12AffineFastState.compose env43313 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound43313 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43314 : List Nat := [2,4,8,16,32,16,9,5,512,53,1,4096,8,4145,0,2,4128,32,52,1,4113,32,17,3,9,16,0,4129,4096,32,53,33,4,33,4145,513]

theorem envBound43314 : H12AffineFastState.Bounded env43314 := by
  intro p hp
  have h : env43314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43313_43314 : H12AffineEnvironment.transform 7 5 env43313 = env43314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env43313 == env43314) = true)

theorem identity43314 : scanCanonicalize (H12AffineFastState.compose env43314 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound43314 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43315 : List Nat := [2,4,8,16,32,16,9,5,512,53,1,571,8,522,0,2,539,32,52,1,554,32,17,3,9,16,0,538,571,32,53,33,4,33,522,513]

theorem envBound43315 : H12AffineFastState.Bounded env43315 := by
  intro p hp
  have h : env43315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43314_43315 : H12AffineEnvironment.transform 11 571 env43314 = env43315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env43314 == env43315) = true)

theorem identity43315 : scanCanonicalize (H12AffineFastState.compose env43315 (packedSelected [0,4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound43315 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env43316 : List Nat := [2,4,2,16,32,16,3,5,512,53,1,561,2,512,0,2,529,32,52,1,544,32,17,3,3,16,0,528,561,32,53,33,4,33,512,513]

theorem envBound43316 : H12AffineFastState.Bounded env43316 := by
  intro p hp
  have h : env43316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43315_43316 : H12AffineEnvironment.transform 2 2 env43315 = env43316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env43315 == env43316) = true)

theorem identity43316 : scanCanonicalize (H12AffineFastState.compose env43316 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 52) := by decide +kernel

theorem selectedBound43316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43317 : List Nat := [2,4,2,16,32,16,3,5,52,53,1,5,2,52,0,2,37,32,52,1,20,32,17,3,3,16,0,36,5,32,53,33,4,33,52,53]

theorem envBound43317 : H12AffineFastState.Bounded env43317 := by
  intro p hp
  have h : env43317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43316_43317 : H12AffineEnvironment.transform 8 52 env43316 = env43317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env43316 == env43317) = true)

theorem identity43317 : scanCanonicalize (H12AffineFastState.compose env43317 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound43317 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env43318 : List Nat := [2,4,2,16,17,16,3,5,5,4,1,5,2,5,0,2,20,17,5,1,20,17,17,3,3,16,0,21,5,17,4,16,4,16,5,4]

theorem envBound43318 : H12AffineFastState.Bounded env43318 := by
  intro p hp
  have h : env43318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43317_43318 : H12AffineEnvironment.transform 4 17 env43317 = env43318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env43317 == env43318) = true)

theorem identity43318 : scanCanonicalize (H12AffineFastState.compose env43318 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound43318 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env43319 : List Nat := [2,4,2,5,4,5,3,5,5,4,1,5,2,5,0,2,1,4,5,1,1,4,4,3,3,5,0,0,5,4,4,5,4,5,5,4]

theorem envBound43319 : H12AffineFastState.Bounded env43319 := by
  intro p hp
  have h : env43319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43318_43319 : H12AffineEnvironment.transform 3 5 env43318 = env43319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env43318 == env43319) = true)

theorem identity43319 : scanCanonicalize (H12AffineFastState.compose env43319 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound43319 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env43320 : List Nat := [2,2,2,3,2,3,3,3,3,2,1,3,2,3,0,2,1,2,3,1,1,2,2,3,3,3,0,0,3,2,2,3,2,3,3,2]

theorem envBound43320 : H12AffineFastState.Bounded env43320 := by
  intro p hp
  have h : env43320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43319_43320 : H12AffineEnvironment.transform 1 2 env43319 = env43320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env43319 == env43320) = true)

def env43321 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,54414,131072,262144,1025,32769,4112,441744,156037,144534,8328,17,64524,160901,140437,303493,1421,272392,257,21792,46213,63109]

theorem envBound43321 : H12AffineFastState.Bounded env43321 := by
  intro p hp
  have h : env43321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43304_43321 : H12AffineEnvironment.transform 5 17 env43304 = env43321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43304 == env43321) = true)

theorem identity43321 : scanCanonicalize (H12AffineFastState.compose env43321 (packedSelected [1,5,8,11,16,17,20,24,32] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound43321 : packedSelected [1,5,8,11,16,17,20,24,32] rootPS < 2^1333 := by decide +kernel

def env43322 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33031,131072,262144,1025,32769,4112,441744,144396,144534,8328,17,43397,139532,140437,303493,1421,272392,257,169,46213,41740]

theorem envBound43322 : H12AffineFastState.Bounded env43322 := by
  intro p hp
  have h : env43322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43321_43322 : H12AffineEnvironment.transform 13 5513 env43321 = env43322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env43321 == env43322) = true)

theorem identity43322 : scanCanonicalize (H12AffineFastState.compose env43322 (packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS)) = affineNative (2^(17+1) ^^^ 35108) := by decide +kernel

theorem selectedBound43322 : packedSelected [3,4,5,7,8,9,16,17,18,20,23,27,28] rootPS < 2^1333 := by decide +kernel

def env43323 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33031,131072,35108,1025,32769,4112,144564,144396,144534,8328,17,43397,139532,140437,10401,1421,41260,257,169,46213,41740]

theorem envBound43323 : H12AffineFastState.Bounded env43323 := by
  intro p hp
  have h : env43323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43322_43323 : H12AffineEnvironment.transform 17 35108 env43322 = env43323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35108 env43322 == env43323) = true)

theorem identity43323 : scanCanonicalize (H12AffineFastState.compose env43323 (packedSelected [16,18,20,23] rootPS)) = affineNative (2^(16+1) ^^^ 38297) := by decide +kernel

theorem selectedBound43323 : packedSelected [16,18,20,23] rootPS < 2^1333 := by decide +kernel

def env43324 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,33031,38297,35108,1025,32769,4112,41261,41365,41231,8328,17,43397,46229,45324,10401,1421,41260,257,169,46213,41740]

theorem envBound43324 : H12AffineFastState.Bounded env43324 := by
  intro p hp
  have h : env43324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43323_43324 : H12AffineEnvironment.transform 16 38297 env43323 = env43324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env43323 == env43324) = true)

theorem identity43324 : scanCanonicalize (H12AffineFastState.compose env43324 (packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound43324 : packedSelected [0,2,4,6,7,9,11,14,16,18,20] rootPS < 2^1333 := by decide +kernel

def env43325 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,32768,33031,38297,35108,1025,32769,4112,32801,32921,32771,388,17,34953,38297,36864,2477,1421,32800,257,169,38281,33280]

theorem envBound43325 : H12AffineFastState.Bounded env43325 := by
  intro p hp
  have h : env43325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43324_43325 : H12AffineEnvironment.transform 12 268 env43324 = env43325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env43324 == env43325) = true)

theorem identity43325 : scanCanonicalize (H12AffineFastState.compose env43325 (packedSelected [0,3,5,7,11,17] rootPS)) = affineNative (2^(14+1) ^^^ 1449) := by decide +kernel

theorem selectedBound43325 : packedSelected [0,3,5,7,11,17] rootPS < 2^1333 := by decide +kernel

def env43326 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,268,5513,1449,1198,4144,3213,1025,1448,4112,1416,1328,1450,388,17,3360,4144,5545,2477,1421,1417,257,169,4128,1961]

theorem envBound43326 : H12AffineFastState.Bounded env43326 := by
  intro p hp
  have h : env43326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43325_43326 : H12AffineEnvironment.transform 14 1449 env43325 = env43326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1449 env43325 == env43326) = true)

theorem identity43326 : scanCanonicalize (H12AffineFastState.compose env43326 (packedSelected [0,1,3,5,6,7,8,11,16] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound43326 : packedSelected [0,1,3,5,6,7,8,11,16] rootPS < 2^1333 := by decide +kernel

def env43327 : List Nat := [2,4,8,16,32,17,128,256,512,20,2048,4096,268,4509,445,186,4144,2201,21,444,4112,412,292,446,388,17,2356,4144,4541,2477,409,413,257,169,4128,957]

theorem envBound43327 : H12AffineFastState.Bounded env43327 := by
  intro p hp
  have h : env43327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43326_43327 : H12AffineEnvironment.transform 9 20 env43326 = env43327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env43326 == env43327) = true)

theorem identity43327 : scanCanonicalize (H12AffineFastState.compose env43327 (packedSelected [0,1,4,7,8,9,10,11] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound43327 : packedSelected [0,1,4,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env43328 : List Nat := [2,4,8,16,32,17,40,256,512,20,2048,4096,268,4405,277,18,4144,2097,21,276,4112,308,292,278,300,17,2356,4144,4373,2309,305,309,257,1,4128,789]

theorem envBound43328 : H12AffineFastState.Bounded env43328 := by
  intro p hp
  have h : env43328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43327_43328 : H12AffineEnvironment.transform 6 40 env43327 = env43328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env43327 == env43328) = true)

theorem identity43328 : scanCanonicalize (H12AffineFastState.compose env43328 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound43328 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env43329 : List Nat := [2,4,8,16,1,17,9,256,512,20,2048,4096,268,4372,277,18,4113,2064,21,276,4112,277,261,278,269,17,2325,4113,4373,2309,272,276,257,1,4097,789]

theorem envBound43329 : H12AffineFastState.Bounded env43329 := by
  intro p hp
  have h : env43329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43328_43329 : H12AffineEnvironment.transform 4 1 env43328 = env43329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env43328 == env43329) = true)

def env43330 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,441745,2257301,253976,8328,64,2157597,2253973,140484,2404757,2102685,2373704,257,21792,46213,2175562]

theorem envBound43330 : H12AffineFastState.Bounded env43330 := by
  intro p hp
  have h : env43330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43274_43330 : H12AffineEnvironment.transform 21 441745 env43274 = env43330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 441745 env43274 == env43330) = true)

def env43331 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156117,253976,8328,64,64605,160981,140484,303573,1501,272392,257,21792,46213,74250]

theorem envBound43331 : H12AffineFastState.Bounded env43331 := by
  intro p hp
  have h : env43331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43330_43331 : H12AffineEnvironment.transform 20 4160 env43330 = env43331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env43330 == env43331) = true)

theorem identity43331 : scanCanonicalize (H12AffineFastState.compose env43331 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound43331 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env43332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,441745,156117,180243,8328,64,64605,160981,140484,303573,1501,272392,257,21792,46213,513]

theorem envBound43332 : H12AffineFastState.Bounded env43332 := by
  intro p hp
  have h : env43332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43331_43332 : H12AffineEnvironment.transform 15 8203 env43331 = env43332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env43331 == env43332) = true)

def env43333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1025,32769,4160,327041,8645,32771,8328,64,64605,13509,25812,303573,1501,272392,257,21792,46213,513]

theorem envBound43333 : H12AffineFastState.Bounded env43333 := by
  intro p hp
  have h : env43333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43332_43333 : H12AffineEnvironment.transform 16 16400 env43332 = env43333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env43332 == env43333) = true)

theorem identity43333 : scanCanonicalize (H12AffineFastState.compose env43333 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound43333 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env43334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16400,262144,1025,32769,4160,318549,17,32771,348,64,56713,5393,17664,294913,1501,264668,257,21792,38225,513]

theorem envBound43334 : H12AffineFastState.Bounded env43334 := by
  intro p hp
  have h : env43334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43333_43334 : H12AffineEnvironment.transform 12 468 env43333 = env43334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env43333 == env43334) = true)

theorem identity43334 : scanCanonicalize (H12AffineFastState.compose env43334 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 56572) := by decide +kernel

theorem selectedBound43334 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env43335 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,479,16400,56572,1025,32769,4160,169,17,32771,348,64,56713,5393,17664,23805,1501,54560,257,21792,38225,513]

theorem envBound43335 : H12AffineFastState.Bounded env43335 := by
  intro p hp
  have h : env43335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43334_43335 : H12AffineEnvironment.transform 17 56572 env43334 = env43335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56572 env43334 == env43335) = true)

theorem identity43335 : scanCanonicalize (H12AffineFastState.compose env43335 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound43335 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env43336 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,32768,342,16400,56437,1025,32769,4160,32,17,32771,348,64,56576,5393,17664,23668,1364,54560,257,21792,38225,513]

theorem envBound43336 : H12AffineFastState.Bounded env43336 := by
  intro p hp
  have h : env43336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43335_43336 : H12AffineEnvironment.transform 6 9 env43335 = env43336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env43335 == env43336) = true)

theorem identity43336 : scanCanonicalize (H12AffineFastState.compose env43336 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound43336 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env43337 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21761,342,16400,2420,1025,21760,4160,32,17,21762,348,64,2049,5393,17664,23668,1364,33,257,21792,16464,513]

theorem envBound43337 : H12AffineFastState.Bounded env43337 := by
  intro p hp
  have h : env43337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43336_43337 : H12AffineEnvironment.transform 14 21761 env43336 = env43337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env43336 == env43337) = true)

theorem identity43337 : scanCanonicalize (H12AffineFastState.compose env43337 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound43337 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env43338 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5456,81,342,5440,2420,1025,80,4160,32,17,82,348,64,2049,5393,4176,2340,1364,33,257,112,5376,513]

theorem envBound43338 : H12AffineFastState.Bounded env43338 := by
  intro p hp
  have h : env43338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43337_43338 : H12AffineEnvironment.transform 13 5456 env43337 = env43338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env43337 == env43338) = true)

theorem identity43338 : scanCanonicalize (H12AffineFastState.compose env43338 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 1386) := by decide +kernel

theorem selectedBound43338 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env43339 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1386,349,58,81,342,42,2420,1025,80,1322,32,17,82,348,64,2049,123,1338,2340,1364,33,257,112,106,513]

theorem envBound43339 : H12AffineFastState.Bounded env43339 := by
  intro p hp
  have h : env43339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43338_43339 : H12AffineEnvironment.transform 11 1386 env43338 = env43339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1386 env43338 == env43339) = true)

theorem identity43339 : scanCanonicalize (H12AffineFastState.compose env43339 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 351) := by decide +kernel

theorem selectedBound43339 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env43340 : List Nat := [2,4,8,16,32,64,9,256,512,1024,351,1386,349,58,81,342,42,43,1025,80,1322,32,17,82,348,64,350,123,1338,123,1364,33,257,112,106,513]

theorem envBound43340 : H12AffineFastState.Bounded env43340 := by
  intro p hp
  have h : env43340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43339_43340 : H12AffineEnvironment.transform 10 351 env43339 = env43340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 351 env43339 == env43340) = true)

theorem identity43340 : scanCanonicalize (H12AffineFastState.compose env43340 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound43340 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env43341 : List Nat := [2,4,8,16,32,64,9,256,512,117,351,287,349,58,81,342,42,43,116,80,351,32,17,82,348,64,350,123,335,123,289,33,257,112,106,513]

theorem envBound43341 : H12AffineFastState.Bounded env43341 := by
  intro p hp
  have h : env43341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43340_43341 : H12AffineEnvironment.transform 9 117 env43340 = env43341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env43340 == env43341) = true)

theorem identity43341 : scanCanonicalize (H12AffineFastState.compose env43341 (packedSelected [0,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 110) := by decide +kernel

theorem selectedBound43341 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env43342 : List Nat := [2,4,8,16,32,64,9,110,512,117,49,113,51,58,81,56,42,43,116,80,49,32,17,82,50,64,48,123,33,123,79,33,111,112,106,513]

theorem envBound43342 : H12AffineFastState.Bounded env43342 := by
  intro p hp
  have h : env43342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43341_43342 : H12AffineEnvironment.transform 7 110 env43341 = env43342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 110 env43341 == env43342) = true)

theorem identity43342 : scanCanonicalize (H12AffineFastState.compose env43342 (packedSelected [1,2,3,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound43342 : packedSelected [1,2,3,11] rootPS < 2^1333 := by decide +kernel

def env43343 : List Nat := [2,4,8,16,32,17,9,63,512,36,49,32,51,58,0,56,42,43,37,1,49,32,17,3,50,17,48,42,33,42,30,33,62,33,59,513]

theorem envBound43343 : H12AffineFastState.Bounded env43343 := by
  intro p hp
  have h : env43343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43342_43343 : H12AffineEnvironment.transform 5 17 env43342 = env43343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env43342 == env43343) = true)

theorem identity43343 : scanCanonicalize (H12AffineFastState.compose env43343 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound43343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env43344 : List Nat := [2,4,8,11,32,10,9,36,512,36,42,32,40,33,0,35,42,43,37,1,42,32,10,3,41,10,43,42,33,42,5,33,37,33,32,513]

theorem envBound43344 : H12AffineFastState.Bounded env43344 := by
  intro p hp
  have h : env43344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43343_43344 : H12AffineEnvironment.transform 3 11 env43343 = env43344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env43343 == env43344) = true)

theorem identity43344 : scanCanonicalize (H12AffineFastState.compose env43344 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 36) := by decide +kernel

theorem selectedBound43344 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env43345 : List Nat := [2,4,8,11,32,10,9,36,36,36,42,32,40,33,0,35,42,43,37,1,42,32,10,3,41,10,43,42,33,42,5,33,37,33,32,37]

theorem envBound43345 : H12AffineFastState.Bounded env43345 := by
  intro p hp
  have h : env43345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43344_43345 : H12AffineEnvironment.transform 8 36 env43344 = env43345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 36 env43344 == env43345) = true)

theorem identity43345 : scanCanonicalize (H12AffineFastState.compose env43345 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound43345 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env43346 : List Nat := [2,4,8,11,0,10,9,4,4,4,10,0,8,1,0,3,10,11,5,1,10,0,10,3,9,10,11,10,1,10,5,1,5,1,0,5]

theorem envBound43346 : H12AffineFastState.Bounded env43346 := by
  intro p hp
  have h : env43346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43345_43346 : H12AffineEnvironment.transform 4 0 env43345 = env43346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env43345 == env43346) = true)

def env43347 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,327040,8644,32770,8328,64,64605,13508,25813,303573,1501,272392,257,21792,46213,513]

theorem envBound43347 : H12AffineFastState.Bounded env43347 := by
  intro p hp
  have h : env43347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43332_43347 : H12AffineEnvironment.transform 16 16401 env43332 = env43347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env43332 == env43347) = true)

def env43348 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16401,262144,1025,32769,4160,326920,8524,32770,8192,64,64605,13388,25693,303453,1365,272392,257,21792,46093,513]

theorem envBound43348 : H12AffineFastState.Bounded env43348 := by
  intro p hp
  have h : env43348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43347_43348 : H12AffineEnvironment.transform 6 8 env43347 = env43348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env43347 == env43348) = true)

theorem identity43348 : scanCanonicalize (H12AffineFastState.compose env43348 (packedSelected [0,14,27] rootPS)) = affineNative (2^(13+1) ^^^ 12621) := by decide +kernel

theorem selectedBound43348 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env43349 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12621,32768,8203,12636,262144,1025,32769,4160,298053,8524,32770,8192,64,36112,13388,5392,303453,1365,272392,257,9325,46093,513]

theorem envBound43349 : H12AffineFastState.Bounded env43349 := by
  intro p hp
  have h : env43349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43348_43349 : H12AffineEnvironment.transform 13 12621 env43348 = env43349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12621 env43348 == env43349) = true)

theorem identity43349 : scanCanonicalize (H12AffineFastState.compose env43349 (packedSelected [3,4,5,9,10,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound43349 : packedSelected [3,4,5,9,10,14,20] rootPS < 2^1333 := by decide +kernel

def env43350 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,32768,1095,5392,262144,1025,32769,4160,298053,1280,32770,1100,64,36112,4096,5392,296209,1365,265284,257,33,36929,513]

theorem envBound43350 : H12AffineFastState.Bounded env43350 := by
  intro p hp
  have h : env43350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43349_43350 : H12AffineEnvironment.transform 12 1100 env43349 = env43350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env43349 == env43350) = true)

theorem identity43350 : scanCanonicalize (H12AffineFastState.compose env43350 (packedSelected [3,5,10] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound43350 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env43351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,5377,32768,1095,5392,35189,1025,32769,4160,1328,1280,32770,1100,64,36112,4096,5392,3172,1365,34097,257,33,36929,513]

theorem envBound43351 : H12AffineFastState.Bounded env43351 := by
  intro p hp
  have h : env43351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans43350_43351 : H12AffineEnvironment.transform 17 35189 env43350 = env43351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env43350 == env43351) = true)

theorem identity43351 : scanCanonicalize (H12AffineFastState.compose env43351 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 1297) := by decide +kernel

theorem selectedBound43351 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1