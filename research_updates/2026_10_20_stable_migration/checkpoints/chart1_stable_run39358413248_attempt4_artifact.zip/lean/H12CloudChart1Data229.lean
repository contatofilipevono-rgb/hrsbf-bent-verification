import H12CloudChart1Data228

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

def env58050 : List Nat := [2,4,8,1,10,1,9,4,11,15,1,2,11,11,11,0,2,11,15,11,11,1,8,2,10,0,11,11,3,1,7,8,5,10,2,10]

theorem envBound58050 : H12AffineFastState.Bounded env58050 := by
  intro p hp
  have h : env58050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58049_58050 : H12AffineEnvironment.transform 11 2 env58049 = env58050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2 env58049 == env58050) = true)

theorem identity58050 : scanCanonicalize (H12AffineFastState.compose env58050 (packedSelected [1,2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58050 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58051 : List Nat := [1,4,8,1,9,1,9,4,8,12,1,1,8,8,8,0,1,8,12,8,8,1,8,1,9,0,8,8,0,1,4,8,5,9,1,9]

theorem envBound58051 : H12AffineFastState.Bounded env58051 := by
  intro p hp
  have h : env58051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58050_58051 : H12AffineEnvironment.transform 0 1 env58050 = env58051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58050 == env58051) = true)

theorem identity58051 : scanCanonicalize (H12AffineFastState.compose env58051 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58051 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58052 : List Nat := [1,4,0,1,1,1,1,4,0,4,1,1,0,0,0,0,1,0,4,0,0,1,0,1,1,0,0,0,0,1,4,0,5,1,1,1]

theorem envBound58052 : H12AffineFastState.Bounded env58052 := by
  intro p hp
  have h : env58052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58051_58052 : H12AffineEnvironment.transform 2 0 env58051 = env58052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58051 == env58052) = true)

def env58053 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46480,144713,169103,26057,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58053 : H12AffineFastState.Bounded env58053 := by
  intro p hp
  have h : env58053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58033_58053 : H12AffineEnvironment.transform 17 87425 env58033 = env58053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58033 == env58053) = true)

theorem identity58053 : scanCanonicalize (H12AffineFastState.compose env58053 (packedSelected [6] rootPS)) = affineNative (2^(16+1) ^^^ 110714) := by decide +kernel

theorem selectedBound58053 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58054 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,110714,87425,1024,32768,107835,46480,99635,74997,26057,120114,103453,16384,110635,93514,41204,53757,257,69731,110714,18240]

theorem envBound58054 : H12AffineFastState.Bounded env58054 := by
  intro p hp
  have h : env58054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58053_58054 : H12AffineEnvironment.transform 16 110714 env58053 = env58054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 110714 env58053 == env58054) = true)

def env58055 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,32768,65536,110714,69825,1024,32768,107835,46480,99635,74997,8329,102514,103453,1344,110635,75786,41204,38077,257,69731,110714,512]

theorem envBound58055 : H12AffineFastState.Bounded env58055 := by
  intro p hp
  have h : env58055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58054_58055 : H12AffineEnvironment.transform 13 1344 env58054 = env58055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58054 == env58055) = true)

theorem identity58055 : scanCanonicalize (H12AffineFastState.compose env58055 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58055 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58056 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,32768,65536,107882,67025,1024,32768,107835,41088,99635,74997,8329,99682,98573,1344,107835,75786,41204,33197,257,66931,107882,512]

theorem envBound58056 : H12AffineFastState.Bounded env58056 := by
  intro p hp
  have h : env58056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58055_58056 : H12AffineEnvironment.transform 11 1296 env58055 = env58056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58055 == env58056) = true)

def env58057 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,65536,110714,69824,1024,32768,107835,46480,99635,74997,8328,102515,103453,1345,110635,75787,41204,38076,257,69731,110714,513]

theorem envBound58057 : H12AffineFastState.Bounded env58057 := by
  intro p hp
  have h : env58057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58054_58057 : H12AffineEnvironment.transform 13 1345 env58054 = env58057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58054 == env58057) = true)

theorem identity58057 : scanCanonicalize (H12AffineFastState.compose env58057 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58057 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,32768,38046,9444,33886,1024,32768,12709,46480,4525,45163,8328,1261,131,1345,9397,48277,41204,38076,257,34045,9444,513]

theorem envBound58058 : H12AffineFastState.Bounded env58058 := by
  intro p hp
  have h : env58058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58057_58058 : H12AffineEnvironment.transform 15 38046 env58057 = env58058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58057 == env58058) = true)

theorem identity58058 : scanCanonicalize (H12AffineFastState.compose env58058 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound58058 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58059 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,32768,36962,8216,32930,252,32768,12709,45420,4525,45163,8328,17,131,445,8265,47209,41204,36928,257,32769,8216,513]

theorem envBound58059 : H12AffineFastState.Bounded env58059 := by
  intro p hp
  have h : env58059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58058_58059 : H12AffineEnvironment.transform 9 252 env58058 = env58059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58058 == env58059) = true)

theorem identity58059 : scanCanonicalize (H12AffineFastState.compose env58059 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 168) := by decide +kernel

theorem selectedBound58059 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58060 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,445,168,4298,8216,10,252,168,12709,12740,4525,12483,8328,17,131,445,8265,14529,8284,4328,257,169,8216,513]

theorem envBound58060 : H12AffineFastState.Bounded env58060 := by
  intro p hp
  have h : env58060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58059_58060 : H12AffineEnvironment.transform 14 168 env58059 = env58060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 168 env58059 == env58060) = true)

theorem identity58060 : scanCanonicalize (H12AffineFastState.compose env58060 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound58060 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58061 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,4096,8192,445,168,4298,8216,10,252,168,12709,12740,4525,12483,8328,17,131,445,8265,13003,8284,4328,257,169,8216,513]

theorem envBound58061 : H12AffineFastState.Bounded env58061 := by
  intro p hp
  have h : env58061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58060_58061 : H12AffineEnvironment.transform 10 522 env58060 = env58061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env58060 == env58061) = true)

theorem identity58061 : scanCanonicalize (H12AffineFastState.compose env58061 (packedSelected [13,21] rootPS)) = affineNative (2^(12+1) ^^^ 4168) := by decide +kernel

theorem selectedBound58061 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58062 : List Nat := [2,4,8,16,32,64,128,256,512,252,522,4096,4168,445,168,4298,4176,10,252,168,493,396,4525,139,4288,17,131,445,4097,643,4116,4328,257,169,4176,513]

theorem envBound58062 : H12AffineFastState.Bounded env58062 := by
  intro p hp
  have h : env58062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58061_58062 : H12AffineEnvironment.transform 12 4168 env58061 = env58062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4168 env58061 == env58062) = true)

theorem identity58062 : scanCanonicalize (H12AffineFastState.compose env58062 (packedSelected [3,5,10] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58062 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58063 : List Nat := [2,4,8,16,32,64,128,256,373,252,383,4096,4168,445,168,4298,4176,10,252,168,493,396,4525,139,4288,17,131,445,4097,502,4116,4328,257,169,4176,372]

theorem envBound58063 : H12AffineFastState.Bounded env58063 := by
  intro p hp
  have h : env58063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58062_58063 : H12AffineEnvironment.transform 8 373 env58062 = env58063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58062 == env58063) = true)

theorem identity58063 : scanCanonicalize (H12AffineFastState.compose env58063 (packedSelected [0,3,4,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 287) := by decide +kernel

theorem selectedBound58063 : packedSelected [0,3,4,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env58064 : List Nat := [2,4,8,16,32,64,128,256,373,252,383,287,343,445,168,469,335,10,252,168,493,396,178,139,479,17,131,445,286,502,267,503,257,169,335,372]

theorem envBound58064 : H12AffineFastState.Bounded env58064 := by
  intro p hp
  have h : env58064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58063_58064 : H12AffineEnvironment.transform 11 287 env58063 = env58064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 287 env58063 == env58064) = true)

theorem identity58064 : scanCanonicalize (H12AffineFastState.compose env58064 (packedSelected [0,1,3,4,5,7,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 94) := by decide +kernel

theorem selectedBound58064 : packedSelected [0,1,3,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env58065 : List Nat := [2,4,8,16,32,64,128,94,43,252,33,65,9,227,168,139,17,10,252,168,179,210,178,139,129,17,131,227,64,168,85,169,95,169,17,42]

theorem envBound58065 : H12AffineFastState.Bounded env58065 := by
  intro p hp
  have h : env58065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58064_58065 : H12AffineEnvironment.transform 7 94 env58064 = env58065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 94 env58064 == env58065) = true)

theorem identity58065 : scanCanonicalize (H12AffineFastState.compose env58065 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 10) := by decide +kernel

theorem selectedBound58065 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env58066 : List Nat := [2,4,8,16,32,64,10,94,43,118,33,65,9,105,34,1,17,10,118,34,57,88,56,1,11,17,9,105,64,34,85,35,95,35,17,42]

theorem envBound58066 : H12AffineFastState.Bounded env58066 := by
  intro p hp
  have h : env58066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58065_58066 : H12AffineEnvironment.transform 6 10 env58065 = env58066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 10 env58065 == env58066) = true)

theorem identity58066 : scanCanonicalize (H12AffineFastState.compose env58066 (packedSelected [4,5,11] rootPS)) = affineNative (2^(5+1) ^^^ 56) := by decide +kernel

theorem selectedBound58066 : packedSelected [4,5,11] rootPS < 2^1333 := by decide +kernel

def env58067 : List Nat := [2,4,8,16,32,56,10,38,43,14,33,57,9,17,34,1,17,10,14,34,57,32,56,1,11,17,9,17,56,34,45,35,39,35,17,42]

theorem envBound58067 : H12AffineFastState.Bounded env58067 := by
  intro p hp
  have h : env58067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58066_58067 : H12AffineEnvironment.transform 5 56 env58066 = env58067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 56 env58066 == env58067) = true)

theorem identity58067 : scanCanonicalize (H12AffineFastState.compose env58067 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound58067 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58068 : List Nat := [2,4,2,16,32,50,0,38,33,4,33,51,3,17,34,1,17,0,4,34,51,32,50,1,1,17,3,17,50,34,39,35,39,35,17,32]

theorem envBound58068 : H12AffineFastState.Bounded env58068 := by
  intro p hp
  have h : env58068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58067_58068 : H12AffineEnvironment.transform 2 2 env58067 = env58068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env58067 == env58068) = true)

theorem identity58068 : scanCanonicalize (H12AffineFastState.compose env58068 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound58068 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58069 : List Nat := [2,4,2,3,32,33,0,38,33,4,33,32,3,2,34,1,2,0,4,34,32,32,33,1,1,2,3,2,33,34,39,35,39,35,2,32]

theorem envBound58069 : H12AffineFastState.Bounded env58069 := by
  intro p hp
  have h : env58069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58068_58069 : H12AffineEnvironment.transform 3 3 env58068 = env58069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env58068 == env58069) = true)

def env58070 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304863,33554432,6342040,2544860,16384,131153,4315354,6402142,221575,257,2295075,131072,33563273]

theorem envBound58070 : H12AffineFastState.Bounded env58070 := by
  intro p hp
  have h : env58070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans57783_58070 : H12AffineEnvironment.transform 22 6329753 env57783 = env58070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 6329753 env57783 == env58070) = true)

def env58071 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304863,4247640,6342040,2544860,16384,131153,4315354,6402142,221575,257,2295075,131072,4256465]

theorem envBound58071 : H12AffineFastState.Bounded env58071 := by
  intro p hp
  have h : env58071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58070_58071 : H12AffineEnvironment.transform 24 4247640 env58070 = env58071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247640 env58070 == env58071) = true)

def env58072 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144713,169103,2257032,157000,2544860,16384,131153,2324490,200846,221575,257,2295075,131072,2249217]

theorem envBound58072 : H12AffineFastState.Bounded env58072 := by
  intro p hp
  have h : env58072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58071_58072 : H12AffineEnvironment.transform 21 2269392 env58071 = env58072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env58071 == env58072) = true)

def env58073 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144713,169103,26056,157000,311708,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound58073 : H12AffineFastState.Bounded env58073 := by
  intro p hp
  have h : env58073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58072_58073 : H12AffineEnvironment.transform 20 136512 env58072 = env58073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58072 == env58073) = true)

def env58074 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144713,169103,26056,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound58074 : H12AffineFastState.Bounded env58074 := by
  intro p hp
  have h : env58074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58073_58074 : H12AffineEnvironment.transform 17 87424 env58073 = env58074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58073 == env58074) = true)

theorem identity58074 : scanCanonicalize (H12AffineFastState.compose env58074 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound58074 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58075 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,16384,32768,65536,131072,83052,1024,32768,132268,42108,140453,165219,26056,157000,99824,16384,131153,93514,196962,221575,257,65935,131072,18241]

theorem envBound58075 : H12AffineFastState.Bounded env58075 := by
  intro p hp
  have h : env58075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58074_58075 : H12AffineEnvironment.transform 11 492 env58074 = env58075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env58074 == env58075) = true)

def env58076 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,65536,131072,65836,1024,32768,132268,42108,140453,165219,8328,139272,99824,1344,131153,75786,196962,206023,257,65935,131072,513]

theorem envBound58076 : H12AffineFastState.Bounded env58076 := by
  intro p hp
  have h : env58076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58075_58076 : H12AffineEnvironment.transform 13 1344 env58075 = env58076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58075 == env58076) = true)

theorem identity58076 : scanCanonicalize (H12AffineFastState.compose env58076 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 34162) := by decide +kernel

theorem selectedBound58076 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58077 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34162,131072,33886,1024,32768,132268,42108,140453,165219,8328,139272,130,1344,131153,44408,164880,172469,257,34045,131072,513]

theorem envBound58077 : H12AffineFastState.Bounded env58077 := by
  intro p hp
  have h : env58077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58076_58077 : H12AffineEnvironment.transform 15 34162 env58076 = env58077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34162 env58076 == env58077) = true)

theorem identity58077 : scanCanonicalize (H12AffineFastState.compose env58077 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound58077 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58078 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34162,8216,33886,1024,32768,9396,42108,1213,42363,8328,16,130,1344,8265,44408,41992,33197,257,34045,8216,513]

theorem envBound58078 : H12AffineFastState.Bounded env58078 := by
  intro p hp
  have h : env58078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58077_58078 : H12AffineEnvironment.transform 16 8216 env58077 = env58078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env58077 == env58078) = true)

theorem identity58078 : scanCanonicalize (H12AffineFastState.compose env58078 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58078 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,1108,294,8216,10,1024,1108,9396,8232,1213,8495,8328,16,130,1344,8265,10540,8284,1529,257,169,8216,513]

theorem envBound58079 : H12AffineFastState.Bounded env58079 := by
  intro p hp
  have h : env58079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58078_58079 : H12AffineEnvironment.transform 14 1108 env58078 = env58079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58078 == env58079) = true)

theorem identity58079 : scanCanonicalize (H12AffineFastState.compose env58079 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound58079 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,2991,1344,1108,294,2999,10,1024,1108,3867,2951,1213,2688,2855,16,130,1344,3046,643,3059,1529,257,169,2999,513]

theorem envBound58080 : H12AffineFastState.Bounded env58080 := by
  intro p hp
  have h : env58080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58079_58080 : H12AffineEnvironment.transform 12 2991 env58079 = env58080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env58079 == env58080) = true)

theorem identity58080 : scanCanonicalize (H12AffineFastState.compose env58080 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound58080 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,523,492,420,1344,1108,294,444,10,1024,1108,1296,396,1213,139,300,16,130,1344,493,643,504,1529,257,169,444,513]

theorem envBound58081 : H12AffineFastState.Bounded env58081 := by
  intro p hp
  have h : env58081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58080_58081 : H12AffineEnvironment.transform 10 523 env58080 = env58081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env58080 == env58081) = true)

theorem identity58081 : scanCanonicalize (H12AffineFastState.compose env58081 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound58081 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58082 : List Nat := [2,4,8,16,32,64,128,256,512,549,523,492,420,869,625,294,444,10,549,625,821,396,664,139,300,16,130,869,493,643,504,988,257,169,444,513]

theorem envBound58082 : H12AffineFastState.Bounded env58082 := by
  intro p hp
  have h : env58082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58081_58082 : H12AffineEnvironment.transform 9 549 env58081 = env58082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env58081 == env58082) = true)

theorem identity58082 : scanCanonicalize (H12AffineFastState.compose env58082 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58082 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58083 : List Nat := [2,4,8,16,32,64,128,172,512,549,523,64,8,713,625,138,16,10,549,625,665,32,664,139,128,16,130,713,65,643,84,624,173,169,16,513]

theorem envBound58083 : H12AffineFastState.Bounded env58083 := by
  intro p hp
  have h : env58083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58082_58083 : H12AffineEnvironment.transform 7 172 env58082 = env58083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58082 == env58083) = true)

theorem identity58083 : scanCanonicalize (H12AffineFastState.compose env58083 (packedSelected [3,8,12] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound58083 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58084 : List Nat := [2,4,8,16,32,64,128,172,42,15,33,64,8,227,91,138,16,10,15,91,179,32,178,139,128,16,130,227,65,169,84,90,173,169,16,43]

theorem envBound58084 : H12AffineFastState.Bounded env58084 := by
  intro p hp
  have h : env58084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58083_58084 : H12AffineEnvironment.transform 8 42 env58083 = env58084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env58083 == env58084) = true)

theorem identity58084 : scanCanonicalize (H12AffineFastState.compose env58084 (packedSelected [0,2,5] rootPS)) = affineNative (2^(5+1) ^^^ 34) := by decide +kernel

theorem selectedBound58084 : packedSelected [0,2,5] rootPS < 2^1333 := by decide +kernel

def env58085 : List Nat := [2,4,8,16,32,34,128,172,42,15,33,34,8,129,57,138,16,10,15,57,179,32,178,139,128,16,130,129,35,169,54,56,173,169,16,43]

theorem envBound58085 : H12AffineFastState.Bounded env58085 := by
  intro p hp
  have h : env58085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58084_58085 : H12AffineEnvironment.transform 5 34 env58084 = env58085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 34 env58084 == env58085) = true)

theorem identity58085 : scanCanonicalize (H12AffineFastState.compose env58085 (packedSelected [0,1,2,3,8] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound58085 : packedSelected [0,1,2,3,8] rootPS < 2^1333 := by decide +kernel

def env58086 : List Nat := [2,4,8,16,32,34,34,14,42,15,33,34,8,35,57,40,16,10,15,57,17,32,16,41,34,16,32,35,35,11,54,56,15,11,16,43]

theorem envBound58086 : H12AffineFastState.Bounded env58086 := by
  intro p hp
  have h : env58086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58085_58086 : H12AffineEnvironment.transform 6 34 env58085 = env58086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env58085 == env58086) = true)

theorem identity58086 : scanCanonicalize (H12AffineFastState.compose env58086 (packedSelected [3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound58086 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58087 : List Nat := [2,4,8,16,27,25,25,14,17,15,26,25,8,24,2,19,16,10,15,2,17,27,16,18,25,16,27,24,24,11,13,3,15,11,16,16]

theorem envBound58087 : H12AffineFastState.Bounded env58087 := by
  intro p hp
  have h : env58087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58086_58087 : H12AffineEnvironment.transform 4 27 env58086 = env58087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env58086 == env58087) = true)

theorem identity58087 : scanCanonicalize (H12AffineFastState.compose env58087 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound58087 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58088 : List Nat := [2,4,8,3,8,10,10,14,2,15,9,10,8,11,2,0,3,10,15,2,2,8,3,1,10,3,8,11,11,11,13,3,15,11,3,3]

theorem envBound58088 : H12AffineFastState.Bounded env58088 := by
  intro p hp
  have h : env58088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58087_58088 : H12AffineEnvironment.transform 3 3 env58087 = env58088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env58087 == env58088) = true)

theorem identity58088 : scanCanonicalize (H12AffineFastState.compose env58088 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound58088 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58089 : List Nat := [2,4,2,3,2,0,0,4,2,5,3,0,2,1,2,0,3,0,5,2,2,2,3,1,0,3,2,1,1,1,7,3,5,1,3,3]

theorem envBound58089 : H12AffineFastState.Bounded env58089 := by
  intro p hp
  have h : env58089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58088_58089 : H12AffineEnvironment.transform 2 2 env58088 = env58089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env58088 == env58089) = true)

theorem identity58089 : scanCanonicalize (H12AffineFastState.compose env58089 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58089 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58090 : List Nat := [0,4,0,1,0,0,0,4,0,5,1,0,0,1,0,0,1,0,5,0,0,0,1,1,0,1,0,1,1,1,5,1,5,1,1,1]

theorem envBound58090 : H12AffineFastState.Bounded env58090 := by
  intro p hp
  have h : env58090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58089_58090 : H12AffineEnvironment.transform 0 0 env58089 = env58090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58089 == env58090) = true)

def env58091 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1345,32768,65536,131072,65837,1024,32768,132268,42108,140453,165219,8329,139273,99824,1345,131153,75787,196962,206022,257,65935,131072,512]

theorem envBound58091 : H12AffineFastState.Bounded env58091 := by
  intro p hp
  have h : env58091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58075_58091 : H12AffineEnvironment.transform 13 1345 env58075 = env58091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58075 == env58091) = true)

theorem identity58091 : scanCanonicalize (H12AffineFastState.compose env58091 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound58091 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58092 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,492,8192,444,32768,65536,131072,65837,253,32768,131153,41089,139352,164254,8329,139273,98573,444,131153,75787,196962,204859,257,65935,131072,512]

theorem envBound58092 : H12AffineFastState.Bounded env58092 := by
  intro p hp
  have h : env58092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58091_58092 : H12AffineEnvironment.transform 9 253 env58091 = env58092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env58091 == env58092) = true)

def env58093 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144713,169103,26056,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18241]

theorem envBound58093 : H12AffineFastState.Bounded env58093 := by
  intro p hp
  have h : env58093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58073_58093 : H12AffineEnvironment.transform 17 87425 env58073 = env58093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58073 == env58093) = true)

theorem identity58093 : scanCanonicalize (H12AffineFastState.compose env58093 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 5292) := by decide +kernel

theorem selectedBound58093 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58094 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5292,32768,65536,131072,65837,1024,32768,136512,46480,144713,169103,12644,143844,103453,5292,131153,80358,200846,210219,257,69731,131072,5101]

theorem envBound58094 : H12AffineFastState.Bounded env58094 := by
  intro p hp
  have h : env58094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58093_58094 : H12AffineEnvironment.transform 13 5292 env58093 = env58094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5292 env58093 == env58094) = true)

def env58095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,65536,131072,65837,1024,32768,132268,42108,140453,165219,8328,139272,99825,1344,131153,75786,196962,206023,257,65935,131072,513]

theorem envBound58095 : H12AffineFastState.Bounded env58095 := by
  intro p hp
  have h : env58095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58094_58095 : H12AffineEnvironment.transform 11 492 env58094 = env58095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env58094 == env58095) = true)

theorem identity58095 : scanCanonicalize (H12AffineFastState.compose env58095 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 34162) := by decide +kernel

theorem selectedBound58095 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34162,131072,33887,1024,32768,132268,42108,140453,165219,8328,139272,131,1344,131153,44408,164880,172469,257,34045,131072,513]

theorem envBound58096 : H12AffineFastState.Bounded env58096 := by
  intro p hp
  have h : env58096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58095_58096 : H12AffineEnvironment.transform 15 34162 env58095 = env58096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34162 env58095 == env58096) = true)

theorem identity58096 : scanCanonicalize (H12AffineFastState.compose env58096 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound58096 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,32768,34162,8216,33887,1024,32768,9396,42108,1213,42363,8328,16,131,1344,8265,44408,41992,33197,257,34045,8216,513]

theorem envBound58097 : H12AffineFastState.Bounded env58097 := by
  intro p hp
  have h : env58097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58096_58097 : H12AffineEnvironment.transform 16 8216 env58096 = env58097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env58096 == env58097) = true)

theorem identity58097 : scanCanonicalize (H12AffineFastState.compose env58097 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1108) := by decide +kernel

theorem selectedBound58097 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,8192,1344,1108,294,8216,11,1024,1108,9396,8232,1213,8495,8328,16,131,1344,8265,10540,8284,1529,257,169,8216,513]

theorem envBound58098 : H12AffineFastState.Bounded env58098 := by
  intro p hp
  have h : env58098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58097_58098 : H12AffineEnvironment.transform 14 1108 env58097 = env58098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1108 env58097 == env58098) = true)

theorem identity58098 : scanCanonicalize (H12AffineFastState.compose env58098 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound58098 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,492,2991,1344,1108,294,2999,11,1024,1108,3867,2951,1213,2688,2855,16,131,1344,3046,643,3059,1529,257,169,2999,513]

theorem envBound58099 : H12AffineFastState.Bounded env58099 := by
  intro p hp
  have h : env58099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58098_58099 : H12AffineEnvironment.transform 12 2991 env58098 = env58099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env58098 == env58099) = true)

theorem identity58099 : scanCanonicalize (H12AffineFastState.compose env58099 (packedSelected [13,21] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound58099 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,523,492,420,1344,1108,294,444,11,1024,1108,1296,396,1213,139,300,16,131,1344,493,643,504,1529,257,169,444,513]

theorem envBound58100 : H12AffineFastState.Bounded env58100 := by
  intro p hp
  have h : env58100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58099_58100 : H12AffineEnvironment.transform 10 523 env58099 = env58100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env58099 == env58100) = true)

theorem identity58100 : scanCanonicalize (H12AffineFastState.compose env58100 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound58100 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58101 : List Nat := [2,4,8,16,32,64,128,256,512,549,523,492,420,869,625,294,444,11,549,625,821,396,664,139,300,16,131,869,493,643,504,988,257,169,444,513]

theorem envBound58101 : H12AffineFastState.Bounded env58101 := by
  intro p hp
  have h : env58101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58100_58101 : H12AffineEnvironment.transform 9 549 env58100 = env58101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env58100 == env58101) = true)

theorem identity58101 : scanCanonicalize (H12AffineFastState.compose env58101 (packedSelected [1,3,17] rootPS)) = affineNative (2^(7+1) ^^^ 172) := by decide +kernel

theorem selectedBound58101 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58102 : List Nat := [2,4,8,16,32,64,128,172,512,549,523,64,8,713,625,138,16,11,549,625,665,32,664,139,128,16,131,713,65,643,84,624,173,169,16,513]

theorem envBound58102 : H12AffineFastState.Bounded env58102 := by
  intro p hp
  have h : env58102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58101_58102 : H12AffineEnvironment.transform 7 172 env58101 = env58102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 172 env58101 == env58102) = true)

theorem identity58102 : scanCanonicalize (H12AffineFastState.compose env58102 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound58102 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58103 : List Nat := [2,4,8,16,32,64,34,14,512,549,523,64,8,619,625,40,16,11,549,625,571,32,570,41,34,16,33,619,65,545,84,624,15,11,16,513]

theorem envBound58103 : H12AffineFastState.Bounded env58103 := by
  intro p hp
  have h : env58103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58102_58103 : H12AffineEnvironment.transform 6 34 env58102 = env58103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env58102 == env58103) = true)

theorem identity58103 : scanCanonicalize (H12AffineFastState.compose env58103 (packedSelected [2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 72) := by decide +kernel

theorem selectedBound58103 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env58104 : List Nat := [2,4,8,16,32,64,34,14,72,109,67,64,8,35,57,40,16,11,109,57,115,32,114,41,34,16,33,35,65,105,84,56,15,11,16,73]

theorem envBound58104 : H12AffineFastState.Bounded env58104 := by
  intro p hp
  have h : env58104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58103_58104 : H12AffineEnvironment.transform 8 72 env58103 = env58104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 72 env58103 == env58104) = true)

theorem identity58104 : scanCanonicalize (H12AffineFastState.compose env58104 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(4+1) ^^^ 18) := by decide +kernel

theorem selectedBound58104 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env58105 : List Nat := [2,4,8,16,18,64,16,14,72,95,67,64,8,17,11,26,16,11,95,11,65,18,64,27,16,16,19,17,65,91,84,10,15,11,16,73]

theorem envBound58105 : H12AffineFastState.Bounded env58105 := by
  intro p hp
  have h : env58105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58104_58105 : H12AffineEnvironment.transform 4 18 env58104 = env58105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 18 env58104 == env58105) = true)

theorem identity58105 : scanCanonicalize (H12AffineFastState.compose env58105 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound58105 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58106 : List Nat := [2,4,8,16,18,9,16,14,1,22,10,9,8,17,11,26,16,11,22,11,8,18,9,27,16,16,19,17,8,18,29,10,15,11,16,0]

theorem envBound58106 : H12AffineFastState.Bounded env58106 := by
  intro p hp
  have h : env58106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58105_58106 : H12AffineEnvironment.transform 5 9 env58105 = env58106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env58105 == env58106) = true)

theorem identity58106 : scanCanonicalize (H12AffineFastState.compose env58106 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound58106 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58107 : List Nat := [2,4,8,10,8,9,10,14,1,12,10,9,8,11,11,0,10,11,12,11,8,8,9,1,10,10,9,11,8,8,7,10,15,11,10,0]

theorem envBound58107 : H12AffineFastState.Bounded env58107 := by
  intro p hp
  have h : env58107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58106_58107 : H12AffineEnvironment.transform 3 10 env58106 = env58107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env58106 == env58107) = true)

theorem identity58107 : scanCanonicalize (H12AffineFastState.compose env58107 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58107 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58108 : List Nat := [1,4,8,9,8,9,9,13,1,12,9,9,8,8,8,0,9,8,12,8,8,8,9,1,9,9,9,8,8,8,4,9,12,8,9,0]

theorem envBound58108 : H12AffineFastState.Bounded env58108 := by
  intro p hp
  have h : env58108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58107_58108 : H12AffineEnvironment.transform 0 1 env58107 = env58108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58107 == env58108) = true)

def env58109 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,493,8192,1345,32768,65536,131072,65837,1024,32768,132269,42109,140452,165218,8329,139273,99824,1345,131153,75787,196963,206022,257,65934,131072,512]

theorem envBound58109 : H12AffineFastState.Bounded env58109 := by
  intro p hp
  have h : env58109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58094_58109 : H12AffineEnvironment.transform 11 493 env58094 = env58109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env58094 == env58109) = true)

theorem identity58109 : scanCanonicalize (H12AffineFastState.compose env58109 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(9+1) ^^^ 252) := by decide +kernel

theorem selectedBound58109 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58110 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,493,8192,445,32768,65536,131072,65837,252,32768,131153,41089,139352,164254,8329,139273,98572,445,131153,75787,196963,204858,257,65934,131072,512]

theorem envBound58110 : H12AffineFastState.Bounded env58110 := by
  intro p hp
  have h : env58110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58109_58110 : H12AffineEnvironment.transform 9 252 env58109 = env58110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58109 == env58110) = true)

def env58111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144713,169103,26057,157000,311709,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound58111 : H12AffineFastState.Bounded env58111 := by
  intro p hp
  have h : env58111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58072_58111 : H12AffineEnvironment.transform 20 136513 env58072 = env58111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env58072 == env58111) = true)

def env58112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144713,169103,26057,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound58112 : H12AffineFastState.Bounded env58112 := by
  intro p hp
  have h : env58112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58111_58112 : H12AffineEnvironment.transform 17 87424 env58111 = env58112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58111 == env58112) = true)

theorem identity58112 : scanCanonicalize (H12AffineFastState.compose env58112 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 444) := by decide +kernel

theorem selectedBound58112 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58113 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,444,32768,65536,131072,70716,1024,32768,136513,46481,144713,169103,9333,140532,103453,444,131153,77047,200846,204859,257,69730,131072,1788]

theorem envBound58113 : H12AffineFastState.Bounded env58113 := by
  intro p hp
  have h : env58113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58112_58113 : H12AffineEnvironment.transform 13 444 env58112 = env58113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env58112 == env58113) = true)

def env58114 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,4096,8192,444,32768,65536,131072,69824,252,32768,135613,45421,143797,168051,8329,139272,102625,444,131153,75787,200846,204859,257,69730,131072,512]

theorem envBound58114 : H12AffineFastState.Bounded env58114 := by
  intro p hp
  have h : env58114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58113_58114 : H12AffineEnvironment.transform 9 252 env58113 = env58114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 252 env58113 == env58114) = true)

theorem identity58114 : scanCanonicalize (H12AffineFastState.compose env58114 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound58114 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58115 : List Nat := [2,4,8,16,32,64,128,256,512,252,2048,492,8192,444,32768,65536,131072,65836,252,32768,131153,41089,139353,164255,8329,139272,98573,444,131153,75787,196962,204859,257,65934,131072,512]

theorem envBound58115 : H12AffineFastState.Bounded env58115 := by
  intro p hp
  have h : env58115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58114_58115 : H12AffineEnvironment.transform 11 492 env58114 = env58115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 492 env58114 == env58115) = true)

def env58116 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,65536,131072,69825,253,32768,135612,45420,143796,168050,8328,139273,102624,444,131153,75786,200846,204859,257,69730,131072,513]

theorem envBound58116 : H12AffineFastState.Bounded env58116 := by
  intro p hp
  have h : env58116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58113_58116 : H12AffineEnvironment.transform 9 253 env58113 = env58116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env58113 == env58116) = true)

theorem identity58116 : scanCanonicalize (H12AffineFastState.compose env58116 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 36962) := by decide +kernel

theorem selectedBound58116 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58117 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36962,131072,32931,253,32768,135612,45420,143796,168050,8328,139273,130,444,131153,47208,164076,176217,257,32768,131072,513]

theorem envBound58117 : H12AffineFastState.Bounded env58117 := by
  intro p hp
  have h : env58117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58116_58117 : H12AffineEnvironment.transform 15 36962 env58116 = env58117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 36962 env58116 == env58117) = true)

theorem identity58117 : scanCanonicalize (H12AffineFastState.compose env58117 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound58117 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58118 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36962,8217,32931,253,32768,12709,45420,4525,45163,8328,16,130,444,8264,47208,41205,36928,257,32768,8217,513]

theorem envBound58118 : H12AffineFastState.Bounded env58118 := by
  intro p hp
  have h : env58118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58117_58118 : H12AffineEnvironment.transform 16 8217 env58117 = env58118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env58117 == env58118) = true)

theorem identity58118 : scanCanonicalize (H12AffineFastState.compose env58118 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound58118 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58119 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,169,4299,8217,10,253,169,12709,12741,4525,12482,8328,16,130,444,8264,14529,8284,4329,257,169,8217,513]

theorem envBound58119 : H12AffineFastState.Bounded env58119 := by
  intro p hp
  have h : env58119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58118_58119 : H12AffineEnvironment.transform 14 169 env58118 = env58119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env58118 == env58119) = true)

theorem identity58119 : scanCanonicalize (H12AffineFastState.compose env58119 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound58119 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58120 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,2991,444,169,4299,2998,10,253,169,6666,6762,4525,7021,2855,16,130,444,3047,4974,3059,4329,257,169,2998,513]

theorem envBound58120 : H12AffineFastState.Bounded env58120 := by
  intro p hp
  have h : env58120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58119_58120 : H12AffineEnvironment.transform 12 2991 env58119 = env58120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env58119 == env58120) = true)

theorem identity58120 : scanCanonicalize (H12AffineFastState.compose env58120 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 3046) := by decide +kernel

theorem selectedBound58120 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58121 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3046,2991,444,169,2861,2998,10,253,169,492,396,2635,139,2855,16,130,444,3047,2184,3059,2831,257,169,2998,513]

theorem envBound58121 : H12AffineFastState.Bounded env58121 := by
  intro p hp
  have h : env58121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58120_58121 : H12AffineEnvironment.transform 11 3046 env58120 = env58121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3046 env58120 == env58121) = true)

theorem identity58121 : scanCanonicalize (H12AffineFastState.compose env58121 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound58121 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58122 : List Nat := [2,4,8,16,32,64,128,256,512,253,210,820,893,444,169,1023,868,10,253,169,492,396,665,139,1013,16,130,444,821,90,801,989,257,169,868,513]

theorem envBound58122 : H12AffineFastState.Bounded env58122 := by
  intro p hp
  have h : env58122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58121_58122 : H12AffineEnvironment.transform 10 210 env58121 = env58122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env58121 == env58122) = true)

theorem identity58122 : scanCanonicalize (H12AffineFastState.compose env58122 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58122 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58123 : List Nat := [2,4,8,16,32,64,128,256,373,253,210,65,8,444,169,138,17,10,253,169,492,396,492,139,128,16,130,444,64,90,84,168,257,169,17,372]

theorem envBound58123 : H12AffineFastState.Bounded env58123 := by
  intro p hp
  have h : env58123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58122_58123 : H12AffineEnvironment.transform 8 373 env58122 = env58123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58122 == env58123) = true)

theorem identity58123 : scanCanonicalize (H12AffineFastState.compose env58123 (packedSelected [3,8,12] rootPS)) = affineNative (2^(7+1) ^^^ 95) := by decide +kernel

theorem selectedBound58123 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58124 : List Nat := [2,4,8,16,32,64,128,95,42,253,210,65,8,227,169,138,17,10,253,169,179,211,179,139,128,16,130,227,64,90,84,168,94,169,17,43]

theorem envBound58124 : H12AffineFastState.Bounded env58124 := by
  intro p hp
  have h : env58124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58123_58124 : H12AffineEnvironment.transform 7 95 env58123 = env58124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 95 env58123 == env58124) = true)

theorem identity58124 : scanCanonicalize (H12AffineFastState.compose env58124 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 35) := by decide +kernel

theorem selectedBound58124 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env58125 : List Nat := [2,4,8,16,32,35,128,60,42,158,177,34,8,128,169,138,17,10,158,169,179,176,179,139,128,16,130,128,35,57,55,168,61,169,17,43]

theorem envBound58125 : H12AffineFastState.Bounded env58125 := by
  intro p hp
  have h : env58125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58124_58125 : H12AffineEnvironment.transform 5 35 env58124 = env58125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 35 env58124 == env58125) = true)

theorem identity58125 : scanCanonicalize (H12AffineFastState.compose env58125 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound58125 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58126 : List Nat := [2,4,8,16,32,35,16,60,42,14,33,34,8,16,57,26,17,10,14,57,35,32,35,27,16,16,18,16,35,57,55,56,61,57,17,43]

theorem envBound58126 : H12AffineFastState.Bounded env58126 := by
  intro p hp
  have h : env58126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58125_58126 : H12AffineEnvironment.transform 6 16 env58125 = env58126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env58125 == env58126) = true)

theorem identity58126 : scanCanonicalize (H12AffineFastState.compose env58126 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58126 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58127 : List Nat := [2,4,8,16,17,18,16,13,27,14,16,19,8,16,8,26,17,10,14,8,18,17,18,27,16,16,18,16,18,8,6,9,12,8,17,26]

theorem envBound58127 : H12AffineFastState.Bounded env58127 := by
  intro p hp
  have h : env58127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58126_58127 : H12AffineEnvironment.transform 4 17 env58126 = env58127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58126 == env58127) = true)

theorem identity58127 : scanCanonicalize (H12AffineFastState.compose env58127 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58127 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58128 : List Nat := [2,4,8,11,10,9,11,13,0,14,11,8,8,11,8,1,10,10,14,8,9,10,9,0,11,11,9,11,9,8,6,9,12,8,10,1]

theorem envBound58128 : H12AffineFastState.Bounded env58128 := by
  intro p hp
  have h : env58128.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58127_58128 : H12AffineEnvironment.transform 3 11 env58127 = env58128 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58127 == env58128) = true)

theorem identity58128 : scanCanonicalize (H12AffineFastState.compose env58128 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58128 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58129 : List Nat := [0,4,8,9,8,9,9,13,0,12,9,8,8,9,8,1,8,8,12,8,9,8,9,0,9,9,9,9,9,8,4,9,12,8,8,1]

theorem envBound58129 : H12AffineFastState.Bounded env58129 := by
  intro p hp
  have h : env58129.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58128_58129 : H12AffineEnvironment.transform 0 0 env58128 = env58129 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58128 == env58129) = true)

def env58130 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144713,169103,26057,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18240]

theorem envBound58130 : H12AffineFastState.Bounded env58130 := by
  intro p hp
  have h : env58130.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58111_58130 : H12AffineEnvironment.transform 17 87425 env58111 = env58130 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58111 == env58130) = true)

theorem identity58130 : scanCanonicalize (H12AffineFastState.compose env58130 (packedSelected [6] rootPS)) = affineNative (2^(9+1) ^^^ 253) := by decide +kernel

theorem selectedBound58130 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58131 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,16384,32768,65536,131072,86396,253,32768,135612,45420,143796,168050,24884,156085,102625,16384,131153,92598,200846,221575,257,69730,131072,17341]

theorem envBound58131 : H12AffineFastState.Bounded env58131 := by
  intro p hp
  have h : env58131.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58130_58131 : H12AffineEnvironment.transform 9 253 env58130 = env58131 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 253 env58130 == env58131) = true)

def env58132 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,65536,131072,69824,253,32768,135612,45420,143796,168050,8328,139273,102625,444,131153,75786,200846,204859,257,69730,131072,513]

theorem envBound58132 : H12AffineFastState.Bounded env58132 := by
  intro p hp
  have h : env58132.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58131_58132 : H12AffineEnvironment.transform 13 444 env58131 = env58132 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 444 env58131 == env58132) = true)

theorem identity58132 : scanCanonicalize (H12AffineFastState.compose env58132 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 36962) := by decide +kernel

theorem selectedBound58132 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58133 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36962,131072,32930,253,32768,135612,45420,143796,168050,8328,139273,131,444,131153,47208,164076,176217,257,32768,131072,513]

theorem envBound58133 : H12AffineFastState.Bounded env58133 := by
  intro p hp
  have h : env58133.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58132_58133 : H12AffineEnvironment.transform 15 36962 env58132 = env58133 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 36962 env58132 == env58133) = true)

theorem identity58133 : scanCanonicalize (H12AffineFastState.compose env58133 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound58133 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58134 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,32768,36962,8217,32930,253,32768,12709,45420,4525,45163,8328,16,131,444,8264,47208,41205,36928,257,32768,8217,513]

theorem envBound58134 : H12AffineFastState.Bounded env58134 := by
  intro p hp
  have h : env58134.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58133_58134 : H12AffineEnvironment.transform 16 8217 env58133 = env58134 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env58133 == env58134) = true)

theorem identity58134 : scanCanonicalize (H12AffineFastState.compose env58134 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 169) := by decide +kernel

theorem selectedBound58134 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58135 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,444,169,4299,8217,11,253,169,12709,12741,4525,12482,8328,16,131,444,8264,14529,8284,4329,257,169,8217,513]

theorem envBound58135 : H12AffineFastState.Bounded env58135 := by
  intro p hp
  have h : env58135.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58134_58135 : H12AffineEnvironment.transform 14 169 env58134 = env58135 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 169 env58134 == env58135) = true)

theorem identity58135 : scanCanonicalize (H12AffineFastState.compose env58135 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 2991) := by decide +kernel

theorem selectedBound58135 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58136 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,2991,444,169,4299,2998,11,253,169,6666,6762,4525,7021,2855,16,131,444,3047,4974,3059,4329,257,169,2998,513]

theorem envBound58136 : H12AffineFastState.Bounded env58136 := by
  intro p hp
  have h : env58136.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58135_58136 : H12AffineEnvironment.transform 12 2991 env58135 = env58136 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2991 env58135 == env58136) = true)

theorem identity58136 : scanCanonicalize (H12AffineFastState.compose env58136 (packedSelected [13,21] rootPS)) = affineNative (2^(11+1) ^^^ 3046) := by decide +kernel

theorem selectedBound58136 : packedSelected [13,21] rootPS < 2^1333 := by decide +kernel

def env58137 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,3046,2991,444,169,2861,2998,11,253,169,492,396,2635,139,2855,16,131,444,3047,2184,3059,2831,257,169,2998,513]

theorem envBound58137 : H12AffineFastState.Bounded env58137 := by
  intro p hp
  have h : env58137.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58136_58137 : H12AffineEnvironment.transform 11 3046 env58136 = env58137 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3046 env58136 == env58137) = true)

theorem identity58137 : scanCanonicalize (H12AffineFastState.compose env58137 (packedSelected [3,5,10] rootPS)) = affineNative (2^(10+1) ^^^ 210) := by decide +kernel

theorem selectedBound58137 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env58138 : List Nat := [2,4,8,16,32,64,128,256,512,253,210,820,893,444,169,1023,868,11,253,169,492,396,665,139,1013,16,131,444,821,90,801,989,257,169,868,513]

theorem envBound58138 : H12AffineFastState.Bounded env58138 := by
  intro p hp
  have h : env58138.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58137_58138 : H12AffineEnvironment.transform 10 210 env58137 = env58138 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 210 env58137 == env58138) = true)

theorem identity58138 : scanCanonicalize (H12AffineFastState.compose env58138 (packedSelected [1,3,17] rootPS)) = affineNative (2^(8+1) ^^^ 373) := by decide +kernel

theorem selectedBound58138 : packedSelected [1,3,17] rootPS < 2^1333 := by decide +kernel

def env58139 : List Nat := [2,4,8,16,32,64,128,256,373,253,210,65,8,444,169,138,17,11,253,169,492,396,492,139,128,16,131,444,64,90,84,168,257,169,17,372]

theorem envBound58139 : H12AffineFastState.Bounded env58139 := by
  intro p hp
  have h : env58139.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58138_58139 : H12AffineEnvironment.transform 8 373 env58138 = env58139 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 373 env58138 == env58139) = true)

theorem identity58139 : scanCanonicalize (H12AffineFastState.compose env58139 (packedSelected [3,8,12] rootPS)) = affineNative (2^(6+1) ^^^ 34) := by decide +kernel

theorem selectedBound58139 : packedSelected [3,8,12] rootPS < 2^1333 := by decide +kernel

def env58140 : List Nat := [2,4,8,16,32,64,34,256,373,95,112,65,8,286,11,40,17,11,95,11,334,302,334,41,34,16,33,286,64,90,84,10,257,11,17,372]

theorem envBound58140 : H12AffineFastState.Bounded env58140 := by
  intro p hp
  have h : env58140.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58139_58140 : H12AffineEnvironment.transform 6 34 env58139 = env58140 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 34 env58139 == env58140) = true)

theorem identity58140 : scanCanonicalize (H12AffineFastState.compose env58140 (packedSelected [2,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 70) := by decide +kernel

theorem selectedBound58140 : packedSelected [2,5,7] rootPS < 2^1333 := by decide +kernel

def env58141 : List Nat := [2,4,8,16,32,64,34,70,51,95,112,65,8,88,11,40,17,11,95,11,8,104,8,41,34,16,33,88,64,90,84,10,71,11,17,50]

theorem envBound58141 : H12AffineFastState.Bounded env58141 := by
  intro p hp
  have h : env58141.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58140_58141 : H12AffineEnvironment.transform 7 70 env58140 = env58141 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 70 env58140 == env58141) = true)

theorem identity58141 : scanCanonicalize (H12AffineFastState.compose env58141 (packedSelected [0,1,2,3,4,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58141 : packedSelected [0,1,2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env58142 : List Nat := [2,4,8,16,32,17,34,23,51,14,33,16,8,9,11,40,17,11,14,11,8,57,8,41,34,16,33,9,17,11,5,10,22,11,17,50]

theorem envBound58142 : H12AffineFastState.Bounded env58142 := by
  intro p hp
  have h : env58142.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58141_58142 : H12AffineEnvironment.transform 5 17 env58141 = env58142 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58141 == env58142) = true)

theorem identity58142 : scanCanonicalize (H12AffineFastState.compose env58142 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound58142 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58143 : List Nat := [2,4,8,16,8,17,10,23,27,14,9,16,8,9,11,0,17,11,14,11,8,17,8,1,10,16,9,9,17,11,5,10,22,11,17,26]

theorem envBound58143 : H12AffineFastState.Bounded env58143 := by
  intro p hp
  have h : env58143.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58142_58143 : H12AffineEnvironment.transform 4 8 env58142 = env58143 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env58142 == env58143) = true)

theorem identity58143 : scanCanonicalize (H12AffineFastState.compose env58143 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58143 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58144 : List Nat := [0,4,8,16,8,17,8,21,25,12,9,16,8,9,9,0,17,9,12,9,8,17,8,1,8,16,9,9,17,9,5,8,20,9,17,24]

theorem envBound58144 : H12AffineFastState.Bounded env58144 := by
  intro p hp
  have h : env58144.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58143_58144 : H12AffineEnvironment.transform 0 0 env58143 = env58144 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58143 == env58144) = true)

theorem identity58144 : scanCanonicalize (H12AffineFastState.compose env58144 (packedSelected [0,3] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound58144 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58145 : List Nat := [0,4,8,8,8,9,8,13,1,12,9,8,8,9,9,0,9,9,12,9,8,9,8,1,8,8,9,9,9,9,5,8,12,9,9,0]

theorem envBound58145 : H12AffineFastState.Bounded env58145 := by
  intro p hp
  have h : env58145.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58144_58145 : H12AffineEnvironment.transform 3 8 env58144 = env58145 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env58144 == env58145) = true)

theorem identity58145 : scanCanonicalize (H12AffineFastState.compose env58145 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound58145 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58146 : List Nat := [0,4,1,1,1,0,1,4,1,5,0,1,1,0,0,0,0,0,5,0,1,0,1,1,1,1,0,0,0,0,5,1,5,0,0,0]

theorem envBound58146 : H12AffineFastState.Bounded env58146 := by
  intro p hp
  have h : env58146.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58145_58146 : H12AffineEnvironment.transform 2 1 env58145 = env58146 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env58145 == env58146) = true)

def env58147 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,4096,8192,445,32768,65536,131072,69825,253,32768,135612,45420,143796,168050,8329,139272,102625,445,131153,75787,200846,204858,257,69730,131072,512]

theorem envBound58147 : H12AffineFastState.Bounded env58147 := by
  intro p hp
  have h : env58147.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58131_58147 : H12AffineEnvironment.transform 13 445 env58131 = env58147 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env58131 == env58147) = true)

theorem identity58147 : scanCanonicalize (H12AffineFastState.compose env58147 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 493) := by decide +kernel

theorem selectedBound58147 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58148 : List Nat := [2,4,8,16,32,64,128,256,512,253,2048,493,8192,445,32768,65536,131072,65836,253,32768,131153,41089,139353,164255,8329,139272,98572,445,131153,75787,196963,204858,257,65935,131072,512]

theorem envBound58148 : H12AffineFastState.Bounded env58148 := by
  intro p hp
  have h : env58148.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58147_58148 : H12AffineEnvironment.transform 11 493 env58147 = env58148 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 493 env58147 == env58148) = true)

def env58149 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144712,169102,2257033,157001,2544860,16384,131153,2324491,200847,221575,257,2295075,131072,2249216]

theorem envBound58149 : H12AffineFastState.Bounded env58149 := by
  intro p hp
  have h : env58149.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58071_58149 : H12AffineEnvironment.transform 21 2269393 env58071 = env58149 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env58071 == env58149) = true)

def env58150 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144712,169102,26057,157001,311708,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound58150 : H12AffineFastState.Bounded env58150 := by
  intro p hp
  have h : env58150.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58149_58150 : H12AffineEnvironment.transform 20 136512 env58149 = env58150 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58149 == env58150) = true)

def env58151 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144712,169102,26057,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound58151 : H12AffineFastState.Bounded env58151 := by
  intro p hp
  have h : env58151.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58150_58151 : H12AffineEnvironment.transform 17 87424 env58150 = env58151 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58150 == env58151) = true)

theorem identity58151 : scanCanonicalize (H12AffineFastState.compose env58151 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 420) := by decide +kernel

theorem selectedBound58151 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58152 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,16384,32768,65536,131072,87424,1024,32768,136512,37941,136428,169102,17517,148717,103452,16384,131153,85231,200847,213027,257,69731,131072,18240]

theorem envBound58152 : H12AffineFastState.Bounded env58152 := by
  intro p hp
  have h : env58152.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58151_58152 : H12AffineEnvironment.transform 12 420 env58151 = env58152 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env58151 == env58152) = true)

def env58153 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1344,32768,65536,131072,69824,1024,32768,136512,37941,136428,169102,301,131501,103452,1344,131153,68015,200847,197987,257,69731,131072,512]

theorem envBound58153 : H12AffineFastState.Bounded env58153 := by
  intro p hp
  have h : env58153.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58152_58153 : H12AffineEnvironment.transform 13 1344 env58152 = env58153 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58152 == env58153) = true)

theorem identity58153 : scanCanonicalize (H12AffineFastState.compose env58153 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58153 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58154 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,420,1344,32768,65536,131072,67024,1024,32768,131152,33061,131580,164254,301,131501,98572,1344,131153,68015,198047,197987,257,66931,131072,512]

theorem envBound58154 : H12AffineFastState.Bounded env58154 := by
  intro p hp
  have h : env58154.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58153_58154 : H12AffineEnvironment.transform 11 1296 env58153 = env58154 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58153 == env58154) = true)

def env58155 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,65536,131072,69825,1024,32768,136512,37941,136428,169102,300,131500,103452,1345,131153,68014,200847,197986,257,69731,131072,513]

theorem envBound58155 : H12AffineFastState.Bounded env58155 := by
  intro p hp
  have h : env58155.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58152_58155 : H12AffineEnvironment.transform 13 1345 env58152 = env58155 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58152 == env58155) = true)

theorem identity58155 : scanCanonicalize (H12AffineFastState.compose env58155 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58155 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58156 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38046,131072,33887,1024,32768,136512,37941,136428,169102,300,131500,130,1345,131153,40240,164881,168444,257,34045,131072,513]

theorem envBound58156 : H12AffineFastState.Bounded env58156 := by
  intro p hp
  have h : env58156.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58155_58156 : H12AffineEnvironment.transform 15 38046 env58155 = env58156 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58155 == env58156) = true)

theorem identity58156 : scanCanonicalize (H12AffineFastState.compose env58156 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 445) := by decide +kernel

theorem selectedBound58156 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58157 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38046,445,33887,1024,32768,5373,37941,5457,38195,300,17,130,1345,492,40240,34220,36929,257,34045,445,513]

theorem envBound58157 : H12AffineFastState.Bounded env58157 := by
  intro p hp
  have h : env58157.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58156_58157 : H12AffineEnvironment.transform 16 445 env58156 = env58157 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 445 env58156 == env58157) = true)

theorem identity58157 : scanCanonicalize (H12AffineFastState.compose env58157 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound58157 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58158 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1109,4299,445,10,1024,1109,5373,4192,5457,4454,300,17,130,1345,492,6501,505,5140,257,168,445,513]

theorem envBound58158 : H12AffineFastState.Bounded env58158 := by
  intro p hp
  have h : env58158.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58157_58158 : H12AffineEnvironment.transform 14 1109 env58157 = env58158 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env58157 == env58158) = true)

theorem identity58158 : scanCanonicalize (H12AffineFastState.compose env58158 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound58158 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58159 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,420,1345,1109,4299,445,10,1024,1109,5373,4192,5457,4454,300,17,130,1345,492,4803,505,5140,257,168,445,513]

theorem envBound58159 : H12AffineFastState.Bounded env58159 := by
  intro p hp
  have h : env58159.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58158_58159 : H12AffineEnvironment.transform 10 934 env58158 = env58159 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env58158 == env58159) = true)

theorem identity58159 : scanCanonicalize (H12AffineFastState.compose env58159 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(9+1) ^^^ 548) := by decide +kernel

theorem selectedBound58159 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58160 : List Nat := [2,4,8,16,32,64,128,256,512,548,934,4096,420,869,625,4299,445,10,548,625,4825,4192,4981,4454,300,17,130,869,492,4803,505,4656,257,168,445,513]

theorem envBound58160 : H12AffineFastState.Bounded env58160 := by
  intro p hp
  have h : env58160.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58159_58160 : H12AffineEnvironment.transform 9 548 env58159 = env58160 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 548 env58159 == env58160) = true)

theorem identity58160 : scanCanonicalize (H12AffineFastState.compose env58160 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound58160 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env58161 : List Nat := [2,4,8,16,32,64,128,256,512,548,934,17,420,869,625,218,445,10,548,625,712,113,868,375,300,17,130,869,492,722,505,545,257,168,445,513]

theorem envBound58161 : H12AffineFastState.Bounded env58161 := by
  intro p hp
  have h : env58161.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58160_58161 : H12AffineEnvironment.transform 11 17 env58160 = env58161 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env58160 == env58161) = true)

theorem identity58161 : scanCanonicalize (H12AffineFastState.compose env58161 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(8+1) ^^^ 372) := by decide +kernel

theorem selectedBound58161 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58162 : List Nat := [2,4,8,16,32,64,128,256,372,336,210,17,420,17,261,218,445,10,336,261,444,113,16,375,300,17,130,17,492,422,505,341,257,168,445,373]

theorem envBound58162 : H12AffineFastState.Bounded env58162 := by
  intro p hp
  have h : env58162.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58161_58162 : H12AffineEnvironment.transform 8 372 env58161 = env58162 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 372 env58161 == env58162) = true)

theorem identity58162 : scanCanonicalize (H12AffineFastState.compose env58162 (packedSelected [1,3,4,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 83) := by decide +kernel

theorem selectedBound58162 : packedSelected [1,3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env58163 : List Nat := [2,4,8,16,32,64,83,256,372,336,1,17,375,17,261,9,366,10,336,261,367,113,16,375,300,17,81,17,319,373,298,341,257,123,366,373]

theorem envBound58163 : H12AffineFastState.Bounded env58163 := by
  intro p hp
  have h : env58163.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58162_58163 : H12AffineEnvironment.transform 6 83 env58162 = env58163 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 83 env58162 == env58163) = true)

theorem identity58163 : scanCanonicalize (H12AffineFastState.compose env58163 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound58163 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58164 : List Nat := [2,4,8,16,32,16,3,256,292,256,1,17,295,17,261,9,318,10,256,261,319,33,16,295,300,17,1,17,319,293,298,261,257,43,318,293]

theorem envBound58164 : H12AffineFastState.Bounded env58164 := by
  intro p hp
  have h : env58164.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58163_58164 : H12AffineEnvironment.transform 5 16 env58163 = env58164 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env58163 == env58164) = true)

theorem identity58164 : scanCanonicalize (H12AffineFastState.compose env58164 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(7+1) ^^^ 63) := by decide +kernel

theorem selectedBound58164 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58165 : List Nat := [2,4,8,16,32,16,3,63,27,63,1,17,24,17,58,9,1,10,63,58,0,33,16,24,19,17,1,17,0,26,21,58,62,43,1,26]

theorem envBound58165 : H12AffineFastState.Bounded env58165 := by
  intro p hp
  have h : env58165.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58164_58165 : H12AffineEnvironment.transform 7 63 env58164 = env58165 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 63 env58164 == env58165) = true)

theorem identity58165 : scanCanonicalize (H12AffineFastState.compose env58165 (packedSelected [2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound58165 : packedSelected [2,3] rootPS < 2^1333 := by decide +kernel

def env58166 : List Nat := [2,4,8,11,32,11,3,36,0,36,1,10,3,10,33,9,1,10,36,33,0,33,11,3,8,10,1,10,0,1,14,33,37,43,1,1]

theorem envBound58166 : H12AffineFastState.Bounded env58166 := by
  intro p hp
  have h : env58166.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58165_58166 : H12AffineEnvironment.transform 3 11 env58165 = env58166 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env58165 == env58166) = true)

theorem identity58166 : scanCanonicalize (H12AffineFastState.compose env58166 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58166 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58167 : List Nat := [2,4,0,3,32,3,3,36,0,36,1,2,3,2,33,1,1,2,36,33,0,33,3,3,0,2,1,2,0,1,6,33,37,35,1,1]

theorem envBound58167 : H12AffineFastState.Bounded env58167 := by
  intro p hp
  have h : env58167.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58166_58167 : H12AffineEnvironment.transform 2 0 env58166 = env58167 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58166 == env58167) = true)

theorem identity58167 : scanCanonicalize (H12AffineFastState.compose env58167 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound58167 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58168 : List Nat := [2,4,0,3,2,3,3,6,0,6,1,2,3,2,3,1,1,2,6,3,0,3,3,3,0,2,1,2,0,1,6,3,7,1,1,1]

theorem envBound58168 : H12AffineFastState.Bounded env58168 := by
  intro p hp
  have h : env58168.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58167_58168 : H12AffineEnvironment.transform 4 2 env58167 = env58168 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env58167 == env58168) = true)

theorem identity58168 : scanCanonicalize (H12AffineFastState.compose env58168 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58168 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58169 : List Nat := [1,4,0,0,1,0,0,5,0,5,1,1,0,1,0,1,1,1,5,0,0,0,0,0,0,1,1,1,0,1,5,0,4,1,1,1]

theorem envBound58169 : H12AffineFastState.Bounded env58169 := by
  intro p hp
  have h : env58169.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58168_58169 : H12AffineEnvironment.transform 0 1 env58168 = env58169 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58168 == env58169) = true)

def env58170 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46481,144712,169102,26057,157001,103453,16384,131153,93515,200847,221575,257,69731,131072,18240]

theorem envBound58170 : H12AffineFastState.Bounded env58170 := by
  intro p hp
  have h : env58170.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58150_58170 : H12AffineEnvironment.transform 17 87425 env58150 = env58170 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58150 == env58170) = true)

theorem identity58170 : scanCanonicalize (H12AffineFastState.compose env58170 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 9445) := by decide +kernel

theorem selectedBound58170 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58171 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,9445,32768,65536,131072,78180,1024,32768,136512,46481,144712,169102,300,131500,103453,9445,131153,68014,200847,197986,257,69731,131072,9125]

theorem envBound58171 : H12AffineFastState.Bounded env58171 := by
  intro p hp
  have h : env58171.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58170_58171 : H12AffineEnvironment.transform 13 9445 env58170 = env58171 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9445 env58170 == env58171) = true)

def env58172 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,65536,131072,69824,1024,32768,136512,37941,136428,169102,300,131500,103453,1345,131153,68014,200847,197986,257,69731,131072,513]

theorem envBound58172 : H12AffineFastState.Bounded env58172 := by
  intro p hp
  have h : env58172.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58171_58172 : H12AffineEnvironment.transform 12 420 env58171 = env58172 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 420 env58171 == env58172) = true)

theorem identity58172 : scanCanonicalize (H12AffineFastState.compose env58172 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38046) := by decide +kernel

theorem selectedBound58172 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58173 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38046,131072,33886,1024,32768,136512,37941,136428,169102,300,131500,131,1345,131153,40240,164881,168444,257,34045,131072,513]

theorem envBound58173 : H12AffineFastState.Bounded env58173 := by
  intro p hp
  have h : env58173.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58172_58173 : H12AffineEnvironment.transform 15 38046 env58172 = env58173 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38046 env58172 == env58173) = true)

theorem identity58173 : scanCanonicalize (H12AffineFastState.compose env58173 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 445) := by decide +kernel

theorem selectedBound58173 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58174 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,32768,38046,445,33886,1024,32768,5373,37941,5457,38195,300,17,131,1345,492,40240,34220,36929,257,34045,445,513]

theorem envBound58174 : H12AffineFastState.Bounded env58174 := by
  intro p hp
  have h : env58174.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58173_58174 : H12AffineEnvironment.transform 16 445 env58173 = env58174 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 445 env58173 == env58174) = true)

theorem identity58174 : scanCanonicalize (H12AffineFastState.compose env58174 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound58174 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58175 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,420,1345,1109,4299,445,11,1024,1109,5373,4192,5457,4454,300,17,131,1345,492,6501,505,5140,257,168,445,513]

theorem envBound58175 : H12AffineFastState.Bounded env58175 := by
  intro p hp
  have h : env58175.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58174_58175 : H12AffineEnvironment.transform 14 1109 env58174 = env58175 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env58174 == env58175) = true)

theorem identity58175 : scanCanonicalize (H12AffineFastState.compose env58175 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 934) := by decide +kernel

theorem selectedBound58175 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58176 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,4096,420,1345,1109,4299,445,11,1024,1109,5373,4192,5457,4454,300,17,131,1345,492,4803,505,5140,257,168,445,513]

theorem envBound58176 : H12AffineFastState.Bounded env58176 := by
  intro p hp
  have h : env58176.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58175_58176 : H12AffineEnvironment.transform 10 934 env58175 = env58176 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 934 env58175 == env58176) = true)

theorem identity58176 : scanCanonicalize (H12AffineFastState.compose env58176 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(11+1) ^^^ 821) := by decide +kernel

theorem selectedBound58176 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58177 : List Nat := [2,4,8,16,32,64,128,256,512,1024,934,821,420,1345,1109,1022,445,11,1024,1109,1992,853,1636,595,300,17,131,1345,492,502,505,1825,257,168,445,513]

theorem envBound58177 : H12AffineFastState.Bounded env58177 := by
  intro p hp
  have h : env58177.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58176_58177 : H12AffineEnvironment.transform 11 821 env58176 = env58177 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 821 env58176 == env58177) = true)

theorem identity58177 : scanCanonicalize (H12AffineFastState.compose env58177 (packedSelected [1,4,5,9,10,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 257) := by decide +kernel

theorem selectedBound58177 : packedSelected [1,4,5,9,10,17,20] rootPS < 2^1333 := by decide +kernel

def env58178 : List Nat := [2,4,8,16,32,64,128,256,512,257,934,821,420,64,340,1022,445,11,257,340,713,853,869,595,300,17,131,64,492,502,505,544,257,168,445,513]

theorem envBound58178 : H12AffineFastState.Bounded env58178 := by
  intro p hp
  have h : env58178.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58177_58178 : H12AffineEnvironment.transform 9 257 env58177 = env58178 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 257 env58177 == env58178) = true)

theorem identity58178 : scanCanonicalize (H12AffineFastState.compose env58178 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58178 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58179 : List Nat := [2,4,8,16,32,17,128,256,512,257,934,821,420,17,261,943,445,11,257,261,664,772,820,514,300,17,131,17,445,423,424,544,257,168,445,513]

theorem envBound58179 : H12AffineFastState.Bounded env58179 := by
  intro p hp
  have h : env58179.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58178_58179 : H12AffineEnvironment.transform 5 17 env58178 = env58179 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58178 == env58179) = true)

theorem identity58179 : scanCanonicalize (H12AffineFastState.compose env58179 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound58179 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58180 : List Nat := [2,4,8,16,32,17,128,256,293,257,131,16,420,17,261,138,445,11,257,261,445,33,17,295,300,17,131,17,445,423,424,261,257,168,445,292]

theorem envBound58180 : H12AffineFastState.Bounded env58180 := by
  intro p hp
  have h : env58180.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58179_58180 : H12AffineEnvironment.transform 8 293 env58179 = env58180 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env58179 == env58180) = true)

theorem identity58180 : scanCanonicalize (H12AffineFastState.compose env58180 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58180 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58181 : List Nat := [2,4,8,0,32,1,128,256,293,257,131,0,420,1,261,138,429,11,257,261,429,33,1,295,300,1,131,1,429,423,424,261,257,168,429,292]

theorem envBound58181 : H12AffineFastState.Bounded env58181 := by
  intro p hp
  have h : env58181.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58180_58181 : H12AffineEnvironment.transform 3 0 env58180 = env58181 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58180 == env58181) = true)

theorem identity58181 : scanCanonicalize (H12AffineFastState.compose env58181 (packedSelected [5] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound58181 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env58182 : List Nat := [2,4,8,0,32,1,8,256,293,257,11,0,300,1,261,2,293,11,257,261,293,33,1,295,300,1,11,1,293,303,288,261,257,32,293,292]

theorem envBound58182 : H12AffineFastState.Bounded env58182 := by
  intro p hp
  have h : env58182.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58181_58182 : H12AffineEnvironment.transform 6 8 env58181 = env58182 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env58181 == env58182) = true)

theorem identity58182 : scanCanonicalize (H12AffineFastState.compose env58182 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58182 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58183 : List Nat := [2,4,0,0,32,1,0,256,293,257,3,0,292,1,261,2,293,3,257,261,293,33,1,295,292,1,3,1,293,295,288,261,257,32,293,292]

theorem envBound58183 : H12AffineFastState.Bounded env58183 := by
  intro p hp
  have h : env58183.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58182_58183 : H12AffineEnvironment.transform 2 0 env58182 = env58183 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58182 == env58183) = true)

theorem identity58183 : scanCanonicalize (H12AffineFastState.compose env58183 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound58183 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58184 : List Nat := [2,4,0,0,3,1,0,256,262,257,3,0,263,1,261,2,262,3,257,261,262,2,1,260,263,1,3,1,262,260,259,261,257,3,262,263]

theorem envBound58184 : H12AffineFastState.Bounded env58184 := by
  intro p hp
  have h : env58184.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58183_58184 : H12AffineEnvironment.transform 4 3 env58183 = env58184 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env58183 == env58184) = true)

theorem identity58184 : scanCanonicalize (H12AffineFastState.compose env58184 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 7) := by decide +kernel

theorem selectedBound58184 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58185 : List Nat := [2,4,0,0,3,1,0,7,1,6,3,0,0,1,2,2,1,3,6,2,1,2,1,3,0,1,3,1,1,3,4,2,6,3,1,0]

theorem envBound58185 : H12AffineFastState.Bounded env58185 := by
  intro p hp
  have h : env58185.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58184_58185 : H12AffineEnvironment.transform 7 7 env58184 = env58185 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 7 env58184 == env58185) = true)

theorem identity58185 : scanCanonicalize (H12AffineFastState.compose env58185 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58185 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58186 : List Nat := [1,4,0,0,0,1,0,4,1,5,0,0,0,1,1,1,1,0,5,1,1,1,1,0,0,1,0,1,1,0,4,1,5,0,1,0]

theorem envBound58186 : H12AffineFastState.Bounded env58186 := by
  intro p hp
  have h : env58186.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58185_58186 : H12AffineEnvironment.transform 0 1 env58185 = env58186 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58185 == env58186) = true)

def env58187 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1344,32768,65536,131072,69825,1024,32768,136512,37940,136429,169102,300,131500,103453,1344,131153,68014,200847,197986,257,69731,131072,512]

theorem envBound58187 : H12AffineFastState.Bounded env58187 := by
  intro p hp
  have h : env58187.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58171_58187 : H12AffineEnvironment.transform 12 421 env58171 = env58187 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env58171 == env58187) = true)

theorem identity58187 : scanCanonicalize (H12AffineFastState.compose env58187 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58187 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58188 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,421,1344,32768,65536,131072,67025,1024,32768,131152,33060,131581,164254,300,131500,98573,1344,131153,68014,198047,197986,257,66931,131072,512]

theorem envBound58188 : H12AffineFastState.Bounded env58188 := by
  intro p hp
  have h : env58188.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58187_58188 : H12AffineEnvironment.transform 11 1296 env58187 = env58188 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58187 == env58188) = true)

def env58189 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46480,144712,169102,26056,157001,311709,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound58189 : H12AffineFastState.Bounded env58189 := by
  intro p hp
  have h : env58189.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58149_58189 : H12AffineEnvironment.transform 20 136513 env58149 = env58189 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env58149 == env58189) = true)

def env58190 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46480,144712,169102,26056,157001,103453,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound58190 : H12AffineFastState.Bounded env58190 := by
  intro p hp
  have h : env58190.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58189_58190 : H12AffineEnvironment.transform 17 87424 env58189 = env58190 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58189 == env58190) = true)

theorem identity58190 : scanCanonicalize (H12AffineFastState.compose env58190 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 12789) := by decide +kernel

theorem selectedBound58190 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58191 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12789,32768,65536,131072,74869,1024,32768,136513,46480,144712,169102,5181,136380,103453,12789,131153,72895,200847,200818,257,69730,131072,14004]

theorem envBound58191 : H12AffineFastState.Bounded env58191 := by
  intro p hp
  have h : env58191.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58190_58191 : H12AffineEnvironment.transform 13 12789 env58190 = env58191 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12789 env58190 == env58191) = true)

def env58192 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1345,32768,65536,131072,69825,1024,32768,136513,33060,131580,169102,5181,136380,103453,1345,131153,72895,200847,200818,257,69730,131072,512]

theorem envBound58192 : H12AffineFastState.Bounded env58192 := by
  intro p hp
  have h : env58192.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58191_58192 : H12AffineEnvironment.transform 12 5300 env58191 = env58192 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env58191 == env58192) = true)

theorem identity58192 : scanCanonicalize (H12AffineFastState.compose env58192 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58192 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58193 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,421,1345,32768,65536,131072,67024,1024,32768,131152,33060,131580,164255,300,131501,98572,1345,131153,68014,198046,197987,257,66931,131072,512]

theorem envBound58193 : H12AffineFastState.Bounded env58193 := by
  intro p hp
  have h : env58193.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58192_58193 : H12AffineEnvironment.transform 11 1297 env58192 = env58193 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58192 == env58193) = true)

def env58194 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,65536,131072,69824,1024,32768,136513,33061,131581,169102,5181,136380,103453,1344,131153,72895,200847,200818,257,69730,131072,513]

theorem envBound58194 : H12AffineFastState.Bounded env58194 := by
  intro p hp
  have h : env58194.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58191_58194 : H12AffineEnvironment.transform 12 5301 env58191 = env58194 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env58191 == env58194) = true)

theorem identity58194 : scanCanonicalize (H12AffineFastState.compose env58194 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58194 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58195 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38047,131072,33887,1024,32768,136513,33061,131581,169102,5181,136380,130,1344,131153,34848,164880,165101,257,34045,131072,513]

theorem envBound58195 : H12AffineFastState.Bounded env58195 := by
  intro p hp
  have h : env58195.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58194_58195 : H12AffineEnvironment.transform 15 38047 env58194 = env58195 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58194 == env58195) = true)

theorem identity58195 : scanCanonicalize (H12AffineFastState.compose env58195 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5293) := by decide +kernel

theorem selectedBound58195 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58196 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38047,5293,33887,1024,32768,492,33061,5456,32803,5181,17,130,1344,5372,34848,37053,36928,257,34045,5293,513]

theorem envBound58196 : H12AffineFastState.Bounded env58196 := by
  intro p hp
  have h : env58196.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58195_58196 : H12AffineEnvironment.transform 16 5293 env58195 = env58196 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5293 env58195 == env58196) = true)

theorem identity58196 : scanCanonicalize (H12AffineFastState.compose env58196 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound58196 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58197 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1109,4298,5293,10,1024,1109,492,1392,5456,1142,5181,17,130,1344,5372,3189,5352,5141,257,168,5293,513]

theorem envBound58197 : H12AffineFastState.Bounded env58197 := by
  intro p hp
  have h : env58197.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58196_58197 : H12AffineEnvironment.transform 14 1109 env58196 = env58197 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env58196 == env58197) = true)

theorem identity58197 : scanCanonicalize (H12AffineFastState.compose env58197 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3767) := by decide +kernel

theorem selectedBound58197 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58198 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3767,2562,1344,1109,3709,2586,10,1024,1109,492,1392,3047,1142,2698,17,130,1344,2635,3189,2655,2722,257,168,2586,513]

theorem envBound58198 : H12AffineFastState.Bounded env58198 := by
  intro p hp
  have h : env58198.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58197_58198 : H12AffineEnvironment.transform 11 3767 env58197 = env58198 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3767 env58197 == env58198) = true)

theorem identity58198 : scanCanonicalize (H12AffineFastState.compose env58198 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(10+1) ^^^ 383) := by decide +kernel

theorem selectedBound58198 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58199 : List Nat := [2,4,8,16,32,64,128,256,512,1024,383,1992,893,1344,1109,1794,869,10,1024,1109,492,1392,664,1142,1013,17,130,1344,820,1290,800,989,257,168,869,513]

theorem envBound58199 : H12AffineFastState.Bounded env58199 := by
  intro p hp
  have h : env58199.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58198_58199 : H12AffineEnvironment.transform 10 383 env58198 = env58199 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 383 env58198 == env58199) = true)

theorem identity58199 : scanCanonicalize (H12AffineFastState.compose env58199 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound58199 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env58200 : List Nat := [2,4,8,16,32,64,128,253,512,1024,130,1589,640,1213,1109,1791,664,10,1024,1109,17,1165,664,1142,520,17,130,1213,713,1271,733,544,252,168,664,513]

theorem envBound58200 : H12AffineFastState.Bounded env58200 := by
  intro p hp
  have h : env58200.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58199_58200 : H12AffineEnvironment.transform 7 253 env58199 = env58200 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env58199 == env58200) = true)

theorem identity58200 : scanCanonicalize (H12AffineFastState.compose env58200 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 628) := by decide +kernel

theorem selectedBound58200 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58201 : List Nat := [2,4,8,16,32,64,128,253,512,628,130,65,640,713,545,139,664,10,628,545,17,761,664,514,520,17,130,713,713,643,733,544,252,168,664,513]

theorem envBound58201 : H12AffineFastState.Bounded env58201 := by
  intro p hp
  have h : env58201.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58200_58201 : H12AffineEnvironment.transform 9 628 env58200 = env58201 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 628 env58200 == env58201) = true)

theorem identity58201 : scanCanonicalize (H12AffineFastState.compose env58201 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58201 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58202 : List Nat := [2,4,8,16,32,64,128,253,216,172,130,65,88,17,249,139,64,10,172,249,17,33,64,218,208,17,130,17,17,91,5,248,252,168,64,217]

theorem envBound58202 : H12AffineFastState.Bounded env58202 := by
  intro p hp
  have h : env58202.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58201_58202 : H12AffineEnvironment.transform 8 216 env58201 = env58202 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58201 == env58202) = true)

theorem identity58202 : scanCanonicalize (H12AffineFastState.compose env58202 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound58202 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58203 : List Nat := [2,4,8,16,32,64,24,101,64,52,26,65,88,17,97,19,64,10,52,97,17,33,64,66,72,17,26,17,17,91,5,96,100,48,64,65]

theorem envBound58203 : H12AffineFastState.Bounded env58203 := by
  intro p hp
  have h : env58203.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58202_58203 : H12AffineEnvironment.transform 6 24 env58202 = env58203 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env58202 == env58203) = true)

theorem identity58203 : scanCanonicalize (H12AffineFastState.compose env58203 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound58203 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58204 : List Nat := [2,4,8,16,27,64,24,94,64,15,26,65,88,17,90,19,64,10,15,90,17,26,64,66,72,17,26,17,17,91,5,91,95,11,64,65]

theorem envBound58204 : H12AffineFastState.Bounded env58204 := by
  intro p hp
  have h : env58204.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58203_58204 : H12AffineEnvironment.transform 4 27 env58203 = env58204 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env58203 == env58204) = true)

theorem identity58204 : scanCanonicalize (H12AffineFastState.compose env58204 (packedSelected [0,1] rootPS)) = affineNative (2^(5+1) ^^^ 25) := by decide +kernel

theorem selectedBound58204 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58205 : List Nat := [2,4,8,16,27,25,24,7,25,15,26,24,1,17,3,19,25,10,15,3,17,26,25,27,17,17,26,17,17,2,5,2,6,11,25,24]

theorem envBound58205 : H12AffineFastState.Bounded env58205 := by
  intro p hp
  have h : env58205.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58204_58205 : H12AffineEnvironment.transform 5 25 env58204 = env58205 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 25 env58204 == env58205) = true)

theorem identity58205 : scanCanonicalize (H12AffineFastState.compose env58205 (packedSelected [0,5] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound58205 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env58206 : List Nat := [2,4,8,9,2,0,1,7,0,15,3,1,1,8,3,10,0,10,15,3,8,3,0,2,8,8,3,8,8,2,5,2,6,11,0,1]

theorem envBound58206 : H12AffineFastState.Bounded env58206 := by
  intro p hp
  have h : env58206.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58205_58206 : H12AffineEnvironment.transform 3 9 env58205 = env58206 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env58205 == env58206) = true)

def env58207 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46480,144712,169102,26056,157001,103452,16384,131153,93514,200847,221575,257,69730,131072,18241]

theorem envBound58207 : H12AffineFastState.Bounded env58207 := by
  intro p hp
  have h : env58207.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58189_58207 : H12AffineEnvironment.transform 17 87425 env58189 = env58207 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58189 == env58207) = true)

theorem identity58207 : scanCanonicalize (H12AffineFastState.compose env58207 (packedSelected [6] rootPS)) = affineNative (2^(12+1) ^^^ 5301) := by decide +kernel

theorem selectedBound58207 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58208 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,16384,32768,65536,131072,87425,1024,32768,136513,33061,131581,169102,20861,152060,103452,16384,131153,88575,200847,218418,257,69730,131072,18241]

theorem envBound58208 : H12AffineFastState.Bounded env58208 := by
  intro p hp
  have h : env58208.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58207_58208 : H12AffineEnvironment.transform 12 5301 env58207 = env58208 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5301 env58207 == env58208) = true)

def env58209 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,65536,131072,69825,1024,32768,136513,33061,131581,169102,5181,136380,103452,1344,131153,72895,200847,200818,257,69730,131072,513]

theorem envBound58209 : H12AffineFastState.Bounded env58209 := by
  intro p hp
  have h : env58209.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58208_58209 : H12AffineEnvironment.transform 13 1344 env58208 = env58209 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58208 == env58209) = true)

theorem identity58209 : scanCanonicalize (H12AffineFastState.compose env58209 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 38047) := by decide +kernel

theorem selectedBound58209 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58210 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38047,131072,33886,1024,32768,136513,33061,131581,169102,5181,136380,131,1344,131153,34848,164880,165101,257,34045,131072,513]

theorem envBound58210 : H12AffineFastState.Bounded env58210 := by
  intro p hp
  have h : env58210.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58209_58210 : H12AffineEnvironment.transform 15 38047 env58209 = env58210 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 38047 env58209 == env58210) = true)

theorem identity58210 : scanCanonicalize (H12AffineFastState.compose env58210 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 5293) := by decide +kernel

theorem selectedBound58210 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58211 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,32768,38047,5293,33886,1024,32768,492,33061,5456,32803,5181,17,131,1344,5372,34848,37053,36928,257,34045,5293,513]

theorem envBound58211 : H12AffineFastState.Bounded env58211 := by
  intro p hp
  have h : env58211.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58210_58211 : H12AffineEnvironment.transform 16 5293 env58210 = env58211 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5293 env58210 == env58211) = true)

theorem identity58211 : scanCanonicalize (H12AffineFastState.compose env58211 (packedSelected [25] rootPS)) = affineNative (2^(14+1) ^^^ 1109) := by decide +kernel

theorem selectedBound58211 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58212 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1344,1109,4298,5293,11,1024,1109,492,1392,5456,1142,5181,17,131,1344,5372,3189,5352,5141,257,168,5293,513]

theorem envBound58212 : H12AffineFastState.Bounded env58212 := by
  intro p hp
  have h : env58212.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58211_58212 : H12AffineEnvironment.transform 14 1109 env58211 = env58212 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1109 env58211 == env58212) = true)

theorem identity58212 : scanCanonicalize (H12AffineFastState.compose env58212 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 3767) := by decide +kernel

theorem selectedBound58212 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58213 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3767,2562,1344,1109,3709,2586,11,1024,1109,492,1392,3047,1142,2698,17,131,1344,2635,3189,2655,2722,257,168,2586,513]

theorem envBound58213 : H12AffineFastState.Bounded env58213 := by
  intro p hp
  have h : env58213.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58212_58213 : H12AffineEnvironment.transform 11 3767 env58212 = env58213 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3767 env58212 == env58213) = true)

theorem identity58213 : scanCanonicalize (H12AffineFastState.compose env58213 (packedSelected [0,1,4,5,7,9,10,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58213 : packedSelected [0,1,4,5,7,9,10,13] rootPS < 2^1333 := by decide +kernel

def env58214 : List Nat := [2,4,8,16,32,64,128,256,216,1024,2048,3183,2266,1344,1109,3237,2242,11,1024,1109,492,1392,2367,1142,2130,17,131,1344,2195,3189,2183,2170,257,168,2242,217]

theorem envBound58214 : H12AffineFastState.Bounded env58214 := by
  intro p hp
  have h : env58214.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58213_58214 : H12AffineEnvironment.transform 8 216 env58213 = env58214 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58213 == env58214) = true)

theorem identity58214 : scanCanonicalize (H12AffineFastState.compose env58214 (packedSelected [3,4,5,9,10,12,15,17,20] rootPS)) = affineNative (2^(10+1) ^^^ 131) := by decide +kernel

theorem selectedBound58214 : packedSelected [3,4,5,9,10,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env58215 : List Nat := [2,4,8,16,32,64,128,256,216,1024,131,1260,89,1344,1109,1062,65,11,1024,1109,492,1392,444,1142,209,17,131,1344,16,1270,4,249,257,168,65,217]

theorem envBound58215 : H12AffineFastState.Bounded env58215 := by
  intro p hp
  have h : env58215.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58214_58215 : H12AffineEnvironment.transform 10 131 env58214 = env58215 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 131 env58214 == env58215) = true)

theorem identity58215 : scanCanonicalize (H12AffineFastState.compose env58215 (packedSelected [1,5,10,17] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound58215 : packedSelected [1,5,10,17] rootPS < 2^1333 := by decide +kernel

def env58216 : List Nat := [2,4,8,16,32,64,128,256,216,173,131,65,89,493,248,139,65,11,173,248,492,477,444,219,209,17,131,493,16,91,4,249,257,168,65,217]

theorem envBound58216 : H12AffineFastState.Bounded env58216 := by
  intro p hp
  have h : env58216.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58215_58216 : H12AffineEnvironment.transform 9 173 env58215 = env58216 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env58215 == env58216) = true)

theorem identity58216 : scanCanonicalize (H12AffineFastState.compose env58216 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound58216 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58217 : List Nat := [2,4,8,16,32,64,128,252,216,173,131,65,89,17,248,139,65,11,173,248,16,33,64,219,209,17,131,17,16,91,4,249,253,168,65,217]

theorem envBound58217 : H12AffineFastState.Bounded env58217 := by
  intro p hp
  have h : env58217.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58216_58217 : H12AffineEnvironment.transform 7 252 env58216 = env58217 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env58216 == env58217) = true)

theorem identity58217 : scanCanonicalize (H12AffineFastState.compose env58217 (packedSelected [0,1,2,4] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound58217 : packedSelected [0,1,2,4] rootPS < 2^1333 := by decide +kernel

def env58218 : List Nat := [2,4,8,16,32,64,24,100,64,53,27,65,89,17,96,19,65,11,53,96,16,33,64,67,73,17,27,17,16,91,4,97,101,48,65,65]

theorem envBound58218 : H12AffineFastState.Bounded env58218 := by
  intro p hp
  have h : env58218.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58217_58218 : H12AffineEnvironment.transform 6 24 env58217 = env58218 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env58217 == env58218) = true)

theorem identity58218 : scanCanonicalize (H12AffineFastState.compose env58218 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 42) := by decide +kernel

theorem selectedBound58218 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env58219 : List Nat := [2,4,8,16,32,42,24,14,42,53,27,43,51,17,10,19,43,11,53,10,16,33,42,41,35,17,27,17,16,49,4,11,15,48,43,43]

theorem envBound58219 : H12AffineFastState.Bounded env58219 := by
  intro p hp
  have h : env58219.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58218_58219 : H12AffineEnvironment.transform 5 42 env58218 = env58219 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 42 env58218 == env58219) = true)

theorem identity58219 : scanCanonicalize (H12AffineFastState.compose env58219 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58219 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58220 : List Nat := [2,4,0,16,32,34,16,6,34,53,19,35,51,17,2,19,35,3,53,2,16,33,34,33,35,17,19,17,16,49,4,3,7,48,35,35]

theorem envBound58220 : H12AffineFastState.Bounded env58220 := by
  intro p hp
  have h : env58220.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58219_58220 : H12AffineEnvironment.transform 2 0 env58219 = env58220 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58219 == env58220) = true)

theorem identity58220 : scanCanonicalize (H12AffineFastState.compose env58220 (packedSelected [1,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58220 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env58221 : List Nat := [2,4,0,0,32,34,0,6,34,37,3,35,35,1,2,3,35,3,37,2,0,33,34,33,35,1,3,1,0,33,4,3,7,32,35,35]

theorem envBound58221 : H12AffineFastState.Bounded env58221 := by
  intro p hp
  have h : env58221.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58220_58221 : H12AffineEnvironment.transform 3 0 env58220 = env58221 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58220 == env58221) = true)

theorem identity58221 : scanCanonicalize (H12AffineFastState.compose env58221 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound58221 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58222 : List Nat := [2,4,0,0,3,1,0,6,1,6,3,0,0,1,2,3,0,3,6,2,0,2,1,2,0,1,3,1,0,2,4,3,7,3,0,0]

theorem envBound58222 : H12AffineFastState.Bounded env58222 := by
  intro p hp
  have h : env58222.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58221_58222 : H12AffineEnvironment.transform 4 3 env58221 = env58222 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env58221 == env58222) = true)

theorem identity58222 : scanCanonicalize (H12AffineFastState.compose env58222 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58222 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env58223 : List Nat := [0,4,0,0,1,1,0,4,1,4,1,0,0,1,0,1,0,1,4,0,0,0,1,0,0,1,1,1,0,0,4,1,5,1,0,0]

theorem envBound58223 : H12AffineFastState.Bounded env58223 := by
  intro p hp
  have h : env58223.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58222_58223 : H12AffineEnvironment.transform 0 0 env58222 = env58223 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58222 == env58223) = true)

def env58224 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5301,1345,32768,65536,131072,69824,1024,32768,136513,33061,131581,169102,5180,136381,103452,1345,131153,72894,200847,200819,257,69730,131072,512]

theorem envBound58224 : H12AffineFastState.Bounded env58224 := by
  intro p hp
  have h : env58224.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58208_58224 : H12AffineEnvironment.transform 13 1345 env58208 = env58224 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58208 == env58224) = true)

theorem identity58224 : scanCanonicalize (H12AffineFastState.compose env58224 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58224 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58225 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,420,1345,32768,65536,131072,67025,1024,32768,131152,33061,131581,164255,301,131500,98573,1345,131153,68015,198046,197986,257,66931,131072,512]

theorem envBound58225 : H12AffineFastState.Bounded env58225 := by
  intro p hp
  have h : env58225.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58224_58225 : H12AffineEnvironment.transform 11 1297 env58224 = env58225 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58224 == env58225) = true)

def env58226 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,4194304,6329753,6304863,4247641,6342040,2544860,16384,131153,4315354,6402142,221575,257,2295075,131072,4256464]

theorem envBound58226 : H12AffineFastState.Bounded env58226 := by
  intro p hp
  have h : env58226.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58070_58226 : H12AffineEnvironment.transform 24 4247641 env58070 = env58226 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 24 4247641 env58070 == env58226) = true)

def env58227 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269392,144713,169103,2257033,157000,2544860,16384,131153,2324490,200846,221575,257,2295075,131072,2249216]

theorem envBound58227 : H12AffineFastState.Bounded env58227 := by
  intro p hp
  have h : env58227.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58226_58227 : H12AffineEnvironment.transform 21 2269392 env58226 = env58227 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269392 env58226 == env58227) = true)

def env58228 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46480,144713,169103,26057,157000,311708,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58228 : H12AffineFastState.Bounded env58228 := by
  intro p hp
  have h : env58228.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58227_58228 : H12AffineEnvironment.transform 20 136512 env58227 = env58228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58227 == env58228) = true)

def env58229 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46480,144713,169103,26057,157000,103452,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58229 : H12AffineFastState.Bounded env58229 := by
  intro p hp
  have h : env58229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58228_58229 : H12AffineEnvironment.transform 17 87424 env58228 = env58229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58228 == env58229) = true)

theorem identity58229 : scanCanonicalize (H12AffineFastState.compose env58229 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 24752) := by decide +kernel

theorem selectedBound58229 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58230 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,24752,65536,131072,87424,1024,24752,136512,21792,144713,160831,26057,157000,95404,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58230 : H12AffineFastState.Bounded env58230 := by
  intro p hp
  have h : env58230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58229_58230 : H12AffineEnvironment.transform 14 24752 env58229 = env58230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 24752 env58229 == env58230) = true)

def env58231 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9712,65536,131072,69824,1024,9712,136512,4192,144713,143743,8329,139272,78316,1344,131153,75786,200846,206023,257,69731,131072,512]

theorem envBound58231 : H12AffineFastState.Bounded env58231 := by
  intro p hp
  have h : env58231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58230_58231 : H12AffineEnvironment.transform 13 1344 env58230 = env58231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58230 == env58231) = true)

theorem identity58231 : scanCanonicalize (H12AffineFastState.compose env58231 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58231 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58232 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,9712,65536,131072,67024,1024,9712,131152,1392,139353,140399,8329,139272,75004,1344,131153,75786,198046,206023,257,66931,131072,512]

theorem envBound58232 : H12AffineFastState.Bounded env58232 := by
  intro p hp
  have h : env58232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58231_58232 : H12AffineEnvironment.transform 11 1296 env58231 = env58232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58231 == env58232) = true)

def env58233 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,65536,131072,69825,1024,9713,136512,4193,144713,143742,8328,139273,78317,1345,131153,75787,200846,206022,257,69731,131072,513]

theorem envBound58233 : H12AffineFastState.Bounded env58233 := by
  intro p hp
  have h : env58233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58230_58233 : H12AffineEnvironment.transform 13 1345 env58230 = env58233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58230 == env58233) = true)

theorem identity58233 : scanCanonicalize (H12AffineFastState.compose env58233 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 12654) := by decide +kernel

theorem selectedBound58233 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58234 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,12654,131072,8623,1024,9713,136512,4193,144713,143742,8328,139273,131,1345,131153,6501,139744,136616,257,8461,131072,513]

theorem envBound58234 : H12AffineFastState.Bounded env58234 := by
  intro p hp
  have h : env58234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58233_58234 : H12AffineEnvironment.transform 15 12654 env58233 = env58234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12654 env58233 == env58234) = true)

theorem identity58234 : scanCanonicalize (H12AffineFastState.compose env58234 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound58234 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58235 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,12654,8217,8623,1024,9713,13657,4193,5456,4455,8328,16,131,1345,8264,6501,505,13745,257,8461,8217,513]

theorem envBound58235 : H12AffineFastState.Bounded env58235 := by
  intro p hp
  have h : env58235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58234_58235 : H12AffineEnvironment.transform 16 8217 env58234 = env58235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env58234 == env58235) = true)

theorem identity58235 : scanCanonicalize (H12AffineFastState.compose env58235 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound58235 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58236 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1108,4299,444,10,1024,1108,5372,4193,5456,4455,301,16,131,1345,493,6501,505,5140,257,168,444,513]

theorem envBound58236 : H12AffineFastState.Bounded env58236 := by
  intro p hp
  have h : env58236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58235_58236 : H12AffineEnvironment.transform 12 421 env58235 = env58236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env58235 == env58236) = true)

theorem identity58236 : scanCanonicalize (H12AffineFastState.compose env58236 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound58236 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58237 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,421,1345,1108,2688,444,10,1024,1108,3767,2602,3867,2860,301,16,131,1345,493,814,505,3679,257,168,444,513]

theorem envBound58237 : H12AffineFastState.Bounded env58237 := by
  intro p hp
  have h : env58237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58236_58237 : H12AffineEnvironment.transform 11 2635 env58236 = env58237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env58236 == env58237) = true)

theorem identity58237 : scanCanonicalize (H12AffineFastState.compose env58237 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 173) := by decide +kernel

theorem selectedBound58237 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58238 : List Nat := [2,4,8,16,32,64,128,256,512,173,2048,2635,421,492,249,2688,444,10,173,249,2586,2602,2998,2860,301,16,131,492,493,814,505,2802,257,168,444,513]

theorem envBound58238 : H12AffineFastState.Bounded env58238 := by
  intro p hp
  have h : env58238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58237_58238 : H12AffineEnvironment.transform 9 173 env58237 = env58238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env58237 == env58238) = true)

theorem identity58238 : scanCanonicalize (H12AffineFastState.compose env58238 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(10+1) ^^^ 603) := by decide +kernel

theorem selectedBound58238 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env58239 : List Nat := [2,4,8,16,32,64,128,256,512,173,603,16,421,492,249,219,444,10,173,249,65,113,493,375,301,16,131,492,493,814,505,169,257,168,444,513]

theorem envBound58239 : H12AffineFastState.Bounded env58239 := by
  intro p hp
  have h : env58239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58238_58239 : H12AffineEnvironment.transform 10 603 env58238 = env58239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 603 env58238 == env58239) = true)

theorem identity58239 : scanCanonicalize (H12AffineFastState.compose env58239 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58239 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58240 : List Nat := [2,4,8,16,32,64,128,256,216,173,131,16,421,492,249,219,444,10,173,249,65,113,493,375,301,16,131,492,493,502,505,169,257,168,444,217]

theorem envBound58240 : H12AffineFastState.Bounded env58240 := by
  intro p hp
  have h : env58240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58239_58240 : H12AffineEnvironment.transform 8 216 env58239 = env58240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58239 == env58240) = true)

theorem identity58240 : scanCanonicalize (H12AffineFastState.compose env58240 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(7+1) ^^^ 205) := by decide +kernel

theorem selectedBound58240 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env58241 : List Nat := [2,4,8,16,32,64,128,205,216,173,131,16,104,33,249,219,113,10,173,249,65,113,32,186,224,16,131,33,32,59,52,169,204,168,113,217]

theorem envBound58241 : H12AffineFastState.Bounded env58241 := by
  intro p hp
  have h : env58241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58240_58241 : H12AffineEnvironment.transform 7 205 env58240 = env58241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 205 env58240 == env58241) = true)

theorem identity58241 : scanCanonicalize (H12AffineFastState.compose env58241 (packedSelected [1,2,4,5,9] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound58241 : packedSelected [1,2,4,5,9] rootPS < 2^1333 := by decide +kernel

def env58242 : List Nat := [2,4,8,16,17,64,128,205,216,156,131,16,89,16,200,219,64,10,156,200,65,64,17,139,209,16,131,16,17,10,5,152,204,153,64,217]

theorem envBound58242 : H12AffineFastState.Bounded env58242 := by
  intro p hp
  have h : env58242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58241_58242 : H12AffineEnvironment.transform 4 17 env58241 = env58242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env58241 == env58242) = true)

theorem identity58242 : scanCanonicalize (H12AffineFastState.compose env58242 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound58242 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58243 : List Nat := [2,4,8,16,17,64,8,69,80,20,11,16,89,16,64,83,64,10,20,64,65,64,17,3,89,16,11,16,17,10,5,16,68,17,64,81]

theorem envBound58243 : H12AffineFastState.Bounded env58243 := by
  intro p hp
  have h : env58243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58242_58243 : H12AffineEnvironment.transform 6 8 env58242 = env58243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env58242 == env58243) = true)

theorem identity58243 : scanCanonicalize (H12AffineFastState.compose env58243 (packedSelected [0,1] rootPS)) = affineNative (2^(3+1) ^^^ 8) := by decide +kernel

theorem selectedBound58243 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env58244 : List Nat := [2,4,8,8,9,64,8,69,72,12,11,8,65,8,64,75,64,10,12,64,65,64,9,3,65,8,11,8,9,10,5,8,68,9,64,73]

theorem envBound58244 : H12AffineFastState.Bounded env58244 := by
  intro p hp
  have h : env58244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58243_58244 : H12AffineEnvironment.transform 3 8 env58243 = env58244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 8 env58243 == env58244) = true)

theorem identity58244 : scanCanonicalize (H12AffineFastState.compose env58244 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 8) := by decide +kernel

theorem selectedBound58244 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58245 : List Nat := [2,4,8,8,9,8,8,13,0,12,11,8,9,8,8,3,8,10,12,8,9,8,9,3,9,8,11,8,9,10,5,8,12,9,8,1]

theorem envBound58245 : H12AffineFastState.Bounded env58245 := by
  intro p hp
  have h : env58245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58244_58245 : H12AffineEnvironment.transform 5 8 env58244 = env58245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 8 env58244 == env58245) = true)

theorem identity58245 : scanCanonicalize (H12AffineFastState.compose env58245 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58245 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58246 : List Nat := [2,4,3,3,2,3,3,6,0,7,0,3,2,3,3,3,3,1,7,3,2,3,2,3,2,3,0,3,2,1,5,3,7,2,3,1]

theorem envBound58246 : H12AffineFastState.Bounded env58246 := by
  intro p hp
  have h : env58246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58245_58246 : H12AffineEnvironment.transform 2 3 env58245 = env58246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58245 == env58246) = true)

theorem identity58246 : scanCanonicalize (H12AffineFastState.compose env58246 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58246 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58247 : List Nat := [0,4,1,1,0,1,1,4,0,5,0,1,0,1,1,1,1,1,5,1,0,1,0,1,0,1,0,1,0,1,5,1,5,0,1,1]

theorem envBound58247 : H12AffineFastState.Bounded env58247 := by
  intro p hp
  have h : env58247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58246_58247 : H12AffineEnvironment.transform 0 0 env58246 = env58247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58246 == env58247) = true)

def env58248 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136512,46480,144713,169103,26057,157000,103453,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58248 : H12AffineFastState.Bounded env58248 := by
  intro p hp
  have h : env58248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58228_58248 : H12AffineEnvironment.transform 17 87425 env58228 = env58248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58228 == env58248) = true)

theorem identity58248 : scanCanonicalize (H12AffineFastState.compose env58248 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 9713) := by decide +kernel

theorem selectedBound58248 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58249 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,9713,65536,131072,87425,1024,9713,136512,4193,144713,143742,26057,157000,78316,16384,131153,93514,200846,221575,257,69731,131072,18240]

theorem envBound58249 : H12AffineFastState.Bounded env58249 := by
  intro p hp
  have h : env58249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58248_58249 : H12AffineEnvironment.transform 14 9713 env58248 = env58249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9713 env58248 == env58249) = true)

def env58250 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,9713,65536,131072,69825,1024,9713,136512,4193,144713,143742,8329,139272,78316,1344,131153,75786,200846,206023,257,69731,131072,512]

theorem envBound58250 : H12AffineFastState.Bounded env58250 := by
  intro p hp
  have h : env58250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58249_58250 : H12AffineEnvironment.transform 13 1344 env58249 = env58250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58249 == env58250) = true)

theorem identity58250 : scanCanonicalize (H12AffineFastState.compose env58250 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound58250 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1296,8192,1344,9713,65536,131072,67025,1024,9713,131152,1393,139353,140398,8329,139272,75004,1344,131153,75786,198046,206023,257,66931,131072,512]

theorem envBound58251 : H12AffineFastState.Bounded env58251 := by
  intro p hp
  have h : env58251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58250_58251 : H12AffineEnvironment.transform 11 1296 env58250 = env58251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env58250 == env58251) = true)

def env58252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,65536,131072,69824,1024,9713,136512,4193,144713,143742,8328,139273,78316,1345,131153,75787,200846,206022,257,69731,131072,513]

theorem envBound58252 : H12AffineFastState.Bounded env58252 := by
  intro p hp
  have h : env58252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58249_58252 : H12AffineEnvironment.transform 13 1345 env58249 = env58252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58249 == env58252) = true)

theorem identity58252 : scanCanonicalize (H12AffineFastState.compose env58252 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 12654) := by decide +kernel

theorem selectedBound58252 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,12654,131072,8622,1024,9713,136512,4193,144713,143742,8328,139273,130,1345,131153,6501,139744,136616,257,8461,131072,513]

theorem envBound58253 : H12AffineFastState.Bounded env58253 := by
  intro p hp
  have h : env58253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58252_58253 : H12AffineEnvironment.transform 15 12654 env58252 = env58253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12654 env58252 == env58253) = true)

theorem identity58253 : scanCanonicalize (H12AffineFastState.compose env58253 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8217) := by decide +kernel

theorem selectedBound58253 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,9713,12654,8217,8622,1024,9713,13657,4193,5456,4455,8328,16,130,1345,8264,6501,505,13745,257,8461,8217,513]

theorem envBound58254 : H12AffineFastState.Bounded env58254 := by
  intro p hp
  have h : env58254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58253_58254 : H12AffineEnvironment.transform 16 8217 env58253 = env58254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8217 env58253 == env58254) = true)

theorem identity58254 : scanCanonicalize (H12AffineFastState.compose env58254 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 421) := by decide +kernel

theorem selectedBound58254 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,421,1345,1108,4299,444,11,1024,1108,5372,4193,5456,4455,301,16,130,1345,493,6501,505,5140,257,168,444,513]

theorem envBound58255 : H12AffineFastState.Bounded env58255 := by
  intro p hp
  have h : env58255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58254_58255 : H12AffineEnvironment.transform 12 421 env58254 = env58255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 421 env58254 == env58255) = true)

theorem identity58255 : scanCanonicalize (H12AffineFastState.compose env58255 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2635) := by decide +kernel

theorem selectedBound58255 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2635,421,1345,1108,2688,444,11,1024,1108,3767,2602,3867,2860,301,16,130,1345,493,814,505,3679,257,168,444,513]

theorem envBound58256 : H12AffineFastState.Bounded env58256 := by
  intro p hp
  have h : env58256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58255_58256 : H12AffineEnvironment.transform 11 2635 env58255 = env58256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2635 env58255 == env58256) = true)

theorem identity58256 : scanCanonicalize (H12AffineFastState.compose env58256 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1014) := by decide +kernel

theorem selectedBound58256 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58257 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1014,445,421,1345,1108,374,444,11,1024,1108,1345,476,1261,218,301,16,130,1345,493,814,505,1449,257,168,444,513]

theorem envBound58257 : H12AffineFastState.Bounded env58257 := by
  intro p hp
  have h : env58257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58256_58257 : H12AffineEnvironment.transform 10 1014 env58256 = env58257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1014 env58256 == env58257) = true)

theorem identity58257 : scanCanonicalize (H12AffineFastState.compose env58257 (packedSelected [1,4,5,9,10,13,20] rootPS)) = affineNative (2^(9+1) ^^^ 256) := by decide +kernel

theorem selectedBound58257 : packedSelected [1,4,5,9,10,13,20] rootPS < 2^1333 := by decide +kernel

def env58258 : List Nat := [2,4,8,16,32,64,128,256,512,256,1014,445,421,65,340,374,444,11,256,340,65,476,493,218,301,16,130,65,493,814,505,169,257,168,444,513]

theorem envBound58258 : H12AffineFastState.Bounded env58258 := by
  intro p hp
  have h : env58258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58257_58258 : H12AffineEnvironment.transform 9 256 env58257 = env58258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 256 env58257 == env58258) = true)

theorem identity58258 : scanCanonicalize (H12AffineFastState.compose env58258 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound58258 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58259 : List Nat := [2,4,8,16,32,64,128,256,216,256,302,445,421,65,340,374,444,11,256,340,65,476,493,218,301,16,130,65,493,502,505,169,257,168,444,217]

theorem envBound58259 : H12AffineFastState.Bounded env58259 := by
  intro p hp
  have h : env58259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58258_58259 : H12AffineEnvironment.transform 8 216 env58258 = env58259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env58258 == env58259) = true)

theorem identity58259 : scanCanonicalize (H12AffineFastState.compose env58259 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound58259 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env58260 : List Nat := [2,4,8,16,32,64,128,252,216,252,210,65,89,65,168,138,64,11,252,168,65,32,17,218,209,16,130,65,17,10,5,169,253,168,64,217]

theorem envBound58260 : H12AffineFastState.Bounded env58260 := by
  intro p hp
  have h : env58260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58259_58260 : H12AffineEnvironment.transform 7 252 env58259 = env58260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env58259 == env58260) = true)

theorem identity58260 : scanCanonicalize (H12AffineFastState.compose env58260 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 99) := by decide +kernel

theorem selectedBound58260 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58261 : List Nat := [2,4,8,16,32,64,99,31,59,31,49,65,89,65,75,105,64,11,31,75,65,32,17,57,50,16,97,65,17,10,5,74,30,75,64,58]

theorem envBound58261 : H12AffineFastState.Bounded env58261 := by
  intro p hp
  have h : env58261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58260_58261 : H12AffineEnvironment.transform 6 99 env58260 = env58261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 99 env58260 == env58261) = true)

theorem identity58261 : scanCanonicalize (H12AffineFastState.compose env58261 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound58261 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58262 : List Nat := [2,4,8,16,26,64,89,31,1,31,11,65,89,65,75,83,64,11,31,75,65,26,17,3,8,16,91,65,17,10,5,74,30,75,64,0]

theorem envBound58262 : H12AffineFastState.Bounded env58262 := by
  intro p hp
  have h : env58262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58261_58262 : H12AffineEnvironment.transform 4 26 env58261 = env58262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env58261 == env58262) = true)

theorem identity58262 : scanCanonicalize (H12AffineFastState.compose env58262 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 18) := by decide +kernel

theorem selectedBound58262 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58263 : List Nat := [2,4,8,16,26,18,11,31,1,31,11,19,11,19,25,1,18,11,31,25,19,26,17,3,8,16,9,19,17,10,5,24,30,25,18,0]

theorem envBound58263 : H12AffineFastState.Bounded env58263 := by
  intro p hp
  have h : env58263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58262_58263 : H12AffineEnvironment.transform 5 18 env58262 = env58263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 18 env58262 == env58263) = true)

theorem identity58263 : scanCanonicalize (H12AffineFastState.compose env58263 (packedSelected [2,4,5] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound58263 : packedSelected [2,4,5] rootPS < 2^1333 := by decide +kernel

def env58264 : List Nat := [2,4,8,9,3,11,11,6,1,6,11,10,11,10,0,1,11,11,6,0,10,3,8,3,8,9,9,10,8,10,5,1,7,0,11,0]

theorem envBound58264 : H12AffineFastState.Bounded env58264 := by
  intro p hp
  have h : env58264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58263_58264 : H12AffineEnvironment.transform 3 9 env58263 = env58264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env58263 == env58264) = true)

theorem identity58264 : scanCanonicalize (H12AffineFastState.compose env58264 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound58264 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env58265 : List Nat := [0,4,8,9,1,9,9,4,1,4,9,8,9,8,0,1,9,9,4,0,8,1,8,1,8,9,9,8,8,8,5,1,5,0,9,0]

theorem envBound58265 : H12AffineFastState.Bounded env58265 := by
  intro p hp
  have h : env58265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58264_58265 : H12AffineEnvironment.transform 0 0 env58264 = env58265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env58264 == env58265) = true)

theorem identity58265 : scanCanonicalize (H12AffineFastState.compose env58265 (packedSelected [2] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound58265 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env58266 : List Nat := [0,4,0,1,1,1,1,4,1,4,1,0,1,0,0,1,1,1,4,0,0,1,0,1,0,1,1,0,0,0,5,1,5,0,1,0]

theorem envBound58266 : H12AffineFastState.Bounded env58266 := by
  intro p hp
  have h : env58266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58265_58266 : H12AffineEnvironment.transform 2 0 env58265 = env58266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env58265 == env58266) = true)

def env58267 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136513,46481,144713,169103,26056,157000,311709,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58267 : H12AffineFastState.Bounded env58267 := by
  intro p hp
  have h : env58267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58227_58267 : H12AffineEnvironment.transform 20 136513 env58227 = env58267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136513 env58227 == env58267) = true)

def env58268 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136513,46481,144713,169103,26056,157000,103453,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58268 : H12AffineFastState.Bounded env58268 := by
  intro p hp
  have h : env58268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58267_58268 : H12AffineEnvironment.transform 17 87424 env58267 = env58268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58267 == env58268) = true)

theorem identity58268 : scanCanonicalize (H12AffineFastState.compose env58268 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 12512) := by decide +kernel

theorem selectedBound58268 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58269 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,12512,65536,131072,87424,1024,12512,136513,1393,144713,140399,26056,157000,75005,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58269 : H12AffineFastState.Bounded env58269 := by
  intro p hp
  have h : env58269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58268_58269 : H12AffineEnvironment.transform 14 12512 env58268 = env58269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 12512 env58268 == env58269) = true)

def env58270 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,65536,131072,69824,1024,12512,136513,1393,144713,140399,8328,139272,75005,1344,131153,75787,200846,206023,257,69730,131072,513]

theorem envBound58270 : H12AffineFastState.Bounded env58270 := by
  intro p hp
  have h : env58270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58269_58270 : H12AffineEnvironment.transform 13 1344 env58269 = env58270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58269 == env58270) = true)

theorem identity58270 : scanCanonicalize (H12AffineFastState.compose env58270 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound58270 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58271 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,9342,131072,13502,1024,12512,136513,1393,144713,140399,8328,139272,131,1344,131153,3189,144624,131257,257,13340,131072,513]

theorem envBound58271 : H12AffineFastState.Bounded env58271 := by
  intro p hp
  have h : env58271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58270_58271 : H12AffineEnvironment.transform 15 9342 env58270 = env58271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env58270 == env58271) = true)

theorem identity58271 : scanCanonicalize (H12AffineFastState.compose env58271 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound58271 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,9342,8216,13502,1024,12512,13657,1393,5457,1143,8328,16,131,1344,8265,3189,5352,8353,257,13340,8216,513]

theorem envBound58272 : H12AffineFastState.Bounded env58272 := by
  intro p hp
  have h : env58272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58271_58272 : H12AffineEnvironment.transform 16 8216 env58271 = env58272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env58271 == env58272) = true)

theorem identity58272 : scanCanonicalize (H12AffineFastState.compose env58272 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound58272 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1108,4298,5292,10,1024,1108,493,1393,5457,1143,5180,16,131,1344,5373,3189,5352,5141,257,168,5292,513]

theorem envBound58273 : H12AffineFastState.Bounded env58273 := by
  intro p hp
  have h : env58273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58272_58273 : H12AffineEnvironment.transform 12 5300 env58272 = env58273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env58272 == env58273) = true)

theorem identity58273 : scanCanonicalize (H12AffineFastState.compose env58273 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound58273 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,3838,1344,1108,2688,3814,10,1024,1108,493,1393,3867,1143,3702,16,131,1344,3767,3189,3746,3679,257,168,3814,513]

theorem envBound58274 : H12AffineFastState.Bounded env58274 := by
  intro p hp
  have h : env58274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58273_58274 : H12AffineEnvironment.transform 11 2634 env58273 = env58274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env58273 == env58274) = true)

theorem identity58274 : scanCanonicalize (H12AffineFastState.compose env58274 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound58274 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58275 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,2587,3759,1297,1029,2688,3767,10,1024,1029,444,1312,3867,1062,3623,16,131,1297,3767,3108,3746,3598,257,168,3767,513]

theorem envBound58275 : H12AffineFastState.Bounded env58275 := by
  intro p hp
  have h : env58275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58274_58275 : H12AffineEnvironment.transform 5 17 env58274 = env58275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env58274 == env58275) = true)

theorem identity58275 : scanCanonicalize (H12AffineFastState.compose env58275 (packedSelected [0,7,20] rootPS)) = affineNative (2^(10+1) ^^^ 1702) := by decide +kernel

theorem selectedBound58275 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env58276 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1702,1213,9,1297,1029,1062,17,10,1024,1029,444,1312,445,1062,129,16,131,1297,17,642,4,168,257,168,17,513]

theorem envBound58276 : H12AffineFastState.Bounded env58276 := by
  intro p hp
  have h : env58276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58275_58276 : H12AffineEnvironment.transform 10 1702 env58275 = env58276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1702 env58275 == env58276) = true)

theorem identity58276 : scanCanonicalize (H12AffineFastState.compose env58276 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound58276 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58277 : List Nat := [2,4,8,16,32,17,128,256,512,549,131,664,9,820,544,515,17,10,549,544,444,773,445,515,129,16,131,820,17,642,4,168,257,168,17,513]

theorem envBound58277 : H12AffineFastState.Bounded env58277 := by
  intro p hp
  have h : env58277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58276_58277 : H12AffineEnvironment.transform 9 549 env58276 = env58277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env58276 == env58277) = true)

theorem identity58277 : scanCanonicalize (H12AffineFastState.compose env58277 (packedSelected [0,1,2,5,7] rootPS)) = affineNative (2^(8+1) ^^^ 397) := by decide +kernel

theorem selectedBound58277 : packedSelected [0,1,2,5,7] rootPS < 2^1333 := by decide +kernel

def env58278 : List Nat := [2,4,8,16,32,17,128,256,397,424,131,277,9,185,429,398,17,10,424,429,444,136,445,398,129,16,131,185,17,271,4,168,257,168,17,396]

theorem envBound58278 : H12AffineFastState.Bounded env58278 := by
  intro p hp
  have h : env58278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58277_58278 : H12AffineEnvironment.transform 8 397 env58277 = env58278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 397 env58277 == env58278) = true)

theorem identity58278 : scanCanonicalize (H12AffineFastState.compose env58278 (packedSelected [1,2,3,4,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound58278 : packedSelected [1,2,3,4,9,10] rootPS < 2^1333 := by decide +kernel

def env58279 : List Nat := [2,4,8,16,32,17,128,4,137,172,131,17,9,185,169,138,17,10,172,169,184,136,185,138,129,16,131,185,17,11,4,168,5,168,17,136]

theorem envBound58279 : H12AffineFastState.Bounded env58279 := by
  intro p hp
  have h : env58279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58278_58279 : H12AffineEnvironment.transform 7 4 env58278 = env58279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env58278 == env58279) = true)

theorem identity58279 : scanCanonicalize (H12AffineFastState.compose env58279 (packedSelected [1,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound58279 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env58280 : List Nat := [2,4,8,16,1,17,128,4,137,141,131,17,9,152,136,138,17,10,141,136,153,136,152,138,129,16,131,152,17,11,4,137,5,137,17,136]

theorem envBound58280 : H12AffineFastState.Bounded env58280 := by
  intro p hp
  have h : env58280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58279_58280 : H12AffineEnvironment.transform 4 1 env58279 = env58280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env58279 == env58280) = true)

theorem identity58280 : scanCanonicalize (H12AffineFastState.compose env58280 (packedSelected [0,3] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58280 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env58281 : List Nat := [1,4,8,16,1,17,128,4,137,141,128,17,9,152,136,137,17,9,141,136,153,136,152,137,129,16,128,152,17,8,4,137,5,137,17,136]

theorem envBound58281 : H12AffineFastState.Bounded env58281 := by
  intro p hp
  have h : env58281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58280_58281 : H12AffineEnvironment.transform 0 1 env58280 = env58281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58280 == env58281) = true)

theorem identity58281 : scanCanonicalize (H12AffineFastState.compose env58281 (packedSelected [0,4] rootPS)) = affineNative (2^(6+1) ^^^ 16) := by decide +kernel

theorem selectedBound58281 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env58282 : List Nat := [1,4,8,16,1,17,16,4,25,29,16,17,9,8,24,25,17,9,29,24,9,24,8,25,17,16,16,8,17,8,4,25,5,25,17,24]

theorem envBound58282 : H12AffineFastState.Bounded env58282 := by
  intro p hp
  have h : env58282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58281_58282 : H12AffineEnvironment.transform 6 16 env58281 = env58282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 16 env58281 == env58282) = true)

theorem identity58282 : scanCanonicalize (H12AffineFastState.compose env58282 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound58282 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58283 : List Nat := [1,4,8,0,1,1,0,4,9,13,0,1,9,8,8,9,1,9,13,8,9,8,8,9,1,0,0,8,1,8,4,9,5,9,1,8]

theorem envBound58283 : H12AffineFastState.Bounded env58283 := by
  intro p hp
  have h : env58283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58282_58283 : H12AffineEnvironment.transform 3 0 env58282 = env58283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env58282 == env58283) = true)

def env58284 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12512,65536,131072,69825,1024,12512,136513,1393,144713,140399,8329,139273,75005,1345,131153,75786,200846,206022,257,69730,131072,512]

theorem envBound58284 : H12AffineFastState.Bounded env58284 := by
  intro p hp
  have h : env58284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58269_58284 : H12AffineEnvironment.transform 13 1345 env58269 = env58284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58269 == env58284) = true)

theorem identity58284 : scanCanonicalize (H12AffineFastState.compose env58284 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58284 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58285 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,9713,65536,131072,67024,1024,9713,131152,1393,139352,140399,8329,139273,75005,1345,131153,75786,198047,206022,257,66931,131072,512]

theorem envBound58285 : H12AffineFastState.Bounded env58285 := by
  intro p hp
  have h : env58285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58284_58285 : H12AffineEnvironment.transform 11 1297 env58284 = env58285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58284 == env58285) = true)

def env58286 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87425,1024,32768,136513,46481,144713,169103,26056,157000,103452,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58286 : H12AffineFastState.Bounded env58286 := by
  intro p hp
  have h : env58286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58267_58286 : H12AffineEnvironment.transform 17 87425 env58267 = env58286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87425 env58267 == env58286) = true)

theorem identity58286 : scanCanonicalize (H12AffineFastState.compose env58286 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 30112) := by decide +kernel

theorem selectedBound58286 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58287 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,30112,65536,131072,87425,1024,30112,136513,16433,144713,155951,26056,157000,90556,16384,131153,93515,200846,221575,257,69730,131072,18241]

theorem envBound58287 : H12AffineFastState.Bounded env58287 := by
  intro p hp
  have h : env58287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58286_58287 : H12AffineEnvironment.transform 14 30112 env58286 = env58287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30112 env58286 == env58287) = true)

def env58288 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,65536,131072,69825,1024,12512,136513,1393,144713,140399,8328,139272,75004,1344,131153,75787,200846,206023,257,69730,131072,513]

theorem envBound58288 : H12AffineFastState.Bounded env58288 := by
  intro p hp
  have h : env58288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58287_58288 : H12AffineEnvironment.transform 13 1344 env58287 = env58288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58287 == env58288) = true)

theorem identity58288 : scanCanonicalize (H12AffineFastState.compose env58288 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 9342) := by decide +kernel

theorem selectedBound58288 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,9342,131072,13503,1024,12512,136513,1393,144713,140399,8328,139272,130,1344,131153,3189,144624,131257,257,13340,131072,513]

theorem envBound58289 : H12AffineFastState.Bounded env58289 := by
  intro p hp
  have h : env58289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58288_58289 : H12AffineEnvironment.transform 15 9342 env58288 = env58289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 9342 env58288 == env58289) = true)

theorem identity58289 : scanCanonicalize (H12AffineFastState.compose env58289 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound58289 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,12512,9342,8216,13503,1024,12512,13657,1393,5457,1143,8328,16,130,1344,8265,3189,5352,8353,257,13340,8216,513]

theorem envBound58290 : H12AffineFastState.Bounded env58290 := by
  intro p hp
  have h : env58290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58289_58290 : H12AffineEnvironment.transform 16 8216 env58289 = env58290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env58289 == env58290) = true)

theorem identity58290 : scanCanonicalize (H12AffineFastState.compose env58290 (packedSelected [25] rootPS)) = affineNative (2^(12+1) ^^^ 5300) := by decide +kernel

theorem selectedBound58290 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

def env58291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,5300,1344,1108,4298,5292,11,1024,1108,493,1393,5457,1143,5180,16,130,1344,5373,3189,5352,5141,257,168,5292,513]

theorem envBound58291 : H12AffineFastState.Bounded env58291 := by
  intro p hp
  have h : env58291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58290_58291 : H12AffineEnvironment.transform 12 5300 env58290 = env58291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5300 env58290 == env58291) = true)

theorem identity58291 : scanCanonicalize (H12AffineFastState.compose env58291 (packedSelected [0,3,5,7,10,12,13,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 2634) := by decide +kernel

theorem selectedBound58291 : packedSelected [0,3,5,7,10,12,13,15,16] rootPS < 2^1333 := by decide +kernel

def env58292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2634,3838,1344,1108,2688,3814,11,1024,1108,493,1393,3867,1143,3702,16,130,1344,3767,3189,3746,3679,257,168,3814,513]

theorem envBound58292 : H12AffineFastState.Bounded env58292 := by
  intro p hp
  have h : env58292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58291_58292 : H12AffineEnvironment.transform 11 2634 env58291 = env58292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2634 env58291 == env58292) = true)

theorem identity58292 : scanCanonicalize (H12AffineFastState.compose env58292 (packedSelected [1,3,12,15] rootPS)) = affineNative (2^(10+1) ^^^ 1802) := by decide +kernel

theorem selectedBound58292 : packedSelected [1,3,12,15] rootPS < 2^1333 := by decide +kernel

def env58293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1802,1344,500,1344,1108,1418,492,11,1024,1108,493,1393,17,1143,380,16,130,1344,445,895,424,341,257,168,492,513]

theorem envBound58293 : H12AffineFastState.Bounded env58293 := by
  intro p hp
  have h : env58293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58292_58293 : H12AffineEnvironment.transform 10 1802 env58292 = env58293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1802 env58292 == env58293) = true)

theorem identity58293 : scanCanonicalize (H12AffineFastState.compose env58293 (packedSelected [0,7,20] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound58293 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env58294 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1783,1213,9,1213,1108,1143,17,11,1024,1108,16,1164,17,1143,129,16,130,1213,64,642,85,168,252,168,17,513]

theorem envBound58294 : H12AffineFastState.Bounded env58294 := by
  intro p hp
  have h : env58294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58293_58294 : H12AffineEnvironment.transform 7 253 env58293 = env58294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env58293 == env58294) = true)

theorem identity58294 : scanCanonicalize (H12AffineFastState.compose env58294 (packedSelected [0,1,3,4,7,9,13] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound58294 : packedSelected [0,1,3,4,7,9,13] rootPS < 2^1333 := by decide +kernel

def env58295 : List Nat := [2,4,8,16,32,64,128,253,512,549,210,664,9,664,625,594,17,11,549,625,16,681,17,594,129,16,130,664,64,642,85,168,252,168,17,513]

theorem envBound58295 : H12AffineFastState.Bounded env58295 := by
  intro p hp
  have h : env58295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58294_58295 : H12AffineEnvironment.transform 9 549 env58294 = env58295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env58294 == env58295) = true)

theorem identity58295 : scanCanonicalize (H12AffineFastState.compose env58295 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(8+1) ^^^ 137) := by decide +kernel

theorem selectedBound58295 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env58296 : List Nat := [2,4,8,16,32,64,128,253,137,172,210,17,9,17,248,219,17,11,172,248,16,32,17,219,129,16,130,17,64,11,85,168,252,168,17,136]

theorem envBound58296 : H12AffineFastState.Bounded env58296 := by
  intro p hp
  have h : env58296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58295_58296 : H12AffineEnvironment.transform 8 137 env58295 = env58296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 137 env58295 == env58296) = true)

theorem identity58296 : scanCanonicalize (H12AffineFastState.compose env58296 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound58296 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env58297 : List Nat := [2,4,8,16,32,64,9,116,0,37,91,17,9,17,113,82,17,11,37,113,16,32,17,82,8,16,11,17,64,11,85,33,117,33,17,1]

theorem envBound58297 : H12AffineFastState.Bounded env58297 := by
  intro p hp
  have h : env58297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58296_58297 : H12AffineEnvironment.transform 6 9 env58296 = env58297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env58296 == env58297) = true)

theorem identity58297 : scanCanonicalize (H12AffineFastState.compose env58297 (packedSelected [0,1,2] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound58297 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env58298 : List Nat := [2,4,8,16,3,64,9,87,0,6,91,17,9,17,82,82,17,11,6,82,16,3,17,82,8,16,11,17,64,11,85,2,86,2,17,1]

theorem envBound58298 : H12AffineFastState.Bounded env58298 := by
  intro p hp
  have h : env58298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58297_58298 : H12AffineEnvironment.transform 4 3 env58297 = env58298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env58297 == env58298) = true)

theorem identity58298 : scanCanonicalize (H12AffineFastState.compose env58298 (packedSelected [1,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound58298 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env58299 : List Nat := [2,4,8,16,3,10,9,29,0,6,17,17,9,17,24,24,17,11,6,24,16,3,17,24,8,16,11,17,10,11,31,2,28,2,17,1]

theorem envBound58299 : H12AffineFastState.Bounded env58299 := by
  intro p hp
  have h : env58299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58298_58299 : H12AffineEnvironment.transform 5 10 env58298 = env58299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env58298 == env58299) = true)

theorem identity58299 : scanCanonicalize (H12AffineFastState.compose env58299 (packedSelected [0,1,4] rootPS)) = affineNative (2^(3+1) ^^^ 9) := by decide +kernel

theorem selectedBound58299 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env58300 : List Nat := [2,4,8,9,3,10,9,4,0,6,8,8,9,8,1,1,8,11,6,1,9,3,8,1,8,9,11,8,10,11,6,2,5,2,8,1]

theorem envBound58300 : H12AffineFastState.Bounded env58300 := by
  intro p hp
  have h : env58300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58299_58300 : H12AffineEnvironment.transform 3 9 env58299 = env58300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 9 env58299 == env58300) = true)

theorem identity58300 : scanCanonicalize (H12AffineFastState.compose env58300 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound58300 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env58301 : List Nat := [2,4,3,2,3,1,2,4,0,6,3,3,2,3,1,1,3,0,6,1,2,3,3,1,3,2,0,3,1,0,6,2,5,2,3,1]

theorem envBound58301 : H12AffineFastState.Bounded env58301 := by
  intro p hp
  have h : env58301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58300_58301 : H12AffineEnvironment.transform 2 3 env58300 = env58301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env58300 == env58301) = true)

theorem identity58301 : scanCanonicalize (H12AffineFastState.compose env58301 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound58301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env58302 : List Nat := [1,4,0,1,0,1,1,4,0,5,0,0,1,0,1,1,0,0,5,1,1,0,0,1,0,1,0,0,1,0,5,1,5,1,0,1]

theorem envBound58302 : H12AffineFastState.Bounded env58302 := by
  intro p hp
  have h : env58302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58301_58302 : H12AffineEnvironment.transform 0 1 env58301 = env58302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env58301 == env58302) = true)

def env58303 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1345,12513,65536,131072,69824,1024,12513,136513,1392,144713,140398,8329,139273,75005,1345,131153,75786,200846,206022,257,69730,131072,512]

theorem envBound58303 : H12AffineFastState.Bounded env58303 := by
  intro p hp
  have h : env58303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58287_58303 : H12AffineEnvironment.transform 13 1345 env58287 = env58303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1345 env58287 == env58303) = true)

theorem identity58303 : scanCanonicalize (H12AffineFastState.compose env58303 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound58303 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58304 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1297,8192,1345,9712,65536,131072,67025,1024,9712,131152,1392,139352,140398,8329,139273,75005,1345,131153,75786,198047,206022,257,66931,131072,512]

theorem envBound58304 : H12AffineFastState.Bounded env58304 := by
  intro p hp
  have h : env58304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58303_58304 : H12AffineEnvironment.transform 11 1297 env58303 = env58304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env58303 == env58304) = true)

def env58305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,2097152,2269393,144712,169102,2257032,157001,2544860,16384,131153,2324491,200847,221575,257,2295075,131072,2249217]

theorem envBound58305 : H12AffineFastState.Bounded env58305 := by
  intro p hp
  have h : env58305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58226_58305 : H12AffineEnvironment.transform 21 2269393 env58226 = env58305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2269393 env58226 == env58305) = true)

def env58306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32768,136512,46481,144712,169102,26056,157001,311708,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound58306 : H12AffineFastState.Bounded env58306 := by
  intro p hp
  have h : env58306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58305_58306 : H12AffineEnvironment.transform 20 136512 env58305 = env58306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 136512 env58305 == env58306) = true)

def env58307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,87424,1024,32768,136512,46481,144712,169102,26056,157001,103452,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound58307 : H12AffineFastState.Bounded env58307 := by
  intro p hp
  have h : env58307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58306_58307 : H12AffineEnvironment.transform 17 87424 env58306 = env58307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 87424 env58306 == env58307) = true)

theorem identity58307 : scanCanonicalize (H12AffineFastState.compose env58307 (packedSelected [6] rootPS)) = affineNative (2^(14+1) ^^^ 20729) := by decide +kernel

theorem selectedBound58307 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env58308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,20729,65536,131072,87424,1024,20729,136512,25960,144712,148599,26056,157001,83173,16384,131153,93515,200847,221575,257,69731,131072,18241]

theorem envBound58308 : H12AffineFastState.Bounded env58308 := by
  intro p hp
  have h : env58308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58307_58308 : H12AffineEnvironment.transform 14 20729 env58307 = env58308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20729 env58307 == env58308) = true)

def env58309 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5561,65536,131072,69824,1024,5561,136512,8232,144712,131383,8328,139273,65957,1344,131153,75787,200847,206023,257,69731,131072,513]

theorem envBound58309 : H12AffineFastState.Bounded env58309 := by
  intro p hp
  have h : env58309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58308_58309 : H12AffineEnvironment.transform 13 1344 env58308 = env58309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1344 env58308 == env58309) = true)

theorem identity58309 : scanCanonicalize (H12AffineFastState.compose env58309 (packedSelected [1,3,4,5,8,9,10,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 294) := by decide +kernel

theorem selectedBound58309 : packedSelected [1,3,4,5,8,9,10,16,19] rootPS < 2^1333 := by decide +kernel

def env58310 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5561,294,131072,4582,1024,5561,136512,8232,144712,131383,8328,139273,131,1344,131153,10541,135593,140769,257,4421,131072,513]

theorem envBound58310 : H12AffineFastState.Bounded env58310 := by
  intro p hp
  have h : env58310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58309_58310 : H12AffineEnvironment.transform 15 294 env58309 = env58310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 294 env58309 == env58310) = true)

theorem identity58310 : scanCanonicalize (H12AffineFastState.compose env58310 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 8216) := by decide +kernel

theorem selectedBound58310 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env58311 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,1344,5561,294,8216,4582,1024,5561,13656,8232,5456,8495,8328,17,131,1344,8265,10541,12721,1529,257,4421,8216,513]

theorem envBound58311 : H12AffineFastState.Bounded env58311 := by
  intro p hp
  have h : env58311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans58310_58311 : H12AffineEnvironment.transform 16 8216 env58310 = env58311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 8216 env58310 == env58311) = true)

theorem identity58311 : scanCanonicalize (H12AffineFastState.compose env58311 (packedSelected [25] rootPS)) = affineNative (2^(11+1) ^^^ 492) := by decide +kernel

theorem selectedBound58311 : packedSelected [25] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1