import H12CloudChart1Data152

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound38794 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38795 : List Nat := [2,4,8,0,4,1,8,1,5,1,5,0,12,0,0,6,1,4,0,1,0,4,0,3,12,1,4,1,0,5,4,5,0,5,1,5]

theorem envBound38795 : H12AffineFastState.Bounded env38795 := by
  intro p hp
  have h : env38795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38794_38795 : H12AffineEnvironment.transform 4 4 env38794 = env38795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env38794 == env38795) = true)

theorem identity38795 : scanCanonicalize (H12AffineFastState.compose env38795 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38795 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env38796 : List Nat := [2,1,8,0,1,1,8,1,0,1,0,0,9,0,0,3,1,1,0,1,0,1,0,3,9,1,1,1,0,0,1,0,0,0,1,0]

theorem envBound38796 : H12AffineFastState.Bounded env38796 := by
  intro p hp
  have h : env38796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38795_38796 : H12AffineEnvironment.transform 1 1 env38795 = env38796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38795 == env38796) = true)

def env38797 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,131072,149860,1025,29788,160012,156012,155997,95497,8193,64,2049,160860,17664,138340,156697,33,257,21793,16464,213831]

theorem envBound38797 : H12AffineFastState.Bounded env38797 := by
  intro p hp
  have h : env38797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38782_38797 : H12AffineEnvironment.transform 6 9 env38782 = env38797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38782 == env38797) = true)

theorem identity38797 : scanCanonicalize (H12AffineFastState.compose env38797 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound38797 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38798 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,65536,13388,32040,1025,29788,17728,21792,21777,95497,8193,64,2049,16400,17664,10280,20565,33,257,21793,16464,96011]

theorem envBound38798 : H12AffineFastState.Bounded env38798 := by
  intro p hp
  have h : env38798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38797_38798 : H12AffineEnvironment.transform 16 13388 env38797 = env38798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env38797 == env38798) = true)

theorem identity38798 : scanCanonicalize (H12AffineFastState.compose env38798 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound38798 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env38799 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8312,65536,13388,10509,1025,8313,4453,261,308,74028,8193,64,2049,5173,4389,10280,1136,33,257,260,5237,74542]

theorem envBound38799 : H12AffineFastState.Bounded env38799 := by
  intro p hp
  have h : env38799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38798_38799 : H12AffineEnvironment.transform 13 5157 env38798 = env38799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env38798 == env38799) = true)

theorem identity38799 : scanCanonicalize (H12AffineFastState.compose env38799 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound38799 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env38800 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5157,8312,8495,13388,10509,1025,8313,4453,261,308,3,8193,64,2049,5173,4389,10280,1136,33,257,260,5237,513]

theorem envBound38800 : H12AffineFastState.Bounded env38800 := by
  intro p hp
  have h : env38800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38799_38800 : H12AffineEnvironment.transform 15 8495 env38799 = env38800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env38799 == env38800) = true)

theorem identity38800 : scanCanonicalize (H12AffineFastState.compose env38800 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38800 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env38801 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,8192,4405,8312,8495,12636,10509,273,8313,4453,261,308,3,8193,64,2049,4389,4389,10280,352,33,257,260,4453,513]

theorem envBound38801 : H12AffineFastState.Bounded env38801 := by
  intro p hp
  have h : env38801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38800_38801 : H12AffineEnvironment.transform 9 272 env38800 = env38801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38800 == env38801) = true)

theorem identity38801 : scanCanonicalize (H12AffineFastState.compose env38801 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38801 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38802 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,348,4405,292,115,4096,2129,273,293,4453,261,308,3,349,64,2049,4389,4389,2420,352,33,257,260,4453,513]

theorem envBound38802 : H12AffineFastState.Bounded env38802 := by
  intro p hp
  have h : env38802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38801_38802 : H12AffineEnvironment.transform 12 348 env38801 = env38802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38801 == env38802) = true)

theorem identity38802 : scanCanonicalize (H12AffineFastState.compose env38802 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38802 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38803 : List Nat := [2,4,8,16,32,64,9,36,512,52,2048,4096,120,4113,0,115,4096,2129,53,1,4161,33,16,3,121,64,2049,4097,4097,2128,68,33,37,32,4161,513]

theorem envBound38803 : H12AffineFastState.Bounded env38803 := by
  intro p hp
  have h : env38803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38802_38803 : H12AffineEnvironment.transform 7 36 env38802 = env38803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38802 == env38803) = true)

theorem identity38803 : scanCanonicalize (H12AffineFastState.compose env38803 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38803 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38804 : List Nat := [2,4,8,16,32,16,9,36,512,52,2048,4096,40,4113,0,35,4096,2049,53,1,4113,33,16,3,41,16,2049,4097,4097,2048,20,33,37,32,4113,513]

theorem envBound38804 : H12AffineFastState.Bounded env38804 := by
  intro p hp
  have h : env38804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38803_38804 : H12AffineEnvironment.transform 5 16 env38803 = env38804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38803 == env38804) = true)

theorem identity38804 : scanCanonicalize (H12AffineFastState.compose env38804 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 529) := by decide +kernel

theorem selectedBound38804 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38805 : List Nat := [2,4,8,16,32,16,9,36,512,52,529,4096,40,4113,0,35,4096,528,53,1,4113,33,16,3,41,16,528,4097,4097,529,20,33,37,32,4113,513]

theorem envBound38805 : H12AffineFastState.Bounded env38805 := by
  intro p hp
  have h : env38805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38804_38805 : H12AffineEnvironment.transform 10 529 env38804 = env38805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 529 env38804 == env38805) = true)

theorem identity38805 : scanCanonicalize (H12AffineFastState.compose env38805 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound38805 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38806 : List Nat := [2,4,8,16,32,16,9,36,512,52,529,570,40,555,0,35,570,528,53,1,555,33,16,3,41,16,528,571,571,529,20,33,37,32,555,513]

theorem envBound38806 : H12AffineFastState.Bounded env38806 := by
  intro p hp
  have h : env38806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38805_38806 : H12AffineEnvironment.transform 11 570 env38805 = env38806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env38805 == env38806) = true)

theorem identity38806 : scanCanonicalize (H12AffineFastState.compose env38806 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound38806 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38807 : List Nat := [2,4,8,16,32,16,9,36,17,52,0,43,40,58,0,35,43,1,53,1,58,33,16,3,41,16,1,42,42,0,20,33,37,32,58,16]

theorem envBound38807 : H12AffineFastState.Bounded env38807 := by
  intro p hp
  have h : env38807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38806_38807 : H12AffineEnvironment.transform 8 17 env38806 = env38807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env38806 == env38807) = true)

theorem identity38807 : scanCanonicalize (H12AffineFastState.compose env38807 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound38807 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env38808 : List Nat := [2,4,8,16,27,16,9,31,17,15,0,16,19,1,0,24,16,1,14,1,1,26,16,3,18,16,1,17,17,0,20,26,30,27,1,16]

theorem envBound38808 : H12AffineFastState.Bounded env38808 := by
  intro p hp
  have h : env38808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38807_38808 : H12AffineEnvironment.transform 4 27 env38807 = env38808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env38807 == env38808) = true)

def env38809 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,8388608,8642688,8328,64,4464768,8393984,8528988,8830976,156816,12645452,257,21792,46213,213831]

theorem envBound38809 : H12AffineFastState.Bounded env38809 := by
  intro p hp
  have h : env38809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38669_38809 : H12AffineEnvironment.transform 20 160013 env38669 = env38809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160013 env38669 == env38809) = true)

def env38810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169352,95496,8328,64,4464768,163976,45524,284040,156816,4350404,257,21792,46213,213831]

theorem envBound38810 : H12AffineFastState.Bounded env38810 := by
  intro p hp
  have h : env38810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38809_38810 : H12AffineEnvironment.transform 22 169352 env38809 = env38810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169352 env38809 == env38810) = true)

def env38811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169352,95496,8328,64,2048,163976,45524,284040,156816,411972,257,21792,46213,213831]

theorem envBound38811 : H12AffineFastState.Bounded env38811 := by
  intro p hp
  have h : env38811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38810_38811 : H12AffineEnvironment.transform 21 272512 env38810 = env38811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38810 == env38811) = true)

theorem identity38811 : scanCanonicalize (H12AffineFastState.compose env38811 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38811 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272512,169352,21762,8328,64,2048,163976,45524,284040,156816,411972,257,21792,46213,156493]

theorem envBound38812 : H12AffineFastState.Bounded env38812 := by
  intro p hp
  have h : env38812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38811_38812 : H12AffineEnvironment.transform 15 8202 env38811 = env38812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38811 == env38812) = true)

def env38813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272392,169216,21762,8192,64,2048,163840,45404,283904,156696,411972,257,21792,46093,156493]

theorem envBound38813 : H12AffineFastState.Bounded env38813 := by
  intro p hp
  have h : env38813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38812_38813 : H12AffineEnvironment.transform 6 8 env38812 = env38813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38812 == env38813) = true)

theorem identity38813 : scanCanonicalize (H12AffineFastState.compose env38813 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 171108) := by decide +kernel

theorem selectedBound38813 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env38814 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,171108,1025,32769,160013,177260,169216,21762,8192,64,2048,163840,45404,182628,156696,54560,257,21792,46093,156493]

theorem envBound38814 : H12AffineFastState.Bounded env38814 := by
  intro p hp
  have h : env38814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38813_38814 : H12AffineEnvironment.transform 17 171108 env38813 = env38814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171108 env38813 == env38814) = true)

theorem identity38814 : scanCanonicalize (H12AffineFastState.compose env38814 (packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS)) = affineNative (2^(16+1) ^^^ 49169) := by decide +kernel

theorem selectedBound38814 : packedSelected [1,3,4,5,7,8,9,10,19,27] rootPS < 2^1333 := by decide +kernel

def env38815 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,23669,1025,32769,45340,29821,21777,21762,8192,64,2048,16401,45404,2421,41993,54560,257,21792,46093,41820]

theorem envBound38815 : H12AffineFastState.Bounded env38815 := by
  intro p hp
  have h : env38815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38814_38815 : H12AffineEnvironment.transform 16 49169 env38814 = env38815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env38814 == env38815) = true)

theorem identity38815 : scanCanonicalize (H12AffineFastState.compose env38815 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound38815 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env38816 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,24908,23669,1025,8540,4161,29821,21777,21762,8192,64,2048,16401,4097,2421,1364,29821,257,21792,5456,513]

theorem envBound38816 : H12AffineFastState.Bounded env38816 := by
  intro p hp
  have h : env38816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38815_38816 : H12AffineEnvironment.transform 14 8541 env38815 = env38816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env38815 == env38816) = true)

def env38817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1025,32769,160013,272393,169217,21762,8193,64,2048,163841,45405,283905,156697,411972,257,21792,46092,156493]

theorem envBound38817 : H12AffineFastState.Bounded env38817 := by
  intro p hp
  have h : env38817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38812_38817 : H12AffineEnvironment.transform 6 9 env38812 = env38817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38812 == env38817) = true)

theorem identity38817 : scanCanonicalize (H12AffineFastState.compose env38817 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(16+1) ^^^ 46392) := by decide +kernel

theorem selectedBound38817 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env38818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46392,262144,1025,32769,50229,272393,8249,21762,8193,64,2048,13625,45405,283905,53537,326780,257,21792,46092,54901]

theorem envBound38818 : H12AffineFastState.Bounded env38818 := by
  intro p hp
  have h : env38818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38817_38818 : H12AffineEnvironment.transform 16 46392 env38817 = env38818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46392 env38817 == env38818) = true)

theorem identity38818 : scanCanonicalize (H12AffineFastState.compose env38818 (packedSelected [0,3,4,10,14,20,22,24,26,27] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound38818 : packedSelected [0,3,4,10,14,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env38819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,46392,32041,1025,32769,50229,21792,8249,21762,8193,64,2048,13625,45405,10280,53537,33109,257,21792,46092,54901]

theorem envBound38819 : H12AffineFastState.Bounded env38819 := by
  intro p hp
  have h : env38819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38818_38819 : H12AffineEnvironment.transform 17 32041 env38818 = env38819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env38818 == env38819) = true)

theorem identity38819 : scanCanonicalize (H12AffineFastState.compose env38819 (packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38819 : packedSelected [0,1,4,6,7,8,9,12,15,17,19] rootPS < 2^1333 := by decide +kernel

def env38820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,8202,46392,10281,1025,32769,37173,32,8249,2,8193,64,2048,13625,45405,10280,33825,33109,257,32,46092,33653]

theorem envBound38820 : H12AffineFastState.Bounded env38820 := by
  intro p hp
  have h : env38820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38819_38820 : H12AffineEnvironment.transform 13 5376 env38819 = env38820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38819 == env38820) = true)

theorem identity38820 : scanCanonicalize (H12AffineFastState.compose env38820 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 9528) := by decide +kernel

theorem selectedBound38820 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,9528,8202,4096,10281,1025,9529,13325,32,8249,2,8193,64,2048,13625,5221,10280,8473,9325,257,32,4404,9805]

theorem envBound38821 : H12AffineFastState.Bounded env38821 := by
  intro p hp
  have h : env38821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38820_38821 : H12AffineEnvironment.transform 14 9528 env38820 = env38821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9528 env38820 == env38821) = true)

theorem identity38821 : scanCanonicalize (H12AffineFastState.compose env38821 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound38821 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env38822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,1336,5376,0,1330,4096,3345,1025,1,4405,32,1281,2,1337,64,2048,4097,5221,3344,1057,341,257,32,4404,885]

theorem envBound38822 : H12AffineFastState.Bounded env38822 := by
  intro p hp
  have h : env38822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38821_38822 : H12AffineEnvironment.transform 12 1336 env38821 = env38822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env38821 == env38822) = true)

theorem identity38822 : scanCanonicalize (H12AffineFastState.compose env38822 (packedSelected [0,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound38822 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env38823 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3188,1336,2420,0,1330,3188,3345,1025,1,3393,32,1281,2,1337,64,2048,3189,2065,3344,1057,341,257,32,3392,885]

theorem envBound38823 : H12AffineFastState.Bounded env38823 := by
  intro p hp
  have h : env38823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38822_38823 : H12AffineEnvironment.transform 11 3188 env38822 = env38823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env38822 == env38823) = true)

theorem identity38823 : scanCanonicalize (H12AffineFastState.compose env38823 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound38823 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env38824 : List Nat := [2,4,8,16,32,64,9,256,512,101,2048,2065,349,2420,0,343,2065,2420,100,1,2340,32,356,2,348,64,2048,2064,2065,2421,68,341,257,32,2341,885]

theorem envBound38824 : H12AffineFastState.Bounded env38824 := by
  intro p hp
  have h : env38824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38823_38824 : H12AffineEnvironment.transform 9 101 env38823 = env38824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env38823 == env38824) = true)

theorem identity38824 : scanCanonicalize (H12AffineFastState.compose env38824 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(7+1) ^^^ 11) := by decide +kernel

theorem selectedBound38824 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env38825 : List Nat := [2,4,8,16,32,64,9,11,512,101,2048,2065,86,2175,0,92,2065,2175,100,1,2095,32,111,2,87,64,2048,2064,2065,2174,68,94,10,32,2094,638]

theorem envBound38825 : H12AffineFastState.Bounded env38825 := by
  intro p hp
  have h : env38825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38824_38825 : H12AffineEnvironment.transform 7 11 env38824 = env38825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 11 env38824 == env38825) = true)

theorem identity38825 : scanCanonicalize (H12AffineFastState.compose env38825 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound38825 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env38826 : List Nat := [2,4,8,16,32,64,9,11,45,101,2048,2065,86,2175,0,92,2065,2175,100,1,2095,32,111,2,87,64,2048,2064,2065,2174,68,94,10,32,2094,83]

theorem envBound38826 : H12AffineFastState.Bounded env38826 := by
  intro p hp
  have h : env38826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38825_38826 : H12AffineEnvironment.transform 8 45 env38825 = env38826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env38825 == env38826) = true)

def env38827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169352,95496,8328,64,2049,163976,45524,284040,156816,411973,257,21792,46213,213831]

theorem envBound38827 : H12AffineFastState.Bounded env38827 := by
  intro p hp
  have h : env38827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38810_38827 : H12AffineEnvironment.transform 21 272513 env38810 = env38827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38810 == env38827) = true)

theorem identity38827 : scanCanonicalize (H12AffineFastState.compose env38827 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 112019) := by decide +kernel

theorem selectedBound38827 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,115870,272513,73755,95496,8328,64,2049,79131,45524,284040,119043,392406,257,21792,46213,63188]

theorem envBound38828 : H12AffineFastState.Bounded env38828 := by
  intro p hp
  have h : env38828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38827_38828 : H12AffineEnvironment.transform 16 112019 env38827 = env38828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 112019 env38827 == env38828) = true)

def env38829 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,115870,272513,73755,95496,8328,16,2049,79131,45444,284040,119043,392326,257,21792,46213,63108]

theorem envBound38829 : H12AffineFastState.Bounded env38829 := by
  intro p hp
  have h : env38829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38828_38829 : H12AffineEnvironment.transform 5 16 env38828 = env38829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38828 == env38829) = true)

theorem identity38829 : scanCanonicalize (H12AffineFastState.compose env38829 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 76078) := by decide +kernel

theorem selectedBound38829 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38830 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,76078,1025,32769,115870,65967,73755,95496,8328,16,2049,79131,45444,97446,119043,54696,257,21792,46213,63108]

theorem envBound38830 : H12AffineFastState.Bounded env38830 := by
  intro p hp
  have h : env38830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38829_38830 : H12AffineEnvironment.transform 17 76078 env38829 = env38830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76078 env38829 == env38830) = true)

theorem identity38830 : scanCanonicalize (H12AffineFastState.compose env38830 (packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 399) := by decide +kernel

theorem selectedBound38830 : packedSelected [3,5,8,10,16,17,19,20,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38831 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,399,46108,10401,1025,32769,50449,32,8596,29831,8328,16,2049,13460,45444,32041,53388,54696,257,21792,46213,63108]

theorem envBound38831 : H12AffineFastState.Bounded env38831 := by
  intro p hp
  have h : env38831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38830_38831 : H12AffineEnvironment.transform 15 399 env38830 = env38831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 399 env38830 == env38831) = true)

theorem identity38831 : scanCanonicalize (H12AffineFastState.compose env38831 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound38831 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env38832 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,136,399,13460,10401,1025,137,17817,32,8596,29831,8328,16,2049,13460,12556,32041,20484,21792,257,21792,13325,30220]

theorem envBound38832 : H12AffineFastState.Bounded env38832 := by
  intro p hp
  have h : env38832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38831_38832 : H12AffineEnvironment.transform 14 136 env38831 = env38832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env38831 == env38832) = true)

theorem identity38832 : scanCanonicalize (H12AffineFastState.compose env38832 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound38832 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env38833 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,16384,136,399,5392,2341,1025,137,17817,32,16,21763,268,16,2049,5392,4232,23725,20484,21792,257,21792,5513,22408]

theorem envBound38833 : H12AffineFastState.Bounded env38833 := by
  intro p hp
  have h : env38833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38832_38833 : H12AffineEnvironment.transform 12 388 env38832 = env38833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env38832 == env38833) = true)

theorem identity38833 : scanCanonicalize (H12AffineFastState.compose env38833 (packedSelected [6,11,12,14] rootPS)) = affineNative (2^(13+1) ^^^ 2340) := by decide +kernel

theorem selectedBound38833 : packedSelected [6,11,12,14] rootPS < 2^1333 := by decide +kernel

def env38834 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,388,2340,136,399,5392,2341,1025,137,3261,32,16,7207,268,16,2049,5392,4232,5513,6432,7172,257,7172,5513,7852]

theorem envBound38834 : H12AffineFastState.Bounded env38834 := by
  intro p hp
  have h : env38834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38833_38834 : H12AffineEnvironment.transform 13 2340 env38833 = env38834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2340 env38833 == env38834) = true)

theorem identity38834 : scanCanonicalize (H12AffineFastState.compose env38834 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3465) := by decide +kernel

theorem selectedBound38834 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38835 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,3465,388,2340,136,399,2201,2341,1025,137,3261,32,16,430,268,16,2049,2201,3329,2048,1193,397,257,397,2048,805]

theorem envBound38835 : H12AffineFastState.Bounded env38835 := by
  intro p hp
  have h : env38835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38834_38835 : H12AffineEnvironment.transform 11 3465 env38834 = env38835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3465 env38834 == env38835) = true)

theorem identity38835 : scanCanonicalize (H12AffineFastState.compose env38835 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38835 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38836 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3328,269,2340,1,262,2064,2341,1025,0,3124,32,16,295,268,16,2049,2064,3329,2048,1056,260,257,260,2048,805]

theorem envBound38836 : H12AffineFastState.Bounded env38836 := by
  intro p hp
  have h : env38836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38835_38836 : H12AffineEnvironment.transform 6 9 env38835 = env38836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38835 == env38836) = true)

theorem identity38836 : scanCanonicalize (H12AffineFastState.compose env38836 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 303) := by decide +kernel

theorem selectedBound38836 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38837 : List Nat := [2,4,8,16,32,16,9,256,512,1024,303,1071,269,11,1,262,319,10,1025,0,1307,32,16,295,268,16,302,319,1070,303,1056,260,257,260,303,805]

theorem envBound38837 : H12AffineFastState.Bounded env38837 := by
  intro p hp
  have h : env38837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38836_38837 : H12AffineEnvironment.transform 10 303 env38836 = env38837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 303 env38836 == env38837) = true)

theorem identity38837 : scanCanonicalize (H12AffineFastState.compose env38837 (packedSelected [0,1,3,4,6] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound38837 : packedSelected [0,1,3,4,6] rootPS < 2^1333 := by decide +kernel

def env38838 : List Nat := [2,4,8,16,27,16,9,256,512,1024,276,1044,269,11,1,262,260,10,1025,0,1307,27,16,284,268,16,277,260,1045,276,1051,260,257,260,276,798]

theorem envBound38838 : H12AffineFastState.Bounded env38838 := by
  intro p hp
  have h : env38838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38837_38838 : H12AffineEnvironment.transform 4 27 env38837 = env38838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env38837 == env38838) = true)

theorem identity38838 : scanCanonicalize (H12AffineFastState.compose env38838 (packedSelected [2,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound38838 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env38839 : List Nat := [2,4,8,16,27,16,9,256,512,267,276,287,269,11,1,262,260,10,266,0,16,27,16,284,268,16,277,260,286,276,272,260,257,260,276,798]

theorem envBound38839 : H12AffineFastState.Bounded env38839 := by
  intro p hp
  have h : env38839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38838_38839 : H12AffineEnvironment.transform 9 267 env38838 = env38839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env38838 == env38839) = true)

def env38840 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,262144,1025,32769,115870,272513,73755,95496,8328,17,2049,79131,45445,284040,119043,392327,257,21792,46213,63109]

theorem envBound38840 : H12AffineFastState.Bounded env38840 := by
  intro p hp
  have h : env38840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38828_38840 : H12AffineEnvironment.transform 5 17 env38828 = env38840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38828 == env38840) = true)

theorem identity38840 : scanCanonicalize (H12AffineFastState.compose env38840 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(17+1) ^^^ 64809) := by decide +kernel

theorem selectedBound38840 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env38841 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,112019,64809,1025,32769,115870,54696,73755,95496,8328,17,2049,79131,45445,43169,119043,65966,257,21792,46213,63109]

theorem envBound38841 : H12AffineFastState.Bounded env38841 := by
  intro p hp
  have h : env38841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38840_38841 : H12AffineEnvironment.transform 17 64809 env38840 = env38841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64809 env38840 == env38841) = true)

theorem identity38841 : scanCanonicalize (H12AffineFastState.compose env38841 (packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38841 : packedSelected [0,1,3,4,5,7,8,17,18,22,23,26,31] rootPS < 2^1333 := by decide +kernel

def env38842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,65536,112019,43049,1025,32769,102814,32936,73755,73736,8328,17,2049,79131,45445,43169,99331,65966,257,32,46213,41861]

theorem envBound38842 : H12AffineFastState.Bounded env38842 := by
  intro p hp
  have h : env38842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38841_38842 : H12AffineEnvironment.transform 13 5376 env38841 = env38842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38841 == env38842) = true)

theorem identity38842 : scanCanonicalize (H12AffineFastState.compose env38842 (packedSelected [3,10,17,18,19,23,24] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38842 : packedSelected [3,10,17,18,19,23,24] rootPS < 2^1333 := by decide +kernel

def env38843 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5376,32768,8203,38296,43049,1025,32769,45461,32936,16,3,8328,17,2049,5392,45445,43169,41992,8613,257,32,46213,41861]

theorem envBound38843 : H12AffineFastState.Bounded env38843 := by
  intro p hp
  have h : env38843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38842_38843 : H12AffineEnvironment.transform 15 8203 env38842 = env38843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38842 == env38843) = true)

theorem identity38843 : scanCanonicalize (H12AffineFastState.compose env38843 (packedSelected [16,20] rootPS)) = affineNative (2^(12+1) ^^^ 388) := by decide +kernel

theorem selectedBound38843 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env38844 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,388,5376,32768,399,38296,35245,1025,32769,36881,32936,16,3,268,17,2049,5392,36865,35109,34188,33,257,32,38145,33281]

theorem envBound38844 : H12AffineFastState.Bounded env38844 := by
  intro p hp
  have h : env38844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38843_38844 : H12AffineEnvironment.transform 12 388 env38843 = env38844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 388 env38843 == env38844) = true)

theorem identity38844 : scanCanonicalize (H12AffineFastState.compose env38844 (packedSelected [0,1,2,4,8,11,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound38844 : packedSelected [0,1,2,4,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env38845 : List Nat := [2,4,8,16,32,17,128,256,512,273,2048,4096,388,4113,32768,399,37001,35245,272,32769,36881,32936,16,3,268,17,2049,4097,36865,35109,32925,33,257,32,36880,33281]

theorem envBound38845 : H12AffineFastState.Bounded env38845 := by
  intro p hp
  have h : env38845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38844_38845 : H12AffineEnvironment.transform 9 273 env38844 = env38845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env38844 == env38845) = true)

theorem identity38845 : scanCanonicalize (H12AffineFastState.compose env38845 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound38845 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38846 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,269,4113,32768,262,36864,35108,272,32769,36881,32801,16,3,268,17,2049,4097,36865,35109,32788,33,257,32,36880,33281]

theorem envBound38846 : H12AffineFastState.Bounded env38846 := by
  intro p hp
  have h : env38846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38845_38846 : H12AffineEnvironment.transform 6 9 env38845 = env38846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38845 == env38846) = true)

theorem identity38846 : scanCanonicalize (H12AffineFastState.compose env38846 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38846 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env38847 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,32768,35,36864,34817,53,32769,36881,32801,16,3,41,17,2049,4097,36865,34816,32788,33,36,32,36880,33281]

theorem envBound38847 : H12AffineFastState.Bounded env38847 := by
  intro p hp
  have h : env38847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38846_38847 : H12AffineEnvironment.transform 7 37 env38846 = env38847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38846 == env38847) = true)

theorem identity38847 : scanCanonicalize (H12AffineFastState.compose env38847 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38847 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env38848 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,4096,40,4113,0,35,4096,2049,53,1,4113,33,16,3,41,17,2049,4097,4097,2048,20,33,36,32,4112,513]

theorem envBound38848 : H12AffineFastState.Bounded env38848 := by
  intro p hp
  have h : env38848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38847_38848 : H12AffineEnvironment.transform 14 0 env38847 = env38848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38847 == env38848) = true)

theorem identity38848 : scanCanonicalize (H12AffineFastState.compose env38848 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2577) := by decide +kernel

theorem selectedBound38848 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38849 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2577,40,2560,0,35,2577,2049,53,1,2560,33,16,3,41,17,2049,2576,2576,2048,20,33,36,32,2561,513]

theorem envBound38849 : H12AffineFastState.Bounded env38849 := by
  intro p hp
  have h : env38849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38848_38849 : H12AffineEnvironment.transform 11 2577 env38848 = env38849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2577 env38848 == env38849) = true)

theorem identity38849 : scanCanonicalize (H12AffineFastState.compose env38849 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 555) := by decide +kernel

theorem selectedBound38849 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38850 : List Nat := [2,4,8,16,32,17,9,37,512,52,555,58,40,43,0,35,58,554,53,1,43,33,16,3,41,17,554,59,59,555,20,33,36,32,42,513]

theorem envBound38850 : H12AffineFastState.Bounded env38850 := by
  intro p hp
  have h : env38850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38849_38850 : H12AffineEnvironment.transform 10 555 env38849 = env38850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 555 env38849 == env38850) = true)

def env38851 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,4194304,169353,95497,8328,64,4464768,163977,45525,284041,156816,4350405,257,21792,46213,213831]

theorem envBound38851 : H12AffineFastState.Bounded env38851 := by
  intro p hp
  have h : env38851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38809_38851 : H12AffineEnvironment.transform 22 169353 env38809 = env38851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169353 env38809 == env38851) = true)

def env38852 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272512,169353,95497,8328,64,2048,163977,45525,284041,156816,411973,257,21792,46213,213831]

theorem envBound38852 : H12AffineFastState.Bounded env38852 := by
  intro p hp
  have h : env38852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38851_38852 : H12AffineEnvironment.transform 21 272512 env38851 = env38852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env38851 == env38852) = true)

theorem identity38852 : scanCanonicalize (H12AffineFastState.compose env38852 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound38852 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,160013,272512,169353,41431,8328,64,2048,163977,45525,284041,156816,411973,257,21792,46213,169881]

theorem envBound38853 : H12AffineFastState.Bounded env38853 := by
  intro p hp
  have h : env38853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38852_38853 : H12AffineEnvironment.transform 15 54494 env38852 = env38853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env38852 == env38853) = true)

def env38854 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160013,272392,169217,41311,8192,64,2048,163841,45405,283905,156696,411973,257,21792,46093,169745]

theorem envBound38854 : H12AffineFastState.Bounded env38854 := by
  intro p hp
  have h : env38854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38853_38854 : H12AffineEnvironment.transform 6 8 env38853 = env38854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38853 == env38854) = true)

theorem identity38854 : scanCanonicalize (H12AffineFastState.compose env38854 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(17+1) ^^^ 32041) := by decide +kernel

theorem selectedBound38854 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env38855 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,32041,1025,32769,160013,21793,169217,41311,8192,64,2048,163841,45405,10280,156696,144492,257,21792,46093,169745]

theorem envBound38855 : H12AffineFastState.Bounded env38855 := by
  intro p hp
  have h : env38855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38854_38855 : H12AffineEnvironment.transform 17 32041 env38854 = env38855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32041 env38854 == env38855) = true)

theorem identity38855 : scanCanonicalize (H12AffineFastState.compose env38855 (packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound38855 : packedSelected [1,3,4,8,9,10,12,14,15,17,19,20,24,26] rootPS < 2^1333 := by decide +kernel

def env38856 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,131072,32041,1025,29789,160013,21793,155997,21763,8192,64,2048,160861,17665,10280,156696,144492,257,21792,16465,156493]

theorem envBound38856 : H12AffineFastState.Bounded env38856 := by
  intro p hp
  have h : env38856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38855_38856 : H12AffineEnvironment.transform 14 29788 env38855 = env38856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env38855 == env38856) = true)

theorem identity38856 : scanCanonicalize (H12AffineFastState.compose env38856 (packedSelected [2,11,14,17,18] rootPS)) = affineNative (2^(16+1) ^^^ 24632) := by decide +kernel

theorem selectedBound38856 : packedSelected [2,11,14,17,18] rootPS < 2^1333 := by decide +kernel

def env38857 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,8202,24632,32041,1025,29789,4405,21793,357,21763,8192,64,2048,5221,17665,10280,1056,21588,257,21792,16465,885]

theorem envBound38857 : H12AffineFastState.Bounded env38857 := by
  intro p hp
  have h : env38857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38856_38857 : H12AffineEnvironment.transform 16 24632 env38856 = env38857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24632 env38856 == env38857) = true)

theorem identity38857 : scanCanonicalize (H12AffineFastState.compose env38857 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound38857 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38858 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,5220,2421,1025,1,4405,8573,357,8543,8192,64,2048,5221,12637,10280,1056,8200,257,8572,13325,885]

theorem envBound38858 : H12AffineFastState.Bounded env38858 := by
  intro p hp
  have h : env38858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38857_38858 : H12AffineEnvironment.transform 13 13404 env38857 = env38858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env38857 == env38858) = true)

def env38859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1025,32769,160013,272393,169216,41310,8193,64,2048,163840,45404,283904,156697,411973,257,21792,46092,169744]

theorem envBound38859 : H12AffineFastState.Bounded env38859 := by
  intro p hp
  have h : env38859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38853_38859 : H12AffineEnvironment.transform 6 9 env38853 = env38859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38853 == env38859) = true)

theorem identity38859 : scanCanonicalize (H12AffineFastState.compose env38859 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(14+1) ^^^ 21620) := by decide +kernel

theorem selectedBound38859 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env38860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,35,131072,262144,1025,21621,160013,272393,147828,29994,8193,64,2048,152692,25896,283904,156697,411973,257,21792,24696,148324]

theorem envBound38860 : H12AffineFastState.Bounded env38860 := by
  intro p hp
  have h : env38860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38859_38860 : H12AffineEnvironment.transform 14 21620 env38859 = env38860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21620 env38859 == env38860) = true)

theorem identity38860 : scanCanonicalize (H12AffineFastState.compose env38860 (packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound38860 : packedSelected [1,3,4,9,10,14,16,17,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,35,131072,138340,1025,21621,160013,144493,147828,29994,8193,64,2048,152692,25896,149860,156697,21793,257,21792,24696,148324]

theorem envBound38861 : H12AffineFastState.Bounded env38861 := by
  intro p hp
  have h : env38861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38860_38861 : H12AffineEnvironment.transform 17 138340 env38860 = env38861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env38860 == env38861) = true)

theorem identity38861 : scanCanonicalize (H12AffineFastState.compose env38861 (packedSelected [0,1,4,7,8,12,15,16,17,18,19,20,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound38861 : packedSelected [0,1,4,7,8,12,15,16,17,18,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env38862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21620,35,16449,23589,1025,21621,12620,29740,309,29994,8193,64,2048,5173,25896,2341,9304,21793,257,21792,24696,805]

theorem envBound38862 : H12AffineFastState.Bounded env38862 := by
  intro p hp
  have h : env38862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38861_38862 : H12AffineEnvironment.transform 16 16449 env38861 = env38862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env38861 == env38862) = true)

theorem identity38862 : scanCanonicalize (H12AffineFastState.compose env38862 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound38862 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env38863 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,8461,35,13624,10588,1025,8460,12620,341,309,83,8193,64,2048,5173,4177,2341,9304,8280,257,8281,5377,805]

theorem envBound38863 : H12AffineFastState.Bounded env38863 := by
  intro p hp
  have h : env38863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38862_38863 : H12AffineEnvironment.transform 13 13689 env38862 = env38863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env38862 == env38863) = true)

theorem identity38863 : scanCanonicalize (H12AffineFastState.compose env38863 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38863 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38864 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,41,5456,292,35,5393,2421,1025,293,4453,341,309,83,40,64,2048,5173,4177,2341,1137,113,257,112,5377,805]

theorem envBound38864 : H12AffineFastState.Bounded env38864 := by
  intro p hp
  have h : env38864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38863_38864 : H12AffineEnvironment.transform 12 41 env38863 = env38864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38863 == env38864) = true)

theorem identity38864 : scanCanonicalize (H12AffineFastState.compose env38864 (packedSelected [2,4,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound38864 : packedSelected [2,4,7,10] rootPS < 2^1333 := by decide +kernel

def env38865 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3189,41,2341,292,35,2404,2421,1025,293,3344,341,309,83,40,64,2048,2112,3108,2341,1137,113,257,112,2420,805]

theorem envBound38865 : H12AffineFastState.Bounded env38865 := by
  intro p hp
  have h : env38865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38864_38865 : H12AffineEnvironment.transform 11 3189 env38864 = env38865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env38864 == env38865) = true)

theorem identity38865 : scanCanonicalize (H12AffineFastState.compose env38865 (packedSelected [3,4,5,6,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38865 : packedSelected [3,4,5,6,7,11] rootPS < 2^1333 := by decide +kernel

def env38866 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,3189,41,2049,0,35,2112,2129,1025,1,3124,113,17,83,40,64,2048,2112,3108,2049,1137,113,37,112,2128,513]

theorem envBound38866 : H12AffineFastState.Bounded env38866 := by
  intro p hp
  have h : env38866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38865_38866 : H12AffineEnvironment.transform 7 36 env38865 = env38866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38865 == env38866) = true)

theorem identity38866 : scanCanonicalize (H12AffineFastState.compose env38866 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38866 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38867 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,3108,41,2049,0,35,2065,2048,1025,1,3124,32,17,2,40,17,2048,2065,3108,2049,1056,32,37,33,2049,513]

theorem envBound38867 : H12AffineFastState.Bounded env38867 := by
  intro p hp
  have h : env38867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38866_38867 : H12AffineEnvironment.transform 5 17 env38866 = env38867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38866 == env38867) = true)

theorem identity38867 : scanCanonicalize (H12AffineFastState.compose env38867 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound38867 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38868 : List Nat := [2,4,8,16,32,17,9,36,512,1024,0,1060,41,1,0,35,17,0,1025,1,1076,32,17,2,40,17,0,17,1060,1,1056,32,37,33,1,513]

theorem envBound38868 : H12AffineFastState.Bounded env38868 := by
  intro p hp
  have h : env38868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38867_38868 : H12AffineEnvironment.transform 10 0 env38867 = env38868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env38867 == env38868) = true)

theorem identity38868 : scanCanonicalize (H12AffineFastState.compose env38868 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38868 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38869 : List Nat := [2,4,8,16,32,17,9,36,512,52,0,16,41,1,0,35,17,0,53,1,0,32,17,2,40,17,0,17,16,1,20,32,37,33,1,513]

theorem envBound38869 : H12AffineFastState.Bounded env38869 := by
  intro p hp
  have h : env38869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38868_38869 : H12AffineEnvironment.transform 9 52 env38868 = env38869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38868 == env38869) = true)

theorem identity38869 : scanCanonicalize (H12AffineFastState.compose env38869 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound38869 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38870 : List Nat := [2,4,8,16,32,17,9,36,1,52,0,16,41,1,0,35,17,0,53,1,0,32,17,2,40,17,0,17,16,1,20,32,37,33,1,0]

theorem envBound38870 : H12AffineFastState.Bounded env38870 := by
  intro p hp
  have h : env38870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38869_38870 : H12AffineEnvironment.transform 8 1 env38869 = env38870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env38869 == env38870) = true)

theorem identity38870 : scanCanonicalize (H12AffineFastState.compose env38870 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound38870 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38871 : List Nat := [2,4,8,16,10,17,9,14,1,30,0,16,3,1,0,9,17,0,31,1,0,10,17,2,2,17,0,17,16,1,20,10,15,11,1,0]

theorem envBound38871 : H12AffineFastState.Bounded env38871 := by
  intro p hp
  have h : env38871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38870_38871 : H12AffineEnvironment.transform 4 10 env38870 = env38871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env38870 == env38871) = true)

def env38872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160013,272513,169353,95497,8328,64,2049,163977,45525,284041,156816,411972,257,21792,46213,213831]

theorem envBound38872 : H12AffineFastState.Bounded env38872 := by
  intro p hp
  have h : env38872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38851_38872 : H12AffineEnvironment.transform 21 272513 env38851 = env38872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env38851 == env38872) = true)

theorem identity38872 : scanCanonicalize (H12AffineFastState.compose env38872 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound38872 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272513,120015,95497,8328,64,2049,115151,45525,284041,75222,329730,257,21792,46213,513]

theorem envBound38873 : H12AffineFastState.Bounded env38873 := by
  intro p hp
  have h : env38873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38872_38873 : H12AffineEnvironment.transform 16 82246 env38872 = env38873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env38872 == env38873) = true)

def env38874 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272393,119879,95497,8192,64,2049,115015,45405,283905,75102,329730,257,21792,46093,513]

theorem envBound38874 : H12AffineFastState.Bounded env38874 := by
  intro p hp
  have h : env38874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38873_38874 : H12AffineEnvironment.transform 6 8 env38873 = env38874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38873 == env38874) = true)

def env38875 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10280,1025,32769,77899,33,119879,95497,8192,64,2049,115015,45405,32041,75102,73770,257,21792,46093,513]

theorem envBound38875 : H12AffineFastState.Bounded env38875 := by
  intro p hp
  have h : env38875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38874_38875 : H12AffineEnvironment.transform 17 10280 env38874 = env38875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env38874 == env38875) = true)

theorem identity38875 : scanCanonicalize (H12AffineFastState.compose env38875 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38875 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env38876 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,0,65536,82246,10280,1025,1,77899,33,87111,95497,8192,64,2049,82247,12637,32041,75102,73770,257,21792,13325,513]

theorem envBound38876 : H12AffineFastState.Bounded env38876 := by
  intro p hp
  have h : env38876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38875_38876 : H12AffineEnvironment.transform 14 0 env38875 = env38876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38875 == env38876) = true)

theorem identity38876 : scanCanonicalize (H12AffineFastState.compose env38876 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38876 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38877 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,65536,82246,2421,1025,1,69910,33,87111,87124,349,64,2049,82247,4096,23668,66563,65911,257,21792,5456,513]

theorem envBound38877 : H12AffineFastState.Bounded env38877 := by
  intro p hp
  have h : env38877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38876_38877 : H12AffineEnvironment.transform 12 349 env38876 = env38877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38876 == env38877) = true)

theorem identity38877 : scanCanonicalize (H12AffineFastState.compose env38877 (packedSelected [1,4,8,9,10,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 21510) := by decide +kernel

theorem selectedBound38877 : packedSelected [1,4,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38878 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,0,21510,5440,2421,1025,1,17680,33,65,82,349,64,2049,5441,4096,23668,20485,21873,257,21792,5456,513]

theorem envBound38878 : H12AffineFastState.Bounded env38878 := by
  intro p hp
  have h : env38878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38877_38878 : H12AffineEnvironment.transform 15 21510 env38877 = env38878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21510 env38877 == env38878) = true)

theorem identity38878 : scanCanonicalize (H12AffineFastState.compose env38878 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38878 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,262,5440,2421,1025,1,4112,33,65,82,349,64,2049,5441,4096,2420,1285,113,257,32,5456,513]

theorem envBound38879 : H12AffineFastState.Bounded env38879 := by
  intro p hp
  have h : env38879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38878_38879 : H12AffineEnvironment.transform 13 5376 env38878 = env38879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38878 == env38879) = true)

theorem identity38879 : scanCanonicalize (H12AffineFastState.compose env38879 (packedSelected [3,5,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38879 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38880 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,0,262,5392,2341,1025,1,4112,33,17,2,269,16,2049,5393,4096,2340,1285,33,257,32,5376,513]

theorem envBound38880 : H12AffineFastState.Bounded env38880 := by
  intro p hp
  have h : env38880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38879_38880 : H12AffineEnvironment.transform 5 16 env38879 = env38880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38879 == env38880) = true)

theorem identity38880 : scanCanonicalize (H12AffineFastState.compose env38880 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound38880 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38881 : List Nat := [2,4,8,16,32,16,8,256,512,52,2048,4096,269,4404,0,262,4388,2341,53,1,4112,33,17,2,269,16,2049,4389,4096,2340,305,33,257,32,4404,513]

theorem envBound38881 : H12AffineFastState.Bounded env38881 := by
  intro p hp
  have h : env38881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38880_38881 : H12AffineEnvironment.transform 9 52 env38880 = env38881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38880 == env38881) = true)

theorem identity38881 : scanCanonicalize (H12AffineFastState.compose env38881 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound38881 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38882 : List Nat := [2,4,8,16,32,16,8,256,512,52,523,4096,269,4404,0,262,4388,814,53,1,4112,33,17,2,269,16,522,4389,4096,815,305,33,257,32,4404,513]

theorem envBound38882 : H12AffineFastState.Bounded env38882 := by
  intro p hp
  have h : env38882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38881_38882 : H12AffineEnvironment.transform 10 523 env38881 = env38882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env38881 == env38882) = true)

theorem identity38882 : scanCanonicalize (H12AffineFastState.compose env38882 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 798) := by decide +kernel

theorem selectedBound38882 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38883 : List Nat := [2,4,8,16,32,16,8,256,512,52,523,798,269,554,0,262,570,814,53,1,782,33,17,2,269,16,522,571,798,815,305,33,257,32,554,513]

theorem envBound38883 : H12AffineFastState.Bounded env38883 := by
  intro p hp
  have h : env38883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38882_38883 : H12AffineEnvironment.transform 11 798 env38882 = env38883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 798 env38882 == env38883) = true)

def env38884 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,10281,1025,32769,77899,32,119879,95497,8192,64,2049,115015,45405,32040,75102,73771,257,21792,46093,513]

theorem envBound38884 : H12AffineFastState.Bounded env38884 := by
  intro p hp
  have h : env38884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38874_38884 : H12AffineEnvironment.transform 17 10281 env38874 = env38884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env38874 == env38884) = true)

theorem identity38884 : scanCanonicalize (H12AffineFastState.compose env38884 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound38884 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38885 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,10281,1025,32769,58396,32,16,41310,8192,64,2049,5392,45405,32040,61705,62588,257,21792,46093,513]

theorem envBound38885 : H12AffineFastState.Bounded env38885 := by
  intro p hp
  have h : env38885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38884_38885 : H12AffineEnvironment.transform 15 54359 env38884 = env38885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env38884 == env38885) = true)

theorem identity38885 : scanCanonicalize (H12AffineFastState.compose env38885 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 7425) := by decide +kernel

theorem selectedBound38885 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env38886 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,7425,18774,2064,10281,1025,7424,31005,32,16,15455,8192,64,2049,5392,11356,32040,27656,27005,257,21792,10508,513]

theorem envBound38886 : H12AffineFastState.Bounded env38886 := by
  intro p hp
  have h : env38886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38885_38886 : H12AffineEnvironment.transform 14 7425 env38885 = env38886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7425 env38885 == env38886) = true)

theorem identity38886 : scanCanonicalize (H12AffineFastState.compose env38886 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38886 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38887 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,7425,18774,2064,2421,1025,7424,22593,32,16,7427,348,64,2049,5392,3328,23668,19796,18465,257,21792,2128,513]

theorem envBound38887 : H12AffineFastState.Bounded env38887 := by
  intro p hp
  have h : env38887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38886_38887 : H12AffineEnvironment.transform 12 348 env38886 = env38887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38886 == env38887) = true)

theorem identity38887 : scanCanonicalize (H12AffineFastState.compose env38887 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 1297) := by decide +kernel

theorem selectedBound38887 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env38888 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,1297,7425,3143,2064,2421,1025,7424,7504,32,16,7427,348,64,2049,5392,3328,6501,2117,3376,257,4145,2128,513]

theorem envBound38888 : H12AffineFastState.Bounded env38888 := by
  intro p hp
  have h : env38888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38887_38888 : H12AffineEnvironment.transform 13 1297 env38887 = env38888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1297 env38887 == env38888) = true)

theorem identity38888 : scanCanonicalize (H12AffineFastState.compose env38888 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38888 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env38889 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,348,1,6161,2391,2064,2421,273,6160,6208,32,16,6163,348,64,2049,4096,2064,6501,2117,2080,257,4145,2128,513]

theorem envBound38889 : H12AffineFastState.Bounded env38889 := by
  intro p hp
  have h : env38889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38888_38889 : H12AffineEnvironment.transform 9 272 env38888 = env38889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38888 == env38889) = true)

theorem identity38889 : scanCanonicalize (H12AffineFastState.compose env38889 (packedSelected [3,5,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38889 : packedSelected [3,5,10,11] rootPS < 2^1333 := by decide +kernel

def env38890 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,4096,121,1,6161,2162,2064,2128,52,6160,6208,32,16,6163,121,64,2049,4096,2064,6208,2117,2080,36,4145,2128,513]

theorem envBound38890 : H12AffineFastState.Bounded env38890 := by
  intro p hp
  have h : env38890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38889_38890 : H12AffineEnvironment.transform 7 37 env38889 = env38890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38889 == env38890) = true)

theorem identity38890 : scanCanonicalize (H12AffineFastState.compose env38890 (packedSelected [0,1,2,3,4,6] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound38890 : packedSelected [0,1,2,3,4,6] rootPS < 2^1333 := by decide +kernel

def env38891 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,64,121,1,2129,2162,2064,2128,52,2128,2048,32,16,2131,121,64,2049,64,2064,2048,2117,2080,36,113,2128,513]

theorem envBound38891 : H12AffineFastState.Bounded env38891 := by
  intro p hp
  have h : env38891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38890_38891 : H12AffineEnvironment.transform 11 64 env38890 = env38891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env38890 == env38891) = true)

theorem identity38891 : scanCanonicalize (H12AffineFastState.compose env38891 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound38891 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env38892 : List Nat := [2,4,8,16,32,64,8,37,512,53,80,64,121,1,1,34,64,0,52,0,80,32,16,3,121,64,81,64,64,80,21,112,36,113,0,513]

theorem envBound38892 : H12AffineFastState.Bounded env38892 := by
  intro p hp
  have h : env38892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38891_38892 : H12AffineEnvironment.transform 10 80 env38891 = env38892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env38891 == env38892) = true)

theorem identity38892 : scanCanonicalize (H12AffineFastState.compose env38892 (packedSelected [1,2] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound38892 : packedSelected [1,2] rootPS < 2^1333 := by decide +kernel

def env38893 : List Nat := [2,4,8,16,32,64,8,37,43,53,80,64,121,1,1,34,64,0,52,0,80,32,16,3,121,64,81,64,64,80,21,112,36,113,0,42]

theorem envBound38893 : H12AffineFastState.Bounded env38893 := by
  intro p hp
  have h : env38893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38892_38893 : H12AffineEnvironment.transform 8 43 env38892 = env38893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env38892 == env38893) = true)

theorem identity38893 : scanCanonicalize (H12AffineFastState.compose env38893 (packedSelected [0,1,3] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound38893 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env38894 : List Nat := [2,4,8,16,26,64,8,31,17,15,80,64,67,1,1,24,64,0,14,0,80,26,16,3,67,64,81,64,64,80,21,74,30,75,0,16]

theorem envBound38894 : H12AffineFastState.Bounded env38894 := by
  intro p hp
  have h : env38894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38893_38894 : H12AffineEnvironment.transform 4 26 env38893 = env38894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env38893 == env38894) = true)

theorem identity38894 : scanCanonicalize (H12AffineFastState.compose env38894 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38894 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38895 : List Nat := [2,4,8,16,26,16,8,31,17,15,0,16,19,1,1,24,16,0,14,0,0,26,16,3,19,16,1,16,16,0,21,26,30,27,0,16]

theorem envBound38895 : H12AffineFastState.Bounded env38895 := by
  intro p hp
  have h : env38895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38894_38895 : H12AffineEnvironment.transform 5 16 env38894 = env38895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38894 == env38895) = true)

def env38896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77899,272392,119878,95497,8193,64,2049,115014,45404,283904,75103,329730,257,21792,46092,513]

theorem envBound38896 : H12AffineFastState.Bounded env38896 := by
  intro p hp
  have h : env38896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38873_38896 : H12AffineEnvironment.transform 6 9 env38873 = env38896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38873 == env38896) = true)

theorem identity38896 : scanCanonicalize (H12AffineFastState.compose env38896 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38896 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env38897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,65536,82246,262144,1025,32769,69911,264532,119878,87125,349,64,2049,115014,36864,283904,66563,329730,257,21792,38224,513]

theorem envBound38897 : H12AffineFastState.Bounded env38897 := by
  intro p hp
  have h : env38897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38896_38897 : H12AffineEnvironment.transform 12 348 env38896 = env38897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38896 == env38897) = true)

theorem identity38897 : scanCanonicalize (H12AffineFastState.compose env38897 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 21841) := by decide +kernel

theorem selectedBound38897 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env38898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21841,65536,82246,262144,1025,21840,69911,264532,65815,87125,349,64,2049,70679,17745,283904,66563,329730,257,21792,16385,513]

theorem envBound38898 : H12AffineFastState.Bounded env38898 := by
  intro p hp
  have h : env38898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38897_38898 : H12AffineEnvironment.transform 14 21841 env38897 = env38898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21841 env38897 == env38898) = true)

theorem identity38898 : scanCanonicalize (H12AffineFastState.compose env38898 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(17+1) ^^^ 23809) := by decide +kernel

theorem selectedBound38898 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38899 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,21841,65536,82246,23809,1025,21840,69911,21589,65815,87125,349,64,2049,70679,17745,2049,66563,87299,257,21792,16385,513]

theorem envBound38899 : H12AffineFastState.Bounded env38899 := by
  intro p hp
  have h : env38899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38898_38899 : H12AffineEnvironment.transform 17 23809 env38898 = env38899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23809 env38898 == env38899) = true)

theorem identity38899 : scanCanonicalize (H12AffineFastState.compose env38899 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38899 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env38900 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,65536,82198,23809,1025,21760,69911,21509,65815,87045,269,16,2049,70679,17665,2049,66563,87299,257,21792,16385,513]

theorem envBound38900 : H12AffineFastState.Bounded env38900 := by
  intro p hp
  have h : env38900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38899_38900 : H12AffineEnvironment.transform 5 16 env38899 = env38900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38899 == env38900) = true)

theorem identity38900 : scanCanonicalize (H12AffineFastState.compose env38900 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound38900 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env38901 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,4404,1077,65536,69666,3125,1025,1076,69911,1329,65815,66865,269,16,2049,70679,5173,2049,66563,66615,257,1044,4405,513]

theorem envBound38901 : H12AffineFastState.Bounded env38901 := by
  intro p hp
  have h : env38901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38900_38901 : H12AffineEnvironment.transform 13 4404 env38900 = env38901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env38900 == env38901) = true)

theorem identity38901 : scanCanonicalize (H12AffineFastState.compose env38901 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38901 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env38902 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4404,293,65536,69666,2341,273,292,69911,33,65815,65569,269,16,2049,69895,4389,2049,65811,65831,257,260,4405,513]

theorem envBound38902 : H12AffineFastState.Bounded env38902 := by
  intro p hp
  have h : env38902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38901_38902 : H12AffineEnvironment.transform 9 272 env38901 = env38902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38901 == env38902) = true)

theorem identity38902 : scanCanonicalize (H12AffineFastState.compose env38902 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound38902 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env38903 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,4096,268,4404,293,263,4389,2341,273,292,4112,33,16,294,269,16,2049,4096,4389,2049,20,32,257,260,4405,513]

theorem envBound38903 : H12AffineFastState.Bounded env38903 := by
  intro p hp
  have h : env38903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38902_38903 : H12AffineEnvironment.transform 15 263 env38902 = env38903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env38902 == env38903) = true)

theorem identity38903 : scanCanonicalize (H12AffineFastState.compose env38903 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound38903 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38904 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,41,4113,0,34,4096,2048,52,1,4112,33,16,3,40,16,2049,4096,4096,2049,20,32,36,33,4112,513]

theorem envBound38904 : H12AffineFastState.Bounded env38904 := by
  intro p hp
  have h : env38904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38903_38904 : H12AffineEnvironment.transform 7 37 env38903 = env38904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env38903 == env38904) = true)

theorem identity38904 : scanCanonicalize (H12AffineFastState.compose env38904 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound38904 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38905 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,0,41,17,0,34,0,2048,52,1,16,33,16,3,40,16,2049,0,0,2049,20,32,36,33,16,513]

theorem envBound38905 : H12AffineFastState.Bounded env38905 := by
  intro p hp
  have h : env38905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38904_38905 : H12AffineEnvironment.transform 11 0 env38904 = env38905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env38904 == env38905) = true)

theorem identity38905 : scanCanonicalize (H12AffineFastState.compose env38905 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound38905 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38906 : List Nat := [2,4,8,16,32,16,9,37,512,53,522,0,41,17,0,34,0,522,52,1,16,33,16,3,40,16,523,0,0,523,20,32,36,33,16,513]

theorem envBound38906 : H12AffineFastState.Bounded env38906 := by
  intro p hp
  have h : env38906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38905_38906 : H12AffineEnvironment.transform 10 522 env38905 = env38906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env38905 == env38906) = true)

def env38907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497100,10507600,155254784,25265169,145662400,525568,140903597,27337992,25733062]

theorem envBound38907 : H12AffineFastState.Bounded env38907 := by
  intro p hp
  have h : env38907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37895_38907 : H12AffineEnvironment.transform 25 65 env37895 = env38907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env37895 == env38907) = true)

def env38908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497100,10507600,9356288,25265169,23160256,525568,27902125,27337992,25733062]

theorem envBound38908 : H12AffineFastState.Bounded env38908 := by
  intro p hp
  have h : env38908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38907_38908 : H12AffineEnvironment.transform 26 30393344 env38907 = env38908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env38907 == env38908) = true)

def env38909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973836,10507600,8830976,25265169,23160256,256,27378861,27337992,25207750]

theorem envBound38909 : H12AffineFastState.Bounded env38909 := by
  intro p hp
  have h : env38909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38908_38909 : H12AffineEnvironment.transform 18 1024 env38908 = env38909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env38908 == env38909) = true)

theorem identity38909 : scanCanonicalize (H12AffineFastState.compose env38909 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 2534880) := by decide +kernel

theorem selectedBound38909 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env38910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534880,16777216,8328,65,23162336,18973836,456880,2125280,19343857,23160256,256,17262925,17271016,19271206]

theorem envBound38910 : H12AffineFastState.Bounded env38910 := by
  intro p hp
  have h : env38910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38909_38910 : H12AffineEnvironment.transform 22 2534880 env38909 = env38910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2534880 env38909 == env38910) = true)

def env38911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534880,474220,8328,65,6705548,2537696,456880,2125280,2102685,6707628,256,21793,46212,2175562]

theorem envBound38911 : H12AffineFastState.Bounded env38911 := by
  intro p hp
  have h : env38911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38910_38911 : H12AffineEnvironment.transform 23 474220 env38910 = env38911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474220 env38910 == env38911) = true)

def env38912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101328,98780,8328,65,6351932,2098512,17664,2125280,2102685,6349852,256,21793,46212,2175562]

theorem envBound38912 : H12AffineFastState.Bounded env38912 := by
  intro p hp
  have h : env38912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38911_38912 : H12AffineEnvironment.transform 17 179632 env38911 = env38912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env38911 == env38912) = true)

def env38913 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,16,98780,8328,65,4258940,5392,17664,32160,1501,4256860,256,21793,46212,74250]

theorem envBound38913 : H12AffineFastState.Bounded env38913 := by
  intro p hp
  have h : env38913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38912_38913 : H12AffineEnvironment.transform 20 4160 env38912 = env38913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38912 == env38913) = true)

theorem identity38913 : scanCanonicalize (H12AffineFastState.compose env38913 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound38913 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38914 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,179632,1024,32769,4160,4194304,16,21763,8328,65,4258940,5392,17664,32160,1501,4256860,256,21793,46212,63189]

theorem envBound38914 : H12AffineFastState.Bounded env38914 := by
  intro p hp
  have h : env38914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38913_38914 : H12AffineEnvironment.transform 15 54495 env38913 = env38914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env38913 == env38914) = true)

def env38915 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,179512,1024,32769,4160,4194304,16,21763,8192,65,4258940,5392,17664,32040,1365,4256860,256,21793,46092,63069]

theorem envBound38915 : H12AffineFastState.Bounded env38915 := by
  intro p hp
  have h : env38915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38914_38915 : H12AffineEnvironment.transform 6 8 env38914 = env38915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38914 == env38915) = true)

theorem identity38915 : scanCanonicalize (H12AffineFastState.compose env38915 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound38915 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38916 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10280,1024,32769,4160,4194304,16,21763,8192,65,4258940,5392,17664,32040,1365,4256860,256,21793,46092,63069]

theorem envBound38916 : H12AffineFastState.Bounded env38916 := by
  intro p hp
  have h : env38916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38915_38916 : H12AffineEnvironment.transform 16 38160 env38915 = env38916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env38915 == env38916) = true)

theorem identity38916 : scanCanonicalize (H12AffineFastState.compose env38916 (packedSelected [0,3,4,5,7,10,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 32880) := by decide +kernel

theorem selectedBound38916 : packedSelected [0,3,4,5,7,10,18,22,23] rootPS < 2^1333 := by decide +kernel

def env38917 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38160,10280,1024,32769,4160,32880,16,21763,8192,65,31756,5392,17664,32040,1365,29740,256,21793,46092,63069]

theorem envBound38917 : H12AffineFastState.Bounded env38917 := by
  intro p hp
  have h : env38917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38916_38917 : H12AffineEnvironment.transform 21 32880 env38916 = env38917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32880 env38916 == env38917) = true)

theorem identity38917 : scanCanonicalize (H12AffineFastState.compose env38917 (packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound38917 : packedSelected [1,2,3,4,5,6,8,10,11,18,19,20,22] rootPS < 2^1333 := by decide +kernel

def env38918 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,21590,5393,10280,1024,0,4160,113,16,21763,8192,65,31756,5392,17664,32040,1365,29740,256,21793,13325,30300]

theorem envBound38918 : H12AffineFastState.Bounded env38918 := by
  intro p hp
  have h : env38918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38917_38918 : H12AffineEnvironment.transform 14 1 env38917 = env38918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env38917 == env38918) = true)

theorem identity38918 : scanCanonicalize (H12AffineFastState.compose env38918 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38918 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env38919 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,1,343,5393,10280,1024,0,4160,113,16,2,8192,65,10509,5392,4097,10281,1365,8493,256,32,13325,9053]

theorem envBound38919 : H12AffineFastState.Bounded env38919 := by
  intro p hp
  have h : env38919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38918_38919 : H12AffineEnvironment.transform 13 5377 env38918 = env38919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38918 == env38919) = true)

theorem identity38919 : scanCanonicalize (H12AffineFastState.compose env38919 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38919 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env38920 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,1,343,5393,2420,1024,0,4160,113,16,2,348,65,2129,5392,4097,2421,1365,113,256,32,5457,513]

theorem envBound38920 : H12AffineFastState.Bounded env38920 := by
  intro p hp
  have h : env38920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38919_38920 : H12AffineEnvironment.transform 12 348 env38919 = env38920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38919 == env38920) = true)

theorem identity38920 : scanCanonicalize (H12AffineFastState.compose env38920 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38921 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5377,1,262,5393,2341,1024,0,4113,32,16,2,269,16,2048,5392,4097,2340,1284,32,256,32,5376,513]

theorem envBound38921 : H12AffineFastState.Bounded env38921 := by
  intro p hp
  have h : env38921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38920_38921 : H12AffineEnvironment.transform 5 17 env38920 = env38921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38920 == env38921) = true)

theorem identity38921 : scanCanonicalize (H12AffineFastState.compose env38921 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound38921 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38922 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,32,269,1313,1,262,1329,2341,1024,0,49,32,16,2,269,16,2048,1328,33,2340,1284,32,256,32,1312,513]

theorem envBound38922 : H12AffineFastState.Bounded env38922 := by
  intro p hp
  have h : env38922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38921_38922 : H12AffineEnvironment.transform 11 32 env38921 = env38922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env38921 == env38922) = true)

theorem identity38922 : scanCanonicalize (H12AffineFastState.compose env38922 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 800) := by decide +kernel

theorem selectedBound38922 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38923 : List Nat := [2,4,8,16,32,17,8,256,512,800,2048,32,269,513,1,262,529,2341,800,0,49,32,16,2,269,16,2048,528,33,2340,548,32,256,32,512,513]

theorem envBound38923 : H12AffineFastState.Bounded env38923 := by
  intro p hp
  have h : env38923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38922_38923 : H12AffineEnvironment.transform 9 800 env38922 = env38923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 800 env38922 == env38923) = true)

theorem identity38923 : scanCanonicalize (H12AffineFastState.compose env38923 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound38923 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38924 : List Nat := [2,4,8,16,32,17,8,256,512,800,1,32,269,513,1,262,529,292,800,0,49,32,16,2,269,16,1,528,33,293,548,32,256,32,512,513]

theorem envBound38924 : H12AffineFastState.Bounded env38924 := by
  intro p hp
  have h : env38924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38923_38924 : H12AffineEnvironment.transform 10 1 env38923 = env38924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env38923 == env38924) = true)

theorem identity38924 : scanCanonicalize (H12AffineFastState.compose env38924 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound38924 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env38925 : List Nat := [2,4,8,16,32,17,8,256,17,305,1,32,269,16,1,262,0,292,305,0,49,32,16,2,269,16,1,1,33,293,53,32,256,32,17,16]

theorem envBound38925 : H12AffineFastState.Bounded env38925 := by
  intro p hp
  have h : env38925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38924_38925 : H12AffineEnvironment.transform 8 17 env38924 = env38925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env38924 == env38925) = true)

theorem identity38925 : scanCanonicalize (H12AffineFastState.compose env38925 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound38925 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env38926 : List Nat := [2,4,8,16,32,17,8,4,17,53,1,32,9,16,1,2,0,32,53,0,49,32,16,2,9,16,1,1,33,33,53,32,4,32,17,16]

theorem envBound38926 : H12AffineFastState.Bounded env38926 := by
  intro p hp
  have h : env38926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38925_38926 : H12AffineEnvironment.transform 7 4 env38925 = env38926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env38925 == env38926) = true)

theorem identity38926 : scanCanonicalize (H12AffineFastState.compose env38926 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38926 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38927 : List Nat := [2,4,8,0,32,1,8,4,1,37,1,32,9,0,1,2,0,32,37,0,33,32,0,2,9,0,1,1,33,33,37,32,4,32,1,0]

theorem envBound38927 : H12AffineFastState.Bounded env38927 := by
  intro p hp
  have h : env38927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38926_38927 : H12AffineEnvironment.transform 3 0 env38926 = env38927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38926 == env38927) = true)

theorem identity38927 : scanCanonicalize (H12AffineFastState.compose env38927 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38927 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env38928 : List Nat := [2,4,8,0,1,1,8,4,1,4,1,1,9,0,1,2,0,1,4,0,0,1,0,2,9,0,1,1,0,0,4,1,4,1,1,0]

theorem envBound38928 : H12AffineFastState.Bounded env38928 := by
  intro p hp
  have h : env38928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38927_38928 : H12AffineEnvironment.transform 4 1 env38927 = env38928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38927 == env38928) = true)

theorem identity38928 : scanCanonicalize (H12AffineFastState.compose env38928 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound38928 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38929 : List Nat := [2,4,2,0,1,1,2,4,1,4,1,1,3,0,1,2,0,1,4,0,0,1,0,2,3,0,1,1,0,0,4,1,4,1,1,0]

theorem envBound38929 : H12AffineFastState.Bounded env38929 := by
  intro p hp
  have h : env38929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38928_38929 : H12AffineEnvironment.transform 2 2 env38928 = env38929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env38928 == env38929) = true)

def env38930 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179513,1024,32769,4160,4194304,16,21763,8193,65,4258940,5392,17664,32041,1364,4256860,256,21793,46093,63068]

theorem envBound38930 : H12AffineFastState.Bounded env38930 := by
  intro p hp
  have h : env38930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38914_38930 : H12AffineEnvironment.transform 6 9 env38914 = env38930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38914 == env38930) = true)

theorem identity38930 : scanCanonicalize (H12AffineFastState.compose env38930 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound38930 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38931 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,13388,35189,1024,32769,4160,4194304,16,21763,8193,65,4258940,5392,17664,32041,1364,4256860,256,21793,46093,63068]

theorem envBound38931 : H12AffineFastState.Bounded env38931 := by
  intro p hp
  have h : env38931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38930_38931 : H12AffineEnvironment.transform 16 13388 env38930 = env38931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env38930 == env38931) = true)

theorem identity38931 : scanCanonicalize (H12AffineFastState.compose env38931 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound38931 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env38932 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,33111,13388,35189,1024,32769,4160,4194304,16,2,8193,65,4237693,5392,4097,10280,1364,4235613,256,32,46093,41821]

theorem envBound38932 : H12AffineFastState.Bounded env38932 := by
  intro p hp
  have h : env38932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38931_38932 : H12AffineEnvironment.transform 13 5377 env38931 = env38932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env38931 == env38932) = true)

theorem identity38932 : scanCanonicalize (H12AffineFastState.compose env38932 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound38932 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env38933 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,33111,5220,35189,1024,32769,4160,4194304,16,2,41,65,4229461,5392,4097,2048,1364,4227445,256,32,37925,33653]

theorem envBound38933 : H12AffineFastState.Bounded env38933 := by
  intro p hp
  have h : env38933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38932_38933 : H12AffineEnvironment.transform 12 40 env38932 = env38933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env38932 == env38933) = true)

theorem identity38933 : scanCanonicalize (H12AffineFastState.compose env38933 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound38933 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env38934 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,32768,33111,5220,35189,1024,32769,4160,32,16,2,41,65,35189,5392,4097,2048,1364,33109,256,32,37925,33653]

theorem envBound38934 : H12AffineFastState.Bounded env38934 := by
  intro p hp
  have h : env38934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38933_38934 : H12AffineEnvironment.transform 21 32 env38933 = env38934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env38933 == env38934) = true)

theorem identity38934 : scanCanonicalize (H12AffineFastState.compose env38934 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(14+1) ^^^ 33) := by decide +kernel

theorem selectedBound38934 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env38935 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5377,33,374,5220,2388,1024,32,4160,32,16,2,41,65,2388,5392,4097,2048,1364,372,256,32,5124,852]

theorem envBound38935 : H12AffineFastState.Bounded env38935 := by
  intro p hp
  have h : env38935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38934_38935 : H12AffineEnvironment.transform 14 33 env38934 = env38935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 33 env38934 == env38935) = true)

theorem identity38935 : scanCanonicalize (H12AffineFastState.compose env38935 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound38935 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env38936 : List Nat := [2,4,8,16,32,64,9,85,512,1024,2048,4096,40,5204,33,35,5220,2049,1024,32,4160,32,16,2,41,65,2049,5189,4097,2048,1025,33,85,32,5124,513]

theorem envBound38936 : H12AffineFastState.Bounded env38936 := by
  intro p hp
  have h : env38936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38935_38936 : H12AffineEnvironment.transform 7 85 env38935 = env38936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env38935 == env38936) = true)

theorem identity38936 : scanCanonicalize (H12AffineFastState.compose env38936 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound38936 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38937 : List Nat := [2,4,8,16,32,48,9,37,512,1024,2048,4096,40,5156,33,35,5140,2049,1024,32,4144,32,16,2,41,49,2049,5173,4097,2048,1025,33,37,32,5124,513]

theorem envBound38937 : H12AffineFastState.Bounded env38937 := by
  intro p hp
  have h : env38937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38936_38937 : H12AffineEnvironment.transform 5 48 env38936 = env38937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env38936 == env38937) = true)

theorem identity38937 : scanCanonicalize (H12AffineFastState.compose env38937 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound38937 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env38938 : List Nat := [2,4,8,16,32,48,9,37,512,1024,513,4096,40,5156,33,35,5140,512,1024,32,4144,32,16,2,41,49,512,5173,4097,513,1025,33,37,32,5124,513]

theorem envBound38938 : H12AffineFastState.Bounded env38938 := by
  intro p hp
  have h : env38938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38937_38938 : H12AffineEnvironment.transform 10 513 env38937 = env38938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env38937 == env38938) = true)

theorem identity38938 : scanCanonicalize (H12AffineFastState.compose env38938 (packedSelected [3,5] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound38938 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38939 : List Nat := [2,4,8,0,32,32,9,37,512,1024,513,4096,40,5156,33,35,5124,512,1024,32,4128,32,0,2,41,33,512,5157,4097,513,1025,33,37,32,5124,513]

theorem envBound38939 : H12AffineFastState.Bounded env38939 := by
  intro p hp
  have h : env38939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38938_38939 : H12AffineEnvironment.transform 3 0 env38938 = env38939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env38938 == env38939) = true)

theorem identity38939 : scanCanonicalize (H12AffineFastState.compose env38939 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound38939 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env38940 : List Nat := [2,4,8,0,1,1,9,4,512,1024,513,4096,9,5125,0,2,5124,512,1024,1,4097,1,0,2,8,0,512,5124,4097,513,1025,0,4,1,5124,513]

theorem envBound38940 : H12AffineFastState.Bounded env38940 := by
  intro p hp
  have h : env38940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38939_38940 : H12AffineEnvironment.transform 4 1 env38939 = env38940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env38939 == env38940) = true)

theorem identity38940 : scanCanonicalize (H12AffineFastState.compose env38940 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound38940 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38941 : List Nat := [2,4,8,0,1,1,9,4,512,5,513,4096,9,4096,0,2,4097,512,5,1,4097,1,0,2,8,0,512,4097,4097,513,4,0,4,1,4097,513]

theorem envBound38941 : H12AffineFastState.Bounded env38941 := by
  intro p hp
  have h : env38941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38940_38941 : H12AffineEnvironment.transform 9 5 env38940 = env38941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env38940 == env38941) = true)

theorem identity38941 : scanCanonicalize (H12AffineFastState.compose env38941 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound38941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38942 : List Nat := [2,1,8,0,1,1,9,1,512,0,513,4096,9,4096,0,2,4097,512,0,1,4097,1,0,2,8,0,512,4097,4097,513,1,0,1,1,4097,513]

theorem envBound38942 : H12AffineFastState.Bounded env38942 := by
  intro p hp
  have h : env38942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38941_38942 : H12AffineEnvironment.transform 1 1 env38941 = env38942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env38941 == env38942) = true)

theorem identity38942 : scanCanonicalize (H12AffineFastState.compose env38942 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2) := by decide +kernel

theorem selectedBound38942 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38943 : List Nat := [2,1,8,0,1,1,9,1,512,0,513,2,9,2,0,2,3,512,0,1,3,1,0,2,8,0,512,3,3,513,1,0,1,1,3,513]

theorem envBound38943 : H12AffineFastState.Bounded env38943 := by
  intro p hp
  have h : env38943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38942_38943 : H12AffineEnvironment.transform 11 2 env38942 = env38943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2 env38942 == env38943) = true)

theorem identity38943 : scanCanonicalize (H12AffineFastState.compose env38943 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound38943 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env38944 : List Nat := [2,1,3,0,1,1,2,1,512,0,513,2,2,2,0,2,3,512,0,1,3,1,0,2,3,0,512,3,3,513,1,0,1,1,3,513]

theorem envBound38944 : H12AffineFastState.Bounded env38944 := by
  intro p hp
  have h : env38944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38943_38944 : H12AffineEnvironment.transform 2 3 env38943 = env38944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env38943 == env38944) = true)

def env38945 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,17,98780,8328,65,4258941,5393,17664,32161,1500,4256861,256,21793,46212,74251]

theorem envBound38945 : H12AffineFastState.Bounded env38945 := by
  intro p hp
  have h : env38945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38912_38945 : H12AffineEnvironment.transform 20 4161 env38912 = env38945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38912 == env38945) = true)

theorem identity38945 : scanCanonicalize (H12AffineFastState.compose env38945 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 213487) := by decide +kernel

theorem selectedBound38945 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38946 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,213487,17,98780,8328,65,245138,5393,17664,32161,1500,243122,256,21793,46212,74251]

theorem envBound38946 : H12AffineFastState.Bounded env38946 := by
  intro p hp
  have h : env38946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38945_38946 : H12AffineEnvironment.transform 21 213487 env38945 = env38946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 213487 env38945 == env38946) = true)

def env38947 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4161,213351,17,98644,8192,65,245018,5393,17664,32041,1364,243002,256,21793,46092,74251]

theorem envBound38947 : H12AffineFastState.Bounded env38947 := by
  intro p hp
  have h : env38947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38946_38947 : H12AffineEnvironment.transform 6 8 env38946 = env38947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38946 == env38947) = true)

theorem identity38947 : scanCanonicalize (H12AffineFastState.compose env38947 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound38947 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38948 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,179512,1024,32769,4161,201831,17,98644,8192,65,245018,5393,4096,10281,1364,243002,256,33,46092,74251]

theorem envBound38948 : H12AffineFastState.Bounded env38948 := by
  intro p hp
  have h : env38948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38947_38948 : H12AffineEnvironment.transform 13 5376 env38947 = env38948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env38947 == env38948) = true)

theorem identity38948 : scanCanonicalize (H12AffineFastState.compose env38948 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound38948 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env38949 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,65536,131072,171109,1024,32769,4161,201831,17,98644,349,65,236615,5393,4096,2420,1364,234599,256,33,38225,66390]

theorem envBound38949 : H12AffineFastState.Bounded env38949 := by
  intro p hp
  have h : env38949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38948_38949 : H12AffineEnvironment.transform 12 349 env38948 = env38949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env38948 == env38949) = true)

theorem identity38949 : scanCanonicalize (H12AffineFastState.compose env38949 (packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound38949 : packedSelected [1,3,4,8,9,10,12,14,15,16,24] rootPS < 2^1333 := by decide +kernel

def env38950 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,65536,131072,138341,1024,1,4161,201831,17,65876,349,65,203847,5393,4096,2420,1364,201831,256,33,5457,66390]

theorem envBound38950 : H12AffineFastState.Bounded env38950 := by
  intro p hp
  have h : env38950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38949_38950 : H12AffineEnvironment.transform 14 0 env38949 = env38950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env38949 == env38950) = true)

theorem identity38950 : scanCanonicalize (H12AffineFastState.compose env38950 (packedSelected [0,1,3,4,5,6,7,9,12,15,19,28] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound38950 : packedSelected [0,1,3,4,5,6,7,9,12,15,19,28] rootPS < 2^1333 := by decide +kernel

def env38951 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,65536,70679,67698,1024,1,4161,112,17,65876,349,65,2128,5393,4096,2420,1364,112,256,33,5457,66390]

theorem envBound38951 : H12AffineFastState.Bounded env38951 := by
  intro p hp
  have h : env38951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38950_38951 : H12AffineEnvironment.transform 16 70679 env38950 = env38951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env38950 == env38951) = true)

theorem identity38951 : scanCanonicalize (H12AffineFastState.compose env38951 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound38951 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env38952 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,262,5393,2420,1024,1,4161,112,17,82,349,65,2128,5393,4096,2420,1364,112,256,33,5457,592]

theorem envBound38952 : H12AffineFastState.Bounded env38952 := by
  intro p hp
  have h : env38952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38951_38952 : H12AffineEnvironment.transform 15 262 env38951 = env38952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env38951 == env38952) = true)

theorem identity38952 : scanCanonicalize (H12AffineFastState.compose env38952 (packedSelected [3,5] rootPS)) = affineNative (2^(11+1) ^^^ 3189) := by decide +kernel

theorem selectedBound38952 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env38953 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3189,349,2421,0,262,2404,2420,1024,1,3124,112,17,82,349,65,2128,2404,3189,2420,1364,112,256,33,2340,592]

theorem envBound38953 : H12AffineFastState.Bounded env38953 := by
  intro p hp
  have h : env38953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38952_38953 : H12AffineEnvironment.transform 11 3189 env38952 = env38953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3189 env38952 == env38953) = true)

theorem identity38953 : scanCanonicalize (H12AffineFastState.compose env38953 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound38953 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env38954 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,3189,41,2049,0,114,2064,2048,1024,1,3124,112,17,82,41,65,2128,2064,3189,2048,1056,112,116,33,2128,592]

theorem envBound38954 : H12AffineFastState.Bounded env38954 := by
  intro p hp
  have h : env38954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38953_38954 : H12AffineEnvironment.transform 7 116 env38953 = env38954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env38953 == env38954) = true)

def env38955 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4161,213350,17,98645,8193,65,245019,5393,17664,32040,1365,243003,256,21793,46093,74251]

theorem envBound38955 : H12AffineFastState.Bounded env38955 := by
  intro p hp
  have h : env38955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38946_38955 : H12AffineEnvironment.transform 6 9 env38946 = env38955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38946 == env38955) = true)

theorem identity38955 : scanCanonicalize (H12AffineFastState.compose env38955 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38955 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38956 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138341,1024,8541,4161,213350,17,73737,8193,65,203847,5393,17664,32040,1365,201831,256,21793,5457,74251]

theorem envBound38956 : H12AffineFastState.Bounded env38956 := by
  intro p hp
  have h : env38956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38955_38956 : H12AffineEnvironment.transform 14 8540 env38955 = env38956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38955 == env38956) = true)

theorem identity38956 : scanCanonicalize (H12AffineFastState.compose env38956 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 90186) := by decide +kernel

theorem selectedBound38956 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env38957 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90186,97327,1024,8541,4161,8492,17,73737,8193,65,31757,5393,17664,32040,1365,29741,256,21793,5457,74251]

theorem envBound38957 : H12AffineFastState.Bounded env38957 := by
  intro p hp
  have h : env38957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38956_38957 : H12AffineEnvironment.transform 16 90186 env38956 = env38957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90186 env38956 == env38957) = true)

theorem identity38957 : scanCanonicalize (H12AffineFastState.compose env38957 (packedSelected [1,5,8,16,18,20,23,24] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound38957 : packedSelected [1,5,8,16,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env38958 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,8540,65536,79130,76159,1024,8541,4161,8492,17,73737,8193,65,10589,5393,4176,10360,1365,8573,256,113,5457,74251]

theorem envBound38958 : H12AffineFastState.Bounded env38958 := by
  intro p hp
  have h : env38958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38957_38958 : H12AffineEnvironment.transform 13 5456 env38957 = env38958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env38957 == env38958) = true)

theorem identity38958 : scanCanonicalize (H12AffineFastState.compose env38958 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound38958 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env38959 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5456,81,65536,70679,67698,1024,80,4161,33,17,65796,268,65,2128,5393,4176,2421,1365,112,256,113,5457,66310]

theorem envBound38959 : H12AffineFastState.Bounded env38959 := by
  intro p hp
  have h : env38959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38958_38959 : H12AffineEnvironment.transform 12 269 env38958 = env38959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env38958 == env38959) = true)

theorem identity38959 : scanCanonicalize (H12AffineFastState.compose env38959 (packedSelected [0,2,4,6,7,9,12,14] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound38959 : packedSelected [0,2,4,6,7,9,12,14] rootPS < 2^1333 := by decide +kernel

def env38960 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,4096,269,4160,81,65536,69895,67698,272,80,4161,33,17,65796,268,65,2128,4097,4176,2421,69,112,256,113,4161,66310]

theorem envBound38960 : H12AffineFastState.Bounded env38960 := by
  intro p hp
  have h : env38960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38959_38960 : H12AffineEnvironment.transform 9 272 env38959 = env38960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env38959 == env38960) = true)

theorem identity38960 : scanCanonicalize (H12AffineFastState.compose env38960 (packedSelected [1,2,4,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound38960 : packedSelected [1,2,4,8,9] rootPS < 2^1333 := by decide +kernel

def env38961 : List Nat := [2,4,8,16,32,64,9,85,512,69,2048,4096,88,4160,81,65536,69714,67698,69,80,4161,33,17,65617,89,65,2128,4097,4176,2080,69,112,85,113,4161,66131]

theorem envBound38961 : H12AffineFastState.Bounded env38961 := by
  intro p hp
  have h : env38961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38960_38961 : H12AffineEnvironment.transform 7 85 env38960 = env38961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env38960 == env38961) = true)

theorem identity38961 : scanCanonicalize (H12AffineFastState.compose env38961 (packedSelected [0,1,2,6,7,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38961 : packedSelected [0,1,2,6,7,8,12] rootPS < 2^1333 := by decide +kernel

def env38962 : List Nat := [2,4,8,16,32,17,9,4,512,20,2048,4096,9,4113,0,65536,69635,67619,20,1,4112,33,17,65536,8,16,2049,4097,4097,2080,20,33,4,32,4112,66050]

theorem envBound38962 : H12AffineFastState.Bounded env38962 := by
  intro p hp
  have h : env38962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38961_38962 : H12AffineEnvironment.transform 5 17 env38961 = env38962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38961 == env38962) = true)

theorem identity38962 : scanCanonicalize (H12AffineFastState.compose env38962 (packedSelected [0,2,4] rootPS)) = affineNative (2^(15+1) ^^^ 4610) := by decide +kernel

theorem selectedBound38962 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env38963 : List Nat := [2,4,8,16,32,17,9,4,512,20,2048,4096,9,4113,0,4610,513,6689,20,1,4112,33,17,4610,8,16,2049,4097,4097,2080,20,33,4,32,4112,4096]

theorem envBound38963 : H12AffineFastState.Bounded env38963 := by
  intro p hp
  have h : env38963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38962_38963 : H12AffineEnvironment.transform 15 4610 env38962 = env38963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4610 env38962 == env38963) = true)

theorem identity38963 : scanCanonicalize (H12AffineFastState.compose env38963 (packedSelected [3,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound38963 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env38964 : List Nat := [2,4,8,16,32,17,9,4,512,20,2048,513,9,528,0,3,513,2080,20,1,529,33,17,3,8,16,2049,512,512,2080,20,33,4,32,529,513]

theorem envBound38964 : H12AffineFastState.Bounded env38964 := by
  intro p hp
  have h : env38964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38963_38964 : H12AffineEnvironment.transform 11 513 env38963 = env38964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env38963 == env38964) = true)

theorem identity38964 : scanCanonicalize (H12AffineFastState.compose env38964 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound38964 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38965 : List Nat := [2,4,8,16,16,17,9,4,512,20,2048,513,9,528,0,3,513,2064,20,1,529,17,17,3,8,16,2049,512,512,2064,20,17,4,16,529,513]

theorem envBound38965 : H12AffineFastState.Bounded env38965 := by
  intro p hp
  have h : env38965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38964_38965 : H12AffineEnvironment.transform 4 16 env38964 = env38965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env38964 == env38965) = true)

theorem identity38965 : scanCanonicalize (H12AffineFastState.compose env38965 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 27) := by decide +kernel

theorem selectedBound38965 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38966 : List Nat := [2,4,8,16,16,17,9,4,512,20,27,513,9,528,0,3,513,11,20,1,529,17,17,3,8,16,26,512,512,11,20,17,4,16,529,513]

theorem envBound38966 : H12AffineFastState.Bounded env38966 := by
  intro p hp
  have h : env38966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38965_38966 : H12AffineEnvironment.transform 10 27 env38965 = env38966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env38965 == env38966) = true)

def env38967 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,2097152,4194304,2101329,98781,8328,65,6351933,2098513,17665,2125280,2102685,6349853,256,21793,46212,2175562]

theorem envBound38967 : H12AffineFastState.Bounded env38967 := by
  intro p hp
  have h : env38967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38911_38967 : H12AffineEnvironment.transform 17 179633 env38911 = env38967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179633 env38911 == env38967) = true)

def env38968 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,4194304,17,98781,8328,65,4258941,5393,17665,32160,1501,4256861,256,21793,46212,74250]

theorem envBound38968 : H12AffineFastState.Bounded env38968 := by
  intro p hp
  have h : env38968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38967_38968 : H12AffineEnvironment.transform 20 4160 env38967 = env38968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env38967 == env38968) = true)

theorem identity38968 : scanCanonicalize (H12AffineFastState.compose env38968 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 243003) := by decide +kernel

theorem selectedBound38968 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env38969 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4160,243003,17,98781,8328,65,215366,5393,17665,32160,1501,213350,256,21793,46212,74250]

theorem envBound38969 : H12AffineFastState.Bounded env38969 := by
  intro p hp
  have h : env38969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38968_38969 : H12AffineEnvironment.transform 21 243003 env38968 = env38969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 243003 env38968 == env38969) = true)

def env38970 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,243003,17,98645,8192,65,215366,5393,17665,32040,1365,213350,256,21793,46092,74250]

theorem envBound38970 : H12AffineFastState.Bounded env38970 := by
  intro p hp
  have h : env38970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38969_38970 : H12AffineEnvironment.transform 6 8 env38969 = env38970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env38969 == env38970) = true)

theorem identity38970 : scanCanonicalize (H12AffineFastState.compose env38970 (packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS)) = affineNative (2^(16+1) ^^^ 114967) := by decide +kernel

theorem selectedBound38970 : packedSelected [1,3,4,8,9,10,12,14,16,18,19,23,24,26,38] rootPS < 2^1333 := by decide +kernel

def env38971 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,114967,97326,1024,32769,4160,29740,17,98645,8192,65,34897,5393,17665,32040,1365,32881,256,21793,46092,74250]

theorem envBound38971 : H12AffineFastState.Bounded env38971 := by
  intro p hp
  have h : env38971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38970_38971 : H12AffineEnvironment.transform 16 114967 env38970 = env38971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114967 env38970 == env38971) = true)

theorem identity38971 : scanCanonicalize (H12AffineFastState.compose env38971 (packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound38971 : packedSelected [3,5,7,12,14,15,16,19,26,27,31] rootPS < 2^1333 := by decide +kernel

def env38972 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,57628,23589,1024,32769,4160,29740,17,41310,8192,65,34897,5393,17665,32040,1365,32881,256,21793,46092,513]

theorem envBound38972 : H12AffineFastState.Bounded env38972 := by
  intro p hp
  have h : env38972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38971_38972 : H12AffineEnvironment.transform 15 8203 env38971 = env38972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env38971 == env38972) = true)

theorem identity38972 : scanCanonicalize (H12AffineFastState.compose env38972 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound38972 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env38973 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8460,8203,16400,23589,1024,8461,4160,29740,17,82,8192,65,10589,5393,17665,32040,1365,8573,256,21793,5376,513]

theorem envBound38973 : H12AffineFastState.Bounded env38973 := by
  intro p hp
  have h : env38973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38972_38973 : H12AffineEnvironment.transform 14 8460 env38972 = env38973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env38972 == env38973) = true)

theorem identity38973 : scanCanonicalize (H12AffineFastState.compose env38973 (packedSelected [0,2,9,10,12,18] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound38973 : packedSelected [0,2,9,10,12,18] rootPS < 2^1333 := by decide +kernel

def env38974 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,16384,8312,8203,16400,23589,1024,8313,4160,29740,17,82,8192,65,10281,5221,17525,31836,1057,8201,116,21589,5236,513]

theorem envBound38974 : H12AffineFastState.Bounded env38974 := by
  intro p hp
  have h : env38974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38973_38974 : H12AffineEnvironment.transform 7 116 env38973 = env38974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env38973 == env38974) = true)

theorem identity38974 : scanCanonicalize (H12AffineFastState.compose env38974 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound38974 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38975 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,16384,81,34,16400,23589,1024,80,4160,21509,17,82,41,65,2048,5221,17525,23669,1057,32,116,21589,5236,513]

theorem envBound38975 : H12AffineFastState.Bounded env38975 := by
  intro p hp
  have h : env38975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38974_38975 : H12AffineEnvironment.transform 12 41 env38974 = env38975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env38974 == env38975) = true)

theorem identity38975 : scanCanonicalize (H12AffineFastState.compose env38975 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound38975 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env38976 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,41,5156,81,34,5172,2049,1024,80,4160,33,17,82,41,65,2048,5221,4177,2129,1057,32,116,113,5236,513]

theorem envBound38976 : H12AffineFastState.Bounded env38976 := by
  intro p hp
  have h : env38976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38975_38976 : H12AffineEnvironment.transform 13 5156 env38975 = env38976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env38975 == env38976) = true)

theorem identity38976 : scanCanonicalize (H12AffineFastState.compose env38976 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound38976 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38977 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,41,5156,1,34,5172,2049,1024,0,4112,33,17,2,41,17,2048,5173,4097,2049,1057,32,36,33,5156,513]

theorem envBound38977 : H12AffineFastState.Bounded env38977 := by
  intro p hp
  have h : env38977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38976_38977 : H12AffineEnvironment.transform 5 16 env38976 = env38977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env38976 == env38977) = true)

def env38978 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,48,41,1044,1,34,1028,2049,1024,0,32,33,17,2,41,17,2048,1029,49,2049,1057,32,36,33,1044,513]

theorem envBound38978 : H12AffineFastState.Bounded env38978 := by
  intro p hp
  have h : env38978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38977_38978 : H12AffineEnvironment.transform 11 48 env38977 = env38978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env38977 == env38978) = true)

theorem identity38978 : scanCanonicalize (H12AffineFastState.compose env38978 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 516) := by decide +kernel

theorem selectedBound38978 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38979 : List Nat := [2,4,8,16,32,16,8,36,512,516,2048,48,41,528,1,34,512,2049,516,0,32,33,17,2,41,17,2048,513,49,2049,549,32,36,33,528,513]

theorem envBound38979 : H12AffineFastState.Bounded env38979 := by
  intro p hp
  have h : env38979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38978_38979 : H12AffineEnvironment.transform 9 516 env38978 = env38979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 516 env38978 == env38979) = true)

def env38980 : List Nat := [2,4,8,16,32,16,8,36,48,52,2048,48,41,32,1,34,48,2049,52,0,32,33,17,2,41,17,2048,49,49,2049,21,32,36,33,32,49]

theorem envBound38980 : H12AffineFastState.Bounded env38980 := by
  intro p hp
  have h : env38980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38979_38980 : H12AffineEnvironment.transform 8 48 env38979 = env38980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env38979 == env38980) = true)

theorem identity38980 : scanCanonicalize (H12AffineFastState.compose env38980 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38980 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38981 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,42,41,32,1,34,42,2049,46,0,32,33,11,2,41,11,2048,43,43,2049,15,32,36,33,32,43]

theorem envBound38981 : H12AffineFastState.Bounded env38981 := by
  intro p hp
  have h : env38981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38980_38981 : H12AffineEnvironment.transform 3 10 env38980 = env38981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38980 == env38981) = true)

def leafEnv38981 : List Nat := [2,4,8,10,32,10,8,36,42,46,2048,42,41,32,1,34,42,2049,46,0,32,33,11,2,15,41,1,11,2048,43,43,2049,15,32,36,33,4,34,32,43,1,32,0]

def active38981 : List Nat := [0,1,2,4,10]

def tree38981 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38981 : H12WitnessSearch.Good tree38981 := H12GlobalWitnessIndex.good

theorem leafIdentity38981 : H12AffineFastState.composeSystem env38981 rootObs = leafEnv38981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38981 rootObs == leafEnv38981) = true)

theorem terminalChecked38981 : H12PackedTerminal.terminalCheckFast leafEnv38981 active38981 tree38981 = true := by decide +kernel

def env38982 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,48,41,33,1,34,49,2049,53,0,32,33,17,2,41,17,2048,48,49,2049,20,32,36,33,33,48]

theorem envBound38982 : H12AffineFastState.Bounded env38982 := by
  intro p hp
  have h : env38982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38979_38982 : H12AffineEnvironment.transform 8 49 env38979 = env38982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38979 == env38982) = true)

def env38983 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,49,41,1045,1,34,1029,2049,1024,0,33,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,513]

theorem envBound38983 : H12AffineFastState.Bounded env38983 := by
  intro p hp
  have h : env38983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38977_38983 : H12AffineEnvironment.transform 11 49 env38977 = env38983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env38977 == env38983) = true)

theorem identity38983 : scanCanonicalize (H12AffineFastState.compose env38983 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 49) := by decide +kernel

theorem selectedBound38983 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env38984 : List Nat := [2,4,8,16,32,16,8,36,49,1024,2048,49,41,1045,1,34,1029,2049,1024,0,33,33,17,2,41,17,2048,1028,48,2049,1057,32,36,33,1045,48]

theorem envBound38984 : H12AffineFastState.Bounded env38984 := by
  intro p hp
  have h : env38984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38983_38984 : H12AffineEnvironment.transform 8 49 env38983 = env38984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 49 env38983 == env38984) = true)

def env38985 : List Nat := [2,4,8,16,32,16,8,36,49,52,2048,49,41,33,1,34,49,2049,52,0,33,33,17,2,41,17,2048,48,48,2049,21,32,36,33,33,48]

theorem envBound38985 : H12AffineFastState.Bounded env38985 := by
  intro p hp
  have h : env38985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38984_38985 : H12AffineEnvironment.transform 9 52 env38984 = env38985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env38984 == env38985) = true)

theorem identity38985 : scanCanonicalize (H12AffineFastState.compose env38985 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound38985 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38986 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,43,41,33,1,34,43,2049,46,0,33,33,11,2,41,11,2048,42,42,2049,15,32,36,33,33,42]

theorem envBound38986 : H12AffineFastState.Bounded env38986 := by
  intro p hp
  have h : env38986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38985_38986 : H12AffineEnvironment.transform 3 10 env38985 = env38986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env38985 == env38986) = true)

def leafEnv38986 : List Nat := [2,4,8,10,32,10,8,36,43,46,2048,43,41,33,1,34,43,2049,46,0,33,33,11,2,15,41,1,11,2048,42,42,2049,15,32,36,33,4,34,33,42,1,33,0]

def active38986 : List Nat := [0,1,2,4,10]

def tree38986 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood38986 : H12WitnessSearch.Good tree38986 := H12GlobalWitnessIndex.good

theorem leafIdentity38986 : H12AffineFastState.composeSystem env38986 rootObs = leafEnv38986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env38986 rootObs == leafEnv38986) = true)

theorem terminalChecked38986 : H12PackedTerminal.terminalCheckFast leafEnv38986 active38986 tree38986 = true := by decide +kernel

def env38987 : List Nat := [2,4,8,16,32,16,8,36,49,53,2048,49,41,32,1,34,48,2049,53,0,33,33,17,2,41,17,2048,49,48,2049,20,32,36,33,32,48]

theorem envBound38987 : H12AffineFastState.Bounded env38987 := by
  intro p hp
  have h : env38987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38984_38987 : H12AffineEnvironment.transform 9 53 env38984 = env38987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38984 == env38987) = true)

def env38988 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,243003,17,98644,8193,65,215366,5393,17665,32041,1364,213350,256,21793,46093,74250]

theorem envBound38988 : H12AffineFastState.Bounded env38988 := by
  intro p hp
  have h : env38988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38969_38988 : H12AffineEnvironment.transform 6 9 env38969 = env38988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env38969 == env38988) = true)

theorem identity38988 : scanCanonicalize (H12AffineFastState.compose env38988 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound38988 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env38989 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,138340,1024,8541,4160,201831,17,73736,8193,65,215366,5393,17665,32041,1364,213350,256,21793,5457,74250]

theorem envBound38989 : H12AffineFastState.Bounded env38989 := by
  intro p hp
  have h : env38989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38988_38989 : H12AffineEnvironment.transform 14 8540 env38988 = env38989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env38988 == env38989) = true)

theorem identity38989 : scanCanonicalize (H12AffineFastState.compose env38989 (packedSelected [0,1,6,7,10,14,20,26,28] rootPS)) = affineNative (2^(16+1) ^^^ 90431) := by decide +kernel

theorem selectedBound38989 : packedSelected [0,1,6,7,10,14,20,26,28] rootPS < 2^1333 := by decide +kernel

def env38990 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,90431,97627,1024,8541,4160,30040,17,73736,8193,65,10361,5393,17665,32041,1364,8281,256,21793,5457,74250]

theorem envBound38990 : H12AffineFastState.Bounded env38990 := by
  intro p hp
  have h : env38990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38989_38990 : H12AffineEnvironment.transform 16 90431 env38989 = env38990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90431 env38989 == env38990) = true)

theorem identity38990 : scanCanonicalize (H12AffineFastState.compose env38990 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 29742) := by decide +kernel

theorem selectedBound38990 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env38991 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,29742,5393,2421,1024,8541,4160,30040,17,21542,8193,65,10361,5393,17665,32041,1364,8281,256,21793,5457,22052]

theorem envBound38991 : H12AffineFastState.Bounded env38991 := by
  intro p hp
  have h : env38991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38990_38991 : H12AffineEnvironment.transform 15 29742 env38990 = env38991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29742 env38990 == env38991) = true)

theorem identity38991 : scanCanonicalize (H12AffineFastState.compose env38991 (packedSelected [2,3,5,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13689) := by decide +kernel

theorem selectedBound38991 : packedSelected [2,3,5,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env38992 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13689,8540,343,5393,2421,1024,8541,4160,33,17,8543,8193,65,10361,5393,12408,2128,1364,8281,256,8280,5457,9053]

theorem envBound38992 : H12AffineFastState.Bounded env38992 := by
  intro p hp
  have h : env38992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38991_38992 : H12AffineEnvironment.transform 13 13689 env38991 = env38992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13689 env38991 == env38992) = true)

theorem identity38992 : scanCanonicalize (H12AffineFastState.compose env38992 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound38992 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env38993 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5157,0,343,5393,2421,1024,1,4160,33,17,3,349,65,2341,5393,4388,2128,1364,261,256,260,5457,513]

theorem envBound38993 : H12AffineFastState.Bounded env38993 := by
  intro p hp
  have h : env38993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38992_38993 : H12AffineEnvironment.transform 12 348 env38992 = env38993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env38992 == env38993) = true)

theorem identity38993 : scanCanonicalize (H12AffineFastState.compose env38993 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound38993 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env38994 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,120,5157,0,115,5173,2129,1024,1,4160,33,17,3,121,65,2049,5173,4096,2128,1136,33,36,32,5237,513]

theorem envBound38994 : H12AffineFastState.Bounded env38994 := by
  intro p hp
  have h : env38994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38993_38994 : H12AffineEnvironment.transform 7 36 env38993 = env38994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env38993 == env38994) = true)

theorem identity38994 : scanCanonicalize (H12AffineFastState.compose env38994 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound38994 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env38995 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,34,5173,2048,1024,1,4113,33,17,3,40,16,2049,5173,4096,2049,1057,33,36,32,5156,513]

theorem envBound38995 : H12AffineFastState.Bounded env38995 := by
  intro p hp
  have h : env38995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38994_38995 : H12AffineEnvironment.transform 5 17 env38994 = env38995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env38994 == env38995) = true)

theorem identity38995 : scanCanonicalize (H12AffineFastState.compose env38995 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound38995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env38996 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,4096,41,4112,0,34,4096,2048,53,1,4113,33,17,3,40,16,2049,4096,4096,2049,20,33,36,32,4113,513]

theorem envBound38996 : H12AffineFastState.Bounded env38996 := by
  intro p hp
  have h : env38996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38995_38996 : H12AffineEnvironment.transform 9 53 env38995 = env38996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env38995 == env38996) = true)

theorem identity38996 : scanCanonicalize (H12AffineFastState.compose env38996 (packedSelected [1] rootPS)) = affineNative (2^(11+1) ^^^ 2058) := by decide +kernel

theorem selectedBound38996 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env38997 : List Nat := [2,4,8,16,32,17,9,36,512,53,2048,2058,41,2074,0,34,2058,2048,53,1,2075,33,17,3,40,16,2049,2058,2058,2049,20,33,36,32,2075,513]

theorem envBound38997 : H12AffineFastState.Bounded env38997 := by
  intro p hp
  have h : env38997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38996_38997 : H12AffineEnvironment.transform 11 2058 env38996 = env38997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2058 env38996 == env38997) = true)

theorem identity38997 : scanCanonicalize (H12AffineFastState.compose env38997 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound38997 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env38998 : List Nat := [2,4,8,11,32,10,9,36,512,46,2048,2058,41,2049,0,34,2058,2048,46,1,2048,33,10,3,40,11,2049,2058,2058,2049,15,33,36,32,2048,513]

theorem envBound38998 : H12AffineFastState.Bounded env38998 := by
  intro p hp
  have h : env38998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38997_38998 : H12AffineEnvironment.transform 3 11 env38997 = env38998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env38997 == env38998) = true)

def env38999 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179633,1024,32769,4161,4194304,16,98781,8328,65,4258940,5392,17665,32161,1500,4256860,256,21793,46212,74251]

theorem envBound38999 : H12AffineFastState.Bounded env38999 := by
  intro p hp
  have h : env38999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38967_38999 : H12AffineEnvironment.transform 20 4161 env38967 = env38999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env38967 == env38999) = true)

theorem identity38999 : scanCanonicalize (H12AffineFastState.compose env38999 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound38999 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4161,4194304,16,41431,8328,65,4258940,5392,17665,32161,1500,4256860,256,21793,46212,513]

theorem envBound39000 : H12AffineFastState.Bounded env39000 := by
  intro p hp
  have h : env39000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38999_39000 : H12AffineEnvironment.transform 15 8202 env38999 = env39000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env38999 == env39000) = true)

theorem identity39000 : scanCanonicalize (H12AffineFastState.compose env39000 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 169264) := by decide +kernel

theorem selectedBound39000 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env39001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179633,1024,32769,4161,169264,16,41431,8328,65,158028,5392,17665,32161,1500,156012,256,21793,46212,513]

theorem envBound39001 : H12AffineFastState.Bounded env39001 := by
  intro p hp
  have h : env39001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39000_39001 : H12AffineEnvironment.transform 21 169264 env39000 = env39001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env39000 == env39001) = true)

theorem identity39001 : scanCanonicalize (H12AffineFastState.compose env39001 (packedSelected [12,15,17,38,41] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound39001 : packedSelected [12,15,17,38,41] rootPS < 2^1333 := by decide +kernel

def env39002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,131072,179513,1024,32769,4161,169264,16,41311,8192,65,158028,5392,17665,32041,1364,156012,256,21793,46092,513]

theorem envBound39002 : H12AffineFastState.Bounded env39002 := by
  intro p hp
  have h : env39002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39001_39002 : H12AffineEnvironment.transform 6 8 env39001 = env39002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39001 == env39002) = true)

theorem identity39002 : scanCanonicalize (H12AffineFastState.compose env39002 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound39002 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,38161,10280,1024,32769,4161,33,16,41311,8192,65,64605,5392,17665,32041,1364,62589,256,21793,46092,513]

theorem envBound39003 : H12AffineFastState.Bounded env39003 := by
  intro p hp
  have h : env39003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39002_39003 : H12AffineEnvironment.transform 16 38161 env39002 = env39003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env39002 == env39003) = true)

theorem identity39003 : scanCanonicalize (H12AffineFastState.compose env39003 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound39003 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env39004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,5392,10280,1024,0,4161,33,16,8542,8192,65,31836,5392,17665,32041,1364,29820,256,21793,13325,513]

theorem envBound39004 : H12AffineFastState.Bounded env39004 := by
  intro p hp
  have h : env39004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39003_39004 : H12AffineEnvironment.transform 14 1 env39003 = env39004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env39003 == env39004) = true)

theorem identity39004 : scanCanonicalize (H12AffineFastState.compose env39004 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39004 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,342,5392,2420,1024,0,4161,33,16,2,348,65,23808,5392,17665,23669,1364,21792,256,21793,5457,513]

theorem envBound39005 : H12AffineFastState.Bounded env39005 := by
  intro p hp
  have h : env39005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39004_39005 : H12AffineEnvironment.transform 12 348 env39004 = env39005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39004 == env39005) = true)

theorem identity39005 : scanCanonicalize (H12AffineFastState.compose env39005 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound39005 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env39006 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,16384,1,342,5392,2389,1024,0,4161,0,16,2,348,65,23808,5392,17665,23636,1364,21761,256,21760,5457,513]

theorem envBound39006 : H12AffineFastState.Bounded env39006 := by
  intro p hp
  have h : env39006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39005_39006 : H12AffineEnvironment.transform 4 1 env39005 = env39006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env39005 == env39006) = true)

theorem identity39006 : scanCanonicalize (H12AffineFastState.compose env39006 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39006 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env39007 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,4096,348,5377,1,342,5392,2389,1024,0,4161,0,16,2,348,65,2049,5392,4096,2389,1364,0,256,1,5457,513]

theorem envBound39007 : H12AffineFastState.Bounded env39007 := by
  intro p hp
  have h : env39007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39006_39007 : H12AffineEnvironment.transform 13 5377 env39006 = env39007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39006 == env39007) = true)

theorem identity39007 : scanCanonicalize (H12AffineFastState.compose env39007 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1029) := by decide +kernel

theorem selectedBound39007 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39008 : List Nat := [2,4,8,16,1,64,8,256,512,1024,2048,1029,348,260,1,342,277,2389,1024,0,1092,0,16,2,348,65,2049,277,1029,2389,1364,0,256,1,340,513]

theorem envBound39008 : H12AffineFastState.Bounded env39008 := by
  intro p hp
  have h : env39008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39007_39008 : H12AffineEnvironment.transform 11 1029 env39007 = env39008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1029 env39007 == env39008) = true)

theorem identity39008 : scanCanonicalize (H12AffineFastState.compose env39008 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound39008 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39009 : List Nat := [2,4,8,16,1,64,8,256,512,1024,1,1029,348,260,1,342,277,340,1024,0,1092,0,16,2,348,65,0,277,1029,340,1364,0,256,1,340,513]

theorem envBound39009 : H12AffineFastState.Bounded env39009 := by
  intro p hp
  have h : env39009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39008_39009 : H12AffineEnvironment.transform 10 1 env39008 = env39009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env39008 == env39009) = true)

theorem identity39009 : scanCanonicalize (H12AffineFastState.compose env39009 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 336) := by decide +kernel

theorem selectedBound39009 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39010 : List Nat := [2,4,8,16,1,64,8,256,512,336,1,341,348,260,1,342,277,340,336,0,276,0,16,2,348,65,0,277,341,340,4,0,256,1,340,513]

theorem envBound39010 : H12AffineFastState.Bounded env39010 := by
  intro p hp
  have h : env39010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39009_39010 : H12AffineEnvironment.transform 9 336 env39009 = env39010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 336 env39009 == env39010) = true)

theorem identity39010 : scanCanonicalize (H12AffineFastState.compose env39010 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(8+1) ^^^ 260) := by decide +kernel

theorem selectedBound39010 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env39011 : List Nat := [2,4,8,16,1,64,8,256,260,336,1,341,348,260,1,342,277,340,336,0,276,0,16,2,348,65,0,277,341,340,4,0,256,1,340,261]

theorem envBound39011 : H12AffineFastState.Bounded env39011 := by
  intro p hp
  have h : env39011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39010_39011 : H12AffineEnvironment.transform 8 260 env39010 = env39011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 260 env39010 == env39011) = true)

theorem identity39011 : scanCanonicalize (H12AffineFastState.compose env39011 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound39011 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env39012 : List Nat := [2,4,8,1,1,64,8,256,260,321,1,324,333,260,1,327,260,325,321,0,261,0,1,2,333,65,0,260,324,325,4,0,256,1,325,261]

theorem envBound39012 : H12AffineFastState.Bounded env39012 := by
  intro p hp
  have h : env39012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39011_39012 : H12AffineEnvironment.transform 3 1 env39011 = env39012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env39011 == env39012) = true)

theorem identity39012 : scanCanonicalize (H12AffineFastState.compose env39012 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound39012 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39013 : List Nat := [2,4,8,1,1,0,8,256,260,257,1,260,269,260,1,263,260,261,257,0,261,0,1,2,269,1,0,260,260,261,4,0,256,1,261,261]

theorem envBound39013 : H12AffineFastState.Bounded env39013 := by
  intro p hp
  have h : env39013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39012_39013 : H12AffineEnvironment.transform 5 0 env39012 = env39013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env39012 == env39013) = true)

theorem identity39013 : scanCanonicalize (H12AffineFastState.compose env39013 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39013 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39014 : List Nat := [2,4,8,1,1,0,8,5,1,4,1,1,8,1,1,2,1,0,4,0,0,0,1,2,8,1,0,1,1,0,4,0,5,1,0,0]

theorem envBound39014 : H12AffineFastState.Bounded env39014 := by
  intro p hp
  have h : env39014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39013_39014 : H12AffineEnvironment.transform 7 5 env39013 = env39014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39013 == env39014) = true)

def env39015 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2534880,474221,8328,65,6705549,2537697,456880,2125280,2102684,6707629,256,21792,46213,2175563]

theorem envBound39015 : H12AffineFastState.Bounded env39015 := by
  intro p hp
  have h : env39015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans38910_39015 : H12AffineEnvironment.transform 23 474221 env38910 = env39015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 474221 env38910 == env39015) = true)

def env39016 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,2097152,4194304,2101328,98781,8328,65,6351933,2098513,17664,2125280,2102684,6349853,256,21792,46213,2175563]

theorem envBound39016 : H12AffineFastState.Bounded env39016 := by
  intro p hp
  have h : env39016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39015_39016 : H12AffineEnvironment.transform 17 179632 env39015 = env39016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env39015 == env39016) = true)

def env39017 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4160,4194304,16,98781,8328,65,4258941,5393,17664,32160,1500,4256861,256,21792,46213,74251]

theorem envBound39017 : H12AffineFastState.Bounded env39017 := by
  intro p hp
  have h : env39017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39016_39017 : H12AffineEnvironment.transform 20 4160 env39016 = env39017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env39016 == env39017) = true)

def env39018 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179512,1024,32769,4160,4194304,16,98645,8192,65,4258941,5393,17664,32040,1364,4256861,256,21792,46093,74251]

theorem envBound39018 : H12AffineFastState.Bounded env39018 := by
  intro p hp
  have h : env39018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39017_39018 : H12AffineEnvironment.transform 6 8 env39017 = env39018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env39017 == env39018) = true)

theorem identity39018 : scanCanonicalize (H12AffineFastState.compose env39018 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound39018 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39019 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4160,4194304,16,98645,8192,65,4258941,5393,17664,32040,1364,4256861,256,21792,46093,74251]

theorem envBound39019 : H12AffineFastState.Bounded env39019 := by
  intro p hp
  have h : env39019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39018_39019 : H12AffineEnvironment.transform 16 38160 env39018 = env39019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env39018 == env39019) = true)

theorem identity39019 : scanCanonicalize (H12AffineFastState.compose env39019 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound39019 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env39020 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10280,1024,32769,4160,33,16,98645,8192,65,64604,5393,17664,32040,1364,62588,256,21792,46093,74251]

theorem envBound39020 : H12AffineFastState.Bounded env39020 := by
  intro p hp
  have h : env39020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39019_39020 : H12AffineEnvironment.transform 21 33 env39019 = env39020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env39019 == env39020) = true)

theorem identity39020 : scanCanonicalize (H12AffineFastState.compose env39020 (packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound39020 : packedSelected [0,1,2,3,4,5,6,8,9,10,11,18,19,20,27] rootPS < 2^1333 := by decide +kernel

def env39021 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38160,10280,1024,32769,4160,33,16,98645,8192,65,43357,5393,4097,10281,1364,41341,256,33,46093,74251]

theorem envBound39021 : H12AffineFastState.Bounded env39021 := by
  intro p hp
  have h : env39021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39020_39021 : H12AffineEnvironment.transform 13 5377 env39020 = env39021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env39020 == env39021) = true)

theorem identity39021 : scanCanonicalize (H12AffineFastState.compose env39021 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound39021 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env39022 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,40970,38160,10280,1024,32769,4160,33,16,8543,8192,65,43357,5393,4097,10281,1364,41341,256,33,46093,33281]

theorem envBound39022 : H12AffineFastState.Bounded env39022 := by
  intro p hp
  have h : env39022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39021_39022 : H12AffineEnvironment.transform 15 40970 env39021 = env39022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env39021 == env39022) = true)

theorem identity39022 : scanCanonicalize (H12AffineFastState.compose env39022 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound39022 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env39023 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,0,8202,5392,10280,1024,1,4160,33,16,8543,8192,65,10589,5393,4097,10281,1364,8573,256,33,13325,513]

theorem envBound39023 : H12AffineFastState.Bounded env39023 := by
  intro p hp
  have h : env39023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39022_39023 : H12AffineEnvironment.transform 14 0 env39022 = env39023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env39022 == env39023) = true)

theorem identity39023 : scanCanonicalize (H12AffineFastState.compose env39023 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound39023 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env39024 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5377,0,342,5392,2420,1024,1,4160,33,16,3,348,65,2049,5393,4097,2421,1364,33,256,33,5457,513]

theorem envBound39024 : H12AffineFastState.Bounded env39024 := by
  intro p hp
  have h : env39024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39023_39024 : H12AffineEnvironment.transform 12 348 env39023 = env39024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env39023 == env39024) = true)

theorem identity39024 : scanCanonicalize (H12AffineFastState.compose env39024 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39024 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39025 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,0,262,5392,2340,1024,1,4112,33,16,3,268,17,2049,5393,4097,2341,1284,33,256,33,5377,513]

theorem envBound39025 : H12AffineFastState.Bounded env39025 := by
  intro p hp
  have h : env39025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39024_39025 : H12AffineEnvironment.transform 5 16 env39024 = env39025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39024 == env39025) = true)

theorem identity39025 : scanCanonicalize (H12AffineFastState.compose env39025 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1312) := by decide +kernel

theorem selectedBound39025 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env39026 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1312,268,33,0,262,48,2340,1024,1,1328,33,16,3,268,17,2049,49,1313,2341,1284,33,256,33,33,513]

theorem envBound39026 : H12AffineFastState.Bounded env39026 := by
  intro p hp
  have h : env39026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39025_39026 : H12AffineEnvironment.transform 11 1312 env39025 = env39026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1312 env39025 == env39026) = true)

theorem identity39026 : scanCanonicalize (H12AffineFastState.compose env39026 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 805) := by decide +kernel

theorem selectedBound39026 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env39027 : List Nat := [2,4,8,16,32,16,8,256,512,1024,805,1312,268,33,0,262,48,513,1024,1,1328,33,16,3,268,17,804,49,1313,512,1284,33,256,33,33,513]

theorem envBound39027 : H12AffineFastState.Bounded env39027 := by
  intro p hp
  have h : env39027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39026_39027 : H12AffineEnvironment.transform 10 805 env39026 = env39027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 805 env39026 == env39027) = true)

theorem identity39027 : scanCanonicalize (H12AffineFastState.compose env39027 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 768) := by decide +kernel

theorem selectedBound39027 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env39028 : List Nat := [2,4,8,16,32,16,8,256,512,768,805,544,268,33,0,262,48,513,768,1,560,33,16,3,268,17,804,49,545,512,516,33,256,33,33,513]

theorem envBound39028 : H12AffineFastState.Bounded env39028 := by
  intro p hp
  have h : env39028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39027_39028 : H12AffineEnvironment.transform 9 768 env39027 = env39028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 768 env39027 == env39028) = true)

theorem identity39028 : scanCanonicalize (H12AffineFastState.compose env39028 (packedSelected [0,7] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound39028 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env39029 : List Nat := [2,4,8,16,32,16,8,256,17,273,308,49,268,33,0,262,48,16,273,1,33,33,16,3,268,17,309,49,48,17,21,33,256,33,33,16]

theorem envBound39029 : H12AffineFastState.Bounded env39029 := by
  intro p hp
  have h : env39029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39028_39029 : H12AffineEnvironment.transform 8 17 env39028 = env39029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env39028 == env39029) = true)

theorem identity39029 : scanCanonicalize (H12AffineFastState.compose env39029 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound39029 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39030 : List Nat := [2,4,8,16,32,16,8,5,17,20,49,49,9,33,0,3,48,16,20,1,33,33,16,3,9,17,48,49,48,17,21,33,5,33,33,16]

theorem envBound39030 : H12AffineFastState.Bounded env39030 := by
  intro p hp
  have h : env39030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39029_39030 : H12AffineEnvironment.transform 7 5 env39029 = env39030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env39029 == env39030) = true)

theorem identity39030 : scanCanonicalize (H12AffineFastState.compose env39030 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 17) := by decide +kernel

theorem selectedBound39030 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env39031 : List Nat := [2,4,8,16,17,16,8,5,17,20,0,0,9,16,0,3,1,16,20,1,16,16,16,3,9,17,1,0,1,17,21,16,5,16,16,16]

theorem envBound39031 : H12AffineFastState.Bounded env39031 := by
  intro p hp
  have h : env39031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39030_39031 : H12AffineEnvironment.transform 4 17 env39030 = env39031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env39030 == env39031) = true)

theorem identity39031 : scanCanonicalize (H12AffineFastState.compose env39031 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound39031 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env39032 : List Nat := [2,4,2,16,17,16,2,5,17,20,0,0,3,16,0,3,1,16,20,1,16,16,16,3,3,17,1,0,1,17,21,16,5,16,16,16]

theorem envBound39032 : H12AffineFastState.Bounded env39032 := by
  intro p hp
  have h : env39032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39031_39032 : H12AffineEnvironment.transform 2 2 env39031 = env39032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env39031 == env39032) = true)

def env39033 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179513,1024,32769,4160,4194304,16,98644,8193,65,4258941,5393,17664,32041,1365,4256861,256,21792,46092,74251]

theorem envBound39033 : H12AffineFastState.Bounded env39033 := by
  intro p hp
  have h : env39033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39017_39033 : H12AffineEnvironment.transform 6 9 env39017 = env39033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env39017 == env39033) = true)

theorem identity39033 : scanCanonicalize (H12AffineFastState.compose env39033 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound39033 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env39034 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,13388,35189,1024,32769,4160,4194304,16,98644,8193,65,4258941,5393,17664,32041,1365,4256861,256,21792,46092,74251]

theorem envBound39034 : H12AffineFastState.Bounded env39034 := by
  intro p hp
  have h : env39034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39033_39034 : H12AffineEnvironment.transform 16 13388 env39033 = env39034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env39033 == env39034) = true)

theorem identity39034 : scanCanonicalize (H12AffineFastState.compose env39034 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound39034 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env39035 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,65536,13388,35189,1024,32769,4160,4194304,16,98644,8193,65,4229152,5393,12637,2420,1365,4227072,256,8573,46092,74251]

theorem envBound39035 : H12AffineFastState.Bounded env39035 := by
  intro p hp
  have h : env39035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39034_39035 : H12AffineEnvironment.transform 13 13405 env39034 = env39035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env39034 == env39035) = true)

theorem identity39035 : scanCanonicalize (H12AffineFastState.compose env39035 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound39035 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env39036 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,8202,13388,35189,1024,32769,4160,4194304,16,41310,8193,65,4229152,5393,12637,2420,1365,4227072,256,8573,46092,513]

theorem envBound39036 : H12AffineFastState.Bounded env39036 := by
  intro p hp
  have h : env39036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39035_39036 : H12AffineEnvironment.transform 15 8202 env39035 = env39036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env39035 == env39036) = true)

theorem identity39036 : scanCanonicalize (H12AffineFastState.compose env39036 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 9293) := by decide +kernel

theorem selectedBound39036 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env39037 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,9293,8202,13388,11576,1024,9292,4160,4194304,16,1299,8193,65,4205677,5393,12637,2420,1365,4203597,256,8573,4161,513]

theorem envBound39037 : H12AffineFastState.Bounded env39037 := by
  intro p hp
  have h : env39037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39036_39037 : H12AffineEnvironment.transform 14 9293 env39036 = env39037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 9293 env39036 == env39037) = true)

theorem identity39037 : scanCanonicalize (H12AffineFastState.compose env39037 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 5417) := by decide +kernel

theorem selectedBound39037 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env39038 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5417,372,4452,5411,357,6161,1024,4453,4160,4194304,16,1299,5416,65,4200772,5393,1140,2420,1365,4198756,256,5204,4161,513]

theorem envBound39038 : H12AffineFastState.Bounded env39038 := by
  intro p hp
  have h : env39038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39037_39038 : H12AffineEnvironment.transform 12 5417 env39037 = env39038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5417 env39037 == env39038) = true)

theorem identity39038 : scanCanonicalize (H12AffineFastState.compose env39038 (packedSelected [0,27] rootPS)) = affineNative (2^(21+1) ^^^ 1328) := by decide +kernel

theorem selectedBound39038 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env39039 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,5417,372,4452,5411,357,6161,1024,4453,4160,1328,16,1299,5416,65,7284,5393,1140,2420,1365,5204,256,5204,4161,513]

theorem envBound39039 : H12AffineFastState.Bounded env39039 := by
  intro p hp
  have h : env39039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39038_39039 : H12AffineEnvironment.transform 21 1328 env39038 = env39039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1328 env39038 == env39039) = true)

def env39040 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,4194304,17,98781,8328,65,4258940,5392,17664,32161,1501,4256860,256,21792,46213,74250]

theorem envBound39040 : H12AffineFastState.Bounded env39040 := by
  intro p hp
  have h : env39040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39016_39040 : H12AffineEnvironment.transform 20 4161 env39016 = env39040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env39016 == env39040) = true)

theorem identity39040 : scanCanonicalize (H12AffineFastState.compose env39040 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 169265) := by decide +kernel

theorem selectedBound39040 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env39041 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,169265,17,98781,8328,65,158029,5392,17664,32161,1501,156013,256,21792,46213,74250]

theorem envBound39041 : H12AffineFastState.Bounded env39041 := by
  intro p hp
  have h : env39041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39040_39041 : H12AffineEnvironment.transform 21 169265 env39040 = env39041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env39040 == env39041) = true)

theorem identity39041 : scanCanonicalize (H12AffineFastState.compose env39041 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound39041 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env39042 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179632,1024,32769,4161,169265,17,41430,8328,65,158029,5392,17664,32161,1501,156013,256,21792,46213,513]

theorem envBound39042 : H12AffineFastState.Bounded env39042 := by
  intro p hp
  have h : env39042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39041_39042 : H12AffineEnvironment.transform 15 8203 env39041 = env39042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env39041 == env39042) = true)

theorem identity39042 : scanCanonicalize (H12AffineFastState.compose env39042 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound39042 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env39043 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,64928,1024,32769,4161,54561,17,41430,8328,65,10589,5392,17664,32161,1501,8573,256,21792,46213,513]

theorem envBound39043 : H12AffineFastState.Bounded env39043 := by
  intro p hp
  have h : env39043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39042_39043 : H12AffineEnvironment.transform 16 16400 env39042 = env39043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env39042 == env39043) = true)

theorem identity39043 : scanCanonicalize (H12AffineFastState.compose env39043 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound39043 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env39044 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,16400,2477,1024,29708,4161,8492,17,21979,8328,65,10589,5392,17664,32161,1501,8573,256,21792,16520,513]

theorem envBound39044 : H12AffineFastState.Bounded env39044 := by
  intro p hp
  have h : env39044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39043_39044 : H12AffineEnvironment.transform 14 29709 env39043 = env39044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env39043 == env39044) = true)

def env39045 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,16384,20925,1467,16400,2477,1024,20924,4161,1180,17,21979,1336,65,3309,5392,17664,22545,1501,1229,256,21792,16520,513]

theorem envBound39045 : H12AffineFastState.Bounded env39045 := by
  intro p hp
  have h : env39045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39044_39045 : H12AffineEnvironment.transform 12 1456 env39044 = env39045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1456 env39044 == env39045) = true)

theorem identity39045 : scanCanonicalize (H12AffineFastState.compose env39045 (packedSelected [6] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound39045 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env39046 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1456,5236,1481,1467,5220,2477,1024,1480,4161,1180,17,431,1336,65,3309,5392,4468,3173,1501,1229,256,340,5372,513]

theorem envBound39046 : H12AffineFastState.Bounded env39046 := by
  intro p hp
  have h : env39046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39045_39046 : H12AffineEnvironment.transform 13 5236 env39045 = env39046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env39045 == env39046) = true)

theorem identity39046 : scanCanonicalize (H12AffineFastState.compose env39046 (packedSelected [12,15] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound39046 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env39047 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,1221,5236,1212,1230,5220,2264,1024,1213,4161,1180,17,218,1101,65,3309,5221,4097,3173,1192,1229,117,33,5372,513]

theorem envBound39047 : H12AffineFastState.Bounded env39047 := by
  intro p hp
  have h : env39047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39046_39047 : H12AffineEnvironment.transform 7 117 env39046 = env39047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env39046 == env39047) = true)

theorem identity39047 : scanCanonicalize (H12AffineFastState.compose env39047 (packedSelected [3,8,10] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound39047 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env39048 : List Nat := [2,4,8,16,32,64,88,117,512,1024,2048,4096,1053,5236,1124,1046,5220,2048,1024,1125,4161,1092,17,2,1101,65,3125,5221,4097,3173,1136,1045,117,33,5156,513]

theorem envBound39048 : H12AffineFastState.Bounded env39048 := by
  intro p hp
  have h : env39048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39047_39048 : H12AffineEnvironment.transform 6 88 env39047 = env39048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env39047 == env39048) = true)

theorem identity39048 : scanCanonicalize (H12AffineFastState.compose env39048 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound39048 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env39049 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,1053,5156,1076,1046,5172,2048,1024,1077,4113,1044,17,2,1053,17,3125,5173,4097,3125,1056,1045,37,33,5156,513]

theorem envBound39049 : H12AffineFastState.Bounded env39049 := by
  intro p hp
  have h : env39049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39048_39049 : H12AffineEnvironment.transform 5 16 env39048 = env39049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env39048 == env39049) = true)

theorem identity39049 : scanCanonicalize (H12AffineFastState.compose env39049 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound39049 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env39050 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,40,4113,1,35,4097,2048,53,0,4113,33,17,2,40,17,2048,4096,4097,2048,21,32,37,33,4113,513]

theorem envBound39050 : H12AffineFastState.Bounded env39050 := by
  intro p hp
  have h : env39050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans39049_39050 : H12AffineEnvironment.transform 9 53 env39049 = env39050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env39049 == env39050) = true)

theorem identity39050 : scanCanonicalize (H12AffineFastState.compose env39050 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound39050 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env39051 : List Nat := [2,4,8,16,32,16,8,37,512,53,32,4096,40,4113,1,35,4097,32,53,0,4113,33,17,2,40,17,32,4096,4097,32,21,32,37,33,4113,513]

end H12CloudChart1