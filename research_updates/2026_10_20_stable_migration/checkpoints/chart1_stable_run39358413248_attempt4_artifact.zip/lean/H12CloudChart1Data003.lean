import H12CloudChart1Data002

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem treeGood714 : H12WitnessSearch.Good tree714 := H12GlobalWitnessIndex.good

theorem leafIdentity714 : H12AffineFastState.composeSystem env714 rootObs = leafEnv714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env714 rootObs == leafEnv714) = true)

theorem terminalChecked714 : H12PackedTerminal.terminalCheckFast leafEnv714 active714 tree714 = true := by decide +kernel

def env715 : List Nat := [2,1,1,1,1,1,1,1,0,2,0,1,1,1,0,3,2,3,3,0,3,1,1,2,1,1,3,2,1,1,2,0,0,0,2,0]

theorem envBound715 : H12AffineFastState.Bounded env715 := by
  intro p hp
  have h : env715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans713_715 : H12AffineEnvironment.transform 3 1 env713 = env715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env713 == env715) = true)

theorem identity715 : scanCanonicalize (H12AffineFastState.compose env715 (packedSelected [3] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound715 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env716 : List Nat := [0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,1,0,1,1,0,1,1,1,0,1,1,1,0,1,1,0,0,0,0,0,0]

theorem envBound716 : H12AffineFastState.Bounded env716 := by
  intro p hp
  have h : env716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans715_716 : H12AffineEnvironment.transform 0 0 env715 = env716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env715 == env716) = true)

def leafEnv716 : List Nat := [0,1,1,1,1,1,1,1,0,0,0,1,1,1,0,1,0,1,1,0,1,1,1,0,1,1,1,1,1,0,1,1,0,0,0,0,0,1,0,0,1,1,0]

def active716 : List Nat := []

def tree716 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood716 : H12WitnessSearch.Good tree716 := H12GlobalWitnessIndex.good

theorem leafIdentity716 : H12AffineFastState.composeSystem env716 rootObs = leafEnv716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env716 rootObs == leafEnv716) = true)

theorem terminalChecked716 : H12PackedTerminal.terminalCheckFast leafEnv716 active716 tree716 = true := by decide +kernel

def env717 : List Nat := [2,4,8,16,32,17,9,37,512,46,2048,4096,40,6656,0,34,4122,523,46,0,6682,32,17,3,41,16,522,4122,4096,2048,14,32,37,32,4106,512]

theorem envBound717 : H12AffineFastState.Bounded env717 := by
  intro p hp
  have h : env717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans680_717 : H12AffineEnvironment.transform 5 17 env680 = env717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env680 == env717) = true)

theorem identity717 : scanCanonicalize (H12AffineFastState.compose env717 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 571) := by decide +kernel

theorem selectedBound717 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env718 : List Nat := [2,4,8,16,32,17,9,37,512,46,571,4096,40,4155,0,34,4122,523,46,0,4129,32,17,3,41,16,522,4122,4096,571,14,32,37,32,4106,512]

theorem envBound718 : H12AffineFastState.Bounded env718 := by
  intro p hp
  have h : env718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans717_718 : H12AffineEnvironment.transform 10 571 env717 = env718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 571 env717 == env718) = true)

def env719 : List Nat := [2,4,8,16,32,17,9,37,512,46,571,48,40,11,0,34,42,523,46,0,17,32,17,3,41,16,522,42,48,571,14,32,37,32,58,512]

theorem envBound719 : H12AffineFastState.Bounded env719 := by
  intro p hp
  have h : env719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans718_719 : H12AffineEnvironment.transform 11 48 env718 = env719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env718 == env719) = true)

theorem identity719 : scanCanonicalize (H12AffineFastState.compose env719 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 56) := by decide +kernel

theorem selectedBound719 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env720 : List Nat := [2,4,8,16,32,17,9,37,56,46,3,48,40,11,0,34,42,51,46,0,17,32,17,3,41,16,50,42,48,3,14,32,37,32,58,56]

theorem envBound720 : H12AffineFastState.Bounded env720 := by
  intro p hp
  have h : env720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans719_720 : H12AffineEnvironment.transform 8 56 env719 = env720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 56 env719 == env720) = true)

def env721 : List Nat := [2,4,8,16,16,17,9,21,8,30,3,0,24,11,0,18,26,3,30,0,17,16,17,3,25,16,2,26,0,3,14,16,21,16,10,8]

theorem envBound721 : H12AffineFastState.Bounded env721 := by
  intro p hp
  have h : env721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans720_721 : H12AffineEnvironment.transform 4 16 env720 = env721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env720 == env721) = true)

theorem identity721 : scanCanonicalize (H12AffineFastState.compose env721 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound721 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env722 : List Nat := [2,4,8,3,3,2,9,6,8,13,3,0,11,11,0,1,9,3,13,0,2,3,2,3,10,3,2,9,0,3,14,3,6,3,10,8]

theorem envBound722 : H12AffineFastState.Bounded env722 := by
  intro p hp
  have h : env722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans721_722 : H12AffineEnvironment.transform 3 3 env721 = env722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env721 == env722) = true)

theorem identity722 : scanCanonicalize (H12AffineFastState.compose env722 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound722 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env723 : List Nat := [2,0,8,3,3,2,9,2,8,9,3,0,11,11,0,1,9,3,9,0,2,3,2,3,10,3,2,9,0,3,10,3,2,3,10,8]

theorem envBound723 : H12AffineFastState.Bounded env723 := by
  intro p hp
  have h : env723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans722_723 : H12AffineEnvironment.transform 1 0 env722 = env723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env722 == env723) = true)

def leafEnv723 : List Nat := [2,0,8,3,3,2,9,2,8,9,3,0,11,11,0,1,9,3,9,0,2,3,2,3,10,10,1,3,2,9,0,3,10,3,2,3,0,0,10,8,1,2,0]

def active723 : List Nat := [0,2]

def tree723 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood723 : H12WitnessSearch.Good tree723 := H12GlobalWitnessIndex.good

theorem leafIdentity723 : H12AffineFastState.composeSystem env723 rootObs = leafEnv723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env723 rootObs == leafEnv723) = true)

theorem terminalChecked723 : H12PackedTerminal.terminalCheckFast leafEnv723 active723 tree723 = true := by decide +kernel

def env724 : List Nat := [2,4,8,16,17,17,9,20,9,31,3,1,25,11,0,19,27,2,31,0,17,17,17,3,24,16,3,27,1,3,14,17,20,17,11,9]

theorem envBound724 : H12AffineFastState.Bounded env724 := by
  intro p hp
  have h : env724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans720_724 : H12AffineEnvironment.transform 4 17 env720 = env724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env720 == env724) = true)

theorem identity724 : scanCanonicalize (H12AffineFastState.compose env724 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound724 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env725 : List Nat := [2,4,1,16,17,17,0,20,0,22,3,1,16,2,0,19,18,2,22,0,17,17,17,3,17,16,3,18,1,3,7,17,20,17,2,0]

theorem envBound725 : H12AffineFastState.Bounded env725 := by
  intro p hp
  have h : env725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans724_725 : H12AffineEnvironment.transform 2 1 env724 = env725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env724 == env725) = true)

theorem identity725 : scanCanonicalize (H12AffineFastState.compose env725 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound725 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env726 : List Nat := [2,4,1,4,5,5,0,0,0,2,3,1,4,2,0,7,6,2,2,0,5,5,5,3,5,4,3,6,1,3,7,5,0,5,2,0]

theorem envBound726 : H12AffineFastState.Bounded env726 := by
  intro p hp
  have h : env726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans725_726 : H12AffineEnvironment.transform 3 4 env725 = env726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env725 == env726) = true)

def leafEnv726 : List Nat := [2,4,1,4,5,5,0,0,0,2,3,1,4,2,0,7,6,2,2,0,5,5,5,3,7,5,1,4,3,6,1,3,7,5,0,5,4,6,2,0,1,4,0]

def active726 : List Nat := [0,1]

def tree726 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood726 : H12WitnessSearch.Good tree726 := H12GlobalWitnessIndex.good

theorem leafIdentity726 : H12AffineFastState.composeSystem env726 rootObs = leafEnv726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env726 rootObs == leafEnv726) = true)

theorem terminalChecked726 : H12PackedTerminal.terminalCheckFast leafEnv726 active726 tree726 = true := by decide +kernel

def env727 : List Nat := [2,4,8,16,32,17,9,37,512,46,571,49,40,10,0,34,43,523,46,0,16,32,17,3,41,16,522,43,49,571,14,32,37,32,59,512]

theorem envBound727 : H12AffineFastState.Bounded env727 := by
  intro p hp
  have h : env727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans718_727 : H12AffineEnvironment.transform 11 49 env718 = env727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env718 == env727) = true)

theorem identity727 : scanCanonicalize (H12AffineFastState.compose env727 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound727 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env728 : List Nat := [2,4,8,16,32,17,9,37,34,46,25,49,40,10,0,34,43,41,46,0,16,32,17,3,41,16,40,43,49,25,14,32,37,32,59,34]

theorem envBound728 : H12AffineFastState.Bounded env728 := by
  intro p hp
  have h : env728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans727_728 : H12AffineEnvironment.transform 8 34 env727 = env728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env727 == env728) = true)

def env729 : List Nat := [2,4,8,16,16,17,9,21,18,30,25,1,24,10,0,18,27,25,30,0,16,16,17,3,25,16,24,27,1,25,14,16,21,16,11,18]

theorem envBound729 : H12AffineFastState.Bounded env729 := by
  intro p hp
  have h : env729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans728_729 : H12AffineEnvironment.transform 4 16 env728 = env729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env728 == env729) = true)

theorem identity729 : scanCanonicalize (H12AffineFastState.compose env729 (packedSelected [1,3] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound729 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env730 : List Nat := [2,4,0,16,16,17,1,21,18,22,17,1,16,2,0,18,19,17,22,0,16,16,17,3,17,16,16,19,1,17,6,16,21,16,3,18]

theorem envBound730 : H12AffineFastState.Bounded env730 := by
  intro p hp
  have h : env730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans729_730 : H12AffineEnvironment.transform 2 0 env729 = env730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env729 == env730) = true)

theorem identity730 : scanCanonicalize (H12AffineFastState.compose env730 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound730 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env731 : List Nat := [2,4,0,6,6,7,1,3,4,0,7,1,6,2,0,4,5,7,0,0,6,6,7,3,7,6,6,5,1,7,6,6,3,6,3,4]

theorem envBound731 : H12AffineFastState.Bounded env731 := by
  intro p hp
  have h : env731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans730_731 : H12AffineEnvironment.transform 3 6 env730 = env731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env730 == env731) = true)

def leafEnv731 : List Nat := [2,4,0,6,6,7,1,3,4,0,7,1,6,2,0,4,5,7,0,0,6,6,7,3,6,7,1,6,6,5,1,7,6,6,3,6,4,5,3,4,1,6,0]

def active731 : List Nat := [0,1]

def tree731 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood731 : H12WitnessSearch.Good tree731 := H12GlobalWitnessIndex.good

theorem leafIdentity731 : H12AffineFastState.composeSystem env731 rootObs = leafEnv731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env731 rootObs == leafEnv731) = true)

theorem terminalChecked731 : H12PackedTerminal.terminalCheckFast leafEnv731 active731 tree731 = true := by decide +kernel

def env732 : List Nat := [2,4,8,16,17,17,9,20,19,31,25,0,25,10,0,19,26,24,31,0,16,17,17,3,24,16,25,26,0,25,14,17,20,17,10,19]

theorem envBound732 : H12AffineFastState.Bounded env732 := by
  intro p hp
  have h : env732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans728_732 : H12AffineEnvironment.transform 4 17 env728 = env732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env728 == env732) = true)

theorem identity732 : scanCanonicalize (H12AffineFastState.compose env732 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound732 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env733 : List Nat := [2,4,8,2,3,3,9,6,1,13,11,0,11,10,0,1,8,10,13,0,2,3,3,3,10,2,11,8,0,11,14,3,6,3,10,1]

theorem envBound733 : H12AffineFastState.Bounded env733 := by
  intro p hp
  have h : env733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans732_733 : H12AffineEnvironment.transform 3 2 env732 = env733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env732 == env733) = true)

theorem identity733 : scanCanonicalize (H12AffineFastState.compose env733 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound733 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env734 : List Nat := [2,4,6,2,3,3,7,6,1,3,5,0,5,4,0,1,6,4,3,0,2,3,3,3,4,2,5,6,0,5,0,3,6,3,4,1]

theorem envBound734 : H12AffineFastState.Bounded env734 := by
  intro p hp
  have h : env734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans733_734 : H12AffineEnvironment.transform 2 6 env733 = env734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env733 == env734) = true)

def leafEnv734 : List Nat := [2,4,6,2,3,3,7,6,1,3,5,0,5,4,0,1,6,4,3,0,2,3,3,3,0,4,1,2,5,6,0,5,0,3,6,3,4,0,4,1,1,3,0]

def active734 : List Nat := [0,1]

def tree734 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood734 : H12WitnessSearch.Good tree734 := H12GlobalWitnessIndex.good

theorem leafIdentity734 : H12AffineFastState.composeSystem env734 rootObs = leafEnv734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env734 rootObs == leafEnv734) = true)

theorem terminalChecked734 : H12PackedTerminal.terminalCheckFast leafEnv734 active734 tree734 = true := by decide +kernel

def env735 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,33,8388608,8988133,8328,599234,262280,11105475,11232451,8990183,75223,73770,525568,8988103,34359738368,74371]

theorem envBound735 : H12AffineFastState.Bounded env735 := by
  intro p hp
  have h : env735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans665_735 : H12AffineEnvironment.transform 21 33 env665 = env735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env665 == env735) = true)

theorem identity735 : scanCanonicalize (H12AffineFastState.compose env735 (packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound735 : packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,8575,131072,262144,524288,8353,2097152,33,8388608,8914074,8328,525757,262280,11031996,11158972,8916120,1192,341,525568,8914104,34359738368,1020]

theorem envBound736 : H12AffineFastState.Bounded env736 := by
  intro p hp
  have h : env736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans735_736 : H12AffineEnvironment.transform 15 8575 env735 = env736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env735 == env736) = true)

theorem identity736 : scanCanonicalize (H12AffineFastState.compose env736 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound736 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env737 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,2097152,33,8388608,8914074,8328,525377,262280,11031616,11158592,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound737 : H12AffineFastState.Bounded env737 := by
  intro p hp
  have h : env737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans736_737 : H12AffineEnvironment.transform 7 252 env736 = env737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env736 == env737) = true)

theorem identity737 : scanCanonicalize (H12AffineFastState.compose env737 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound737 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env738 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,17596,33,8388608,8914074,8328,525377,262280,8917244,9044220,8916120,1192,169,525564,8914104,34359738368,512]

theorem envBound738 : H12AffineFastState.Bounded env738 := by
  intro p hp
  have h : env738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans737_738 : H12AffineEnvironment.transform 20 17596 env737 = env738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env737 == env738) = true)

theorem identity738 : scanCanonicalize (H12AffineFastState.compose env738 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 940085) := by decide +kernel

theorem selectedBound738 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env739 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8353,8323,131072,262144,524288,8353,17596,33,8388608,8914074,8328,525377,262280,8917244,9044220,8916120,1192,169,525564,8914104,940085,512]

theorem envBound739 : H12AffineFastState.Bounded env739 := by
  intro p hp
  have h : env739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans738_739 : H12AffineEnvironment.transform 34 940085 env738 = env739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 940085 env738 == env739) = true)

theorem identity739 : scanCanonicalize (H12AffineFastState.compose env739 (packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound739 : packedSelected [0,4,7,9,11,12,13,14,15,23] rootPS < 2^1333 := by decide +kernel

def env740 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,131072,262144,524288,1,17596,33,8388608,8914074,40,525377,262280,8917244,9044220,8916120,1192,169,525564,8914104,940085,512]

theorem envBound740 : H12AffineFastState.Bounded env740 := by
  intro p hp
  have h : env740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans739_740 : H12AffineEnvironment.transform 12 160 env739 = env740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env739 == env740) = true)

theorem identity740 : scanCanonicalize (H12AffineFastState.compose env740 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound740 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env741 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5357,262144,524288,1,17596,33,8388608,8914074,40,525377,262280,8917244,8918033,8916120,1192,169,525564,8914104,806104,512]

theorem envBound741 : H12AffineFastState.Bounded env741 := by
  intro p hp
  have h : env741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans740_741 : H12AffineEnvironment.transform 16 5357 env740 = env741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env740 == env741) = true)

theorem identity741 : scanCanonicalize (H12AffineFastState.compose env741 (packedSelected [1,3,4,5,8,9,11,12] rootPS)) = affineNative (2^(22+1) ^^^ 789657) := by decide +kernel

theorem selectedBound741 : packedSelected [1,3,4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env742 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5357,262144,524288,1,17596,33,789657,264195,40,525377,262280,269413,268424,262145,1192,169,525564,264225,806104,512]

theorem envBound742 : H12AffineFastState.Bounded env742 := by
  intro p hp
  have h : env742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans741_742 : H12AffineEnvironment.transform 22 789657 env741 = env742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 789657 env741 == env742) = true)

theorem identity742 : scanCanonicalize (H12AffineFastState.compose env742 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(17+1) ^^^ 2185) := by decide +kernel

theorem selectedBound742 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env743 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,160,16384,1,35,5357,2185,524288,1,17596,33,525328,138,40,525377,2049,5356,4097,2184,1192,169,525564,168,541777,512]

theorem envBound743 : H12AffineFastState.Bounded env743 := by
  intro p hp
  have h : env743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans742_743 : H12AffineEnvironment.transform 17 2185 env742 = env743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env742 == env743) = true)

theorem identity743 : scanCanonicalize (H12AffineFastState.compose env743 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound743 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env744 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,1,35,5189,2081,524288,1,17428,33,525328,34,40,525377,2049,5188,4097,2080,1024,1,525396,0,541777,512]

theorem envBound744 : H12AffineFastState.Bounded env744 := by
  intro p hp
  have h : env744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans743_744 : H12AffineEnvironment.transform 6 40 env743 = env744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env743 == env744) = true)

def env745 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,1,35,5189,2081,1104,1,17428,33,64,34,40,17,2049,5188,4097,2080,1024,1,4,0,16385,512]

theorem envBound745 : H12AffineFastState.Bounded env745 := by
  intro p hp
  have h : env745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans744_745 : H12AffineEnvironment.transform 18 1104 env744 = env745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1104 env744 == env745) = true)

theorem identity745 : scanCanonicalize (H12AffineFastState.compose env745 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 80) := by decide +kernel

theorem selectedBound745 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env746 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,80,1,35,5189,2081,1104,1,1092,33,64,34,40,17,2049,5188,4097,2080,1024,1,4,0,81,512]

theorem envBound746 : H12AffineFastState.Bounded env746 := by
  intro p hp
  have h : env746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans745_746 : H12AffineEnvironment.transform 13 80 env745 = env746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 80 env745 == env746) = true)

theorem identity746 : scanCanonicalize (H12AffineFastState.compose env746 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1086) := by decide +kernel

theorem selectedBound746 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env747 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1086,4096,8,80,1,35,5189,1055,1104,1,1092,33,64,34,40,17,1087,5188,4097,1054,1024,1,4,0,81,512]

theorem envBound747 : H12AffineFastState.Bounded env747 := by
  intro p hp
  have h : env747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans746_747 : H12AffineEnvironment.transform 10 1086 env746 = env747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1086 env746 == env747) = true)

theorem identity747 : scanCanonicalize (H12AffineFastState.compose env747 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound747 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env748 : List Nat := [2,4,8,16,32,32,40,52,512,1024,1086,4096,8,48,1,35,5157,1055,1072,1,1060,33,32,34,40,17,1087,5156,4097,1054,1024,1,4,0,49,512]

theorem envBound748 : H12AffineFastState.Bounded env748 := by
  intro p hp
  have h : env748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans747_748 : H12AffineEnvironment.transform 5 32 env747 = env748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env747 == env748) = true)

theorem identity748 : scanCanonicalize (H12AffineFastState.compose env748 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 26) := by decide +kernel

theorem selectedBound748 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env749 : List Nat := [2,4,8,16,26,26,18,14,512,1024,1028,4096,8,10,1,25,5151,1055,1034,1,1054,27,26,24,18,17,1029,5150,4097,1054,1024,1,4,0,11,512]

theorem envBound749 : H12AffineFastState.Bounded env749 := by
  intro p hp
  have h : env749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans748_749 : H12AffineEnvironment.transform 4 26 env748 = env749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 26 env748 == env749) = true)

def env750 : List Nat := [2,4,8,16,26,26,18,14,512,1024,1028,1044,8,10,1,25,11,1055,1034,1,1054,27,26,24,18,17,1029,10,1045,1054,1024,1,4,0,11,512]

theorem envBound750 : H12AffineFastState.Bounded env750 := by
  intro p hp
  have h : env750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans749_750 : H12AffineEnvironment.transform 11 1044 env749 = env750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env749 == env750) = true)

theorem identity750 : scanCanonicalize (H12AffineFastState.compose env750 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound750 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env751 : List Nat := [2,4,8,2,8,8,0,14,512,1024,1028,1030,8,10,1,11,11,1037,1034,1,1036,9,8,10,0,3,1029,10,1031,1036,1024,1,4,0,11,512]

theorem envBound751 : H12AffineFastState.Bounded env751 := by
  intro p hp
  have h : env751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans750_751 : H12AffineEnvironment.transform 3 2 env750 = env751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env750 == env751) = true)

def env752 : List Nat := [2,4,8,2,8,8,0,14,8,1024,1028,1030,8,10,1,11,11,1037,1034,1,1036,9,8,10,0,3,1029,10,1031,1036,1024,1,4,0,11,8]

theorem envBound752 : H12AffineFastState.Bounded env752 := by
  intro p hp
  have h : env752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans751_752 : H12AffineEnvironment.transform 8 8 env751 = env752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env751 == env752) = true)

theorem identity752 : scanCanonicalize (H12AffineFastState.compose env752 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 8) := by decide +kernel

theorem selectedBound752 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env753 : List Nat := [2,4,8,2,8,8,0,14,8,8,12,14,8,10,1,11,11,5,2,1,4,9,8,10,0,3,13,10,15,4,8,1,4,0,11,8]

theorem envBound753 : H12AffineFastState.Bounded env753 := by
  intro p hp
  have h : env753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans752_753 : H12AffineEnvironment.transform 9 8 env752 = env753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 8 env752 == env753) = true)

def leafEnv753 : List Nat := [2,4,8,2,8,8,0,14,8,8,12,14,8,10,1,11,11,5,2,1,4,9,8,10,3,0,1,3,13,10,15,4,8,1,4,0,15,3,11,8,1,4,0]

def active753 : List Nat := [0,1,2]

def tree753 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood753 : H12WitnessSearch.Good tree753 := H12GlobalWitnessIndex.good

theorem leafIdentity753 : H12AffineFastState.composeSystem env753 rootObs = leafEnv753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env753 rootObs == leafEnv753) = true)

theorem terminalChecked753 : H12PackedTerminal.terminalCheckFast leafEnv753 active753 tree753 = true := by decide +kernel

def env754 : List Nat := [2,4,8,2,8,8,0,14,9,1024,1028,1030,8,10,1,11,11,1037,1034,1,1036,9,8,10,0,3,1029,10,1031,1036,1024,1,4,0,11,9]

theorem envBound754 : H12AffineFastState.Bounded env754 := by
  intro p hp
  have h : env754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans751_754 : H12AffineEnvironment.transform 8 9 env751 = env754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env751 == env754) = true)

theorem identity754 : scanCanonicalize (H12AffineFastState.compose env754 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env755 : List Nat := [2,0,8,2,8,8,0,10,9,1024,1024,1026,8,10,1,11,11,1033,1034,1,1032,9,8,10,0,3,1025,10,1027,1032,1024,1,0,0,11,9]

theorem envBound755 : H12AffineFastState.Bounded env755 := by
  intro p hp
  have h : env755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans754_755 : H12AffineEnvironment.transform 1 0 env754 = env755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env754 == env755) = true)

def leafEnv755 : List Nat := [2,0,8,2,8,8,0,10,9,1024,1024,1026,8,10,1,11,11,1033,1034,1,1032,9,8,10,1035,0,1,3,1025,10,1027,1032,1024,1,0,0,11,3,11,9,1,1032,0]

def active755 : List Nat := [0,2,9]

def tree755 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood755 : H12WitnessSearch.Good tree755 := H12GlobalWitnessIndex.good

theorem leafIdentity755 : H12AffineFastState.composeSystem env755 rootObs = leafEnv755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env755 rootObs == leafEnv755) = true)

theorem terminalChecked755 : H12PackedTerminal.terminalCheckFast leafEnv755 active755 tree755 = true := by decide +kernel

def env756 : List Nat := [2,4,8,16,26,26,18,14,512,1024,1028,1045,8,10,1,25,10,1055,1034,1,1054,27,26,24,18,17,1029,11,1044,1054,1024,1,4,0,11,512]

theorem envBound756 : H12AffineFastState.Bounded env756 := by
  intro p hp
  have h : env756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans749_756 : H12AffineEnvironment.transform 11 1045 env749 = env756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env749 == env756) = true)

theorem identity756 : scanCanonicalize (H12AffineFastState.compose env756 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 12) := by decide +kernel

theorem selectedBound756 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env757 : List Nat := [2,4,8,16,26,26,18,14,512,12,8,25,8,10,1,25,10,19,6,1,18,27,26,24,18,17,9,11,24,18,12,1,4,0,11,512]

theorem envBound757 : H12AffineFastState.Bounded env757 := by
  intro p hp
  have h : env757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans756_757 : H12AffineEnvironment.transform 9 12 env756 = env757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 12 env756 == env757) = true)

def env758 : List Nat := [2,4,8,16,26,26,18,14,8,12,8,25,8,10,1,25,10,19,6,1,18,27,26,24,18,17,9,11,24,18,12,1,4,0,11,8]

theorem envBound758 : H12AffineFastState.Bounded env758 := by
  intro p hp
  have h : env758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans757_758 : H12AffineEnvironment.transform 8 8 env757 = env758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env757 == env758) = true)

theorem identity758 : scanCanonicalize (H12AffineFastState.compose env758 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound758 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env759 : List Nat := [2,1,8,16,26,26,18,11,8,9,8,25,8,10,1,25,10,19,3,1,18,27,26,24,18,17,9,11,24,18,9,1,1,0,11,8]

theorem envBound759 : H12AffineFastState.Bounded env759 := by
  intro p hp
  have h : env759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans758_759 : H12AffineEnvironment.transform 1 1 env758 = env759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env758 == env759) = true)

def leafEnv759 : List Nat := [2,1,8,16,26,26,18,11,8,9,8,25,8,10,1,25,10,19,3,1,18,27,26,24,2,18,1,17,9,11,24,18,9,1,1,0,10,3,11,8,1,18,0]

def active759 : List Nat := [0,2,3]

def tree759 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood759 : H12WitnessSearch.Good tree759 := H12GlobalWitnessIndex.good

theorem leafIdentity759 : H12AffineFastState.composeSystem env759 rootObs = leafEnv759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env759 rootObs == leafEnv759) = true)

theorem terminalChecked759 : H12PackedTerminal.terminalCheckFast leafEnv759 active759 tree759 = true := by decide +kernel

def env760 : List Nat := [2,4,8,16,26,26,18,14,9,12,8,25,8,10,1,25,10,19,6,1,18,27,26,24,18,17,9,11,24,18,12,1,4,0,11,9]

theorem envBound760 : H12AffineFastState.Bounded env760 := by
  intro p hp
  have h : env760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans757_760 : H12AffineEnvironment.transform 8 9 env757 = env760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env757 == env760) = true)

theorem identity760 : scanCanonicalize (H12AffineFastState.compose env760 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound760 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env761 : List Nat := [2,4,8,7,13,13,5,14,9,12,8,14,8,10,1,14,10,4,6,1,5,12,13,15,5,6,9,11,15,5,12,1,4,0,11,9]

theorem envBound761 : H12AffineFastState.Bounded env761 := by
  intro p hp
  have h : env761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans760_761 : H12AffineEnvironment.transform 3 7 env760 = env761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env760 == env761) = true)

def leafEnv761 : List Nat := [2,4,8,7,13,13,5,14,9,12,8,14,8,10,1,14,10,4,6,1,5,12,13,15,7,5,1,6,9,11,15,5,12,1,4,0,15,3,11,9,1,5,0]

def active761 : List Nat := [0,1,2]

def tree761 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood761 : H12WitnessSearch.Good tree761 := H12GlobalWitnessIndex.good

theorem leafIdentity761 : H12AffineFastState.composeSystem env761 rootObs = leafEnv761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env761 rootObs == leafEnv761) = true)

theorem terminalChecked761 : H12PackedTerminal.terminalCheckFast leafEnv761 active761 tree761 = true := by decide +kernel

def env762 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,16384,1,35,5189,2081,1105,1,17428,33,65,34,40,16,2049,5188,4097,2080,1024,1,5,0,16384,512]

theorem envBound762 : H12AffineFastState.Bounded env762 := by
  intro p hp
  have h : env762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans744_762 : H12AffineEnvironment.transform 18 1105 env744 = env762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1105 env744 == env762) = true)

theorem identity762 : scanCanonicalize (H12AffineFastState.compose env762 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1092) := by decide +kernel

theorem selectedBound762 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env763 : List Nat := [2,4,8,16,32,64,40,84,512,1024,2048,4096,8,1092,1,35,5189,2081,1105,1,80,33,65,34,40,16,2049,5188,4097,2080,1024,1,5,0,1092,512]

theorem envBound763 : H12AffineFastState.Bounded env763 := by
  intro p hp
  have h : env763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans762_763 : H12AffineEnvironment.transform 13 1092 env762 = env763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1092 env762 == env763) = true)

theorem identity763 : scanCanonicalize (H12AffineFastState.compose env763 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1086) := by decide +kernel

theorem selectedBound763 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env764 : List Nat := [2,4,8,16,32,64,40,84,512,1024,1086,4096,8,1092,1,35,5189,1055,1105,1,80,33,65,34,40,16,1087,5188,4097,1054,1024,1,5,0,1092,512]

theorem envBound764 : H12AffineFastState.Bounded env764 := by
  intro p hp
  have h : env764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans763_764 : H12AffineEnvironment.transform 10 1086 env763 = env764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1086 env763 == env764) = true)

theorem identity764 : scanCanonicalize (H12AffineFastState.compose env764 (packedSelected [1,5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound764 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env765 : List Nat := [2,4,8,16,32,10,40,30,512,1024,1086,4096,8,1038,1,35,5135,1055,1051,1,26,33,11,34,40,16,1087,5134,4097,1054,1024,1,5,0,1038,512]

theorem envBound765 : H12AffineFastState.Bounded env765 := by
  intro p hp
  have h : env765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans764_765 : H12AffineEnvironment.transform 5 10 env764 = env765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env764 == env765) = true)

theorem identity765 : scanCanonicalize (H12AffineFastState.compose env765 (packedSelected [1,8] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound765 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env766 : List Nat := [2,4,8,16,16,10,24,30,512,1024,1038,4096,8,1038,1,19,5135,1055,1051,1,26,17,11,18,24,16,1039,5134,4097,1054,1024,1,5,0,1038,512]

theorem envBound766 : H12AffineFastState.Bounded env766 := by
  intro p hp
  have h : env766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans765_766 : H12AffineEnvironment.transform 4 16 env765 = env766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env765 == env766) = true)

def env767 : List Nat := [2,4,8,16,16,10,24,30,512,1024,1038,1044,8,1038,1,19,27,1055,1051,1,26,17,11,18,24,16,1039,26,1045,1054,1024,1,5,0,1038,512]

theorem envBound767 : H12AffineFastState.Bounded env767 := by
  intro p hp
  have h : env767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans766_767 : H12AffineEnvironment.transform 11 1044 env766 = env767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env766 == env767) = true)

theorem identity767 : scanCanonicalize (H12AffineFastState.compose env767 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 6) := by decide +kernel

theorem selectedBound767 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env768 : List Nat := [2,4,8,16,16,10,24,30,512,6,8,18,8,8,1,19,27,25,29,1,26,17,11,18,24,16,9,26,19,24,6,1,5,0,8,512]

theorem envBound768 : H12AffineFastState.Bounded env768 := by
  intro p hp
  have h : env768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans767_768 : H12AffineEnvironment.transform 9 6 env767 = env768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 6 env767 == env768) = true)

def env769 : List Nat := [2,4,8,16,16,10,24,30,16,6,8,18,8,8,1,19,27,25,29,1,26,17,11,18,24,16,9,26,19,24,6,1,5,0,8,16]

theorem envBound769 : H12AffineFastState.Bounded env769 := by
  intro p hp
  have h : env769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans768_769 : H12AffineEnvironment.transform 8 16 env768 = env769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env768 == env769) = true)

theorem identity769 : scanCanonicalize (H12AffineFastState.compose env769 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 14) := by decide +kernel

theorem selectedBound769 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env770 : List Nat := [2,4,8,14,14,10,6,0,14,6,8,12,8,8,1,13,5,7,3,1,4,15,11,12,6,14,9,4,13,6,6,1,5,0,8,14]

theorem envBound770 : H12AffineFastState.Bounded env770 := by
  intro p hp
  have h : env770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans769_770 : H12AffineEnvironment.transform 3 14 env769 = env770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 14 env769 == env770) = true)

def leafEnv770 : List Nat := [2,4,8,14,14,10,6,0,14,6,8,12,8,8,1,13,5,7,3,1,4,15,11,12,2,6,1,14,9,4,13,6,6,1,5,0,0,3,8,14,1,5,0]

def active770 : List Nat := [0,1,2]

def tree770 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood770 : H12WitnessSearch.Good tree770 := H12GlobalWitnessIndex.good

theorem leafIdentity770 : H12AffineFastState.composeSystem env770 rootObs = leafEnv770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env770 rootObs == leafEnv770) = true)

theorem terminalChecked770 : H12PackedTerminal.terminalCheckFast leafEnv770 active770 tree770 = true := by decide +kernel

def env771 : List Nat := [2,4,8,16,16,10,24,30,17,6,8,18,8,8,1,19,27,25,29,1,26,17,11,18,24,16,9,26,19,24,6,1,5,0,8,17]

theorem envBound771 : H12AffineFastState.Bounded env771 := by
  intro p hp
  have h : env771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans768_771 : H12AffineEnvironment.transform 8 17 env768 = env771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env768 == env771) = true)

theorem identity771 : scanCanonicalize (H12AffineFastState.compose env771 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound771 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env772 : List Nat := [2,4,8,6,6,10,14,8,7,6,8,4,8,8,1,5,13,15,11,1,12,7,11,4,14,6,9,12,5,14,6,1,5,0,8,7]

theorem envBound772 : H12AffineFastState.Bounded env772 := by
  intro p hp
  have h : env772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans771_772 : H12AffineEnvironment.transform 3 6 env771 = env772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env771 == env772) = true)

def leafEnv772 : List Nat := [2,4,8,6,6,10,14,8,7,6,8,4,8,8,1,5,13,15,11,1,12,7,11,4,10,14,1,6,9,12,5,14,6,1,5,0,8,3,8,7,1,13,0]

def active772 : List Nat := [0,1,2]

def tree772 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood772 : H12WitnessSearch.Good tree772 := H12GlobalWitnessIndex.good

theorem leafIdentity772 : H12AffineFastState.composeSystem env772 rootObs = leafEnv772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env772 rootObs == leafEnv772) = true)

theorem terminalChecked772 : H12PackedTerminal.terminalCheckFast leafEnv772 active772 tree772 = true := by decide +kernel

def env773 : List Nat := [2,4,8,16,16,10,24,30,512,1024,1038,1045,8,1038,1,19,26,1055,1051,1,26,17,11,18,24,16,1039,27,1044,1054,1024,1,5,0,1038,512]

theorem envBound773 : H12AffineFastState.Bounded env773 := by
  intro p hp
  have h : env773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans766_773 : H12AffineEnvironment.transform 11 1045 env766 = env773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env766 == env773) = true)

theorem identity773 : scanCanonicalize (H12AffineFastState.compose env773 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound773 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env774 : List Nat := [2,4,0,16,16,2,16,22,512,1024,1030,1045,0,1030,1,19,18,1047,1043,1,18,17,3,18,16,16,1031,19,1044,1046,1024,1,5,0,1030,512]

theorem envBound774 : H12AffineFastState.Bounded env774 := by
  intro p hp
  have h : env774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans773_774 : H12AffineEnvironment.transform 2 0 env773 = env774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env773 == env774) = true)

def env775 : List Nat := [2,4,0,16,16,2,16,22,16,1024,1030,1045,0,1030,1,19,18,1047,1043,1,18,17,3,18,16,16,1031,19,1044,1046,1024,1,5,0,1030,16]

theorem envBound775 : H12AffineFastState.Bounded env775 := by
  intro p hp
  have h : env775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans774_775 : H12AffineEnvironment.transform 8 16 env774 = env775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env774 == env775) = true)

theorem identity775 : scanCanonicalize (H12AffineFastState.compose env775 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound775 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env776 : List Nat := [2,4,0,7,7,2,7,1,7,1024,1030,1026,0,1030,1,4,5,1024,1028,1,5,6,3,5,7,7,1031,4,1027,1025,1024,1,5,0,1030,7]

theorem envBound776 : H12AffineFastState.Bounded env776 := by
  intro p hp
  have h : env776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans775_776 : H12AffineEnvironment.transform 3 7 env775 = env776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env775 == env776) = true)

def leafEnv776 : List Nat := [2,4,0,7,7,2,7,1,7,1024,1030,1026,0,1030,1,4,5,1024,1028,1,5,6,3,5,1029,7,1,7,1031,4,1027,1025,1024,1,5,0,1,3,1030,7,1,4,0]

def active776 : List Nat := [0,1,9]

def tree776 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood776 : H12WitnessSearch.Good tree776 := H12GlobalWitnessIndex.good

theorem leafIdentity776 : H12AffineFastState.composeSystem env776 rootObs = leafEnv776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env776 rootObs == leafEnv776) = true)

theorem terminalChecked776 : H12PackedTerminal.terminalCheckFast leafEnv776 active776 tree776 = true := by decide +kernel

def env777 : List Nat := [2,4,0,16,16,2,16,22,17,1024,1030,1045,0,1030,1,19,18,1047,1043,1,18,17,3,18,16,16,1031,19,1044,1046,1024,1,5,0,1030,17]

theorem envBound777 : H12AffineFastState.Bounded env777 := by
  intro p hp
  have h : env777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans774_777 : H12AffineEnvironment.transform 8 17 env774 = env777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env774 == env777) = true)

theorem identity777 : scanCanonicalize (H12AffineFastState.compose env777 (packedSelected [1] rootPS)) = affineNative (2^(9+1) ^^^ 17) := by decide +kernel

theorem selectedBound777 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env778 : List Nat := [2,4,0,16,16,2,16,22,17,17,23,4,0,23,1,19,18,6,2,1,18,17,3,18,16,16,22,19,5,7,17,1,5,0,23,17]

theorem envBound778 : H12AffineFastState.Bounded env778 := by
  intro p hp
  have h : env778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans777_778 : H12AffineEnvironment.transform 9 17 env777 = env778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 17 env777 == env778) = true)

def leafEnv778 : List Nat := [2,4,0,16,16,2,16,22,17,17,23,4,0,23,1,19,18,6,2,1,18,17,3,18,3,16,1,16,22,19,5,7,17,1,5,0,22,3,23,17,1,19,0]

def active778 : List Nat := [0,1,3]

def tree778 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood778 : H12WitnessSearch.Good tree778 := H12GlobalWitnessIndex.good

theorem leafIdentity778 : H12AffineFastState.composeSystem env778 rootObs = leafEnv778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env778 rootObs == leafEnv778) = true)

theorem terminalChecked778 : H12PackedTerminal.terminalCheckFast leafEnv778 active778 tree778 = true := by decide +kernel

def env779 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,134217728,268435456,268570625,1073741824,92374097,1086893389,525568,1073743904,34359738368,25733063]

theorem envBound779 : H12AffineFastState.Bounded env779 := by
  intro p hp
  have h : env779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans7_779 : H12AffineEnvironment.transform 28 268570625 env7 = env779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 268570625 env7 == env779) = true)

theorem identity779 : scanCanonicalize (H12AffineFastState.compose env779 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(26+1) ^^^ 9176216) := by decide +kernel

theorem selectedBound779 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env780 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,1073741824,92374097,1086893389,525568,1073743904,34359738368,25733063]

theorem envBound780 : H12AffineFastState.Bounded env780 := by
  intro p hp
  have h : env780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans779_780 : H12AffineEnvironment.transform 26 9176216 env779 = env780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 9176216 env779 == env780) = true)

def env781 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,67108864,9176216,268435456,268570625,268453920,92374097,281601389,525568,268451840,34359738368,25733063]

theorem envBound781 : H12AffineFastState.Bounded env781 := by
  intro p hp
  have h : env781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans780_781 : H12AffineEnvironment.transform 29 268453920 env780 = env781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 268453920 env780 == env781) = true)

def env782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,268435456,268570625,268453920,17399809,281601389,525568,268451840,34359738368,25733063]

theorem envBound782 : H12AffineFastState.Bounded env782 := by
  intro p hp
  have h : env782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans781_782 : H12AffineEnvironment.transform 25 8914000 env781 = env782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 8914000 env781 == env782) = true)

def env783 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2080,17399809,13149549,525568,0,34359738368,25733063]

theorem envBound783 : H12AffineFastState.Bounded env783 := by
  intro p hp
  have h : env783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans782_783 : H12AffineEnvironment.transform 27 16384 env782 = env783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 16384 env782 == env783) = true)

def env784 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2080,17375733,13108377,525568,0,34359738368,25691699]

theorem envBound784 : H12AffineFastState.Bounded env784 := by
  intro p hp
  have h : env784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans783_784 : H12AffineEnvironment.transform 14 8692 env783 = env784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8692 env783 == env784) = true)

theorem identity784 : scanCanonicalize (H12AffineFastState.compose env784 (packedSelected [7,20,27,35] rootPS)) = affineNative (2^(23+1) ^^^ 8913971) := by decide +kernel

theorem selectedBound784 : packedSelected [7,20,27,35] rootPS < 2^1333 := by decide +kernel

def env785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,4194304,8388608,8913971,8328,8914000,9176216,16384,151553,2080,8463814,13108377,525568,0,34359738368,512]

theorem envBound785 : H12AffineFastState.Bounded env785 := by
  intro p hp
  have h : env785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans784_785 : H12AffineEnvironment.transform 23 8913971 env784 = env785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8913971 env784 == env785) = true)

theorem identity785 : scanCanonicalize (H12AffineFastState.compose env785 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(21+1) ^^^ 525344) := by decide +kernel

theorem selectedBound785 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,524288,8692,2097152,525344,8388608,8913971,8328,8914000,9176216,16384,151553,2080,8463814,8388793,525568,0,34359738368,512]

theorem envBound786 : H12AffineFastState.Bounded env786 := by
  intro p hp
  have h : env786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans785_786 : H12AffineEnvironment.transform 21 525344 env785 = env786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 525344 env785 == env786) = true)

theorem identity786 : scanCanonicalize (H12AffineFastState.compose env786 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(18+1) ^^^ 75134) := by decide +kernel

theorem selectedBound786 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462669,8328,8462638,8724966,16384,151553,2080,8463814,8388793,73854,0,34359738368,512]

theorem envBound787 : H12AffineFastState.Bounded env787 := by
  intro p hp
  have h : env787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans786_787 : H12AffineEnvironment.transform 18 75134 env786 = env787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 75134 env786 == env787) = true)

theorem identity787 : scanCanonicalize (H12AffineFastState.compose env787 (packedSelected [0,3,5,7,10,20] rootPS)) = affineNative (2^(34+1) ^^^ 131333) := by decide +kernel

theorem selectedBound787 : packedSelected [0,3,5,7,10,20] rootPS < 2^1333 := by decide +kernel

def env788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,8388608,8462669,8328,8462638,8724966,16384,151553,2080,8463814,8388793,73854,0,131333,512]

theorem envBound788 : H12AffineFastState.Bounded env788 := by
  intro p hp
  have h : env788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans787_788 : H12AffineEnvironment.transform 34 131333 env787 = env788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131333 env787 == env788) = true)

def env789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,184,74229,8328,74134,336222,16384,151553,2080,75134,1,73854,0,131333,512]

theorem envBound789 : H12AffineFastState.Bounded env789 := by
  intro p hp
  have h : env789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans788_789 : H12AffineEnvironment.transform 22 184 env788 = env789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 184 env788 == env789) = true)

theorem identity789 : scanCanonicalize (H12AffineFastState.compose env789 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound789 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env790 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,262144,74883,8201,2097152,73891,184,73736,8328,73835,336035,16384,151553,2080,74883,1,73854,0,131320,512]

theorem envBound790 : H12AffineFastState.Bounded env790 := by
  intro p hp
  have h : env790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans789_790 : H12AffineEnvironment.transform 7 253 env789 = env790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env789 == env790) = true)

def env791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,262144,75134,8692,2097152,74078,185,74228,8328,74135,336223,16384,151553,2080,75135,0,73854,0,131333,512]

theorem envBound791 : H12AffineFastState.Bounded env791 := by
  intro p hp
  have h : env791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans788_791 : H12AffineEnvironment.transform 22 185 env788 = env791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 185 env788 == env791) = true)

theorem identity791 : scanCanonicalize (H12AffineFastState.compose env791 (packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS)) = affineNative (2^(17+1) ^^^ 223322) := by decide +kernel

theorem selectedBound791 : packedSelected [0,2,3,5,6,10,11,12,13,14,15,23,27] rootPS < 2^1333 := by decide +kernel

def env792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8692,65536,131072,223322,75134,8692,2097152,74078,185,74228,8328,74135,149765,16384,151553,2080,75135,0,73854,0,131333,512]

theorem envBound792 : H12AffineFastState.Bounded env792 := by
  intro p hp
  have h : env792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans791_792 : H12AffineEnvironment.transform 17 223322 env791 = env792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 223322 env791 == env792) = true)

def env793 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74882,8200,2097152,73890,185,73736,8328,73835,149753,16384,151553,2080,74883,0,73854,0,131321,512]

theorem envBound793 : H12AffineFastState.Bounded env793 := by
  intro p hp
  have h : env793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans792_793 : H12AffineEnvironment.transform 7 252 env792 = env793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env792 == env793) = true)

theorem identity793 : scanCanonicalize (H12AffineFastState.compose env793 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 151553) := by decide +kernel

theorem selectedBound793 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env794 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,131072,223322,74882,8200,151553,73890,185,73736,8328,73835,149753,16384,151553,2080,74883,0,73854,0,131321,512]

theorem envBound794 : H12AffineFastState.Bounded env794 := by
  intro p hp
  have h : env794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans793_794 : H12AffineEnvironment.transform 20 151553 env793 = env794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 151553 env793 == env794) = true)

theorem identity794 : scanCanonicalize (H12AffineFastState.compose env794 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(16+1) ^^^ 90234) := by decide +kernel

theorem selectedBound794 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env795 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,65536,90234,2080,74882,8200,77947,73890,185,73736,8328,73835,75907,16384,77947,2080,74883,0,73854,0,90243,512]

theorem envBound795 : H12AffineFastState.Bounded env795 := by
  intro p hp
  have h : env795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans794_795 : H12AffineEnvironment.transform 16 90234 env794 = env795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90234 env794 == env795) = true)

theorem identity795 : scanCanonicalize (H12AffineFastState.compose env795 (packedSelected [1,5,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound795 : packedSelected [1,5,7,9] rootPS < 2^1333 := by decide +kernel

def env796 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8200,8323,16633,2080,1025,8200,4344,33,185,139,8328,232,2048,16384,4344,2080,1024,0,253,0,16384,512]

theorem envBound796 : H12AffineFastState.Bounded env796 := by
  intro p hp
  have h : env796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans795_796 : H12AffineEnvironment.transform 15 8323 env795 = env796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env795 == env796) = true)

theorem identity796 : scanCanonicalize (H12AffineFastState.compose env796 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env797 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,5236,8200,8323,5261,2080,1025,8200,4344,33,185,139,8328,232,2048,5236,4344,2080,1024,0,253,0,5236,512]

theorem envBound797 : H12AffineFastState.Bounded env797 := by
  intro p hp
  have h : env797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans796_797 : H12AffineEnvironment.transform 13 5236 env796 = env797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env796 == env797) = true)

theorem identity797 : scanCanonicalize (H12AffineFastState.compose env797 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 1583) := by decide +kernel

theorem selectedBound797 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env798 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,8192,603,8200,8323,674,2080,1025,8200,1751,33,185,139,8328,232,2048,603,1751,2080,1024,0,253,0,603,512]

theorem envBound798 : H12AffineFastState.Bounded env798 := by
  intro p hp
  have h : env798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans797_798 : H12AffineEnvironment.transform 11 1583 env797 = env798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1583 env797 == env798) = true)

theorem identity798 : scanCanonicalize (H12AffineFastState.compose env798 (packedSelected [3,5] rootPS)) = affineNative (2^(12+1) ^^^ 3823) := by decide +kernel

theorem selectedBound798 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env799 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,1583,3823,603,3815,3692,674,2080,1025,3815,1751,33,185,139,3687,232,2048,603,1751,2080,1024,0,253,0,603,512]

theorem envBound799 : H12AffineFastState.Bounded env799 := by
  intro p hp
  have h : env799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans798_799 : H12AffineEnvironment.transform 12 3823 env798 = env799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3823 env798 == env799) = true)

theorem identity799 : scanCanonicalize (H12AffineFastState.compose env799 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound799 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env800 : List Nat := [2,4,8,16,32,64,128,252,512,5,2048,554,2794,603,2786,2665,674,2080,4,2786,722,33,185,139,2658,232,2048,603,722,2080,5,0,253,0,603,512]

theorem envBound800 : H12AffineFastState.Bounded env800 := by
  intro p hp
  have h : env800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans799_800 : H12AffineEnvironment.transform 9 5 env799 = env800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env799 == env800) = true)

theorem identity800 : scanCanonicalize (H12AffineFastState.compose env800 (packedSelected [1,3,11] rootPS)) = affineNative (2^(6+1) ^^^ 120) := by decide +kernel

theorem selectedBound800 : packedSelected [1,3,11] rootPS < 2^1333 := by decide +kernel

def env801 : List Nat := [2,4,8,16,32,64,120,4,512,5,2048,554,2578,603,2586,2665,602,2080,4,2586,554,33,65,115,2658,16,2048,603,554,2080,5,0,5,0,603,512]

theorem envBound801 : H12AffineFastState.Bounded env801 := by
  intro p hp
  have h : env801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans800_801 : H12AffineEnvironment.transform 6 120 env800 = env801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 120 env800 == env801) = true)

theorem identity801 : scanCanonicalize (H12AffineFastState.compose env801 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 608) := by decide +kernel

theorem selectedBound801 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env802 : List Nat := [2,4,8,16,32,64,120,4,512,5,608,554,114,603,122,9,602,576,4,122,554,33,65,115,2,16,608,603,554,576,5,0,5,0,603,512]

theorem envBound802 : H12AffineFastState.Bounded env802 := by
  intro p hp
  have h : env802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans801_802 : H12AffineEnvironment.transform 10 608 env801 = env802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 608 env801 == env802) = true)

theorem identity802 : scanCanonicalize (H12AffineFastState.compose env802 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound802 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env803 : List Nat := [2,4,8,16,27,64,67,4,512,5,603,529,73,603,65,9,602,576,4,65,529,26,65,72,2,16,603,603,529,576,5,0,5,0,603,512]

theorem envBound803 : H12AffineFastState.Bounded env803 := by
  intro p hp
  have h : env803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans802_803 : H12AffineEnvironment.transform 4 27 env802 = env803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env802 == env803) = true)

def env804 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74883,8201,2097152,73891,185,73737,8328,73834,149752,16384,151553,2080,74882,0,73854,0,131320,512]

theorem envBound804 : H12AffineFastState.Bounded env804 := by
  intro p hp
  have h : env804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans792_804 : H12AffineEnvironment.transform 7 253 env792 = env804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env792 == env804) = true)

theorem identity804 : scanCanonicalize (H12AffineFastState.compose env804 (packedSelected [0,1,4,5,6] rootPS)) = affineNative (2^(20+1) ^^^ 78035) := by decide +kernel

theorem selectedBound804 : packedSelected [0,1,4,5,6] rootPS < 2^1333 := by decide +kernel

def env805 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8201,65536,131072,223322,74883,8201,78035,73891,185,73737,8328,73834,149752,16384,151553,2080,74882,0,73854,0,131320,512]

theorem envBound805 : H12AffineFastState.Bounded env805 := by
  intro p hp
  have h : env805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans804_805 : H12AffineEnvironment.transform 20 78035 env804 = env805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 78035 env804 == env805) = true)

theorem identity805 : scanCanonicalize (H12AffineFastState.compose env805 (packedSelected [1,2,3] rootPS)) = affineNative (2^(13+1) ^^^ 7695) := by decide +kernel

theorem selectedBound805 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env806 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,7695,8201,65536,131072,210517,74883,8201,78035,73891,185,73737,8328,73834,136951,7695,134670,2080,74882,0,73854,0,131320,512]

theorem envBound806 : H12AffineFastState.Bounded env806 := by
  intro p hp
  have h : env806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans805_806 : H12AffineEnvironment.transform 13 7695 env805 = env806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7695 env805 == env806) = true)

def env807 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,131072,205377,74883,8201,74951,73891,185,73737,8328,73834,131811,2587,134670,2080,74882,0,73854,0,131320,512]

theorem envBound807 : H12AffineFastState.Bounded env807 := by
  intro p hp
  have h : env807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans806_807 : H12AffineEnvironment.transform 11 1044 env806 = env807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1044 env806 == env807) = true)

def env808 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76384,2081,74883,8201,74951,73891,185,73737,8328,73834,75907,2587,74862,2080,74882,0,73854,0,76440,512]

theorem envBound808 : H12AffineFastState.Bounded env808 := by
  intro p hp
  have h : env808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans807_808 : H12AffineEnvironment.transform 16 76384 env807 = env808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env807 == env808) = true)

theorem identity808 : scanCanonicalize (H12AffineFastState.compose env808 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound808 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env809 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2587,3615,65536,66678,2081,68245,3615,68305,69301,185,69151,3742,69244,67221,2587,68216,2080,68244,0,69224,0,66702,512]

theorem envBound809 : H12AffineFastState.Bounded env809 := by
  intro p hp
  have h : env809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans808_809 : H12AffineEnvironment.transform 12 3606 env808 = env809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env808 == env809) = true)

theorem identity809 : scanCanonicalize (H12AffineFastState.compose env809 (packedSelected [2,13] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound809 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env810 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,3606,2587,3615,3732,2786,2081,1025,3615,1093,33,185,139,3742,232,2049,2587,1260,2080,1024,0,252,0,2586,512]

theorem envBound810 : H12AffineFastState.Bounded env810 := by
  intro p hp
  have h : env810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans809_810 : H12AffineEnvironment.transform 15 3732 env809 = env810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env809 == env810) = true)

theorem identity810 : scanCanonicalize (H12AffineFastState.compose env810 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound810 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env811 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,64,2626,2587,2635,2752,2786,2081,85,2635,17,33,185,139,2762,232,2049,2587,184,2080,84,0,252,0,2586,512]

theorem envBound811 : H12AffineFastState.Bounded env811 := by
  intro p hp
  have h : env811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans810_811 : H12AffineEnvironment.transform 9 84 env810 = env811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env810 == env811) = true)

theorem identity811 : scanCanonicalize (H12AffineFastState.compose env811 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound811 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env812 : List Nat := [2,4,8,16,32,64,41,84,512,84,2048,64,2626,2587,2635,2665,2635,2081,85,2635,17,33,16,34,2659,65,2049,2587,17,2080,84,0,85,0,2586,512]

theorem envBound812 : H12AffineFastState.Bounded env812 := by
  intro p hp
  have h : env812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans811_812 : H12AffineEnvironment.transform 6 41 env811 = env812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env811 == env812) = true)

def env813 : List Nat := [2,4,8,16,16,64,25,84,512,84,2048,64,2626,2587,2635,2649,2635,2065,85,2635,17,17,16,18,2643,65,2049,2587,17,2064,84,0,85,0,2586,512]

theorem envBound813 : H12AffineFastState.Bounded env813 := by
  intro p hp
  have h : env813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans812_813 : H12AffineEnvironment.transform 4 16 env812 = env813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env812 == env813) = true)

def env814 : List Nat := [2,4,8,16,16,64,25,84,512,84,0,64,578,539,587,601,587,17,85,587,17,17,16,18,595,65,1,539,17,16,84,0,85,0,538,512]

theorem envBound814 : H12AffineFastState.Bounded env814 := by
  intro p hp
  have h : env814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans813_814 : H12AffineEnvironment.transform 10 0 env813 = env814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env813 == env814) = true)

theorem identity814 : scanCanonicalize (H12AffineFastState.compose env814 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 86) := by decide +kernel

theorem selectedBound814 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env815 : List Nat := [2,4,8,16,16,64,25,84,86,84,0,64,20,77,29,15,29,17,85,29,17,17,16,18,5,65,1,77,17,16,84,0,85,0,76,86]

theorem envBound815 : H12AffineFastState.Bounded env815 := by
  intro p hp
  have h : env815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans814_815 : H12AffineEnvironment.transform 8 86 env814 = env815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 86 env814 == env815) = true)

def env816 : List Nat := [2,4,8,16,16,0,25,20,22,20,0,0,20,13,29,15,29,17,21,29,17,17,16,18,5,1,1,13,17,16,20,0,21,0,12,22]

theorem envBound816 : H12AffineFastState.Bounded env816 := by
  intro p hp
  have h : env816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans815_816 : H12AffineEnvironment.transform 5 0 env815 = env816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env815 == env816) = true)

theorem identity816 : scanCanonicalize (H12AffineFastState.compose env816 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound816 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env817 : List Nat := [2,4,5,16,16,0,20,20,22,20,0,0,20,0,16,2,16,17,21,16,17,17,16,18,5,1,1,0,17,16,20,0,21,0,1,22]

theorem envBound817 : H12AffineFastState.Bounded env817 := by
  intro p hp
  have h : env817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans816_817 : H12AffineEnvironment.transform 2 5 env816 = env817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env816 == env817) = true)

def leafEnv817 : List Nat := [2,4,5,16,16,0,20,20,22,20,0,0,20,0,16,2,16,17,21,16,17,17,16,18,20,5,1,1,1,0,17,16,20,0,21,0,4,18,1,22,1,16,0]

def active817 : List Nat := [0,1,3]

def tree817 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood817 : H12WitnessSearch.Good tree817 := H12GlobalWitnessIndex.good

theorem leafIdentity817 : H12AffineFastState.composeSystem env817 rootObs = leafEnv817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env817 rootObs == leafEnv817) = true)

theorem terminalChecked817 : H12PackedTerminal.terminalCheckFast leafEnv817 active817 tree817 = true := by decide +kernel

def env818 : List Nat := [2,4,8,16,16,1,25,21,23,21,0,1,20,12,29,15,29,17,20,29,17,17,16,18,5,0,1,12,17,16,21,0,20,0,13,23]

theorem envBound818 : H12AffineFastState.Bounded env818 := by
  intro p hp
  have h : env818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans815_818 : H12AffineEnvironment.transform 5 1 env815 = env818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env815 == env818) = true)

def leafEnv818 : List Nat := [2,4,8,16,16,1,25,21,23,21,0,1,20,12,29,15,29,17,20,29,17,17,16,18,21,5,1,0,1,12,17,16,21,0,20,0,4,31,13,23,1,16,0]

def active818 : List Nat := [0,1,2,3]

def tree818 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood818 : H12WitnessSearch.Good tree818 := H12GlobalWitnessIndex.good

theorem leafIdentity818 : H12AffineFastState.composeSystem env818 rootObs = leafEnv818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env818 rootObs == leafEnv818) = true)

theorem terminalChecked818 : H12PackedTerminal.terminalCheckFast leafEnv818 active818 tree818 = true := by decide +kernel

def env819 : List Nat := [2,4,8,16,16,64,25,84,512,84,1,64,579,538,586,600,586,16,85,586,17,17,16,18,594,65,0,538,17,17,84,0,85,0,539,512]

theorem envBound819 : H12AffineFastState.Bounded env819 := by
  intro p hp
  have h : env819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans813_819 : H12AffineEnvironment.transform 10 1 env813 = env819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env813 == env819) = true)

theorem identity819 : scanCanonicalize (H12AffineFastState.compose env819 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 71) := by decide +kernel

theorem selectedBound819 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env820 : List Nat := [2,4,8,16,16,64,25,84,71,84,1,64,4,93,13,31,13,16,85,13,17,17,16,18,21,65,0,93,17,17,84,0,85,0,92,71]

theorem envBound820 : H12AffineFastState.Bounded env820 := by
  intro p hp
  have h : env820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans819_820 : H12AffineEnvironment.transform 8 71 env819 = env820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 71 env819 == env820) = true)

def env821 : List Nat := [2,4,8,16,16,0,25,20,7,20,1,0,4,29,13,31,13,16,21,13,17,17,16,18,21,1,0,29,17,17,20,0,21,0,28,7]

theorem envBound821 : H12AffineFastState.Bounded env821 := by
  intro p hp
  have h : env821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans820_821 : H12AffineEnvironment.transform 5 0 env820 = env821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env820 == env821) = true)

def leafEnv821 : List Nat := [2,4,8,16,16,0,25,20,7,20,1,0,4,29,13,31,13,16,21,13,17,17,16,18,20,21,1,1,0,29,17,17,20,0,21,0,4,15,28,7,1,16,0]

def active821 : List Nat := [0,1,2,3]

def tree821 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood821 : H12WitnessSearch.Good tree821 := H12GlobalWitnessIndex.good

theorem leafIdentity821 : H12AffineFastState.composeSystem env821 rootObs = leafEnv821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env821 rootObs == leafEnv821) = true)

theorem terminalChecked821 : H12PackedTerminal.terminalCheckFast leafEnv821 active821 tree821 = true := by decide +kernel

def env822 : List Nat := [2,4,8,16,16,1,25,21,6,21,1,1,4,28,13,31,13,16,20,13,17,17,16,18,21,0,0,28,17,17,21,0,20,0,29,6]

theorem envBound822 : H12AffineFastState.Bounded env822 := by
  intro p hp
  have h : env822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans820_822 : H12AffineEnvironment.transform 5 1 env820 = env822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env820 == env822) = true)

theorem identity822 : scanCanonicalize (H12AffineFastState.compose env822 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 12) := by decide +kernel

theorem selectedBound822 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env823 : List Nat := [2,4,8,12,12,1,5,9,6,9,1,1,4,0,13,3,13,12,8,13,13,13,12,14,9,0,0,0,13,13,9,0,8,0,1,6]

theorem envBound823 : H12AffineFastState.Bounded env823 := by
  intro p hp
  have h : env823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans822_823 : H12AffineEnvironment.transform 3 12 env822 = env823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env822 == env823) = true)

def leafEnv823 : List Nat := [2,4,8,12,12,1,5,9,6,9,1,1,4,0,13,3,13,12,8,13,13,13,12,14,9,9,1,0,0,0,13,13,9,0,8,0,4,15,1,6,1,12,0]

def active823 : List Nat := [0,1,2]

def tree823 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood823 : H12WitnessSearch.Good tree823 := H12GlobalWitnessIndex.good

theorem leafIdentity823 : H12AffineFastState.composeSystem env823 rootObs = leafEnv823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env823 rootObs == leafEnv823) = true)

theorem terminalChecked823 : H12PackedTerminal.terminalCheckFast leafEnv823 active823 tree823 = true := by decide +kernel

def env824 : List Nat := [2,4,8,16,17,64,24,84,512,84,2048,64,2626,2587,2635,2648,2635,2064,85,2635,17,16,16,19,2642,65,2049,2587,17,2065,84,0,85,0,2586,512]

theorem envBound824 : H12AffineFastState.Bounded env824 := by
  intro p hp
  have h : env824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans812_824 : H12AffineEnvironment.transform 4 17 env812 = env824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env812 == env824) = true)

def env825 : List Nat := [2,4,8,16,17,64,24,84,512,84,0,64,578,539,587,600,587,16,85,587,17,16,16,19,594,65,1,539,17,17,84,0,85,0,538,512]

theorem envBound825 : H12AffineFastState.Bounded env825 := by
  intro p hp
  have h : env825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans824_825 : H12AffineEnvironment.transform 10 0 env824 = env825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env824 == env825) = true)

theorem identity825 : scanCanonicalize (H12AffineFastState.compose env825 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound825 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env826 : List Nat := [2,4,8,13,12,64,5,73,512,73,0,64,578,518,587,581,587,13,72,587,12,13,13,14,591,65,1,518,12,12,73,0,72,0,519,512]

theorem envBound826 : H12AffineFastState.Bounded env826 := by
  intro p hp
  have h : env826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans825_826 : H12AffineEnvironment.transform 3 13 env825 = env826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env825 == env826) = true)

def env827 : List Nat := [2,4,8,13,12,0,5,9,512,9,0,0,514,518,523,517,523,13,8,523,12,13,13,14,527,1,1,518,12,12,9,0,8,0,519,512]

theorem envBound827 : H12AffineFastState.Bounded env827 := by
  intro p hp
  have h : env827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans826_827 : H12AffineEnvironment.transform 5 0 env826 = env827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env826 == env827) = true)

theorem identity827 : scanCanonicalize (H12AffineFastState.compose env827 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound827 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env828 : List Nat := [2,4,8,13,12,0,5,9,7,9,0,0,5,1,12,2,12,13,8,12,12,13,13,14,8,1,1,1,12,12,9,0,8,0,0,7]

theorem envBound828 : H12AffineFastState.Bounded env828 := by
  intro p hp
  have h : env828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans827_828 : H12AffineEnvironment.transform 8 7 env827 = env828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env827 == env828) = true)

def leafEnv828 : List Nat := [2,4,8,13,12,0,5,9,7,9,0,0,5,1,12,2,12,13,8,12,12,13,13,14,9,8,1,1,1,1,12,12,9,0,8,0,4,14,0,7,1,13,0]

def active828 : List Nat := [0,1,2]

def tree828 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood828 : H12WitnessSearch.Good tree828 := H12GlobalWitnessIndex.good

theorem leafIdentity828 : H12AffineFastState.composeSystem env828 rootObs = leafEnv828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env828 rootObs == leafEnv828) = true)

theorem terminalChecked828 : H12PackedTerminal.terminalCheckFast leafEnv828 active828 tree828 = true := by decide +kernel

def env829 : List Nat := [2,4,8,13,12,1,5,8,512,8,0,1,515,518,522,516,522,13,9,522,12,13,13,14,526,0,1,518,12,12,8,0,9,0,519,512]

theorem envBound829 : H12AffineFastState.Bounded env829 := by
  intro p hp
  have h : env829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans826_829 : H12AffineEnvironment.transform 5 1 env826 = env829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env826 == env829) = true)

def leafEnv829 : List Nat := [2,4,8,13,12,1,5,8,512,8,0,1,515,518,522,516,522,13,9,522,12,13,13,14,8,526,1,0,1,518,12,12,8,0,9,0,4,520,519,512,1,13,0]

def active829 : List Nat := [0,1,2,8]

def tree829 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood829 : H12WitnessSearch.Good tree829 := H12GlobalWitnessIndex.good

theorem leafIdentity829 : H12AffineFastState.composeSystem env829 rootObs = leafEnv829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env829 rootObs == leafEnv829) = true)

theorem terminalChecked829 : H12PackedTerminal.terminalCheckFast leafEnv829 active829 tree829 = true := by decide +kernel

def env830 : List Nat := [2,4,8,16,17,64,24,84,512,84,1,64,579,538,586,601,586,17,85,586,17,16,16,19,595,65,0,538,17,16,84,0,85,0,539,512]

theorem envBound830 : H12AffineFastState.Bounded env830 := by
  intro p hp
  have h : env830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans824_830 : H12AffineEnvironment.transform 10 1 env824 = env830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env824 == env830) = true)

theorem identity830 : scanCanonicalize (H12AffineFastState.compose env830 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound830 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env831 : List Nat := [2,4,4,16,17,64,20,84,512,84,1,64,579,534,582,597,582,17,85,582,17,16,16,19,595,65,0,534,17,16,84,0,85,0,535,512]

theorem envBound831 : H12AffineFastState.Bounded env831 := by
  intro p hp
  have h : env831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans830_831 : H12AffineEnvironment.transform 2 4 env830 = env831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env830 == env831) = true)

def env832 : List Nat := [2,4,4,16,17,0,20,20,512,20,1,0,515,534,518,533,518,17,21,518,17,16,16,19,531,1,0,534,17,16,20,0,21,0,535,512]

theorem envBound832 : H12AffineFastState.Bounded env832 := by
  intro p hp
  have h : env832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans831_832 : H12AffineEnvironment.transform 5 0 env831 = env832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env831 == env832) = true)

def leafEnv832 : List Nat := [2,4,4,16,17,0,20,20,512,20,1,0,515,534,518,533,518,17,21,518,17,16,16,19,20,531,1,1,0,534,17,16,20,0,21,0,4,516,535,512,1,16,0]

def active832 : List Nat := [0,1,3,8]

def tree832 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood832 : H12WitnessSearch.Good tree832 := H12GlobalWitnessIndex.good

theorem leafIdentity832 : H12AffineFastState.composeSystem env832 rootObs = leafEnv832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env832 rootObs == leafEnv832) = true)

theorem terminalChecked832 : H12PackedTerminal.terminalCheckFast leafEnv832 active832 tree832 = true := by decide +kernel

def env833 : List Nat := [2,4,4,16,17,1,20,21,512,21,1,1,514,534,519,532,519,17,20,519,17,16,16,19,530,0,0,534,17,16,21,0,20,0,535,512]

theorem envBound833 : H12AffineFastState.Bounded env833 := by
  intro p hp
  have h : env833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans831_833 : H12AffineEnvironment.transform 5 1 env831 = env833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env831 == env833) = true)

theorem identity833 : scanCanonicalize (H12AffineFastState.compose env833 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound833 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env834 : List Nat := [2,4,4,16,17,1,20,21,23,21,1,1,21,1,16,3,16,17,20,16,17,16,16,19,5,0,0,1,17,16,21,0,20,0,0,23]

theorem envBound834 : H12AffineFastState.Bounded env834 := by
  intro p hp
  have h : env834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans833_834 : H12AffineEnvironment.transform 8 23 env833 = env834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env833 == env834) = true)

def leafEnv834 : List Nat := [2,4,4,16,17,1,20,21,23,21,1,1,21,1,16,3,16,17,20,16,17,16,16,19,21,5,1,0,0,1,17,16,21,0,20,0,4,18,0,23,1,16,0]

def active834 : List Nat := [0,1,3]

def tree834 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood834 : H12WitnessSearch.Good tree834 := H12GlobalWitnessIndex.good

theorem leafIdentity834 : H12AffineFastState.composeSystem env834 rootObs = leafEnv834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env834 rootObs == leafEnv834) = true)

theorem terminalChecked834 : H12PackedTerminal.terminalCheckFast leafEnv834 active834 tree834 = true := by decide +kernel

def env835 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,65536,76385,2080,74883,8201,74951,73891,185,73737,8328,73834,75906,2587,74863,2080,74882,0,73854,0,76441,512]

theorem envBound835 : H12AffineFastState.Bounded env835 := by
  intro p hp
  have h : env835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans807_835 : H12AffineEnvironment.transform 16 76385 env807 = env835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env807 == env835) = true)

theorem identity835 : scanCanonicalize (H12AffineFastState.compose env835 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 98) := by decide +kernel

theorem selectedBound835 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env836 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1044,8192,2587,8201,98,10755,2080,9441,8201,9381,8385,185,8299,8328,8200,10464,2587,9229,2080,9440,0,8220,0,11003,512]

theorem envBound836 : H12AffineFastState.Bounded env836 := by
  intro p hp
  have h : env836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans835_836 : H12AffineEnvironment.transform 15 98 env835 = env836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 98 env835 == env836) = true)

def env837 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,131072,205376,74883,8201,74950,73891,185,73737,8328,73834,131810,2586,134670,2080,74882,0,73854,0,131320,512]

theorem envBound837 : H12AffineFastState.Bounded env837 := by
  intro p hp
  have h : env837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans806_837 : H12AffineEnvironment.transform 11 1045 env806 = env837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1045 env806 == env837) = true)

def env838 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76384,2080,74883,8201,74950,73891,185,73737,8328,73834,75906,2586,74862,2080,74882,0,73854,0,76440,512]

theorem envBound838 : H12AffineFastState.Bounded env838 := by
  intro p hp
  have h : env838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans837_838 : H12AffineEnvironment.transform 16 76384 env837 = env838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76384 env837 == env838) = true)

theorem identity838 : scanCanonicalize (H12AffineFastState.compose env838 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(12+1) ^^^ 224) := by decide +kernel

theorem selectedBound838 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env839 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,224,2586,233,65536,68224,2080,66659,233,66598,65603,185,65769,104,65674,67682,2586,66702,2080,66658,0,65694,0,68216,512]

theorem envBound839 : H12AffineFastState.Bounded env839 := by
  intro p hp
  have h : env839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans838_839 : H12AffineEnvironment.transform 12 224 env838 = env839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 224 env838 == env839) = true)

def env840 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,65536,76385,2081,74883,8201,74950,73891,185,73737,8328,73834,75907,2586,74863,2080,74882,0,73854,0,76441,512]

theorem envBound840 : H12AffineFastState.Bounded env840 := by
  intro p hp
  have h : env840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans837_840 : H12AffineEnvironment.transform 16 76385 env837 = env840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 76385 env837 == env840) = true)

theorem identity840 : scanCanonicalize (H12AffineFastState.compose env840 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(15+1) ^^^ 3732) := by decide +kernel

theorem selectedBound840 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env841 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,8192,2586,8201,3732,9461,2081,10775,8201,10834,11831,185,11933,8328,12030,9751,2586,11003,2080,10774,0,12010,0,9229,512]

theorem envBound841 : H12AffineFastState.Bounded env841 := by
  intro p hp
  have h : env841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans840_841 : H12AffineEnvironment.transform 15 3732 env840 = env841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 3732 env840 == env841) = true)

theorem identity841 : scanCanonicalize (H12AffineFastState.compose env841 (packedSelected [2,13] rootPS)) = affineNative (2^(12+1) ^^^ 3606) := by decide +kernel

theorem selectedBound841 : packedSelected [2,13] rootPS < 2^1333 := by decide +kernel

def env842 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,1045,3606,2586,3615,3732,2787,2081,1025,3615,1092,33,185,139,3742,232,2049,2586,1261,2080,1024,0,252,0,2587,512]

theorem envBound842 : H12AffineFastState.Bounded env842 := by
  intro p hp
  have h : env842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans841_842 : H12AffineEnvironment.transform 12 3606 env841 = env842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3606 env841 == env842) = true)

theorem identity842 : scanCanonicalize (H12AffineFastState.compose env842 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 84) := by decide +kernel

theorem selectedBound842 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env843 : List Nat := [2,4,8,16,32,64,128,253,512,84,2048,65,2626,2586,2635,2752,2787,2081,85,2635,16,33,185,139,2762,232,2049,2586,185,2080,84,0,252,0,2587,512]

theorem envBound843 : H12AffineFastState.Bounded env843 := by
  intro p hp
  have h : env843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans842_843 : H12AffineEnvironment.transform 9 84 env842 = env843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 84 env842 == env843) = true)

theorem identity843 : scanCanonicalize (H12AffineFastState.compose env843 (packedSelected [0,7] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound843 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env844 : List Nat := [2,4,8,16,32,64,41,84,512,84,2048,65,2626,2586,2635,2665,2634,2081,85,2635,16,33,16,34,2659,65,2049,2586,16,2080,84,0,85,0,2587,512]

theorem envBound844 : H12AffineFastState.Bounded env844 := by
  intro p hp
  have h : env844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans843_844 : H12AffineEnvironment.transform 6 41 env843 = env844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env843 == env844) = true)

def env845 : List Nat := [2,4,8,16,16,64,25,84,512,84,2048,65,2626,2586,2635,2649,2634,2065,85,2635,16,17,16,18,2643,65,2049,2586,16,2064,84,0,85,0,2587,512]

theorem envBound845 : H12AffineFastState.Bounded env845 := by
  intro p hp
  have h : env845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans844_845 : H12AffineEnvironment.transform 4 16 env844 = env845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env844 == env845) = true)

def env846 : List Nat := [2,4,8,16,16,64,25,84,512,84,0,65,578,538,587,601,586,17,85,587,16,17,16,18,595,65,1,538,16,16,84,0,85,0,539,512]

theorem envBound846 : H12AffineFastState.Bounded env846 := by
  intro p hp
  have h : env846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans845_846 : H12AffineEnvironment.transform 10 0 env845 = env846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env845 == env846) = true)

theorem identity846 : scanCanonicalize (H12AffineFastState.compose env846 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 29) := by decide +kernel

theorem selectedBound846 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env847 : List Nat := [2,4,8,16,16,29,25,9,512,9,0,28,543,538,534,516,535,17,8,534,16,17,16,18,526,28,1,538,16,16,9,0,8,0,539,512]

theorem envBound847 : H12AffineFastState.Bounded env847 := by
  intro p hp
  have h : env847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans846_847 : H12AffineEnvironment.transform 5 29 env846 = env847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 29 env846 == env847) = true)

def env848 : List Nat := [2,4,8,12,12,1,5,9,512,9,0,0,515,518,522,516,523,13,8,522,12,13,12,14,526,0,1,518,12,12,9,0,8,0,519,512]

theorem envBound848 : H12AffineFastState.Bounded env848 := by
  intro p hp
  have h : env848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans847_848 : H12AffineEnvironment.transform 3 12 env847 = env848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 12 env847 == env848) = true)

theorem identity848 : scanCanonicalize (H12AffineFastState.compose env848 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound848 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env849 : List Nat := [2,4,8,12,12,1,5,9,7,9,0,0,4,1,13,3,12,13,8,13,12,13,12,14,9,0,1,1,12,12,9,0,8,0,0,7]

theorem envBound849 : H12AffineFastState.Bounded env849 := by
  intro p hp
  have h : env849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans848_849 : H12AffineEnvironment.transform 8 7 env848 = env849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env848 == env849) = true)

def leafEnv849 : List Nat := [2,4,8,12,12,1,5,9,7,9,0,0,4,1,13,3,12,13,8,13,12,13,12,14,9,9,1,0,1,1,12,12,9,0,8,0,4,15,0,7,1,13,0]

def active849 : List Nat := [0,1,2]

def tree849 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood849 : H12WitnessSearch.Good tree849 := H12GlobalWitnessIndex.good

theorem leafIdentity849 : H12AffineFastState.composeSystem env849 rootObs = leafEnv849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env849 rootObs == leafEnv849) = true)

theorem terminalChecked849 : H12PackedTerminal.terminalCheckFast leafEnv849 active849 tree849 = true := by decide +kernel

def env850 : List Nat := [2,4,8,13,13,0,4,9,512,9,0,1,514,519,523,516,522,12,8,523,13,12,13,15,526,1,1,519,13,13,9,0,8,0,518,512]

theorem envBound850 : H12AffineFastState.Bounded env850 := by
  intro p hp
  have h : env850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans847_850 : H12AffineEnvironment.transform 3 13 env847 = env850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env847 == env850) = true)

def leafEnv850 : List Nat := [2,4,8,13,13,0,4,9,512,9,0,1,514,519,523,516,522,12,8,523,13,12,13,15,9,526,1,1,1,519,13,13,9,0,8,0,4,521,518,512,1,12,0]

def active850 : List Nat := [0,1,2,8]

def tree850 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood850 : H12WitnessSearch.Good tree850 := H12GlobalWitnessIndex.good

theorem leafIdentity850 : H12AffineFastState.composeSystem env850 rootObs = leafEnv850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env850 rootObs == leafEnv850) = true)

theorem terminalChecked850 : H12PackedTerminal.terminalCheckFast leafEnv850 active850 tree850 = true := by decide +kernel

def env851 : List Nat := [2,4,8,16,16,64,25,84,512,84,1,65,579,539,586,600,587,16,85,586,16,17,16,18,594,65,0,539,16,17,84,0,85,0,538,512]

theorem envBound851 : H12AffineFastState.Bounded env851 := by
  intro p hp
  have h : env851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans845_851 : H12AffineEnvironment.transform 10 1 env845 = env851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env845 == env851) = true)

theorem identity851 : scanCanonicalize (H12AffineFastState.compose env851 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 13) := by decide +kernel

theorem selectedBound851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env852 : List Nat := [2,4,8,16,16,13,25,25,512,25,1,12,526,539,519,533,518,16,24,519,16,17,16,18,543,12,0,539,16,17,25,0,24,0,538,512]

theorem envBound852 : H12AffineFastState.Bounded env852 := by
  intro p hp
  have h : env852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans851_852 : H12AffineEnvironment.transform 5 13 env851 = env852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 13 env851 == env852) = true)

def env853 : List Nat := [2,4,4,16,16,1,21,21,512,21,1,0,514,535,519,533,518,16,20,519,16,17,16,18,531,0,0,535,16,17,21,0,20,0,534,512]

theorem envBound853 : H12AffineFastState.Bounded env853 := by
  intro p hp
  have h : env853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans852_853 : H12AffineEnvironment.transform 2 4 env852 = env853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env852 == env853) = true)

def leafEnv853 : List Nat := [2,4,4,16,16,1,21,21,512,21,1,0,514,535,519,533,518,16,20,519,16,17,16,18,21,531,1,0,0,535,16,17,21,0,20,0,4,517,534,512,1,17,0]

def active853 : List Nat := [0,1,3,8]

def tree853 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood853 : H12WitnessSearch.Good tree853 := H12GlobalWitnessIndex.good

theorem leafIdentity853 : H12AffineFastState.composeSystem env853 rootObs = leafEnv853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env853 rootObs == leafEnv853) = true)

theorem terminalChecked853 : H12PackedTerminal.terminalCheckFast leafEnv853 active853 tree853 = true := by decide +kernel

def env854 : List Nat := [2,4,5,16,16,0,20,20,512,20,1,1,515,534,519,533,518,16,21,519,16,17,16,18,530,1,0,534,16,17,20,0,21,0,535,512]

theorem envBound854 : H12AffineFastState.Bounded env854 := by
  intro p hp
  have h : env854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans852_854 : H12AffineEnvironment.transform 2 5 env852 = env854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env852 == env854) = true)

theorem identity854 : scanCanonicalize (H12AffineFastState.compose env854 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 23) := by decide +kernel

theorem selectedBound854 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env855 : List Nat := [2,4,5,16,16,0,20,20,23,20,1,1,20,1,16,2,17,16,21,16,16,17,16,18,5,1,0,1,16,17,20,0,21,0,0,23]

theorem envBound855 : H12AffineFastState.Bounded env855 := by
  intro p hp
  have h : env855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans854_855 : H12AffineEnvironment.transform 8 23 env854 = env855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 23 env854 == env855) = true)

def leafEnv855 : List Nat := [2,4,5,16,16,0,20,20,23,20,1,1,20,1,16,2,17,16,21,16,16,17,16,18,20,5,1,1,0,1,16,17,20,0,21,0,4,18,0,23,1,17,0]

def active855 : List Nat := [0,1,3]

def tree855 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood855 : H12WitnessSearch.Good tree855 := H12GlobalWitnessIndex.good

theorem leafIdentity855 : H12AffineFastState.composeSystem env855 rootObs = leafEnv855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env855 rootObs == leafEnv855) = true)

theorem terminalChecked855 : H12PackedTerminal.terminalCheckFast leafEnv855 active855 tree855 = true := by decide +kernel

def env856 : List Nat := [2,4,8,16,17,64,24,84,512,84,2048,65,2626,2586,2635,2648,2634,2064,85,2635,16,16,16,19,2642,65,2049,2586,16,2065,84,0,85,0,2587,512]

theorem envBound856 : H12AffineFastState.Bounded env856 := by
  intro p hp
  have h : env856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans844_856 : H12AffineEnvironment.transform 4 17 env844 = env856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 17 env844 == env856) = true)

def env857 : List Nat := [2,4,8,16,17,64,24,84,512,84,0,65,578,538,587,600,586,16,85,587,16,16,16,19,594,65,1,538,16,17,84,0,85,0,539,512]

theorem envBound857 : H12AffineFastState.Bounded env857 := by
  intro p hp
  have h : env857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans856_857 : H12AffineEnvironment.transform 10 0 env856 = env857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env856 == env857) = true)

theorem identity857 : scanCanonicalize (H12AffineFastState.compose env857 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 22) := by decide +kernel

theorem selectedBound857 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env858 : List Nat := [2,4,8,16,17,64,24,84,22,84,0,65,84,12,93,78,92,16,85,93,16,16,16,19,68,65,1,12,16,17,84,0,85,0,13,22]

theorem envBound858 : H12AffineFastState.Bounded env858 := by
  intro p hp
  have h : env858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans857_858 : H12AffineEnvironment.transform 8 22 env857 = env858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 22 env857 == env858) = true)

def env859 : List Nat := [2,4,8,16,17,0,24,20,22,20,0,1,20,12,29,14,28,16,21,29,16,16,16,19,4,1,1,12,16,17,20,0,21,0,13,22]

theorem envBound859 : H12AffineFastState.Bounded env859 := by
  intro p hp
  have h : env859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans858_859 : H12AffineEnvironment.transform 5 0 env858 = env859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env858 == env859) = true)

def leafEnv859 : List Nat := [2,4,8,16,17,0,24,20,22,20,0,1,20,12,29,14,28,16,21,29,16,16,16,19,20,4,1,1,1,12,16,17,20,0,21,0,4,31,13,22,1,17,0]

def active859 : List Nat := [0,1,2,3]

def tree859 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood859 : H12WitnessSearch.Good tree859 := H12GlobalWitnessIndex.good

theorem leafIdentity859 : H12AffineFastState.composeSystem env859 rootObs = leafEnv859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env859 rootObs == leafEnv859) = true)

theorem terminalChecked859 : H12PackedTerminal.terminalCheckFast leafEnv859 active859 tree859 = true := by decide +kernel

def env860 : List Nat := [2,4,8,16,17,1,24,21,22,21,0,0,21,12,28,15,29,16,20,28,16,16,16,19,5,0,1,12,16,17,21,0,20,0,13,22]

theorem envBound860 : H12AffineFastState.Bounded env860 := by
  intro p hp
  have h : env860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans858_860 : H12AffineEnvironment.transform 5 1 env858 = env860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env858 == env860) = true)

theorem identity860 : scanCanonicalize (H12AffineFastState.compose env860 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound860 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env861 : List Nat := [2,4,4,16,17,1,20,21,22,21,0,0,21,0,16,3,17,16,20,16,16,16,16,19,5,0,1,0,16,17,21,0,20,0,1,22]

theorem envBound861 : H12AffineFastState.Bounded env861 := by
  intro p hp
  have h : env861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans860_861 : H12AffineEnvironment.transform 2 4 env860 = env861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env860 == env861) = true)

def leafEnv861 : List Nat := [2,4,4,16,17,1,20,21,22,21,0,0,21,0,16,3,17,16,20,16,16,16,16,19,21,5,1,0,1,0,16,17,21,0,20,0,4,18,1,22,1,17,0]

def active861 : List Nat := [0,1,3]

def tree861 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood861 : H12WitnessSearch.Good tree861 := H12GlobalWitnessIndex.good

theorem leafIdentity861 : H12AffineFastState.composeSystem env861 rootObs = leafEnv861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env861 rootObs == leafEnv861) = true)

theorem terminalChecked861 : H12PackedTerminal.terminalCheckFast leafEnv861 active861 tree861 = true := by decide +kernel

def env862 : List Nat := [2,4,8,16,17,64,24,84,512,84,1,65,579,539,586,601,587,17,85,586,16,16,16,19,595,65,0,539,16,16,84,0,85,0,538,512]

theorem envBound862 : H12AffineFastState.Bounded env862 := by
  intro p hp
  have h : env862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans856_862 : H12AffineEnvironment.transform 10 1 env856 = env862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env856 == env862) = true)

theorem identity862 : scanCanonicalize (H12AffineFastState.compose env862 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 6) := by decide +kernel

theorem selectedBound862 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env863 : List Nat := [2,4,8,16,17,64,24,84,6,84,1,65,69,29,76,95,77,17,85,76,16,16,16,19,85,65,0,29,16,16,84,0,85,0,28,6]

theorem envBound863 : H12AffineFastState.Bounded env863 := by
  intro p hp
  have h : env863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans862_863 : H12AffineEnvironment.transform 8 6 env862 = env863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 6 env862 == env863) = true)

def env864 : List Nat := [2,4,8,16,17,0,24,20,6,20,1,1,5,29,12,31,13,17,21,12,16,16,16,19,21,1,0,29,16,16,20,0,21,0,28,6]

theorem envBound864 : H12AffineFastState.Bounded env864 := by
  intro p hp
  have h : env864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans863_864 : H12AffineEnvironment.transform 5 0 env863 = env864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env863 == env864) = true)

theorem identity864 : scanCanonicalize (H12AffineFastState.compose env864 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 13) := by decide +kernel

theorem selectedBound864 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env865 : List Nat := [2,4,8,13,12,0,5,9,6,9,1,1,5,0,12,2,13,12,8,12,13,13,13,14,8,1,0,0,13,13,9,0,8,0,1,6]

theorem envBound865 : H12AffineFastState.Bounded env865 := by
  intro p hp
  have h : env865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans864_865 : H12AffineEnvironment.transform 3 13 env864 = env865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 13 env864 == env865) = true)

def leafEnv865 : List Nat := [2,4,8,13,12,0,5,9,6,9,1,1,5,0,12,2,13,12,8,12,13,13,13,14,9,8,1,1,0,0,13,13,9,0,8,0,4,14,1,6,1,12,0]

def active865 : List Nat := [0,1,2]

def tree865 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood865 : H12WitnessSearch.Good tree865 := H12GlobalWitnessIndex.good

theorem leafIdentity865 : H12AffineFastState.composeSystem env865 rootObs = leafEnv865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env865 rootObs == leafEnv865) = true)

theorem terminalChecked865 : H12PackedTerminal.terminalCheckFast leafEnv865 active865 tree865 = true := by decide +kernel

def env866 : List Nat := [2,4,8,16,17,1,24,21,6,21,1,0,4,29,13,30,12,17,20,13,16,16,16,19,20,0,0,29,16,16,21,0,20,0,28,6]

theorem envBound866 : H12AffineFastState.Bounded env866 := by
  intro p hp
  have h : env866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans863_866 : H12AffineEnvironment.transform 5 1 env863 = env866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env863 == env866) = true)

def leafEnv866 : List Nat := [2,4,8,16,17,1,24,21,6,21,1,0,4,29,13,30,12,17,20,13,16,16,16,19,21,20,1,0,0,29,16,16,21,0,20,0,4,15,28,6,1,17,0]

def active866 : List Nat := [0,1,2,3]

def tree866 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood866 : H12WitnessSearch.Good tree866 := H12GlobalWitnessIndex.good

theorem leafIdentity866 : H12AffineFastState.composeSystem env866 rootObs = leafEnv866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env866 rootObs == leafEnv866) = true)

theorem terminalChecked866 : H12PackedTerminal.terminalCheckFast leafEnv866 active866 tree866 = true := by decide +kernel

def env867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,8388608,16777216,8328,8914000,9176216,16384,151553,2080,17375732,13108376,525568,0,34359738368,25691698]

theorem envBound867 : H12AffineFastState.Bounded env867 := by
  intro p hp
  have h : env867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans783_867 : H12AffineEnvironment.transform 14 8693 env783 = env867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8693 env783 == env867) = true)

def env868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,524288,8693,2097152,4194304,147520,16777216,8328,672784,935128,16384,151553,2080,17375732,4867288,525568,0,34359738368,17450610]

theorem envBound868 : H12AffineFastState.Bounded env868 := by
  intro p hp
  have h : env868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans867_868 : H12AffineEnvironment.transform 22 147520 env867 = env868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147520 env867 == env868) = true)

def env869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2080,16852468,4341976,256,0,34359738368,16925298]

theorem envBound869 : H12AffineFastState.Bounded env869 := by
  intro p hp
  have h : env869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans868_869 : H12AffineEnvironment.transform 18 1024 env868 = env869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env868 == env869) = true)

def env870 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2080,16852468,4341976,256,0,131072,16925298]

theorem envBound870 : H12AffineFastState.Bounded env870 := by
  intro p hp
  have h : env870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans869_870 : H12AffineEnvironment.transform 34 131072 env869 = env870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env869 == env870) = true)

theorem identity870 : scanCanonicalize (H12AffineFastState.compose env870 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 204976) := by decide +kernel

theorem selectedBound870 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env871 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,204976,8328,147472,409816,16384,151553,2080,132420,4341976,256,0,131072,90818]

theorem envBound871 : H12AffineFastState.Bounded env871 := by
  intro p hp
  have h : env871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans870_871 : H12AffineEnvironment.transform 23 204976 env870 = env871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 204976 env870 == env871) = true)

theorem identity871 : scanCanonicalize (H12AffineFastState.compose env871 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 293) := by decide +kernel

theorem selectedBound871 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env872 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,293,147520,204976,8328,147472,409816,16384,151553,2080,132420,147965,256,0,131072,90818]

theorem envBound872 : H12AffineFastState.Bounded env872 := by
  intro p hp
  have h : env872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans871_872 : H12AffineEnvironment.transform 21 293 env871 = env872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 293 env871 == env872) = true)

def env873 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16892,262144,1024,8693,2097152,293,444,90444,8328,492,262436,16384,4605,2080,17592,1,256,0,16892,90818]

theorem envBound873 : H12AffineFastState.Bounded env873 := by
  intro p hp
  have h : env873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans872_873 : H12AffineEnvironment.transform 16 16892 env872 = env873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16892 env872 == env873) = true)

theorem identity873 : scanCanonicalize (H12AffineFastState.compose env873 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8575) := by decide +kernel

theorem selectedBound873 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env874 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8575,16892,262144,1024,8693,2097152,293,444,16435,8328,492,262436,16384,4605,2080,17592,1,256,0,16892,17341]

theorem envBound874 : H12AffineFastState.Bounded env874 := by
  intro p hp
  have h : env874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans873_874 : H12AffineEnvironment.transform 15 8575 env873 = env874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8575 env873 == env874) = true)

def env875 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,16893,262144,1024,8693,2097152,293,445,90445,8328,493,262437,16384,4604,2080,17593,0,256,0,16893,90818]

theorem envBound875 : H12AffineFastState.Bounded env875 := by
  intro p hp
  have h : env875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans872_875 : H12AffineEnvironment.transform 16 16893 env872 = env875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16893 env872 == env875) = true)

theorem identity875 : scanCanonicalize (H12AffineFastState.compose env875 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 445) := by decide +kernel

theorem selectedBound875 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env876 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8693,65536,64,262144,1024,8693,2097152,293,445,73968,8328,493,262437,445,4604,2080,1284,0,256,0,64,74623]

theorem envBound876 : H12AffineFastState.Bounded env876 := by
  intro p hp
  have h : env876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans875_876 : H12AffineEnvironment.transform 13 445 env875 = env876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 445 env875 == env876) = true)

theorem identity876 : scanCanonicalize (H12AffineFastState.compose env876 (packedSelected [15,18,23,38] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound876 : packedSelected [15,18,23,38] rootPS < 2^1333 := by decide +kernel

def env877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8693,65536,64,2264,1024,8693,2097152,293,445,73968,8328,493,2557,445,4604,2080,1284,0,256,0,64,74623]

theorem envBound877 : H12AffineFastState.Bounded env877 := by
  intro p hp
  have h : env877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans876_877 : H12AffineEnvironment.transform 17 2264 env876 = env877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env876 == env877) = true)

theorem identity877 : scanCanonicalize (H12AffineFastState.compose env877 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound877 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8693,8314,64,2264,1024,8693,2097152,293,445,138,8328,493,2557,445,4604,2080,1284,0,256,0,64,773]

theorem envBound878 : H12AffineFastState.Bounded env878 := by
  intro p hp
  have h : env878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans877_878 : H12AffineEnvironment.transform 15 8314 env877 = env878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env877 == env878) = true)

theorem identity878 : scanCanonicalize (H12AffineFastState.compose env878 (packedSelected [0,4,5,7,8,9,13,17] rootPS)) = affineNative (2^(20+1) ^^^ 11439) := by decide +kernel

theorem selectedBound878 : packedSelected [0,4,5,7,8,9,13,17] rootPS < 2^1333 := by decide +kernel

def env879 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,445,8693,8314,64,2264,1024,8693,11439,293,445,138,8328,493,2557,445,4604,2080,1284,0,256,0,64,773]

theorem envBound879 : H12AffineFastState.Bounded env879 := by
  intro p hp
  have h : env879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans878_879 : H12AffineEnvironment.transform 20 11439 env878 = env879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 11439 env878 == env879) = true)

theorem identity879 : scanCanonicalize (H12AffineFastState.compose env879 (packedSelected [0,4,7,9,10,13,18] rootPS)) = affineNative (2^(12+1) ^^^ 3117) := by decide +kernel

theorem selectedBound879 : packedSelected [0,4,7,9,10,13,18] rootPS < 2^1333 := by decide +kernel

def env880 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,3117,445,3544,3159,64,2264,1024,3544,130,293,445,138,3237,493,2557,445,4604,2080,1284,0,256,0,64,773]

theorem envBound880 : H12AffineFastState.Bounded env880 := by
  intro p hp
  have h : env880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans879_880 : H12AffineEnvironment.transform 12 3117 env879 = env880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3117 env879 == env880) = true)

theorem identity880 : scanCanonicalize (H12AffineFastState.compose env880 (packedSelected [0,1,2,5,6,7,11,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound880 : packedSelected [0,1,2,5,6,7,11,12,15] rootPS < 2^1333 := by decide +kernel

def env881 : List Nat := [2,4,8,16,32,64,128,4,512,1024,2048,4096,3117,185,3292,3159,64,2264,1024,3292,130,33,185,138,3237,233,2297,185,4344,2080,1024,0,4,0,64,513]

theorem envBound881 : H12AffineFastState.Bounded env881 := by
  intro p hp
  have h : env881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans880_881 : H12AffineEnvironment.transform 7 4 env880 = env881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env880 == env881) = true)

theorem identity881 : scanCanonicalize (H12AffineFastState.compose env881 (packedSelected [0,2,4,6] rootPS)) = affineNative (2^(10+1) ^^^ 1708) := by decide +kernel

theorem selectedBound881 : packedSelected [0,2,4,6] rootPS < 2^1333 := by decide +kernel

def env882 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1708,4096,641,185,624,763,64,1652,1024,624,130,33,185,138,521,233,1621,185,4344,1676,1024,0,4,0,64,513]

theorem envBound882 : H12AffineFastState.Bounded env882 := by
  intro p hp
  have h : env882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans881_882 : H12AffineEnvironment.transform 10 1708 env881 = env882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1708 env881 == env882) = true)

theorem identity882 : scanCanonicalize (H12AffineFastState.compose env882 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 1677) := by decide +kernel

theorem selectedBound882 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env883 : List Nat := [2,4,8,16,32,64,128,4,512,1024,1708,1677,641,185,624,763,64,1652,1024,624,130,33,185,138,521,233,1621,185,1653,1676,1024,0,4,0,64,513]

theorem envBound883 : H12AffineFastState.Bounded env883 := by
  intro p hp
  have h : env883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans882_883 : H12AffineEnvironment.transform 11 1677 env882 = env883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1677 env882 == env883) = true)

theorem identity883 : scanCanonicalize (H12AffineFastState.compose env883 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(6+1) ^^^ 24) := by decide +kernel

theorem selectedBound883 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env884 : List Nat := [2,4,8,16,32,64,24,4,512,1024,1588,1557,537,33,624,611,64,1652,1024,624,26,33,33,18,521,113,1621,33,1653,1556,1024,0,4,0,64,513]

theorem envBound884 : H12AffineFastState.Bounded env884 := by
  intro p hp
  have h : env884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans883_884 : H12AffineEnvironment.transform 6 24 env883 = env884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 24 env883 == env884) = true)

theorem identity884 : scanCanonicalize (H12AffineFastState.compose env884 (packedSelected [0,3,5,9] rootPS)) = affineNative (2^(9+1) ^^^ 623) := by decide +kernel

theorem selectedBound884 : packedSelected [0,3,5,9] rootPS < 2^1333 := by decide +kernel

def env885 : List Nat := [2,4,8,16,32,64,24,4,512,623,91,122,537,33,624,611,64,27,623,624,26,33,33,18,521,113,58,33,26,123,623,0,4,0,64,513]

theorem envBound885 : H12AffineFastState.Bounded env885 := by
  intro p hp
  have h : env885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans884_885 : H12AffineEnvironment.transform 9 623 env884 = env885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 623 env884 == env885) = true)

theorem identity885 : scanCanonicalize (H12AffineFastState.compose env885 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 59) := by decide +kernel

theorem selectedBound885 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env886 : List Nat := [2,4,8,16,32,59,24,4,512,532,32,1,537,33,523,536,59,27,532,523,26,33,33,18,521,10,58,33,26,0,532,0,4,0,59,513]

theorem envBound886 : H12AffineFastState.Bounded env886 := by
  intro p hp
  have h : env886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans885_886 : H12AffineEnvironment.transform 5 59 env885 = env886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 59 env885 == env886) = true)

theorem identity886 : scanCanonicalize (H12AffineFastState.compose env886 (packedSelected [2] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound886 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env887 : List Nat := [2,4,8,16,32,59,24,4,32,52,32,1,57,33,43,56,59,27,52,43,26,33,33,18,41,10,58,33,26,0,52,0,4,0,59,33]

theorem envBound887 : H12AffineFastState.Bounded env887 := by
  intro p hp
  have h : env887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans886_887 : H12AffineEnvironment.transform 8 32 env886 = env887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env886 == env887) = true)

theorem identity887 : scanCanonicalize (H12AffineFastState.compose env887 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 30) := by decide +kernel

theorem selectedBound887 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env888 : List Nat := [2,4,8,16,30,5,24,4,30,10,30,1,7,31,21,6,5,27,10,21,26,31,31,18,23,10,4,31,26,0,10,0,4,0,5,31]

theorem envBound888 : H12AffineFastState.Bounded env888 := by
  intro p hp
  have h : env888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans887_888 : H12AffineEnvironment.transform 4 30 env887 = env888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 30 env887 == env888) = true)

def env889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,16777216,8328,147472,409816,16384,151553,2080,16852468,4341976,256,0,131073,16925298]

theorem envBound889 : H12AffineFastState.Bounded env889 := by
  intro p hp
  have h : env889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans869_889 : H12AffineEnvironment.transform 34 131073 env869 = env889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env869 == env889) = true)

theorem identity889 : scanCanonicalize (H12AffineFastState.compose env889 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2306224) := by decide +kernel

theorem selectedBound889 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1024,8693,2097152,4194304,147520,2306224,8328,147472,409816,16384,151553,2080,2233668,4341976,256,0,131073,2192066]

theorem envBound890 : H12AffineFastState.Bounded env890 := by
  intro p hp
  have h : env890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans889_890 : H12AffineEnvironment.transform 23 2306224 env889 = env890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2306224 env889 == env890) = true)

theorem identity890 : scanCanonicalize (H12AffineFastState.compose env890 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(15+1) ^^^ 8314) := by decide +kernel

theorem selectedBound890 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,4194304,147520,2232522,8328,147472,409816,16384,151553,2080,2233668,4341976,256,0,131073,2118328]

theorem envBound891 : H12AffineFastState.Bounded env891 := by
  intro p hp
  have h : env891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans890_891 : H12AffineEnvironment.transform 15 8314 env890 = env891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8314 env890 == env891) = true)

def env892 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,2232416,147520,2232522,8328,147472,409816,16384,151553,2080,2233668,2117816,256,0,131073,2118328]

theorem envBound892 : H12AffineFastState.Bounded env892 := by
  intro p hp
  have h : env892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans891_892 : H12AffineEnvironment.transform 21 2232416 env891 = env892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2232416 env891 == env892) = true)

theorem identity892 : scanCanonicalize (H12AffineFastState.compose env892 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound892 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env893 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1024,8432,2097152,2232416,147520,2232522,8328,147472,409816,16384,151553,2080,2233409,2117816,5,0,131073,2118328]

theorem envBound893 : H12AffineFastState.Bounded env893 := by
  intro p hp
  have h : env893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans892_893 : H12AffineEnvironment.transform 7 5 env892 = env893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env892 == env893) = true)

theorem identity893 : scanCanonicalize (H12AffineFastState.compose env893 (packedSelected [4,9,17,18,19,20,21,23,26] rootPS)) = affineNative (2^(20+1) ^^^ 20664) := by decide +kernel

theorem selectedBound893 : packedSelected [4,9,17,18,19,20,21,23,26] rootPS < 2^1333 := by decide +kernel

def env894 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,131072,262144,1024,8432,20664,147672,147520,147570,8328,147472,409816,16384,151553,2080,148729,0,5,0,131073,512]

theorem envBound894 : H12AffineFastState.Bounded env894 := by
  intro p hp
  have h : env894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans893_894 : H12AffineEnvironment.transform 20 20664 env893 = env894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 20664 env893 == env894) = true)

theorem identity894 : scanCanonicalize (H12AffineFastState.compose env894 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 16632) := by decide +kernel

theorem selectedBound894 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env895 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,16632,262144,1024,8432,20664,32,184,138,8328,232,262176,16384,4345,2080,1025,0,5,0,16633,512]

theorem envBound895 : H12AffineFastState.Bounded env895 := by
  intro p hp
  have h : env895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans894_895 : H12AffineEnvironment.transform 16 16632 env894 = env895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16632 env894 == env895) = true)

theorem identity895 : scanCanonicalize (H12AffineFastState.compose env895 (packedSelected [0,4,5,7,8,9] rootPS)) = affineNative (2^(12+1) ^^^ 7310) := by decide +kernel

theorem selectedBound895 : packedSelected [0,4,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env896 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,7310,16384,7294,7412,16632,262144,1024,7294,20664,32,184,138,7174,232,262176,16384,4345,2080,1025,0,5,0,16633,512]

theorem envBound896 : H12AffineFastState.Bounded env896 := by
  intro p hp
  have h : env896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans895_896 : H12AffineEnvironment.transform 12 7310 env895 = env896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 7310 env895 == env896) = true)

theorem identity896 : scanCanonicalize (H12AffineFastState.compose env896 (packedSelected [3,8,10] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound896 : packedSelected [3,8,10] rootPS < 2^1333 := by decide +kernel

def env897 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,7310,16384,7294,7412,16632,2264,1024,7294,20664,32,184,138,7174,232,2296,16384,4345,2080,1025,0,5,0,16633,512]

theorem envBound897 : H12AffineFastState.Bounded env897 := by
  intro p hp
  have h : env897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans896_897 : H12AffineEnvironment.transform 17 2264 env896 = env897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env896 == env897) = true)

theorem identity897 : scanCanonicalize (H12AffineFastState.compose env897 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 152) := by decide +kernel

theorem selectedBound897 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env898 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,152,3094,16384,3302,3180,16632,2264,1024,3302,16416,32,184,138,3230,232,2296,16384,97,2080,1025,0,5,0,16633,512]

theorem envBound898 : H12AffineFastState.Bounded env898 := by
  intro p hp
  have h : env898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans897_898 : H12AffineEnvironment.transform 11 152 env897 = env898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 152 env897 == env898) = true)

theorem identity898 : scanCanonicalize (H12AffineFastState.compose env898 (packedSelected [1,3,6] rootPS)) = affineNative (2^(13+1) ^^^ 2259) := by decide +kernel

theorem selectedBound898 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env899 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,152,3094,2259,3302,3180,2091,2264,1024,3302,2291,32,184,138,3230,232,2296,2259,97,2080,1025,0,5,0,2090,512]

theorem envBound899 : H12AffineFastState.Bounded env899 := by
  intro p hp
  have h : env899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans898_899 : H12AffineEnvironment.transform 13 2259 env898 = env899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2259 env898 == env899) = true)

theorem identity899 : scanCanonicalize (H12AffineFastState.compose env899 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound899 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env900 : List Nat := [2,4,8,16,32,64,128,5,512,1024,96,152,1142,179,1158,1036,75,184,1024,1158,147,32,184,138,1278,232,152,179,97,64,1025,0,5,0,74,512]

theorem envBound900 : H12AffineFastState.Bounded env900 := by
  intro p hp
  have h : env900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans899_900 : H12AffineEnvironment.transform 10 96 env899 = env900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env899 == env900) = true)

theorem identity900 : scanCanonicalize (H12AffineFastState.compose env900 (packedSelected [0,1,2,3,4,11] rootPS)) = affineNative (2^(9+1) ^^^ 78) := by decide +kernel

theorem selectedBound900 : packedSelected [0,1,2,3,4,11] rootPS < 2^1333 := by decide +kernel

def env901 : List Nat := [2,4,8,16,32,64,128,5,512,78,96,152,56,179,200,66,75,184,78,200,147,32,184,138,176,232,152,179,97,64,79,0,5,0,74,512]

theorem envBound901 : H12AffineFastState.Bounded env901 := by
  intro p hp
  have h : env901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans900_901 : H12AffineEnvironment.transform 9 78 env900 = env901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 78 env900 == env901) = true)

theorem identity901 : scanCanonicalize (H12AffineFastState.compose env901 (packedSelected [1,2,5,12] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound901 : packedSelected [1,2,5,12] rootPS < 2^1333 := by decide +kernel

def env902 : List Nat := [2,4,8,11,32,64,128,5,512,78,96,131,35,168,200,66,75,163,78,200,136,32,163,138,171,232,131,168,97,64,79,0,5,0,74,512]

theorem envBound902 : H12AffineFastState.Bounded env902 := by
  intro p hp
  have h : env902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans901_902 : H12AffineEnvironment.transform 3 11 env901 = env902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env901 == env902) = true)

theorem identity902 : scanCanonicalize (H12AffineFastState.compose env902 (packedSelected [0,2,4] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound902 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env903 : List Nat := [2,4,8,11,11,64,128,5,512,78,75,131,8,131,200,66,75,136,78,200,136,11,136,138,128,195,131,131,74,64,79,0,5,0,74,512]

theorem envBound903 : H12AffineFastState.Bounded env903 := by
  intro p hp
  have h : env903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans902_903 : H12AffineEnvironment.transform 4 11 env902 = env903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env902 == env903) = true)

theorem identity903 : scanCanonicalize (H12AffineFastState.compose env903 (packedSelected [1,3] rootPS)) = affineNative (2^(6+1) ^^^ 3) := by decide +kernel

theorem selectedBound903 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env904 : List Nat := [2,4,8,11,11,64,3,5,512,78,75,0,8,0,75,66,75,11,78,75,11,11,11,9,3,64,0,0,74,64,79,0,5,0,74,512]

theorem envBound904 : H12AffineFastState.Bounded env904 := by
  intro p hp
  have h : env904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans903_904 : H12AffineEnvironment.transform 6 3 env903 = env904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 3 env903 == env904) = true)

theorem identity904 : scanCanonicalize (H12AffineFastState.compose env904 (packedSelected [0,2] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound904 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env905 : List Nat := [2,4,5,6,6,64,3,5,512,67,70,0,5,0,70,66,70,6,67,70,6,6,6,4,3,64,0,0,71,64,66,0,5,0,71,512]

theorem envBound905 : H12AffineFastState.Bounded env905 := by
  intro p hp
  have h : env905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans904_905 : H12AffineEnvironment.transform 2 5 env904 = env905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env904 == env905) = true)

theorem identity905 : scanCanonicalize (H12AffineFastState.compose env905 (packedSelected [0,1,5] rootPS)) = affineNative (2^(5+1) ^^^ 6) := by decide +kernel

theorem selectedBound905 : packedSelected [0,1,5] rootPS < 2^1333 := by decide +kernel

def env906 : List Nat := [2,4,5,6,6,6,3,5,512,5,0,0,5,0,0,4,0,6,5,0,6,6,6,4,3,6,0,0,1,6,4,0,5,0,1,512]

theorem envBound906 : H12AffineFastState.Bounded env906 := by
  intro p hp
  have h : env906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans905_906 : H12AffineEnvironment.transform 5 6 env905 = env906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 6 env905 == env906) = true)

def env907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,2097152,2232417,147520,2232522,8328,147472,409816,16384,151553,2080,2233668,2117817,256,0,131073,2118328]

theorem envBound907 : H12AffineFastState.Bounded env907 := by
  intro p hp
  have h : env907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans891_907 : H12AffineEnvironment.transform 21 2232417 env891 = env907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2232417 env891 == env907) = true)

theorem identity907 : scanCanonicalize (H12AffineFastState.compose env907 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(20+1) ^^^ 20925) := by decide +kernel

theorem selectedBound907 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,262144,1024,8693,20925,147932,147520,147831,8328,147472,409816,16384,151553,2080,148729,260,256,0,131073,773]

theorem envBound908 : H12AffineFastState.Bounded env908 := by
  intro p hp
  have h : env908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans907_908 : H12AffineEnvironment.transform 20 20925 env907 = env908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 20925 env907 == env908) = true)

theorem identity908 : scanCanonicalize (H12AffineFastState.compose env908 (packedSelected [4,9,17,18,19,20,21,23,26] rootPS)) = affineNative (2^(17+1) ^^^ 2264) := by decide +kernel

theorem selectedBound908 : packedSelected [4,9,17,18,19,20,21,23,26] rootPS < 2^1333 := by decide +kernel

def env909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,131072,2264,1024,8693,20925,147932,147520,147831,8328,147472,149504,16384,151553,2080,148729,260,256,0,131073,773]

theorem envBound909 : H12AffineFastState.Bounded env909 := by
  intro p hp
  have h : env909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans908_909 : H12AffineEnvironment.transform 17 2264 env908 = env909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2264 env908 == env909) = true)

theorem identity909 : scanCanonicalize (H12AffineFastState.compose env909 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 16385) := by decide +kernel

theorem selectedBound909 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8314,16385,2264,1024,8693,20925,477,65,374,8328,17,2049,16384,4096,2080,1272,260,256,0,16384,773]

theorem envBound910 : H12AffineFastState.Bounded env910 := by
  intro p hp
  have h : env910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans909_910 : H12AffineEnvironment.transform 16 16385 env909 = env910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16385 env909 == env910) = true)

theorem identity910 : scanCanonicalize (H12AffineFastState.compose env910 (packedSelected [17,21] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound910 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env911 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,8192,16384,8432,8314,16385,2264,1024,8432,20664,216,65,115,8328,17,2049,16384,4096,2080,1272,1,5,0,16384,512]

theorem envBound911 : H12AffineFastState.Bounded env911 := by
  intro p hp
  have h : env911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans910_911 : H12AffineEnvironment.transform 7 5 env910 = env911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env910 == env911) = true)

theorem identity911 : scanCanonicalize (H12AffineFastState.compose env911 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 5213) := by decide +kernel

theorem selectedBound911 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env912 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,5213,16384,5293,5159,16385,2264,1024,5293,20664,216,65,115,5333,17,2049,16384,4096,2080,1272,1,5,0,16384,512]

theorem envBound912 : H12AffineFastState.Bounded env912 := by
  intro p hp
  have h : env912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans911_912 : H12AffineEnvironment.transform 12 5213 env911 = env912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5213 env911 == env912) = true)

theorem identity912 : scanCanonicalize (H12AffineFastState.compose env912 (packedSelected [1,3,4,5,7,8,10] rootPS)) = affineNative (2^(13+1) ^^^ 194) := by decide +kernel

theorem selectedBound912 : packedSelected [1,3,4,5,7,8,10] rootPS < 2^1333 := by decide +kernel

def env913 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,4096,5213,194,5293,5159,195,2264,1024,5293,4218,216,65,115,5333,17,2049,194,4096,2080,1272,1,5,0,194,512]

theorem envBound913 : H12AffineFastState.Bounded env913 := by
  intro p hp
  have h : env913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans912_913 : H12AffineEnvironment.transform 13 194 env912 = env913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 194 env912 == env913) = true)

theorem identity913 : scanCanonicalize (H12AffineFastState.compose env913 (packedSelected [0,1,4,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1109) := by decide +kernel

theorem selectedBound913 : packedSelected [0,1,4,8,11] rootPS < 2^1333 := by decide +kernel

def env914 : List Nat := [2,4,8,16,32,64,128,5,512,1024,2048,1109,8,194,248,114,195,2264,1024,248,1071,216,65,115,128,17,2049,194,1109,2080,1272,1,5,0,194,512]

theorem envBound914 : H12AffineFastState.Bounded env914 := by
  intro p hp
  have h : env914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans913_914 : H12AffineEnvironment.transform 11 1109 env913 = env914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1109 env913 == env914) = true)

theorem identity914 : scanCanonicalize (H12AffineFastState.compose env914 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 121) := by decide +kernel

theorem selectedBound914 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env915 : List Nat := [2,4,8,16,32,64,121,5,512,1024,2048,1109,8,59,1,114,58,2081,1024,1,1071,33,65,115,121,17,2049,59,1109,2080,1025,1,5,0,59,512]

theorem envBound915 : H12AffineFastState.Bounded env915 := by
  intro p hp
  have h : env915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans914_915 : H12AffineEnvironment.transform 6 121 env914 = env915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 121 env914 == env915) = true)

theorem identity915 : scanCanonicalize (H12AffineFastState.compose env915 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound915 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env916 : List Nat := [2,4,8,16,32,17,40,5,512,1024,2048,1028,8,59,1,35,58,2081,1024,1,1071,33,16,34,40,17,2049,59,1028,2080,1025,1,5,0,59,512]

theorem envBound916 : H12AffineFastState.Bounded env916 := by
  intro p hp
  have h : env916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans915_916 : H12AffineEnvironment.transform 5 17 env915 = env916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env915 == env916) = true)

theorem identity916 : scanCanonicalize (H12AffineFastState.compose env916 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 545) := by decide +kernel

theorem selectedBound916 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env917 : List Nat := [2,4,8,16,32,17,40,5,512,1024,545,1028,8,59,1,35,58,512,1024,1,1071,33,16,34,40,17,544,59,1028,513,1025,1,5,0,59,512]

theorem envBound917 : H12AffineFastState.Bounded env917 := by
  intro p hp
  have h : env917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans916_917 : H12AffineEnvironment.transform 10 545 env916 = env917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 545 env916 == env917) = true)

theorem identity917 : scanCanonicalize (H12AffineFastState.compose env917 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound917 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env918 : List Nat := [2,4,8,16,32,17,40,5,512,549,545,545,8,59,1,35,58,512,549,1,522,33,16,34,40,17,544,59,545,513,548,1,5,0,59,512]

theorem envBound918 : H12AffineFastState.Bounded env918 := by
  intro p hp
  have h : env918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans917_918 : H12AffineEnvironment.transform 9 549 env917 = env918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env917 == env918) = true)

theorem identity918 : scanCanonicalize (H12AffineFastState.compose env918 (packedSelected [1,5] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound918 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env919 : List Nat := [2,4,2,16,32,17,34,5,512,549,545,545,2,49,1,35,48,512,549,1,512,33,16,34,34,17,544,49,545,513,548,1,5,0,49,512]

theorem envBound919 : H12AffineFastState.Bounded env919 := by
  intro p hp
  have h : env919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans918_919 : H12AffineEnvironment.transform 2 2 env918 = env919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env918 == env919) = true)

theorem identity919 : scanCanonicalize (H12AffineFastState.compose env919 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound919 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env920 : List Nat := [2,4,2,16,16,17,18,5,512,533,529,529,2,1,1,19,0,512,533,1,512,17,16,18,18,17,528,1,529,513,532,1,5,0,1,512]

theorem envBound920 : H12AffineFastState.Bounded env920 := by
  intro p hp
  have h : env920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans919_920 : H12AffineEnvironment.transform 4 16 env919 = env920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env919 == env920) = true)

theorem identity920 : scanCanonicalize (H12AffineFastState.compose env920 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound920 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env921 : List Nat := [2,4,2,6,6,7,4,5,512,515,519,519,2,1,1,5,0,512,515,1,512,7,6,4,4,7,518,1,519,513,514,1,5,0,1,512]

theorem envBound921 : H12AffineFastState.Bounded env921 := by
  intro p hp
  have h : env921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans920_921 : H12AffineEnvironment.transform 3 6 env920 = env921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env920 == env921) = true)

theorem identity921 : scanCanonicalize (H12AffineFastState.compose env921 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound921 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env922 : List Nat := [2,4,2,6,6,7,4,5,1,2,6,6,2,1,1,5,0,1,2,1,1,7,6,4,4,7,7,1,6,0,3,1,5,0,1,1]

theorem envBound922 : H12AffineFastState.Bounded env922 := by
  intro p hp
  have h : env922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans921_922 : H12AffineEnvironment.transform 8 1 env921 = env922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env921 == env922) = true)

def env923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2080,16852469,4341977,257,0,34359738368,16925299]

theorem envBound923 : H12AffineFastState.Bounded env923 := by
  intro p hp
  have h : env923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans868_923 : H12AffineEnvironment.transform 18 1025 env868 = env923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env868 == env923) = true)

def env924 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2080,16852469,4341977,257,0,131072,16925299]

theorem envBound924 : H12AffineFastState.Bounded env924 := by
  intro p hp
  have h : env924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans923_924 : H12AffineEnvironment.transform 34 131072 env923 = env924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131072 env923 == env924) = true)

theorem identity924 : scanCanonicalize (H12AffineFastState.compose env924 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 75248) := by decide +kernel

theorem selectedBound924 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env925 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,75248,8328,147473,409817,16384,151553,2080,5,4341977,257,0,131072,223107]

theorem envBound925 : H12AffineFastState.Bounded env925 := by
  intro p hp
  have h : env925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans924_925 : H12AffineEnvironment.transform 23 75248 env924 = env925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 75248 env924 == env925) = true)

theorem identity925 : scanCanonicalize (H12AffineFastState.compose env925 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 1061) := by decide +kernel

theorem selectedBound925 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env926 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,1061,147520,75248,8328,147473,409817,16384,151553,2080,5,148732,257,0,131072,223107]

theorem envBound926 : H12AffineFastState.Bounded env926 := by
  intro p hp
  have h : env926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans925_926 : H12AffineEnvironment.transform 21 1061 env925 = env926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 1061 env925 == env926) = true)

theorem identity926 : scanCanonicalize (H12AffineFastState.compose env926 (packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 91523) := by decide +kernel

theorem selectedBound926 : packedSelected [0,1,3,7,9,10,11,12,15,18,19,20,22,23,24,26,28,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env927 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,91523,262144,1025,8693,2097152,1061,75203,75248,8328,75154,337242,16384,79234,2080,5,74111,257,0,91523,512]

theorem envBound927 : H12AffineFastState.Bounded env927 := by
  intro p hp
  have h : env927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans926_927 : H12AffineEnvironment.transform 16 91523 env926 = env927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 91523 env926 == env927) = true)

theorem identity927 : scanCanonicalize (H12AffineFastState.compose env927 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound927 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env928 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8693,65536,90503,262144,5,8693,2097152,33,74183,74228,8328,74134,336222,16384,78214,2080,5,74111,257,0,90503,512]

theorem envBound928 : H12AffineFastState.Bounded env928 := by
  intro p hp
  have h : env928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans927_928 : H12AffineEnvironment.transform 9 4 env927 = env928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env927 == env928) = true)

theorem identity928 : scanCanonicalize (H12AffineFastState.compose env928 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8574) := by decide +kernel

theorem selectedBound928 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env929 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8693,8574,16633,262144,5,8693,2097152,33,185,138,8328,232,262176,16384,4344,2080,5,1,257,0,16633,512]

theorem envBound929 : H12AffineFastState.Bounded env929 := by
  intro p hp
  have h : env929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans928_929 : H12AffineEnvironment.transform 15 8574 env928 = env929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8574 env928 == env929) = true)

theorem identity929 : scanCanonicalize (H12AffineFastState.compose env929 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(17+1) ^^^ 2080) := by decide +kernel

theorem selectedBound929 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env930 : List Nat := [2,4,8,16,32,64,128,256,512,4,2048,4096,8192,16384,8693,8574,16633,2080,5,8693,2097152,33,185,138,8328,232,2048,16384,4344,2080,5,1,257,0,16633,512]

theorem envBound930 : H12AffineFastState.Bounded env930 := by
  intro p hp
  have h : env930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans929_930 : H12AffineEnvironment.transform 17 2080 env929 = env930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2080 env929 == env930) = true)

theorem identity930 : scanCanonicalize (H12AffineFastState.compose env930 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound930 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env931 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8201,8322,16633,2080,5,8201,2097152,33,185,138,8328,232,2048,16384,4344,2080,5,1,253,0,16633,512]

theorem envBound931 : H12AffineFastState.Bounded env931 := by
  intro p hp
  have h : env931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans930_931 : H12AffineEnvironment.transform 7 252 env930 = env931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env930 == env931) = true)

theorem identity931 : scanCanonicalize (H12AffineFastState.compose env931 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(20+1) ^^^ 26826) := by decide +kernel

theorem selectedBound931 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env932 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,16384,8201,8322,16633,2080,5,8201,26826,33,185,138,8328,232,2048,16384,4344,2080,5,1,253,0,16633,512]

theorem envBound932 : H12AffineFastState.Bounded env932 := by
  intro p hp
  have h : env932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans931_932 : H12AffineEnvironment.transform 20 26826 env931 = env932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 26826 env931 == env932) = true)

theorem identity932 : scanCanonicalize (H12AffineFastState.compose env932 (packedSelected [0,1,3,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 12496) := by decide +kernel

theorem selectedBound932 : packedSelected [0,1,3,4,7,9] rootPS < 2^1333 := by decide +kernel

def env933 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,8192,12496,8201,8322,12329,2080,5,8201,6170,33,185,138,8328,232,2048,12496,4344,2080,5,1,253,0,12329,512]

theorem envBound933 : H12AffineFastState.Bounded env933 := by
  intro p hp
  have h : env933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans932_933 : H12AffineEnvironment.transform 13 12496 env932 = env933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12496 env932 == env933) = true)

theorem identity933 : scanCanonicalize (H12AffineFastState.compose env933 (packedSelected [0,1,2,3,7,12] rootPS)) = affineNative (2^(12+1) ^^^ 2283) := by decide +kernel

theorem selectedBound933 : packedSelected [0,1,2,3,7,12] rootPS < 2^1333 := by decide +kernel

def env934 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,4096,2283,6203,2274,2153,6338,2080,5,2274,6170,33,185,138,2147,232,2048,6203,4344,2080,5,1,253,0,6338,512]

theorem envBound934 : H12AffineFastState.Bounded env934 := by
  intro p hp
  have h : env934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans933_934 : H12AffineEnvironment.transform 12 2283 env933 = env934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2283 env933 == env934) = true)

theorem identity934 : scanCanonicalize (H12AffineFastState.compose env934 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2129) := by decide +kernel

theorem selectedBound934 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env935 : List Nat := [2,4,8,16,32,64,128,252,512,4,2048,2129,2283,106,2274,2153,147,2080,5,2274,75,33,185,138,2147,232,2048,106,2217,2080,5,1,253,0,147,512]

theorem envBound935 : H12AffineFastState.Bounded env935 := by
  intro p hp
  have h : env935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans934_935 : H12AffineEnvironment.transform 11 2129 env934 = env935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2129 env934 == env935) = true)

theorem identity935 : scanCanonicalize (H12AffineFastState.compose env935 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 58) := by decide +kernel

theorem selectedBound935 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env936 : List Nat := [2,4,8,16,32,64,128,252,512,4,58,107,209,106,216,83,147,26,5,216,75,33,185,138,89,232,58,106,147,26,5,1,253,0,147,512]

theorem envBound936 : H12AffineFastState.Bounded env936 := by
  intro p hp
  have h : env936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans935_936 : H12AffineEnvironment.transform 10 58 env935 = env936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 58 env935 == env936) = true)

theorem identity936 : scanCanonicalize (H12AffineFastState.compose env936 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound936 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env937 : List Nat := [2,4,8,16,32,43,128,151,512,4,58,0,186,1,179,56,147,26,5,179,32,33,185,138,50,131,58,1,147,26,5,1,150,0,147,512]

theorem envBound937 : H12AffineFastState.Bounded env937 := by
  intro p hp
  have h : env937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans936_937 : H12AffineEnvironment.transform 5 43 env936 = env937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env936 == env937) = true)

def env938 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,16777216,8328,147473,409817,16384,151553,2080,16852469,4341977,257,0,131073,16925299]

theorem envBound938 : H12AffineFastState.Bounded env938 := by
  intro p hp
  have h : env938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans923_938 : H12AffineEnvironment.transform 34 131073 env923 = env938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 131073 env923 == env938) = true)

theorem identity938 : scanCanonicalize (H12AffineFastState.compose env938 (packedSelected [14] rootPS)) = affineNative (2^(23+1) ^^^ 2176496) := by decide +kernel

theorem selectedBound938 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env939 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,2097152,4194304,147520,2176496,8328,147473,409817,16384,151553,2080,2101253,4341977,257,0,131073,2324355]

theorem envBound939 : H12AffineFastState.Bounded env939 := by
  intro p hp
  have h : env939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans938_939 : H12AffineEnvironment.transform 23 2176496 env938 = env939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2176496 env938 == env939) = true)

theorem identity939 : scanCanonicalize (H12AffineFastState.compose env939 (packedSelected [0,9,22,27] rootPS)) = affineNative (2^(20+1) ^^^ 79227) := by decide +kernel

theorem selectedBound939 : packedSelected [0,9,22,27] rootPS < 2^1333 := by decide +kernel

def env940 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,79227,4194304,147520,139,8328,147473,409817,16384,151553,2080,75134,4341977,257,0,131073,148216]

theorem envBound940 : H12AffineFastState.Bounded env940 := by
  intro p hp
  have h : env940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans939_940 : H12AffineEnvironment.transform 20 79227 env939 = env940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 79227 env939 == env940) = true)

def env941 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,131072,262144,1025,8693,79227,32,147520,139,8328,147473,409817,16384,151553,2080,75134,147705,257,0,131073,148216]

theorem envBound941 : H12AffineFastState.Bounded env941 := by
  intro p hp
  have h : env941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans940_941 : H12AffineEnvironment.transform 21 32 env940 = env941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env940 == env941) = true)

theorem identity941 : scanCanonicalize (H12AffineFastState.compose env941 (packedSelected [0,7,9,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90502) := by decide +kernel

theorem selectedBound941 : packedSelected [0,7,9,20,22] rootPS < 2^1333 := by decide +kernel

def env942 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,65536,90502,262144,1025,8693,79227,32,74182,139,8328,74135,336223,16384,78215,2080,75134,74111,257,0,90503,74622]

theorem envBound942 : H12AffineFastState.Bounded env942 := by
  intro p hp
  have h : env942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans941_942 : H12AffineEnvironment.transform 16 90502 env941 = env942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90502 env941 == env942) = true)

theorem identity942 : scanCanonicalize (H12AffineFastState.compose env942 (packedSelected [1,3,5,8,10,13,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8663) := by decide +kernel

theorem selectedBound942 : packedSelected [1,3,5,8,10,13,17,19] rootPS < 2^1333 := by decide +kernel

def env943 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8693,8663,16465,262144,1025,8693,5292,32,17,139,8328,64,262280,16384,4176,2080,1193,168,257,0,16464,681]

theorem envBound943 : H12AffineFastState.Bounded env943 := by
  intro p hp
  have h : env943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans942_943 : H12AffineEnvironment.transform 15 8663 env942 = env943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8663 env942 == env943) = true)

theorem identity943 : scanCanonicalize (H12AffineFastState.compose env943 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound943 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,15,21,23] rootPS < 2^1333 := by decide +kernel

def env944 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,12573,8693,8663,12620,262144,1025,8693,5292,32,17,139,8328,64,262280,12573,4176,2080,1193,168,257,0,12621,681]

theorem envBound944 : H12AffineFastState.Bounded env944 := by
  intro p hp
  have h : env944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans943_944 : H12AffineEnvironment.transform 13 12573 env943 = env944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env943 == env944) = true)

theorem identity944 : scanCanonicalize (H12AffineFastState.compose env944 (packedSelected [3,10,13,21,24,26] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound944 : packedSelected [3,10,13,21,24,26] rootPS < 2^1333 := by decide +kernel

def env945 : List Nat := [2,4,8,16,32,64,41,256,512,1024,2048,4096,8192,12573,8540,8574,12620,262144,1025,8540,5125,32,17,34,8225,64,262177,12573,4176,2080,1024,1,257,0,12621,512]

theorem envBound945 : H12AffineFastState.Bounded env945 := by
  intro p hp
  have h : env945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans944_945 : H12AffineEnvironment.transform 6 41 env944 = env945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env944 == env945) = true)

theorem identity945 : scanCanonicalize (H12AffineFastState.compose env945 (packedSelected [0,3,4,5,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound945 : packedSelected [0,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env946 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,12573,8460,8494,12572,262144,1025,8460,5125,32,17,34,8225,16,262177,12573,4096,2080,1024,1,257,0,12573,512]

theorem envBound946 : H12AffineFastState.Bounded env946 := by
  intro p hp
  have h : env946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans945_946 : H12AffineEnvironment.transform 5 16 env945 = env946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env945 == env946) = true)

theorem identity946 : scanCanonicalize (H12AffineFastState.compose env946 (packedSelected [0,2,4,5,6,7,8,9] rootPS)) = affineNative (2^(17+1) ^^^ 8983) := by decide +kernel

theorem selectedBound946 : packedSelected [0,2,4,5,6,7,8,9] rootPS < 2^1333 := by decide +kernel

def env947 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,8192,12573,8460,8494,12572,8983,1025,8460,5125,32,17,34,8225,16,9014,12573,4096,2080,1024,1,257,0,12573,512]

theorem envBound947 : H12AffineFastState.Bounded env947 := by
  intro p hp
  have h : env947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans946_947 : H12AffineEnvironment.transform 17 8983 env946 = env947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 8983 env946 == env947) = true)

theorem identity947 : scanCanonicalize (H12AffineFastState.compose env947 (packedSelected [0,1,3,6,7,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 2870) := by decide +kernel

theorem selectedBound947 : packedSelected [0,1,3,6,7,11,12] rootPS < 2^1333 := by decide +kernel

def env948 : List Nat := [2,4,8,16,32,16,41,256,512,1024,2048,4096,2870,6699,2618,2584,6698,2081,1025,2618,5125,32,17,34,2839,16,2048,6699,4096,2080,1024,1,257,0,6699,512]

theorem envBound948 : H12AffineFastState.Bounded env948 := by
  intro p hp
  have h : env948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans947_948 : H12AffineEnvironment.transform 12 2870 env947 = env948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2870 env947 == env948) = true)

theorem identity948 : scanCanonicalize (H12AffineFastState.compose env948 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 1338) := by decide +kernel

theorem selectedBound948 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env949 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1338,4096,1548,5905,1792,1826,5904,1307,1025,1792,5125,32,17,34,1581,16,1338,5905,4096,1306,1024,1,257,0,5905,512]

theorem envBound949 : H12AffineFastState.Bounded env949 := by
  intro p hp
  have h : env949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans948_949 : H12AffineEnvironment.transform 10 1338 env948 = env949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1338 env948 == env949) = true)

theorem identity949 : scanCanonicalize (H12AffineFastState.compose env949 (packedSelected [1,5,6] rootPS)) = affineNative (2^(11+1) ^^^ 1306) := by decide +kernel

theorem selectedBound949 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env950 : List Nat := [2,4,8,16,32,16,41,256,512,1024,1338,1306,1548,523,1792,1826,522,1307,1025,1792,287,32,17,34,1581,16,1338,523,1306,1306,1024,1,257,0,523,512]

theorem envBound950 : H12AffineFastState.Bounded env950 := by
  intro p hp
  have h : env950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans949_950 : H12AffineEnvironment.transform 11 1306 env949 = env950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1306 env949 == env950) = true)

theorem identity950 : scanCanonicalize (H12AffineFastState.compose env950 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 816) := by decide +kernel

end H12CloudChart1