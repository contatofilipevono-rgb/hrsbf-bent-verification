import H12CloudChart1Data040

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans10227_10228 : H12AffineEnvironment.transform 11 2414 env10227 = env10228 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2414 env10227 == env10228) = true)

theorem identity10228 : scanCanonicalize (H12AffineFastState.compose env10228 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 267) := by decide +kernel

theorem selectedBound10228 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10229 : List Nat := [2,4,8,16,32,64,8,256,512,267,2048,2414,348,2404,1,342,2420,2420,266,0,2350,33,17,2,348,64,2048,2421,2414,2421,95,32,257,33,2356,513]

theorem envBound10229 : H12AffineFastState.Bounded env10229 := by
  intro p hp
  have h : env10229.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10228_10229 : H12AffineEnvironment.transform 9 267 env10228 = env10229 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 267 env10228 == env10229) = true)

theorem identity10229 : scanCanonicalize (H12AffineFastState.compose env10229 (packedSelected [2,4,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10229 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env10230 : List Nat := [2,4,8,16,1,64,8,256,512,267,2048,2383,348,2373,1,342,2389,2389,266,0,2319,0,17,2,348,64,2048,2388,2383,2388,95,1,257,0,2325,513]

theorem envBound10230 : H12AffineFastState.Bounded env10230 := by
  intro p hp
  have h : env10230.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10229_10230 : H12AffineEnvironment.transform 4 1 env10229 = env10230 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10229 == env10230) = true)

theorem identity10230 : scanCanonicalize (H12AffineFastState.compose env10230 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10230 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env10231 : List Nat := [2,4,8,16,1,16,8,256,512,267,2048,2335,268,2325,1,262,2309,2309,266,0,2319,0,17,2,268,16,2048,2308,2335,2308,15,1,257,0,2325,513]

theorem envBound10231 : H12AffineFastState.Bounded env10231 := by
  intro p hp
  have h : env10231.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10230_10231 : H12AffineEnvironment.transform 5 16 env10230 = env10231 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10230 == env10231) = true)

theorem identity10231 : scanCanonicalize (H12AffineFastState.compose env10231 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound10231 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10232 : List Nat := [2,4,8,16,1,16,8,14,512,5,2048,2065,2,2075,1,8,2059,2059,4,0,2049,0,17,2,2,16,2048,2058,2065,2058,15,1,15,0,2075,513]

theorem envBound10232 : H12AffineFastState.Bounded env10232 := by
  intro p hp
  have h : env10232.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10231_10232 : H12AffineEnvironment.transform 7 14 env10231 = env10232 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env10231 == env10232) = true)

theorem identity10232 : scanCanonicalize (H12AffineFastState.compose env10232 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound10232 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10233 : List Nat := [2,4,8,16,1,16,8,14,17,5,2048,2065,2,2075,1,8,2059,2059,4,0,2049,0,17,2,2,16,2048,2058,2065,2058,15,1,15,0,2075,16]

theorem envBound10233 : H12AffineFastState.Bounded env10233 := by
  intro p hp
  have h : env10233.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10232_10233 : H12AffineEnvironment.transform 8 17 env10232 = env10233 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env10232 == env10233) = true)

theorem identity10233 : scanCanonicalize (H12AffineFastState.compose env10233 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound10233 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10234 : List Nat := [2,4,8,16,1,16,8,14,17,5,26,11,2,1,1,8,17,17,4,0,27,0,17,2,2,16,26,16,11,16,15,1,15,0,1,16]

theorem envBound10234 : H12AffineFastState.Bounded env10234 := by
  intro p hp
  have h : env10234.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10233_10234 : H12AffineEnvironment.transform 10 26 env10233 = env10234 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env10233 == env10234) = true)

theorem identity10234 : scanCanonicalize (H12AffineFastState.compose env10234 (packedSelected [0,1] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound10234 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10235 : List Nat := [2,2,8,16,1,16,8,8,17,3,26,11,2,1,1,8,17,17,2,0,27,0,17,2,2,16,26,16,11,16,9,1,9,0,1,16]

theorem envBound10235 : H12AffineFastState.Bounded env10235 := by
  intro p hp
  have h : env10235.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10234_10235 : H12AffineEnvironment.transform 1 2 env10234 = env10235 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env10234 == env10235) = true)

theorem identity10235 : scanCanonicalize (H12AffineFastState.compose env10235 (packedSelected [0,8] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound10235 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env10236 : List Nat := [2,2,8,11,1,11,8,8,10,3,1,11,2,1,1,8,10,10,2,0,0,0,10,2,2,11,1,11,11,11,9,1,9,0,1,11]

theorem envBound10236 : H12AffineFastState.Bounded env10236 := by
  intro p hp
  have h : env10236.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10235_10236 : H12AffineEnvironment.transform 3 11 env10235 = env10236 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env10235 == env10236) = true)

theorem identity10236 : scanCanonicalize (H12AffineFastState.compose env10236 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10236 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10237 : List Nat := [0,0,8,9,1,9,8,8,8,1,1,9,0,1,1,8,8,8,0,0,0,0,8,0,0,9,1,9,9,9,9,1,9,0,1,9]

theorem envBound10237 : H12AffineFastState.Bounded env10237 := by
  intro p hp
  have h : env10237.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10236_10237 : H12AffineEnvironment.transform 0 0 env10236 = env10237 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env10236 == env10237) = true)

def env10238 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,38160,10281,1025,32769,77898,32,73755,98645,8192,64,121942,79130,17665,89379,75102,119927,257,21792,46092,513]

theorem envBound10238 : H12AffineFastState.Bounded env10238 := by
  intro p hp
  have h : env10238.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10222_10238 : H12AffineEnvironment.transform 17 10281 env10222 = env10238 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10222 == env10238) = true)

theorem identity10238 : scanCanonicalize (H12AffineFastState.compose env10238 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10238 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10239 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,38160,10281,1025,32769,4161,32,16,41310,8192,64,64605,5393,17665,32040,1365,62588,257,21792,46092,513]

theorem envBound10239 : H12AffineFastState.Bounded env10239 := by
  intro p hp
  have h : env10239.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10238_10239 : H12AffineEnvironment.transform 15 8203 env10238 = env10239 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10238 == env10239) = true)

theorem identity10239 : scanCanonicalize (H12AffineFastState.compose env10239 (packedSelected [0,7,11,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 3148) := by decide +kernel

theorem selectedBound10239 : packedSelected [0,7,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10240 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,32768,3143,38160,1125,1025,32769,4161,32,16,36114,3148,64,53265,5393,17665,20836,1365,55344,257,21792,38976,513]

theorem envBound10240 : H12AffineFastState.Bounded env10240 := by
  intro p hp
  have h : env10240.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10239_10240 : H12AffineEnvironment.transform 12 3148 env10239 = env10240 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3148 env10239 == env10240) = true)

theorem identity10240 : scanCanonicalize (H12AffineFastState.compose env10240 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound10240 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10241 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,3148,16384,21760,3143,16400,1125,1025,21761,4161,32,16,22546,3148,64,1297,5393,17665,20836,1365,3376,257,21792,19776,513]

theorem envBound10241 : H12AffineFastState.Bounded env10241 := by
  intro p hp
  have h : env10241.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10240_10241 : H12AffineEnvironment.transform 14 21760 env10240 = env10241 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env10240 == env10241) = true)

theorem identity10241 : scanCanonicalize (H12AffineFastState.compose env10241 (packedSelected [2,6] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10241 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10242 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1296,4096,348,16384,21760,343,16400,1125,1025,21761,4161,32,16,21762,348,64,1297,5393,17665,20836,1365,32,257,21792,16464,513]

theorem envBound10242 : H12AffineFastState.Bounded env10242 := by
  intro p hp
  have h : env10242.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10241_10242 : H12AffineEnvironment.transform 10 1296 env10241 = env10242 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env10241 == env10242) = true)

theorem identity10242 : scanCanonicalize (H12AffineFastState.compose env10242 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound10242 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10243 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,4096,348,16384,20544,343,16400,293,321,20545,4161,32,16,20546,348,64,81,4177,16449,20836,21,32,257,20576,16464,513]

theorem envBound10243 : H12AffineFastState.Bounded env10243 := by
  intro p hp
  have h : env10243.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10242_10243 : H12AffineEnvironment.transform 9 320 env10242 = env10243 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env10242 == env10243) = true)

theorem identity10243 : scanCanonicalize (H12AffineFastState.compose env10243 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound10243 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env10244 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,64,348,16384,16384,343,16400,293,321,16385,1,32,16,16386,348,64,81,17,16449,16676,21,32,257,16416,16464,513]

theorem envBound10244 : H12AffineFastState.Bounded env10244 := by
  intro p hp
  have h : env10244.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10243_10244 : H12AffineEnvironment.transform 11 64 env10243 = env10244 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env10243 == env10244) = true)

theorem identity10244 : scanCanonicalize (H12AffineFastState.compose env10244 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10244 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env10245 : List Nat := [2,4,8,16,32,64,8,36,512,100,80,64,120,16384,16384,115,16400,1,101,16385,1,32,16,16386,120,64,81,17,16449,16384,21,32,37,16416,16464,513]

theorem envBound10245 : H12AffineFastState.Bounded env10245 := by
  intro p hp
  have h : env10245.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10244_10245 : H12AffineEnvironment.transform 7 36 env10244 = env10245 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10244 == env10245) = true)

theorem identity10245 : scanCanonicalize (H12AffineFastState.compose env10245 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10245 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10246 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,17,41,16384,16384,34,16400,1,52,16385,1,32,16,16386,41,17,0,17,16400,16384,21,32,37,16416,16385,513]

theorem envBound10246 : H12AffineFastState.Bounded env10246 := by
  intro p hp
  have h : env10246.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10245_10246 : H12AffineEnvironment.transform 5 17 env10245 = env10246 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10245 == env10246) = true)

def env10247 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,2097152,272392,2101329,98644,8193,64,2157597,2098512,17665,2377025,2102549,2411541,257,21792,46093,2175563]

theorem envBound10247 : H12AffineFastState.Bounded env10247 := by
  intro p hp
  have h : env10247.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10220_10247 : H12AffineEnvironment.transform 6 9 env10220 = env10247 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10220 == env10247) = true)

theorem identity10247 : scanCanonicalize (H12AffineFastState.compose env10247 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound10247 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env10248 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1025,21760,2097152,272392,2101329,87125,8193,64,2111772,2098512,17665,2377025,2102549,2365716,257,21792,24844,2175563]

theorem envBound10248 : H12AffineFastState.Bounded env10248 := by
  intro p hp
  have h : env10248.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10247_10248 : H12AffineEnvironment.transform 14 21761 env10247 = env10248 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env10247 == env10248) = true)

def env10249 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1025,21760,4160,272392,17,87125,8193,64,10588,5392,17665,283905,1365,264532,257,21792,24844,74251]

theorem envBound10249 : H12AffineFastState.Bounded env10249 := by
  intro p hp
  have h : env10249.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10248_10249 : H12AffineEnvironment.transform 20 4160 env10248 = env10249 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env10248 == env10249) = true)

theorem identity10249 : scanCanonicalize (H12AffineFastState.compose env10249 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 97406) := by decide +kernel

theorem selectedBound10249 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10250 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,97406,1025,21760,4160,87158,17,87125,8193,64,10588,5392,17665,76159,1365,95530,257,21792,24844,74251]

theorem envBound10250 : H12AffineFastState.Bounded env10250 := by
  intro p hp
  have h : env10250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10249_10250 : H12AffineEnvironment.transform 17 97406 env10249 = env10250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 97406 env10249 == env10250) = true)

theorem identity10250 : scanCanonicalize (H12AffineFastState.compose env10250 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10250 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10251 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,16400,23669,1025,21760,4160,29821,17,29790,8193,64,10588,5392,17665,2420,1365,21793,257,21792,24844,512]

theorem envBound10251 : H12AffineFastState.Bounded env10251 := by
  intro p hp
  have h : env10251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10250_10251 : H12AffineEnvironment.transform 15 8203 env10250 = env10251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10250 == env10251) = true)

theorem identity10251 : scanCanonicalize (H12AffineFastState.compose env10251 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound10251 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10252 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,16384,21761,114,16400,23669,1025,21760,4160,21508,17,21543,120,64,2341,5392,17665,2420,1365,21793,257,21792,16757,512]

theorem envBound10252 : H12AffineFastState.Bounded env10252 := by
  intro p hp
  have h : env10252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10251_10252 : H12AffineEnvironment.transform 12 121 env10251 = env10252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env10251 == env10252) = true)

theorem identity10252 : scanCanonicalize (H12AffineFastState.compose env10252 (packedSelected [0,2,4,5,6,7,8,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 863) := by decide +kernel

theorem selectedBound10252 : packedSelected [0,2,4,5,6,7,8,9,11] rootPS < 2^1333 := by decide +kernel

def env10253 : List Nat := [2,4,8,16,32,64,9,256,512,1024,863,4096,121,16384,21761,114,16400,22314,1025,21760,4160,21508,17,21543,120,64,634,5392,17665,555,1365,21793,257,21792,16757,512]

theorem envBound10253 : H12AffineFastState.Bounded env10253 := by
  intro p hp
  have h : env10253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10252_10253 : H12AffineEnvironment.transform 10 863 env10252 = env10253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 863 env10252 == env10253) = true)

theorem identity10253 : scanCanonicalize (H12AffineFastState.compose env10253 (packedSelected [0,2,6,7,16] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound10253 : packedSelected [0,2,6,7,16] rootPS < 2^1333 := by decide +kernel

def env10254 : List Nat := [2,4,8,16,32,64,9,256,512,1024,863,4096,121,5236,373,114,5220,862,1025,372,4160,112,17,83,120,64,634,5392,4469,555,1365,341,257,340,5377,512]

theorem envBound10254 : H12AffineFastState.Bounded env10254 := by
  intro p hp
  have h : env10254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10253_10254 : H12AffineEnvironment.transform 13 5236 env10253 = env10254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env10253 == env10254) = true)

theorem identity10254 : scanCanonicalize (H12AffineFastState.compose env10254 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10254 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env10255 : List Nat := [2,4,8,16,32,17,9,256,512,1024,782,4096,40,5157,292,35,5173,783,1025,293,4113,33,17,2,41,17,555,5392,4388,555,1284,260,257,261,5377,512]

theorem envBound10255 : H12AffineFastState.Bounded env10255 := by
  intro p hp
  have h : env10255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10254_10255 : H12AffineEnvironment.transform 5 17 env10254 = env10255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10254 == env10255) = true)

theorem identity10255 : scanCanonicalize (H12AffineFastState.compose env10255 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound10255 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10256 : List Nat := [2,4,8,16,32,17,9,256,512,1024,782,1313,40,260,292,35,276,783,1025,293,1328,33,17,2,41,17,555,49,1029,555,1284,260,257,261,32,512]

theorem envBound10256 : H12AffineFastState.Bounded env10256 := by
  intro p hp
  have h : env10256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10255_10256 : H12AffineEnvironment.transform 11 1313 env10255 = env10256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env10255 == env10256) = true)

theorem identity10256 : scanCanonicalize (H12AffineFastState.compose env10256 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10256 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10257 : List Nat := [2,4,8,16,32,17,9,5,512,1024,523,1060,40,1,33,35,17,522,1025,32,1077,33,17,2,41,17,555,49,1029,555,1025,1,4,0,32,512]

theorem envBound10257 : H12AffineFastState.Bounded env10257 := by
  intro p hp
  have h : env10257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10256_10257 : H12AffineEnvironment.transform 7 5 env10256 = env10257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10256 == env10257) = true)

theorem identity10257 : scanCanonicalize (H12AffineFastState.compose env10257 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 543) := by decide +kernel

theorem selectedBound10257 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10258 : List Nat := [2,4,8,16,32,17,9,5,512,543,523,571,40,1,33,35,17,522,542,32,554,33,17,2,41,17,555,49,538,555,542,1,4,0,32,512]

theorem envBound10258 : H12AffineFastState.Bounded env10258 := by
  intro p hp
  have h : env10258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10257_10258 : H12AffineEnvironment.transform 9 543 env10257 = env10258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 543 env10257 == env10258) = true)

theorem identity10258 : scanCanonicalize (H12AffineFastState.compose env10258 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 40) := by decide +kernel

theorem selectedBound10258 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env10259 : List Nat := [2,4,8,16,32,17,9,5,40,55,35,19,40,1,33,35,17,34,54,32,2,33,17,2,41,17,3,49,50,3,54,1,4,0,32,40]

theorem envBound10259 : H12AffineFastState.Bounded env10259 := by
  intro p hp
  have h : env10259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10258_10259 : H12AffineEnvironment.transform 8 40 env10258 = env10259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 40 env10258 == env10259) = true)

theorem identity10259 : scanCanonicalize (H12AffineFastState.compose env10259 (packedSelected [0,8] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound10259 : packedSelected [0,8] rootPS < 2^1333 := by decide +kernel

def env10260 : List Nat := [2,4,8,16,2,17,9,5,10,21,1,19,10,1,3,1,17,0,20,2,2,3,17,2,11,17,3,19,16,3,20,1,4,0,2,10]

theorem envBound10260 : H12AffineFastState.Bounded env10260 := by
  intro p hp
  have h : env10260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10259_10260 : H12AffineEnvironment.transform 4 2 env10259 = env10260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env10259 == env10260) = true)

def env10261 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,16400,262144,1025,21760,4161,272392,16,87125,8193,64,10589,5393,17665,283904,1364,264533,257,21792,24844,74250]

theorem envBound10261 : H12AffineFastState.Bounded env10261 := by
  intro p hp
  have h : env10261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10248_10261 : H12AffineEnvironment.transform 20 4161 env10248 = env10261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env10248 == env10261) = true)

theorem identity10261 : scanCanonicalize (H12AffineFastState.compose env10261 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound10261 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10262 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21590,16400,262144,1025,21760,4161,272392,16,3,8193,64,10589,5393,17665,283904,1364,264533,257,21792,24844,30300]

theorem envBound10262 : H12AffineFastState.Bounded env10262 := by
  intro p hp
  have h : env10262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10261_10262 : H12AffineEnvironment.transform 15 21590 env10261 = env10262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env10261 == env10262) = true)

theorem identity10262 : scanCanonicalize (H12AffineFastState.compose env10262 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound10262 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env10263 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,21590,16400,32040,1025,21760,4161,21792,16,3,8193,64,10589,5393,17665,10280,1364,29821,257,21792,24844,30300]

theorem envBound10263 : H12AffineFastState.Bounded env10263 := by
  intro p hp
  have h : env10263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10262_10263 : H12AffineEnvironment.transform 17 32040 env10262 = env10263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env10262 == env10263) = true)

theorem identity10263 : scanCanonicalize (H12AffineFastState.compose env10263 (packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound10263 : packedSelected [0,1,2,3,5,7,8,10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env10264 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13688,8313,8494,13672,2128,1025,8312,4161,8280,16,3,8193,64,10589,5393,12409,10280,1364,261,257,8280,5236,804]

theorem envBound10264 : H12AffineFastState.Bounded env10264 := by
  intro p hp
  have h : env10264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10263_10264 : H12AffineEnvironment.transform 13 13688 env10263 = env10264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env10263 == env10264) = true)

theorem identity10264 : scanCanonicalize (H12AffineFastState.compose env10264 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10264 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env10265 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5156,293,114,5172,2128,1025,292,4161,260,16,3,349,64,2049,5393,4389,2420,1364,261,257,260,5236,804]

theorem envBound10265 : H12AffineFastState.Bounded env10265 := by
  intro p hp
  have h : env10265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10264_10265 : H12AffineEnvironment.transform 12 348 env10264 = env10265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10264 == env10265) = true)

theorem identity10265 : scanCanonicalize (H12AffineFastState.compose env10265 (packedSelected [1,2,4,6,8,9,10,11] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound10265 : packedSelected [1,2,4,6,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env10266 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3409,348,2421,293,114,2405,2128,1025,292,3344,260,16,3,349,64,2049,2112,3188,2420,1364,261,257,260,2341,804]

theorem envBound10266 : H12AffineFastState.Bounded env10266 := by
  intro p hp
  have h : env10266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10265_10266 : H12AffineEnvironment.transform 11 3409 env10265 = env10266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env10265 == env10266) = true)

theorem identity10266 : scanCanonicalize (H12AffineFastState.compose env10266 (packedSelected [0,1,2,3,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10266 : packedSelected [0,1,2,3,9,10] rootPS < 2^1333 := by decide +kernel

def env10267 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3328,269,2340,293,35,2356,2049,1025,292,3344,260,16,3,268,17,2049,2065,3109,2341,1285,261,257,260,2341,804]

theorem envBound10267 : H12AffineFastState.Bounded env10267 := by
  intro p hp
  have h : env10267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10266_10267 : H12AffineEnvironment.transform 5 17 env10266 = env10267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10266 == env10267) = true)

theorem identity10267 : scanCanonicalize (H12AffineFastState.compose env10267 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound10267 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10268 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2356,269,2340,293,35,2356,2049,53,292,2340,260,16,3,268,17,2049,2065,2065,2341,305,261,257,260,2341,804]

theorem envBound10268 : H12AffineFastState.Bounded env10268 := by
  intro p hp
  have h : env10268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10267_10268 : H12AffineEnvironment.transform 9 52 env10267 = env10268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env10267 == env10268) = true)

theorem identity10268 : scanCanonicalize (H12AffineFastState.compose env10268 (packedSelected [0,2] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound10268 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env10269 : List Nat := [2,4,8,16,32,17,9,256,512,52,528,804,269,820,293,35,804,529,53,292,820,260,16,3,268,17,529,513,513,821,305,261,257,260,821,804]

theorem envBound10269 : H12AffineFastState.Bounded env10269 := by
  intro p hp
  have h : env10269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10268_10269 : H12AffineEnvironment.transform 10 528 env10268 = env10269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env10268 == env10269) = true)

theorem identity10269 : scanCanonicalize (H12AffineFastState.compose env10269 (packedSelected [1,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10269 : packedSelected [1,3,6] rootPS < 2^1333 := by decide +kernel

def env10270 : List Nat := [2,4,8,16,32,17,9,37,512,52,528,513,40,529,0,35,513,529,53,1,529,33,16,3,41,17,529,513,513,528,20,32,36,33,528,513]

theorem envBound10270 : H12AffineFastState.Bounded env10270 := by
  intro p hp
  have h : env10270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10269_10270 : H12AffineEnvironment.transform 7 37 env10269 = env10270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10269 == env10270) = true)

theorem identity10270 : scanCanonicalize (H12AffineFastState.compose env10270 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound10270 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10271 : List Nat := [2,4,8,16,32,17,9,37,27,52,11,26,40,10,0,35,26,10,53,1,10,33,16,3,41,17,10,26,26,11,20,32,36,33,11,26]

theorem envBound10271 : H12AffineFastState.Bounded env10271 := by
  intro p hp
  have h : env10271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10270_10271 : H12AffineEnvironment.transform 8 27 env10270 = env10271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env10270 == env10271) = true)

def env10272 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,4194304,2101328,98780,8328,64,6603796,2098513,17664,2377160,2102684,6349852,257,21792,46212,2175563]

theorem envBound10272 : H12AffineFastState.Bounded env10272 := by
  intro p hp
  have h : env10272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10215_10272 : H12AffineEnvironment.transform 16 38297 env10215 = env10272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38297 env10215 == env10272) = true)

def env10273 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272512,2101328,98780,8328,64,2157716,2098513,17664,2377160,2102684,2411676,257,21792,46212,2175563]

theorem envBound10273 : H12AffineFastState.Bounded env10273 := by
  intro p hp
  have h : env10273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10272_10273 : H12AffineEnvironment.transform 21 272512 env10272 = env10273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10272 == env10273) = true)

theorem identity10273 : scanCanonicalize (H12AffineFastState.compose env10273 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 58516) := by decide +kernel

theorem selectedBound10273 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10274 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,58516,272512,62660,98780,8328,64,2048,57797,17664,303452,61704,272392,257,21792,46212,120543]

theorem envBound10274 : H12AffineFastState.Bounded env10274 := by
  intro p hp
  have h : env10274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10273_10274 : H12AffineEnvironment.transform 20 58516 env10273 = env10274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58516 env10273 == env10274) = true)

def env10275 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10280,1025,32769,58516,168,62660,98780,8328,64,2048,57797,17664,35188,61704,32,257,21792,46212,120543]

theorem envBound10275 : H12AffineFastState.Bounded env10275 := by
  intro p hp
  have h : env10275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10274_10275 : H12AffineEnvironment.transform 17 10280 env10274 = env10275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10274 == env10275) = true)

theorem identity10275 : scanCanonicalize (H12AffineFastState.compose env10275 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound10275 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10276 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33111,38297,10280,1025,32769,58516,168,62660,139,8328,64,2048,57797,17664,35188,61704,32,257,21792,46212,22408]

theorem envBound10276 : H12AffineFastState.Bounded env10276 := by
  intro p hp
  have h : env10276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10275_10276 : H12AffineEnvironment.transform 15 33111 env10275 = env10276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env10275 == env10276) = true)

theorem identity10276 : scanCanonicalize (H12AffineFastState.compose env10276 (packedSelected [0,1,4,7,8,16,19,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound10276 : packedSelected [0,1,4,7,8,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env10277 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,30082,24908,10280,1025,29908,4161,168,17,139,8328,64,2048,5392,17664,32161,1501,32,257,21792,16465,22408]

theorem envBound10277 : H12AffineFastState.Bounded env10277 := by
  intro p hp
  have h : env10277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10276_10277 : H12AffineEnvironment.transform 14 29909 env10276 = env10277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env10276 == env10277) = true)

theorem identity10277 : scanCanonicalize (H12AffineFastState.compose env10277 (packedSelected [1,4,6,8,9,11,12,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 13356) := by decide +kernel

theorem selectedBound10277 : packedSelected [1,4,6,8,9,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env10278 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13356,249,430,5472,10280,1025,248,4161,168,17,139,8328,64,2048,5392,12588,2445,1501,32,257,8460,13437,9124]

theorem envBound10278 : H12AffineFastState.Bounded env10278 := by
  intro p hp
  have h : env10278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10277_10278 : H12AffineEnvironment.transform 13 13356 env10277 = env10278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13356 env10277 == env10278) = true)

theorem identity10278 : scanCanonicalize (H12AffineFastState.compose env10278 (packedSelected [2,3,5,6,10,17] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound10278 : packedSelected [2,3,5,6,10,17] rootPS < 2^1333 := by decide +kernel

def env10279 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,8192,13356,81,262,5472,10280,1025,80,4161,0,17,35,8224,64,2048,5392,12588,2341,1397,32,257,8460,13437,8972]

theorem envBound10279 : H12AffineFastState.Bounded env10279 := by
  intro p hp
  have h : env10279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10278_10279 : H12AffineEnvironment.transform 6 40 env10278 = env10279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env10278 == env10279) = true)

theorem identity10279 : scanCanonicalize (H12AffineFastState.compose env10279 (packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound10279 : packedSelected [0,2,3,4,5,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env10280 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,13325,81,262,5441,10249,1025,80,4161,0,17,2,8193,64,2048,5392,12557,2308,1364,1,257,8460,13404,8972]

theorem envBound10280 : H12AffineFastState.Bounded env10280 := by
  intro p hp
  have h : env10280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10279_10280 : H12AffineEnvironment.transform 4 1 env10279 = env10280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env10279 == env10280) = true)

theorem identity10280 : scanCanonicalize (H12AffineFastState.compose env10280 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10280 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10281 : List Nat := [2,4,8,16,1,16,9,256,512,1024,2048,4096,8192,13325,1,262,5393,10249,1025,0,4113,0,17,2,8193,16,2048,5392,12557,2308,1284,1,257,8460,13324,8972]

theorem envBound10281 : H12AffineFastState.Bounded env10281 := by
  intro p hp
  have h : env10281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10280_10281 : H12AffineEnvironment.transform 5 16 env10280 = env10281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10280 == env10281) = true)

def env10282 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,10281,1025,32769,58516,169,62660,98780,8328,64,2048,57797,17664,35189,61704,33,257,21792,46212,120543]

theorem envBound10282 : H12AffineFastState.Bounded env10282 := by
  intro p hp
  have h : env10282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10274_10282 : H12AffineEnvironment.transform 17 10281 env10274 = env10282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10274 == env10282) = true)

theorem identity10282 : scanCanonicalize (H12AffineFastState.compose env10282 (packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound10282 : packedSelected [2,3,6,7,8,9,10,16,22,23,24,26,27,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10283 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,16384,32768,65536,37373,10281,101,32769,57584,169,61600,98780,8328,64,2048,57797,16740,35189,61704,33,257,20804,45280,119483]

theorem envBound10283 : H12AffineFastState.Bounded env10283 := by
  intro p hp
  have h : env10283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10282_10283 : H12AffineEnvironment.transform 9 100 env10282 = env10283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env10282 == env10283) = true)

theorem identity10283 : scanCanonicalize (H12AffineFastState.compose env10283 (packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS)) = affineNative (2^(13+1) ^^^ 12573) := by decide +kernel

theorem selectedBound10283 : packedSelected [0,1,4,7,8,10,15,16,20,22,26,31,38] rootPS < 2^1333 := by decide +kernel

def env10284 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12573,32768,65536,37373,10281,101,32769,37357,169,33213,98780,8328,64,2048,37080,12409,35189,32789,33,257,8281,45280,107430]

theorem envBound10284 : H12AffineFastState.Bounded env10284 := by
  intro p hp
  have h : env10284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10283_10284 : H12AffineEnvironment.transform 13 12573 env10283 = env10284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12573 env10283 == env10284) = true)

theorem identity10284 : scanCanonicalize (H12AffineFastState.compose env10284 (packedSelected [1,2,3,4,5,6,11,12,15,16,17,22,23,26,28] rootPS)) = affineNative (2^(14+1) ^^^ 8660) := by decide +kernel

theorem selectedBound10284 : packedSelected [1,2,3,4,5,6,11,12,15,16,17,22,23,26,28] rootPS < 2^1333 := by decide +kernel

def env10285 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12573,8660,65536,12329,10281,101,8661,12345,169,8297,73736,8328,64,2048,12556,12409,10401,8641,33,257,8281,4404,66162]

theorem envBound10285 : H12AffineFastState.Bounded env10285 := by
  intro p hp
  have h : env10285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10284_10285 : H12AffineEnvironment.transform 14 8660 env10284 = env10285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8660 env10284 == env10285) = true)

theorem identity10285 : scanCanonicalize (H12AffineFastState.compose env10285 (packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 8403) := by decide +kernel

theorem selectedBound10285 : packedSelected [1,4,8,9,12,14,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env10286 : List Nat := [2,4,8,16,32,64,128,256,512,100,2048,4096,8192,12573,8660,8403,12329,10281,101,8661,12345,169,8297,219,8328,64,2048,12556,12409,10401,8641,33,257,8281,4404,8865]

theorem envBound10286 : H12AffineFastState.Bounded env10286 := by
  intro p hp
  have h : env10286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10285_10286 : H12AffineEnvironment.transform 15 8403 env10285 = env10286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8403 env10285 == env10286) = true)

theorem identity10286 : scanCanonicalize (H12AffineFastState.compose env10286 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound10286 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env10287 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,4096,8192,12573,8461,8202,12329,10281,101,8460,12345,112,8297,2,8273,64,2048,12556,12409,10360,8472,33,257,8281,4404,8824]

theorem envBound10287 : H12AffineFastState.Bounded env10287 := by
  intro p hp
  have h : env10287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10286_10287 : H12AffineEnvironment.transform 6 89 env10286 = env10287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env10286 == env10287) = true)

theorem identity10287 : scanCanonicalize (H12AffineFastState.compose env10287 (packedSelected [2,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10287 : packedSelected [2,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10288 : List Nat := [2,4,8,16,32,64,89,256,512,100,2048,4096,269,4112,0,263,4388,2340,101,1,4404,112,356,2,348,64,2048,4097,4468,2421,21,33,257,340,4404,885]

theorem envBound10288 : H12AffineFastState.Bounded env10288 := by
  intro p hp
  have h : env10288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10287_10288 : H12AffineEnvironment.transform 12 269 env10287 = env10288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10287 == env10288) = true)

def env10289 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38297,262144,1025,32769,2097152,272513,2101328,98780,8328,64,2157717,2098513,17664,2377160,2102684,2411677,257,21792,46212,2175563]

theorem envBound10289 : H12AffineFastState.Bounded env10289 := by
  intro p hp
  have h : env10289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10272_10289 : H12AffineEnvironment.transform 21 272513 env10272 = env10289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10272 == env10289) = true)

theorem identity10289 : scanCanonicalize (H12AffineFastState.compose env10289 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound10289 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10290 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,24908,262144,1025,29908,2097152,272513,2101328,95497,8328,64,2103360,2098513,17664,2377160,2102684,2373704,257,21792,16465,2175563]

theorem envBound10290 : H12AffineFastState.Bounded env10290 := by
  intro p hp
  have h : env10290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10289_10290 : H12AffineEnvironment.transform 14 29909 env10289 = env10290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env10289 == env10290) = true)

def env10291 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,13388,262144,1025,8660,2097152,272513,2101328,73737,8328,64,2103360,2098513,4096,2363592,2102684,2373704,257,32,5457,2175563]

theorem envBound10291 : H12AffineFastState.Bounded env10291 := by
  intro p hp
  have h : env10291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10290_10291 : H12AffineEnvironment.transform 13 5376 env10290 = env10291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10290 == env10291) = true)

theorem identity10291 : scanCanonicalize (H12AffineFastState.compose env10291 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound10291 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env10292 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,65536,5528,262144,1025,0,2097152,264533,2101328,66013,348,64,2103360,2098513,4096,2363592,2102684,2365852,257,32,5457,2167711]

theorem envBound10292 : H12AffineFastState.Bounded env10292 := by
  intro p hp
  have h : env10292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10291_10292 : H12AffineEnvironment.transform 12 468 env10291 = env10292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env10291 == env10292) = true)

theorem identity10292 : scanCanonicalize (H12AffineFastState.compose env10292 (packedSelected [0,1,4,7,19,22,28,31] rootPS)) = affineNative (2^(20+1) ^^^ 333922) := by decide +kernel

theorem selectedBound10292 : packedSelected [0,1,4,7,19,22,28,31] rootPS < 2^1333 := by decide +kernel

def env10293 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,65536,5528,262144,1025,0,333922,264533,329778,66013,348,64,327714,335155,4096,67754,331262,66046,257,32,5457,265213]

theorem envBound10293 : H12AffineFastState.Bounded env10293 := by
  intro p hp
  have h : env10293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10292_10293 : H12AffineEnvironment.transform 20 333922 env10292 = env10293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 333922 env10292 == env10293) = true)

theorem identity10293 : scanCanonicalize (H12AffineFastState.compose env10293 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(17+1) ^^^ 67755) := by decide +kernel

theorem selectedBound10293 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env10294 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,65536,5528,67755,1025,0,4297,66046,153,66013,348,64,2185,5528,4096,67754,1365,66046,257,32,5457,66390]

theorem envBound10294 : H12AffineFastState.Bounded env10294 := by
  intro p hp
  have h : env10294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10293_10294 : H12AffineEnvironment.transform 17 67755 env10293 = env10294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67755 env10293 == env10294) = true)

theorem identity10294 : scanCanonicalize (H12AffineFastState.compose env10294 (packedSelected [16,17,20] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound10294 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env10295 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,1,343,5528,2556,1025,0,4297,169,153,138,348,64,2185,5528,4096,2557,1365,169,257,32,5457,513]

theorem envBound10295 : H12AffineFastState.Bounded env10295 := by
  intro p hp
  have h : env10295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10294_10295 : H12AffineEnvironment.transform 15 343 env10294 = env10295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env10294 == env10295) = true)

theorem identity10295 : scanCanonicalize (H12AffineFastState.compose env10295 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10295 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10296 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,389,5376,1,262,5528,2477,1025,0,4248,169,153,138,269,17,2185,5528,4096,2476,1284,169,257,32,5376,513]

theorem envBound10296 : H12AffineFastState.Bounded env10296 := by
  intro p hp
  have h : env10296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10295_10296 : H12AffineEnvironment.transform 5 17 env10295 = env10296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10295 == env10296) = true)

theorem identity10296 : scanCanonicalize (H12AffineFastState.compose env10296 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1724) := by decide +kernel

theorem selectedBound10296 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10297 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,1724,389,956,1,262,804,2477,1025,0,1572,169,153,138,269,17,2185,804,1724,2476,1284,169,257,32,956,513]

theorem envBound10297 : H12AffineFastState.Bounded env10297 := by
  intro p hp
  have h : env10297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10296_10297 : H12AffineEnvironment.transform 11 1724 env10296 = env10297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1724 env10296 == env10297) = true)

theorem identity10297 : scanCanonicalize (H12AffineFastState.compose env10297 (packedSelected [3,5,7,9,11] rootPS)) = affineNative (2^(10+1) ^^^ 1280) := by decide +kernel

theorem selectedBound10297 : packedSelected [3,5,7,9,11] rootPS < 2^1333 := by decide +kernel

def env10298 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1280,1724,389,956,1,262,804,1197,1025,0,1572,169,153,138,269,17,1417,804,1724,1196,1284,169,257,32,956,513]

theorem envBound10298 : H12AffineFastState.Bounded env10298 := by
  intro p hp
  have h : env10298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10297_10298 : H12AffineEnvironment.transform 10 1280 env10297 = env10298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1280 env10297 == env10298) = true)

theorem identity10298 : scanCanonicalize (H12AffineFastState.compose env10298 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(9+1) ^^^ 37) := by decide +kernel

theorem selectedBound10298 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env10299 : List Nat := [2,4,8,16,32,17,128,256,512,37,293,665,389,956,1,262,804,136,36,0,513,169,153,138,269,17,428,804,665,137,289,169,257,32,956,513]

theorem envBound10299 : H12AffineFastState.Bounded env10299 := by
  intro p hp
  have h : env10299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10298_10299 : H12AffineEnvironment.transform 9 37 env10298 = env10299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 37 env10298 == env10299) = true)

theorem identity10299 : scanCanonicalize (H12AffineFastState.compose env10299 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 428) := by decide +kernel

theorem selectedBound10299 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env10300 : List Nat := [2,4,8,16,32,17,128,256,428,37,293,309,389,16,1,262,136,136,36,0,429,169,153,138,269,17,428,136,309,137,289,169,257,32,16,429]

theorem envBound10300 : H12AffineFastState.Bounded env10300 := by
  intro p hp
  have h : env10300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10299_10300 : H12AffineEnvironment.transform 8 428 env10299 = env10300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 428 env10299 == env10300) = true)

theorem identity10300 : scanCanonicalize (H12AffineFastState.compose env10300 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 52) := by decide +kernel

theorem selectedBound10300 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10301 : List Nat := [2,4,8,16,32,17,128,52,152,37,17,1,177,16,1,50,136,136,36,0,153,169,153,138,57,17,152,136,1,137,21,169,53,32,16,153]

theorem envBound10301 : H12AffineFastState.Bounded env10301 := by
  intro p hp
  have h : env10301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10300_10301 : H12AffineEnvironment.transform 7 52 env10300 = env10301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 52 env10300 == env10301) = true)

theorem identity10301 : scanCanonicalize (H12AffineFastState.compose env10301 (packedSelected [0] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10301 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10302 : List Nat := [2,4,8,16,32,17,8,52,16,37,17,1,57,16,1,50,0,0,36,0,17,33,17,2,57,17,16,0,1,1,21,33,53,32,16,17]

theorem envBound10302 : H12AffineFastState.Bounded env10302 := by
  intro p hp
  have h : env10302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10301_10302 : H12AffineEnvironment.transform 6 8 env10301 = env10302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10301 == env10302) = true)

theorem identity10302 : scanCanonicalize (H12AffineFastState.compose env10302 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound10302 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10303 : List Nat := [2,4,8,16,10,17,8,30,16,15,17,1,19,16,1,24,0,0,14,0,17,11,17,2,19,17,16,0,1,1,21,11,31,10,16,17]

theorem envBound10303 : H12AffineFastState.Bounded env10303 := by
  intro p hp
  have h : env10303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10302_10303 : H12AffineEnvironment.transform 4 10 env10302 = env10303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env10302 == env10303) = true)

theorem identity10303 : scanCanonicalize (H12AffineFastState.compose env10303 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10303 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10304 : List Nat := [2,4,8,0,10,1,8,14,0,15,1,1,3,0,1,8,0,0,14,0,1,11,1,2,3,1,0,0,1,1,5,11,15,10,0,1]

theorem envBound10304 : H12AffineFastState.Bounded env10304 := by
  intro p hp
  have h : env10304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10303_10304 : H12AffineEnvironment.transform 3 0 env10303 = env10304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10303 == env10304) = true)

def env10305 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,262144,1025,8661,2097152,272513,2101328,73736,8328,64,2103360,2098513,4097,2363593,2102684,2373704,257,33,5456,2175563]

theorem envBound10305 : H12AffineFastState.Bounded env10305 := by
  intro p hp
  have h : env10305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10290_10305 : H12AffineEnvironment.transform 13 5377 env10290 = env10305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10290 == env10305) = true)

theorem identity10305 : scanCanonicalize (H12AffineFastState.compose env10305 (packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 276584) := by decide +kernel

theorem selectedBound10305 : packedSelected [3,4,5,7,8,9,11,12,15,16,17,18,20,23,27,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env10306 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,13389,262144,1025,8661,276584,272513,272440,73736,8328,64,270376,277817,4097,10401,273908,32,257,33,5456,330275]

theorem envBound10306 : H12AffineFastState.Bounded env10306 := by
  intro p hp
  have h : env10306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10305_10306 : H12AffineEnvironment.transform 20 276584 env10305 = env10306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 276584 env10305 == env10306) = true)

theorem identity10306 : scanCanonicalize (H12AffineFastState.compose env10306 (packedSelected [1,4,5,7,8,9,10,16,17,19,20,24,26,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound10306 : packedSelected [1,4,5,7,8,9,10,16,17,19,20,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env10307 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8322,13389,262144,1025,8661,276584,272513,272440,138,8328,64,270376,277817,4097,10401,273908,32,257,33,5456,273057]

theorem envBound10307 : H12AffineFastState.Bounded env10307 := by
  intro p hp
  have h : env10307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10306_10307 : H12AffineEnvironment.transform 15 8322 env10306 = env10307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env10306 == env10307) = true)

theorem identity10307 : scanCanonicalize (H12AffineFastState.compose env10307 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10307 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env10308 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,136,478,5393,262144,1025,137,268596,264669,264548,138,468,64,262516,269413,4097,2557,265384,32,257,33,5456,265213]

theorem envBound10308 : H12AffineFastState.Bounded env10308 := by
  intro p hp
  have h : env10308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10307_10308 : H12AffineEnvironment.transform 12 348 env10307 = env10308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10307 == env10308) = true)

theorem identity10308 : scanCanonicalize (H12AffineFastState.compose env10308 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound10308 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env10309 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,81,263,5393,262144,1025,80,268596,264452,264548,83,269,64,262516,269413,4097,2340,265329,32,257,33,5456,264996]

theorem envBound10309 : H12AffineFastState.Bounded env10309 := by
  intro p hp
  have h : env10309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10308_10309 : H12AffineEnvironment.transform 6 89 env10308 = env10309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env10308 == env10309) = true)

theorem identity10309 : scanCanonicalize (H12AffineFastState.compose env10309 (packedSelected [2,3,5,6,10,11,15] rootPS)) = affineNative (2^(17+1) ^^^ 2341) := by decide +kernel

theorem selectedBound10309 : packedSelected [2,3,5,6,10,11,15] rootPS < 2^1333 := by decide +kernel

def env10310 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,348,5377,81,263,5393,2341,1025,80,4113,33,65,83,269,64,2129,5440,4097,2340,1364,32,257,33,5456,513]

theorem envBound10310 : H12AffineFastState.Bounded env10310 := by
  intro p hp
  have h : env10310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10309_10310 : H12AffineEnvironment.transform 17 2341 env10309 = env10310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2341 env10309 == env10310) = true)

theorem identity10310 : scanCanonicalize (H12AffineFastState.compose env10310 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10310 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10311 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,1,263,5393,2341,1025,0,4113,33,17,3,269,16,2049,5392,4097,2340,1284,32,257,33,5376,513]

theorem envBound10311 : H12AffineFastState.Bounded env10311 := by
  intro p hp
  have h : env10311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10310_10311 : H12AffineEnvironment.transform 5 16 env10310 = env10311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10310 == env10311) = true)

theorem identity10311 : scanCanonicalize (H12AffineFastState.compose env10311 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10311 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10312 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,1296,268,17,1,263,1,2341,1025,0,1281,33,17,3,269,16,2049,0,1297,2340,1284,32,257,33,16,513]

theorem envBound10312 : H12AffineFastState.Bounded env10312 := by
  intro p hp
  have h : env10312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10311_10312 : H12AffineEnvironment.transform 11 1296 env10311 = env10312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1296 env10311 == env10312) = true)

theorem identity10312 : scanCanonicalize (H12AffineFastState.compose env10312 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10312 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10313 : List Nat := [2,4,8,16,32,16,9,256,0,1024,2048,1296,268,17,1,263,1,2341,1025,0,1281,33,17,3,269,16,2049,0,1297,2340,1284,32,257,33,16,1]

theorem envBound10313 : H12AffineFastState.Bounded env10313 := by
  intro p hp
  have h : env10313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10312_10313 : H12AffineEnvironment.transform 8 0 env10312 = env10313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10312 == env10313) = true)

theorem identity10313 : scanCanonicalize (H12AffineFastState.compose env10313 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 16) := by decide +kernel

theorem selectedBound10313 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10314 : List Nat := [2,4,8,16,32,16,9,256,0,1024,16,1296,268,17,1,263,1,309,1025,0,1281,33,17,3,269,16,17,0,1297,308,1284,32,257,33,16,1]

theorem envBound10314 : H12AffineFastState.Bounded env10314 := by
  intro p hp
  have h : env10314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10313_10314 : H12AffineEnvironment.transform 10 16 env10313 = env10314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 16 env10313 == env10314) = true)

theorem identity10314 : scanCanonicalize (H12AffineFastState.compose env10314 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound10314 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10315 : List Nat := [2,4,8,16,32,16,9,37,0,1024,16,1077,41,17,1,34,1,16,1025,0,1060,33,17,3,40,16,17,0,1076,17,1057,32,36,33,16,1]

theorem envBound10315 : H12AffineFastState.Bounded env10315 := by
  intro p hp
  have h : env10315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10314_10315 : H12AffineEnvironment.transform 7 37 env10314 = env10315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env10314 == env10315) = true)

def env10316 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393345,19497100,10507600,9356289,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound10316 : H12AffineFastState.Bounded env10316 := by
  intro p hp
  have h : env10316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9920_10316 : H12AffineEnvironment.transform 26 30393345 env9920 = env10316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env9920 == env10316) = true)

def env10317 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound10317 : H12AffineFastState.Bounded env10317 := by
  intro p hp
  have h : env10317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10316_10317 : H12AffineEnvironment.transform 18 1024 env10316 = env10317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env10316 == env10317) = true)

theorem identity10317 : scanCanonicalize (H12AffineFastState.compose env10317 (packedSelected [13] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound10317 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10318 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8192,64,29868033,18973700,10507600,8830977,25265168,23160137,256,27378724,27337992,25207630]

theorem envBound10318 : H12AffineFastState.Bounded env10318 := by
  intro p hp
  have h : env10318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10317_10318 : H12AffineEnvironment.transform 6 8 env10317 = env10318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10317 == env10318) = true)

def env10319 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147456,16777216,8192,64,21331969,18973700,2233680,294913,17024016,23160137,256,19104804,19096840,16966478]

theorem envBound10319 : H12AffineFastState.Bounded env10319 := by
  intro p hp
  have h : env10319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10318_10319 : H12AffineEnvironment.transform 22 147456 env10318 = env10319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env10318 == env10319) = true)

theorem identity10319 : scanCanonicalize (H12AffineFastState.compose env10319 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(23+1) ^^^ 188751) := by decide +kernel

theorem selectedBound10319 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env10320 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147456,188751,8192,64,4677966,2319691,2233680,294913,75103,6521862,256,2188651,2196551,513]

theorem envBound10320 : H12AffineFastState.Bounded env10320 := by
  intro p hp
  have h : env10320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10319_10320 : H12AffineEnvironment.transform 23 188751 env10319 = env10320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 188751 env10319 == env10320) = true)

def env10321 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,16,41311,8192,64,4530526,2172251,2118976,294913,75103,6407190,256,2188651,2196551,513]

theorem envBound10321 : H12AffineFastState.Bounded env10321 := by
  intro p hp
  have h : env10321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10320_10321 : H12AffineEnvironment.transform 16 16400 env10320 = env10321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10320 == env10321) = true)

def env10322 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41311,8192,64,4530526,115015,45404,294913,75103,4268042,256,98679,90203,513]

theorem envBound10322 : H12AffineFastState.Bounded env10322 := by
  intro p hp
  have h : env10322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10321_10322 : H12AffineEnvironment.transform 20 58396 env10321 = env10322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env10321 == env10322) = true)

def env10323 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41231,8192,16,4530446,114967,45324,294913,75023,4268042,256,98599,90123,513]

theorem envBound10323 : H12AffineFastState.Bounded env10323 := by
  intro p hp
  have h : env10323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10322_10323 : H12AffineEnvironment.transform 5 16 env10322 = env10323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10322 == env10323) = true)

theorem identity10323 : scanCanonicalize (H12AffineFastState.compose env10323 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 329731) := by decide +kernel

theorem selectedBound10323 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env10324 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,329731,16,41231,8192,16,10509,114967,45324,294913,75023,272393,256,98599,90123,513]

theorem envBound10324 : H12AffineFastState.Bounded env10324 := by
  intro p hp
  have h : env10324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10323_10324 : H12AffineEnvironment.transform 21 329731 env10323 = env10324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 329731 env10323 == env10324) = true)

theorem identity10324 : scanCanonicalize (H12AffineFastState.compose env10324 (packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS)) = affineNative (2^(17+1) ^^^ 108847) := by decide +kernel

theorem selectedBound10324 : packedSelected [1,2,3,4,5,6,8,9,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env10325 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,108847,1024,32769,58396,41260,16,41231,8192,16,10509,114967,45324,76078,75023,98598,256,98599,90123,513]

theorem envBound10325 : H12AffineFastState.Bounded env10325 := by
  intro p hp
  have h : env10325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10324_10325 : H12AffineEnvironment.transform 17 108847 env10324 = env10325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 108847 env10324 == env10325) = true)

def env10326 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,4194304,16,41230,8192,17,4530447,114966,45325,294913,75022,4268042,256,98598,90122,513]

theorem envBound10326 : H12AffineFastState.Bounded env10326 := by
  intro p hp
  have h : env10326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10322_10326 : H12AffineEnvironment.transform 5 17 env10322 = env10326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10322 == env10326) = true)

theorem identity10326 : scanCanonicalize (H12AffineFastState.compose env10326 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272393) := by decide +kernel

theorem selectedBound10326 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env10327 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58396,272393,16,41230,8192,17,67846,114966,45325,294913,75022,329731,256,98598,90122,513]

theorem envBound10327 : H12AffineFastState.Bounded env10327 := by
  intro p hp
  have h : env10327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10326_10327 : H12AffineEnvironment.transform 21 272393 env10326 = env10327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272393 env10326 == env10327) = true)

theorem identity10327 : scanCanonicalize (H12AffineFastState.compose env10327 (packedSelected [0,3,7,10,19,20,24] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10327 : packedSelected [0,3,7,10,19,20,24] rootPS < 2^1333 := by decide +kernel

def env10328 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,65536,16400,262144,1024,1,25628,272393,16,8462,8192,17,67846,82198,12557,262145,75022,329731,256,65830,90122,513]

theorem envBound10328 : H12AffineFastState.Bounded env10328 := by
  intro p hp
  have h : env10328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10327_10328 : H12AffineEnvironment.transform 14 0 env10327 = env10328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10327 == env10328) = true)

theorem identity10328 : scanCanonicalize (H12AffineFastState.compose env10328 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10328 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10329 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,0,65536,16400,10280,1024,1,25628,33,16,8462,8192,17,67846,82198,12557,10281,75022,73771,256,65830,90122,513]

theorem envBound10329 : H12AffineFastState.Bounded env10329 := by
  intro p hp
  have h : env10329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10328_10329 : H12AffineEnvironment.transform 17 10280 env10328 = env10329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10328 == env10329) = true)

def env10330 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,58397,4194304,16,41311,8192,64,4530526,115014,45405,294913,75103,4268043,256,98678,90202,513]

theorem envBound10330 : H12AffineFastState.Bounded env10330 := by
  intro p hp
  have h : env10330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10321_10330 : H12AffineEnvironment.transform 20 58397 env10321 = env10330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env10321 == env10330) = true)

theorem identity10330 : scanCanonicalize (H12AffineFastState.compose env10330 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10330 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10331 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,58397,4194304,16,41311,8192,64,4456789,57677,45405,294913,1364,4194304,256,41341,16465,513]

theorem envBound10331 : H12AffineFastState.Bounded env10331 := by
  intro p hp
  have h : env10331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10330_10331 : H12AffineEnvironment.transform 15 8203 env10330 = env10331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10330 == env10331) = true)

theorem identity10331 : scanCanonicalize (H12AffineFastState.compose env10331 (packedSelected [0,14,27] rootPS)) = affineNative (2^(21+1) ^^^ 272472) := by decide +kernel

theorem selectedBound10331 : packedSelected [0,14,27] rootPS < 2^1333 := by decide +kernel

def env10332 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,262144,1024,32769,58397,272472,16,41311,8192,64,10509,57677,45405,294913,1364,272472,256,41341,16465,513]

theorem envBound10332 : H12AffineFastState.Bounded env10332 := by
  intro p hp
  have h : env10332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10331_10332 : H12AffineEnvironment.transform 21 272472 env10331 = env10332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272472 env10331 == env10332) = true)

theorem identity10332 : scanCanonicalize (H12AffineFastState.compose env10332 (packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10332 : packedSelected [0,1,2,4,5,6,7,8,9,14,24] rootPS < 2^1333 := by decide +kernel

def env10333 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,16400,262144,1024,32769,50449,264532,16,32851,268,64,2049,49217,36945,294913,1364,264532,256,32881,16465,513]

theorem envBound10333 : H12AffineFastState.Bounded env10333 := by
  intro p hp
  have h : env10333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10332_10333 : H12AffineEnvironment.transform 12 268 env10332 = env10333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10332 == env10333) = true)

theorem identity10333 : scanCanonicalize (H12AffineFastState.compose env10333 (packedSelected [2,6] rootPS)) = affineNative (2^(17+1) ^^^ 2420) := by decide +kernel

theorem selectedBound10333 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10334 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,32768,263,16400,2420,1024,32769,50449,32,16,32851,268,64,2049,49217,36945,35189,1364,32,256,32881,16465,513]

theorem envBound10334 : H12AffineFastState.Bounded env10334 := by
  intro p hp
  have h : env10334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10333_10334 : H12AffineEnvironment.transform 17 2420 env10333 = env10334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env10333 == env10334) = true)

theorem identity10334 : scanCanonicalize (H12AffineFastState.compose env10334 (packedSelected [3,5,8,18,23,28] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10334 : packedSelected [3,5,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env10335 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,0,263,16400,2420,1024,1,17681,32,16,83,268,64,2049,16449,4177,2421,1364,32,256,113,16465,513]

theorem envBound10335 : H12AffineFastState.Bounded env10335 := by
  intro p hp
  have h : env10335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10334_10335 : H12AffineEnvironment.transform 14 0 env10334 = env10335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10334 == env10335) = true)

theorem identity10335 : scanCanonicalize (H12AffineFastState.compose env10335 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 4453) := by decide +kernel

theorem selectedBound10335 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10336 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,4453,0,263,4469,2420,1024,1,5236,32,16,83,268,64,2049,4388,4177,2421,1364,32,256,113,4404,513]

theorem envBound10336 : H12AffineFastState.Bounded env10336 := by
  intro p hp
  have h : env10336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10335_10336 : H12AffineEnvironment.transform 13 4453 env10335 = env10336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4453 env10335 == env10336) = true)

theorem identity10336 : scanCanonicalize (H12AffineFastState.compose env10336 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound10336 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env10337 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,4096,268,4453,0,263,4469,2420,320,1,4404,32,16,83,268,64,2049,4388,4177,2421,20,32,256,113,4404,513]

theorem envBound10337 : H12AffineFastState.Bounded env10337 := by
  intro p hp
  have h : env10337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10336_10337 : H12AffineEnvironment.transform 9 320 env10336 = env10337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env10336 == env10337) = true)

theorem identity10337 : scanCanonicalize (H12AffineFastState.compose env10337 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10337 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env10338 : List Nat := [2,4,8,16,32,64,8,36,512,100,2048,4096,40,4161,0,35,4177,2128,100,1,4112,32,16,83,40,64,2049,4096,4177,2129,20,32,36,113,4112,513]

theorem envBound10338 : H12AffineFastState.Bounded env10338 := by
  intro p hp
  have h : env10338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10337_10338 : H12AffineEnvironment.transform 7 36 env10337 = env10338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10337 == env10338) = true)

def env10339 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,17,41310,8192,64,4530527,2172250,2118977,294913,75103,6407191,256,2188651,2196551,513]

theorem envBound10339 : H12AffineFastState.Bounded env10339 := by
  intro p hp
  have h : env10339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10320_10339 : H12AffineEnvironment.transform 16 16401 env10320 = env10339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10320 == env10339) = true)

theorem identity10339 : scanCanonicalize (H12AffineFastState.compose env10339 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound10339 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10340 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,2097152,4194304,17,41310,8192,64,4456789,2098512,2118977,294913,1365,6349853,256,2114913,2139213,513]

theorem envBound10340 : H12AffineFastState.Bounded env10340 := by
  intro p hp
  have h : env10340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10339_10340 : H12AffineEnvironment.transform 15 8202 env10339 = env10340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env10339 == env10340) = true)

theorem identity10340 : scanCanonicalize (H12AffineFastState.compose env10340 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound10340 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10341 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,16401,262144,1024,32769,2097152,32,17,41310,8192,64,262517,2098512,2118977,294913,1365,2155581,256,2114913,2139213,513]

theorem envBound10341 : H12AffineFastState.Bounded env10341 := by
  intro p hp
  have h : env10341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10340_10341 : H12AffineEnvironment.transform 21 32 env10340 = env10341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env10340 == env10341) = true)

theorem identity10341 : scanCanonicalize (H12AffineFastState.compose env10341 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound10341 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env10342 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1024,8540,2097152,32,17,3,8192,64,262517,2098512,2118977,270684,1365,2114912,256,2114913,2098448,513]

theorem envBound10342 : H12AffineFastState.Bounded env10342 := by
  intro p hp
  have h : env10342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10341_10342 : H12AffineEnvironment.transform 14 8541 env10341 = env10342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env10341 == env10342) = true)

theorem identity10342 : scanCanonicalize (H12AffineFastState.compose env10342 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 281700) := by decide +kernel

theorem selectedBound10342 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10343 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,262144,1024,8540,281700,32,17,3,8192,64,262517,280884,268581,270684,1365,264452,256,264453,280948,513]

theorem envBound10343 : H12AffineFastState.Bounded env10343 := by
  intro p hp
  have h : env10343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10342_10343 : H12AffineEnvironment.transform 20 281700 env10342 = env10343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 281700 env10342 == env10343) = true)

theorem identity10343 : scanCanonicalize (H12AffineFastState.compose env10343 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10343 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10344 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8202,16401,10280,1024,8540,25676,32,17,3,8192,64,10589,24860,12557,2420,1365,8492,256,8493,24924,513]

theorem envBound10344 : H12AffineFastState.Bounded env10344 := by
  intro p hp
  have h : env10344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10343_10344 : H12AffineEnvironment.transform 17 10280 env10343 = env10344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10343 == env10344) = true)

theorem identity10344 : scanCanonicalize (H12AffineFastState.compose env10344 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1336) := by decide +kernel

theorem selectedBound10344 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10345 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1336,16384,1125,1330,16401,3344,1024,1124,16756,32,17,3,1336,64,3173,17444,5173,2420,1365,1044,256,1045,17508,513]

theorem envBound10345 : H12AffineFastState.Bounded env10345 := by
  intro p hp
  have h : env10345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10344_10345 : H12AffineEnvironment.transform 12 1336 env10344 = env10345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1336 env10344 == env10345) = true)

theorem identity10345 : scanCanonicalize (H12AffineFastState.compose env10345 (packedSelected [0,2,7] rootPS)) = affineNative (2^(11+1) ^^^ 3408) := by decide +kernel

theorem selectedBound10345 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10346 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3408,1336,16384,1125,1330,16401,3344,1024,1124,16756,32,17,3,1336,64,3173,17444,2405,2420,1365,1044,256,1045,17508,513]

theorem envBound10346 : H12AffineFastState.Bounded env10346 := by
  intro p hp
  have h : env10346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10345_10346 : H12AffineEnvironment.transform 11 3408 env10345 = env10346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3408 env10345 == env10346) = true)

theorem identity10346 : scanCanonicalize (H12AffineFastState.compose env10346 (packedSelected [4,9] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound10346 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env10347 : List Nat := [2,4,8,16,32,64,8,256,512,53,2048,2405,269,16384,80,263,16401,2341,53,81,16756,32,17,3,269,64,2128,16401,2405,2420,352,33,256,32,16465,513]

theorem envBound10347 : H12AffineFastState.Bounded env10347 := by
  intro p hp
  have h : env10347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10346_10347 : H12AffineEnvironment.transform 9 53 env10346 = env10347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env10346 == env10347) = true)

theorem identity10347 : scanCanonicalize (H12AffineFastState.compose env10347 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound10347 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10348 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,2065,121,16384,80,115,16401,2129,53,81,16384,32,17,3,121,64,2128,16401,2065,2048,20,33,116,32,16465,513]

theorem envBound10348 : H12AffineFastState.Bounded env10348 := by
  intro p hp
  have h : env10348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10347_10348 : H12AffineEnvironment.transform 7 116 env10347 = env10348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env10347 == env10348) = true)

theorem identity10348 : scanCanonicalize (H12AffineFastState.compose env10348 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound10348 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10349 : List Nat := [2,4,8,16,32,64,8,116,512,53,2048,2065,121,1,80,115,16,2129,53,81,1,32,17,3,121,64,2128,16,2065,2048,20,33,116,32,80,513]

theorem envBound10349 : H12AffineFastState.Bounded env10349 := by
  intro p hp
  have h : env10349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10348_10349 : H12AffineEnvironment.transform 13 1 env10348 = env10349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env10348 == env10349) = true)

theorem identity10349 : scanCanonicalize (H12AffineFastState.compose env10349 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10349 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env10350 : List Nat := [2,4,8,16,32,64,8,116,512,53,0,17,121,1,80,115,16,81,53,81,1,32,17,3,121,64,80,16,17,0,20,33,116,32,80,513]

theorem envBound10350 : H12AffineFastState.Bounded env10350 := by
  intro p hp
  have h : env10350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10349_10350 : H12AffineEnvironment.transform 10 0 env10349 = env10350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10349 == env10350) = true)

def env10351 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147457,16777216,8192,64,21331968,18973700,2233681,294912,17024017,23160137,256,19104805,19096841,16966479]

theorem envBound10351 : H12AffineFastState.Bounded env10351 := by
  intro p hp
  have h : env10351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10318_10351 : H12AffineEnvironment.transform 22 147457 env10318 = env10351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147457 env10318 == env10351) = true)

def env10352 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,17,16777216,8192,64,21331968,18973700,2118977,294912,16876545,23160137,256,18990133,18949401,16819039]

theorem envBound10352 : H12AffineFastState.Bounded env10352 := by
  intro p hp
  have h : env10352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10351_10352 : H12AffineEnvironment.transform 16 16400 env10351 = env10352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env10351 == env10352) = true)

theorem identity10352 : scanCanonicalize (H12AffineFastState.compose env10352 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 297334) := by decide +kernel

theorem selectedBound10352 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10353 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1024,32769,2097152,4194304,17,297334,8192,64,4262262,2428274,2118977,294912,331127,6679615,256,2444611,2468975,272937]

theorem envBound10353 : H12AffineFastState.Bounded env10353 := by
  intro p hp
  have h : env10353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10352_10353 : H12AffineEnvironment.transform 23 297334 env10352 = env10353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 297334 env10352 == env10353) = true)

def env10354 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1024,32769,2097152,4194304,17,41310,8192,64,4262262,2172250,2118977,43048,75103,6407191,256,2188651,2196551,513]

theorem envBound10354 : H12AffineFastState.Bounded env10354 := by
  intro p hp
  have h : env10354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10353_10354 : H12AffineEnvironment.transform 17 10280 env10353 = env10354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10353 == env10354) = true)

theorem identity10354 : scanCanonicalize (H12AffineFastState.compose env10354 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10354 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10355 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,2097152,4194304,17,41310,8192,64,4204925,2098513,2118977,43048,1364,6349852,256,2114912,2139212,513]

theorem envBound10355 : H12AffineFastState.Bounded env10355 := by
  intro p hp
  have h : env10355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10354_10355 : H12AffineEnvironment.transform 15 8203 env10354 = env10355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10354 == env10355) = true)

theorem identity10355 : scanCanonicalize (H12AffineFastState.compose env10355 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 2155581) := by decide +kernel

theorem selectedBound10355 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10356 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,2097152,2155581,17,41310,8192,64,2149696,2098513,2118977,43048,1364,33,256,2114912,2139212,513]

theorem envBound10356 : H12AffineFastState.Bounded env10356 := by
  intro p hp
  have h : env10356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10355_10356 : H12AffineEnvironment.transform 21 2155581 env10355 = env10356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2155581 env10355 == env10356) = true)

theorem identity10356 : scanCanonicalize (H12AffineFastState.compose env10356 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10356 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10357 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,2097152,2155581,17,41231,8192,17,2149649,2098432,2118928,43048,1285,33,256,2114865,2139165,513]

theorem envBound10357 : H12AffineFastState.Bounded env10357 := by
  intro p hp
  have h : env10357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10356_10357 : H12AffineEnvironment.transform 5 17 env10356 = env10357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10356 == env10357) = true)

theorem identity10357 : scanCanonicalize (H12AffineFastState.compose env10357 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 25628) := by decide +kernel

theorem selectedBound10357 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env10358 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,8203,16400,10280,1024,32769,25628,32801,17,41231,8192,17,43277,24860,12556,43048,1285,33,256,8493,49153,513]

theorem envBound10358 : H12AffineFastState.Bounded env10358 := by
  intro p hp
  have h : env10358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10357_10358 : H12AffineEnvironment.transform 20 25628 env10357 = env10358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25628 env10357 == env10358) = true)

theorem identity10358 : scanCanonicalize (H12AffineFastState.compose env10358 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10358 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10359 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,262,16400,2341,1024,32769,17681,32801,17,32770,269,17,34816,16401,4097,35109,1285,33,256,32,49153,513]

theorem envBound10359 : H12AffineFastState.Bounded env10359 := by
  intro p hp
  have h : env10359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10358_10359 : H12AffineEnvironment.transform 12 269 env10358 = env10359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10358 == env10359) = true)

def env10360 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,2097152,4194304,17,41311,8192,64,4262262,2172251,2118977,43049,75102,6407190,256,2188650,2196550,512]

theorem envBound10360 : H12AffineFastState.Bounded env10360 := by
  intro p hp
  have h : env10360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10353_10360 : H12AffineEnvironment.transform 17 10281 env10353 = env10360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10353 == env10360) = true)

theorem identity10360 : scanCanonicalize (H12AffineFastState.compose env10360 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 58729) := by decide +kernel

theorem selectedBound10360 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10361 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,58729,4194304,17,41311,8192,64,4262262,114738,45096,43049,75102,4268415,256,98307,90415,512]

theorem envBound10361 : H12AffineFastState.Bounded env10361 := by
  intro p hp
  have h : env10361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10360_10361 : H12AffineEnvironment.transform 20 58729 env10360 = env10361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58729 env10360 == env10361) = true)

theorem identity10361 : scanCanonicalize (H12AffineFastState.compose env10361 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound10361 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env10362 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1024,32769,58729,41341,17,41311,8192,64,108555,114738,45096,43049,75102,98306,256,98307,90415,512]

theorem envBound10362 : H12AffineFastState.Bounded env10362 := by
  intro p hp
  have h : env10362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10361_10362 : H12AffineEnvironment.transform 21 41341 env10361 = env10362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env10361 == env10362) = true)

theorem identity10362 : scanCanonicalize (H12AffineFastState.compose env10362 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(15+1) ^^^ 62843) := by decide +kernel

theorem selectedBound10362 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10363 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62843,16400,10281,1024,32769,58729,41341,17,41311,8192,64,23920,13641,45096,43049,53285,30073,256,30072,37972,512]

theorem envBound10363 : H12AffineFastState.Bounded env10363 := by
  intro p hp
  have h : env10363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10362_10363 : H12AffineEnvironment.transform 15 62843 env10362 = env10363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62843 env10362 == env10363) = true)

theorem identity10363 : scanCanonicalize (H12AffineFastState.compose env10363 (packedSelected [0,7,9,14,20,22] rootPS)) = affineNative (2^(14+1) ^^^ 21873) := by decide +kernel

theorem selectedBound10363 : packedSelected [0,7,9,14,20,22] rootPS < 2^1333 := by decide +kernel

def env10364 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21873,8202,16400,10281,1024,21872,12312,29708,17,29742,8192,64,23920,13641,25945,32088,1364,30073,256,30072,16677,512]

theorem envBound10364 : H12AffineFastState.Bounded env10364 := by
  intro p hp
  have h : env10364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10363_10364 : H12AffineEnvironment.transform 14 21873 env10363 = env10364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21873 env10363 == env10364) = true)

theorem identity10364 : scanCanonicalize (H12AffineFastState.compose env10364 (packedSelected [0,2,3,5,7,10,11] rootPS)) = affineNative (2^(13+1) ^^^ 3424) := by decide +kernel

theorem selectedBound10364 : packedSelected [0,2,3,5,7,10,11] rootPS < 2^1333 := by decide +kernel

def env10365 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,3424,6161,8202,3440,10281,1024,6160,12312,14700,17,14670,8192,64,4112,13641,10297,12344,1364,14361,256,14360,3141,512]

theorem envBound10365 : H12AffineFastState.Bounded env10365 := by
  intro p hp
  have h : env10365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10364_10365 : H12AffineEnvironment.transform 13 3424 env10364 = env10365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3424 env10364 == env10365) = true)

theorem identity10365 : scanCanonicalize (H12AffineFastState.compose env10365 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(11+1) ^^^ 3409) := by decide +kernel

theorem selectedBound10365 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env10366 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3409,8192,3424,1344,8202,3440,10281,1024,1345,11593,9277,17,9247,8192,64,3393,10264,10297,11625,1364,9544,256,9545,3141,512]

theorem envBound10366 : H12AffineFastState.Bounded env10366 := by
  intro p hp
  have h : env10366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10365_10366 : H12AffineEnvironment.transform 11 3409 env10365 = env10366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3409 env10365 == env10366) = true)

theorem identity10366 : scanCanonicalize (H12AffineFastState.compose env10366 (packedSelected [12,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10366 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env10367 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,3409,8192,3392,1344,8202,3408,10249,1024,1345,11593,9245,17,9247,8192,64,3393,10264,10265,11593,1364,9544,256,9545,3141,512]

theorem envBound10367 : H12AffineFastState.Bounded env10367 := by
  intro p hp
  have h : env10367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10366_10367 : H12AffineEnvironment.transform 4 0 env10366 = env10367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10366 == env10367) = true)

theorem identity10367 : scanCanonicalize (H12AffineFastState.compose env10367 (packedSelected [0,3,7,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound10367 : packedSelected [0,3,7,8,10] rootPS < 2^1333 := by decide +kernel

def env10368 : List Nat := [2,4,8,16,0,64,8,84,512,1024,2048,3077,8192,3092,1044,8202,3076,10249,1024,1045,11293,9245,17,9247,8192,64,3093,10264,10265,11293,1024,9244,84,9245,3141,512]

theorem envBound10368 : H12AffineFastState.Bounded env10368 := by
  intro p hp
  have h : env10368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10367_10368 : H12AffineEnvironment.transform 7 84 env10367 = env10368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env10367 == env10368) = true)

theorem identity10368 : scanCanonicalize (H12AffineFastState.compose env10368 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound10368 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env10369 : List Nat := [2,4,8,16,0,64,8,84,512,1024,1093,64,8192,81,1044,8202,65,9292,1024,1045,8280,9245,17,9247,8192,64,80,9309,9308,8280,1024,9244,84,9245,0,512]

theorem envBound10369 : H12AffineFastState.Bounded env10369 := by
  intro p hp
  have h : env10369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10368_10369 : H12AffineEnvironment.transform 10 1093 env10368 = env10369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env10368 == env10369) = true)

theorem identity10369 : scanCanonicalize (H12AffineFastState.compose env10369 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound10369 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env10370 : List Nat := [2,4,8,16,0,64,8,84,512,69,0,64,8192,81,81,8202,65,8201,69,80,8280,8280,17,8282,8192,64,80,8216,8217,8280,69,8281,84,8280,0,512]

theorem envBound10370 : H12AffineFastState.Bounded env10370 := by
  intro p hp
  have h : env10370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10369_10370 : H12AffineEnvironment.transform 9 69 env10369 = env10370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env10369 == env10370) = true)

theorem identity10370 : scanCanonicalize (H12AffineFastState.compose env10370 (packedSelected [1,2,3] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound10370 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10371 : List Nat := [2,4,8,16,0,64,8,84,512,69,0,64,89,81,81,83,65,80,69,80,1,1,17,3,89,64,80,65,64,1,69,0,84,1,0,512]

theorem envBound10371 : H12AffineFastState.Bounded env10371 := by
  intro p hp
  have h : env10371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10370_10371 : H12AffineEnvironment.transform 12 89 env10370 = env10371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env10370 == env10371) = true)

theorem identity10371 : scanCanonicalize (H12AffineFastState.compose env10371 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10371 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10372 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,17,8,0,0,2,16,1,20,1,1,1,17,3,8,17,1,16,17,1,20,0,5,1,0,512]

theorem envBound10372 : H12AffineFastState.Bounded env10372 := by
  intro p hp
  have h : env10372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10371_10372 : H12AffineEnvironment.transform 5 17 env10371 = env10372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10371 == env10372) = true)

theorem identity10372 : scanCanonicalize (H12AffineFastState.compose env10372 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound10372 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10373 : List Nat := [2,1,8,16,0,17,8,0,512,17,0,17,8,0,0,2,16,1,17,1,1,1,17,3,8,17,1,16,17,1,17,0,0,1,0,512]

theorem envBound10373 : H12AffineFastState.Bounded env10373 := by
  intro p hp
  have h : env10373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10372_10373 : H12AffineEnvironment.transform 1 1 env10372 = env10373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env10372 == env10373) = true)

def env10374 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,16777216,8192,64,21331968,18973700,2118976,294912,16876544,23160137,256,18990132,18949400,16819038]

theorem envBound10374 : H12AffineFastState.Bounded env10374 := by
  intro p hp
  have h : env10374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10351_10374 : H12AffineEnvironment.transform 16 16401 env10351 = env10374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env10351 == env10374) = true)

theorem identity10374 : scanCanonicalize (H12AffineFastState.compose env10374 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41311) := by decide +kernel

theorem selectedBound10374 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env10375 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,2097152,4194304,16,41311,8192,64,4530527,2172251,2118976,294912,75103,6407190,256,2188651,2196551,513]

theorem envBound10375 : H12AffineFastState.Bounded env10375 := by
  intro p hp
  have h : env10375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10374_10375 : H12AffineEnvironment.transform 23 41311 env10374 = env10375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41311 env10374 == env10375) = true)

theorem identity10375 : scanCanonicalize (H12AffineFastState.compose env10375 (packedSelected [3,10,17,24,26] rootPS)) = affineNative (2^(20+1) ^^^ 115734) := by decide +kernel

theorem selectedBound10375 : packedSelected [3,10,17,24,26] rootPS < 2^1333 := by decide +kernel

def env10376 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1024,32769,115734,4194304,16,41311,8192,64,4530527,57677,102742,294912,75103,4194304,256,41341,16465,513]

theorem envBound10376 : H12AffineFastState.Bounded env10376 := by
  intro p hp
  have h : env10376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10375_10376 : H12AffineEnvironment.transform 20 115734 env10375 = env10376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115734 env10375 == env10376) = true)

theorem identity10376 : scanCanonicalize (H12AffineFastState.compose env10376 (packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10376 : packedSelected [1,3,5,8,10,12,15,19,38,41] rootPS < 2^1333 := by decide +kernel

def env10377 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115734,4194304,16,41311,8192,64,4262263,57677,102742,43048,75103,4194304,256,41341,16465,513]

theorem envBound10377 : H12AffineFastState.Bounded env10377 := by
  intro p hp
  have h : env10377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10376_10377 : H12AffineEnvironment.transform 17 10280 env10376 = env10377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10376 == env10377) = true)

theorem identity10377 : scanCanonicalize (H12AffineFastState.compose env10377 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound10377 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env10378 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10280,1024,32769,115734,113,16,41311,8192,64,67846,57677,102742,43048,75103,113,256,41341,16465,513]

theorem envBound10378 : H12AffineFastState.Bounded env10378 := by
  intro p hp
  have h : env10378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10377_10378 : H12AffineEnvironment.transform 21 113 env10377 = env10378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env10377 == env10378) = true)

theorem identity10378 : scanCanonicalize (H12AffineFastState.compose env10378 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound10378 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10379 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,65536,16401,10280,1024,80,83015,113,16,8462,8192,64,67846,24860,69895,10361,75103,113,256,8492,16465,513]

theorem envBound10379 : H12AffineFastState.Bounded env10379 := by
  intro p hp
  have h : env10379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10378_10379 : H12AffineEnvironment.transform 14 81 env10378 = env10379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env10378 == env10379) = true)

theorem identity10379 : scanCanonicalize (H12AffineFastState.compose env10379 (packedSelected [1,2,6,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 8283) := by decide +kernel

theorem selectedBound10379 : packedSelected [1,2,6,8,10,15] rootPS < 2^1333 := by decide +kernel

def env10380 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,81,8283,16401,10280,1024,80,25628,113,16,8462,8192,64,10589,24860,12636,10361,1284,113,256,8492,16465,513]

theorem envBound10380 : H12AffineFastState.Bounded env10380 := by
  intro p hp
  have h : env10380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10379_10380 : H12AffineEnvironment.transform 15 8283 env10379 = env10380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8283 env10379 == env10380) = true)

theorem identity10380 : scanCanonicalize (H12AffineFastState.compose env10380 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10380 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10381 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,81,263,16401,2420,1024,80,17728,113,16,82,348,64,2049,16448,4096,2341,1284,113,256,112,16465,513]

theorem envBound10381 : H12AffineFastState.Bounded env10381 := by
  intro p hp
  have h : env10381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10380_10381 : H12AffineEnvironment.transform 12 348 env10380 = env10381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10380 == env10381) = true)

def env10382 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160257,257,27378861,27337992,25207751]

theorem envBound10382 : H12AffineFastState.Bounded env10382 := by
  intro p hp
  have h : env10382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10316_10382 : H12AffineEnvironment.transform 18 1025 env10316 = env10382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env10316 == env10382) = true)

theorem identity10382 : scanCanonicalize (H12AffineFastState.compose env10382 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8642568) := by decide +kernel

theorem selectedBound10382 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env10383 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,8642568,8328,64,4464648,10642565,10507600,8830976,156696,14845385,257,2237605,2278656,213967]

theorem envBound10383 : H12AffineFastState.Bounded env10383 := by
  intro p hp
  have h : env10383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10382_10383 : H12AffineEnvironment.transform 23 8642568 env10382 = env10383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8642568 env10382 == env10383) = true)

def env10384 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,8388608,8642568,8328,64,4464648,8393985,8529108,8830976,156696,12645453,257,21793,46212,213967]

theorem envBound10384 : H12AffineFastState.Bounded env10384 := by
  intro p hp
  have h : env10384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10383_10384 : H12AffineEnvironment.transform 20 160132 env10383 = env10384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 160132 env10383 == env10384) = true)

def env10385 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169216,95496,8328,64,4464648,163841,45524,283904,156696,4350285,257,21793,46212,213967]

theorem envBound10385 : H12AffineFastState.Bounded env10385 := by
  intro p hp
  have h : env10385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10384_10385 : H12AffineEnvironment.transform 22 169216 env10384 = env10385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169216 env10384 == env10385) = true)

def env10386 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169216,95496,8328,64,2184,163841,45524,283904,156696,412109,257,21793,46212,213967]

theorem envBound10386 : H12AffineFastState.Bounded env10386 := by
  intro p hp
  have h : env10386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10385_10386 : H12AffineEnvironment.transform 21 272512 env10385 = env10386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10385 == env10386) = true)

theorem identity10386 : scanCanonicalize (H12AffineFastState.compose env10386 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound10386 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10387 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,262144,1025,32769,115870,272512,73754,95496,8328,64,2184,79131,45524,283904,119042,392407,257,21793,46212,63189]

theorem envBound10387 : H12AffineFastState.Bounded env10387 := by
  intro p hp
  have h : env10387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10386_10387 : H12AffineEnvironment.transform 16 111898 env10386 = env10387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env10386 == env10387) = true)

def env10388 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10400,1025,32769,115870,32,73754,95496,8328,64,2184,79131,45524,32160,119042,119927,257,21793,46212,63189]

theorem envBound10388 : H12AffineFastState.Bounded env10388 := by
  intro p hp
  have h : env10388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10387_10388 : H12AffineEnvironment.transform 17 10400 env10387 = env10388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env10387 == env10388) = true)

theorem identity10388 : scanCanonicalize (H12AffineFastState.compose env10388 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound10388 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10389 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,13388,10400,1025,32769,17864,32,41292,62558,8328,64,2184,46157,45524,32160,20564,21793,257,21793,46212,63189]

theorem envBound10389 : H12AffineFastState.Bounded env10389 := by
  intro p hp
  have h : env10389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10388_10389 : H12AffineEnvironment.transform 15 33110 env10388 = env10389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env10388 == env10389) = true)

theorem identity10389 : scanCanonicalize (H12AffineFastState.compose env10389 (packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5372) := by decide +kernel

theorem selectedBound10389 : packedSelected [0,2,3,5,6,10,11,12,14,15,17,23,27] rootPS < 2^1333 := by decide +kernel

def env10390 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5372,32768,33110,13388,10400,1025,32769,4404,32,41292,41122,8328,64,2184,46157,45524,10588,1192,477,257,477,46212,41513]

theorem envBound10390 : H12AffineFastState.Bounded env10390 := by
  intro p hp
  have h : env10390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10389_10390 : H12AffineEnvironment.transform 13 5372 env10389 = env10390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5372 env10389 == env10390) = true)

theorem identity10390 : scanCanonicalize (H12AffineFastState.compose env10390 (packedSelected [1,3,8,10,12,15,17,18,19,23,24,26] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10390 : packedSelected [1,3,8,10,12,15,17,18,19,23,24,26] rootPS < 2^1333 := by decide +kernel

def env10391 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,32768,32803,13388,10400,1025,32769,4161,32,41017,41122,8328,64,2184,46157,45217,10281,1192,168,116,168,46212,41513]

theorem envBound10391 : H12AffineFastState.Bounded env10391 := by
  intro p hp
  have h : env10391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10390_10391 : H12AffineEnvironment.transform 7 117 env10390 = env10391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10390 == env10391) = true)

theorem identity10391 : scanCanonicalize (H12AffineFastState.compose env10391 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 8232) := by decide +kernel

theorem selectedBound10391 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10392 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,8192,5372,8232,8203,13388,10400,1025,8233,4161,32,17,138,8328,64,2184,5221,4233,10281,1192,168,116,168,5292,513]

theorem envBound10392 : H12AffineFastState.Bounded env10392 := by
  intro p hp
  have h : env10392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10391_10392 : H12AffineEnvironment.transform 14 8232 env10391 = env10392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8232 env10391 == env10392) = true)

theorem identity10392 : scanCanonicalize (H12AffineFastState.compose env10392 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound10392 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env10393 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,8192,5204,8232,8203,13388,10248,1025,8233,4161,32,17,34,8224,64,2080,5221,4129,10281,1024,0,116,0,5124,513]

theorem envBound10393 : H12AffineFastState.Bounded env10393 := by
  intro p hp
  have h : env10393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10392_10393 : H12AffineEnvironment.transform 6 40 env10392 = env10393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env10392 == env10393) = true)

theorem identity10393 : scanCanonicalize (H12AffineFastState.compose env10393 (packedSelected [3,5,6,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 1133) := by decide +kernel

theorem selectedBound10393 : packedSelected [3,5,6,10,14] rootPS < 2^1333 := by decide +kernel

def env10394 : List Nat := [2,4,8,16,32,64,40,117,512,1024,2048,4096,1133,5204,1093,1126,4129,3173,1025,1092,4161,32,17,34,1101,64,2080,5221,4129,3140,1024,0,116,0,5124,513]

theorem envBound10394 : H12AffineFastState.Bounded env10394 := by
  intro p hp
  have h : env10394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10393_10394 : H12AffineEnvironment.transform 12 1133 env10393 = env10394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1133 env10393 == env10394) = true)

theorem identity10394 : scanCanonicalize (H12AffineFastState.compose env10394 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound10394 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10395 : List Nat := [2,4,8,16,32,64,40,117,512,69,2048,4096,40,4113,0,35,4129,2080,68,1,4161,32,17,34,8,64,2080,4128,4129,2049,69,0,116,0,4161,513]

theorem envBound10395 : H12AffineFastState.Bounded env10395 := by
  intro p hp
  have h : env10395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10394_10395 : H12AffineEnvironment.transform 9 69 env10394 = env10395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env10394 == env10395) = true)

theorem identity10395 : scanCanonicalize (H12AffineFastState.compose env10395 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10395 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10396 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,4096,8,4113,0,3,4097,2048,68,1,4161,0,17,2,8,64,2048,4096,4097,2049,69,0,84,0,4161,513]

theorem envBound10396 : H12AffineFastState.Bounded env10396 := by
  intro p hp
  have h : env10396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10395_10396 : H12AffineEnvironment.transform 4 0 env10395 = env10396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10395 == env10396) = true)

theorem identity10396 : scanCanonicalize (H12AffineFastState.compose env10396 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound10396 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10397 : List Nat := [2,4,8,16,0,64,8,85,512,69,2048,65,8,80,0,3,64,2048,68,1,0,0,17,2,8,64,2048,65,64,2049,69,0,84,0,0,513]

theorem envBound10397 : H12AffineFastState.Bounded env10397 := by
  intro p hp
  have h : env10397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10396_10397 : H12AffineEnvironment.transform 11 65 env10396 = env10397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env10396 == env10397) = true)

theorem identity10397 : scanCanonicalize (H12AffineFastState.compose env10397 (packedSelected [0] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound10397 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10398 : List Nat := [2,4,8,16,0,0,8,21,512,5,2048,1,8,16,0,3,0,2048,4,1,0,0,17,2,8,0,2048,1,0,2049,5,0,20,0,0,513]

theorem envBound10398 : H12AffineFastState.Bounded env10398 := by
  intro p hp
  have h : env10398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10397_10398 : H12AffineEnvironment.transform 5 0 env10397 = env10398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env10397 == env10398) = true)

theorem identity10398 : scanCanonicalize (H12AffineFastState.compose env10398 (packedSelected [1,3] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound10398 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10399 : List Nat := [2,4,8,1,0,0,8,4,512,5,2048,1,8,1,0,3,0,2048,4,1,0,0,0,2,8,0,2048,1,0,2049,5,0,5,0,0,513]

theorem envBound10399 : H12AffineFastState.Bounded env10399 := by
  intro p hp
  have h : env10399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10398_10399 : H12AffineEnvironment.transform 3 1 env10398 = env10399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env10398 == env10399) = true)

theorem identity10399 : scanCanonicalize (H12AffineFastState.compose env10399 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound10399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10400 : List Nat := [2,4,2,1,0,0,2,4,512,5,2048,1,2,1,0,3,0,2048,4,1,0,0,0,2,2,0,2048,1,0,2049,5,0,5,0,0,513]

theorem envBound10400 : H12AffineFastState.Bounded env10400 := by
  intro p hp
  have h : env10400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10399_10400 : H12AffineEnvironment.transform 2 2 env10399 = env10400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env10399 == env10400) = true)

theorem identity10400 : scanCanonicalize (H12AffineFastState.compose env10400 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound10400 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10401 : List Nat := [2,4,2,1,0,0,2,4,512,5,512,1,2,1,0,3,0,512,4,1,0,0,0,2,2,0,512,1,0,513,5,0,5,0,0,513]

theorem envBound10401 : H12AffineFastState.Bounded env10401 := by
  intro p hp
  have h : env10401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10400_10401 : H12AffineEnvironment.transform 10 512 env10400 = env10401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env10400 == env10401) = true)

def env10402 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111898,10401,1025,32769,115870,33,73754,95496,8328,64,2184,79131,45524,32161,119042,119926,257,21793,46212,63189]

theorem envBound10402 : H12AffineFastState.Bounded env10402 := by
  intro p hp
  have h : env10402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10387_10402 : H12AffineEnvironment.transform 17 10401 env10387 = env10402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env10387 == env10402) = true)

theorem identity10402 : scanCanonicalize (H12AffineFastState.compose env10402 (packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10402 : packedSelected [1,3,10,11,16,18,19,20,23,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env10403 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10401,1025,32769,58517,33,17,21763,8328,64,2184,5392,45524,32161,61705,62589,257,21793,46212,63189]

theorem envBound10403 : H12AffineFastState.Bounded env10403 := by
  intro p hp
  have h : env10403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10402_10403 : H12AffineEnvironment.transform 15 8203 env10402 = env10403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10402 == env10403) = true)

theorem identity10403 : scanCanonicalize (H12AffineFastState.compose env10403 (packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound10403 : packedSelected [0,1,3,4,5,7,8,10,17,19,22] rootPS < 2^1333 := by decide +kernel

def env10404 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,38161,10280,1025,32769,58396,33,17,21763,8193,64,2049,5392,45405,32040,61705,62589,257,21793,46093,63068]

theorem envBound10404 : H12AffineFastState.Bounded env10404 := by
  intro p hp
  have h : env10404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10403_10404 : H12AffineEnvironment.transform 6 9 env10403 = env10404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10403 == env10404) = true)

theorem identity10404 : scanCanonicalize (H12AffineFastState.compose env10404 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound10404 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10405 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29789,8203,24908,10280,1025,29788,4161,33,17,21763,8193,64,2049,5392,17664,32040,1364,32,257,21793,16464,513]

theorem envBound10405 : H12AffineFastState.Bounded env10405 := by
  intro p hp
  have h : env10405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10404_10405 : H12AffineEnvironment.transform 14 29789 env10404 = env10405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env10404 == env10405) = true)

theorem identity10405 : scanCanonicalize (H12AffineFastState.compose env10405 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound10405 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10406 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21841,263,16448,2340,1025,21840,4161,33,17,21763,269,64,2049,5392,17664,23588,1364,32,257,21793,16464,513]

theorem envBound10406 : H12AffineFastState.Bounded env10406 := by
  intro p hp
  have h : env10406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10405_10406 : H12AffineEnvironment.transform 12 268 env10405 = env10406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env10405 == env10406) = true)

def env10407 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169216,95496,8328,64,2185,163841,45524,283904,156696,412108,257,21793,46212,213967]

theorem envBound10407 : H12AffineFastState.Bounded env10407 := by
  intro p hp
  have h : env10407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10385_10407 : H12AffineEnvironment.transform 21 272513 env10385 = env10407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10385 == env10407) = true)

theorem identity10407 : scanCanonicalize (H12AffineFastState.compose env10407 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound10407 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10408 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160132,272513,169216,21763,8328,64,2185,163841,45524,283904,156696,412108,257,21793,46212,156612]

theorem envBound10408 : H12AffineFastState.Bounded env10408 := by
  intro p hp
  have h : env10408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10407_10408 : H12AffineEnvironment.transform 15 8203 env10407 = env10408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env10407 == env10408) = true)

def env10409 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160012,272393,169216,21763,8192,64,2049,163841,45404,283904,156696,411972,257,21793,46092,156492]

theorem envBound10409 : H12AffineFastState.Bounded env10409 := by
  intro p hp
  have h : env10409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10408_10409 : H12AffineEnvironment.transform 6 8 env10408 = env10409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10408 == env10409) = true)

theorem identity10409 : scanCanonicalize (H12AffineFastState.compose env10409 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 29993) := by decide +kernel

theorem selectedBound10409 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env10410 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8203,131072,262144,1025,29992,160012,272393,155689,21763,8192,64,2049,161064,17525,283904,156696,411972,257,21793,16677,156492]

theorem envBound10410 : H12AffineFastState.Bounded env10410 := by
  intro p hp
  have h : env10410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10409_10410 : H12AffineEnvironment.transform 14 29993 env10409 = env10410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29993 env10409 == env10410) = true)

theorem identity10410 : scanCanonicalize (H12AffineFastState.compose env10410 (packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound10410 : packedSelected [0,1,2,5,6,7,8,17,19,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env10411 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29993,8203,5221,262144,1025,29992,25961,272393,29772,21763,8192,64,2049,24909,17525,283904,28797,285985,257,21793,16677,30505]

theorem envBound10411 : H12AffineFastState.Bounded env10411 := by
  intro p hp
  have h : env10411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10410_10411 : H12AffineEnvironment.transform 16 5221 env10410 = env10411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env10410 == env10411) = true)

theorem identity10411 : scanCanonicalize (H12AffineFastState.compose env10411 (packedSelected [0,2,6,7,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound10411 : packedSelected [0,2,6,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env10412 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8233,8203,5221,262144,1025,8232,12393,272393,8524,3,8192,64,2049,13389,4469,262144,9597,264225,257,33,5157,8745]

theorem envBound10412 : H12AffineFastState.Bounded env10412 := by
  intro p hp
  have h : env10412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10411_10412 : H12AffineEnvironment.transform 13 5376 env10411 = env10412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env10411 == env10412) = true)

theorem identity10412 : scanCanonicalize (H12AffineFastState.compose env10412 (packedSelected [2,6,16] rootPS)) = affineNative (2^(17+1) ^^^ 9292) := by decide +kernel

theorem selectedBound10412 : packedSelected [2,6,16] rootPS < 2^1333 := by decide +kernel

def env10413 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8233,8203,5221,9292,1025,8232,12393,3141,8524,3,8192,64,2049,13389,4469,9292,9597,11373,257,33,5157,8745]

theorem envBound10413 : H12AffineFastState.Bounded env10413 := by
  intro p hp
  have h : env10413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10412_10413 : H12AffineEnvironment.transform 17 9292 env10412 = env10413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 9292 env10412 == env10413) = true)

theorem identity10413 : scanCanonicalize (H12AffineFastState.compose env10413 (packedSelected [4,6,9,11,18] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10413 : packedSelected [4,6,9,11,18] rootPS < 2^1333 := by decide +kernel

def env10414 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5376,373,343,5221,1296,1025,372,4405,3141,16,3,348,64,2049,5393,4469,1296,1057,3377,257,33,5157,885]

theorem envBound10414 : H12AffineFastState.Bounded env10414 := by
  intro p hp
  have h : env10414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10413_10414 : H12AffineEnvironment.transform 12 348 env10413 = env10414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10413 == env10414) = true)

theorem identity10414 : scanCanonicalize (H12AffineFastState.compose env10414 (packedSelected [1,2,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1376) := by decide +kernel

theorem selectedBound10414 : packedSelected [1,2,6,8,11] rootPS < 2^1333 := by decide +kernel

def env10415 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1376,4096,348,5376,373,343,5221,1296,1025,372,4405,293,16,3,348,64,1377,5393,4469,1296,1057,81,257,33,5157,885]

theorem envBound10415 : H12AffineFastState.Bounded env10415 := by
  intro p hp
  have h : env10415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10414_10415 : H12AffineEnvironment.transform 10 1376 env10414 = env10415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1376 env10414 == env10415) = true)

theorem identity10415 : scanCanonicalize (H12AffineFastState.compose env10415 (packedSelected [0,1,3,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 1883) := by decide +kernel

theorem selectedBound10415 : packedSelected [0,1,3,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10416 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1376,1883,348,603,373,343,830,1296,1025,372,1646,293,16,3,348,64,1377,586,1582,1296,1057,81,257,33,894,885]

theorem envBound10416 : H12AffineFastState.Bounded env10416 := by
  intro p hp
  have h : env10416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10415_10416 : H12AffineEnvironment.transform 11 1883 env10415 = env10416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1883 env10415 == env10416) = true)

theorem identity10416 : scanCanonicalize (H12AffineFastState.compose env10416 (packedSelected [0,2,7,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound10416 : packedSelected [0,2,7,14] rootPS < 2^1333 := by decide +kernel

def env10417 : List Nat := [2,4,8,16,32,64,8,5,512,1024,1125,1630,89,603,112,82,571,1045,1025,113,1646,32,16,3,89,64,1124,586,1582,1045,1057,81,4,33,635,624]

theorem envBound10417 : H12AffineFastState.Bounded env10417 := by
  intro p hp
  have h : env10417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10416_10417 : H12AffineEnvironment.transform 7 5 env10416 = env10417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env10416 == env10417) = true)

theorem identity10417 : scanCanonicalize (H12AffineFastState.compose env10417 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound10417 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env10418 : List Nat := [2,4,8,16,32,48,8,5,512,1024,1045,1582,41,555,0,34,571,1045,1025,1,1566,32,16,3,41,48,1044,570,1582,1045,1057,33,4,33,523,512]

theorem envBound10418 : H12AffineFastState.Bounded env10418 := by
  intro p hp
  have h : env10418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10417_10418 : H12AffineEnvironment.transform 5 48 env10417 = env10418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env10417 == env10418) = true)

theorem identity10418 : scanCanonicalize (H12AffineFastState.compose env10418 (packedSelected [1,4] rootPS)) = affineNative (2^(8+1) ^^^ 34) := by decide +kernel

theorem selectedBound10418 : packedSelected [1,4] rootPS < 2^1333 := by decide +kernel

def env10419 : List Nat := [2,4,8,16,32,48,8,5,34,1024,1045,1036,41,9,0,34,25,1045,1025,1,1084,32,16,3,41,48,1044,24,1036,1045,1057,33,4,33,41,34]

theorem envBound10419 : H12AffineFastState.Bounded env10419 := by
  intro p hp
  have h : env10419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10418_10419 : H12AffineEnvironment.transform 8 34 env10418 = env10419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 34 env10418 == env10419) = true)

theorem identity10419 : scanCanonicalize (H12AffineFastState.compose env10419 (packedSelected [1,2,5] rootPS)) = affineNative (2^(9+1) ^^^ 28) := by decide +kernel

theorem selectedBound10419 : packedSelected [1,2,5] rootPS < 2^1333 := by decide +kernel

def env10420 : List Nat := [2,4,8,16,32,48,8,5,34,28,9,16,41,9,0,34,25,9,29,1,32,32,16,3,41,48,8,24,16,9,61,33,4,33,41,34]

theorem envBound10420 : H12AffineFastState.Bounded env10420 := by
  intro p hp
  have h : env10420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10419_10420 : H12AffineEnvironment.transform 9 28 env10419 = env10420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 28 env10419 == env10420) = true)

theorem identity10420 : scanCanonicalize (H12AffineFastState.compose env10420 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 15) := by decide +kernel

theorem selectedBound10420 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10421 : List Nat := [2,4,8,16,15,31,8,5,13,28,9,16,6,9,0,13,25,9,29,1,15,15,16,3,6,31,8,24,16,9,18,14,4,14,6,13]

theorem envBound10421 : H12AffineFastState.Bounded env10421 := by
  intro p hp
  have h : env10421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10420_10421 : H12AffineEnvironment.transform 4 15 env10420 = env10421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 15 env10420 == env10421) = true)

def env10422 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,160013,272392,169216,21763,8193,64,2048,163841,45405,283904,156696,411973,257,21793,46093,156493]

theorem envBound10422 : H12AffineFastState.Bounded env10422 := by
  intro p hp
  have h : env10422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10408_10422 : H12AffineEnvironment.transform 6 9 env10408 = env10422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10408 == env10422) = true)

theorem identity10422 : scanCanonicalize (H12AffineFastState.compose env10422 (packedSelected [5,7,12,14,20,24,26,27,38] rootPS)) = affineNative (2^(17+1) ^^^ 157753) := by decide +kernel

theorem selectedBound10422 : packedSelected [5,7,12,14,20,24,26,27,38] rootPS < 2^1333 := by decide +kernel

def env10423 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,157753,1025,32769,160013,147505,169216,21763,8193,64,2048,163841,45405,146745,156696,8572,257,21793,46093,156493]

theorem envBound10423 : H12AffineFastState.Bounded env10423 := by
  intro p hp
  have h : env10423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10422_10423 : H12AffineEnvironment.transform 17 157753 env10422 = env10423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env10422 == env10423) = true)

theorem identity10423 : scanCanonicalize (H12AffineFastState.compose env10423 (packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 57676) := by decide +kernel

theorem selectedBound10423 : packedSelected [1,4,5,7,8,9,17,19,24,26,27] rootPS < 2^1333 := by decide +kernel

def env10424 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,57676,35189,1025,32769,36929,41341,29772,21763,8193,64,2048,24909,45405,56437,34132,8572,257,21793,46093,33281]

theorem envBound10424 : H12AffineFastState.Bounded env10424 := by
  intro p hp
  have h : env10424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10423_10424 : H12AffineEnvironment.transform 16 57676 env10423 = env10424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57676 env10423 == env10424) = true)

theorem identity10424 : scanCanonicalize (H12AffineFastState.compose env10424 (packedSelected [1,3,5,8,10,16,17,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound10424 : packedSelected [1,3,5,8,10,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env10425 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21760,8203,13388,23669,1025,21761,17729,29821,29772,21763,8193,64,2048,24909,25693,2421,20564,8572,257,21793,24845,22273]

theorem envBound10425 : H12AffineFastState.Bounded env10425 := by
  intro p hp
  have h : env10425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10424_10425 : H12AffineEnvironment.transform 14 21760 env10424 = env10425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env10424 == env10425) = true)

theorem identity10425 : scanCanonicalize (H12AffineFastState.compose env10425 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10425 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env10426 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,21621,8203,13388,23669,1025,21620,17460,29821,29772,21622,8193,64,2048,24632,25693,2048,20564,8201,116,21588,24696,22132]

theorem envBound10426 : H12AffineFastState.Bounded env10426 := by
  intro p hp
  have h : env10426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10425_10426 : H12AffineEnvironment.transform 7 117 env10425 = env10426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10425 == env10426) = true)

theorem identity10426 : scanCanonicalize (H12AffineFastState.compose env10426 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound10426 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10427 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5237,0,8203,13388,2048,1025,1,4161,8200,8249,3,8193,64,2048,13389,12328,2048,1057,8201,116,33,13325,513]

theorem envBound10427 : H12AffineFastState.Bounded env10427 := by
  intro p hp
  have h : env10427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10426_10427 : H12AffineEnvironment.transform 13 5237 env10426 = env10427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env10426 == env10427) = true)

theorem identity10427 : scanCanonicalize (H12AffineFastState.compose env10427 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 5196) := by decide +kernel

theorem selectedBound10427 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env10428 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,5196,5237,0,5191,0,2048,1025,1,4161,5188,5237,3,5197,64,2048,1,1124,2048,1057,5189,116,33,65,513]

theorem envBound10428 : H12AffineFastState.Bounded env10428 := by
  intro p hp
  have h : env10428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10427_10428 : H12AffineEnvironment.transform 12 5196 env10427 = env10428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 5196 env10427 == env10428) = true)

theorem identity10428 : scanCanonicalize (H12AffineFastState.compose env10428 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound10428 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env10429 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,4096,5196,5237,0,5191,0,0,1025,1,4161,5188,5237,3,5197,64,0,1,1124,0,1057,5189,116,33,65,513]

theorem envBound10429 : H12AffineFastState.Bounded env10429 := by
  intro p hp
  have h : env10429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10428_10429 : H12AffineEnvironment.transform 10 0 env10428 = env10429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env10428 == env10429) = true)

theorem identity10429 : scanCanonicalize (H12AffineFastState.compose env10429 (packedSelected [6,11] rootPS)) = affineNative (2^(11+1) ^^^ 1076) := by decide +kernel

theorem selectedBound10429 : packedSelected [6,11] rootPS < 2^1333 := by decide +kernel

def env10430 : List Nat := [2,4,8,16,32,64,9,117,512,1024,0,1076,120,65,0,115,0,0,1025,1,1141,112,65,3,121,64,0,1,1124,0,1057,113,116,33,65,513]

theorem envBound10430 : H12AffineFastState.Bounded env10430 := by
  intro p hp
  have h : env10430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10429_10430 : H12AffineEnvironment.transform 11 1076 env10429 = env10430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1076 env10429 == env10430) = true)

theorem identity10430 : scanCanonicalize (H12AffineFastState.compose env10430 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 117) := by decide +kernel

theorem selectedBound10430 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env10431 : List Nat := [2,4,8,16,32,64,9,117,512,117,0,65,120,65,0,115,0,0,116,1,0,112,65,3,121,64,0,1,17,0,84,113,116,33,65,513]

theorem envBound10431 : H12AffineFastState.Bounded env10431 := by
  intro p hp
  have h : env10431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10430_10431 : H12AffineEnvironment.transform 9 117 env10430 = env10431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 117 env10430 == env10431) = true)

def env10432 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,4194304,169217,95497,8328,64,4464648,163840,45525,283905,156696,4350284,257,21793,46212,213967]

theorem envBound10432 : H12AffineFastState.Bounded env10432 := by
  intro p hp
  have h : env10432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10384_10432 : H12AffineEnvironment.transform 22 169217 env10384 = env10432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 169217 env10384 == env10432) = true)

def env10433 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272512,169217,95497,8328,64,2184,163840,45525,283905,156696,412108,257,21793,46212,213967]

theorem envBound10433 : H12AffineFastState.Bounded env10433 := by
  intro p hp
  have h : env10433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10432_10433 : H12AffineEnvironment.transform 21 272512 env10432 = env10433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env10432 == env10433) = true)

theorem identity10433 : scanCanonicalize (H12AffineFastState.compose env10433 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound10433 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10434 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,77898,272512,120015,95497,8328,64,2184,115150,45525,283905,75222,329730,257,21793,46212,513]

theorem envBound10434 : H12AffineFastState.Bounded env10434 := by
  intro p hp
  have h : env10434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10433_10434 : H12AffineEnvironment.transform 16 82382 env10433 = env10434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env10433 == env10434) = true)

def env10435 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,262144,1025,32769,77898,272392,119879,95497,8192,64,2048,115014,45405,283905,75102,329730,257,21793,46092,513]

theorem envBound10435 : H12AffineFastState.Bounded env10435 := by
  intro p hp
  have h : env10435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10434_10435 : H12AffineEnvironment.transform 6 8 env10434 = env10435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10434 == env10435) = true)

theorem identity10435 : scanCanonicalize (H12AffineFastState.compose env10435 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound10435 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env10436 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,262144,1025,32769,69911,264533,119879,87124,349,64,2048,115014,36864,283905,66563,329730,257,21793,38225,513]

theorem envBound10436 : H12AffineFastState.Bounded env10436 := by
  intro p hp
  have h : env10436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10435_10436 : H12AffineEnvironment.transform 12 349 env10435 = env10436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env10435 == env10436) = true)

theorem identity10436 : scanCanonicalize (H12AffineFastState.compose env10436 (packedSelected [4,7,9,11,27,32] rootPS)) = affineNative (2^(17+1) ^^^ 56357) := by decide +kernel

theorem selectedBound10436 : packedSelected [4,7,9,11,27,32] rootPS < 2^1333 := by decide +kernel

def env10437 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,65536,82246,56357,1025,32769,69911,54640,119879,87124,349,64,2048,115014,36864,35108,66563,119847,257,21793,38225,513]

theorem envBound10437 : H12AffineFastState.Bounded env10437 := by
  intro p hp
  have h : env10437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10436_10437 : H12AffineEnvironment.transform 17 56357 env10436 = env10437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56357 env10436 == env10437) = true)

theorem identity10437 : scanCanonicalize (H12AffineFastState.compose env10437 (packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS)) = affineNative (2^(15+1) ^^^ 114) := by decide +kernel

theorem selectedBound10437 : packedSelected [2,3,5,6,10,12,15,17,18,23] rootPS < 2^1333 := by decide +kernel

def env10438 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,114,16692,56357,1025,32769,4453,54640,54325,21542,349,64,2048,49460,36864,35108,1137,54357,257,21793,38225,513]

theorem envBound10438 : H12AffineFastState.Bounded env10438 := by
  intro p hp
  have h : env10438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10437_10438 : H12AffineEnvironment.transform 15 114 env10437 = env10438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 114 env10437 == env10438) = true)

theorem identity10438 : scanCanonicalize (H12AffineFastState.compose env10438 (packedSelected [1,2,3,6,8,10,12,15,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound10438 : packedSelected [1,2,3,6,8,10,12,15,24] rootPS < 2^1333 := by decide +kernel

def env10439 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,16384,32768,34,16692,56357,1025,32769,4405,54560,54325,21542,269,16,2048,49460,36864,35108,1057,54277,257,21793,38145,513]

theorem envBound10439 : H12AffineFastState.Bounded env10439 := by
  intro p hp
  have h : env10439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10438_10439 : H12AffineEnvironment.transform 5 16 env10438 = env10439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env10438 == env10439) = true)

theorem identity10439 : scanCanonicalize (H12AffineFastState.compose env10439 (packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound10439 : packedSelected [0,3,4,5,7,9,10,12,14,15,17] rootPS < 2^1333 := by decide +kernel

def env10440 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,16384,32768,34,16692,55605,273,32769,4405,53296,53541,20790,269,16,2048,49460,36864,35108,305,53525,257,20529,36881,513]

theorem envBound10440 : H12AffineFastState.Bounded env10440 := by
  intro p hp
  have h : env10440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10439_10440 : H12AffineEnvironment.transform 9 272 env10439 = env10440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env10439 == env10440) = true)

theorem identity10440 : scanCanonicalize (H12AffineFastState.compose env10440 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4404) := by decide +kernel

theorem selectedBound10440 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env10441 : List Nat := [2,4,8,16,32,16,8,256,512,272,2048,4096,269,4404,32768,34,4096,34817,273,32769,4405,33028,32785,2,269,16,2048,36864,36864,35108,305,32801,257,261,36881,513]

theorem envBound10441 : H12AffineFastState.Bounded env10441 := by
  intro p hp
  have h : env10441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10440_10441 : H12AffineEnvironment.transform 13 4404 env10440 = env10441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4404 env10440 == env10441) = true)

theorem identity10441 : scanCanonicalize (H12AffineFastState.compose env10441 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound10441 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env10442 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,32768,34,4096,34817,53,32769,4113,32800,32785,2,41,16,2048,36864,36864,34816,21,32801,37,33,36881,513]

theorem envBound10442 : H12AffineFastState.Bounded env10442 := by
  intro p hp
  have h : env10442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10441_10442 : H12AffineEnvironment.transform 7 36 env10441 = env10442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env10441 == env10442) = true)

theorem identity10442 : scanCanonicalize (H12AffineFastState.compose env10442 (packedSelected [0,2,7] rootPS)) = affineNative (2^(14+1) ^^^ 6193) := by decide +kernel

theorem selectedBound10442 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env10443 : List Nat := [2,4,8,16,32,16,8,36,512,52,2048,4096,41,4112,6193,34,4096,4144,53,6192,4113,6161,6176,2,41,16,2048,2097,2097,4145,21,6160,37,33,2080,513]

theorem envBound10443 : H12AffineFastState.Bounded env10443 := by
  intro p hp
  have h : env10443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10442_10443 : H12AffineEnvironment.transform 14 6193 env10442 = env10443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 6193 env10442 == env10443) = true)

theorem identity10443 : scanCanonicalize (H12AffineFastState.compose env10443 (packedSelected [0,1,3] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound10443 : packedSelected [0,1,3] rootPS < 2^1333 := by decide +kernel

def env10444 : List Nat := [2,4,8,16,32,16,8,36,0,52,2048,4096,41,4112,6193,34,4096,4144,53,6192,4113,6161,6176,2,41,16,2048,2097,2097,4145,21,6160,37,33,2080,1]

theorem envBound10444 : H12AffineFastState.Bounded env10444 := by
  intro p hp
  have h : env10444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10443_10444 : H12AffineEnvironment.transform 8 0 env10443 = env10444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env10443 == env10444) = true)

theorem identity10444 : scanCanonicalize (H12AffineFastState.compose env10444 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound10444 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10445 : List Nat := [2,4,8,16,32,16,8,36,0,52,32,4096,41,4112,4113,34,4096,4144,53,4112,4113,4145,4096,2,41,16,32,17,17,4145,21,4144,37,33,0,1]

theorem envBound10445 : H12AffineFastState.Bounded env10445 := by
  intro p hp
  have h : env10445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10444_10445 : H12AffineEnvironment.transform 10 32 env10444 = env10445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env10444 == env10445) = true)

theorem identity10445 : scanCanonicalize (H12AffineFastState.compose env10445 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound10445 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10446 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,4096,9,4112,4113,2,4096,4112,21,4112,4113,4113,4096,2,9,16,0,17,17,4113,21,4112,5,1,0,1]

theorem envBound10446 : H12AffineFastState.Bounded env10446 := by
  intro p hp
  have h : env10446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10445_10446 : H12AffineEnvironment.transform 4 0 env10445 = env10446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env10445 == env10446) = true)

theorem identity10446 : scanCanonicalize (H12AffineFastState.compose env10446 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound10446 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env10447 : List Nat := [2,4,8,16,0,16,8,4,0,20,0,1,9,17,16,2,1,17,21,17,16,16,1,2,9,16,0,17,17,16,21,17,5,1,0,1]

theorem envBound10447 : H12AffineFastState.Bounded env10447 := by
  intro p hp
  have h : env10447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10446_10447 : H12AffineEnvironment.transform 11 1 env10446 = env10447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env10446 == env10447) = true)

theorem identity10447 : scanCanonicalize (H12AffineFastState.compose env10447 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10447 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env10448 : List Nat := [2,4,8,0,0,0,8,4,0,4,0,1,9,1,0,2,1,1,5,1,0,0,1,2,9,0,0,1,1,0,5,1,5,1,0,1]

theorem envBound10448 : H12AffineFastState.Bounded env10448 := by
  intro p hp
  have h : env10448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10447_10448 : H12AffineEnvironment.transform 3 0 env10447 = env10448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10447 == env10448) = true)

def env10449 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,262144,1025,32769,77898,272393,119878,95497,8193,64,2049,115015,45404,283905,75103,329730,257,21793,46093,513]

theorem envBound10449 : H12AffineFastState.Bounded env10449 := by
  intro p hp
  have h : env10449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10434_10449 : H12AffineEnvironment.transform 6 9 env10434 = env10449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env10434 == env10449) = true)

def env10450 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10280,1025,32769,77898,33,119878,95497,8193,64,2049,115015,45404,32041,75103,73770,257,21793,46093,513]

theorem envBound10450 : H12AffineFastState.Bounded env10450 := by
  intro p hp
  have h : env10450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10449_10450 : H12AffineEnvironment.transform 17 10280 env10449 = env10450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10449 == env10450) = true)

theorem identity10450 : scanCanonicalize (H12AffineFastState.compose env10450 (packedSelected [0,1,7,8,12,14,15,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 21590) := by decide +kernel

theorem selectedBound10450 : packedSelected [0,1,7,8,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env10451 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,21590,5393,10280,1025,32769,25628,33,32784,8543,8193,64,2049,38161,45404,32041,28937,29820,257,21793,46093,513]

theorem envBound10451 : H12AffineFastState.Bounded env10451 := by
  intro p hp
  have h : env10451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10450_10451 : H12AffineEnvironment.transform 15 21590 env10450 = env10451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21590 env10450 == env10451) = true)

theorem identity10451 : scanCanonicalize (H12AffineFastState.compose env10451 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound10451 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env10452 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,21590,5393,10280,1025,1,25628,33,16,8543,8193,64,2049,5393,12636,32041,28937,29820,257,21793,13325,513]

theorem envBound10452 : H12AffineFastState.Bounded env10452 := by
  intro p hp
  have h : env10452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10451_10452 : H12AffineEnvironment.transform 14 0 env10451 = env10452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env10451 == env10452) = true)

theorem identity10452 : scanCanonicalize (H12AffineFastState.compose env10452 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound10452 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env10453 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,16384,0,21590,5393,2341,1025,1,17681,33,16,82,268,64,2049,5393,4177,23588,20484,21873,257,21793,5376,513]

theorem envBound10453 : H12AffineFastState.Bounded env10453 := by
  intro p hp
  have h : env10453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10452_10453 : H12AffineEnvironment.transform 12 269 env10452 = env10453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env10452 == env10453) = true)

theorem identity10453 : scanCanonicalize (H12AffineFastState.compose env10453 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound10453 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env10454 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,0,343,5393,2341,1025,1,4112,33,16,82,268,64,2049,5393,4177,2341,1285,112,257,32,5376,513]

theorem envBound10454 : H12AffineFastState.Bounded env10454 := by
  intro p hp
  have h : env10454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10453_10454 : H12AffineEnvironment.transform 13 5377 env10453 = env10454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env10453 == env10454) = true)

def env10455 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,10281,1025,32769,77898,32,119878,95497,8193,64,2049,115015,45404,32040,75103,73771,257,21793,46093,513]

theorem envBound10455 : H12AffineFastState.Bounded env10455 := by
  intro p hp
  have h : env10455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10449_10455 : H12AffineEnvironment.transform 17 10281 env10449 = env10455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env10449 == env10455) = true)

theorem identity10455 : scanCanonicalize (H12AffineFastState.compose env10455 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound10455 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env10456 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,38161,10281,1025,32769,58396,32,16,41311,8193,64,2049,5393,45404,32040,61705,62589,257,21793,46093,513]

theorem envBound10456 : H12AffineFastState.Bounded env10456 := by
  intro p hp
  have h : env10456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10455_10456 : H12AffineEnvironment.transform 15 54358 env10455 = env10456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env10455 == env10456) = true)

theorem identity10456 : scanCanonicalize (H12AffineFastState.compose env10456 (packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 2049) := by decide +kernel

theorem selectedBound10456 : packedSelected [0,1,2,3,5,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env10457 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2049,32768,40023,38161,10281,1025,32769,44061,32,16,41311,8193,64,2049,5393,45404,13609,47368,48252,257,7456,46093,513]

theorem envBound10457 : H12AffineFastState.Bounded env10457 := by
  intro p hp
  have h : env10457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10456_10457 : H12AffineEnvironment.transform 13 2049 env10456 = env10457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2049 env10456 == env10457) = true)

theorem identity10457 : scanCanonicalize (H12AffineFastState.compose env10457 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound10457 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env10458 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,2049,32768,40023,38161,2421,1025,32769,36161,32,16,32771,349,64,2049,5393,36864,5237,38996,40224,257,7456,38225,513]

theorem envBound10458 : H12AffineFastState.Bounded env10458 := by
  intro p hp
  have h : env10458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10457_10458 : H12AffineEnvironment.transform 12 348 env10457 = env10458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env10457 == env10458) = true)

theorem identity10458 : scanCanonicalize (H12AffineFastState.compose env10458 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound10458 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env10459 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1296,4096,348,1297,32768,37191,38161,1125,1025,32769,32849,32,16,32771,349,64,1297,5393,36864,5237,38212,36912,257,4144,38225,513]

theorem envBound10459 : H12AffineFastState.Bounded env10459 := by
  intro p hp
  have h : env10459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10458_10459 : H12AffineEnvironment.transform 10 1296 env10458 = env10459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env10458 == env10459) = true)

theorem identity10459 : scanCanonicalize (H12AffineFastState.compose env10459 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound10459 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env10460 : List Nat := [2,4,8,16,32,64,9,256,512,273,1,4096,348,0,32768,37191,36864,372,272,32769,32849,32,16,32771,349,64,0,4096,36864,4452,36949,36912,257,4144,36928,513]

theorem envBound10460 : H12AffineFastState.Bounded env10460 := by
  intro p hp
  have h : env10460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10459_10460 : H12AffineEnvironment.transform 9 273 env10459 = env10460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env10459 == env10460) = true)

theorem identity10460 : scanCanonicalize (H12AffineFastState.compose env10460 (packedSelected [11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound10460 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env10461 : List Nat := [2,4,8,16,32,64,9,117,512,100,1,4096,41,0,32768,36914,36864,1,101,32769,32849,32,16,32771,40,64,0,4096,36864,4113,36949,36912,116,4144,36928,513]

theorem envBound10461 : H12AffineFastState.Bounded env10461 := by
  intro p hp
  have h : env10461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10460_10461 : H12AffineEnvironment.transform 7 117 env10460 = env10461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env10460 == env10461) = true)

theorem identity10461 : scanCanonicalize (H12AffineFastState.compose env10461 (packedSelected [1,2,4,5,6,7] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10461 : packedSelected [1,2,4,5,6,7] rootPS < 2^1333 := by decide +kernel

def env10462 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,41,0,32768,36914,36864,1,52,32769,32768,32,16,32771,40,17,0,4096,36864,4113,36868,36912,37,4144,36881,513]

theorem envBound10462 : H12AffineFastState.Bounded env10462 := by
  intro p hp
  have h : env10462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10461_10462 : H12AffineEnvironment.transform 5 17 env10461 = env10462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10461 == env10462) = true)

theorem identity10462 : scanCanonicalize (H12AffineFastState.compose env10462 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(14+1) ^^^ 4113) := by decide +kernel

theorem selectedBound10462 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env10463 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,4096,41,0,4113,35,17,1,52,4112,4113,32,16,4114,40,17,0,4096,17,4113,21,33,37,4144,0,513]

theorem envBound10463 : H12AffineFastState.Bounded env10463 := by
  intro p hp
  have h : env10463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10462_10463 : H12AffineEnvironment.transform 14 4113 env10462 = env10463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 4113 env10462 == env10463) = true)

theorem identity10463 : scanCanonicalize (H12AffineFastState.compose env10463 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound10463 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env10464 : List Nat := [2,4,8,16,32,17,9,36,512,53,1,17,41,0,0,35,17,1,52,1,0,32,16,3,40,17,0,17,17,0,21,33,37,33,0,513]

theorem envBound10464 : H12AffineFastState.Bounded env10464 := by
  intro p hp
  have h : env10464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10463_10464 : H12AffineEnvironment.transform 11 17 env10463 = env10464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env10463 == env10464) = true)

theorem identity10464 : scanCanonicalize (H12AffineFastState.compose env10464 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound10464 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10465 : List Nat := [2,4,8,0,32,1,9,36,512,37,1,1,41,0,0,35,1,1,36,1,0,32,0,3,40,1,0,1,1,0,5,33,37,33,0,513]

theorem envBound10465 : H12AffineFastState.Bounded env10465 := by
  intro p hp
  have h : env10465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10464_10465 : H12AffineEnvironment.transform 3 0 env10464 = env10465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env10464 == env10465) = true)

theorem identity10465 : scanCanonicalize (H12AffineFastState.compose env10465 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound10465 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10466 : List Nat := [2,4,8,0,32,1,9,36,43,37,1,1,41,0,0,35,1,1,36,1,0,32,0,3,40,1,0,1,1,0,5,33,37,33,0,42]

theorem envBound10466 : H12AffineFastState.Bounded env10466 := by
  intro p hp
  have h : env10466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10465_10466 : H12AffineEnvironment.transform 8 43 env10465 = env10466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env10465 == env10466) = true)

def env10467 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,160132,272513,169217,95497,8328,64,2185,163840,45525,283905,156696,412109,257,21793,46212,213967]

theorem envBound10467 : H12AffineFastState.Bounded env10467 := by
  intro p hp
  have h : env10467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10432_10467 : H12AffineEnvironment.transform 21 272513 env10432 = env10467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env10432 == env10467) = true)

theorem identity10467 : scanCanonicalize (H12AffineFastState.compose env10467 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound10467 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env10468 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,160132,272513,169217,41431,8328,64,2185,163840,45525,283905,156696,412109,257,21793,46212,169745]

theorem envBound10468 : H12AffineFastState.Bounded env10468 := by
  intro p hp
  have h : env10468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10467_10468 : H12AffineEnvironment.transform 15 54494 env10467 = env10468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env10467 == env10468) = true)

def env10469 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1025,32769,160012,272393,169217,41311,8192,64,2049,163840,45405,283905,156696,411973,257,21793,46092,169745]

theorem envBound10469 : H12AffineFastState.Bounded env10469 := by
  intro p hp
  have h : env10469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10468_10469 : H12AffineEnvironment.transform 6 8 env10468 = env10469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env10468 == env10469) = true)

theorem identity10469 : scanCanonicalize (H12AffineFastState.compose env10469 (packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound10469 : packedSelected [0,5,7,9,14,15,20,22,24,26,41] rootPS < 2^1333 := by decide +kernel

def env10470 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8574,131072,262144,1025,29993,160012,272393,155689,21623,8192,64,2049,161064,17525,283905,156696,411973,257,21793,16676,156217]

theorem envBound10470 : H12AffineFastState.Bounded env10470 := by
  intro p hp
  have h : env10470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10469_10470 : H12AffineEnvironment.transform 14 29992 env10469 = env10470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env10469 == env10470) = true)

theorem identity10470 : scanCanonicalize (H12AffineFastState.compose env10470 (packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS)) = affineNative (2^(16+1) ^^^ 13625) := by decide +kernel

theorem selectedBound10470 : packedSelected [0,1,2,4,5,6,8,9,16,19,23,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env10471 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8574,13625,262144,1025,29993,17461,272393,21776,21623,8192,64,2049,16401,17525,283905,20769,294012,257,21793,16676,22272]

theorem envBound10471 : H12AffineFastState.Bounded env10471 := by
  intro p hp
  have h : env10471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10470_10471 : H12AffineEnvironment.transform 16 13625 env10470 = env10471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13625 env10470 == env10471) = true)

theorem identity10471 : scanCanonicalize (H12AffineFastState.compose env10471 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound10471 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env10472 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,8574,13625,10280,1025,29993,17461,33,21776,21623,8192,64,2049,16401,17525,32041,20769,21588,257,21793,16676,22272]

theorem envBound10472 : H12AffineFastState.Bounded env10472 := by
  intro p hp
  have h : env10472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10471_10472 : H12AffineEnvironment.transform 17 10280 env10471 = env10472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env10471 == env10472) = true)

theorem identity10472 : scanCanonicalize (H12AffineFastState.compose env10472 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound10472 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env10473 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8541,8574,13625,10280,1025,8540,4160,33,357,2,8192,64,2049,5220,4096,10588,1364,33,257,340,5457,885]

theorem envBound10473 : H12AffineFastState.Bounded env10473 := by
  intro p hp
  have h : env10473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10472_10473 : H12AffineEnvironment.transform 13 5237 env10472 = env10473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env10472 == env10473) = true)

theorem identity10473 : scanCanonicalize (H12AffineFastState.compose env10473 (packedSelected [0,2,4,7,9,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound10473 : packedSelected [0,2,4,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env10474 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,8192,5237,8281,8314,13373,10280,1025,8280,4160,33,97,2,8192,64,2049,5220,4096,10328,1104,33,5,80,5205,625]

theorem envBound10474 : H12AffineFastState.Bounded env10474 := by
  intro p hp
  have h : env10474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10473_10474 : H12AffineEnvironment.transform 7 4 env10473 = env10474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env10473 == env10474) = true)

theorem identity10474 : scanCanonicalize (H12AffineFastState.compose env10474 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 88) := by decide +kernel

theorem selectedBound10474 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env10475 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,88,5237,1,34,5221,2160,1025,0,4160,33,97,2,88,64,2049,5220,4096,2048,1104,33,5,80,5205,625]

theorem envBound10475 : H12AffineFastState.Bounded env10475 := by
  intro p hp
  have h : env10475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10474_10475 : H12AffineEnvironment.transform 12 88 env10474 = env10475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 88 env10474 == env10475) = true)

theorem identity10475 : scanCanonicalize (H12AffineFastState.compose env10475 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound10475 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env10476 : List Nat := [2,4,8,16,32,64,8,4,512,1024,33,4096,88,5237,1,34,5221,81,1025,0,4160,33,97,2,88,64,32,5220,4096,33,1104,33,5,80,5205,625]

theorem envBound10476 : H12AffineFastState.Bounded env10476 := by
  intro p hp
  have h : env10476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10475_10476 : H12AffineEnvironment.transform 10 33 env10475 = env10476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env10475 == env10476) = true)

theorem identity10476 : scanCanonicalize (H12AffineFastState.compose env10476 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 574) := by decide +kernel

theorem selectedBound10476 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env10477 : List Nat := [2,4,8,16,32,64,8,4,512,574,33,4096,88,4683,1,34,4699,81,575,0,4160,33,97,2,88,64,32,4698,4096,33,622,33,5,80,4715,625]

theorem envBound10477 : H12AffineFastState.Bounded env10477 := by
  intro p hp
  have h : env10477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10476_10477 : H12AffineEnvironment.transform 9 574 env10476 = env10477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 574 env10476 == env10477) = true)

theorem identity10477 : scanCanonicalize (H12AffineFastState.compose env10477 (packedSelected [1,2,3,6,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound10477 : packedSelected [1,2,3,6,12] rootPS < 2^1333 := by decide +kernel

def env10478 : List Nat := [2,4,8,16,32,17,8,4,512,574,33,4096,9,4634,1,34,4618,0,575,0,4113,33,48,2,9,17,32,4619,4096,33,575,33,5,1,4666,544]

theorem envBound10478 : H12AffineFastState.Bounded env10478 := by
  intro p hp
  have h : env10478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10477_10478 : H12AffineEnvironment.transform 5 17 env10477 = env10478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env10477 == env10478) = true)

theorem identity10478 : scanCanonicalize (H12AffineFastState.compose env10478 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 538) := by decide +kernel

theorem selectedBound10478 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env10479 : List Nat := [2,4,8,16,32,17,8,4,512,574,33,538,9,0,1,34,16,0,575,0,523,33,48,2,9,17,32,17,538,33,575,33,5,1,32,544]

theorem envBound10479 : H12AffineFastState.Bounded env10479 := by
  intro p hp
  have h : env10479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10478_10479 : H12AffineEnvironment.transform 11 538 env10478 = env10479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 538 env10478 == env10479) = true)

theorem identity10479 : scanCanonicalize (H12AffineFastState.compose env10479 (packedSelected [1,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound10479 : packedSelected [1,4,5] rootPS < 2^1333 := by decide +kernel

def env10480 : List Nat := [2,4,8,16,5,17,8,4,512,539,4,538,9,0,1,7,16,0,538,0,523,4,21,2,9,17,5,17,538,4,538,4,5,1,5,517]

theorem envBound10480 : H12AffineFastState.Bounded env10480 := by
  intro p hp
  have h : env10480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10479_10480 : H12AffineEnvironment.transform 4 5 env10479 = env10480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env10479 == env10480) = true)

theorem identity10480 : scanCanonicalize (H12AffineFastState.compose env10480 (packedSelected [0,1,2] rootPS)) = affineNative (2^(8+1) ^^^ 2) := by decide +kernel

theorem selectedBound10480 : packedSelected [0,1,2] rootPS < 2^1333 := by decide +kernel

def env10481 : List Nat := [2,4,8,16,5,17,8,4,2,25,4,24,9,0,1,7,16,0,24,0,9,4,21,2,9,17,5,17,24,4,24,4,5,1,5,7]

theorem envBound10481 : H12AffineFastState.Bounded env10481 := by
  intro p hp
  have h : env10481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10480_10481 : H12AffineEnvironment.transform 8 2 env10480 = env10481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 2 env10480 == env10481) = true)

theorem identity10481 : scanCanonicalize (H12AffineFastState.compose env10481 (packedSelected [0,1,6] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound10481 : packedSelected [0,1,6] rootPS < 2^1333 := by decide +kernel

def env10482 : List Nat := [2,0,8,16,1,17,8,0,2,25,0,24,9,0,1,3,16,0,24,0,9,0,17,2,9,17,1,17,24,0,24,0,1,1,1,3]

theorem envBound10482 : H12AffineFastState.Bounded env10482 := by
  intro p hp
  have h : env10482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10481_10482 : H12AffineEnvironment.transform 1 0 env10481 = env10482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env10481 == env10482) = true)

theorem identity10482 : scanCanonicalize (H12AffineFastState.compose env10482 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 2) := by decide +kernel

theorem selectedBound10482 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env10483 : List Nat := [2,0,8,2,1,3,8,0,2,11,0,10,9,0,1,3,2,0,10,0,9,0,3,2,9,3,1,3,10,0,10,0,1,1,1,3]

theorem envBound10483 : H12AffineFastState.Bounded env10483 := by
  intro p hp
  have h : env10483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10482_10483 : H12AffineEnvironment.transform 3 2 env10482 = env10483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 2 env10482 == env10483) = true)

theorem identity10483 : scanCanonicalize (H12AffineFastState.compose env10483 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound10483 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env10484 : List Nat := [2,0,1,2,1,3,1,0,2,2,0,3,0,0,1,3,2,0,3,0,0,0,3,2,0,3,1,3,3,0,3,0,1,1,1,3]

theorem envBound10484 : H12AffineFastState.Bounded env10484 := by
  intro p hp
  have h : env10484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans10483_10484 : H12AffineEnvironment.transform 2 1 env10483 = env10484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env10483 == env10484) = true)

theorem identity10484 : scanCanonicalize (H12AffineFastState.compose env10484 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound10484 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env10485 : List Nat := [0,0,1,0,1,1,1,0,0,0,0,1,0,0,1,1,0,0,1,0,0,0,1,0,0,1,1,1,1,0,1,0,1,1,1,1]

end H12CloudChart1