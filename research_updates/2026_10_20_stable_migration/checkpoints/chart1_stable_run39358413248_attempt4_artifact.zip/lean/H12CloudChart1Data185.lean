import H12CloudChart1Data184

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound46878 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46879 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,4096,41,5157,0,34,5172,2048,1025,1,4113,33,16,2,41,17,2048,5173,4097,2048,1056,32,37,33,5157,513]

theorem envBound46879 : H12AffineFastState.Bounded env46879 := by
  intro p hp
  have h : env46879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46878_46879 : H12AffineEnvironment.transform 7 36 env46878 = env46879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46878 == env46879) = true)

def env46880 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,48,41,1045,0,34,1028,2048,1025,1,33,33,16,2,41,17,2048,1029,49,2048,1056,32,37,33,1045,513]

theorem envBound46880 : H12AffineFastState.Bounded env46880 := by
  intro p hp
  have h : env46880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46879_46880 : H12AffineEnvironment.transform 11 48 env46879 = env46880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46879 == env46880) = true)

theorem identity46880 : scanCanonicalize (H12AffineFastState.compose env46880 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound46880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46881 : List Nat := [2,4,8,16,32,17,8,36,512,1024,0,48,41,1045,0,34,1028,0,1025,1,33,33,16,2,41,17,0,1029,49,0,1056,32,37,33,1045,513]

theorem envBound46881 : H12AffineFastState.Bounded env46881 := by
  intro p hp
  have h : env46881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46880_46881 : H12AffineEnvironment.transform 10 0 env46880 = env46881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env46880 == env46881) = true)

def env46882 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,48,41,33,0,34,48,0,53,1,33,33,16,2,41,17,0,49,49,0,20,32,37,33,33,513]

theorem envBound46882 : H12AffineFastState.Bounded env46882 := by
  intro p hp
  have h : env46882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46881_46882 : H12AffineEnvironment.transform 9 52 env46881 = env46882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46881 == env46882) = true)

theorem identity46882 : scanCanonicalize (H12AffineFastState.compose env46882 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound46882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46883 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,41,33,0,34,48,0,53,1,33,33,16,2,41,17,0,49,49,0,20,32,37,33,33,11]

theorem envBound46883 : H12AffineFastState.Bounded env46883 := by
  intro p hp
  have h : env46883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46882_46883 : H12AffineEnvironment.transform 8 10 env46882 = env46883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env46882 == env46883) = true)

def leafEnv46883 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,48,41,33,0,34,48,0,53,1,33,33,16,2,21,41,1,17,0,49,49,0,20,32,37,33,5,34,33,11,1,33,0]

def active46883 : List Nat := [0,1,2,3,4]

def tree46883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46883 : H12WitnessSearch.Good tree46883 := H12GlobalWitnessIndex.good

theorem leafIdentity46883 : H12AffineFastState.composeSystem env46883 rootObs = leafEnv46883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46883 rootObs == leafEnv46883) = true)

theorem terminalChecked46883 : H12PackedTerminal.terminalCheckFast leafEnv46883 active46883 tree46883 = true := by decide +kernel

def env46884 : List Nat := [2,4,8,16,32,17,8,36,512,53,0,48,41,32,0,34,49,0,52,1,33,33,16,2,41,17,0,48,49,0,21,32,37,33,32,513]

theorem envBound46884 : H12AffineFastState.Bounded env46884 := by
  intro p hp
  have h : env46884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46881_46884 : H12AffineEnvironment.transform 9 53 env46881 = env46884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46881 == env46884) = true)

theorem identity46884 : scanCanonicalize (H12AffineFastState.compose env46884 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46884 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46885 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,9,0,0,2,17,0,20,1,1,1,16,2,9,17,0,16,17,0,21,0,5,1,0,513]

theorem envBound46885 : H12AffineFastState.Bounded env46885 := by
  intro p hp
  have h : env46885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46884_46885 : H12AffineEnvironment.transform 4 0 env46884 = env46885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46884 == env46885) = true)

def leafEnv46885 : List Nat := [2,4,8,16,0,17,8,4,512,21,0,16,9,0,0,2,17,0,20,1,1,1,16,2,20,9,1,17,0,16,17,0,21,0,5,1,5,2,0,513,1,1,0]

def active46885 : List Nat := [0,1,2,3,8]

def tree46885 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46885 : H12WitnessSearch.Good tree46885 := H12GlobalWitnessIndex.good

theorem leafIdentity46885 : H12AffineFastState.composeSystem env46885 rootObs = leafEnv46885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46885 rootObs == leafEnv46885) = true)

theorem terminalChecked46885 : H12PackedTerminal.terminalCheckFast leafEnv46885 active46885 tree46885 = true := by decide +kernel

def env46886 : List Nat := [2,4,8,16,32,17,8,36,512,1024,2048,49,41,1044,0,34,1029,2048,1025,1,32,33,16,2,41,17,2048,1028,48,2048,1056,32,37,33,1044,513]

theorem envBound46886 : H12AffineFastState.Bounded env46886 := by
  intro p hp
  have h : env46886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46879_46886 : H12AffineEnvironment.transform 11 49 env46879 = env46886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46879 == env46886) = true)

theorem identity46886 : scanCanonicalize (H12AffineFastState.compose env46886 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound46886 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46887 : List Nat := [2,4,8,16,32,17,8,36,512,1024,1076,49,41,1044,0,34,1029,1076,1025,1,32,33,16,2,41,17,1076,1028,48,1076,1056,32,37,33,1044,513]

theorem envBound46887 : H12AffineFastState.Bounded env46887 := by
  intro p hp
  have h : env46887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46886_46887 : H12AffineEnvironment.transform 10 1076 env46886 = env46887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env46886 == env46887) = true)

def env46888 : List Nat := [2,4,8,16,32,17,8,36,512,52,0,49,41,32,0,34,49,0,53,1,32,33,16,2,41,17,0,48,48,0,20,32,37,33,32,513]

theorem envBound46888 : H12AffineFastState.Bounded env46888 := by
  intro p hp
  have h : env46888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46887_46888 : H12AffineEnvironment.transform 9 52 env46887 = env46888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46887 == env46888) = true)

theorem identity46888 : scanCanonicalize (H12AffineFastState.compose env46888 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound46888 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46889 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,41,32,0,34,49,0,53,1,32,33,16,2,41,17,0,48,48,0,20,32,37,33,32,11]

theorem envBound46889 : H12AffineFastState.Bounded env46889 := by
  intro p hp
  have h : env46889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46888_46889 : H12AffineEnvironment.transform 8 10 env46888 = env46889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env46888 == env46889) = true)

def leafEnv46889 : List Nat := [2,4,8,16,32,17,8,36,10,52,0,49,41,32,0,34,49,0,53,1,32,33,16,2,21,41,1,17,0,48,48,0,20,32,37,33,5,34,32,11,1,32,0]

def active46889 : List Nat := [0,1,2,3,4]

def tree46889 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46889 : H12WitnessSearch.Good tree46889 := H12GlobalWitnessIndex.good

theorem leafIdentity46889 : H12AffineFastState.composeSystem env46889 rootObs = leafEnv46889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46889 rootObs == leafEnv46889) = true)

theorem terminalChecked46889 : H12PackedTerminal.terminalCheckFast leafEnv46889 active46889 tree46889 = true := by decide +kernel

def env46890 : List Nat := [2,4,8,16,32,17,8,36,512,53,1,49,41,33,0,34,48,1,52,1,32,33,16,2,41,17,1,49,48,1,21,32,37,33,33,513]

theorem envBound46890 : H12AffineFastState.Bounded env46890 := by
  intro p hp
  have h : env46890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46887_46890 : H12AffineEnvironment.transform 9 53 env46887 = env46890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46887 == env46890) = true)

theorem identity46890 : scanCanonicalize (H12AffineFastState.compose env46890 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46890 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46891 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,9,1,0,2,16,1,20,1,0,1,16,2,9,17,1,17,16,1,21,0,5,1,1,513]

theorem envBound46891 : H12AffineFastState.Bounded env46891 := by
  intro p hp
  have h : env46891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46890_46891 : H12AffineEnvironment.transform 4 0 env46890 = env46891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46890 == env46891) = true)

def leafEnv46891 : List Nat := [2,4,8,16,0,17,8,4,512,21,1,17,9,1,0,2,16,1,20,1,0,1,16,2,20,9,1,17,1,17,16,1,21,0,5,1,5,2,1,513,1,0,0]

def active46891 : List Nat := [0,1,2,3,8]

def tree46891 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46891 : H12WitnessSearch.Good tree46891 := H12GlobalWitnessIndex.good

theorem leafIdentity46891 : H12AffineFastState.composeSystem env46891 rootObs = leafEnv46891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46891 rootObs == leafEnv46891) = true)

theorem terminalChecked46891 : H12PackedTerminal.terminalCheckFast leafEnv46891 active46891 tree46891 = true := by decide +kernel

def env46892 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,115735,272393,119879,98644,8193,64,97547,115014,17664,382039,119043,329730,257,21792,46093,63069]

theorem envBound46892 : H12AffineFastState.Bounded env46892 := by
  intro p hp
  have h : env46892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46871_46892 : H12AffineEnvironment.transform 6 9 env46871 = env46892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46871 == env46892) = true)

theorem identity46892 : scanCanonicalize (H12AffineFastState.compose env46892 (packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS)) = affineNative (2^(15+1) ^^^ 62510) := by decide +kernel

theorem selectedBound46892 : packedSelected [0,1,3,7,8,9,10,12,16,17,22,24,35,38] rootPS < 2^1333 := by decide +kernel

def env46893 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62510,49169,262144,1025,32769,12345,272393,8297,30074,8193,64,35109,13672,17664,270457,9517,326700,257,21792,46093,63069]

theorem envBound46893 : H12AffineFastState.Bounded env46893 := by
  intro p hp
  have h : env46893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46892_46893 : H12AffineEnvironment.transform 15 62510 env46892 = env46893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62510 env46892 == env46893) = true)

theorem identity46893 : scanCanonicalize (H12AffineFastState.compose env46893 (packedSelected [1,2,3,4,6,8,11,12,14,15,16,17,19,22,23,24,26,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound46893 : packedSelected [1,2,3,4,6,8,11,12,14,15,16,17,19,22,23,24,26,31,35] rootPS < 2^1333 := by decide +kernel

def env46894 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,30043,16740,262144,1025,372,12345,272393,8297,30074,8193,64,2128,13672,17664,270457,9517,294233,257,21792,13688,30504]

theorem envBound46894 : H12AffineFastState.Bounded env46894 := by
  intro p hp
  have h : env46894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46893_46894 : H12AffineEnvironment.transform 14 373 env46893 = env46894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env46893 == env46894) = true)

theorem identity46894 : scanCanonicalize (H12AffineFastState.compose env46894 (packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS)) = affineNative (2^(17+1) ^^^ 23808) := by decide +kernel

theorem selectedBound46894 : packedSelected [0,2,3,5,6,7,10,11,12,15,17,20,23] rootPS < 2^1333 := by decide +kernel

def env46895 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,373,30043,16740,23808,1025,372,12345,29961,8297,30074,8193,64,2128,13672,17664,32121,9517,8281,257,21792,13688,30504]

theorem envBound46895 : H12AffineFastState.Bounded env46895 := by
  intro p hp
  have h : env46895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46894_46895 : H12AffineEnvironment.transform 17 23808 env46894 = env46895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23808 env46894 == env46895) = true)

theorem identity46895 : scanCanonicalize (H12AffineFastState.compose env46895 (packedSelected [2,3,5,6,11,12,14,16,19] rootPS)) = affineNative (2^(13+1) ^^^ 2128) := by decide +kernel

theorem selectedBound46895 : packedSelected [2,3,5,6,11,12,14,16,19] rootPS < 2^1333 := by decide +kernel

def env46896 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,2128,373,15627,2356,5456,1025,372,12345,15705,8297,15658,8193,64,2128,13672,3408,13609,9517,8281,257,7536,13688,16248]

theorem envBound46896 : H12AffineFastState.Bounded env46896 := by
  intro p hp
  have h : env46896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46895_46896 : H12AffineEnvironment.transform 13 2128 env46895 = env46896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2128 env46895 == env46896) = true)

theorem identity46896 : scanCanonicalize (H12AffineFastState.compose env46896 (packedSelected [0,1,2,4,6,7,8,9,10,14,15,17] rootPS)) = affineNative (2^(10+1) ^^^ 1125) := by decide +kernel

theorem selectedBound46896 : packedSelected [0,1,2,4,6,7,8,9,10,14,15,17] rootPS < 2^1333 := by decide +kernel

def env46897 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,4096,8192,1077,373,12654,1361,5456,1025,372,12345,12604,8297,12623,8193,64,1077,13672,309,13609,9517,8281,257,4373,13688,13085]

theorem envBound46897 : H12AffineFastState.Bounded env46897 := by
  intro p hp
  have h : env46897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46896_46897 : H12AffineEnvironment.transform 10 1125 env46896 = env46897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1125 env46896 == env46897) = true)

theorem identity46897 : scanCanonicalize (H12AffineFastState.compose env46897 (packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS)) = affineNative (2^(11+1) ^^^ 16) := by decide +kernel

theorem selectedBound46897 : packedSelected [0,2,3,4,5,6,7,9,10,11,12,14,15,16,18,20] rootPS < 2^1333 := by decide +kernel

def env46898 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1125,16,8192,1077,373,8574,1361,1344,1025,372,8233,8492,8297,8543,8193,64,1077,9592,309,9529,9517,8281,257,261,9576,8973]

theorem envBound46898 : H12AffineFastState.Bounded env46898 := by
  intro p hp
  have h : env46898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46897_46898 : H12AffineEnvironment.transform 11 16 env46897 = env46898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env46897 == env46898) = true)

theorem identity46898 : scanCanonicalize (H12AffineFastState.compose env46898 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 321) := by decide +kernel

theorem selectedBound46898 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46899 : List Nat := [2,4,8,16,32,64,9,256,512,321,292,16,8192,372,373,8574,16,1,320,372,8233,8492,8297,8543,8193,64,372,8249,309,8312,8300,8281,257,261,8233,8973]

theorem envBound46899 : H12AffineFastState.Bounded env46899 := by
  intro p hp
  have h : env46899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46898_46899 : H12AffineEnvironment.transform 9 321 env46898 = env46899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 321 env46898 == env46899) = true)

theorem identity46899 : scanCanonicalize (H12AffineFastState.compose env46899 (packedSelected [1,8,10] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound46899 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env46900 : List Nat := [2,4,8,16,32,64,9,117,512,52,81,16,8192,1,0,8203,16,1,53,1,8233,8281,8297,8234,8193,64,1,8249,64,8312,8300,8281,116,112,8233,8824]

theorem envBound46900 : H12AffineFastState.Bounded env46900 := by
  intro p hp
  have h : env46900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46899_46900 : H12AffineEnvironment.transform 7 117 env46899 = env46900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env46899 == env46900) = true)

theorem identity46900 : scanCanonicalize (H12AffineFastState.compose env46900 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound46900 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46901 : List Nat := [2,4,8,16,32,64,9,117,512,52,81,16,120,1,0,115,16,1,53,1,81,33,17,82,121,64,1,65,64,0,20,33,116,112,81,512]

theorem envBound46901 : H12AffineFastState.Bounded env46901 := by
  intro p hp
  have h : env46901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46900_46901 : H12AffineEnvironment.transform 12 120 env46900 = env46901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env46900 == env46901) = true)

theorem identity46901 : scanCanonicalize (H12AffineFastState.compose env46901 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound46901 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46902 : List Nat := [2,4,8,16,32,49,9,4,512,52,32,16,9,1,0,2,16,1,53,1,32,33,17,35,8,49,1,48,49,0,20,33,5,1,32,512]

theorem envBound46902 : H12AffineFastState.Bounded env46902 := by
  intro p hp
  have h : env46902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46901_46902 : H12AffineEnvironment.transform 5 49 env46901 = env46902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env46901 == env46902) = true)

theorem identity46902 : scanCanonicalize (H12AffineFastState.compose env46902 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound46902 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env46903 : List Nat := [2,4,8,16,9,24,9,4,512,29,9,16,9,1,0,2,16,1,28,1,9,8,17,10,8,24,1,25,24,0,20,8,5,1,9,512]

theorem envBound46903 : H12AffineFastState.Bounded env46903 := by
  intro p hp
  have h : env46903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46902_46903 : H12AffineEnvironment.transform 4 9 env46902 = env46903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env46902 == env46903) = true)

theorem identity46903 : scanCanonicalize (H12AffineFastState.compose env46903 (packedSelected [0,3] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound46903 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env46904 : List Nat := [2,4,8,16,9,24,9,4,3,29,9,16,9,1,0,2,16,1,28,1,9,8,17,10,8,24,1,25,24,0,20,8,5,1,9,3]

theorem envBound46904 : H12AffineFastState.Bounded env46904 := by
  intro p hp
  have h : env46904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46903_46904 : H12AffineEnvironment.transform 8 3 env46903 = env46904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env46903 == env46904) = true)

theorem identity46904 : scanCanonicalize (H12AffineFastState.compose env46904 (packedSelected [0,5] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound46904 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env46905 : List Nat := [2,4,0,16,1,16,1,4,3,21,1,16,1,1,0,2,16,1,20,1,1,0,17,2,0,16,1,17,16,0,20,0,5,1,1,3]

theorem envBound46905 : H12AffineFastState.Bounded env46905 := by
  intro p hp
  have h : env46905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46904_46905 : H12AffineEnvironment.transform 2 0 env46904 = env46905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env46904 == env46905) = true)

theorem identity46905 : scanCanonicalize (H12AffineFastState.compose env46905 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound46905 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46906 : List Nat := [2,4,0,6,1,6,1,4,3,3,1,6,1,1,0,2,6,1,2,1,1,0,7,2,0,6,1,7,6,0,2,0,5,1,1,3]

theorem envBound46906 : H12AffineFastState.Bounded env46906 := by
  intro p hp
  have h : env46906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46905_46906 : H12AffineEnvironment.transform 3 6 env46905 = env46906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env46905 == env46906) = true)

def env46907 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,97667,115151,17664,2363456,119043,329731,257,2199998,2191386,63188]

theorem envBound46907 : H12AffineFastState.Bounded env46907 := by
  intro p hp
  have h : env46907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46869_46907 : H12AffineEnvironment.transform 21 272513 env46869 = env46907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46869 == env46907) = true)

theorem identity46907 : scanCanonicalize (H12AffineFastState.compose env46907 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound46907 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46908 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,49169,262144,1025,32769,2097152,272513,2101328,2114883,8328,64,43356,5392,17664,2363456,1500,318684,257,2114913,2139333,63188]

theorem envBound46908 : H12AffineFastState.Bounded env46908 := by
  intro p hp
  have h : env46908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46907_46908 : H12AffineEnvironment.transform 15 54495 env46907 = env46908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env46907 == env46908) = true)

theorem identity46908 : scanCanonicalize (H12AffineFastState.compose env46908 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound46908 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env46909 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,13508,262144,1025,29908,2097152,272513,2101328,2114883,8328,64,23945,5392,17664,2363456,1500,272393,257,2114913,2117648,513]

theorem envBound46909 : H12AffineFastState.Bounded env46909 := by
  intro p hp
  have h : env46909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46908_46909 : H12AffineEnvironment.transform 14 29909 env46908 = env46909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env46908 == env46909) = true)

theorem identity46909 : scanCanonicalize (H12AffineFastState.compose env46909 (packedSelected [16,20] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound46909 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env46910 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,8202,13508,23668,1025,29908,2097152,29941,2101328,2114883,8328,64,23945,5392,17664,2116660,1500,29821,257,2114913,2117648,513]

theorem envBound46910 : H12AffineFastState.Bounded env46910 := by
  intro p hp
  have h : env46910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46909_46910 : H12AffineEnvironment.transform 17 23668 env46909 = env46910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env46909 == env46910) = true)

theorem identity46910 : scanCanonicalize (H12AffineFastState.compose env46910 (packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound46910 : packedSelected [1,2,5,6,8,12,15,17,24,38,41] rootPS < 2^1333 := by decide +kernel

def env46911 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8581,8202,13508,2340,1025,8580,2097152,8613,2101328,2101267,8328,64,2265,5392,4176,2103652,1500,8493,257,2101297,2098496,513]

theorem envBound46911 : H12AffineFastState.Bounded env46911 := by
  intro p hp
  have h : env46911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46910_46911 : H12AffineEnvironment.transform 13 5456 env46910 = env46911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env46910 == env46911) = true)

theorem identity46911 : scanCanonicalize (H12AffineFastState.compose env46911 (packedSelected [4,7,9,17,18,23,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46911 : packedSelected [4,7,9,17,18,23,27] rootPS < 2^1333 := by decide +kernel

def env46912 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5456,136,263,5577,2340,1025,137,2097152,168,2101328,2101267,389,64,2265,5392,4176,2103652,1500,32,257,2101297,2098496,513]

theorem envBound46912 : H12AffineFastState.Bounded env46912 := by
  intro p hp
  have h : env46912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46911_46912 : H12AffineEnvironment.transform 12 269 env46911 = env46912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46911 == env46912) = true)

theorem identity46912 : scanCanonicalize (H12AffineFastState.compose env46912 (packedSelected [3,4,5,9,10,14,16,17] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound46912 : packedSelected [3,4,5,9,10,14,16,17] rootPS < 2^1333 := by decide +kernel

def env46913 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,80,263,5393,2340,1025,81,2097152,112,2101328,2101267,349,64,2049,5392,4176,2103652,1284,32,257,2101297,2098496,513]

theorem envBound46913 : H12AffineFastState.Bounded env46913 := by
  intro p hp
  have h : env46913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46912_46913 : H12AffineEnvironment.transform 6 88 env46912 = env46913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env46912 == env46913) = true)

theorem identity46913 : scanCanonicalize (H12AffineFastState.compose env46913 (packedSelected [2,6] rootPS)) = affineNative (2^(20+1) ^^^ 4161) := by decide +kernel

theorem selectedBound46913 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46914 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,269,5456,80,263,5393,2340,1025,81,4161,112,17,82,349,64,2049,5392,4176,2341,1284,32,257,112,5377,513]

theorem envBound46914 : H12AffineFastState.Bounded env46914 := by
  intro p hp
  have h : env46914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46913_46914 : H12AffineEnvironment.transform 20 4161 env46913 = env46914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46913 == env46914) = true)

theorem identity46914 : scanCanonicalize (H12AffineFastState.compose env46914 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound46914 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env46915 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,1141,269,293,80,263,356,2340,1025,81,1076,112,17,82,349,64,2049,357,1061,2341,1284,32,257,112,372,513]

theorem envBound46915 : H12AffineFastState.Bounded env46915 := by
  intro p hp
  have h : env46915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46914_46915 : H12AffineEnvironment.transform 11 1141 env46914 = env46915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env46914 == env46915) = true)

theorem identity46915 : scanCanonicalize (H12AffineFastState.compose env46915 (packedSelected [1,2,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1344) := by decide +kernel

theorem selectedBound46915 : packedSelected [1,2,7,8,9] rootPS < 2^1333 := by decide +kernel

def env46916 : List Nat := [2,4,8,16,32,64,88,256,512,1024,1344,1141,269,293,80,263,356,1124,1025,81,1076,112,17,82,349,64,1345,357,1061,1125,1284,32,257,112,372,513]

theorem envBound46916 : H12AffineFastState.Bounded env46916 := by
  intro p hp
  have h : env46916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46915_46916 : H12AffineEnvironment.transform 10 1344 env46915 = env46916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1344 env46915 == env46916) = true)

theorem identity46916 : scanCanonicalize (H12AffineFastState.compose env46916 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound46916 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env46917 : List Nat := [2,4,8,16,32,64,88,117,512,1024,1077,1141,120,80,80,114,17,1124,1025,81,1076,112,17,82,40,64,1076,16,1061,1125,1137,32,116,112,1,513]

theorem envBound46917 : H12AffineFastState.Bounded env46917 := by
  intro p hp
  have h : env46917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46916_46917 : H12AffineEnvironment.transform 7 117 env46916 = env46917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env46916 == env46917) = true)

def env46918 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,4194304,2101329,2114883,8328,64,4543747,115151,17665,2363457,119042,4268162,257,2199999,2191387,63189]

theorem envBound46918 : H12AffineFastState.Bounded env46918 := by
  intro p hp
  have h : env46918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46868_46918 : H12AffineEnvironment.transform 22 2101329 env46868 = env46918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env46868 == env46918) = true)

def env46919 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272512,2101329,2114883,8328,64,97667,115151,17665,2363457,119042,329730,257,2199999,2191387,63189]

theorem envBound46919 : H12AffineFastState.Bounded env46919 := by
  intro p hp
  have h : env46919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46918_46919 : H12AffineEnvironment.transform 21 272512 env46918 = env46919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env46918 == env46919) = true)

theorem identity46919 : scanCanonicalize (H12AffineFastState.compose env46919 (packedSelected [21] rootPS)) = affineNative (2^(20+1) ^^^ 77898) := by decide +kernel

theorem selectedBound46919 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46920 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,77898,272512,73755,95497,8328,64,97667,115151,17665,335883,119042,329730,257,41461,16465,63189]

theorem envBound46920 : H12AffineFastState.Bounded env46920 := by
  intro p hp
  have h : env46920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46919_46920 : H12AffineEnvironment.transform 20 77898 env46919 = env46920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 77898 env46919 == env46920) = true)

def env46921 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10400,1025,32769,77898,32,73755,95497,8328,64,97667,115151,17665,67755,119042,73890,257,41461,16465,63189]

theorem envBound46921 : H12AffineFastState.Bounded env46921 := by
  intro p hp
  have h : env46921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46920_46921 : H12AffineEnvironment.transform 17 10400 env46920 = env46921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env46920 == env46921) = true)

theorem identity46921 : scanCanonicalize (H12AffineFastState.compose env46921 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46921 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env46922 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,32768,65536,49169,2184,1025,32769,69730,32,65587,87329,160,64,89515,115151,17665,67755,119042,65674,257,33245,16465,55037]

theorem envBound46922 : H12AffineFastState.Bounded env46922 := by
  intro p hp
  have h : env46922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46921_46922 : H12AffineEnvironment.transform 12 40 env46921 = env46922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46921 == env46922) = true)

theorem identity46922 : scanCanonicalize (H12AffineFastState.compose env46922 (packedSelected [1,2,4,5,6,7,8,11,14,16,18,19,20,22,24,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound46922 : packedSelected [1,2,4,5,6,7,8,11,14,16,18,19,20,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env46923 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,5236,32768,65536,37989,2184,1025,32769,69730,32,65587,65877,160,64,68063,103867,4469,67755,99702,65674,257,33245,5157,33417]

theorem envBound46923 : H12AffineFastState.Bounded env46923 := by
  intro p hp
  have h : env46923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46922_46923 : H12AffineEnvironment.transform 13 5236 env46922 = env46923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env46922 == env46923) = true)

theorem identity46923 : scanCanonicalize (H12AffineFastState.compose env46923 (packedSelected [0,1,4,5,7,10,12,15,16,17,18,19,20,22,23,24,26,28] rootPS)) = affineNative (2^(7+1) ^^^ 252) := by decide +kernel

theorem selectedBound46923 : packedSelected [0,1,4,5,7,10,12,15,16,17,18,19,20,22,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env46924 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,32768,65536,37989,2184,1025,32769,69730,32,65587,65705,160,64,67619,103495,4233,67755,99466,65674,253,32801,5157,33417]

theorem envBound46924 : H12AffineFastState.Bounded env46924 := by
  intro p hp
  have h : env46924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46923_46924 : H12AffineEnvironment.transform 7 252 env46923 = env46924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env46923 == env46924) = true)

theorem identity46924 : scanCanonicalize (H12AffineFastState.compose env46924 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 171) := by decide +kernel

theorem selectedBound46924 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46925 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,32768,171,37989,2184,1025,32769,4297,32,152,2,160,64,2184,38124,4233,2048,33825,33,253,32801,5157,33417]

theorem envBound46925 : H12AffineFastState.Bounded env46925 := by
  intro p hp
  have h : env46925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46924_46925 : H12AffineEnvironment.transform 15 171 env46924 = env46925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 171 env46924 == env46925) = true)

theorem identity46925 : scanCanonicalize (H12AffineFastState.compose env46925 (packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound46925 : packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env46926 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,40,5236,137,171,5356,2184,1025,136,4297,32,152,2,160,64,2184,5221,4233,2048,1192,33,253,168,5157,512]

theorem envBound46926 : H12AffineFastState.Bounded env46926 := by
  intro p hp
  have h : env46926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46925_46926 : H12AffineEnvironment.transform 14 137 env46925 = env46926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env46925 == env46926) = true)

theorem identity46926 : scanCanonicalize (H12AffineFastState.compose env46926 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound46926 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46927 : List Nat := [2,4,8,16,0,64,128,220,512,1024,2048,4096,8,5204,137,139,5324,2184,1025,136,4297,0,152,2,128,64,2184,5189,4233,2048,1160,1,221,136,5125,512]

theorem envBound46927 : H12AffineFastState.Bounded env46927 := by
  intro p hp
  have h : env46927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46926_46927 : H12AffineEnvironment.transform 4 0 env46926 = env46927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env46926 == env46927) = true)

theorem identity46927 : scanCanonicalize (H12AffineFastState.compose env46927 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(9+1) ^^^ 205) := by decide +kernel

theorem selectedBound46927 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env46928 : List Nat := [2,4,8,16,0,64,128,220,512,205,2048,4096,8,4249,137,139,4097,2184,204,136,4297,0,152,2,128,64,2184,4232,4233,2048,69,1,221,136,4296,512]

theorem envBound46928 : H12AffineFastState.Bounded env46928 := by
  intro p hp
  have h : env46928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46927_46928 : H12AffineEnvironment.transform 9 205 env46927 = env46928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 205 env46927 == env46928) = true)

theorem identity46928 : scanCanonicalize (H12AffineFastState.compose env46928 (packedSelected [2,4,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46928 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env46929 : List Nat := [2,4,8,16,0,64,8,84,512,69,2048,4096,8,4113,1,3,4097,2048,68,0,4161,0,16,2,8,64,2048,4096,4097,2048,69,1,85,0,4160,512]

theorem envBound46929 : H12AffineFastState.Bounded env46929 := by
  intro p hp
  have h : env46929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46928_46929 : H12AffineEnvironment.transform 6 8 env46928 = env46929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46928 == env46929) = true)

theorem identity46929 : scanCanonicalize (H12AffineFastState.compose env46929 (packedSelected [1,3] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46929 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46930 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,4096,8,4113,1,3,4097,2048,20,0,4113,0,16,2,8,16,2048,4096,4097,2048,21,1,5,0,4112,512]

theorem envBound46930 : H12AffineFastState.Bounded env46930 := by
  intro p hp
  have h : env46930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46929_46930 : H12AffineEnvironment.transform 5 16 env46929 = env46930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46929 == env46930) = true)

theorem identity46930 : scanCanonicalize (H12AffineFastState.compose env46930 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound46930 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46931 : List Nat := [2,4,8,16,0,16,8,4,512,21,2048,2065,8,2048,1,3,2064,2048,20,0,2048,0,16,2,8,16,2048,2065,2064,2048,21,1,5,0,2049,512]

theorem envBound46931 : H12AffineFastState.Bounded env46931 := by
  intro p hp
  have h : env46931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46930_46931 : H12AffineEnvironment.transform 11 2065 env46930 = env46931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env46930 == env46931) = true)

theorem identity46931 : scanCanonicalize (H12AffineFastState.compose env46931 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 5) := by decide +kernel

theorem selectedBound46931 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46932 : List Nat := [2,4,8,16,0,16,8,4,512,21,5,20,8,5,1,3,21,5,20,0,5,0,16,2,8,16,5,20,21,5,21,1,5,0,4,512]

theorem envBound46932 : H12AffineFastState.Bounded env46932 := by
  intro p hp
  have h : env46932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46931_46932 : H12AffineEnvironment.transform 10 5 env46931 = env46932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 5 env46931 == env46932) = true)

def env46933 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10401,1025,32769,77898,33,73755,95497,8328,64,97667,115151,17665,67754,119042,73891,257,41461,16465,63189]

theorem envBound46933 : H12AffineFastState.Bounded env46933 := by
  intro p hp
  have h : env46933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46920_46933 : H12AffineEnvironment.transform 17 10401 env46920 = env46933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env46920 == env46933) = true)

theorem identity46933 : scanCanonicalize (H12AffineFastState.compose env46933 (packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS)) = affineNative (2^(15+1) ^^^ 398) := by decide +kernel

theorem selectedBound46933 : packedSelected [1,2,3,5,6,9,12,15,18,19,22,28,32,35] rootPS < 2^1333 := by decide +kernel

def env46934 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,398,49169,10401,1025,32769,12740,33,8597,29831,8328,64,31757,49217,17665,2340,53388,8493,257,41461,16465,63189]

theorem envBound46934 : H12AffineFastState.Bounded env46934 := by
  intro p hp
  have h : env46934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46933_46934 : H12AffineEnvironment.transform 15 398 env46933 = env46934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 398 env46933 == env46934) = true)

theorem identity46934 : scanCanonicalize (H12AffineFastState.compose env46934 (packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound46934 : packedSelected [2,3,4,5,6,7,10,11,12,14,15,19,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env46935 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,16384,32768,398,49169,2476,1025,32769,4297,33,152,21898,389,64,23808,49217,17665,2340,53388,32,257,33016,16465,55256]

theorem envBound46935 : H12AffineFastState.Bounded env46935 := by
  intro p hp
  have h : env46935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46934_46935 : H12AffineEnvironment.transform 12 269 env46934 = env46935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env46934 == env46935) = true)

theorem identity46935 : scanCanonicalize (H12AffineFastState.compose env46935 (packedSelected [16,17,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound46935 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env46936 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,16384,32768,343,49169,2421,1025,32769,4112,33,65,21843,348,64,23808,49217,17665,2340,53333,32,257,32801,16465,55041]

theorem envBound46936 : H12AffineFastState.Bounded env46936 := by
  intro p hp
  have h : env46936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46935_46936 : H12AffineEnvironment.transform 6 89 env46935 = env46936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env46935 == env46936) = true)

theorem identity46936 : scanCanonicalize (H12AffineFastState.compose env46936 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound46936 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46937 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5457,32768,343,38208,2421,1025,32769,4112,33,65,2,348,64,2129,38160,4176,2340,34052,32,257,32801,5376,33360]

theorem envBound46937 : H12AffineFastState.Bounded env46937 := by
  intro p hp
  have h : env46937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46936_46937 : H12AffineEnvironment.transform 13 5457 env46936 = env46937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env46936 == env46937) = true)

theorem identity46937 : scanCanonicalize (H12AffineFastState.compose env46937 (packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 372) := by decide +kernel

theorem selectedBound46937 : packedSelected [2,3,4,5,6,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env46938 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,269,5457,372,343,5172,2421,1025,373,4112,33,65,2,348,64,2129,5220,4176,2340,1136,32,257,341,5376,804]

theorem envBound46938 : H12AffineFastState.Bounded env46938 := by
  intro p hp
  have h : env46938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46937_46938 : H12AffineEnvironment.transform 14 372 env46937 = env46938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 372 env46937 == env46938) = true)

theorem identity46938 : scanCanonicalize (H12AffineFastState.compose env46938 (packedSelected [2,4,6,9,14] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound46938 : packedSelected [2,4,6,9,14] rootPS < 2^1333 := by decide +kernel

def env46939 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5376,293,262,5172,2340,1025,292,4112,33,16,2,269,17,2048,5173,4097,2340,1057,32,257,260,5376,804]

theorem envBound46939 : H12AffineFastState.Bounded env46939 := by
  intro p hp
  have h : env46939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46938_46939 : H12AffineEnvironment.transform 5 17 env46938 = env46939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env46938 == env46939) = true)

theorem identity46939 : scanCanonicalize (H12AffineFastState.compose env46939 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound46939 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env46940 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,40,5157,0,35,5172,2049,1025,1,4112,33,16,2,40,17,2048,5173,4097,2049,1057,32,36,33,5157,513]

theorem envBound46940 : H12AffineFastState.Bounded env46940 := by
  intro p hp
  have h : env46940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46939_46940 : H12AffineEnvironment.transform 7 37 env46939 = env46940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env46939 == env46940) = true)

def env46941 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,40,1045,0,35,1028,2049,1025,1,32,33,16,2,40,17,2048,1029,49,2049,1057,32,36,33,1045,513]

theorem envBound46941 : H12AffineFastState.Bounded env46941 := by
  intro p hp
  have h : env46941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46940_46941 : H12AffineEnvironment.transform 11 48 env46940 = env46941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env46940 == env46941) = true)

theorem identity46941 : scanCanonicalize (H12AffineFastState.compose env46941 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound46941 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46942 : List Nat := [2,4,8,16,32,17,8,37,512,549,2048,48,40,560,0,35,545,2049,548,1,32,33,16,2,40,17,2048,544,49,2049,516,32,36,33,560,513]

theorem envBound46942 : H12AffineFastState.Bounded env46942 := by
  intro p hp
  have h : env46942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46941_46942 : H12AffineEnvironment.transform 9 549 env46941 = env46942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env46941 == env46942) = true)

def env46943 : List Nat := [2,4,8,16,32,17,8,37,16,53,2048,48,40,32,0,35,49,2049,52,1,32,33,16,2,40,17,2048,48,49,2049,20,32,36,33,32,17]

theorem envBound46943 : H12AffineFastState.Bounded env46943 := by
  intro p hp
  have h : env46943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46942_46943 : H12AffineEnvironment.transform 8 16 env46942 = env46943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env46942 == env46943) = true)

theorem identity46943 : scanCanonicalize (H12AffineFastState.compose env46943 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound46943 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46944 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,48,40,32,0,35,49,33,52,1,32,33,16,2,40,17,32,48,49,33,20,32,36,33,32,17]

theorem envBound46944 : H12AffineFastState.Bounded env46944 := by
  intro p hp
  have h : env46944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46943_46944 : H12AffineEnvironment.transform 10 32 env46943 = env46944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env46943 == env46944) = true)

def leafEnv46944 : List Nat := [2,4,8,16,32,17,8,37,16,53,32,48,40,32,0,35,49,33,52,1,32,33,16,2,21,40,1,17,32,48,49,33,20,32,36,33,5,35,32,17,1,32,0]

def active46944 : List Nat := [0,1,2,3,4]

def tree46944 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46944 : H12WitnessSearch.Good tree46944 := H12GlobalWitnessIndex.good

theorem leafIdentity46944 : H12AffineFastState.composeSystem env46944 rootObs = leafEnv46944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46944 rootObs == leafEnv46944) = true)

theorem terminalChecked46944 : H12PackedTerminal.terminalCheckFast leafEnv46944 active46944 tree46944 = true := by decide +kernel

def env46945 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,48,40,33,0,35,48,2049,53,1,32,33,16,2,40,17,2048,49,49,2049,21,32,36,33,33,16]

theorem envBound46945 : H12AffineFastState.Bounded env46945 := by
  intro p hp
  have h : env46945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46942_46945 : H12AffineEnvironment.transform 8 17 env46942 = env46945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46942 == env46945) = true)

theorem identity46945 : scanCanonicalize (H12AffineFastState.compose env46945 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound46945 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46946 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,40,33,0,35,48,27,53,1,32,33,16,2,40,17,26,49,49,27,21,32,36,33,33,16]

theorem envBound46946 : H12AffineFastState.Bounded env46946 := by
  intro p hp
  have h : env46946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46945_46946 : H12AffineEnvironment.transform 10 26 env46945 = env46946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env46945 == env46946) = true)

def leafEnv46946 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,48,40,33,0,35,48,27,53,1,32,33,16,2,20,40,1,17,26,49,49,27,21,32,36,33,5,35,33,16,1,32,0]

def active46946 : List Nat := [0,1,2,3,4]

def tree46946 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46946 : H12WitnessSearch.Good tree46946 := H12GlobalWitnessIndex.good

theorem leafIdentity46946 : H12AffineFastState.composeSystem env46946 rootObs = leafEnv46946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46946 rootObs == leafEnv46946) = true)

theorem terminalChecked46946 : H12PackedTerminal.terminalCheckFast leafEnv46946 active46946 tree46946 = true := by decide +kernel

def env46947 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,40,1044,0,35,1029,2049,1025,1,33,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,513]

theorem envBound46947 : H12AffineFastState.Bounded env46947 := by
  intro p hp
  have h : env46947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46940_46947 : H12AffineEnvironment.transform 11 49 env46940 = env46947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46940 == env46947) = true)

theorem identity46947 : scanCanonicalize (H12AffineFastState.compose env46947 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound46947 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env46948 : List Nat := [2,4,8,16,32,17,8,37,17,1024,2048,49,40,1044,0,35,1029,2049,1025,1,33,33,16,2,40,17,2048,1028,48,2049,1057,32,36,33,1044,16]

theorem envBound46948 : H12AffineFastState.Bounded env46948 := by
  intro p hp
  have h : env46948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46947_46948 : H12AffineEnvironment.transform 8 17 env46947 = env46948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env46947 == env46948) = true)

def env46949 : List Nat := [2,4,8,16,32,17,8,37,17,52,2048,49,40,32,0,35,49,2049,53,1,33,33,16,2,40,17,2048,48,48,2049,21,32,36,33,32,16]

theorem envBound46949 : H12AffineFastState.Bounded env46949 := by
  intro p hp
  have h : env46949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46948_46949 : H12AffineEnvironment.transform 9 52 env46948 = env46949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env46948 == env46949) = true)

theorem identity46949 : scanCanonicalize (H12AffineFastState.compose env46949 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 26) := by decide +kernel

theorem selectedBound46949 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46950 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,40,32,0,35,49,27,53,1,33,33,16,2,40,17,26,48,48,27,21,32,36,33,32,16]

theorem envBound46950 : H12AffineFastState.Bounded env46950 := by
  intro p hp
  have h : env46950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46949_46950 : H12AffineEnvironment.transform 10 26 env46949 = env46950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 26 env46949 == env46950) = true)

def leafEnv46950 : List Nat := [2,4,8,16,32,17,8,37,17,52,26,49,40,32,0,35,49,27,53,1,33,33,16,2,20,40,1,17,26,48,48,27,21,32,36,33,5,35,32,16,1,33,0]

def active46950 : List Nat := [0,1,2,3,4]

def tree46950 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46950 : H12WitnessSearch.Good tree46950 := H12GlobalWitnessIndex.good

theorem leafIdentity46950 : H12AffineFastState.composeSystem env46950 rootObs = leafEnv46950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46950 rootObs == leafEnv46950) = true)

theorem terminalChecked46950 : H12PackedTerminal.terminalCheckFast leafEnv46950 active46950 tree46950 = true := by decide +kernel

def env46951 : List Nat := [2,4,8,16,32,17,8,37,17,53,2048,49,40,33,0,35,48,2049,52,1,33,33,16,2,40,17,2048,49,48,2049,20,32,36,33,33,16]

theorem envBound46951 : H12AffineFastState.Bounded env46951 := by
  intro p hp
  have h : env46951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46948_46951 : H12AffineEnvironment.transform 9 53 env46948 = env46951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env46948 == env46951) = true)

theorem identity46951 : scanCanonicalize (H12AffineFastState.compose env46951 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound46951 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env46952 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,49,40,33,0,35,48,32,52,1,33,33,16,2,40,17,33,49,48,32,20,32,36,33,33,16]

theorem envBound46952 : H12AffineFastState.Bounded env46952 := by
  intro p hp
  have h : env46952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46951_46952 : H12AffineEnvironment.transform 10 33 env46951 = env46952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env46951 == env46952) = true)

def leafEnv46952 : List Nat := [2,4,8,16,32,17,8,37,17,53,33,49,40,33,0,35,48,32,52,1,33,33,16,2,21,40,1,17,33,49,48,32,20,32,36,33,5,35,33,16,1,33,0]

def active46952 : List Nat := [0,1,2,3,4]

def tree46952 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood46952 : H12WitnessSearch.Good tree46952 := H12GlobalWitnessIndex.good

theorem leafIdentity46952 : H12AffineFastState.composeSystem env46952 rootObs = leafEnv46952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env46952 rootObs == leafEnv46952) = true)

theorem terminalChecked46952 : H12PackedTerminal.terminalCheckFast leafEnv46952 active46952 tree46952 = true := by decide +kernel

def env46953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,97666,115151,17665,2363457,119042,329731,257,2199999,2191387,63189]

theorem envBound46953 : H12AffineFastState.Bounded env46953 := by
  intro p hp
  have h : env46953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46918_46953 : H12AffineEnvironment.transform 21 272513 env46918 = env46953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env46918 == env46953) = true)

theorem identity46953 : scanCanonicalize (H12AffineFastState.compose env46953 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound46953 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272513,2101329,2114883,8328,64,23944,57797,17665,2363457,61704,272393,257,2142645,2117649,63189]

theorem envBound46954 : H12AffineFastState.Bounded env46954 := by
  intro p hp
  have h : env46954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46953_46954 : H12AffineEnvironment.transform 15 8202 env46953 = env46954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env46953 == env46954) = true)

def env46955 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272393,2101329,2114883,8192,64,23808,57677,17665,2363457,61704,272393,257,2142525,2117649,63069]

theorem envBound46955 : H12AffineFastState.Bounded env46955 := by
  intro p hp
  have h : env46955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46954_46955 : H12AffineEnvironment.transform 6 8 env46954 = env46955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46954 == env46955) = true)

theorem identity46955 : scanCanonicalize (H12AffineFastState.compose env46955 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound46955 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46956 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46157,262144,1025,32769,2097152,272393,2101329,2109727,8192,64,10588,38161,12637,2363457,34132,272393,257,2142525,2106445,33281]

theorem envBound46956 : H12AffineFastState.Bounded env46956 := by
  intro p hp
  have h : env46956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46955_46956 : H12AffineEnvironment.transform 13 13404 env46955 = env46956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env46955 == env46956) = true)

theorem identity46956 : scanCanonicalize (H12AffineFastState.compose env46956 (packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS)) = affineNative (2^(20+1) ^^^ 268596) := by decide +kernel

theorem selectedBound46956 : packedSelected [1,3,4,5,9,10,12,14,17,19,20,28,31,38] rootPS < 2^1333 := by decide +kernel

def env46957 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46157,262144,1025,32769,268596,272393,264549,272427,8192,64,10588,38161,12637,2421,34132,272393,257,305161,277881,33281]

theorem envBound46957 : H12AffineFastState.Bounded env46957 := by
  intro p hp
  have h : env46957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46956_46957 : H12AffineEnvironment.transform 20 268596 env46956 = env46957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268596 env46956 == env46957) = true)

theorem identity46957 : scanCanonicalize (H12AffineFastState.compose env46957 (packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS)) = affineNative (2^(17+1) ^^^ 34816) := by decide +kernel

theorem selectedBound46957 : packedSelected [2,3,4,5,9,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env46958 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,8202,46157,34816,1025,32769,37172,40969,33125,41003,8192,64,10588,38161,12637,2421,34132,40969,257,8201,46457,33281]

theorem envBound46958 : H12AffineFastState.Bounded env46958 := by
  intro p hp
  have h : env46958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46957_46958 : H12AffineEnvironment.transform 17 34816 env46957 = env46958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 34816 env46957 == env46958) = true)

theorem identity46958 : scanCanonicalize (H12AffineFastState.compose env46958 (packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46958 : packedSelected [0,3,4,5,6,7,9,10,12,15,17] rootPS < 2^1333 := by decide +kernel

def env46959 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,0,8202,13389,2048,1025,1,4404,8201,357,8235,8192,64,10588,5393,12637,2421,1364,8201,257,8201,13689,513]

theorem envBound46959 : H12AffineFastState.Bounded env46959 := by
  intro p hp
  have h : env46959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46958_46959 : H12AffineEnvironment.transform 14 0 env46958 = env46959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46958 == env46959) = true)

theorem identity46959 : scanCanonicalize (H12AffineFastState.compose env46959 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound46959 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46960 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,40,5236,0,34,5221,2048,1025,1,4404,33,357,3,40,64,2420,5393,4469,2421,1364,33,257,33,5457,513]

theorem envBound46960 : H12AffineFastState.Bounded env46960 := by
  intro p hp
  have h : env46960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46959_46960 : H12AffineEnvironment.transform 12 40 env46959 = env46960 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env46959 == env46960) = true)

theorem identity46960 : scanCanonicalize (H12AffineFastState.compose env46960 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound46960 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env46961 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,4096,40,4453,0,34,4468,2048,272,1,4404,33,357,3,40,64,2420,4096,4469,2421,69,33,257,33,4160,513]

theorem envBound46961 : H12AffineFastState.Bounded env46961 := by
  intro p hp
  have h : env46961.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46960_46961 : H12AffineEnvironment.transform 9 273 env46960 = env46961 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env46960 == env46961) = true)

theorem identity46961 : scanCanonicalize (H12AffineFastState.compose env46961 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 315) := by decide +kernel

theorem selectedBound46961 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env46962 : List Nat := [2,4,8,16,32,64,8,256,512,273,2048,315,40,94,0,34,79,2048,272,1,15,33,357,3,40,64,2420,315,78,2421,69,33,257,33,379,513]

theorem envBound46962 : H12AffineFastState.Bounded env46962 := by
  intro p hp
  have h : env46962.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46961_46962 : H12AffineEnvironment.transform 11 315 env46961 = env46962 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 315 env46961 == env46962) = true)

theorem identity46962 : scanCanonicalize (H12AffineFastState.compose env46962 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 14) := by decide +kernel

theorem selectedBound46962 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46963 : List Nat := [2,4,8,16,32,64,8,256,512,273,14,315,40,94,0,34,79,14,272,1,15,33,357,3,40,64,378,315,78,379,69,33,257,33,379,513]

theorem envBound46963 : H12AffineFastState.Bounded env46963 := by
  intro p hp
  have h : env46963.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46962_46963 : H12AffineEnvironment.transform 10 14 env46962 = env46963 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 14 env46962 == env46963) = true)

def env46964 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,2097152,272392,2101329,2114883,8193,64,23809,57676,17665,2363457,61704,272393,257,2142524,2117649,63068]

theorem envBound46964 : H12AffineFastState.Bounded env46964 := by
  intro p hp
  have h : env46964.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46954_46964 : H12AffineEnvironment.transform 6 9 env46954 = env46964 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env46954 == env46964) = true)

theorem identity46964 : scanCanonicalize (H12AffineFastState.compose env46964 (packedSelected [0,4,7,12,15,22,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 17728) := by decide +kernel

theorem selectedBound46964 : packedSelected [0,4,7,12,15,22,38,41] rootPS < 2^1333 := by decide +kernel

def env46965 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,49169,262144,1025,32769,17728,272392,21777,3,8193,64,23809,57676,17665,283905,61704,272393,257,62588,5457,63068]

theorem envBound46965 : H12AffineFastState.Bounded env46965 := by
  intro p hp
  have h : env46965.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46964_46965 : H12AffineEnvironment.transform 20 17728 env46964 = env46965 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17728 env46964 == env46965) = true)

theorem identity46965 : scanCanonicalize (H12AffineFastState.compose env46965 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound46965 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env46966 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,0,8202,16401,262144,1025,1,17728,272392,21777,3,8193,64,23809,24908,17665,283905,28936,272393,257,29820,5457,30300]

theorem envBound46966 : H12AffineFastState.Bounded env46966 := by
  intro p hp
  have h : env46966.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46965_46966 : H12AffineEnvironment.transform 14 0 env46965 = env46966 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env46965 == env46966) = true)

theorem identity46966 : scanCanonicalize (H12AffineFastState.compose env46966 (packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound46966 : packedSelected [0,1,3,5,6,7,8,10,14,19,20] rootPS < 2^1333 := by decide +kernel

def env46967 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8202,13389,262144,1025,1,12572,272392,8525,3,8193,64,10589,5392,12637,270685,1364,272393,257,32,5457,512]

theorem envBound46967 : H12AffineFastState.Bounded env46967 := by
  intro p hp
  have h : env46967.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46966_46967 : H12AffineEnvironment.transform 13 13404 env46966 = env46967 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env46966 == env46967) = true)

theorem identity46967 : scanCanonicalize (H12AffineFastState.compose env46967 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(17+1) ^^^ 10589) := by decide +kernel

theorem selectedBound46967 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env46968 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,0,8202,13389,10589,1025,1,12572,341,8525,3,8193,64,10589,5392,12637,2048,1364,340,257,32,5457,512]

theorem envBound46968 : H12AffineFastState.Bounded env46968 := by
  intro p hp
  have h : env46968.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46967_46968 : H12AffineEnvironment.transform 17 10589 env46967 = env46968 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10589 env46967 == env46968) = true)

theorem identity46968 : scanCanonicalize (H12AffineFastState.compose env46968 (packedSelected [6,14] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound46968 : packedSelected [6,14] rootPS < 2^1333 := by decide +kernel

def env46969 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8,5204,0,2,5189,2389,1025,1,4372,341,325,3,9,64,2389,5392,4437,2048,1364,340,257,32,5457,512]

theorem envBound46969 : H12AffineFastState.Bounded env46969 := by
  intro p hp
  have h : env46969.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46968_46969 : H12AffineEnvironment.transform 12 8 env46968 = env46969 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env46968 == env46969) = true)

theorem identity46969 : scanCanonicalize (H12AffineFastState.compose env46969 (packedSelected [2,6,11,18] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound46969 : packedSelected [2,6,11,18] rootPS < 2^1333 := by decide +kernel

def env46970 : List Nat := [2,4,8,16,32,64,9,84,512,1024,2048,4096,8,5204,0,2,5189,2049,1025,1,4160,1,17,3,9,64,2049,5188,4097,2048,1024,0,85,32,5125,512]

theorem envBound46970 : H12AffineFastState.Bounded env46970 := by
  intro p hp
  have h : env46970.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46969_46970 : H12AffineEnvironment.transform 7 84 env46969 = env46970 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env46969 == env46970) = true)

theorem identity46970 : scanCanonicalize (H12AffineFastState.compose env46970 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound46970 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46971 : List Nat := [2,4,8,16,32,64,9,84,512,68,2048,4096,8,4112,0,2,4097,2049,69,1,4160,1,17,3,9,64,2049,4096,4097,2048,68,0,85,32,4161,512]

theorem envBound46971 : H12AffineFastState.Bounded env46971 := by
  intro p hp
  have h : env46971.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46970_46971 : H12AffineEnvironment.transform 9 68 env46970 = env46971 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env46970 == env46971) = true)

theorem identity46971 : scanCanonicalize (H12AffineFastState.compose env46971 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 49) := by decide +kernel

theorem selectedBound46971 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46972 : List Nat := [2,4,8,16,32,64,9,84,512,68,2048,49,8,33,0,2,48,2049,69,1,113,1,17,3,9,64,2049,49,48,2048,68,0,85,32,112,512]

theorem envBound46972 : H12AffineFastState.Bounded env46972 := by
  intro p hp
  have h : env46972.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46971_46972 : H12AffineEnvironment.transform 11 49 env46971 = env46972 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env46971 == env46972) = true)

theorem identity46972 : scanCanonicalize (H12AffineFastState.compose env46972 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 577) := by decide +kernel

theorem selectedBound46972 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env46973 : List Nat := [2,4,8,16,32,64,9,84,512,68,577,49,8,33,0,2,48,576,69,1,113,1,17,3,9,64,576,49,48,577,68,0,85,32,112,512]

theorem envBound46973 : H12AffineFastState.Bounded env46973 := by
  intro p hp
  have h : env46973.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46972_46973 : H12AffineEnvironment.transform 10 577 env46972 = env46973 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 577 env46972 == env46973) = true)

theorem identity46973 : scanCanonicalize (H12AffineFastState.compose env46973 (packedSelected [5] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound46973 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env46974 : List Nat := [2,4,7,16,32,64,6,84,512,68,577,49,7,33,0,2,48,576,69,1,113,1,17,3,6,64,576,49,48,577,68,0,85,32,112,512]

theorem envBound46974 : H12AffineFastState.Bounded env46974 := by
  intro p hp
  have h : env46974.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46973_46974 : H12AffineEnvironment.transform 2 7 env46973 = env46974 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env46973 == env46974) = true)

def env46975 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,134217728,19497101,10507601,155254785,25265169,145662400,525568,140903597,27337993,25733062]

theorem envBound46975 : H12AffineFastState.Bounded env46975 := by
  intro p hp
  have h : env46975.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46282_46975 : H12AffineEnvironment.transform 25 65 env46282 = env46975 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 65 env46282 == env46975) = true)

def env46976 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393344,19497101,10507601,9356289,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound46976 : H12AffineFastState.Bounded env46976 := by
  intro p hp
  have h : env46976.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46975_46976 : H12AffineEnvironment.transform 26 30393344 env46975 = env46976 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env46975 == env46976) = true)

def env46977 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound46977 : H12AffineFastState.Bounded env46977 := by
  intro p hp
  have h : env46977.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46976_46977 : H12AffineEnvironment.transform 18 1024 env46976 = env46977 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env46976 == env46977) = true)

theorem identity46977 : scanCanonicalize (H12AffineFastState.compose env46977 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 247859) := by decide +kernel

theorem selectedBound46977 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env46978 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,2097152,4194304,8388608,16777216,8328,65,29362227,18973837,10507601,8456242,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound46978 : H12AffineFastState.Bounded env46978 := by
  intro p hp
  have h : env46978.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46977_46978 : H12AffineEnvironment.transform 17 247859 env46977 = env46978 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247859 env46977 == env46978) = true)

def env46979 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,2097152,4194304,8388608,2199964,8328,65,14784943,5393,10507601,8456242,10491277,4256860,256,8410417,8434837,10564186]

theorem envBound46979 : H12AffineFastState.Bounded env46979 := by
  intro p hp
  have h : env46979.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46978_46979 : H12AffineEnvironment.transform 23 2199964 env46978 = env46979 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199964 env46978 == env46979) = true)

def env46980 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,8388608,98780,8328,65,12683759,5393,8406289,8456242,8390093,4256860,256,8410417,8434837,8462874]

theorem envBound46980 : H12AffineFastState.Bounded env46980 := by
  intro p hp
  have h : env46980.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46979_46980 : H12AffineEnvironment.transform 20 4160 env46979 = env46980 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env46979 == env46980) = true)

def env46981 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,16,98780,8328,65,4295167,5393,17665,67618,1501,4256860,256,21793,46213,74250]

theorem envBound46981 : H12AffineFastState.Bounded env46981 := by
  intro p hp
  have h : env46981.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46980_46981 : H12AffineEnvironment.transform 22 16 env46980 = env46981 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env46980 == env46981) = true)

theorem identity46981 : scanCanonicalize (H12AffineFastState.compose env46981 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound46981 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env46982 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,212199,1024,29909,4160,4194304,16,95496,8328,65,4291883,5393,17665,67618,1501,4194440,256,21793,16465,74250]

theorem envBound46982 : H12AffineFastState.Bounded env46982 := by
  intro p hp
  have h : env46982.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46981_46982 : H12AffineEnvironment.transform 14 29908 env46981 = env46982 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env46981 == env46982) = true)

def env46983 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,131072,212199,1024,8661,4160,4194304,16,73736,8328,65,4270123,5393,4097,67618,1501,4194440,256,33,5457,74250]

theorem envBound46983 : H12AffineFastState.Bounded env46983 := by
  intro p hp
  have h : env46983.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46982_46983 : H12AffineEnvironment.transform 13 5376 env46982 = env46983 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env46982 == env46983) = true)

theorem identity46983 : scanCanonicalize (H12AffineFastState.compose env46983 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70862) := by decide +kernel

theorem selectedBound46983 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46984 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,65536,70862,10281,1024,8661,4160,4194304,16,73736,8328,65,4270123,5393,4097,67618,1501,4194440,256,33,5457,74250]

theorem envBound46984 : H12AffineFastState.Bounded env46984 := by
  intro p hp
  have h : env46984.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46983_46984 : H12AffineEnvironment.transform 16 70862 env46983 = env46984 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70862 env46983 == env46984) = true)

theorem identity46984 : scanCanonicalize (H12AffineFastState.compose env46984 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound46984 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env46985 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8660,479,5393,10281,1024,8661,4160,4194304,16,8663,8328,65,4205044,5393,4097,2557,1501,4194440,256,33,5457,9173]

theorem envBound46985 : H12AffineFastState.Bounded env46985 := by
  intro p hp
  have h : env46985.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46984_46985 : H12AffineEnvironment.transform 15 479 env46984 = env46985 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env46984 == env46985) = true)

theorem identity46985 : scanCanonicalize (H12AffineFastState.compose env46985 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound46985 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env46986 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,479,5393,2557,1024,1,4160,4194304,16,3,348,65,4196384,5393,4097,2557,1501,4194440,256,33,5457,513]

theorem envBound46986 : H12AffineFastState.Bounded env46986 := by
  intro p hp
  have h : env46986.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46985_46986 : H12AffineEnvironment.transform 12 468 env46985 = env46986 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env46985 == env46986) = true)

theorem identity46986 : scanCanonicalize (H12AffineFastState.compose env46986 (packedSelected [2,6] rootPS)) = affineNative (2^(21+1) ^^^ 248) := by decide +kernel

theorem selectedBound46986 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env46987 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5376,0,479,5393,2557,1024,1,4160,248,16,3,348,65,2264,5393,4097,2557,1501,112,256,33,5457,513]

theorem envBound46987 : H12AffineFastState.Bounded env46987 := by
  intro p hp
  have h : env46987.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46986_46987 : H12AffineEnvironment.transform 21 248 env46986 = env46987 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 248 env46986 == env46987) = true)

def env46988 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,131072,212199,1024,8660,4160,4194304,16,73737,8328,65,4270122,5393,4096,67618,1501,4194440,256,32,5456,74250]

theorem envBound46988 : H12AffineFastState.Bounded env46988 := by
  intro p hp
  have h : env46988.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46982_46988 : H12AffineEnvironment.transform 13 5377 env46982 = env46988 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env46982 == env46988) = true)

theorem identity46988 : scanCanonicalize (H12AffineFastState.compose env46988 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound46988 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env46989 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8661,65536,70726,10401,1024,8660,4160,4194304,16,73737,8328,65,4270122,5393,4096,67618,1501,4194440,256,32,5456,74250]

theorem envBound46989 : H12AffineFastState.Bounded env46989 := by
  intro p hp
  have h : env46989.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46988_46989 : H12AffineEnvironment.transform 16 70726 env46988 = env46989 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env46988 == env46989) = true)

theorem identity46989 : scanCanonicalize (H12AffineFastState.compose env46989 (packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound46989 : packedSelected [0,1,2,3,6,8,11,12,14,15,16,20,23,24,27,31] rootPS < 2^1333 := by decide +kernel

def env46990 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,65536,70678,10401,1024,8580,4112,4194304,16,73737,8328,17,4270122,5393,4096,67618,1421,4194440,256,32,5376,74250]

theorem envBound46990 : H12AffineFastState.Bounded env46990 := by
  intro p hp
  have h : env46990.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46989_46990 : H12AffineEnvironment.transform 5 16 env46989 = env46990 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env46989 == env46990) = true)

theorem identity46990 : scanCanonicalize (H12AffineFastState.compose env46990 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound46990 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env46991 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,8323,13461,10401,1024,8580,4112,4194304,16,138,8328,17,4196521,5393,4096,10401,1421,4194440,256,32,5376,649]

theorem envBound46991 : H12AffineFastState.Bounded env46991 := by
  intro p hp
  have h : env46991.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46990_46991 : H12AffineEnvironment.transform 15 8323 env46990 = env46991 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env46990 == env46991) = true)

theorem identity46991 : scanCanonicalize (H12AffineFastState.compose env46991 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(21+1) ^^^ 33) := by decide +kernel

theorem selectedBound46991 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env46992 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,8581,8323,13461,10401,1024,8580,4112,33,16,138,8328,17,2184,5393,4096,10401,1421,169,256,32,5376,649]

theorem envBound46992 : H12AffineFastState.Bounded env46992 := by
  intro p hp
  have h : env46992.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46991_46992 : H12AffineEnvironment.transform 21 33 env46991 = env46992 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env46991 == env46992) = true)

theorem identity46992 : scanCanonicalize (H12AffineFastState.compose env46992 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound46992 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env46993 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,160,5377,293,35,5173,2049,1024,292,4112,33,16,138,40,17,2184,5393,4096,2049,1421,169,256,32,5376,649]

theorem envBound46993 : H12AffineFastState.Bounded env46993 := by
  intro p hp
  have h : env46993.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46992_46993 : H12AffineEnvironment.transform 12 160 env46992 = env46993 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env46992 == env46993) = true)

theorem identity46993 : scanCanonicalize (H12AffineFastState.compose env46993 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound46993 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env46994 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,40,5377,293,35,5173,2049,1024,292,4112,33,16,2,40,17,2048,5393,4096,2049,1285,33,256,32,5376,513]

theorem envBound46994 : H12AffineFastState.Bounded env46994 := by
  intro p hp
  have h : env46994.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46993_46994 : H12AffineEnvironment.transform 6 8 env46993 = env46994 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env46993 == env46994) = true)

theorem identity46994 : scanCanonicalize (H12AffineFastState.compose env46994 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound46994 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env46995 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,4096,40,5157,1,35,5173,2049,1024,0,4112,33,16,2,40,17,2048,5173,4096,2049,1057,33,36,32,5156,513]

theorem envBound46995 : H12AffineFastState.Bounded env46995 := by
  intro p hp
  have h : env46995.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46994_46995 : H12AffineEnvironment.transform 7 36 env46994 = env46995 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env46994 == env46995) = true)

theorem identity46995 : scanCanonicalize (H12AffineFastState.compose env46995 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound46995 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env46996 : List Nat := [2,4,8,16,32,16,8,36,512,1024,2048,0,40,1061,1,35,1077,2049,1024,0,16,33,16,2,40,17,2048,1077,0,2049,1057,33,36,32,1060,513]

theorem envBound46996 : H12AffineFastState.Bounded env46996 := by
  intro p hp
  have h : env46996.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46995_46996 : H12AffineEnvironment.transform 11 0 env46995 = env46996 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env46995 == env46996) = true)

theorem identity46996 : scanCanonicalize (H12AffineFastState.compose env46996 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound46996 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env46997 : List Nat := [2,4,8,16,32,16,8,36,1,1024,2048,0,40,1061,1,35,1077,2049,1024,0,16,33,16,2,40,17,2048,1077,0,2049,1057,33,36,32,1060,0]

theorem envBound46997 : H12AffineFastState.Bounded env46997 := by
  intro p hp
  have h : env46997.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46996_46997 : H12AffineEnvironment.transform 8 1 env46996 = env46997 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env46996 == env46997) = true)

theorem identity46997 : scanCanonicalize (H12AffineFastState.compose env46997 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 36) := by decide +kernel

theorem selectedBound46997 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env46998 : List Nat := [2,4,8,16,32,16,8,36,1,36,2048,0,40,1,1,35,17,2049,36,0,16,33,16,2,40,17,2048,17,0,2049,5,33,36,32,0,0]

theorem envBound46998 : H12AffineFastState.Bounded env46998 := by
  intro p hp
  have h : env46998.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46997_46998 : H12AffineEnvironment.transform 9 36 env46997 = env46998 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 36 env46997 == env46998) = true)

theorem identity46998 : scanCanonicalize (H12AffineFastState.compose env46998 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound46998 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env46999 : List Nat := [2,4,8,16,32,16,8,36,1,36,1,0,40,1,1,35,17,0,36,0,16,33,16,2,40,17,1,17,0,0,5,33,36,32,0,0]

theorem envBound46999 : H12AffineFastState.Bounded env46999 := by
  intro p hp
  have h : env46999.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46998_46999 : H12AffineEnvironment.transform 10 1 env46998 = env46999 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env46998 == env46999) = true)

def env47000 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,17,98780,8328,65,4295166,5393,17664,67619,1500,4256860,256,21792,46212,74251]

theorem envBound47000 : H12AffineFastState.Bounded env47000 := by
  intro p hp
  have h : env47000.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46980_47000 : H12AffineEnvironment.transform 22 17 env46980 = env47000 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env46980 == env47000) = true)

theorem identity47000 : scanCanonicalize (H12AffineFastState.compose env47000 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 144492) := by decide +kernel

theorem selectedBound47000 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47001 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,144492,17,98780,8328,65,245138,5393,17664,67619,1500,180272,256,21792,46212,74251]

theorem envBound47001 : H12AffineFastState.Bounded env47001 := by
  intro p hp
  have h : env47001.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47000_47001 : H12AffineEnvironment.transform 21 144492 env47000 = env47001 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 144492 env47000 == env47001) = true)

def env47002 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,144492,17,98644,8192,65,245018,5393,17664,67619,1364,180272,256,21792,46092,74251]

theorem envBound47002 : H12AffineFastState.Bounded env47002 := by
  intro p hp
  have h : env47002.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47001_47002 : H12AffineEnvironment.transform 6 8 env47001 = env47002 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47001 == env47002) = true)

theorem identity47002 : scanCanonicalize (H12AffineFastState.compose env47002 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47002 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47003 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,236850,1024,32769,4160,144492,17,98644,8192,65,245018,5393,4097,67619,1364,169265,256,33,46092,74251]

theorem envBound47003 : H12AffineFastState.Bounded env47003 := by
  intro p hp
  have h : env47003.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47002_47003 : H12AffineEnvironment.transform 13 5377 env47002 = env47003 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47002 == env47003) = true)

theorem identity47003 : scanCanonicalize (H12AffineFastState.compose env47003 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound47003 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47004 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,38161,67619,1024,32769,4160,41341,17,98644,8192,65,75787,5393,4097,67619,1364,32,256,33,46092,74251]

theorem envBound47004 : H12AffineFastState.Bounded env47004 := by
  intro p hp
  have h : env47004.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47003_47004 : H12AffineEnvironment.transform 16 38161 env47003 = env47004 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env47003 == env47004) = true)

theorem identity47004 : scanCanonicalize (H12AffineFastState.compose env47004 (packedSelected [1,3,5,8,10,11,12,15,16,18,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47004 : packedSelected [1,3,5,8,10,11,12,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env47005 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,8203,38161,10280,1024,32769,4160,41341,17,41311,8192,65,2048,5393,4097,10280,1364,32,256,33,46092,512]

theorem envBound47005 : H12AffineFastState.Bounded env47005 := by
  intro p hp
  have h : env47005.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47004_47005 : H12AffineEnvironment.transform 15 8203 env47004 = env47005 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47004 == env47005) = true)

theorem identity47005 : scanCanonicalize (H12AffineFastState.compose env47005 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 380) := by decide +kernel

theorem selectedBound47005 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47006 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5377,32768,375,38161,2388,1024,32769,4160,32769,17,32803,380,65,2048,5393,4097,2388,1364,32,256,33,38256,512]

theorem envBound47006 : H12AffineFastState.Bounded env47006 := by
  intro p hp
  have h : env47006.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47005_47006 : H12AffineEnvironment.transform 12 380 env47005 = env47006 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 380 env47005 == env47006) = true)

theorem identity47006 : scanCanonicalize (H12AffineFastState.compose env47006 (packedSelected [0,2,3,4,5,7,9,10] rootPS)) = affineNative (2^(14+1) ^^^ 1076) := by decide +kernel

theorem selectedBound47006 : packedSelected [0,2,3,4,5,7,9,10] rootPS < 2^1333 := by decide +kernel

def env47007 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,380,5377,1076,375,4389,2388,1024,1077,4160,1077,17,1047,380,65,2048,5393,4097,2388,1364,32,256,33,4420,512]

theorem envBound47007 : H12AffineFastState.Bounded env47007 := by
  intro p hp
  have h : env47007.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47006_47007 : H12AffineEnvironment.transform 14 1076 env47006 = env47007 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1076 env47006 == env47007) = true)

theorem identity47007 : scanCanonicalize (H12AffineFastState.compose env47007 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(11+1) ^^^ 3108) := by decide +kernel

theorem selectedBound47007 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env47008 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3108,380,2341,1076,375,3329,2388,1024,1077,3172,1077,17,1047,380,65,2048,2357,3109,2388,1364,32,256,33,3424,512]

theorem envBound47008 : H12AffineFastState.Bounded env47008 := by
  intro p hp
  have h : env47008.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47007_47008 : H12AffineEnvironment.transform 11 3108 env47007 = env47008 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3108 env47007 == env47008) = true)

theorem identity47008 : scanCanonicalize (H12AffineFastState.compose env47008 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47008 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env47009 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2113,380,2341,81,375,2404,2388,101,80,2049,80,17,114,380,65,2048,2357,2112,2388,305,32,256,33,2309,512]

theorem envBound47009 : H12AffineFastState.Bounded env47009 := by
  intro p hp
  have h : env47009.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47008_47009 : H12AffineEnvironment.transform 9 101 env47008 = env47009 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47008 == env47009) = true)

theorem identity47009 : scanCanonicalize (H12AffineFastState.compose env47009 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47009 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env47010 : List Nat := [2,4,8,16,32,17,8,256,512,52,2048,2064,301,2341,0,294,2357,2309,52,1,2049,1,17,35,301,16,2048,2357,2065,2309,305,32,256,33,2309,512]

theorem envBound47010 : H12AffineFastState.Bounded env47010 := by
  intro p hp
  have h : env47010.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47009_47010 : H12AffineEnvironment.transform 5 17 env47009 = env47010 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47009 == env47010) = true)

theorem identity47010 : scanCanonicalize (H12AffineFastState.compose env47010 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 277) := by decide +kernel

theorem selectedBound47010 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47011 : List Nat := [2,4,8,16,32,17,8,256,512,52,277,261,301,48,0,294,32,16,52,1,276,1,17,35,301,16,277,32,260,16,305,32,256,33,16,512]

theorem envBound47011 : H12AffineFastState.Bounded env47011 := by
  intro p hp
  have h : env47011.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47010_47011 : H12AffineEnvironment.transform 10 277 env47010 = env47011 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 277 env47010 == env47011) = true)

theorem identity47011 : scanCanonicalize (H12AffineFastState.compose env47011 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 31) := by decide +kernel

theorem selectedBound47011 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47012 : List Nat := [2,4,8,16,32,17,8,31,512,52,10,26,50,48,0,57,32,16,52,1,11,1,17,35,50,16,10,32,27,16,46,32,31,33,16,512]

theorem envBound47012 : H12AffineFastState.Bounded env47012 := by
  intro p hp
  have h : env47012.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47011_47012 : H12AffineEnvironment.transform 7 31 env47011 = env47012 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 31 env47011 == env47012) = true)

theorem identity47012 : scanCanonicalize (H12AffineFastState.compose env47012 (packedSelected [1,7] rootPS)) = affineNative (2^(8+1) ^^^ 24) := by decide +kernel

theorem selectedBound47012 : packedSelected [1,7] rootPS < 2^1333 := by decide +kernel

def env47013 : List Nat := [2,4,8,16,32,17,8,31,24,52,10,26,50,48,0,57,32,16,52,1,11,1,17,35,50,16,10,32,27,16,46,32,31,33,16,24]

theorem envBound47013 : H12AffineFastState.Bounded env47013 := by
  intro p hp
  have h : env47013.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47012_47013 : H12AffineEnvironment.transform 8 24 env47012 = env47013 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 24 env47012 == env47013) = true)

theorem identity47013 : scanCanonicalize (H12AffineFastState.compose env47013 (packedSelected [5,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47013 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47014 : List Nat := [2,4,8,16,0,17,8,31,24,20,10,26,18,16,0,25,0,16,20,1,11,1,17,3,18,16,10,0,27,16,14,0,31,1,16,24]

theorem envBound47014 : H12AffineFastState.Bounded env47014 := by
  intro p hp
  have h : env47014.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47013_47014 : H12AffineEnvironment.transform 4 0 env47013 = env47014 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47013 == env47014) = true)

theorem identity47014 : scanCanonicalize (H12AffineFastState.compose env47014 (packedSelected [0,4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound47014 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47015 : List Nat := [1,4,8,16,0,17,8,28,24,20,9,25,17,16,0,25,0,16,20,1,8,1,17,0,17,16,9,0,24,16,13,0,28,1,16,24]

theorem envBound47015 : H12AffineFastState.Bounded env47015 := by
  intro p hp
  have h : env47015.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47014_47015 : H12AffineEnvironment.transform 0 1 env47014 = env47015 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env47014 == env47015) = true)

theorem identity47015 : scanCanonicalize (H12AffineFastState.compose env47015 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47015 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47016 : List Nat := [1,4,8,4,0,5,8,8,12,0,9,13,5,4,0,13,0,4,0,1,8,1,5,0,5,4,9,0,12,4,13,0,8,1,4,12]

theorem envBound47016 : H12AffineFastState.Bounded env47016 := by
  intro p hp
  have h : env47016.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47015_47016 : H12AffineEnvironment.transform 3 4 env47015 = env47016 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47015 == env47016) = true)

def env47017 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,144492,17,98645,8193,65,245019,5393,17664,67619,1365,180272,256,21792,46093,74251]

theorem envBound47017 : H12AffineFastState.Bounded env47017 := by
  intro p hp
  have h : env47017.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47001_47017 : H12AffineEnvironment.transform 6 9 env47001 = env47017 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47001 == env47017) = true)

theorem identity47017 : scanCanonicalize (H12AffineFastState.compose env47017 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47017 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47018 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223599,1024,8541,4160,144492,17,73737,8193,65,203847,5393,17664,67619,1365,156012,256,21792,5457,74251]

theorem envBound47018 : H12AffineFastState.Bounded env47018 := by
  intro p hp
  have h : env47018.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47017_47018 : H12AffineEnvironment.transform 14 8540 env47017 = env47018 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47017 == env47018) = true)

theorem identity47018 : scanCanonicalize (H12AffineFastState.compose env47018 (packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS)) = affineNative (2^(16+1) ^^^ 78959) := by decide +kernel

theorem selectedBound47018 : packedSelected [1,4,8,9,10,12,14,15,19,20,31] rootPS < 2^1333 := by decide +kernel

def env47019 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,78959,23808,1024,8541,4160,65539,17,73737,8193,65,10280,5393,17664,67619,1365,87299,256,21792,5457,74251]

theorem envBound47019 : H12AffineFastState.Bounded env47019 := by
  intro p hp
  have h : env47019.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47018_47019 : H12AffineEnvironment.transform 16 78959 env47018 = env47019 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 78959 env47018 == env47019) = true)

theorem identity47019 : scanCanonicalize (H12AffineFastState.compose env47019 (packedSelected [0,3,7,9,10,14,16,18,22,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 30042) := by decide +kernel

theorem selectedBound47019 : packedSelected [0,3,7,9,10,14,16,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47020 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,30042,16693,23808,1024,8541,4160,30041,17,21843,8193,65,10280,5393,17664,32121,1365,8281,256,21792,5457,22353]

theorem envBound47020 : H12AffineFastState.Bounded env47020 := by
  intro p hp
  have h : env47020.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47019_47020 : H12AffineEnvironment.transform 15 30042 env47019 = env47020 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30042 env47019 == env47020) = true)

theorem identity47020 : scanCanonicalize (H12AffineFastState.compose env47020 (packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47020 : packedSelected [1,2,6,8,9,11,12,14,15,16,19,20,22,23] rootPS < 2^1333 := by decide +kernel

def env47021 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8312,29822,16401,23588,1024,8313,4160,29821,17,21623,8193,65,10280,5173,17444,31837,1137,8281,36,21508,5237,22133]

theorem envBound47021 : H12AffineFastState.Bounded env47021 := by
  intro p hp
  have h : env47021.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47020_47021 : H12AffineEnvironment.transform 7 36 env47020 = env47021 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47020 == env47021) = true)

theorem identity47021 : scanCanonicalize (H12AffineFastState.compose env47021 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound47021 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env47022 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,5237,8312,8203,5220,2129,1024,8313,4160,8200,17,2,8193,65,10280,5173,4177,10280,1137,8281,36,113,5237,512]

theorem envBound47022 : H12AffineFastState.Bounded env47022 := by
  intro p hp
  have h : env47022.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47021_47022 : H12AffineEnvironment.transform 13 5237 env47021 = env47022 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env47021 == env47022) = true)

theorem identity47022 : scanCanonicalize (H12AffineFastState.compose env47022 (packedSelected [2,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound47022 : packedSelected [2,5,6,8] rootPS < 2^1333 := by decide +kernel

def env47023 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,1100,5237,1076,1095,5220,2129,1024,1077,4160,1092,17,2,1101,65,3172,5173,4177,3172,1137,1045,36,113,5237,512]

theorem envBound47023 : H12AffineFastState.Bounded env47023 := by
  intro p hp
  have h : env47023.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47022_47023 : H12AffineEnvironment.transform 12 1100 env47022 = env47023 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env47022 == env47023) = true)

theorem identity47023 : scanCanonicalize (H12AffineFastState.compose env47023 (packedSelected [0,2,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound47023 : packedSelected [0,2,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env47024 : List Nat := [2,4,8,16,32,64,9,36,512,20,2048,4096,88,4193,32,83,4208,2129,20,33,4160,80,17,2,89,65,2160,4129,4177,2160,101,1,36,113,4193,512]

theorem envBound47024 : H12AffineFastState.Bounded env47024 := by
  intro p hp
  have h : env47024.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47023_47024 : H12AffineEnvironment.transform 9 20 env47023 = env47024 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env47023 == env47024) = true)

def env47025 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,8388608,98781,8328,65,12683758,5393,8406288,8456242,8390092,4256860,256,8410417,8434837,8462875]

theorem envBound47025 : H12AffineFastState.Bounded env47025 := by
  intro p hp
  have h : env47025.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46979_47025 : H12AffineEnvironment.transform 20 4161 env46979 = env47025 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env46979 == env47025) = true)

def env47026 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,16,98781,8328,65,4295166,5393,17664,67618,1500,4256860,256,21793,46213,74251]

theorem envBound47026 : H12AffineFastState.Bounded env47026 := by
  intro p hp
  have h : env47026.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47025_47026 : H12AffineEnvironment.transform 22 16 env47025 = env47026 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env47025 == env47026) = true)

def env47027 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,16,98645,8192,65,4295030,5393,17664,67618,1364,4256860,256,21793,46093,74251]

theorem envBound47027 : H12AffineFastState.Bounded env47027 := by
  intro p hp
  have h : env47027.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47026_47027 : H12AffineEnvironment.transform 6 8 env47026 = env47027 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47026 == env47027) = true)

theorem identity47027 : scanCanonicalize (H12AffineFastState.compose env47027 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122906) := by decide +kernel

theorem selectedBound47027 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47028 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,4161,4194304,16,98645,8192,65,4295030,5393,17664,67618,1364,4256860,256,21793,46093,74251]

theorem envBound47028 : H12AffineFastState.Bounded env47028 := by
  intro p hp
  have h : env47028.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47027_47028 : H12AffineEnvironment.transform 16 122906 env47027 = env47028 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122906 env47027 == env47028) = true)

theorem identity47028 : scanCanonicalize (H12AffineFastState.compose env47028 (packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS)) = affineNative (2^(21+1) ^^^ 32800) := by decide +kernel

theorem selectedBound47028 : packedSelected [0,3,4,7,10,18,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env47029 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,10281,1024,32769,4161,32800,16,98645,8192,65,67926,5393,17664,67618,1364,29820,256,21793,46093,74251]

theorem envBound47029 : H12AffineFastState.Bounded env47029 := by
  intro p hp
  have h : env47029.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47028_47029 : H12AffineEnvironment.transform 21 32800 env47028 = env47029 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32800 env47028 == env47029) = true)

theorem identity47029 : scanCanonicalize (H12AffineFastState.compose env47029 (packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound47029 : packedSelected [0,1,3,4,5,7,8,10,19,22] rootPS < 2^1333 := by decide +kernel

def env47030 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,16401,10281,1024,32769,4161,32800,16,8542,8192,65,43357,5393,17664,43049,1364,29820,256,21793,46093,33280]

theorem envBound47030 : H12AffineFastState.Bounded env47030 := by
  intro p hp
  have h : env47030.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47029_47030 : H12AffineEnvironment.transform 15 40971 env47029 = env47030 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env47029 == env47030) = true)

theorem identity47030 : scanCanonicalize (H12AffineFastState.compose env47030 (packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47030 : packedSelected [1,3,5,8,10,16,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env47031 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,1,8202,16401,10281,1024,0,4161,33,16,8542,8192,65,10588,5393,17664,10280,1364,29820,256,21793,13324,513]

theorem envBound47031 : H12AffineFastState.Bounded env47031 := by
  intro p hp
  have h : env47031.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47030_47031 : H12AffineEnvironment.transform 14 1 env47030 = env47031 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47030 == env47031) = true)

theorem identity47031 : scanCanonicalize (H12AffineFastState.compose env47031 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47031 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env47032 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,1,343,16401,2420,1024,0,4161,33,16,3,349,65,2049,5393,17664,2421,1364,21793,256,21793,5457,513]

theorem envBound47032 : H12AffineFastState.Bounded env47032 := by
  intro p hp
  have h : env47032.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47031_47032 : H12AffineEnvironment.transform 12 349 env47031 = env47032 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47031 == env47032) = true)

theorem identity47032 : scanCanonicalize (H12AffineFastState.compose env47032 (packedSelected [0,7] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound47032 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env47033 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,4113,1,343,4096,2420,1024,0,4161,33,16,3,349,65,2049,5393,5393,2421,1364,1328,256,1328,5457,513]

theorem envBound47033 : H12AffineFastState.Bounded env47033 := by
  intro p hp
  have h : env47033.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47032_47033 : H12AffineEnvironment.transform 13 4113 env47032 = env47033 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env47032 == env47033) = true)

theorem identity47033 : scanCanonicalize (H12AffineFastState.compose env47033 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound47033 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env47034 : List Nat := [2,4,8,16,32,64,8,85,512,1024,2048,4096,8,4113,1,2,4096,2081,1024,0,4161,33,16,3,8,65,2049,5188,5188,2080,1025,1125,85,1125,5124,513]

theorem envBound47034 : H12AffineFastState.Bounded env47034 := by
  intro p hp
  have h : env47034.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47033_47034 : H12AffineEnvironment.transform 7 85 env47033 = env47034 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env47033 == env47034) = true)

theorem identity47034 : scanCanonicalize (H12AffineFastState.compose env47034 (packedSelected [2,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47034 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env47035 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,4096,8,4113,1,2,4096,2081,1024,0,4113,33,16,3,8,17,2049,5140,5140,2080,1025,1077,5,1077,5124,513]

theorem envBound47035 : H12AffineFastState.Bounded env47035 := by
  intro p hp
  have h : env47035.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47034_47035 : H12AffineEnvironment.transform 5 16 env47034 = env47035 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47034 == env47035) = true)

theorem identity47035 : scanCanonicalize (H12AffineFastState.compose env47035 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 48) := by decide +kernel

theorem selectedBound47035 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47036 : List Nat := [2,4,8,16,32,16,8,5,512,1024,2048,48,8,33,1,2,48,2081,1024,0,33,33,16,3,8,17,2049,1060,1060,2080,1025,1077,5,1077,1076,513]

theorem envBound47036 : H12AffineFastState.Bounded env47036 := by
  intro p hp
  have h : env47036.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47035_47036 : H12AffineEnvironment.transform 11 48 env47035 = env47036 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env47035 == env47036) = true)

theorem identity47036 : scanCanonicalize (H12AffineFastState.compose env47036 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 544) := by decide +kernel

theorem selectedBound47036 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env47037 : List Nat := [2,4,8,16,32,16,8,5,512,1024,544,48,8,33,1,2,48,513,1024,0,33,33,16,3,8,17,545,1060,1060,512,1025,1077,5,1077,1076,513]

theorem envBound47037 : H12AffineFastState.Bounded env47037 := by
  intro p hp
  have h : env47037.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47036_47037 : H12AffineEnvironment.transform 10 544 env47036 = env47037 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 544 env47036 == env47037) = true)

theorem identity47037 : scanCanonicalize (H12AffineFastState.compose env47037 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound47037 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env47038 : List Nat := [2,4,8,16,32,16,8,5,512,565,544,48,8,33,1,2,48,513,565,0,33,33,16,3,8,17,545,529,529,512,564,512,5,512,513,513]

theorem envBound47038 : H12AffineFastState.Bounded env47038 := by
  intro p hp
  have h : env47038.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47037_47038 : H12AffineEnvironment.transform 9 565 env47037 = env47038 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env47037 == env47038) = true)

theorem identity47038 : scanCanonicalize (H12AffineFastState.compose env47038 (packedSelected [1,5] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound47038 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env47039 : List Nat := [2,4,8,16,16,16,8,5,512,517,528,0,8,17,1,2,0,513,517,0,17,17,16,3,8,17,529,529,529,512,516,512,5,512,513,513]

theorem envBound47039 : H12AffineFastState.Bounded env47039 := by
  intro p hp
  have h : env47039.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47038_47039 : H12AffineEnvironment.transform 4 16 env47038 = env47039 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env47038 == env47039) = true)

theorem identity47039 : scanCanonicalize (H12AffineFastState.compose env47039 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound47039 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47040 : List Nat := [2,4,8,16,16,16,8,5,1,4,17,0,8,17,1,2,0,0,4,0,17,17,16,3,8,17,16,16,16,1,5,1,5,1,0,0]

theorem envBound47040 : H12AffineFastState.Bounded env47040 := by
  intro p hp
  have h : env47040.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47039_47040 : H12AffineEnvironment.transform 8 1 env47039 = env47040 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env47039 == env47040) = true)

theorem identity47040 : scanCanonicalize (H12AffineFastState.compose env47040 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47040 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47041 : List Nat := [2,4,8,0,0,0,8,5,1,4,1,0,8,1,1,2,0,0,4,0,1,1,0,3,8,1,0,0,0,1,5,1,5,1,0,0]

theorem envBound47041 : H12AffineFastState.Bounded env47041 := by
  intro p hp
  have h : env47041.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47040_47041 : H12AffineEnvironment.transform 3 0 env47040 = env47041 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47040 == env47041) = true)

def env47042 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,16,98644,8193,65,4295031,5393,17664,67618,1365,4256860,256,21793,46092,74251]

theorem envBound47042 : H12AffineFastState.Bounded env47042 := by
  intro p hp
  have h : env47042.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47026_47042 : H12AffineEnvironment.transform 6 9 env47026 = env47042 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47026 == env47042) = true)

theorem identity47042 : scanCanonicalize (H12AffineFastState.compose env47042 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82247) := by decide +kernel

theorem selectedBound47042 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47043 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,82247,35188,1024,32769,4161,4194304,16,98644,8193,65,4295031,5393,17664,67618,1365,4256860,256,21793,46092,74251]

theorem envBound47043 : H12AffineFastState.Bounded env47043 := by
  intro p hp
  have h : env47043.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47042_47043 : H12AffineEnvironment.transform 16 82247 env47042 = env47043 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82247 env47042 == env47043) = true)

theorem identity47043 : scanCanonicalize (H12AffineFastState.compose env47043 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound47043 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47044 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,65536,70678,35188,1024,32769,4161,4194304,16,98644,8193,65,4295031,5393,4177,67618,1365,4235533,256,112,46092,74251]

theorem envBound47044 : H12AffineFastState.Bounded env47044 := by
  intro p hp
  have h : env47044.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47043_47044 : H12AffineEnvironment.transform 13 5457 env47043 = env47044 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env47043 == env47044) = true)

theorem identity47044 : scanCanonicalize (H12AffineFastState.compose env47044 (packedSelected [0,4,5,7,8,10,19,22,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound47044 : packedSelected [0,4,5,7,8,10,19,22,24,28] rootPS < 2^1333 := by decide +kernel

def env47045 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,343,5441,35188,1024,32769,4161,4194304,16,32771,8193,65,4229152,5393,4177,2421,1365,4235533,256,112,46092,9052]

theorem envBound47045 : H12AffineFastState.Bounded env47045 := by
  intro p hp
  have h : env47045.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47044_47045 : H12AffineEnvironment.transform 15 343 env47044 = env47045 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env47044 == env47045) = true)

theorem identity47045 : scanCanonicalize (H12AffineFastState.compose env47045 (packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS)) = affineNative (2^(21+1) ^^^ 8281) := by decide +kernel

theorem selectedBound47045 : packedSelected [0,3,5,7,9,10,12,14,15,20,22] rootPS < 2^1333 := by decide +kernel

def env47046 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5457,32768,343,5441,35188,1024,32769,4161,8281,16,32771,8193,65,43129,5393,4177,2421,1365,33108,256,112,46092,9052]

theorem envBound47046 : H12AffineFastState.Bounded env47046 := by
  intro p hp
  have h : env47046.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47045_47046 : H12AffineEnvironment.transform 21 8281 env47045 = env47046 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8281 env47045 == env47046) = true)

theorem identity47046 : scanCanonicalize (H12AffineFastState.compose env47046 (packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS)) = affineNative (2^(12+1) ^^^ 121) := by decide +kernel

theorem selectedBound47046 : packedSelected [1,4,8,9,12,14,15,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env47047 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,121,5457,32768,343,5441,35188,1024,32769,4161,32,16,32771,120,65,34816,5393,4177,2421,1365,33108,256,112,38005,805]

theorem envBound47047 : H12AffineFastState.Bounded env47047 := by
  intro p hp
  have h : env47047.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47046_47047 : H12AffineEnvironment.transform 12 121 env47046 = env47047 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 121 env47046 == env47047) = true)

theorem identity47047 : scanCanonicalize (H12AffineFastState.compose env47047 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound47047 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,18,19] rootPS < 2^1333 := by decide +kernel

def env47048 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5156,32768,34,5172,34817,1024,32769,4161,32,16,32771,120,65,34816,5220,4177,2048,1056,32801,117,112,38005,592]

theorem envBound47048 : H12AffineFastState.Bounded env47048 := by
  intro p hp
  have h : env47048.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47047_47048 : H12AffineEnvironment.transform 7 117 env47047 = env47048 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env47047 == env47048) = true)

theorem identity47048 : scanCanonicalize (H12AffineFastState.compose env47048 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound47048 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env47049 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5156,1,34,5172,2048,1024,0,4161,32,16,2,120,65,2049,5220,4177,2048,1056,32,117,112,5236,592]

theorem envBound47049 : H12AffineFastState.Bounded env47049 := by
  intro p hp
  have h : env47049.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47048_47049 : H12AffineEnvironment.transform 14 1 env47048 = env47049 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env47048 == env47049) = true)

theorem identity47049 : scanCanonicalize (H12AffineFastState.compose env47049 (packedSelected [0,3,5,6,7] rootPS)) = affineNative (2^(9+1) ^^^ 68) := by decide +kernel

theorem selectedBound47049 : packedSelected [0,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env47050 : List Nat := [2,4,8,16,32,64,9,117,512,68,2048,4096,121,4192,1,34,4208,2048,68,0,4161,32,16,2,120,65,2049,4128,4177,2048,100,32,117,112,4144,592]

theorem envBound47050 : H12AffineFastState.Bounded env47050 := by
  intro p hp
  have h : env47050.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47049_47050 : H12AffineEnvironment.transform 9 68 env47049 = env47050 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 68 env47049 == env47050) = true)

theorem identity47050 : scanCanonicalize (H12AffineFastState.compose env47050 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47050 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env47051 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,4096,41,4144,1,34,4128,2048,20,0,4113,32,16,2,40,17,2049,4128,4097,2048,52,32,37,32,4144,512]

theorem envBound47051 : H12AffineFastState.Bounded env47051 := by
  intro p hp
  have h : env47051.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47050_47051 : H12AffineEnvironment.transform 5 16 env47050 = env47051 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47050 == env47051) = true)

theorem identity47051 : scanCanonicalize (H12AffineFastState.compose env47051 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2587) := by decide +kernel

theorem selectedBound47051 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47052 : List Nat := [2,4,8,16,32,16,9,37,512,20,2048,2587,41,2603,1,34,2619,2048,20,0,2570,32,16,2,40,17,2049,2619,2586,2048,52,32,37,32,2603,512]

theorem envBound47052 : H12AffineFastState.Bounded env47052 := by
  intro p hp
  have h : env47052.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47051_47052 : H12AffineEnvironment.transform 11 2587 env47051 = env47052 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2587 env47051 == env47052) = true)

theorem identity47052 : scanCanonicalize (H12AffineFastState.compose env47052 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound47052 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47053 : List Nat := [2,4,8,16,32,16,9,37,43,20,2048,2096,41,2048,1,34,2064,2048,20,0,2081,32,16,2,40,17,2049,2064,2097,2048,52,32,37,32,2048,43]

theorem envBound47053 : H12AffineFastState.Bounded env47053 := by
  intro p hp
  have h : env47053.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47052_47053 : H12AffineEnvironment.transform 8 43 env47052 = env47053 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env47052 == env47053) = true)

theorem identity47053 : scanCanonicalize (H12AffineFastState.compose env47053 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 7) := by decide +kernel

theorem selectedBound47053 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47054 : List Nat := [2,4,8,16,32,16,9,37,43,20,7,55,41,7,1,34,23,7,20,0,38,32,16,2,40,17,6,23,54,7,52,32,37,32,7,43]

theorem envBound47054 : H12AffineFastState.Bounded env47054 := by
  intro p hp
  have h : env47054.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47053_47054 : H12AffineEnvironment.transform 10 7 env47053 = env47054 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 7 env47053 == env47054) = true)

theorem identity47054 : scanCanonicalize (H12AffineFastState.compose env47054 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 7) := by decide +kernel

theorem selectedBound47054 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env47055 : List Nat := [2,4,8,16,7,16,9,2,12,20,7,16,14,7,1,5,23,7,20,0,1,7,16,2,15,17,6,23,17,7,19,7,2,7,7,12]

theorem envBound47055 : H12AffineFastState.Bounded env47055 := by
  intro p hp
  have h : env47055.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47054_47055 : H12AffineEnvironment.transform 4 7 env47054 = env47055 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 7 env47054 == env47055) = true)

theorem identity47055 : scanCanonicalize (H12AffineFastState.compose env47055 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47055 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47056 : List Nat := [2,4,8,4,7,4,9,2,12,0,7,4,14,7,1,5,3,7,0,0,1,7,4,2,15,5,6,3,5,7,7,7,2,7,7,12]

theorem envBound47056 : H12AffineFastState.Bounded env47056 := by
  intro p hp
  have h : env47056.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47055_47056 : H12AffineEnvironment.transform 3 4 env47055 = env47056 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47055 == env47056) = true)

theorem identity47056 : scanCanonicalize (H12AffineFastState.compose env47056 (packedSelected [6] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound47056 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env47057 : List Nat := [2,3,8,3,0,3,9,2,11,0,0,3,9,0,1,2,3,0,0,0,1,0,3,2,8,2,1,3,2,0,0,0,2,0,0,11]

theorem envBound47057 : H12AffineFastState.Bounded env47057 := by
  intro p hp
  have h : env47057.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47056_47057 : H12AffineEnvironment.transform 1 3 env47056 = env47057 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env47056 == env47057) = true)

def env47058 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,17,98781,8328,65,4295167,5393,17665,67619,1501,4256860,256,21792,46212,74250]

theorem envBound47058 : H12AffineFastState.Bounded env47058 := by
  intro p hp
  have h : env47058.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47025_47058 : H12AffineEnvironment.transform 22 17 env47025 = env47058 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env47025 == env47058) = true)

theorem identity47058 : scanCanonicalize (H12AffineFastState.compose env47058 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 180408) := by decide +kernel

theorem selectedBound47058 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47059 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180408,17,98781,8328,65,215367,5393,17665,67619,1501,144612,256,21792,46212,74250]

theorem envBound47059 : H12AffineFastState.Bounded env47059 := by
  intro p hp
  have h : env47059.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47058_47059 : H12AffineEnvironment.transform 21 180408 env47058 = env47059 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 180408 env47058 == env47059) = true)

def env47060 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180272,17,98645,8192,65,215367,5393,17665,67619,1365,144492,256,21792,46092,74250]

theorem envBound47060 : H12AffineFastState.Bounded env47060 := by
  intro p hp
  have h : env47060.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47059_47060 : H12AffineEnvironment.transform 6 8 env47059 = env47060 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47059 == env47060) = true)

theorem identity47060 : scanCanonicalize (H12AffineFastState.compose env47060 (packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 70679) := by decide +kernel

theorem selectedBound47060 : packedSelected [0,1,3,4,7,10,11,16,19,20,22,24,26,28,31,32] rootPS < 2^1333 := by decide +kernel

def env47061 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,70679,56356,1024,32769,4161,119847,17,98645,8192,65,23888,5393,17665,67619,1365,73851,256,21792,46092,74250]

theorem envBound47061 : H12AffineFastState.Bounded env47061 := by
  intro p hp
  have h : env47061.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47060_47061 : H12AffineEnvironment.transform 16 70679 env47060 = env47061 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70679 env47060 == env47061) = true)

theorem identity47061 : scanCanonicalize (H12AffineFastState.compose env47061 (packedSelected [1,10,16,19,20,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound47061 : packedSelected [1,10,16,19,20,28] rootPS < 2^1333 := by decide +kernel

def env47062 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,342,5441,56356,1024,32769,4161,54641,17,32771,8192,65,23888,5393,17665,2421,1365,8493,256,21792,46092,9052]

theorem envBound47062 : H12AffineFastState.Bounded env47062 := by
  intro p hp
  have h : env47062.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47061_47062 : H12AffineEnvironment.transform 15 342 env47061 = env47062 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env47061 == env47062) = true)

theorem identity47062 : scanCanonicalize (H12AffineFastState.compose env47062 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47062 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env47063 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,16384,32768,342,5441,56356,1024,32769,4161,54641,17,32771,349,65,23888,5393,17665,2421,1365,112,256,21792,38225,513]

theorem envBound47063 : H12AffineFastState.Bounded env47063 := by
  intro p hp
  have h : env47063.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47062_47063 : H12AffineEnvironment.transform 12 349 env47062 = env47063 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47062 == env47063) = true)

def env47064 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,180273,17,98644,8193,65,215367,5393,17665,67619,1364,144493,256,21792,46093,74250]

theorem envBound47064 : H12AffineFastState.Bounded env47064 := by
  intro p hp
  have h : env47064.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47059_47064 : H12AffineEnvironment.transform 6 9 env47059 = env47064 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env47059 == env47064) = true)

theorem identity47064 : scanCanonicalize (H12AffineFastState.compose env47064 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound47064 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47065 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,131072,223599,1024,8541,4161,156013,17,73736,8193,65,215367,5393,17665,67619,1364,144493,256,21792,5457,74250]

theorem envBound47065 : H12AffineFastState.Bounded env47065 := by
  intro p hp
  have h : env47065.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47064_47065 : H12AffineEnvironment.transform 14 8540 env47064 = env47065 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env47064 == env47065) = true)

theorem identity47065 : scanCanonicalize (H12AffineFastState.compose env47065 (packedSelected [18,23] rootPS)) = affineNative (2^(16+1) ^^^ 24908) := by decide +kernel

theorem selectedBound47065 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env47066 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,65536,24908,67619,1024,8541,4161,33,17,73736,8193,65,75787,5393,17665,67619,1364,21793,256,21792,5457,74250]

theorem envBound47066 : H12AffineFastState.Bounded env47066 := by
  intro p hp
  have h : env47066.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47065_47066 : H12AffineEnvironment.transform 16 24908 env47065 = env47066 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24908 env47065 == env47066) = true)

theorem identity47066 : scanCanonicalize (H12AffineFastState.compose env47066 (packedSelected [2,3,5,10,14] rootPS)) = affineNative (2^(15+1) ^^^ 8495) := by decide +kernel

theorem selectedBound47066 : packedSelected [2,3,5,10,14] rootPS < 2^1333 := by decide +kernel

def env47067 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,8495,24908,10508,1024,8541,4161,33,17,295,8193,65,2340,5393,17665,10508,1364,21793,256,21792,5457,805]

theorem envBound47067 : H12AffineFastState.Bounded env47067 := by
  intro p hp
  have h : env47067.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47066_47067 : H12AffineEnvironment.transform 15 8495 env47066 = env47067 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8495 env47066 == env47067) = true)

theorem identity47067 : scanCanonicalize (H12AffineFastState.compose env47067 (packedSelected [2,4,9,12,15,20] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound47067 : packedSelected [2,4,9,12,15,20] rootPS < 2^1333 := by decide +kernel

def env47068 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,16384,8312,8203,24680,10280,1024,8313,4161,33,17,3,8193,65,2048,5173,17445,10280,1136,21509,36,21508,5237,513]

theorem envBound47068 : H12AffineFastState.Bounded env47068 := by
  intro p hp
  have h : env47068.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47067_47068 : H12AffineEnvironment.transform 7 36 env47067 = env47068 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env47067 == env47068) = true)

theorem identity47068 : scanCanonicalize (H12AffineFastState.compose env47068 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 12392) := by decide +kernel

theorem selectedBound47068 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47069 : List Nat := [2,4,8,16,32,64,9,36,512,1024,2048,4096,8192,12392,8312,8203,4096,10280,1024,8313,4161,33,17,3,8193,65,2048,5173,13389,10280,1136,9325,36,9324,5237,513]

theorem envBound47069 : H12AffineFastState.Bounded env47069 := by
  intro p hp
  have h : env47069.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47068_47069 : H12AffineEnvironment.transform 13 12392 env47068 = env47069 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12392 env47068 == env47069) = true)

theorem identity47069 : scanCanonicalize (H12AffineFastState.compose env47069 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound47069 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env47070 : List Nat := [2,4,8,16,32,64,9,36,512,101,2048,4096,8192,12392,8312,8203,4096,10280,101,8313,4161,33,17,3,8193,65,2048,4176,12328,10280,21,8200,36,8201,4112,513]

theorem envBound47070 : H12AffineFastState.Bounded env47070 := by
  intro p hp
  have h : env47070.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47069_47070 : H12AffineEnvironment.transform 9 101 env47069 = env47070 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env47069 == env47070) = true)

theorem identity47070 : scanCanonicalize (H12AffineFastState.compose env47070 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47070 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env47071 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,8192,12344,8232,8203,4096,10280,53,8233,4113,33,17,3,8193,17,2048,4096,12328,10280,21,8200,36,8201,4112,513]

theorem envBound47071 : H12AffineFastState.Bounded env47071 := by
  intro p hp
  have h : env47071.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47070_47071 : H12AffineEnvironment.transform 5 16 env47070 = env47071 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47070 == env47071) = true)

theorem identity47071 : scanCanonicalize (H12AffineFastState.compose env47071 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound47071 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47072 : List Nat := [2,4,8,16,32,16,9,36,512,53,2048,4096,41,4113,1,34,4096,2049,53,0,4113,33,17,3,40,17,2048,4096,4097,2049,21,33,36,32,4112,513]

theorem envBound47072 : H12AffineFastState.Bounded env47072 := by
  intro p hp
  have h : env47072.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47071_47072 : H12AffineEnvironment.transform 12 41 env47071 = env47072 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env47071 == env47072) = true)

theorem identity47072 : scanCanonicalize (H12AffineFastState.compose env47072 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound47072 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47073 : List Nat := [2,4,8,4,32,4,9,36,512,33,2048,4096,41,4101,1,34,4096,2049,33,0,4101,33,5,3,40,5,2048,4096,4097,2049,1,33,36,32,4100,513]

theorem envBound47073 : H12AffineFastState.Bounded env47073 := by
  intro p hp
  have h : env47073.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47072_47073 : H12AffineEnvironment.transform 3 4 env47072 = env47073 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env47072 == env47073) = true)

theorem identity47073 : scanCanonicalize (H12AffineFastState.compose env47073 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 39) := by decide +kernel

theorem selectedBound47073 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47074 : List Nat := [2,4,8,4,32,4,9,36,39,33,2048,4096,41,4101,1,34,4096,2049,33,0,4101,33,5,3,40,5,2048,4096,4097,2049,1,33,36,32,4100,38]

theorem envBound47074 : H12AffineFastState.Bounded env47074 := by
  intro p hp
  have h : env47074.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47073_47074 : H12AffineEnvironment.transform 8 39 env47073 = env47074 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 39 env47073 == env47074) = true)

theorem identity47074 : scanCanonicalize (H12AffineFastState.compose env47074 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound47074 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47075 : List Nat := [2,4,8,4,32,4,9,36,39,33,2048,1,41,4,1,34,1,2049,33,0,4,33,5,3,40,5,2048,1,0,2049,1,33,36,32,5,38]

theorem envBound47075 : H12AffineFastState.Bounded env47075 := by
  intro p hp
  have h : env47075.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47074_47075 : H12AffineEnvironment.transform 11 1 env47074 = env47075 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env47074 == env47075) = true)

theorem identity47075 : scanCanonicalize (H12AffineFastState.compose env47075 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound47075 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env47076 : List Nat := [2,4,8,4,32,4,9,36,39,33,10,1,41,4,1,34,1,11,33,0,4,33,5,3,40,5,10,1,0,11,1,33,36,32,5,38]

theorem envBound47076 : H12AffineFastState.Bounded env47076 := by
  intro p hp
  have h : env47076.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47075_47076 : H12AffineEnvironment.transform 10 10 env47075 = env47076 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env47075 == env47076) = true)

theorem identity47076 : scanCanonicalize (H12AffineFastState.compose env47076 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound47076 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env47077 : List Nat := [2,4,8,4,1,4,9,5,6,0,10,1,8,4,1,3,1,11,0,0,4,0,5,3,9,5,10,1,0,11,1,0,5,1,5,7]

theorem envBound47077 : H12AffineFastState.Bounded env47077 := by
  intro p hp
  have h : env47077.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47076_47077 : H12AffineEnvironment.transform 4 1 env47076 = env47077 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env47076 == env47077) = true)

theorem identity47077 : scanCanonicalize (H12AffineFastState.compose env47077 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound47077 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env47078 : List Nat := [2,4,7,4,1,4,6,5,6,0,5,1,7,4,1,3,1,4,0,0,4,0,5,3,6,5,5,1,0,4,1,0,5,1,5,7]

theorem envBound47078 : H12AffineFastState.Bounded env47078 := by
  intro p hp
  have h : env47078.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47077_47078 : H12AffineEnvironment.transform 2 7 env47077 = env47078 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env47077 == env47078) = true)

def env47079 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,2097152,4194304,8388608,2199965,8328,65,14784942,5392,10507601,8456242,10491276,4256861,256,8410416,8434836,10564187]

theorem envBound47079 : H12AffineFastState.Bounded env47079 := by
  intro p hp
  have h : env47079.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans46978_47079 : H12AffineEnvironment.transform 23 2199965 env46978 = env47079 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2199965 env46978 == env47079) = true)

def env47080 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,8388608,98781,8328,65,12683758,5392,8406289,8456242,8390092,4256861,256,8410416,8434836,8462875]

theorem envBound47080 : H12AffineFastState.Bounded env47080 := by
  intro p hp
  have h : env47080.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47079_47080 : H12AffineEnvironment.transform 20 4160 env47079 = env47080 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env47079 == env47080) = true)

def env47081 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,16,98781,8328,65,4295166,5392,17665,67618,1500,4256861,256,21792,46212,74251]

theorem envBound47081 : H12AffineFastState.Bounded env47081 := by
  intro p hp
  have h : env47081.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47080_47081 : H12AffineEnvironment.transform 22 16 env47080 = env47081 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env47080 == env47081) = true)

theorem identity47081 : scanCanonicalize (H12AffineFastState.compose env47081 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound47081 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47082 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,4194304,16,41431,8328,65,4237812,5392,17665,10280,1500,4256861,256,21792,46212,513]

theorem envBound47082 : H12AffineFastState.Bounded env47082 := by
  intro p hp
  have h : env47082.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47081_47082 : H12AffineEnvironment.transform 15 8202 env47081 = env47082 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env47081 == env47082) = true)

theorem identity47082 : scanCanonicalize (H12AffineFastState.compose env47082 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(21+1) ^^^ 32936) := by decide +kernel

theorem selectedBound47082 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env47083 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190521,1024,32769,4160,32936,16,41431,8328,65,10588,5392,17665,10280,1500,29941,256,21792,46212,513]

theorem envBound47083 : H12AffineFastState.Bounded env47083 := by
  intro p hp
  have h : env47083.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47082_47083 : H12AffineEnvironment.transform 21 32936 env47082 = env47083 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32936 env47082 == env47083) = true)

theorem identity47083 : scanCanonicalize (H12AffineFastState.compose env47083 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound47083 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env47084 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4160,32936,16,41431,8328,65,10588,5392,17665,10280,1500,29941,256,21792,46212,513]

theorem envBound47084 : H12AffineFastState.Bounded env47084 := by
  intro p hp
  have h : env47084.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47083_47084 : H12AffineEnvironment.transform 16 16401 env47083 = env47084 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env47083 == env47084) = true)

theorem identity47084 : scanCanonicalize (H12AffineFastState.compose env47084 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47084 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env47085 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43048,1024,32769,4112,32936,16,41351,8328,17,10508,5392,17665,10280,1420,29861,256,21792,46212,513]

theorem envBound47085 : H12AffineFastState.Bounded env47085 := by
  intro p hp
  have h : env47085.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47084_47085 : H12AffineEnvironment.transform 5 16 env47084 = env47085 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47084 == env47085) = true)

theorem identity47085 : scanCanonicalize (H12AffineFastState.compose env47085 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound47085 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env47086 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,262,16401,35108,1024,32769,4112,32936,16,32907,388,17,2048,5392,17665,2340,1420,21929,256,21792,38280,513]

theorem envBound47086 : H12AffineFastState.Bounded env47086 := by
  intro p hp
  have h : env47086.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47085_47086 : H12AffineEnvironment.transform 12 268 env47085 = env47086 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env47085 == env47086) = true)

theorem identity47086 : scanCanonicalize (H12AffineFastState.compose env47086 (packedSelected [3,6,8,10,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 22805) := by decide +kernel

theorem selectedBound47086 : packedSelected [3,6,8,10,14,17] rootPS < 2^1333 := by decide +kernel

def env47087 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,22805,262,16401,20529,1024,22804,4112,22973,16,22942,388,17,2048,5392,17665,2340,1420,21929,256,21792,19613,513]

theorem envBound47087 : H12AffineFastState.Bounded env47087 := by
  intro p hp
  have h : env47087.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47086_47087 : H12AffineEnvironment.transform 14 22805 env47086 = env47087 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22805 env47086 == env47087) = true)

theorem identity47087 : scanCanonicalize (H12AffineFastState.compose env47087 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound47087 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env47088 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,22805,262,16401,20529,1024,22804,4112,22837,16,22806,268,17,2048,5392,17665,2340,1284,21793,256,21792,19477,513]

theorem envBound47088 : H12AffineFastState.Bounded env47088 := by
  intro p hp
  have h : env47088.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47087_47088 : H12AffineEnvironment.transform 6 8 env47087 = env47088 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47087 == env47088) = true)

theorem identity47088 : scanCanonicalize (H12AffineFastState.compose env47088 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound47088 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47089 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5377,3092,262,5392,1328,1024,3093,4112,3124,16,3095,268,17,2048,5392,4096,2340,1284,32,256,33,6420,513]

theorem envBound47089 : H12AffineFastState.Bounded env47089 := by
  intro p hp
  have h : env47089.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47088_47089 : H12AffineEnvironment.transform 13 5377 env47088 = env47089 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env47088 == env47089) = true)

theorem identity47089 : scanCanonicalize (H12AffineFastState.compose env47089 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 560) := by decide +kernel

theorem selectedBound47089 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47090 : List Nat := [2,4,8,16,32,16,8,256,512,1024,560,4096,268,5377,1572,262,5392,1328,1024,1573,4112,1540,16,1575,268,17,560,5392,4096,788,1284,32,256,33,4900,513]

theorem envBound47090 : H12AffineFastState.Bounded env47090 := by
  intro p hp
  have h : env47090.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47089_47090 : H12AffineEnvironment.transform 10 560 env47089 = env47090 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 560 env47089 == env47090) = true)

theorem identity47090 : scanCanonicalize (H12AffineFastState.compose env47090 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound47090 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env47091 : List Nat := [2,4,8,16,32,16,8,256,512,1024,560,292,268,1061,1572,262,1076,1328,1024,1573,308,1540,16,1575,268,17,560,1076,292,788,1284,32,256,33,512,513]

theorem envBound47091 : H12AffineFastState.Bounded env47091 := by
  intro p hp
  have h : env47091.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47090_47091 : H12AffineEnvironment.transform 11 292 env47090 = env47091 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env47090 == env47091) = true)

theorem identity47091 : scanCanonicalize (H12AffineFastState.compose env47091 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound47091 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env47092 : List Nat := [2,4,8,0,32,0,8,256,512,1024,544,292,268,1061,1572,262,1060,1312,1024,1573,292,1540,0,1575,268,1,544,1060,292,772,1284,32,256,33,512,513]

theorem envBound47092 : H12AffineFastState.Bounded env47092 := by
  intro p hp
  have h : env47092.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47091_47092 : H12AffineEnvironment.transform 3 0 env47091 = env47092 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env47091 == env47092) = true)

theorem identity47092 : scanCanonicalize (H12AffineFastState.compose env47092 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47092 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env47093 : List Nat := [2,4,8,0,0,0,8,256,512,1024,512,260,268,1029,1540,262,1028,1280,1024,1541,260,1540,0,1543,268,1,512,1028,260,772,1284,0,256,1,512,513]

theorem envBound47093 : H12AffineFastState.Bounded env47093 := by
  intro p hp
  have h : env47093.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47092_47093 : H12AffineEnvironment.transform 4 0 env47092 = env47093 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47092 == env47093) = true)

theorem identity47093 : scanCanonicalize (H12AffineFastState.compose env47093 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound47093 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env47094 : List Nat := [2,4,8,0,0,0,8,256,261,1024,261,260,268,1029,1281,262,1028,1280,1024,1280,260,1281,0,1282,268,1,261,1028,260,1,1284,0,256,1,261,260]

theorem envBound47094 : H12AffineFastState.Bounded env47094 := by
  intro p hp
  have h : env47094.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47093_47094 : H12AffineEnvironment.transform 8 261 env47093 = env47094 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env47093 == env47094) = true)

def env47095 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,4194304,17,98781,8328,65,4295167,5392,17664,67619,1501,4256861,256,21793,46213,74250]

theorem envBound47095 : H12AffineFastState.Bounded env47095 := by
  intro p hp
  have h : env47095.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47080_47095 : H12AffineEnvironment.transform 22 17 env47080 = env47095 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env47080 == env47095) = true)

theorem identity47095 : scanCanonicalize (H12AffineFastState.compose env47095 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 254131) := by decide +kernel

theorem selectedBound47095 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47096 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4160,254131,17,98781,8328,65,158028,5392,17664,67619,1501,201966,256,21793,46213,74250]

theorem envBound47096 : H12AffineFastState.Bounded env47096 := by
  intro p hp
  have h : env47096.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47095_47096 : H12AffineEnvironment.transform 21 254131 env47095 = env47096 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 254131 env47095 == env47096) = true)

theorem identity47096 : scanCanonicalize (H12AffineFastState.compose env47096 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound47096 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env47097 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,190520,1024,32769,4160,180408,17,41430,8328,65,158028,5392,17664,10280,1501,144613,256,21793,46213,513]

theorem envBound47097 : H12AffineFastState.Bounded env47097 := by
  intro p hp
  have h : env47097.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47096_47097 : H12AffineEnvironment.transform 15 8203 env47096 = env47097 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env47096 == env47097) = true)

theorem identity47097 : scanCanonicalize (H12AffineFastState.compose env47097 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound47097 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env47098 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,16400,43048,1024,32769,4160,32936,17,41430,8328,65,10588,5392,17664,10280,1501,29941,256,21793,46213,513]

theorem envBound47098 : H12AffineFastState.Bounded env47098 := by
  intro p hp
  have h : env47098.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47097_47098 : H12AffineEnvironment.transform 16 16400 env47097 = env47098 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env47097 == env47098) = true)

theorem identity47098 : scanCanonicalize (H12AffineFastState.compose env47098 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound47098 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env47099 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,16400,23589,1024,29708,4160,29861,17,21979,8328,65,10588,5392,17664,10280,1501,29941,256,21793,16520,513]

theorem envBound47099 : H12AffineFastState.Bounded env47099 := by
  intro p hp
  have h : env47099.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47098_47099 : H12AffineEnvironment.transform 14 29709 env47098 = env47099 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env47098 == env47099) = true)

theorem identity47099 : scanCanonicalize (H12AffineFastState.compose env47099 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound47099 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env47100 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,1,8203,13340,10281,1024,0,4160,169,17,8663,8328,65,10588,5392,12556,10280,1501,249,256,8493,13444,513]

theorem envBound47100 : H12AffineFastState.Bounded env47100 := by
  intro p hp
  have h : env47100.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47099_47100 : H12AffineEnvironment.transform 13 13324 env47099 = env47100 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env47099 == env47100) = true)

theorem identity47100 : scanCanonicalize (H12AffineFastState.compose env47100 (packedSelected [0,5,6,8,9,10,11,14,15] rootPS)) = affineNative (2^(11+1) ^^^ 2540) := by decide +kernel

theorem selectedBound47100 : packedSelected [0,5,6,8,9,10,11,14,15] rootPS < 2^1333 := by decide +kernel

def env47101 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2540,8192,11744,1,8203,11760,10281,1024,0,2476,169,17,8663,8328,65,10588,3324,10464,10280,1501,249,256,8493,11624,513]

theorem envBound47101 : H12AffineFastState.Bounded env47101 := by
  intro p hp
  have h : env47101.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47100_47101 : H12AffineEnvironment.transform 11 2540 env47100 = env47101 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2540 env47100 == env47101) = true)

theorem identity47101 : scanCanonicalize (H12AffineFastState.compose env47101 (packedSelected [1,6,7,8,9,10,11] rootPS)) = affineNative (2^(12+1) ^^^ 3149) := by decide +kernel

theorem selectedBound47101 : packedSelected [1,6,7,8,9,10,11] rootPS < 2^1333 := by decide +kernel

def env47102 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,2540,3149,429,1,3142,445,1124,1024,0,2476,169,17,3482,3269,65,1297,3324,1197,1125,1501,249,256,3424,293,513]

theorem envBound47102 : H12AffineFastState.Bounded env47102 := by
  intro p hp
  have h : env47102.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47101_47102 : H12AffineEnvironment.transform 12 3149 env47101 = env47102 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3149 env47101 == env47102) = true)

theorem identity47102 : scanCanonicalize (H12AffineFastState.compose env47102 (packedSelected [1,3,5,7,8,9] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound47102 : packedSelected [1,3,5,7,8,9] rootPS < 2^1333 := by decide +kernel

def env47103 : List Nat := [2,4,8,16,32,64,128,256,512,1024,1296,1276,349,429,1,342,445,1124,1024,0,1212,169,17,138,469,65,1297,492,1197,1125,1501,249,256,112,293,513]

theorem envBound47103 : H12AffineFastState.Bounded env47103 := by
  intro p hp
  have h : env47103.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47102_47103 : H12AffineEnvironment.transform 10 1296 env47102 = env47103 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env47102 == env47103) = true)

theorem identity47103 : scanCanonicalize (H12AffineFastState.compose env47103 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound47103 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env47104 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1296,1061,349,372,1,342,356,1124,1024,0,1125,112,17,83,268,65,1297,309,1140,1125,1284,32,256,112,293,513]

theorem envBound47104 : H12AffineFastState.Bounded env47104 := by
  intro p hp
  have h : env47104.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47103_47104 : H12AffineEnvironment.transform 6 89 env47103 = env47104 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env47103 == env47104) = true)

theorem identity47104 : scanCanonicalize (H12AffineFastState.compose env47104 (packedSelected [1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound47104 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env47105 : List Nat := [2,4,8,16,32,64,89,256,512,52,292,17,349,372,1,342,356,80,52,0,81,112,17,83,268,65,293,309,64,81,304,32,256,112,293,513]

theorem envBound47105 : H12AffineFastState.Bounded env47105 := by
  intro p hp
  have h : env47105.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47104_47105 : H12AffineEnvironment.transform 9 52 env47104 = env47105 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env47104 == env47105) = true)

theorem identity47105 : scanCanonicalize (H12AffineFastState.compose env47105 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound47105 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47106 : List Nat := [2,4,8,16,32,64,89,37,512,52,1,17,120,81,1,115,65,80,52,0,81,112,17,83,41,65,0,16,64,81,21,32,37,112,0,513]

theorem envBound47106 : H12AffineFastState.Bounded env47106 := by
  intro p hp
  have h : env47106.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47105_47106 : H12AffineEnvironment.transform 7 37 env47105 = env47106 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env47105 == env47106) = true)

theorem identity47106 : scanCanonicalize (H12AffineFastState.compose env47106 (packedSelected [0,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound47106 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env47107 : List Nat := [2,4,8,16,32,17,8,37,512,52,1,17,41,0,1,34,16,1,52,0,0,33,17,2,41,16,0,16,17,0,21,32,37,33,0,513]

theorem envBound47107 : H12AffineFastState.Bounded env47107 := by
  intro p hp
  have h : env47107.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47106_47107 : H12AffineEnvironment.transform 5 17 env47106 = env47107 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env47106 == env47107) = true)

theorem identity47107 : scanCanonicalize (H12AffineFastState.compose env47107 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound47107 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47108 : List Nat := [2,4,8,16,32,17,8,37,33,52,1,17,41,0,1,34,16,1,52,0,0,33,17,2,41,16,0,16,17,0,21,32,37,33,0,32]

theorem envBound47108 : H12AffineFastState.Bounded env47108 := by
  intro p hp
  have h : env47108.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47107_47108 : H12AffineEnvironment.transform 8 33 env47107 = env47108 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env47107 == env47108) = true)

theorem identity47108 : scanCanonicalize (H12AffineFastState.compose env47108 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound47108 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47109 : List Nat := [2,4,8,1,32,0,8,37,33,37,1,0,41,0,1,34,1,1,37,0,0,33,0,2,41,1,0,1,0,0,4,32,37,33,0,32]

theorem envBound47109 : H12AffineFastState.Bounded env47109 := by
  intro p hp
  have h : env47109.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47108_47109 : H12AffineEnvironment.transform 3 1 env47108 = env47109 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env47108 == env47109) = true)

def env47110 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,8388608,98780,8328,65,12683759,5392,8406288,8456242,8390093,4256861,256,8410416,8434836,8462874]

theorem envBound47110 : H12AffineFastState.Bounded env47110 := by
  intro p hp
  have h : env47110.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47079_47110 : H12AffineEnvironment.transform 20 4161 env47079 = env47110 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env47079 == env47110) = true)

def env47111 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247859,1024,32769,4161,4194304,16,98780,8328,65,4295167,5392,17664,67618,1501,4256861,256,21792,46212,74250]

theorem envBound47111 : H12AffineFastState.Bounded env47111 := by
  intro p hp
  have h : env47111.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47110_47111 : H12AffineEnvironment.transform 22 16 env47110 = env47111 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env47110 == env47111) = true)

theorem identity47111 : scanCanonicalize (H12AffineFastState.compose env47111 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound47111 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env47112 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,138477,1024,32769,4161,4194304,16,21762,8328,65,4218145,5392,17664,56572,1501,4256861,256,21792,46212,63188]

theorem envBound47112 : H12AffineFastState.Bounded env47112 := by
  intro p hp
  have h : env47112.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47111_47112 : H12AffineEnvironment.transform 15 54494 env47111 = env47112 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env47111 == env47112) = true)

def env47113 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,138341,1024,32769,4161,4194304,16,21762,8192,65,4218145,5392,17664,56436,1365,4256861,256,21792,46092,63068]

theorem envBound47113 : H12AffineFastState.Bounded env47113 := by
  intro p hp
  have h : env47113.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47112_47113 : H12AffineEnvironment.transform 6 8 env47112 = env47113 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env47112 == env47113) = true)

theorem identity47113 : scanCanonicalize (H12AffineFastState.compose env47113 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound47113 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env47114 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,13388,10281,1024,32769,4161,4194304,16,21762,8192,65,4218145,5392,17664,56436,1365,4256861,256,21792,46092,63068]

theorem envBound47114 : H12AffineFastState.Bounded env47114 := by
  intro p hp
  have h : env47114.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47113_47114 : H12AffineEnvironment.transform 16 13388 env47113 = env47114 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env47113 == env47114) = true)

theorem identity47114 : scanCanonicalize (H12AffineFastState.compose env47114 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound47114 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env47115 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,40971,13388,10281,1024,32769,4161,4194304,16,8543,8192,65,4204924,5392,12637,43049,1365,4227072,256,8573,46092,33281]

theorem envBound47115 : H12AffineFastState.Bounded env47115 := by
  intro p hp
  have h : env47115.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47114_47115 : H12AffineEnvironment.transform 13 13405 env47114 = env47115 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env47114 == env47115) = true)

theorem identity47115 : scanCanonicalize (H12AffineFastState.compose env47115 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound47115 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env47116 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33110,5393,2420,1024,32769,4161,4194304,16,2,349,65,4196385,5392,4096,35188,1365,4227072,256,32,38225,33281]

theorem envBound47116 : H12AffineFastState.Bounded env47116 := by
  intro p hp
  have h : env47116.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47115_47116 : H12AffineEnvironment.transform 12 349 env47115 = env47116 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env47115 == env47116) = true)

theorem identity47116 : scanCanonicalize (H12AffineFastState.compose env47116 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(21+1) ^^^ 32881) := by decide +kernel

theorem selectedBound47116 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env47117 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,32768,33110,5393,2420,1024,32769,4161,32881,16,2,349,65,34896,5392,4096,35188,1365,113,256,32,38225,33281]

theorem envBound47117 : H12AffineFastState.Bounded env47117 := by
  intro p hp
  have h : env47117.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47116_47117 : H12AffineEnvironment.transform 21 32881 env47116 = env47117 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32881 env47116 == env47117) = true)

theorem identity47117 : scanCanonicalize (H12AffineFastState.compose env47117 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound47117 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env47118 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5376,32768,33030,5393,2340,1024,32769,4113,32801,16,2,269,17,34816,5392,4096,35108,1285,33,256,32,38145,33281]

theorem envBound47118 : H12AffineFastState.Bounded env47118 := by
  intro p hp
  have h : env47118.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47117_47118 : H12AffineEnvironment.transform 5 16 env47117 = env47118 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env47117 == env47118) = true)

theorem identity47118 : scanCanonicalize (H12AffineFastState.compose env47118 (packedSelected [3,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound47118 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env47119 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5376,32768,33030,5393,2308,1024,32769,4113,32769,16,2,269,17,34816,5392,4096,35076,1285,1,256,0,38145,33281]

theorem envBound47119 : H12AffineFastState.Bounded env47119 := by
  intro p hp
  have h : env47119.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47118_47119 : H12AffineEnvironment.transform 4 0 env47118 = env47119 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env47118 == env47119) = true)

theorem identity47119 : scanCanonicalize (H12AffineFastState.compose env47119 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound47119 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env47120 : List Nat := [2,4,8,16,0,16,8,256,512,1024,2048,4096,269,5376,0,262,5393,2308,1024,1,4113,1,16,2,269,17,2048,5392,4096,2308,1285,1,256,0,5377,513]

theorem envBound47120 : H12AffineFastState.Bounded env47120 := by
  intro p hp
  have h : env47120.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47119_47120 : H12AffineEnvironment.transform 14 0 env47119 = env47120 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env47119 == env47120) = true)

theorem identity47120 : scanCanonicalize (H12AffineFastState.compose env47120 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound47120 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env47121 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,0,2,5141,2048,1024,1,4113,1,16,2,9,17,2048,5140,4096,2048,1025,1,4,0,5125,513]

theorem envBound47121 : H12AffineFastState.Bounded env47121 := by
  intro p hp
  have h : env47121.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47120_47121 : H12AffineEnvironment.transform 7 4 env47120 = env47121 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env47120 == env47121) = true)

theorem identity47121 : scanCanonicalize (H12AffineFastState.compose env47121 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 523) := by decide +kernel

theorem selectedBound47121 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env47122 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,4096,9,5124,0,2,5141,523,1024,1,4113,1,16,2,9,17,523,5140,4096,523,1025,1,4,0,5125,513]

theorem envBound47122 : H12AffineFastState.Bounded env47122 := by
  intro p hp
  have h : env47122.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47121_47122 : H12AffineEnvironment.transform 10 523 env47121 = env47122 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 523 env47121 == env47122) = true)

def env47123 : List Nat := [2,4,8,16,0,16,8,4,512,1024,523,16,9,1044,0,2,1029,523,1024,1,1,1,16,2,9,17,523,1028,16,523,1025,1,4,0,1045,513]

theorem envBound47123 : H12AffineFastState.Bounded env47123 := by
  intro p hp
  have h : env47123.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47122_47123 : H12AffineEnvironment.transform 11 16 env47122 = env47123 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env47122 == env47123) = true)

theorem identity47123 : scanCanonicalize (H12AffineFastState.compose env47123 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound47123 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env47124 : List Nat := [2,4,8,16,0,16,8,4,30,1024,21,16,9,1044,0,2,1029,21,1024,1,1,1,16,2,9,17,21,1028,16,21,1025,1,4,0,1045,31]

theorem envBound47124 : H12AffineFastState.Bounded env47124 := by
  intro p hp
  have h : env47124.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47123_47124 : H12AffineEnvironment.transform 8 30 env47123 = env47124 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env47123 == env47124) = true)

def env47125 : List Nat := [2,4,8,16,0,16,8,4,30,0,21,16,9,20,0,2,5,21,0,1,1,1,16,2,9,17,21,4,16,21,1,1,4,0,21,31]

theorem envBound47125 : H12AffineFastState.Bounded env47125 := by
  intro p hp
  have h : env47125.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47124_47125 : H12AffineEnvironment.transform 9 0 env47124 = env47125 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 0 env47124 == env47125) = true)

theorem identity47125 : scanCanonicalize (H12AffineFastState.compose env47125 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound47125 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env47126 : List Nat := [2,4,8,7,0,7,8,4,9,0,2,7,9,3,0,2,5,2,0,1,1,1,7,2,9,6,2,4,7,2,1,1,4,0,2,8]

theorem envBound47126 : H12AffineFastState.Bounded env47126 := by
  intro p hp
  have h : env47126.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47125_47126 : H12AffineEnvironment.transform 3 7 env47125 = env47126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env47125 == env47126) = true)

def leafEnv47126 : List Nat := [2,4,8,7,0,7,8,4,9,0,2,7,9,3,0,2,5,2,0,1,1,1,7,2,0,9,1,6,2,4,7,2,1,1,4,0,5,2,2,8,1,0,0]

def active47126 : List Nat := [0,1,2]

def tree47126 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood47126 : H12WitnessSearch.Good tree47126 := H12GlobalWitnessIndex.good

theorem leafIdentity47126 : H12AffineFastState.composeSystem env47126 rootObs = leafEnv47126 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env47126 rootObs == leafEnv47126) = true)

theorem terminalChecked47126 : H12PackedTerminal.terminalCheckFast leafEnv47126 active47126 tree47126 = true := by decide +kernel

def env47127 : List Nat := [2,4,8,16,0,16,8,4,30,1,21,16,9,21,0,2,4,21,1,1,1,1,16,2,9,17,21,5,16,21,0,1,4,0,20,31]

theorem envBound47127 : H12AffineFastState.Bounded env47127 := by
  intro p hp
  have h : env47127.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans47124_47127 : H12AffineEnvironment.transform 9 1 env47124 = env47127 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 1 env47124 == env47127) = true)

end H12CloudChart1