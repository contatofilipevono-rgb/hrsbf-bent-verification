import H12CloudChart1Data049

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound12530 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,2420,1024,32769,4161,54560,16,41431,8328,65,56713,5392,17664,35189,1500,8573,256,21792,46212,513]

theorem envBound12531 : H12AffineFastState.Bounded env12531 := by
  intro p hp
  have h : env12531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12530_12531 : H12AffineEnvironment.transform 17 2420 env12530 = env12531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2420 env12530 == env12531) = true)

theorem identity12531 : scanCanonicalize (H12AffineFastState.compose env12531 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound12531 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12532 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21896,8202,16401,2420,1024,21897,4161,168,16,29791,8328,65,2049,5392,17664,23805,1500,8573,256,21792,24844,513]

theorem envBound12532 : H12AffineFastState.Bounded env12532 := by
  intro p hp
  have h : env12532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12531_12532 : H12AffineEnvironment.transform 14 21896 env12531 = env12532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env12531 == env12532) = true)

theorem identity12532 : scanCanonicalize (H12AffineFastState.compose env12532 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound12532 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env12533 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21896,478,16401,2420,1024,21897,4161,168,16,21899,348,65,2049,5392,17664,23805,1500,169,256,21792,16600,513]

theorem envBound12533 : H12AffineFastState.Bounded env12533 := by
  intro p hp
  have h : env12533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12532_12533 : H12AffineEnvironment.transform 12 468 env12532 = env12533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env12532 == env12533) = true)

theorem identity12533 : scanCanonicalize (H12AffineFastState.compose env12533 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound12533 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12534 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5512,0,478,5529,2420,1024,1,4161,168,16,3,348,65,2049,5392,4232,2421,1500,169,256,168,5456,513]

theorem envBound12534 : H12AffineFastState.Bounded env12534 := by
  intro p hp
  have h : env12534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12533_12534 : H12AffineEnvironment.transform 13 5512 env12533 = env12534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env12533 == env12534) = true)

theorem identity12534 : scanCanonicalize (H12AffineFastState.compose env12534 (packedSelected [0,3,5,7,10] rootPS)) = affineNative (2^(11+1) ^^^ 1432) := by decide +kernel

theorem selectedBound12534 : packedSelected [0,3,5,7,10] rootPS < 2^1333 := by decide +kernel

def env12535 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1432,468,16,0,478,1,2420,1024,1,1497,168,16,3,348,65,2049,136,1296,2421,1500,169,256,168,200,513]

theorem envBound12535 : H12AffineFastState.Bounded env12535 := by
  intro p hp
  have h : env12535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12534_12535 : H12AffineEnvironment.transform 11 1432 env12534 = env12535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1432 env12534 == env12535) = true)

theorem identity12535 : scanCanonicalize (H12AffineFastState.compose env12535 (packedSelected [4,5,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 167) := by decide +kernel

theorem selectedBound12535 : packedSelected [4,5,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env12536 : List Nat := [2,4,8,16,32,64,128,256,512,167,2048,319,468,16,0,478,1,2420,167,1,382,168,16,3,348,65,2049,136,439,2421,379,169,256,168,200,513]

theorem envBound12536 : H12AffineFastState.Bounded env12536 := by
  intro p hp
  have h : env12536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12535_12536 : H12AffineEnvironment.transform 9 167 env12535 = env12536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 167 env12535 == env12536) = true)

theorem identity12536 : scanCanonicalize (H12AffineFastState.compose env12536 (packedSelected [4,9,14] rootPS)) = affineNative (2^(7+1) ^^^ 62) := by decide +kernel

theorem selectedBound12536 : packedSelected [4,9,14] rootPS < 2^1333 := by decide +kernel

def env12537 : List Nat := [2,4,8,16,32,64,128,62,512,167,2048,1,234,16,0,224,1,2122,167,1,64,168,16,3,98,65,2049,136,137,2123,69,169,62,168,200,513]

theorem envBound12537 : H12AffineFastState.Bounded env12537 := by
  intro p hp
  have h : env12537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12536_12537 : H12AffineEnvironment.transform 7 62 env12536 = env12537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 62 env12536 == env12537) = true)

def env12538 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2513205,510136,8328,65,6705548,2509876,396388,2136373,2102684,6729081,256,21793,46213,2175563]

theorem envBound12538 : H12AffineFastState.Bounded env12538 := by
  intro p hp
  have h : env12538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12423_12538 : H12AffineEnvironment.transform 22 2513205 env12423 = env12538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2513205 env12423 == env12538) = true)

def env12539 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169264,2513205,510136,8328,65,2409660,2509876,396388,2136373,2102684,2373705,256,21793,46213,2175563]

theorem envBound12539 : H12AffineFastState.Bounded env12539 := by
  intro p hp
  have h : env12539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12538_12539 : H12AffineEnvironment.transform 21 169264 env12538 = env12539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169264 env12538 == env12539) = true)

def env12540 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169264,412021,510136,8328,65,316668,416884,396388,35189,1500,272393,256,21793,46213,74251]

theorem envBound12540 : H12AffineFastState.Bounded env12540 := by
  intro p hp
  have h : env12540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12539_12540 : H12AffineEnvironment.transform 20 4160 env12539 = env12540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12539 == env12540) = true)

def env12541 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10280,1024,32769,4160,169264,155997,254096,8328,65,64724,160860,140364,35189,1500,33,256,21793,46213,74251]

theorem envBound12541 : H12AffineFastState.Bounded env12541 := by
  intro p hp
  have h : env12541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12540_12541 : H12AffineEnvironment.transform 17 10280 env12540 = env12541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12540 == env12541) = true)

def env12542 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10280,1024,32769,4160,21792,41293,73856,8328,65,64724,46156,58460,35189,1500,33,256,21793,46213,74251]

theorem envBound12542 : H12AffineFastState.Bounded env12542 := by
  intro p hp
  have h : env12542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12541_12542 : H12AffineEnvironment.transform 16 49168 env12541 = env12542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env12541 == env12542) = true)

theorem identity12542 : scanCanonicalize (H12AffineFastState.compose env12542 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound12542 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12543 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33110,49168,10280,1024,32769,4160,21792,41293,41430,8328,65,64724,46156,58460,35189,1500,33,256,21793,46213,41821]

theorem envBound12543 : H12AffineFastState.Bounded env12543 := by
  intro p hp
  have h : env12543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12542_12543 : H12AffineEnvironment.transform 15 33110 env12542 = env12543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env12542 == env12543) = true)

theorem identity12543 : scanCanonicalize (H12AffineFastState.compose env12543 (packedSelected [0,1,4,5,7,8,22,24] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound12543 : packedSelected [0,1,4,5,7,8,22,24] rootPS < 2^1333 := by decide +kernel

def env12544 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,81,263,16449,10280,1024,80,4160,21792,8476,8583,8328,65,31877,13341,25613,2340,1500,33,256,21793,13524,8972]

theorem envBound12544 : H12AffineFastState.Bounded env12544 := by
  intro p hp
  have h : env12544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12543_12544 : H12AffineEnvironment.transform 14 81 env12543 = env12544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env12543 == env12544) = true)

theorem identity12544 : scanCanonicalize (H12AffineFastState.compose env12544 (packedSelected [0,1,2,6,7,8,11,16,18,26] rootPS)) = affineNative (2^(12+1) ^^^ 1384) := by decide +kernel

theorem selectedBound12544 : packedSelected [0,1,2,6,7,8,11,16,18,26] rootPS < 2^1333 := by decide +kernel

def env12545 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,16384,81,263,16449,3392,1024,80,4160,21792,1140,1263,1504,65,23021,4469,16741,2340,1500,33,256,21793,4540,1636]

theorem envBound12545 : H12AffineFastState.Bounded env12545 := by
  intro p hp
  have h : env12545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12544_12545 : H12AffineEnvironment.transform 12 1384 env12544 = env12545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1384 env12544 == env12545) = true)

theorem identity12545 : scanCanonicalize (H12AffineFastState.compose env12545 (packedSelected [2,3,4,5,6,10,12,15,18,20,22,23] rootPS)) = affineNative (2^(13+1) ^^^ 4588) := by decide +kernel

theorem selectedBound12545 : packedSelected [2,3,4,5,6,10,12,15,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env12546 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,1384,4588,81,263,4525,3392,1024,80,4160,1228,1140,1263,1504,65,2049,4469,4233,2340,1500,33,256,1229,4540,1636]

theorem envBound12546 : H12AffineFastState.Bounded env12546 := by
  intro p hp
  have h : env12546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12545_12546 : H12AffineEnvironment.transform 13 4588 env12545 = env12546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4588 env12545 == env12546) = true)

theorem identity12546 : scanCanonicalize (H12AffineFastState.compose env12546 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(9+1) ^^^ 236) := by decide +kernel

theorem selectedBound12546 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env12547 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,4096,388,4588,81,263,4525,2476,236,80,4160,32,152,3,268,65,2049,4469,4233,2340,304,33,256,33,4540,648]

theorem envBound12547 : H12AffineFastState.Bounded env12547 := by
  intro p hp
  have h : env12547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12546_12547 : H12AffineEnvironment.transform 9 236 env12546 = env12547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 236 env12546 == env12547) = true)

theorem identity12547 : scanCanonicalize (H12AffineFastState.compose env12547 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 2540) := by decide +kernel

theorem selectedBound12547 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12548 : List Nat := [2,4,8,16,32,64,128,256,512,236,2048,2540,388,2048,81,263,2113,2476,236,80,2476,32,152,3,268,65,2049,2201,2405,2340,304,33,256,33,2128,648]

theorem envBound12548 : H12AffineFastState.Bounded env12548 := by
  intro p hp
  have h : env12548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12547_12548 : H12AffineEnvironment.transform 11 2540 env12547 = env12548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2540 env12547 == env12548) = true)

theorem identity12548 : scanCanonicalize (H12AffineFastState.compose env12548 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12548 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env12549 : List Nat := [2,4,8,16,32,64,128,256,512,236,0,492,388,0,81,263,65,428,236,80,428,32,152,3,268,65,1,153,357,292,304,33,256,33,80,648]

theorem envBound12549 : H12AffineFastState.Bounded env12549 := by
  intro p hp
  have h : env12549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12548_12549 : H12AffineEnvironment.transform 10 0 env12548 = env12549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12548 == env12549) = true)

theorem identity12549 : scanCanonicalize (H12AffineFastState.compose env12549 (packedSelected [3,5,10] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12549 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12550 : List Nat := [2,4,8,16,32,64,128,36,512,236,0,200,160,0,81,35,65,136,236,80,136,32,152,3,40,65,1,153,65,0,20,33,36,33,80,648]

theorem envBound12550 : H12AffineFastState.Bounded env12550 := by
  intro p hp
  have h : env12550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12549_12550 : H12AffineEnvironment.transform 7 36 env12549 = env12550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12549 == env12550) = true)

theorem identity12550 : scanCanonicalize (H12AffineFastState.compose env12550 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound12550 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env12551 : List Nat := [2,4,8,16,32,64,88,36,512,52,0,16,120,0,81,35,65,80,52,80,80,32,64,3,40,65,1,65,65,0,20,33,36,33,80,592]

theorem envBound12551 : H12AffineFastState.Bounded env12551 := by
  intro p hp
  have h : env12551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12550_12551 : H12AffineEnvironment.transform 6 88 env12550 = env12551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env12550 == env12551) = true)

def env12552 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10280,1024,32769,4160,21793,41292,73857,8328,65,64724,46157,58461,35189,1500,33,256,21793,46213,74251]

theorem envBound12552 : H12AffineFastState.Bounded env12552 := by
  intro p hp
  have h : env12552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12541_12552 : H12AffineEnvironment.transform 16 49169 env12541 = env12552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env12541 == env12552) = true)

theorem identity12552 : scanCanonicalize (H12AffineFastState.compose env12552 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 33247) := by decide +kernel

theorem selectedBound12552 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12553 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,33247,49169,10280,1024,32769,4160,21793,41292,41310,8328,65,64724,46157,58461,35189,1500,33,256,21793,46213,41940]

theorem envBound12553 : H12AffineFastState.Bounded env12553 := by
  intro p hp
  have h : env12553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12552_12553 : H12AffineEnvironment.transform 15 33247 env12552 = env12553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33247 env12552 == env12553) = true)

theorem identity12553 : scanCanonicalize (H12AffineFastState.compose env12553 (packedSelected [5,16,20,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29005) := by decide +kernel

theorem selectedBound12553 : packedSelected [5,16,20,24,26] rootPS < 2^1333 := by decide +kernel

def env12554 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29005,28818,12636,10280,1024,29004,4160,21793,20481,20499,8328,65,3481,17664,5392,30776,1500,33,256,21793,17864,21145]

theorem envBound12554 : H12AffineFastState.Bounded env12554 := by
  intro p hp
  have h : env12554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12553_12554 : H12AffineEnvironment.transform 14 29005 env12553 = env12554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29005 env12553 == env12554) = true)

theorem identity12554 : scanCanonicalize (H12AffineFastState.compose env12554 (packedSelected [1,3,4,7,8,9,10,11,16,18,20,24,27] rootPS)) = affineNative (2^(12+1) ^^^ 240) := by decide +kernel

theorem selectedBound12554 : packedSelected [1,3,4,7,8,9,10,11,16,18,20,24,27] rootPS < 2^1333 := by decide +kernel

def env12555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,240,16384,20925,20578,4524,2264,1024,20924,4160,21793,20481,20499,120,65,3481,17664,5392,22728,1500,33,256,21793,17864,21145]

theorem envBound12555 : H12AffineFastState.Bounded env12555 := by
  intro p hp
  have h : env12555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12554_12555 : H12AffineEnvironment.transform 12 240 env12554 = env12555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 240 env12554 == env12555) = true)

theorem identity12555 : scanCanonicalize (H12AffineFastState.compose env12555 (packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound12555 : packedSelected [1,2,3,5,6,8,9,10,11,14,18,19,22] rootPS < 2^1333 := by decide +kernel

def env12556 : List Nat := [2,4,8,16,32,64,128,256,512,101,2048,4096,240,16384,20925,20578,4524,2264,101,20924,4160,20804,20481,20499,120,65,2556,16741,4469,22728,441,33,256,20804,16813,21145]

theorem envBound12556 : H12AffineFastState.Bounded env12556 := by
  intro p hp
  have h : env12556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12555_12556 : H12AffineEnvironment.transform 9 101 env12555 = env12556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env12555 == env12556) = true)

theorem identity12556 : scanCanonicalize (H12AffineFastState.compose env12556 (packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound12556 : packedSelected [0,1,2,6,7,8,11,18,19,20] rootPS < 2^1333 := by decide +kernel

def env12557 : List Nat := [2,4,8,16,32,64,89,256,512,101,2048,4096,41,16384,20836,20578,4469,2049,101,20837,4160,20804,20481,20499,120,65,2341,16741,4469,22545,352,33,256,20804,16756,21056]

theorem envBound12557 : H12AffineFastState.Bounded env12557 := by
  intro p hp
  have h : env12557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12556_12557 : H12AffineEnvironment.transform 6 89 env12556 = env12557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env12556 == env12557) = true)

theorem identity12557 : scanCanonicalize (H12AffineFastState.compose env12557 (packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12557 : packedSelected [0,2,3,5,6,7,10,12,15,16] rootPS < 2^1333 := by decide +kernel

def env12558 : List Nat := [2,4,8,16,32,64,89,37,512,101,2048,4096,41,16384,20545,20578,4176,2049,101,20544,4160,20577,20481,20499,120,65,2048,16448,4176,22545,69,33,37,20577,16465,21056]

theorem envBound12558 : H12AffineFastState.Bounded env12558 := by
  intro p hp
  have h : env12558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12557_12558 : H12AffineEnvironment.transform 7 37 env12557 = env12558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12557 == env12558) = true)

theorem identity12558 : scanCanonicalize (H12AffineFastState.compose env12558 (packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound12558 : packedSelected [0,2,3,4,5,6,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env12559 : List Nat := [2,4,8,16,32,64,89,37,512,101,2048,4096,41,4113,80,115,4176,2049,101,81,4160,112,16,2,120,65,2048,4177,4176,2048,69,33,37,112,4160,593]

theorem envBound12559 : H12AffineFastState.Bounded env12559 := by
  intro p hp
  have h : env12559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12558_12559 : H12AffineEnvironment.transform 13 4113 env12558 = env12559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env12558 == env12559) = true)

theorem identity12559 : scanCanonicalize (H12AffineFastState.compose env12559 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12559 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12560 : List Nat := [2,4,8,16,32,64,89,37,512,101,2048,2049,41,2064,80,115,2129,2049,101,81,2113,112,16,2,120,65,2048,2128,2129,2048,69,33,37,112,2113,593]

theorem envBound12560 : H12AffineFastState.Bounded env12560 := by
  intro p hp
  have h : env12560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12559_12560 : H12AffineEnvironment.transform 11 2049 env12559 = env12560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env12559 == env12560) = true)

theorem identity12560 : scanCanonicalize (H12AffineFastState.compose env12560 (packedSelected [3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 96) := by decide +kernel

theorem selectedBound12560 : packedSelected [3,5,6] rootPS < 2^1333 := by decide +kernel

def env12561 : List Nat := [2,4,8,16,32,64,89,37,512,101,96,97,41,112,80,115,49,97,101,81,33,112,16,2,120,65,96,48,49,96,69,33,37,112,33,593]

theorem envBound12561 : H12AffineFastState.Bounded env12561 := by
  intro p hp
  have h : env12561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12560_12561 : H12AffineEnvironment.transform 10 96 env12560 = env12561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 96 env12560 == env12561) = true)

theorem identity12561 : scanCanonicalize (H12AffineFastState.compose env12561 (packedSelected [3,5] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound12561 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12562 : List Nat := [2,4,8,16,32,0,25,37,512,37,32,33,41,48,16,51,49,33,37,17,33,48,16,2,56,1,32,48,49,32,5,33,37,48,33,529]

theorem envBound12562 : H12AffineFastState.Bounded env12562 := by
  intro p hp
  have h : env12562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12561_12562 : H12AffineEnvironment.transform 5 0 env12561 = env12562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env12561 == env12562) = true)

theorem identity12562 : scanCanonicalize (H12AffineFastState.compose env12562 (packedSelected [1,2,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound12562 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env12563 : List Nat := [2,4,8,1,32,0,8,37,512,37,32,33,41,33,1,34,32,33,37,0,33,33,1,2,41,1,32,33,32,32,5,33,37,33,33,512]

theorem envBound12563 : H12AffineFastState.Bounded env12563 := by
  intro p hp
  have h : env12563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12562_12563 : H12AffineEnvironment.transform 3 1 env12562 = env12563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env12562 == env12563) = true)

theorem identity12563 : scanCanonicalize (H12AffineFastState.compose env12563 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 33) := by decide +kernel

theorem selectedBound12563 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12564 : List Nat := [2,4,8,1,32,0,8,37,33,37,32,33,41,33,1,34,32,33,37,0,33,33,1,2,41,1,32,33,32,32,5,33,37,33,33,33]

theorem envBound12564 : H12AffineFastState.Bounded env12564 := by
  intro p hp
  have h : env12564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12563_12564 : H12AffineEnvironment.transform 8 33 env12563 = env12564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 33 env12563 == env12564) = true)

theorem identity12564 : scanCanonicalize (H12AffineFastState.compose env12564 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound12564 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12565 : List Nat := [2,4,6,1,32,0,6,37,33,37,32,33,39,33,1,34,32,33,37,0,33,33,1,2,39,1,32,33,32,32,5,33,37,33,33,33]

theorem envBound12565 : H12AffineFastState.Bounded env12565 := by
  intro p hp
  have h : env12565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12564_12565 : H12AffineEnvironment.transform 2 6 env12564 = env12565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env12564 == env12565) = true)

theorem identity12565 : scanCanonicalize (H12AffineFastState.compose env12565 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12565 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12566 : List Nat := [2,4,6,1,0,0,6,5,1,5,0,1,7,1,1,2,0,1,5,0,1,1,1,2,7,1,0,1,0,0,5,1,5,1,1,1]

theorem envBound12566 : H12AffineFastState.Bounded env12566 := by
  intro p hp
  have h : env12566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12565_12566 : H12AffineEnvironment.transform 4 0 env12565 = env12566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12565 == env12566) = true)

def env12567 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,10281,1024,32769,4160,169264,155996,254097,8328,65,64725,160861,140365,35189,1500,32,256,21793,46213,74251]

theorem envBound12567 : H12AffineFastState.Bounded env12567 := by
  intro p hp
  have h : env12567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12540_12567 : H12AffineEnvironment.transform 17 10281 env12540 = env12567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12540 == env12567) = true)

def env12568 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4160,21792,41292,73857,8328,65,64725,46157,58461,35189,1500,32,256,21793,46213,74251]

theorem envBound12568 : H12AffineFastState.Bounded env12568 := by
  intro p hp
  have h : env12568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12567_12568 : H12AffineEnvironment.transform 16 49168 env12567 = env12568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env12567 == env12568) = true)

theorem identity12568 : scanCanonicalize (H12AffineFastState.compose env12568 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound12568 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12569 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8322,49168,10281,1024,32769,4160,21792,41292,3,8328,65,64725,46157,58461,35189,1500,32,256,21793,46213,649]

theorem envBound12569 : H12AffineFastState.Bounded env12569 := by
  intro p hp
  have h : env12569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12568_12569 : H12AffineEnvironment.transform 15 8322 env12568 = env12569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env12568 == env12569) = true)

theorem identity12569 : scanCanonicalize (H12AffineFastState.compose env12569 (packedSelected [9,10,12,16,18,19,22] rootPS)) = affineNative (2^(13+1) ^^^ 13445) := by decide +kernel

theorem selectedBound12569 : packedSelected [9,10,12,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env12570 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,32768,8322,46229,10281,1024,32769,4160,8613,41292,3,8328,65,34896,46157,37080,35189,1500,32,256,8612,46213,649]

theorem envBound12570 : H12AffineFastState.Bounded env12570 := by
  intro p hp
  have h : env12570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12569_12570 : H12AffineEnvironment.transform 13 13445 env12569 = env12570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13445 env12569 == env12570) = true)

theorem identity12570 : scanCanonicalize (H12AffineFastState.compose env12570 (packedSelected [0,1,4,7,8,9,11,16,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound12570 : packedSelected [0,1,4,7,8,9,11,16,19] rootPS < 2^1333 := by decide +kernel

def env12571 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13445,137,8322,13340,10281,1024,136,4160,8613,8645,3,8328,65,2265,13508,4177,2556,1500,32,256,8612,13324,649]

theorem envBound12571 : H12AffineFastState.Bounded env12571 := by
  intro p hp
  have h : env12571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12570_12571 : H12AffineEnvironment.transform 14 137 env12570 = env12571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env12570 == env12571) = true)

theorem identity12571 : scanCanonicalize (H12AffineFastState.compose env12571 (packedSelected [1,2,4,6,8,9,10,11,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12571 : packedSelected [1,2,4,6,8,9,10,11,15] rootPS < 2^1333 := by decide +kernel

def env12572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,0,8203,13340,10281,1024,1,4160,8492,8524,3,8193,65,2128,13389,4177,2421,1365,32,256,8493,13324,512]

theorem envBound12572 : H12AffineFastState.Bounded env12572 := by
  intro p hp
  have h : env12572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12571_12572 : H12AffineEnvironment.transform 6 9 env12571 = env12572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12571 == env12572) = true)

theorem identity12572 : scanCanonicalize (H12AffineFastState.compose env12572 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound12572 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12573 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,8192,13324,0,8203,13340,10248,1024,1,4160,8461,8524,3,8193,65,2128,13389,4177,2388,1365,1,256,8460,13324,512]

theorem envBound12573 : H12AffineFastState.Bounded env12573 := by
  intro p hp
  have h : env12573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12572_12573 : H12AffineEnvironment.transform 4 1 env12572 = env12573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env12572 == env12573) = true)

theorem identity12573 : scanCanonicalize (H12AffineFastState.compose env12573 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12573 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12574 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,349,5457,0,342,5441,2389,1024,1,4160,80,17,3,348,65,2128,5392,4177,2388,1365,1,256,81,5457,512]

theorem envBound12574 : H12AffineFastState.Bounded env12574 := by
  intro p hp
  have h : env12574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12573_12574 : H12AffineEnvironment.transform 12 349 env12573 = env12574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12573 == env12574) = true)

theorem identity12574 : scanCanonicalize (H12AffineFastState.compose env12574 (packedSelected [2,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound12574 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env12575 : List Nat := [2,4,8,16,1,64,9,84,512,1024,2048,4096,9,5125,0,2,5141,2049,1024,1,4160,80,17,3,8,65,2128,5188,4177,2048,1025,1,84,81,5125,512]

theorem envBound12575 : H12AffineFastState.Bounded env12575 := by
  intro p hp
  have h : env12575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12574_12575 : H12AffineEnvironment.transform 7 84 env12574 = env12575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env12574 == env12575) = true)

def env12576 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,21793,41293,73856,8328,65,64725,46156,58460,35189,1500,32,256,21793,46213,74251]

theorem envBound12576 : H12AffineFastState.Bounded env12576 := by
  intro p hp
  have h : env12576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12567_12576 : H12AffineEnvironment.transform 16 49169 env12567 = env12576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env12567 == env12576) = true)

theorem identity12576 : scanCanonicalize (H12AffineFastState.compose env12576 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12576 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,49169,10281,1024,32769,4160,21793,41293,138,8328,65,64725,46156,58460,35189,1500,32,256,21793,46213,513]

theorem envBound12577 : H12AffineFastState.Bounded env12577 := by
  intro p hp
  have h : env12577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12576_12577 : H12AffineEnvironment.transform 15 8202 env12576 = env12577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12576 == env12577) = true)

theorem identity12577 : scanCanonicalize (H12AffineFastState.compose env12577 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound12577 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env12578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,32768,478,49169,2557,1024,32769,4160,21793,32921,138,348,65,56577,38296,50568,35189,1500,32,256,21793,38225,513]

theorem envBound12578 : H12AffineFastState.Bounded env12578 := by
  intro p hp
  have h : env12578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12577_12578 : H12AffineEnvironment.transform 12 468 env12577 = env12578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env12577 == env12578) = true)

theorem identity12578 : scanCanonicalize (H12AffineFastState.compose env12578 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12578 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12579 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,32768,342,49169,2421,1024,32769,4160,21793,32785,2,348,65,56577,38160,50432,35189,1364,32,256,21793,38225,513]

theorem envBound12579 : H12AffineFastState.Bounded env12579 := by
  intro p hp
  have h : env12579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12578_12579 : H12AffineEnvironment.transform 6 8 env12578 = env12579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12578 == env12579) = true)

theorem identity12579 : scanCanonicalize (H12AffineFastState.compose env12579 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12579 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12580 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,32768,263,49169,2340,1024,32769,4113,21793,32785,2,269,16,56577,38160,50432,35108,1285,32,256,21793,38144,513]

theorem envBound12580 : H12AffineFastState.Bounded env12580 := by
  intro p hp
  have h : env12580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12579_12580 : H12AffineEnvironment.transform 5 17 env12579 = env12580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12579 == env12580) = true)

theorem identity12580 : scanCanonicalize (H12AffineFastState.compose env12580 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12580 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env12581 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,0,263,16401,2340,1024,1,4113,21793,17,2,269,16,23809,5392,17664,2340,1285,32,256,21793,5376,513]

theorem envBound12581 : H12AffineFastState.Bounded env12581 := by
  intro p hp
  have h : env12581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12580_12581 : H12AffineEnvironment.transform 14 0 env12580 = env12581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12580 == env12581) = true)

theorem identity12581 : scanCanonicalize (H12AffineFastState.compose env12581 (packedSelected [5,8] rootPS)) = affineNative (2^(9+1) ^^^ 795) := by decide +kernel

theorem selectedBound12581 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env12582 : List Nat := [2,4,8,16,32,17,8,256,512,795,2048,4096,269,16384,0,263,16401,2340,795,1,4113,21050,17,2,269,16,23066,4619,16923,2340,542,32,256,21050,4635,513]

theorem envBound12582 : H12AffineFastState.Bounded env12582 := by
  intro p hp
  have h : env12582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12581_12582 : H12AffineEnvironment.transform 9 795 env12581 = env12582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 795 env12581 == env12582) = true)

def env12583 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169264,412020,510136,8328,65,316669,416885,396388,35188,1501,272392,256,21793,46213,74250]

theorem envBound12583 : H12AffineFastState.Bounded env12583 := by
  intro p hp
  have h : env12583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12539_12583 : H12AffineEnvironment.transform 20 4161 env12539 = env12583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12539 == env12583) = true)

theorem identity12583 : scanCanonicalize (H12AffineFastState.compose env12583 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 179632) := by decide +kernel

theorem selectedBound12583 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12584 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,179632,1024,32769,4161,169264,62660,95496,8328,65,158029,57797,45524,35188,1501,169400,256,21793,46213,74250]

theorem envBound12584 : H12AffineFastState.Bounded env12584 := by
  intro p hp
  have h : env12584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12583_12584 : H12AffineEnvironment.transform 17 179632 env12583 = env12584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179632 env12583 == env12584) = true)

theorem identity12584 : scanCanonicalize (H12AffineFastState.compose env12584 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound12584 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env12585 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,179632,1024,32769,4161,169264,62660,21763,8328,65,158029,57797,45524,35188,1501,169400,256,21793,46213,513]

theorem envBound12585 : H12AffineFastState.Bounded env12585 := by
  intro p hp
  have h : env12585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12584_12585 : H12AffineEnvironment.transform 15 8203 env12584 = env12585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env12584 == env12585) = true)

theorem identity12585 : scanCanonicalize (H12AffineFastState.compose env12585 (packedSelected [11,16,18,20,23,32] rootPS)) = affineNative (2^(16+1) ^^^ 46277) := by decide +kernel

theorem selectedBound12585 : packedSelected [11,16,18,20,23,32] rootPS < 2^1333 := by decide +kernel

def env12586 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,46277,2421,1024,32769,4161,8693,62660,21763,8328,65,56712,57797,45524,35188,1501,8573,256,21793,46213,513]

theorem envBound12586 : H12AffineFastState.Bounded env12586 := by
  intro p hp
  have h : env12586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12585_12586 : H12AffineEnvironment.transform 16 46277 env12585 = env12586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46277 env12585 == env12586) = true)

theorem identity12586 : scanCanonicalize (H12AffineFastState.compose env12586 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound12586 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12587 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8203,16401,2421,1024,29909,4161,8693,16,21763,8328,65,10588,5393,17664,32160,1501,8573,256,21793,16465,513]

theorem envBound12587 : H12AffineFastState.Bounded env12587 := by
  intro p hp
  have h : env12587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12586_12587 : H12AffineEnvironment.transform 14 29908 env12586 = env12587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env12586 == env12587) = true)

theorem identity12587 : scanCanonicalize (H12AffineFastState.compose env12587 (packedSelected [7,14,20,27] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12587 : packedSelected [7,14,20,27] rootPS < 2^1333 := by decide +kernel

def env12588 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8580,8203,5441,2421,1024,8581,4161,8693,16,83,8328,65,10588,5393,4176,10480,1501,8573,256,113,5377,513]

theorem envBound12588 : H12AffineFastState.Bounded env12588 := by
  intro p hp
  have h : env12588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12587_12588 : H12AffineEnvironment.transform 13 5456 env12587 = env12588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12587 == env12588) = true)

theorem identity12588 : scanCanonicalize (H12AffineFastState.compose env12588 (packedSelected [14] rootPS)) = affineNative (2^(12+1) ^^^ 4257) := by decide +kernel

theorem selectedBound12588 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env12589 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,4257,5456,4389,4266,5441,2421,1024,4388,4161,4436,16,83,4137,65,6653,5393,4176,6225,1501,4572,256,113,5377,513]

theorem envBound12589 : H12AffineFastState.Bounded env12589 := by
  intro p hp
  have h : env12589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12588_12589 : H12AffineEnvironment.transform 12 4257 env12588 = env12589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4257 env12588 == env12589) = true)

theorem identity12589 : scanCanonicalize (H12AffineFastState.compose env12589 (packedSelected [0,1,5,6,7,11,12,17,18] rootPS)) = affineNative (2^(11+1) ^^^ 1725) := by decide +kernel

theorem selectedBound12589 : packedSelected [0,1,5,6,7,11,12,17,18] rootPS < 2^1333 := by decide +kernel

def env12590 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,1725,1564,1005,1944,1559,1020,2421,1024,1945,1788,2025,16,83,1684,65,3904,940,1773,3820,1501,1889,256,113,956,513]

theorem envBound12590 : H12AffineFastState.Bounded env12590 := by
  intro p hp
  have h : env12590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12589_12590 : H12AffineEnvironment.transform 11 1725 env12589 = env12590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1725 env12589 == env12590) = true)

theorem identity12590 : scanCanonicalize (H12AffineFastState.compose env12590 (packedSelected [1,2,3,4,6,7,11,12,15,17,20] rootPS)) = affineNative (2^(9+1) ^^^ 237) := by decide +kernel

theorem selectedBound12590 : packedSelected [1,2,3,4,6,7,11,12,15,17,20] rootPS < 2^1333 := by decide +kernel

def env12591 : List Nat := [2,4,8,16,32,64,128,256,512,237,2048,592,753,1005,885,762,1020,2421,237,884,529,772,16,83,633,65,2989,940,512,2561,304,908,256,113,956,513]

theorem envBound12591 : H12AffineFastState.Bounded env12591 := by
  intro p hp
  have h : env12591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12590_12591 : H12AffineEnvironment.transform 9 237 env12590 = env12591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 237 env12590 == env12591) = true)

theorem identity12591 : scanCanonicalize (H12AffineFastState.compose env12591 (packedSelected [0,1,4,5,10,11] rootPS)) = affineNative (2^(8+1) ^^^ 509) := by decide +kernel

theorem selectedBound12591 : packedSelected [0,1,4,5,10,11] rootPS < 2^1333 := by decide +kernel

def env12592 : List Nat := [2,4,8,16,32,64,128,256,509,237,2048,429,268,16,136,263,1,2421,237,137,492,249,16,83,388,65,2128,81,509,2556,304,113,256,113,65,508]

theorem envBound12592 : H12AffineFastState.Bounded env12592 := by
  intro p hp
  have h : env12592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12591_12592 : H12AffineEnvironment.transform 8 509 env12591 = env12592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 509 env12591 == env12592) = true)

theorem identity12592 : scanCanonicalize (H12AffineFastState.compose env12592 (packedSelected [2,3,4,6,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 492) := by decide +kernel

theorem selectedBound12592 : packedSelected [2,3,4,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12593 : List Nat := [2,4,8,16,32,64,128,256,509,237,492,429,268,16,136,263,1,153,237,137,492,249,16,83,388,65,444,81,509,16,304,113,256,113,65,508]

theorem envBound12593 : H12AffineFastState.Bounded env12593 := by
  intro p hp
  have h : env12593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12592_12593 : H12AffineEnvironment.transform 10 492 env12592 = env12593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 492 env12592 == env12593) = true)

theorem identity12593 : scanCanonicalize (H12AffineFastState.compose env12593 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound12593 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env12594 : List Nat := [2,4,8,16,32,0,128,256,445,173,428,429,268,16,136,263,1,153,173,137,428,185,16,19,388,1,444,17,445,16,304,49,256,49,1,444]

theorem envBound12594 : H12AffineFastState.Bounded env12594 := by
  intro p hp
  have h : env12594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12593_12594 : H12AffineEnvironment.transform 5 0 env12593 = env12594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env12593 == env12594) = true)

theorem identity12594 : scanCanonicalize (H12AffineFastState.compose env12594 (packedSelected [1,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12594 : packedSelected [1,5,6] rootPS < 2^1333 := by decide +kernel

def env12595 : List Nat := [2,4,8,16,32,0,128,37,152,173,137,136,41,16,136,34,1,153,173,137,137,185,16,19,161,1,153,17,152,16,21,49,37,49,1,153]

theorem envBound12595 : H12AffineFastState.Bounded env12595 := by
  intro p hp
  have h : env12595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12594_12595 : H12AffineEnvironment.transform 7 37 env12594 = env12595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12594 == env12595) = true)

theorem identity12595 : scanCanonicalize (H12AffineFastState.compose env12595 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound12595 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12596 : List Nat := [2,4,8,16,32,0,8,37,16,37,1,0,41,16,0,34,1,17,37,1,1,49,16,19,41,1,17,17,16,16,21,49,37,49,1,17]

theorem envBound12596 : H12AffineFastState.Bounded env12596 := by
  intro p hp
  have h : env12596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12595_12596 : H12AffineEnvironment.transform 6 8 env12595 = env12596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12595 == env12596) = true)

theorem identity12596 : scanCanonicalize (H12AffineFastState.compose env12596 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound12596 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12597 : List Nat := [2,4,8,0,32,0,8,37,0,37,1,0,41,0,0,34,1,1,37,1,1,33,0,3,41,1,1,1,0,0,5,33,37,33,1,1]

theorem envBound12597 : H12AffineFastState.Bounded env12597 := by
  intro p hp
  have h : env12597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12596_12597 : H12AffineEnvironment.transform 3 0 env12596 = env12597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env12596 == env12597) = true)

theorem identity12597 : scanCanonicalize (H12AffineFastState.compose env12597 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 11) := by decide +kernel

theorem selectedBound12597 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12598 : List Nat := [2,4,8,0,11,0,8,14,0,14,1,0,2,0,0,9,1,1,14,1,1,10,0,3,2,1,1,1,0,0,5,10,14,10,1,1]

theorem envBound12598 : H12AffineFastState.Bounded env12598 := by
  intro p hp
  have h : env12598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12597_12598 : H12AffineEnvironment.transform 4 11 env12597 = env12598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 11 env12597 == env12598) = true)

def env12599 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,169265,2513205,510136,8328,65,2409661,2509876,396388,2136373,2102684,2373704,256,21793,46213,2175563]

theorem envBound12599 : H12AffineFastState.Bounded env12599 := by
  intro p hp
  have h : env12599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12538_12599 : H12AffineEnvironment.transform 21 169265 env12538 = env12599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 169265 env12538 == env12599) = true)

def env12600 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4160,169265,412021,510136,8328,65,316669,416884,396388,35189,1500,272392,256,21793,46213,74251]

theorem envBound12600 : H12AffineFastState.Bounded env12600 := by
  intro p hp
  have h : env12600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12599_12600 : H12AffineEnvironment.transform 20 4160 env12599 = env12600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env12599 == env12600) = true)

theorem identity12600 : scanCanonicalize (H12AffineFastState.compose env12600 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 149861) := by decide +kernel

theorem selectedBound12600 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12601 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,98781,8328,65,171416,5393,17665,35189,1500,156013,256,21793,46213,74251]

theorem envBound12601 : H12AffineFastState.Bounded env12601 := by
  intro p hp
  have h : env12601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12600_12601 : H12AffineEnvironment.transform 17 149861 env12600 = env12601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 149861 env12600 == env12601) = true)

def env12602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,98645,8192,65,171280,5393,17665,35189,1364,156013,256,21793,46093,74251]

theorem envBound12602 : H12AffineFastState.Bounded env12602 := by
  intro p hp
  have h : env12602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12601_12602 : H12AffineEnvironment.transform 6 8 env12601 = env12602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12601 == env12602) = true)

theorem identity12602 : scanCanonicalize (H12AffineFastState.compose env12602 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 82246) := by decide +kernel

theorem selectedBound12602 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12603 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,82246,67619,1024,32769,4160,119927,16,98645,8192,65,121942,5393,17665,35189,1364,73771,256,21793,46093,74251]

theorem envBound12603 : H12AffineFastState.Bounded env12603 := by
  intro p hp
  have h : env12603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12602_12603 : H12AffineEnvironment.transform 16 82246 env12602 = env12603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82246 env12602 == env12603) = true)

theorem identity12603 : scanCanonicalize (H12AffineFastState.compose env12603 (packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound12603 : packedSelected [0,1,3,4,5,7,8,10,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env12604 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,62730,46156,64809,1024,32769,4160,8573,16,29791,8192,65,10588,5393,17665,35189,1364,54561,256,21793,46093,55041]

theorem envBound12604 : H12AffineFastState.Bounded env12604 := by
  intro p hp
  have h : env12604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12603_12604 : H12AffineEnvironment.transform 15 62730 env12603 = env12604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env12603 == env12604) = true)

theorem identity12604 : scanCanonicalize (H12AffineFastState.compose env12604 (packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound12604 : packedSelected [0,1,7,8,9,11,14,16,18,19,22] rootPS < 2^1333 := by decide +kernel

def env12605 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,343,16401,2420,1024,29788,4160,8573,16,29791,8192,65,10588,5393,17665,32040,1364,8572,256,21793,16464,9052]

theorem envBound12605 : H12AffineFastState.Bounded env12605 := by
  intro p hp
  have h : env12605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12604_12605 : H12AffineEnvironment.transform 14 29789 env12604 = env12605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env12604 == env12605) = true)

def env12606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,149861,1024,32769,4160,169265,16,98644,8193,65,171281,5393,17665,35189,1365,156013,256,21793,46092,74251]

theorem envBound12606 : H12AffineFastState.Bounded env12606 := by
  intro p hp
  have h : env12606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12601_12606 : H12AffineEnvironment.transform 6 9 env12601 = env12606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12601 == env12606) = true)

theorem identity12606 : scanCanonicalize (H12AffineFastState.compose env12606 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 122907) := by decide +kernel

theorem selectedBound12606 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,108926,1024,32769,4160,95530,16,98644,8193,65,97546,5393,17665,35189,1365,98678,256,21793,46092,74251]

theorem envBound12607 : H12AffineFastState.Bounded env12607 := by
  intro p hp
  have h : env12607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12606_12607 : H12AffineEnvironment.transform 16 122907 env12606 = env12607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 122907 env12606 == env12607) = true)

theorem identity12607 : scanCanonicalize (H12AffineFastState.compose env12607 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound12607 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12608 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,65536,111947,108926,1024,32769,4160,73850,16,98644,8193,65,75866,5393,4177,35189,1365,98678,256,113,46092,74251]

theorem envBound12608 : H12AffineFastState.Bounded env12608 := by
  intro p hp
  have h : env12608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12607_12608 : H12AffineEnvironment.transform 13 5456 env12607 = env12608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env12607 == env12608) = true)

theorem identity12608 : scanCanonicalize (H12AffineFastState.compose env12608 (packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound12608 : packedSelected [4,5,9,12,14,15,16,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12609 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5456,32768,34,46441,43356,1024,32769,4160,8280,16,33142,8193,65,10360,5393,4177,35189,1365,33108,256,113,46092,8745]

theorem envBound12609 : H12AffineFastState.Bounded env12609 := by
  intro p hp
  have h : env12609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12608_12609 : H12AffineEnvironment.transform 15 34 env12608 = env12609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env12608 == env12609) = true)

theorem identity12609 : scanCanonicalize (H12AffineFastState.compose env12609 (packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12609 : packedSelected [2,3,4,5,6,10,11,12,15,16,18,22] rootPS < 2^1333 := by decide +kernel

def env12610 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,32768,34,37941,34816,1024,32769,4160,260,16,33142,349,65,2340,5393,4177,35189,1365,33108,256,113,38224,885]

theorem envBound12610 : H12AffineFastState.Bounded env12610 := by
  intro p hp
  have h : env12610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12609_12610 : H12AffineEnvironment.transform 12 348 env12609 = env12610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12609 == env12610) = true)

theorem identity12610 : scanCanonicalize (H12AffineFastState.compose env12610 (packedSelected [3,5,10,12,15,16,20] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound12610 : packedSelected [3,5,10,12,15,16,20] rootPS < 2^1333 := by decide +kernel

def env12611 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5456,80,34,5221,2128,1024,81,4160,260,16,294,349,65,2340,5393,4177,2341,1365,260,256,113,5376,885]

theorem envBound12611 : H12AffineFastState.Bounded env12611 := by
  intro p hp
  have h : env12611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12610_12611 : H12AffineEnvironment.transform 14 80 env12610 = env12611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env12610 == env12611) = true)

theorem identity12611 : scanCanonicalize (H12AffineFastState.compose env12611 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12611 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12612 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5376,0,34,5173,2048,1024,1,4112,260,16,294,269,17,2340,5393,4097,2341,1285,260,256,33,5376,805]

theorem envBound12612 : H12AffineFastState.Bounded env12612 := by
  intro p hp
  have h : env12612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12611_12612 : H12AffineEnvironment.transform 5 16 env12611 = env12612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12611 == env12612) = true)

theorem identity12612 : scanCanonicalize (H12AffineFastState.compose env12612 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12612 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12613 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,2049,268,3329,0,34,3124,2048,1024,1,2065,260,16,294,269,17,2340,3344,2048,2341,1285,260,256,33,3329,805]

theorem envBound12613 : H12AffineFastState.Bounded env12613 := by
  intro p hp
  have h : env12613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12612_12613 : H12AffineEnvironment.transform 11 2049 env12612 = env12613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env12612 == env12613) = true)

theorem identity12613 : scanCanonicalize (H12AffineFastState.compose env12613 (packedSelected [1,2,3,5,6,8,10] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound12613 : packedSelected [1,2,3,5,6,8,10] rootPS < 2^1333 := by decide +kernel

def env12614 : List Nat := [2,4,8,16,16,16,9,256,512,1024,2048,2049,268,3329,0,18,3076,2048,1024,1,2065,260,16,278,269,17,2324,3344,2048,2325,1285,260,256,17,3329,789]

theorem envBound12614 : H12AffineFastState.Bounded env12614 := by
  intro p hp
  have h : env12614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12613_12614 : H12AffineEnvironment.transform 4 16 env12613 = env12614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env12613 == env12614) = true)

def env12615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,4161,169265,412020,510136,8328,65,316668,416885,396388,35188,1501,272393,256,21793,46213,74250]

theorem envBound12615 : H12AffineFastState.Bounded env12615 := by
  intro p hp
  have h : env12615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12599_12615 : H12AffineEnvironment.transform 20 4161 env12599 = env12615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env12599 == env12615) = true)

theorem identity12615 : scanCanonicalize (H12AffineFastState.compose env12615 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound12615 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12616 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,262144,1024,29909,4161,156133,412020,474220,8328,65,270376,416885,396388,32160,1501,272393,256,21793,16465,74250]

theorem envBound12616 : H12AffineFastState.Bounded env12616 := by
  intro p hp
  have h : env12616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12615_12616 : H12AffineEnvironment.transform 14 29908 env12615 = env12616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env12615 == env12616) = true)

def env12617 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,262144,1024,29829,4113,156085,411940,474172,8328,17,270376,416805,396340,32160,1421,272393,256,21793,16385,74250]

theorem envBound12617 : H12AffineFastState.Bounded env12617 := by
  intro p hp
  have h : env12617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12616_12617 : H12AffineEnvironment.transform 5 16 env12616 = env12617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12616 == env12617) = true)

theorem identity12617 : scanCanonicalize (H12AffineFastState.compose env12617 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215227) := by decide +kernel

theorem selectedBound12617 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12618 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,131072,215227,1024,29829,4113,156085,65951,29831,8328,17,223379,70814,83087,32160,1421,221362,256,21793,16385,74250]

theorem envBound12618 : H12AffineFastState.Bounded env12618 := by
  intro p hp
  have h : env12618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12617_12618 : H12AffineEnvironment.transform 17 215227 env12617 = env12618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215227 env12617 == env12618) = true)

theorem identity12618 : scanCanonicalize (H12AffineFastState.compose env12618 (packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS)) = affineNative (2^(16+1) ^^^ 79130) := by decide +kernel

theorem selectedBound12618 : packedSelected [3,4,7,9,10,16,17,18,19,20,23,24,27] rootPS < 2^1333 := by decide +kernel

def env12619 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,65536,79130,32161,1024,29829,4113,87215,65951,29831,8328,17,23945,70814,83087,32160,1421,21928,256,21793,16385,74250]

theorem envBound12619 : H12AffineFastState.Bounded env12619 := by
  intro p hp
  have h : env12619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12618_12619 : H12AffineEnvironment.transform 16 79130 env12618 = env12619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79130 env12618 == env12619) = true)

theorem identity12619 : scanCanonicalize (H12AffineFastState.compose env12619 (packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound12619 : packedSelected [0,1,3,4,7,16,18,20,22,23,24,28] rootPS < 2^1333 := by decide +kernel

def env12620 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,29828,30083,16537,32161,1024,29829,4113,8492,29724,29831,8328,17,23945,24861,12556,32160,1421,21928,256,21793,16385,22409]

theorem envBound12620 : H12AffineFastState.Bounded env12620 := by
  intro p hp
  have h : env12620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12619_12620 : H12AffineEnvironment.transform 15 30083 env12619 = env12620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env12619 == env12620) = true)

theorem identity12620 : scanCanonicalize (H12AffineFastState.compose env12620 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound12620 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env12621 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,21761,21510,16537,23588,1024,21760,4113,169,21913,21762,269,17,23945,16536,4233,23589,1421,21928,256,21793,16385,22409]

theorem envBound12621 : H12AffineFastState.Bounded env12621 := by
  intro p hp
  have h : env12621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12620_12621 : H12AffineEnvironment.transform 12 389 env12620 = env12621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env12620 == env12621) = true)

theorem identity12621 : scanCanonicalize (H12AffineFastState.compose env12621 (packedSelected [3,4,5,6,7,11,12,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 409) := by decide +kernel

theorem selectedBound12621 : packedSelected [3,4,5,6,7,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env12622 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,389,16384,20632,20895,16537,22973,409,20633,4113,169,20480,20635,269,17,22544,16536,4233,22972,20,20529,256,20664,16385,21008]

theorem envBound12622 : H12AffineFastState.Bounded env12622 := by
  intro p hp
  have h : env12622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12621_12622 : H12AffineEnvironment.transform 9 409 env12621 = env12622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 409 env12621 == env12622) = true)

theorem identity12622 : scanCanonicalize (H12AffineFastState.compose env12622 (packedSelected [1,2,4,6,7,8,11,14,15] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound12622 : packedSelected [1,2,4,6,7,8,11,14,15] rootPS < 2^1333 := by decide +kernel

def env12623 : List Nat := [2,4,8,16,32,16,128,256,512,409,2048,4096,389,4112,136,399,4233,2477,409,137,4113,169,16,139,269,17,2048,4232,4233,2476,20,33,256,168,4113,512]

theorem envBound12623 : H12AffineFastState.Bounded env12623 := by
  intro p hp
  have h : env12623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12622_12623 : H12AffineEnvironment.transform 13 4112 env12622 = env12623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env12622 == env12623) = true)

theorem identity12623 : scanCanonicalize (H12AffineFastState.compose env12623 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound12623 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12624 : List Nat := [2,4,8,16,32,16,40,256,512,305,2048,4096,301,4112,32,295,4129,2309,305,33,4113,1,16,35,269,17,2048,4128,4129,2308,20,33,256,0,4113,512]

theorem envBound12624 : H12AffineFastState.Bounded env12624 := by
  intro p hp
  have h : env12624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12623_12624 : H12AffineEnvironment.transform 6 40 env12623 = env12624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env12623 == env12624) = true)

theorem identity12624 : scanCanonicalize (H12AffineFastState.compose env12624 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 2325) := by decide +kernel

theorem selectedBound12624 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env12625 : List Nat := [2,4,8,16,32,16,40,256,512,305,2048,2325,301,2309,32,295,2356,2309,305,33,2308,1,16,35,269,17,2048,2357,2356,2308,20,33,256,0,2308,512]

theorem envBound12625 : H12AffineFastState.Bounded env12625 := by
  intro p hp
  have h : env12625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12624_12625 : H12AffineEnvironment.transform 11 2325 env12624 = env12625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2325 env12624 == env12625) = true)

theorem identity12625 : scanCanonicalize (H12AffineFastState.compose env12625 (packedSelected [3,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12625 : packedSelected [3,5,11] rootPS < 2^1333 := by decide +kernel

def env12626 : List Nat := [2,4,8,16,32,16,40,256,512,305,0,277,301,261,32,295,308,261,305,33,260,1,16,35,269,17,0,309,308,260,20,33,256,0,260,512]

theorem envBound12626 : H12AffineFastState.Bounded env12626 := by
  intro p hp
  have h : env12626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12625_12626 : H12AffineEnvironment.transform 10 0 env12625 = env12626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12625 == env12626) = true)

theorem identity12626 : scanCanonicalize (H12AffineFastState.compose env12626 (packedSelected [3,5,12] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12626 : packedSelected [3,5,12] rootPS < 2^1333 := by decide +kernel

def env12627 : List Nat := [2,4,8,16,32,16,40,36,512,21,0,49,9,33,32,3,16,33,21,33,32,1,16,35,41,17,0,17,16,32,20,33,36,0,32,512]

theorem envBound12627 : H12AffineFastState.Bounded env12627 := by
  intro p hp
  have h : env12627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12626_12627 : H12AffineEnvironment.transform 7 36 env12626 = env12627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12626 == env12627) = true)

theorem identity12627 : scanCanonicalize (H12AffineFastState.compose env12627 (packedSelected [2,14] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12627 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env12628 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,1,0,3,16,1,21,1,0,1,16,3,9,17,0,17,16,0,20,1,4,0,0,512]

theorem envBound12628 : H12AffineFastState.Bounded env12628 := by
  intro p hp
  have h : env12628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12627_12628 : H12AffineEnvironment.transform 4 0 env12627 = env12628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12627 == env12628) = true)

theorem identity12628 : scanCanonicalize (H12AffineFastState.compose env12628 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound12628 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12629 : List Nat := [2,4,8,16,0,16,8,4,0,21,0,17,9,1,0,3,16,1,21,1,0,1,16,3,9,17,0,17,16,0,20,1,4,0,0,0]

theorem envBound12629 : H12AffineFastState.Bounded env12629 := by
  intro p hp
  have h : env12629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12628_12629 : H12AffineEnvironment.transform 8 0 env12628 = env12629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env12628 == env12629) = true)

theorem identity12629 : scanCanonicalize (H12AffineFastState.compose env12629 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound12629 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12630 : List Nat := [2,4,8,15,0,15,8,4,0,10,0,14,9,1,0,3,15,1,10,1,0,1,15,3,9,14,0,14,15,0,11,1,4,0,0,0]

theorem envBound12630 : H12AffineFastState.Bounded env12630 := by
  intro p hp
  have h : env12630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12629_12630 : H12AffineEnvironment.transform 3 15 env12629 = env12630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env12629 == env12630) = true)

def env12631 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,262144,1024,29828,4112,156084,411941,474173,8328,16,270376,416804,396341,32160,1420,272393,256,21793,16384,74250]

theorem envBound12631 : H12AffineFastState.Bounded env12631 := by
  intro p hp
  have h : env12631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12616_12631 : H12AffineEnvironment.transform 5 17 env12616 = env12631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12616 == env12631) = true)

theorem identity12631 : scanCanonicalize (H12AffineFastState.compose env12631 (packedSelected [3,10,18,23,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 215090) := by decide +kernel

theorem selectedBound12631 : packedSelected [3,10,18,23,24,26] rootPS < 2^1333 := by decide +kernel

def env12632 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,65536,131072,215090,1024,29828,4112,156084,65815,29711,8328,16,223258,70678,82951,32160,1420,221243,256,21793,16384,74250]

theorem envBound12632 : H12AffineFastState.Bounded env12632 := by
  intro p hp
  have h : env12632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12631_12632 : H12AffineEnvironment.transform 17 215090 env12631 = env12632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 215090 env12631 == env12632) = true)

theorem identity12632 : scanCanonicalize (H12AffineFastState.compose env12632 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 29962) := by decide +kernel

theorem selectedBound12632 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env12633 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,29829,29962,131072,146744,1024,29828,4112,156084,29725,29711,8328,16,138512,24860,12557,32160,1420,136497,256,21793,16384,22272]

theorem envBound12633 : H12AffineFastState.Bounded env12633 := by
  intro p hp
  have h : env12633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12632_12633 : H12AffineEnvironment.transform 15 29962 env12632 = env12633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29962 env12632 == env12633) = true)

theorem identity12633 : scanCanonicalize (H12AffineFastState.compose env12633 (packedSelected [1,3,5,8,10,18,19,23] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12633 : packedSelected [1,3,5,8,10,18,19,23] rootPS < 2^1333 := by decide +kernel

def env12634 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,8203,131072,146744,1024,8581,4112,144565,8476,8462,8328,16,138512,13341,12557,10401,1420,136497,256,32,5377,513]

theorem envBound12634 : H12AffineFastState.Bounded env12634 := by
  intro p hp
  have h : env12634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12633_12634 : H12AffineEnvironment.transform 13 5377 env12633 = env12634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12633 == env12634) = true)

theorem identity12634 : scanCanonicalize (H12AffineFastState.compose env12634 (packedSelected [2,6,17] rootPS)) = affineNative (2^(16+1) ^^^ 5529) := by decide +kernel

theorem selectedBound12634 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env12635 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5377,8580,8203,5529,10401,1024,8581,4112,8492,8476,8462,8328,16,2185,13341,12557,10401,1420,168,256,32,5377,513]

theorem envBound12635 : H12AffineFastState.Bounded env12635 := by
  intro p hp
  have h : env12635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12634_12635 : H12AffineEnvironment.transform 16 5529 env12634 = env12635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5529 env12634 == env12635) = true)

theorem identity12635 : scanCanonicalize (H12AffineFastState.compose env12635 (packedSelected [3,4,5,9,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound12635 : packedSelected [3,4,5,9,10,12] rootPS < 2^1333 := by decide +kernel

def env12636 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3245,8192,2476,8580,8203,2356,10401,1024,8581,3261,8492,8476,8462,8328,16,2185,10416,11680,10401,1420,168,256,32,2476,513]

theorem envBound12636 : H12AffineFastState.Bounded env12636 := by
  intro p hp
  have h : env12636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12635_12636 : H12AffineEnvironment.transform 11 3245 env12635 = env12636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env12635 == env12636) = true)

theorem identity12636 : scanCanonicalize (H12AffineFastState.compose env12636 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound12636 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env12637 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,8192,2341,8461,8203,2356,10280,1024,8460,3124,8492,8476,8462,8193,16,2048,10297,11561,10280,1285,33,256,32,2341,513]

theorem envBound12637 : H12AffineFastState.Bounded env12637 := by
  intro p hp
  have h : env12637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12636_12637 : H12AffineEnvironment.transform 6 9 env12636 = env12637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12636 == env12637) = true)

theorem identity12637 : scanCanonicalize (H12AffineFastState.compose env12637 (packedSelected [0,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound12637 : packedSelected [0,3,5,7] rootPS < 2^1333 := by decide +kernel

def env12638 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3108,1052,2341,1297,1047,2356,3124,1024,1296,3124,1328,1280,1298,1053,16,2048,3109,2357,3124,1285,33,256,32,2341,513]

theorem envBound12638 : H12AffineFastState.Bounded env12638 := by
  intro p hp
  have h : env12638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12637_12638 : H12AffineEnvironment.transform 12 1052 env12637 = env12638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env12637 == env12638) = true)

theorem identity12638 : scanCanonicalize (H12AffineFastState.compose env12638 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound12638 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env12639 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,2357,269,2341,0,262,2356,2341,273,1,2341,33,17,3,268,16,2048,2356,2357,2341,20,33,256,32,2341,513]

theorem envBound12639 : H12AffineFastState.Bounded env12639 := by
  intro p hp
  have h : env12639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12638_12639 : H12AffineEnvironment.transform 9 273 env12638 = env12639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env12638 == env12639) = true)

theorem identity12639 : scanCanonicalize (H12AffineFastState.compose env12639 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12639 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12640 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,2064,40,2048,0,35,2065,2048,52,1,2048,33,17,3,41,16,2048,2065,2064,2048,20,33,37,32,2048,513]

theorem envBound12640 : H12AffineFastState.Bounded env12640 := by
  intro p hp
  have h : env12640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12639_12640 : H12AffineEnvironment.transform 7 37 env12639 = env12640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12639 == env12640) = true)

theorem identity12640 : scanCanonicalize (H12AffineFastState.compose env12640 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound12640 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12641 : List Nat := [2,4,8,16,32,17,9,37,32,52,2048,2064,40,2048,0,35,2065,2048,52,1,2048,33,17,3,41,16,2048,2065,2064,2048,20,33,37,32,2048,33]

theorem envBound12641 : H12AffineFastState.Bounded env12641 := by
  intro p hp
  have h : env12641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12640_12641 : H12AffineEnvironment.transform 8 32 env12640 = env12641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env12640 == env12641) = true)

theorem identity12641 : scanCanonicalize (H12AffineFastState.compose env12641 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound12641 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12642 : List Nat := [2,4,8,16,32,17,9,37,32,52,33,49,40,33,0,35,48,33,52,1,33,33,17,3,41,16,33,48,49,33,20,33,37,32,33,33]

theorem envBound12642 : H12AffineFastState.Bounded env12642 := by
  intro p hp
  have h : env12642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12641_12642 : H12AffineEnvironment.transform 10 33 env12641 = env12642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env12641 == env12642) = true)

def env12643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265169,23160257,257,27378861,27337992,25207751]

theorem envBound12643 : H12AffineFastState.Bounded env12643 := by
  intro p hp
  have h : env12643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12421_12643 : H12AffineEnvironment.transform 18 1025 env12421 = env12643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env12421 == env12643) = true)

theorem identity12643 : scanCanonicalize (H12AffineFastState.compose env12643 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 272440) := by decide +kernel

theorem selectedBound12643 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env12644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8328,65,21227576,18973837,2391401,190521,17148969,23160257,257,19262613,19205424,17075199]

theorem envBound12644 : H12AffineFastState.Bounded env12644 := by
  intro p hp
  have h : env12644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12643_12644 : H12AffineEnvironment.transform 22 272440 env12643 = env12644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 272440 env12643 == env12644) = true)

def env12645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8192,65,21227576,18973701,2391401,190521,17148969,23160137,257,19262493,19205424,17075063]

theorem envBound12645 : H12AffineFastState.Bounded env12645 := by
  intro p hp
  have h : env12645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12644_12645 : H12AffineEnvironment.transform 6 8 env12644 = env12645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12644 == env12645) = true)

theorem identity12645 : scanCanonicalize (H12AffineFastState.compose env12645 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 272427) := by decide +kernel

theorem selectedBound12645 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env12646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,272427,8192,65,4702227,2468910,2391401,190521,99330,6638946,257,2212918,2172187,41820]

theorem envBound12646 : H12AffineFastState.Bounded env12646 := by
  intro p hp
  have h : env12646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12645_12646 : H12AffineEnvironment.transform 23 272427 env12645 = env12646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 272427 env12645 == env12646) = true)

def env12647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1025,32769,2097152,4194304,147456,147475,8192,65,4302891,2343958,2233681,190521,99330,6497626,257,2212918,2172187,41820]

theorem envBound12647 : H12AffineFastState.Bounded env12647 := by
  intro p hp
  have h : env12647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12646_12647 : H12AffineEnvironment.transform 17 157752 env12646 = env12647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157752 env12646 == env12647) = true)

theorem identity12647 : scanCanonicalize (H12AffineFastState.compose env12647 (packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 188781) := by decide +kernel

theorem selectedBound12647 : packedSelected [0,1,4,5,7,8,12,15,16,19,20,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env12648 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157752,1025,32769,2097152,188781,147456,147475,8192,65,215366,2343958,2233681,190521,99330,2212919,257,2212918,2172187,41820]

theorem envBound12648 : H12AffineFastState.Bounded env12648 := by
  intro p hp
  have h : env12648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12647_12648 : H12AffineEnvironment.transform 21 188781 env12647 = env12648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188781 env12647 == env12648) = true)

theorem identity12648 : scanCanonicalize (H12AffineFastState.compose env12648 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound12648 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env12649 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1025,32769,2097152,32,41293,41310,8192,65,108555,2172251,2159644,2420,99330,2212919,257,2212918,2172187,41820]

theorem envBound12649 : H12AffineFastState.Bounded env12649 := by
  intro p hp
  have h : env12649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12648_12649 : H12AffineEnvironment.transform 16 57677 env12648 = env12649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env12648 == env12649) = true)

theorem identity12649 : scanCanonicalize (H12AffineFastState.compose env12649 (packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS)) = affineNative (2^(20+1) ^^^ 115783) := by decide +kernel

theorem selectedBound12649 : packedSelected [2,3,5,6,7,9,10,11,12,15,16,22,23,27] rootPS < 2^1333 := by decide +kernel

def env12650 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57677,35189,1025,32769,115783,32,41293,41310,8192,65,108555,57628,77915,2420,99330,112,257,113,57692,41820]

theorem envBound12650 : H12AffineFastState.Bounded env12650 := by
  intro p hp
  have h : env12650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12649_12650 : H12AffineEnvironment.transform 20 115783 env12649 = env12650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115783 env12649 == env12650) = true)

theorem identity12650 : scanCanonicalize (H12AffineFastState.compose env12650 (packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound12650 : packedSelected [0,1,4,7,8,9,10,11,15,16,17] rootPS < 2^1333 := by decide +kernel

def env12651 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40970,57677,35189,1025,32769,25677,32,41293,41310,8192,65,2049,57628,36945,2420,9224,112,257,113,57692,41820]

theorem envBound12651 : H12AffineFastState.Bounded env12651 := by
  intro p hp
  have h : env12651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12650_12651 : H12AffineEnvironment.transform 15 40970 env12650 = env12651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env12650 == env12651) = true)

theorem identity12651 : scanCanonicalize (H12AffineFastState.compose env12651 (packedSelected [3,4,5,9,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound12651 : packedSelected [3,4,5,9,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env12652 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,32768,40970,37941,35189,1025,32769,4405,32,41293,41310,8192,65,2049,37988,36945,2420,9224,112,257,113,37924,41820]

theorem envBound12652 : H12AffineFastState.Bounded env12652 := by
  intro p hp
  have h : env12652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12651_12652 : H12AffineEnvironment.transform 13 13688 env12651 = env12652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env12651 == env12652) = true)

theorem identity12652 : scanCanonicalize (H12AffineFastState.compose env12652 (packedSelected [10,14,16,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12652 : packedSelected [10,14,16,19] rootPS < 2^1333 := by decide +kernel

def env12653 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5156,32768,33110,37941,35189,1025,32769,4405,32,32785,32770,348,65,2049,37988,36945,2420,1364,112,257,113,37924,33280]

theorem envBound12653 : H12AffineFastState.Bounded env12653 := by
  intro p hp
  have h : env12653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12652_12653 : H12AffineEnvironment.transform 12 348 env12652 = env12653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12652 == env12653) = true)

theorem identity12653 : scanCanonicalize (H12AffineFastState.compose env12653 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound12653 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env12654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5156,81,263,5220,2340,1025,80,4405,32,64,83,348,65,2049,5173,4096,2420,1364,112,257,113,5237,593]

theorem envBound12654 : H12AffineFastState.Bounded env12654 := by
  intro p hp
  have h : env12654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12653_12654 : H12AffineEnvironment.transform 14 81 env12653 = env12654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env12653 == env12654) = true)

theorem identity12654 : scanCanonicalize (H12AffineFastState.compose env12654 (packedSelected [0,2,7,10] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound12654 : packedSelected [0,2,7,10] rootPS < 2^1333 := by decide +kernel

def env12655 : List Nat := [2,4,8,16,32,49,8,256,512,1024,2048,4096,301,5156,32,263,5141,2340,1025,33,4405,32,49,34,301,48,2049,5173,4096,2309,1317,1,257,0,5124,544]

theorem envBound12655 : H12AffineFastState.Bounded env12655 := by
  intro p hp
  have h : env12655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12654_12655 : H12AffineEnvironment.transform 5 49 env12654 = env12655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env12654 == env12655) = true)

theorem identity12655 : scanCanonicalize (H12AffineFastState.compose env12655 (packedSelected [0,2,3,5,7,12] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12655 : packedSelected [0,2,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env12656 : List Nat := [2,4,8,16,0,17,8,256,512,1024,2048,4096,269,5124,0,263,5141,2308,1025,1,4373,0,17,2,269,16,2049,5141,4096,2309,1285,1,257,0,5124,512]

theorem envBound12656 : H12AffineFastState.Bounded env12656 := by
  intro p hp
  have h : env12656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12655_12656 : H12AffineEnvironment.transform 4 0 env12655 = env12656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12655 == env12656) = true)

theorem identity12656 : scanCanonicalize (H12AffineFastState.compose env12656 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound12656 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12657 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,4096,8,5124,0,2,5141,2049,1025,1,4112,0,17,2,8,16,2049,5141,4096,2048,1024,1,4,0,5124,512]

theorem envBound12657 : H12AffineFastState.Bounded env12657 := by
  intro p hp
  have h : env12657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12656_12657 : H12AffineEnvironment.transform 7 5 env12656 = env12657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env12656 == env12657) = true)

def env12658 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,16,8,1044,0,2,1029,2049,1025,1,0,0,17,2,8,16,2049,1029,16,2048,1024,1,4,0,1044,512]

theorem envBound12658 : H12AffineFastState.Bounded env12658 := by
  intro p hp
  have h : env12658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12657_12658 : H12AffineEnvironment.transform 11 16 env12657 = env12658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12657 == env12658) = true)

theorem identity12658 : scanCanonicalize (H12AffineFastState.compose env12658 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12658 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12659 : List Nat := [2,4,8,16,0,17,8,5,512,1024,0,16,8,1044,0,2,1029,1,1025,1,0,0,17,2,8,16,1,1029,16,0,1024,1,4,0,1044,512]

theorem envBound12659 : H12AffineFastState.Bounded env12659 := by
  intro p hp
  have h : env12659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12658_12659 : H12AffineEnvironment.transform 10 0 env12658 = env12659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12658 == env12659) = true)

def env12660 : List Nat := [2,4,8,16,0,17,8,5,512,20,0,16,8,0,0,2,17,1,21,1,0,0,17,2,8,16,1,17,16,0,20,1,4,0,0,512]

theorem envBound12660 : H12AffineFastState.Bounded env12660 := by
  intro p hp
  have h : env12660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12659_12660 : H12AffineEnvironment.transform 9 20 env12659 = env12660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12659 == env12660) = true)

theorem identity12660 : scanCanonicalize (H12AffineFastState.compose env12660 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 31) := by decide +kernel

theorem selectedBound12660 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12661 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,8,0,0,2,17,1,21,1,0,0,17,2,8,16,1,17,16,0,20,1,4,0,0,31]

theorem envBound12661 : H12AffineFastState.Bounded env12661 := by
  intro p hp
  have h : env12661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12660_12661 : H12AffineEnvironment.transform 8 31 env12660 = env12661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 31 env12660 == env12661) = true)

def leafEnv12661 : List Nat := [2,4,8,16,0,17,8,5,31,20,0,16,8,0,0,2,17,1,21,1,0,0,17,2,21,8,1,16,1,17,16,0,20,1,4,0,5,2,0,31,1,0,0]

def active12661 : List Nat := [0,1,2,3]

def tree12661 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12661 : H12WitnessSearch.Good tree12661 := H12GlobalWitnessIndex.good

theorem leafIdentity12661 : H12AffineFastState.composeSystem env12661 rootObs = leafEnv12661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12661 rootObs == leafEnv12661) = true)

theorem terminalChecked12661 : H12PackedTerminal.terminalCheckFast leafEnv12661 active12661 tree12661 = true := by decide +kernel

def env12662 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,16,8,1,0,2,16,1,20,1,0,0,17,2,8,16,1,16,16,0,21,1,4,0,1,512]

theorem envBound12662 : H12AffineFastState.Bounded env12662 := by
  intro p hp
  have h : env12662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12659_12662 : H12AffineEnvironment.transform 9 21 env12659 = env12662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env12659 == env12662) = true)

theorem identity12662 : scanCanonicalize (H12AffineFastState.compose env12662 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound12662 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12663 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,0,2,5,1,1,1,0,0,4,2,8,5,1,5,5,0,0,1,4,0,1,512]

theorem envBound12663 : H12AffineFastState.Bounded env12663 := by
  intro p hp
  have h : env12663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12662_12663 : H12AffineEnvironment.transform 3 5 env12662 = env12663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env12662 == env12663) = true)

def leafEnv12663 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,5,8,1,0,2,5,1,1,1,0,0,4,2,1,8,1,5,1,5,5,0,0,1,4,0,5,2,1,512,1,0,0]

def active12663 : List Nat := [0,1,2,8]

def tree12663 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12663 : H12WitnessSearch.Good tree12663 := H12GlobalWitnessIndex.good

theorem leafIdentity12663 : H12AffineFastState.composeSystem env12663 rootObs = leafEnv12663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12663 rootObs == leafEnv12663) = true)

theorem terminalChecked12663 : H12PackedTerminal.terminalCheckFast leafEnv12663 active12663 tree12663 = true := by decide +kernel

def env12664 : List Nat := [2,4,8,16,0,17,8,5,512,1024,2048,17,8,1045,0,2,1028,2049,1025,1,1,0,17,2,8,16,2049,1028,17,2048,1024,1,4,0,1045,512]

theorem envBound12664 : H12AffineFastState.Bounded env12664 := by
  intro p hp
  have h : env12664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12657_12664 : H12AffineEnvironment.transform 11 17 env12657 = env12664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12657 == env12664) = true)

theorem identity12664 : scanCanonicalize (H12AffineFastState.compose env12664 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound12664 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12665 : List Nat := [2,4,8,16,0,17,8,5,512,1024,1045,17,8,1045,0,2,1028,1044,1025,1,1,0,17,2,8,16,1044,1028,17,1045,1024,1,4,0,1045,512]

theorem envBound12665 : H12AffineFastState.Bounded env12665 := by
  intro p hp
  have h : env12665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12664_12665 : H12AffineEnvironment.transform 10 1045 env12664 = env12665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env12664 == env12665) = true)

def env12666 : List Nat := [2,4,8,16,0,17,8,5,512,20,1,17,8,1,0,2,16,0,21,1,1,0,17,2,8,16,0,16,17,1,20,1,4,0,1,512]

theorem envBound12666 : H12AffineFastState.Bounded env12666 := by
  intro p hp
  have h : env12666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12665_12666 : H12AffineEnvironment.transform 9 20 env12665 = env12666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12665 == env12666) = true)

theorem identity12666 : scanCanonicalize (H12AffineFastState.compose env12666 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound12666 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12667 : List Nat := [2,4,8,16,0,17,8,5,30,20,1,17,8,1,0,2,16,0,21,1,1,0,17,2,8,16,0,16,17,1,20,1,4,0,1,30]

theorem envBound12667 : H12AffineFastState.Bounded env12667 := by
  intro p hp
  have h : env12667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12666_12667 : H12AffineEnvironment.transform 8 30 env12666 = env12667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env12666 == env12667) = true)

def leafEnv12667 : List Nat := [2,4,8,16,0,17,8,5,30,20,1,17,8,1,0,2,16,0,21,1,1,0,17,2,21,8,1,16,0,16,17,1,20,1,4,0,5,2,1,30,1,1,0]

def active12667 : List Nat := [0,1,2,3]

def tree12667 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12667 : H12WitnessSearch.Good tree12667 := H12GlobalWitnessIndex.good

theorem leafIdentity12667 : H12AffineFastState.composeSystem env12667 rootObs = leafEnv12667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12667 rootObs == leafEnv12667) = true)

theorem terminalChecked12667 : H12PackedTerminal.terminalCheckFast leafEnv12667 active12667 tree12667 = true := by decide +kernel

def env12668 : List Nat := [2,4,8,16,0,17,8,5,512,21,0,17,8,0,0,2,17,1,20,1,1,0,17,2,8,16,1,17,17,0,21,1,4,0,0,512]

theorem envBound12668 : H12AffineFastState.Bounded env12668 := by
  intro p hp
  have h : env12668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12665_12668 : H12AffineEnvironment.transform 9 21 env12665 = env12668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env12665 == env12668) = true)

theorem identity12668 : scanCanonicalize (H12AffineFastState.compose env12668 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound12668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12669 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,4,8,0,0,2,4,1,1,1,1,0,4,2,8,5,1,4,4,0,0,1,4,0,0,512]

theorem envBound12669 : H12AffineFastState.Bounded env12669 := by
  intro p hp
  have h : env12669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12668_12669 : H12AffineEnvironment.transform 3 5 env12668 = env12669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env12668 == env12669) = true)

def leafEnv12669 : List Nat := [2,4,8,5,0,4,8,5,512,0,0,4,8,0,0,2,4,1,1,1,1,0,4,2,1,8,1,5,1,4,4,0,0,1,4,0,5,2,0,512,1,1,0]

def active12669 : List Nat := [0,1,2,8]

def tree12669 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12669 : H12WitnessSearch.Good tree12669 := H12GlobalWitnessIndex.good

theorem leafIdentity12669 : H12AffineFastState.composeSystem env12669 rootObs = leafEnv12669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12669 rootObs == leafEnv12669) = true)

theorem terminalChecked12669 : H12PackedTerminal.terminalCheckFast leafEnv12669 active12669 tree12669 = true := by decide +kernel

def env12670 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1025,32769,2097152,4194304,147457,147474,8192,65,4302890,2343959,2233680,190521,99330,6497627,257,2212918,2172187,41820]

theorem envBound12670 : H12AffineFastState.Bounded env12670 := by
  intro p hp
  have h : env12670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12646_12670 : H12AffineEnvironment.transform 17 157753 env12646 = env12670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157753 env12646 == env12670) = true)

theorem identity12670 : scanCanonicalize (H12AffineFastState.compose env12670 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12670 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12671 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157753,1025,8540,2097152,4194304,147457,147474,8192,65,4262263,2319690,2233680,149860,75103,6497627,257,2188651,2172187,513]

theorem envBound12671 : H12AffineFastState.Bounded env12671 := by
  intro p hp
  have h : env12671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12670_12671 : H12AffineEnvironment.transform 14 8541 env12670 = env12671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12670 == env12671) = true)

theorem identity12671 : scanCanonicalize (H12AffineFastState.compose env12671 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound12671 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env12672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,67619,1025,8540,2097152,4194304,73755,73736,8192,65,4262263,2098512,2192714,76158,75103,6309185,257,2188651,2172187,513]

theorem envBound12672 : H12AffineFastState.Bounded env12672 := by
  intro p hp
  have h : env12672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12671_12672 : H12AffineEnvironment.transform 16 90138 env12671 = env12672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env12671 == env12672) = true)

theorem identity12672 : scanCanonicalize (H12AffineFastState.compose env12672 (packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS)) = affineNative (2^(20+1) ^^^ 25677) := by decide +kernel

theorem selectedBound12672 : packedSelected [1,3,7,14,15,20,24,27,28,38] rootPS < 2^1333 := by decide +kernel

def env12673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,67619,1025,8540,25677,4194304,73755,73736,8192,65,4262263,24861,69895,76158,75103,4202764,257,65830,82262,513]

theorem envBound12673 : H12AffineFastState.Bounded env12673 := by
  intro p hp
  have h : env12673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12672_12673 : H12AffineEnvironment.transform 20 25677 env12672 = env12673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25677 env12672 == env12673) = true)

theorem identity12673 : scanCanonicalize (H12AffineFastState.compose env12673 (packedSelected [4,9,14,18,20,23] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound12673 : packedSelected [4,9,14,18,20,23] rootPS < 2^1333 := by decide +kernel

def env12674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,67619,1025,8540,25677,32,73755,73736,8192,65,67927,24861,69895,76158,75103,8492,257,65830,82262,513]

theorem envBound12674 : H12AffineFastState.Bounded env12674 := by
  intro p hp
  have h : env12674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12673_12674 : H12AffineEnvironment.transform 21 32 env12673 = env12674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env12673 == env12674) = true)

theorem identity12674 : scanCanonicalize (H12AffineFastState.compose env12674 (packedSelected [0,1,2,3,5,6,7,8,14] rootPS)) = affineNative (2^(15+1) ^^^ 29743) := by decide +kernel

theorem selectedBound12674 : packedSelected [0,1,2,3,5,6,7,8,14] rootPS < 2^1333 := by decide +kernel

def env12675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,29743,5173,31756,1025,8540,25677,32,21556,21543,8192,65,32120,24861,25896,23889,20848,8492,257,29961,13689,513]

theorem envBound12675 : H12AffineFastState.Bounded env12675 := by
  intro p hp
  have h : env12675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12674_12675 : H12AffineEnvironment.transform 15 29743 env12674 = env12675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29743 env12674 == env12675) = true)

theorem identity12675 : scanCanonicalize (H12AffineFastState.compose env12675 (packedSelected [0,3,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 11340) := by decide +kernel

theorem selectedBound12675 : packedSelected [0,3,4,5] rootPS < 2^1333 := by decide +kernel

def env12676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,11340,8541,6243,5173,4160,1025,8540,2049,32,14456,14443,8192,65,4404,3409,2404,12573,15676,8492,257,6469,13689,513]

theorem envBound12676 : H12AffineFastState.Bounded env12676 := by
  intro p hp
  have h : env12676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12675_12676 : H12AffineEnvironment.transform 13 11340 env12675 = env12676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 11340 env12675 == env12676) = true)

theorem identity12676 : scanCanonicalize (H12AffineFastState.compose env12676 (packedSelected [1,2,3,6,7,9,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 1053) := by decide +kernel

theorem selectedBound12676 : packedSelected [1,2,3,6,7,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env12677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1053,2129,1344,6243,5173,4160,1025,1345,2049,32,7269,7286,1053,65,4404,3409,2404,5376,6433,1329,257,6469,4452,513]

theorem envBound12677 : H12AffineFastState.Bounded env12677 := by
  intro p hp
  have h : env12677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12676_12677 : H12AffineEnvironment.transform 12 1053 env12676 = env12677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1053 env12676 == env12677) = true)

theorem identity12677 : scanCanonicalize (H12AffineFastState.compose env12677 (packedSelected [2,4,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 1361) := by decide +kernel

theorem selectedBound12677 : packedSelected [2,4,6,7] rootPS < 2^1333 := by decide +kernel

def env12678 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1361,1053,2129,1344,3378,356,1297,1025,1345,2049,32,2356,2343,1053,65,1125,3409,2404,81,3184,1329,257,3092,1077,513]

theorem envBound12678 : H12AffineFastState.Bounded env12678 := by
  intro p hp
  have h : env12678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12677_12678 : H12AffineEnvironment.transform 11 1361 env12677 = env12678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1361 env12677 == env12678) = true)

theorem identity12678 : scanCanonicalize (H12AffineFastState.compose env12678 (packedSelected [0,1,2,4,8,10] rootPS)) = affineNative (2^(10+1) ^^^ 80) := by decide +kernel

theorem selectedBound12678 : packedSelected [0,1,2,4,8,10] rootPS < 2^1333 := by decide +kernel

def env12679 : List Nat := [2,4,8,16,32,64,8,256,512,1024,80,1361,1053,1,1344,1378,356,1297,1025,1345,81,32,356,375,1053,65,1125,1281,308,81,1056,1329,257,1092,1077,513]

theorem envBound12679 : H12AffineFastState.Bounded env12679 := by
  intro p hp
  have h : env12679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12678_12679 : H12AffineEnvironment.transform 10 80 env12678 = env12679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 80 env12678 == env12679) = true)

theorem identity12679 : scanCanonicalize (H12AffineFastState.compose env12679 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound12679 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env12680 : List Nat := [2,4,8,16,32,64,8,256,512,320,80,17,349,1,0,34,356,81,321,1,81,32,356,375,349,65,293,65,308,81,352,113,257,260,373,513]

theorem envBound12680 : H12AffineFastState.Bounded env12680 := by
  intro p hp
  have h : env12680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12679_12680 : H12AffineEnvironment.transform 9 320 env12679 = env12680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env12679 == env12680) = true)

theorem identity12680 : scanCanonicalize (H12AffineFastState.compose env12680 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12680 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12681 : List Nat := [2,4,8,16,32,64,8,116,512,52,80,17,41,1,0,34,16,81,53,1,81,32,16,3,41,65,81,65,64,81,20,113,117,112,1,513]

theorem envBound12681 : H12AffineFastState.Bounded env12681 := by
  intro p hp
  have h : env12681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12680_12681 : H12AffineEnvironment.transform 7 116 env12680 = env12681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12680 == env12681) = true)

def env12682 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,16777216,8193,65,21227576,18973700,2391401,190521,17148969,23160136,257,19262492,19205424,17075062]

theorem envBound12682 : H12AffineFastState.Bounded env12682 := by
  intro p hp
  have h : env12682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12644_12682 : H12AffineEnvironment.transform 6 9 env12644 = env12682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12644 == env12682) = true)

theorem identity12682 : scanCanonicalize (H12AffineFastState.compose env12682 (packedSelected [17,21] rootPS)) = affineNative (2^(23+1) ^^^ 41310) := by decide +kernel

theorem selectedBound12682 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env12683 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,272440,41310,8193,65,4409702,2172250,2391401,190521,331127,6407190,257,2444610,2468974,272936]

theorem envBound12683 : H12AffineFastState.Bounded env12683 := by
  intro p hp
  have h : env12683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12682_12683 : H12AffineEnvironment.transform 23 41310 env12682 = env12683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 41310 env12682 == env12683) = true)

def env12684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,2097152,4194304,272440,41310,8193,65,4262262,2172250,2391401,43049,331127,6407190,257,2444610,2468974,272936]

theorem envBound12684 : H12AffineFastState.Bounded env12684 := by
  intro p hp
  have h : env12684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12683_12684 : H12AffineEnvironment.transform 16 16400 env12683 = env12684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env12683 == env12684) = true)

def env12685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,58396,4194304,272440,41310,8193,65,4262262,115014,301429,43049,331127,4268042,257,371038,346226,272936]

theorem envBound12685 : H12AffineFastState.Bounded env12685 := by
  intro p hp
  have h : env12685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12684_12685 : H12AffineEnvironment.transform 20 58396 env12684 = env12685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env12684 == env12685) = true)

def env12686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58396,4194304,16,41310,8193,65,4262262,115014,45405,43049,75103,4268042,257,98678,90202,512]

theorem envBound12686 : H12AffineFastState.Bounded env12686 := by
  intro p hp
  have h : env12686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12685_12686 : H12AffineEnvironment.transform 17 10280 env12685 = env12686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12685 == env12686) = true)

theorem identity12686 : scanCanonicalize (H12AffineFastState.compose env12686 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound12686 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12687 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58396,4194304,16,41002,8193,65,4261890,114738,45097,43049,74795,4268042,117,98306,90202,512]

theorem envBound12687 : H12AffineFastState.Bounded env12687 := by
  intro p hp
  have h : env12687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12686_12687 : H12AffineEnvironment.transform 7 116 env12686 = env12687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env12686 == env12687) = true)

theorem identity12687 : scanCanonicalize (H12AffineFastState.compose env12687 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 62589) := by decide +kernel

theorem selectedBound12687 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12688 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58396,62589,16,41002,8193,65,130175,114738,45097,43049,74795,119927,117,98306,90202,512]

theorem envBound12688 : H12AffineFastState.Bounded env12688 := by
  intro p hp
  have h : env12688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12687_12688 : H12AffineEnvironment.transform 21 62589 env12687 = env12688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 62589 env12687 == env12688) = true)

theorem identity12688 : scanCanonicalize (H12AffineFastState.compose env12688 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound12688 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12689 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,32768,65536,5220,10280,1025,32769,45160,40969,16,41002,8193,65,108555,103494,45097,43049,74795,98307,117,98306,78894,512]

theorem envBound12689 : H12AffineFastState.Bounded env12689 := by
  intro p hp
  have h : env12689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12688_12689 : H12AffineEnvironment.transform 13 5236 env12688 = env12689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env12688 == env12689) = true)

theorem identity12689 : scanCanonicalize (H12AffineFastState.compose env12689 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(14+1) ^^^ 8200) := by decide +kernel

theorem selectedBound12689 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env12690 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,8200,65536,5220,10280,1025,8201,4192,1,16,34,8193,65,67587,78926,4129,2081,74795,73739,117,73738,78894,512]

theorem envBound12690 : H12AffineFastState.Bounded env12690 := by
  intro p hp
  have h : env12690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12689_12690 : H12AffineEnvironment.transform 14 8200 env12689 = env12690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8200 env12689 == env12690) = true)

theorem identity12690 : scanCanonicalize (H12AffineFastState.compose env12690 (packedSelected [0,1,2,3,5,7,8,11,12] rootPS)) = affineNative (2^(15+1) ^^^ 1127) := by decide +kernel

theorem selectedBound12690 : packedSelected [0,1,2,3,5,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env12691 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,8192,5236,8200,1127,5220,10280,1025,8201,4192,1,16,34,8193,65,3172,12329,4129,2081,8268,9324,117,9325,12361,512]

theorem envBound12691 : H12AffineFastState.Bounded env12691 := by
  intro p hp
  have h : env12691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12690_12691 : H12AffineEnvironment.transform 15 1127 env12690 = env12691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 1127 env12690 == env12691) = true)

theorem identity12691 : scanCanonicalize (H12AffineFastState.compose env12691 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound12691 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env12692 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,4096,1101,5236,1093,1127,5220,3173,1025,1092,4192,1,16,34,1100,65,3172,5220,4129,2081,1025,33,117,32,5124,512]

theorem envBound12692 : H12AffineFastState.Bounded env12692 := by
  intro p hp
  have h : env12692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12691_12692 : H12AffineEnvironment.transform 12 1101 env12691 = env12692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env12691 == env12692) = true)

theorem identity12692 : scanCanonicalize (H12AffineFastState.compose env12692 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound12692 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12693 : List Nat := [2,4,8,16,32,64,9,116,512,20,2048,4096,89,4192,81,115,4208,2161,21,80,4192,1,16,34,88,65,2160,4208,4129,2081,21,33,117,32,4112,512]

theorem envBound12693 : H12AffineFastState.Bounded env12693 := by
  intro p hp
  have h : env12693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12692_12693 : H12AffineEnvironment.transform 9 20 env12692 = env12693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12692 == env12693) = true)

theorem identity12693 : scanCanonicalize (H12AffineFastState.compose env12693 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound12693 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12694 : List Nat := [2,4,8,16,32,48,9,4,512,20,2048,4096,41,4112,33,3,4096,2049,21,32,4112,1,16,34,40,49,2048,4096,4129,2081,21,33,5,32,4112,512]

theorem envBound12694 : H12AffineFastState.Bounded env12694 := by
  intro p hp
  have h : env12694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12693_12694 : H12AffineEnvironment.transform 5 48 env12693 = env12694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env12693 == env12694) = true)

theorem identity12694 : scanCanonicalize (H12AffineFastState.compose env12694 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 17) := by decide +kernel

theorem selectedBound12694 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env12695 : List Nat := [2,4,8,16,32,48,9,4,512,20,17,4096,41,4112,33,3,4096,16,21,32,4112,1,16,34,40,49,17,4096,4129,48,21,33,5,32,4112,512]

theorem envBound12695 : H12AffineFastState.Bounded env12695 := by
  intro p hp
  have h : env12695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12694_12695 : H12AffineEnvironment.transform 10 17 env12694 = env12695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 17 env12694 == env12695) = true)

theorem identity12695 : scanCanonicalize (H12AffineFastState.compose env12695 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 544) := by decide +kernel

theorem selectedBound12695 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env12696 : List Nat := [2,4,8,16,32,48,9,4,512,20,17,544,41,560,33,3,544,16,21,32,560,1,16,34,40,49,17,544,513,48,21,33,5,32,560,512]

theorem envBound12696 : H12AffineFastState.Bounded env12696 := by
  intro p hp
  have h : env12696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12695_12696 : H12AffineEnvironment.transform 11 544 env12695 = env12696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 544 env12695 == env12696) = true)

theorem identity12696 : scanCanonicalize (H12AffineFastState.compose env12696 (packedSelected [10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12696 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env12697 : List Nat := [2,4,8,16,0,16,9,4,512,20,17,512,9,528,1,3,512,16,21,0,528,1,16,2,8,17,17,512,513,16,21,1,5,0,528,512]

theorem envBound12697 : H12AffineFastState.Bounded env12697 := by
  intro p hp
  have h : env12697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12696_12697 : H12AffineEnvironment.transform 4 0 env12696 = env12697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12696 == env12697) = true)

theorem identity12697 : scanCanonicalize (H12AffineFastState.compose env12697 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 21) := by decide +kernel

theorem selectedBound12697 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12698 : List Nat := [2,4,8,16,0,16,9,4,21,20,17,21,9,5,1,3,21,16,21,0,5,1,16,2,8,17,17,21,20,16,21,1,5,0,5,21]

theorem envBound12698 : H12AffineFastState.Bounded env12698 := by
  intro p hp
  have h : env12698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12697_12698 : H12AffineEnvironment.transform 8 21 env12697 = env12698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 21 env12697 == env12698) = true)

theorem identity12698 : scanCanonicalize (H12AffineFastState.compose env12698 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 7) := by decide +kernel

theorem selectedBound12698 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12699 : List Nat := [2,4,8,7,0,7,9,4,2,3,6,2,9,5,1,3,2,7,2,0,5,1,7,2,8,6,6,2,3,7,2,1,5,0,5,2]

theorem envBound12699 : H12AffineFastState.Bounded env12699 := by
  intro p hp
  have h : env12699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12698_12699 : H12AffineEnvironment.transform 3 7 env12698 = env12699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 7 env12698 == env12699) = true)

def env12700 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58396,4194304,17,41310,8193,65,4262262,115014,45404,43049,75102,4268042,257,98679,90203,513]

theorem envBound12700 : H12AffineFastState.Bounded env12700 := by
  intro p hp
  have h : env12700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12685_12700 : H12AffineEnvironment.transform 17 10281 env12685 = env12700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12685 == env12700) = true)

theorem identity12700 : scanCanonicalize (H12AffineFastState.compose env12700 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound12700 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env12701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1025,8540,17729,4194304,17,3,8193,65,4262262,90139,4097,2420,75102,4268042,257,73770,90203,513]

theorem envBound12701 : H12AffineFastState.Bounded env12701 := by
  intro p hp
  have h : env12701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12700_12701 : H12AffineEnvironment.transform 14 8541 env12700 = env12701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env12700 == env12701) = true)

theorem identity12701 : scanCanonicalize (H12AffineFastState.compose env12701 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound12701 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env12702 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,262,16400,10281,1025,8540,17729,4194304,17,3,8193,65,4196464,24861,4097,2420,9304,4202764,257,8492,24925,513]

theorem envBound12702 : H12AffineFastState.Bounded env12702 := by
  intro p hp
  have h : env12702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12701_12702 : H12AffineEnvironment.transform 15 262 env12701 = env12702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env12701 == env12702) = true)

theorem identity12702 : scanCanonicalize (H12AffineFastState.compose env12702 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound12702 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env12703 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,262,16400,10281,1025,8540,17729,113,17,3,8193,65,2049,24861,4097,2420,9304,8573,257,8492,24925,513]

theorem envBound12703 : H12AffineFastState.Bounded env12703 := by
  intro p hp
  have h : env12703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12702_12703 : H12AffineEnvironment.transform 21 113 env12702 = env12703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env12702 == env12703) = true)

theorem identity12703 : scanCanonicalize (H12AffineFastState.compose env12703 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12703 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12704 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,16384,8461,262,16400,10281,1025,8460,17681,33,17,3,8193,17,2049,24861,4097,2340,9224,8493,257,8492,24845,513]

theorem envBound12704 : H12AffineFastState.Bounded env12704 := by
  intro p hp
  have h : env12704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12703_12704 : H12AffineEnvironment.transform 5 16 env12703 = env12704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12703 == env12704) = true)

def env12705 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,58397,4194304,272440,41310,8193,65,4262262,115015,301428,43049,331127,4268043,257,371039,346227,272936]

theorem envBound12705 : H12AffineFastState.Bounded env12705 := by
  intro p hp
  have h : env12705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12684_12705 : H12AffineEnvironment.transform 20 58397 env12684 = env12705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58397 env12684 == env12705) = true)

def env12706 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58397,4194304,16,41310,8193,65,4262262,115015,45404,43049,75103,4268043,257,98679,90203,512]

theorem envBound12706 : H12AffineFastState.Bounded env12706 := by
  intro p hp
  have h : env12706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12705_12706 : H12AffineEnvironment.transform 17 10280 env12705 = env12706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12705 == env12706) = true)

theorem identity12706 : scanCanonicalize (H12AffineFastState.compose env12706 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound12706 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env12707 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58397,4194304,16,41003,8193,65,4261891,114738,45097,43049,74794,4268043,116,98306,90203,512]

theorem envBound12707 : H12AffineFastState.Bounded env12707 := by
  intro p hp
  have h : env12707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12706_12707 : H12AffineEnvironment.transform 7 117 env12706 = env12707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env12706 == env12707) = true)

theorem identity12707 : scanCanonicalize (H12AffineFastState.compose env12707 (packedSelected [17] rootPS)) = affineNative (2^(21+1) ^^^ 119926) := by decide +kernel

theorem selectedBound12707 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12708 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,65536,16400,10280,1025,32769,58397,119926,16,41003,8193,65,56437,114738,45097,43049,74794,62589,116,98306,90203,512]

theorem envBound12708 : H12AffineFastState.Bounded env12708 := by
  intro p hp
  have h : env12708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12707_12708 : H12AffineEnvironment.transform 21 119926 env12707 = env12708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 119926 env12707 == env12708) = true)

theorem identity12708 : scanCanonicalize (H12AffineFastState.compose env12708 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 29822) := by decide +kernel

theorem selectedBound12708 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env12709 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,32768,29822,16400,10280,1025,32769,58397,40968,16,41003,8193,65,56437,46156,45097,43049,20564,62589,116,62588,5157,512]

theorem envBound12709 : H12AffineFastState.Bounded env12709 := by
  intro p hp
  have h : env12709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12708_12709 : H12AffineEnvironment.transform 15 29822 env12708 = env12709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29822 env12708 == env12709) = true)

theorem identity12709 : scanCanonicalize (H12AffineFastState.compose env12709 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 5205) := by decide +kernel

theorem selectedBound12709 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env12710 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,5205,32768,8235,5189,10280,1025,32769,45128,40968,16,41003,8193,65,34848,46156,45097,43049,1025,41000,116,41001,5157,512]

theorem envBound12710 : H12AffineFastState.Bounded env12710 := by
  intro p hp
  have h : env12710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12709_12710 : H12AffineEnvironment.transform 13 5205 env12709 = env12710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5205 env12709 == env12710) = true)

theorem identity12710 : scanCanonicalize (H12AffineFastState.compose env12710 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound12710 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env12711 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,120,5205,32768,83,5189,2128,1025,32769,36912,32880,16,32851,121,65,34848,37940,36945,34897,1025,32848,116,32849,5157,512]

theorem envBound12711 : H12AffineFastState.Bounded env12711 := by
  intro p hp
  have h : env12711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12710_12711 : H12AffineEnvironment.transform 12 120 env12710 = env12711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env12710 == env12711) = true)

theorem identity12711 : scanCanonicalize (H12AffineFastState.compose env12711 (packedSelected [0,6,7,12] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound12711 : packedSelected [0,6,7,12] rootPS < 2^1333 := by decide +kernel

def env12712 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,2065,120,3140,32768,83,3156,2128,1025,32769,34849,32880,16,32851,121,65,34848,35877,34880,34897,1025,32848,116,32849,3124,512]

theorem envBound12712 : H12AffineFastState.Bounded env12712 := by
  intro p hp
  have h : env12712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12711_12712 : H12AffineEnvironment.transform 11 2065 env12711 = env12712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env12711 == env12712) = true)

theorem identity12712 : scanCanonicalize (H12AffineFastState.compose env12712 (packedSelected [0,3,5,6,7,10,15] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12712 : packedSelected [0,3,5,6,7,10,15] rootPS < 2^1333 := by decide +kernel

def env12713 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,2065,88,3140,32768,83,3156,2128,1025,32769,34817,32848,16,32851,89,65,34816,35845,34880,34897,1025,32848,84,32849,3092,512]

theorem envBound12713 : H12AffineFastState.Bounded env12713 := by
  intro p hp
  have h : env12713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12712_12713 : H12AffineEnvironment.transform 4 0 env12712 = env12713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12712 == env12713) = true)

theorem identity12713 : scanCanonicalize (H12AffineFastState.compose env12713 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound12713 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env12714 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,2065,88,2049,32768,83,2065,2128,68,32769,34817,32848,16,32851,89,65,34816,34880,34880,34897,68,32848,84,32849,2129,512]

theorem envBound12714 : H12AffineFastState.Bounded env12714 := by
  intro p hp
  have h : env12714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12713_12714 : H12AffineEnvironment.transform 9 69 env12713 = env12714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env12713 == env12714) = true)

theorem identity12714 : scanCanonicalize (H12AffineFastState.compose env12714 (packedSelected [1,3] rootPS)) = affineNative (2^(14+1) ^^^ 2049) := by decide +kernel

theorem selectedBound12714 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12715 : List Nat := [2,4,8,16,0,64,9,85,512,69,2048,2065,88,2049,2049,83,2065,2128,68,2048,0,2129,16,2130,89,65,1,65,65,80,68,2129,84,2128,2129,512]

theorem envBound12715 : H12AffineFastState.Bounded env12715 := by
  intro p hp
  have h : env12715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12714_12715 : H12AffineEnvironment.transform 14 2049 env12714 = env12715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 2049 env12714 == env12715) = true)

theorem identity12715 : scanCanonicalize (H12AffineFastState.compose env12715 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12715 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env12716 : List Nat := [2,4,8,16,0,64,9,85,512,69,1,16,88,0,0,83,16,81,68,1,0,80,16,83,89,65,1,65,65,80,68,80,84,81,80,512]

theorem envBound12716 : H12AffineFastState.Bounded env12716 := by
  intro p hp
  have h : env12716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12715_12716 : H12AffineEnvironment.transform 10 1 env12715 = env12716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12715 == env12716) = true)

theorem identity12716 : scanCanonicalize (H12AffineFastState.compose env12716 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12716 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12717 : List Nat := [2,4,8,16,0,17,9,4,512,20,1,16,9,0,0,2,16,0,21,1,0,1,16,2,8,16,1,16,16,1,21,1,5,0,1,512]

theorem envBound12717 : H12AffineFastState.Bounded env12717 := by
  intro p hp
  have h : env12717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12716_12717 : H12AffineEnvironment.transform 5 17 env12716 = env12717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12716 == env12717) = true)

theorem identity12717 : scanCanonicalize (H12AffineFastState.compose env12717 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 15) := by decide +kernel

theorem selectedBound12717 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12718 : List Nat := [2,4,8,16,0,17,9,4,15,20,1,16,9,0,0,2,16,0,21,1,0,1,16,2,8,16,1,16,16,1,21,1,5,0,1,15]

theorem envBound12718 : H12AffineFastState.Bounded env12718 := by
  intro p hp
  have h : env12718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12717_12718 : H12AffineEnvironment.transform 8 15 env12717 = env12718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 15 env12717 == env12718) = true)

def env12719 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10281,1025,32769,58397,4194304,17,41310,8193,65,4262262,115015,45405,43049,75102,4268043,257,98678,90202,513]

theorem envBound12719 : H12AffineFastState.Bounded env12719 := by
  intro p hp
  have h : env12719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12705_12719 : H12AffineEnvironment.transform 17 10281 env12705 = env12719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12705 == env12719) = true)

theorem identity12719 : scanCanonicalize (H12AffineFastState.compose env12719 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound12719 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58397,4194304,17,41310,8193,65,4204924,57677,45405,43049,1364,4194305,257,41340,16464,513]

theorem envBound12720 : H12AffineFastState.Bounded env12720 := by
  intro p hp
  have h : env12720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12719_12720 : H12AffineEnvironment.transform 15 8202 env12719 = env12720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env12719 == env12720) = true)

theorem identity12720 : scanCanonicalize (H12AffineFastState.compose env12720 (packedSelected [1,3,4,5,8,9,15,23] rootPS)) = affineNative (2^(21+1) ^^^ 113) := by decide +kernel

theorem selectedBound12720 : packedSelected [1,3,4,5,8,9,15,23] rootPS < 2^1333 := by decide +kernel

def env12721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8202,16400,10281,1025,32769,58397,113,17,41310,8193,65,10509,57677,45405,43049,1364,112,257,41340,16464,513]

theorem envBound12721 : H12AffineFastState.Bounded env12721 := by
  intro p hp
  have h : env12721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12720_12721 : H12AffineEnvironment.transform 21 113 env12720 = env12721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 113 env12720 == env12721) = true)

theorem identity12721 : scanCanonicalize (H12AffineFastState.compose env12721 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound12721 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,32768,342,16400,2421,1025,32769,50497,113,17,32770,349,65,2129,49169,36865,35189,1364,112,257,32800,16464,513]

theorem envBound12722 : H12AffineFastState.Bounded env12722 := by
  intro p hp
  have h : env12722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12721_12722 : H12AffineEnvironment.transform 12 348 env12721 = env12722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env12721 == env12722) = true)

theorem identity12722 : scanCanonicalize (H12AffineFastState.compose env12722 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound12722 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env12723 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,32768,262,16400,2341,1025,32769,50449,33,17,32770,269,17,2049,49169,36865,35109,1284,32,257,32800,16384,513]

theorem envBound12723 : H12AffineFastState.Bounded env12723 := by
  intro p hp
  have h : env12723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12722_12723 : H12AffineEnvironment.transform 5 16 env12722 = env12723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env12722 == env12723) = true)

theorem identity12723 : scanCanonicalize (H12AffineFastState.compose env12723 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound12723 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12724 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,0,262,16400,2341,1025,1,17681,33,17,2,269,17,2049,16401,4097,2341,1284,32,257,32,16384,513]

theorem envBound12724 : H12AffineFastState.Bounded env12724 := by
  intro p hp
  have h : env12724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12723_12724 : H12AffineEnvironment.transform 14 0 env12723 = env12724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env12723 == env12724) = true)

theorem identity12724 : scanCanonicalize (H12AffineFastState.compose env12724 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound12724 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env12725 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,5377,0,262,5393,2341,1025,1,4112,33,17,2,269,17,2049,5392,4097,2341,1284,32,257,32,5377,513]

theorem envBound12725 : H12AffineFastState.Bounded env12725 := by
  intro p hp
  have h : env12725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12724_12725 : H12AffineEnvironment.transform 13 5377 env12724 = env12725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env12724 == env12725) = true)

theorem identity12725 : scanCanonicalize (H12AffineFastState.compose env12725 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound12725 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12726 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,309,268,1076,0,262,1060,2341,1025,1,293,33,17,2,269,17,2049,1061,308,2341,1284,32,257,32,1076,513]

theorem envBound12726 : H12AffineFastState.Bounded env12726 := by
  intro p hp
  have h : env12726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12725_12726 : H12AffineEnvironment.transform 11 309 env12725 = env12726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env12725 == env12726) = true)

theorem identity12726 : scanCanonicalize (H12AffineFastState.compose env12726 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound12726 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env12727 : List Nat := [2,4,8,16,32,16,9,256,512,272,2048,309,268,292,0,262,308,2341,273,1,293,33,17,2,269,17,2049,309,308,2341,20,32,257,32,292,513]

theorem envBound12727 : H12AffineFastState.Bounded env12727 := by
  intro p hp
  have h : env12727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12726_12727 : H12AffineEnvironment.transform 9 272 env12726 = env12727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env12726 == env12727) = true)

theorem identity12727 : scanCanonicalize (H12AffineFastState.compose env12727 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound12727 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env12728 : List Nat := [2,4,8,16,32,16,9,256,512,272,1,309,268,292,0,262,308,292,273,1,293,33,17,2,269,17,0,309,308,292,20,32,257,32,292,513]

theorem envBound12728 : H12AffineFastState.Bounded env12728 := by
  intro p hp
  have h : env12728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12727_12728 : H12AffineEnvironment.transform 10 1 env12727 = env12728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env12727 == env12728) = true)

theorem identity12728 : scanCanonicalize (H12AffineFastState.compose env12728 (packedSelected [1,8] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12728 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env12729 : List Nat := [2,4,8,16,32,16,9,36,512,52,1,17,40,0,0,34,16,0,53,1,1,33,17,2,41,17,0,17,16,0,20,32,37,32,0,513]

theorem envBound12729 : H12AffineFastState.Bounded env12729 := by
  intro p hp
  have h : env12729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12728_12729 : H12AffineEnvironment.transform 7 36 env12728 = env12729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12728 == env12729) = true)

theorem identity12729 : scanCanonicalize (H12AffineFastState.compose env12729 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 16) := by decide +kernel

theorem selectedBound12729 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12730 : List Nat := [2,4,8,16,32,16,9,36,16,52,1,17,40,0,0,34,16,0,53,1,1,33,17,2,41,17,0,17,16,0,20,32,37,32,0,17]

theorem envBound12730 : H12AffineFastState.Bounded env12730 := by
  intro p hp
  have h : env12730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12729_12730 : H12AffineEnvironment.transform 8 16 env12729 = env12730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env12729 == env12730) = true)

theorem identity12730 : scanCanonicalize (H12AffineFastState.compose env12730 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound12730 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12731 : List Nat := [2,4,2,16,32,16,3,36,16,52,1,17,34,0,0,34,16,0,53,1,1,33,17,2,35,17,0,17,16,0,20,32,37,32,0,17]

theorem envBound12731 : H12AffineFastState.Bounded env12731 := by
  intro p hp
  have h : env12731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12730_12731 : H12AffineEnvironment.transform 2 2 env12730 = env12731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env12730 == env12731) = true)

def env12732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,262144,1025,32769,2097152,4194304,272440,41310,8193,65,4262263,2172250,2391401,43048,331127,6407190,257,2444610,2468974,272936]

theorem envBound12732 : H12AffineFastState.Bounded env12732 := by
  intro p hp
  have h : env12732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12683_12732 : H12AffineEnvironment.transform 16 16401 env12683 = env12732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env12683 == env12732) = true)

theorem identity12732 : scanCanonicalize (H12AffineFastState.compose env12732 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound12732 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env12733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,2097152,4194304,17,41310,8193,65,4262263,2172250,2118976,43048,75102,6407190,257,2188651,2196551,513]

theorem envBound12733 : H12AffineFastState.Bounded env12733 := by
  intro p hp
  have h : env12733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12732_12733 : H12AffineEnvironment.transform 17 10281 env12732 = env12733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env12732 == env12733) = true)

theorem identity12733 : scanCanonicalize (H12AffineFastState.compose env12733 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 115735) := by decide +kernel

theorem selectedBound12733 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16401,10281,1025,32769,115735,4194304,17,41310,8193,65,4262263,57677,102743,43048,75102,4194305,257,41340,16464,513]

theorem envBound12734 : H12AffineFastState.Bounded env12734 := by
  intro p hp
  have h : env12734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12733_12734 : H12AffineEnvironment.transform 20 115735 env12733 = env12734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 115735 env12733 == env12734) = true)

theorem identity12734 : scanCanonicalize (H12AffineFastState.compose env12734 (packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound12734 : packedSelected [0,3,4,7,8,9,10,11,12,20,24,28] rootPS < 2^1333 := by decide +kernel

def env12735 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,342,16401,10281,1025,32769,50497,4194304,17,41310,8193,65,4196385,57677,36865,43048,9224,4194305,257,41340,16464,513]

theorem envBound12735 : H12AffineFastState.Bounded env12735 := by
  intro p hp
  have h : env12735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12734_12735 : H12AffineEnvironment.transform 15 342 env12734 = env12735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env12734 == env12735) = true)

theorem identity12735 : scanCanonicalize (H12AffineFastState.compose env12735 (packedSelected [0,7,11,18,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound12735 : packedSelected [0,7,11,18,20] rootPS < 2^1333 := by decide +kernel

def env12736 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16401,10281,1025,8541,25629,4194304,17,2,8193,65,4196385,16401,12637,2420,9224,4194305,257,32,16464,513]

theorem envBound12736 : H12AffineFastState.Bounded env12736 := by
  intro p hp
  have h : env12736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12735_12736 : H12AffineEnvironment.transform 14 8540 env12735 = env12736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env12735 == env12736) = true)

theorem identity12736 : scanCanonicalize (H12AffineFastState.compose env12736 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(21+1) ^^^ 8572) := by decide +kernel

theorem selectedBound12736 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env12737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8540,342,16401,10281,1025,8541,25629,8572,17,2,8193,65,10589,16401,12637,2420,9224,8573,257,32,16464,513]

theorem envBound12737 : H12AffineFastState.Bounded env12737 := by
  intro p hp
  have h : env12737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12736_12737 : H12AffineEnvironment.transform 21 8572 env12736 = env12737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8572 env12736 == env12737) = true)

theorem identity12737 : scanCanonicalize (H12AffineFastState.compose env12737 (packedSelected [2,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 9341) := by decide +kernel

theorem selectedBound12737 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env12738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,9341,8540,342,9324,10281,1025,8541,96,8572,17,2,8193,65,10589,9324,12637,2420,9224,8573,257,32,9261,513]

theorem envBound12738 : H12AffineFastState.Bounded env12738 := by
  intro p hp
  have h : env12738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12737_12738 : H12AffineEnvironment.transform 13 9341 env12737 = env12738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 9341 env12737 == env12738) = true)

theorem identity12738 : scanCanonicalize (H12AffineFastState.compose env12738 (packedSelected [1,2,3,5,6,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound12738 : packedSelected [1,2,3,5,6,8,12] rootPS < 2^1333 := by decide +kernel

def env12739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,1312,1,342,1329,2420,1025,0,96,33,17,2,348,65,2048,1329,4096,2420,1365,32,257,32,1392,513]

theorem envBound12739 : H12AffineFastState.Bounded env12739 := by
  intro p hp
  have h : env12739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12738_12739 : H12AffineEnvironment.transform 12 349 env12738 = env12739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env12738 == env12739) = true)

theorem identity12739 : scanCanonicalize (H12AffineFastState.compose env12739 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 784) := by decide +kernel

theorem selectedBound12739 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env12740 : List Nat := [2,4,8,16,32,64,9,256,512,784,2048,4096,349,560,1,342,545,2420,785,0,96,33,17,2,348,65,2048,545,4096,2420,581,32,257,32,608,513]

theorem envBound12740 : H12AffineFastState.Bounded env12740 := by
  intro p hp
  have h : env12740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12739_12740 : H12AffineEnvironment.transform 9 784 env12739 = env12740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 784 env12739 == env12740) = true)

def env12741 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,1073741824,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound12741 : H12AffineFastState.Bounded env12741 := by
  intro p hp
  have h : env12741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9917_12741 : H12AffineEnvironment.transform 31 145662401 env9917 = env12741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662401 env9917 == env12741) = true)

def env12742 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497100,77616400,155254784,92374096,145662401,525568,140903596,27337992,25733062]

theorem envBound12742 : H12AffineFastState.Bounded env12742 := by
  intro p hp
  have h : env12742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12741_12742 : H12AffineEnvironment.transform 29 155254784 env12741 = env12742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env12741 == env12742) = true)

def env12743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497100,10507600,155254784,25265168,145662401,525568,140903596,27337992,25733062]

theorem envBound12743 : H12AffineFastState.Bounded env12743 := by
  intro p hp
  have h : env12743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12742_12743 : H12AffineEnvironment.transform 25 64 env12742 = env12743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env12742 == env12743) = true)

def env12744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497100,10507600,9356288,25265168,23160257,525568,27902124,27337992,25733062]

theorem envBound12744 : H12AffineFastState.Bounded env12744 := by
  intro p hp
  have h : env12744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12743_12744 : H12AffineEnvironment.transform 26 30393344 env12743 = env12744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env12743 == env12744) = true)

def env12745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507600,8830976,25265168,23160257,256,27378860,27337992,25207750]

theorem envBound12745 : H12AffineFastState.Bounded env12745 := by
  intro p hp
  have h : env12745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12744_12745 : H12AffineEnvironment.transform 18 1024 env12744 = env12745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env12744 == env12745) = true)

def env12746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,10588556,8328,64,6705548,8393984,10507600,8830976,2102684,12645453,256,21792,46212,2175562]

theorem envBound12746 : H12AffineFastState.Bounded env12746 := by
  intro p hp
  have h : env12746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12745_12746 : H12AffineEnvironment.transform 23 10588556 env12745 = env12746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10588556 env12745 == env12746) = true)

def env12747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,2101328,98780,8328,64,6705548,2098512,17664,2543696,2102684,6349853,256,21792,46212,2175562]

theorem envBound12747 : H12AffineFastState.Bounded env12747 := by
  intro p hp
  have h : env12747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12746_12747 : H12AffineEnvironment.transform 22 2101328 env12746 = env12747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env12746 == env12747) = true)

def env12748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272512,2101328,98780,8328,64,2259212,2098512,17664,2543696,2102684,2411677,256,21792,46212,2175562]

theorem envBound12748 : H12AffineFastState.Bounded env12748 := by
  intro p hp
  have h : env12748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12747_12748 : H12AffineEnvironment.transform 21 272512 env12747 = env12748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env12747 == env12748) = true)

theorem identity12748 : scanCanonicalize (H12AffineFastState.compose env12748 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound12748 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env12749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1024,32769,2097152,272512,2101328,21762,8328,64,2259212,2098512,17664,2543696,2102684,2411677,256,21792,46212,2156180]

theorem envBound12749 : H12AffineFastState.Bounded env12749 := by
  intro p hp
  have h : env12749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12748_12749 : H12AffineEnvironment.transform 15 54494 env12748 = env12749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env12748 == env12749) = true)

def env12750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,2097152,272392,2101328,21762,8192,64,2259212,2098512,17664,2543696,2102548,2411541,256,21792,46092,2156060]

theorem envBound12750 : H12AffineFastState.Bounded env12750 := by
  intro p hp
  have h : env12750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12749_12750 : H12AffineEnvironment.transform 6 8 env12749 = env12750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env12749 == env12750) = true)

theorem identity12750 : scanCanonicalize (H12AffineFastState.compose env12750 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(20+1) ^^^ 429092) := by decide +kernel

theorem selectedBound12750 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env12751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,429092,272392,433268,21762,8192,64,324904,428404,17664,23668,432432,147505,256,21792,46092,420408]

theorem envBound12751 : H12AffineFastState.Bounded env12751 := by
  intro p hp
  have h : env12751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12750_12751 : H12AffineEnvironment.transform 20 429092 env12750 = env12751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 429092 env12750 == env12751) = true)

theorem identity12751 : scanCanonicalize (H12AffineFastState.compose env12751 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound12751 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env12752 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54358,131072,35188,1024,32769,132432,41340,136448,21762,8192,64,31836,131072,17664,23668,135236,147505,256,21792,46092,189260]

theorem envBound12752 : H12AffineFastState.Bounded env12752 := by
  intro p hp
  have h : env12752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12751_12752 : H12AffineEnvironment.transform 17 35188 env12751 = env12752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env12751 == env12752) = true)

theorem identity12752 : scanCanonicalize (H12AffineFastState.compose env12752 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound12752 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env12753 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,35188,1024,32769,132432,41340,136448,2,8192,64,10588,131072,4096,2420,135236,136497,256,32,46092,177740]

theorem envBound12753 : H12AffineFastState.Bounded env12753 := by
  intro p hp
  have h : env12753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12752_12753 : H12AffineEnvironment.transform 13 5376 env12752 = env12753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env12752 == env12753) = true)

theorem identity12753 : scanCanonicalize (H12AffineFastState.compose env12753 (packedSelected [3,4,5,9,10,12,14,15,20] rootPS)) = affineNative (2^(14+1) ^^^ 373) := by decide +kernel

theorem selectedBound12753 : packedSelected [3,4,5,9,10,12,14,15,20] rootPS < 2^1333 := by decide +kernel

def env12754 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,373,35,131072,2049,1024,372,132432,8201,136448,2,8192,64,10588,131072,4096,2420,135236,136497,256,32,13689,145209]

theorem envBound12754 : H12AffineFastState.Bounded env12754 := by
  intro p hp
  have h : env12754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12753_12754 : H12AffineEnvironment.transform 14 373 env12753 = env12754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 373 env12753 == env12754) = true)

theorem identity12754 : scanCanonicalize (H12AffineFastState.compose env12754 (packedSelected [0,2,4,6,9,11,16,17,18,27] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound12754 : packedSelected [0,2,4,6,9,11,16,17,18,27] rootPS < 2^1333 := by decide +kernel

def env12755 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,373,35,5392,2049,1024,372,4160,8201,16,2,8192,64,10588,5392,4096,2420,1364,33,256,32,13689,8745]

theorem envBound12755 : H12AffineFastState.Bounded env12755 := by
  intro p hp
  have h : env12755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12754_12755 : H12AffineEnvironment.transform 16 5392 env12754 = env12755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env12754 == env12755) = true)

theorem identity12755 : scanCanonicalize (H12AffineFastState.compose env12755 (packedSelected [0,1,6,7,8,10,11,12] rootPS)) = affineNative (2^(12+1) ^^^ 89) := by decide +kernel

theorem selectedBound12755 : packedSelected [0,1,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env12756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,89,5376,373,35,5392,2049,1024,372,4160,80,16,2,89,64,2309,5392,4096,2420,1364,33,256,32,5408,624]

theorem envBound12756 : H12AffineFastState.Bounded env12756 := by
  intro p hp
  have h : env12756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12755_12756 : H12AffineEnvironment.transform 12 89 env12755 = env12756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 89 env12755 == env12756) = true)

theorem identity12756 : scanCanonicalize (H12AffineFastState.compose env12756 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound12756 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12757 : List Nat := [2,4,8,16,32,48,8,256,512,1024,2048,4096,41,5376,261,35,5392,2049,1024,260,4144,32,16,2,41,48,2309,5392,4096,2308,1316,33,256,32,5408,512]

theorem envBound12757 : H12AffineFastState.Bounded env12757 := by
  intro p hp
  have h : env12757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12756_12757 : H12AffineEnvironment.transform 5 48 env12756 = env12757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env12756 == env12757) = true)

theorem identity12757 : scanCanonicalize (H12AffineFastState.compose env12757 (packedSelected [2,4,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound12757 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env12758 : List Nat := [2,4,8,16,32,48,8,36,512,1024,2048,4096,41,5156,33,35,5172,2049,1024,32,4144,32,16,2,41,48,2081,5172,4096,2080,1024,33,36,32,5124,512]

theorem envBound12758 : H12AffineFastState.Bounded env12758 := by
  intro p hp
  have h : env12758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12757_12758 : H12AffineEnvironment.transform 7 36 env12757 = env12758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env12757 == env12758) = true)

theorem identity12758 : scanCanonicalize (H12AffineFastState.compose env12758 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound12758 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env12759 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,4096,9,5124,1,3,5140,2049,1024,0,4112,0,16,2,9,16,2049,5140,4096,2048,1024,1,4,0,5124,512]

theorem envBound12759 : H12AffineFastState.Bounded env12759 := by
  intro p hp
  have h : env12759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12758_12759 : H12AffineEnvironment.transform 4 0 env12758 = env12759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env12758 == env12759) = true)

def env12760 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,16,9,1044,1,3,1028,2049,1024,0,0,0,16,2,9,16,2049,1028,16,2048,1024,1,4,0,1044,512]

theorem envBound12760 : H12AffineFastState.Bounded env12760 := by
  intro p hp
  have h : env12760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12759_12760 : H12AffineEnvironment.transform 11 16 env12759 = env12760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 16 env12759 == env12760) = true)

theorem identity12760 : scanCanonicalize (H12AffineFastState.compose env12760 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound12760 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12761 : List Nat := [2,4,8,16,0,16,8,4,512,1024,1045,16,9,1044,1,3,1028,1044,1024,0,0,0,16,2,9,16,1044,1028,16,1045,1024,1,4,0,1044,512]

theorem envBound12761 : H12AffineFastState.Bounded env12761 := by
  intro p hp
  have h : env12761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12760_12761 : H12AffineEnvironment.transform 10 1045 env12760 = env12761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env12760 == env12761) = true)

def env12762 : List Nat := [2,4,8,16,0,16,8,4,512,20,1,16,9,0,1,3,16,0,20,0,0,0,16,2,9,16,0,16,16,1,20,1,4,0,0,512]

theorem envBound12762 : H12AffineFastState.Bounded env12762 := by
  intro p hp
  have h : env12762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12761_12762 : H12AffineEnvironment.transform 9 20 env12761 = env12762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12761 == env12762) = true)

theorem identity12762 : scanCanonicalize (H12AffineFastState.compose env12762 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound12762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12763 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,9,0,1,3,4,0,0,0,0,0,4,2,9,4,0,4,4,1,0,1,4,0,0,512]

theorem envBound12763 : H12AffineFastState.Bounded env12763 := by
  intro p hp
  have h : env12763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12762_12763 : H12AffineEnvironment.transform 3 4 env12762 = env12763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env12762 == env12763) = true)

def leafEnv12763 : List Nat := [2,4,8,4,0,4,8,4,512,0,1,4,9,0,1,3,4,0,0,0,0,0,4,2,0,9,1,4,0,4,4,1,0,1,4,0,4,3,0,512,1,0,0]

def active12763 : List Nat := [0,1,2,8]

def tree12763 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12763 : H12WitnessSearch.Good tree12763 := H12GlobalWitnessIndex.good

theorem leafIdentity12763 : H12AffineFastState.composeSystem env12763 rootObs = leafEnv12763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12763 rootObs == leafEnv12763) = true)

theorem terminalChecked12763 : H12PackedTerminal.terminalCheckFast leafEnv12763 active12763 tree12763 = true := by decide +kernel

def env12764 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,16,9,1,1,3,17,1,21,0,0,0,16,2,9,16,1,17,16,0,21,1,4,0,1,512]

theorem envBound12764 : H12AffineFastState.Bounded env12764 := by
  intro p hp
  have h : env12764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12761_12764 : H12AffineEnvironment.transform 9 21 env12761 = env12764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env12761 == env12764) = true)

theorem identity12764 : scanCanonicalize (H12AffineFastState.compose env12764 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound12764 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12765 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,16,9,1,1,3,17,1,21,0,0,0,16,2,9,16,1,17,16,0,21,1,4,0,1,30]

theorem envBound12765 : H12AffineFastState.Bounded env12765 := by
  intro p hp
  have h : env12765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12764_12765 : H12AffineEnvironment.transform 8 30 env12764 = env12765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env12764 == env12765) = true)

def leafEnv12765 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,16,9,1,1,3,17,1,21,0,0,0,16,2,21,9,1,16,1,17,16,0,21,1,4,0,4,3,1,30,1,0,0]

def active12765 : List Nat := [0,1,2,3]

def tree12765 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12765 : H12WitnessSearch.Good tree12765 := H12GlobalWitnessIndex.good

theorem leafIdentity12765 : H12AffineFastState.composeSystem env12765 rootObs = leafEnv12765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12765 rootObs == leafEnv12765) = true)

theorem terminalChecked12765 : H12PackedTerminal.terminalCheckFast leafEnv12765 active12765 tree12765 = true := by decide +kernel

def env12766 : List Nat := [2,4,8,16,0,16,8,4,512,1024,2048,17,9,1045,1,3,1029,2049,1024,0,1,0,16,2,9,16,2049,1029,17,2048,1024,1,4,0,1045,512]

theorem envBound12766 : H12AffineFastState.Bounded env12766 := by
  intro p hp
  have h : env12766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12759_12766 : H12AffineEnvironment.transform 11 17 env12759 = env12766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env12759 == env12766) = true)

theorem identity12766 : scanCanonicalize (H12AffineFastState.compose env12766 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound12766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env12767 : List Nat := [2,4,8,16,0,16,8,4,512,1024,0,17,9,1045,1,3,1029,1,1024,0,1,0,16,2,9,16,1,1029,17,0,1024,1,4,0,1045,512]

theorem envBound12767 : H12AffineFastState.Bounded env12767 := by
  intro p hp
  have h : env12767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12766_12767 : H12AffineEnvironment.transform 10 0 env12766 = env12767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env12766 == env12767) = true)

def env12768 : List Nat := [2,4,8,16,0,16,8,4,512,20,0,17,9,1,1,3,17,1,20,0,1,0,16,2,9,16,1,17,17,0,20,1,4,0,1,512]

theorem envBound12768 : H12AffineFastState.Bounded env12768 := by
  intro p hp
  have h : env12768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12767_12768 : H12AffineEnvironment.transform 9 20 env12767 = env12768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env12767 == env12768) = true)

theorem identity12768 : scanCanonicalize (H12AffineFastState.compose env12768 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound12768 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12769 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,1,3,5,1,0,0,1,0,4,2,9,4,1,5,5,0,0,1,4,0,1,512]

theorem envBound12769 : H12AffineFastState.Bounded env12769 := by
  intro p hp
  have h : env12769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12768_12769 : H12AffineEnvironment.transform 3 4 env12768 = env12769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env12768 == env12769) = true)

def leafEnv12769 : List Nat := [2,4,8,4,0,4,8,4,512,0,0,5,9,1,1,3,5,1,0,0,1,0,4,2,0,9,1,4,1,5,5,0,0,1,4,0,4,3,1,512,1,1,0]

def active12769 : List Nat := [0,1,2,8]

def tree12769 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12769 : H12WitnessSearch.Good tree12769 := H12GlobalWitnessIndex.good

theorem leafIdentity12769 : H12AffineFastState.composeSystem env12769 rootObs = leafEnv12769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12769 rootObs == leafEnv12769) = true)

theorem terminalChecked12769 : H12PackedTerminal.terminalCheckFast leafEnv12769 active12769 tree12769 = true := by decide +kernel

def env12770 : List Nat := [2,4,8,16,0,16,8,4,512,21,0,17,9,0,1,3,16,1,21,0,1,0,16,2,9,16,1,16,17,0,21,1,4,0,0,512]

theorem envBound12770 : H12AffineFastState.Bounded env12770 := by
  intro p hp
  have h : env12770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12767_12770 : H12AffineEnvironment.transform 9 21 env12767 = env12770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env12767 == env12770) = true)

theorem identity12770 : scanCanonicalize (H12AffineFastState.compose env12770 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 30) := by decide +kernel

theorem selectedBound12770 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env12771 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,9,0,1,3,16,1,21,0,1,0,16,2,9,16,1,16,17,0,21,1,4,0,0,30]

theorem envBound12771 : H12AffineFastState.Bounded env12771 := by
  intro p hp
  have h : env12771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12770_12771 : H12AffineEnvironment.transform 8 30 env12770 = env12771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 30 env12770 == env12771) = true)

def leafEnv12771 : List Nat := [2,4,8,16,0,16,8,4,30,21,0,17,9,0,1,3,16,1,21,0,1,0,16,2,21,9,1,16,1,16,17,0,21,1,4,0,4,3,0,30,1,1,0]

def active12771 : List Nat := [0,1,2,3]

def tree12771 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood12771 : H12WitnessSearch.Good tree12771 := H12GlobalWitnessIndex.good

theorem leafIdentity12771 : H12AffineFastState.composeSystem env12771 rootObs = leafEnv12771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env12771 rootObs == leafEnv12771) = true)

theorem terminalChecked12771 : H12PackedTerminal.terminalCheckFast leafEnv12771 active12771 tree12771 = true := by decide +kernel

def env12772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,2097152,272393,2101328,21762,8193,64,2259212,2098512,17664,2543696,2102549,2411540,256,21792,46093,2156061]

theorem envBound12772 : H12AffineFastState.Bounded env12772 := by
  intro p hp
  have h : env12772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12749_12772 : H12AffineEnvironment.transform 6 9 env12749 = env12772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env12749 == env12772) = true)

theorem identity12772 : scanCanonicalize (H12AffineFastState.compose env12772 (packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound12772 : packedSelected [0,1,4,7,12,15,16,17,19,20,22,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env12773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,2097152,33,2101328,21762,8193,64,2259212,2098512,17664,2291832,2102549,2155580,256,21792,46093,2156061]

theorem envBound12773 : H12AffineFastState.Bounded env12773 := by
  intro p hp
  have h : env12773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12772_12773 : H12AffineEnvironment.transform 17 10280 env12772 = env12773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env12772 == env12773) = true)

theorem identity12773 : scanCanonicalize (H12AffineFastState.compose env12773 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 58396) := by decide +kernel

theorem selectedBound12773 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env12774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,131072,10280,1024,32769,58396,33,62540,21762,8193,64,171280,57676,17664,138340,61705,32,256,21792,46093,513]

theorem envBound12774 : H12AffineFastState.Bounded env12774 := by
  intro p hp
  have h : env12774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12773_12774 : H12AffineEnvironment.transform 20 58396 env12773 = env12774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 58396 env12773 == env12774) = true)

theorem identity12774 : scanCanonicalize (H12AffineFastState.compose env12774 (packedSelected [0,1,7,8,10,12,16] rootPS)) = affineNative (2^(16+1) ^^^ 49216) := by decide +kernel

theorem selectedBound12774 : packedSelected [0,1,7,8,10,12,16] rootPS < 2^1333 := by decide +kernel

def env12775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49216,10280,1024,32769,58396,33,62540,21762,8193,64,23888,57676,17664,56356,61705,32,256,21792,46093,513]

theorem envBound12775 : H12AffineFastState.Bounded env12775 := by
  intro p hp
  have h : env12775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12774_12775 : H12AffineEnvironment.transform 16 49216 env12774 = env12775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49216 env12774 == env12775) = true)

theorem identity12775 : scanCanonicalize (H12AffineFastState.compose env12775 (packedSelected [2,6,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound12775 : packedSelected [2,6,12,15] rootPS < 2^1333 := by decide +kernel

def env12776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,21590,16449,10280,1024,0,25629,33,29773,21762,8193,64,23888,24909,17664,23589,28936,32,256,21792,13324,513]

theorem envBound12776 : H12AffineFastState.Bounded env12776 := by
  intro p hp
  have h : env12776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12775_12776 : H12AffineEnvironment.transform 14 1 env12775 = env12776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env12775 == env12776) = true)

theorem identity12776 : scanCanonicalize (H12AffineFastState.compose env12776 (packedSelected [1,2,6,8,10,12] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound12776 : packedSelected [1,2,6,8,10,12] rootPS < 2^1333 := by decide +kernel

def env12777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,1,8202,13341,10280,1024,0,4161,33,17,8542,8193,64,10508,5393,12636,10361,1364,32,256,8572,13324,513]

theorem envBound12777 : H12AffineFastState.Bounded env12777 := by
  intro p hp
  have h : env12777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12776_12777 : H12AffineEnvironment.transform 13 13404 env12776 = env12777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env12776 == env12777) = true)

theorem identity12777 : scanCanonicalize (H12AffineFastState.compose env12777 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound12777 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env12778 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,1,8202,13341,10280,1024,0,4112,33,17,8463,8193,17,10508,5393,12557,10280,1285,32,256,8493,13324,513]

theorem envBound12778 : H12AffineFastState.Bounded env12778 := by
  intro p hp
  have h : env12778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12777_12778 : H12AffineEnvironment.transform 5 17 env12777 = env12778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env12777 == env12778) = true)

theorem identity12778 : scanCanonicalize (H12AffineFastState.compose env12778 (packedSelected [0,2,4] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound12778 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env12779 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,9,5124,1,3,5140,2081,1024,0,4112,33,17,262,8,17,2309,5393,4356,2081,1285,32,256,292,5125,513]

theorem envBound12779 : H12AffineFastState.Bounded env12779 := by
  intro p hp
  have h : env12779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12778_12779 : H12AffineEnvironment.transform 12 9 env12778 = env12779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env12778 == env12779) = true)

theorem identity12779 : scanCanonicalize (H12AffineFastState.compose env12779 (packedSelected [2,5,8] rootPS)) = affineNative (2^(10+1) ^^^ 1818) := by decide +kernel

theorem selectedBound12779 : packedSelected [2,5,8] rootPS < 2^1333 := by decide +kernel

def env12780 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1818,4096,9,5124,1,3,5140,1851,1024,0,4112,33,17,262,8,17,1567,5393,4356,1851,1285,32,256,292,5125,513]

theorem envBound12780 : H12AffineFastState.Bounded env12780 := by
  intro p hp
  have h : env12780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12779_12780 : H12AffineEnvironment.transform 10 1818 env12779 = env12780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1818 env12779 == env12780) = true)

theorem identity12780 : scanCanonicalize (H12AffineFastState.compose env12780 (packedSelected [1,2,5,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound12780 : packedSelected [1,2,5,7,9] rootPS < 2^1333 := by decide +kernel

def env12781 : List Nat := [2,4,8,16,32,17,9,37,512,1024,1599,4096,9,5124,1,3,5140,1566,1024,0,4112,33,17,35,8,17,1567,5172,4129,1566,1056,32,37,1,5125,513]

theorem envBound12781 : H12AffineFastState.Bounded env12781 := by
  intro p hp
  have h : env12781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans12780_12781 : H12AffineEnvironment.transform 7 37 env12780 = env12781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env12780 == env12781) = true)

def env12782 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,272513,2101328,98780,8328,64,2259213,2098512,17664,2543696,2102684,2411676,256,21792,46212,2175562]

theorem envBound12782 : H12AffineFastState.Bounded env12782 := by
  intro p hp
  have h : env12782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1