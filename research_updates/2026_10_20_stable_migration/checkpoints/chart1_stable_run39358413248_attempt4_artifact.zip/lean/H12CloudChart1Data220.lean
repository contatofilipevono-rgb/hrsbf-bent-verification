import H12CloudChart1Data219

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envBound55707 : H12AffineFastState.Bounded env55707 := by
  intro p hp
  have h : env55707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55706_55707 : H12AffineEnvironment.transform 10 31 env55706 = env55707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 31 env55706 == env55707) = true)

def env55708 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,17,73737,8192,64,439609,79131,102743,431377,41992,98678,256,73770,103431,99158]

theorem envBound55708 : H12AffineFastState.Bounded env55708 := by
  intro p hp
  have h : env55708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55689_55708 : H12AffineEnvironment.transform 22 17 env55689 = env55708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env55689 == env55708) = true)

theorem identity55708 : scanCanonicalize (H12AffineFastState.compose env55708 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55708 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,10281,1024,32769,102679,32,17,73737,8192,64,171280,79131,102743,179512,41992,98678,256,73770,103431,99158]

theorem envBound55709 : H12AffineFastState.Bounded env55709 := by
  intro p hp
  have h : env55709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55708_55709 : H12AffineEnvironment.transform 17 10281 env55708 = env55709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55708 == env55709) = true)

theorem identity55709 : scanCanonicalize (H12AffineFastState.compose env55709 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 79131) := by decide +kernel

theorem selectedBound55709 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,79131,10281,1024,32769,102679,32,17,73737,8192,64,108555,79131,102743,100387,41992,98678,256,73770,103431,99158]

theorem envBound55710 : H12AffineFastState.Bounded env55710 := by
  intro p hp
  have h : env55710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55709_55710 : H12AffineEnvironment.transform 16 79131 env55709 = env55710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 79131 env55709 == env55710) = true)

theorem identity55710 : scanCanonicalize (H12AffineFastState.compose env55710 (packedSelected [1,4,8,9,12,14,15,16,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55710 : packedSelected [1,4,8,9,12,14,15,16,19] rootPS < 2^1333 := by decide +kernel

def env55711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,263,13340,10281,1024,32769,36880,32,17,8462,8192,64,43276,13340,36944,35108,41992,32881,256,8493,38144,33361]

theorem envBound55711 : H12AffineFastState.Bounded env55711 := by
  intro p hp
  have h : env55711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55710_55711 : H12AffineEnvironment.transform 15 263 env55710 = env55711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55710 == env55711) = true)

theorem identity55711 : scanCanonicalize (H12AffineFastState.compose env55711 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound55711 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env55712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,80,263,13340,10281,1024,81,4160,32,17,8462,8192,64,10588,13340,4096,2420,9304,33,256,8493,5456,513]

theorem envBound55712 : H12AffineFastState.Bounded env55712 := by
  intro p hp
  have h : env55712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55711_55712 : H12AffineEnvironment.transform 14 80 env55711 = env55712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env55711 == env55712) = true)

theorem identity55712 : scanCanonicalize (H12AffineFastState.compose env55712 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55712 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5376,80,263,5392,2341,1024,81,4160,32,17,2,268,64,2128,5392,4096,2420,1364,33,256,33,5456,513]

theorem envBound55713 : H12AffineFastState.Bounded env55713 := by
  intro p hp
  have h : env55713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55712_55713 : H12AffineEnvironment.transform 12 268 env55712 = env55713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55712 == env55713) = true)

theorem identity55713 : scanCanonicalize (H12AffineFastState.compose env55713 (packedSelected [1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 276) := by decide +kernel

theorem selectedBound55713 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55714 : List Nat := [2,4,8,16,32,64,8,256,276,1024,2048,4096,268,5376,80,263,5392,2341,1024,81,4160,32,17,2,268,64,2128,5392,4096,2420,1364,33,256,33,5456,277]

theorem envBound55714 : H12AffineFastState.Bounded env55714 := by
  intro p hp
  have h : env55714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55713_55714 : H12AffineEnvironment.transform 8 276 env55713 = env55714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 276 env55713 == env55714) = true)

theorem identity55714 : scanCanonicalize (H12AffineFastState.compose env55714 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 3360) := by decide +kernel

theorem selectedBound55714 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env55715 : List Nat := [2,4,8,16,32,64,8,256,276,1024,2048,3360,268,2080,80,263,2096,2341,1024,81,3424,32,17,2,268,64,2128,2096,3360,2420,1364,33,256,33,2160,277]

theorem envBound55715 : H12AffineFastState.Bounded env55715 := by
  intro p hp
  have h : env55715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55714_55715 : H12AffineEnvironment.transform 11 3360 env55714 = env55715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3360 env55714 == env55715) = true)

theorem identity55715 : scanCanonicalize (H12AffineFastState.compose env55715 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound55715 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55716 : List Nat := [2,4,8,16,32,64,8,256,276,101,2048,2373,268,2080,80,263,2096,2341,101,81,2309,32,17,2,268,64,2128,2096,2373,2420,305,33,256,33,2160,277]

theorem envBound55716 : H12AffineFastState.Bounded env55716 := by
  intro p hp
  have h : env55716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55715_55716 : H12AffineEnvironment.transform 9 101 env55715 = env55716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env55715 == env55716) = true)

theorem identity55716 : scanCanonicalize (H12AffineFastState.compose env55716 (packedSelected [0,2,7] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound55716 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55717 : List Nat := [2,4,8,16,32,64,8,256,276,101,32,357,268,0,80,263,16,261,101,81,293,32,17,2,268,64,112,16,357,340,305,33,256,33,80,277]

theorem envBound55717 : H12AffineFastState.Bounded env55717 := by
  intro p hp
  have h : env55717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55716_55717 : H12AffineEnvironment.transform 10 32 env55716 = env55717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env55716 == env55717) = true)

theorem identity55717 : scanCanonicalize (H12AffineFastState.compose env55717 (packedSelected [4,9] rootPS)) = affineNative (2^(7+1) ^^^ 85) := by decide +kernel

theorem selectedBound55717 : packedSelected [4,9] rootPS < 2^1333 := by decide +kernel

def env55718 : List Nat := [2,4,8,16,32,64,8,85,65,101,32,48,89,0,80,82,16,80,101,81,112,32,17,2,89,64,112,16,48,1,100,33,85,33,80,64]

theorem envBound55718 : H12AffineFastState.Bounded env55718 := by
  intro p hp
  have h : env55718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55717_55718 : H12AffineEnvironment.transform 7 85 env55717 = env55718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 85 env55717 == env55718) = true)

theorem identity55718 : scanCanonicalize (H12AffineFastState.compose env55718 (packedSelected [11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55718 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env55719 : List Nat := [2,4,8,16,32,17,8,4,16,52,32,48,8,0,1,3,16,1,52,0,33,32,17,2,8,17,33,16,48,1,53,33,4,33,1,17]

theorem envBound55719 : H12AffineFastState.Bounded env55719 := by
  intro p hp
  have h : env55719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55718_55719 : H12AffineEnvironment.transform 5 17 env55718 = env55719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55718 == env55719) = true)

theorem identity55719 : scanCanonicalize (H12AffineFastState.compose env55719 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound55719 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55720 : List Nat := [2,4,8,0,32,1,8,4,0,36,32,32,8,0,1,3,0,1,36,0,33,32,1,2,8,1,33,0,32,1,37,33,4,33,1,1]

theorem envBound55720 : H12AffineFastState.Bounded env55720 := by
  intro p hp
  have h : env55720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55719_55720 : H12AffineEnvironment.transform 3 0 env55719 = env55720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env55719 == env55720) = true)

def env55721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,8388608,73736,8193,64,8828201,79131,8491334,8819968,8430616,98678,256,8462395,8492055,8487751]

theorem envBound55721 : H12AffineFastState.Bounded env55721 := by
  intro p hp
  have h : env55721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55688_55721 : H12AffineEnvironment.transform 6 9 env55688 = env55721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55688 == env55721) = true)

def env55722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,16,73736,8193,64,439609,79131,102742,431376,41992,98678,256,73771,103431,99159]

theorem envBound55722 : H12AffineFastState.Bounded env55722 := by
  intro p hp
  have h : env55722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55721_55722 : H12AffineEnvironment.transform 22 16 env55721 = env55722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55721 == env55722) = true)

theorem identity55722 : scanCanonicalize (H12AffineFastState.compose env55722 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55722 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,77898,32,16,73736,8193,64,398436,79131,77835,406605,1365,73771,256,73771,79194,74250]

theorem envBound55723 : H12AffineFastState.Bounded env55723 := by
  intro p hp
  have h : env55723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55722_55723 : H12AffineEnvironment.transform 14 8541 env55722 = env55723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55722 == env55723) = true)

theorem identity55723 : scanCanonicalize (H12AffineFastState.compose env55723 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 212079) := by decide +kernel

theorem selectedBound55723 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env55724 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,212079,1024,8540,77898,32,16,73736,8193,64,75787,79131,77835,67618,1365,73771,256,73771,79194,74250]

theorem envBound55724 : H12AffineFastState.Bounded env55724 := by
  intro p hp
  have h : env55724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55723_55724 : H12AffineEnvironment.transform 17 212079 env55723 = env55724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212079 env55723 == env55724) = true)

theorem identity55724 : scanCanonicalize (H12AffineFastState.compose env55724 (packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55724 : packedSelected [0,1,7,8,9,12,14,15,19,20,22] rootPS < 2^1333 := by decide +kernel

def env55725 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,373,65536,131072,203847,1024,372,69730,32,16,65568,41,64,67619,70963,69667,67618,1365,65539,256,65539,71026,66082]

theorem envBound55725 : H12AffineFastState.Bounded env55725 := by
  intro p hp
  have h : env55725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55724_55725 : H12AffineEnvironment.transform 12 40 env55724 = env55725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55724 == env55725) = true)

theorem identity55725 : scanCanonicalize (H12AffineFastState.compose env55725 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound55725 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55726 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,373,35,131072,138340,1024,372,4161,32,16,3,41,64,2048,5392,4096,2049,1365,32,256,32,5457,513]

theorem envBound55726 : H12AffineFastState.Bounded env55726 := by
  intro p hp
  have h : env55726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55725_55726 : H12AffineEnvironment.transform 15 35 env55725 = env55726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env55725 == env55726) = true)

theorem identity55726 : scanCanonicalize (H12AffineFastState.compose env55726 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 5172) := by decide +kernel

theorem selectedBound55726 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55727 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,40,5376,373,35,5172,2128,1024,372,4161,32,16,3,41,64,2048,5392,4096,2049,1365,32,256,32,5457,513]

theorem envBound55727 : H12AffineFastState.Bounded env55727 := by
  intro p hp
  have h : env55727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55726_55727 : H12AffineEnvironment.transform 16 5172 env55726 = env55727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5172 env55726 == env55727) = true)

theorem identity55727 : scanCanonicalize (H12AffineFastState.compose env55727 (packedSelected [11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound55727 : packedSelected [11,12] rootPS < 2^1333 := by decide +kernel

def env55728 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3109,40,2341,373,35,2065,2128,1024,372,3172,32,16,3,41,64,2048,2357,3109,2049,1365,32,256,32,2420,513]

theorem envBound55728 : H12AffineFastState.Bounded env55728 := by
  intro p hp
  have h : env55728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55727_55728 : H12AffineEnvironment.transform 11 3109 env55727 = env55728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env55727 == env55728) = true)

theorem identity55728 : scanCanonicalize (H12AffineFastState.compose env55728 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound55728 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55729 : List Nat := [2,4,8,16,32,64,9,256,512,100,2048,2113,40,2341,373,35,2065,2128,100,372,2048,32,16,3,41,64,2048,2357,2113,2049,305,32,256,32,2420,513]

theorem envBound55729 : H12AffineFastState.Bounded env55729 := by
  intro p hp
  have h : env55729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55728_55729 : H12AffineEnvironment.transform 9 100 env55728 = env55729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env55728 == env55729) = true)

theorem identity55729 : scanCanonicalize (H12AffineFastState.compose env55729 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55729 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env55730 : List Nat := [2,4,8,16,32,64,9,37,512,100,2048,2113,40,2048,80,35,2065,2128,100,81,2048,32,16,3,41,64,2048,2064,2113,2049,20,32,37,32,2129,513]

theorem envBound55730 : H12AffineFastState.Bounded env55730 := by
  intro p hp
  have h : env55730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55729_55730 : H12AffineEnvironment.transform 7 37 env55729 = env55730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55729 == env55730) = true)

theorem identity55730 : scanCanonicalize (H12AffineFastState.compose env55730 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound55730 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env55731 : List Nat := [2,4,8,16,21,64,9,16,512,81,2048,2113,29,2048,80,22,2065,2128,81,81,2048,21,16,3,28,64,2048,2064,2113,2049,20,21,16,21,2129,513]

theorem envBound55731 : H12AffineFastState.Bounded env55731 := by
  intro p hp
  have h : env55731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55730_55731 : H12AffineEnvironment.transform 4 21 env55730 = env55731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env55730 == env55731) = true)

theorem identity55731 : scanCanonicalize (H12AffineFastState.compose env55731 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound55731 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env55732 : List Nat := [2,4,8,10,15,64,9,10,512,75,2048,2113,7,2048,74,12,2059,2122,75,75,2048,15,10,3,6,64,2048,2058,2113,2049,14,15,10,15,2123,513]

theorem envBound55732 : H12AffineFastState.Bounded env55732 := by
  intro p hp
  have h : env55732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55731_55732 : H12AffineEnvironment.transform 3 10 env55731 = env55732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env55731 == env55732) = true)

theorem identity55732 : scanCanonicalize (H12AffineFastState.compose env55732 (packedSelected [0,1,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 9) := by decide +kernel

theorem selectedBound55732 : packedSelected [0,1,3,5] rootPS < 2^1333 := by decide +kernel

def env55733 : List Nat := [2,4,8,10,15,9,9,10,512,2,2048,2056,7,2048,3,12,2059,2051,2,2,2048,15,10,3,6,9,2048,2058,2056,2049,14,15,10,15,2050,513]

theorem envBound55733 : H12AffineFastState.Bounded env55733 := by
  intro p hp
  have h : env55733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55732_55733 : H12AffineEnvironment.transform 5 9 env55732 = env55733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 9 env55732 == env55733) = true)

theorem identity55733 : scanCanonicalize (H12AffineFastState.compose env55733 (packedSelected [0,1,3,8] rootPS)) = affineNative (2^(10+1) ^^^ 11) := by decide +kernel

theorem selectedBound55733 : packedSelected [0,1,3,8] rootPS < 2^1333 := by decide +kernel

def env55734 : List Nat := [2,4,8,10,15,9,9,10,512,2,11,3,7,11,3,12,0,8,2,2,11,15,10,3,6,9,11,1,3,10,14,15,10,15,9,513]

theorem envBound55734 : H12AffineFastState.Bounded env55734 := by
  intro p hp
  have h : env55734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55733_55734 : H12AffineEnvironment.transform 10 11 env55733 = env55734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 11 env55733 == env55734) = true)

theorem identity55734 : scanCanonicalize (H12AffineFastState.compose env55734 (packedSelected [0,3] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55734 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env55735 : List Nat := [2,1,8,10,10,9,9,10,512,2,11,3,2,11,3,9,0,8,2,2,11,10,10,3,3,9,11,1,3,10,11,10,10,10,9,513]

theorem envBound55735 : H12AffineFastState.Bounded env55735 := by
  intro p hp
  have h : env55735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55734_55735 : H12AffineEnvironment.transform 1 1 env55734 = env55735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55734 == env55735) = true)

theorem identity55735 : scanCanonicalize (H12AffineFastState.compose env55735 (packedSelected [11] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55735 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env55736 : List Nat := [2,1,2,0,0,3,3,0,512,2,1,3,2,1,3,3,0,2,2,2,1,0,0,3,3,3,1,1,3,0,1,0,0,0,3,513]

theorem envBound55736 : H12AffineFastState.Bounded env55736 := by
  intro p hp
  have h : env55736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55735_55736 : H12AffineEnvironment.transform 2 2 env55735 = env55736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55735 == env55736) = true)

def env55737 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,32,17,73736,8193,64,439608,79131,102743,431377,41993,98678,256,73770,103430,99158]

theorem envBound55737 : H12AffineFastState.Bounded env55737 := by
  intro p hp
  have h : env55737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55721_55737 : H12AffineEnvironment.transform 22 17 env55721 = env55737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env55721 == env55737) = true)

theorem identity55737 : scanCanonicalize (H12AffineFastState.compose env55737 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound55737 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55738 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,35189,1024,32769,102679,32,17,73736,8193,64,146509,79131,102743,138340,41993,98678,256,73770,103430,99158]

theorem envBound55738 : H12AffineFastState.Bounded env55738 := by
  intro p hp
  have h : env55738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55737_55738 : H12AffineEnvironment.transform 17 35189 env55737 = env55738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env55737 == env55738) = true)

theorem identity55738 : scanCanonicalize (H12AffineFastState.compose env55738 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 37940) := by decide +kernel

theorem selectedBound55738 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55739 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,37940,35189,1024,32769,102679,32,17,73736,8193,64,43129,79131,102743,34896,41993,98678,256,73770,103430,99158]

theorem envBound55739 : H12AffineFastState.Bounded env55739 := by
  intro p hp
  have h : env55739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55738_55739 : H12AffineEnvironment.transform 16 37940 env55738 = env55739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 37940 env55738 == env55739) = true)

theorem identity55739 : scanCanonicalize (H12AffineFastState.compose env55739 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound55739 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55740 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,32768,65536,37940,35189,1024,32769,102679,32,17,65648,121,64,34817,71011,102743,34896,33905,98678,256,65618,103430,99158]

theorem envBound55740 : H12AffineFastState.Bounded env55740 := by
  intro p hp
  have h : env55740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55739_55740 : H12AffineEnvironment.transform 12 120 env55739 = env55740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env55739 == env55740) = true)

theorem identity55740 : scanCanonicalize (H12AffineFastState.compose env55740 (packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55740 : packedSelected [1,3,5,6,8,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env55741 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,32768,263,37940,35189,1024,32769,36880,32,17,375,121,64,34817,5220,36944,34896,33905,32881,256,341,38145,33361]

theorem envBound55741 : H12AffineFastState.Bounded env55741 := by
  intro p hp
  have h : env55741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55740_55741 : H12AffineEnvironment.transform 15 263 env55740 = env55741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55740 == env55741) = true)

theorem identity55741 : scanCanonicalize (H12AffineFastState.compose env55741 (packedSelected [6,11,14,16,20,23] rootPS)) = affineNative (2^(14+1) ^^^ 292) := by decide +kernel

theorem selectedBound55741 : packedSelected [6,11,14,16,20,23] rootPS < 2^1333 := by decide +kernel

def env55742 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5376,292,263,5392,2129,1024,293,4404,32,17,375,121,64,2341,5220,4468,2420,1365,341,256,341,5157,885]

theorem envBound55742 : H12AffineFastState.Bounded env55742 := by
  intro p hp
  have h : env55742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55741_55742 : H12AffineEnvironment.transform 14 292 env55741 = env55742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 292 env55741 == env55742) = true)

theorem identity55742 : scanCanonicalize (H12AffineFastState.compose env55742 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 885) := by decide +kernel

theorem selectedBound55742 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env55743 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,885,120,1653,292,263,1637,2129,1024,293,577,32,17,375,121,64,2341,1809,513,2420,1365,341,256,341,1872,885]

theorem envBound55743 : H12AffineFastState.Bounded env55743 := by
  intro p hp
  have h : env55743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55742_55743 : H12AffineEnvironment.transform 11 885 env55742 = env55743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 885 env55742 == env55743) = true)

def env55744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,8388608,73857,8328,64,8828321,79131,8491334,8819968,8430737,98679,256,8462395,8492190,8487751]

theorem envBound55744 : H12AffineFastState.Bounded env55744 := by
  intro p hp
  have h : env55744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55687_55744 : H12AffineEnvironment.transform 21 33 env55687 = env55744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55687 == env55744) = true)

theorem identity55744 : scanCanonicalize (H12AffineFastState.compose env55744 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 16) := by decide +kernel

theorem selectedBound55744 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,16,73857,8328,64,439729,79131,102742,431376,42113,98679,256,73771,103566,99159]

theorem envBound55745 : H12AffineFastState.Bounded env55745 := by
  intro p hp
  have h : env55745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55744_55745 : H12AffineEnvironment.transform 22 16 env55744 = env55745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55744 == env55745) = true)

def env55746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,16,73737,8192,64,439609,79131,102742,431376,41993,98679,256,73771,103430,99159]

theorem envBound55746 : H12AffineFastState.Bounded env55746 := by
  intro p hp
  have h : env55746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55745_55746 : H12AffineEnvironment.transform 6 8 env55745 = env55746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55745 == env55746) = true)

theorem identity55746 : scanCanonicalize (H12AffineFastState.compose env55746 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound55746 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33110,131072,262144,1024,32769,4161,33,16,41311,8192,64,439609,46157,4096,431376,41993,33,256,41341,5456,513]

theorem envBound55747 : H12AffineFastState.Bounded env55747 := by
  intro p hp
  have h : env55747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55746_55747 : H12AffineEnvironment.transform 15 33110 env55746 = env55747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env55746 == env55747) = true)

theorem identity55747 : scanCanonicalize (H12AffineFastState.compose env55747 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound55747 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env55748 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,342,131072,262144,1024,1,4161,33,16,8543,8192,64,406841,13389,4096,398608,9225,33,256,8573,5456,513]

theorem envBound55748 : H12AffineFastState.Bounded env55748 := by
  intro p hp
  have h : env55748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55747_55748 : H12AffineEnvironment.transform 14 0 env55747 = env55748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env55747 == env55748) = true)

theorem identity55748 : scanCanonicalize (H12AffineFastState.compose env55748 (packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound55748 : packedSelected [0,1,4,7,8,9,12,14,15,19] rootPS < 2^1333 := by decide +kernel

def env55749 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,342,131072,138340,1024,1,4161,33,16,8543,8192,64,10589,13389,4096,2420,9225,33,256,8573,5456,513]

theorem envBound55749 : H12AffineFastState.Bounded env55749 := by
  intro p hp
  have h : env55749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55748_55749 : H12AffineEnvironment.transform 17 138340 env55748 = env55749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env55748 == env55749) = true)

theorem identity55749 : scanCanonicalize (H12AffineFastState.compose env55749 (packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 13389) := by decide +kernel

theorem selectedBound55749 : packedSelected [0,3,4,5,7,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55750 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,0,342,13389,10281,1024,1,4161,33,16,8543,8192,64,10589,13389,4096,2420,9225,33,256,8573,5456,513]

theorem envBound55750 : H12AffineFastState.Bounded env55750 := by
  intro p hp
  have h : env55750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55749_55750 : H12AffineEnvironment.transform 16 13389 env55749 = env55750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13389 env55749 == env55750) = true)

theorem identity55750 : scanCanonicalize (H12AffineFastState.compose env55750 (packedSelected [4,9,11] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55750 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55751 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,349,5376,0,342,5392,2420,1024,1,4161,33,16,2,349,64,2048,5392,4096,2420,1364,33,256,32,5456,513]

theorem envBound55751 : H12AffineFastState.Bounded env55751 := by
  intro p hp
  have h : env55751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55750_55751 : H12AffineEnvironment.transform 12 349 env55750 = env55751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55750 == env55751) = true)

def env55752 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,131072,262144,1024,32769,102679,33,16,73736,8193,64,439608,79131,102742,431376,41992,98679,256,73771,103431,99159]

theorem envBound55752 : H12AffineFastState.Bounded env55752 := by
  intro p hp
  have h : env55752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55745_55752 : H12AffineEnvironment.transform 6 9 env55745 = env55752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55745 == env55752) = true)

theorem identity55752 : scanCanonicalize (H12AffineFastState.compose env55752 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound55752 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55753 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,262144,1024,8540,77898,33,16,73736,8193,64,398437,79131,77835,406605,1365,73770,256,73771,79194,74250]

theorem envBound55753 : H12AffineFastState.Bounded env55753 := by
  intro p hp
  have h : env55753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55752_55753 : H12AffineEnvironment.transform 14 8541 env55752 = env55753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env55752 == env55753) = true)

theorem identity55753 : scanCanonicalize (H12AffineFastState.compose env55753 (packedSelected [18,23] rootPS)) = affineNative (2^(17+1) ^^^ 67619) := by decide +kernel

theorem selectedBound55753 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env55754 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8541,65536,131072,67619,1024,8540,77898,33,16,73736,8193,64,203846,79131,77835,212078,1365,73770,256,73771,79194,74250]

theorem envBound55754 : H12AffineFastState.Bounded env55754 := by
  intro p hp
  have h : env55754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55753_55754 : H12AffineEnvironment.transform 17 67619 env55753 = env55754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67619 env55753 == env55754) = true)

theorem identity55754 : scanCanonicalize (H12AffineFastState.compose env55754 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55754 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env55755 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,65536,131072,67619,1024,80,69958,33,16,65796,269,64,203846,70679,69895,204130,1365,65830,256,65831,70742,66310]

theorem envBound55755 : H12AffineFastState.Bounded env55755 := by
  intro p hp
  have h : env55755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55754_55755 : H12AffineEnvironment.transform 12 268 env55754 = env55755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55754 == env55755) = true)

theorem identity55755 : scanCanonicalize (H12AffineFastState.compose env55755 (packedSelected [0,2,9,10,11,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 67635) := by decide +kernel

theorem selectedBound55755 : packedSelected [0,2,9,10,11,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55756 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,65536,67635,67619,1024,80,69958,33,16,65796,269,64,5237,70679,69895,5457,1365,65830,256,65831,70742,66310]

theorem envBound55756 : H12AffineFastState.Bounded env55756 := by
  intro p hp
  have h : env55756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55755_55756 : H12AffineEnvironment.transform 16 67635 env55755 = env55756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 67635 env55755 == env55756) = true)

theorem identity55756 : scanCanonicalize (H12AffineFastState.compose env55756 (packedSelected [0,2,4,6,10] rootPS)) = affineNative (2^(15+1) ^^^ 7255) := by decide +kernel

theorem selectedBound55756 : packedSelected [0,2,4,6,10] rootPS < 2^1333 := by decide +kernel

def env55757 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,5376,81,7255,5220,5236,1024,80,3345,33,16,7507,269,64,5237,2112,3408,5457,1365,7537,256,7536,2049,8017]

theorem envBound55757 : H12AffineFastState.Bounded env55757 := by
  intro p hp
  have h : env55757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55756_55757 : H12AffineEnvironment.transform 15 7255 env55756 = env55757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 7255 env55756 == env55757) = true)

theorem identity55757 : scanCanonicalize (H12AffineFastState.compose env55757 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound55757 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55758 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,3109,268,2341,81,114,2113,2129,1024,80,3345,33,16,374,269,64,2128,2112,3408,2420,1365,340,256,341,2049,884]

theorem envBound55758 : H12AffineFastState.Bounded env55758 := by
  intro p hp
  have h : env55758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55757_55758 : H12AffineEnvironment.transform 11 3109 env55757 = env55758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env55757 == env55758) = true)

theorem identity55758 : scanCanonicalize (H12AffineFastState.compose env55758 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55758 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env55759 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,3109,268,2341,0,35,2064,2048,1024,1,3345,33,16,295,269,17,2049,2065,3329,2341,1284,261,256,260,2049,805]

theorem envBound55759 : H12AffineFastState.Bounded env55759 := by
  intro p hp
  have h : env55759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55758_55759 : H12AffineEnvironment.transform 5 17 env55758 = env55759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55758 == env55759) = true)

theorem identity55759 : scanCanonicalize (H12AffineFastState.compose env55759 (packedSelected [0,4] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound55759 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55760 : List Nat := [2,4,8,16,32,17,9,256,512,305,2048,2324,268,2341,0,35,2064,2048,305,1,2080,33,16,295,269,17,2049,2065,2096,2341,53,261,256,260,2049,805]

theorem envBound55760 : H12AffineFastState.Bounded env55760 := by
  intro p hp
  have h : env55760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55759_55760 : H12AffineEnvironment.transform 9 305 env55759 = env55760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env55759 == env55760) = true)

theorem identity55760 : scanCanonicalize (H12AffineFastState.compose env55760 (packedSelected [3,5] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55760 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env55761 : List Nat := [2,4,8,16,32,17,9,5,512,52,2048,2065,9,2080,0,35,2064,2048,52,1,2080,33,16,34,8,17,2049,2065,2096,2080,53,0,5,1,2049,544]

theorem envBound55761 : H12AffineFastState.Bounded env55761 := by
  intro p hp
  have h : env55761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55760_55761 : H12AffineEnvironment.transform 7 5 env55760 = env55761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55760 == env55761) = true)

theorem identity55761 : scanCanonicalize (H12AffineFastState.compose env55761 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55761 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55762 : List Nat := [2,4,8,16,0,17,9,5,512,20,2048,2065,9,2048,0,3,2064,2048,20,1,2048,1,16,2,8,17,2049,2065,2064,2048,21,0,5,1,2049,512]

theorem envBound55762 : H12AffineFastState.Bounded env55762 := by
  intro p hp
  have h : env55762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55761_55762 : H12AffineEnvironment.transform 4 0 env55761 = env55762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55761 == env55762) = true)

theorem identity55762 : scanCanonicalize (H12AffineFastState.compose env55762 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55762 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55763 : List Nat := [2,4,8,1,0,0,9,5,512,5,2048,2048,9,2048,0,3,2049,2048,5,1,2048,1,1,2,8,0,2049,2048,2049,2048,4,0,5,1,2049,512]

theorem envBound55763 : H12AffineFastState.Bounded env55763 := by
  intro p hp
  have h : env55763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55762_55763 : H12AffineEnvironment.transform 3 1 env55762 = env55763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55762 == env55763) = true)

theorem identity55763 : scanCanonicalize (H12AffineFastState.compose env55763 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound55763 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55764 : List Nat := [2,4,6,1,0,0,7,5,512,5,2048,2048,7,2048,0,3,2049,2048,5,1,2048,1,1,2,6,0,2049,2048,2049,2048,4,0,5,1,2049,512]

theorem envBound55764 : H12AffineFastState.Bounded env55764 := by
  intro p hp
  have h : env55764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55763_55764 : H12AffineEnvironment.transform 2 6 env55763 = env55764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env55763 == env55764) = true)

theorem identity55764 : scanCanonicalize (H12AffineFastState.compose env55764 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 512) := by decide +kernel

theorem selectedBound55764 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55765 : List Nat := [2,4,6,1,0,0,7,5,512,5,512,512,7,512,0,3,513,512,5,1,512,1,1,2,6,0,513,512,513,512,4,0,5,1,513,512]

theorem envBound55765 : H12AffineFastState.Bounded env55765 := by
  intro p hp
  have h : env55765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55764_55765 : H12AffineEnvironment.transform 10 512 env55764 = env55765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 512 env55764 == env55765) = true)

def env55766 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,4194304,8388608,73856,8328,64,13022592,79131,8491334,8819969,8430736,4292951,256,8462394,8492190,8487750]

theorem envBound55766 : H12AffineFastState.Bounded env55766 := by
  intro p hp
  have h : env55766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55686_55766 : H12AffineEnvironment.transform 13 5377 env55686 = env55766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55686 == env55766) = true)

def env55767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,8388608,73856,8328,64,8828320,79131,8491334,8819969,8430736,98679,256,8462394,8492190,8487750]

theorem envBound55767 : H12AffineFastState.Bounded env55767 := by
  intro p hp
  have h : env55767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55766_55767 : H12AffineEnvironment.transform 21 32 env55766 = env55767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env55766 == env55767) = true)

theorem identity55767 : scanCanonicalize (H12AffineFastState.compose env55767 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55767 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,8388608,73736,8192,64,8828200,79131,8491334,8819969,8430616,98679,256,8462394,8492054,8487750]

theorem envBound55768 : H12AffineFastState.Bounded env55768 := by
  intro p hp
  have h : env55768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55767_55768 : H12AffineEnvironment.transform 6 8 env55767 = env55768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55767 == env55768) = true)

def env55769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,16,73736,8192,64,439608,79131,102742,431377,41992,98679,256,73770,103430,99158]

theorem envBound55769 : H12AffineFastState.Bounded env55769 := by
  intro p hp
  have h : env55769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55768_55769 : H12AffineEnvironment.transform 22 16 env55768 = env55769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env55768 == env55769) = true)

theorem identity55769 : scanCanonicalize (H12AffineFastState.compose env55769 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound55769 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,131072,262144,1024,32769,4161,32,16,41311,8192,64,439608,46156,4097,431377,41992,32,256,41341,5457,513]

theorem envBound55770 : H12AffineFastState.Bounded env55770 := by
  intro p hp
  have h : env55770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55769_55770 : H12AffineEnvironment.transform 15 33111 env55769 = env55770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env55769 == env55770) = true)

theorem identity55770 : scanCanonicalize (H12AffineFastState.compose env55770 (packedSelected [0,14,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 38160) := by decide +kernel

theorem selectedBound55770 : packedSelected [0,14,18,23,27] rootPS < 2^1333 := by decide +kernel

def env55771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,38160,262144,1024,32769,4161,32,16,41311,8192,64,270376,46156,4097,262145,41992,32,256,41341,5457,513]

theorem envBound55771 : H12AffineFastState.Bounded env55771 := by
  intro p hp
  have h : env55771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55770_55771 : H12AffineEnvironment.transform 16 38160 env55770 = env55771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38160 env55770 == env55771) = true)

theorem identity55771 : scanCanonicalize (H12AffineFastState.compose env55771 (packedSelected [2,6,18,23] rootPS)) = affineNative (2^(17+1) ^^^ 43048) := by decide +kernel

theorem selectedBound55771 : packedSelected [2,6,18,23] rootPS < 2^1333 := by decide +kernel

def env55772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,38160,43048,1024,32769,4161,32,16,41311,8192,64,34816,46156,4097,43049,41992,32,256,41341,5457,513]

theorem envBound55772 : H12AffineFastState.Bounded env55772 := by
  intro p hp
  have h : env55772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55771_55772 : H12AffineEnvironment.transform 17 43048 env55771 = env55772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43048 env55771 == env55772) = true)

theorem identity55772 : scanCanonicalize (H12AffineFastState.compose env55772 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55772 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55773 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,13388,2420,1024,8541,4161,32,16,3,8192,64,10588,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound55773 : H12AffineFastState.Bounded env55773 := by
  intro p hp
  have h : env55773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55772_55773 : H12AffineEnvironment.transform 14 8540 env55772 = env55773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55772 == env55773) = true)

theorem identity55773 : scanCanonicalize (H12AffineFastState.compose env55773 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55773 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55774 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5377,80,263,5440,2420,1024,81,4161,32,16,3,268,64,2128,5392,4097,2421,1364,32,256,33,5457,513]

theorem envBound55774 : H12AffineFastState.Bounded env55774 := by
  intro p hp
  have h : env55774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55773_55774 : H12AffineEnvironment.transform 12 268 env55773 = env55774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55773 == env55774) = true)

theorem identity55774 : scanCanonicalize (H12AffineFastState.compose env55774 (packedSelected [1,2,3,5,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1393) := by decide +kernel

theorem selectedBound55774 : packedSelected [1,2,3,5,8,10,11] rootPS < 2^1333 := by decide +kernel

def env55775 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1393,4096,268,5377,80,263,5440,1029,1024,81,4161,32,16,3,268,64,1313,5392,4097,1028,1364,32,256,33,5457,513]

theorem envBound55775 : H12AffineFastState.Bounded env55775 := by
  intro p hp
  have h : env55775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55774_55775 : H12AffineEnvironment.transform 10 1393 env55774 = env55775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1393 env55774 == env55775) = true)

theorem identity55775 : scanCanonicalize (H12AffineFastState.compose env55775 (packedSelected [4,9,10] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55775 : packedSelected [4,9,10] rootPS < 2^1333 := by decide +kernel

def env55776 : List Nat := [2,4,8,16,0,64,8,256,512,1024,1361,4096,268,5377,80,263,5440,1029,1024,81,4161,0,16,3,268,64,1281,5392,4097,1028,1364,0,256,1,5457,513]

theorem envBound55776 : H12AffineFastState.Bounded env55776 := by
  intro p hp
  have h : env55776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55775_55776 : H12AffineEnvironment.transform 4 0 env55775 = env55776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55775 == env55776) = true)

theorem identity55776 : scanCanonicalize (H12AffineFastState.compose env55776 (packedSelected [0,1,4,7,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound55776 : packedSelected [0,1,4,7,8,9] rootPS < 2^1333 := by decide +kernel

def env55777 : List Nat := [2,4,8,16,0,64,8,256,512,69,276,4096,268,4420,80,263,4357,64,69,81,4161,0,16,3,268,64,324,4437,4097,65,273,0,256,1,4372,513]

theorem envBound55777 : H12AffineFastState.Bounded env55777 := by
  intro p hp
  have h : env55777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55776_55777 : H12AffineEnvironment.transform 9 69 env55776 = env55777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env55776 == env55777) = true)

def env55778 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,32,17,73736,8192,64,439609,79131,102743,431376,41993,98679,256,73771,103431,99159]

theorem envBound55778 : H12AffineFastState.Bounded env55778 := by
  intro p hp
  have h : env55778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55768_55778 : H12AffineEnvironment.transform 22 17 env55768 = env55778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env55768 == env55778) = true)

theorem identity55778 : scanCanonicalize (H12AffineFastState.compose env55778 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55778 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,10281,1024,32769,102678,32,17,73736,8192,64,171280,79131,102743,179513,41993,98679,256,73771,103431,99159]

theorem envBound55779 : H12AffineFastState.Bounded env55779 := by
  intro p hp
  have h : env55779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55778_55779 : H12AffineEnvironment.transform 17 10281 env55778 = env55779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55778 == env55779) = true)

theorem identity55779 : scanCanonicalize (H12AffineFastState.compose env55779 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 46156) := by decide +kernel

theorem selectedBound55779 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,46156,10281,1024,32769,102678,32,17,73736,8192,64,10588,79131,102743,2421,41993,98679,256,73771,103431,99159]

theorem envBound55780 : H12AffineFastState.Bounded env55780 := by
  intro p hp
  have h : env55780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55779_55780 : H12AffineEnvironment.transform 16 46156 env55779 = env55780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46156 env55779 == env55780) = true)

theorem identity55780 : scanCanonicalize (H12AffineFastState.compose env55780 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound55780 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,46156,10281,1024,32769,4161,32,17,41311,8192,64,10588,46156,4096,2421,41993,32,256,41340,5456,512]

theorem envBound55781 : H12AffineFastState.Bounded env55781 := by
  intro p hp
  have h : env55781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55780_55781 : H12AffineEnvironment.transform 15 33111 env55780 = env55781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env55780 == env55781) = true)

theorem identity55781 : scanCanonicalize (H12AffineFastState.compose env55781 (packedSelected [4,9,11] rootPS)) = affineNative (2^(11+1) ^^^ 1313) := by decide +kernel

theorem selectedBound55781 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1313,8192,32,32768,33111,41325,10281,1024,32769,1376,32,17,41311,8192,64,10588,41325,1313,2421,41993,32,256,41340,113,512]

theorem envBound55782 : H12AffineFastState.Bounded env55782 := by
  intro p hp
  have h : env55782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55781_55782 : H12AffineEnvironment.transform 11 1313 env55781 = env55782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1313 env55781 == env55782) = true)

theorem identity55782 : scanCanonicalize (H12AffineFastState.compose env55782 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 1305) := by decide +kernel

theorem selectedBound55782 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1313,1305,32,32768,33111,33908,3376,1024,32769,1376,32,17,33862,1305,64,3141,33908,1313,2421,33040,32,256,33893,113,512]

theorem envBound55783 : H12AffineFastState.Bounded env55783 := by
  intro p hp
  have h : env55783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55782_55783 : H12AffineEnvironment.transform 12 1305 env55782 = env55783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1305 env55782 == env55783) = true)

theorem identity55783 : scanCanonicalize (H12AffineFastState.compose env55783 (packedSelected [12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1328) := by decide +kernel

theorem selectedBound55783 : packedSelected [12,15] rootPS < 2^1333 := by decide +kernel

def env55784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,1313,1305,32,1328,1127,324,3376,1024,1329,1376,32,17,374,1305,64,3141,324,1313,2421,1056,32,256,341,113,512]

theorem envBound55784 : H12AffineFastState.Bounded env55784 := by
  intro p hp
  have h : env55784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55783_55784 : H12AffineEnvironment.transform 14 1328 env55783 = env55784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1328 env55783 == env55784) = true)

theorem identity55784 : scanCanonicalize (H12AffineFastState.compose env55784 (packedSelected [4,9,18] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound55784 : packedSelected [4,9,18] rootPS < 2^1333 := by decide +kernel

def env55785 : List Nat := [2,4,8,16,32,64,8,256,512,320,2048,97,89,32,112,295,324,2160,320,113,32,32,17,374,89,64,2309,324,97,2421,352,32,256,341,113,512]

theorem envBound55785 : H12AffineFastState.Bounded env55785 := by
  intro p hp
  have h : env55785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55784_55785 : H12AffineEnvironment.transform 9 320 env55784 = env55785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env55784 == env55785) = true)

theorem identity55785 : scanCanonicalize (H12AffineFastState.compose env55785 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound55785 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55786 : List Nat := [2,4,8,16,32,64,8,5,512,69,2048,97,89,32,112,34,65,2160,69,113,32,32,17,115,89,64,2048,65,97,2160,101,32,5,80,113,512]

theorem envBound55786 : H12AffineFastState.Bounded env55786 := by
  intro p hp
  have h : env55786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55785_55786 : H12AffineEnvironment.transform 7 5 env55785 = env55786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env55785 == env55786) = true)

theorem identity55786 : scanCanonicalize (H12AffineFastState.compose env55786 (packedSelected [0,1,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 112) := by decide +kernel

theorem selectedBound55786 : packedSelected [0,1,3,4] rootPS < 2^1333 := by decide +kernel

def env55787 : List Nat := [2,4,8,16,32,64,8,5,512,69,112,97,89,32,112,34,65,0,69,113,32,32,17,115,89,64,112,65,97,0,101,32,5,80,113,512]

theorem envBound55787 : H12AffineFastState.Bounded env55787 := by
  intro p hp
  have h : env55787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55786_55787 : H12AffineEnvironment.transform 10 112 env55786 = env55787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 112 env55786 == env55787) = true)

theorem identity55787 : scanCanonicalize (H12AffineFastState.compose env55787 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55787 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env55788 : List Nat := [2,4,8,16,32,17,8,5,512,20,33,48,8,32,33,34,16,0,20,32,32,32,17,34,8,17,33,16,48,0,52,32,5,1,32,512]

theorem envBound55788 : H12AffineFastState.Bounded env55788 := by
  intro p hp
  have h : env55788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55787_55788 : H12AffineEnvironment.transform 5 17 env55787 = env55788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55787 == env55788) = true)

theorem identity55788 : scanCanonicalize (H12AffineFastState.compose env55788 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound55788 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env55789 : List Nat := [2,4,8,16,32,17,8,5,1,20,33,48,8,32,33,34,16,0,20,32,32,32,17,34,8,17,33,16,48,0,52,32,5,1,32,1]

theorem envBound55789 : H12AffineFastState.Bounded env55789 := by
  intro p hp
  have h : env55789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55788_55789 : H12AffineEnvironment.transform 8 1 env55788 = env55789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env55788 == env55789) = true)

theorem identity55789 : scanCanonicalize (H12AffineFastState.compose env55789 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound55789 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env55790 : List Nat := [2,4,8,16,0,17,8,5,1,20,1,16,8,0,1,2,16,0,20,0,0,0,17,2,8,17,1,16,16,0,20,0,5,1,0,1]

theorem envBound55790 : H12AffineFastState.Bounded env55790 := by
  intro p hp
  have h : env55790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55789_55790 : H12AffineEnvironment.transform 4 0 env55789 = env55790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env55789 == env55790) = true)

theorem identity55790 : scanCanonicalize (H12AffineFastState.compose env55790 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 7) := by decide +kernel

theorem selectedBound55790 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55791 : List Nat := [2,4,7,16,0,17,7,5,1,20,1,16,7,0,1,2,16,0,20,0,0,0,17,2,7,17,1,16,16,0,20,0,5,1,0,1]

theorem envBound55791 : H12AffineFastState.Bounded env55791 := by
  intro p hp
  have h : env55791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55790_55791 : H12AffineEnvironment.transform 2 7 env55790 = env55791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 7 env55790 == env55791) = true)

def env55792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,8388608,73856,8328,64,8828321,79131,8491334,8819969,8430736,98678,256,8462394,8492190,8487750]

theorem envBound55792 : H12AffineFastState.Bounded env55792 := by
  intro p hp
  have h : env55792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55766_55792 : H12AffineEnvironment.transform 21 33 env55766 = env55792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env55766 == env55792) = true)

theorem identity55792 : scanCanonicalize (H12AffineFastState.compose env55792 (packedSelected [17] rootPS)) = affineNative (2^(22+1) ^^^ 152) := by decide +kernel

theorem selectedBound55792 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,152,73856,8328,64,439609,79131,102878,431513,41992,98678,256,73890,103430,99294]

theorem envBound55793 : H12AffineFastState.Bounded env55793 := by
  intro p hp
  have h : env55793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55792_55793 : H12AffineEnvironment.transform 22 152 env55792 = env55793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 152 env55792 == env55793) = true)

def env55794 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,16,73736,8192,64,439609,79131,102742,431377,41992,98678,256,73770,103430,99158]

theorem envBound55794 : H12AffineFastState.Bounded env55794 := by
  intro p hp
  have h : env55794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55793_55794 : H12AffineEnvironment.transform 6 8 env55793 = env55794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55793 == env55794) = true)

def env55795 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5392,262144,1024,32769,102678,33,16,73736,8192,64,303145,79131,102742,294913,41992,98678,256,73770,103430,99158]

theorem envBound55795 : H12AffineFastState.Bounded env55795 := by
  intro p hp
  have h : env55795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55794_55795 : H12AffineEnvironment.transform 16 5392 env55794 = env55795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env55794 == env55795) = true)

theorem identity55795 : scanCanonicalize (H12AffineFastState.compose env55795 (packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55795 : packedSelected [1,3,5,8,10,11,12,15,18,19,23,32,38,41] rootPS < 2^1333 := by decide +kernel

def env55796 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5392,10281,1024,32769,102678,33,16,73736,8192,64,34816,79131,102742,43048,41992,98678,256,73770,103430,99158]

theorem envBound55796 : H12AffineFastState.Bounded env55796 := by
  intro p hp
  have h : env55796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55795_55796 : H12AffineEnvironment.transform 17 10281 env55795 = env55796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55795 == env55796) = true)

theorem identity55796 : scanCanonicalize (H12AffineFastState.compose env55796 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound55796 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55797 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,5392,10281,1024,32769,4160,33,16,41310,8192,64,34816,46157,4096,43048,41992,32,256,41340,5456,512]

theorem envBound55797 : H12AffineFastState.Bounded env55797 := by
  intro p hp
  have h : env55797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55796_55797 : H12AffineEnvironment.transform 15 33110 env55796 = env55797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env55796 == env55797) = true)

theorem identity55797 : scanCanonicalize (H12AffineFastState.compose env55797 (packedSelected [4,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 13356) := by decide +kernel

theorem selectedBound55797 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env55798 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,13356,13690,5392,10281,1024,13357,4160,33,16,5490,8192,64,15404,97,4096,7172,4132,32,256,5456,5456,512]

theorem envBound55798 : H12AffineFastState.Bounded env55798 := by
  intro p hp
  have h : env55798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55797_55798 : H12AffineEnvironment.transform 14 13356 env55797 = env55798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 13356 env55797 == env55798) = true)

theorem identity55798 : scanCanonicalize (H12AffineFastState.compose env55798 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(11+1) ^^^ 3156) := by decide +kernel

theorem selectedBound55798 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55799 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3156,8192,2389,10360,10542,2372,10281,1024,10361,3092,33,16,2342,8192,64,8312,97,3156,80,3184,32,256,2308,2308,512]

theorem envBound55799 : H12AffineFastState.Bounded env55799 := by
  intro p hp
  have h : env55799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55798_55799 : H12AffineEnvironment.transform 11 3156 env55798 = env55799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3156 env55798 == env55799) = true)

theorem identity55799 : scanCanonicalize (H12AffineFastState.compose env55799 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(10+1) ^^^ 1377) := by decide +kernel

theorem selectedBound55799 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55800 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1377,309,8192,1076,9497,9295,1061,9544,1024,9496,373,33,16,1095,8192,64,8312,97,309,80,273,32,256,1125,1125,512]

theorem envBound55800 : H12AffineFastState.Bounded env55800 := by
  intro p hp
  have h : env55800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55799_55800 : H12AffineEnvironment.transform 10 1377 env55799 = env55800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1377 env55799 == env55800) = true)

theorem identity55800 : scanCanonicalize (H12AffineFastState.compose env55800 (packedSelected [1,3,5,8,15] rootPS)) = affineNative (2^(12+1) ^^^ 1085) := by decide +kernel

theorem selectedBound55800 : packedSelected [1,3,5,8,15] rootPS < 2^1333 := by decide +kernel

def env55801 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1377,309,1085,1076,292,114,1061,373,1024,293,373,33,16,1095,1085,64,1093,97,309,80,273,32,256,1125,1125,512]

theorem envBound55801 : H12AffineFastState.Bounded env55801 := by
  intro p hp
  have h : env55801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55800_55801 : H12AffineEnvironment.transform 12 1085 env55800 = env55801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1085 env55800 == env55801) = true)

theorem identity55801 : scanCanonicalize (H12AffineFastState.compose env55801 (packedSelected [0,7,16] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55801 : packedSelected [0,7,16] rootPS < 2^1333 := by decide +kernel

def env55802 : List Nat := [2,4,8,16,32,64,8,116,512,1024,1045,65,1085,1076,80,114,1061,1,1024,81,1,33,16,1095,1085,64,1093,97,65,80,101,32,116,1125,1125,512]

theorem envBound55802 : H12AffineFastState.Bounded env55802 := by
  intro p hp
  have h : env55802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55801_55802 : H12AffineEnvironment.transform 7 116 env55801 = env55802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55801 == env55802) = true)

theorem identity55802 : scanCanonicalize (H12AffineFastState.compose env55802 (packedSelected [2,6] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound55802 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55803 : List Nat := [2,4,8,16,1,64,8,85,512,1024,1045,65,1052,1045,80,83,1028,1,1024,81,1,0,16,1095,1052,64,1093,64,65,80,68,1,85,1092,1092,512]

theorem envBound55803 : H12AffineFastState.Bounded env55803 := by
  intro p hp
  have h : env55803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55802_55803 : H12AffineEnvironment.transform 4 1 env55802 = env55803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env55802 == env55803) = true)

theorem identity55803 : scanCanonicalize (H12AffineFastState.compose env55803 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55803 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55804 : List Nat := [2,4,8,16,1,17,8,4,512,1024,1045,16,1052,1045,1,2,1028,1,1024,0,1,0,16,1046,1052,17,1044,17,16,1,21,1,4,1045,1045,512]

theorem envBound55804 : H12AffineFastState.Bounded env55804 := by
  intro p hp
  have h : env55804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55803_55804 : H12AffineEnvironment.transform 5 17 env55803 = env55804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55803 == env55804) = true)

theorem identity55804 : scanCanonicalize (H12AffineFastState.compose env55804 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound55804 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55805 : List Nat := [2,4,8,16,1,17,8,4,512,21,0,16,9,0,1,2,17,1,21,0,1,0,16,3,9,17,1,17,16,1,21,1,4,0,0,512]

theorem envBound55805 : H12AffineFastState.Bounded env55805 := by
  intro p hp
  have h : env55805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55804_55805 : H12AffineEnvironment.transform 9 21 env55804 = env55805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55804 == env55805) = true)

theorem identity55805 : scanCanonicalize (H12AffineFastState.compose env55805 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55805 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55806 : List Nat := [2,4,8,1,1,0,8,4,512,4,0,1,9,0,1,2,0,1,4,0,1,0,1,3,9,0,1,0,1,1,4,1,4,0,0,512]

theorem envBound55806 : H12AffineFastState.Bounded env55806 := by
  intro p hp
  have h : env55806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55805_55806 : H12AffineEnvironment.transform 3 1 env55805 = env55806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55805 == env55806) = true)

theorem identity55806 : scanCanonicalize (H12AffineFastState.compose env55806 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 14) := by decide +kernel

theorem selectedBound55806 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55807 : List Nat := [2,4,8,1,1,0,8,4,14,4,0,1,9,0,1,2,0,1,4,0,1,0,1,3,9,0,1,0,1,1,4,1,4,0,0,14]

theorem envBound55807 : H12AffineFastState.Bounded env55807 := by
  intro p hp
  have h : env55807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55806_55807 : H12AffineEnvironment.transform 8 14 env55806 = env55807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 14 env55806 == env55807) = true)

def env55808 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,65536,5393,262144,1024,32769,102678,33,16,73736,8192,64,303144,79131,102742,294912,41992,98678,256,73770,103430,99158]

theorem envBound55808 : H12AffineFastState.Bounded env55808 := by
  intro p hp
  have h : env55808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55794_55808 : H12AffineEnvironment.transform 16 5393 env55794 = env55808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env55794 == env55808) = true)

theorem identity55808 : scanCanonicalize (H12AffineFastState.compose env55808 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 33111) := by decide +kernel

theorem selectedBound55808 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env55809 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33111,5393,262144,1024,32769,4161,33,16,41311,8192,64,303144,46156,4097,294912,41992,33,256,41341,5457,513]

theorem envBound55809 : H12AffineFastState.Bounded env55809 := by
  intro p hp
  have h : env55809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55808_55809 : H12AffineEnvironment.transform 15 33111 env55808 = env55809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33111 env55808 == env55809) = true)

theorem identity55809 : scanCanonicalize (H12AffineFastState.compose env55809 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55809 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env55810 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8540,8203,5393,262144,1024,8541,4161,33,16,3,8192,64,262516,5392,4097,270684,1364,33,256,33,5457,513]

theorem envBound55810 : H12AffineFastState.Bounded env55810 := by
  intro p hp
  have h : env55810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55809_55810 : H12AffineEnvironment.transform 14 8540 env55809 = env55810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55809 == env55810) = true)

theorem identity55810 : scanCanonicalize (H12AffineFastState.compose env55810 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55810 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55811 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,262,5393,262144,1024,80,4161,33,16,3,269,64,262516,5392,4097,262225,1364,33,256,33,5457,513]

theorem envBound55811 : H12AffineFastState.Bounded env55811 := by
  intro p hp
  have h : env55811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55810_55811 : H12AffineEnvironment.transform 12 269 env55810 = env55811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55810 == env55811) = true)

theorem identity55811 : scanCanonicalize (H12AffineFastState.compose env55811 (packedSelected [0,4,5,7,8,9,12] rootPS)) = affineNative (2^(17+1) ^^^ 6453) := by decide +kernel

theorem selectedBound55811 : packedSelected [0,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env55812 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,81,262,5393,6453,1024,80,4161,33,16,3,269,64,6209,5392,4097,6500,1364,33,256,33,5457,513]

theorem envBound55812 : H12AffineFastState.Bounded env55812 := by
  intro p hp
  have h : env55812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55811_55812 : H12AffineEnvironment.transform 17 6453 env55811 = env55812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6453 env55811 == env55812) = true)

theorem identity55812 : scanCanonicalize (H12AffineFastState.compose env55812 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound55812 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env55813 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,65,269,1344,81,262,1360,2420,1024,80,0,33,16,3,269,64,2048,1361,64,2341,1364,33,256,33,1296,513]

theorem envBound55813 : H12AffineFastState.Bounded env55813 := by
  intro p hp
  have h : env55813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55812_55813 : H12AffineEnvironment.transform 11 65 env55812 = env55813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env55812 == env55813) = true)

theorem identity55813 : scanCanonicalize (H12AffineFastState.compose env55813 (packedSelected [1,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound55813 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env55814 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,65,269,293,81,262,309,2420,101,80,0,33,16,3,269,64,2048,308,64,2341,305,33,256,33,373,513]

theorem envBound55814 : H12AffineFastState.Bounded env55814 := by
  intro p hp
  have h : env55814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55813_55814 : H12AffineEnvironment.transform 9 101 env55813 = env55814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env55813 == env55814) = true)

def env55815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,262144,1024,32769,102678,33,17,73737,8193,64,439609,79131,102743,431376,41992,98678,256,73771,103430,99159]

theorem envBound55815 : H12AffineFastState.Bounded env55815 := by
  intro p hp
  have h : env55815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55793_55815 : H12AffineEnvironment.transform 6 9 env55793 = env55815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55793 == env55815) = true)

theorem identity55815 : scanCanonicalize (H12AffineFastState.compose env55815 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound55815 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,131072,35189,1024,32769,102678,33,17,73737,8193,64,146508,79131,102743,138341,41992,98678,256,73771,103430,99159]

theorem envBound55816 : H12AffineFastState.Bounded env55816 := by
  intro p hp
  have h : env55816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55815_55816 : H12AffineEnvironment.transform 17 35189 env55815 = env55816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env55815 == env55816) = true)

theorem identity55816 : scanCanonicalize (H12AffineFastState.compose env55816 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 13341) := by decide +kernel

theorem selectedBound55816 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55817 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,13341,35189,1024,32769,102678,33,17,73737,8193,64,2129,79131,102743,10360,41992,98678,256,73771,103430,99159]

theorem envBound55817 : H12AffineFastState.Bounded env55817 := by
  intro p hp
  have h : env55817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55816_55817 : H12AffineEnvironment.transform 16 13341 env55816 = env55817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13341 env55816 == env55817) = true)

theorem identity55817 : scanCanonicalize (H12AffineFastState.compose env55817 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound55817 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55818 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,65536,13341,2340,1024,80,69959,33,17,73737,8193,64,2129,79131,69894,10360,9305,65831,256,73771,70743,66310]

theorem envBound55818 : H12AffineFastState.Bounded env55818 := by
  intro p hp
  have h : env55818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55817_55818 : H12AffineEnvironment.transform 14 81 env55817 = env55818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env55817 == env55818) = true)

theorem identity55818 : scanCanonicalize (H12AffineFastState.compose env55818 (packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound55818 : packedSelected [0,1,3,4,5,7,8,10,16,19,20,22] rootPS < 2^1333 := by decide +kernel

def env55819 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,263,13341,2340,1024,80,4160,33,17,8462,8193,64,2129,13340,4097,10360,9305,32,256,8492,5456,513]

theorem envBound55819 : H12AffineFastState.Bounded env55819 := by
  intro p hp
  have h : env55819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55818_55819 : H12AffineEnvironment.transform 15 263 env55818 = env55819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env55818 == env55819) = true)

theorem identity55819 : scanCanonicalize (H12AffineFastState.compose env55819 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound55819 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55820 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5377,81,263,5440,2340,1024,80,4160,33,17,83,348,64,2129,5441,4097,2341,1284,32,256,113,5456,513]

theorem envBound55820 : H12AffineFastState.Bounded env55820 := by
  intro p hp
  have h : env55820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55819_55820 : H12AffineEnvironment.transform 12 349 env55819 = env55820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env55819 == env55820) = true)

theorem identity55820 : scanCanonicalize (H12AffineFastState.compose env55820 (packedSelected [0,1,2,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound55820 : packedSelected [0,1,2,7,8,10] rootPS < 2^1333 := by decide +kernel

def env55821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,349,3345,81,263,3408,2340,1024,80,2128,33,17,83,348,64,2129,3409,2065,2341,1284,32,256,113,3392,513]

theorem envBound55821 : H12AffineFastState.Bounded env55821 := by
  intro p hp
  have h : env55821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55820_55821 : H12AffineEnvironment.transform 11 2064 env55820 = env55821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env55820 == env55821) = true)

theorem identity55821 : scanCanonicalize (H12AffineFastState.compose env55821 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound55821 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55822 : List Nat := [2,4,8,16,32,64,9,256,512,272,2048,2064,349,2049,81,263,2112,2340,272,80,2128,33,17,83,348,64,2129,2113,2065,2341,20,32,256,113,2128,513]

theorem envBound55822 : H12AffineFastState.Bounded env55822 := by
  intro p hp
  have h : env55822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55821_55822 : H12AffineEnvironment.transform 9 272 env55821 = env55822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env55821 == env55822) = true)

def env55823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973836,10507601,8830977,25265168,23160256,257,27378860,27337992,25207751]

theorem envBound55823 : H12AffineFastState.Bounded env55823 := by
  intro p hp
  have h : env55823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55597_55823 : H12AffineEnvironment.transform 18 1025 env55597 = env55823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env55597 == env55823) = true)

theorem identity55823 : scanCanonicalize (H12AffineFastState.compose env55823 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10626199) := by decide +kernel

theorem selectedBound55823 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env55824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10626199,8328,64,6677655,8626203,10507601,8830977,2334855,12796247,257,254011,197023,2262864]

theorem envBound55824 : H12AffineFastState.Bounded env55824 := by
  intro p hp
  have h : env55824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55823_55824 : H12AffineEnvironment.transform 23 10626199 env55823 = env55824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10626199 env55823 == env55824) = true)

def env55825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156116,2114883,8328,64,6677655,115151,2241669,303573,2334855,4268163,257,254011,197023,2262864]

theorem envBound55825 : H12AffineFastState.Bounded env55825 := by
  intro p hp
  have h : env55825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55824_55825 : H12AffineEnvironment.transform 22 156116 env55824 = env55825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156116 env55824 == env55825) = true)

def env55826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156116,2114883,8328,64,215367,115151,2241669,303573,2334855,2592083,257,254011,197023,2262864]

theorem envBound55826 : H12AffineFastState.Bounded env55826 := by
  intro p hp
  have h : env55826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55825_55826 : H12AffineEnvironment.transform 21 2534864 env55825 = env55826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env55825 == env55826) = true)

def env55827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156116,21763,8328,64,215367,115151,140485,303573,241863,498963,257,254011,197023,169744]

theorem envBound55827 : H12AffineFastState.Bounded env55827 := by
  intro p hp
  have h : env55827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55826_55827 : H12AffineEnvironment.transform 20 4160 env55826 = env55827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55826 == env55827) = true)

theorem identity55827 : scanCanonicalize (H12AffineFastState.compose env55827 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 82382) := by decide +kernel

theorem selectedBound55827 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,82382,262144,1025,32769,4160,392286,73754,21763,8328,64,2185,115151,91403,303573,61705,318685,257,41461,16465,120542]

theorem envBound55828 : H12AffineFastState.Bounded env55828 := by
  intro p hp
  have h : env55828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55827_55828 : H12AffineEnvironment.transform 16 82382 env55827 = env55828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82382 env55827 == env55828) = true)

def env55829 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,262144,1025,32769,4112,392206,73754,21763,8328,16,2185,115103,91403,303493,61705,318605,257,41381,16385,120462]

theorem envBound55829 : H12AffineFastState.Bounded env55829 := by
  intro p hp
  have h : env55829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55828_55829 : H12AffineEnvironment.transform 5 16 env55828 = env55829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55828 == env55829) = true)

theorem identity55829 : scanCanonicalize (H12AffineFastState.compose env55829 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(17+1) ^^^ 76079) := by decide +kernel

theorem selectedBound55829 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env55830 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,82334,76079,1025,32769,4112,54561,73754,21763,8328,16,2185,115103,91403,100522,61705,128418,257,41381,16385,120462]

theorem envBound55830 : H12AffineFastState.Bounded env55830 := by
  intro p hp
  have h : env55830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55829_55830 : H12AffineEnvironment.transform 17 76079 env55829 = env55830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 76079 env55829 == env55830) = true)

theorem identity55830 : scanCanonicalize (H12AffineFastState.compose env55830 (packedSelected [0,4,7,11,17,19,22,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 33166) := by decide +kernel

theorem selectedBound55830 : packedSelected [0,4,7,11,17,19,22,26,32] rootPS < 2^1333 := by decide +kernel

def env55831 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,33166,49168,43169,1025,32769,4112,54561,41364,21763,8328,16,2185,16401,58501,2340,61705,29740,257,41381,16385,22272]

theorem envBound55831 : H12AffineFastState.Bounded env55831 := by
  intro p hp
  have h : env55831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55830_55831 : H12AffineEnvironment.transform 15 33166 env55830 = env55831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33166 env55830 == env55831) = true)

theorem identity55831 : scanCanonicalize (H12AffineFastState.compose env55831 (packedSelected [16,18,19,20,23,26] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound55831 : packedSelected [16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env55832 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,21760,21646,5392,32161,1025,21761,4112,33,29844,21763,8328,16,2185,16401,12677,2340,9225,29740,257,29861,16385,22272]

theorem envBound55832 : H12AffineFastState.Bounded env55832 := by
  intro p hp
  have h : env55832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55831_55832 : H12AffineEnvironment.transform 14 21760 env55831 = env55832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env55831 == env55832) = true)

theorem identity55832 : scanCanonicalize (H12AffineFastState.compose env55832 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound55832 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env55833 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,5377,1,399,5392,10400,1025,0,4112,33,8597,2,8328,16,2185,5392,12677,2340,9225,8493,257,8612,5376,513]

theorem envBound55833 : H12AffineFastState.Bounded env55833 := by
  intro p hp
  have h : env55833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55832_55833 : H12AffineEnvironment.transform 13 5377 env55832 = env55833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env55832 == env55833) = true)

theorem identity55833 : scanCanonicalize (H12AffineFastState.compose env55833 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55833 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env55834 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5377,1,399,5392,2477,1025,0,4112,33,152,2,389,16,2185,5392,4232,2340,1284,32,257,169,5376,513]

theorem envBound55834 : H12AffineFastState.Bounded env55834 := by
  intro p hp
  have h : env55834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55833_55834 : H12AffineEnvironment.transform 12 269 env55833 = env55834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55833 == env55834) = true)

theorem identity55834 : scanCanonicalize (H12AffineFastState.compose env55834 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55834 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55835 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,1,263,5392,2341,1025,0,4112,33,16,2,269,16,2049,5392,4096,2340,1284,32,257,33,5376,513]

theorem envBound55835 : H12AffineFastState.Bounded env55835 := by
  intro p hp
  have h : env55835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55834_55835 : H12AffineEnvironment.transform 6 8 env55834 = env55835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55834 == env55835) = true)

theorem identity55835 : scanCanonicalize (H12AffineFastState.compose env55835 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound55835 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55836 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,4096,269,4112,1,263,4097,2341,272,0,4112,33,16,2,269,16,2049,4097,4096,2340,21,32,257,33,4113,513]

theorem envBound55836 : H12AffineFastState.Bounded env55836 := by
  intro p hp
  have h : env55836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55835_55836 : H12AffineEnvironment.transform 9 273 env55835 = env55836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env55835 == env55836) = true)

theorem identity55836 : scanCanonicalize (H12AffineFastState.compose env55836 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound55836 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env55837 : List Nat := [2,4,8,16,32,16,8,256,512,273,2048,2065,269,2049,1,263,2064,2341,272,0,2049,33,16,2,269,16,2049,2064,2065,2340,21,32,257,33,2048,513]

theorem envBound55837 : H12AffineFastState.Bounded env55837 := by
  intro p hp
  have h : env55837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55836_55837 : H12AffineEnvironment.transform 11 2065 env55836 = env55837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env55836 == env55837) = true)

theorem identity55837 : scanCanonicalize (H12AffineFastState.compose env55837 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55837 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55838 : List Nat := [2,4,8,16,32,16,8,36,512,53,2048,2065,41,2049,1,35,2064,2049,52,0,2049,33,16,2,41,16,2049,2064,2065,2048,21,32,37,33,2048,513]

theorem envBound55838 : H12AffineFastState.Bounded env55838 := by
  intro p hp
  have h : env55838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55837_55838 : H12AffineEnvironment.transform 7 36 env55837 = env55838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55837 == env55838) = true)

theorem identity55838 : scanCanonicalize (H12AffineFastState.compose env55838 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound55838 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55839 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,41,49,1,35,32,49,52,0,49,33,16,2,41,16,49,32,33,48,21,32,37,33,48,513]

theorem envBound55839 : H12AffineFastState.Bounded env55839 := by
  intro p hp
  have h : env55839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55838_55839 : H12AffineEnvironment.transform 10 48 env55838 = env55839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env55838 == env55839) = true)

def leafEnv55839 : List Nat := [2,4,8,16,32,16,8,36,512,53,48,33,41,49,1,35,32,49,52,0,49,33,16,2,20,41,1,16,49,32,33,48,21,32,37,33,5,35,48,513,1,48,0]

def active55839 : List Nat := [0,1,2,3,4,8]

def tree55839 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55839 : H12WitnessSearch.Good tree55839 := H12GlobalWitnessIndex.good

theorem leafIdentity55839 : H12AffineFastState.composeSystem env55839 rootObs = leafEnv55839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55839 rootObs == leafEnv55839) = true)

theorem terminalChecked55839 : H12PackedTerminal.terminalCheckFast leafEnv55839 active55839 tree55839 = true := by decide +kernel

def env55840 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,82335,262144,1025,32769,4113,392207,73754,21763,8328,17,2185,115102,91403,303492,61705,318604,257,41380,16384,120463]

theorem envBound55840 : H12AffineFastState.Bounded env55840 := by
  intro p hp
  have h : env55840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55828_55840 : H12AffineEnvironment.transform 5 17 env55828 = env55840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55828 == env55840) = true)

theorem identity55840 : scanCanonicalize (H12AffineFastState.compose env55840 (packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound55840 : packedSelected [1,3,4,5,7,8,9,11,15,16,19,20,27,31,32,38] rootPS < 2^1333 := by decide +kernel

def env55841 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,40970,57749,262144,1025,32769,4113,285701,32784,21763,8328,17,2185,24980,50433,303492,61705,318604,257,41380,16384,30341]

theorem envBound55841 : H12AffineFastState.Bounded env55841 := by
  intro p hp
  have h : env55841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55840_55841 : H12AffineEnvironment.transform 15 40970 env55840 = env55841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env55840 == env55841) = true)

theorem identity55841 : scanCanonicalize (H12AffineFastState.compose env55841 (packedSelected [0,3,9,19,22,24,27,31] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound55841 : packedSelected [0,3,9,19,22,24,27,31] rootPS < 2^1333 := by decide +kernel

def env55842 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,40970,46108,262144,1025,32769,4113,264588,32784,138,8328,17,2185,13341,37000,303492,42112,297221,257,41380,5513,8972]

theorem envBound55842 : H12AffineFastState.Bounded env55842 := by
  intro p hp
  have h : env55842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55841_55842 : H12AffineEnvironment.transform 13 5513 env55841 = env55842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env55841 == env55842) = true)

theorem identity55842 : scanCanonicalize (H12AffineFastState.compose env55842 (packedSelected [3,10,16,19,20,24] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound55842 : packedSelected [3,10,16,19,20,24] rootPS < 2^1333 := by decide +kernel

def env55843 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,32768,40970,46108,10281,1025,32769,4113,8613,32784,138,8328,17,2185,13341,37000,35245,42112,41260,257,41380,5513,8972]

theorem envBound55843 : H12AffineFastState.Bounded env55843 := by
  intro p hp
  have h : env55843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55842_55843 : H12AffineEnvironment.transform 17 10281 env55842 = env55843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55842 == env55843) = true)

theorem identity55843 : scanCanonicalize (H12AffineFastState.compose env55843 (packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS)) = affineNative (2^(14+1) ^^^ 137) := by decide +kernel

theorem selectedBound55843 : packedSelected [0,1,2,3,5,6,7,8,10,11,16,18,19] rootPS < 2^1333 := by decide +kernel

def env55844 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,5513,137,8323,13461,10281,1025,136,4113,8613,153,138,8328,17,2185,13341,4097,2340,9225,8613,257,8493,5513,8972]

theorem envBound55844 : H12AffineFastState.Bounded env55844 := by
  intro p hp
  have h : env55844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55843_55844 : H12AffineEnvironment.transform 14 137 env55843 = env55844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 137 env55843 == env55844) = true)

theorem identity55844 : scanCanonicalize (H12AffineFastState.compose env55844 (packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55844 : packedSelected [0,2,3,5,6,7,10,11,16,18] rootPS < 2^1333 := by decide +kernel

def env55845 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5513,137,398,5528,2340,1025,136,4113,168,153,138,389,17,2185,5392,4097,2340,1284,168,257,32,5513,513]

theorem envBound55845 : H12AffineFastState.Bounded env55845 := by
  intro p hp
  have h : env55845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55844_55845 : H12AffineEnvironment.transform 12 269 env55844 = env55845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55844 == env55845) = true)

theorem identity55845 : scanCanonicalize (H12AffineFastState.compose env55845 (packedSelected [0,2,3,5,7,11,12,14] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55845 : packedSelected [0,2,3,5,7,11,12,14] rootPS < 2^1333 := by decide +kernel

def env55846 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5376,0,263,5393,2340,1025,1,4113,33,16,3,268,17,2048,5392,4097,2340,1284,33,257,32,5376,513]

theorem envBound55846 : H12AffineFastState.Bounded env55846 := by
  intro p hp
  have h : env55846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55845_55846 : H12AffineEnvironment.transform 6 9 env55845 = env55846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55845 == env55846) = true)

theorem identity55846 : scanCanonicalize (H12AffineFastState.compose env55846 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound55846 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55847 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,4096,40,5157,0,34,5172,2049,1025,1,4113,33,16,3,41,17,2048,5173,4097,2049,1057,33,36,32,5157,513]

theorem envBound55847 : H12AffineFastState.Bounded env55847 := by
  intro p hp
  have h : env55847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55846_55847 : H12AffineEnvironment.transform 7 37 env55846 = env55847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env55846 == env55847) = true)

def env55848 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,48,40,1045,0,34,1028,2049,1025,1,33,33,16,3,41,17,2048,1029,49,2049,1057,33,36,32,1045,513]

theorem envBound55848 : H12AffineFastState.Bounded env55848 := by
  intro p hp
  have h : env55848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55847_55848 : H12AffineEnvironment.transform 11 48 env55847 = env55848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55847 == env55848) = true)

def env55849 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,48,40,33,0,34,48,2049,53,1,33,33,16,3,41,17,2048,49,49,2049,21,33,36,32,33,513]

theorem envBound55849 : H12AffineFastState.Bounded env55849 := by
  intro p hp
  have h : env55849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55848_55849 : H12AffineEnvironment.transform 9 52 env55848 = env55849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55848 == env55849) = true)

theorem identity55849 : scanCanonicalize (H12AffineFastState.compose env55849 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55849 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55850 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,48,40,33,0,34,48,2049,53,1,33,33,16,3,41,17,2048,49,49,2049,21,33,36,32,33,43]

theorem envBound55850 : H12AffineFastState.Bounded env55850 := by
  intro p hp
  have h : env55850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55849_55850 : H12AffineEnvironment.transform 8 42 env55849 = env55850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55849 == env55850) = true)

def leafEnv55850 : List Nat := [2,4,8,16,32,17,9,37,42,52,2048,48,40,33,0,34,48,2049,53,1,33,33,16,3,20,41,1,17,2048,49,49,2049,21,33,36,32,5,35,33,43,1,33,0]

def active55850 : List Nat := [0,1,2,3,4,10]

def tree55850 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55850 : H12WitnessSearch.Good tree55850 := H12GlobalWitnessIndex.good

theorem leafIdentity55850 : H12AffineFastState.composeSystem env55850 rootObs = leafEnv55850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55850 rootObs == leafEnv55850) = true)

theorem terminalChecked55850 : H12PackedTerminal.terminalCheckFast leafEnv55850 active55850 tree55850 = true := by decide +kernel

def env55851 : List Nat := [2,4,8,16,32,17,9,37,512,53,2048,48,40,32,0,34,49,2049,52,1,33,33,16,3,41,17,2048,48,49,2049,20,33,36,32,32,513]

theorem envBound55851 : H12AffineFastState.Bounded env55851 := by
  intro p hp
  have h : env55851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55848_55851 : H12AffineEnvironment.transform 9 53 env55848 = env55851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55848 == env55851) = true)

def env55852 : List Nat := [2,4,8,16,32,17,9,37,512,1024,2048,49,40,1044,0,34,1029,2049,1025,1,32,33,16,3,41,17,2048,1028,48,2049,1057,33,36,32,1044,513]

theorem envBound55852 : H12AffineFastState.Bounded env55852 := by
  intro p hp
  have h : env55852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55847_55852 : H12AffineEnvironment.transform 11 49 env55847 = env55852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55847 == env55852) = true)

theorem identity55852 : scanCanonicalize (H12AffineFastState.compose env55852 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound55852 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55853 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,49,40,32,0,34,49,2049,53,1,32,33,16,3,41,17,2048,48,48,2049,21,33,36,32,32,513]

theorem envBound55853 : H12AffineFastState.Bounded env55853 := by
  intro p hp
  have h : env55853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55852_55853 : H12AffineEnvironment.transform 9 52 env55852 = env55853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55852 == env55853) = true)

theorem identity55853 : scanCanonicalize (H12AffineFastState.compose env55853 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55853 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55854 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,49,40,32,0,34,49,2049,53,1,32,33,16,3,41,17,2048,48,48,2049,21,33,36,32,32,42]

theorem envBound55854 : H12AffineFastState.Bounded env55854 := by
  intro p hp
  have h : env55854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55853_55854 : H12AffineEnvironment.transform 8 43 env55853 = env55854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55853 == env55854) = true)

def leafEnv55854 : List Nat := [2,4,8,16,32,17,9,37,43,52,2048,49,40,32,0,34,49,2049,53,1,32,33,16,3,20,41,1,17,2048,48,48,2049,21,33,36,32,5,35,32,42,1,32,0]

def active55854 : List Nat := [0,1,2,3,4,10]

def tree55854 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55854 : H12WitnessSearch.Good tree55854 := H12GlobalWitnessIndex.good

theorem leafIdentity55854 : H12AffineFastState.composeSystem env55854 rootObs = leafEnv55854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55854 rootObs == leafEnv55854) = true)

theorem terminalChecked55854 : H12PackedTerminal.terminalCheckFast leafEnv55854 active55854 tree55854 = true := by decide +kernel

def env55855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441745,156116,21762,8328,64,215367,115151,140484,303573,241862,498962,257,254011,197023,169745]

theorem envBound55855 : H12AffineFastState.Bounded env55855 := by
  intro p hp
  have h : env55855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55826_55855 : H12AffineEnvironment.transform 20 4161 env55826 = env55855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55826 == env55855) = true)

theorem identity55855 : scanCanonicalize (H12AffineFastState.compose env55855 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound55855 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,441745,156116,21762,8328,64,171417,5393,140484,303573,156696,412108,257,144613,185665,169745]

theorem envBound55856 : H12AffineFastState.Bounded env55856 := by
  intro p hp
  have h : env55856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55855_55856 : H12AffineEnvironment.transform 15 54494 env55855 = env55856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env55855 == env55856) = true)

def env55857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10280,1025,32769,4161,169401,156116,21762,8328,64,171417,5393,140484,35325,156696,156132,257,144613,185665,169745]

theorem envBound55857 : H12AffineFastState.Bounded env55857 := by
  intro p hp
  have h : env55857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55856_55857 : H12AffineEnvironment.transform 17 10280 env55856 = env55857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55856 == env55857) = true)

theorem identity55857 : scanCanonicalize (H12AffineFastState.compose env55857 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 45216) := by decide +kernel

theorem selectedBound55857 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env55858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,45216,10280,1025,32769,4161,9497,53620,21762,8328,64,11577,5393,37988,35325,54456,53572,257,33861,26081,10161]

theorem envBound55858 : H12AffineFastState.Bounded env55858 := by
  intro p hp
  have h : env55858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55857_55858 : H12AffineEnvironment.transform 16 45216 env55857 = env55858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 45216 env55857 == env55858) = true)

theorem identity55858 : scanCanonicalize (H12AffineFastState.compose env55858 (packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound55858 : packedSelected [3,5,8,15,16,17,19,20,26,28,38] rootPS < 2^1333 := by decide +kernel

def env55859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8460,30162,4524,10280,1025,8461,4161,9497,28792,21762,8328,64,11577,5393,13672,10481,30132,28744,257,9545,26081,10161]

theorem envBound55859 : H12AffineFastState.Bounded env55859 := by
  intro p hp
  have h : env55859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55858_55859 : H12AffineEnvironment.transform 14 8460 env55858 = env55859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env55858 == env55859) = true)

theorem identity55859 : scanCanonicalize (H12AffineFastState.compose env55859 (packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55859 : packedSelected [0,2,3,6,7,10,11,18,19,20,24] rootPS < 2^1333 := by decide +kernel

def env55860 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,16384,292,22010,4524,2048,1025,293,4161,1329,20560,21762,160,64,3345,5393,5440,2265,21916,20576,257,1377,17865,1945]

theorem envBound55860 : H12AffineFastState.Bounded env55860 := by
  intro p hp
  have h : env55860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55859_55860 : H12AffineEnvironment.transform 12 40 env55859 = env55860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55859 == env55860) = true)

theorem identity55860 : scanCanonicalize (H12AffineFastState.compose env55860 (packedSelected [0,2,3,4,5,6,7,9,10,11,14,17,23] rootPS)) = affineNative (2^(13+1) ^^^ 4541) := by decide +kernel

theorem selectedBound55860 : packedSelected [0,2,3,4,5,6,7,9,10,11,14,17,23] rootPS < 2^1333 := by decide +kernel

def env55861 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,40,4541,292,1095,4524,2048,1025,293,4161,1329,493,1215,160,64,3345,5393,5440,2265,1057,477,257,1377,5236,1945]

theorem envBound55861 : H12AffineFastState.Bounded env55861 := by
  intro p hp
  have h : env55861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55860_55861 : H12AffineEnvironment.transform 13 4541 env55860 = env55861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4541 env55860 == env55861) = true)

theorem identity55861 : scanCanonicalize (H12AffineFastState.compose env55861 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 408) := by decide +kernel

theorem selectedBound55861 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55862 : List Nat := [2,4,8,16,32,64,128,256,512,408,2048,4096,40,4541,292,479,4524,2048,409,293,4161,169,493,295,160,64,2185,4233,4312,2265,441,477,257,249,4588,513]

theorem envBound55862 : H12AffineFastState.Bounded env55862 := by
  intro p hp
  have h : env55862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55861_55862 : H12AffineEnvironment.transform 9 408 env55861 = env55862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 408 env55861 == env55862) = true)

theorem identity55862 : scanCanonicalize (H12AffineFastState.compose env55862 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound55862 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55863 : List Nat := [2,4,8,16,32,64,88,256,512,320,2048,4096,40,4453,292,263,4468,2048,321,293,4161,113,309,295,120,64,2129,4177,4096,2049,353,261,257,33,4404,513]

theorem envBound55863 : H12AffineFastState.Bounded env55863 := by
  intro p hp
  have h : env55863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55862_55863 : H12AffineEnvironment.transform 6 88 env55862 = env55863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env55862 == env55863) = true)

theorem identity55863 : scanCanonicalize (H12AffineFastState.compose env55863 (packedSelected [2,10,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55863 : packedSelected [2,10,11] rootPS < 2^1333 := by decide +kernel

def env55864 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,4096,40,4404,292,263,4389,2048,272,293,4112,32,309,295,41,17,2048,4096,4096,2049,304,261,257,33,4404,513]

theorem envBound55864 : H12AffineFastState.Bounded env55864 := by
  intro p hp
  have h : env55864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55863_55864 : H12AffineEnvironment.transform 5 17 env55863 = env55864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55863 == env55864) = true)

theorem identity55864 : scanCanonicalize (H12AffineFastState.compose env55864 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(10+1) ^^^ 292) := by decide +kernel

theorem selectedBound55864 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env55865 : List Nat := [2,4,8,16,32,17,9,256,512,273,292,4096,40,4404,292,263,4389,292,272,293,4112,32,309,295,41,17,292,4096,4096,293,304,261,257,33,4404,513]

theorem envBound55865 : H12AffineFastState.Bounded env55865 := by
  intro p hp
  have h : env55865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55864_55865 : H12AffineEnvironment.transform 10 292 env55864 = env55865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 292 env55864 == env55865) = true)

theorem identity55865 : scanCanonicalize (H12AffineFastState.compose env55865 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(11+1) ^^^ 308) := by decide +kernel

theorem selectedBound55865 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env55866 : List Nat := [2,4,8,16,32,17,9,256,512,273,292,308,40,0,292,263,17,292,272,293,292,32,309,295,41,17,292,308,308,293,304,261,257,33,0,513]

theorem envBound55866 : H12AffineFastState.Bounded env55866 := by
  intro p hp
  have h : env55866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55865_55866 : H12AffineEnvironment.transform 11 308 env55865 = env55866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 308 env55865 == env55866) = true)

def env55867 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,10281,1025,32769,4161,169400,156116,21762,8328,64,171417,5393,140484,35324,156696,156133,257,144613,185665,169745]

theorem envBound55867 : H12AffineFastState.Bounded env55867 := by
  intro p hp
  have h : env55867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55856_55867 : H12AffineEnvironment.transform 17 10281 env55856 = env55867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env55856 == env55867) = true)

theorem identity55867 : scanCanonicalize (H12AffineFastState.compose env55867 (packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS)) = affineNative (2^(14+1) ^^^ 29908) := by decide +kernel

theorem selectedBound55867 : packedSelected [0,1,2,3,5,6,7,10,11,14,16,17,18,19,28,31,35] rootPS < 2^1333 := by decide +kernel

def env55868 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,8202,131072,10281,1025,29909,4161,156012,156116,21762,8328,64,158029,5393,140484,32040,156696,156133,257,144613,139669,156613]

theorem envBound55868 : H12AffineFastState.Bounded env55868 := by
  intro p hp
  have h : env55868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55867_55868 : H12AffineEnvironment.transform 14 29908 env55867 = env55868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29908 env55867 == env55868) = true)

theorem identity55868 : scanCanonicalize (H12AffineFastState.compose env55868 (packedSelected [0,2,3,5,6,7,10,11,18,20] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound55868 : packedSelected [0,2,3,5,6,7,10,11,18,20] rootPS < 2^1333 := by decide +kernel

def env55869 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13324,216,8202,131072,10281,1025,217,4161,136544,136664,8462,8328,64,138561,5393,140484,2340,135188,136681,257,144613,139669,137161]

theorem envBound55869 : H12AffineFastState.Bounded env55869 := by
  intro p hp
  have h : env55869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55868_55869 : H12AffineEnvironment.transform 13 13324 env55868 = env55869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env55868 == env55869) = true)

theorem identity55869 : scanCanonicalize (H12AffineFastState.compose env55869 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound55869 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env55870 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,137,8202,131072,10281,1025,136,4112,136497,136585,8462,8328,17,138512,5393,140437,2340,135188,136632,257,144564,139669,137112]

theorem envBound55870 : H12AffineFastState.Bounded env55870 := by
  intro p hp
  have h : env55870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55869_55870 : H12AffineEnvironment.transform 5 17 env55869 = env55870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env55869 == env55870) = true)

theorem identity55870 : scanCanonicalize (H12AffineFastState.compose env55870 (packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound55870 : packedSelected [0,1,2,6,7,8,11,16,17,18,19] rootPS < 2^1333 := by decide +kernel

def env55871 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,137,8202,13460,10281,1025,136,4112,8613,8477,8462,8328,17,10628,5393,4097,2340,9344,8492,257,32,5377,8972]

theorem envBound55871 : H12AffineFastState.Bounded env55871 := by
  intro p hp
  have h : env55871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55870_55871 : H12AffineEnvironment.transform 16 13460 env55870 = env55871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env55870 == env55871) = true)

theorem identity55871 : scanCanonicalize (H12AffineFastState.compose env55871 (packedSelected [0,2,7,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55871 : packedSelected [0,2,7,14,16] rootPS < 2^1333 := by decide +kernel

def env55872 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,137,263,5529,2340,1025,136,4112,168,16,3,389,17,2185,5393,4097,2340,1421,33,257,32,5377,513]

theorem envBound55872 : H12AffineFastState.Bounded env55872 := by
  intro p hp
  have h : env55872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55871_55872 : H12AffineEnvironment.transform 12 269 env55871 = env55872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55871 == env55872) = true)

theorem identity55872 : scanCanonicalize (H12AffineFastState.compose env55872 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound55872 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env55873 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,0,263,5392,2340,1025,1,4112,33,16,3,268,17,2048,5393,4097,2340,1284,33,257,32,5377,513]

theorem envBound55873 : H12AffineFastState.Bounded env55873 := by
  intro p hp
  have h : env55873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55872_55873 : H12AffineEnvironment.transform 6 9 env55872 = env55873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55872 == env55873) = true)

theorem identity55873 : scanCanonicalize (H12AffineFastState.compose env55873 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55873 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55874 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,4096,41,5157,0,35,5172,2048,1025,1,4112,33,16,3,40,17,2048,5173,4097,2048,1056,33,37,32,5157,513]

theorem envBound55874 : H12AffineFastState.Bounded env55874 := by
  intro p hp
  have h : env55874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55873_55874 : H12AffineEnvironment.transform 7 36 env55873 = env55874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55873 == env55874) = true)

def env55875 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,48,41,1045,0,35,1028,2048,1025,1,32,33,16,3,40,17,2048,1029,49,2048,1056,33,37,32,1045,513]

theorem envBound55875 : H12AffineFastState.Bounded env55875 := by
  intro p hp
  have h : env55875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55874_55875 : H12AffineEnvironment.transform 11 48 env55874 = env55875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env55874 == env55875) = true)

theorem identity55875 : scanCanonicalize (H12AffineFastState.compose env55875 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1572) := by decide +kernel

theorem selectedBound55875 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55876 : List Nat := [2,4,8,16,32,17,9,36,512,1024,1572,48,41,1045,0,35,1028,1572,1025,1,32,33,16,3,40,17,1572,1029,49,1572,1056,33,37,32,1045,513]

theorem envBound55876 : H12AffineFastState.Bounded env55876 := by
  intro p hp
  have h : env55876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55875_55876 : H12AffineEnvironment.transform 10 1572 env55875 = env55876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1572 env55875 == env55876) = true)

def env55877 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,48,41,33,0,35,48,528,53,1,32,33,16,3,40,17,528,49,49,528,20,33,37,32,33,513]

theorem envBound55877 : H12AffineFastState.Bounded env55877 := by
  intro p hp
  have h : env55877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55876_55877 : H12AffineEnvironment.transform 9 52 env55876 = env55877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55876 == env55877) = true)

theorem identity55877 : scanCanonicalize (H12AffineFastState.compose env55877 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 43) := by decide +kernel

theorem selectedBound55877 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55878 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,48,41,33,0,35,48,59,53,1,32,33,16,3,40,17,59,49,49,59,20,33,37,32,33,42]

theorem envBound55878 : H12AffineFastState.Bounded env55878 := by
  intro p hp
  have h : env55878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55877_55878 : H12AffineEnvironment.transform 8 43 env55877 = env55878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 43 env55877 == env55878) = true)

def leafEnv55878 : List Nat := [2,4,8,16,32,17,9,36,43,52,59,48,41,33,0,35,48,59,53,1,32,33,16,3,21,40,1,17,59,49,49,59,20,33,37,32,5,34,33,42,1,32,0]

def active55878 : List Nat := [0,1,2,3,4]

def tree55878 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55878 : H12WitnessSearch.Good tree55878 := H12GlobalWitnessIndex.good

theorem leafIdentity55878 : H12AffineFastState.composeSystem env55878 rootObs = leafEnv55878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55878 rootObs == leafEnv55878) = true)

theorem terminalChecked55878 : H12PackedTerminal.terminalCheckFast leafEnv55878 active55878 tree55878 = true := by decide +kernel

def env55879 : List Nat := [2,4,8,16,32,17,9,36,512,53,529,48,41,32,0,35,49,529,52,1,32,33,16,3,40,17,529,48,49,529,21,33,37,32,32,513]

theorem envBound55879 : H12AffineFastState.Bounded env55879 := by
  intro p hp
  have h : env55879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55876_55879 : H12AffineEnvironment.transform 9 53 env55876 = env55879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55876 == env55879) = true)

def env55880 : List Nat := [2,4,8,16,32,17,9,36,512,1024,2048,49,41,1044,0,35,1029,2048,1025,1,33,33,16,3,40,17,2048,1028,48,2048,1056,33,37,32,1044,513]

theorem envBound55880 : H12AffineFastState.Bounded env55880 := by
  intro p hp
  have h : env55880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55874_55880 : H12AffineEnvironment.transform 11 49 env55874 = env55880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env55874 == env55880) = true)

theorem identity55880 : scanCanonicalize (H12AffineFastState.compose env55880 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 528) := by decide +kernel

theorem selectedBound55880 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55881 : List Nat := [2,4,8,16,32,17,9,36,512,1024,528,49,41,1044,0,35,1029,528,1025,1,33,33,16,3,40,17,528,1028,48,528,1056,33,37,32,1044,513]

theorem envBound55881 : H12AffineFastState.Bounded env55881 := by
  intro p hp
  have h : env55881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55880_55881 : H12AffineEnvironment.transform 10 528 env55880 = env55881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 528 env55880 == env55881) = true)

def env55882 : List Nat := [2,4,8,16,32,17,9,36,512,52,528,49,41,32,0,35,49,528,53,1,33,33,16,3,40,17,528,48,48,528,20,33,37,32,32,513]

theorem envBound55882 : H12AffineFastState.Bounded env55882 := by
  intro p hp
  have h : env55882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55881_55882 : H12AffineEnvironment.transform 9 52 env55881 = env55882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env55881 == env55882) = true)

theorem identity55882 : scanCanonicalize (H12AffineFastState.compose env55882 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound55882 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55883 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,49,41,32,0,35,49,58,53,1,33,33,16,3,40,17,58,48,48,58,20,33,37,32,32,43]

theorem envBound55883 : H12AffineFastState.Bounded env55883 := by
  intro p hp
  have h : env55883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55882_55883 : H12AffineEnvironment.transform 8 42 env55882 = env55883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env55882 == env55883) = true)

def leafEnv55883 : List Nat := [2,4,8,16,32,17,9,36,42,52,58,49,41,32,0,35,49,58,53,1,33,33,16,3,21,40,1,17,58,48,48,58,20,33,37,32,5,34,32,43,1,33,0]

def active55883 : List Nat := [0,1,2,3,4]

def tree55883 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood55883 : H12WitnessSearch.Good tree55883 := H12GlobalWitnessIndex.good

theorem leafIdentity55883 : H12AffineFastState.composeSystem env55883 rootObs = leafEnv55883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env55883 rootObs == leafEnv55883) = true)

theorem terminalChecked55883 : H12PackedTerminal.terminalCheckFast leafEnv55883 active55883 tree55883 = true := by decide +kernel

def env55884 : List Nat := [2,4,8,16,32,17,9,36,512,53,528,49,41,33,0,35,48,528,52,1,33,33,16,3,40,17,528,49,48,528,21,33,37,32,33,513]

theorem envBound55884 : H12AffineFastState.Bounded env55884 := by
  intro p hp
  have h : env55884.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55881_55884 : H12AffineEnvironment.transform 9 53 env55881 = env55884 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55881 == env55884) = true)

def env55885 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534865,156116,2114883,8328,64,215366,115151,2241669,303573,2334855,2592082,257,254011,197023,2262864]

theorem envBound55885 : H12AffineFastState.Bounded env55885 := by
  intro p hp
  have h : env55885.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55825_55885 : H12AffineEnvironment.transform 21 2534865 env55825 = env55885 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534865 env55825 == env55885) = true)

def env55886 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441745,156116,21763,8328,64,215366,115151,140485,303573,241863,498962,257,254011,197023,169744]

theorem envBound55886 : H12AffineFastState.Bounded env55886 := by
  intro p hp
  have h : env55886.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55885_55886 : H12AffineEnvironment.transform 20 4160 env55885 = env55886 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55885 == env55886) = true)

theorem identity55886 : scanCanonicalize (H12AffineFastState.compose env55886 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55886 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55887 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,441745,156116,21763,8328,64,158029,57796,140485,303573,168140,441625,257,180272,139668,169744]

theorem envBound55887 : H12AffineFastState.Bounded env55887 := by
  intro p hp
  have h : env55887.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55886_55887 : H12AffineEnvironment.transform 15 8203 env55886 = env55887 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55886 == env55887) = true)

theorem identity55887 : scanCanonicalize (H12AffineFastState.compose env55887 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound55887 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env55888 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,38161,262144,1025,32769,4160,272512,62661,21763,8328,64,64604,57796,45524,303573,1501,272392,257,21793,46213,513]

theorem envBound55888 : H12AffineFastState.Bounded env55888 := by
  intro p hp
  have h : env55888.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55887_55888 : H12AffineEnvironment.transform 16 38161 env55887 = env55888 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env55887 == env55888) = true)

theorem identity55888 : scanCanonicalize (H12AffineFastState.compose env55888 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound55888 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env55889 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,8203,16401,262144,1025,21761,4160,272512,8645,21763,8328,64,10588,13508,25812,292053,1501,272392,257,21793,24965,513]

theorem envBound55889 : H12AffineFastState.Bounded env55889 := by
  intro p hp
  have h : env55889.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55888_55889 : H12AffineEnvironment.transform 14 21760 env55888 = env55889 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env55888 == env55889) = true)

theorem identity55889 : scanCanonicalize (H12AffineFastState.compose env55889 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound55889 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55890 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,16401,262144,1025,21761,4160,264532,17,21763,348,64,2184,5392,17664,283905,1501,264668,257,21793,16465,513]

theorem envBound55890 : H12AffineFastState.Bounded env55890 := by
  intro p hp
  have h : env55890.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55889_55890 : H12AffineEnvironment.transform 12 468 env55889 = env55890 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env55889 == env55890) = true)

theorem identity55890 : scanCanonicalize (H12AffineFastState.compose env55890 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(17+1) ^^^ 2557) := by decide +kernel

theorem selectedBound55890 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env55891 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,16384,21760,479,16401,2557,1025,21761,4160,169,17,21763,348,64,2184,5392,17664,23804,1501,33,257,21793,16465,513]

theorem envBound55891 : H12AffineFastState.Bounded env55891 := by
  intro p hp
  have h : env55891.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55890_55891 : H12AffineEnvironment.transform 17 2557 env55890 = env55891 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2557 env55890 == env55891) = true)

theorem identity55891 : scanCanonicalize (H12AffineFastState.compose env55891 (packedSelected [2,6] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound55891 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55892 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,21760,343,16401,2421,1025,21761,4160,33,17,21763,348,64,2048,5392,17664,23668,1365,33,257,21793,16465,513]

theorem envBound55892 : H12AffineFastState.Bounded env55892 := by
  intro p hp
  have h : env55892.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55891_55892 : H12AffineEnvironment.transform 6 8 env55891 = env55892 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55891 == env55892) = true)

theorem identity55892 : scanCanonicalize (H12AffineFastState.compose env55892 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(13+1) ^^^ 7284) := by decide +kernel

theorem selectedBound55892 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env55893 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,7284,2420,343,7269,2421,1025,2421,4160,33,17,2423,348,64,2048,5392,6516,0,1365,33,257,2389,7205,513]

theorem envBound55893 : H12AffineFastState.Bounded env55893 := by
  intro p hp
  have h : env55893.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55892_55893 : H12AffineEnvironment.transform 13 7284 env55892 = env55893 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7284 env55892 == env55893) = true)

theorem identity55893 : scanCanonicalize (H12AffineFastState.compose env55893 (packedSelected [2,3,4,8,9] rootPS)) = affineNative (2^(11+1) ^^^ 2318) := by decide +kernel

theorem selectedBound55893 : packedSelected [2,3,4,8,9] rootPS < 2^1333 := by decide +kernel

def env55894 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2318,348,1402,2420,343,1387,2421,1025,2421,2382,33,17,2423,348,64,2048,3102,122,0,1365,33,257,2389,1323,513]

theorem envBound55894 : H12AffineFastState.Bounded env55894 := by
  intro p hp
  have h : env55894.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55893_55894 : H12AffineEnvironment.transform 11 2318 env55893 = env55894 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2318 env55893 == env55894) = true)

theorem identity55894 : scanCanonicalize (H12AffineFastState.compose env55894 (packedSelected [0,2,3,7,8,14] rootPS)) = affineNative (2^(10+1) ^^^ 1124) := by decide +kernel

theorem selectedBound55894 : packedSelected [0,2,3,7,8,14] rootPS < 2^1333 := by decide +kernel

def env55895 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1124,1386,348,1402,1296,343,1387,1297,1025,1297,1322,33,17,1299,348,64,1124,122,122,0,1365,33,257,1329,1323,513]

theorem envBound55895 : H12AffineFastState.Bounded env55895 := by
  intro p hp
  have h : env55895.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55894_55895 : H12AffineEnvironment.transform 10 1124 env55894 = env55895 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1124 env55894 == env55895) = true)

theorem identity55895 : scanCanonicalize (H12AffineFastState.compose env55895 (packedSelected [0,2,7] rootPS)) = affineNative (2^(5+1) ^^^ 43) := by decide +kernel

theorem selectedBound55895 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env55896 : List Nat := [2,4,8,16,32,43,8,256,512,1024,1039,1281,311,1297,1296,316,1280,1297,1025,1297,1322,33,17,1299,311,43,1039,17,17,0,1342,33,257,1329,1323,513]

theorem envBound55896 : H12AffineFastState.Bounded env55896 := by
  intro p hp
  have h : env55896.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55895_55896 : H12AffineEnvironment.transform 5 43 env55895 = env55896 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 43 env55895 == env55896) = true)

theorem identity55896 : scanCanonicalize (H12AffineFastState.compose env55896 (packedSelected [1,2,3] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound55896 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env55897 : List Nat := [2,4,8,11,32,43,8,256,512,1024,1039,1281,300,1290,1291,295,1280,1290,1025,1290,1322,33,10,1288,300,43,1039,10,10,0,1317,33,257,1322,1323,513]

theorem envBound55897 : H12AffineFastState.Bounded env55897 := by
  intro p hp
  have h : env55897.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55896_55897 : H12AffineEnvironment.transform 3 11 env55896 = env55897 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env55896 == env55897) = true)

theorem identity55897 : scanCanonicalize (H12AffineFastState.compose env55897 (packedSelected [1,2,8] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound55897 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env55898 : List Nat := [2,4,8,11,32,43,8,14,512,1024,1039,1039,34,1028,1029,41,1038,1028,1025,1028,1060,33,10,1030,34,43,1039,10,10,0,1067,33,15,1060,1061,513]

theorem envBound55898 : H12AffineFastState.Bounded env55898 := by
  intro p hp
  have h : env55898.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55897_55898 : H12AffineEnvironment.transform 7 14 env55897 = env55898 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env55897 == env55898) = true)

theorem identity55898 : scanCanonicalize (H12AffineFastState.compose env55898 (packedSelected [0,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound55898 : packedSelected [0,4,5] rootPS < 2^1333 := by decide +kernel

def env55899 : List Nat := [2,4,8,11,32,43,8,14,35,1024,1039,1039,34,1028,1029,41,1038,1028,1025,1028,1060,33,10,1030,34,43,1039,10,10,0,1067,33,15,1060,1061,34]

theorem envBound55899 : H12AffineFastState.Bounded env55899 := by
  intro p hp
  have h : env55899.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55898_55899 : H12AffineEnvironment.transform 8 35 env55898 = env55899 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env55898 == env55899) = true)

def env55900 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,441744,156116,21762,8328,64,215366,115151,140484,303573,241862,498963,257,254011,197023,169745]

theorem envBound55900 : H12AffineFastState.Bounded env55900 := by
  intro p hp
  have h : env55900.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55885_55900 : H12AffineEnvironment.transform 20 4161 env55885 = env55900 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env55885 == env55900) = true)

theorem identity55900 : scanCanonicalize (H12AffineFastState.compose env55900 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 111899) := by decide +kernel

theorem selectedBound55900 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55901 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,262144,1025,32769,4161,329867,120015,21762,8328,64,64605,115151,102879,303573,1501,272392,257,21792,46212,74250]

theorem envBound55901 : H12AffineFastState.Bounded env55901 := by
  intro p hp
  have h : env55901.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55900_55901 : H12AffineEnvironment.transform 16 111899 env55900 = env55901 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111899 env55900 == env55901) = true)

def env55902 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10400,1025,32769,4161,73771,120015,21762,8328,64,64605,115151,102879,35189,1501,168,257,21792,46212,74250]

theorem envBound55902 : H12AffineFastState.Bounded env55902 := by
  intro p hp
  have h : env55902.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55901_55902 : H12AffineEnvironment.transform 17 10400 env55901 = env55902 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env55901 == env55902) = true)

def env55903 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4161,73771,119879,21762,8192,64,64605,115015,102743,35189,1365,32,257,21792,46092,74250]

theorem envBound55903 : H12AffineFastState.Bounded env55903 := by
  intro p hp
  have h : env55903.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55902_55903 : H12AffineEnvironment.transform 6 8 env55902 = env55903 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55902 == env55903) = true)

theorem identity55903 : scanCanonicalize (H12AffineFastState.compose env55903 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound55903 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55904 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,65536,70727,10280,1025,8541,4161,73771,95515,21762,8192,64,23809,90139,77835,10281,1365,32,257,21792,5456,74250]

theorem envBound55904 : H12AffineFastState.Bounded env55904 := by
  intro p hp
  have h : env55904.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55903_55904 : H12AffineEnvironment.transform 14 8540 env55903 = env55904 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env55903 == env55904) = true)

theorem identity55904 : scanCanonicalize (H12AffineFastState.compose env55904 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound55904 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env55905 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8540,29963,24908,10280,1025,8541,4161,21792,16,21762,8192,64,23809,5392,17664,10281,1365,32,257,21792,5456,22273]

theorem envBound55905 : H12AffineFastState.Bounded env55905 := by
  intro p hp
  have h : env55905.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55904_55905 : H12AffineEnvironment.transform 15 29963 env55904 = env55905 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env55904 == env55905) = true)

theorem identity55905 : scanCanonicalize (H12AffineFastState.compose env55905 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1100) := by decide +kernel

theorem selectedBound55905 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55906 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,16384,1296,20807,17664,3172,1025,1297,4161,21792,16,21762,1100,64,23809,5392,17664,3173,1365,32,257,21792,5456,22273]

theorem envBound55906 : H12AffineFastState.Bounded env55906 := by
  intro p hp
  have h : env55906.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55905_55906 : H12AffineEnvironment.transform 12 1100 env55905 = env55906 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1100 env55905 == env55906) = true)

theorem identity55906 : scanCanonicalize (H12AffineFastState.compose env55906 (packedSelected [0,4,6,7,9,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 4405) := by decide +kernel

theorem selectedBound55906 : packedSelected [0,4,6,7,9,12,15] rootPS < 2^1333 := by decide +kernel

def env55907 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1100,4405,1296,114,5173,3172,1025,1297,4161,1045,16,1079,1100,64,3124,5392,5173,3173,1365,32,257,1045,5456,1588]

theorem envBound55907 : H12AffineFastState.Bounded env55907 := by
  intro p hp
  have h : env55907.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55906_55907 : H12AffineEnvironment.transform 13 4405 env55906 = env55907 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4405 env55906 == env55907) = true)

theorem identity55907 : scanCanonicalize (H12AffineFastState.compose env55907 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound55907 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env55908 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,4096,1100,4113,1076,114,5173,3172,1025,1077,4161,1045,16,1079,1100,64,3124,5172,5173,3173,1137,32,37,1045,5236,1588]

theorem envBound55908 : H12AffineFastState.Bounded env55908 := by
  intro p hp
  have h : env55908.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55907_55908 : H12AffineEnvironment.transform 7 36 env55907 = env55908 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env55907 == env55908) = true)

theorem identity55908 : scanCanonicalize (H12AffineFastState.compose env55908 (packedSelected [1,2,3,5,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 1141) := by decide +kernel

theorem selectedBound55908 : packedSelected [1,2,3,5,8,11] rootPS < 2^1333 := by decide +kernel

def env55909 : List Nat := [2,4,8,16,32,64,8,36,512,1024,2048,1141,1100,1124,1076,114,64,3172,1025,1077,1076,1045,16,1079,1100,64,3124,65,64,3173,1137,32,37,1045,1,1588]

theorem envBound55909 : H12AffineFastState.Bounded env55909 := by
  intro p hp
  have h : env55909.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55908_55909 : H12AffineEnvironment.transform 11 1141 env55908 = env55909 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1141 env55908 == env55909) = true)

theorem identity55909 : scanCanonicalize (H12AffineFastState.compose env55909 (packedSelected [4,6,7] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound55909 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env55910 : List Nat := [2,4,8,16,32,64,8,36,512,1024,33,1141,1100,1124,1076,114,64,1093,1025,1077,1076,1045,16,1079,1100,64,1045,65,64,1092,1137,32,37,1045,1,1588]

theorem envBound55910 : H12AffineFastState.Bounded env55910 := by
  intro p hp
  have h : env55910.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55909_55910 : H12AffineEnvironment.transform 10 33 env55909 = env55910 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env55909 == env55910) = true)

theorem identity55910 : scanCanonicalize (H12AffineFastState.compose env55910 (packedSelected [0,2,4] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55910 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env55911 : List Nat := [2,4,8,16,32,64,8,36,512,53,33,64,121,81,1,114,64,112,52,0,1,32,16,2,121,64,32,65,64,113,68,32,37,32,1,513]

theorem envBound55911 : H12AffineFastState.Bounded env55911 := by
  intro p hp
  have h : env55911.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55910_55911 : H12AffineEnvironment.transform 9 53 env55910 = env55911 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55910 == env55911) = true)

theorem identity55911 : scanCanonicalize (H12AffineFastState.compose env55911 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55911 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55912 : List Nat := [2,4,8,16,32,16,8,36,512,53,33,16,41,1,1,34,16,32,52,0,1,32,16,2,41,16,32,17,16,33,20,32,37,32,1,513]

theorem envBound55912 : H12AffineFastState.Bounded env55912 := by
  intro p hp
  have h : env55912.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55911_55912 : H12AffineEnvironment.transform 5 16 env55911 = env55912 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55911 == env55912) = true)

theorem identity55912 : scanCanonicalize (H12AffineFastState.compose env55912 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound55912 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55913 : List Nat := [2,4,8,16,5,16,8,1,512,16,4,16,12,1,1,7,16,5,17,0,1,5,16,2,12,16,5,17,16,4,20,5,0,5,1,513]

theorem envBound55913 : H12AffineFastState.Bounded env55913 := by
  intro p hp
  have h : env55913.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55912_55913 : H12AffineEnvironment.transform 4 5 env55912 = env55913 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env55912 == env55913) = true)

theorem identity55913 : scanCanonicalize (H12AffineFastState.compose env55913 (packedSelected [1] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound55913 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55914 : List Nat := [2,3,8,16,2,16,8,1,512,16,3,16,11,1,1,0,16,2,17,0,1,2,16,2,11,16,2,17,16,3,19,2,0,2,1,513]

theorem envBound55914 : H12AffineFastState.Bounded env55914 := by
  intro p hp
  have h : env55914.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55913_55914 : H12AffineEnvironment.transform 1 3 env55913 = env55914 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env55913 == env55914) = true)

theorem identity55914 : scanCanonicalize (H12AffineFastState.compose env55914 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound55914 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55915 : List Nat := [2,3,8,16,2,16,8,1,9,16,3,16,11,1,1,0,16,2,17,0,1,2,16,2,11,16,2,17,16,3,19,2,0,2,1,8]

theorem envBound55915 : H12AffineFastState.Bounded env55915 := by
  intro p hp
  have h : env55915.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55914_55915 : H12AffineEnvironment.transform 8 9 env55914 = env55915 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env55914 == env55915) = true)

theorem identity55915 : scanCanonicalize (H12AffineFastState.compose env55915 (packedSelected [5] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55915 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env55916 : List Nat := [0,1,8,16,0,16,8,1,9,16,1,16,9,1,1,0,16,0,17,0,1,0,16,0,9,16,0,17,16,1,17,0,0,0,1,8]

theorem envBound55916 : H12AffineFastState.Bounded env55916 := by
  intro p hp
  have h : env55916.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55915_55916 : H12AffineEnvironment.transform 0 0 env55915 = env55916 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55915 == env55916) = true)

def env55917 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4161,73771,119878,21762,8193,64,64605,115014,102742,35189,1364,33,257,21792,46093,74250]

theorem envBound55917 : H12AffineFastState.Bounded env55917 := by
  intro p hp
  have h : env55917.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55902_55917 : H12AffineEnvironment.transform 6 9 env55902 = env55917 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55902 == env55917) = true)

theorem identity55917 : scanCanonicalize (H12AffineFastState.compose env55917 (packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound55917 : packedSelected [0,1,4,5,7,8,19,22,24,26] rootPS < 2^1333 := by decide +kernel

def env55918 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,65536,90138,10281,1025,21760,4161,73771,65863,21762,8193,64,10588,70727,83031,23668,1364,33,257,21792,24844,74250]

theorem envBound55918 : H12AffineFastState.Bounded env55918 := by
  intro p hp
  have h : env55918.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55917_55918 : H12AffineEnvironment.transform 14 21761 env55917 = env55918 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env55917 == env55918) = true)

theorem identity55918 : scanCanonicalize (H12AffineFastState.compose env55918 (packedSelected [3,5,10,16,20] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound55918 : packedSelected [3,5,10,16,20] rootPS < 2^1333 := by decide +kernel

def env55919 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,16401,10281,1025,21760,4161,32,8524,21762,8193,64,10588,13388,25692,23668,1364,33,257,21792,24844,513]

theorem envBound55919 : H12AffineFastState.Bounded env55919 := by
  intro p hp
  have h : env55919.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55918_55919 : H12AffineEnvironment.transform 15 8203 env55918 = env55919 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env55918 == env55919) = true)

theorem identity55919 : scanCanonicalize (H12AffineFastState.compose env55919 (packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound55919 : packedSelected [0,1,3,4,5,7,8,9,12,14] rootPS < 2^1333 := by decide +kernel

def env55920 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,268,16384,21761,263,16401,2341,1025,21760,4161,32,64,21762,269,64,2128,5440,17744,23668,1364,33,257,21792,16384,513]

theorem envBound55920 : H12AffineFastState.Bounded env55920 := by
  intro p hp
  have h : env55920.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55919_55920 : H12AffineEnvironment.transform 12 268 env55919 = env55920 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env55919 == env55920) = true)

theorem identity55920 : scanCanonicalize (H12AffineFastState.compose env55920 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound55920 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env55921 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,16384,21761,263,16401,2341,1025,21760,4113,32,16,21762,269,16,2048,5392,17664,23588,1284,33,257,21792,16384,513]

theorem envBound55921 : H12AffineFastState.Bounded env55921 := by
  intro p hp
  have h : env55921.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55920_55921 : H12AffineEnvironment.transform 5 16 env55920 = env55921 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env55920 == env55921) = true)

theorem identity55921 : scanCanonicalize (H12AffineFastState.compose env55921 (packedSelected [3,4,5,7] rootPS)) = affineNative (2^(13+1) ^^^ 1) := by decide +kernel

theorem selectedBound55921 : packedSelected [3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env55922 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,268,1,5376,263,16,2341,1025,5377,4113,32,16,5379,269,16,2048,5392,1281,7205,1284,33,257,5409,1,513]

theorem envBound55922 : H12AffineFastState.Bounded env55922 := by
  intro p hp
  have h : env55922.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55921_55922 : H12AffineEnvironment.transform 13 1 env55921 = env55922 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1 env55921 == env55922) = true)

theorem identity55922 : scanCanonicalize (H12AffineFastState.compose env55922 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 3883) := by decide +kernel

theorem selectedBound55922 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env55923 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,3883,268,1,2603,263,16,2341,1025,2602,3898,32,16,2600,269,16,2048,2619,1281,782,1284,33,257,2570,1,513]

theorem envBound55923 : H12AffineFastState.Bounded env55923 := by
  intro p hp
  have h : env55923.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55922_55923 : H12AffineEnvironment.transform 11 3883 env55922 = env55923 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3883 env55922 == env55923) = true)

theorem identity55923 : scanCanonicalize (H12AffineFastState.compose env55923 (packedSelected [1,2,8] rootPS)) = affineNative (2^(10+1) ^^^ 1044) := by decide +kernel

theorem selectedBound55923 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env55924 : List Nat := [2,4,8,16,32,16,9,256,512,1024,1044,831,268,1,1599,263,16,1329,1025,1598,814,32,16,1596,269,16,1044,1583,1281,782,1284,33,257,1566,1,513]

theorem envBound55924 : H12AffineFastState.Bounded env55924 := by
  intro p hp
  have h : env55924.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55923_55924 : H12AffineEnvironment.transform 10 1044 env55923 = env55924 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1044 env55923 == env55924) = true)

theorem identity55924 : scanCanonicalize (H12AffineFastState.compose env55924 (packedSelected [0,2,9] rootPS)) = affineNative (2^(8+1) ^^^ 271) := by decide +kernel

theorem selectedBound55924 : packedSelected [0,2,9] rootPS < 2^1333 := by decide +kernel

def env55925 : List Nat := [2,4,8,16,32,16,9,256,271,1024,1044,48,268,1,1328,263,16,1329,1025,1329,33,32,16,1331,269,16,1044,1312,1281,1,1284,33,257,1297,1,270]

theorem envBound55925 : H12AffineFastState.Bounded env55925 := by
  intro p hp
  have h : env55925.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55924_55925 : H12AffineEnvironment.transform 8 271 env55924 = env55925 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 271 env55924 == env55925) = true)

theorem identity55925 : scanCanonicalize (H12AffineFastState.compose env55925 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(9+1) ^^^ 21) := by decide +kernel

theorem selectedBound55925 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env55926 : List Nat := [2,4,8,16,32,16,9,256,271,21,1,48,268,1,293,263,16,292,20,292,33,32,16,294,269,16,1,309,276,1,273,33,257,260,1,270]

theorem envBound55926 : H12AffineFastState.Bounded env55926 := by
  intro p hp
  have h : env55926.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55925_55926 : H12AffineEnvironment.transform 9 21 env55925 = env55926 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 21 env55925 == env55926) = true)

theorem identity55926 : scanCanonicalize (H12AffineFastState.compose env55926 (packedSelected [1] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound55926 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55927 : List Nat := [0,4,8,16,32,16,9,256,269,21,1,48,268,1,293,261,16,292,20,292,33,32,16,292,269,16,1,309,276,1,273,33,257,260,1,268]

theorem envBound55927 : H12AffineFastState.Bounded env55927 := by
  intro p hp
  have h : env55927.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55926_55927 : H12AffineEnvironment.transform 0 0 env55926 = env55927 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env55926 == env55927) = true)

def env55928 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10401,1025,32769,4161,73770,120015,21762,8328,64,64605,115151,102879,35188,1501,169,257,21792,46212,74250]

theorem envBound55928 : H12AffineFastState.Bounded env55928 := by
  intro p hp
  have h : env55928.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55901_55928 : H12AffineEnvironment.transform 17 10401 env55901 = env55928 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env55901 == env55928) = true)

def env55929 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10281,1025,32769,4161,73770,119879,21762,8192,64,64605,115015,102743,35188,1365,33,257,21792,46092,74250]

theorem envBound55929 : H12AffineFastState.Bounded env55929 := by
  intro p hp
  have h : env55929.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55928_55929 : H12AffineEnvironment.transform 6 8 env55928 = env55929 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env55928 == env55929) = true)

theorem identity55929 : scanCanonicalize (H12AffineFastState.compose env55929 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound55929 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55930 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49168,10281,1025,32769,4161,21793,41292,21762,8192,64,64605,46156,58460,35188,1365,33,257,21792,46092,22273]

theorem envBound55930 : H12AffineFastState.Bounded env55930 := by
  intro p hp
  have h : env55930.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55929_55930 : H12AffineEnvironment.transform 15 29963 env55929 = env55930 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env55929 == env55930) = true)

theorem identity55930 : scanCanonicalize (H12AffineFastState.compose env55930 (packedSelected [2,3,5,10,11,14,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound55930 : packedSelected [2,3,5,10,11,14,18] rootPS < 2^1333 := by decide +kernel

def env55931 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,343,46156,10281,1025,32769,4161,8573,41292,8542,8192,64,34817,46156,36864,35188,1365,33,257,8572,46092,9053]

theorem envBound55931 : H12AffineFastState.Bounded env55931 := by
  intro p hp
  have h : env55931.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55930_55931 : H12AffineEnvironment.transform 13 13404 env55930 = env55931 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env55930 == env55931) = true)

theorem identity55931 : scanCanonicalize (H12AffineFastState.compose env55931 (packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound55931 : packedSelected [0,3,4,5,6,7,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env55932 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,8192,13404,32768,35,46156,10281,1025,32769,4161,8201,41016,8234,8192,64,34817,46156,36864,34816,1057,33,117,8200,46092,8745]

theorem envBound55932 : H12AffineFastState.Bounded env55932 := by
  intro p hp
  have h : env55932.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55931_55932 : H12AffineEnvironment.transform 7 116 env55931 = env55932 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env55931 == env55932) = true)

theorem identity55932 : scanCanonicalize (H12AffineFastState.compose env55932 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(12+1) ^^^ 40) := by decide +kernel

theorem selectedBound55932 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env55933 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,4096,40,5236,32768,35,37988,2049,1025,32769,4161,33,32784,2,40,64,34817,37988,36864,34816,1057,33,117,32,37924,513]

theorem envBound55933 : H12AffineFastState.Bounded env55933 := by
  intro p hp
  have h : env55933.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55932_55933 : H12AffineEnvironment.transform 12 40 env55932 = env55933 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 40 env55932 == env55933) = true)

theorem identity55933 : scanCanonicalize (H12AffineFastState.compose env55933 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound55933 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env55934 : List Nat := [2,4,8,16,32,64,8,116,512,1024,2048,0,40,1140,32768,35,33892,2049,1025,32769,65,33,32784,2,40,64,34817,33892,32768,34816,1057,33,117,32,33828,513]

theorem envBound55934 : H12AffineFastState.Bounded env55934 := by
  intro p hp
  have h : env55934.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55933_55934 : H12AffineEnvironment.transform 11 0 env55933 = env55934 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env55933 == env55934) = true)

def env55935 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,111899,10280,1025,32769,4161,73770,119878,21762,8193,64,64605,115014,102742,35188,1364,32,257,21792,46093,74250]

theorem envBound55935 : H12AffineFastState.Bounded env55935 := by
  intro p hp
  have h : env55935.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55928_55935 : H12AffineEnvironment.transform 6 9 env55928 = env55935 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env55928 == env55935) = true)

theorem identity55935 : scanCanonicalize (H12AffineFastState.compose env55935 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound55935 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env55936 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,24909,10280,1025,32769,4161,62588,16,21762,8193,64,64605,5392,17664,35188,1364,32,257,21792,46093,63068]

theorem envBound55936 : H12AffineFastState.Bounded env55936 := by
  intro p hp
  have h : env55936.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55935_55936 : H12AffineEnvironment.transform 15 54358 env55935 = env55936 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env55935 == env55936) = true)

theorem identity55936 : scanCanonicalize (H12AffineFastState.compose env55936 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1296) := by decide +kernel

theorem selectedBound55936 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env55937 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1296,20806,24909,10280,1025,1297,4161,29036,16,21762,8193,64,31053,5392,17664,3172,1364,32,257,21792,12573,29516]

theorem envBound55937 : H12AffineFastState.Bounded env55937 := by
  intro p hp
  have h : env55937.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55936_55937 : H12AffineEnvironment.transform 14 1296 env55936 = env55937 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1296 env55936 == env55937) = true)

theorem identity55937 : scanCanonicalize (H12AffineFastState.compose env55937 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound55937 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env55938 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,1296,342,12637,10280,1025,1297,4161,8572,16,1298,8193,64,10589,5392,5392,3172,1364,32,257,1328,12573,9052]

theorem envBound55938 : H12AffineFastState.Bounded env55938 := by
  intro p hp
  have h : env55938.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55937_55938 : H12AffineEnvironment.transform 13 4112 env55937 = env55938 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env55937 == env55938) = true)

theorem identity55938 : scanCanonicalize (H12AffineFastState.compose env55938 (packedSelected [11,12,15,16] rootPS)) = affineNative (2^(10+1) ^^^ 1141) := by decide +kernel

theorem selectedBound55938 : packedSelected [11,12,15,16] rootPS < 2^1333 := by decide +kernel

def env55939 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1141,4096,8192,4112,1296,342,12637,9309,1025,1297,4161,8572,16,1298,8193,64,9512,5392,5392,17,1364,32,257,1328,12573,9052]

theorem envBound55939 : H12AffineFastState.Bounded env55939 := by
  intro p hp
  have h : env55939.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55938_55939 : H12AffineEnvironment.transform 10 1141 env55938 = env55939 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1141 env55938 == env55939) = true)

theorem identity55939 : scanCanonicalize (H12AffineFastState.compose env55939 (packedSelected [1,8,11,18,19] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound55939 : packedSelected [1,8,11,18,19] rootPS < 2^1333 := by decide +kernel

def env55940 : List Nat := [2,4,8,16,32,64,9,256,512,53,64,4096,8192,4112,293,342,12637,8296,52,292,4161,8572,16,295,8193,64,8477,4389,4389,17,353,32,257,261,12573,9052]

theorem envBound55940 : H12AffineFastState.Bounded env55940 := by
  intro p hp
  have h : env55940.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55939_55940 : H12AffineEnvironment.transform 9 53 env55939 = env55940 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env55939 == env55940) = true)

theorem identity55940 : scanCanonicalize (H12AffineFastState.compose env55940 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound55940 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env55941 : List Nat := [2,4,8,16,32,64,9,256,512,53,64,4096,269,4112,293,342,4176,357,52,292,4161,113,16,295,268,64,16,4389,4389,17,353,32,257,261,4112,593]

theorem envBound55941 : H12AffineFastState.Bounded env55941 := by
  intro p hp
  have h : env55941.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55940_55941 : H12AffineEnvironment.transform 12 269 env55940 = env55941 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env55940 == env55941) = true)

theorem identity55941 : scanCanonicalize (H12AffineFastState.compose env55941 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound55941 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env55942 : List Nat := [2,4,8,1,32,64,9,256,512,36,64,4096,269,4097,293,327,4161,357,37,292,4161,96,1,295,268,64,1,4389,4389,0,353,32,257,261,4097,576]

theorem envBound55942 : H12AffineFastState.Bounded env55942 := by
  intro p hp
  have h : env55942.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55941_55942 : H12AffineEnvironment.transform 3 1 env55941 = env55942 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env55941 == env55942) = true)

theorem identity55942 : scanCanonicalize (H12AffineFastState.compose env55942 (packedSelected [0,2,3,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound55942 : packedSelected [0,2,3,4,5] rootPS < 2^1333 := by decide +kernel

def env55943 : List Nat := [2,4,8,1,32,64,9,101,512,36,64,4096,104,4097,64,34,4161,0,37,65,4161,96,1,66,105,64,1,4160,4160,0,4,32,100,96,4097,576]

theorem envBound55943 : H12AffineFastState.Bounded env55943 := by
  intro p hp
  have h : env55943.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55942_55943 : H12AffineEnvironment.transform 7 101 env55942 = env55943 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env55942 == env55943) = true)

theorem identity55943 : scanCanonicalize (H12AffineFastState.compose env55943 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 64) := by decide +kernel

theorem selectedBound55943 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env55944 : List Nat := [2,4,8,1,32,64,9,101,512,36,64,64,104,65,64,34,1,0,37,65,1,96,1,66,105,64,1,0,0,0,4,32,100,96,65,576]

theorem envBound55944 : H12AffineFastState.Bounded env55944 := by
  intro p hp
  have h : env55944.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55943_55944 : H12AffineEnvironment.transform 11 64 env55943 = env55944 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 64 env55943 == env55944) = true)

theorem identity55944 : scanCanonicalize (H12AffineFastState.compose env55944 (packedSelected [1,2,8] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound55944 : packedSelected [1,2,8] rootPS < 2^1333 := by decide +kernel

def env55945 : List Nat := [2,4,8,1,32,0,9,37,512,36,0,0,40,1,0,34,1,0,37,1,1,32,1,2,41,0,1,0,0,0,4,32,36,32,1,512]

theorem envBound55945 : H12AffineFastState.Bounded env55945 := by
  intro p hp
  have h : env55945.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55944_55945 : H12AffineEnvironment.transform 5 0 env55944 = env55945 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env55944 == env55945) = true)

theorem identity55945 : scanCanonicalize (H12AffineFastState.compose env55945 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound55945 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env55946 : List Nat := [2,4,8,1,5,0,9,0,512,1,0,0,13,1,0,7,1,0,0,1,1,5,1,2,12,0,1,0,0,0,4,5,1,5,1,512]

theorem envBound55946 : H12AffineFastState.Bounded env55946 := by
  intro p hp
  have h : env55946.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55945_55946 : H12AffineEnvironment.transform 4 5 env55945 = env55946 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env55945 == env55946) = true)

theorem identity55946 : scanCanonicalize (H12AffineFastState.compose env55946 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 13) := by decide +kernel

theorem selectedBound55946 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env55947 : List Nat := [2,4,8,1,5,0,9,0,13,1,0,0,13,1,0,7,1,0,0,1,1,5,1,2,12,0,1,0,0,0,4,5,1,5,1,13]

theorem envBound55947 : H12AffineFastState.Bounded env55947 := by
  intro p hp
  have h : env55947.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55946_55947 : H12AffineEnvironment.transform 8 13 env55946 = env55947 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 13 env55946 == env55947) = true)

theorem identity55947 : scanCanonicalize (H12AffineFastState.compose env55947 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound55947 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env55948 : List Nat := [2,1,8,1,0,0,9,0,8,1,0,0,8,1,0,2,1,0,0,1,1,0,1,2,9,0,1,0,0,0,1,0,1,0,1,8]

theorem envBound55948 : H12AffineFastState.Bounded env55948 := by
  intro p hp
  have h : env55948.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55947_55948 : H12AffineEnvironment.transform 1 1 env55947 = env55948 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env55947 == env55948) = true)

theorem identity55948 : scanCanonicalize (H12AffineFastState.compose env55948 (packedSelected [3] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound55948 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env55949 : List Nat := [2,1,2,1,0,0,3,0,2,1,0,0,2,1,0,2,1,0,0,1,1,0,1,2,3,0,1,0,0,0,1,0,1,0,1,2]

theorem envBound55949 : H12AffineFastState.Bounded env55949 := by
  intro p hp
  have h : env55949.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55948_55949 : H12AffineEnvironment.transform 2 2 env55948 = env55949 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env55948 == env55949) = true)

def env55950 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,156117,2114882,8328,64,6677655,115150,2241668,303572,2334855,4268162,257,254011,197023,2262864]

theorem envBound55950 : H12AffineFastState.Bounded env55950 := by
  intro p hp
  have h : env55950.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55824_55950 : H12AffineEnvironment.transform 22 156117 env55824 = env55950 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 156117 env55824 == env55950) = true)

def env55951 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,2534864,156117,2114882,8328,64,215367,115150,2241668,303572,2334855,2592082,257,254011,197023,2262864]

theorem envBound55951 : H12AffineFastState.Bounded env55951 := by
  intro p hp
  have h : env55951.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55950_55951 : H12AffineEnvironment.transform 21 2534864 env55950 = env55951 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 2534864 env55950 == env55951) = true)

def env55952 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,441744,156117,21762,8328,64,215367,115150,140484,303572,241863,498962,257,254011,197023,169744]

theorem envBound55952 : H12AffineFastState.Bounded env55952 := by
  intro p hp
  have h : env55952.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55951_55952 : H12AffineEnvironment.transform 20 4160 env55951 = env55952 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env55951 == env55952) = true)

theorem identity55952 : scanCanonicalize (H12AffineFastState.compose env55952 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound55952 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env55953 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,262144,1025,32769,4160,272513,62660,21762,8328,64,121942,115150,45525,303572,75222,329731,257,95530,103566,513]

theorem envBound55953 : H12AffineFastState.Bounded env55953 := by
  intro p hp
  have h : env55953.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55952_55953 : H12AffineEnvironment.transform 16 38161 env55952 = env55953 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env55952 == env55953) = true)

def env55954 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,38161,10280,1025,32769,4160,169,62660,21762,8328,64,121942,115150,45525,35324,75222,73771,257,95530,103566,513]

theorem envBound55954 : H12AffineFastState.Bounded env55954 := by
  intro p hp
  have h : env55954.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55953_55954 : H12AffineEnvironment.transform 17 10280 env55953 = env55954 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env55953 == env55954) = true)

theorem identity55954 : scanCanonicalize (H12AffineFastState.compose env55954 (packedSelected [1,5,8,19,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 62730) := by decide +kernel

theorem selectedBound55954 : packedSelected [1,5,8,19,24,26] rootPS < 2^1333 := by decide +kernel

def env55955 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,62730,38161,10280,1025,32769,4160,169,62660,21762,8328,64,10588,13508,45525,35324,53468,54561,257,32800,24964,513]

theorem envBound55955 : H12AffineFastState.Bounded env55955 := by
  intro p hp
  have h : env55955.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55954_55955 : H12AffineEnvironment.transform 15 62730 env55954 = env55955 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62730 env55954 == env55955) = true)

theorem identity55955 : scanCanonicalize (H12AffineFastState.compose env55955 (packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS)) = affineNative (2^(9+1) ^^^ 320) := by decide +kernel

theorem selectedBound55955 : packedSelected [2,4,6,7,8,9,10,11,17,27,28,32] rootPS < 2^1333 := by decide +kernel

def env55956 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,16384,32768,61514,36945,10280,321,32769,4160,169,61828,20546,8328,64,10588,12676,45525,35324,53468,53345,257,32800,24964,513]

theorem envBound55956 : H12AffineFastState.Bounded env55956 := by
  intro p hp
  have h : env55956.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55955_55956 : H12AffineEnvironment.transform 9 320 env55955 = env55956 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 320 env55955 == env55956) = true)

theorem identity55956 : scanCanonicalize (H12AffineFastState.compose env55956 (packedSelected [7,8,10,11,14,18,20,27,28] rootPS)) = affineNative (2^(13+1) ^^^ 12513) := by decide +kernel

theorem selectedBound55956 : packedSelected [7,8,10,11,14,18,20,27,28] rootPS < 2^1333 := by decide +kernel

def env55957 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,12513,32768,32939,36945,10280,321,32769,4160,169,33125,8355,8328,64,10588,12676,45525,35324,41021,41088,257,32800,4453,513]

theorem envBound55957 : H12AffineFastState.Bounded env55957 := by
  intro p hp
  have h : env55957.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55956_55957 : H12AffineEnvironment.transform 13 12513 env55956 = env55957 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12513 env55956 == env55957) = true)

theorem identity55957 : scanCanonicalize (H12AffineFastState.compose env55957 (packedSelected [0,3,5,10,12,14,17,18,23,27,38] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound55957 : packedSelected [0,3,5,10,12,14,17,18,23,27,38] rootPS < 2^1333 := by decide +kernel

def env55958 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,8192,12513,8661,8574,12676,10280,321,8660,4160,169,8368,8355,8328,64,10588,12676,4096,10281,488,341,257,8693,4453,513]

theorem envBound55958 : H12AffineFastState.Bounded env55958 := by
  intro p hp
  have h : env55958.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55957_55958 : H12AffineEnvironment.transform 14 8661 env55957 = env55958 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env55957 == env55958) = true)

theorem identity55958 : scanCanonicalize (H12AffineFastState.compose env55958 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound55958 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env55959 : List Nat := [2,4,8,16,32,64,128,256,512,320,2048,4096,41,4296,508,343,4525,2049,321,509,4160,169,153,138,161,64,2421,4525,4096,2048,488,341,257,476,4453,513]

theorem envBound55959 : H12AffineFastState.Bounded env55959 := by
  intro p hp
  have h : env55959.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans55958_55959 : H12AffineEnvironment.transform 12 41 env55958 = env55959 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env55958 == env55959) = true)

theorem identity55959 : scanCanonicalize (H12AffineFastState.compose env55959 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound55959 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env55960 : List Nat := [2,4,8,16,32,64,89,256,512,320,2048,4096,41,4113,293,343,4468,2049,321,292,4160,112,64,83,120,64,2421,4468,4096,2048,305,341,257,261,4453,513]

theorem envBound55960 : H12AffineFastState.Bounded env55960 := by
  intro p hp
  have h : env55960.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1