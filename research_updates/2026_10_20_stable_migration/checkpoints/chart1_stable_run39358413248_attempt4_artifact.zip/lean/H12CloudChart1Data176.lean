import H12CloudChart1Data175

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem selectedBound44612 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44613 : List Nat := [2,4,8,16,32,17,9,37,512,36,27,4096,40,4097,0,34,4113,26,37,1,4112,33,16,3,41,16,26,4113,4097,27,4,32,36,33,4096,513]

theorem envBound44613 : H12AffineFastState.Bounded env44613 := by
  intro p hp
  have h : env44613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44612_44613 : H12AffineEnvironment.transform 10 27 env44612 = env44613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 27 env44612 == env44613) = true)

theorem identity44613 : scanCanonicalize (H12AffineFastState.compose env44613 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 27) := by decide +kernel

theorem selectedBound44613 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44614 : List Nat := [2,4,8,16,27,17,9,30,512,31,27,4096,19,4097,0,25,4113,26,30,1,4112,26,16,3,18,16,26,4113,4097,27,4,27,31,26,4096,513]

theorem envBound44614 : H12AffineFastState.Bounded env44614 := by
  intro p hp
  have h : env44614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44613_44614 : H12AffineEnvironment.transform 4 27 env44613 = env44614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 27 env44613 == env44614) = true)

theorem identity44614 : scanCanonicalize (H12AffineFastState.compose env44614 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 0) := by decide +kernel

theorem selectedBound44614 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44615 : List Nat := [2,4,8,16,27,17,9,30,512,31,27,0,19,1,0,25,17,26,30,1,16,26,16,3,18,16,26,17,1,27,4,27,31,26,0,513]

theorem envBound44615 : H12AffineFastState.Bounded env44615 := by
  intro p hp
  have h : env44615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44614_44615 : H12AffineEnvironment.transform 11 0 env44614 = env44615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 0 env44614 == env44615) = true)

theorem identity44615 : scanCanonicalize (H12AffineFastState.compose env44615 (packedSelected [1,8] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound44615 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env44616 : List Nat := [2,4,2,16,17,17,3,20,512,21,17,0,19,1,0,19,17,16,20,1,16,16,16,3,18,16,16,17,1,17,4,17,21,16,0,513]

theorem envBound44616 : H12AffineFastState.Bounded env44616 := by
  intro p hp
  have h : env44616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44615_44616 : H12AffineEnvironment.transform 2 2 env44615 = env44616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env44615 == env44616) = true)

theorem identity44616 : scanCanonicalize (H12AffineFastState.compose env44616 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 20) := by decide +kernel

theorem selectedBound44616 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44617 : List Nat := [2,4,2,16,17,17,3,20,20,21,17,0,19,1,0,19,17,16,20,1,16,16,16,3,18,16,16,17,1,17,4,17,21,16,0,21]

theorem envBound44617 : H12AffineFastState.Bounded env44617 := by
  intro p hp
  have h : env44617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44616_44617 : H12AffineEnvironment.transform 8 20 env44616 = env44617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 20 env44616 == env44617) = true)

def env44618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,536870912,1073741824,92374096,4294967296,525568,4308116845,620851225,25733062]

theorem envBound44618 : H12AffineFastState.Bounded env44618 := by
  intro p hp
  have h : env44618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans31959_44618 : H12AffineEnvironment.transform 27 19497101 env31959 = env44618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 19497101 env31959 == env44618) = true)

def env44619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374096,4294967296,525568,4308116845,27337993,25733062]

theorem envBound44619 : H12AffineFastState.Bounded env44619 := by
  intro p hp
  have h : env44619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44618_44619 : H12AffineEnvironment.transform 28 77616400 env44618 = env44619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 28 77616400 env44618 == env44619) = true)

def env44620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,1073741824,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound44620 : H12AffineFastState.Bounded env44620 := by
  intro p hp
  have h : env44620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44619_44620 : H12AffineEnvironment.transform 31 145662400 env44619 = env44620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 31 145662400 env44619 == env44620) = true)

def env44621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,67108864,134217728,19497101,77616400,155254784,92374096,145662400,525568,140903597,27337993,25733062]

theorem envBound44621 : H12AffineFastState.Bounded env44621 := by
  intro p hp
  have h : env44621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44620_44621 : H12AffineEnvironment.transform 29 155254784 env44620 = env44621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 155254784 env44620 == env44621) = true)

def env44622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,134217728,19497101,10507600,155254784,25265168,145662400,525568,140903597,27337993,25733062]

theorem envBound44622 : H12AffineFastState.Bounded env44622 := by
  intro p hp
  have h : env44622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44621_44622 : H12AffineEnvironment.transform 25 64 env44621 = env44622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 64 env44621 == env44622) = true)

def env44623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,64,30393344,19497101,10507600,9356288,25265168,23160256,525568,27902125,27337993,25733062]

theorem envBound44623 : H12AffineFastState.Bounded env44623 := by
  intro p hp
  have h : env44623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44622_44623 : H12AffineEnvironment.transform 26 30393344 env44622 = env44623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393344 env44622 == env44623) = true)

def env44624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,64,29868032,18973837,10507600,8830976,25265168,23160256,256,27378861,27337993,25207750]

theorem envBound44624 : H12AffineFastState.Bounded env44624 := by
  intro p hp
  have h : env44624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44623_44624 : H12AffineEnvironment.transform 18 1024 env44623 = env44624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env44623 == env44624) = true)

theorem identity44624 : scanCanonicalize (H12AffineFastState.compose env44624 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 2) := by decide +kernel

theorem selectedBound44624 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,2,8328,64,13090818,2196623,10507600,8830976,8487954,6383042,256,10601647,10560779,8430532]

theorem envBound44625 : H12AffineFastState.Bounded env44625 := by
  intro p hp
  have h : env44625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44624_44625 : H12AffineEnvironment.transform 23 2 env44624 = env44625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 2 env44624 == env44625) = true)

def env44626 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147592,2,8328,64,4554890,2196623,2233816,295048,246938,6383042,256,2327591,2319747,189260]

theorem envBound44626 : H12AffineFastState.Bounded env44626 := by
  intro p hp
  have h : env44626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44625_44626 : H12AffineEnvironment.transform 22 147592 env44625 = env44626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147592 env44625 == env44626) = true)

def env44627 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147592,2,8328,64,4450362,2196623,2233816,190520,246938,6383042,256,2327591,2319747,189260]

theorem envBound44627 : H12AffineFastState.Bounded env44627 := by
  intro p hp
  have h : env44627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44626_44627 : H12AffineEnvironment.transform 17 157872 env44626 = env44627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env44626 == env44627) = true)

theorem identity44627 : scanCanonicalize (H12AffineFastState.compose env44627 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound44627 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44628 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,16400,10400,1024,32769,2097152,4194304,152,2,8328,64,4302890,2196623,2119112,43048,99466,6383042,256,2212919,2172307,41820]

theorem envBound44628 : H12AffineFastState.Bounded env44628 := by
  intro p hp
  have h : env44628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44627_44628 : H12AffineEnvironment.transform 16 16400 env44627 = env44628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env44627 == env44628) = true)

theorem identity44628 : scanCanonicalize (H12AffineFastState.compose env44628 (packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44628 : packedSelected [0,1,5,8,9,14,19,22,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env44629 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10400,1024,8540,2097152,4194304,152,2,8328,64,4262263,2172370,2119112,2421,75223,6383042,256,2188650,2172307,513]

theorem envBound44629 : H12AffineFastState.Bounded env44629 := by
  intro p hp
  have h : env44629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44628_44629 : H12AffineEnvironment.transform 14 8541 env44628 = env44629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44628 == env44629) = true)

def env44630 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,2097152,4194304,16,2,8192,64,4262263,2172250,2118976,2421,75103,6382922,256,2188650,2172187,513]

theorem envBound44630 : H12AffineFastState.Bounded env44630 := by
  intro p hp
  have h : env44630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44629_44630 : H12AffineEnvironment.transform 6 8 env44629 = env44630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44629 == env44630) = true)

theorem identity44630 : scanCanonicalize (H12AffineFastState.compose env44630 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound44630 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env44631 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,91466,4194304,16,2,8192,64,4262263,16400,77834,2421,75103,4194304,256,32,16465,513]

theorem envBound44631 : H12AffineFastState.Bounded env44631 := by
  intro p hp
  have h : env44631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44630_44631 : H12AffineEnvironment.transform 20 91466 env44630 = env44631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env44630 == env44631) = true)

theorem identity44631 : scanCanonicalize (H12AffineFastState.compose env44631 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44631 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44632 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1024,8540,17729,4194304,16,2,8192,64,4204924,16400,4097,2421,1364,4194304,256,32,16465,513]

theorem envBound44632 : H12AffineFastState.Bounded env44632 := by
  intro p hp
  have h : env44632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44631_44632 : H12AffineEnvironment.transform 15 8203 env44631 = env44632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44631 == env44632) = true)

theorem identity44632 : scanCanonicalize (H12AffineFastState.compose env44632 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44632 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44633 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,8461,8203,16400,10280,1024,8460,17681,4194304,16,2,8192,16,4204844,16400,4097,2341,1284,4194304,256,32,16385,513]

theorem envBound44633 : H12AffineFastState.Bounded env44633 := by
  intro p hp
  have h : env44633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44632_44633 : H12AffineEnvironment.transform 5 16 env44632 = env44633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44632 == env44633) = true)

theorem identity44633 : scanCanonicalize (H12AffineFastState.compose env44633 (packedSelected [5,8] rootPS)) = affineNative (2^(13+1) ^^^ 15366) := by decide +kernel

theorem selectedBound44633 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env44634 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,15366,8461,8203,15382,10280,1024,8460,14615,4194304,16,2,8192,16,4204844,15382,4097,2341,1284,4194304,256,32,15367,513]

theorem envBound44634 : H12AffineFastState.Bounded env44634 := by
  intro p hp
  have h : env44634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44633_44634 : H12AffineEnvironment.transform 13 15366 env44633 = env44634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 15366 env44633 == env44634) = true)

theorem identity44634 : scanCanonicalize (H12AffineFastState.compose env44634 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44634 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44635 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,7434,1,263,7450,2340,1024,0,6171,4194304,16,2,268,16,4196384,7450,4097,2341,1284,4194304,256,32,7435,513]

theorem envBound44635 : H12AffineFastState.Bounded env44635 := by
  intro p hp
  have h : env44635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44634_44635 : H12AffineEnvironment.transform 12 268 env44634 = env44635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44634 == env44635) = true)

theorem identity44635 : scanCanonicalize (H12AffineFastState.compose env44635 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(21+1) ^^^ 5141) := by decide +kernel

theorem selectedBound44635 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44636 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,7434,1,263,7450,2340,1024,0,6171,5141,16,2,268,16,7221,7450,4097,2341,1284,5141,256,32,7435,513]

theorem envBound44636 : H12AffineFastState.Bounded env44636 := by
  intro p hp
  have h : env44636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44635_44636 : H12AffineEnvironment.transform 21 5141 env44635 = env44636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 5141 env44635 == env44636) = true)

theorem identity44636 : scanCanonicalize (H12AffineFastState.compose env44636 (packedSelected [1,3,12] rootPS)) = affineNative (2^(11+1) ^^^ 1077) := by decide +kernel

theorem selectedBound44636 : packedSelected [1,3,12] rootPS < 2^1333 := by decide +kernel

def env44637 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,1077,268,2367,1,263,2351,2340,1024,0,3118,32,16,2,268,16,2048,2351,1076,2341,1284,32,256,32,2366,513]

theorem envBound44637 : H12AffineFastState.Bounded env44637 := by
  intro p hp
  have h : env44637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44636_44637 : H12AffineEnvironment.transform 11 1077 env44636 = env44637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1077 env44636 == env44637) = true)

theorem identity44637 : scanCanonicalize (H12AffineFastState.compose env44637 (packedSelected [2] rootPS)) = affineNative (2^(10+1) ^^^ 271) := by decide +kernel

theorem selectedBound44637 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44638 : List Nat := [2,4,8,16,32,16,8,256,512,1024,271,1077,268,48,1,263,32,43,1024,0,1313,32,16,2,268,16,271,32,1076,42,1284,32,256,32,49,513]

theorem envBound44638 : H12AffineFastState.Bounded env44638 := by
  intro p hp
  have h : env44638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44637_44638 : H12AffineEnvironment.transform 10 271 env44637 = env44638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 271 env44637 == env44638) = true)

theorem identity44638 : scanCanonicalize (H12AffineFastState.compose env44638 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound44638 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44639 : List Nat := [2,4,8,16,32,16,8,21,512,1024,26,1077,25,48,1,18,32,43,1024,0,1076,32,16,2,25,16,26,32,1076,42,1041,32,21,32,49,513]

theorem envBound44639 : H12AffineFastState.Bounded env44639 := by
  intro p hp
  have h : env44639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44638_44639 : H12AffineEnvironment.transform 7 21 env44638 = env44639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env44638 == env44639) = true)

theorem identity44639 : scanCanonicalize (H12AffineFastState.compose env44639 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound44639 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44640 : List Nat := [2,4,8,16,32,16,8,21,10,1024,26,1077,25,48,1,18,32,43,1024,0,1076,32,16,2,25,16,26,32,1076,42,1041,32,21,32,49,11]

theorem envBound44640 : H12AffineFastState.Bounded env44640 := by
  intro p hp
  have h : env44640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44639_44640 : H12AffineEnvironment.transform 8 10 env44639 = env44640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env44639 == env44640) = true)

theorem identity44640 : scanCanonicalize (H12AffineFastState.compose env44640 (packedSelected [0,1] rootPS)) = affineNative (2^(9+1) ^^^ 34) := by decide +kernel

theorem selectedBound44640 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44641 : List Nat := [2,4,8,16,32,16,8,21,10,34,26,23,25,48,1,18,32,43,34,0,22,32,16,2,25,16,26,32,22,42,51,32,21,32,49,11]

theorem envBound44641 : H12AffineFastState.Bounded env44641 := by
  intro p hp
  have h : env44641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44640_44641 : H12AffineEnvironment.transform 9 34 env44640 = env44641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 34 env44640 == env44641) = true)

def env44642 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10281,1024,8540,2097152,4194304,17,2,8193,64,4262263,2172251,2118977,2421,75102,6382923,256,2188650,2172186,513]

theorem envBound44642 : H12AffineFastState.Bounded env44642 := by
  intro p hp
  have h : env44642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44629_44642 : H12AffineEnvironment.transform 6 9 env44629 = env44642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44629 == env44642) = true)

theorem identity44642 : scanCanonicalize (H12AffineFastState.compose env44642 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44642 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44643 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1024,8540,2097152,4194304,17,2,8193,64,4204925,2098513,2118977,2421,1364,6309185,256,2114912,2098448,513]

theorem envBound44643 : H12AffineFastState.Bounded env44643 := by
  intro p hp
  have h : env44643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44642_44643 : H12AffineEnvironment.transform 15 8202 env44642 = env44643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44642 == env44643) = true)

theorem identity44643 : scanCanonicalize (H12AffineFastState.compose env44643 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound44643 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44644 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1024,8540,2097152,20528,17,2,8193,64,31053,2098513,2118977,2421,1364,2102641,256,2114912,2098448,513]

theorem envBound44644 : H12AffineFastState.Bounded env44644 := by
  intro p hp
  have h : env44644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44643_44644 : H12AffineEnvironment.transform 21 20528 env44643 = env44644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env44643 == env44644) = true)

theorem identity44644 : scanCanonicalize (H12AffineFastState.compose env44644 (packedSelected [4,9,11] rootPS)) = affineNative (2^(20+1) ^^^ 23808) := by decide +kernel

theorem selectedBound44644 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44645 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10281,1024,8540,23808,20528,17,2,8193,64,31053,22609,2113,2421,1364,18545,256,6240,22544,513]

theorem envBound44645 : H12AffineFastState.Bounded env44645 := by
  intro p hp
  have h : env44645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44644_44645 : H12AffineEnvironment.transform 20 23808 env44644 = env44645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 23808 env44644 == env44645) = true)

theorem identity44645 : scanCanonicalize (H12AffineFastState.compose env44645 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 4112) := by decide +kernel

theorem selectedBound44645 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44646 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,4112,8541,8202,4096,10281,1024,8540,3344,32,17,2,8193,64,10589,2113,2113,2421,1364,6241,256,6240,2048,513]

theorem envBound44646 : H12AffineFastState.Bounded env44646 := by
  intro p hp
  have h : env44646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44645_44646 : H12AffineEnvironment.transform 13 4112 env44645 = env44646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4112 env44645 == env44646) = true)

theorem identity44646 : scanCanonicalize (H12AffineFastState.compose env44646 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 6476) := by decide +kernel

theorem selectedBound44646 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44647 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,6476,4112,6161,6470,4096,4453,1024,6160,3344,32,17,2,6477,64,4113,2113,2113,2421,1364,6241,256,6240,2048,513]

theorem envBound44647 : H12AffineFastState.Bounded env44647 := by
  intro p hp
  have h : env44647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44646_44647 : H12AffineEnvironment.transform 12 6476 env44646 = env44647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6476 env44646 == env44647) = true)

theorem identity44647 : scanCanonicalize (H12AffineFastState.compose env44647 (packedSelected [0,2,4] rootPS)) = affineNative (2^(10+1) ^^^ 1077) := by decide +kernel

theorem selectedBound44647 : packedSelected [0,2,4] rootPS < 2^1333 := by decide +kernel

def env44648 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1077,4096,5497,4112,5156,5491,4096,4453,1024,5157,293,32,17,2,5496,64,4113,1140,1140,1344,1364,5204,256,5205,1077,513]

theorem envBound44648 : H12AffineFastState.Bounded env44648 := by
  intro p hp
  have h : env44648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44647_44648 : H12AffineEnvironment.transform 10 1077 env44647 = env44648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1077 env44647 == env44648) = true)

theorem identity44648 : scanCanonicalize (H12AffineFastState.compose env44648 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound44648 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44649 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1077,1061,348,1077,1,342,1061,1344,1024,0,293,32,17,2,349,64,1076,1140,1140,1344,1364,113,256,112,1077,513]

theorem envBound44649 : H12AffineFastState.Bounded env44649 := by
  intro p hp
  have h : env44649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44648_44649 : H12AffineEnvironment.transform 11 1061 env44648 = env44649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env44648 == env44649) = true)

theorem identity44649 : scanCanonicalize (H12AffineFastState.compose env44649 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 100) := by decide +kernel

theorem selectedBound44649 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env44650 : List Nat := [2,4,8,16,32,64,9,256,512,100,81,65,348,81,1,342,65,292,100,0,293,32,17,2,349,64,80,16,16,292,304,113,256,112,81,513]

theorem envBound44650 : H12AffineFastState.Bounded env44650 := by
  intro p hp
  have h : env44650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44649_44650 : H12AffineEnvironment.transform 9 100 env44649 = env44650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 100 env44649 == env44650) = true)

theorem identity44650 : scanCanonicalize (H12AffineFastState.compose env44650 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44650 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44651 : List Nat := [2,4,8,16,32,64,9,116,512,100,81,65,40,81,1,34,65,80,100,0,81,32,17,2,41,64,80,16,16,80,68,113,116,112,81,513]

theorem envBound44651 : H12AffineFastState.Bounded env44651 := by
  intro p hp
  have h : env44651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44650_44651 : H12AffineEnvironment.transform 7 116 env44650 = env44651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44650 == env44651) = true)

theorem identity44651 : scanCanonicalize (H12AffineFastState.compose env44651 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound44651 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44652 : List Nat := [2,4,8,16,32,64,9,116,1,100,81,65,40,81,1,34,65,80,100,0,81,32,17,2,41,64,80,16,16,80,68,113,116,112,81,0]

theorem envBound44652 : H12AffineFastState.Bounded env44652 := by
  intro p hp
  have h : env44652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44651_44652 : H12AffineEnvironment.transform 8 1 env44651 = env44652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env44651 == env44652) = true)

def env44653 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147592,2,8328,64,4450363,2196623,2233816,190521,246938,6383042,256,2327591,2319747,189260]

theorem envBound44653 : H12AffineFastState.Bounded env44653 := by
  intro p hp
  have h : env44653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44626_44653 : H12AffineEnvironment.transform 17 157873 env44626 = env44653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env44626 == env44653) = true)

theorem identity44653 : scanCanonicalize (H12AffineFastState.compose env44653 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44653 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44654 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,64,4450363,2196487,2233680,190521,246802,6382922,256,2327591,2319627,189260]

theorem envBound44654 : H12AffineFastState.Bounded env44654 := by
  intro p hp
  have h : env44654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44653_44654 : H12AffineEnvironment.transform 6 8 env44653 = env44654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44653 == env44654) = true)

def env44655 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,16,4450363,2196487,2233600,190521,246802,6382874,256,2327591,2319627,189212]

theorem envBound44655 : H12AffineFastState.Bounded env44655 := by
  intro p hp
  have h : env44655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44654_44655 : H12AffineEnvironment.transform 5 16 env44654 = env44655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44654 == env44655) = true)

def env44656 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,4194304,147456,2,8192,16,4450363,2195767,2232368,190521,246050,6381610,256,2326807,2318395,189212]

theorem envBound44656 : H12AffineFastState.Bounded env44656 := by
  intro p hp
  have h : env44656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44655_44656 : H12AffineEnvironment.transform 9 304 env44655 = env44656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env44655 == env44656) = true)

theorem identity44656 : scanCanonicalize (H12AffineFastState.compose env44656 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound44656 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env44657 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,73770,147456,2,8192,16,182289,2195767,2232368,190521,246050,2113536,256,2326807,2318395,189212]

theorem envBound44657 : H12AffineFastState.Bounded env44657 := by
  intro p hp
  have h : env44657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44656_44657 : H12AffineEnvironment.transform 21 73770 env44656 = env44657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env44656 == env44657) = true)

theorem identity44657 : scanCanonicalize (H12AffineFastState.compose env44657 (packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS)) = affineNative (2^(20+1) ^^^ 49184) := by decide +kernel

theorem selectedBound44657 : packedSelected [0,1,3,5,7,8,10,18,19,20,23] rootPS < 2^1333 := by decide +kernel

def env44658 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,49184,73770,147456,2,8192,16,182289,82199,184336,190521,246050,32800,256,213303,237595,189212]

theorem envBound44658 : H12AffineFastState.Bounded env44658 := by
  intro p hp
  have h : env44658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44657_44658 : H12AffineEnvironment.transform 20 49184 env44657 = env44658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 49184 env44657 == env44658) = true)

theorem identity44658 : scanCanonicalize (H12AffineFastState.compose env44658 (packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS)) = affineNative (2^(14+1) ^^^ 0) := by decide +kernel

theorem selectedBound44658 : packedSelected [0,1,3,4,5,7,8,10,17,22,26] rootPS < 2^1333 := by decide +kernel

def env44659 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,0,65536,131072,157753,304,1,16416,73770,147456,2,8192,16,149521,82199,151568,157753,213282,32,256,213303,204827,156444]

theorem envBound44659 : H12AffineFastState.Bounded env44659 := by
  intro p hp
  have h : env44659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44658_44659 : H12AffineEnvironment.transform 14 0 env44658 = env44659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 0 env44658 == env44659) = true)

theorem identity44659 : scanCanonicalize (H12AffineFastState.compose env44659 (packedSelected [1,3,4,5,8,10,19,20,22] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound44659 : packedSelected [1,3,4,5,8,10,19,20,22] rootPS < 2^1333 := by decide +kernel

def env44660 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,0,262,131072,157753,304,1,16416,8492,147456,2,8192,16,149521,16401,151568,157753,147492,32,256,147505,139549,156444]

theorem envBound44660 : H12AffineFastState.Bounded env44660 := by
  intro p hp
  have h : env44660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44659_44660 : H12AffineEnvironment.transform 15 262 env44659 = env44660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env44659 == env44660) = true)

theorem identity44660 : scanCanonicalize (H12AffineFastState.compose env44660 (packedSelected [6,12,14,15] rootPS)) = affineNative (2^(16+1) ^^^ 12297) := by decide +kernel

theorem selectedBound44660 : packedSelected [6,12,14,15] rootPS < 2^1333 := by decide +kernel

def env44661 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,16384,0,262,12297,22576,304,1,16416,8492,28681,2,8192,16,30744,16401,24601,22576,28717,32,256,28728,4372,21269]

theorem envBound44661 : H12AffineFastState.Bounded env44661 := by
  intro p hp
  have h : env44661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44660_44661 : H12AffineEnvironment.transform 16 12297 env44660 = env44661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12297 env44660 == env44661) = true)

theorem identity44661 : scanCanonicalize (H12AffineFastState.compose env44661 (packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 12313) := by decide +kernel

theorem selectedBound44661 : packedSelected [0,2,3,5,7,10,11,14,16,18] rootPS < 2^1333 := by decide +kernel

def env44662 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,8192,12313,0,262,12297,10281,304,1,12345,8492,16,2,8192,16,2049,12296,4096,10281,52,32,256,33,4372,8972]

theorem envBound44662 : H12AffineFastState.Bounded env44662 := by
  intro p hp
  have h : env44662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44661_44662 : H12AffineEnvironment.transform 13 12313 env44661 = env44662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12313 env44661 == env44662) = true)

theorem identity44662 : scanCanonicalize (H12AffineFastState.compose env44662 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(12+1) ^^^ 25) := by decide +kernel

theorem selectedBound44662 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env44663 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,4096,25,4096,0,262,4112,2096,304,1,4128,309,16,2,25,16,2049,4113,4096,2096,52,32,256,33,4372,789]

theorem envBound44663 : H12AffineFastState.Bounded env44663 := by
  intro p hp
  have h : env44663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44662_44663 : H12AffineEnvironment.transform 12 25 env44662 = env44663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 25 env44662 == env44663) = true)

theorem identity44663 : scanCanonicalize (H12AffineFastState.compose env44663 (packedSelected [6] rootPS)) = affineNative (2^(11+1) ^^^ 32) := by decide +kernel

theorem selectedBound44663 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44664 : List Nat := [2,4,8,16,32,16,8,256,512,304,2048,32,25,32,0,262,48,2096,304,1,0,309,16,2,25,16,2049,49,32,2096,52,32,256,33,308,789]

theorem envBound44664 : H12AffineFastState.Bounded env44664 := by
  intro p hp
  have h : env44664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44663_44664 : H12AffineEnvironment.transform 11 32 env44663 = env44664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 32 env44663 == env44664) = true)

theorem identity44664 : scanCanonicalize (H12AffineFastState.compose env44664 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(10+1) ^^^ 773) := by decide +kernel

theorem selectedBound44664 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env44665 : List Nat := [2,4,8,16,32,16,8,256,512,304,773,32,25,32,0,262,48,821,304,1,0,309,16,2,25,16,772,49,32,821,52,32,256,33,308,789]

theorem envBound44665 : H12AffineFastState.Bounded env44665 := by
  intro p hp
  have h : env44665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44664_44665 : H12AffineEnvironment.transform 10 773 env44664 = env44665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 773 env44664 == env44665) = true)

theorem identity44665 : scanCanonicalize (H12AffineFastState.compose env44665 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 319) := by decide +kernel

theorem selectedBound44665 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44666 : List Nat := [2,4,8,16,32,16,8,256,319,304,58,32,25,32,0,262,48,10,304,1,0,309,16,2,25,16,59,49,32,10,52,32,256,33,308,42]

theorem envBound44666 : H12AffineFastState.Bounded env44666 := by
  intro p hp
  have h : env44666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44665_44666 : H12AffineEnvironment.transform 8 319 env44665 = env44666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 319 env44665 == env44666) = true)

theorem identity44666 : scanCanonicalize (H12AffineFastState.compose env44666 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44666 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env44667 : List Nat := [2,4,8,16,1,16,8,256,286,273,27,1,25,1,0,262,17,10,273,1,0,276,16,2,25,16,26,16,1,10,21,1,256,0,277,11]

theorem envBound44667 : H12AffineFastState.Bounded env44667 := by
  intro p hp
  have h : env44667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44666_44667 : H12AffineEnvironment.transform 4 1 env44666 = env44667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44666 == env44667) = true)

theorem identity44667 : scanCanonicalize (H12AffineFastState.compose env44667 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound44667 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44668 : List Nat := [2,1,8,16,1,16,8,256,283,273,27,1,25,1,0,259,17,10,273,1,0,273,16,2,25,16,26,16,1,10,16,1,256,0,272,11]

theorem envBound44668 : H12AffineFastState.Bounded env44668 := by
  intro p hp
  have h : env44668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44667_44668 : H12AffineEnvironment.transform 1 1 env44667 = env44668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env44667 == env44668) = true)

theorem identity44668 : scanCanonicalize (H12AffineFastState.compose env44668 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 9) := by decide +kernel

theorem selectedBound44668 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44669 : List Nat := [2,1,8,16,1,16,8,9,18,24,27,1,25,1,0,10,17,10,24,1,0,24,16,2,25,16,26,16,1,10,16,1,9,0,25,11]

theorem envBound44669 : H12AffineFastState.Bounded env44669 := by
  intro p hp
  have h : env44669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44668_44669 : H12AffineEnvironment.transform 7 9 env44668 = env44669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 9 env44668 == env44669) = true)

theorem identity44669 : scanCanonicalize (H12AffineFastState.compose env44669 (packedSelected [10] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound44669 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env44670 : List Nat := [1,1,8,16,1,16,8,9,17,24,24,1,25,1,0,9,17,9,24,1,0,24,16,1,25,16,25,16,1,9,16,1,9,0,25,8]

theorem envBound44670 : H12AffineFastState.Bounded env44670 := by
  intro p hp
  have h : env44670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44669_44670 : H12AffineEnvironment.transform 0 1 env44669 = env44670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env44669 == env44670) = true)

theorem identity44670 : scanCanonicalize (H12AffineFastState.compose env44670 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound44670 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env44671 : List Nat := [1,1,8,0,1,0,8,9,1,8,8,1,9,1,0,9,1,9,8,1,0,8,0,1,9,0,9,0,1,9,0,1,9,0,9,8]

theorem envBound44671 : H12AffineFastState.Bounded env44671 := by
  intro p hp
  have h : env44671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44670_44671 : H12AffineEnvironment.transform 3 0 env44670 = env44671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env44670 == env44671) = true)

theorem identity44671 : scanCanonicalize (H12AffineFastState.compose env44671 (packedSelected [14] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound44671 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env44672 : List Nat := [1,1,0,0,1,0,0,1,1,0,0,1,1,1,0,1,1,1,0,1,0,0,0,1,1,0,1,0,1,1,0,1,1,0,1,0]

theorem envBound44672 : H12AffineFastState.Bounded env44672 := by
  intro p hp
  have h : env44672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44671_44672 : H12AffineEnvironment.transform 2 0 env44671 = env44672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env44671 == env44672) = true)

def env44673 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,4194304,147456,2,8192,16,4450363,2195766,2232369,190521,246051,6381611,256,2326806,2318394,189212]

theorem envBound44673 : H12AffineFastState.Bounded env44673 := by
  intro p hp
  have h : env44673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44655_44673 : H12AffineEnvironment.transform 9 305 env44655 = env44673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env44655 == env44673) = true)

theorem identity44673 : scanCanonicalize (H12AffineFastState.compose env44673 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 246071) := by decide +kernel

theorem selectedBound44673 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env44674 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,246071,147456,2,8192,16,10508,2195766,2232369,190521,246051,2269468,256,2326806,2318394,189212]

theorem envBound44674 : H12AffineFastState.Bounded env44674 := by
  intro p hp
  have h : env44674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44673_44674 : H12AffineEnvironment.transform 21 246071 env44673 = env44674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 246071 env44673 == env44674) = true)

theorem identity44674 : scanCanonicalize (H12AffineFastState.compose env44674 (packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound44674 : packedSelected [1,5,8,12,15,19,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env44675 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,8460,65536,131072,157753,305,8461,2097152,221243,147456,2,8192,16,10508,2170938,2232369,149813,221231,2228240,256,2301978,2318394,147984]

theorem envBound44675 : H12AffineFastState.Bounded env44675 := by
  intro p hp
  have h : env44675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44674_44675 : H12AffineEnvironment.transform 14 8460 env44674 = env44675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env44674 == env44675) = true)

theorem identity44675 : scanCanonicalize (H12AffineFastState.compose env44675 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(20+1) ^^^ 82215) := by decide +kernel

theorem selectedBound44675 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env44676 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,8192,16384,8460,65536,131072,157753,305,8461,82215,221243,147456,2,8192,16,10508,24861,217366,149813,221231,213303,256,155965,139549,147984]

theorem envBound44676 : H12AffineFastState.Bounded env44676 := by
  intro p hp
  have h : env44676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44675_44676 : H12AffineEnvironment.transform 20 82215 env44675 = env44676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 82215 env44675 == env44676) = true)

theorem identity44676 : scanCanonicalize (H12AffineFastState.compose env44676 (packedSelected [0,2,3,5,6,7,10,16,17] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44676 : packedSelected [0,2,3,5,6,7,10,16,17] rootPS < 2^1333 := by decide +kernel

def env44677 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,16384,0,65536,131072,149813,305,1,82215,213303,147456,2,268,16,2048,16401,217366,149813,213283,213303,256,147505,131089,147984]

theorem envBound44677 : H12AffineFastState.Bounded env44677 := by
  intro p hp
  have h : env44677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44676_44677 : H12AffineEnvironment.transform 12 268 env44676 = env44677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44676 == env44677) = true)

theorem identity44677 : scanCanonicalize (H12AffineFastState.compose env44677 (packedSelected [0,1,3,4,5,8,10,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 69894) := by decide +kernel

theorem selectedBound44677 : packedSelected [0,1,3,4,5,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env44678 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,16384,0,65536,69894,88115,305,1,82215,20529,86278,2,268,16,2048,16401,16400,88115,20517,20529,256,86327,69911,86806]

theorem envBound44678 : H12AffineFastState.Bounded env44678 := by
  intro p hp
  have h : env44678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44677_44678 : H12AffineEnvironment.transform 16 69894 env44677 = env44678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 69894 env44677 == env44678) = true)

theorem identity44678 : scanCanonicalize (H12AffineFastState.compose env44678 (packedSelected [4,7,10,14] rootPS)) = affineNative (2^(13+1) ^^^ 4113) := by decide +kernel

theorem selectedBound44678 : packedSelected [4,7,10,14] rootPS < 2^1333 := by decide +kernel

def env44679 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,4113,0,65536,69894,67618,305,1,69942,32,65815,2,268,16,2048,4096,4097,67618,52,32,256,65830,69911,66311]

theorem envBound44679 : H12AffineFastState.Bounded env44679 := by
  intro p hp
  have h : env44679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44678_44679 : H12AffineEnvironment.transform 13 4113 env44678 = env44679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4113 env44678 == env44679) = true)

theorem identity44679 : scanCanonicalize (H12AffineFastState.compose env44679 (packedSelected [0,1,2,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 6162) := by decide +kernel

theorem selectedBound44679 : packedSelected [0,1,2,7,8] rootPS < 2^1333 := by decide +kernel

def env44680 : List Nat := [2,4,8,16,32,16,8,256,512,305,2048,4096,268,4113,0,6162,2324,4144,305,1,2340,32,6405,2,268,16,2048,4096,4097,4144,52,32,256,6452,2309,6933]

theorem envBound44680 : H12AffineFastState.Bounded env44680 := by
  intro p hp
  have h : env44680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44679_44680 : H12AffineEnvironment.transform 15 6162 env44679 = env44680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6162 env44679 == env44680) = true)

theorem identity44680 : scanCanonicalize (H12AffineFastState.compose env44680 (packedSelected [4,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44680 : packedSelected [4,6,7] rootPS < 2^1333 := by decide +kernel

def env44681 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,4096,8,4113,0,6162,2064,4144,53,1,2080,32,6145,2,8,16,2048,4096,4097,4144,52,32,4,6192,2049,6673]

theorem envBound44681 : H12AffineFastState.Bounded env44681 := by
  intro p hp
  have h : env44681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44680_44681 : H12AffineEnvironment.transform 7 4 env44680 = env44681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44680 == env44681) = true)

theorem identity44681 : scanCanonicalize (H12AffineFastState.compose env44681 (packedSelected [0,9] rootPS)) = affineNative (2^(11+1) ^^^ 2065) := by decide +kernel

theorem selectedBound44681 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env44682 : List Nat := [2,4,8,16,32,16,8,4,512,53,2048,2065,8,2048,0,3,2064,2081,53,1,2080,32,16,2,8,16,2048,2065,2064,2081,52,32,4,33,2049,512]

theorem envBound44682 : H12AffineFastState.Bounded env44682 := by
  intro p hp
  have h : env44682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44681_44682 : H12AffineEnvironment.transform 11 2065 env44681 = env44682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2065 env44681 == env44682) = true)

theorem identity44682 : scanCanonicalize (H12AffineFastState.compose env44682 (packedSelected [0,1] rootPS)) = affineNative (2^(10+1) ^^^ 63) := by decide +kernel

theorem selectedBound44682 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44683 : List Nat := [2,4,8,16,32,16,8,4,512,53,63,46,8,63,0,3,47,30,53,1,31,32,16,2,8,16,63,46,47,30,52,32,4,33,62,512]

theorem envBound44683 : H12AffineFastState.Bounded env44683 := by
  intro p hp
  have h : env44683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44682_44683 : H12AffineEnvironment.transform 10 63 env44682 = env44683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 63 env44682 == env44683) = true)

theorem identity44683 : scanCanonicalize (H12AffineFastState.compose env44683 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44683 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44684 : List Nat := [2,4,8,16,0,16,8,4,512,21,31,14,8,31,0,3,15,30,21,1,31,0,16,2,8,16,31,14,15,30,20,0,4,1,30,512]

theorem envBound44684 : H12AffineFastState.Bounded env44684 := by
  intro p hp
  have h : env44684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44683_44684 : H12AffineEnvironment.transform 4 0 env44683 = env44684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44683 == env44684) = true)

theorem identity44684 : scanCanonicalize (H12AffineFastState.compose env44684 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound44684 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44685 : List Nat := [2,4,8,16,0,16,8,4,0,21,31,14,8,31,0,3,15,30,21,1,31,0,16,2,8,16,31,14,15,30,20,0,4,1,30,0]

theorem envBound44685 : H12AffineFastState.Bounded env44685 := by
  intro p hp
  have h : env44685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44684_44685 : H12AffineEnvironment.transform 8 0 env44684 = env44685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env44684 == env44685) = true)

def leafEnv44685 : List Nat := [2,4,8,16,0,16,8,4,0,21,31,14,8,31,0,3,15,30,21,1,31,0,16,2,20,8,1,16,31,14,15,30,20,0,4,1,4,3,30,0,1,30,0]

def active44685 : List Nat := [0,1,2,3]

def tree44685 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44685 : H12WitnessSearch.Good tree44685 := H12GlobalWitnessIndex.good

theorem leafIdentity44685 : H12AffineFastState.composeSystem env44685 rootObs = leafEnv44685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44685 rootObs == leafEnv44685) = true)

theorem terminalChecked44685 : H12PackedTerminal.terminalCheckFast leafEnv44685 active44685 tree44685 = true := by decide +kernel

def env44686 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157753,1024,32769,2097152,4194304,147456,2,8192,17,4450363,2196487,2233601,190521,246802,6382875,256,2327591,2319627,189213]

theorem envBound44686 : H12AffineFastState.Bounded env44686 := by
  intro p hp
  have h : env44686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44654_44686 : H12AffineEnvironment.transform 5 17 env44654 = env44686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44654 == env44686) = true)

def env44687 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,4194304,147456,2,8192,17,4450363,2195767,2232369,190521,246050,6381611,256,2326807,2318395,189213]

theorem envBound44687 : H12AffineFastState.Bounded env44687 := by
  intro p hp
  have h : env44687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44686_44687 : H12AffineEnvironment.transform 9 304 env44686 = env44687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 304 env44686 == env44687) = true)

theorem identity44687 : scanCanonicalize (H12AffineFastState.compose env44687 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 32) := by decide +kernel

theorem selectedBound44687 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env44688 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,32768,65536,131072,157753,304,32769,2097152,32,147456,2,8192,17,256027,2195767,2232369,190521,246050,2187275,256,2326807,2318395,189213]

theorem envBound44688 : H12AffineFastState.Bounded env44688 := by
  intro p hp
  have h : env44688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44687_44688 : H12AffineEnvironment.transform 21 32 env44687 = env44688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44687 == env44688) = true)

theorem identity44688 : scanCanonicalize (H12AffineFastState.compose env44688 (packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound44688 : packedSelected [0,1,4,5,7,8,11,16,18,19,20,22,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env44689 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,8192,16384,8461,65536,131072,157753,304,8460,2097152,32,147456,2,8192,17,215318,2170938,2232369,149812,221231,2187275,256,2301978,2318395,147984]

theorem envBound44689 : H12AffineFastState.Bounded env44689 := by
  intro p hp
  have h : env44689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44688_44689 : H12AffineEnvironment.transform 14 8461 env44688 = env44689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env44688 == env44689) = true)

theorem identity44689 : scanCanonicalize (H12AffineFastState.compose env44689 (packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound44689 : packedSelected [0,1,2,3,4,5,6,7,8,9,10,11,14,18,19] rootPS < 2^1333 := by decide +kernel

def env44690 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,1,65536,131072,149813,304,0,2097152,32,147456,2,268,17,215318,2162998,2232369,149812,213283,2179335,256,2294038,2310455,147984]

theorem envBound44690 : H12AffineFastState.Bounded env44690 := by
  intro p hp
  have h : env44690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44689_44690 : H12AffineEnvironment.transform 12 268 env44689 = env44690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env44689 == env44690) = true)

theorem identity44690 : scanCanonicalize (H12AffineFastState.compose env44690 (packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS)) = affineNative (2^(20+1) ^^^ 196919) := by decide +kernel

theorem selectedBound44690 : packedSelected [1,2,6,8,10,11,12,14,16,17] rootPS < 2^1333 := by decide +kernel

def env44691 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,1,65536,131072,149813,304,0,196919,32,147456,2,268,17,215318,131073,69894,149812,213283,147504,256,33,16384,147984]

theorem envBound44691 : H12AffineFastState.Bounded env44691 := by
  intro p hp
  have h : env44691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44690_44691 : H12AffineEnvironment.transform 20 196919 env44690 = env44691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 196919 env44690 == env44691) = true)

theorem identity44691 : scanCanonicalize (H12AffineFastState.compose env44691 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(16+1) ^^^ 82199) := by decide +kernel

theorem selectedBound44691 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env44692 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,1,65536,82199,67618,304,0,16416,32,65815,2,268,17,2049,82198,69894,67619,52,65831,256,33,16384,66311]

theorem envBound44692 : H12AffineFastState.Bounded env44692 := by
  intro p hp
  have h : env44692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44691_44692 : H12AffineEnvironment.transform 16 82199 env44691 = env44692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 82199 env44691 == env44692) = true)

theorem identity44692 : scanCanonicalize (H12AffineFastState.compose env44692 (packedSelected [0,2,3,5,7] rootPS)) = affineNative (2^(15+1) ^^^ 20530) := by decide +kernel

theorem selectedBound44692 : packedSelected [0,2,3,5,7] rootPS < 2^1333 := by decide +kernel

def env44693 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,16384,1,20530,4389,22544,304,0,16416,32,20773,2,268,17,2049,4388,16692,22545,52,20757,256,33,16384,21301]

theorem envBound44693 : H12AffineFastState.Bounded env44693 := by
  intro p hp
  have h : env44693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44692_44693 : H12AffineEnvironment.transform 15 20530 env44692 = env44693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 20530 env44692 == env44693) = true)

theorem identity44693 : scanCanonicalize (H12AffineFastState.compose env44693 (packedSelected [2,3,4,5,6,9] rootPS)) = affineNative (2^(13+1) ^^^ 4373) := by decide +kernel

theorem selectedBound44693 : packedSelected [2,3,4,5,6,9] rootPS < 2^1333 := by decide +kernel

def env44694 : List Nat := [2,4,8,16,32,17,8,256,512,304,2048,4096,268,4373,1,295,4389,2309,304,0,4405,32,48,2,268,17,2049,4388,4129,2308,52,0,256,33,4373,544]

theorem envBound44694 : H12AffineFastState.Bounded env44694 := by
  intro p hp
  have h : env44694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44693_44694 : H12AffineEnvironment.transform 13 4373 env44693 = env44694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4373 env44693 == env44694) = true)

def env44695 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,4194304,147456,2,8192,17,4450363,2195766,2232368,190521,246051,6381610,256,2326806,2318394,189213]

theorem envBound44695 : H12AffineFastState.Bounded env44695 := by
  intro p hp
  have h : env44695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44686_44695 : H12AffineEnvironment.transform 9 305 env44686 = env44695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env44686 == env44695) = true)

theorem identity44695 : scanCanonicalize (H12AffineFastState.compose env44695 (packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS)) = affineNative (2^(21+1) ^^^ 188732) := by decide +kernel

theorem selectedBound44695 : packedSelected [1,3,5,7,8,9,10,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env44696 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,131072,157753,305,32769,2097152,188732,147456,2,8192,17,67847,2195766,2232368,190521,246051,2326806,256,2326806,2318394,189213]

theorem envBound44696 : H12AffineFastState.Bounded env44696 := by
  intro p hp
  have h : env44696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44695_44696 : H12AffineEnvironment.transform 21 188732 env44695 = env44696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 188732 env44695 == env44696) = true)

theorem identity44696 : scanCanonicalize (H12AffineFastState.compose env44696 (packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS)) = affineNative (2^(16+1) ^^^ 114966) := by decide +kernel

theorem selectedBound44696 : packedSelected [1,5,8,11,15,19,24,26,32,38] rootPS < 2^1333 := by decide +kernel

def env44697 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,114966,108847,305,32769,2097152,73770,98582,2,8192,17,67847,2195766,2216230,76079,53,2113536,256,2113536,2138412,74251]

theorem envBound44697 : H12AffineFastState.Bounded env44697 := by
  intro p hp
  have h : env44697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44696_44697 : H12AffineEnvironment.transform 16 114966 env44696 = env44697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 114966 env44696 == env44697) = true)

theorem identity44697 : scanCanonicalize (H12AffineFastState.compose env44697 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(20+1) ^^^ 16416) := by decide +kernel

theorem selectedBound44697 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env44698 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,65536,114966,108847,305,32769,16416,73770,98582,2,8192,17,67847,114966,102662,76079,53,32,256,32,57612,74251]

theorem envBound44698 : H12AffineFastState.Bounded env44698 := by
  intro p hp
  have h : env44698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44697_44698 : H12AffineEnvironment.transform 20 16416 env44697 = env44698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16416 env44697 == env44698) = true)

theorem identity44698 : scanCanonicalize (H12AffineFastState.compose env44698 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40970) := by decide +kernel

theorem selectedBound44698 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env44699 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,16384,32768,40970,24860,2341,305,32769,16416,32800,8476,2,8192,17,43277,24860,12556,35109,53,32,256,32,57612,33281]

theorem envBound44699 : H12AffineFastState.Bounded env44699 := by
  intro p hp
  have h : env44699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44698_44699 : H12AffineEnvironment.transform 15 40970 env44698 = env44699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40970 env44698 == env44699) = true)

theorem identity44699 : scanCanonicalize (H12AffineFastState.compose env44699 (packedSelected [0,6,7,14,15,16] rootPS)) = affineNative (2^(13+1) ^^^ 14652) := by decide +kernel

theorem selectedBound44699 : packedSelected [0,6,7,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44700 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,8192,14652,32768,40970,6176,2341,305,32769,14620,32800,8476,2,8192,17,43277,6176,12556,35109,53,32,256,32,38960,33281]

theorem envBound44700 : H12AffineFastState.Bounded env44700 := by
  intro p hp
  have h : env44700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44699_44700 : H12AffineEnvironment.transform 13 14652 env44699 = env44700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 14652 env44699 == env44700) = true)

theorem identity44700 : scanCanonicalize (H12AffineFastState.compose env44700 (packedSelected [6,14,15,17] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44700 : packedSelected [6,14,15,17] rootPS < 2^1333 := by decide +kernel

def env44701 : List Nat := [2,4,8,16,32,17,8,256,512,305,2048,4096,269,6193,32768,33031,6176,2341,305,32769,6161,32800,17,2,269,17,34816,6176,4097,35109,53,32,256,32,38960,33281]

theorem envBound44701 : H12AffineFastState.Bounded env44701 := by
  intro p hp
  have h : env44701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44700_44701 : H12AffineEnvironment.transform 12 269 env44700 = env44701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44700 == env44701) = true)

theorem identity44701 : scanCanonicalize (H12AffineFastState.compose env44701 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44701 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env44702 : List Nat := [2,4,8,16,32,17,8,256,512,305,0,4096,269,4145,32768,33031,4128,293,305,32769,4113,32800,17,2,269,17,32768,4128,4097,33061,53,32,256,32,36912,33281]

theorem envBound44702 : H12AffineFastState.Bounded env44702 := by
  intro p hp
  have h : env44702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44701_44702 : H12AffineEnvironment.transform 10 0 env44701 = env44702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44701 == env44702) = true)

theorem identity44702 : scanCanonicalize (H12AffineFastState.compose env44702 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 277) := by decide +kernel

theorem selectedBound44702 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env44703 : List Nat := [2,4,8,16,32,17,8,256,512,305,0,277,269,292,32768,33031,309,293,305,32769,260,32800,17,2,269,17,32768,309,276,33061,53,32,256,32,33061,33281]

theorem envBound44703 : H12AffineFastState.Bounded env44703 := by
  intro p hp
  have h : env44703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44702_44703 : H12AffineEnvironment.transform 11 277 env44702 = env44703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 277 env44702 == env44703) = true)

theorem identity44703 : scanCanonicalize (H12AffineFastState.compose env44703 (packedSelected [0,1,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44703 : packedSelected [0,1,4,8] rootPS < 2^1333 := by decide +kernel

def env44704 : List Nat := [2,4,8,16,32,17,8,37,512,20,0,48,40,1,32768,32802,16,0,20,32769,33,32800,17,2,40,17,32768,16,49,32768,53,32,37,32,32768,33281]

theorem envBound44704 : H12AffineFastState.Bounded env44704 := by
  intro p hp
  have h : env44704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44703_44704 : H12AffineEnvironment.transform 7 37 env44703 = env44704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44703 == env44704) = true)

def env44705 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,147593,2,8328,64,4554891,2196623,2233817,295049,246939,6383042,256,2327590,2319746,189261]

theorem envBound44705 : H12AffineFastState.Bounded env44705 := by
  intro p hp
  have h : env44705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44625_44705 : H12AffineEnvironment.transform 22 147593 env44625 = env44705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147593 env44625 == env44705) = true)

def env44706 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157872,1024,32769,2097152,4194304,147593,2,8328,64,4450363,2196623,2233817,190521,246939,6383042,256,2327590,2319746,189261]

theorem envBound44706 : H12AffineFastState.Bounded env44706 := by
  intro p hp
  have h : env44706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44705_44706 : H12AffineEnvironment.transform 17 157872 env44705 = env44706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157872 env44705 == env44706) = true)

theorem identity44706 : scanCanonicalize (H12AffineFastState.compose env44706 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(16+1) ^^^ 57796) := by decide +kernel

theorem selectedBound44706 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44707 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,35188,1024,32769,2097152,4194304,41293,2,8328,64,4262399,2196623,2159645,2557,75103,6383042,256,2188770,2196550,649]

theorem envBound44707 : H12AffineFastState.Bounded env44707 := by
  intro p hp
  have h : env44707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44706_44707 : H12AffineEnvironment.transform 16 57796 env44706 = env44707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57796 env44706 == env44707) = true)

def env44708 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,35188,1024,32769,2097152,32,41293,2,8328,64,68063,2196623,2159645,2557,75103,2188770,256,2188770,2196550,649]

theorem envBound44708 : H12AffineFastState.Bounded env44708 := by
  intro p hp
  have h : env44708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44707_44708 : H12AffineEnvironment.transform 21 32 env44707 = env44708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env44707 == env44708) = true)

theorem identity44708 : scanCanonicalize (H12AffineFastState.compose env44708 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound44708 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env44709 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,57676,35188,1024,32769,2097152,32,41293,2,8192,64,67927,2196487,2159645,2421,75103,2188650,256,2188650,2196550,513]

theorem envBound44709 : H12AffineFastState.Bounded env44709 := by
  intro p hp
  have h : env44709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44708_44709 : H12AffineEnvironment.transform 6 8 env44708 = env44709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44708 == env44709) = true)

theorem identity44709 : scanCanonicalize (H12AffineFastState.compose env44709 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 33110) := by decide +kernel

theorem selectedBound44709 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env44710 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,33110,57676,35188,1024,32769,2097152,32,41293,2,8192,64,34817,2098513,2159645,2421,41993,2155580,256,2155580,2098448,513]

theorem envBound44710 : H12AffineFastState.Bounded env44710 := by
  intro p hp
  have h : env44710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44709_44710 : H12AffineEnvironment.transform 15 33110 env44709 = env44710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 33110 env44709 == env44710) = true)

theorem identity44710 : scanCanonicalize (H12AffineFastState.compose env44710 (packedSelected [0,2,4,6,7,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44710 : packedSelected [0,2,4,6,7,9,14] rootPS < 2^1333 := by decide +kernel

def env44711 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,32768,33110,49217,35188,1024,32769,2097152,32,32832,2,269,64,34817,2098513,2151696,2421,34052,2147633,256,2147633,2098448,513]

theorem envBound44711 : H12AffineFastState.Bounded env44711 := by
  intro p hp
  have h : env44711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44710_44711 : H12AffineEnvironment.transform 12 269 env44710 = env44711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44710 == env44711) = true)

theorem identity44711 : scanCanonicalize (H12AffineFastState.compose env44711 (packedSelected [0,4,6,7,9,11,18] rootPS)) = affineNative (2^(14+1) ^^^ 293) := by decide +kernel

theorem selectedBound44711 : packedSelected [0,4,6,7,9,11,18] rootPS < 2^1333 := by decide +kernel

def env44712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,16384,293,115,16740,2129,1024,292,2097152,32,357,2,269,64,2340,2098513,2118709,2421,1057,2114580,256,2114580,2098448,513]

theorem envBound44712 : H12AffineFastState.Bounded env44712 := by
  intro p hp
  have h : env44712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44711_44712 : H12AffineEnvironment.transform 14 293 env44711 = env44712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 293 env44711 == env44712) = true)

theorem identity44712 : scanCanonicalize (H12AffineFastState.compose env44712 (packedSelected [0,3,6,7,8,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1297) := by decide +kernel

theorem selectedBound44712 : packedSelected [0,3,6,7,8,10,11] rootPS < 2^1333 := by decide +kernel

def env44713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,269,16384,293,115,16740,1344,1024,292,2097152,32,357,2,269,64,1077,2098513,2118709,1124,1057,2114580,256,2114580,2098448,513]

theorem envBound44713 : H12AffineFastState.Bounded env44713 := by
  intro p hp
  have h : env44713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44712_44713 : H12AffineEnvironment.transform 10 1297 env44712 = env44713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1297 env44712 == env44713) = true)

theorem identity44713 : scanCanonicalize (H12AffineFastState.compose env44713 (packedSelected [3,8,10,12,15] rootPS)) = affineNative (2^(20+1) ^^^ 17680) := by decide +kernel

theorem selectedBound44713 : packedSelected [3,8,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,1297,4096,269,16384,293,115,16740,1344,1024,292,17680,32,357,2,269,64,1077,16449,4389,1124,1057,260,256,260,16384,513]

theorem envBound44714 : H12AffineFastState.Bounded env44714 := by
  intro p hp
  have h : env44714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44713_44714 : H12AffineEnvironment.transform 20 17680 env44713 = env44714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17680 env44713 == env44714) = true)

theorem identity44714 : scanCanonicalize (H12AffineFastState.compose env44714 (packedSelected [1,3,4,5,7,8] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44714 : packedSelected [1,3,4,5,7,8] rootPS < 2^1333 := by decide +kernel

def env44715 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,4096,120,16384,80,115,16401,1077,1024,81,17509,32,16,2,120,64,1077,16449,4176,1124,1057,113,117,113,16384,513]

theorem envBound44715 : H12AffineFastState.Bounded env44715 := by
  intro p hp
  have h : env44715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44714_44715 : H12AffineEnvironment.transform 7 117 env44714 = env44715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44714 == env44715) = true)

theorem identity44715 : scanCanonicalize (H12AffineFastState.compose env44715 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound44715 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44716 : List Nat := [2,4,8,16,32,64,8,117,512,1024,1124,4096,120,5237,80,115,5220,1077,1024,81,4112,32,16,2,120,64,1077,5172,4176,1124,1057,113,117,113,5237,513]

theorem envBound44716 : H12AffineFastState.Bounded env44716 := by
  intro p hp
  have h : env44716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44715_44716 : H12AffineEnvironment.transform 13 5237 env44715 = env44716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env44715 == env44716) = true)

def env44717 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,57796,35188,1024,32769,2097152,33,41293,2,8328,64,68062,2196623,2159645,2557,75103,2188771,256,2188770,2196550,649]

theorem envBound44717 : H12AffineFastState.Bounded env44717 := by
  intro p hp
  have h : env44717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44707_44717 : H12AffineEnvironment.transform 21 33 env44707 = env44717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 33 env44707 == env44717) = true)

theorem identity44717 : scanCanonicalize (H12AffineFastState.compose env44717 (packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound44717 : packedSelected [1,5,8,11,18,19,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env44718 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16536,10280,1024,8541,2097152,33,17,2,8328,64,68062,2172371,2118977,2557,75103,2188771,256,2188770,2172186,649]

theorem envBound44718 : H12AffineFastState.Bounded env44718 := by
  intro p hp
  have h : env44718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44717_44718 : H12AffineEnvironment.transform 14 8540 env44717 = env44718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env44717 == env44718) = true)

theorem identity44718 : scanCanonicalize (H12AffineFastState.compose env44718 (packedSelected [2,4,6,9,18] rootPS)) = affineNative (2^(20+1) ^^^ 25797) := by decide +kernel

theorem selectedBound44718 : packedSelected [2,4,6,9,18] rootPS < 2^1333 := by decide +kernel

def env44719 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,65536,16536,10280,1024,8541,25797,33,17,2,8328,64,68062,82198,12676,2557,75103,65830,256,65831,82399,649]

theorem envBound44719 : H12AffineFastState.Bounded env44719 := by
  intro p hp
  have h : env44719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44718_44719 : H12AffineEnvironment.transform 20 25797 env44718 = env44719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 25797 env44718 == env44719) = true)

theorem identity44719 : scanCanonicalize (H12AffineFastState.compose env44719 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound44719 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44720 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8540,8323,16536,10280,1024,8541,25797,33,17,2,8328,64,10589,24981,12676,2557,1500,8613,256,8612,24924,649]

theorem envBound44720 : H12AffineFastState.Bounded env44720 := by
  intro p hp
  have h : env44720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44719_44720 : H12AffineEnvironment.transform 15 8323 env44719 = env44720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env44719 == env44720) = true)

theorem identity44720 : scanCanonicalize (H12AffineFastState.compose env44720 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound44720 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44721 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,389,16384,217,262,16536,2477,1024,216,17728,33,17,2,269,64,2264,16400,4097,2557,1500,32,256,33,16601,649]

theorem envBound44721 : H12AffineFastState.Bounded env44721 := by
  intro p hp
  have h : env44721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44720_44721 : H12AffineEnvironment.transform 12 389 env44720 = env44721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env44720 == env44721) = true)

theorem identity44721 : scanCanonicalize (H12AffineFastState.compose env44721 (packedSelected [4,6,7,10,11] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44721 : packedSelected [4,6,7,10,11] rootPS < 2^1333 := by decide +kernel

def env44722 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,240,16384,217,115,16536,2264,1024,216,17461,33,17,2,120,64,2264,16400,4097,2184,1193,32,117,33,16601,649]

theorem envBound44722 : H12AffineFastState.Bounded env44722 := by
  intro p hp
  have h : env44722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44721_44722 : H12AffineEnvironment.transform 7 117 env44721 = env44722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44721 == env44722) = true)

theorem identity44722 : scanCanonicalize (H12AffineFastState.compose env44722 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 5236) := by decide +kernel

theorem selectedBound44722 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env44723 : List Nat := [2,4,8,16,32,64,128,117,512,1024,2048,4096,240,5236,217,115,5356,2264,1024,216,4161,33,17,2,120,64,2264,5220,4097,2184,1193,32,117,33,5293,649]

theorem envBound44723 : H12AffineFastState.Bounded env44723 := by
  intro p hp
  have h : env44723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44722_44723 : H12AffineEnvironment.transform 13 5236 env44722 = env44723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5236 env44722 == env44723) = true)

theorem identity44723 : scanCanonicalize (H12AffineFastState.compose env44723 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44723 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env44724 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,121,5236,80,115,5221,2129,1024,81,4161,33,17,2,120,64,2129,5220,4097,2049,1056,32,117,33,5156,512]

theorem envBound44724 : H12AffineFastState.Bounded env44724 := by
  intro p hp
  have h : env44724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44723_44724 : H12AffineEnvironment.transform 6 9 env44723 = env44724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44723 == env44724) = true)

theorem identity44724 : scanCanonicalize (H12AffineFastState.compose env44724 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44724 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44725 : List Nat := [2,4,8,16,0,64,9,85,512,1024,2048,4096,89,5204,80,83,5189,2129,1024,81,4161,1,17,2,88,64,2129,5188,4097,2049,1024,0,85,1,5124,512]

theorem envBound44725 : H12AffineFastState.Bounded env44725 := by
  intro p hp
  have h : env44725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44724_44725 : H12AffineEnvironment.transform 4 0 env44724 = env44725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44724 == env44725) = true)

theorem identity44725 : scanCanonicalize (H12AffineFastState.compose env44725 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44725 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44726 : List Nat := [2,4,8,16,0,64,9,85,512,1024,0,4096,89,5204,80,83,5189,81,1024,81,4161,1,17,2,88,64,81,5188,4097,1,1024,0,85,1,5124,512]

theorem envBound44726 : H12AffineFastState.Bounded env44726 := by
  intro p hp
  have h : env44726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44725_44726 : H12AffineEnvironment.transform 10 0 env44725 = env44726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env44725 == env44726) = true)

def env44727 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,157873,1024,32769,2097152,4194304,147593,2,8328,64,4450362,2196623,2233817,190520,246939,6383042,256,2327590,2319746,189261]

theorem envBound44727 : H12AffineFastState.Bounded env44727 := by
  intro p hp
  have h : env44727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44705_44727 : H12AffineEnvironment.transform 17 157873 env44705 = env44727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 157873 env44705 == env44727) = true)

theorem identity44727 : scanCanonicalize (H12AffineFastState.compose env44727 (packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44727 : packedSelected [1,3,10,17,19,21,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env44728 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,131072,157873,1024,8540,2097152,4194304,147593,2,8328,64,4409703,2172370,2233817,149861,222662,6383042,256,2303355,2319746,147984]

theorem envBound44728 : H12AffineFastState.Bounded env44728 := by
  intro p hp
  have h : env44728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44727_44728 : H12AffineEnvironment.transform 14 8541 env44727 = env44728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44727 == env44728) = true)

def env44729 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10401,1024,8540,2097152,4194304,153,2,8328,64,4262263,2172370,2119113,2421,75222,6383042,256,2188651,2172306,512]

theorem envBound44729 : H12AffineFastState.Bounded env44729 := by
  intro p hp
  have h : env44729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44728_44729 : H12AffineEnvironment.transform 16 16400 env44728 = env44729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env44728 == env44729) = true)

theorem identity44729 : scanCanonicalize (H12AffineFastState.compose env44729 (packedSelected [17,21] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44729 : packedSelected [17,21] rootPS < 2^1333 := by decide +kernel

def env44730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,2097152,4194304,16,2,8193,64,4262263,2172251,2118976,2421,75103,6382923,256,2188651,2172187,512]

theorem envBound44730 : H12AffineFastState.Bounded env44730 := by
  intro p hp
  have h : env44730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44729_44730 : H12AffineEnvironment.transform 6 9 env44729 = env44730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44729 == env44730) = true)

theorem identity44730 : scanCanonicalize (H12AffineFastState.compose env44730 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(20+1) ^^^ 91198) := by decide +kernel

theorem selectedBound44730 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,91198,4194304,16,2,8193,64,4262263,16741,78206,2421,75103,4194677,256,341,16677,512]

theorem envBound44731 : H12AffineFastState.Bounded env44731 := by
  intro p hp
  have h : env44731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44730_44731 : H12AffineEnvironment.transform 20 91198 env44730 = env44731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91198 env44730 == env44731) = true)

theorem identity44731 : scanCanonicalize (H12AffineFastState.compose env44731 (packedSelected [0,7,20] rootPS)) = affineNative (2^(21+1) ^^^ 372) := by decide +kernel

theorem selectedBound44731 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16400,10280,1024,8540,91198,372,16,2,8193,64,67587,16741,78206,2421,75103,1,256,341,16677,512]

theorem envBound44732 : H12AffineFastState.Bounded env44732 := by
  intro p hp
  have h : env44732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44731_44732 : H12AffineEnvironment.transform 21 372 env44731 = env44732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 372 env44731 == env44732) = true)

theorem identity44732 : scanCanonicalize (H12AffineFastState.compose env44732 (packedSelected [0,3,5,6,7,10,11,17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound44732 : packedSelected [0,3,5,6,7,10,11,17] rootPS < 2^1333 := by decide +kernel

def env44733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8202,16400,10280,1024,8540,17460,372,16,2,8193,64,10249,16741,4468,2421,1365,1,256,341,16677,512]

theorem envBound44733 : H12AffineFastState.Bounded env44733 := by
  intro p hp
  have h : env44733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44732_44733 : H12AffineEnvironment.transform 15 8202 env44732 = env44733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env44732 == env44733) = true)

theorem identity44733 : scanCanonicalize (H12AffineFastState.compose env44733 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44733 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44734 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,16384,8232,8202,16400,10280,1024,8233,17460,1,16,2,8193,64,10249,16400,4097,2048,1056,1,117,32,16464,512]

theorem envBound44734 : H12AffineFastState.Bounded env44734 := by
  intro p hp
  have h : env44734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44733_44734 : H12AffineEnvironment.transform 7 117 env44733 = env44734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44733 == env44734) = true)

theorem identity44734 : scanCanonicalize (H12AffineFastState.compose env44734 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44734 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44735 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,41,16384,1,35,16400,2049,1024,0,17460,1,16,2,40,64,2080,16400,4097,2048,1056,1,117,32,16464,512]

theorem envBound44735 : H12AffineFastState.Bounded env44735 := by
  intro p hp
  have h : env44735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44734_44735 : H12AffineEnvironment.transform 12 41 env44734 = env44735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44734 == env44735) = true)

theorem identity44735 : scanCanonicalize (H12AffineFastState.compose env44735 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound44735 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env44736 : List Nat := [2,4,8,16,32,64,9,117,42,1024,2048,4096,41,16384,1,35,16400,2049,1024,0,17460,1,16,2,40,64,2080,16400,4097,2048,1056,1,117,32,16464,42]

theorem envBound44736 : H12AffineFastState.Bounded env44736 := by
  intro p hp
  have h : env44736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44735_44736 : H12AffineEnvironment.transform 8 42 env44735 = env44736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env44735 == env44736) = true)

theorem identity44736 : scanCanonicalize (H12AffineFastState.compose env44736 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound44736 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44737 : List Nat := [2,4,8,16,32,64,9,117,42,1024,2048,4096,41,5237,1,35,5221,2049,1024,0,4161,1,16,2,40,64,2080,5221,4097,2048,1056,1,117,32,5157,42]

theorem envBound44737 : H12AffineFastState.Bounded env44737 := by
  intro p hp
  have h : env44737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44736_44737 : H12AffineEnvironment.transform 13 5237 env44736 = env44737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env44736 == env44737) = true)

def env44738 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10400,1024,8540,2097152,4194304,152,2,8328,64,4262262,2172370,2119112,2420,75223,6383042,256,2188650,2172307,513]

theorem envBound44738 : H12AffineFastState.Bounded env44738 := by
  intro p hp
  have h : env44738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44728_44738 : H12AffineEnvironment.transform 16 16401 env44728 = env44738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env44728 == env44738) = true)

def env44739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,2097152,4194304,16,2,8192,64,4262262,2172250,2118976,2420,75103,6382922,256,2188650,2172187,513]

theorem envBound44739 : H12AffineFastState.Bounded env44739 := by
  intro p hp
  have h : env44739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44738_44739 : H12AffineEnvironment.transform 6 8 env44738 = env44739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44738 == env44739) = true)

theorem identity44739 : scanCanonicalize (H12AffineFastState.compose env44739 (packedSelected [0,7,20] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound44739 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env44740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10280,1024,8540,91466,4194304,16,2,8192,64,4262262,16400,77834,2420,75103,4194304,256,32,16465,513]

theorem envBound44740 : H12AffineFastState.Bounded env44740 := by
  intro p hp
  have h : env44740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44739_44740 : H12AffineEnvironment.transform 20 91466 env44739 = env44740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env44739 == env44740) = true)

theorem identity44740 : scanCanonicalize (H12AffineFastState.compose env44740 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(15+1) ^^^ 343) := by decide +kernel

theorem selectedBound44740 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env44741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,343,16401,10280,1024,8540,25629,4194304,16,2,8192,64,4196385,16400,12637,2420,9224,4194304,256,32,16465,513]

theorem envBound44741 : H12AffineFastState.Bounded env44741 := by
  intro p hp
  have h : env44741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44740_44741 : H12AffineEnvironment.transform 15 343 env44740 = env44741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 343 env44740 == env44741) = true)

theorem identity44741 : scanCanonicalize (H12AffineFastState.compose env44741 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound44741 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,16384,1,343,16401,2420,1024,0,17729,4194304,16,2,348,64,4196385,16400,4097,2420,1364,4194304,256,32,16465,513]

theorem envBound44742 : H12AffineFastState.Bounded env44742 := by
  intro p hp
  have h : env44742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44741_44742 : H12AffineEnvironment.transform 12 348 env44741 = env44742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env44741 == env44742) = true)

theorem identity44742 : scanCanonicalize (H12AffineFastState.compose env44742 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44742 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44743 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1024,0,17680,4194304,16,2,269,17,4196385,16400,4097,2341,1285,4194304,256,32,16384,513]

theorem envBound44743 : H12AffineFastState.Bounded env44743 := by
  intro p hp
  have h : env44743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44742_44743 : H12AffineEnvironment.transform 5 17 env44742 = env44743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44742 == env44743) = true)

theorem identity44743 : scanCanonicalize (H12AffineFastState.compose env44743 (packedSelected [5,8] rootPS)) = affineNative (2^(21+1) ^^^ 21509) := by decide +kernel

theorem selectedBound44743 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env44744 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,1,262,16401,2341,1024,0,17680,21509,16,2,269,17,23588,16400,4097,2341,1285,21509,256,32,16384,513]

theorem envBound44744 : H12AffineFastState.Bounded env44744 := by
  intro p hp
  have h : env44744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44743_44744 : H12AffineEnvironment.transform 21 21509 env44743 = env44744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21509 env44743 == env44744) = true)

theorem identity44744 : scanCanonicalize (H12AffineFastState.compose env44744 (packedSelected [0,4,7,9] rootPS)) = affineNative (2^(13+1) ^^^ 5156) := by decide +kernel

theorem selectedBound44744 : packedSelected [0,4,7,9] rootPS < 2^1333 := by decide +kernel

def env44745 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,5156,1,262,5173,2341,1024,0,4404,33,16,2,269,17,2048,5172,4097,2341,1285,33,256,32,5156,513]

theorem envBound44745 : H12AffineFastState.Bounded env44745 := by
  intro p hp
  have h : env44745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44744_44745 : H12AffineEnvironment.transform 13 5156 env44744 = env44745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5156 env44744 == env44745) = true)

def env44746 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3888,269,2836,1,262,2821,2341,1024,0,3588,33,16,2,269,17,2048,2820,3889,2341,1285,33,256,32,2836,513]

theorem envBound44746 : H12AffineFastState.Bounded env44746 := by
  intro p hp
  have h : env44746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44745_44746 : H12AffineEnvironment.transform 11 3888 env44745 = env44746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3888 env44745 == env44746) = true)

def env44747 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,48,269,1044,1,262,1029,1573,1024,0,260,33,16,2,269,17,1792,1028,49,1573,1285,33,256,32,1044,513]

theorem envBound44747 : H12AffineFastState.Bounded env44747 := by
  intro p hp
  have h : env44747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44746_44747 : H12AffineEnvironment.transform 10 1792 env44746 = env44747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env44746 == env44747) = true)

theorem identity44747 : scanCanonicalize (H12AffineFastState.compose env44747 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 549) := by decide +kernel

theorem selectedBound44747 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44748 : List Nat := [2,4,8,16,32,17,8,256,512,549,293,48,269,561,1,262,544,0,549,0,260,33,16,2,269,17,293,545,49,0,800,33,256,32,561,513]

theorem envBound44748 : H12AffineFastState.Bounded env44748 := by
  intro p hp
  have h : env44748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44747_44748 : H12AffineEnvironment.transform 9 549 env44747 = env44748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 549 env44747 == env44748) = true)

def env44749 : List Nat := [2,4,8,16,32,17,8,256,16,53,293,48,269,33,1,262,48,0,53,0,260,33,16,2,269,17,293,49,49,0,304,33,256,32,33,17]

theorem envBound44749 : H12AffineFastState.Bounded env44749 := by
  intro p hp
  have h : env44749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44748_44749 : H12AffineEnvironment.transform 8 16 env44748 = env44749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 16 env44748 == env44749) = true)

theorem identity44749 : scanCanonicalize (H12AffineFastState.compose env44749 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44749 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44750 : List Nat := [2,4,8,16,32,17,8,4,16,53,33,48,9,33,1,2,48,0,53,0,0,33,16,2,9,17,33,49,49,0,52,33,4,32,33,17]

theorem envBound44750 : H12AffineFastState.Bounded env44750 := by
  intro p hp
  have h : env44750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44749_44750 : H12AffineEnvironment.transform 7 4 env44749 = env44750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44749 == env44750) = true)

def leafEnv44750 : List Nat := [2,4,8,16,32,17,8,4,16,53,33,48,9,33,1,2,48,0,53,0,0,33,16,2,52,9,1,17,33,49,49,0,52,33,4,32,4,2,33,17,1,0,0]

def active44750 : List Nat := [0,1,2,3,4]

def tree44750 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44750 : H12WitnessSearch.Good tree44750 := H12GlobalWitnessIndex.good

theorem leafIdentity44750 : H12AffineFastState.composeSystem env44750 rootObs = leafEnv44750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44750 rootObs == leafEnv44750) = true)

theorem terminalChecked44750 : H12PackedTerminal.terminalCheckFast leafEnv44750 active44750 tree44750 = true := by decide +kernel

def env44751 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,48,269,32,1,262,49,0,52,0,260,33,16,2,269,17,293,48,49,0,305,33,256,32,32,16]

theorem envBound44751 : H12AffineFastState.Bounded env44751 := by
  intro p hp
  have h : env44751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44748_44751 : H12AffineEnvironment.transform 8 17 env44748 = env44751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44748 == env44751) = true)

theorem identity44751 : scanCanonicalize (H12AffineFastState.compose env44751 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44751 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44752 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,269,32,1,262,43,0,46,0,260,33,10,2,269,11,293,42,43,0,299,33,256,32,32,10]

theorem envBound44752 : H12AffineFastState.Bounded env44752 := by
  intro p hp
  have h : env44752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44751_44752 : H12AffineEnvironment.transform 3 10 env44751 = env44752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44751 == env44752) = true)

def leafEnv44752 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,42,269,32,1,262,43,0,46,0,260,33,10,2,299,269,1,11,293,42,43,0,299,33,256,32,4,262,32,10,1,260,0]

def active44752 : List Nat := [0,1,2,4,7]

def tree44752 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44752 : H12WitnessSearch.Good tree44752 := H12GlobalWitnessIndex.good

theorem leafIdentity44752 : H12AffineFastState.composeSystem env44752 rootObs = leafEnv44752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44752 rootObs == leafEnv44752) = true)

theorem terminalChecked44752 : H12PackedTerminal.terminalCheckFast leafEnv44752 active44752 tree44752 = true := by decide +kernel

def env44753 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,49,269,1045,1,262,1028,1572,1024,0,261,33,16,2,269,17,1793,1029,48,1572,1285,33,256,32,1045,513]

theorem envBound44753 : H12AffineFastState.Bounded env44753 := by
  intro p hp
  have h : env44753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44746_44753 : H12AffineEnvironment.transform 10 1793 env44746 = env44753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env44746 == env44753) = true)

theorem identity44753 : scanCanonicalize (H12AffineFastState.compose env44753 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 309) := by decide +kernel

theorem selectedBound44753 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44754 : List Nat := [2,4,8,16,32,17,8,256,309,1024,1076,49,269,1045,1,262,1028,1297,1024,0,261,33,16,2,269,17,1076,1029,48,1297,1285,33,256,32,1045,308]

theorem envBound44754 : H12AffineFastState.Bounded env44754 := by
  intro p hp
  have h : env44754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44753_44754 : H12AffineEnvironment.transform 8 309 env44753 = env44754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env44753 == env44754) = true)

def env44755 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,49,269,33,1,262,48,293,52,0,261,33,16,2,269,17,0,49,48,293,305,33,256,32,33,308]

theorem envBound44755 : H12AffineFastState.Bounded env44755 := by
  intro p hp
  have h : env44755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44754_44755 : H12AffineEnvironment.transform 9 52 env44754 = env44755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44754 == env44755) = true)

theorem identity44755 : scanCanonicalize (H12AffineFastState.compose env44755 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44755 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44756 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,269,33,1,262,43,293,47,0,261,33,11,2,269,10,0,42,43,293,298,33,256,32,33,303]

theorem envBound44756 : H12AffineFastState.Bounded env44756 := by
  intro p hp
  have h : env44756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44755_44756 : H12AffineEnvironment.transform 3 11 env44755 = env44756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44755 == env44756) = true)

def leafEnv44756 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,42,269,33,1,262,43,293,47,0,261,33,11,2,298,269,1,10,0,42,43,293,298,33,256,32,4,262,33,303,1,261,0]

def active44756 : List Nat := [0,1,2,4,7]

def tree44756 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44756 : H12WitnessSearch.Good tree44756 := H12GlobalWitnessIndex.good

theorem leafIdentity44756 : H12AffineFastState.composeSystem env44756 rootObs = leafEnv44756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44756 rootObs == leafEnv44756) = true)

theorem terminalChecked44756 : H12PackedTerminal.terminalCheckFast leafEnv44756 active44756 tree44756 = true := by decide +kernel

def env44757 : List Nat := [2,4,8,16,32,17,8,256,309,53,1,49,269,32,1,262,49,292,53,0,261,33,16,2,269,17,1,48,48,292,304,33,256,32,32,308]

theorem envBound44757 : H12AffineFastState.Bounded env44757 := by
  intro p hp
  have h : env44757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44754_44757 : H12AffineEnvironment.transform 9 53 env44754 = env44757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44754 == env44757) = true)

theorem identity44757 : scanCanonicalize (H12AffineFastState.compose env44757 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44757 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44758 : List Nat := [2,4,8,16,1,17,8,256,276,20,1,16,269,1,1,262,16,261,20,0,261,0,16,2,269,17,1,17,17,261,273,0,256,1,1,277]

theorem envBound44758 : H12AffineFastState.Bounded env44758 := by
  intro p hp
  have h : env44758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44757_44758 : H12AffineEnvironment.transform 4 1 env44757 = env44758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44757 == env44758) = true)

def leafEnv44758 : List Nat := [2,4,8,16,1,17,8,256,276,20,1,16,269,1,1,262,16,261,20,0,261,0,16,2,273,269,1,17,1,17,17,261,273,0,256,1,4,262,1,277,1,261,0]

def active44758 : List Nat := [0,1,2,3,7]

def tree44758 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44758 : H12WitnessSearch.Good tree44758 := H12GlobalWitnessIndex.good

theorem leafIdentity44758 : H12AffineFastState.composeSystem env44758 rootObs = leafEnv44758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44758 rootObs == leafEnv44758) = true)

theorem terminalChecked44758 : H12PackedTerminal.terminalCheckFast leafEnv44758 active44758 tree44758 = true := by decide +kernel

def env44759 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,3889,269,2837,1,262,2820,2341,1024,0,3589,33,16,2,269,17,2048,2821,3888,2341,1285,33,256,32,2837,513]

theorem envBound44759 : H12AffineFastState.Bounded env44759 := by
  intro p hp
  have h : env44759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44745_44759 : H12AffineEnvironment.transform 11 3889 env44745 = env44759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env44745 == env44759) = true)

def env44760 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1792,49,269,1045,1,262,1028,1573,1024,0,261,33,16,2,269,17,1792,1029,48,1573,1285,33,256,32,1045,513]

theorem envBound44760 : H12AffineFastState.Bounded env44760 := by
  intro p hp
  have h : env44760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44759_44760 : H12AffineEnvironment.transform 10 1792 env44759 = env44760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1792 env44759 == env44760) = true)

theorem identity44760 : scanCanonicalize (H12AffineFastState.compose env44760 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 17) := by decide +kernel

theorem selectedBound44760 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44761 : List Nat := [2,4,8,16,32,17,8,256,17,1024,1297,49,269,1045,1,262,1028,1076,1024,0,261,33,16,2,269,17,1297,1029,48,1076,1285,33,256,32,1045,16]

theorem envBound44761 : H12AffineFastState.Bounded env44761 := by
  intro p hp
  have h : env44761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44760_44761 : H12AffineEnvironment.transform 8 17 env44760 = env44761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 17 env44760 == env44761) = true)

def env44762 : List Nat := [2,4,8,16,32,17,8,256,17,52,293,49,269,33,1,262,48,0,52,0,261,33,16,2,269,17,293,49,48,0,305,33,256,32,33,16]

theorem envBound44762 : H12AffineFastState.Bounded env44762 := by
  intro p hp
  have h : env44762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44761_44762 : H12AffineEnvironment.transform 9 52 env44761 = env44762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44761 == env44762) = true)

theorem identity44762 : scanCanonicalize (H12AffineFastState.compose env44762 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 10) := by decide +kernel

theorem selectedBound44762 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44763 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,269,33,1,262,42,0,46,0,261,33,10,2,269,11,293,43,42,0,299,33,256,32,33,10]

theorem envBound44763 : H12AffineFastState.Bounded env44763 := by
  intro p hp
  have h : env44763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44762_44763 : H12AffineEnvironment.transform 3 10 env44762 = env44763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 10 env44762 == env44763) = true)

def leafEnv44763 : List Nat := [2,4,8,10,32,11,8,256,11,46,293,43,269,33,1,262,42,0,46,0,261,33,10,2,299,269,1,11,293,43,42,0,299,33,256,32,4,262,33,10,1,261,0]

def active44763 : List Nat := [0,1,2,4,7]

def tree44763 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44763 : H12WitnessSearch.Good tree44763 := H12GlobalWitnessIndex.good

theorem leafIdentity44763 : H12AffineFastState.composeSystem env44763 rootObs = leafEnv44763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44763 rootObs == leafEnv44763) = true)

theorem terminalChecked44763 : H12PackedTerminal.terminalCheckFast leafEnv44763 active44763 tree44763 = true := by decide +kernel

def env44764 : List Nat := [2,4,8,16,32,17,8,256,17,53,292,49,269,32,1,262,49,1,53,0,261,33,16,2,269,17,292,48,48,1,304,33,256,32,32,16]

theorem envBound44764 : H12AffineFastState.Bounded env44764 := by
  intro p hp
  have h : env44764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44761_44764 : H12AffineEnvironment.transform 9 53 env44761 = env44764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env44761 == env44764) = true)

theorem identity44764 : scanCanonicalize (H12AffineFastState.compose env44764 (packedSelected [1] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44764 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44765 : List Nat := [2,4,8,16,32,17,8,4,17,53,32,49,9,32,1,2,49,1,53,0,1,33,16,2,9,17,32,48,48,1,52,33,4,32,32,16]

theorem envBound44765 : H12AffineFastState.Bounded env44765 := by
  intro p hp
  have h : env44765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44764_44765 : H12AffineEnvironment.transform 7 4 env44764 = env44765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44764 == env44765) = true)

def leafEnv44765 : List Nat := [2,4,8,16,32,17,8,4,17,53,32,49,9,32,1,2,49,1,53,0,1,33,16,2,52,9,1,17,32,48,48,1,52,33,4,32,4,2,32,16,1,1,0]

def active44765 : List Nat := [0,1,2,3,4]

def tree44765 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44765 : H12WitnessSearch.Good tree44765 := H12GlobalWitnessIndex.good

theorem leafIdentity44765 : H12AffineFastState.composeSystem env44765 rootObs = leafEnv44765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44765 rootObs == leafEnv44765) = true)

theorem terminalChecked44765 : H12PackedTerminal.terminalCheckFast leafEnv44765 active44765 tree44765 = true := by decide +kernel

def env44766 : List Nat := [2,4,8,16,32,17,8,256,512,1024,1793,48,269,1044,1,262,1029,1572,1024,0,260,33,16,2,269,17,1793,1028,49,1572,1285,33,256,32,1044,513]

theorem envBound44766 : H12AffineFastState.Bounded env44766 := by
  intro p hp
  have h : env44766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44759_44766 : H12AffineEnvironment.transform 10 1793 env44759 = env44766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1793 env44759 == env44766) = true)

theorem identity44766 : scanCanonicalize (H12AffineFastState.compose env44766 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 769) := by decide +kernel

theorem selectedBound44766 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44767 : List Nat := [2,4,8,16,32,17,8,256,512,769,0,48,269,789,1,262,772,293,769,0,260,33,16,2,269,17,0,773,49,293,516,33,256,32,789,513]

theorem envBound44767 : H12AffineFastState.Bounded env44767 := by
  intro p hp
  have h : env44767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44766_44767 : H12AffineEnvironment.transform 9 769 env44766 = env44767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 769 env44766 == env44767) = true)

def env44768 : List Nat := [2,4,8,16,32,17,8,256,308,53,0,48,269,33,1,262,48,293,53,0,260,33,16,2,269,17,0,49,49,293,304,33,256,32,33,309]

theorem envBound44768 : H12AffineFastState.Bounded env44768 := by
  intro p hp
  have h : env44768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44767_44768 : H12AffineEnvironment.transform 8 308 env44767 = env44768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 308 env44767 == env44768) = true)

theorem identity44768 : scanCanonicalize (H12AffineFastState.compose env44768 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound44768 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44769 : List Nat := [2,4,8,16,1,17,8,256,277,20,0,17,269,0,1,262,17,260,20,0,260,0,16,2,269,17,0,16,16,260,273,0,256,1,0,276]

theorem envBound44769 : H12AffineFastState.Bounded env44769 := by
  intro p hp
  have h : env44769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44768_44769 : H12AffineEnvironment.transform 4 1 env44768 = env44769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env44768 == env44769) = true)

def leafEnv44769 : List Nat := [2,4,8,16,1,17,8,256,277,20,0,17,269,0,1,262,17,260,20,0,260,0,16,2,273,269,1,17,0,16,16,260,273,0,256,1,4,262,0,276,1,260,0]

def active44769 : List Nat := [0,1,2,3,7]

def tree44769 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44769 : H12WitnessSearch.Good tree44769 := H12GlobalWitnessIndex.good

theorem leafIdentity44769 : H12AffineFastState.composeSystem env44769 rootObs = leafEnv44769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44769 rootObs == leafEnv44769) = true)

theorem terminalChecked44769 : H12PackedTerminal.terminalCheckFast leafEnv44769 active44769 tree44769 = true := by decide +kernel

def env44770 : List Nat := [2,4,8,16,32,17,8,256,309,52,0,48,269,32,1,262,49,293,52,0,260,33,16,2,269,17,0,48,49,293,305,33,256,32,32,308]

theorem envBound44770 : H12AffineFastState.Bounded env44770 := by
  intro p hp
  have h : env44770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44767_44770 : H12AffineEnvironment.transform 8 309 env44767 = env44770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 309 env44767 == env44770) = true)

theorem identity44770 : scanCanonicalize (H12AffineFastState.compose env44770 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound44770 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44771 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,269,32,1,262,42,293,47,0,260,33,11,2,269,10,0,43,42,293,298,33,256,32,32,303]

theorem envBound44771 : H12AffineFastState.Bounded env44771 := by
  intro p hp
  have h : env44771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44770_44771 : H12AffineEnvironment.transform 3 11 env44770 = env44771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env44770 == env44771) = true)

def leafEnv44771 : List Nat := [2,4,8,11,32,10,8,256,302,47,0,43,269,32,1,262,42,293,47,0,260,33,11,2,298,269,1,10,0,43,42,293,298,33,256,32,4,262,32,303,1,260,0]

def active44771 : List Nat := [0,1,2,4,7]

def tree44771 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood44771 : H12WitnessSearch.Good tree44771 := H12GlobalWitnessIndex.good

theorem leafIdentity44771 : H12AffineFastState.composeSystem env44771 rootObs = leafEnv44771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env44771 rootObs == leafEnv44771) = true)

theorem terminalChecked44771 : H12PackedTerminal.terminalCheckFast leafEnv44771 active44771 tree44771 = true := by decide +kernel

def env44772 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,16401,10281,1024,8540,2097152,4194304,17,2,8193,64,4262262,2172251,2118977,2420,75102,6382923,256,2188650,2172186,513]

theorem envBound44772 : H12AffineFastState.Bounded env44772 := by
  intro p hp
  have h : env44772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44738_44772 : H12AffineEnvironment.transform 6 9 env44738 = env44772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44738 == env44772) = true)

theorem identity44772 : scanCanonicalize (H12AffineFastState.compose env44772 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44772 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env44773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1024,8540,2097152,4194304,17,2,8193,64,4204925,2098512,2118977,2420,1365,6309184,256,2114913,2098449,513]

theorem envBound44773 : H12AffineFastState.Bounded env44773 := by
  intro p hp
  have h : env44773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44772_44773 : H12AffineEnvironment.transform 15 8203 env44772 = env44773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44772 == env44773) = true)

theorem identity44773 : scanCanonicalize (H12AffineFastState.compose env44773 (packedSelected [3,5,10] rootPS)) = affineNative (2^(21+1) ^^^ 20528) := by decide +kernel

theorem selectedBound44773 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16401,10281,1024,8540,2097152,20528,17,2,8193,64,31053,2098512,2118977,2420,1365,2102640,256,2114913,2098449,513]

theorem envBound44774 : H12AffineFastState.Bounded env44774 := by
  intro p hp
  have h : env44774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44773_44774 : H12AffineEnvironment.transform 21 20528 env44773 = env44774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 20528 env44773 == env44774) = true)

theorem identity44774 : scanCanonicalize (H12AffineFastState.compose env44774 (packedSelected [4,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 10589) := by decide +kernel

theorem selectedBound44774 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env44775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,10589,8541,8203,10572,10281,1024,8540,2097152,14701,17,2,8193,64,4112,2098512,2112540,2420,1365,2102640,256,2108476,2098449,513]

theorem envBound44775 : H12AffineFastState.Bounded env44775 := by
  intro p hp
  have h : env44775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44774_44775 : H12AffineEnvironment.transform 13 10589 env44774 = env44775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 10589 env44774 == env44775) = true)

theorem identity44775 : scanCanonicalize (H12AffineFastState.compose env44775 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 5456) := by decide +kernel

theorem selectedBound44775 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44776 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,10589,8541,8203,10572,10281,1024,8540,5456,14701,17,2,8193,64,4112,4096,10572,2420,1365,32,256,14700,4161,513]

theorem envBound44776 : H12AffineFastState.Bounded env44776 := by
  intro p hp
  have h : env44776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44775_44776 : H12AffineEnvironment.transform 20 5456 env44775 = env44776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 5456 env44775 == env44776) = true)

theorem identity44776 : scanCanonicalize (H12AffineFastState.compose env44776 (packedSelected [2,6] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound44776 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44777 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,8192,10589,8541,8203,10572,10281,1024,8540,3392,8573,17,2,8193,64,2048,2064,10572,2420,1365,32,256,8572,2129,513]

theorem envBound44777 : H12AffineFastState.Bounded env44777 := by
  intro p hp
  have h : env44777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44776_44777 : H12AffineEnvironment.transform 11 2064 env44776 = env44777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env44776 == env44777) = true)

theorem identity44777 : scanCanonicalize (H12AffineFastState.compose env44777 (packedSelected [1,3,5,8,12] rootPS)) = affineNative (2^(12+1) ^^^ 1385) := by decide +kernel

theorem selectedBound44777 : packedSelected [1,3,5,8,12] rootPS < 2^1333 := by decide +kernel

def env44778 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,1385,3124,1076,1378,3109,3392,1024,1077,3392,1044,17,2,1384,64,2048,2064,3109,2420,1365,32,256,1045,2129,513]

theorem envBound44778 : H12AffineFastState.Bounded env44778 := by
  intro p hp
  have h : env44778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44777_44778 : H12AffineEnvironment.transform 12 1385 env44777 = env44778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1385 env44777 == env44778) = true)

theorem identity44778 : scanCanonicalize (H12AffineFastState.compose env44778 (packedSelected [1,3,4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound44778 : packedSelected [1,3,4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env44779 : List Nat := [2,4,8,16,32,64,9,256,512,52,2048,2064,349,2048,0,342,2065,2420,52,1,2420,32,17,2,348,64,2048,2064,2065,2420,353,32,256,33,2129,513]

theorem envBound44779 : H12AffineFastState.Bounded env44779 := by
  intro p hp
  have h : env44779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44778_44779 : H12AffineEnvironment.transform 9 52 env44778 = env44779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env44778 == env44779) = true)

theorem identity44779 : scanCanonicalize (H12AffineFastState.compose env44779 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound44779 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44780 : List Nat := [2,4,8,16,32,64,9,256,293,52,2048,2064,349,2048,0,342,2065,2420,52,1,2420,32,17,2,348,64,2048,2064,2065,2420,353,32,256,33,2129,292]

theorem envBound44780 : H12AffineFastState.Bounded env44780 := by
  intro p hp
  have h : env44780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44779_44780 : H12AffineEnvironment.transform 8 293 env44779 = env44780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env44779 == env44780) = true)

theorem identity44780 : scanCanonicalize (H12AffineFastState.compose env44780 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound44780 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env44781 : List Nat := [2,4,8,16,32,64,9,4,33,52,2048,2064,89,2048,0,82,2065,2160,52,1,2160,32,17,2,88,64,2048,2064,2065,2160,101,32,4,33,2129,32]

theorem envBound44781 : H12AffineFastState.Bounded env44781 := by
  intro p hp
  have h : env44781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44780_44781 : H12AffineEnvironment.transform 7 4 env44780 = env44781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env44780 == env44781) = true)

theorem identity44781 : scanCanonicalize (H12AffineFastState.compose env44781 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 48) := by decide +kernel

theorem selectedBound44781 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env44782 : List Nat := [2,4,8,16,32,64,9,4,33,52,48,32,89,48,0,82,33,64,52,1,64,32,17,2,88,64,48,32,33,64,101,32,4,33,97,32]

theorem envBound44782 : H12AffineFastState.Bounded env44782 := by
  intro p hp
  have h : env44782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44781_44782 : H12AffineEnvironment.transform 10 48 env44781 = env44782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 48 env44781 == env44782) = true)

theorem identity44782 : scanCanonicalize (H12AffineFastState.compose env44782 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44782 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44783 : List Nat := [2,4,8,16,0,64,9,4,1,20,16,0,89,16,0,82,1,64,20,1,64,0,17,2,88,64,16,0,1,64,69,0,4,1,65,0]

theorem envBound44783 : H12AffineFastState.Bounded env44783 := by
  intro p hp
  have h : env44783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44782_44783 : H12AffineEnvironment.transform 4 0 env44782 = env44783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44782 == env44783) = true)

theorem identity44783 : scanCanonicalize (H12AffineFastState.compose env44783 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound44783 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44784 : List Nat := [2,4,8,16,0,1,9,4,1,20,16,0,24,16,0,19,1,1,20,1,1,0,17,2,25,1,16,0,1,1,4,0,4,1,0,0]

theorem envBound44784 : H12AffineFastState.Bounded env44784 := by
  intro p hp
  have h : env44784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44783_44784 : H12AffineEnvironment.transform 5 1 env44783 = env44784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env44783 == env44784) = true)

def env44785 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,64,29868033,18973836,10507600,8830977,25265168,23160256,257,27378860,27337993,25207751]

theorem envBound44785 : H12AffineFastState.Bounded env44785 := by
  intro p hp
  have h : env44785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44623_44785 : H12AffineEnvironment.transform 18 1025 env44623 = env44785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env44623 == env44785) = true)

theorem identity44785 : scanCanonicalize (H12AffineFastState.compose env44785 (packedSelected [13] rootPS)) = affineNative (2^(22+1) ^^^ 254083) := by decide +kernel

theorem selectedBound44785 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env44786 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,254083,16777216,8328,64,21241986,18973836,2340307,336002,16934035,23160256,257,19014703,19056010,16991044]

theorem envBound44786 : H12AffineFastState.Bounded env44786 := by
  intro p hp
  have h : env44786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44785_44786 : H12AffineEnvironment.transform 22 254083 env44785 = env44786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 254083 env44785 == env44786) = true)

def env44787 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254083,16777216,8328,64,16959642,18973836,2340307,336002,16934035,19369432,257,19014703,19056010,16991044]

theorem envBound44787 : H12AffineFastState.Bounded env44787 := by
  intro p hp
  have h : env44787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44786_44787 : H12AffineEnvironment.transform 21 452632 env44786 = env44787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 452632 env44786 == env44787) = true)

def env44788 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254083,243088,8328,64,97546,2240796,2340307,336002,119043,2373704,257,2199999,2191386,63188]

theorem envBound44788 : H12AffineFastState.Bounded env44788 := by
  intro p hp
  have h : env44788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44787_44788 : H12AffineEnvironment.transform 23 243088 env44787 = env44788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243088 env44787 == env44788) = true)

def env44789 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254083,243088,8328,64,97546,139612,238995,336002,119043,272392,257,98815,90202,63188]

theorem envBound44789 : H12AffineFastState.Bounded env44789 := by
  intro p hp
  have h : env44789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44788_44789 : H12AffineEnvironment.transform 20 4160 env44788 = env44789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44788 == env44789) = true)

theorem identity44789 : scanCanonicalize (H12AffineFastState.compose env44789 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound44789 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44790 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,70727,262144,1025,32769,4160,392287,62660,41431,8328,64,97546,79131,45524,336002,119043,272392,257,98815,90202,63188]

theorem envBound44790 : H12AffineFastState.Bounded env44790 := by
  intro p hp
  have h : env44790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44789_44790 : H12AffineEnvironment.transform 16 70727 env44789 = env44790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env44789 == env44790) = true)

theorem identity44790 : scanCanonicalize (H12AffineFastState.compose env44790 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound44790 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env44791 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,70727,262144,1025,29908,4160,329866,17,21762,8328,64,97546,79131,17665,336002,75222,272392,257,95530,90202,513]

theorem envBound44791 : H12AffineFastState.Bounded env44791 := by
  intro p hp
  have h : env44791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44790_44791 : H12AffineEnvironment.transform 14 29909 env44790 = env44791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env44790 == env44791) = true)

def env44792 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70727,262144,1025,8660,4160,329866,17,2,8328,64,75786,79131,4097,336002,75222,272392,257,73770,79194,513]

theorem envBound44792 : H12AffineFastState.Bounded env44792 := by
  intro p hp
  have h : env44792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44791_44792 : H12AffineEnvironment.transform 13 5376 env44791 = env44792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44791 == env44792) = true)

theorem identity44792 : scanCanonicalize (H12AffineFastState.compose env44792 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44792 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44793 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,70727,10280,1025,8660,4160,73890,17,2,8328,64,75786,79131,4097,67754,75222,32,257,73770,79194,513]

theorem envBound44793 : H12AffineFastState.Bounded env44793 := by
  intro p hp
  have h : env44793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44792_44793 : H12AffineEnvironment.transform 17 10280 env44792 = env44793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44792 == env44793) = true)

theorem identity44793 : scanCanonicalize (H12AffineFastState.compose env44793 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44793 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env44794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,70727,10280,1025,8541,4160,73771,17,2,8193,64,75786,79131,4097,67619,75103,32,257,73770,79194,513]

theorem envBound44794 : H12AffineFastState.Bounded env44794 := by
  intro p hp
  have h : env44794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44793_44794 : H12AffineEnvironment.transform 6 9 env44793 = env44794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44793 == env44794) = true)

theorem identity44794 : scanCanonicalize (H12AffineFastState.compose env44794 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44794 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44795 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,1,65536,70727,2421,1025,0,4160,65910,17,2,348,64,67927,70726,4097,67619,66562,32,257,65911,70663,513]

theorem envBound44795 : H12AffineFastState.Bounded env44795 := by
  intro p hp
  have h : env44795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44794_44795 : H12AffineEnvironment.transform 12 349 env44794 = env44795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44794 == env44795) = true)

theorem identity44795 : scanCanonicalize (H12AffineFastState.compose env44795 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound44795 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env44796 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,269,5376,1,65536,70679,2341,1025,0,4112,65830,17,2,268,16,67847,70678,4097,67619,66562,32,257,65831,70663,513]

theorem envBound44796 : H12AffineFastState.Bounded env44796 := by
  intro p hp
  have h : env44796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44795_44796 : H12AffineEnvironment.transform 5 16 env44795 = env44796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env44795 == env44796) = true)

def env44797 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70727,262144,1025,8661,4160,329866,17,3,8328,64,75787,79131,4096,336002,75222,272392,257,73771,79195,513]

theorem envBound44797 : H12AffineFastState.Bounded env44797 := by
  intro p hp
  have h : env44797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44791_44797 : H12AffineEnvironment.transform 13 5377 env44791 = env44797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env44791 == env44797) = true)

theorem identity44797 : scanCanonicalize (H12AffineFastState.compose env44797 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10401) := by decide +kernel

theorem selectedBound44797 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44798 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,70727,10401,1025,8661,4160,73771,17,3,8328,64,75787,79131,4096,67619,75222,169,257,73771,79195,513]

theorem envBound44798 : H12AffineFastState.Bounded env44798 := by
  intro p hp
  have h : env44798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44797_44798 : H12AffineEnvironment.transform 17 10401 env44797 = env44798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env44797 == env44798) = true)

theorem identity44798 : scanCanonicalize (H12AffineFastState.compose env44798 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44798 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env44799 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5377,217,65536,70727,2476,1025,216,4160,65830,17,3,389,64,67846,70678,4096,67619,66779,169,257,65830,70742,513]

theorem envBound44799 : H12AffineFastState.Bounded env44799 := by
  intro p hp
  have h : env44799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44798_44799 : H12AffineEnvironment.transform 12 269 env44798 = env44799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44798 == env44799) = true)

theorem identity44799 : scanCanonicalize (H12AffineFastState.compose env44799 (packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound44799 : packedSelected [0,1,4,7,8,9,10,11,15,20] rootPS < 2^1333 := by decide +kernel

def env44800 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5377,217,342,5393,2476,1025,216,4160,112,17,3,389,64,2128,5440,4096,2421,1421,169,257,112,5376,513]

theorem envBound44800 : H12AffineFastState.Bounded env44800 := by
  intro p hp
  have h : env44800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44799_44800 : H12AffineEnvironment.transform 15 342 env44799 = env44800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env44799 == env44800) = true)

theorem identity44800 : scanCanonicalize (H12AffineFastState.compose env44800 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44800 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env44801 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,269,5377,136,263,5393,2476,1025,137,4113,33,17,3,389,17,2049,5393,4096,2340,1421,169,257,33,5376,513]

theorem envBound44801 : H12AffineFastState.Bounded env44801 := by
  intro p hp
  have h : env44801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44800_44801 : H12AffineEnvironment.transform 5 17 env44800 = env44801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44800 == env44801) = true)

theorem identity44801 : scanCanonicalize (H12AffineFastState.compose env44801 (packedSelected [2,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 3464) := by decide +kernel

theorem selectedBound44801 : packedSelected [2,4,7] rootPS < 2^1333 := by decide +kernel

def env44802 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,3464,269,2185,136,263,2201,2476,1025,137,3481,33,17,3,389,17,2049,2201,3464,2340,1421,169,257,33,2184,513]

theorem envBound44802 : H12AffineFastState.Bounded env44802 := by
  intro p hp
  have h : env44802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44801_44802 : H12AffineEnvironment.transform 11 3464 env44801 = env44802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3464 env44801 == env44802) = true)

theorem identity44802 : scanCanonicalize (H12AffineFastState.compose env44802 (packedSelected [0,1,2,3,4] rootPS)) = affineNative (2^(10+1) ^^^ 956) := by decide +kernel

theorem selectedBound44802 : packedSelected [0,1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env44803 : List Nat := [2,4,8,16,32,17,128,256,512,1024,956,1588,269,821,136,263,805,528,1025,137,1573,33,17,3,389,17,957,805,1588,664,1421,169,257,33,820,513]

theorem envBound44803 : H12AffineFastState.Bounded env44803 := by
  intro p hp
  have h : env44803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44802_44803 : H12AffineEnvironment.transform 10 956 env44802 = env44803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 956 env44802 == env44803) = true)

theorem identity44803 : scanCanonicalize (H12AffineFastState.compose env44803 (packedSelected [5,8] rootPS)) = affineNative (2^(8+1) ^^^ 136) := by decide +kernel

theorem selectedBound44803 : packedSelected [5,8] rootPS < 2^1333 := by decide +kernel

def env44804 : List Nat := [2,4,8,16,32,17,128,256,136,1024,308,1212,269,445,136,263,429,152,1025,137,1197,33,17,3,389,17,309,429,1212,16,1421,169,257,33,444,137]

theorem envBound44804 : H12AffineFastState.Bounded env44804 := by
  intro p hp
  have h : env44804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44803_44804 : H12AffineEnvironment.transform 8 136 env44803 = env44804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 136 env44803 == env44804) = true)

theorem identity44804 : scanCanonicalize (H12AffineFastState.compose env44804 (packedSelected [2,3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound44804 : packedSelected [2,3,5,10] rootPS < 2^1333 := by decide +kernel

def env44805 : List Nat := [2,4,8,16,32,17,128,256,136,272,308,428,269,445,136,263,429,152,273,137,445,33,17,3,389,17,309,429,428,16,157,169,257,33,444,137]

theorem envBound44805 : H12AffineFastState.Bounded env44805 := by
  intro p hp
  have h : env44805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44804_44805 : H12AffineEnvironment.transform 9 272 env44804 = env44805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env44804 == env44805) = true)

theorem identity44805 : scanCanonicalize (H12AffineFastState.compose env44805 (packedSelected [2] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44805 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44806 : List Nat := [2,4,8,16,32,17,9,256,1,272,308,293,269,308,1,263,292,17,273,0,308,33,17,3,268,17,309,292,293,16,20,32,257,33,309,0]

theorem envBound44806 : H12AffineFastState.Bounded env44806 := by
  intro p hp
  have h : env44806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44805_44806 : H12AffineEnvironment.transform 6 9 env44805 = env44806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44805 == env44806) = true)

theorem identity44806 : scanCanonicalize (H12AffineFastState.compose env44806 (packedSelected [0,1] rootPS)) = affineNative (2^(7+1) ^^^ 15) := by decide +kernel

theorem selectedBound44806 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env44807 : List Nat := [2,4,8,16,32,17,9,15,1,31,59,42,2,59,1,8,43,17,30,0,59,33,17,3,3,17,58,43,42,16,20,32,14,33,58,0]

theorem envBound44807 : H12AffineFastState.Bounded env44807 := by
  intro p hp
  have h : env44807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44806_44807 : H12AffineEnvironment.transform 7 15 env44806 = env44807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 15 env44806 == env44807) = true)

theorem identity44807 : scanCanonicalize (H12AffineFastState.compose env44807 (packedSelected [0,3] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound44807 : packedSelected [0,3] rootPS < 2^1333 := by decide +kernel

def env44808 : List Nat := [2,4,8,16,10,17,9,15,1,31,17,0,2,17,1,8,1,17,30,0,17,11,17,3,3,17,16,1,0,16,20,10,14,11,16,0]

theorem envBound44808 : H12AffineFastState.Bounded env44808 := by
  intro p hp
  have h : env44808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44807_44808 : H12AffineEnvironment.transform 4 10 env44807 = env44808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env44807 == env44808) = true)

theorem identity44808 : scanCanonicalize (H12AffineFastState.compose env44808 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound44808 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44809 : List Nat := [2,4,8,1,10,0,9,15,1,14,0,0,2,0,1,8,1,0,15,0,0,11,0,3,3,0,1,1,0,1,5,10,14,11,1,0]

theorem envBound44809 : H12AffineFastState.Bounded env44809 := by
  intro p hp
  have h : env44809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44808_44809 : H12AffineEnvironment.transform 3 1 env44808 = env44809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env44808 == env44809) = true)

def env44810 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254083,243088,8328,64,97546,139613,238994,336002,119043,272393,257,98814,90203,63188]

theorem envBound44810 : H12AffineFastState.Bounded env44810 := by
  intro p hp
  have h : env44810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44788_44810 : H12AffineEnvironment.transform 20 4161 env44788 = env44810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44788 == env44810) = true)

theorem identity44810 : scanCanonicalize (H12AffineFastState.compose env44810 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54494) := by decide +kernel

theorem selectedBound44810 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44811 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,262144,1025,32769,4161,452632,144477,155982,8328,64,43476,139613,160076,324700,1501,272393,257,21792,46213,63188]

theorem envBound44811 : H12AffineFastState.Bounded env44811 := by
  intro p hp
  have h : env44811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44810_44811 : H12AffineEnvironment.transform 15 54494 env44810 = env44811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54494 env44810 == env44811) = true)

def env44812 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146912,1025,32769,4161,54776,144477,155982,8328,64,43476,139613,160076,182716,1501,136681,257,21792,46213,63188]

theorem envBound44812 : H12AffineFastState.Bounded env44812 := by
  intro p hp
  have h : env44812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44811_44812 : H12AffineEnvironment.transform 17 146912 env44811 = env44812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146912 env44811 == env44812) = true)

theorem identity44812 : scanCanonicalize (H12AffineFastState.compose env44812 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound44812 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44813 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,5393,10481,1025,32769,4161,54776,8524,29791,8328,64,43476,13388,25693,56493,1501,248,257,21792,46213,63188]

theorem envBound44813 : H12AffineFastState.Bounded env44813 := by
  intro p hp
  have h : env44813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44812_44813 : H12AffineEnvironment.transform 16 5393 env44812 = env44813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env44812 == env44813) = true)

theorem identity44813 : scanCanonicalize (H12AffineFastState.compose env44813 (packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS)) = affineNative (2^(13+1) ^^^ 5512) := by decide +kernel

theorem selectedBound44813 : packedSelected [3,4,7,9,11,14,16,18,19,20,23,24,27,31,32,35] rootPS < 2^1333 := by decide +kernel

def env44814 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,32768,33110,5393,10481,1025,32769,4161,32880,8524,8663,8328,64,43476,13388,12757,35109,1501,248,257,168,46213,41820]

theorem envBound44814 : H12AffineFastState.Bounded env44814 := by
  intro p hp
  have h : env44814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44813_44814 : H12AffineEnvironment.transform 13 5512 env44813 = env44814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5512 env44813 == env44814) = true)

theorem identity44814 : scanCanonicalize (H12AffineFastState.compose env44814 (packedSelected [1,5,8,17,24] rootPS)) = affineNative (2^(14+1) ^^^ 80) := by decide +kernel

theorem selectedBound44814 : packedSelected [1,5,8,17,24] rootPS < 2^1333 := by decide +kernel

def env44815 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5512,80,262,5393,10481,1025,81,4161,32,8524,8663,8328,64,10628,13388,12757,2421,1501,248,257,168,13525,8972]

theorem envBound44815 : H12AffineFastState.Bounded env44815 := by
  intro p hp
  have h : env44815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44814_44815 : H12AffineEnvironment.transform 14 80 env44814 = env44815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 80 env44814 == env44815) = true)

theorem identity44815 : scanCanonicalize (H12AffineFastState.compose env44815 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound44815 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env44816 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,269,5512,80,262,5393,2556,1025,81,4161,32,65,218,389,64,2185,5441,4312,2421,1501,248,257,168,5592,513]

theorem envBound44816 : H12AffineFastState.Bounded env44816 := by
  intro p hp
  have h : env44816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44815_44816 : H12AffineEnvironment.transform 12 269 env44815 = env44816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env44815 == env44816) = true)

theorem identity44816 : scanCanonicalize (H12AffineFastState.compose env44816 (packedSelected [3,4,5,9,10,12,15] rootPS)) = affineNative (2^(11+1) ^^^ 201) := by decide +kernel

theorem selectedBound44816 : packedSelected [3,4,5,9,10,12,15] rootPS < 2^1333 := by decide +kernel

def env44817 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,201,269,1345,80,262,1496,2556,1025,81,136,32,65,218,389,64,2185,1416,17,2421,1501,248,257,168,1297,513]

theorem envBound44817 : H12AffineFastState.Bounded env44817 := by
  intro p hp
  have h : env44817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44816_44817 : H12AffineEnvironment.transform 11 201 env44816 = env44817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 201 env44816 == env44817) = true)

def env44818 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,131072,146913,1025,32769,4161,54777,144477,155982,8328,64,43476,139613,160076,182717,1501,136680,257,21792,46213,63188]

theorem envBound44818 : H12AffineFastState.Bounded env44818 := by
  intro p hp
  have h : env44818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44811_44818 : H12AffineEnvironment.transform 17 146913 env44811 = env44818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146913 env44811 == env44818) = true)

theorem identity44818 : scanCanonicalize (H12AffineFastState.compose env44818 (packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound44818 : packedSelected [0,3,4,7,10,16,18,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env44819 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54494,5528,10361,1025,32769,4161,54777,8645,29910,8328,64,43476,13509,25812,56357,1501,112,257,21792,46213,63188]

theorem envBound44819 : H12AffineFastState.Bounded env44819 := by
  intro p hp
  have h : env44819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44818_44819 : H12AffineEnvironment.transform 16 5528 env44818 = env44819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env44818 == env44819) = true)

theorem identity44819 : scanCanonicalize (H12AffineFastState.compose env44819 (packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound44819 : packedSelected [1,4,5,7,8,9,16,17,20,24,27] rootPS < 2^1333 := by decide +kernel

def env44820 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8403,5528,10361,1025,29708,4161,8692,8645,29910,8328,64,24025,13509,25812,10280,1501,112,257,21792,16520,729]

theorem envBound44820 : H12AffineFastState.Bounded env44820 := by
  intro p hp
  have h : env44820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44819_44820 : H12AffineEnvironment.transform 14 29709 env44819 = env44820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env44819 == env44820) = true)

theorem identity44820 : scanCanonicalize (H12AffineFastState.compose env44820 (packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44820 : packedSelected [0,3,4,5,7,9,11,15,16,17,19] rootPS < 2^1333 := by decide +kernel

def env44821 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,8282,5393,10361,1025,29708,4161,8573,8524,29791,8193,64,23888,13388,25693,10280,1364,112,257,21792,16385,592]

theorem envBound44821 : H12AffineFastState.Bounded env44821 := by
  intro p hp
  have h : env44821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44820_44821 : H12AffineEnvironment.transform 6 9 env44820 = env44821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44820 == env44821) = true)

theorem identity44821 : scanCanonicalize (H12AffineFastState.compose env44821 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound44821 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env44822 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,16384,21840,263,5393,2340,1025,21841,4161,32,17,21762,348,64,23888,5393,17664,2421,1364,112,257,21792,16385,592]

theorem envBound44822 : H12AffineFastState.Bounded env44822 := by
  intro p hp
  have h : env44822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44821_44822 : H12AffineEnvironment.transform 12 349 env44821 = env44822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env44821 == env44822) = true)

theorem identity44822 : scanCanonicalize (H12AffineFastState.compose env44822 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound44822 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44823 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,16384,21761,263,5393,2340,1025,21760,4112,32,17,21762,269,17,23809,5393,17664,2340,1285,33,257,21792,16385,513]

theorem envBound44823 : H12AffineFastState.Bounded env44823 := by
  intro p hp
  have h : env44823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44822_44823 : H12AffineEnvironment.transform 5 17 env44822 = env44823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env44822 == env44823) = true)

theorem identity44823 : scanCanonicalize (H12AffineFastState.compose env44823 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound44823 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env44824 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,268,5376,1,263,5393,2340,1025,0,4112,32,17,2,269,17,2049,5393,4096,2340,1285,33,257,32,5377,513]

theorem envBound44824 : H12AffineFastState.Bounded env44824 := by
  intro p hp
  have h : env44824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44823_44824 : H12AffineEnvironment.transform 13 5376 env44823 = env44824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env44823 == env44824) = true)

theorem identity44824 : scanCanonicalize (H12AffineFastState.compose env44824 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 309) := by decide +kernel

theorem selectedBound44824 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44825 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,309,268,1077,1,263,1060,2340,1025,0,293,32,17,2,269,17,2049,1060,309,2340,1285,33,257,32,1076,513]

theorem envBound44825 : H12AffineFastState.Bounded env44825 := by
  intro p hp
  have h : env44825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44824_44825 : H12AffineEnvironment.transform 11 309 env44824 = env44825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 309 env44824 == env44825) = true)

theorem identity44825 : scanCanonicalize (H12AffineFastState.compose env44825 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound44825 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env44826 : List Nat := [2,4,8,16,32,17,9,256,512,273,2048,309,268,292,1,263,309,2340,272,0,293,32,17,2,269,17,2049,309,309,2340,20,33,257,32,293,513]

theorem envBound44826 : H12AffineFastState.Bounded env44826 := by
  intro p hp
  have h : env44826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44825_44826 : H12AffineEnvironment.transform 9 273 env44825 = env44826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env44825 == env44826) = true)

theorem identity44826 : scanCanonicalize (H12AffineFastState.compose env44826 (packedSelected [0,4] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound44826 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44827 : List Nat := [2,4,8,16,32,17,9,37,512,52,2048,16,41,1,1,34,16,2049,53,0,0,32,17,2,40,17,2049,16,16,2049,20,33,36,32,0,513]

theorem envBound44827 : H12AffineFastState.Bounded env44827 := by
  intro p hp
  have h : env44827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44826_44827 : H12AffineEnvironment.transform 7 37 env44826 = env44827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env44826 == env44827) = true)

theorem identity44827 : scanCanonicalize (H12AffineFastState.compose env44827 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 48) := by decide +kernel

theorem selectedBound44827 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44828 : List Nat := [2,4,8,16,32,17,9,37,48,52,2048,16,41,1,1,34,16,2049,53,0,0,32,17,2,40,17,2049,16,16,2049,20,33,36,32,0,49]

theorem envBound44828 : H12AffineFastState.Bounded env44828 := by
  intro p hp
  have h : env44828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44827_44828 : H12AffineEnvironment.transform 8 48 env44827 = env44828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 48 env44827 == env44828) = true)

theorem identity44828 : scanCanonicalize (H12AffineFastState.compose env44828 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 49) := by decide +kernel

theorem selectedBound44828 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44829 : List Nat := [2,4,8,16,32,17,9,37,48,52,49,16,41,1,1,34,16,48,53,0,0,32,17,2,40,17,48,16,16,48,20,33,36,32,0,49]

theorem envBound44829 : H12AffineFastState.Bounded env44829 := by
  intro p hp
  have h : env44829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44828_44829 : H12AffineEnvironment.transform 10 49 env44828 = env44829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 49 env44828 == env44829) = true)

def env44830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,452632,254083,243089,8328,64,97547,2240797,2340307,336002,119042,2373705,257,2199998,2191387,63189]

theorem envBound44830 : H12AffineFastState.Bounded env44830 := by
  intro p hp
  have h : env44830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44787_44830 : H12AffineEnvironment.transform 23 243089 env44787 = env44830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 243089 env44787 == env44830) = true)

def env44831 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4160,452632,254083,243089,8328,64,97547,139613,238995,336002,119042,272393,257,98814,90203,63189]

theorem envBound44831 : H12AffineFastState.Bounded env44831 := by
  intro p hp
  have h : env44831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44830_44831 : H12AffineEnvironment.transform 20 4160 env44830 = env44831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env44830 == env44831) = true)

theorem identity44831 : scanCanonicalize (H12AffineFastState.compose env44831 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound44831 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44832 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1025,32769,4160,452632,180360,169370,8328,64,23808,139613,165272,262281,61705,272393,257,41461,16464,63189]

theorem envBound44832 : H12AffineFastState.Bounded env44832 := by
  intro p hp
  have h : env44832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44831_44832 : H12AffineEnvironment.transform 15 8203 env44831 = env44832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env44831 == env44832) = true)

theorem identity44832 : scanCanonicalize (H12AffineFastState.compose env44832 (packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound44832 : packedSelected [1,4,7,9,12,15,19,27,28,31,38,41] rootPS < 2^1333 := by decide +kernel

def env44833 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57677,262144,1025,32769,4160,264533,8645,29911,8328,64,23808,49168,25813,262281,61705,272393,257,41461,16464,63189]

theorem envBound44833 : H12AffineFastState.Bounded env44833 := by
  intro p hp
  have h : env44833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44832_44833 : H12AffineEnvironment.transform 16 57677 env44832 = env44833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env44832 == env44833) = true)

theorem identity44833 : scanCanonicalize (H12AffineFastState.compose env44833 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(17+1) ^^^ 35324) := by decide +kernel

theorem selectedBound44833 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env44834 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,57677,35324,1025,32769,4160,32937,8645,29911,8328,64,23808,49168,25813,35189,61705,41461,257,41461,16464,63189]

theorem envBound44834 : H12AffineFastState.Bounded env44834 := by
  intro p hp
  have h : env44834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44833_44834 : H12AffineEnvironment.transform 17 35324 env44833 = env44834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35324 env44833 == env44834) = true)

theorem identity44834 : scanCanonicalize (H12AffineFastState.compose env44834 (packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound44834 : packedSelected [3,4,7,9,10,16,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env44835 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10401,1025,8540,4160,8692,8645,29911,8328,64,23808,24909,25813,10280,20564,168,257,168,16464,22408]

theorem envBound44835 : H12AffineFastState.Bounded env44835 := by
  intro p hp
  have h : env44835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44834_44835 : H12AffineEnvironment.transform 14 8541 env44834 = env44835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env44834 == env44835) = true)

theorem identity44835 : scanCanonicalize (H12AffineFastState.compose env44835 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound44835 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44836 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,8203,16400,10280,1025,8540,4160,8573,8524,29790,8193,64,23808,24909,25692,10280,20564,33,257,33,16464,22273]

theorem envBound44836 : H12AffineFastState.Bounded env44836 := by
  intro p hp
  have h : env44836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44835_44836 : H12AffineEnvironment.transform 6 9 env44835 = env44836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44835 == env44836) = true)

theorem identity44836 : scanCanonicalize (H12AffineFastState.compose env44836 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound44836 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env44837 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8541,8203,13388,10280,1025,8540,4160,8573,8524,2,8193,64,10588,5393,4096,10280,9224,33,257,33,13324,9053]

theorem envBound44837 : H12AffineFastState.Bounded env44837 := by
  intro p hp
  have h : env44837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44836_44837 : H12AffineEnvironment.transform 13 13404 env44836 = env44837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env44836 == env44837) = true)

theorem identity44837 : scanCanonicalize (H12AffineFastState.compose env44837 (packedSelected [0,1,3,5,6,7,8,14,15] rootPS)) = affineNative (2^(9+1) ^^^ 352) := by decide +kernel

theorem selectedBound44837 : packedSelected [0,1,3,5,6,7,8,14,15] rootPS < 2^1333 := by decide +kernel

def env44838 : List Nat := [2,4,8,16,32,64,9,256,512,352,2048,4096,8192,12604,8541,8203,12588,10280,353,8540,4160,8573,8524,2,8193,64,10588,4209,4096,10280,8552,33,257,33,12652,9053]

theorem envBound44838 : H12AffineFastState.Bounded env44838 := by
  intro p hp
  have h : env44838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44837_44838 : H12AffineEnvironment.transform 9 352 env44837 = env44838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 352 env44837 == env44838) = true)

def env44839 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,4161,452632,254083,243089,8328,64,97547,139612,238994,336002,119042,272392,257,98815,90202,63189]

theorem envBound44839 : H12AffineFastState.Bounded env44839 := by
  intro p hp
  have h : env44839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44830_44839 : H12AffineEnvironment.transform 20 4161 env44830 = env44839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env44830 == env44839) = true)

theorem identity44839 : scanCanonicalize (H12AffineFastState.compose env44839 (packedSelected [21] rootPS)) = affineNative (2^(16+1) ^^^ 123026) := by decide +kernel

theorem selectedBound44839 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env44840 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,123026,262144,1025,32769,4161,329866,17,21763,8328,64,97547,115150,17664,336002,119042,272392,257,98815,90202,63189]

theorem envBound44840 : H12AffineFastState.Bounded env44840 := by
  intro p hp
  have h : env44840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44839_44840 : H12AffineEnvironment.transform 16 123026 env44839 = env44840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 123026 env44839 == env44840) = true)

def env44841 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,262144,1025,32769,4161,329730,17,21763,8192,64,97547,115014,17664,335882,119042,272392,257,98679,90202,63069]

theorem envBound44841 : H12AffineFastState.Bounded env44841 := by
  intro p hp
  have h : env44841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44840_44841 : H12AffineEnvironment.transform 6 8 env44840 = env44841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env44840 == env44841) = true)

theorem identity44841 : scanCanonicalize (H12AffineFastState.compose env44841 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound44841 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44842 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,122906,35189,1025,32769,4161,98679,17,21763,8192,64,97547,115014,17664,108927,119042,41341,257,98679,90202,63069]

theorem envBound44842 : H12AffineFastState.Bounded env44842 := by
  intro p hp
  have h : env44842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44841_44842 : H12AffineEnvironment.transform 17 35189 env44841 = env44842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env44841 == env44842) = true)

theorem identity44842 : scanCanonicalize (H12AffineFastState.compose env44842 (packedSelected [16,18,19,20,23,26] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound44842 : packedSelected [16,18,19,20,23,26] rootPS < 2^1333 := by decide +kernel

def env44843 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,38161,35189,1025,32769,4161,62588,17,21763,8192,64,2048,46157,17664,56436,41993,41341,257,62588,5457,63069]

theorem envBound44843 : H12AffineFastState.Bounded env44843 := by
  intro p hp
  have h : env44843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44842_44843 : H12AffineEnvironment.transform 15 29963 env44842 = env44843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env44842 == env44843) = true)

theorem identity44843 : scanCanonicalize (H12AffineFastState.compose env44843 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound44843 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env44844 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,32768,342,38161,35189,1025,32769,4161,32801,17,8542,8192,64,2048,46157,12637,43049,41993,41341,257,32801,5457,33280]

theorem envBound44844 : H12AffineFastState.Bounded env44844 := by
  intro p hp
  have h : env44844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44843_44844 : H12AffineEnvironment.transform 13 13405 env44843 = env44844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env44843 == env44844) = true)

theorem identity44844 : scanCanonicalize (H12AffineFastState.compose env44844 (packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound44844 : packedSelected [0,3,4,5,6,7,9,10,12,15,18,23] rootPS < 2^1333 := by decide +kernel

def env44845 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13405,8461,342,13340,10360,1025,8460,4161,8492,17,8542,8192,64,2048,5440,12637,2340,1284,112,257,8492,5457,8973]

theorem envBound44845 : H12AffineFastState.Bounded env44845 := by
  intro p hp
  have h : env44845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44844_44845 : H12AffineEnvironment.transform 14 8461 env44844 = env44845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env44844 == env44845) = true)

theorem identity44845 : scanCanonicalize (H12AffineFastState.compose env44845 (packedSelected [4,6,7,11] rootPS)) = affineNative (2^(9+1) ^^^ 20) := by decide +kernel

theorem selectedBound44845 : packedSelected [4,6,7,11] rootPS < 2^1333 := by decide +kernel

def env44846 : List Nat := [2,4,8,16,32,64,8,256,512,20,2048,4096,8192,12361,8461,342,12296,10360,21,8460,4161,8492,17,8542,8192,64,2048,4436,12637,2340,272,112,257,8492,4421,8973]

theorem envBound44846 : H12AffineFastState.Bounded env44846 := by
  intro p hp
  have h : env44846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44845_44846 : H12AffineEnvironment.transform 9 20 env44845 = env44846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 20 env44845 == env44846) = true)

theorem identity44846 : scanCanonicalize (H12AffineFastState.compose env44846 (packedSelected [1,3,4,5,6,7,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound44846 : packedSelected [1,3,4,5,6,7,8,10] rootPS < 2^1333 := by decide +kernel

def env44847 : List Nat := [2,4,8,16,32,64,8,256,512,20,2048,2405,8192,10540,8461,342,10605,10360,21,8460,2340,8492,17,8542,8192,64,2048,2097,10296,2340,272,112,257,8492,2080,8973]

theorem envBound44847 : H12AffineFastState.Bounded env44847 := by
  intro p hp
  have h : env44847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44846_44847 : H12AffineEnvironment.transform 11 2405 env44846 = env44847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env44846 == env44847) = true)

theorem identity44847 : scanCanonicalize (H12AffineFastState.compose env44847 (packedSelected [0,3,4,5,6,7,9,12] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound44847 : packedSelected [0,3,4,5,6,7,9,12] rootPS < 2^1333 := by decide +kernel

def env44848 : List Nat := [2,4,8,16,32,64,8,117,512,20,2048,2064,8192,10329,8312,35,10264,10360,21,8313,2129,8281,17,8235,8192,64,2048,2097,10296,2129,101,112,116,8281,2080,8824]

theorem envBound44848 : H12AffineFastState.Bounded env44848 := by
  intro p hp
  have h : env44848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44847_44848 : H12AffineEnvironment.transform 7 117 env44847 = env44848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env44847 == env44848) = true)

theorem identity44848 : scanCanonicalize (H12AffineFastState.compose env44848 (packedSelected [1,2,3,5,6,8] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound44848 : packedSelected [1,2,3,5,6,8] rootPS < 2^1333 := by decide +kernel

def env44849 : List Nat := [2,4,8,16,32,64,8,117,512,20,2048,2064,41,2160,81,35,2097,2129,21,80,2129,112,17,2,41,64,2048,2097,2065,2129,101,112,116,112,2080,593]

theorem envBound44849 : H12AffineFastState.Bounded env44849 := by
  intro p hp
  have h : env44849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44848_44849 : H12AffineEnvironment.transform 12 41 env44848 = env44849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env44848 == env44849) = true)

theorem identity44849 : scanCanonicalize (H12AffineFastState.compose env44849 (packedSelected [1,2,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound44849 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env44850 : List Nat := [2,4,8,16,32,64,8,117,512,20,522,538,41,634,81,35,571,603,21,80,603,112,17,2,41,64,522,571,539,603,101,112,116,112,554,593]

theorem envBound44850 : H12AffineFastState.Bounded env44850 := by
  intro p hp
  have h : env44850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44849_44850 : H12AffineEnvironment.transform 10 522 env44849 = env44850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env44849 == env44850) = true)

theorem identity44850 : scanCanonicalize (H12AffineFastState.compose env44850 (packedSelected [0,4] rootPS)) = affineNative (2^(8+1) ^^^ 42) := by decide +kernel

theorem selectedBound44850 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env44851 : List Nat := [2,4,8,16,32,64,8,117,42,20,32,48,41,80,81,35,17,113,21,80,113,112,17,2,41,64,32,17,49,113,101,112,116,112,0,123]

theorem envBound44851 : H12AffineFastState.Bounded env44851 := by
  intro p hp
  have h : env44851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44850_44851 : H12AffineEnvironment.transform 8 42 env44850 = env44851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 42 env44850 == env44851) = true)

theorem identity44851 : scanCanonicalize (H12AffineFastState.compose env44851 (packedSelected [6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound44851 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env44852 : List Nat := [2,4,8,16,32,49,8,4,42,20,32,48,41,33,32,35,17,0,21,33,0,1,17,2,41,49,32,17,49,0,20,1,5,1,0,10]

theorem envBound44852 : H12AffineFastState.Bounded env44852 := by
  intro p hp
  have h : env44852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44851_44852 : H12AffineEnvironment.transform 5 49 env44851 = env44852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env44851 == env44852) = true)

theorem identity44852 : scanCanonicalize (H12AffineFastState.compose env44852 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound44852 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env44853 : List Nat := [2,4,8,16,0,17,8,4,10,20,0,16,9,1,0,3,17,0,21,1,0,1,17,2,9,17,0,17,17,0,20,1,5,1,0,10]

theorem envBound44853 : H12AffineFastState.Bounded env44853 := by
  intro p hp
  have h : env44853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44852_44853 : H12AffineEnvironment.transform 4 0 env44852 = env44853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env44852 == env44853) = true)

theorem identity44853 : scanCanonicalize (H12AffineFastState.compose env44853 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 4) := by decide +kernel

theorem selectedBound44853 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env44854 : List Nat := [2,4,8,4,0,5,8,4,10,0,0,4,9,1,0,3,5,0,1,1,0,1,5,2,9,5,0,5,5,0,0,1,5,1,0,10]

theorem envBound44854 : H12AffineFastState.Bounded env44854 := by
  intro p hp
  have h : env44854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44853_44854 : H12AffineEnvironment.transform 3 4 env44853 = env44854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env44853 == env44854) = true)

theorem identity44854 : scanCanonicalize (H12AffineFastState.compose env44854 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound44854 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env44855 : List Nat := [2,4,1,4,0,5,1,4,3,0,0,4,0,1,0,3,5,0,1,1,0,1,5,2,0,5,0,5,5,0,0,1,5,1,0,3]

theorem envBound44855 : H12AffineFastState.Bounded env44855 := by
  intro p hp
  have h : env44855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44854_44855 : H12AffineEnvironment.transform 2 1 env44854 = env44855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env44854 == env44855) = true)

def env44856 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,262144,1025,32769,4161,329731,17,21763,8193,64,97547,115015,17664,335883,119042,272392,257,98678,90202,63068]

theorem envBound44856 : H12AffineFastState.Bounded env44856 := by
  intro p hp
  have h : env44856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44840_44856 : H12AffineEnvironment.transform 6 9 env44840 = env44856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env44840 == env44856) = true)

theorem identity44856 : scanCanonicalize (H12AffineFastState.compose env44856 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10280) := by decide +kernel

theorem selectedBound44856 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env44857 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,122907,10280,1025,32769,4161,73771,17,21763,8193,64,97547,115015,17664,67619,119042,32,257,98678,90202,63068]

theorem envBound44857 : H12AffineFastState.Bounded env44857 := by
  intro p hp
  have h : env44857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44856_44857 : H12AffineEnvironment.transform 17 10280 env44856 = env44857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10280 env44856 == env44857) = true)

theorem identity44857 : scanCanonicalize (H12AffineFastState.compose env44857 (packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound44857 : packedSelected [2,4,5,6,7,8,10,11,12,14,15,18,19,22,24,27,28] rootPS < 2^1333 := by decide +kernel

def env44858 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,40971,16400,10280,1025,32769,4161,32800,17,21763,8193,64,56576,24908,17664,43048,28937,32,257,8573,49233,63068]

theorem envBound44858 : H12AffineFastState.Bounded env44858 := by
  intro p hp
  have h : env44858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44857_44858 : H12AffineEnvironment.transform 15 40971 env44857 = env44858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env44857 == env44858) = true)

theorem identity44858 : scanCanonicalize (H12AffineFastState.compose env44858 (packedSelected [3,5,10] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound44858 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env44859 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,1,8202,16400,10280,1025,0,4161,33,17,21763,8193,64,23809,24908,17664,10281,28937,32,257,8573,16464,30301]

theorem envBound44859 : H12AffineFastState.Bounded env44859 := by
  intro p hp
  have h : env44859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44858_44859 : H12AffineEnvironment.transform 14 1 env44858 = env44859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env44858 == env44859) = true)

theorem identity44859 : scanCanonicalize (H12AffineFastState.compose env44859 (packedSelected [0,2,6,7,11,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound44859 : packedSelected [0,2,6,7,11,16,18] rootPS < 2^1333 := by decide +kernel

def env44860 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,1,8202,13341,10280,1025,0,4161,33,17,8462,8193,64,10508,5441,12557,10281,1284,32,257,8573,13405,592]

theorem envBound44860 : H12AffineFastState.Bounded env44860 := by
  intro p hp
  have h : env44860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44859_44860 : H12AffineEnvironment.transform 13 13325 env44859 = env44860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env44859 == env44860) = true)

theorem identity44860 : scanCanonicalize (H12AffineFastState.compose env44860 (packedSelected [0,1,6,7,8,11] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound44860 : packedSelected [0,1,6,7,8,11] rootPS < 2^1333 := by decide +kernel

def env44861 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,8192,11293,1,8202,11277,10280,1025,0,2129,33,17,8462,8193,64,10508,3409,10525,10281,1284,32,257,8573,11341,592]

theorem envBound44861 : H12AffineFastState.Bounded env44861 := by
  intro p hp
  have h : env44861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44860_44861 : H12AffineEnvironment.transform 11 2064 env44860 = env44861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env44860 == env44861) = true)

theorem identity44861 : scanCanonicalize (H12AffineFastState.compose env44861 (packedSelected [0,3,5,6,9,14] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound44861 : packedSelected [0,3,5,6,9,14] rootPS < 2^1333 := by decide +kernel

def env44862 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2064,120,3173,1,114,3189,2128,1025,0,2129,33,17,374,121,64,2420,3409,2405,2129,1284,32,257,261,3125,592]

theorem envBound44862 : H12AffineFastState.Bounded env44862 := by
  intro p hp
  have h : env44862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44861_44862 : H12AffineEnvironment.transform 12 120 env44861 = env44862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env44861 == env44862) = true)

theorem identity44862 : scanCanonicalize (H12AffineFastState.compose env44862 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound44862 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env44863 : List Nat := [2,4,8,16,32,64,9,116,512,1024,2048,2064,120,3173,1,114,3189,2128,1025,0,2129,33,17,2,121,64,2048,3109,2065,2129,1136,32,117,113,3125,592]

theorem envBound44863 : H12AffineFastState.Bounded env44863 := by
  intro p hp
  have h : env44863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans44862_44863 : H12AffineEnvironment.transform 7 116 env44862 = env44863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env44862 == env44863) = true)

theorem identity44863 : scanCanonicalize (H12AffineFastState.compose env44863 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound44863 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

end H12CloudChart1