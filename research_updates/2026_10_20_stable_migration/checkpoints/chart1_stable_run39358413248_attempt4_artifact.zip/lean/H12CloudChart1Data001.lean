import H12CloudChart1Data000

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity249 : scanCanonicalize (H12AffineFastState.compose env249 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 1093) := by decide +kernel

theorem selectedBound249 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env250 : List Nat := [2,4,8,16,32,64,9,116,512,1024,1093,1630,1133,634,1092,1126,570,1092,100,1092,635,33,1140,2,1132,1060,1093,1550,618,1092,1057,32,1040,33,635,513]

theorem envBound250 : H12AffineFastState.Bounded env250 := by
  intro p hp
  have h : env250.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans249_250 : H12AffineEnvironment.transform 10 1093 env249 = env250 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1093 env249 == env250) = true)

def env251 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,268435456,268570624,1073741824,67674548,1086893389,525568,1073743904,34359738368,98850]

theorem envBound251 : H12AffineFastState.Bounded env251 := by
  intro p hp
  have h : env251.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans9_251 : H12AffineEnvironment.transform 23 8988133 env9 = env251 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8988133 env9 == env251) = true)

theorem identity251 : scanCanonicalize (H12AffineFastState.compose env251 (packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS)) = affineNative (2^(29+1) ^^^ 13208935) := by decide +kernel

theorem selectedBound251 : packedSelected [0,1,3,7,9,10,14,19,20,22,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env252 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,268435456,268570624,13208935,67674548,73770,525568,13206855,34359738368,98850]

theorem envBound252 : H12AffineFastState.Bounded env252 := by
  intro p hp
  have h : env252.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans251_252 : H12AffineEnvironment.transform 29 13208935 env251 = env252 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 29 13208935 env251 == env252) = true)

def env253 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,67108864,262280,77615104,77742080,13208935,67674548,73770,525568,13206855,34359738368,98850]

theorem envBound253 : H12AffineFastState.Bounded env253 := by
  intro p hp
  have h : env253.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans252_253 : H12AffineEnvironment.transform 27 77615104 env252 = env253 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 27 77615104 env252 == env253) = true)

theorem identity253 : scanCanonicalize (H12AffineFastState.compose env253 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(25+1) ^^^ 566496) := by decide +kernel

theorem selectedBound253 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env254 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32768,2097152,4194304,8388608,8988133,8328,566496,262280,11072736,11199712,13208935,1364,73770,525568,13206855,34359738368,98850]

theorem envBound254 : H12AffineFastState.Bounded env254 := by
  intro p hp
  have h : env254.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans253_254 : H12AffineEnvironment.transform 25 566496 env253 = env254 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 25 566496 env253 == env254) = true)

def env255 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,4194304,8388608,8988133,8328,525376,262280,11031616,11158592,13184455,1364,73770,525568,13182439,34359738368,74370]

theorem envBound255 : H12AffineFastState.Bounded env255 := by
  intro p hp
  have h : env255.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans254_255 : H12AffineEnvironment.transform 14 8352 env254 = env255 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8352 env254 == env255) = true)

theorem identity255 : scanCanonicalize (H12AffineFastState.compose env255 (packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS)) = affineNative (2^(21+1) ^^^ 476) := by decide +kernel

theorem selectedBound255 : packedSelected [0,7,9,11,14,18,20,22,23,32] rootPS < 2^1333 := by decide +kernel

def env256 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,476,8388608,8988133,8328,525376,262280,11031616,11158592,8989723,1364,73770,525568,8987707,34359738368,74370]

theorem envBound256 : H12AffineFastState.Bounded env256 := by
  intro p hp
  have h : env256.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans255_256 : H12AffineEnvironment.transform 21 476 env255 = env256 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 476 env255 == env256) = true)

def env257 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,32,8388608,8987673,8328,525376,262280,11031616,11158592,8989723,1192,73770,525564,8987707,34359738368,74370]

theorem envBound257 : H12AffineFastState.Bounded env257 := by
  intro p hp
  have h : env257.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans256_257 : H12AffineEnvironment.transform 7 252 env256 = env257 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env256 == env257) = true)

theorem identity257 : scanCanonicalize (H12AffineFastState.compose env257 (packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound257 : packedSelected [0,3,7,9,10,13,14,20,21,22,24,26] rootPS < 2^1333 := by decide +kernel

def env258 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8322,131072,262144,524288,8352,2097152,32,8388608,8914075,8328,525376,262280,11031616,11158592,8916121,1192,168,525564,8914105,34359738368,512]

theorem envBound258 : H12AffineFastState.Bounded env258 := by
  intro p hp
  have h : env258.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans257_258 : H12AffineEnvironment.transform 15 8322 env257 = env258 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env257 == env258) = true)

theorem identity258 : scanCanonicalize (H12AffineFastState.compose env258 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 17596) := by decide +kernel

theorem selectedBound258 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env259 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8322,131072,262144,524288,8352,17596,32,8388608,8914075,8328,525376,262280,8917244,9044220,8916121,1192,168,525564,8914105,34359738368,512]

theorem envBound259 : H12AffineFastState.Bounded env259 := by
  intro p hp
  have h : env259.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans258_259 : H12AffineEnvironment.transform 20 17596 env258 = env259 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 17596 env258 == env259) = true)

theorem identity259 : scanCanonicalize (H12AffineFastState.compose env259 (packedSelected [11,12,13,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 9072732) := by decide +kernel

theorem selectedBound259 : packedSelected [11,12,13,15,18] rootPS < 2^1333 := by decide +kernel

def env260 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,16384,8352,8322,131072,262144,524288,8352,17596,32,8388608,8914075,8328,525376,262280,8917244,9044220,8916121,1192,168,525564,8914105,9072732,512]

theorem envBound260 : H12AffineFastState.Bounded env260 := by
  intro p hp
  have h : env260.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans259_260 : H12AffineEnvironment.transform 34 9072732 env259 = env260 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 9072732 env259 == env260) = true)

def env261 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8352,65536,131072,262144,524288,8352,2097152,33,8388608,8987672,8328,525376,262280,11031616,11158592,8989723,1193,73770,525565,8987707,34359738368,74370]

theorem envBound261 : H12AffineFastState.Bounded env261 := by
  intro p hp
  have h : env261.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans256_261 : H12AffineEnvironment.transform 7 253 env256 = env261 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env256 == env261) = true)

def env262 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,208,16384,112,65536,131072,262144,524288,112,2097152,33,8388608,8979656,88,525376,262280,11031616,11158592,8981707,1193,65786,525565,8979691,34359738368,66130]

theorem envBound262 : H12AffineFastState.Bounded env262 := by
  intro p hp
  have h : env262.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans261_262 : H12AffineEnvironment.transform 12 208 env261 = env262 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 208 env261 == env262) = true)

theorem identity262 : scanCanonicalize (H12AffineFastState.compose env262 (packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 725215) := by decide +kernel

theorem selectedBound262 : packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env263 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,208,16384,112,65536,131072,262144,524288,112,2097152,33,725215,136215,88,525376,262280,2311327,2184351,138260,1193,65786,525565,136244,34359738368,66130]

theorem envBound263 : H12AffineFastState.Bounded env263 := by
  intro p hp
  have h : env263.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans262_263 : H12AffineEnvironment.transform 22 725215 env262 = env263 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 725215 env262 == env263) = true)

def env264 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,2097152,33,725167,136215,40,525360,262280,2311327,2184351,138260,1193,65674,525453,136244,34359738368,66082]

theorem envBound264 : H12AffineFastState.Bounded env264 := by
  intro p hp
  have h : env264.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans263_264 : H12AffineEnvironment.transform 5 48 env263 = env264 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env263 == env264) = true)

def env265 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,268336,33,725167,136215,40,525360,262280,482479,347311,138260,1193,65674,525453,136244,34359738368,66082]

theorem envBound265 : H12AffineFastState.Bounded env265 := by
  intro p hp
  have h : env265.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans264_265 : H12AffineEnvironment.transform 20 268336 env264 = env265 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268336 env264 == env265) = true)

def env266 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,268336,33,725167,136215,40,525360,262280,482479,347311,138260,1193,65674,525453,136244,656568,66082]

theorem envBound266 : H12AffineFastState.Bounded env266 := by
  intro p hp
  have h : env266.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans265_266 : H12AffineEnvironment.transform 34 656568 env265 = env266 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656568 env265 == env266) = true)

theorem identity266 : scanCanonicalize (H12AffineFastState.compose env266 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 67754) := by decide +kernel

theorem selectedBound266 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env267 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,67754,524288,0,69786,33,725167,136215,40,525360,67618,152581,17413,138260,1193,65674,525453,136244,656568,66082]

theorem envBound267 : H12AffineFastState.Bounded env267 := by
  intro p hp
  have h : env267.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans266_267 : H12AffineEnvironment.transform 17 67754 env266 = env267 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 67754 env266 == env267) = true)

theorem identity267 : scanCanonicalize (H12AffineFastState.compose env267 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound267 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env268 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,5277,67754,524288,0,69786,33,590898,138,40,525360,67618,16536,17413,2185,1193,65674,525453,169,528421,66082]

theorem envBound268 : H12AffineFastState.Bounded env268 := by
  intro p hp
  have h : env268.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans267_268 : H12AffineEnvironment.transform 16 5277 env267 = env268 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env267 == env268) = true)

theorem identity268 : scanCanonicalize (H12AffineFastState.compose env268 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound268 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env269 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,3245,160,16384,0,65536,2096,67754,524288,0,68663,33,590898,138,40,525360,67618,16536,17413,2185,1193,65674,525453,169,527496,66082]

theorem envBound269 : H12AffineFastState.Bounded env269 := by
  intro p hp
  have h : env269.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans268_269 : H12AffineEnvironment.transform 11 3245 env268 = env269 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env268 == env269) = true)

theorem identity269 : scanCanonicalize (H12AffineFastState.compose env269 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound269 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env270 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,3245,160,16384,0,35,2096,2185,524288,0,3092,33,525329,138,40,525360,2049,16536,17413,2185,1193,169,525453,169,527496,513]

theorem envBound270 : H12AffineFastState.Bounded env270 := by
  intro p hp
  have h : env270.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans269_270 : H12AffineEnvironment.transform 15 35 env269 = env270 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env269 == env270) = true)

theorem identity270 : scanCanonicalize (H12AffineFastState.compose env270 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 1) := by decide +kernel

theorem selectedBound270 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env271 : List Nat := [2,4,8,16,32,48,128,141,512,1024,1,1196,160,16384,0,35,49,136,524288,0,1045,33,525329,138,40,525360,0,16536,17413,136,1193,169,525453,169,525449,513]

theorem envBound271 : H12AffineFastState.Bounded env271 := by
  intro p hp
  have h : env271.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans270_271 : H12AffineEnvironment.transform 10 1 env270 = env271 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1 env270 == env271) = true)

def env272 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,268336,33,725167,136215,40,525360,262280,482479,347311,138260,1193,65674,525453,136244,656569,66082]

theorem envBound272 : H12AffineFastState.Bounded env272 := by
  intro p hp
  have h : env272.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans265_272 : H12AffineEnvironment.transform 34 656569 env265 = env272 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656569 env265 == env272) = true)

theorem identity272 : scanCanonicalize (H12AffineFastState.compose env272 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 203830) := by decide +kernel

theorem selectedBound272 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env273 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,203830,524288,0,197638,33,725167,136215,40,525360,203966,16537,151705,138260,1193,65674,525453,136244,656569,66082]

theorem envBound273 : H12AffineFastState.Bounded env273 := by
  intro p hp
  have h : env273.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans272_273 : H12AffineEnvironment.transform 17 203830 env272 = env273 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 203830 env272 == env273) = true)

theorem identity273 : scanCanonicalize (H12AffineFastState.compose env273 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound273 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env274 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,5277,67755,524288,0,69787,33,590898,138,40,525360,67619,16537,17412,2185,1193,65674,525453,169,528420,66082]

theorem envBound274 : H12AffineFastState.Bounded env274 := by
  intro p hp
  have h : env274.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans273_274 : H12AffineEnvironment.transform 16 5277 env273 = env274 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env273 == env274) = true)

theorem identity274 : scanCanonicalize (H12AffineFastState.compose env274 (packedSelected [0,1,3,7] rootPS)) = affineNative (2^(15+1) ^^^ 19646) := by decide +kernel

theorem selectedBound274 : packedSelected [0,1,3,7] rootPS < 2^1333 := by decide +kernel

def env275 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,19646,5277,17429,524288,0,23589,33,542860,138,40,525360,17565,16537,17412,2185,1193,19508,525453,169,528420,20124]

theorem envBound275 : H12AffineFastState.Bounded env275 := by
  intro p hp
  have h : env275.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans274_275 : H12AffineEnvironment.transform 15 19646 env274 = env275 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 19646 env274 == env275) = true)

theorem identity275 : scanCanonicalize (H12AffineFastState.compose env275 (packedSelected [1,2,3,4,9] rootPS)) = affineNative (2^(13+1) ^^^ 3229) := by decide +kernel

theorem selectedBound275 : packedSelected [1,2,3,4,9] rootPS < 2^1333 := by decide +kernel

def env276 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,3229,0,35,5277,2184,524288,0,4280,33,525329,138,40,525360,2048,3076,2201,2185,1193,169,525453,169,528420,513]

theorem envBound276 : H12AffineFastState.Bounded env276 := by
  intro p hp
  have h : env276.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans275_276 : H12AffineEnvironment.transform 13 3229 env275 = env276 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3229 env275 == env276) = true)

theorem identity276 : scanCanonicalize (H12AffineFastState.compose env276 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 136) := by decide +kernel

theorem selectedBound276 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env277 : List Nat := [2,4,8,16,32,48,128,141,512,1024,136,4096,160,1045,0,35,5277,0,524288,0,4280,33,525329,138,40,525360,136,1164,17,1,1193,169,525453,169,528420,513]

theorem envBound277 : H12AffineFastState.Bounded env277 := by
  intro p hp
  have h : env277.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans276_277 : H12AffineEnvironment.transform 10 136 env276 = env277 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 136 env276 == env277) = true)

theorem identity277 : scanCanonicalize (H12AffineFastState.compose env277 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(11+1) ^^^ 570) := by decide +kernel

theorem selectedBound277 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env278 : List Nat := [2,4,8,16,32,48,128,141,512,1024,136,570,160,1045,0,35,1703,0,524288,0,642,33,525329,138,40,525360,136,1164,17,1,1193,169,525453,169,524830,513]

theorem envBound278 : H12AffineFastState.Bounded env278 := by
  intro p hp
  have h : env278.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans277_278 : H12AffineEnvironment.transform 11 570 env277 = env278 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 570 env277 == env278) = true)

def env279 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,268337,33,725167,136215,40,525360,262280,482478,347310,138260,1193,65674,525453,136244,34359738368,66082]

theorem envBound279 : H12AffineFastState.Bounded env279 := by
  intro p hp
  have h : env279.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans264_279 : H12AffineEnvironment.transform 20 268337 env264 = env279 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 268337 env264 == env279) = true)

def env280 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,268337,33,725167,136215,40,525360,262280,482478,347310,138260,1193,65674,525453,136244,656568,66082]

theorem envBound280 : H12AffineFastState.Bounded env280 := by
  intro p hp
  have h : env280.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans279_280 : H12AffineEnvironment.transform 34 656568 env279 = env280 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656568 env279 == env280) = true)

theorem identity280 : scanCanonicalize (H12AffineFastState.compose env280 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 138260) := by decide +kernel

theorem selectedBound280 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env281 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,138260,524288,0,132133,33,725167,136215,40,525360,138396,82106,217274,138260,1193,65674,525453,136244,656568,66082]

theorem envBound281 : H12AffineFastState.Bounded env281 := by
  intro p hp
  have h : env281.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans280_281 : H12AffineEnvironment.transform 17 138260 env280 = env281 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138260 env280 == env281) = true)

theorem identity281 : scanCanonicalize (H12AffineFastState.compose env281 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(18+1) ^^^ 214171) := by decide +kernel

theorem selectedBound281 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env282 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,138260,214171,0,132133,33,21556,136215,40,213163,138396,82106,217274,138260,1193,65674,213014,136244,81955,66082]

theorem envBound282 : H12AffineFastState.Bounded env282 := by
  intro p hp
  have h : env282.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans281_282 : H12AffineEnvironment.transform 18 214171 env281 = env282 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 214171 env281 == env282) = true)

theorem identity282 : scanCanonicalize (H12AffineFastState.compose env282 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 70846) := by decide +kernel

theorem selectedBound282 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env283 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,70846,67754,20517,0,69787,33,21556,65705,40,21525,67618,82106,17412,67754,1193,65674,21672,65674,81955,66082]

theorem envBound283 : H12AffineFastState.Bounded env283 := by
  intro p hp
  have h : env283.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans282_283 : H12AffineEnvironment.transform 16 70846 env282 = env283 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70846 env282 == env283) = true)

theorem identity283 : scanCanonicalize (H12AffineFastState.compose env283 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4144) := by decide +kernel

theorem selectedBound283 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env284 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,4144,0,65536,70846,67754,21,0,69787,33,1028,65705,40,1061,67618,69770,5172,67754,1193,65674,1176,65674,69651,66082]

theorem envBound284 : H12AffineFastState.Bounded env284 := by
  intro p hp
  have h : env284.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans283_284 : H12AffineEnvironment.transform 13 4144 env283 = env284 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4144 env283 == env284) = true)

def env285 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,262144,524288,0,268337,33,725167,136215,40,525360,262280,482478,347310,138260,1193,65674,525453,136244,656569,66082]

theorem envBound285 : H12AffineFastState.Bounded env285 := by
  intro p hp
  have h : env285.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans279_285 : H12AffineEnvironment.transform 34 656569 env279 = env285 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 656569 env279 == env285) = true)

theorem identity285 : scanCanonicalize (H12AffineFastState.compose env285 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 2184) := by decide +kernel

theorem selectedBound285 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env286 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,2184,524288,0,4281,33,725167,136215,40,525360,2048,218150,82982,138260,1193,65674,525453,136244,656569,66082]

theorem envBound286 : H12AffineFastState.Bounded env286 := by
  intro p hp
  have h : env286.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans285_286 : H12AffineEnvironment.transform 17 2184 env285 = env286 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env285 == env286) = true)

theorem identity286 : scanCanonicalize (H12AffineFastState.compose env286 (packedSelected [2,3,5,6,10,11,18] rootPS)) = affineNative (2^(18+1) ^^^ 148664) := by decide +kernel

theorem selectedBound286 : packedSelected [2,3,5,6,10,11,18] rootPS < 2^1333 := by decide +kernel

def env287 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,131072,2184,148664,0,4281,33,87063,136215,40,147592,2048,218150,82982,138260,1193,65674,147509,136244,16385,66082]

theorem envBound287 : H12AffineFastState.Bounded env287 := by
  intro p hp
  have h : env287.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans286_287 : H12AffineEnvironment.transform 18 148664 env286 = env287 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 148664 env286 == env287) = true)

theorem identity287 : scanCanonicalize (H12AffineFastState.compose env287 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 70846) := by decide +kernel

theorem selectedBound287 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env288 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,16384,0,65536,70846,2184,86022,0,4281,33,87063,65705,40,87094,2048,16536,82982,67754,1193,65674,87179,65674,16385,66082]

theorem envBound288 : H12AffineFastState.Bounded env288 := by
  intro p hp
  have h : env288.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans287_288 : H12AffineEnvironment.transform 16 70846 env287 = env288 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70846 env287 == env288) = true)

theorem identity288 : scanCanonicalize (H12AffineFastState.compose env288 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 4145) := by decide +kernel

theorem selectedBound288 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env289 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,160,4145,0,65536,70846,2184,65591,0,4281,33,66598,65705,40,66567,2048,4265,70679,67754,1193,65674,66746,65674,4144,66082]

theorem envBound289 : H12AffineFastState.Bounded env289 := by
  intro p hp
  have h : env289.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans288_289 : H12AffineEnvironment.transform 13 4145 env288 = env289 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4145 env288 == env289) = true)

def env290 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,1,65536,131072,262144,524288,1,2097152,33,725166,136215,41,525361,262280,2311327,2184351,138260,1193,65675,525452,136244,34359738368,66083]

theorem envBound290 : H12AffineFastState.Bounded env290 := by
  intro p hp
  have h : env290.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans263_290 : H12AffineEnvironment.transform 5 49 env263 = env290 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env263 == env290) = true)

theorem identity290 : scanCanonicalize (H12AffineFastState.compose env290 (packedSelected [2,3,5,6,10,11,21,23] rootPS)) = affineNative (2^(16+1) ^^^ 5277) := by decide +kernel

theorem selectedBound290 : packedSelected [2,3,5,6,10,11,21,23] rootPS < 2^1333 := by decide +kernel

def env291 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,1,65536,5277,262144,524288,1,2097152,33,590899,138,41,525361,262280,2183170,2184351,2185,1193,65675,525452,169,34359738368,66083]

theorem envBound291 : H12AffineFastState.Bounded env291 := by
  intro p hp
  have h : env291.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans290_291 : H12AffineEnvironment.transform 16 5277 env290 = env291 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5277 env290 == env291) = true)

theorem identity291 : scanCanonicalize (H12AffineFastState.compose env291 (packedSelected [2,3,5,6,10,12,13,15] rootPS)) = affineNative (2^(34+1) ^^^ 2687166) := by decide +kernel

theorem selectedBound291 : packedSelected [2,3,5,6,10,12,13,15] rootPS < 2^1333 := by decide +kernel

def env292 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,1,65536,5277,262144,524288,1,2097152,33,590899,138,41,525361,262280,2183170,2184351,2185,1193,65675,525452,169,2687166,66083]

theorem envBound292 : H12AffineFastState.Bounded env292 := by
  intro p hp
  have h : env292.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans291_292 : H12AffineEnvironment.transform 34 2687166 env291 = env292 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2687166 env291 == env292) = true)

theorem identity292 : scanCanonicalize (H12AffineFastState.compose env292 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound292 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env293 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,1,34,5277,262144,524288,1,2097152,33,525329,138,41,525361,262280,2117664,2118845,2185,1193,169,525452,169,2621596,513]

theorem envBound293 : H12AffineFastState.Bounded env293 := by
  intro p hp
  have h : env293.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans292_293 : H12AffineEnvironment.transform 15 34 env292 = env293 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env292 == env293) = true)

theorem identity293 : scanCanonicalize (H12AffineFastState.compose env293 (packedSelected [3,5,10] rootPS)) = affineNative (2^(20+1) ^^^ 528556) := by decide +kernel

theorem selectedBound293 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env294 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,1,34,5277,262144,524288,1,528556,33,525329,138,41,525361,262280,540812,541713,2185,1193,169,525452,169,4144,513]

theorem envBound294 : H12AffineFastState.Bounded env294 := by
  intro p hp
  have h : env294.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans293_294 : H12AffineEnvironment.transform 20 528556 env293 = env294 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528556 env293 == env294) = true)

theorem identity294 : scanCanonicalize (H12AffineFastState.compose env294 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(18+1) ^^^ 19592) := by decide +kernel

theorem selectedBound294 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env295 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,16384,1,34,5277,262144,19592,1,23588,33,18585,138,41,18617,262280,3076,2201,2185,1193,169,18436,169,4144,513]

theorem envBound295 : H12AffineFastState.Bounded env295 := by
  intro p hp
  have h : env295.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans294_295 : H12AffineEnvironment.transform 18 19592 env294 = env295 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 19592 env294 == env295) = true)

theorem identity295 : scanCanonicalize (H12AffineFastState.compose env295 (packedSelected [1,4,5,7,12] rootPS)) = affineNative (2^(13+1) ^^^ 7847) := by decide +kernel

theorem selectedBound295 : packedSelected [1,4,5,7,12] rootPS < 2^1333 := by decide +kernel

def env296 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,7847,1,34,5277,262144,4655,1,643,33,5694,138,41,5662,262280,3076,2201,2185,1193,169,5795,169,4144,513]

theorem envBound296 : H12AffineFastState.Bounded env296 := by
  intro p hp
  have h : env296.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans295_296 : H12AffineEnvironment.transform 13 7847 env295 = env296 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7847 env295 == env296) = true)

theorem identity296 : scanCanonicalize (H12AffineFastState.compose env296 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 6835) := by decide +kernel

theorem selectedBound296 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env297 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,161,7847,1,34,5277,6835,4655,1,643,33,5694,138,41,5662,6715,3076,2201,2185,1193,169,5795,169,4144,513]

theorem envBound297 : H12AffineFastState.Bounded env297 := by
  intro p hp
  have h : env297.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans296_297 : H12AffineEnvironment.transform 17 6835 env296 = env297 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 6835 env296 == env297) = true)

theorem identity297 : scanCanonicalize (H12AffineFastState.compose env297 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 3245) := by decide +kernel

theorem selectedBound297 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env298 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,3245,161,522,1,34,2096,1566,3714,1,643,33,2707,138,41,2739,1686,3076,2201,2185,1193,169,2574,169,3229,513]

theorem envBound298 : H12AffineFastState.Bounded env298 := by
  intro p hp
  have h : env298.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans297_298 : H12AffineEnvironment.transform 11 3245 env297 = env298 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3245 env297 == env298) = true)

theorem identity298 : scanCanonicalize (H12AffineFastState.compose env298 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 34) := by decide +kernel

theorem selectedBound298 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env299 : List Nat := [2,4,8,16,32,49,128,140,512,1024,34,1167,161,522,1,34,18,1566,1696,1,643,33,689,138,41,657,1686,1062,187,171,1193,169,556,169,1215,513]

theorem envBound299 : H12AffineFastState.Bounded env299 := by
  intro p hp
  have h : env299.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans298_299 : H12AffineEnvironment.transform 10 34 env298 = env299 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 34 env298 == env299) = true)

theorem identity299 : scanCanonicalize (H12AffineFastState.compose env299 (packedSelected [1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound299 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env300 : List Nat := [2,4,8,16,32,49,9,5,512,1024,34,1030,40,522,1,34,18,1566,1577,1,522,33,568,3,41,536,1567,1062,50,34,1056,32,556,32,1078,513]

theorem envBound300 : H12AffineFastState.Bounded env300 := by
  intro p hp
  have h : env300.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans299_300 : H12AffineEnvironment.transform 6 9 env299 = env300 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env299 == env300) = true)

theorem identity300 : scanCanonicalize (H12AffineFastState.compose env300 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound300 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env301 : List Nat := [2,4,8,16,32,49,9,5,512,542,34,536,40,522,1,34,18,0,55,1,522,33,568,3,41,536,1,568,50,34,574,32,556,32,552,513]

theorem envBound301 : H12AffineFastState.Bounded env301 := by
  intro p hp
  have h : env301.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans300_301 : H12AffineEnvironment.transform 9 542 env300 = env301 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env300 == env301) = true)

theorem identity301 : scanCanonicalize (H12AffineFastState.compose env301 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound301 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env302 : List Nat := [2,4,1,16,32,49,0,5,512,535,34,529,33,515,1,34,18,0,55,1,515,33,561,3,32,529,1,561,50,34,567,32,549,32,545,513]

theorem envBound302 : H12AffineFastState.Bounded env302 := by
  intro p hp
  have h : env302.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans301_302 : H12AffineEnvironment.transform 2 1 env301 = env302 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env301 == env302) = true)

theorem identity302 : scanCanonicalize (H12AffineFastState.compose env302 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound302 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env303 : List Nat := [2,4,1,16,2,19,0,5,512,535,0,529,3,515,1,0,18,0,21,1,515,3,531,3,2,529,1,531,16,0,533,2,519,2,515,513]

theorem envBound303 : H12AffineFastState.Bounded env303 := by
  intro p hp
  have h : env303.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans302_303 : H12AffineEnvironment.transform 4 2 env302 = env303 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env302 == env303) = true)

def env304 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,65536,131072,262144,524288,113,2097152,33,8388608,8979657,89,525376,262280,11031616,11158592,8981706,1193,65787,525565,8979690,34359738368,66131]

theorem envBound304 : H12AffineFastState.Bounded env304 := by
  intro p hp
  have h : env304.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans261_304 : H12AffineEnvironment.transform 12 209 env261 = env304 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 209 env261 == env304) = true)

theorem identity304 : scanCanonicalize (H12AffineFastState.compose env304 (packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS)) = affineNative (2^(22+1) ^^^ 659596) := by decide +kernel

theorem selectedBound304 : packedSelected [1,2,3,4,6,7,9,11,12,15,18,24,27,28] rootPS < 2^1333 := by decide +kernel

def env305 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,65536,131072,262144,524288,113,2097152,33,659596,201797,89,525376,262280,2245836,2118860,203846,1193,65787,525565,201830,34359738368,66131]

theorem envBound305 : H12AffineFastState.Bounded env305 := by
  intro p hp
  have h : env305.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans304_305 : H12AffineEnvironment.transform 22 659596 env304 = env305 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 659596 env304 == env305) = true)

def env306 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,65536,131072,262144,524288,113,528604,33,659596,201797,89,525376,262280,676880,541712,203846,1193,65787,525565,201830,34359738368,66131]

theorem envBound306 : H12AffineFastState.Bounded env306 := by
  intro p hp
  have h : env306.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans305_306 : H12AffineEnvironment.transform 20 528604 env305 = env306 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528604 env305 == env306) = true)

theorem identity306 : scanCanonicalize (H12AffineFastState.compose env306 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 5357) := by decide +kernel

theorem selectedBound306 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env307 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,65536,5357,262144,524288,113,528604,33,525409,65704,89,525376,262280,540925,541712,67755,1193,65787,525565,65675,34359738368,66131]

theorem envBound307 : H12AffineFastState.Bounded env307 := by
  intro p hp
  have h : env307.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans306_307 : H12AffineEnvironment.transform 16 5357 env306 = env307 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5357 env306 == env307) = true)

theorem identity307 : scanCanonicalize (H12AffineFastState.compose env307 (packedSelected [0,2,6,7,9,11,14,20,21,22,23] rootPS)) = affineNative (2^(15+1) ^^^ 34) := by decide +kernel

theorem selectedBound307 : packedSelected [0,2,6,7,9,11,14,20,21,22,23] rootPS < 2^1333 := by decide +kernel

def env308 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,34,5357,262144,524288,113,528604,33,525409,138,89,525376,262280,540925,541712,2185,1193,217,525565,169,34359738368,625]

theorem envBound308 : H12AffineFastState.Bounded env308 := by
  intro p hp
  have h : env308.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans307_308 : H12AffineEnvironment.transform 15 34 env307 = env308 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 34 env307 == env308) = true)

theorem identity308 : scanCanonicalize (H12AffineFastState.compose env308 (packedSelected [2,6,12,13,15] rootPS)) = affineNative (2^(34+1) ^^^ 4160) := by decide +kernel

theorem selectedBound308 : packedSelected [2,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env309 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,34,5357,262144,524288,113,528604,33,525409,138,89,525376,262280,540925,541712,2185,1193,217,525565,169,4160,625]

theorem envBound309 : H12AffineFastState.Bounded env309 := by
  intro p hp
  have h : env309.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans308_309 : H12AffineEnvironment.transform 34 4160 env308 = env309 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4160 env308 == env309) = true)

theorem identity309 : scanCanonicalize (H12AffineFastState.compose env309 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound309 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env310 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,16384,1,34,5277,262144,524288,1,528556,33,525329,138,41,525360,262280,540813,541712,2185,1193,169,525453,169,4144,513]

theorem envBound310 : H12AffineFastState.Bounded env310 := by
  intro p hp
  have h : env310.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans309_310 : H12AffineEnvironment.transform 5 48 env309 = env310 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env309 == env310) = true)

theorem identity310 : scanCanonicalize (H12AffineFastState.compose env310 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(18+1) ^^^ 7353) := by decide +kernel

theorem selectedBound310 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env311 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,16384,1,34,5277,262144,7353,1,3093,33,6312,138,41,6281,262280,23604,22697,2185,1193,169,6196,169,4144,513]

theorem envBound311 : H12AffineFastState.Bounded env311 := by
  intro p hp
  have h : env311.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans310_311 : H12AffineEnvironment.transform 18 7353 env310 = env311 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 7353 env310 == env311) = true)

theorem identity311 : scanCanonicalize (H12AffineFastState.compose env311 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(17+1) ^^^ 1567) := by decide +kernel

theorem selectedBound311 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env312 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,4096,161,16384,1,34,5277,1567,7353,1,3093,33,6312,138,41,6281,1687,23604,22697,2185,1193,169,6196,169,4144,513]

theorem envBound312 : H12AffineFastState.Bounded env312 := by
  intro p hp
  have h : env312.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans311_312 : H12AffineEnvironment.transform 17 1567 env311 = env312 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1567 env311 == env312) = true)

theorem identity312 : scanCanonicalize (H12AffineFastState.compose env312 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound312 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env313 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,571,161,16384,1,34,1702,1567,3714,1,3093,33,2707,138,41,2738,1687,19983,19090,2185,1193,169,2575,169,523,513]

theorem envBound313 : H12AffineFastState.Bounded env313 := by
  intro p hp
  have h : env313.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans312_313 : H12AffineEnvironment.transform 11 571 env312 = env313 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env312 == env313) = true)

theorem identity313 : scanCanonicalize (H12AffineFastState.compose env313 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(13+1) ^^^ 3228) := by decide +kernel

theorem selectedBound313 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env314 : List Nat := [2,4,8,16,32,48,128,141,512,1024,2048,571,161,3228,1,34,1702,1567,3714,1,3093,33,2707,138,41,2738,1687,659,1550,2185,1193,169,2575,169,523,513]

theorem envBound314 : H12AffineFastState.Bounded env314 := by
  intro p hp
  have h : env314.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans313_314 : H12AffineEnvironment.transform 13 3228 env313 = env314 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3228 env313 == env314) = true)

theorem identity314 : scanCanonicalize (H12AffineFastState.compose env314 (packedSelected [0,2] rootPS)) = affineNative (2^(9+1) ^^^ 159) := by decide +kernel

theorem selectedBound314 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env315 : List Nat := [2,4,8,16,32,48,128,141,512,159,2048,571,161,2051,1,34,569,640,2589,1,2186,33,2707,138,41,2738,520,659,657,2185,54,169,2575,169,523,513]

theorem envBound315 : H12AffineFastState.Bounded env315 := by
  intro p hp
  have h : env315.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans314_315 : H12AffineEnvironment.transform 9 159 env314 = env315 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 159 env314 == env315) = true)

theorem identity315 : scanCanonicalize (H12AffineFastState.compose env315 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 521) := by decide +kernel

theorem selectedBound315 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env316 : List Nat := [2,4,8,16,32,48,128,141,512,159,521,571,161,522,1,34,569,640,20,1,643,33,154,138,41,187,520,659,657,640,54,169,6,169,523,513]

theorem envBound316 : H12AffineFastState.Bounded env316 := by
  intro p hp
  have h : env316.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans315_316 : H12AffineEnvironment.transform 10 521 env315 = env316 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 521 env315 == env316) = true)

theorem identity316 : scanCanonicalize (H12AffineFastState.compose env316 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound316 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env317 : List Nat := [2,4,8,16,32,48,128,141,8,159,1,51,161,2,1,34,49,136,20,1,139,33,154,138,41,187,0,155,153,136,54,169,6,169,3,9]

theorem envBound317 : H12AffineFastState.Bounded env317 := by
  intro p hp
  have h : env317.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans316_317 : H12AffineEnvironment.transform 8 8 env316 = env317 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env316 == env317) = true)

theorem identity317 : scanCanonicalize (H12AffineFastState.compose env317 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 0) := by decide +kernel

theorem selectedBound317 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env318 : List Nat := [2,4,8,16,32,48,0,13,8,31,1,51,33,2,1,34,49,8,20,1,11,33,26,10,41,59,0,27,25,8,54,41,6,41,3,9]

theorem envBound318 : H12AffineFastState.Bounded env318 := by
  intro p hp
  have h : env318.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans317_318 : H12AffineEnvironment.transform 6 0 env317 = env318 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 0 env317 == env318) = true)

def env319 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,65536,131072,262144,524288,113,528605,33,659596,201797,89,525376,262280,676881,541713,203846,1193,65787,525565,201830,34359738368,66131]

theorem envBound319 : H12AffineFastState.Bounded env319 := by
  intro p hp
  have h : env319.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans305_319 : H12AffineEnvironment.transform 20 528605 env305 = env319 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 528605 env305 == env319) = true)

theorem identity319 : scanCanonicalize (H12AffineFastState.compose env319 (packedSelected [3,5,10] rootPS)) = affineNative (2^(16+1) ^^^ 70846) := by decide +kernel

theorem selectedBound319 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env320 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,209,16384,113,65536,70846,262144,524288,113,528605,33,590898,251,89,525376,262280,606383,541713,2296,1193,65787,525565,216,34359738368,66131]

theorem envBound320 : H12AffineFastState.Bounded env320 := by
  intro p hp
  have h : env320.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans319_320 : H12AffineEnvironment.transform 16 70846 env319 = env320 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70846 env319 == env320) = true)

theorem identity320 : scanCanonicalize (H12AffineFastState.compose env320 (packedSelected [2,6,11,21,23] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound320 : packedSelected [2,6,11,21,23] rootPS < 2^1333 := by decide +kernel

def env321 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,0,65536,70846,262144,524288,0,528556,33,590898,138,40,525361,262280,606383,541713,2185,1193,65674,525452,169,34359738368,66082]

theorem envBound321 : H12AffineFastState.Bounded env321 := by
  intro p hp
  have h : env321.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans320_321 : H12AffineEnvironment.transform 5 49 env320 = env321 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env320 == env321) = true)

theorem identity321 : scanCanonicalize (H12AffineFastState.compose env321 (packedSelected [2,6,12,13,15] rootPS)) = affineNative (2^(34+1) ^^^ 4144) := by decide +kernel

theorem selectedBound321 : packedSelected [2,6,12,13,15] rootPS < 2^1333 := by decide +kernel

def env322 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,0,65536,70846,262144,524288,0,528556,33,590898,138,40,525361,262280,606383,541713,2185,1193,65674,525452,169,4144,66082]

theorem envBound322 : H12AffineFastState.Bounded env322 := by
  intro p hp
  have h : env322.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans321_322 : H12AffineEnvironment.transform 34 4144 env321 = env322 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 4144 env321 == env322) = true)

theorem identity322 : scanCanonicalize (H12AffineFastState.compose env322 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 35) := by decide +kernel

theorem selectedBound322 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env323 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,0,35,5277,262144,524288,0,528556,33,525329,138,40,525361,262280,540812,541713,2185,1193,169,525452,169,4144,513]

theorem envBound323 : H12AffineFastState.Bounded env323 := by
  intro p hp
  have h : env323.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans322_323 : H12AffineEnvironment.transform 15 35 env322 = env323 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 35 env322 == env323) = true)

theorem identity323 : scanCanonicalize (H12AffineFastState.compose env323 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(18+1) ^^^ 279553) := by decide +kernel

theorem selectedBound323 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env324 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,16384,0,35,5277,262144,279553,0,283821,33,278544,138,40,278576,262280,263309,262160,2185,1193,169,278669,169,4144,513]

theorem envBound324 : H12AffineFastState.Bounded env324 := by
  intro p hp
  have h : env324.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans323_324 : H12AffineEnvironment.transform 18 279553 env323 = env324 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 279553 env323 == env324) = true)

theorem identity324 : scanCanonicalize (H12AffineFastState.compose env324 (packedSelected [3,4,7,8] rootPS)) = affineNative (2^(13+1) ^^^ 7847) := by decide +kernel

theorem selectedBound324 : packedSelected [3,4,7,8] rootPS < 2^1333 := by decide +kernel

def env325 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,4096,160,7847,0,35,5277,262144,268966,0,264714,33,270007,138,40,269975,262280,263309,262160,2185,1193,169,269866,169,4144,513]

theorem envBound325 : H12AffineFastState.Bounded env325 := by
  intro p hp
  have h : env325.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans324_325 : H12AffineEnvironment.transform 13 7847 env324 = env325 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 7847 env324 == env325) = true)

theorem identity325 : scanCanonicalize (H12AffineFastState.compose env325 (packedSelected [13] rootPS)) = affineNative (2^(11+1) ^^^ 571) := by decide +kernel

theorem selectedBound325 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env326 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,571,160,3228,0,35,1702,262144,264349,0,264714,33,265356,138,40,265388,262280,263309,262160,2185,1193,169,265233,169,523,513]

theorem envBound326 : H12AffineFastState.Bounded env326 := by
  intro p hp
  have h : env326.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans325_326 : H12AffineEnvironment.transform 11 571 env325 = env326 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 571 env325 == env326) = true)

theorem identity326 : scanCanonicalize (H12AffineFastState.compose env326 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(17+1) ^^^ 1567) := by decide +kernel

theorem selectedBound326 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env327 : List Nat := [2,4,8,16,32,49,128,140,512,1024,2048,571,160,3228,0,35,1702,1567,3714,0,3093,33,2707,138,40,2739,1687,658,1551,2185,1193,169,2574,169,523,513]

theorem envBound327 : H12AffineFastState.Bounded env327 := by
  intro p hp
  have h : env327.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans326_327 : H12AffineEnvironment.transform 17 1567 env326 = env327 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 1567 env326 == env327) = true)

theorem identity327 : scanCanonicalize (H12AffineFastState.compose env327 (packedSelected [0,2] rootPS)) = affineNative (2^(6+1) ^^^ 42) := by decide +kernel

theorem selectedBound327 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env328 : List Nat := [2,4,8,16,32,49,42,38,512,1024,2048,571,10,3126,0,35,1548,1567,3624,0,3093,33,2617,32,40,2585,1597,568,1551,2083,1027,3,2574,3,523,513]

theorem envBound328 : H12AffineFastState.Bounded env328 := by
  intro p hp
  have h : env328.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans327_328 : H12AffineEnvironment.transform 6 42 env327 = env328 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 42 env327 == env328) = true)

theorem identity328 : scanCanonicalize (H12AffineFastState.compose env328 (packedSelected [4] rootPS)) = affineNative (2^(10+1) ^^^ 1596) := by decide +kernel

theorem selectedBound328 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env329 : List Nat := [2,4,8,16,32,49,42,38,512,1024,1596,571,10,522,0,35,1548,1567,20,0,553,33,1029,32,40,1061,1597,568,1551,1567,1027,3,1074,3,523,513]

theorem envBound329 : H12AffineFastState.Bounded env329 := by
  intro p hp
  have h : env329.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans328_329 : H12AffineEnvironment.transform 10 1596 env328 = env329 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1596 env328 == env329) = true)

theorem identity329 : scanCanonicalize (H12AffineFastState.compose env329 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 572) := by decide +kernel

theorem selectedBound329 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env330 : List Nat := [2,4,8,16,32,49,42,38,512,572,0,571,10,522,0,35,48,35,20,0,553,33,569,32,40,537,1,568,51,35,575,3,526,3,523,513]

theorem envBound330 : H12AffineFastState.Bounded env330 := by
  intro p hp
  have h : env330.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans329_330 : H12AffineEnvironment.transform 9 572 env329 = env330 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 572 env329 == env330) = true)

theorem identity330 : scanCanonicalize (H12AffineFastState.compose env330 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 35) := by decide +kernel

theorem selectedBound330 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env331 : List Nat := [2,4,8,16,32,49,42,38,35,31,0,24,10,41,0,35,48,35,20,0,10,33,26,32,40,58,1,27,51,35,28,3,45,3,40,34]

theorem envBound331 : H12AffineFastState.Bounded env331 := by
  intro p hp
  have h : env331.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans330_331 : H12AffineEnvironment.transform 8 35 env330 = env331 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 35 env330 == env331) = true)

def env332 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,4194304,8388608,8988133,8328,525377,262280,11031617,11158593,13184454,1364,73770,525568,13182438,34359738368,74371]

theorem envBound332 : H12AffineFastState.Bounded env332 := by
  intro p hp
  have h : env332.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans254_332 : H12AffineEnvironment.transform 14 8353 env254 = env332 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8353 env254 == env332) = true)

def env333 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,8388608,8988133,8328,525377,262280,11031617,11158593,8990182,1364,73770,525568,8988102,34359738368,74371]

theorem envBound333 : H12AffineFastState.Bounded env333 := by
  intro p hp
  have h : env333.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans332_333 : H12AffineEnvironment.transform 21 32 env332 = env333 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 32 env332 == env333) = true)

def env334 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,525328,74229,8328,525377,262280,2117713,2244689,76278,1364,73770,525568,74198,34359738368,74371]

theorem envBound334 : H12AffineFastState.Bounded env334 := by
  intro p hp
  have h : env334.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans333_334 : H12AffineEnvironment.transform 22 525328 env333 = env334 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525328 env333 == env334) = true)

theorem identity334 : scanCanonicalize (H12AffineFastState.compose env334 (packedSelected [13,17] rootPS)) = affineNative (2^(7+1) ^^^ 253) := by decide +kernel

theorem selectedBound334 : packedSelected [13,17] rootPS < 2^1333 := by decide +kernel

def env335 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,525328,73736,8328,525377,262280,2117713,2244689,75787,1193,73770,525565,73771,34359738368,74371]

theorem envBound335 : H12AffineFastState.Bounded env335 := by
  intro p hp
  have h : env335.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans334_335 : H12AffineEnvironment.transform 7 253 env334 = env335 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env334 == env335) = true)

theorem identity335 : scanCanonicalize (H12AffineFastState.compose env335 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(34+1) ^^^ 2894021) := by decide +kernel

theorem selectedBound335 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env336 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,525328,73736,8328,525377,262280,2117713,2244689,75787,1193,73770,525565,73771,2894021,74371]

theorem envBound336 : H12AffineFastState.Bounded env336 := by
  intro p hp
  have h : env336.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans335_336 : H12AffineEnvironment.transform 34 2894021 env335 = env336 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 2894021 env335 == env336) = true)

theorem identity336 : scanCanonicalize (H12AffineFastState.compose env336 (packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS)) = affineNative (2^(17+1) ^^^ 203846) := by decide +kernel

theorem selectedBound336 : packedSelected [0,1,4,7,8,9,10,11,13,15,20,21] rootPS < 2^1333 := by decide +kernel

def env337 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,65536,131072,203846,524288,8353,2097152,32,525328,73736,8328,525377,203982,2117713,2244689,75787,1193,73770,525565,73771,2831491,74371]

theorem envBound337 : H12AffineFastState.Bounded env337 := by
  intro p hp
  have h : env337.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans336_337 : H12AffineEnvironment.transform 17 203846 env336 = env337 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 203846 env336 == env337) = true)

theorem identity337 : scanCanonicalize (H12AffineFastState.compose env337 (packedSelected [1,4,8,10,11,14,15,22] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound337 : packedSelected [1,4,8,10,11,14,15,22] rootPS < 2^1333 := by decide +kernel

def env338 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8323,131072,146629,524288,8353,2097152,32,525328,139,8328,525377,146509,2117713,2244689,2184,1193,169,525565,168,2757632,512]

theorem envBound338 : H12AffineFastState.Bounded env338 := by
  intro p hp
  have h : env338.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans337_338 : H12AffineEnvironment.transform 15 8323 env337 = env338 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env337 == env338) = true)

theorem identity338 : scanCanonicalize (H12AffineFastState.compose env338 (packedSelected [2,6] rootPS)) = affineNative (2^(16+1) ^^^ 13388) := by decide +kernel

theorem selectedBound338 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env339 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,16384,8353,8323,13388,2185,524288,8353,2097152,32,525328,139,8328,525377,2049,2117713,2126877,2184,1193,169,525565,168,2629708,512]

theorem envBound339 : H12AffineFastState.Bounded env339 := by
  intro p hp
  have h : env339.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans338_339 : H12AffineEnvironment.transform 16 13388 env338 = env339 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13388 env338 == env339) = true)

theorem identity339 : scanCanonicalize (H12AffineFastState.compose env339 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 8) := by decide +kernel

theorem selectedBound339 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env340 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8,16384,169,139,5188,2185,524288,169,2097152,32,525328,139,128,525377,2049,2117713,2118677,2184,1193,169,525565,168,2621508,512]

theorem envBound340 : H12AffineFastState.Bounded env340 := by
  intro p hp
  have h : env340.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans339_340 : H12AffineEnvironment.transform 12 8 env339 = env340 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 8 env339 == env340) = true)

theorem identity340 : scanCanonicalize (H12AffineFastState.compose env340 (packedSelected [0,7] rootPS)) = affineNative (2^(20+1) ^^^ 16632) := by decide +kernel

theorem selectedBound340 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env341 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8,16384,169,139,5188,2185,524288,169,16632,32,525328,139,128,525377,2049,4265,5357,2184,1193,169,525565,168,540860,512]

theorem envBound341 : H12AffineFastState.Bounded env341 := by
  intro p hp
  have h : env341.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans340_341 : H12AffineEnvironment.transform 20 16632 env340 = env341 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 16632 env340 == env341) = true)

theorem identity341 : scanCanonicalize (H12AffineFastState.compose env341 (packedSelected [1,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 41) := by decide +kernel

theorem selectedBound341 : packedSelected [1,5,10] rootPS < 2^1333 := by decide +kernel

def env342 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,0,34,5188,2080,524288,0,16465,32,525328,34,41,525377,2049,4096,5188,2081,1024,0,525396,1,540693,512]

theorem envBound342 : H12AffineFastState.Bounded env342 := by
  intro p hp
  have h : env342.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans341_342 : H12AffineEnvironment.transform 6 41 env341 = env342 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 41 env341 == env342) = true)

theorem identity342 : scanCanonicalize (H12AffineFastState.compose env342 (packedSelected [2,11] rootPS)) = affineNative (2^(18+1) ^^^ 21) := by decide +kernel

theorem selectedBound342 : packedSelected [2,11] rootPS < 2^1333 := by decide +kernel

def env343 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,16384,0,34,5188,2080,21,0,16465,32,1029,34,41,1108,2049,4096,5188,2081,1024,0,1089,1,16384,512]

theorem envBound343 : H12AffineFastState.Bounded env343 := by
  intro p hp
  have h : env343.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans342_343 : H12AffineEnvironment.transform 18 21 env342 = env343 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 21 env342 == env343) = true)

theorem identity343 : scanCanonicalize (H12AffineFastState.compose env343 (packedSelected [2] rootPS)) = affineNative (2^(13+1) ^^^ 1093) := by decide +kernel

theorem selectedBound343 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env344 : List Nat := [2,4,8,16,32,64,41,84,512,1024,2048,4096,8,1093,0,34,5188,2080,21,0,1044,32,1029,34,41,1108,2049,4096,5188,2081,1024,0,1089,1,1093,512]

theorem envBound344 : H12AffineFastState.Bounded env344 := by
  intro p hp
  have h : env344.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans343_344 : H12AffineEnvironment.transform 13 1093 env343 = env344 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 1093 env343 == env344) = true)

theorem identity344 : scanCanonicalize (H12AffineFastState.compose env344 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1567) := by decide +kernel

theorem selectedBound344 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env345 : List Nat := [2,4,8,16,32,64,41,84,512,1024,1567,4096,8,1093,0,34,5188,1599,21,0,1044,32,1029,34,41,1108,1566,4096,5188,1598,1024,0,1089,1,1093,512]

theorem envBound345 : H12AffineFastState.Bounded env345 := by
  intro p hp
  have h : env345.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans344_345 : H12AffineEnvironment.transform 10 1567 env344 = env345 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1567 env344 == env345) = true)

theorem identity345 : scanCanonicalize (H12AffineFastState.compose env345 (packedSelected [1,5] rootPS)) = affineNative (2^(11+1) ^^^ 1662) := by decide +kernel

theorem selectedBound345 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env346 : List Nat := [2,4,8,16,32,64,41,84,512,1024,1567,1662,8,1093,0,34,570,1599,21,0,1044,32,1029,34,41,1108,1566,1662,570,1598,1024,0,1089,1,1093,512]

theorem envBound346 : H12AffineFastState.Bounded env346 := by
  intro p hp
  have h : env346.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans345_346 : H12AffineEnvironment.transform 11 1662 env345 = env346 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1662 env345 == env346) = true)

theorem identity346 : scanCanonicalize (H12AffineFastState.compose env346 (packedSelected [1,8] rootPS)) = affineNative (2^(9+1) ^^^ 542) := by decide +kernel

theorem selectedBound346 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env347 : List Nat := [2,4,8,16,32,64,41,84,512,542,1,96,8,603,0,34,570,33,21,0,522,32,539,34,41,586,0,96,570,32,542,0,607,1,603,512]

theorem envBound347 : H12AffineFastState.Bounded env347 := by
  intro p hp
  have h : env347.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans346_347 : H12AffineEnvironment.transform 9 542 env346 = env347 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 542 env346 == env347) = true)

theorem identity347 : scanCanonicalize (H12AffineFastState.compose env347 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 89) := by decide +kernel

theorem selectedBound347 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env348 : List Nat := [2,4,8,16,32,64,41,84,89,71,1,96,8,2,0,34,99,33,21,0,83,32,66,34,41,19,0,96,99,32,71,0,6,1,2,89]

theorem envBound348 : H12AffineFastState.Bounded env348 := by
  intro p hp
  have h : env348.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans347_348 : H12AffineEnvironment.transform 8 89 env347 = env348 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 89 env347 == env348) = true)

def env349 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,525329,74228,8328,525377,262280,2117712,2244688,76279,1364,73770,525568,74199,34359738368,74371]

theorem envBound349 : H12AffineFastState.Bounded env349 := by
  intro p hp
  have h : env349.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans333_349 : H12AffineEnvironment.transform 22 525329 env333 = env349 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 525329 env333 == env349) = true)

theorem identity349 : scanCanonicalize (H12AffineFastState.compose env349 (packedSelected [1,3,4,7,9,24,27,28] rootPS)) = affineNative (2^(34+1) ^^^ 280712) := by decide +kernel

theorem selectedBound349 : packedSelected [1,3,4,7,9,24,27,28] rootPS < 2^1333 := by decide +kernel

def env350 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,2097152,32,525329,74228,8328,525377,262280,2117712,2244688,76279,1364,73770,525568,74199,280712,74371]

theorem envBound350 : H12AffineFastState.Bounded env350 := by
  intro p hp
  have h : env350.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans349_350 : H12AffineEnvironment.transform 34 280712 env349 = env350 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 34 280712 env349 == env350) = true)

theorem identity350 : scanCanonicalize (H12AffineFastState.compose env350 (packedSelected [0,1,5,7,8,9,14,18,20,22,23,24] rootPS)) = affineNative (2^(20+1) ^^^ 676865) := by decide +kernel

theorem selectedBound350 : packedSelected [0,1,5,7,8,9,14,18,20,22,23,24] rootPS < 2^1333 := by decide +kernel

def env351 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8353,65536,131072,262144,524288,8353,676865,32,525329,74228,8328,525377,262280,656465,529489,76279,1364,73770,525568,74199,280712,74371]

theorem envBound351 : H12AffineFastState.Bounded env351 := by
  intro p hp
  have h : env351.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans350_351 : H12AffineEnvironment.transform 20 676865 env350 = env351 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 676865 env350 == env351) = true)

def env352 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,8353,65536,131072,262144,524288,8353,656585,32,525329,74228,8328,525377,262280,656465,529489,76279,1364,73770,525568,74199,268352,74371]

theorem envBound352 : H12AffineFastState.Bounded env352 := by
  intro p hp
  have h : env352.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans351_352 : H12AffineEnvironment.transform 13 4296 env351 = env352 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 4296 env351 == env352) = true)

theorem identity352 : scanCanonicalize (H12AffineFastState.compose env352 (packedSelected [0,1,3,5,6,7,8,13] rootPS)) = affineNative (2^(18+1) ^^^ 272) := by decide +kernel

theorem selectedBound352 : packedSelected [0,1,3,5,6,7,8,13] rootPS < 2^1333 := by decide +kernel

def env353 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,4296,8353,65536,131072,262144,272,8353,132569,32,1281,74228,8328,1361,262280,132417,5441,76279,1364,73770,1040,74199,268352,74371]

theorem envBound353 : H12AffineFastState.Bounded env353 := by
  intro p hp
  have h : env353.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans352_353 : H12AffineEnvironment.transform 18 272 env352 = env353 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 272 env352 == env353) = true)

def env354 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4296,8353,65536,131072,262144,236,8353,132133,32,1277,73736,8328,1197,262280,132285,5309,75787,1192,73770,1040,73771,268352,74371]

theorem envBound354 : H12AffineFastState.Bounded env354 := by
  intro p hp
  have h : env354.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans353_354 : H12AffineEnvironment.transform 7 252 env353 = env354 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 252 env353 == env354) = true)

theorem identity354 : scanCanonicalize (H12AffineFastState.compose env354 (packedSelected [11,12,15,18] rootPS)) = affineNative (2^(16+1) ^^^ 5221) := by decide +kernel

theorem selectedBound354 : packedSelected [11,12,15,18] rootPS < 2^1333 := by decide +kernel

def env355 : List Nat := [2,4,8,16,32,64,128,252,512,1024,2048,4096,8192,4296,8353,65536,5221,262144,236,8353,4160,32,1277,73736,8328,1197,262280,4312,5309,75787,1192,73770,1040,73771,268352,74371]

theorem envBound355 : H12AffineFastState.Bounded env355 := by
  intro p hp
  have h : env355.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans354_355 : H12AffineEnvironment.transform 16 5221 env354 = env355 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5221 env354 == env355) = true)

theorem identity355 : scanCanonicalize (H12AffineFastState.compose env355 (packedSelected [1,2,4,8,9,10,12,14,15] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound355 : packedSelected [1,2,4,8,9,10,12,14,15] rootPS < 2^1333 := by decide +kernel

def env356 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4161,8232,65536,5221,262144,101,8232,4160,32,1140,73736,8193,1060,262145,4177,5172,75787,1057,73770,1040,73771,268352,74250]

theorem envBound356 : H12AffineFastState.Bounded env356 := by
  intro p hp
  have h : env356.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans355_356 : H12AffineEnvironment.transform 6 9 env355 = env356 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env355 == env356) = true)

theorem identity356 : scanCanonicalize (H12AffineFastState.compose env356 (packedSelected [4,6,9,11,12,20] rootPS)) = affineNative (2^(17+1) ^^^ 13324) := by decide +kernel

theorem selectedBound356 : packedSelected [4,6,9,11,12,20] rootPS < 2^1333 := by decide +kernel

def env357 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4161,8232,65536,5221,13324,101,8232,4160,32,1140,73736,8193,1060,13325,4177,5172,75787,1057,73770,1040,73771,11340,74250]

theorem envBound357 : H12AffineFastState.Bounded env357 := by
  intro p hp
  have h : env357.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans356_357 : H12AffineEnvironment.transform 17 13324 env356 = env357 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 13324 env356 == env357) = true)

theorem identity357 : scanCanonicalize (H12AffineFastState.compose env357 (packedSelected [3,5,12] rootPS)) = affineNative (2^(15+1) ^^^ 6242) := by decide +kernel

theorem selectedBound357 : packedSelected [3,5,12] rootPS < 2^1333 := by decide +kernel

def env358 : List Nat := [2,4,8,16,32,64,9,117,512,1024,2048,4096,8192,4161,8232,6242,5221,13324,101,8232,4160,32,1140,14442,8193,1060,13325,4177,5172,12393,1057,14408,1040,14409,11340,14952]

theorem envBound358 : H12AffineFastState.Bounded env358 := by
  intro p hp
  have h : env358.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans357_358 : H12AffineEnvironment.transform 15 6242 env357 = env358 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 6242 env357 == env358) = true)

theorem identity358 : scanCanonicalize (H12AffineFastState.compose env358 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound358 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env359 : List Nat := [2,4,8,16,32,64,9,117,512,101,2048,4096,8192,4161,8232,6242,4096,12393,101,8232,4160,32,17,14442,8193,65,12392,4177,4177,12393,68,14408,117,14409,10281,14952]

theorem envBound359 : H12AffineFastState.Bounded env359 := by
  intro p hp
  have h : env359.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans358_359 : H12AffineEnvironment.transform 9 101 env358 = env359 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env358 == env359) = true)

theorem identity359 : scanCanonicalize (H12AffineFastState.compose env359 (packedSelected [3,5] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound359 : packedSelected [3,5] rootPS < 2^1333 := by decide +kernel

def env360 : List Nat := [2,4,8,16,32,64,9,117,512,101,0,4096,8192,4161,8232,4194,4096,12393,101,8232,4160,32,17,12394,8193,65,12392,4177,4177,12393,68,12360,117,12361,8233,12904]

theorem envBound360 : H12AffineFastState.Bounded env360 := by
  intro p hp
  have h : env360.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans359_360 : H12AffineEnvironment.transform 10 0 env359 = env360 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env359 == env360) = true)

theorem identity360 : scanCanonicalize (H12AffineFastState.compose env360 (packedSelected [0] rootPS)) = affineNative (2^(12+1) ^^^ 90) := by decide +kernel

theorem selectedBound360 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env361 : List Nat := [2,4,8,16,32,64,9,117,512,101,0,4096,90,4161,114,4194,4096,4147,101,114,4160,32,17,4144,91,65,4146,4177,4177,4147,68,4114,117,4115,115,4658]

theorem envBound361 : H12AffineFastState.Bounded env361 := by
  intro p hp
  have h : env361.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans360_361 : H12AffineEnvironment.transform 12 90 env360 = env361 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 90 env360 == env361) = true)

theorem identity361 : scanCanonicalize (H12AffineFastState.compose env361 (packedSelected [1,6,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 50) := by decide +kernel

theorem selectedBound361 : packedSelected [1,6,7,8] rootPS < 2^1333 := by decide +kernel

def env362 : List Nat := [2,4,8,16,32,64,9,117,512,101,0,50,90,115,114,80,50,1,101,114,114,32,17,2,91,65,0,99,99,1,68,32,117,33,115,512]

theorem envBound362 : H12AffineFastState.Bounded env362 := by
  intro p hp
  have h : env362.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans361_362 : H12AffineEnvironment.transform 11 50 env361 = env362 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 50 env361 == env362) = true)

theorem identity362 : scanCanonicalize (H12AffineFastState.compose env362 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound362 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env363 : List Nat := [2,4,8,16,32,48,9,5,512,21,0,50,42,3,2,32,50,1,21,2,2,32,17,2,43,49,0,19,19,1,52,32,5,33,3,512]

theorem envBound363 : H12AffineFastState.Bounded env363 := by
  intro p hp
  have h : env363.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans362_363 : H12AffineEnvironment.transform 5 48 env362 = env363 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env362 == env363) = true)

theorem identity363 : scanCanonicalize (H12AffineFastState.compose env363 (packedSelected [1,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound363 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env364 : List Nat := [2,4,8,16,1,17,9,5,512,21,0,19,11,3,2,1,19,1,21,2,2,1,17,2,10,16,0,19,19,1,21,1,5,0,3,512]

theorem envBound364 : H12AffineFastState.Bounded env364 := by
  intro p hp
  have h : env364.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans363_364 : H12AffineEnvironment.transform 4 1 env363 = env364 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env363 == env364) = true)

theorem identity364 : scanCanonicalize (H12AffineFastState.compose env364 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 29) := by decide +kernel

theorem selectedBound364 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env365 : List Nat := [2,4,8,16,1,17,9,5,29,21,0,19,11,3,2,1,19,1,21,2,2,1,17,2,10,16,0,19,19,1,21,1,5,0,3,29]

theorem envBound365 : H12AffineFastState.Bounded env365 := by
  intro p hp
  have h : env365.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans364_365 : H12AffineEnvironment.transform 8 29 env364 = env365 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 29 env364 == env365) = true)

theorem identity365 : scanCanonicalize (H12AffineFastState.compose env365 (packedSelected [4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound365 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env366 : List Nat := [2,4,8,5,1,4,9,5,8,0,0,6,11,3,2,1,6,1,0,2,2,1,4,2,10,5,0,6,6,1,0,1,5,0,3,8]

theorem envBound366 : H12AffineFastState.Bounded env366 := by
  intro p hp
  have h : env366.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans365_366 : H12AffineEnvironment.transform 3 5 env365 = env366 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env365 == env366) = true)

theorem identity366 : scanCanonicalize (H12AffineFastState.compose env366 (packedSelected [6] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound366 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env367 : List Nat := [1,4,8,5,1,4,9,5,8,0,0,5,8,0,1,1,5,1,0,1,1,1,4,1,9,5,0,5,5,1,0,1,5,0,0,8]

theorem envBound367 : H12AffineFastState.Bounded env367 := by
  intro p hp
  have h : env367.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans366_367 : H12AffineEnvironment.transform 0 1 env366 = env367 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env366 == env367) = true)

def env368 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8353,65536,131072,262144,237,8353,132132,32,1276,73737,8328,1196,262280,132284,5308,75786,1193,73770,1040,73770,268352,74371]

theorem envBound368 : H12AffineFastState.Bounded env368 := by
  intro p hp
  have h : env368.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans353_368 : H12AffineEnvironment.transform 7 253 env353 = env368 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 253 env353 == env368) = true)

def env369 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8353,65536,131072,2184,237,8353,132132,32,1276,73737,8328,1196,2048,132284,5308,75786,1193,73770,1040,73770,4296,74371]

theorem envBound369 : H12AffineFastState.Bounded env369 := by
  intro p hp
  have h : env369.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans368_369 : H12AffineEnvironment.transform 17 2184 env368 = env369 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2184 env368 == env369) = true)

theorem identity369 : scanCanonicalize (H12AffineFastState.compose env369 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 8323) := by decide +kernel

theorem selectedBound369 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env370 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8353,8323,131072,2184,237,8353,132132,32,1276,138,8328,1196,2048,132284,5308,2185,1193,169,1040,169,4296,512]

theorem envBound370 : H12AffineFastState.Bounded env370 := by
  intro p hp
  have h : env370.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans369_370 : H12AffineEnvironment.transform 15 8323 env369 = env370 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8323 env369 == env370) = true)

theorem identity370 : scanCanonicalize (H12AffineFastState.compose env370 (packedSelected [2] rootPS)) = affineNative (2^(16+1) ^^^ 12360) := by decide +kernel

theorem selectedBound370 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env371 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8353,8323,12360,2184,237,8353,13420,32,1276,138,8328,1196,2048,13556,5308,2185,1193,169,1040,169,4296,512]

theorem envBound371 : H12AffineFastState.Bounded env371 := by
  intro p hp
  have h : env371.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans370_371 : H12AffineEnvironment.transform 16 12360 env370 = env371 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 12360 env370 == env371) = true)

theorem identity371 : scanCanonicalize (H12AffineFastState.compose env371 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 592) := by decide +kernel

theorem selectedBound371 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env372 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,592,8192,664,8353,8323,8728,2184,237,8353,9788,32,1276,138,8328,1196,2048,9892,1772,2185,1193,169,1040,169,664,512]

theorem envBound372 : H12AffineFastState.Bounded env372 := by
  intro p hp
  have h : env372.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans371_372 : H12AffineEnvironment.transform 11 592 env371 = env372 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 592 env371 == env372) = true)

theorem identity372 : scanCanonicalize (H12AffineFastState.compose env372 (packedSelected [0,4] rootPS)) = affineNative (2^(12+1) ^^^ 3702) := by decide +kernel

theorem selectedBound372 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env373 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,592,3702,664,3799,3829,3182,2184,237,3799,2122,32,1276,138,3838,1196,2048,2258,1772,2185,1193,169,1040,169,664,512]

theorem envBound373 : H12AffineFastState.Bounded env373 := by
  intro p hp
  have h : env373.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans372_373 : H12AffineEnvironment.transform 12 3702 env372 = env373 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 3702 env372 == env373) = true)

theorem identity373 : scanCanonicalize (H12AffineFastState.compose env373 (packedSelected [1,5] rootPS)) = affineNative (2^(10+1) ^^^ 624) := by decide +kernel

theorem selectedBound373 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env374 : List Nat := [2,4,8,16,32,64,128,253,512,1024,624,592,1030,664,1191,1157,1566,760,237,1191,570,32,1276,138,1166,1196,624,674,1772,761,1193,169,1040,169,664,512]

theorem envBound374 : H12AffineFastState.Bounded env374 := by
  intro p hp
  have h : env374.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans373_374 : H12AffineEnvironment.transform 10 624 env373 = env374 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 624 env373 == env374) = true)

theorem identity374 : scanCanonicalize (H12AffineFastState.compose env374 (packedSelected [0,7] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound374 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env375 : List Nat := [2,4,8,16,32,64,128,253,512,4,624,592,2,664,163,129,538,760,237,163,570,32,248,138,138,168,624,674,744,761,173,169,20,169,664,512]

theorem envBound375 : H12AffineFastState.Bounded env375 := by
  intro p hp
  have h : env375.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans374_375 : H12AffineEnvironment.transform 9 4 env374 = env375 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env374 == env375) = true)

theorem identity375 : scanCanonicalize (H12AffineFastState.compose env375 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 32) := by decide +kernel

theorem selectedBound375 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env376 : List Nat := [2,4,8,16,32,32,128,157,512,4,528,560,2,664,163,129,538,664,141,163,570,32,152,138,138,168,528,674,648,665,173,169,20,169,664,512]

theorem envBound376 : H12AffineFastState.Bounded env376 := by
  intro p hp
  have h : env376.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans375_376 : H12AffineEnvironment.transform 5 32 env375 = env376 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 32 env375 == env376) = true)

theorem identity376 : scanCanonicalize (H12AffineFastState.compose env376 (packedSelected [10] rootPS)) = affineNative (2^(6+1) ^^^ 35) := by decide +kernel

theorem selectedBound376 : packedSelected [10] rootPS < 2^1333 := by decide +kernel

def env377 : List Nat := [2,4,8,16,32,32,35,62,512,4,528,560,2,571,0,34,538,571,46,0,570,32,59,41,41,11,528,513,555,570,14,10,20,10,571,512]

theorem envBound377 : H12AffineFastState.Bounded env377 := by
  intro p hp
  have h : env377.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans376_377 : H12AffineEnvironment.transform 6 35 env376 = env377 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 35 env376 == env377) = true)

theorem identity377 : scanCanonicalize (H12AffineFastState.compose env377 (packedSelected [11] rootPS)) = affineNative (2^(3+1) ^^^ 11) := by decide +kernel

theorem selectedBound377 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env378 : List Nat := [2,4,8,11,32,32,35,37,512,4,523,555,2,544,0,34,513,544,46,0,545,32,32,41,41,11,523,513,555,545,14,10,15,10,544,512]

theorem envBound378 : H12AffineFastState.Bounded env378 := by
  intro p hp
  have h : env378.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans377_378 : H12AffineEnvironment.transform 3 11 env377 = env378 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 11 env377 == env378) = true)

theorem identity378 : scanCanonicalize (H12AffineFastState.compose env378 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 7) := by decide +kernel

theorem selectedBound378 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env379 : List Nat := [2,4,8,11,32,32,35,37,7,4,12,44,2,39,0,34,6,39,46,0,38,32,32,41,41,11,12,6,44,38,14,10,15,10,39,7]

theorem envBound379 : H12AffineFastState.Bounded env379 := by
  intro p hp
  have h : env379.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans378_379 : H12AffineEnvironment.transform 8 7 env378 = env379 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 7 env378 == env379) = true)

def env380 : List Nat := [2,4,8,11,12,12,15,9,7,4,12,0,2,11,0,14,6,11,2,0,10,12,12,5,5,11,12,6,0,10,14,10,15,10,11,7]

theorem envBound380 : H12AffineFastState.Bounded env380 := by
  intro p hp
  have h : env380.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans379_380 : H12AffineEnvironment.transform 4 12 env379 = env380 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 12 env379 == env380) = true)

theorem identity380 : scanCanonicalize (H12AffineFastState.compose env380 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound380 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env381 : List Nat := [2,0,8,11,8,8,11,9,3,0,8,0,2,11,0,10,2,11,2,0,10,8,8,1,1,11,8,2,0,10,10,10,11,10,11,3]

theorem envBound381 : H12AffineFastState.Bounded env381 := by
  intro p hp
  have h : env381.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans380_381 : H12AffineEnvironment.transform 1 0 env380 = env381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env380 == env381) = true)

def leafEnv381 : List Nat := [2,0,8,11,8,8,11,9,3,0,8,0,2,11,0,10,2,11,2,0,10,8,8,1,8,1,1,11,8,2,0,10,10,10,11,10,2,9,11,3,1,11,0]

def active381 : List Nat := [0,2]

def tree381 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood381 : H12WitnessSearch.Good tree381 := H12GlobalWitnessIndex.good

theorem leafIdentity381 : H12AffineFastState.composeSystem env381 rootObs = leafEnv381 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env381 rootObs == leafEnv381) = true)

theorem terminalChecked381 : H12PackedTerminal.terminalCheckFast leafEnv381 active381 tree381 = true := by decide +kernel

def env382 : List Nat := [2,4,8,11,13,13,14,8,7,4,12,1,2,10,0,15,6,10,3,0,11,13,13,4,4,11,12,6,1,11,14,10,15,10,10,7]

theorem envBound382 : H12AffineFastState.Bounded env382 := by
  intro p hp
  have h : env382.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans379_382 : H12AffineEnvironment.transform 4 13 env379 = env382 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 13 env379 == env382) = true)

theorem identity382 : scanCanonicalize (H12AffineFastState.compose env382 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound382 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env383 : List Nat := [1,4,8,8,13,13,13,8,4,4,12,1,1,9,0,12,5,9,0,0,8,13,13,4,4,8,12,5,1,8,13,9,12,9,9,4]

theorem envBound383 : H12AffineFastState.Bounded env383 := by
  intro p hp
  have h : env383.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans382_383 : H12AffineEnvironment.transform 0 1 env382 = env383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env382 == env383) = true)

def leafEnv383 : List Nat := [1,4,8,8,13,13,13,8,4,4,12,1,1,9,0,12,5,9,0,0,8,13,13,4,9,4,1,8,12,5,1,8,13,9,12,9,0,9,9,4,1,9,0]

def active383 : List Nat := [1,2]

def tree383 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood383 : H12WitnessSearch.Good tree383 := H12GlobalWitnessIndex.good

theorem leafIdentity383 : H12AffineFastState.composeSystem env383 rootObs = leafEnv383 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env383 rootObs == leafEnv383) = true)

theorem terminalChecked383 : H12PackedTerminal.terminalCheckFast leafEnv383 active383 tree383 = true := by decide +kernel

def env384 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8353,65536,131072,2185,237,8353,132132,32,1276,73737,8328,1196,2049,132284,5308,75786,1193,73770,1040,73770,4297,74371]

theorem envBound384 : H12AffineFastState.Bounded env384 := by
  intro p hp
  have h : env384.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans368_384 : H12AffineEnvironment.transform 17 2185 env368 = env384 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2185 env368 == env384) = true)

theorem identity384 : scanCanonicalize (H12AffineFastState.compose env384 (packedSelected [0,4,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 9870) := by decide +kernel

theorem selectedBound384 : packedSelected [0,4,11,12] rootPS < 2^1333 := by decide +kernel

def env385 : List Nat := [2,4,8,16,32,64,128,253,512,1024,2048,4096,8192,4296,8353,65536,9870,2185,237,8353,8874,32,1276,73737,8328,1196,2049,8754,5308,75786,1193,73770,1040,73770,4297,74371]

theorem envBound385 : H12AffineFastState.Bounded env385 := by
  intro p hp
  have h : env385.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans384_385 : H12AffineEnvironment.transform 16 9870 env384 = env385 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 9870 env384 == env385) = true)

theorem identity385 : scanCanonicalize (H12AffineFastState.compose env385 (packedSelected [3,5,10,15] rootPS)) = affineNative (2^(10+1) ^^^ 1646) := by decide +kernel

theorem selectedBound385 : packedSelected [3,5,10,15] rootPS < 2^1333 := by decide +kernel

def env386 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1646,4096,8192,4296,8353,65536,9870,1767,237,8353,8874,32,1276,73737,8328,1196,1647,8754,5308,75364,1193,73770,1040,73770,4297,74371]

theorem envBound386 : H12AffineFastState.Bounded env386 := by
  intro p hp
  have h : env386.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans385_386 : H12AffineEnvironment.transform 10 1646 env385 = env386 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1646 env385 == env386) = true)

def env387 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1646,4096,1148,4296,1245,65536,754,1767,237,1245,1750,32,1276,66677,1268,1196,1647,1614,5308,66072,1193,66646,1040,66646,4297,67327]

theorem envBound387 : H12AffineFastState.Bounded env387 := by
  intro p hp
  have h : env387.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans386_387 : H12AffineEnvironment.transform 12 1148 env386 = env387 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1148 env386 == env387) = true)

theorem identity387 : scanCanonicalize (H12AffineFastState.compose env387 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1686) := by decide +kernel

theorem selectedBound387 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env388 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1646,1686,1148,1630,1245,65536,754,1767,237,1245,1750,32,1276,66677,1268,1196,1647,1614,554,66072,1193,66646,1040,66646,1631,67327]

theorem envBound388 : H12AffineFastState.Bounded env388 := by
  intro p hp
  have h : env388.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans387_388 : H12AffineEnvironment.transform 11 1686 env387 = env388 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1686 env387 == env388) = true)

def env389 : List Nat := [2,4,8,16,32,64,128,253,512,172,706,570,208,754,113,65536,754,587,237,113,634,32,80,65753,88,0,707,738,554,66072,5,65786,188,65786,755,66131]

theorem envBound389 : H12AffineFastState.Bounded env389 := by
  intro p hp
  have h : env389.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans388_389 : H12AffineEnvironment.transform 9 172 env388 = env389 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env388 == env389) = true)

theorem identity389 : scanCanonicalize (H12AffineFastState.compose env389 (packedSelected [6] rootPS)) = affineNative (2^(15+1) ^^^ 83) := by decide +kernel

theorem selectedBound389 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env390 : List Nat := [2,4,8,16,32,64,128,253,512,172,706,570,208,754,113,83,754,587,237,113,634,32,80,138,88,0,707,738,554,587,5,169,188,169,755,512]

theorem envBound390 : H12AffineFastState.Bounded env390 := by
  intro p hp
  have h : env390.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans389_390 : H12AffineEnvironment.transform 15 83 env389 = env390 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 83 env389 == env390) = true)

theorem identity390 : scanCanonicalize (H12AffineFastState.compose env390 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 21) := by decide +kernel

theorem selectedBound390 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env391 : List Nat := [2,4,8,16,21,64,128,200,512,153,706,527,208,711,68,83,711,587,216,68,591,21,80,138,88,0,707,727,543,587,5,156,137,156,710,512]

theorem envBound391 : H12AffineFastState.Bounded env391 := by
  intro p hp
  have h : env391.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans390_391 : H12AffineEnvironment.transform 4 21 env390 = env391 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 21 env390 == env391) = true)

theorem identity391 : scanCanonicalize (H12AffineFastState.compose env391 (packedSelected [3] rootPS)) = affineNative (2^(6+1) ^^^ 7) := by decide +kernel

theorem selectedBound391 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env392 : List Nat := [2,4,8,16,21,64,7,79,512,30,581,527,87,576,68,83,576,587,95,68,591,21,80,13,88,0,580,592,543,587,5,27,14,27,577,512]

theorem envBound392 : H12AffineFastState.Bounded env392 := by
  intro p hp
  have h : env392.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans391_392 : H12AffineEnvironment.transform 6 7 env391 = env392 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 7 env391 == env392) = true)

theorem identity392 : scanCanonicalize (H12AffineFastState.compose env392 (packedSelected [0,4] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound392 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env393 : List Nat := [2,4,8,5,0,64,7,79,512,11,581,527,66,576,68,70,576,587,74,68,591,0,69,13,77,0,580,581,522,587,5,14,14,14,577,512]

theorem envBound393 : H12AffineFastState.Bounded env393 := by
  intro p hp
  have h : env393.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans392_393 : H12AffineEnvironment.transform 3 5 env392 = env393 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env392 == env393) = true)

theorem identity393 : scanCanonicalize (H12AffineFastState.compose env393 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound393 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env394 : List Nat := [2,4,8,5,0,10,7,5,512,11,527,527,8,522,14,12,522,513,0,14,517,0,15,13,7,0,526,527,522,513,5,14,14,14,523,512]

theorem envBound394 : H12AffineFastState.Bounded env394 := by
  intro p hp
  have h : env394.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans393_394 : H12AffineEnvironment.transform 5 10 env393 = env394 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env393 == env394) = true)

theorem identity394 : scanCanonicalize (H12AffineFastState.compose env394 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound394 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env395 : List Nat := [2,4,6,5,0,4,7,5,512,5,513,513,6,516,0,2,516,513,0,0,517,0,1,3,7,0,512,513,516,513,5,0,0,0,517,512]

theorem envBound395 : H12AffineFastState.Bounded env395 := by
  intro p hp
  have h : env395.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans394_395 : H12AffineEnvironment.transform 2 6 env394 = env395 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env394 == env395) = true)

theorem identity395 : scanCanonicalize (H12AffineFastState.compose env395 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 3) := by decide +kernel

theorem selectedBound395 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env396 : List Nat := [2,4,6,5,0,4,7,5,3,5,2,2,6,7,0,2,7,2,0,0,6,0,1,3,7,0,3,2,7,2,5,0,0,0,6,3]

theorem envBound396 : H12AffineFastState.Bounded env396 := by
  intro p hp
  have h : env396.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans395_396 : H12AffineEnvironment.transform 8 3 env395 = env396 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 3 env395 == env396) = true)

theorem identity396 : scanCanonicalize (H12AffineFastState.compose env396 (packedSelected [9] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound396 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env397 : List Nat := [2,1,3,0,0,1,2,0,3,0,2,2,3,2,0,2,2,2,0,0,3,0,1,3,2,0,3,2,2,2,0,0,0,0,3,3]

theorem envBound397 : H12AffineFastState.Bounded env397 := by
  intro p hp
  have h : env397.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans396_397 : H12AffineEnvironment.transform 1 1 env396 = env397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env396 == env397) = true)

def leafEnv397 : List Nat := [2,1,3,0,0,1,2,0,3,0,2,2,3,2,0,2,2,2,0,0,3,0,1,3,0,2,1,0,3,2,2,2,0,0,0,0,1,3,3,3,1,3,0]

def active397 : List Nat := [0]

def tree397 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood397 : H12WitnessSearch.Good tree397 := H12GlobalWitnessIndex.good

theorem leafIdentity397 : H12AffineFastState.composeSystem env397 rootObs = leafEnv397 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env397 rootObs == leafEnv397) = true)

theorem terminalChecked397 : H12PackedTerminal.terminalCheckFast leafEnv397 active397 tree397 = true := by decide +kernel

def env398 : List Nat := [2,4,8,16,32,64,128,253,512,173,707,571,209,755,112,65536,754,586,237,112,635,32,81,65752,89,1,706,739,554,66072,4,65787,189,65787,754,66130]

theorem envBound398 : H12AffineFastState.Bounded env398 := by
  intro p hp
  have h : env398.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans388_398 : H12AffineEnvironment.transform 9 173 env388 = env398 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 173 env388 == env398) = true)

def env399 : List Nat := [2,4,8,16,32,64,128,253,52,173,247,15,209,199,112,65536,198,126,237,112,79,32,81,65752,89,1,246,215,30,65580,4,65787,189,65787,198,65638]

theorem envBound399 : H12AffineFastState.Bounded env399 := by
  intro p hp
  have h : env399.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans398_399 : H12AffineEnvironment.transform 8 52 env398 = env399 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 52 env398 == env399) = true)

theorem identity399 : scanCanonicalize (H12AffineFastState.compose env399 (packedSelected [1] rootPS)) = affineNative (2^(6+1) ^^^ 108) := by decide +kernel

theorem selectedBound399 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env400 : List Nat := [2,4,8,16,32,64,108,17,52,65,27,15,61,43,112,65536,42,126,1,112,79,32,81,65588,89,1,26,59,30,65580,4,65559,81,65559,42,65638]

theorem envBound400 : H12AffineFastState.Bounded env400 := by
  intro p hp
  have h : env400.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans399_400 : H12AffineEnvironment.transform 6 108 env399 = env400 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 108 env399 == env400) = true)

def env401 : List Nat := [2,4,8,16,32,64,108,17,52,65,27,15,61,43,112,12,42,126,1,112,79,32,81,56,89,1,26,59,30,32,4,27,81,27,42,106]

theorem envBound401 : H12AffineFastState.Bounded env401 := by
  intro p hp
  have h : env401.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans400_401 : H12AffineEnvironment.transform 15 12 env400 = env401 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 12 env400 == env401) = true)

theorem identity401 : scanCanonicalize (H12AffineFastState.compose env401 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 31) := by decide +kernel

theorem selectedBound401 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env402 : List Nat := [2,4,8,16,32,31,51,17,52,30,27,15,61,43,47,12,42,33,1,47,16,32,14,56,6,1,26,59,30,32,4,27,14,27,42,53]

theorem envBound402 : H12AffineFastState.Bounded env402 := by
  intro p hp
  have h : env402.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans401_402 : H12AffineEnvironment.transform 5 31 env401 = env402 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 31 env401 == env402) = true)

def env403 : List Nat := [2,4,8,0,32,15,35,1,36,14,11,15,45,43,47,12,42,33,1,47,0,32,14,40,6,1,10,43,14,32,4,11,14,11,42,37]

theorem envBound403 : H12AffineFastState.Bounded env403 := by
  intro p hp
  have h : env403.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans402_403 : H12AffineEnvironment.transform 3 0 env402 = env403 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env402 == env403) = true)

def env404 : List Nat := [2,4,8,0,0,15,3,1,4,14,11,15,13,11,15,12,10,1,1,15,0,0,14,8,6,1,10,11,14,0,4,11,14,11,10,5]

theorem envBound404 : H12AffineFastState.Bounded env404 := by
  intro p hp
  have h : env404.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans403_404 : H12AffineEnvironment.transform 4 0 env403 = env404 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env403 == env404) = true)

theorem identity404 : scanCanonicalize (H12AffineFastState.compose env404 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound404 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env405 : List Nat := [1,4,8,0,0,12,0,1,4,13,8,12,13,8,12,12,9,1,1,12,0,0,13,8,5,1,9,8,13,0,4,8,13,8,9,5]

theorem envBound405 : H12AffineFastState.Bounded env405 := by
  intro p hp
  have h : env405.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans404_405 : H12AffineEnvironment.transform 0 1 env404 = env405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env404 == env405) = true)

def leafEnv405 : List Nat := [1,4,8,0,0,12,0,1,4,13,8,12,13,8,12,12,9,1,1,12,0,0,13,8,8,5,1,1,9,8,13,0,4,8,13,8,8,5,9,5,1,1,0]

def active405 : List Nat := [1,2]

def tree405 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood405 : H12WitnessSearch.Good tree405 := H12GlobalWitnessIndex.good

theorem leafIdentity405 : H12AffineFastState.composeSystem env405 rootObs = leafEnv405 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env405 rootObs == leafEnv405) = true)

theorem terminalChecked405 : H12PackedTerminal.terminalCheckFast leafEnv405 active405 tree405 = true := by decide +kernel

def env406 : List Nat := [2,4,8,0,1,15,2,1,5,14,11,15,12,10,14,12,11,0,1,14,0,1,14,9,6,1,10,10,14,1,4,11,14,11,11,4]

theorem envBound406 : H12AffineFastState.Bounded env406 := by
  intro p hp
  have h : env406.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans403_406 : H12AffineEnvironment.transform 4 1 env403 = env406 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env403 == env406) = true)

theorem identity406 : scanCanonicalize (H12AffineFastState.compose env406 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound406 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env407 : List Nat := [2,3,8,0,1,8,2,1,2,9,11,8,11,10,9,11,11,0,1,9,0,1,9,9,1,1,10,10,9,1,3,11,9,11,11,3]

theorem envBound407 : H12AffineFastState.Bounded env407 := by
  intro p hp
  have h : env407.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans406_407 : H12AffineEnvironment.transform 1 3 env406 = env407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env406 == env407) = true)

def leafEnv407 : List Nat := [2,3,8,0,1,8,2,1,2,9,11,8,11,10,9,11,11,0,1,9,0,1,9,9,11,1,1,1,10,10,9,1,3,11,9,11,11,0,11,3,1,1,0]

def active407 : List Nat := [0,2]

def tree407 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood407 : H12WitnessSearch.Good tree407 := H12GlobalWitnessIndex.good

theorem leafIdentity407 : H12AffineFastState.composeSystem env407 rootObs = leafEnv407 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env407 rootObs == leafEnv407) = true)

theorem terminalChecked407 : H12PackedTerminal.terminalCheckFast leafEnv407 active407 tree407 = true := by decide +kernel

def env408 : List Nat := [2,4,8,1,32,14,34,0,37,15,10,15,44,43,47,12,42,33,1,47,1,32,14,41,6,1,11,42,15,32,4,10,14,10,42,36]

theorem envBound408 : H12AffineFastState.Bounded env408 := by
  intro p hp
  have h : env408.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans402_408 : H12AffineEnvironment.transform 3 1 env402 = env408 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env402 == env408) = true)

def env409 : List Nat := [2,4,8,1,0,14,2,0,5,15,10,15,12,11,15,12,10,1,1,15,1,0,14,9,6,1,11,10,15,0,4,10,14,10,10,4]

theorem envBound409 : H12AffineFastState.Bounded env409 := by
  intro p hp
  have h : env409.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans408_409 : H12AffineEnvironment.transform 4 0 env408 = env409 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env408 == env409) = true)

theorem identity409 : scanCanonicalize (H12AffineFastState.compose env409 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound409 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env410 : List Nat := [2,4,5,1,0,3,2,0,5,2,7,2,1,6,2,1,7,1,1,2,1,0,3,4,6,1,6,7,2,0,4,7,3,7,7,4]

theorem envBound410 : H12AffineFastState.Bounded env410 := by
  intro p hp
  have h : env410.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans409_410 : H12AffineEnvironment.transform 2 5 env409 = env410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env409 == env410) = true)

def leafEnv410 : List Nat := [2,4,5,1,0,3,2,0,5,2,7,2,1,6,2,1,7,1,1,2,1,0,3,4,7,6,1,1,6,7,2,0,4,7,3,7,7,7,7,4,1,0,0]

def active410 : List Nat := [0,1]

def tree410 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood410 : H12WitnessSearch.Good tree410 := H12GlobalWitnessIndex.good

theorem leafIdentity410 : H12AffineFastState.composeSystem env410 rootObs = leafEnv410 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env410 rootObs == leafEnv410) = true)

theorem terminalChecked410 : H12PackedTerminal.terminalCheckFast leafEnv410 active410 tree410 = true := by decide +kernel

def env411 : List Nat := [2,4,8,1,1,14,3,0,4,15,10,15,13,10,14,12,11,0,1,14,1,1,14,8,6,1,11,11,15,1,4,10,14,10,11,5]

theorem envBound411 : H12AffineFastState.Bounded env411 := by
  intro p hp
  have h : env411.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans408_411 : H12AffineEnvironment.transform 4 1 env408 = env411 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env408 == env411) = true)

theorem identity411 : scanCanonicalize (H12AffineFastState.compose env411 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound411 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env412 : List Nat := [2,4,1,1,1,7,3,0,4,6,3,6,4,3,7,5,2,0,1,7,1,1,7,1,6,1,2,2,6,1,4,3,7,3,2,5]

theorem envBound412 : H12AffineFastState.Bounded env412 := by
  intro p hp
  have h : env412.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans411_412 : H12AffineEnvironment.transform 2 1 env411 = env412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env411 == env412) = true)

def leafEnv412 : List Nat := [2,4,1,1,1,7,3,0,4,6,3,6,4,3,7,5,2,0,1,7,1,1,7,1,3,6,1,1,2,2,6,1,4,3,7,3,3,6,2,5,1,0,0]

def active412 : List Nat := [0,1]

def tree412 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood412 : H12WitnessSearch.Good tree412 := H12GlobalWitnessIndex.good

theorem leafIdentity412 : H12AffineFastState.composeSystem env412 rootObs = leafEnv412 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env412 rootObs == leafEnv412) = true)

theorem terminalChecked412 : H12PackedTerminal.terminalCheckFast leafEnv412 active412 tree412 = true := by decide +kernel

def env413 : List Nat := [2,4,8,16,32,64,108,17,52,65,27,15,61,43,112,13,42,126,1,112,79,32,81,57,89,1,26,59,30,33,4,26,81,26,42,107]

theorem envBound413 : H12AffineFastState.Bounded env413 := by
  intro p hp
  have h : env413.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans400_413 : H12AffineEnvironment.transform 15 13 env400 = env413 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 13 env400 == env413) = true)

def env414 : List Nat := [2,4,8,4,32,64,108,5,32,65,15,15,41,43,100,13,42,106,1,100,79,32,69,45,77,1,14,47,10,33,4,14,69,14,42,107]

theorem envBound414 : H12AffineFastState.Bounded env414 := by
  intro p hp
  have h : env414.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans413_414 : H12AffineEnvironment.transform 3 4 env413 = env414 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 4 env413 == env414) = true)

theorem identity414 : scanCanonicalize (H12AffineFastState.compose env414 (packedSelected [5] rootPS)) = affineNative (2^(5+1) ^^^ 10) := by decide +kernel

theorem selectedBound414 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env415 : List Nat := [2,4,8,4,32,10,38,5,32,11,15,15,41,43,46,13,42,32,1,46,5,32,15,45,7,1,14,47,10,33,4,14,15,14,42,33]

theorem envBound415 : H12AffineFastState.Bounded env415 := by
  intro p hp
  have h : env415.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans414_415 : H12AffineEnvironment.transform 5 10 env414 = env415 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 10 env414 == env415) = true)

def env416 : List Nat := [2,0,8,0,32,10,34,1,32,11,11,11,41,43,42,9,42,32,1,42,1,32,11,41,3,1,10,43,10,33,0,10,11,10,42,33]

theorem envBound416 : H12AffineFastState.Bounded env416 := by
  intro p hp
  have h : env416.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans415_416 : H12AffineEnvironment.transform 1 0 env415 = env416 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env415 == env416) = true)

theorem identity416 : scanCanonicalize (H12AffineFastState.compose env416 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound416 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env417 : List Nat := [1,0,8,0,32,9,33,1,32,8,8,8,41,40,41,9,41,32,1,41,1,32,8,41,0,1,9,40,9,33,0,9,8,9,41,33]

theorem envBound417 : H12AffineFastState.Bounded env417 := by
  intro p hp
  have h : env417.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans416_417 : H12AffineEnvironment.transform 0 1 env416 = env417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env416 == env417) = true)

def leafEnv417 : List Nat := [1,0,8,0,32,9,33,1,32,8,8,8,41,40,41,9,41,32,1,41,1,32,8,41,9,0,1,1,9,40,9,33,0,9,8,9,9,33,41,33,1,0,0]

def active417 : List Nat := [2,4]

def tree417 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood417 : H12WitnessSearch.Good tree417 := H12GlobalWitnessIndex.good

theorem leafIdentity417 : H12AffineFastState.composeSystem env417 rootObs = leafEnv417 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env417 rootObs == leafEnv417) = true)

theorem terminalChecked417 : H12PackedTerminal.terminalCheckFast leafEnv417 active417 tree417 = true := by decide +kernel

def env418 : List Nat := [2,1,8,1,32,10,35,0,32,11,10,10,41,43,43,8,42,32,1,43,0,32,10,40,2,1,11,42,10,33,1,11,10,11,42,33]

theorem envBound418 : H12AffineFastState.Bounded env418 := by
  intro p hp
  have h : env418.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans415_418 : H12AffineEnvironment.transform 1 1 env415 = env418 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env415 == env418) = true)

theorem identity418 : scanCanonicalize (H12AffineFastState.compose env418 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 9) := by decide +kernel

theorem selectedBound418 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env419 : List Nat := [2,1,8,1,9,10,10,0,9,11,10,10,0,2,2,8,3,9,1,2,0,9,10,1,2,1,11,3,10,8,1,11,10,11,3,8]

theorem envBound419 : H12AffineFastState.Bounded env419 := by
  intro p hp
  have h : env419.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans418_419 : H12AffineEnvironment.transform 4 9 env418 = env419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 9 env418 == env419) = true)

def leafEnv419 : List Nat := [2,1,8,1,9,10,10,0,9,11,10,10,0,2,2,8,3,9,1,2,0,9,10,1,11,2,1,1,11,3,10,8,1,11,10,11,11,11,3,8,1,1,0]

def active419 : List Nat := [0,2]

def tree419 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood419 : H12WitnessSearch.Good tree419 := H12GlobalWitnessIndex.good

theorem leafIdentity419 : H12AffineFastState.composeSystem env419 rootObs = leafEnv419 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env419 rootObs == leafEnv419) = true)

theorem terminalChecked419 : H12PackedTerminal.terminalCheckFast leafEnv419 active419 tree419 = true := by decide +kernel

def env420 : List Nat := [2,4,8,5,32,64,108,4,33,65,14,15,40,43,101,13,42,107,1,101,79,32,68,44,76,1,15,46,11,33,4,15,68,15,42,107]

theorem envBound420 : H12AffineFastState.Bounded env420 := by
  intro p hp
  have h : env420.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans413_420 : H12AffineEnvironment.transform 3 5 env413 = env420 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env413 == env420) = true)

def env421 : List Nat := [2,4,8,5,32,36,8,4,33,37,14,15,40,43,1,13,42,15,1,1,43,32,32,44,40,1,15,46,11,33,4,15,32,15,42,15]

theorem envBound421 : H12AffineFastState.Bounded env421 := by
  intro p hp
  have h : env421.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans420_421 : H12AffineEnvironment.transform 5 36 env420 = env421 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 36 env420 == env421) = true)

theorem identity421 : scanCanonicalize (H12AffineFastState.compose env421 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 4) := by decide +kernel

theorem selectedBound421 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env422 : List Nat := [2,4,4,5,32,36,4,4,33,37,2,3,36,39,1,1,38,3,1,1,39,32,32,32,36,1,3,34,7,33,4,3,32,3,38,3]

theorem envBound422 : H12AffineFastState.Bounded env422 := by
  intro p hp
  have h : env422.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans421_422 : H12AffineEnvironment.transform 2 4 env421 = env422 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 4 env421 == env422) = true)

theorem identity422 : scanCanonicalize (H12AffineFastState.compose env422 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 3) := by decide +kernel

theorem selectedBound422 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env423 : List Nat := [2,4,4,5,3,7,4,4,2,6,2,3,7,4,1,1,5,3,1,1,4,3,3,3,7,1,3,1,7,2,4,3,3,3,5,3]

theorem envBound423 : H12AffineFastState.Bounded env423 := by
  intro p hp
  have h : env423.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans422_423 : H12AffineEnvironment.transform 4 3 env422 = env423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 3 env422 == env423) = true)

def leafEnv423 : List Nat := [2,4,4,5,3,7,4,4,2,6,2,3,7,4,1,1,5,3,1,1,4,3,3,3,3,7,1,1,3,1,7,2,4,3,3,3,3,0,5,3,1,5,0]

def active423 : List Nat := [0,1]

def tree423 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood423 : H12WitnessSearch.Good tree423 := H12GlobalWitnessIndex.good

theorem leafIdentity423 : H12AffineFastState.composeSystem env423 rootObs = leafEnv423 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env423 rootObs == leafEnv423) = true)

theorem terminalChecked423 : H12PackedTerminal.terminalCheckFast leafEnv423 active423 tree423 = true := by decide +kernel

def env424 : List Nat := [2,4,8,5,32,37,9,4,33,36,14,15,40,43,0,13,42,14,1,0,42,32,33,44,41,1,15,46,11,33,4,15,33,15,42,14]

theorem envBound424 : H12AffineFastState.Bounded env424 := by
  intro p hp
  have h : env424.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans420_424 : H12AffineEnvironment.transform 5 37 env420 = env424 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 37 env420 == env424) = true)

theorem identity424 : scanCanonicalize (H12AffineFastState.compose env424 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 6) := by decide +kernel

theorem selectedBound424 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env425 : List Nat := [2,4,8,5,6,3,9,4,7,2,14,15,14,13,0,13,12,14,1,0,12,6,7,10,15,1,15,8,11,7,4,15,7,15,12,14]

theorem envBound425 : H12AffineFastState.Bounded env425 := by
  intro p hp
  have h : env425.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans424_425 : H12AffineEnvironment.transform 4 6 env424 = env425 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 6 env424 == env425) = true)

def env426 : List Nat := [2,4,0,5,6,3,1,4,7,2,6,7,6,5,0,5,4,6,1,0,4,6,7,2,7,1,7,0,3,7,4,7,7,7,4,6]

theorem envBound426 : H12AffineFastState.Bounded env426 := by
  intro p hp
  have h : env426.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans425_426 : H12AffineEnvironment.transform 2 0 env425 = env426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env425 == env426) = true)

def leafEnv426 : List Nat := [2,4,0,5,6,3,1,4,7,2,6,7,6,5,0,5,4,6,1,0,4,6,7,2,7,7,1,1,7,0,3,7,4,7,7,7,7,5,4,6,1,5,0]

def active426 : List Nat := [0,1]

def tree426 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood426 : H12WitnessSearch.Good tree426 := H12GlobalWitnessIndex.good

theorem leafIdentity426 : H12AffineFastState.composeSystem env426 rootObs = leafEnv426 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env426 rootObs == leafEnv426) = true)

theorem terminalChecked426 : H12PackedTerminal.terminalCheckFast leafEnv426 active426 tree426 = true := by decide +kernel

def env427 : List Nat := [2,4,1,5,6,3,0,4,7,2,7,6,7,4,0,4,5,7,1,0,5,6,7,3,6,1,6,1,2,7,4,6,7,6,5,7]

theorem envBound427 : H12AffineFastState.Bounded env427 := by
  intro p hp
  have h : env427.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans425_427 : H12AffineEnvironment.transform 2 1 env425 = env427 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env425 == env427) = true)

theorem identity427 : scanCanonicalize (H12AffineFastState.compose env427 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound427 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env428 : List Nat := [2,3,1,2,1,3,0,3,0,2,0,1,0,3,0,3,2,0,1,0,2,1,0,3,1,1,1,1,2,0,3,1,0,1,2,0]

theorem envBound428 : H12AffineFastState.Bounded env428 := by
  intro p hp
  have h : env428.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans427_428 : H12AffineEnvironment.transform 1 3 env427 = env428 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env427 == env428) = true)

theorem identity428 : scanCanonicalize (H12AffineFastState.compose env428 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound428 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env429 : List Nat := [1,0,1,1,1,0,0,0,0,1,0,1,0,0,0,0,1,0,1,0,1,1,0,0,1,1,1,1,1,0,0,1,0,1,1,0]

theorem envBound429 : H12AffineFastState.Bounded env429 := by
  intro p hp
  have h : env429.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans428_429 : H12AffineEnvironment.transform 0 1 env428 = env429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env428 == env429) = true)

def leafEnv429 : List Nat := [1,0,1,1,1,0,0,0,0,1,0,1,0,0,0,0,1,0,1,0,1,1,0,0,0,1,1,1,1,1,1,0,0,1,0,1,0,1,1,0,1,1,0]

def active429 : List Nat := []

def tree429 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood429 : H12WitnessSearch.Good tree429 := H12GlobalWitnessIndex.good

theorem leafIdentity429 : H12AffineFastState.composeSystem env429 rootObs = leafEnv429 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env429 rootObs == leafEnv429) = true)

theorem terminalChecked429 : H12PackedTerminal.terminalCheckFast leafEnv429 active429 tree429 = true := by decide +kernel

def env430 : List Nat := [2,4,8,16,32,64,128,253,53,173,246,14,209,198,112,65536,199,127,237,112,78,32,81,65752,89,1,247,214,31,65581,4,65787,189,65787,199,65639]

theorem envBound430 : H12AffineFastState.Bounded env430 := by
  intro p hp
  have h : env430.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans398_430 : H12AffineEnvironment.transform 8 53 env398 = env430 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 53 env398 == env430) = true)

theorem identity430 : scanCanonicalize (H12AffineFastState.compose env430 (packedSelected [1] rootPS)) = affineNative (2^(15+1) ^^^ 190) := by decide +kernel

theorem selectedBound430 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env431 : List Nat := [2,4,8,16,32,64,128,253,53,173,246,14,209,198,112,190,199,127,237,112,78,32,81,102,89,1,247,214,31,147,4,69,189,69,199,217]

theorem envBound431 : H12AffineFastState.Bounded env431 := by
  intro p hp
  have h : env431.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans430_431 : H12AffineEnvironment.transform 15 190 env430 = env431 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 190 env430 == env431) = true)

def env432 : List Nat := [2,4,8,16,32,64,108,17,53,65,26,14,61,42,112,82,43,127,1,112,78,32,81,102,89,1,27,58,31,127,4,69,81,69,43,53]

theorem envBound432 : H12AffineFastState.Bounded env432 := by
  intro p hp
  have h : env432.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans431_432 : H12AffineEnvironment.transform 6 108 env431 = env432 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 108 env431 == env432) = true)

theorem identity432 : scanCanonicalize (H12AffineFastState.compose env432 (packedSelected [3] rootPS)) = affineNative (2^(5+1) ^^^ 31) := by decide +kernel

theorem selectedBound432 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env433 : List Nat := [2,4,8,16,32,31,51,17,53,30,26,14,61,42,47,13,43,32,1,47,17,32,14,57,6,1,27,58,31,32,4,26,14,26,43,53]

theorem envBound433 : H12AffineFastState.Bounded env433 := by
  intro p hp
  have h : env433.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans432_433 : H12AffineEnvironment.transform 5 31 env432 = env433 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 31 env432 == env433) = true)

theorem identity433 : scanCanonicalize (H12AffineFastState.compose env433 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound433 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env434 : List Nat := [2,4,8,16,1,31,18,17,20,30,26,14,28,11,14,13,10,1,1,14,17,1,14,24,6,1,27,27,31,1,4,26,14,26,10,20]

theorem envBound434 : H12AffineFastState.Bounded env434 := by
  intro p hp
  have h : env434.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans433_434 : H12AffineEnvironment.transform 4 1 env433 = env434 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env433 == env434) = true)

theorem identity434 : scanCanonicalize (H12AffineFastState.compose env434 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 5) := by decide +kernel

theorem selectedBound434 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env435 : List Nat := [2,4,8,5,1,10,7,4,1,11,15,14,9,11,14,13,10,1,1,14,4,1,14,13,6,1,14,14,10,1,4,15,14,15,10,1]

theorem envBound435 : H12AffineFastState.Bounded env435 := by
  intro p hp
  have h : env435.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans434_435 : H12AffineEnvironment.transform 3 5 env434 = env435 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 5 env434 == env435) = true)

theorem identity435 : scanCanonicalize (H12AffineFastState.compose env435 (packedSelected [0,7] rootPS)) = affineNative (2^(2+1) ^^^ 6) := by decide +kernel

theorem selectedBound435 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env436 : List Nat := [2,4,6,5,1,4,7,4,1,5,1,0,7,5,0,3,4,1,1,0,4,1,0,3,6,1,0,0,4,1,4,1,0,1,4,1]

theorem envBound436 : H12AffineFastState.Bounded env436 := by
  intro p hp
  have h : env436.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans435_436 : H12AffineEnvironment.transform 2 6 env435 = env436 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 6 env435 == env436) = true)

theorem identity436 : scanCanonicalize (H12AffineFastState.compose env436 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound436 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env437 : List Nat := [2,2,0,3,1,2,1,2,1,3,1,0,1,3,0,3,2,1,1,0,2,1,0,3,0,1,0,0,2,1,2,1,0,1,2,1]

theorem envBound437 : H12AffineFastState.Bounded env437 := by
  intro p hp
  have h : env437.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans436_437 : H12AffineEnvironment.transform 1 2 env436 = env437 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env436 == env437) = true)

theorem identity437 : scanCanonicalize (H12AffineFastState.compose env437 (packedSelected [9] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound437 : packedSelected [9] rootPS < 2^1333 := by decide +kernel

def env438 : List Nat := [0,0,0,1,1,0,1,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,0,1,0,1,0,0,0,1,0,1,0,1,0,1]

theorem envBound438 : H12AffineFastState.Bounded env438 := by
  intro p hp
  have h : env438.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans437_438 : H12AffineEnvironment.transform 0 0 env437 = env438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env437 == env438) = true)

def leafEnv438 : List Nat := [0,0,0,1,1,0,1,0,1,1,1,0,1,1,0,1,0,1,1,0,0,1,0,1,0,0,1,1,0,0,0,1,0,1,0,1,0,0,0,1,1,0,0]

def active438 : List Nat := []

def tree438 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood438 : H12WitnessSearch.Good tree438 := H12GlobalWitnessIndex.good

theorem leafIdentity438 : H12AffineFastState.composeSystem env438 rootObs = leafEnv438 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env438 rootObs == leafEnv438) = true)

theorem terminalChecked438 : H12PackedTerminal.terminalCheckFast leafEnv438 active438 tree438 = true := by decide +kernel

def env439 : List Nat := [2,4,8,16,32,64,109,16,53,64,27,14,60,43,112,83,42,127,0,112,78,32,81,102,89,1,26,59,31,126,4,69,80,69,42,52]

theorem envBound439 : H12AffineFastState.Bounded env439 := by
  intro p hp
  have h : env439.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans431_439 : H12AffineEnvironment.transform 6 109 env431 = env439 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 109 env431 == env439) = true)

def env440 : List Nat := [2,4,8,16,0,64,77,16,21,64,27,14,28,11,80,83,10,95,0,80,78,0,81,70,89,1,26,27,31,94,4,69,80,69,10,20]

theorem envBound440 : H12AffineFastState.Bounded env440 := by
  intro p hp
  have h : env440.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans439_440 : H12AffineEnvironment.transform 4 0 env439 = env440 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env439 == env440) = true)

def env441 : List Nat := [2,4,8,16,0,0,13,16,21,0,27,14,28,11,16,19,10,31,0,16,14,0,17,6,25,1,26,27,31,30,4,5,16,5,10,20]

theorem envBound441 : H12AffineFastState.Bounded env441 := by
  intro p hp
  have h : env441.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans440_441 : H12AffineEnvironment.transform 5 0 env440 = env441 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env440 == env441) = true)

theorem identity441 : scanCanonicalize (H12AffineFastState.compose env441 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound441 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env442 : List Nat := [1,4,8,16,0,0,13,16,21,0,24,13,28,8,16,16,9,28,0,16,13,0,17,5,25,1,25,24,28,29,4,5,16,5,9,20]

theorem envBound442 : H12AffineFastState.Bounded env442 := by
  intro p hp
  have h : env442.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans441_442 : H12AffineEnvironment.transform 0 1 env441 = env442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env441 == env442) = true)

def leafEnv442 : List Nat := [1,4,8,16,0,0,13,16,21,0,24,13,28,8,16,16,9,28,0,16,13,0,17,5,4,25,1,1,25,24,28,29,4,5,16,5,4,20,9,20,1,12,0]

def active442 : List Nat := [1,2,3]

def tree442 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood442 : H12WitnessSearch.Good tree442 := H12GlobalWitnessIndex.good

theorem leafIdentity442 : H12AffineFastState.composeSystem env442 rootObs = leafEnv442 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env442 rootObs == leafEnv442) = true)

theorem terminalChecked442 : H12PackedTerminal.terminalCheckFast leafEnv442 active442 tree442 = true := by decide +kernel

def env443 : List Nat := [2,4,8,16,0,1,12,16,21,1,27,14,28,11,17,18,10,30,0,17,15,0,16,7,24,1,26,27,31,31,4,4,17,4,10,20]

theorem envBound443 : H12AffineFastState.Bounded env443 := by
  intro p hp
  have h : env443.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans440_443 : H12AffineEnvironment.transform 5 1 env440 = env443 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env440 == env443) = true)

theorem identity443 : scanCanonicalize (H12AffineFastState.compose env443 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound443 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env444 : List Nat := [2,4,8,3,0,1,12,3,6,1,8,14,15,11,2,1,10,13,0,2,15,0,3,7,11,1,9,8,12,12,4,4,2,4,10,7]

theorem envBound444 : H12AffineFastState.Bounded env444 := by
  intro p hp
  have h : env444.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans443_444 : H12AffineEnvironment.transform 3 3 env443 = env444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env443 == env444) = true)

def leafEnv444 : List Nat := [2,4,8,3,0,1,12,3,6,1,8,14,15,11,2,1,10,13,0,2,15,0,3,7,5,11,1,1,9,8,12,12,4,4,2,4,5,4,10,7,1,14,0]

def active444 : List Nat := [0,1,2]

def tree444 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood444 : H12WitnessSearch.Good tree444 := H12GlobalWitnessIndex.good

theorem leafIdentity444 : H12AffineFastState.composeSystem env444 rootObs = leafEnv444 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env444 rootObs == leafEnv444) = true)

theorem terminalChecked444 : H12PackedTerminal.terminalCheckFast leafEnv444 active444 tree444 = true := by decide +kernel

def env445 : List Nat := [2,4,8,16,1,64,76,16,20,64,27,14,29,10,81,83,11,94,0,81,78,1,81,71,89,1,26,26,31,95,4,69,80,69,11,21]

theorem envBound445 : H12AffineFastState.Bounded env445 := by
  intro p hp
  have h : env445.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans439_445 : H12AffineEnvironment.transform 4 1 env439 = env445 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env439 == env445) = true)

def env446 : List Nat := [2,4,8,16,1,0,12,16,20,0,27,14,29,10,17,19,11,30,0,17,14,1,17,7,25,1,26,26,31,31,4,5,16,5,11,21]

theorem envBound446 : H12AffineFastState.Bounded env446 := by
  intro p hp
  have h : env446.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans445_446 : H12AffineEnvironment.transform 5 0 env445 = env446 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env445 == env446) = true)

theorem identity446 : scanCanonicalize (H12AffineFastState.compose env446 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound446 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env447 : List Nat := [2,2,8,16,1,0,10,16,18,0,27,8,27,10,17,19,11,24,0,17,8,1,17,1,25,1,26,26,25,25,2,3,16,3,11,19]

theorem envBound447 : H12AffineFastState.Bounded env447 := by
  intro p hp
  have h : env447.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans446_447 : H12AffineEnvironment.transform 1 2 env446 = env447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env446 == env447) = true)

def leafEnv447 : List Nat := [2,2,8,16,1,0,10,16,18,0,27,8,27,10,17,19,11,24,0,17,8,1,17,1,2,25,1,1,26,26,25,25,2,3,16,3,2,16,11,19,1,9,0]

def active447 : List Nat := [0,2,3]

def tree447 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood447 : H12WitnessSearch.Good tree447 := H12GlobalWitnessIndex.good

theorem leafIdentity447 : H12AffineFastState.composeSystem env447 rootObs = leafEnv447 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env447 rootObs == leafEnv447) = true)

theorem terminalChecked447 : H12PackedTerminal.terminalCheckFast leafEnv447 active447 tree447 = true := by decide +kernel

def env448 : List Nat := [2,4,8,16,1,1,13,16,20,1,27,14,29,10,16,18,11,31,0,16,15,1,16,6,24,1,26,26,31,30,4,4,17,4,11,21]

theorem envBound448 : H12AffineFastState.Bounded env448 := by
  intro p hp
  have h : env448.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans445_448 : H12AffineEnvironment.transform 5 1 env445 = env448 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env445 == env448) = true)

theorem identity448 : scanCanonicalize (H12AffineFastState.compose env448 (packedSelected [0] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound448 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env449 : List Nat := [2,4,8,6,1,1,13,6,2,1,13,14,11,10,6,4,11,9,0,6,15,1,6,6,14,1,12,12,9,8,4,4,7,4,11,3]

theorem envBound449 : H12AffineFastState.Bounded env449 := by
  intro p hp
  have h : env449.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans448_449 : H12AffineEnvironment.transform 3 6 env448 = env449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env448 == env449) = true)

def leafEnv449 : List Nat := [2,4,8,6,1,1,13,6,2,1,13,14,11,10,6,4,11,9,0,6,15,1,6,6,5,14,1,1,12,12,9,8,4,4,7,4,5,0,11,3,1,14,0]

def active449 : List Nat := [0,1,2]

def tree449 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood449 : H12WitnessSearch.Good tree449 := H12GlobalWitnessIndex.good

theorem leafIdentity449 : H12AffineFastState.composeSystem env449 rootObs = leafEnv449 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env449 rootObs == leafEnv449) = true)

theorem terminalChecked449 : H12PackedTerminal.terminalCheckFast leafEnv449 active449 tree449 = true := by decide +kernel

def env450 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1646,4096,1149,4296,1244,65536,755,1767,237,1244,1751,32,1276,66676,1269,1196,1647,1615,5308,66073,1193,66647,1040,66647,4297,67326]

theorem envBound450 : H12AffineFastState.Bounded env450 := by
  intro p hp
  have h : env450.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans386_450 : H12AffineEnvironment.transform 12 1149 env386 = env450 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1149 env386 == env450) = true)

theorem identity450 : scanCanonicalize (H12AffineFastState.compose env450 (packedSelected [2] rootPS)) = affineNative (2^(15+1) ^^^ 4712) := by decide +kernel

theorem selectedBound450 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env451 : List Nat := [2,4,8,16,32,64,128,253,512,1024,1646,4096,1149,4296,1244,4712,755,1767,237,1244,1751,32,1276,5660,1269,1196,1647,1615,5308,4209,1193,5695,1040,5695,4297,5270]

theorem envBound451 : H12AffineFastState.Bounded env451 := by
  intro p hp
  have h : env451.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans450_451 : H12AffineEnvironment.transform 15 4712 env450 = env451 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 4712 env450 == env451) = true)

def env452 : List Nat := [2,4,8,16,32,64,128,253,512,172,706,4096,209,4296,112,4712,755,587,237,112,635,32,80,4784,89,0,707,739,4112,4209,5,4755,188,4755,4297,4154]

theorem envBound452 : H12AffineFastState.Bounded env452 := by
  intro p hp
  have h : env452.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans451_452 : H12AffineEnvironment.transform 9 172 env451 = env452 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 172 env451 == env452) = true)

def env453 : List Nat := [2,4,8,16,32,64,128,253,512,172,706,548,209,748,112,76,755,587,237,112,635,32,80,148,89,0,707,739,564,597,5,183,188,183,749,542]

theorem envBound453 : H12AffineFastState.Bounded env453 := by
  intro p hp
  have h : env453.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans452_453 : H12AffineEnvironment.transform 11 548 env452 = env453 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 548 env452 == env453) = true)

theorem identity453 : scanCanonicalize (H12AffineFastState.compose env453 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 216) := by decide +kernel

theorem selectedBound453 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env454 : List Nat := [2,4,8,16,32,64,128,253,216,172,26,252,209,52,112,76,43,147,237,112,163,32,80,148,89,0,27,59,236,141,5,183,188,183,53,198]

theorem envBound454 : H12AffineFastState.Bounded env454 := by
  intro p hp
  have h : env454.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans453_454 : H12AffineEnvironment.transform 8 216 env453 = env454 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 216 env453 == env454) = true)

def env455 : List Nat := [2,4,8,16,32,64,44,81,116,0,26,80,125,52,112,76,43,63,65,112,15,32,80,56,89,0,27,59,64,33,5,27,16,27,53,106]

theorem envBound455 : H12AffineFastState.Bounded env455 := by
  intro p hp
  have h : env455.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans454_455 : H12AffineEnvironment.transform 6 44 env454 = env455 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env454 == env455) = true)

theorem identity455 : scanCanonicalize (H12AffineFastState.compose env455 (packedSelected [3] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound455 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env456 : List Nat := [2,4,8,15,32,64,44,78,107,0,5,79,98,43,111,76,43,32,65,111,15,32,79,39,70,0,4,36,64,33,5,4,15,4,42,106]

theorem envBound456 : H12AffineFastState.Bounded env456 := by
  intro p hp
  have h : env456.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans455_456 : H12AffineEnvironment.transform 3 15 env455 = env456 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env455 == env456) = true)

def env457 : List Nat := [2,4,8,15,32,0,44,14,43,0,5,15,34,43,47,12,43,32,1,47,15,32,15,39,6,0,4,36,0,33,5,4,15,4,42,42]

theorem envBound457 : H12AffineFastState.Bounded env457 := by
  intro p hp
  have h : env457.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans456_457 : H12AffineEnvironment.transform 5 0 env456 = env457 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env456 == env457) = true)

def env458 : List Nat := [2,4,8,15,0,0,12,14,11,0,5,15,2,11,15,12,11,0,1,15,15,0,15,7,6,0,4,4,0,1,5,4,15,4,10,10]

theorem envBound458 : H12AffineFastState.Bounded env458 := by
  intro p hp
  have h : env458.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans457_458 : H12AffineEnvironment.transform 4 0 env457 = env458 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env457 == env458) = true)

theorem identity458 : scanCanonicalize (H12AffineFastState.compose env458 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound458 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env459 : List Nat := [2,4,5,2,0,0,1,3,6,0,5,2,2,6,2,1,6,0,1,2,2,0,2,7,6,0,4,4,0,1,5,4,2,4,7,7]

theorem envBound459 : H12AffineFastState.Bounded env459 := by
  intro p hp
  have h : env459.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans458_459 : H12AffineEnvironment.transform 2 5 env458 = env459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env458 == env459) = true)

def leafEnv459 : List Nat := [2,4,5,2,0,0,1,3,6,0,5,2,2,6,2,1,6,0,1,2,2,0,2,7,4,6,1,0,4,4,0,1,5,4,2,4,5,4,7,7,1,3,0]

def active459 : List Nat := [0,1]

def tree459 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood459 : H12WitnessSearch.Good tree459 := H12GlobalWitnessIndex.good

theorem leafIdentity459 : H12AffineFastState.composeSystem env459 rootObs = leafEnv459 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env459 rootObs == leafEnv459) = true)

theorem terminalChecked459 : H12PackedTerminal.terminalCheckFast leafEnv459 active459 tree459 = true := by decide +kernel

def env460 : List Nat := [2,4,8,15,1,0,13,14,10,0,5,15,3,10,14,12,10,1,1,14,15,1,15,6,6,0,4,5,0,0,5,4,15,4,11,11]

theorem envBound460 : H12AffineFastState.Bounded env460 := by
  intro p hp
  have h : env460.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans457_460 : H12AffineEnvironment.transform 4 1 env457 = env460 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env457 == env460) = true)

theorem identity460 : scanCanonicalize (H12AffineFastState.compose env460 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 0) := by decide +kernel

theorem selectedBound460 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env461 : List Nat := [2,4,0,7,1,0,5,6,2,0,5,7,3,2,6,4,2,1,1,6,7,1,7,6,6,0,4,5,0,0,5,4,7,4,3,3]

theorem envBound461 : H12AffineFastState.Bounded env461 := by
  intro p hp
  have h : env461.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans460_461 : H12AffineEnvironment.transform 2 0 env460 = env461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env460 == env461) = true)

def leafEnv461 : List Nat := [2,4,0,7,1,0,5,6,2,0,5,7,3,2,6,4,2,1,1,6,7,1,7,6,4,6,1,0,4,5,0,0,5,4,7,4,5,0,3,3,1,6,0]

def active461 : List Nat := [0,1]

def tree461 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood461 : H12WitnessSearch.Good tree461 := H12GlobalWitnessIndex.good

theorem leafIdentity461 : H12AffineFastState.composeSystem env461 rootObs = leafEnv461 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env461 rootObs == leafEnv461) = true)

theorem terminalChecked461 : H12PackedTerminal.terminalCheckFast leafEnv461 active461 tree461 = true := by decide +kernel

def env462 : List Nat := [2,4,8,15,32,1,44,15,42,0,5,14,35,43,46,13,43,32,0,46,15,32,14,39,7,0,4,36,1,33,5,4,15,4,42,43]

theorem envBound462 : H12AffineFastState.Bounded env462 := by
  intro p hp
  have h : env462.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans456_462 : H12AffineEnvironment.transform 5 1 env456 = env462 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env456 == env462) = true)

def env463 : List Nat := [2,4,8,15,0,1,12,15,10,0,5,14,3,11,14,13,11,0,0,14,15,0,14,7,7,0,4,4,1,1,5,4,15,4,10,11]

theorem envBound463 : H12AffineFastState.Bounded env463 := by
  intro p hp
  have h : env463.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans462_463 : H12AffineEnvironment.transform 4 0 env462 = env463 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env462 == env463) = true)

theorem identity463 : scanCanonicalize (H12AffineFastState.compose env463 (packedSelected [0] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound463 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env464 : List Nat := [1,4,8,12,0,1,12,12,9,0,5,13,0,8,13,13,8,0,0,13,12,0,13,4,4,0,4,4,1,1,5,4,12,4,9,8]

theorem envBound464 : H12AffineFastState.Bounded env464 := by
  intro p hp
  have h : env464.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans463_464 : H12AffineEnvironment.transform 0 1 env463 = env464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env463 == env464) = true)

def leafEnv464 : List Nat := [1,4,8,12,0,1,12,12,9,0,5,13,0,8,13,13,8,0,0,13,12,0,13,4,5,4,1,0,4,4,1,1,5,4,12,4,4,8,9,8,1,13,0]

def active464 : List Nat := [1,2]

def tree464 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood464 : H12WitnessSearch.Good tree464 := H12GlobalWitnessIndex.good

theorem leafIdentity464 : H12AffineFastState.composeSystem env464 rootObs = leafEnv464 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env464 rootObs == leafEnv464) = true)

theorem terminalChecked464 : H12PackedTerminal.terminalCheckFast leafEnv464 active464 tree464 = true := by decide +kernel

def env465 : List Nat := [2,4,8,15,1,1,13,15,11,0,5,14,2,10,15,13,10,1,0,15,15,1,14,6,7,0,4,5,1,0,5,4,15,4,11,10]

theorem envBound465 : H12AffineFastState.Bounded env465 := by
  intro p hp
  have h : env465.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans462_465 : H12AffineEnvironment.transform 4 1 env462 = env465 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env462 == env465) = true)

theorem identity465 : scanCanonicalize (H12AffineFastState.compose env465 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 3) := by decide +kernel

theorem selectedBound465 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env466 : List Nat := [2,3,8,8,1,1,10,8,11,0,2,9,2,10,8,10,10,1,0,8,8,1,9,1,0,0,3,2,1,0,2,3,8,3,11,10]

theorem envBound466 : H12AffineFastState.Bounded env466 := by
  intro p hp
  have h : env466.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans465_466 : H12AffineEnvironment.transform 1 3 env465 = env466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 3 env465 == env466) = true)

def leafEnv466 : List Nat := [2,3,8,8,1,1,10,8,11,0,2,9,2,10,8,10,10,1,0,8,8,1,9,1,2,0,1,0,3,2,1,0,2,3,8,3,3,9,11,10,1,9,0]

def active466 : List Nat := [0,2]

def tree466 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood466 : H12WitnessSearch.Good tree466 := H12GlobalWitnessIndex.good

theorem leafIdentity466 : H12AffineFastState.composeSystem env466 rootObs = leafEnv466 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env466 rootObs == leafEnv466) = true)

theorem terminalChecked466 : H12PackedTerminal.terminalCheckFast leafEnv466 active466 tree466 = true := by decide +kernel

def env467 : List Nat := [2,4,8,16,32,64,45,80,117,1,26,81,124,52,112,76,43,62,64,112,14,32,80,57,89,0,27,59,65,32,5,26,17,26,53,107]

theorem envBound467 : H12AffineFastState.Bounded env467 := by
  intro p hp
  have h : env467.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans454_467 : H12AffineEnvironment.transform 6 45 env454 = env467 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 45 env454 == env467) = true)

def env468 : List Nat := [2,4,8,16,32,20,45,4,33,1,26,5,40,52,36,24,43,62,20,36,14,32,4,57,13,0,27,59,21,32,5,26,17,26,53,63]

theorem envBound468 : H12AffineFastState.Bounded env468 := by
  intro p hp
  have h : env468.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans467_468 : H12AffineEnvironment.transform 5 20 env467 = env468 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env467 == env468) = true)

theorem identity468 : scanCanonicalize (H12AffineFastState.compose env468 (packedSelected [5] rootPS)) = affineNative (2^(3+1) ^^^ 15) := by decide +kernel

theorem selectedBound468 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env469 : List Nat := [2,4,8,15,32,11,45,4,33,1,5,5,40,43,36,7,43,33,11,36,14,32,4,38,13,0,4,36,10,32,5,5,14,5,42,32]

theorem envBound469 : H12AffineFastState.Bounded env469 := by
  intro p hp
  have h : env469.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans468_469 : H12AffineEnvironment.transform 3 15 env468 = env469 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 15 env468 == env469) = true)

def env470 : List Nat := [2,4,8,15,4,11,9,4,5,1,5,5,12,15,0,7,15,5,11,0,14,4,4,2,13,0,4,0,10,4,5,5,14,5,14,4]

theorem envBound470 : H12AffineFastState.Bounded env470 := by
  intro p hp
  have h : env470.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans469_470 : H12AffineEnvironment.transform 4 4 env469 = env470 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 4 env469 == env470) = true)

theorem identity470 : scanCanonicalize (H12AffineFastState.compose env470 (packedSelected [0] rootPS)) = affineNative (2^(2+1) ^^^ 1) := by decide +kernel

theorem selectedBound470 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env471 : List Nat := [2,4,1,6,4,2,0,4,5,1,5,5,5,6,0,7,6,5,2,0,7,4,4,2,4,0,4,0,3,4,5,5,7,5,7,4]

theorem envBound471 : H12AffineFastState.Bounded env471 := by
  intro p hp
  have h : env471.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans470_471 : H12AffineEnvironment.transform 2 1 env470 = env471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env470 == env471) = true)

def leafEnv471 : List Nat := [2,4,1,6,4,2,0,4,5,1,5,5,5,6,0,7,6,5,2,0,7,4,4,2,6,4,1,0,4,0,3,4,5,5,7,5,7,7,7,4,1,6,0]

def active471 : List Nat := [0,1]

def tree471 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood471 : H12WitnessSearch.Good tree471 := H12GlobalWitnessIndex.good

theorem leafIdentity471 : H12AffineFastState.composeSystem env471 rootObs = leafEnv471 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env471 rootObs == leafEnv471) = true)

theorem terminalChecked471 : H12PackedTerminal.terminalCheckFast leafEnv471 active471 tree471 = true := by decide +kernel

def env472 : List Nat := [2,4,8,15,5,11,8,4,4,1,5,5,13,14,1,7,14,4,11,1,14,5,4,3,13,0,4,1,10,5,5,5,14,5,15,5]

theorem envBound472 : H12AffineFastState.Bounded env472 := by
  intro p hp
  have h : env472.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans469_472 : H12AffineEnvironment.transform 4 5 env469 = env472 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env469 == env472) = true)

theorem identity472 : scanCanonicalize (H12AffineFastState.compose env472 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound472 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env473 : List Nat := [2,2,8,9,3,11,8,2,2,1,3,3,11,8,1,1,8,2,11,1,8,3,2,3,11,0,2,1,10,3,3,3,8,3,9,3]

theorem envBound473 : H12AffineFastState.Bounded env473 := by
  intro p hp
  have h : env473.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans472_473 : H12AffineEnvironment.transform 1 2 env472 = env473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env472 == env473) = true)

def leafEnv473 : List Nat := [2,2,8,9,3,11,8,2,2,1,3,3,11,8,1,1,8,2,11,1,8,3,2,3,9,11,1,0,2,1,10,3,3,3,8,3,8,0,9,3,1,9,0]

def active473 : List Nat := [0,2]

def tree473 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood473 : H12WitnessSearch.Good tree473 := H12GlobalWitnessIndex.good

theorem leafIdentity473 : H12AffineFastState.composeSystem env473 rootObs = leafEnv473 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env473 rootObs == leafEnv473) = true)

theorem terminalChecked473 : H12PackedTerminal.terminalCheckFast leafEnv473 active473 tree473 = true := by decide +kernel

def env474 : List Nat := [2,4,8,16,32,21,45,5,32,1,26,4,41,52,37,25,43,62,21,37,14,32,5,57,12,0,27,59,20,32,5,26,17,26,53,62]

theorem envBound474 : H12AffineFastState.Bounded env474 := by
  intro p hp
  have h : env474.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans467_474 : H12AffineEnvironment.transform 5 21 env467 = env474 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 21 env467 == env474) = true)

def env475 : List Nat := [2,4,8,0,32,5,45,5,32,1,10,4,41,36,37,9,43,46,5,37,14,32,5,41,12,0,11,43,4,32,5,10,1,10,37,46]

theorem envBound475 : H12AffineFastState.Bounded env475 := by
  intro p hp
  have h : env475.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans474_475 : H12AffineEnvironment.transform 3 0 env474 = env475 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env474 == env475) = true)

theorem identity475 : scanCanonicalize (H12AffineFastState.compose env475 (packedSelected [4] rootPS)) = affineNative (2^(4+1) ^^^ 8) := by decide +kernel

theorem selectedBound475 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env476 : List Nat := [2,4,8,0,8,5,5,5,8,1,10,4,1,12,13,9,3,6,5,13,14,8,5,1,12,0,11,3,4,8,5,10,1,10,13,6]

theorem envBound476 : H12AffineFastState.Bounded env476 := by
  intro p hp
  have h : env476.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans475_476 : H12AffineEnvironment.transform 4 8 env475 = env476 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 8 env475 == env476) = true)

def env477 : List Nat := [2,4,0,0,0,5,5,5,0,1,2,4,1,4,5,1,3,6,5,5,6,0,5,1,4,0,3,3,4,0,5,2,1,2,5,6]

theorem envBound477 : H12AffineFastState.Bounded env477 := by
  intro p hp
  have h : env477.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans476_477 : H12AffineEnvironment.transform 2 0 env476 = env477 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 0 env476 == env477) = true)

def env478 : List Nat := [2,0,0,0,0,1,1,1,0,1,2,0,1,0,1,1,3,2,1,1,2,0,1,1,0,0,3,3,0,0,1,2,1,2,1,2]

theorem envBound478 : H12AffineFastState.Bounded env478 := by
  intro p hp
  have h : env478.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans477_478 : H12AffineEnvironment.transform 1 0 env477 = env478 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env477 == env478) = true)

theorem identity478 : scanCanonicalize (H12AffineFastState.compose env478 (packedSelected [7] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound478 : packedSelected [7] rootPS < 2^1333 := by decide +kernel

def env479 : List Nat := [1,0,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,1,1,1,1,0,1,1,0,0,0,0,0,0,1,1,1,1,1,1]

theorem envBound479 : H12AffineFastState.Bounded env479 := by
  intro p hp
  have h : env479.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans478_479 : H12AffineEnvironment.transform 0 1 env478 = env479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env478 == env479) = true)

def leafEnv479 : List Nat := [1,0,0,0,0,1,1,1,0,1,1,0,1,0,1,1,0,1,1,1,1,0,1,1,1,0,1,0,0,0,0,0,1,1,1,1,0,1,1,1,1,0,0]

def active479 : List Nat := []

def tree479 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood479 : H12WitnessSearch.Good tree479 := H12GlobalWitnessIndex.good

theorem leafIdentity479 : H12AffineFastState.composeSystem env479 rootObs = leafEnv479 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env479 rootObs == leafEnv479) = true)

theorem terminalChecked479 : H12PackedTerminal.terminalCheckFast leafEnv479 active479 tree479 = true := by decide +kernel

def env480 : List Nat := [2,1,0,0,0,0,0,0,0,1,2,1,1,1,0,1,3,3,0,0,3,0,0,1,1,0,3,3,1,0,0,2,1,2,0,3]

theorem envBound480 : H12AffineFastState.Bounded env480 := by
  intro p hp
  have h : env480.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans477_480 : H12AffineEnvironment.transform 1 1 env477 = env480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env477 == env480) = true)

def leafEnv480 : List Nat := [2,1,0,0,0,0,0,0,0,1,2,1,1,1,0,1,3,3,0,0,3,0,0,1,1,1,1,0,3,3,1,0,0,2,1,2,0,2,0,3,1,0,0]

def active480 : List Nat := [0]

def tree480 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood480 : H12WitnessSearch.Good tree480 := H12GlobalWitnessIndex.good

theorem leafIdentity480 : H12AffineFastState.composeSystem env480 rootObs = leafEnv480 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env480 rootObs == leafEnv480) = true)

theorem terminalChecked480 : H12PackedTerminal.terminalCheckFast leafEnv480 active480 tree480 = true := by decide +kernel

def env481 : List Nat := [2,4,1,0,1,5,5,5,1,1,3,4,1,5,4,0,3,6,5,4,7,1,5,1,5,0,2,3,4,1,5,3,1,3,4,6]

theorem envBound481 : H12AffineFastState.Bounded env481 := by
  intro p hp
  have h : env481.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans476_481 : H12AffineEnvironment.transform 2 1 env476 = env481 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 1 env476 == env481) = true)

theorem identity481 : scanCanonicalize (H12AffineFastState.compose env481 (packedSelected [0] rootPS)) = affineNative (2^(1+1) ^^^ 2) := by decide +kernel

theorem selectedBound481 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env482 : List Nat := [2,2,1,0,1,3,3,3,1,1,3,2,1,3,2,0,3,0,3,2,1,1,3,1,3,0,2,3,2,1,3,3,1,3,2,0]

theorem envBound482 : H12AffineFastState.Bounded env482 := by
  intro p hp
  have h : env482.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans481_482 : H12AffineEnvironment.transform 1 2 env481 = env482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 2 env481 == env482) = true)

def leafEnv482 : List Nat := [2,2,1,0,1,3,3,3,1,1,3,2,1,3,2,0,3,0,3,2,1,1,3,1,1,3,1,0,2,3,2,1,3,3,1,3,0,3,2,0,1,0,0]

def active482 : List Nat := [0]

def tree482 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood482 : H12WitnessSearch.Good tree482 := H12GlobalWitnessIndex.good

theorem leafIdentity482 : H12AffineFastState.composeSystem env482 rootObs = leafEnv482 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env482 rootObs == leafEnv482) = true)

theorem terminalChecked482 : H12PackedTerminal.terminalCheckFast leafEnv482 active482 tree482 = true := by decide +kernel

def env483 : List Nat := [2,4,8,1,32,4,45,5,32,1,11,4,41,37,37,8,43,47,4,37,14,32,5,40,12,0,10,42,5,32,5,11,0,11,36,47]

theorem envBound483 : H12AffineFastState.Bounded env483 := by
  intro p hp
  have h : env483.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans474_483 : H12AffineEnvironment.transform 3 1 env474 = env483 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env474 == env483) = true)

theorem identity483 : scanCanonicalize (H12AffineFastState.compose env483 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 1) := by decide +kernel

theorem selectedBound483 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env484 : List Nat := [1,4,8,1,32,4,45,5,32,1,8,4,41,37,37,8,40,44,4,37,13,32,5,40,12,0,9,41,5,32,5,8,0,8,36,44]

theorem envBound484 : H12AffineFastState.Bounded env484 := by
  intro p hp
  have h : env484.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans483_484 : H12AffineEnvironment.transform 0 1 env483 = env484 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 1 env483 == env484) = true)

theorem identity484 : scanCanonicalize (H12AffineFastState.compose env484 (packedSelected [7,9] rootPS)) = affineNative (2^(2+1) ^^^ 5) := by decide +kernel

theorem selectedBound484 : packedSelected [7,9] rootPS < 2^1333 := by decide +kernel

def env485 : List Nat := [1,4,5,1,32,4,32,5,32,1,5,4,36,37,37,5,37,33,4,37,0,32,5,37,1,0,4,36,5,32,5,5,0,5,36,33]

theorem envBound485 : H12AffineFastState.Bounded env485 := by
  intro p hp
  have h : env485.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans484_485 : H12AffineEnvironment.transform 2 5 env484 = env485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 5 env484 == env485) = true)

def leafEnv485 : List Nat := [1,4,5,1,32,4,32,5,32,1,5,4,36,37,37,5,37,33,4,37,0,32,5,37,0,1,1,0,4,36,5,32,5,5,0,5,1,33,36,33,1,1,0]

def active485 : List Nat := [1,4]

def tree485 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood485 : H12WitnessSearch.Good tree485 := H12GlobalWitnessIndex.good

theorem leafIdentity485 : H12AffineFastState.composeSystem env485 rootObs = leafEnv485 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env485 rootObs == leafEnv485) = true)

theorem terminalChecked485 : H12PackedTerminal.terminalCheckFast leafEnv485 active485 tree485 = true := by decide +kernel

def env486 : List Nat := [2,4,8,16,32,64,128,253,512,172,706,549,209,749,112,77,755,587,237,112,635,32,80,149,89,0,707,739,565,596,5,182,188,182,748,543]

theorem envBound486 : H12AffineFastState.Bounded env486 := by
  intro p hp
  have h : env486.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans452_486 : H12AffineEnvironment.transform 11 549 env452 = env486 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 549 env452 == env486) = true)

theorem identity486 : scanCanonicalize (H12AffineFastState.compose env486 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 198) := by decide +kernel

theorem selectedBound486 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env487 : List Nat := [2,4,8,16,32,64,128,253,198,172,4,227,209,43,112,77,53,141,237,112,189,32,80,149,89,0,5,37,243,146,5,182,188,182,42,217]

theorem envBound487 : H12AffineFastState.Bounded env487 := by
  intro p hp
  have h : env487.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans486_487 : H12AffineEnvironment.transform 8 198 env486 = env487 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 198 env486 == env487) = true)

def env488 : List Nat := [2,4,8,16,32,64,44,81,106,0,4,79,125,43,112,77,53,33,65,112,17,32,80,57,89,0,5,37,95,62,5,26,16,26,42,117]

theorem envBound488 : H12AffineFastState.Bounded env488 := by
  intro p hp
  have h : env488.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans487_488 : H12AffineEnvironment.transform 6 44 env487 = env488 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env487 == env488) = true)

def env489 : List Nat := [2,4,8,16,32,20,44,5,62,0,4,27,41,43,36,25,53,33,21,36,17,32,4,57,13,0,5,37,11,62,5,26,16,26,42,33]

theorem envBound489 : H12AffineFastState.Bounded env489 := by
  intro p hp
  have h : env489.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans488_489 : H12AffineEnvironment.transform 5 20 env488 = env489 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 20 env488 == env489) = true)

end H12CloudChart1