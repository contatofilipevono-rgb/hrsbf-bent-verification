import H12CloudChart1Data147

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem envTrans37525_37526 : H12AffineEnvironment.transform 21 272512 env37525 = env37526 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37525 == env37526) = true)

theorem identity37526 : scanCanonicalize (H12AffineFastState.compose env37526 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 32040) := by decide +kernel

theorem selectedBound37526 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37527 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,21928,17,98780,8328,65,158028,5392,17665,179513,1500,41460,257,21793,46213,74250]

theorem envBound37527 : H12AffineFastState.Bounded env37527 := by
  intro p hp
  have h : env37527.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37526_37527 : H12AffineEnvironment.transform 17 32040 env37526 = env37527 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env37526 == env37527) = true)

theorem identity37527 : scanCanonicalize (H12AffineFastState.compose env37527 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37527 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env37528 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4161,21928,17,41431,8328,65,158028,5392,17665,179513,1500,41460,257,21793,46213,513]

theorem envBound37528 : H12AffineFastState.Bounded env37528 := by
  intro p hp
  have h : env37528.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37527_37528 : H12AffineEnvironment.transform 15 8203 env37527 = env37528 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37527 == env37528) = true)

theorem identity37528 : scanCanonicalize (H12AffineFastState.compose env37528 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound37528 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37529 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29709,8203,131072,32040,1025,29708,4161,21928,17,21978,8328,65,158028,5392,17665,149812,1500,22009,257,21793,16520,513]

theorem envBound37529 : H12AffineFastState.Bounded env37529 := by
  intro p hp
  have h : env37529.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37528_37529 : H12AffineEnvironment.transform 14 29709 env37528 = env37529 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env37528 == env37529) = true)

def env37530 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5456,8541,8203,131072,10360,1025,8540,4161,248,17,138,8328,65,146460,5392,4177,138340,1500,169,257,113,5592,513]

theorem envBound37530 : H12AffineFastState.Bounded env37530 := by
  intro p hp
  have h : env37530.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37529_37530 : H12AffineEnvironment.transform 13 5456 env37529 = env37530 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env37529 == env37530) = true)

theorem identity37530 : scanCanonicalize (H12AffineFastState.compose env37530 (packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37530 : packedSelected [0,2,4,5,7,9,12,15,19,24] rootPS < 2^1333 := by decide +kernel

def env37531 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5456,81,263,131072,2420,1025,80,4161,248,17,138,388,65,138512,5392,4177,138340,1500,169,257,113,5592,513]

theorem envBound37531 : H12AffineFastState.Bounded env37531 := by
  intro p hp
  have h : env37531.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37530_37531 : H12AffineEnvironment.transform 12 268 env37530 = env37531 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37530 == env37531) = true)

theorem identity37531 : scanCanonicalize (H12AffineFastState.compose env37531 (packedSelected [0,2,3,5,6,9,10,11,12,19] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37531 : packedSelected [0,2,3,5,6,9,10,11,12,19] rootPS < 2^1333 := by decide +kernel

def env37532 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,41,5237,81,34,131072,2129,1025,80,4161,248,17,138,161,65,138293,5173,4177,138340,1273,169,36,113,5373,513]

theorem envBound37532 : H12AffineFastState.Bounded env37532 := by
  intro p hp
  have h : env37532.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37531_37532 : H12AffineEnvironment.transform 7 37 env37531 = env37532 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37531 == env37532) = true)

theorem identity37532 : scanCanonicalize (H12AffineFastState.compose env37532 (packedSelected [1,2,4,7,8,11,12] rootPS)) = affineNative (2^(16+1) ^^^ 5356) := by decide +kernel

theorem selectedBound37532 : packedSelected [1,2,4,7,8,11,12] rootPS < 2^1333 := by decide +kernel

def env37533 : List Nat := [2,4,8,16,32,64,128,37,512,1024,2048,4096,41,5237,81,34,5356,2129,1025,80,4161,248,17,138,161,65,2265,5173,4177,2184,1273,169,36,113,5373,513]

theorem envBound37533 : H12AffineFastState.Bounded env37533 := by
  intro p hp
  have h : env37533.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37532_37533 : H12AffineEnvironment.transform 16 5356 env37532 = env37533 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5356 env37532 == env37533) = true)

theorem identity37533 : scanCanonicalize (H12AffineFastState.compose env37533 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37533 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37534 : List Nat := [2,4,8,16,32,17,128,37,512,1024,2048,4096,41,5156,0,34,5309,2048,1025,1,4112,169,17,138,161,16,2184,5173,4096,2184,1192,169,36,32,5292,513]

theorem envBound37534 : H12AffineFastState.Bounded env37534 := by
  intro p hp
  have h : env37534.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37533_37534 : H12AffineEnvironment.transform 5 17 env37533 = env37534 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37533 == env37534) = true)

theorem identity37534 : scanCanonicalize (H12AffineFastState.compose env37534 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37534 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37535 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,4096,41,5156,0,34,5173,2048,1025,1,4112,33,17,2,41,16,2048,5173,4096,2048,1056,33,36,32,5156,513]

theorem envBound37535 : H12AffineFastState.Bounded env37535 := by
  intro p hp
  have h : env37535.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37534_37535 : H12AffineEnvironment.transform 6 8 env37534 = env37535 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37534 == env37535) = true)

def env37536 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,48,41,1044,0,34,1029,2048,1025,1,32,33,17,2,41,16,2048,1029,48,2048,1056,33,36,32,1044,513]

theorem envBound37536 : H12AffineFastState.Bounded env37536 := by
  intro p hp
  have h : env37536.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37535_37536 : H12AffineEnvironment.transform 11 48 env37535 = env37536 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 48 env37535 == env37536) = true)

theorem identity37536 : scanCanonicalize (H12AffineFastState.compose env37536 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 32) := by decide +kernel

theorem selectedBound37536 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37537 : List Nat := [2,4,8,16,32,17,8,37,512,1024,32,48,41,1044,0,34,1029,32,1025,1,32,33,17,2,41,16,32,1029,48,32,1056,33,36,32,1044,513]

theorem envBound37537 : H12AffineFastState.Bounded env37537 := by
  intro p hp
  have h : env37537.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37536_37537 : H12AffineEnvironment.transform 10 32 env37536 = env37537 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 32 env37536 == env37537) = true)

def env37538 : List Nat := [2,4,8,16,32,17,8,37,512,52,32,48,41,32,0,34,49,32,53,1,32,33,17,2,41,16,32,49,48,32,20,33,36,32,32,513]

theorem envBound37538 : H12AffineFastState.Bounded env37538 := by
  intro p hp
  have h : env37538.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37537_37538 : H12AffineEnvironment.transform 9 52 env37537 = env37538 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37537 == env37538) = true)

theorem identity37538 : scanCanonicalize (H12AffineFastState.compose env37538 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 11) := by decide +kernel

theorem selectedBound37538 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37539 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,41,32,0,34,49,32,53,1,32,33,17,2,41,16,32,49,48,32,20,33,36,32,32,10]

theorem envBound37539 : H12AffineFastState.Bounded env37539 := by
  intro p hp
  have h : env37539.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37538_37539 : H12AffineEnvironment.transform 8 11 env37538 = env37539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 11 env37538 == env37539) = true)

def leafEnv37539 : List Nat := [2,4,8,16,32,17,8,37,11,52,32,48,41,32,0,34,49,32,53,1,32,33,17,2,21,41,1,16,32,49,48,32,20,33,36,32,5,34,32,10,1,32,0]

def active37539 : List Nat := [0,1,2,3,4]

def tree37539 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37539 : H12WitnessSearch.Good tree37539 := H12GlobalWitnessIndex.good

theorem leafIdentity37539 : H12AffineFastState.composeSystem env37539 rootObs = leafEnv37539 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37539 rootObs == leafEnv37539) = true)

theorem terminalChecked37539 : H12PackedTerminal.terminalCheckFast leafEnv37539 active37539 tree37539 = true := by decide +kernel

def env37540 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,48,41,33,0,34,48,32,52,1,32,33,17,2,41,16,32,48,48,32,21,33,36,32,33,513]

theorem envBound37540 : H12AffineFastState.Bounded env37540 := by
  intro p hp
  have h : env37540.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37537_37540 : H12AffineEnvironment.transform 9 53 env37537 = env37540 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37537 == env37540) = true)

theorem identity37540 : scanCanonicalize (H12AffineFastState.compose env37540 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37540 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37541 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,8,0,0,3,17,1,21,1,1,0,17,2,8,16,1,17,17,1,21,0,5,1,0,513]

theorem envBound37541 : H12AffineFastState.Bounded env37541 := by
  intro p hp
  have h : env37541.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37540_37541 : H12AffineEnvironment.transform 4 1 env37540 = env37541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37540 == env37541) = true)

def leafEnv37541 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,17,8,0,0,3,17,1,21,1,1,0,17,2,20,8,1,16,1,17,17,1,21,0,5,1,5,3,0,513,1,1,0]

def active37541 : List Nat := [0,1,2,3,8]

def tree37541 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37541 : H12WitnessSearch.Good tree37541 := H12GlobalWitnessIndex.good

theorem leafIdentity37541 : H12AffineFastState.composeSystem env37541 rootObs = leafEnv37541 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37541 rootObs == leafEnv37541) = true)

theorem terminalChecked37541 : H12PackedTerminal.terminalCheckFast leafEnv37541 active37541 tree37541 = true := by decide +kernel

def env37542 : List Nat := [2,4,8,16,32,17,8,37,512,1024,2048,49,41,1045,0,34,1028,2048,1025,1,33,33,17,2,41,16,2048,1028,49,2048,1056,33,36,32,1045,513]

theorem envBound37542 : H12AffineFastState.Bounded env37542 := by
  intro p hp
  have h : env37542.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37535_37542 : H12AffineEnvironment.transform 11 49 env37535 = env37542 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 49 env37535 == env37542) = true)

theorem identity37542 : scanCanonicalize (H12AffineFastState.compose env37542 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 1045) := by decide +kernel

theorem selectedBound37542 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37543 : List Nat := [2,4,8,16,32,17,8,37,512,1024,1045,49,41,1045,0,34,1028,1045,1025,1,33,33,17,2,41,16,1045,1028,49,1045,1056,33,36,32,1045,513]

theorem envBound37543 : H12AffineFastState.Bounded env37543 := by
  intro p hp
  have h : env37543.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37542_37543 : H12AffineEnvironment.transform 10 1045 env37542 = env37543 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1045 env37542 == env37543) = true)

def env37544 : List Nat := [2,4,8,16,32,17,8,37,512,52,33,49,41,33,0,34,48,33,53,1,33,33,17,2,41,16,33,48,49,33,20,33,36,32,33,513]

theorem envBound37544 : H12AffineFastState.Bounded env37544 := by
  intro p hp
  have h : env37544.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37543_37544 : H12AffineEnvironment.transform 9 52 env37543 = env37544 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env37543 == env37544) = true)

theorem identity37544 : scanCanonicalize (H12AffineFastState.compose env37544 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 10) := by decide +kernel

theorem selectedBound37544 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37545 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,41,33,0,34,48,33,53,1,33,33,17,2,41,16,33,48,49,33,20,33,36,32,33,11]

theorem envBound37545 : H12AffineFastState.Bounded env37545 := by
  intro p hp
  have h : env37545.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37544_37545 : H12AffineEnvironment.transform 8 10 env37544 = env37545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 10 env37544 == env37545) = true)

def leafEnv37545 : List Nat := [2,4,8,16,32,17,8,37,10,52,33,49,41,33,0,34,48,33,53,1,33,33,17,2,21,41,1,16,33,48,49,33,20,33,36,32,5,34,33,11,1,33,0]

def active37545 : List Nat := [0,1,2,3,4]

def tree37545 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37545 : H12WitnessSearch.Good tree37545 := H12GlobalWitnessIndex.good

theorem leafIdentity37545 : H12AffineFastState.composeSystem env37545 rootObs = leafEnv37545 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37545 rootObs == leafEnv37545) = true)

theorem terminalChecked37545 : H12PackedTerminal.terminalCheckFast leafEnv37545 active37545 tree37545 = true := by decide +kernel

def env37546 : List Nat := [2,4,8,16,32,17,8,37,512,53,32,49,41,32,0,34,49,32,52,1,33,33,17,2,41,16,32,49,49,32,21,33,36,32,32,513]

theorem envBound37546 : H12AffineFastState.Bounded env37546 := by
  intro p hp
  have h : env37546.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37543_37546 : H12AffineEnvironment.transform 9 53 env37543 = env37546 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37543 == env37546) = true)

theorem identity37546 : scanCanonicalize (H12AffineFastState.compose env37546 (packedSelected [1] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37546 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37547 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,8,1,0,3,16,1,21,1,0,0,17,2,8,16,1,16,16,1,21,0,5,1,1,513]

theorem envBound37547 : H12AffineFastState.Bounded env37547 := by
  intro p hp
  have h : env37547.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37546_37547 : H12AffineEnvironment.transform 4 1 env37546 = env37547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37546 == env37547) = true)

def leafEnv37547 : List Nat := [2,4,8,16,1,17,8,4,512,20,1,16,8,1,0,3,16,1,21,1,0,0,17,2,20,8,1,16,1,16,16,1,21,0,5,1,5,3,1,513,1,0,0]

def active37547 : List Nat := [0,1,2,3,8]

def tree37547 : H12WitnessSearch.Tree := H12GlobalWitnessIndex.tree

theorem treeGood37547 : H12WitnessSearch.Good tree37547 := H12GlobalWitnessIndex.good

theorem leafIdentity37547 : H12AffineFastState.composeSystem env37547 rootObs = leafEnv37547 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineFastState.composeSystem env37547 rootObs == leafEnv37547) = true)

theorem terminalChecked37547 : H12PackedTerminal.terminalCheckFast leafEnv37547 active37547 tree37547 = true := by decide +kernel

def env37548 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5457,8540,8203,131072,10361,1025,8541,4161,249,17,139,8328,65,146461,5392,4176,138341,1500,168,257,112,5593,513]

theorem envBound37548 : H12AffineFastState.Bounded env37548 := by
  intro p hp
  have h : env37548.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37529_37548 : H12AffineEnvironment.transform 13 5457 env37529 = env37548 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env37529 == env37548) = true)

theorem identity37548 : scanCanonicalize (H12AffineFastState.compose env37548 (packedSelected [17] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37548 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37549 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8540,8203,131072,10361,1025,8541,4161,113,17,3,8192,65,146461,5392,4176,138341,1364,32,257,112,5457,513]

theorem envBound37549 : H12AffineFastState.Bounded env37549 := by
  intro p hp
  have h : env37549.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37548_37549 : H12AffineEnvironment.transform 6 8 env37548 = env37549 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37548 == env37549) = true)

theorem identity37549 : scanCanonicalize (H12AffineFastState.compose env37549 (packedSelected [0,4,6,7,9] rootPS)) = affineNative (2^(16+1) ^^^ 5220) := by decide +kernel

theorem selectedBound37549 : packedSelected [0,4,6,7,9] rootPS < 2^1333 := by decide +kernel

def env37550 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5457,8540,8203,5220,10361,1025,8541,4161,113,17,3,8192,65,10361,5392,4176,2049,1364,32,257,112,5457,513]

theorem envBound37550 : H12AffineFastState.Bounded env37550 := by
  intro p hp
  have h : env37550.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37549_37550 : H12AffineEnvironment.transform 16 5220 env37549 = env37550 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5220 env37549 == env37550) = true)

theorem identity37550 : scanCanonicalize (H12AffineFastState.compose env37550 (packedSelected [0,6,7] rootPS)) = affineNative (2^(12+1) ^^^ 2396) := by decide +kernel

theorem selectedBound37550 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env37551 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,2396,5457,2048,2391,5220,293,1025,2049,4161,113,17,3,2396,65,293,5392,4176,2049,1364,32,257,112,5457,513]

theorem envBound37551 : H12AffineFastState.Bounded env37551 := by
  intro p hp
  have h : env37551.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37550_37551 : H12AffineEnvironment.transform 12 2396 env37550 = env37551 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 2396 env37550 == env37551) = true)

theorem identity37551 : scanCanonicalize (H12AffineFastState.compose env37551 (packedSelected [2,14] rootPS)) = affineNative (2^(10+1) ^^^ 373) := by decide +kernel

theorem selectedBound37551 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env37552 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,4096,41,5457,373,34,5220,293,1025,372,4161,113,17,3,41,65,293,5392,4176,372,1364,32,257,112,5457,513]

theorem envBound37552 : H12AffineFastState.Bounded env37552 := by
  intro p hp
  have h : env37552.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37551_37552 : H12AffineEnvironment.transform 10 373 env37551 = env37552 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 373 env37551 == env37552) = true)

theorem identity37552 : scanCanonicalize (H12AffineFastState.compose env37552 (packedSelected [1,8,10] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound37552 : packedSelected [1,8,10] rootPS < 2^1333 := by decide +kernel

def env37553 : List Nat := [2,4,8,16,32,64,8,256,512,1024,373,357,41,1076,373,34,1281,293,1025,372,292,113,17,3,41,65,293,1141,309,372,1364,32,257,112,1076,513]

theorem envBound37553 : H12AffineFastState.Bounded env37553 := by
  intro p hp
  have h : env37553.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37552_37553 : H12AffineEnvironment.transform 11 357 env37552 = env37553 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env37552 == env37553) = true)

theorem identity37553 : scanCanonicalize (H12AffineFastState.compose env37553 (packedSelected [2,6,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37553 : packedSelected [2,6,11] rootPS < 2^1333 := by decide +kernel

def env37554 : List Nat := [2,4,8,16,32,16,8,256,512,1024,293,309,41,1076,293,34,1281,293,1025,292,292,33,17,3,41,17,293,1061,309,292,1284,32,257,32,1076,513]

theorem envBound37554 : H12AffineFastState.Bounded env37554 := by
  intro p hp
  have h : env37554.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37553_37554 : H12AffineEnvironment.transform 5 16 env37553 = env37554 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37553 == env37554) = true)

def env37555 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272513,294201,98780,8328,65,398437,288824,17665,179513,293108,41461,257,21793,46213,352034]

theorem envBound37555 : H12AffineFastState.Bounded env37555 := by
  intro p hp
  have h : env37555.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37525_37555 : H12AffineEnvironment.transform 21 272513 env37525 = env37555 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37525 == env37555) = true)

def env37556 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272393,294201,98644,8192,65,398437,288824,17665,179513,292988,41341,257,21793,46093,352034]

theorem envBound37556 : H12AffineFastState.Bounded env37556 := by
  intro p hp
  have h : env37556.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37555_37556 : H12AffineEnvironment.transform 6 8 env37555 = env37556 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37555 == env37556) = true)

theorem identity37556 : scanCanonicalize (H12AffineFastState.compose env37556 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound37556 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env37557 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,89379,1025,32769,77898,95530,73754,98644,8192,65,215366,79131,17665,179513,75103,41341,257,21793,46093,513]

theorem envBound37557 : H12AffineFastState.Bounded env37557 := by
  intro p hp
  have h : env37557.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37556_37557 : H12AffineEnvironment.transform 17 89379 env37556 = env37557 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env37556 == env37557) = true)

theorem identity37557 : scanCanonicalize (H12AffineFastState.compose env37557 (packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound37557 : packedSelected [0,1,3,4,5,7,8,9,10,14,16,17,19,20] rootPS < 2^1333 := by decide +kernel

def env37558 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35188,1025,32769,58397,41341,62541,21763,8192,65,171281,57676,17665,179513,61704,41341,257,21793,46093,513]

theorem envBound37558 : H12AffineFastState.Bounded env37558 := by
  intro p hp
  have h : env37558.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37557_37558 : H12AffineEnvironment.transform 15 54359 env37557 = env37558 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env37557 == env37558) = true)

theorem identity37558 : scanCanonicalize (H12AffineFastState.compose env37558 (packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37558 : packedSelected [0,1,3,4,5,8,9,10,16,17,18,19,23,27] rootPS < 2^1333 := by decide +kernel

def env37559 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,32768,33110,131072,35188,1025,32769,45340,41341,41292,2,8192,65,171281,46157,4096,179513,41993,41341,257,32,46093,513]

theorem envBound37559 : H12AffineFastState.Bounded env37559 := by
  intro p hp
  have h : env37559.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37558_37559 : H12AffineEnvironment.transform 13 5377 env37558 = env37559 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37558 == env37559) = true)

theorem identity37559 : scanCanonicalize (H12AffineFastState.compose env37559 (packedSelected [2,6] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound37559 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37560 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5377,8460,8282,131072,10360,1025,8461,4112,113,64,2,8192,65,146461,5441,4096,138293,1285,113,257,32,5377,513]

theorem envBound37560 : H12AffineFastState.Bounded env37560 := by
  intro p hp
  have h : env37560.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37559_37560 : H12AffineEnvironment.transform 14 8460 env37559 = env37560 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env37559 == env37560) = true)

theorem identity37560 : scanCanonicalize (H12AffineFastState.compose env37560 (packedSelected [17] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37560 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37561 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,5377,8460,8203,131072,10281,1025,8461,4112,32,17,2,8192,16,146461,5392,4096,138293,1285,32,257,32,5377,513]

theorem envBound37561 : H12AffineFastState.Bounded env37561 := by
  intro p hp
  have h : env37561.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37560_37561 : H12AffineEnvironment.transform 5 17 env37560 = env37561 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37560 == env37561) = true)

theorem identity37561 : scanCanonicalize (H12AffineFastState.compose env37561 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(12+1) ^^^ 9) := by decide +kernel

theorem selectedBound37561 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37562 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,9,5377,261,2,131072,2080,1025,260,4112,32,17,2,9,16,138260,5392,4096,138293,1285,32,257,32,5377,513]

theorem envBound37562 : H12AffineFastState.Bounded env37562 := by
  intro p hp
  have h : env37562.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37561_37562 : H12AffineEnvironment.transform 12 9 env37561 = env37562 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 9 env37561 == env37562) = true)

def env37563 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,290153,272392,294201,98645,8193,65,398437,288824,17665,179513,292989,41340,257,21793,46092,352034]

theorem envBound37563 : H12AffineFastState.Bounded env37563 := by
  intro p hp
  have h : env37563.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37555_37563 : H12AffineEnvironment.transform 6 9 env37555 = env37563 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37555 == env37563) = true)

theorem identity37563 : scanCanonicalize (H12AffineFastState.compose env37563 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37563 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env37564 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,262144,1025,32769,290153,272392,294201,98645,8193,65,283765,288824,17665,64809,292989,41340,257,21793,46092,352034]

theorem envBound37564 : H12AffineFastState.Bounded env37564 := by
  intro p hp
  have h : env37564.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37563_37564 : H12AffineEnvironment.transform 16 16400 env37563 = env37564 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37563 == env37564) = true)

def env37565 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5392,262144,1025,32769,276585,272392,272441,98645,8193,65,262517,277816,4097,43049,273789,41340,257,33,46092,330274]

theorem envBound37565 : H12AffineFastState.Bounded env37565 := by
  intro p hp
  have h : env37565.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37564_37565 : H12AffineEnvironment.transform 13 5376 env37564 = env37565 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37564 == env37565) = true)

theorem identity37565 : scanCanonicalize (H12AffineFastState.compose env37565 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 35189) := by decide +kernel

theorem selectedBound37565 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37566 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,32768,65536,5392,35189,1025,32769,45340,41341,41292,98645,8193,65,34816,46157,4097,43049,41992,41340,257,33,46092,99159]

theorem envBound37566 : H12AffineFastState.Bounded env37566 := by
  intro p hp
  have h : env37566.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37565_37566 : H12AffineEnvironment.transform 17 35189 env37565 = env37566 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35189 env37565 == env37566) = true)

theorem identity37566 : scanCanonicalize (H12AffineFastState.compose env37566 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37566 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37567 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,65536,5392,10281,1025,8541,4160,33,16,73737,8193,65,10588,5393,4097,2421,1364,32,257,33,5456,74251]

theorem envBound37567 : H12AffineFastState.Bounded env37567 := by
  intro p hp
  have h : env37567.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37566_37567 : H12AffineEnvironment.transform 14 8540 env37566 = env37567 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37566 == env37567) = true)

theorem identity37567 : scanCanonicalize (H12AffineFastState.compose env37567 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(15+1) ^^^ 262) := by decide +kernel

theorem selectedBound37567 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env37568 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5376,8540,262,5392,10281,1025,8541,4160,33,16,8463,8193,65,10588,5393,4097,2421,1364,32,257,33,5456,8973]

theorem envBound37568 : H12AffineFastState.Bounded env37568 := by
  intro p hp
  have h : env37568.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37567_37568 : H12AffineEnvironment.transform 15 262 env37567 = env37568 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 262 env37567 == env37568) = true)

theorem identity37568 : scanCanonicalize (H12AffineFastState.compose env37568 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37568 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37569 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5376,81,262,5392,2340,1025,80,4160,33,16,2,268,65,2129,5393,4097,2421,1364,32,257,33,5456,512]

theorem envBound37569 : H12AffineFastState.Bounded env37569 := by
  intro p hp
  have h : env37569.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37568_37569 : H12AffineEnvironment.transform 12 269 env37568 = env37569 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37568 == env37569) = true)

theorem identity37569 : scanCanonicalize (H12AffineFastState.compose env37569 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1604) := by decide +kernel

theorem selectedBound37569 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env37570 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,1604,269,836,81,262,852,2340,1025,80,1540,33,16,2,268,65,2129,853,1605,2421,1364,32,257,33,788,512]

theorem envBound37570 : H12AffineFastState.Bounded env37570 := by
  intro p hp
  have h : env37570.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37569_37570 : H12AffineEnvironment.transform 11 1604 env37569 = env37570 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1604 env37569 == env37570) = true)

theorem identity37570 : scanCanonicalize (H12AffineFastState.compose env37570 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound37570 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37571 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,1588,269,820,33,262,804,2340,1025,32,1540,33,16,2,268,49,2081,805,1589,2309,1316,32,257,33,788,512]

theorem envBound37571 : H12AffineFastState.Bounded env37571 := by
  intro p hp
  have h : env37571.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37570_37571 : H12AffineEnvironment.transform 5 48 env37570 = env37571 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env37570 == env37571) = true)

def env37572 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,5393,262144,1025,32769,276584,272392,272440,98645,8193,65,262516,277817,4096,43048,273788,41340,257,32,46092,330275]

theorem envBound37572 : H12AffineFastState.Bounded env37572 := by
  intro p hp
  have h : env37572.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37564_37572 : H12AffineEnvironment.transform 13 5377 env37564 = env37572 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37564 == env37572) = true)

theorem identity37572 : scanCanonicalize (H12AffineFastState.compose env37572 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37572 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37573 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,65536,5393,262144,1025,8540,276584,272392,272440,73736,8193,65,262516,277817,4096,2421,273788,33,257,32,5457,330275]

theorem envBound37573 : H12AffineFastState.Bounded env37573 := by
  intro p hp
  have h : env37573.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37572_37573 : H12AffineEnvironment.transform 14 8541 env37572 = env37573 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37572 == env37573) = true)

theorem identity37573 : scanCanonicalize (H12AffineFastState.compose env37573 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37573 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37574 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5393,262144,1025,8540,276584,272392,272440,2,8193,65,262516,277817,4096,2421,273788,33,257,32,5457,272937]

theorem envBound37574 : H12AffineFastState.Bounded env37574 := by
  intro p hp
  have h : env37574.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37573_37574 : H12AffineEnvironment.transform 15 8202 env37573 = env37574 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37573 == env37574) = true)

theorem identity37574 : scanCanonicalize (H12AffineFastState.compose env37574 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(17+1) ^^^ 2340) := by decide +kernel

theorem selectedBound37574 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37575 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8541,8202,5393,2340,1025,8540,12620,8492,8476,2,8193,65,2128,13341,4096,2421,9304,33,257,32,5457,8973]

theorem envBound37575 : H12AffineFastState.Bounded env37575 := by
  intro p hp
  have h : env37575.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37574_37575 : H12AffineEnvironment.transform 17 2340 env37574 = env37575 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 2340 env37574 == env37575) = true)

theorem identity37575 : scanCanonicalize (H12AffineFastState.compose env37575 (packedSelected [0,1,3,5,6,7,8] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound37575 : packedSelected [0,1,3,5,6,7,8] rootPS < 2^1333 := by decide +kernel

def env37576 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,293,114,5393,2340,1025,292,4404,340,356,2,121,65,2128,5221,4096,2421,1056,33,257,32,5457,885]

theorem envBound37576 : H12AffineFastState.Bounded env37576 := by
  intro p hp
  have h : env37576.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37575_37576 : H12AffineEnvironment.transform 12 120 env37575 = env37576 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env37575 == env37576) = true)

def env37577 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,524288,32769,2097152,4194304,8388608,16777216,8328,65,30393345,19497100,10507601,9356288,25265169,23160256,525568,27902125,27337993,25733062]

theorem envBound37577 : H12AffineFastState.Bounded env37577 := by
  intro p hp
  have h : env37577.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37113_37577 : H12AffineEnvironment.transform 26 30393345 env37113 = env37577 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 26 30393345 env37113 == env37577) = true)

def env37578 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,16777216,8328,65,29868033,18973836,10507601,8830976,25265169,23160256,256,27378861,27337993,25207750]

theorem envBound37578 : H12AffineFastState.Bounded env37578 := by
  intro p hp
  have h : env37578.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37577_37578 : H12AffineEnvironment.transform 18 1024 env37577 = env37578 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1024 env37577 == env37578) = true)

theorem identity37578 : scanCanonicalize (H12AffineFastState.compose env37578 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 8874485) := by decide +kernel

theorem selectedBound37578 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37579 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,2097152,4194304,8388608,8874485,8328,65,4237812,10939769,10507601,8830976,454116,15076405,256,2534744,2510076,510515]

theorem envBound37579 : H12AffineFastState.Bounded env37579 := by
  intro p hp
  have h : env37579.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37578_37579 : H12AffineEnvironment.transform 23 8874485 env37578 = env37579 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8874485 env37578 == env37579) = true)

def env37580 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,8388608,8874485,8328,65,4237812,8393985,8826153,8830976,454116,12645453,256,21792,46212,510515]

theorem envBound37580 : H12AffineFastState.Bounded env37580 := by
  intro p hp
  have h : env37580.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37579_37580 : H12AffineEnvironment.transform 20 456824 env37579 = env37580 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456824 env37579 == env37580) = true)

def env37581 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452648,98781,8328,65,4237812,458025,17665,10280,454116,4594789,256,21792,46212,510515]

theorem envBound37581 : H12AffineFastState.Bounded env37581 := by
  intro p hp
  have h : env37581.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37580_37581 : H12AffineEnvironment.transform 22 452648 env37580 = env37581 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env37580 == env37581) = true)

def env37582 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452648,98781,8328,65,295284,458025,17665,10280,454116,144613,256,21792,46212,510515]

theorem envBound37582 : H12AffineFastState.Bounded env37582 := by
  intro p hp
  have h : env37582.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37581_37582 : H12AffineEnvironment.transform 21 272512 env37581 = env37582 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37581 == env37582) = true)

def env37583 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272392,452648,98645,8192,65,295284,458025,17665,10280,453996,144493,256,21792,46092,510515]

theorem envBound37583 : H12AffineFastState.Bounded env37583 := by
  intro p hp
  have h : env37583.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37582_37583 : H12AffineEnvironment.transform 6 8 env37582 = env37583 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37582 == env37583) = true)

def env37584 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,276584,272392,272440,98645,8192,65,295284,277817,17665,10280,273788,62589,256,21792,46092,330275]

theorem envBound37584 : H12AffineFastState.Bounded env37584 := by
  intro p hp
  have h : env37584.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37583_37584 : H12AffineEnvironment.transform 16 49168 env37583 = env37584 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env37583 == env37584) = true)

theorem identity37584 : scanCanonicalize (H12AffineFastState.compose env37584 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound37584 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37585 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,10281,1024,32769,4161,33,17,98645,8192,65,43357,5392,17665,10280,1365,62589,256,21792,46092,74250]

theorem envBound37585 : H12AffineFastState.Bounded env37585 := by
  intro p hp
  have h : env37585.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37584_37585 : H12AffineEnvironment.transform 17 10281 env37584 = env37585 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37584 == env37585) = true)

theorem identity37585 : scanCanonicalize (H12AffineFastState.compose env37585 (packedSelected [1,3,5,8,10,16,19,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound37585 : packedSelected [1,3,5,8,10,16,19,20] rootPS < 2^1333 := by decide +kernel

def env37586 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49168,10281,1024,32769,4161,33,17,8542,8192,65,43357,5392,17665,10280,1365,62589,256,21792,46092,33281]

theorem envBound37586 : H12AffineFastState.Bounded env37586 := by
  intro p hp
  have h : env37586.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37585_37586 : H12AffineEnvironment.transform 15 40971 env37585 = env37586 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env37585 == env37586) = true)

theorem identity37586 : scanCanonicalize (H12AffineFastState.compose env37586 (packedSelected [0,4,7,22] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound37586 : packedSelected [0,4,7,22] rootPS < 2^1333 := by decide +kernel

def env37587 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,40971,46156,10281,1024,32769,4161,33,17,8542,8192,65,43357,5392,12637,10280,1365,32801,256,8572,46092,33281]

theorem envBound37587 : H12AffineFastState.Bounded env37587 := by
  intro p hp
  have h : env37587.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37586_37587 : H12AffineEnvironment.transform 13 13404 env37586 = env37587 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env37586 == env37587) = true)

theorem identity37587 : scanCanonicalize (H12AffineFastState.compose env37587 (packedSelected [1,8,19] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37587 : packedSelected [1,8,19] rootPS < 2^1333 := by decide +kernel

def env37588 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,8540,343,5392,10281,1024,8541,4161,33,17,8542,8192,65,2049,5392,12637,10280,1365,8573,256,8572,5456,9053]

theorem envBound37588 : H12AffineFastState.Bounded env37588 := by
  intro p hp
  have h : env37588.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37587_37588 : H12AffineEnvironment.transform 14 8540 env37587 = env37588 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37587 == env37588) = true)

theorem identity37588 : scanCanonicalize (H12AffineFastState.compose env37588 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 4364) := by decide +kernel

theorem selectedBound37588 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37589 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,4364,1360,4176,343,5392,6437,1024,4177,4161,33,17,4178,4364,65,2049,5392,81,6436,1365,4209,256,4208,5456,4689]

theorem envBound37589 : H12AffineFastState.Bounded env37589 := by
  intro p hp
  have h : env37589.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37588_37589 : H12AffineEnvironment.transform 12 4364 env37588 = env37589 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 4364 env37588 == env37589) = true)

theorem identity37589 : scanCanonicalize (H12AffineFastState.compose env37589 (packedSelected [2,4,9] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37589 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37590 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,4364,1281,4097,262,5392,6437,1024,4096,4112,33,17,4099,4364,16,2049,5392,0,6436,1284,4128,256,4129,5377,4608]

theorem envBound37590 : H12AffineFastState.Bounded env37590 := by
  intro p hp
  have h : env37590.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37589_37590 : H12AffineEnvironment.transform 5 17 env37589 = env37590 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37589 == env37590) = true)

theorem identity37590 : scanCanonicalize (H12AffineFastState.compose env37590 (packedSelected [1,6,8] rootPS)) = affineNative (2^(9+1) ^^^ 288) := by decide +kernel

theorem selectedBound37590 : packedSelected [1,6,8] rootPS < 2^1333 := by decide +kernel

def env37591 : List Nat := [2,4,8,16,32,17,8,256,512,288,2048,4096,4364,33,4097,262,4144,6437,288,4096,4112,33,17,4099,4364,16,2049,4144,0,6436,36,4128,256,4129,4129,4608]

theorem envBound37591 : H12AffineFastState.Bounded env37591 := by
  intro p hp
  have h : env37591.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37590_37591 : H12AffineEnvironment.transform 9 288 env37590 = env37591 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 288 env37590 == env37591) = true)

theorem identity37591 : scanCanonicalize (H12AffineFastState.compose env37591 (packedSelected [12] rootPS)) = affineNative (2^(7+1) ^^^ 21) := by decide +kernel

theorem selectedBound37591 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env37592 : List Nat := [2,4,8,16,32,17,8,21,512,53,2048,4096,4121,33,4097,19,4144,6192,53,4096,4112,33,17,4099,4121,16,2049,4144,0,6193,36,4128,21,4129,4129,4608]

theorem envBound37592 : H12AffineFastState.Bounded env37592 := by
  intro p hp
  have h : env37592.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37591_37592 : H12AffineEnvironment.transform 7 21 env37591 = env37592 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 21 env37591 == env37592) = true)

theorem identity37592 : scanCanonicalize (H12AffineFastState.compose env37592 (packedSelected [2,15,16] rootPS)) = affineNative (2^(11+1) ^^^ 1) := by decide +kernel

theorem selectedBound37592 : packedSelected [2,15,16] rootPS < 2^1333 := by decide +kernel

def env37593 : List Nat := [2,4,8,16,32,17,8,21,512,53,2048,1,24,33,0,19,49,2097,53,1,17,33,17,2,24,16,2049,49,0,2096,36,33,21,32,32,513]

theorem envBound37593 : H12AffineFastState.Bounded env37593 := by
  intro p hp
  have h : env37593.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37592_37593 : H12AffineEnvironment.transform 11 1 env37592 = env37593 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1 env37592 == env37593) = true)

theorem identity37593 : scanCanonicalize (H12AffineFastState.compose env37593 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound37593 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37594 : List Nat := [2,4,8,16,32,17,8,21,512,53,10,1,24,33,0,19,49,59,53,1,17,33,17,2,24,16,11,49,0,58,36,33,21,32,32,513]

theorem envBound37594 : H12AffineFastState.Bounded env37594 := by
  intro p hp
  have h : env37594.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37593_37594 : H12AffineEnvironment.transform 10 10 env37593 = env37594 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env37593 == env37594) = true)

theorem identity37594 : scanCanonicalize (H12AffineFastState.compose env37594 (packedSelected [0,1] rootPS)) = affineNative (2^(8+1) ^^^ 45) := by decide +kernel

theorem selectedBound37594 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env37595 : List Nat := [2,4,8,16,32,17,8,21,45,53,10,1,24,33,0,19,49,59,53,1,17,33,17,2,24,16,11,49,0,58,36,33,21,32,32,44]

theorem envBound37595 : H12AffineFastState.Bounded env37595 := by
  intro p hp
  have h : env37595.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37594_37595 : H12AffineEnvironment.transform 8 45 env37594 = env37595 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 45 env37594 == env37595) = true)

theorem identity37595 : scanCanonicalize (H12AffineFastState.compose env37595 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 10) := by decide +kernel

theorem selectedBound37595 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37596 : List Nat := [2,4,8,16,10,17,8,21,7,31,10,1,24,11,0,19,27,17,31,1,17,11,17,2,24,16,11,27,0,16,14,11,21,10,10,6]

theorem envBound37596 : H12AffineFastState.Bounded env37596 := by
  intro p hp
  have h : env37596.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37595_37596 : H12AffineEnvironment.transform 4 10 env37595 = env37596 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 10 env37595 == env37596) = true)

def env37597 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,276585,272392,272441,98645,8192,65,295284,277816,17665,10280,273789,62588,256,21792,46092,330274]

theorem envBound37597 : H12AffineFastState.Bounded env37597 := by
  intro p hp
  have h : env37597.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37583_37597 : H12AffineEnvironment.transform 16 49169 env37583 = env37597 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env37583 == env37597) = true)

theorem identity37597 : scanCanonicalize (H12AffineFastState.compose env37597 (packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS)) = affineNative (2^(17+1) ^^^ 10281) := by decide +kernel

theorem selectedBound37597 : packedSelected [1,3,4,5,7,8,9,10,11,14,18,19,23,27,32,35] rootPS < 2^1333 := by decide +kernel

def env37598 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,10281,1024,32769,4160,33,16,98645,8192,65,43357,5393,17665,10280,1364,62588,256,21792,46092,74251]

theorem envBound37598 : H12AffineFastState.Bounded env37598 := by
  intro p hp
  have h : env37598.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37597_37598 : H12AffineEnvironment.transform 17 10281 env37597 = env37598 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10281 env37597 == env37598) = true)

theorem identity37598 : scanCanonicalize (H12AffineFastState.compose env37598 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound37598 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37599 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,40971,49169,10281,1024,32769,4160,33,16,8542,8192,65,43357,5393,17665,10280,1364,62588,256,21792,46092,33280]

theorem envBound37599 : H12AffineFastState.Bounded env37599 := by
  intro p hp
  have h : env37599.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37598_37599 : H12AffineEnvironment.transform 15 40971 env37598 = env37599 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env37598 == env37599) = true)

theorem identity37599 : scanCanonicalize (H12AffineFastState.compose env37599 (packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS)) = affineNative (2^(14+1) ^^^ 29788) := by decide +kernel

theorem selectedBound37599 : packedSelected [0,1,2,4,6,8,9,11,16,18,19,27] rootPS < 2^1333 := by decide +kernel

def env37600 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29788,21591,13389,10281,1024,29789,4160,33,16,8542,8192,65,23809,5393,17665,10280,1364,32,256,21792,16464,30300]

theorem envBound37600 : H12AffineFastState.Bounded env37600 := by
  intro p hp
  have h : env37600.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37599_37600 : H12AffineEnvironment.transform 14 29788 env37599 = env37600 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29788 env37599 == env37600) = true)

theorem identity37600 : scanCanonicalize (H12AffineFastState.compose env37600 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37600 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37601 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,8540,343,13389,10281,1024,8541,4160,33,16,8542,8192,65,2049,5393,4097,10280,1364,32,256,32,5456,9052]

theorem envBound37601 : H12AffineFastState.Bounded env37601 := by
  intro p hp
  have h : env37601.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37600_37601 : H12AffineEnvironment.transform 13 5376 env37600 = env37601 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37600 == env37601) = true)

theorem identity37601 : scanCanonicalize (H12AffineFastState.compose env37601 (packedSelected [0,7] rootPS)) = affineNative (2^(12+1) ^^^ 1101) := by decide +kernel

theorem selectedBound37601 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37602 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1101,5376,1297,343,4096,3172,1024,1296,4160,33,16,1299,1101,65,2049,5393,4097,3173,1364,32,256,32,5456,1809]

theorem envBound37602 : H12AffineFastState.Bounded env37602 := by
  intro p hp
  have h : env37602.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37601_37602 : H12AffineEnvironment.transform 12 1101 env37601 = env37602 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1101 env37601 == env37602) = true)

theorem identity37602 : scanCanonicalize (H12AffineFastState.compose env37602 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound37602 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37603 : List Nat := [2,4,8,16,32,64,8,256,512,69,2048,4096,8,4421,340,343,4096,2081,69,341,4160,33,16,342,8,65,2049,4436,4097,2080,273,32,256,32,4373,852]

theorem envBound37603 : H12AffineFastState.Bounded env37603 := by
  intro p hp
  have h : env37603.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37602_37603 : H12AffineEnvironment.transform 9 69 env37602 = env37603 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env37602 == env37603) = true)

theorem identity37603 : scanCanonicalize (H12AffineFastState.compose env37603 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 84) := by decide +kernel

theorem selectedBound37603 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env37604 : List Nat := [2,4,8,16,32,64,8,84,512,69,2048,4096,8,4113,0,3,4096,2081,69,1,4160,33,16,2,8,65,2049,4096,4097,2080,69,32,84,32,4161,512]

theorem envBound37604 : H12AffineFastState.Bounded env37604 := by
  intro p hp
  have h : env37604.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37603_37604 : H12AffineEnvironment.transform 7 84 env37603 = env37604 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 84 env37603 == env37604) = true)

def env37605 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272393,452648,98644,8193,65,295284,458025,17665,10280,453997,144492,256,21792,46093,510515]

theorem envBound37605 : H12AffineFastState.Bounded env37605 := by
  intro p hp
  have h : env37605.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37582_37605 : H12AffineEnvironment.transform 6 9 env37582 = env37605 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37582 == env37605) = true)

theorem identity37605 : scanCanonicalize (H12AffineFastState.compose env37605 (packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 100387) := by decide +kernel

theorem selectedBound37605 : packedSelected [0,9,12,14,15,17,22,27,35,38,41] rootPS < 2^1333 := by decide +kernel

def env37606 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,100387,1024,32769,225371,106538,221195,98644,8193,65,67927,226570,17665,10280,222542,144492,256,21792,46093,147984]

theorem envBound37606 : H12AffineFastState.Bounded env37606 := by
  intro p hp
  have h : env37606.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37605_37606 : H12AffineEnvironment.transform 17 100387 env37605 = env37606 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 100387 env37605 == env37606) = true)

theorem identity37606 : scanCanonicalize (H12AffineFastState.compose env37606 (packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 57677) := by decide +kernel

theorem selectedBound37606 : packedSelected [0,1,4,5,7,8,16,17,19,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37607 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,57677,100387,1024,32769,102678,106538,98630,98644,8193,65,67927,103495,17665,10280,99331,54561,256,21792,46093,41821]

theorem envBound37607 : H12AffineFastState.Bounded env37607 := by
  intro p hp
  have h : env37607.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37606_37607 : H12AffineEnvironment.transform 16 57677 env37606 = env37607 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 57677 env37606 == env37607) = true)

def env37608 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452648,98781,8328,65,295285,458025,17665,10280,454116,144612,256,21792,46212,510515]

theorem envBound37608 : H12AffineFastState.Bounded env37608 := by
  intro p hp
  have h : env37608.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37581_37608 : H12AffineEnvironment.transform 21 272513 env37581 = env37608 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37581 == env37608) = true)

theorem identity37608 : scanCanonicalize (H12AffineFastState.compose env37608 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190520) := by decide +kernel

theorem selectedBound37608 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37609 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,4160,180409,16,98781,8328,65,158029,5393,17665,10280,1500,144612,256,21792,46212,74251]

theorem envBound37609 : H12AffineFastState.Bounded env37609 := by
  intro p hp
  have h : env37609.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37608_37609 : H12AffineEnvironment.transform 17 190520 env37608 = env37609 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190520 env37608 == env37609) = true)

theorem identity37609 : scanCanonicalize (H12AffineFastState.compose env37609 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37609 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env37610 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4160,180409,16,41431,8328,65,158029,5393,17665,10280,1500,144612,256,21792,46212,513]

theorem envBound37610 : H12AffineFastState.Bounded env37610 := by
  intro p hp
  have h : env37610.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37609_37610 : H12AffineEnvironment.transform 15 8202 env37609 = env37610 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37609 == env37610) = true)

theorem identity37610 : scanCanonicalize (H12AffineFastState.compose env37610 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound37610 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37611 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16401,43049,1024,32769,4160,32936,16,41431,8328,65,10588,5393,17665,10280,1500,29941,256,21792,46212,513]

theorem envBound37611 : H12AffineFastState.Bounded env37611 := by
  intro p hp
  have h : env37611.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37610_37611 : H12AffineEnvironment.transform 16 16401 env37610 = env37611 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env37610 == env37611) = true)

theorem identity37611 : scanCanonicalize (H12AffineFastState.compose env37611 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(13+1) ^^^ 13525) := by decide +kernel

theorem selectedBound37611 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env37612 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,32768,8202,13508,43049,1024,32769,4160,32936,16,41431,8328,65,10588,5393,12756,10280,1500,32,256,8693,46212,513]

theorem envBound37612 : H12AffineFastState.Bounded env37612 := by
  intro p hp
  have h : env37612.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37611_37612 : H12AffineEnvironment.transform 13 13525 env37611 = env37612 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13525 env37611 == env37612) = true)

theorem identity37612 : scanCanonicalize (H12AffineFastState.compose env37612 (packedSelected [2,6,17] rootPS)) = affineNative (2^(14+1) ^^^ 8540) := by decide +kernel

theorem selectedBound37612 : packedSelected [2,6,17] rootPS < 2^1333 := by decide +kernel

def env37613 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13525,8540,8202,13508,2421,1024,8541,4160,8692,16,139,8328,65,10588,5393,12756,10280,1500,32,256,8693,5592,513]

theorem envBound37613 : H12AffineFastState.Bounded env37613 := by
  intro p hp
  have h : env37613.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37612_37613 : H12AffineEnvironment.transform 14 8540 env37612 = env37613 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8540 env37612 == env37613) = true)

theorem identity37613 : scanCanonicalize (H12AffineFastState.compose env37613 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 468) := by decide +kernel

theorem selectedBound37613 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37614 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,468,5377,136,478,5392,2421,1024,137,4160,32,16,139,348,65,2184,5393,4096,2556,1500,32,256,33,5592,513]

theorem envBound37614 : H12AffineFastState.Bounded env37614 := by
  intro p hp
  have h : env37614.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37613_37614 : H12AffineEnvironment.transform 12 468 env37613 = env37614 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 468 env37613 == env37614) = true)

theorem identity37614 : scanCanonicalize (H12AffineFastState.compose env37614 (packedSelected [2,4,9] rootPS)) = affineNative (2^(11+1) ^^^ 3308) := by decide +kernel

theorem selectedBound37614 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37615 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,3308,468,2541,136,478,2556,2421,1024,137,3244,32,16,139,348,65,2184,2557,3308,2556,1500,32,256,33,2356,513]

theorem envBound37615 : H12AffineFastState.Bounded env37615 := by
  intro p hp
  have h : env37615.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37614_37615 : H12AffineEnvironment.transform 11 3308 env37614 = env37615 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3308 env37614 == env37615) = true)

theorem identity37615 : scanCanonicalize (H12AffineFastState.compose env37615 (packedSelected [0,1,2,7,8,10,11,12] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37615 : packedSelected [0,1,2,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37616 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3172,348,2405,0,342,2420,2421,1024,1,3108,32,16,3,348,65,2048,2421,3172,2420,1364,32,256,33,2356,513]

theorem envBound37616 : H12AffineFastState.Bounded env37616 := by
  intro p hp
  have h : env37616.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37615_37616 : H12AffineEnvironment.transform 6 8 env37615 = env37616 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37615 == env37616) = true)

theorem identity37616 : scanCanonicalize (H12AffineFastState.compose env37616 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 266) := by decide +kernel

theorem selectedBound37616 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37617 : List Nat := [2,4,8,16,32,64,8,256,512,266,2048,2414,348,2405,0,342,2420,2421,266,1,2350,32,16,3,348,65,2048,2421,2414,2420,94,32,256,33,2356,513]

theorem envBound37617 : H12AffineFastState.Bounded env37617 := by
  intro p hp
  have h : env37617.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37616_37617 : H12AffineEnvironment.transform 9 266 env37616 = env37617 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 266 env37616 == env37617) = true)

def env37618 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,4194304,452649,98780,8328,65,4237812,458024,17664,10281,454116,4594788,256,21792,46212,510515]

theorem envBound37618 : H12AffineFastState.Bounded env37618 := by
  intro p hp
  have h : env37618.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37580_37618 : H12AffineEnvironment.transform 22 452649 env37580 = env37618 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env37580 == env37618) = true)

def env37619 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272512,452649,98780,8328,65,295284,458024,17664,10281,454116,144612,256,21792,46212,510515]

theorem envBound37619 : H12AffineFastState.Bounded env37619 := by
  intro p hp
  have h : env37619.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37618_37619 : H12AffineEnvironment.transform 21 272512 env37618 = env37619 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37618 == env37619) = true)

theorem identity37619 : scanCanonicalize (H12AffineFastState.compose env37619 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound37619 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37620 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,262144,1024,29908,396461,272512,400636,95497,8328,65,292257,395773,17664,10281,399665,144612,256,21792,16465,474854]

theorem envBound37620 : H12AffineFastState.Bounded env37620 := by
  intro p hp
  have h : env37620.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37619_37620 : H12AffineEnvironment.transform 14 29909 env37619 = env37620 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env37619 == env37620) = true)

def env37621 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10400,1024,29908,140301,32,144476,95497,8328,65,23809,139613,17664,10281,143761,144612,256,21792,16465,202310]

theorem envBound37621 : H12AffineFastState.Bounded env37621 := by
  intro p hp
  have h : env37621.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37620_37621 : H12AffineEnvironment.transform 17 10400 env37620 = env37621 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10400 env37620 == env37621) = true)

theorem identity37621 : scanCanonicalize (H12AffineFastState.compose env37621 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 479) := by decide +kernel

theorem selectedBound37621 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env37622 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,479,131072,10400,1024,29908,140301,32,144476,29910,8328,65,23809,139613,17664,10281,143761,144612,256,21792,16465,137113]

theorem envBound37622 : H12AffineFastState.Bounded env37622 := by
  intro p hp
  have h : env37622.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37621_37622 : H12AffineEnvironment.transform 15 479 env37621 = env37622 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 479 env37621 == env37622) = true)

theorem identity37622 : scanCanonicalize (H12AffineFastState.compose env37622 (packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound37622 : packedSelected [4,7,9,16,17,18,19,20,23,26,27] rootPS < 2^1333 := by decide +kernel

def env37623 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,216,479,131072,10400,1024,217,140301,32,144476,219,8328,65,10508,139613,12557,10281,143761,144612,256,8493,13404,137113]

theorem envBound37623 : H12AffineFastState.Bounded env37623 := by
  intro p hp
  have h : env37623.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37622_37623 : H12AffineEnvironment.transform 13 13325 env37622 = env37623 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env37622 == env37623) = true)

theorem identity37623 : scanCanonicalize (H12AffineFastState.compose env37623 (packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS)) = affineNative (2^(16+1) ^^^ 13793) := by decide +kernel

theorem selectedBound37623 : packedSelected [0,1,2,4,6,7,8,9,11,12,14,15,16,18,19,20] rootPS < 2^1333 := by decide +kernel

def env37624 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13325,216,479,13793,10400,1024,217,4588,32,445,219,8328,65,10508,5308,12557,10281,1136,261,256,8493,13404,8824]

theorem envBound37624 : H12AffineFastState.Bounded env37624 := by
  intro p hp
  have h : env37624.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37623_37624 : H12AffineEnvironment.transform 16 13793 env37623 = env37624 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13793 env37623 == env37624) = true)

theorem identity37624 : scanCanonicalize (H12AffineFastState.compose env37624 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37624 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env37625 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,268,5377,216,479,5357,2476,1024,217,4588,32,445,219,388,65,2048,5308,4097,2341,1136,261,256,33,5456,884]

theorem envBound37625 : H12AffineFastState.Bounded env37625 := by
  intro p hp
  have h : env37625.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37624_37625 : H12AffineEnvironment.transform 12 268 env37624 = env37625 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37624 == env37625) = true)

theorem identity37625 : scanCanonicalize (H12AffineFastState.compose env37625 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(6+1) ^^^ 88) := by decide +kernel

theorem selectedBound37625 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37626 : List Nat := [2,4,8,16,32,64,88,256,512,1024,2048,4096,268,5377,0,263,5173,2420,1024,1,4404,32,357,3,348,65,2048,5220,4097,2341,1136,261,256,33,5456,884]

theorem envBound37626 : H12AffineFastState.Bounded env37626 := by
  intro p hp
  have h : env37626.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37625_37626 : H12AffineEnvironment.transform 6 88 env37625 = env37626 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 88 env37625 == env37626) = true)

theorem identity37626 : scanCanonicalize (H12AffineFastState.compose env37626 (packedSelected [1,6,7,8,9,11,12] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound37626 : packedSelected [1,6,7,8,9,11,12] rootPS < 2^1333 := by decide +kernel

def env37627 : List Nat := [2,4,8,16,32,64,88,256,512,101,2048,4096,268,4452,0,263,4176,2420,101,1,4404,32,357,3,348,65,2048,4097,4097,2341,21,261,256,33,4405,884]

theorem envBound37627 : H12AffineFastState.Bounded env37627 := by
  intro p hp
  have h : env37627.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37626_37627 : H12AffineEnvironment.transform 9 101 env37626 = env37627 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env37626 == env37627) = true)

theorem identity37627 : scanCanonicalize (H12AffineFastState.compose env37627 (packedSelected [0,3,4,5,6,7,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37627 : packedSelected [0,3,4,5,6,7,9,10] rootPS < 2^1333 := by decide +kernel

def env37628 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,268,4405,0,263,4097,2341,52,1,4404,32,308,3,269,16,2048,4097,4097,2341,21,261,256,33,4405,805]

theorem envBound37628 : H12AffineFastState.Bounded env37628 := by
  intro p hp
  have h : env37628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37627_37628 : H12AffineEnvironment.transform 5 17 env37627 = env37628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37627 == env37628) = true)

theorem identity37628 : scanCanonicalize (H12AffineFastState.compose env37628 (packedSelected [1,2,3,4] rootPS)) = affineNative (2^(11+1) ^^^ 2827) := by decide +kernel

theorem selectedBound37628 : packedSelected [1,2,3,4] rootPS < 2^1333 := by decide +kernel

def env37629 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,2827,268,2622,0,263,2826,2341,52,1,2623,32,308,3,269,16,2048,2826,2826,2341,21,261,256,33,2622,805]

theorem envBound37629 : H12AffineFastState.Bounded env37629 := by
  intro p hp
  have h : env37629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37628_37629 : H12AffineEnvironment.transform 11 2827 env37628 = env37629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2827 env37628 == env37629) = true)

theorem identity37629 : scanCanonicalize (H12AffineFastState.compose env37629 (packedSelected [0,1,2,3,5] rootPS)) = affineNative (2^(10+1) ^^^ 519) := by decide +kernel

theorem selectedBound37629 : packedSelected [0,1,2,3,5] rootPS < 2^1333 := by decide +kernel

def env37630 : List Nat := [2,4,8,16,32,17,9,256,512,52,519,268,268,57,0,263,269,802,52,1,56,32,308,3,269,16,519,269,269,802,21,261,256,33,57,805]

theorem envBound37630 : H12AffineFastState.Bounded env37630 := by
  intro p hp
  have h : env37630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37629_37630 : H12AffineEnvironment.transform 10 519 env37629 = env37630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 519 env37629 == env37630) = true)

def env37631 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,10401,1024,29908,140300,33,144477,95497,8328,65,23808,139612,17664,10281,143760,144612,256,21792,16465,202311]

theorem envBound37631 : H12AffineFastState.Bounded env37631 := by
  intro p hp
  have h : env37631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37620_37631 : H12AffineEnvironment.transform 17 10401 env37620 = env37631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env37620 == env37631) = true)

theorem identity37631 : scanCanonicalize (H12AffineFastState.compose env37631 (packedSelected [12,15,16,20,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound37631 : packedSelected [12,15,16,20,38,41] rootPS < 2^1333 := by decide +kernel

def env37632 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,90139,10401,1024,29908,82967,33,87110,95497,8328,65,23808,82247,17664,10281,86411,87295,256,21792,16465,30300]

theorem envBound37632 : H12AffineFastState.Bounded env37632 := by
  intro p hp
  have h : env37632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37631_37632 : H12AffineEnvironment.transform 16 90139 env37631 = env37632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env37631 == env37632) = true)

theorem identity37632 : scanCanonicalize (H12AffineFastState.compose env37632 (packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound37632 : packedSelected [0,1,3,5,8,9,10,16,17,18,20,22,23,26,27] rootPS < 2^1333 := by decide +kernel

def env37633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,65536,82246,2556,1024,21897,82967,33,87110,87124,469,65,23808,82247,17664,2420,86411,87295,256,21792,16465,22273]

theorem envBound37633 : H12AffineFastState.Bounded env37633 := by
  intro p hp
  have h : env37633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37632_37633 : H12AffineEnvironment.transform 12 349 env37632 = env37633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env37632 == env37633) = true)

theorem identity37633 : scanCanonicalize (H12AffineFastState.compose env37633 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(15+1) ^^^ 21726) := by decide +kernel

theorem selectedBound37633 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env37634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,21726,5528,2556,1024,21897,4297,33,152,138,469,65,23808,5529,17664,2420,1365,33,256,21792,16465,22273]

theorem envBound37634 : H12AffineFastState.Bounded env37634 := by
  intro p hp
  have h : env37634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37633_37634 : H12AffineEnvironment.transform 15 21726 env37633 = env37634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21726 env37633 == env37634) = true)

theorem identity37634 : scanCanonicalize (H12AffineFastState.compose env37634 (packedSelected [16,17,20] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37634 : packedSelected [16,17,20] rootPS < 2^1333 := by decide +kernel

def env37635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,478,5528,2556,1024,137,4297,33,152,138,469,65,2048,5529,4096,2420,1365,33,256,32,5457,513]

theorem envBound37635 : H12AffineFastState.Bounded env37635 := by
  intro p hp
  have h : env37635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37634_37635 : H12AffineEnvironment.transform 13 5376 env37634 = env37635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37634 == env37635) = true)

theorem identity37635 : scanCanonicalize (H12AffineFastState.compose env37635 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37635 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37636 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,269,5376,136,398,5528,2476,1024,137,4249,33,152,138,389,17,2048,5529,4096,2340,1285,33,256,32,5377,513]

theorem envBound37636 : H12AffineFastState.Bounded env37636 := by
  intro p hp
  have h : env37636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37635_37636 : H12AffineEnvironment.transform 5 16 env37635 = env37636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37635 == env37636) = true)

theorem identity37636 : scanCanonicalize (H12AffineFastState.compose env37636 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37636 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37637 : List Nat := [2,4,8,16,32,16,128,37,512,1024,2048,4096,40,5157,136,171,5309,2185,1024,137,4249,33,152,138,160,17,2048,5308,4096,2049,1056,33,37,32,5156,513]

theorem envBound37637 : H12AffineFastState.Bounded env37637 := by
  intro p hp
  have h : env37637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37636_37637 : H12AffineEnvironment.transform 7 37 env37636 = env37637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37636 == env37637) = true)

theorem identity37637 : scanCanonicalize (H12AffineFastState.compose env37637 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 642) := by decide +kernel

theorem selectedBound37637 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env37638 : List Nat := [2,4,8,16,32,16,128,37,512,1024,642,4096,40,5157,136,171,5309,523,1024,137,4249,33,152,138,160,17,642,5308,4096,643,1056,33,37,32,5156,513]

theorem envBound37638 : H12AffineFastState.Bounded env37638 := by
  intro p hp
  have h : env37638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37637_37638 : H12AffineEnvironment.transform 10 642 env37637 = env37638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 642 env37637 == env37638) = true)

def env37639 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456824,272513,452649,98780,8328,65,295285,458024,17664,10281,454116,144613,256,21792,46212,510515]

theorem envBound37639 : H12AffineFastState.Bounded env37639 := by
  intro p hp
  have h : env37639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37618_37639 : H12AffineEnvironment.transform 21 272513 env37618 = env37639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37618 == env37639) = true)

theorem identity37639 : scanCanonicalize (H12AffineFastState.compose env37639 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138476) := by decide +kernel

theorem selectedBound37639 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37640 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138476,1024,32769,58516,144493,62661,98780,8328,65,171417,57796,17664,10281,61704,144613,256,21792,46212,120543]

theorem envBound37640 : H12AffineFastState.Bounded env37640 := by
  intro p hp
  have h : env37640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37639_37640 : H12AffineEnvironment.transform 17 138476 env37639 = env37640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138476 env37639 == env37640) = true)

def env37641 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,58396,144493,62541,98644,8192,65,171281,57676,17664,10281,61704,144493,256,21792,46092,120407]

theorem envBound37641 : H12AffineFastState.Bounded env37641 := by
  intro p hp
  have h : env37641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37640_37641 : H12AffineEnvironment.transform 6 8 env37640 = env37641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37640 == env37641) = true)

theorem identity37641 : scanCanonicalize (H12AffineFastState.compose env37641 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37641 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env37642 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,131072,138340,1024,8540,17729,144493,21776,73737,8192,65,146508,16401,17664,10281,20565,144493,256,21792,5457,96010]

theorem envBound37642 : H12AffineFastState.Bounded env37642 := by
  intro p hp
  have h : env37642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37641_37642 : H12AffineEnvironment.transform 14 8541 env37641 = env37642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37641 == env37642) = true)

theorem identity37642 : scanCanonicalize (H12AffineFastState.compose env37642 (packedSelected [1,3,16,17,20,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16449) := by decide +kernel

theorem selectedBound37642 : packedSelected [1,3,16,17,20,24,28] rootPS < 2^1333 := by decide +kernel

def env37643 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,16449,23589,1024,8540,17729,29740,21776,73737,8192,65,31757,16401,17664,10281,20565,29740,256,21792,5457,96010]

theorem envBound37643 : H12AffineFastState.Bounded env37643 := by
  intro p hp
  have h : env37643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37642_37643 : H12AffineEnvironment.transform 16 16449 env37642 = env37643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16449 env37642 == env37643) = true)

theorem identity37643 : scanCanonicalize (H12AffineFastState.compose env37643 (packedSelected [18,23] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound37643 : packedSelected [18,23] rootPS < 2^1333 := by decide +kernel

def env37644 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,263,16449,23589,1024,8540,17729,29740,21776,8462,8192,65,31757,16401,17664,10281,20565,29740,256,21792,5457,30221]

theorem envBound37644 : H12AffineFastState.Bounded env37644 := by
  intro p hp
  have h : env37644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37643_37644 : H12AffineEnvironment.transform 15 263 env37643 = env37644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env37643 == env37644) = true)

theorem identity37644 : scanCanonicalize (H12AffineFastState.compose env37644 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37644 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env37645 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,16384,81,263,16449,23589,1024,80,17729,21792,21776,2,268,65,23809,16401,17664,2341,20565,21792,256,21792,5457,22273]

theorem envBound37645 : H12AffineFastState.Bounded env37645 := by
  intro p hp
  have h : env37645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37644_37645 : H12AffineEnvironment.transform 12 268 env37644 = env37645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37644 == env37645) = true)

theorem identity37645 : scanCanonicalize (H12AffineFastState.compose env37645 (packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS)) = affineNative (2^(13+1) ^^^ 2657) := by decide +kernel

theorem selectedBound37645 : packedSelected [1,3,4,5,6,7,8,10,11,12] rootPS < 2^1333 := by decide +kernel

def env37646 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,2657,81,263,2592,5700,1024,80,3872,8001,8049,2,268,65,5984,2672,3937,2341,6708,8001,256,8001,5457,7520]

theorem envBound37646 : H12AffineFastState.Bounded env37646 := by
  intro p hp
  have h : env37646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37645_37646 : H12AffineEnvironment.transform 13 2657 env37645 = env37646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 2657 env37645 == env37646) = true)

theorem identity37646 : scanCanonicalize (H12AffineFastState.compose env37646 (packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS)) = affineNative (2^(11+1) ^^^ 3889) := by decide +kernel

theorem selectedBound37646 : packedSelected [1,2,3,4,5,6,8,9,11,15] rootPS < 2^1333 := by decide +kernel

def env37647 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3889,268,2657,81,263,2592,2421,1024,80,3872,112,64,2,268,65,2129,2672,3937,2341,1285,112,256,112,2656,593]

theorem envBound37647 : H12AffineFastState.Bounded env37647 := by
  intro p hp
  have h : env37647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37646_37647 : H12AffineEnvironment.transform 11 3889 env37646 = env37647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3889 env37646 == env37647) = true)

theorem identity37647 : scanCanonicalize (H12AffineFastState.compose env37647 (packedSelected [0,2,3,4,5,6] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound37647 : packedSelected [0,2,3,4,5,6] rootPS < 2^1333 := by decide +kernel

def env37648 : List Nat := [2,4,8,16,32,64,8,5,512,1024,2048,3636,9,2657,81,2,2592,2160,1024,80,3621,112,64,2,9,65,2129,2672,3684,2080,1024,112,5,112,2656,593]

theorem envBound37648 : H12AffineFastState.Bounded env37648 := by
  intro p hp
  have h : env37648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37647_37648 : H12AffineEnvironment.transform 7 5 env37647 = env37648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env37647 == env37648) = true)

theorem identity37648 : scanCanonicalize (H12AffineFastState.compose env37648 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 97) := by decide +kernel

theorem selectedBound37648 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37649 : List Nat := [2,4,8,16,32,64,8,5,512,1024,97,1621,9,512,81,2,577,17,1024,80,1604,112,64,2,9,65,48,529,1541,65,1024,112,5,112,513,593]

theorem envBound37649 : H12AffineFastState.Bounded env37649 := by
  intro p hp
  have h : env37649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37648_37649 : H12AffineEnvironment.transform 10 97 env37648 = env37649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 97 env37648 == env37649) = true)

theorem identity37649 : scanCanonicalize (H12AffineFastState.compose env37649 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(9+1) ^^^ 564) := by decide +kernel

theorem selectedBound37649 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env37650 : List Nat := [2,4,8,16,32,64,8,5,512,564,97,97,9,512,81,2,577,17,564,80,112,112,64,2,9,65,48,529,49,65,564,112,5,112,513,593]

theorem envBound37650 : H12AffineFastState.Bounded env37650 := by
  intro p hp
  have h : env37650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37649_37650 : H12AffineEnvironment.transform 9 564 env37649 = env37650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 564 env37649 == env37650) = true)

theorem identity37650 : scanCanonicalize (H12AffineFastState.compose env37650 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 80) := by decide +kernel

theorem selectedBound37650 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env37651 : List Nat := [2,4,8,16,32,64,8,5,80,100,97,97,9,80,81,2,17,17,100,80,112,112,64,2,9,65,48,65,49,65,100,112,5,112,81,1]

theorem envBound37651 : H12AffineFastState.Bounded env37651 := by
  intro p hp
  have h : env37651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37650_37651 : H12AffineEnvironment.transform 8 80 env37650 = env37651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 80 env37650 == env37651) = true)

theorem identity37651 : scanCanonicalize (H12AffineFastState.compose env37651 (packedSelected [0,1,2,3,7] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37651 : packedSelected [0,1,2,3,7] rootPS < 2^1333 := by decide +kernel

def env37652 : List Nat := [2,4,8,1,32,64,8,5,65,100,97,97,9,65,64,2,0,0,100,65,97,97,64,2,9,65,33,65,32,65,100,97,5,97,64,1]

theorem envBound37652 : H12AffineFastState.Bounded env37652 := by
  intro p hp
  have h : env37652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37651_37652 : H12AffineEnvironment.transform 3 1 env37651 = env37652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37651 == env37652) = true)

theorem identity37652 : scanCanonicalize (H12AffineFastState.compose env37652 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound37652 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37653 : List Nat := [2,4,8,1,32,1,8,5,0,37,32,32,9,0,1,2,0,0,37,0,32,32,1,2,9,0,33,0,32,0,37,32,5,32,1,1]

theorem envBound37653 : H12AffineFastState.Bounded env37653 := by
  intro p hp
  have h : env37653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37652_37653 : H12AffineEnvironment.transform 5 1 env37652 = env37653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env37652 == env37653) = true)

theorem identity37653 : scanCanonicalize (H12AffineFastState.compose env37653 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37653 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37654 : List Nat := [2,4,8,1,1,1,8,5,0,4,1,1,9,0,1,2,0,0,4,0,1,1,1,2,9,0,0,0,1,0,4,1,5,1,1,1]

theorem envBound37654 : H12AffineFastState.Bounded env37654 := by
  intro p hp
  have h : env37654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37653_37654 : H12AffineEnvironment.transform 4 1 env37653 = env37654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37653 == env37654) = true)

theorem identity37654 : scanCanonicalize (H12AffineFastState.compose env37654 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37654 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37655 : List Nat := [2,4,2,1,1,1,2,5,0,4,1,1,3,0,1,2,0,0,4,0,1,1,1,2,3,0,0,0,1,0,4,1,5,1,1,1]

theorem envBound37655 : H12AffineFastState.Bounded env37655 := by
  intro p hp
  have h : env37655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37654_37655 : H12AffineEnvironment.transform 2 2 env37654 = env37655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37654 == env37655) = true)

def env37656 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138341,1024,32769,58397,144493,62540,98645,8193,65,171280,57677,17664,10281,61704,144492,256,21792,46093,120406]

theorem envBound37656 : H12AffineFastState.Bounded env37656 := by
  intro p hp
  have h : env37656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37640_37656 : H12AffineEnvironment.transform 6 9 env37640 = env37656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37640 == env37656) = true)

theorem identity37656 : scanCanonicalize (H12AffineFastState.compose env37656 (packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS)) = affineNative (2^(15+1) ^^^ 62510) := by decide +kernel

theorem selectedBound37656 : packedSelected [1,7,8,10,12,14,15,16,18,19,23,27,31] rootPS < 2^1333 := by decide +kernel

def env37657 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,62510,131072,138341,1024,32769,58397,144493,62540,30075,8193,65,171280,57677,17664,10281,61704,144492,256,21792,46093,8824]

theorem envBound37657 : H12AffineFastState.Bounded env37657 := by
  intro p hp
  have h : env37657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37656_37657 : H12AffineEnvironment.transform 15 62510 env37656 = env37657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 62510 env37656 == env37657) = true)

theorem identity37657 : scanCanonicalize (H12AffineFastState.compose env37657 (packedSelected [0,3,4,10,11,14,16,22,24,26,27,32] rootPS)) = affineNative (2^(14+1) ^^^ 29709) := by decide +kernel

theorem selectedBound37657 : packedSelected [0,3,4,10,11,14,16,22,24,26,27,32] rootPS < 2^1333 := by decide +kernel

def env37658 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,35,131072,138341,1024,29708,4112,144493,65,30075,8193,65,157981,5440,17664,10281,1285,144492,256,21792,16384,8824]

theorem envBound37658 : H12AffineFastState.Bounded env37658 := by
  intro p hp
  have h : env37658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37657_37658 : H12AffineEnvironment.transform 14 29709 env37657 = env37658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29709 env37657 == env37658) = true)

theorem identity37658 : scanCanonicalize (H12AffineFastState.compose env37658 (packedSelected [0,4,7,18,22,23] rootPS)) = affineNative (2^(16+1) ^^^ 13673) := by decide +kernel

theorem selectedBound37658 : packedSelected [0,4,7,18,22,23] rootPS < 2^1333 := by decide +kernel

def env37659 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,29709,35,13673,10508,1024,29708,4112,260,65,30075,8193,65,23668,5440,17664,10281,1285,261,256,21792,16384,8824]

theorem envBound37659 : H12AffineFastState.Bounded env37659 := by
  intro p hp
  have h : env37659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37658_37659 : H12AffineEnvironment.transform 16 13673 env37658 = env37659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13673 env37658 == env37659) = true)

theorem identity37659 : scanCanonicalize (H12AffineFastState.compose env37659 (packedSelected [2,3,5,6,9,10,11,12,14,15,16,17,18,20,22] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound37659 : packedSelected [2,3,5,6,9,10,11,12,14,15,16,17,18,20,22] rootPS < 2^1333 := by decide +kernel

def env37660 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,8460,35,13673,10508,1024,8461,4112,260,65,8314,8193,65,2421,5440,4097,10281,1285,261,256,33,5377,8824]

theorem envBound37660 : H12AffineFastState.Bounded env37660 := by
  intro p hp
  have h : env37660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37659_37660 : H12AffineEnvironment.transform 13 5377 env37659 = env37660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env37659 == env37660) = true)

theorem identity37660 : scanCanonicalize (H12AffineFastState.compose env37660 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 120) := by decide +kernel

theorem selectedBound37660 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37661 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,120,5377,372,35,5393,2420,1024,373,4112,260,65,2,121,65,2421,5440,4097,2129,1285,261,256,33,5377,512]

theorem envBound37661 : H12AffineFastState.Bounded env37661 := by
  intro p hp
  have h : env37661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37660_37661 : H12AffineEnvironment.transform 12 120 env37660 = env37661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 120 env37660 == env37661) = true)

theorem identity37661 : scanCanonicalize (H12AffineFastState.compose env37661 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 49) := by decide +kernel

theorem selectedBound37661 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37662 : List Nat := [2,4,8,16,32,49,9,256,512,1024,2048,4096,9,5377,261,35,5393,2309,1024,260,4112,260,48,2,8,48,2308,5425,4097,2080,1285,261,256,33,5377,512]

theorem envBound37662 : H12AffineFastState.Bounded env37662 := by
  intro p hp
  have h : env37662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37661_37662 : H12AffineEnvironment.transform 5 49 env37661 = env37662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 49 env37661 == env37662) = true)

theorem identity37662 : scanCanonicalize (H12AffineFastState.compose env37662 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37662 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env37663 : List Nat := [2,4,8,16,32,49,9,37,512,1024,2048,4096,9,5156,32,35,5172,2080,1024,33,4112,33,48,2,8,48,2081,5140,4097,2080,1056,32,37,33,5156,512]

theorem envBound37663 : H12AffineFastState.Bounded env37663 := by
  intro p hp
  have h : env37663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37662_37663 : H12AffineEnvironment.transform 7 37 env37662 = env37663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37662 == env37663) = true)

def env37664 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,8388608,8874485,8328,65,4237812,8393984,8826152,8830976,454116,12645452,256,21793,46213,510515]

theorem envBound37664 : H12AffineFastState.Bounded env37664 := by
  intro p hp
  have h : env37664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37579_37664 : H12AffineEnvironment.transform 20 456825 env37579 = env37664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 456825 env37579 == env37664) = true)

def env37665 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452648,98781,8328,65,4237812,458024,17664,10280,454116,4594788,256,21793,46213,510515]

theorem envBound37665 : H12AffineFastState.Bounded env37665 := by
  intro p hp
  have h : env37665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37664_37665 : H12AffineEnvironment.transform 22 452648 env37664 = env37665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452648 env37664 == env37665) = true)

def env37666 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452648,98781,8328,65,295284,458024,17664,10280,454116,144612,256,21793,46213,510515]

theorem envBound37666 : H12AffineFastState.Bounded env37666 := by
  intro p hp
  have h : env37666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37665_37666 : H12AffineEnvironment.transform 21 272512 env37665 = env37666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37665 == env37666) = true)

theorem identity37666 : scanCanonicalize (H12AffineFastState.compose env37666 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247858) := by decide +kernel

theorem selectedBound37666 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37667 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247858,1024,32769,77899,254130,73754,98781,8328,65,215366,79130,17664,10280,75222,144612,256,21793,46213,513]

theorem envBound37667 : H12AffineFastState.Bounded env37667 := by
  intro p hp
  have h : env37667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37666_37667 : H12AffineEnvironment.transform 17 247858 env37666 = env37667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247858 env37666 == env37667) = true)

theorem identity37667 : scanCanonicalize (H12AffineFastState.compose env37667 (packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37667 : packedSelected [3,4,9,10,11,14,18,20,23,24,26,32] rootPS < 2^1333 := by decide +kernel

def env37668 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,190520,1024,32769,4161,180408,16,41431,8328,65,158028,5392,17664,10280,1500,144612,256,21793,46213,513]

theorem envBound37668 : H12AffineFastState.Bounded env37668 := by
  intro p hp
  have h : env37668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37667_37668 : H12AffineEnvironment.transform 15 8202 env37667 = env37668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37667 == env37668) = true)

theorem identity37668 : scanCanonicalize (H12AffineFastState.compose env37668 (packedSelected [3,7,10,14,20,24,26,27] rootPS)) = affineNative (2^(16+1) ^^^ 16400) := by decide +kernel

theorem selectedBound37668 : packedSelected [3,7,10,14,20,24,26,27] rootPS < 2^1333 := by decide +kernel

def env37669 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43048,1024,32769,4161,32936,16,41431,8328,65,10588,5392,17664,10280,1500,29940,256,21793,46213,513]

theorem envBound37669 : H12AffineFastState.Bounded env37669 := by
  intro p hp
  have h : env37669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37668_37669 : H12AffineEnvironment.transform 16 16400 env37668 = env37669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16400 env37668 == env37669) = true)

theorem identity37669 : scanCanonicalize (H12AffineFastState.compose env37669 (packedSelected [3,5,8,15,28,38] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37669 : packedSelected [3,5,8,15,28,38] rootPS < 2^1333 := by decide +kernel

def env37670 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,8202,16400,43048,1024,32769,4113,32936,16,41351,8328,17,10508,5392,17664,10280,1420,29860,256,21793,46213,513]

theorem envBound37670 : H12AffineFastState.Bounded env37670 := by
  intro p hp
  have h : env37670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37669_37670 : H12AffineEnvironment.transform 5 16 env37669 = env37670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37669 == env37670) = true)

theorem identity37670 : scanCanonicalize (H12AffineFastState.compose env37670 (packedSelected [2,3,5,6,8,18,23,28] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound37670 : packedSelected [2,3,5,6,8,18,23,28] rootPS < 2^1333 := by decide +kernel

def env37671 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,32768,262,16400,35108,1024,32769,4113,32936,16,32907,388,17,2048,5392,17664,2340,1420,21928,256,21793,38281,513]

theorem envBound37671 : H12AffineFastState.Bounded env37671 := by
  intro p hp
  have h : env37671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37670_37671 : H12AffineEnvironment.transform 12 268 env37670 = env37671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env37670 == env37671) = true)

theorem identity37671 : scanCanonicalize (H12AffineFastState.compose env37671 (packedSelected [3,6,8,10,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 22804) := by decide +kernel

theorem selectedBound37671 : packedSelected [3,6,8,10,14,17] rootPS < 2^1333 := by decide +kernel

def env37672 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,268,16384,22804,262,16400,20528,1024,22805,4113,22972,16,22943,388,17,2048,5392,17664,2340,1420,21928,256,21793,19613,513]

theorem envBound37672 : H12AffineFastState.Bounded env37672 := by
  intro p hp
  have h : env37672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37671_37672 : H12AffineEnvironment.transform 14 22804 env37671 = env37672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 22804 env37671 == env37672) = true)

theorem identity37672 : scanCanonicalize (H12AffineFastState.compose env37672 (packedSelected [4,9,14,20] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37672 : packedSelected [4,9,14,20] rootPS < 2^1333 := by decide +kernel

def env37673 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,16384,22804,262,16400,20528,1024,22805,4113,22836,16,22807,268,17,2048,5392,17664,2340,1284,21792,256,21793,19477,513]

theorem envBound37673 : H12AffineFastState.Bounded env37673 := by
  intro p hp
  have h : env37673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37672_37673 : H12AffineEnvironment.transform 6 8 env37672 = env37673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37672 == env37673) = true)

theorem identity37673 : scanCanonicalize (H12AffineFastState.compose env37673 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37673 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37674 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,268,5376,3092,262,5392,1328,1024,3093,4113,3124,16,3095,268,17,2048,5392,4096,2340,1284,32,256,33,6421,513]

theorem envBound37674 : H12AffineFastState.Bounded env37674 := by
  intro p hp
  have h : env37674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37673_37674 : H12AffineEnvironment.transform 13 5376 env37673 = env37674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37673 == env37674) = true)

theorem identity37674 : scanCanonicalize (H12AffineFastState.compose env37674 (packedSelected [0,1,4,5] rootPS)) = affineNative (2^(10+1) ^^^ 561) := by decide +kernel

theorem selectedBound37674 : packedSelected [0,1,4,5] rootPS < 2^1333 := by decide +kernel

def env37675 : List Nat := [2,4,8,16,32,16,8,256,512,1024,561,4096,268,5376,1573,262,5392,1328,1024,1572,4113,1541,16,1574,268,17,561,5392,4096,789,1284,32,256,33,4900,513]

theorem envBound37675 : H12AffineFastState.Bounded env37675 := by
  intro p hp
  have h : env37675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37674_37675 : H12AffineEnvironment.transform 10 561 env37674 = env37675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 561 env37674 == env37675) = true)

theorem identity37675 : scanCanonicalize (H12AffineFastState.compose env37675 (packedSelected [1,3,4,7] rootPS)) = affineNative (2^(11+1) ^^^ 292) := by decide +kernel

theorem selectedBound37675 : packedSelected [1,3,4,7] rootPS < 2^1333 := by decide +kernel

def env37676 : List Nat := [2,4,8,16,32,16,8,256,512,1024,561,292,268,1060,1573,262,1076,1328,1024,1572,309,1541,16,1574,268,17,561,1076,292,789,1284,32,256,33,512,513]

theorem envBound37676 : H12AffineFastState.Bounded env37676 := by
  intro p hp
  have h : env37676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37675_37676 : H12AffineEnvironment.transform 11 292 env37675 = env37676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 292 env37675 == env37676) = true)

theorem identity37676 : scanCanonicalize (H12AffineFastState.compose env37676 (packedSelected [0,1,3,9] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound37676 : packedSelected [0,1,3,9] rootPS < 2^1333 := by decide +kernel

def env37677 : List Nat := [2,4,8,1,32,1,8,256,512,1024,544,292,268,1060,1573,262,1061,1313,1024,1572,292,1541,1,1574,268,0,544,1061,292,772,1284,32,256,33,512,513]

theorem envBound37677 : H12AffineFastState.Bounded env37677 := by
  intro p hp
  have h : env37677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37676_37677 : H12AffineEnvironment.transform 3 1 env37676 = env37677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env37676 == env37677) = true)

theorem identity37677 : scanCanonicalize (H12AffineFastState.compose env37677 (packedSelected [0,3,4,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37677 : packedSelected [0,3,4,8] rootPS < 2^1333 := by decide +kernel

def env37678 : List Nat := [2,4,8,1,0,1,8,256,512,1024,512,260,268,1028,1541,262,1029,1281,1024,1540,260,1541,1,1542,268,0,512,1029,260,772,1284,0,256,1,512,513]

theorem envBound37678 : H12AffineFastState.Bounded env37678 := by
  intro p hp
  have h : env37678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37677_37678 : H12AffineEnvironment.transform 4 0 env37677 = env37678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37677 == env37678) = true)

theorem identity37678 : scanCanonicalize (H12AffineFastState.compose env37678 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound37678 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env37679 : List Nat := [2,4,8,1,0,1,8,256,512,517,512,260,268,513,0,262,512,772,517,1,260,0,1,3,268,0,512,512,260,772,769,0,256,1,512,513]

theorem envBound37679 : H12AffineFastState.Bounded env37679 := by
  intro p hp
  have h : env37679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37678_37679 : H12AffineEnvironment.transform 9 517 env37678 = env37679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env37678 == env37679) = true)

theorem identity37679 : scanCanonicalize (H12AffineFastState.compose env37679 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound37679 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37680 : List Nat := [2,4,8,1,0,1,8,256,261,256,261,260,268,260,0,262,261,1,256,1,260,0,1,3,268,0,261,261,260,1,4,0,256,1,261,260]

theorem envBound37680 : H12AffineFastState.Bounded env37680 := by
  intro p hp
  have h : env37680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37679_37680 : H12AffineEnvironment.transform 8 261 env37679 = env37680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env37679 == env37680) = true)

theorem identity37680 : scanCanonicalize (H12AffineFastState.compose env37680 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound37680 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37681 : List Nat := [2,4,3,1,0,1,3,256,261,256,261,260,263,260,0,262,261,1,256,1,260,0,1,3,263,0,261,261,260,1,4,0,256,1,261,260]

theorem envBound37681 : H12AffineFastState.Bounded env37681 := by
  intro p hp
  have h : env37681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37680_37681 : H12AffineEnvironment.transform 2 3 env37680 = env37681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env37680 == env37681) = true)

theorem identity37681 : scanCanonicalize (H12AffineFastState.compose env37681 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound37681 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37682 : List Nat := [2,4,3,1,0,1,3,4,1,4,1,0,3,0,0,2,1,1,4,1,0,0,1,3,3,0,1,1,0,1,4,0,4,1,1,0]

theorem envBound37682 : H12AffineFastState.Bounded env37682 := by
  intro p hp
  have h : env37682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37681_37682 : H12AffineEnvironment.transform 7 4 env37681 = env37682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env37681 == env37682) = true)

def env37683 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452648,98781,8328,65,295285,458024,17664,10280,454116,144613,256,21793,46213,510515]

theorem envBound37683 : H12AffineFastState.Bounded env37683 := by
  intro p hp
  have h : env37683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37665_37683 : H12AffineEnvironment.transform 21 272513 env37665 = env37683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37665 == env37683) = true)

theorem identity37683 : scanCanonicalize (H12AffineFastState.compose env37683 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37683 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37684 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8202,131072,262144,1024,32769,456825,272513,452648,41431,8328,65,295285,458024,17664,10280,454116,144613,256,21793,46213,453177]

theorem envBound37684 : H12AffineFastState.Bounded env37684 := by
  intro p hp
  have h : env37684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37683_37684 : H12AffineEnvironment.transform 15 8202 env37683 = env37684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37683 == env37684) = true)

def env37685 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,4194304,452649,98780,8328,65,4237812,458025,17665,10281,454116,4594789,256,21793,46213,510515]

theorem envBound37685 : H12AffineFastState.Bounded env37685 := by
  intro p hp
  have h : env37685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37664_37685 : H12AffineEnvironment.transform 22 452649 env37664 = env37685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452649 env37664 == env37685) = true)

def env37686 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272512,452649,98780,8328,65,295284,458025,17665,10281,454116,144613,256,21793,46213,510515]

theorem envBound37686 : H12AffineFastState.Bounded env37686 := by
  intro p hp
  have h : env37686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37685_37686 : H12AffineEnvironment.transform 21 272512 env37685 = env37686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env37685 == env37686) = true)

theorem identity37686 : scanCanonicalize (H12AffineFastState.compose env37686 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212198) := by decide +kernel

theorem selectedBound37686 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37687 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212198,1024,32769,115871,201830,120015,98780,8328,65,245138,115151,17665,10281,119042,144613,256,21793,46213,63189]

theorem envBound37687 : H12AffineFastState.Bounded env37687 := by
  intro p hp
  have h : env37687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37686_37687 : H12AffineEnvironment.transform 17 212198 env37686 = env37687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212198 env37686 == env37687) = true)

def env37688 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212150,1024,32769,115871,201782,119967,98700,8328,17,245138,115103,17665,10281,119042,144565,256,21793,46213,63109]

theorem envBound37688 : H12AffineFastState.Bounded env37688 := by
  intro p hp
  have h : env37688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37687_37688 : H12AffineEnvironment.transform 5 16 env37687 = env37688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37687 == env37688) = true)

theorem identity37688 : scanCanonicalize (H12AffineFastState.compose env37688 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 115102) := by decide +kernel

theorem selectedBound37688 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37689 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,8192,16384,32768,65536,115102,64808,1024,32769,115871,54696,119967,98700,8328,17,31756,115103,17665,10281,119042,128299,256,21793,46213,63109]

theorem envBound37689 : H12AffineFastState.Bounded env37689 := by
  intro p hp
  have h : env37689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37688_37689 : H12AffineEnvironment.transform 16 115102 env37688 = env37689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 115102 env37688 == env37689) = true)

theorem identity37689 : scanCanonicalize (H12AffineFastState.compose env37689 (packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS)) = affineNative (2^(12+1) ^^^ 389) := by decide +kernel

theorem selectedBound37689 : packedSelected [0,5,8,9,14,16,19,20,22,24,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env37690 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,65536,115102,56493,1024,32769,115871,54696,119967,98700,269,17,23945,115103,17665,2476,119042,119982,256,21793,38144,55040]

theorem envBound37690 : H12AffineFastState.Bounded env37690 := by
  intro p hp
  have h : env37690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37689_37690 : H12AffineEnvironment.transform 12 389 env37689 = env37690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 389 env37689 == env37690) = true)

theorem identity37690 : scanCanonicalize (H12AffineFastState.compose env37690 (packedSelected [2,6,9,11,14,18,19,22,26] rootPS)) = affineNative (2^(15+1) ^^^ 54279) := by decide +kernel

theorem selectedBound37690 : packedSelected [2,6,9,11,14,18,19,22,26] rootPS < 2^1333 := by decide +kernel

def env37691 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,16384,32768,54279,5529,56493,1024,32769,4248,54696,152,21899,269,17,23945,5528,17665,2476,1285,169,256,21793,38144,55040]

theorem envBound37691 : H12AffineFastState.Bounded env37691 := by
  intro p hp
  have h : env37691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37690_37691 : H12AffineEnvironment.transform 15 54279 env37690 = env37691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54279 env37690 == env37691) = true)

theorem identity37691 : scanCanonicalize (H12AffineFastState.compose env37691 (packedSelected [16,20] rootPS)) = affineNative (2^(13+1) ^^^ 5513) := by decide +kernel

theorem selectedBound37691 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env37692 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,32768,33166,5529,35108,1024,32769,4248,32801,152,2,269,17,2048,5528,4232,2476,1285,169,256,168,38144,33417]

theorem envBound37692 : H12AffineFastState.Bounded env37692 := by
  intro p hp
  have h : env37692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37691_37692 : H12AffineEnvironment.transform 13 5513 env37691 = env37692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5513 env37691 == env37692) = true)

theorem identity37692 : scanCanonicalize (H12AffineFastState.compose env37692 (packedSelected [0,4,7,9,11,14] rootPS)) = affineNative (2^(14+1) ^^^ 136) := by decide +kernel

theorem selectedBound37692 : packedSelected [0,4,7,9,11,14] rootPS < 2^1333 := by decide +kernel

def env37693 : List Nat := [2,4,8,16,32,16,128,256,512,1024,2048,4096,389,5513,136,262,5529,2476,1024,137,4248,169,152,2,269,17,2048,5528,4232,2476,1285,169,256,168,5512,513]

theorem envBound37693 : H12AffineFastState.Bounded env37693 := by
  intro p hp
  have h : env37693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37692_37693 : H12AffineEnvironment.transform 14 136 env37692 = env37693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 136 env37692 == env37693) = true)

theorem identity37693 : scanCanonicalize (H12AffineFastState.compose env37693 (packedSelected [3,5,10] rootPS)) = affineNative (2^(6+1) ^^^ 8) := by decide +kernel

theorem selectedBound37693 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37694 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,269,5377,0,262,5393,2340,1024,1,4112,33,16,2,269,17,2048,5392,4096,2340,1285,33,256,32,5376,513]

theorem envBound37694 : H12AffineFastState.Bounded env37694 := by
  intro p hp
  have h : env37694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37693_37694 : H12AffineEnvironment.transform 6 8 env37693 = env37694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37693 == env37694) = true)

theorem identity37694 : scanCanonicalize (H12AffineFastState.compose env37694 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37694 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37695 : List Nat := [2,4,8,16,32,16,8,37,512,1024,2048,4096,40,5156,0,35,5172,2049,1024,1,4112,33,16,2,40,17,2048,5173,4096,2049,1056,33,37,32,5157,513]

theorem envBound37695 : H12AffineFastState.Bounded env37695 := by
  intro p hp
  have h : env37695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37694_37695 : H12AffineEnvironment.transform 7 37 env37694 = env37695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37694 == env37695) = true)

theorem identity37695 : scanCanonicalize (H12AffineFastState.compose env37695 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 522) := by decide +kernel

theorem selectedBound37695 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37696 : List Nat := [2,4,8,16,32,16,8,37,512,1024,522,4096,40,5156,0,35,5172,523,1024,1,4112,33,16,2,40,17,522,5173,4096,523,1056,33,37,32,5157,513]

theorem envBound37696 : H12AffineFastState.Bounded env37696 := by
  intro p hp
  have h : env37696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37695_37696 : H12AffineEnvironment.transform 10 522 env37695 = env37696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 522 env37695 == env37696) = true)

theorem identity37696 : scanCanonicalize (H12AffineFastState.compose env37696 (packedSelected [0,4] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37696 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env37697 : List Nat := [2,4,8,16,0,16,8,5,512,1024,522,4096,8,5124,0,3,5140,523,1024,1,4112,1,16,2,8,17,522,5141,4096,523,1024,1,5,0,5125,513]

theorem envBound37697 : H12AffineFastState.Bounded env37697 := by
  intro p hp
  have h : env37697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37696_37697 : H12AffineEnvironment.transform 4 0 env37696 = env37697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37696 == env37697) = true)

def env37698 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212151,1024,32769,115871,201783,119966,98701,8328,16,245138,115102,17665,10281,119042,144564,256,21793,46213,63108]

theorem envBound37698 : H12AffineFastState.Bounded env37698 := by
  intro p hp
  have h : env37698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37687_37698 : H12AffineEnvironment.transform 5 17 env37687 = env37698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37687 == env37698) = true)

theorem identity37698 : scanCanonicalize (H12AffineFastState.compose env37698 (packedSelected [1,11,19,28,31,32] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound37698 : packedSelected [1,11,19,28,31,32] rootPS < 2^1333 := by decide +kernel

def env37699 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,65536,5528,76079,1024,32769,115871,65967,119966,98701,8328,16,108554,115102,17665,10281,119042,8492,256,21793,46213,63108]

theorem envBound37699 : H12AffineFastState.Bounded env37699 := by
  intro p hp
  have h : env37699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37698_37699 : H12AffineEnvironment.transform 16 5528 env37698 = env37699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env37698 == env37699) = true)

theorem identity37699 : scanCanonicalize (H12AffineFastState.compose env37699 (packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS)) = affineNative (2^(15+1) ^^^ 21647) := by decide +kernel

theorem selectedBound37699 : packedSelected [0,3,4,7,16,17,19,20,22,24,31] rootPS < 2^1333 := by decide +kernel

def env37700 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,32768,21647,5528,32160,1024,32769,36880,21792,32785,54530,8328,16,64645,38161,17665,10281,34189,8492,256,21793,46213,63108]

theorem envBound37700 : H12AffineFastState.Bounded env37700 := by
  intro p hp
  have h : env37700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37699_37700 : H12AffineEnvironment.transform 15 21647 env37699 = env37700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21647 env37699 == env37700) = true)

theorem identity37700 : scanCanonicalize (H12AffineFastState.compose env37700 (packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS)) = affineNative (2^(14+1) ^^^ 21897) := by decide +kernel

theorem selectedBound37700 : packedSelected [0,1,3,4,5,7,8,10,17,18,19,22,23] rootPS < 2^1333 := by decide +kernel

def env37701 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,16384,21897,21647,5528,32160,1024,21896,17817,21792,21912,139,8328,16,10508,16536,17665,10281,20484,8492,256,21793,24844,8973]

theorem envBound37701 : H12AffineFastState.Bounded env37701 := by
  intro p hp
  have h : env37701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37700_37701 : H12AffineEnvironment.transform 14 21897 env37700 = env37701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21897 env37700 == env37701) = true)

theorem identity37701 : scanCanonicalize (H12AffineFastState.compose env37701 (packedSelected [1,3,5,8,10,17,19] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound37701 : packedSelected [1,3,5,8,10,17,19] rootPS < 2^1333 := by decide +kernel

def env37702 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,8192,13324,8581,8323,5528,2476,1024,8580,12693,8492,8596,139,8328,16,10508,13460,12557,10281,9224,8492,256,8493,5376,8973]

theorem envBound37702 : H12AffineFastState.Bounded env37702 := by
  intro p hp
  have h : env37702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37701_37702 : H12AffineEnvironment.transform 13 13324 env37701 = env37702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env37701 == env37702) = true)

theorem identity37702 : scanCanonicalize (H12AffineFastState.compose env37702 (packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS)) = affineNative (2^(12+1) ^^^ 6429) := by decide +kernel

theorem selectedBound37702 : packedSelected [0,1,4,7,8,9,10,11,15,16] rootPS < 2^1333 := by decide +kernel

def env37703 : List Nat := [2,4,8,16,32,17,128,256,512,1024,2048,4096,6429,3345,6296,6558,5528,2476,1024,6297,2184,6193,6281,139,6549,16,4113,3465,2064,4404,7445,6193,256,6192,5376,6672]

theorem envBound37703 : H12AffineFastState.Bounded env37703 := by
  intro p hp
  have h : env37703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37702_37703 : H12AffineEnvironment.transform 12 6429 env37702 = env37703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6429 env37702 == env37703) = true)

theorem identity37703 : scanCanonicalize (H12AffineFastState.compose env37703 (packedSelected [2,3,4,5,6,9,10,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound37703 : packedSelected [2,3,4,5,6,9,10,11] rootPS < 2^1333 := by decide +kernel

def env37704 : List Nat := [2,4,8,16,32,17,128,256,512,1024,1296,4096,5133,1,5512,5262,5528,1212,1024,5513,1432,5409,5529,139,5253,16,4113,153,1280,4404,4101,5409,256,5408,5376,5888]

theorem envBound37704 : H12AffineFastState.Bounded env37704 := by
  intro p hp
  have h : env37704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37703_37704 : H12AffineEnvironment.transform 10 1296 env37703 = env37704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env37703 == env37704) = true)

theorem identity37704 : scanCanonicalize (H12AffineFastState.compose env37704 (packedSelected [1,4,8,9,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37704 : packedSelected [1,4,8,9,10,15] rootPS < 2^1333 := by decide +kernel

def env37705 : List Nat := [2,4,8,16,32,17,128,256,512,272,0,4096,4381,1,4248,4510,4232,428,272,4249,136,4145,4233,139,4501,16,4113,153,16,4404,4101,4145,256,4144,4112,4624]

theorem envBound37705 : H12AffineFastState.Bounded env37705 := by
  intro p hp
  have h : env37705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37704_37705 : H12AffineEnvironment.transform 9 272 env37704 = env37705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37704 == env37705) = true)

theorem identity37705 : scanCanonicalize (H12AffineFastState.compose env37705 (packedSelected [3,4,5,9,10] rootPS)) = affineNative (2^(11+1) ^^^ 153) := by decide +kernel

theorem selectedBound37705 : packedSelected [3,4,5,9,10] rootPS < 2^1333 := by decide +kernel

def env37706 : List Nat := [2,4,8,16,32,17,128,256,512,272,0,153,388,1,1,263,17,428,272,0,136,168,16,139,268,16,136,153,16,429,156,168,256,169,137,649]

theorem envBound37706 : H12AffineFastState.Bounded env37706 := by
  intro p hp
  have h : env37706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37705_37706 : H12AffineEnvironment.transform 11 153 env37705 = env37706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 153 env37705 == env37706) = true)

theorem identity37706 : scanCanonicalize (H12AffineFastState.compose env37706 (packedSelected [0,1,2,4,5] rootPS)) = affineNative (2^(8+1) ^^^ 303) := by decide +kernel

theorem selectedBound37706 : packedSelected [0,1,2,4,5] rootPS < 2^1333 := by decide +kernel

def env37707 : List Nat := [2,4,8,16,32,17,128,256,303,272,0,153,388,1,1,263,17,428,272,0,136,168,16,139,268,16,136,153,16,429,156,168,256,169,137,422]

theorem envBound37707 : H12AffineFastState.Bounded env37707 := by
  intro p hp
  have h : env37707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37706_37707 : H12AffineEnvironment.transform 8 303 env37706 = env37707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 303 env37706 == env37707) = true)

theorem identity37707 : scanCanonicalize (H12AffineFastState.compose env37707 (packedSelected [0,2,7] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound37707 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env37708 : List Nat := [2,4,8,16,32,17,128,36,11,52,0,153,160,1,1,35,17,136,52,0,136,168,16,139,40,16,136,153,16,137,156,168,36,169,137,130]

theorem envBound37708 : H12AffineFastState.Bounded env37708 := by
  intro p hp
  have h : env37708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37707_37708 : H12AffineEnvironment.transform 7 36 env37707 = env37708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env37707 == env37708) = true)

theorem identity37708 : scanCanonicalize (H12AffineFastState.compose env37708 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(6+1) ^^^ 44) := by decide +kernel

theorem selectedBound37708 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env37709 : List Nat := [2,4,8,16,32,17,44,36,11,52,0,53,12,1,1,35,17,36,52,0,36,4,16,39,40,16,36,53,16,37,48,4,36,5,37,46]

theorem envBound37709 : H12AffineFastState.Bounded env37709 := by
  intro p hp
  have h : env37709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37708_37709 : H12AffineEnvironment.transform 6 44 env37708 = env37709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 44 env37708 == env37709) = true)

theorem identity37709 : scanCanonicalize (H12AffineFastState.compose env37709 (packedSelected [2,4] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound37709 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env37710 : List Nat := [2,4,8,16,1,17,13,5,11,21,0,20,12,1,1,2,17,5,21,0,5,4,16,6,9,16,5,20,16,4,17,4,5,5,4,15]

theorem envBound37710 : H12AffineFastState.Bounded env37710 := by
  intro p hp
  have h : env37710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37709_37710 : H12AffineEnvironment.transform 4 1 env37709 = env37710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env37709 == env37710) = true)

theorem identity37710 : scanCanonicalize (H12AffineFastState.compose env37710 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 3) := by decide +kernel

theorem selectedBound37710 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37711 : List Nat := [2,4,8,3,1,2,13,5,11,6,0,7,12,1,1,2,2,5,6,0,5,4,3,6,9,3,5,7,3,4,2,4,5,5,4,15]

theorem envBound37711 : H12AffineFastState.Bounded env37711 := by
  intro p hp
  have h : env37711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37710_37711 : H12AffineEnvironment.transform 3 3 env37710 = env37711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 3 env37710 == env37711) = true)

theorem identity37711 : scanCanonicalize (H12AffineFastState.compose env37711 (packedSelected [2,6] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37711 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37712 : List Nat := [2,1,8,3,1,2,8,0,11,3,0,2,9,1,1,2,2,0,3,0,0,1,3,3,9,3,0,2,3,1,2,1,0,0,1,10]

theorem envBound37712 : H12AffineFastState.Bounded env37712 := by
  intro p hp
  have h : env37712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37711_37712 : H12AffineEnvironment.transform 1 1 env37711 = env37712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37711 == env37712) = true)

def env37713 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,456825,272513,452649,98780,8328,65,295285,458025,17665,10281,454116,144612,256,21793,46213,510515]

theorem envBound37713 : H12AffineFastState.Bounded env37713 := by
  intro p hp
  have h : env37713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37685_37713 : H12AffineEnvironment.transform 21 272513 env37685 = env37713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env37685 == env37713) = true)

theorem identity37713 : scanCanonicalize (H12AffineFastState.compose env37713 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound37713 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37714 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,456825,272513,452649,21763,8328,65,295285,458025,17665,10281,454116,144612,256,21793,46213,401132]

theorem envBound37714 : H12AffineFastState.Bounded env37714 := by
  intro p hp
  have h : env37714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37713_37714 : H12AffineEnvironment.transform 15 54495 env37713 = env37714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env37713 == env37714) = true)

def env37715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,456825,272393,452649,21763,8192,65,295285,458025,17665,10281,453996,144492,256,21793,46093,400996]

theorem envBound37715 : H12AffineFastState.Bounded env37715 := by
  intro p hp
  have h : env37715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37714_37715 : H12AffineEnvironment.transform 6 8 env37714 = env37715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37714 == env37715) = true)

theorem identity37715 : scanCanonicalize (H12AffineFastState.compose env37715 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound37715 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env37716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,35188,1024,32769,160013,41341,155997,21763,8192,65,2049,160861,17665,10281,156696,144492,256,21793,46093,169744]

theorem envBound37716 : H12AffineFastState.Bounded env37716 := by
  intro p hp
  have h : env37716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37715_37716 : H12AffineEnvironment.transform 17 35188 env37715 = env37716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env37715 == env37716) = true)

theorem identity37716 : scanCanonicalize (H12AffineFastState.compose env37716 (packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS)) = affineNative (2^(16+1) ^^^ 38161) := by decide +kernel

theorem selectedBound37716 : packedSelected [0,3,4,7,10,16,20,22,24,26] rootPS < 2^1333 := by decide +kernel

def env37717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,38161,35188,1024,32769,58396,41341,62540,21763,8192,65,2049,57676,17665,10281,61705,41341,256,21793,46093,513]

theorem envBound37717 : H12AffineFastState.Bounded env37717 := by
  intro p hp
  have h : env37717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37716_37717 : H12AffineEnvironment.transform 16 38161 env37716 = env37717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 38161 env37716 == env37717) = true)

theorem identity37717 : scanCanonicalize (H12AffineFastState.compose env37717 (packedSelected [2,3,5,6,10,12,15] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound37717 : packedSelected [2,3,5,6,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37718 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,33111,38161,35188,1024,32769,45340,41341,41292,3,8192,65,2049,46156,4097,10281,41993,41341,256,33,46093,513]

theorem envBound37718 : H12AffineFastState.Bounded env37718 := by
  intro p hp
  have h : env37718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37717_37718 : H12AffineEnvironment.transform 13 5376 env37717 = env37718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env37717 == env37718) = true)

theorem identity37718 : scanCanonicalize (H12AffineFastState.compose env37718 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound37718 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37719 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5376,32768,33111,38161,35188,1024,32769,36881,32880,32833,3,269,65,2049,38209,4097,2340,34052,32880,256,33,38144,513]

theorem envBound37719 : H12AffineFastState.Bounded env37719 := by
  intro p hp
  have h : env37719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37718_37719 : H12AffineEnvironment.transform 12 269 env37718 = env37719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env37718 == env37719) = true)

def env37720 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,456825,272392,452649,21763,8193,65,295285,458025,17665,10281,453997,144493,256,21793,46092,400997]

theorem envBound37720 : H12AffineFastState.Bounded env37720 := by
  intro p hp
  have h : env37720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37714_37720 : H12AffineEnvironment.transform 6 9 env37714 = env37720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37714 == env37720) = true)

theorem identity37720 : scanCanonicalize (H12AffineFastState.compose env37720 (packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS)) = affineNative (2^(17+1) ^^^ 179228) := by decide +kernel

theorem selectedBound37720 : packedSelected [0,1,3,4,8,12,14,15,18,19,20,22,23,24,26,27,31] rootPS < 2^1333 := by decide +kernel

def env37721 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,179228,1024,32769,17509,168980,21557,21763,8193,65,146793,16693,17665,10281,20849,144493,256,21793,46092,41593]

theorem envBound37721 : H12AffineFastState.Bounded env37721 := by
  intro p hp
  have h : env37721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37720_37721 : H12AffineEnvironment.transform 17 179228 env37720 = env37721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 179228 env37720 == env37721) = true)

theorem identity37721 : scanCanonicalize (H12AffineFastState.compose env37721 (packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound37721 : packedSelected [3,7,8,14,16,17,18,23,24,26,27,28,38,41] rootPS < 2^1333 := by decide +kernel

def env37722 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,131072,179228,1024,32769,12344,168980,8296,8542,8193,65,146793,13672,12636,10281,9516,144493,256,8572,46092,41593]

theorem envBound37722 : H12AffineFastState.Bounded env37722 := by
  intro p hp
  have h : env37722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37721_37722 : H12AffineEnvironment.transform 13 13405 env37721 = env37722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env37721 == env37722) = true)

theorem identity37722 : scanCanonicalize (H12AffineFastState.compose env37722 (packedSelected [2,3,4,6,10,11,16,19,22,23,24] rootPS)) = affineNative (2^(16+1) ^^^ 13624) := by decide +kernel

theorem selectedBound37722 : packedSelected [2,3,4,6,10,11,16,19,22,23,24] rootPS < 2^1333 := by decide +kernel

def env37723 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,32768,40971,13624,35108,1024,32769,12344,41260,8296,8542,8193,65,2129,13672,12636,10281,9516,341,256,8572,46092,41593]

theorem envBound37723 : H12AffineFastState.Bounded env37723 := by
  intro p hp
  have h : env37723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37722_37723 : H12AffineEnvironment.transform 16 13624 env37722 = env37723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13624 env37722 == env37723) = true)

theorem identity37723 : scanCanonicalize (H12AffineFastState.compose env37723 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound37723 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env37724 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,32768,40971,13624,35108,1024,32769,12344,41260,8248,8462,8193,17,2049,13624,12556,10281,9516,261,256,8492,46092,41513]

theorem envBound37724 : H12AffineFastState.Bounded env37724 := by
  intro p hp
  have h : env37724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37723_37724 : H12AffineEnvironment.transform 5 16 env37723 = env37724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env37723 == env37724) = true)

theorem identity37724 : scanCanonicalize (H12AffineFastState.compose env37724 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 1) := by decide +kernel

theorem selectedBound37724 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37725 : List Nat := [2,4,8,16,32,16,9,256,512,1024,2048,4096,8192,13325,1,8202,13624,2341,1024,0,12344,8493,8248,8462,8193,17,2049,13624,12556,10281,9516,261,256,8492,13325,8744]

theorem envBound37725 : H12AffineFastState.Bounded env37725 := by
  intro p hp
  have h : env37725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37724_37725 : H12AffineEnvironment.transform 14 1 env37724 = env37725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 1 env37724 == env37725) = true)

theorem identity37725 : scanCanonicalize (H12AffineFastState.compose env37725 (packedSelected [0,6,7,14,16] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37725 : packedSelected [0,6,7,14,16] rootPS < 2^1333 := by decide +kernel

def env37726 : List Nat := [2,4,8,16,32,16,9,37,512,1024,2048,4096,8192,13325,1,8202,13341,2048,1024,0,12344,8200,8248,8235,8193,17,2049,13341,12329,10281,9225,32,37,8201,13325,8744]

theorem envBound37726 : H12AffineFastState.Bounded env37726 := by
  intro p hp
  have h : env37726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37725_37726 : H12AffineEnvironment.transform 7 37 env37725 = env37726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37725 == env37726) = true)

theorem identity37726 : scanCanonicalize (H12AffineFastState.compose env37726 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound37726 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env37727 : List Nat := [2,4,8,16,32,16,9,37,512,53,2048,4096,8192,12344,1,8202,12328,2048,53,0,12344,8200,8248,8235,8193,17,2049,12328,12329,10281,8252,32,37,8201,12344,8744]

theorem envBound37727 : H12AffineFastState.Bounded env37727 := by
  intro p hp
  have h : env37727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37726_37727 : H12AffineEnvironment.transform 9 53 env37726 = env37727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env37726 == env37727) = true)

theorem identity37727 : scanCanonicalize (H12AffineFastState.compose env37727 (packedSelected [6] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37727 : packedSelected [6] rootPS < 2^1333 := by decide +kernel

def env37728 : List Nat := [2,4,8,0,32,0,9,37,512,37,2048,4096,8192,12328,1,8202,12328,2048,37,0,12328,8200,8232,8235,8193,1,2049,12328,12329,10281,8236,32,37,8201,12328,8744]

theorem envBound37728 : H12AffineFastState.Bounded env37728 := by
  intro p hp
  have h : env37728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37727_37728 : H12AffineEnvironment.transform 3 0 env37727 = env37728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37727 == env37728) = true)

theorem identity37728 : scanCanonicalize (H12AffineFastState.compose env37728 (packedSelected [0,1,3,4,5,8] rootPS)) = affineNative (2^(12+1) ^^^ 6185) := by decide +kernel

theorem selectedBound37728 : packedSelected [0,1,3,4,5,8] rootPS < 2^1333 := by decide +kernel

def env37729 : List Nat := [2,4,8,0,32,0,9,37,512,37,2048,4096,6185,2049,1,6179,2049,2048,37,0,2049,6177,6145,6146,6184,1,2049,2049,2048,4096,6149,32,37,6176,2049,6657]

theorem envBound37729 : H12AffineFastState.Bounded env37729 := by
  intro p hp
  have h : env37729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37728_37729 : H12AffineEnvironment.transform 12 6185 env37728 = env37729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 6185 env37728 == env37729) = true)

theorem identity37729 : scanCanonicalize (H12AffineFastState.compose env37729 (packedSelected [2,3,5] rootPS)) = affineNative (2^(11+1) ^^^ 2049) := by decide +kernel

theorem selectedBound37729 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37730 : List Nat := [2,4,8,0,32,0,9,37,512,37,2048,2049,40,2049,1,34,2049,2048,37,0,2049,32,0,3,41,1,2049,2049,2048,2049,4,32,37,33,2049,512]

theorem envBound37730 : H12AffineFastState.Bounded env37730 := by
  intro p hp
  have h : env37730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37729_37730 : H12AffineEnvironment.transform 11 2049 env37729 = env37730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2049 env37729 == env37730) = true)

theorem identity37730 : scanCanonicalize (H12AffineFastState.compose env37730 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 5) := by decide +kernel

theorem selectedBound37730 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37731 : List Nat := [2,4,8,0,5,0,9,0,512,0,2048,2049,13,2049,1,7,2049,2048,0,0,2049,5,0,3,12,1,2049,2049,2048,2049,4,5,0,4,2049,512]

theorem envBound37731 : H12AffineFastState.Bounded env37731 := by
  intro p hp
  have h : env37731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37730_37731 : H12AffineEnvironment.transform 4 5 env37730 = env37731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 5 env37730 == env37731) = true)

theorem identity37731 : scanCanonicalize (H12AffineFastState.compose env37731 (packedSelected [1] rootPS)) = affineNative (2^(8+1) ^^^ 8) := by decide +kernel

theorem selectedBound37731 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37732 : List Nat := [2,4,8,0,5,0,9,0,8,0,2048,2049,13,2049,1,7,2049,2048,0,0,2049,5,0,3,12,1,2049,2049,2048,2049,4,5,0,4,2049,8]

theorem envBound37732 : H12AffineFastState.Bounded env37732 := by
  intro p hp
  have h : env37732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37731_37732 : H12AffineEnvironment.transform 8 8 env37731 = env37732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 8 env37731 == env37732) = true)

theorem identity37732 : scanCanonicalize (H12AffineFastState.compose env37732 (packedSelected [2] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound37732 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37733 : List Nat := [2,1,8,0,0,0,9,0,8,0,2048,2049,8,2049,1,2,2049,2048,0,0,2049,0,0,3,9,1,2049,2049,2048,2049,1,0,0,1,2049,8]

theorem envBound37733 : H12AffineFastState.Bounded env37733 := by
  intro p hp
  have h : env37733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37732_37733 : H12AffineEnvironment.transform 1 1 env37732 = env37733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env37732 == env37733) = true)

theorem identity37733 : scanCanonicalize (H12AffineFastState.compose env37733 (packedSelected [3] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound37733 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37734 : List Nat := [2,1,8,0,0,0,9,0,8,0,10,11,8,11,1,2,11,10,0,0,11,0,0,3,9,1,11,11,10,11,1,0,0,1,11,8]

theorem envBound37734 : H12AffineFastState.Bounded env37734 := by
  intro p hp
  have h : env37734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37733_37734 : H12AffineEnvironment.transform 10 10 env37733 = env37734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env37733 == env37734) = true)

theorem identity37734 : scanCanonicalize (H12AffineFastState.compose env37734 (packedSelected [4] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound37734 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37735 : List Nat := [2,1,2,0,0,0,3,0,2,0,0,1,2,1,1,2,1,0,0,0,1,0,0,3,3,1,1,1,0,1,1,0,0,1,1,2]

theorem envBound37735 : H12AffineFastState.Bounded env37735 := by
  intro p hp
  have h : env37735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37734_37735 : H12AffineEnvironment.transform 2 2 env37734 = env37735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env37734 == env37735) = true)

def env37736 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507601,8830977,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound37736 : H12AffineFastState.Bounded env37736 := by
  intro p hp
  have h : env37736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37577_37736 : H12AffineEnvironment.transform 18 1025 env37577 = env37736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env37577 == env37736) = true)

theorem identity37736 : scanCanonicalize (H12AffineFastState.compose env37736 (packedSelected [13] rootPS)) = affineNative (2^(17+1) ^^^ 35188) := by decide +kernel

theorem selectedBound37736 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env37737 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8328,65,29575540,18973837,10507601,8538485,25265169,23160256,257,27378860,27337993,25207751]

theorem envBound37737 : H12AffineFastState.Bounded env37737 := by
  intro p hp
  have h : env37737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37736_37737 : H12AffineEnvironment.transform 17 35188 env37736 = env37737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 35188 env37736 == env37737) = true)

def env37738 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8192,65,29575540,18973701,10507601,8538485,25265169,23160136,257,27378724,27337993,25207631]

theorem envBound37738 : H12AffineFastState.Bounded env37738 := by
  intro p hp
  have h : env37738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37737_37738 : H12AffineEnvironment.transform 6 8 env37737 = env37738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env37737 == env37738) = true)

theorem identity37738 : scanCanonicalize (H12AffineFastState.compose env37738 (packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS)) = affineNative (2^(16+1) ^^^ 90138) := by decide +kernel

theorem selectedBound37738 : packedSelected [0,1,3,9,10,14,19,22,24,26,27,28,31,35] rootPS < 2^1333 := by decide +kernel

def env37739 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,8388608,16777216,8192,65,29370734,18973701,10507601,8464751,25265169,23160136,257,27378724,27337993,25207631]

theorem envBound37739 : H12AffineFastState.Bounded env37739 := by
  intro p hp
  have h : env37739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37738_37739 : H12AffineEnvironment.transform 16 90138 env37738 = env37739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90138 env37738 == env37739) = true)

def env37740 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,8388608,98644,8192,65,12691514,2098513,10507601,8464751,8389957,6349852,257,10503536,10527837,8462875]

theorem envBound37740 : H12AffineFastState.Bounded env37740 := by
  intro p hp
  have h : env37740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37739_37740 : H12AffineEnvironment.transform 23 98644 env37739 = env37740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98644 env37739 == env37740) = true)

theorem identity37740 : scanCanonicalize (H12AffineFastState.compose env37740 (packedSelected [1,3,10,19,24,26,28,31] rootPS)) = affineNative (2^(22+1) ^^^ 73754) := by decide +kernel

theorem selectedBound37740 : packedSelected [1,3,10,19,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env37741 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,73754,98644,8192,65,4229152,2098513,2192715,2421,75103,6349852,257,2188650,2196551,513]

theorem envBound37741 : H12AffineFastState.Bounded env37741 := by
  intro p hp
  have h : env37741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37740_37741 : H12AffineEnvironment.transform 22 73754 env37740 = env37741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73754 env37740 == env37741) = true)

theorem identity37741 : scanCanonicalize (H12AffineFastState.compose env37741 (packedSelected [12,15,17,21,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 73770) := by decide +kernel

theorem selectedBound37741 : packedSelected [12,15,17,21,38,41] rootPS < 2^1333 := by decide +kernel

def env37742 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,73770,73754,98644,8192,65,108554,2098513,2192715,2421,75103,2212918,257,2188650,2196551,513]

theorem envBound37742 : H12AffineFastState.Bounded env37742 := by
  intro p hp
  have h : env37742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37741_37742 : H12AffineEnvironment.transform 21 73770 env37741 = env37742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 73770 env37741 == env37742) = true)

theorem identity37742 : scanCanonicalize (H12AffineFastState.compose env37742 (packedSelected [17] rootPS)) = affineNative (2^(20+1) ^^^ 91466) := by decide +kernel

theorem selectedBound37742 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37743 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,91466,73770,73754,98644,8192,65,108554,90139,4097,2421,75103,41340,257,32,57613,513]

theorem envBound37743 : H12AffineFastState.Bounded env37743 := by
  intro p hp
  have h : env37743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37742_37743 : H12AffineEnvironment.transform 20 91466 env37742 = env37743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 91466 env37742 == env37743) = true)

theorem identity37743 : scanCanonicalize (H12AffineFastState.compose env37743 (packedSelected [0,7,20] rootPS)) = affineNative (2^(14+1) ^^^ 29004) := by decide +kernel

theorem selectedBound37743 : packedSelected [0,7,20] rootPS < 2^1333 := by decide +kernel

def env37744 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,65536,90138,30776,1025,29005,91466,73770,73754,94232,8192,65,88390,90139,4097,2421,75103,20528,257,32,4161,513]

theorem envBound37744 : H12AffineFastState.Bounded env37744 := by
  intro p hp
  have h : env37744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37743_37744 : H12AffineEnvironment.transform 14 29004 env37743 = env37744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29004 env37743 == env37744) = true)

theorem identity37744 : scanCanonicalize (H12AffineFastState.compose env37744 (packedSelected [3,5,10] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound37744 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env37745 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29004,8203,16401,30776,1025,29005,17729,33,17,20499,8192,65,31053,16400,4097,2421,1364,20528,257,32,4161,513]

theorem envBound37745 : H12AffineFastState.Bounded env37745 := by
  intro p hp
  have h : env37745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37744_37745 : H12AffineEnvironment.transform 15 8203 env37744 = env37745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env37744 == env37745) = true)

theorem identity37745 : scanCanonicalize (H12AffineFastState.compose env37745 (packedSelected [0,4,7,9,14] rootPS)) = affineNative (2^(13+1) ^^^ 12620) := by decide +kernel

theorem selectedBound37745 : packedSelected [0,4,7,9,14] rootPS < 2^1333 := by decide +kernel

def env37746 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,12620,0,8203,12637,2420,1025,1,13325,33,17,8543,8192,65,2049,12636,4097,2421,1364,8572,257,32,4161,513]

theorem envBound37746 : H12AffineFastState.Bounded env37746 := by
  intro p hp
  have h : env37746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37745_37746 : H12AffineEnvironment.transform 13 12620 env37745 = env37746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 12620 env37745 == env37746) = true)

theorem identity37746 : scanCanonicalize (H12AffineFastState.compose env37746 (packedSelected [1,3] rootPS)) = affineNative (2^(12+1) ^^^ 633) := by decide +kernel

theorem selectedBound37746 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env37747 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,633,4917,0,626,4900,2420,1025,1,5748,33,17,806,633,65,2049,4901,4097,2421,1364,773,257,32,4161,513]

theorem envBound37747 : H12AffineFastState.Bounded env37747 := by
  intro p hp
  have h : env37747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37746_37747 : H12AffineEnvironment.transform 12 633 env37746 = env37747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 633 env37746 == env37747) = true)

theorem identity37747 : scanCanonicalize (H12AffineFastState.compose env37747 (packedSelected [2,6] rootPS)) = affineNative (2^(8+1) ^^^ 292) := by decide +kernel

theorem selectedBound37747 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env37748 : List Nat := [2,4,8,16,32,64,8,256,292,1024,2048,4096,349,4113,0,342,4096,2420,1025,1,5456,33,17,2,349,65,2049,4097,4097,2421,1364,33,257,32,4161,293]

theorem envBound37748 : H12AffineFastState.Bounded env37748 := by
  intro p hp
  have h : env37748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37747_37748 : H12AffineEnvironment.transform 8 292 env37747 = env37748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 292 env37747 == env37748) = true)

theorem identity37748 : scanCanonicalize (H12AffineFastState.compose env37748 (packedSelected [0,7] rootPS)) = affineNative (2^(11+1) ^^^ 1297) := by decide +kernel

theorem selectedBound37748 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env37749 : List Nat := [2,4,8,16,32,64,8,256,292,1024,2048,1297,349,1280,0,342,1297,2420,1025,1,65,33,17,2,349,65,2049,1296,1296,2421,1364,33,257,32,1360,293]

theorem envBound37749 : H12AffineFastState.Bounded env37749 := by
  intro p hp
  have h : env37749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37748_37749 : H12AffineEnvironment.transform 11 1297 env37748 = env37749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1297 env37748 == env37749) = true)

theorem identity37749 : scanCanonicalize (H12AffineFastState.compose env37749 (packedSelected [2,4,9] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37749 : packedSelected [2,4,9] rootPS < 2^1333 := by decide +kernel

def env37750 : List Nat := [2,4,8,16,32,64,8,256,292,272,2048,1,349,16,0,342,1,2420,273,1,65,33,17,2,349,65,2049,0,0,2421,68,33,257,32,64,293]

theorem envBound37750 : H12AffineFastState.Bounded env37750 := by
  intro p hp
  have h : env37750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37749_37750 : H12AffineEnvironment.transform 9 272 env37749 = env37750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37749 == env37750) = true)

theorem identity37750 : scanCanonicalize (H12AffineFastState.compose env37750 (packedSelected [2] rootPS)) = affineNative (2^(7+1) ^^^ 101) := by decide +kernel

theorem selectedBound37750 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37751 : List Nat := [2,4,8,16,32,64,8,101,65,117,2048,1,56,16,0,51,1,2065,116,1,65,33,17,2,56,65,2049,0,0,2064,68,33,100,32,64,64]

theorem envBound37751 : H12AffineFastState.Bounded env37751 := by
  intro p hp
  have h : env37751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37750_37751 : H12AffineEnvironment.transform 7 101 env37750 = env37751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 101 env37750 == env37751) = true)

theorem identity37751 : scanCanonicalize (H12AffineFastState.compose env37751 (packedSelected [5] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound37751 : packedSelected [5] rootPS < 2^1333 := by decide +kernel

def env37752 : List Nat := [2,4,8,16,0,64,8,69,65,85,2048,1,24,16,0,19,1,2065,84,1,65,1,17,2,24,65,2049,0,0,2064,68,1,68,0,64,64]

theorem envBound37752 : H12AffineFastState.Bounded env37752 := by
  intro p hp
  have h : env37752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37751_37752 : H12AffineEnvironment.transform 4 0 env37751 = env37752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env37751 == env37752) = true)

theorem identity37752 : scanCanonicalize (H12AffineFastState.compose env37752 (packedSelected [0,4,8] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound37752 : packedSelected [0,4,8] rootPS < 2^1333 := by decide +kernel

def env37753 : List Nat := [2,4,8,0,0,64,8,69,65,69,2048,1,8,0,0,3,1,2049,68,1,65,1,1,2,8,65,2049,0,0,2048,68,1,68,0,64,64]

theorem envBound37753 : H12AffineFastState.Bounded env37753 := by
  intro p hp
  have h : env37753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37752_37753 : H12AffineEnvironment.transform 3 0 env37752 = env37753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env37752 == env37753) = true)

theorem identity37753 : scanCanonicalize (H12AffineFastState.compose env37753 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 65) := by decide +kernel

theorem selectedBound37753 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37754 : List Nat := [2,4,8,0,0,64,8,69,65,69,65,1,8,0,0,3,1,64,68,1,65,1,1,2,8,65,64,0,0,65,68,1,68,0,64,64]

theorem envBound37754 : H12AffineFastState.Bounded env37754 := by
  intro p hp
  have h : env37754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37753_37754 : H12AffineEnvironment.transform 10 65 env37753 = env37754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 65 env37753 == env37754) = true)

theorem identity37754 : scanCanonicalize (H12AffineFastState.compose env37754 (packedSelected [1] rootPS)) = affineNative (2^(5+1) ^^^ 0) := by decide +kernel

theorem selectedBound37754 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37755 : List Nat := [2,4,8,0,0,0,8,5,1,5,1,1,8,0,0,3,1,0,4,1,1,1,1,2,8,1,0,0,0,1,4,1,4,0,0,0]

theorem envBound37755 : H12AffineFastState.Bounded env37755 := by
  intro p hp
  have h : env37755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37754_37755 : H12AffineEnvironment.transform 5 0 env37754 = env37755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 0 env37754 == env37755) = true)

def env37756 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,4194304,8388608,98645,8192,65,12691515,2098512,10507601,8464751,8389956,6349853,257,10503537,10527836,8462874]

theorem envBound37756 : H12AffineFastState.Bounded env37756 := by
  intro p hp
  have h : env37756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37739_37756 : H12AffineEnvironment.transform 23 98645 env37739 = env37756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 98645 env37739 == env37756) = true)

theorem identity37756 : scanCanonicalize (H12AffineFastState.compose env37756 (packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS)) = affineNative (2^(21+1) ^^^ 98679) := by decide +kernel

theorem selectedBound37756 : packedSelected [0,1,4,5,7,8,12,15,16,17,19,20,21,22,24,26,38,41] rootPS < 2^1333 := by decide +kernel

def env37757 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,2097152,98679,8388608,98645,8192,65,8399180,2098512,10507601,8464751,8389956,2188650,257,10503537,10527836,8462874]

theorem envBound37757 : H12AffineFastState.Bounded env37757 := by
  intro p hp
  have h : env37757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37756_37757 : H12AffineEnvironment.transform 21 98679 env37756 = env37757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 98679 env37756 == env37757) = true)

def env37758 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,4160,98679,8388608,98645,8192,65,8399180,5392,8406289,8464751,8389956,95530,257,8410417,8434716,8462874]

theorem envBound37758 : H12AffineFastState.Bounded env37758 := by
  intro p hp
  have h : env37758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37757_37758 : H12AffineEnvironment.transform 20 4160 env37757 = env37758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env37757 == env37758) = true)

theorem identity37758 : scanCanonicalize (H12AffineFastState.compose env37758 (packedSelected [21] rootPS)) = affineNative (2^(22+1) ^^^ 73755) := by decide +kernel

theorem selectedBound37758 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env37759 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,4160,98679,73755,98645,8192,65,67927,5392,91402,2420,75103,95530,257,95530,103431,513]

theorem envBound37759 : H12AffineFastState.Bounded env37759 := by
  intro p hp
  have h : env37759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37758_37759 : H12AffineEnvironment.transform 22 73755 env37758 = env37759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 73755 env37758 == env37759) = true)

theorem identity37759 : scanCanonicalize (H12AffineFastState.compose env37759 (packedSelected [0,2,4,6,7,9,14,17] rootPS)) = affineNative (2^(14+1) ^^^ 20545) := by decide +kernel

theorem selectedBound37759 : packedSelected [0,2,4,6,7,9,14,17] rootPS < 2^1333 := by decide +kernel

def env37760 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,20545,65536,90138,22837,1025,20544,4160,86326,73755,86292,8192,65,67927,5392,91402,2420,75103,95530,257,95530,83014,513]

theorem envBound37760 : H12AffineFastState.Bounded env37760 := by
  intro p hp
  have h : env37760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37759_37760 : H12AffineEnvironment.transform 14 20545 env37759 = env37760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 20545 env37759 == env37760) = true)

theorem identity37760 : scanCanonicalize (H12AffineFastState.compose env37760 (packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS)) = affineNative (2^(13+1) ^^^ 13688) := by decide +kernel

theorem selectedBound37760 : packedSelected [0,3,5,7,10,12,15,18,20,23] rootPS < 2^1333 := by decide +kernel

def env37761 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,9529,65536,71010,11341,1025,9528,4160,74830,73755,74860,8192,65,67927,5392,69746,2420,75103,65618,257,65618,78142,513]

theorem envBound37761 : H12AffineFastState.Bounded env37761 := by
  intro p hp
  have h : env37761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37760_37761 : H12AffineEnvironment.transform 13 13688 env37760 = env37761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13688 env37760 == env37761) = true)

theorem identity37761 : scanCanonicalize (H12AffineFastState.compose env37761 (packedSelected [3,4,5,7,9,10,11,18,27] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound37761 : packedSelected [3,4,5,7,9,10,11,18,27] rootPS < 2^1333 := by decide +kernel

def env37762 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13688,9529,8202,13672,11341,1025,9528,4160,1092,17,1126,8192,65,10589,5392,12408,2420,1365,8280,257,8280,4404,513]

theorem envBound37762 : H12AffineFastState.Bounded env37762 := by
  intro p hp
  have h : env37762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37761_37762 : H12AffineEnvironment.transform 15 8202 env37761 = env37762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env37761 == env37762) = true)

theorem identity37762 : scanCanonicalize (H12AffineFastState.compose env37762 (packedSelected [11] rootPS)) = affineNative (2^(11+1) ^^^ 17) := by decide +kernel

theorem selectedBound37762 : packedSelected [11] rootPS < 2^1333 := by decide +kernel

def env37763 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,17,8192,9577,9529,8202,9593,11341,1025,9528,81,1092,17,1126,8192,65,10589,1281,8297,2420,1365,8280,257,8280,293,513]

theorem envBound37763 : H12AffineFastState.Bounded env37763 := by
  intro p hp
  have h : env37763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37762_37763 : H12AffineEnvironment.transform 11 17 env37762 = env37763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 17 env37762 == env37763) = true)

def env37764 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,4161,98679,8388608,98645,8192,65,8399180,5393,8406288,8464751,8389956,95531,257,8410416,8434717,8462874]

theorem envBound37764 : H12AffineFastState.Bounded env37764 := by
  intro p hp
  have h : env37764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37757_37764 : H12AffineEnvironment.transform 20 4161 env37757 = env37764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env37757 == env37764) = true)

def env37765 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,4161,98679,16,98645,8192,65,10588,5393,17664,76159,1364,95531,257,21792,46093,74250]

theorem envBound37765 : H12AffineFastState.Bounded env37765 := by
  intro p hp
  have h : env37765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37764_37765 : H12AffineEnvironment.transform 22 16 env37764 = env37765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 16 env37764 == env37765) = true)

def env37766 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90138,35188,1025,32769,4161,98679,17,98645,8192,65,10589,5393,17665,76158,1365,95531,257,21793,46092,74251]

theorem envBound37766 : H12AffineFastState.Bounded env37766 := by
  intro p hp
  have h : env37766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37764_37766 : H12AffineEnvironment.transform 22 17 env37764 = env37766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 17 env37764 == env37766) = true)

theorem identity37766 : scanCanonicalize (H12AffineFastState.compose env37766 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound37766 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env37767 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,8541,65536,90138,10281,1025,8540,4161,73770,17,73736,8192,65,10589,5393,17665,76158,1365,95531,257,21793,5457,74251]

theorem envBound37767 : H12AffineFastState.Bounded env37767 := by
  intro p hp
  have h : env37767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37766_37767 : H12AffineEnvironment.transform 14 8541 env37766 = env37767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env37766 == env37767) = true)

theorem identity37767 : scanCanonicalize (H12AffineFastState.compose env37767 (packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5157) := by decide +kernel

theorem selectedBound37767 : packedSelected [0,2,4,6,7,9,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env37768 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5157,8541,65536,78911,10281,1025,8540,4161,73770,17,73736,8192,65,10589,5393,4388,76158,1365,73998,257,260,5457,74251]

theorem envBound37768 : H12AffineFastState.Bounded env37768 := by
  intro p hp
  have h : env37768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37767_37768 : H12AffineEnvironment.transform 13 5157 env37767 = env37768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5157 env37767 == env37768) = true)

theorem identity37768 : scanCanonicalize (H12AffineFastState.compose env37768 (packedSelected [3,5,10,12,15] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound37768 : packedSelected [3,5,10,12,15] rootPS < 2^1333 := by decide +kernel

def env37769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5157,372,65536,70678,2048,1025,373,4161,65539,17,65569,41,65,2420,5393,4388,67927,1365,65831,257,260,5457,66082]

theorem envBound37769 : H12AffineFastState.Bounded env37769 := by
  intro p hp
  have h : env37769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37768_37769 : H12AffineEnvironment.transform 12 41 env37768 = env37769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env37768 == env37769) = true)

theorem identity37769 : scanCanonicalize (H12AffineFastState.compose env37769 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(15+1) ^^^ 342) := by decide +kernel

theorem selectedBound37769 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env37770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,41,5157,372,342,5440,2048,1025,373,4161,341,17,375,41,65,2420,5393,4388,2049,1365,113,257,260,5457,884]

theorem envBound37770 : H12AffineFastState.Bounded env37770 := by
  intro p hp
  have h : env37770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37769_37770 : H12AffineEnvironment.transform 15 342 env37769 = env37770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 342 env37769 == env37770) = true)

theorem identity37770 : scanCanonicalize (H12AffineFastState.compose env37770 (packedSelected [0,2,3,5,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2064) := by decide +kernel

theorem selectedBound37770 : packedSelected [0,2,3,5,6,7] rootPS < 2^1333 := by decide +kernel

def env37771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,2064,41,3125,372,342,3408,2048,1025,373,2129,341,17,375,41,65,2420,3329,2356,2049,1365,113,257,260,3393,884]

theorem envBound37771 : H12AffineFastState.Bounded env37771 := by
  intro p hp
  have h : env37771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37770_37771 : H12AffineEnvironment.transform 11 2064 env37770 = env37771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2064 env37770 == env37771) = true)

theorem identity37771 : scanCanonicalize (H12AffineFastState.compose env37771 (packedSelected [0,4,6] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound37771 : packedSelected [0,4,6] rootPS < 2^1333 := by decide +kernel

def env37772 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,2064,41,2341,372,342,2112,2048,273,373,2129,341,17,375,41,65,2420,2065,2356,2049,69,113,257,260,2129,884]

theorem envBound37772 : H12AffineFastState.Bounded env37772 := by
  intro p hp
  have h : env37772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37771_37772 : H12AffineEnvironment.transform 9 272 env37771 = env37772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env37771 == env37772) = true)

theorem identity37772 : scanCanonicalize (H12AffineFastState.compose env37772 (packedSelected [2,3,4,5,9] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound37772 : packedSelected [2,3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env37773 : List Nat := [2,4,8,16,32,64,8,37,512,53,2048,2064,41,2048,81,115,2112,2048,52,80,2129,112,17,82,41,65,2129,2065,2065,2049,69,113,36,33,2129,593]

theorem envBound37773 : H12AffineFastState.Bounded env37773 := by
  intro p hp
  have h : env37773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37772_37773 : H12AffineEnvironment.transform 7 37 env37772 = env37773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env37772 == env37773) = true)

theorem identity37773 : scanCanonicalize (H12AffineFastState.compose env37773 (packedSelected [2,3,5] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound37773 : packedSelected [2,3,5] rootPS < 2^1333 := by decide +kernel

def env37774 : List Nat := [2,4,8,16,32,17,8,37,512,53,2048,2064,41,2048,0,34,2065,2048,52,1,2048,33,17,3,41,16,2048,2065,2065,2049,20,32,36,33,2048,512]

theorem envBound37774 : H12AffineFastState.Bounded env37774 := by
  intro p hp
  have h : env37774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37773_37774 : H12AffineEnvironment.transform 5 17 env37773 = env37774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env37773 == env37774) = true)

theorem identity37774 : scanCanonicalize (H12AffineFastState.compose env37774 (packedSelected [0] rootPS)) = affineNative (2^(10+1) ^^^ 21) := by decide +kernel

theorem selectedBound37774 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env37775 : List Nat := [2,4,8,16,32,17,8,37,512,53,21,5,41,21,0,34,4,21,52,1,21,33,17,3,41,16,21,4,4,20,20,32,36,33,21,512]

theorem envBound37775 : H12AffineFastState.Bounded env37775 := by
  intro p hp
  have h : env37775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37774_37775 : H12AffineEnvironment.transform 10 21 env37774 = env37775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 21 env37774 == env37775) = true)

theorem identity37775 : scanCanonicalize (H12AffineFastState.compose env37775 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 6) := by decide +kernel

theorem selectedBound37775 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env37776 : List Nat := [2,4,8,6,32,7,8,37,512,35,3,5,41,3,0,34,4,3,34,1,3,33,7,3,41,6,3,4,4,2,2,32,36,33,3,512]

theorem envBound37776 : H12AffineFastState.Bounded env37776 := by
  intro p hp
  have h : env37776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37775_37776 : H12AffineEnvironment.transform 3 6 env37775 = env37776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 6 env37775 == env37776) = true)

theorem identity37776 : scanCanonicalize (H12AffineFastState.compose env37776 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 2) := by decide +kernel

theorem selectedBound37776 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env37777 : List Nat := [2,4,8,6,2,7,8,7,512,1,3,5,11,3,0,0,4,3,0,1,3,3,7,3,11,6,3,4,4,2,2,2,6,3,3,512]

theorem envBound37777 : H12AffineFastState.Bounded env37777 := by
  intro p hp
  have h : env37777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37776_37777 : H12AffineEnvironment.transform 4 2 env37776 = env37777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 2 env37776 == env37777) = true)

theorem identity37777 : scanCanonicalize (H12AffineFastState.compose env37777 (packedSelected [3] rootPS)) = affineNative (2^(8+1) ^^^ 9) := by decide +kernel

theorem selectedBound37777 : packedSelected [3] rootPS < 2^1333 := by decide +kernel

def env37778 : List Nat := [2,4,8,6,2,7,8,7,9,1,3,5,11,3,0,0,4,3,0,1,3,3,7,3,11,6,3,4,4,2,2,2,6,3,3,9]

theorem envBound37778 : H12AffineFastState.Bounded env37778 := by
  intro p hp
  have h : env37778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37777_37778 : H12AffineEnvironment.transform 8 9 env37777 = env37778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 9 env37777 == env37778) = true)

theorem identity37778 : scanCanonicalize (H12AffineFastState.compose env37778 (packedSelected [4] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound37778 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env37779 : List Nat := [0,4,8,4,0,5,8,5,9,1,1,5,9,1,0,0,4,1,0,1,1,1,5,1,9,4,1,4,4,0,0,0,4,1,1,9]

theorem envBound37779 : H12AffineFastState.Bounded env37779 := by
  intro p hp
  have h : env37779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37778_37779 : H12AffineEnvironment.transform 0 0 env37778 = env37779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env37778 == env37779) = true)

def env37780 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,8388608,16777216,8193,65,29575540,18973700,10507601,8538485,25265169,23160137,257,27378725,27337993,25207630]

theorem envBound37780 : H12AffineFastState.Bounded env37780 := by
  intro p hp
  have h : env37780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37737_37780 : H12AffineEnvironment.transform 6 9 env37737 = env37780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env37737 == env37780) = true)

def env37781 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,35188,1025,32769,2097152,4194304,147456,16777216,8193,65,21039476,18973700,2233681,2421,17024017,23160137,257,19104805,19096841,16966478]

theorem envBound37781 : H12AffineFastState.Bounded env37781 := by
  intro p hp
  have h : env37781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans37780_37781 : H12AffineEnvironment.transform 22 147456 env37780 = env37781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 147456 env37780 == env37781) = true)

def env37782 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,16400,35188,1025,32769,2097152,4194304,16,16777216,8193,65,21039476,18973700,2118977,2421,16876545,23160137,257,18990133,18949401,16819038]

theorem envBound37782 : H12AffineFastState.Bounded env37782 := by
  intro p hp
  have h : env37782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

end H12CloudChart1