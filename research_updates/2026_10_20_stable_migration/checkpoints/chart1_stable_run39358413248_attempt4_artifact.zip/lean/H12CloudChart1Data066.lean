import H12CloudChart1Data065

namespace H12CloudChart1

open H12PackedPolynomial

set_option maxRecDepth 100000

set_option maxHeartbeats 1000000000

theorem identity16627 : scanCanonicalize (H12AffineFastState.compose env16627 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1061) := by decide +kernel

theorem selectedBound16627 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16628 : List Nat := [2,4,8,16,32,16,9,36,512,1024,2048,1061,41,1,0,35,16,2048,1024,1,1077,32,17,2,40,17,2048,17,1060,2049,1057,32,36,33,1,513]

theorem envBound16628 : H12AffineFastState.Bounded env16628 := by
  intro p hp
  have h : env16628.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16627_16628 : H12AffineEnvironment.transform 11 1061 env16627 = env16628 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1061 env16627 == env16628) = true)

theorem identity16628 : scanCanonicalize (H12AffineFastState.compose env16628 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 0) := by decide +kernel

theorem selectedBound16628 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16629 : List Nat := [2,4,8,16,32,16,9,36,512,1024,0,1061,41,1,0,35,16,0,1024,1,1077,32,17,2,40,17,0,17,1060,1,1057,32,36,33,1,513]

theorem envBound16629 : H12AffineFastState.Bounded env16629 := by
  intro p hp
  have h : env16629.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16628_16629 : H12AffineEnvironment.transform 10 0 env16628 = env16629 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 0 env16628 == env16629) = true)

theorem identity16629 : scanCanonicalize (H12AffineFastState.compose env16629 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound16629 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16630 : List Nat := [2,4,8,16,32,16,9,36,512,53,0,16,41,1,0,35,16,0,53,1,0,32,17,2,40,17,0,17,17,1,20,32,36,33,1,513]

theorem envBound16630 : H12AffineFastState.Bounded env16630 := by
  intro p hp
  have h : env16630.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16629_16630 : H12AffineEnvironment.transform 9 53 env16629 = env16630 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env16629 == env16630) = true)

theorem identity16630 : scanCanonicalize (H12AffineFastState.compose env16630 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16630 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16631 : List Nat := [2,4,8,16,32,16,9,36,0,53,0,16,41,1,0,35,16,0,53,1,0,32,17,2,40,17,0,17,17,1,20,32,36,33,1,1]

theorem envBound16631 : H12AffineFastState.Bounded env16631 := by
  intro p hp
  have h : env16631.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16630_16631 : H12AffineEnvironment.transform 8 0 env16630 = env16631 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16630 == env16631) = true)

theorem identity16631 : scanCanonicalize (H12AffineFastState.compose env16631 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16631 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16632 : List Nat := [2,4,3,16,32,16,2,36,0,53,0,16,34,1,0,35,16,0,53,1,0,32,17,2,35,17,0,17,17,1,20,32,36,33,1,1]

theorem envBound16632 : H12AffineFastState.Bounded env16632 := by
  intro p hp
  have h : env16632.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16631_16632 : H12AffineEnvironment.transform 2 3 env16631 = env16632 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16631 == env16632) = true)

def env16633 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,65536,131072,10401,1024,29909,140420,33,144597,95496,8328,65,23944,139732,17665,10401,143640,144492,256,21793,16464,202447]

theorem envBound16633 : H12AffineFastState.Bounded env16633 := by
  intro p hp
  have h : env16633.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16619_16633 : H12AffineEnvironment.transform 17 10401 env16619 = env16633 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 10401 env16619 == env16633) = true)

theorem identity16633 : scanCanonicalize (H12AffineFastState.compose env16633 (packedSelected [12,15,16,17,20,38,41] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound16633 : packedSelected [12,15,16,17,20,38,41] rootPS < 2^1333 := by decide +kernel

def env16634 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29908,478,131072,10401,1024,29909,140420,33,144597,29910,8328,65,23944,139732,17665,10401,143640,144492,256,21793,16464,136977]

theorem envBound16634 : H12AffineFastState.Bounded env16634 := by
  intro p hp
  have h : env16634.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16633_16634 : H12AffineEnvironment.transform 15 478 env16633 = env16634 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env16633 == env16634) = true)

theorem identity16634 : scanCanonicalize (H12AffineFastState.compose env16634 (packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS)) = affineNative (2^(13+1) ^^^ 13405) := by decide +kernel

theorem selectedBound16634 : packedSelected [0,2,3,4,6,7,8,9,11,12,14,15,17,23,24,26,28] rootPS < 2^1333 := by decide +kernel

def env16635 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,478,131072,10401,1024,136,140420,33,144597,139,8328,65,10709,139732,12636,10401,143640,144492,256,8572,13325,136977]

theorem envBound16635 : H12AffineFastState.Bounded env16635 := by
  intro p hp
  have h : env16635.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16634_16635 : H12AffineEnvironment.transform 13 13405 env16634 = env16635 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13405 env16634 == env16635) = true)

theorem identity16635 : scanCanonicalize (H12AffineFastState.compose env16635 (packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 13509) := by decide +kernel

theorem selectedBound16635 : packedSelected [0,1,3,4,5,7,8,10,16,17,19,20,22] rootPS < 2^1333 := by decide +kernel

def env16636 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13405,137,478,13509,10401,1024,136,4161,33,16,139,8328,65,10709,5393,12636,10401,1501,169,256,8572,13325,9172]

theorem envBound16636 : H12AffineFastState.Bounded env16636 := by
  intro p hp
  have h : env16636.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16635_16636 : H12AffineEnvironment.transform 16 13509 env16635 = env16636 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13509 env16635 == env16636) = true)

theorem identity16636 : scanCanonicalize (H12AffineFastState.compose env16636 (packedSelected [16,20] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16636 : packedSelected [16,20] rootPS < 2^1333 := by decide +kernel

def env16637 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13405,0,343,13388,10280,1024,1,4161,33,16,2,8193,65,10588,5393,12636,10280,1364,32,256,8572,13325,9053]

theorem envBound16637 : H12AffineFastState.Bounded env16637 := by
  intro p hp
  have h : env16637.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16636_16637 : H12AffineEnvironment.transform 6 9 env16636 = env16637 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16636 == env16637) = true)

theorem identity16637 : scanCanonicalize (H12AffineFastState.compose env16637 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound16637 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16638 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,349,5376,0,343,5393,2421,1024,1,4161,33,16,2,348,65,2049,5393,4097,2421,1364,32,256,33,5456,512]

theorem envBound16638 : H12AffineFastState.Bounded env16638 := by
  intro p hp
  have h : env16638.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16637_16638 : H12AffineEnvironment.transform 12 349 env16637 = env16638 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env16637 == env16638) = true)

theorem identity16638 : scanCanonicalize (H12AffineFastState.compose env16638 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 2895) := by decide +kernel

theorem selectedBound16638 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16639 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,2895,349,3663,0,343,3678,2421,1024,1,2830,33,16,2,348,65,2049,3678,2894,2421,1364,32,256,33,3615,512]

theorem envBound16639 : H12AffineFastState.Bounded env16639 := by
  intro p hp
  have h : env16639.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16638_16639 : H12AffineEnvironment.transform 11 2895 env16638 = env16639 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2895 env16638 == env16639) = true)

theorem identity16639 : scanCanonicalize (H12AffineFastState.compose env16639 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound16639 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16640 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,2879,301,3647,0,295,3630,2309,1024,1,2830,33,16,2,300,49,2049,3630,2878,2309,1316,32,256,33,3615,512]

theorem envBound16640 : H12AffineFastState.Bounded env16640 := by
  intro p hp
  have h : env16640.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16639_16640 : H12AffineEnvironment.transform 5 48 env16639 = env16640 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env16639 == env16640) = true)

theorem identity16640 : scanCanonicalize (H12AffineFastState.compose env16640 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound16640 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16641 : List Nat := [2,4,8,16,32,48,9,256,512,1024,1296,1583,301,815,0,295,830,1045,1024,1,1566,33,16,2,300,49,1297,830,1582,1045,1316,32,256,33,783,512]

theorem envBound16641 : H12AffineFastState.Bounded env16641 := by
  intro p hp
  have h : env16641.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16640_16641 : H12AffineEnvironment.transform 10 1296 env16640 = env16641 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env16640 == env16641) = true)

def env16642 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452768,95496,8328,65,292136,458145,45525,10401,399801,144493,256,21793,46212,474734]

theorem envBound16642 : H12AffineFastState.Bounded env16642 := by
  intro p hp
  have h : env16642.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16617_16642 : H12AffineEnvironment.transform 21 272513 env16617 = env16642 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16617 == env16642) = true)

theorem identity16642 : scanCanonicalize (H12AffineFastState.compose env16642 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 138340) := by decide +kernel

theorem selectedBound16642 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16643 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,138340,1024,32769,4161,144613,62660,95496,8328,65,158028,57797,45525,10401,1501,144493,256,21793,46212,74250]

theorem envBound16643 : H12AffineFastState.Bounded env16643 := by
  intro p hp
  have h : env16643.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16642_16643 : H12AffineEnvironment.transform 17 138340 env16642 = env16643 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 138340 env16642 == env16643) = true)

theorem identity16643 : scanCanonicalize (H12AffineFastState.compose env16643 (packedSelected [4,7,9,14,16,20,27,35] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16643 : packedSelected [4,7,9,14,16,20,27,35] rootPS < 2^1333 := by decide +kernel

def env16644 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,138340,1024,32769,4161,144613,62660,21763,8328,65,158028,57797,45525,10401,1501,144493,256,21793,46212,513]

theorem envBound16644 : H12AffineFastState.Bounded env16644 := by
  intro p hp
  have h : env16644.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16643_16644 : H12AffineEnvironment.transform 15 8203 env16643 = env16644 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16643 == env16644) = true)

theorem identity16644 : scanCanonicalize (H12AffineFastState.compose env16644 (packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound16644 : packedSelected [7,11,12,14,15,16,18,23,27,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16645 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,131072,138340,1024,32769,4161,136632,54681,21763,469,65,149521,49304,37000,2556,1501,136496,256,21793,38361,513]

theorem envBound16645 : H12AffineFastState.Bounded env16645 := by
  intro p hp
  have h : env16645.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16644_16645 : H12AffineEnvironment.transform 12 349 env16644 = env16645 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env16644 == env16645) = true)

theorem identity16645 : scanCanonicalize (H12AffineFastState.compose env16645 (packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS)) = affineNative (2^(16+1) ^^^ 5528) := by decide +kernel

theorem selectedBound16645 : packedSelected [0,1,3,4,5,8,10,14,19,20,22,27] rootPS < 2^1333 := by decide +kernel

def env16646 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,32768,342,5528,2556,1024,32769,4161,32,54681,21763,469,65,23945,49304,37000,2556,1501,168,256,21793,38361,513]

theorem envBound16646 : H12AffineFastState.Bounded env16646 := by
  intro p hp
  have h : env16646.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16645_16646 : H12AffineEnvironment.transform 16 5528 env16645 = env16646 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5528 env16645 == env16646) = true)

theorem identity16646 : scanCanonicalize (H12AffineFastState.compose env16646 (packedSelected [0,3,5,7,10,16] rootPS)) = affineNative (2^(14+1) ^^^ 21896) := by decide +kernel

theorem selectedBound16646 : packedSelected [0,3,5,7,10,16] rootPS < 2^1333 := by decide +kernel

def env16647 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,16384,21896,342,5528,2556,1024,21897,4161,32,17,21763,469,65,23945,5392,17664,2556,1501,168,256,21793,16465,513]

theorem envBound16647 : H12AffineFastState.Bounded env16647 := by
  intro p hp
  have h : env16647.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16646_16647 : H12AffineEnvironment.transform 14 21896 env16646 = env16647 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21896 env16646 == env16647) = true)

theorem identity16647 : scanCanonicalize (H12AffineFastState.compose env16647 (packedSelected [2,6] rootPS)) = affineNative (2^(13+1) ^^^ 5457) := by decide +kernel

theorem selectedBound16647 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16648 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5457,217,342,5528,2556,1024,216,4161,32,17,82,469,65,2264,5392,4177,2556,1501,168,256,112,5376,513]

theorem envBound16648 : H12AffineFastState.Bounded env16648 := by
  intro p hp
  have h : env16648.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16647_16648 : H12AffineEnvironment.transform 13 5457 env16647 = env16648 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5457 env16647 == env16648) = true)

theorem identity16648 : scanCanonicalize (H12AffineFastState.compose env16648 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound16648 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env16649 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,349,5457,0,342,5441,2341,1024,1,4161,32,17,82,268,65,2049,5392,4177,2341,1284,113,256,112,5376,513]

theorem envBound16649 : H12AffineFastState.Bounded env16649 := by
  intro p hp
  have h : env16649.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16648_16649 : H12AffineEnvironment.transform 6 89 env16648 = env16649 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env16648 == env16649) = true)

theorem identity16649 : scanCanonicalize (H12AffineFastState.compose env16649 (packedSelected [1,2,3] rootPS)) = affineNative (2^(11+1) ^^^ 1856) := by decide +kernel

theorem selectedBound16649 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env16650 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,1856,349,529,0,342,513,2341,1024,1,1793,32,17,82,268,65,2049,592,1809,2341,1284,113,256,112,576,513]

theorem envBound16650 : H12AffineFastState.Bounded env16650 := by
  intro p hp
  have h : env16650.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16649_16650 : H12AffineEnvironment.transform 11 1856 env16649 = env16650 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1856 env16649 == env16650) = true)

theorem identity16650 : scanCanonicalize (H12AffineFastState.compose env16650 (packedSelected [0,7] rootPS)) = affineNative (2^(10+1) ^^^ 1856) := by decide +kernel

theorem selectedBound16650 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16651 : List Nat := [2,4,8,16,32,64,89,256,512,1024,1856,1856,349,529,0,342,513,1637,1024,1,1793,32,17,82,268,65,1857,592,1809,1637,1284,113,256,112,576,513]

theorem envBound16651 : H12AffineFastState.Bounded env16651 := by
  intro p hp
  have h : env16651.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16650_16651 : H12AffineEnvironment.transform 10 1856 env16650 = env16651 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1856 env16650 == env16651) = true)

theorem identity16651 : scanCanonicalize (H12AffineFastState.compose env16651 (packedSelected [4,5,8,9] rootPS)) = affineNative (2^(9+1) ^^^ 116) := by decide +kernel

theorem selectedBound16651 : packedSelected [4,5,8,9] rootPS < 2^1333 := by decide +kernel

def env16652 : List Nat := [2,4,8,16,32,64,89,256,512,116,820,820,349,529,0,342,513,529,116,1,885,32,17,82,268,65,821,592,869,529,368,113,256,112,576,513]

theorem envBound16652 : H12AffineFastState.Bounded env16652 := by
  intro p hp
  have h : env16652.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16651_16652 : H12AffineEnvironment.transform 9 116 env16651 = env16652 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 116 env16651 == env16652) = true)

theorem identity16652 : scanCanonicalize (H12AffineFastState.compose env16652 (packedSelected [0,1,2,4,8] rootPS)) = affineNative (2^(7+1) ^^^ 100) := by decide +kernel

theorem selectedBound16652 : packedSelected [0,1,2,4,8] rootPS < 2^1333 := by decide +kernel

def env16653 : List Nat := [2,4,8,16,32,64,89,100,512,116,592,592,57,529,0,50,513,529,116,1,529,32,17,82,104,65,593,592,513,529,20,113,100,112,576,513]

theorem envBound16653 : H12AffineFastState.Bounded env16653 := by
  intro p hp
  have h : env16653.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16652_16653 : H12AffineEnvironment.transform 7 100 env16652 = env16653 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 100 env16652 == env16653) = true)

def env16654 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,452769,95497,8328,65,4218281,458144,45524,10400,399801,4594925,256,21793,46212,474734]

theorem envBound16654 : H12AffineFastState.Bounded env16654 := by
  intro p hp
  have h : env16654.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16616_16654 : H12AffineEnvironment.transform 22 452769 env16616 = env16654 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env16616 == env16654) = true)

def env16655 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272512,452769,95497,8328,65,292137,458144,45524,10400,399801,144493,256,21793,46212,474734]

theorem envBound16655 : H12AffineFastState.Bounded env16655 := by
  intro p hp
  have h : env16655.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16654_16655 : H12AffineEnvironment.transform 21 272512 env16654 = env16655 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16654 == env16655) = true)

def env16656 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272392,452649,95497,8192,65,292137,458024,45404,10280,399665,144493,256,21793,46092,474734]

theorem envBound16656 : H12AffineFastState.Bounded env16656 := by
  intro p hp
  have h : env16656.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16655_16656 : H12AffineEnvironment.transform 6 8 env16655 = env16656 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16655 == env16656) = true)

def env16657 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272392,272441,95497,8192,65,292137,277816,45404,10280,317729,62589,256,21793,46092,392830]

theorem envBound16657 : H12AffineFastState.Bounded env16657 := by
  intro p hp
  have h : env16657.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16656_16657 : H12AffineEnvironment.transform 16 49168 env16656 = env16657 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env16656 == env16657) = true)

theorem identity16657 : scanCanonicalize (H12AffineFastState.compose env16657 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 89379) := by decide +kernel

theorem selectedBound16657 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16658 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49168,89379,1024,32769,102678,95531,95514,95497,8192,65,75786,90139,45404,10280,99330,62589,256,21793,46092,41821]

theorem envBound16658 : H12AffineFastState.Bounded env16658 := by
  intro p hp
  have h : env16658.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16657_16658 : H12AffineEnvironment.transform 17 89379 env16657 = env16658 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 89379 env16657 == env16658) = true)

theorem identity16658 : scanCanonicalize (H12AffineFastState.compose env16658 (packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 30073) := by decide +kernel

theorem selectedBound16658 : packedSelected [1,5,7,10,12,14,15,16,18,19,23,24,26,27,28] rootPS < 2^1333 := by decide +kernel

def env16659 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,30073,65536,13673,89379,1024,30072,91247,95531,95514,95497,8192,65,75786,90139,17445,10280,94587,260,256,21793,16757,22052]

theorem envBound16659 : H12AffineFastState.Bounded env16659 := by
  intro p hp
  have h : env16659.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16658_16659 : H12AffineEnvironment.transform 14 30073 env16658 = env16659 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 30073 env16658 == env16659) = true)

theorem identity16659 : scanCanonicalize (H12AffineFastState.compose env16659 (packedSelected [0,1,2,5,6,7,8,11,16,23,24] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16659 : packedSelected [0,1,2,5,6,7,8,11,16,23,24] rootPS < 2^1333 := by decide +kernel

def env16660 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,8192,16384,29993,65536,13625,89379,1024,29992,91199,95531,95514,95497,8192,17,75786,90139,17445,10280,94507,260,256,21793,16677,22052]

theorem envBound16660 : H12AffineFastState.Bounded env16660 := by
  intro p hp
  have h : env16660.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16659_16660 : H12AffineEnvironment.transform 5 16 env16659 = env16660 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16659 == env16660) = true)

theorem identity16660 : scanCanonicalize (H12AffineFastState.compose env16660 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 41) := by decide +kernel

theorem selectedBound16660 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env16661 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,16384,21760,65536,5392,89379,1024,21761,82966,87298,87347,87328,41,17,67619,81970,17445,2049,86274,260,256,21793,16677,22052]

theorem envBound16661 : H12AffineFastState.Bounded env16661 := by
  intro p hp
  have h : env16661.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16660_16661 : H12AffineEnvironment.transform 12 41 env16660 = env16661 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 41 env16660 == env16661) = true)

theorem identity16661 : scanCanonicalize (H12AffineFastState.compose env16661 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound16661 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16662 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,4096,41,16384,21760,263,5392,23588,1024,21761,17681,21509,21556,21543,41,17,2340,16693,17445,2049,20485,260,256,21793,16677,22052]

theorem envBound16662 : H12AffineFastState.Bounded env16662 := by
  intro p hp
  have h : env16662.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16661_16662 : H12AffineEnvironment.transform 15 263 env16661 = env16662 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env16661 == env16662) = true)

theorem identity16662 : scanCanonicalize (H12AffineFastState.compose env16662 (packedSelected [1,2,4,6,8,9,10,11,12] rootPS)) = affineNative (2^(11+1) ^^^ 3109) := by decide +kernel

theorem selectedBound16662 : packedSelected [1,2,4,6,8,9,10,11,12] rootPS < 2^1333 := by decide +kernel

def env16663 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,41,16384,18725,263,2357,16385,1024,18724,17681,18464,18449,18434,41,17,2340,16693,17445,2049,19488,260,256,18692,16677,18945]

theorem envBound16663 : H12AffineFastState.Bounded env16663 := by
  intro p hp
  have h : env16663.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16662_16663 : H12AffineEnvironment.transform 11 3109 env16662 = env16663 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3109 env16662 == env16663) = true)

theorem identity16663 : scanCanonicalize (H12AffineFastState.compose env16663 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(13+1) ^^^ 3125) := by decide +kernel

theorem selectedBound16663 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16664 : List Nat := [2,4,8,16,32,16,8,256,512,1024,2048,3109,41,3125,1296,263,2357,3124,1024,1297,2340,1045,1060,1079,41,17,2340,3328,2064,2049,21,260,256,1329,3344,1588]

theorem envBound16664 : H12AffineFastState.Bounded env16664 := by
  intro p hp
  have h : env16664.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16663_16664 : H12AffineEnvironment.transform 13 3125 env16663 = env16664 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 3125 env16663 == env16664) = true)

theorem identity16664 : scanCanonicalize (H12AffineFastState.compose env16664 (packedSelected [1,2,3,5,6,8,11] rootPS)) = affineNative (2^(10+1) ^^^ 1296) := by decide +kernel

theorem selectedBound16664 : packedSelected [1,2,3,5,6,8,11] rootPS < 2^1333 := by decide +kernel

def env16665 : List Nat := [2,4,8,16,32,16,8,256,512,1024,1296,309,41,293,1296,263,1061,292,1024,1297,1076,1045,1060,1079,41,17,1076,16,1280,1297,21,260,256,1329,0,1588]

theorem envBound16665 : H12AffineFastState.Bounded env16665 := by
  intro p hp
  have h : env16665.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16664_16665 : H12AffineEnvironment.transform 10 1296 env16664 = env16665 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1296 env16664 == env16665) = true)

theorem identity16665 : scanCanonicalize (H12AffineFastState.compose env16665 (packedSelected [1,3,5,8] rootPS)) = affineNative (2^(7+1) ^^^ 37) := by decide +kernel

theorem selectedBound16665 : packedSelected [1,3,5,8] rootPS < 2^1333 := by decide +kernel

def env16666 : List Nat := [2,4,8,16,32,16,8,37,512,1024,1077,16,41,0,1077,34,1061,1,1024,1076,1076,1045,1060,1079,41,17,1076,16,1061,1076,21,33,37,1044,0,1588]

theorem envBound16666 : H12AffineFastState.Bounded env16666 := by
  intro p hp
  have h : env16666.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16665_16666 : H12AffineEnvironment.transform 7 37 env16665 = env16666 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 37 env16665 == env16666) = true)

theorem identity16666 : scanCanonicalize (H12AffineFastState.compose env16666 (packedSelected [1,3,4] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16666 : packedSelected [1,3,4] rootPS < 2^1333 := by decide +kernel

def env16667 : List Nat := [2,4,8,0,32,0,8,37,512,1024,1061,0,41,0,1061,34,1061,1,1024,1060,1060,1029,1060,1063,41,1,1060,0,1061,1060,5,33,37,1028,0,1572]

theorem envBound16667 : H12AffineFastState.Bounded env16667 := by
  intro p hp
  have h : env16667.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16666_16667 : H12AffineEnvironment.transform 3 0 env16666 = env16667 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16666 == env16667) = true)

theorem identity16667 : scanCanonicalize (H12AffineFastState.compose env16667 (packedSelected [0,1,2,3] rootPS)) = affineNative (2^(8+1) ^^^ 32) := by decide +kernel

theorem selectedBound16667 : packedSelected [0,1,2,3] rootPS < 2^1333 := by decide +kernel

def env16668 : List Nat := [2,4,8,0,32,0,8,37,32,1024,1061,0,41,0,1061,34,1061,1,1024,1060,1060,1029,1060,1063,41,1,1060,0,1061,1060,5,33,37,1028,0,1028]

theorem envBound16668 : H12AffineFastState.Bounded env16668 := by
  intro p hp
  have h : env16668.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16667_16668 : H12AffineEnvironment.transform 8 32 env16667 = env16668 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 32 env16667 == env16668) = true)

theorem identity16668 : scanCanonicalize (H12AffineFastState.compose env16668 (packedSelected [0,2] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16668 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16669 : List Nat := [2,4,8,0,1,0,8,4,1,1024,1028,0,8,0,1028,3,1028,1,1024,1029,1029,1029,1029,1030,8,1,1029,0,1028,1029,5,0,4,1028,0,1028]

theorem envBound16669 : H12AffineFastState.Bounded env16669 := by
  intro p hp
  have h : env16669.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16668_16669 : H12AffineEnvironment.transform 4 1 env16668 = env16669 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16668 == env16669) = true)

theorem identity16669 : scanCanonicalize (H12AffineFastState.compose env16669 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 4) := by decide +kernel

theorem selectedBound16669 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16670 : List Nat := [2,4,8,0,1,0,8,4,1,4,0,0,8,0,0,3,0,1,4,1,1,1,1,2,8,1,1,0,0,1,5,0,4,0,0,0]

theorem envBound16670 : H12AffineFastState.Bounded env16670 := by
  intro p hp
  have h : env16670.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16669_16670 : H12AffineEnvironment.transform 9 4 env16669 = env16670 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 4 env16669 == env16670) = true)

theorem identity16670 : scanCanonicalize (H12AffineFastState.compose env16670 (packedSelected [1] rootPS)) = affineNative (2^(2+1) ^^^ 3) := by decide +kernel

theorem selectedBound16670 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16671 : List Nat := [2,4,3,0,1,0,3,4,1,4,0,0,3,0,0,3,0,1,4,1,1,1,1,2,3,1,1,0,0,1,5,0,4,0,0,0]

theorem envBound16671 : H12AffineFastState.Bounded env16671 := by
  intro p hp
  have h : env16671.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16670_16671 : H12AffineEnvironment.transform 2 3 env16670 = env16671 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 3 env16670 == env16671) = true)

def env16672 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272392,272440,95497,8192,65,292137,277817,45404,10280,317728,62588,256,21793,46092,392831]

theorem envBound16672 : H12AffineFastState.Bounded env16672 := by
  intro p hp
  have h : env16672.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16656_16672 : H12AffineEnvironment.transform 16 49169 env16656 = env16672 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env16656 == env16672) = true)

theorem identity16672 : scanCanonicalize (H12AffineFastState.compose env16672 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 29963) := by decide +kernel

theorem selectedBound16672 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16673 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49169,262144,1024,32769,314420,272392,272440,2,8192,65,292137,277817,45404,10280,317728,62588,256,21793,46092,297844]

theorem envBound16673 : H12AffineFastState.Bounded env16673 := by
  intro p hp
  have h : env16673.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16672_16673 : H12AffineEnvironment.transform 15 29963 env16672 = env16673 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 29963 env16672 == env16673) = true)

theorem identity16673 : scanCanonicalize (H12AffineFastState.compose env16673 (packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS)) = affineNative (2^(17+1) ^^^ 56577) := by decide +kernel

theorem selectedBound16673 : packedSelected [1,3,4,8,9,10,12,14,15,18,20,23,24] rootPS < 2^1333 := by decide +kernel

def env16674 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,29963,49169,56577,1024,32769,4405,62729,62777,2,8192,65,43048,57400,45404,10280,1057,62588,256,21793,46092,22133]

theorem envBound16674 : H12AffineFastState.Bounded env16674 := by
  intro p hp
  have h : env16674.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16673_16674 : H12AffineEnvironment.transform 17 56577 env16673 = env16674 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 56577 env16673 == env16674) = true)

theorem identity16674 : scanCanonicalize (H12AffineFastState.compose env16674 (packedSelected [2,6,7,9,11,16,18,22,27] rootPS)) = affineNative (2^(14+1) ^^^ 29992) := by decide +kernel

theorem selectedBound16674 : packedSelected [2,6,7,9,11,16,18,22,27] rootPS < 2^1333 := by decide +kernel

def env16675 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29992,29963,13625,10281,1024,29993,4405,33,17,2,8192,65,23808,5392,17524,10280,1057,340,256,21793,16676,22133]

theorem envBound16675 : H12AffineFastState.Bounded env16675 := by
  intro p hp
  have h : env16675.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16674_16675 : H12AffineEnvironment.transform 14 29992 env16674 = env16675 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29992 env16674 == env16675) = true)

theorem identity16675 : scanCanonicalize (H12AffineFastState.compose env16675 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(13+1) ^^^ 13608) := by decide +kernel

theorem selectedBound16675 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env16676 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13608,0,35,13625,10281,1024,1,4405,33,17,2,8192,65,10280,5392,12636,10280,1057,340,256,8201,13324,9053]

theorem envBound16676 : H12AffineFastState.Bounded env16676 := by
  intro p hp
  have h : env16676.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16675_16676 : H12AffineEnvironment.transform 13 13608 env16675 = env16676 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13608 env16675 == env16676) = true)

theorem identity16676 : scanCanonicalize (H12AffineFastState.compose env16676 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 1337) := by decide +kernel

theorem selectedBound16676 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16677 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,1337,4113,0,35,4096,3344,1024,1,4405,33,17,2,1337,65,3345,5392,5221,3345,1057,340,256,1328,4405,1636]

theorem envBound16677 : H12AffineFastState.Bounded env16677 := by
  intro p hp
  have h : env16677.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16676_16677 : H12AffineEnvironment.transform 12 1337 env16676 = env16677 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1337 env16676 == env16677) = true)

theorem identity16677 : scanCanonicalize (H12AffineFastState.compose env16677 (packedSelected [4,9,14,16] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound16677 : packedSelected [4,9,14,16] rootPS < 2^1333 := by decide +kernel

def env16678 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,41,4113,0,35,4096,2048,272,1,4405,33,17,2,41,65,2049,4096,4469,2049,305,340,256,32,4405,884]

theorem envBound16678 : H12AffineFastState.Bounded env16678 := by
  intro p hp
  have h : env16678.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16677_16678 : H12AffineEnvironment.transform 9 272 env16677 = env16678 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16677 == env16678) = true)

theorem identity16678 : scanCanonicalize (H12AffineFastState.compose env16678 (packedSelected [0,6,7] rootPS)) = affineNative (2^(7+1) ^^^ 117) := by decide +kernel

theorem selectedBound16678 : packedSelected [0,6,7] rootPS < 2^1333 := by decide +kernel

def env16679 : List Nat := [2,4,8,16,32,64,8,117,512,101,2048,4096,41,4113,0,35,4096,2048,101,1,4160,33,17,2,41,65,2049,4096,4096,2049,68,33,117,32,4160,513]

theorem envBound16679 : H12AffineFastState.Bounded env16679 := by
  intro p hp
  have h : env16679.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16678_16679 : H12AffineEnvironment.transform 7 117 env16678 = env16679 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 117 env16678 == env16679) = true)

theorem identity16679 : scanCanonicalize (H12AffineFastState.compose env16679 (packedSelected [2] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16679 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16680 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,4096,41,4113,0,35,4096,2048,53,1,4112,33,17,2,41,17,2049,4096,4096,2049,20,33,37,32,4112,513]

theorem envBound16680 : H12AffineFastState.Bounded env16680 := by
  intro p hp
  have h : env16680.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16679_16680 : H12AffineEnvironment.transform 5 16 env16679 = env16680 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16679 == env16680) = true)

theorem identity16680 : scanCanonicalize (H12AffineFastState.compose env16680 (packedSelected [0] rootPS)) = affineNative (2^(11+1) ^^^ 512) := by decide +kernel

theorem selectedBound16680 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16681 : List Nat := [2,4,8,16,32,16,8,37,512,53,2048,512,41,529,0,35,512,2048,53,1,528,33,17,2,41,17,2049,512,512,2049,20,33,37,32,528,513]

theorem envBound16681 : H12AffineFastState.Bounded env16681 := by
  intro p hp
  have h : env16681.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16680_16681 : H12AffineEnvironment.transform 11 512 env16680 = env16681 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 512 env16680 == env16681) = true)

theorem identity16681 : scanCanonicalize (H12AffineFastState.compose env16681 (packedSelected [1] rootPS)) = affineNative (2^(10+1) ^^^ 10) := by decide +kernel

theorem selectedBound16681 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16682 : List Nat := [2,4,8,16,32,16,8,37,512,53,10,512,41,529,0,35,512,10,53,1,528,33,17,2,41,17,11,512,512,11,20,33,37,32,528,513]

theorem envBound16682 : H12AffineFastState.Bounded env16682 := by
  intro p hp
  have h : env16682.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16681_16682 : H12AffineEnvironment.transform 10 10 env16681 = env16682 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 10 env16681 == env16682) = true)

theorem identity16682 : scanCanonicalize (H12AffineFastState.compose env16682 (packedSelected [4] rootPS)) = affineNative (2^(8+1) ^^^ 26) := by decide +kernel

theorem selectedBound16682 : packedSelected [4] rootPS < 2^1333 := by decide +kernel

def env16683 : List Nat := [2,4,8,16,32,16,8,37,26,53,10,26,41,11,0,35,26,10,53,1,10,33,17,2,41,17,11,26,26,11,20,33,37,32,10,27]

theorem envBound16683 : H12AffineFastState.Bounded env16683 := by
  intro p hp
  have h : env16683.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16682_16683 : H12AffineEnvironment.transform 8 26 env16682 = env16683 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 26 env16682 == env16683) = true)

def env16684 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272393,452648,95497,8193,65,292137,458025,45405,10281,399664,144493,256,21793,46093,474734]

theorem envBound16684 : H12AffineFastState.Bounded env16684 := by
  intro p hp
  have h : env16684.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16655_16684 : H12AffineEnvironment.transform 6 9 env16655 = env16684 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16655 == env16684) = true)

def env16685 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,262144,1024,32769,314421,272393,272440,95497,8193,65,292137,277817,45405,10281,317728,62589,256,21793,46093,392830]

theorem envBound16685 : H12AffineFastState.Bounded env16685 := by
  intro p hp
  have h : env16685.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16684_16685 : H12AffineEnvironment.transform 16 49168 env16684 = env16685 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env16684 == env16685) = true)

theorem identity16685 : scanCanonicalize (H12AffineFastState.compose env16685 (packedSelected [17] rootPS)) = affineNative (2^(17+1) ^^^ 130175) := by decide +kernel

theorem selectedBound16685 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16686 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49168,130175,1024,32769,77898,119926,119879,95497,8193,65,100694,115014,45405,10281,75103,62589,256,21793,46093,513]

theorem envBound16686 : H12AffineFastState.Bounded env16686 := by
  intro p hp
  have h : env16686.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16685_16686 : H12AffineEnvironment.transform 17 130175 env16685 = env16686 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 130175 env16685 == env16686) = true)

theorem identity16686 : scanCanonicalize (H12AffineFastState.compose env16686 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54359) := by decide +kernel

theorem selectedBound16686 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env16687 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54359,49168,10280,1024,32769,58397,33,16,41310,8193,65,23809,5393,45405,10281,61704,62589,256,21793,46093,513]

theorem envBound16687 : H12AffineFastState.Bounded env16687 := by
  intro p hp
  have h : env16687.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16686_16687 : H12AffineEnvironment.transform 15 54359 env16686 = env16687 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54359 env16686 == env16687) = true)

theorem identity16687 : scanCanonicalize (H12AffineFastState.compose env16687 (packedSelected [3,4,5,9,10,11,12,15] rootPS)) = affineNative (2^(14+1) ^^^ 21840) := by decide +kernel

theorem selectedBound16687 : packedSelected [3,4,5,9,10,11,12,15] rootPS < 2^1333 := by decide +kernel

def env16688 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21840,263,5440,10280,1024,21841,12621,33,16,29710,8193,65,23809,5393,25613,10281,9304,8493,256,21793,24925,513]

theorem envBound16688 : H12AffineFastState.Bounded env16688 := by
  intro p hp
  have h : env16688.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16687_16688 : H12AffineEnvironment.transform 14 21840 env16687 = env16688 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21840 env16687 == env16688) = true)

theorem identity16688 : scanCanonicalize (H12AffineFastState.compose env16688 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound16688 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env16689 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13404,8460,263,5440,10280,1024,8461,12621,33,16,82,8193,65,10589,5393,4177,10281,9304,8493,256,8573,5377,513]

theorem envBound16689 : H12AffineFastState.Bounded env16689 := by
  intro p hp
  have h : env16689.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16688_16689 : H12AffineEnvironment.transform 13 13404 env16688 = env16689 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env16688 == env16689) = true)

theorem identity16689 : scanCanonicalize (H12AffineFastState.compose env16689 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16689 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16690 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5376,80,263,5440,2420,1024,81,4113,33,16,82,349,65,2049,5393,4177,2421,1284,113,256,33,5377,513]

theorem envBound16690 : H12AffineFastState.Bounded env16690 := by
  intro p hp
  have h : env16690.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16689_16690 : H12AffineEnvironment.transform 12 348 env16689 = env16690 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16689 == env16690) = true)

theorem identity16690 : scanCanonicalize (H12AffineFastState.compose env16690 (packedSelected [0,1,7,8] rootPS)) = affineNative (2^(10+1) ^^^ 1281) := by decide +kernel

theorem selectedBound16690 : packedSelected [0,1,7,8] rootPS < 2^1333 := by decide +kernel

def env16691 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1281,4096,348,5376,80,263,5440,1141,1024,81,4113,33,16,82,349,65,1280,5393,4177,1140,1284,113,256,33,5377,513]

theorem envBound16691 : H12AffineFastState.Bounded env16691 := by
  intro p hp
  have h : env16691.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16690_16691 : H12AffineEnvironment.transform 10 1281 env16690 = env16691 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1281 env16690 == env16691) = true)

theorem identity16691 : scanCanonicalize (H12AffineFastState.compose env16691 (packedSelected [3,4,5,9] rootPS)) = affineNative (2^(11+1) ^^^ 81) := by decide +kernel

theorem selectedBound16691 : packedSelected [3,4,5,9] rootPS < 2^1333 := by decide +kernel

def env16692 : List Nat := [2,4,8,16,32,64,9,256,512,1024,1281,81,348,1361,80,263,1297,1141,1024,81,64,33,16,82,349,65,1280,1344,0,1140,1284,113,256,33,1360,513]

theorem envBound16692 : H12AffineFastState.Bounded env16692 := by
  intro p hp
  have h : env16692.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16691_16692 : H12AffineEnvironment.transform 11 81 env16691 = env16692 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 81 env16691 == env16692) = true)

theorem identity16692 : scanCanonicalize (H12AffineFastState.compose env16692 (packedSelected [0,3,5,7,12] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16692 : packedSelected [0,3,5,7,12] rootPS < 2^1333 := by decide +kernel

def env16693 : List Nat := [2,4,8,16,32,17,9,256,512,1024,1281,0,269,1280,1,263,1297,1060,1024,0,17,33,16,3,268,16,1280,1297,0,1061,1284,32,256,33,1281,513]

theorem envBound16693 : H12AffineFastState.Bounded env16693 := by
  intro p hp
  have h : env16693.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16692_16693 : H12AffineEnvironment.transform 5 17 env16692 = env16693 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16692 == env16693) = true)

theorem identity16693 : scanCanonicalize (H12AffineFastState.compose env16693 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 53) := by decide +kernel

theorem selectedBound16693 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16694 : List Nat := [2,4,8,16,32,17,9,256,512,53,308,0,269,309,1,263,292,17,53,0,17,33,16,3,268,16,309,292,0,16,305,32,256,33,308,513]

theorem envBound16694 : H12AffineFastState.Bounded env16694 := by
  intro p hp
  have h : env16694.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16693_16694 : H12AffineEnvironment.transform 9 53 env16693 = env16694 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 53 env16693 == env16694) = true)

theorem identity16694 : scanCanonicalize (H12AffineFastState.compose env16694 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16694 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16695 : List Nat := [2,4,8,16,32,17,9,256,1,53,308,0,269,309,1,263,292,17,53,0,17,33,16,3,268,16,309,292,0,16,305,32,256,33,308,0]

theorem envBound16695 : H12AffineFastState.Bounded env16695 := by
  intro p hp
  have h : env16695.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16694_16695 : H12AffineEnvironment.transform 8 1 env16694 = env16695 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16694 == env16695) = true)

theorem identity16695 : scanCanonicalize (H12AffineFastState.compose env16695 (packedSelected [1,5] rootPS)) = affineNative (2^(7+1) ^^^ 36) := by decide +kernel

theorem selectedBound16695 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16696 : List Nat := [2,4,8,16,32,17,9,36,1,53,16,0,41,17,1,35,0,17,53,0,17,33,16,3,40,16,17,0,0,16,21,32,36,33,16,0]

theorem envBound16696 : H12AffineFastState.Bounded env16696 := by
  intro p hp
  have h : env16696.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16695_16696 : H12AffineEnvironment.transform 7 36 env16695 = env16696 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 36 env16695 == env16696) = true)

theorem identity16696 : scanCanonicalize (H12AffineFastState.compose env16696 (packedSelected [0] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16696 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16697 : List Nat := [2,4,8,16,0,17,9,4,1,21,16,0,9,17,1,3,0,17,21,0,17,1,16,3,8,16,17,0,0,16,21,0,4,1,16,0]

theorem envBound16697 : H12AffineFastState.Bounded env16697 := by
  intro p hp
  have h : env16697.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16696_16697 : H12AffineEnvironment.transform 4 0 env16696 = env16697 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16696 == env16697) = true)

theorem identity16697 : scanCanonicalize (H12AffineFastState.compose env16697 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16697 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16698 : List Nat := [2,4,8,1,0,0,9,4,1,4,1,0,9,0,1,3,0,0,4,0,0,1,1,3,8,1,0,0,0,1,4,0,4,1,1,0]

theorem envBound16698 : H12AffineFastState.Bounded env16698 := by
  intro p hp
  have h : env16698.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16697_16698 : H12AffineEnvironment.transform 3 1 env16697 = env16698 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16697 == env16698) = true)

def env16699 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,49169,262144,1024,32769,314420,272393,272441,95497,8193,65,292137,277816,45405,10281,317729,62588,256,21793,46093,392831]

theorem envBound16699 : H12AffineFastState.Bounded env16699 := by
  intro p hp
  have h : env16699.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16684_16699 : H12AffineEnvironment.transform 16 49169 env16684 = env16699 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env16684 == env16699) = true)

theorem identity16699 : scanCanonicalize (H12AffineFastState.compose env16699 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 54358) := by decide +kernel

theorem selectedBound16699 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16700 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49169,262144,1024,32769,314420,272393,272441,41311,8193,65,292137,277816,45405,10281,317729,62588,256,21793,46093,272937]

theorem envBound16700 : H12AffineFastState.Bounded env16700 := by
  intro p hp
  have h : env16700.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16699_16700 : H12AffineEnvironment.transform 15 54358 env16699 = env16700 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54358 env16699 == env16700) = true)

theorem identity16700 : scanCanonicalize (H12AffineFastState.compose env16700 (packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS)) = affineNative (2^(13+1) ^^^ 13325) := by decide +kernel

theorem selectedBound16700 : packedSelected [1,4,5,8,10,14,15,16,20,22,23,24,26] rootPS < 2^1333 := by decide +kernel

def env16701 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,41051,46108,262144,1024,32769,309305,272393,272441,41311,8193,65,262436,277816,45405,10281,306476,32881,256,8492,46093,272937]

theorem envBound16701 : H12AffineFastState.Bounded env16701 := by
  intro p hp
  have h : env16701.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16700_16701 : H12AffineEnvironment.transform 13 13325 env16700 = env16701 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13325 env16700 == env16701) = true)

theorem identity16701 : scanCanonicalize (H12AffineFastState.compose env16701 (packedSelected [0,1,3,5,7,8,14,15,18] rootPS)) = affineNative (2^(17+1) ^^^ 43049) := by decide +kernel

theorem selectedBound16701 : packedSelected [0,1,3,5,7,8,14,15,18] rootPS < 2^1333 := by decide +kernel

def env16702 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,41051,46108,43049,1024,32769,4112,32800,32784,41311,8193,65,43277,38161,45405,10281,1285,32881,256,8492,46093,33280]

theorem envBound16702 : H12AffineFastState.Bounded env16702 := by
  intro p hp
  have h : env16702.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16701_16702 : H12AffineEnvironment.transform 17 43049 env16701 = env16702 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 43049 env16701 == env16702) = true)

theorem identity16702 : scanCanonicalize (H12AffineFastState.compose env16702 (packedSelected [3,4,5,9,10,12,14,15,16] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16702 : packedSelected [3,4,5,9,10,12,14,15,16] rootPS < 2^1333 := by decide +kernel

def env16703 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,32768,40970,46108,43049,1024,32769,4112,32800,32784,41230,8193,16,43277,38161,45324,10281,1285,32800,256,8492,46093,33280]

theorem envBound16703 : H12AffineFastState.Bounded env16703 := by
  intro p hp
  have h : env16703.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16702_16703 : H12AffineEnvironment.transform 5 17 env16702 = env16703 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16702 == env16703) = true)

theorem identity16703 : scanCanonicalize (H12AffineFastState.compose env16703 (packedSelected [0,2,4,6,7,9,12,14,15] rootPS)) = affineNative (2^(14+1) ^^^ 8461) := by decide +kernel

theorem selectedBound16703 : packedSelected [0,2,4,6,7,9,12,14,15] rootPS < 2^1333 := by decide +kernel

def env16704 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,8192,13325,8461,263,5393,2340,1024,8460,4112,8493,8477,3,8193,16,2048,13340,4097,10281,1285,8493,256,8492,5376,8973]

theorem envBound16704 : H12AffineFastState.Bounded env16704 := by
  intro p hp
  have h : env16704.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16703_16704 : H12AffineEnvironment.transform 14 8461 env16703 = env16704 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8461 env16703 == env16704) = true)

theorem identity16704 : scanCanonicalize (H12AffineFastState.compose env16704 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(9+1) ^^^ 52) := by decide +kernel

theorem selectedBound16704 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16705 : List Nat := [2,4,8,16,32,17,9,256,512,52,2048,4096,8192,12345,8461,263,4389,2340,52,8460,4112,8493,8477,3,8193,16,2048,12328,4097,10281,305,8493,256,8492,4404,8973]

theorem envBound16705 : H12AffineFastState.Bounded env16705 := by
  intro p hp
  have h : env16705.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16704_16705 : H12AffineEnvironment.transform 9 52 env16704 = env16705 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 52 env16704 == env16705) = true)

theorem identity16705 : scanCanonicalize (H12AffineFastState.compose env16705 (packedSelected [0,1,2,3,5,7,8] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16705 : packedSelected [0,1,2,3,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16706 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,8192,12313,8461,263,4357,2308,20,8460,4112,8461,8477,3,8193,16,2048,12296,4097,10249,273,8461,256,8460,4372,8973]

theorem envBound16706 : H12AffineFastState.Bounded env16706 := by
  intro p hp
  have h : env16706.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16705_16706 : H12AffineEnvironment.transform 4 0 env16705 = env16706 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16705 == env16706) = true)

theorem identity16706 : scanCanonicalize (H12AffineFastState.compose env16706 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16706 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16707 : List Nat := [2,4,8,16,0,17,9,256,512,20,2048,4096,269,4372,0,263,4357,2308,20,1,4112,0,16,3,268,16,2048,4357,4097,2308,273,0,256,1,4372,512]

theorem envBound16707 : H12AffineFastState.Bounded env16707 := by
  intro p hp
  have h : env16707.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16706_16707 : H12AffineEnvironment.transform 12 269 env16706 = env16707 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16706 == env16707) = true)

theorem identity16707 : scanCanonicalize (H12AffineFastState.compose env16707 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 783) := by decide +kernel

theorem selectedBound16707 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16708 : List Nat := [2,4,8,16,0,17,9,256,512,20,783,4096,269,4372,0,263,4357,523,20,1,4112,0,16,3,268,16,783,4357,4097,523,273,0,256,1,4372,512]

theorem envBound16708 : H12AffineFastState.Bounded env16708 := by
  intro p hp
  have h : env16708.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16707_16708 : H12AffineEnvironment.transform 10 783 env16707 = env16708 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 783 env16707 == env16708) = true)

theorem identity16708 : scanCanonicalize (H12AffineFastState.compose env16708 (packedSelected [0,4] rootPS)) = affineNative (2^(11+1) ^^^ 539) := by decide +kernel

theorem selectedBound16708 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16709 : List Nat := [2,4,8,16,0,17,9,256,512,20,783,539,269,783,0,263,798,523,20,1,523,0,16,3,268,16,783,798,538,523,273,0,256,1,783,512]

theorem envBound16709 : H12AffineFastState.Bounded env16709 := by
  intro p hp
  have h : env16709.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16708_16709 : H12AffineEnvironment.transform 11 539 env16708 = env16709 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 539 env16708 == env16709) = true)

def env16710 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452769,95497,8328,65,292136,458144,45524,10400,399801,144492,256,21793,46212,474734]

theorem envBound16710 : H12AffineFastState.Bounded env16710 := by
  intro p hp
  have h : env16710.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16654_16710 : H12AffineEnvironment.transform 21 272513 env16654 = env16710 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16654 == env16710) = true)

theorem identity16710 : scanCanonicalize (H12AffineFastState.compose env16710 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 190641) := by decide +kernel

theorem selectedBound16710 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16711 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190641,1024,32769,58516,180272,16,95497,8328,65,171417,5393,45524,10400,61704,144492,256,21793,46212,120543]

theorem envBound16711 : H12AffineFastState.Bounded env16711 := by
  intro p hp
  have h : env16711.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16710_16711 : H12AffineEnvironment.transform 17 190641 env16710 = env16711 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 190641 env16710 == env16711) = true)

def env16712 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190521,1024,32769,58396,180272,16,95497,8192,65,171281,5393,45404,10280,61704,144492,256,21793,46092,120407]

theorem envBound16712 : H12AffineFastState.Bounded env16712 := by
  intro p hp
  have h : env16712.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16711_16712 : H12AffineEnvironment.transform 6 8 env16711 = env16712 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16711 == env16712) = true)

theorem identity16712 : scanCanonicalize (H12AffineFastState.compose env16712 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 111898) := by decide +kernel

theorem selectedBound16712 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16713 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,111898,89379,1024,32769,58396,95530,16,95497,8192,65,75787,5393,45404,10280,61704,98678,256,21793,46092,120407]

theorem envBound16713 : H12AffineFastState.Bounded env16713 := by
  intro p hp
  have h : env16713.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16712_16713 : H12AffineEnvironment.transform 16 111898 env16712 = env16713 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 111898 env16712 == env16713) = true)

theorem identity16713 : scanCanonicalize (H12AffineFastState.compose env16713 (packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS)) = affineNative (2^(15+1) ^^^ 41342) := by decide +kernel

theorem selectedBound16713 : packedSelected [0,1,3,4,8,10,12,14,15,16,19,22,24,26,27] rootPS < 2^1333 := by decide +kernel

def env16714 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,41342,5220,64605,1024,32769,58396,54356,16,54391,8192,65,35189,5393,45404,10280,61704,8200,256,21793,46092,30505]

theorem envBound16714 : H12AffineFastState.Bounded env16714 := by
  intro p hp
  have h : env16714.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16713_16714 : H12AffineEnvironment.transform 15 41342 env16713 = env16714 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 41342 env16713 == env16714) = true)

theorem identity16714 : scanCanonicalize (H12AffineFastState.compose env16714 (packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound16714 : packedSelected [0,1,2,3,4,6,7,8,9,10,11,12,14,15,18,19,24,26] rootPS < 2^1333 := by decide +kernel

def env16715 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,21795,5220,2048,1024,29788,4161,8201,16,8234,8192,65,32040,5393,17665,10280,1365,8200,256,21793,16465,30505]

theorem envBound16715 : H12AffineFastState.Bounded env16715 := by
  intro p hp
  have h : env16715.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16714_16715 : H12AffineEnvironment.transform 14 29789 env16714 = env16715 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env16714 == env16715) = true)

theorem identity16715 : scanCanonicalize (H12AffineFastState.compose env16715 (packedSelected [3,5,6,10,11,12,14,15,18] rootPS)) = affineNative (2^(13+1) ^^^ 5237) := by decide +kernel

theorem selectedBound16715 : packedSelected [3,5,6,10,11,12,14,15,18] rootPS < 2^1333 := by decide +kernel

def env16716 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5237,8232,342,5220,2048,1024,8233,4161,8201,16,8234,8192,65,10589,5393,4468,10280,1365,8200,256,340,5156,9052]

theorem envBound16716 : H12AffineFastState.Bounded env16716 := by
  intro p hp
  have h : env16716.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16715_16716 : H12AffineEnvironment.transform 13 5237 env16715 = env16716 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5237 env16715 == env16716) = true)

theorem identity16716 : scanCanonicalize (H12AffineFastState.compose env16716 (packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16716 : packedSelected [0,1,2,3,4,5,7,8,9,10,19] rootPS < 2^1333 := by decide +kernel

def env16717 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,348,5237,372,342,5220,2048,1024,373,4161,341,16,374,348,65,2049,5393,4468,2420,1365,340,256,340,5156,512]

theorem envBound16717 : H12AffineFastState.Bounded env16717 := by
  intro p hp
  have h : env16717.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16716_16717 : H12AffineEnvironment.transform 12 348 env16716 = env16717 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16716 == env16717) = true)

theorem identity16717 : scanCanonicalize (H12AffineFastState.compose env16717 (packedSelected [2,6] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16717 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16718 : List Nat := [2,4,8,16,32,64,8,4,512,1024,2048,4096,88,5237,112,82,5220,2048,1024,113,4161,81,16,114,88,65,2049,5141,4208,2160,1105,80,4,80,5156,512]

theorem envBound16718 : H12AffineFastState.Bounded env16718 := by
  intro p hp
  have h : env16718.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16717_16718 : H12AffineEnvironment.transform 7 4 env16717 = env16718 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16717 == env16718) = true)

theorem identity16718 : scanCanonicalize (H12AffineFastState.compose env16718 (packedSelected [2,5,8,11] rootPS)) = affineNative (2^(8+1) ^^^ 122) := by decide +kernel

theorem selectedBound16718 : packedSelected [2,5,8,11] rootPS < 2^1333 := by decide +kernel

def env16719 : List Nat := [2,4,8,16,32,64,8,4,122,1024,2048,4096,88,5237,112,82,5220,2048,1024,113,4161,81,16,114,88,65,2049,5141,4208,2160,1105,80,4,80,5156,122]

theorem envBound16719 : H12AffineFastState.Bounded env16719 := by
  intro p hp
  have h : env16719.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16718_16719 : H12AffineEnvironment.transform 8 122 env16718 = env16719 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 122 env16718 == env16719) = true)

theorem identity16719 : scanCanonicalize (H12AffineFastState.compose env16719 (packedSelected [12] rootPS)) = affineNative (2^(11+1) ^^^ 1028) := by decide +kernel

theorem selectedBound16719 : packedSelected [12] rootPS < 2^1333 := by decide +kernel

def env16720 : List Nat := [2,4,8,16,32,64,8,4,122,1024,2048,1028,88,113,112,82,96,2048,1024,113,1093,81,16,114,88,65,2049,17,1140,2160,1105,80,4,80,32,122]

theorem envBound16720 : H12AffineFastState.Bounded env16720 := by
  intro p hp
  have h : env16720.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16719_16720 : H12AffineEnvironment.transform 11 1028 env16719 = env16720 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1028 env16719 == env16720) = true)

theorem identity16720 : scanCanonicalize (H12AffineFastState.compose env16720 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 33) := by decide +kernel

theorem selectedBound16720 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16721 : List Nat := [2,4,8,16,32,64,8,4,122,1024,33,1028,88,113,112,82,96,33,1024,113,1093,81,16,114,88,65,32,17,1140,81,1105,80,4,80,32,122]

theorem envBound16721 : H12AffineFastState.Bounded env16721 := by
  intro p hp
  have h : env16721.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16720_16721 : H12AffineEnvironment.transform 10 33 env16720 = env16721 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 33 env16720 == env16721) = true)

theorem identity16721 : scanCanonicalize (H12AffineFastState.compose env16721 (packedSelected [4,5] rootPS)) = affineNative (2^(9+1) ^^^ 118) := by decide +kernel

theorem selectedBound16721 : packedSelected [4,5] rootPS < 2^1333 := by decide +kernel

def env16722 : List Nat := [2,4,8,16,32,64,8,4,122,118,33,114,88,113,112,82,96,33,118,113,51,81,16,114,88,65,32,17,2,81,39,80,4,80,32,122]

theorem envBound16722 : H12AffineFastState.Bounded env16722 := by
  intro p hp
  have h : env16722.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16721_16722 : H12AffineEnvironment.transform 9 118 env16721 = env16722 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 118 env16721 == env16722) = true)

theorem identity16722 : scanCanonicalize (H12AffineFastState.compose env16722 (packedSelected [0,1,4,7] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16722 : packedSelected [0,1,4,7] rootPS < 2^1333 := by decide +kernel

def env16723 : List Nat := [2,4,8,16,16,64,8,4,74,70,17,66,88,65,64,82,80,17,70,65,3,81,16,66,88,65,16,17,2,81,23,80,4,80,16,74]

theorem envBound16723 : H12AffineFastState.Bounded env16723 := by
  intro p hp
  have h : env16723.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16722_16723 : H12AffineEnvironment.transform 4 16 env16722 = env16723 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16722 == env16723) = true)

theorem identity16723 : scanCanonicalize (H12AffineFastState.compose env16723 (packedSelected [2,4] rootPS)) = affineNative (2^(1+1) ^^^ 1) := by decide +kernel

theorem selectedBound16723 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16724 : List Nat := [2,1,8,16,16,64,8,1,74,67,17,66,88,65,64,82,80,17,67,65,3,81,16,66,88,65,16,17,2,81,18,80,1,80,16,74]

theorem envBound16724 : H12AffineFastState.Bounded env16724 := by
  intro p hp
  have h : env16724.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16723_16724 : H12AffineEnvironment.transform 1 1 env16723 = env16724 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 1 env16723 == env16724) = true)

theorem identity16724 : scanCanonicalize (H12AffineFastState.compose env16724 (packedSelected [1,8] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16724 : packedSelected [1,8] rootPS < 2^1333 := by decide +kernel

def env16725 : List Nat := [2,1,8,1,1,64,8,1,74,67,0,66,73,65,64,67,65,0,67,65,3,64,1,66,73,65,1,0,2,64,3,65,1,65,1,74]

theorem envBound16725 : H12AffineFastState.Bounded env16725 := by
  intro p hp
  have h : env16725.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16724_16725 : H12AffineEnvironment.transform 3 1 env16724 = env16725 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16724 == env16725) = true)

theorem identity16725 : scanCanonicalize (H12AffineFastState.compose env16725 (packedSelected [0,1] rootPS)) = affineNative (2^(2+1) ^^^ 2) := by decide +kernel

theorem selectedBound16725 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16726 : List Nat := [2,1,2,1,1,64,2,1,64,67,0,66,67,65,64,67,65,0,67,65,3,64,1,66,67,65,1,0,2,64,3,65,1,65,1,64]

theorem envBound16726 : H12AffineFastState.Bounded env16726 := by
  intro p hp
  have h : env16726.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16725_16726 : H12AffineEnvironment.transform 2 2 env16725 = env16726 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 2 2 env16725 == env16726) = true)

theorem identity16726 : scanCanonicalize (H12AffineFastState.compose env16726 (packedSelected [2] rootPS)) = affineNative (2^(0+1) ^^^ 0) := by decide +kernel

theorem selectedBound16726 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16727 : List Nat := [0,1,0,1,1,64,0,1,64,65,0,64,65,65,64,65,65,0,65,65,1,64,1,64,65,65,1,0,0,64,1,65,1,65,1,64]

theorem envBound16727 : H12AffineFastState.Bounded env16727 := by
  intro p hp
  have h : env16727.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16726_16727 : H12AffineEnvironment.transform 0 0 env16726 = env16727 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 0 0 env16726 == env16727) = true)

theorem identity16727 : scanCanonicalize (H12AffineFastState.compose env16727 (packedSelected [14] rootPS)) = affineNative (2^(5+1) ^^^ 1) := by decide +kernel

theorem selectedBound16727 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16728 : List Nat := [0,1,0,1,1,1,0,1,1,0,0,1,0,0,1,0,0,0,0,0,1,1,1,1,0,0,1,0,0,1,1,0,1,0,1,1]

theorem envBound16728 : H12AffineFastState.Bounded env16728 := by
  intro p hp
  have h : env16728.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16727_16728 : H12AffineEnvironment.transform 5 1 env16727 = env16728 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 1 env16727 == env16728) = true)

def env16729 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,190520,1024,32769,58397,180272,16,95497,8193,65,171280,5393,45405,10281,61704,144492,256,21793,46093,120406]

theorem envBound16729 : H12AffineFastState.Bounded env16729 := by
  intro p hp
  have h : env16729.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16711_16729 : H12AffineEnvironment.transform 6 9 env16711 = env16729 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16711 == env16729) = true)

theorem identity16729 : scanCanonicalize (H12AffineFastState.compose env16729 (packedSelected [17] rootPS)) = affineNative (2^(16+1) ^^^ 70727) := by decide +kernel

theorem selectedBound16729 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16730 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70727,130175,1024,32769,58397,119927,16,95497,8193,65,100695,5393,45405,10281,61704,73771,256,21793,46093,120406]

theorem envBound16730 : H12AffineFastState.Bounded env16730 := by
  intro p hp
  have h : env16730.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16729_16730 : H12AffineEnvironment.transform 16 70727 env16729 = env16730 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70727 env16729 == env16730) = true)

theorem identity16730 : scanCanonicalize (H12AffineFastState.compose env16730 (packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound16730 : packedSelected [1,8,9,10,11,15,18,19,20,22,23,26] rootPS < 2^1333 := by decide +kernel

def env16731 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,65536,70727,108926,1024,32769,45340,98678,16,73736,8193,65,100695,5393,45405,10281,41993,73771,256,32,46093,99159]

theorem envBound16731 : H12AffineFastState.Bounded env16731 := by
  intro p hp
  have h : env16731.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16730_16731 : H12AffineEnvironment.transform 13 5377 env16730 = env16731 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16730 == env16731) = true)

theorem identity16731 : scanCanonicalize (H12AffineFastState.compose env16731 (packedSelected [3,4,5,9,10,11,14,18,20] rootPS)) = affineNative (2^(15+1) ^^^ 40971) := by decide +kernel

theorem selectedBound16731 : packedSelected [3,4,5,9,10,11,14,18,20] rootPS < 2^1333 := by decide +kernel

def env16732 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,32768,40971,46156,2421,1024,32769,45340,8573,16,32771,8193,65,10588,5393,45405,10281,41993,32800,256,32,46093,9052]

theorem envBound16732 : H12AffineFastState.Bounded env16732 := by
  intro p hp
  have h : env16732.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16731_16732 : H12AffineEnvironment.transform 15 40971 env16731 = env16732 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 40971 env16731 == env16732) = true)

theorem identity16732 : scanCanonicalize (H12AffineFastState.compose env16732 (packedSelected [1,2,6,8,10,11,12,14,16] rootPS)) = affineNative (2^(14+1) ^^^ 81) := by decide +kernel

theorem selectedBound16732 : packedSelected [1,2,6,8,10,11,12,14,16] rootPS < 2^1333 := by decide +kernel

def env16733 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,5377,81,8282,13341,2421,1024,80,12621,8573,16,82,8193,65,10588,5393,12556,10281,9304,113,256,32,13404,9052]

theorem envBound16733 : H12AffineFastState.Bounded env16733 := by
  intro p hp
  have h : env16733.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16732_16733 : H12AffineEnvironment.transform 14 81 env16732 = env16733 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 81 env16732 == env16733) = true)

theorem identity16733 : scanCanonicalize (H12AffineFastState.compose env16733 (packedSelected [0,2,4,6,7,9,11,14,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16733 : packedSelected [0,2,4,6,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env16734 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,81,343,5392,2421,1024,80,4160,112,16,82,268,65,2129,5393,4097,2340,1365,113,256,32,5457,593]

theorem envBound16734 : H12AffineFastState.Bounded env16734 := by
  intro p hp
  have h : env16734.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16733_16734 : H12AffineEnvironment.transform 12 269 env16733 = env16734 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16733 == env16734) = true)

theorem identity16734 : scanCanonicalize (H12AffineFastState.compose env16734 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16734 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16735 : List Nat := [2,4,8,16,1,64,9,256,512,1024,2048,4096,269,5377,81,343,5392,2388,1024,80,4160,81,16,82,268,65,2129,5393,4097,2309,1365,80,256,1,5457,593]

theorem envBound16735 : H12AffineFastState.Bounded env16735 := by
  intro p hp
  have h : env16735.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16734_16735 : H12AffineEnvironment.transform 4 1 env16734 = env16735 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16734 == env16735) = true)

theorem identity16735 : scanCanonicalize (H12AffineFastState.compose env16735 (packedSelected [1,2,4,5,7,10] rootPS)) = affineNative (2^(10+1) ^^^ 81) := by decide +kernel

theorem selectedBound16735 : packedSelected [1,2,4,5,7,10] rootPS < 2^1333 := by decide +kernel

def env16736 : List Nat := [2,4,8,16,1,64,9,256,512,1024,81,4096,269,5377,81,343,5392,261,1024,80,4160,81,16,82,268,65,0,5393,4097,340,1365,80,256,1,5457,593]

theorem envBound16736 : H12AffineFastState.Bounded env16736 := by
  intro p hp
  have h : env16736.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16735_16736 : H12AffineEnvironment.transform 10 81 env16735 = env16736 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 81 env16735 == env16736) = true)

theorem identity16736 : scanCanonicalize (H12AffineFastState.compose env16736 (packedSelected [0,2,3,4,8] rootPS)) = affineNative (2^(11+1) ^^^ 65) := by decide +kernel

theorem selectedBound16736 : packedSelected [0,2,3,4,8] rootPS < 2^1333 := by decide +kernel

def env16737 : List Nat := [2,4,8,16,1,64,9,256,512,1024,81,65,269,1344,81,343,1361,261,1024,80,1,81,16,82,268,65,0,1360,64,340,1365,80,256,1,1296,593]

theorem envBound16737 : H12AffineFastState.Bounded env16737 := by
  intro p hp
  have h : env16737.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16736_16737 : H12AffineEnvironment.transform 11 65 env16736 = env16737 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 65 env16736 == env16737) = true)

theorem identity16737 : scanCanonicalize (H12AffineFastState.compose env16737 (packedSelected [0,2,7] rootPS)) = affineNative (2^(9+1) ^^^ 69) := by decide +kernel

theorem selectedBound16737 : packedSelected [0,2,7] rootPS < 2^1333 := by decide +kernel

def env16738 : List Nat := [2,4,8,16,1,64,9,256,512,69,81,65,269,261,81,343,276,261,69,80,1,81,16,82,268,65,0,277,64,340,272,80,256,1,341,593]

theorem envBound16738 : H12AffineFastState.Bounded env16738 := by
  intro p hp
  have h : env16738.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16737_16738 : H12AffineEnvironment.transform 9 69 env16737 = env16738 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 69 env16737 == env16738) = true)

theorem identity16738 : scanCanonicalize (H12AffineFastState.compose env16738 (packedSelected [0,1,3,4,11] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16738 : packedSelected [0,1,3,4,11] rootPS < 2^1333 := by decide +kernel

def env16739 : List Nat := [2,4,8,16,1,16,9,256,512,21,1,17,269,261,1,263,276,261,21,0,1,1,16,2,268,17,0,277,16,260,272,0,256,1,261,513]

theorem envBound16739 : H12AffineFastState.Bounded env16739 := by
  intro p hp
  have h : env16739.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16738_16739 : H12AffineEnvironment.transform 5 16 env16738 = env16739 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16738 == env16739) = true)

theorem identity16739 : scanCanonicalize (H12AffineFastState.compose env16739 (packedSelected [2] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16739 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16740 : List Nat := [2,4,8,1,1,1,9,256,512,4,1,0,269,261,1,263,261,261,4,0,1,1,1,2,268,0,0,260,1,260,257,0,256,1,261,513]

theorem envBound16740 : H12AffineFastState.Bounded env16740 := by
  intro p hp
  have h : env16740.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16739_16740 : H12AffineEnvironment.transform 3 1 env16739 = env16740 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16739 == env16740) = true)

theorem identity16740 : scanCanonicalize (H12AffineFastState.compose env16740 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 261) := by decide +kernel

theorem selectedBound16740 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16741 : List Nat := [2,4,8,1,1,1,9,256,261,4,1,0,269,261,1,263,261,261,4,0,1,1,1,2,268,0,0,260,1,260,257,0,256,1,261,260]

theorem envBound16741 : H12AffineFastState.Bounded env16741 := by
  intro p hp
  have h : env16741.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16740_16741 : H12AffineEnvironment.transform 8 261 env16740 = env16741 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 261 env16740 == env16741) = true)

theorem identity16741 : scanCanonicalize (H12AffineFastState.compose env16741 (packedSelected [0] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16741 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16742 : List Nat := [2,4,8,1,1,1,9,5,0,4,1,0,8,0,1,2,0,0,4,0,1,1,1,2,9,0,0,1,1,1,4,0,5,1,0,1]

theorem envBound16742 : H12AffineFastState.Bounded env16742 := by
  intro p hp
  have h : env16742.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16741_16742 : H12AffineEnvironment.transform 7 5 env16741 = env16742 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16741 == env16742) = true)

def env16743 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,8388608,8887721,8328,65,4218280,8393984,8804725,8830977,399800,12645453,256,21792,46213,474735]

theorem envBound16743 : H12AffineFastState.Bounded env16743 := by
  intro p hp
  have h : env16743.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16615_16743 : H12AffineEnvironment.transform 23 8887721 env16615 = env16743 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 8887721 env16615 == env16743) = true)

def env16744 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,452768,95497,8328,65,4218280,458144,45525,10401,399800,4594925,256,21792,46213,474735]

theorem envBound16744 : H12AffineFastState.Bounded env16744 := by
  intro p hp
  have h : env16744.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16743_16744 : H12AffineEnvironment.transform 22 452768 env16743 = env16744 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452768 env16743 == env16744) = true)

def env16745 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272512,452768,95497,8328,65,292136,458144,45525,10401,399800,144493,256,21792,46213,474735]

theorem envBound16745 : H12AffineFastState.Bounded env16745 := by
  intro p hp
  have h : env16745.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16744_16745 : H12AffineEnvironment.transform 21 272512 env16744 = env16745 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16744 == env16745) = true)

theorem identity16745 : scanCanonicalize (H12AffineFastState.compose env16745 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 247995) := by decide +kernel

theorem selectedBound16745 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16746 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,247995,1024,32769,115870,254011,73755,95497,8328,65,245139,79131,45525,10401,119043,144493,256,21792,46213,63188]

theorem envBound16746 : H12AffineFastState.Bounded env16746 := by
  intro p hp
  have h : env16746.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16745_16746 : H12AffineEnvironment.transform 17 247995 env16745 = env16746 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 247995 env16745 == env16746) = true)

def env16747 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49168,67755,1024,32769,115870,73771,73755,95497,8328,65,97667,79131,45525,10401,119043,62589,256,21792,46213,63188]

theorem envBound16747 : H12AffineFastState.Bounded env16747 := by
  intro p hp
  have h : env16747.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16746_16747 : H12AffineEnvironment.transform 16 49168 env16746 = env16747 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env16746 == env16747) = true)

theorem identity16747 : scanCanonicalize (H12AffineFastState.compose env16747 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 8661) := by decide +kernel

theorem selectedBound16747 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env16748 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,65536,25029,67755,1024,8660,91467,73771,73755,95497,8328,65,97667,79131,4096,10401,94422,21928,256,21792,5456,22273]

theorem envBound16748 : H12AffineFastState.Bounded env16748 := by
  intro p hp
  have h : env16748.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16747_16748 : H12AffineEnvironment.transform 14 8661 env16747 = env16748 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8661 env16747 == env16748) = true)

theorem identity16748 : scanCanonicalize (H12AffineFastState.compose env16748 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 30083) := by decide +kernel

theorem selectedBound16748 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16749 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,8661,30083,25029,32040,1024,8660,4296,21928,21912,138,8328,65,2048,16536,4096,10401,1365,21928,256,21792,5456,22273]

theorem envBound16749 : H12AffineFastState.Bounded env16749 := by
  intro p hp
  have h : env16749.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16748_16749 : H12AffineEnvironment.transform 15 30083 env16748 = env16749 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 30083 env16748 == env16749) = true)

theorem identity16749 : scanCanonicalize (H12AffineFastState.compose env16749 (packedSelected [0,4,7,16,18,20,22,23] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound16749 : packedSelected [0,4,7,16,18,20,22,23] rootPS < 2^1333 := by decide +kernel

def env16750 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,16384,8460,30042,24860,32040,1024,8461,4113,21873,21825,83,8273,65,2048,16449,4096,10360,1365,21873,256,21792,5456,22273]

theorem envBound16750 : H12AffineFastState.Bounded env16750 := by
  intro p hp
  have h : env16750.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16749_16750 : H12AffineEnvironment.transform 6 89 env16749 = env16750 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env16749 == env16750) = true)

theorem identity16750 : scanCanonicalize (H12AffineFastState.compose env16750 (packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS)) = affineNative (2^(13+1) ^^^ 5456) := by decide +kernel

theorem selectedBound16750 : packedSelected [0,2,4,6,7,9,10,11,12,15,16,18,19] rootPS < 2^1333 := by decide +kernel

def env16751 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,8192,5456,8460,8202,13388,10360,1024,8461,4113,33,17,83,8273,65,2048,5393,4096,10360,1365,33,256,112,5456,593]

theorem envBound16751 : H12AffineFastState.Bounded env16751 := by
  intro p hp
  have h : env16751.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16750_16751 : H12AffineEnvironment.transform 13 5456 env16750 = env16751 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5456 env16750 == env16751) = true)

theorem identity16751 : scanCanonicalize (H12AffineFastState.compose env16751 (packedSelected [0,1,4,6,7,8,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16751 : packedSelected [0,1,4,6,7,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16752 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,4096,268,5456,0,262,5440,2420,1024,1,4113,33,17,83,349,65,2048,5393,4096,2420,1365,33,256,112,5456,593]

theorem envBound16752 : H12AffineFastState.Bounded env16752 := by
  intro p hp
  have h : env16752.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16751_16752 : H12AffineEnvironment.transform 12 268 env16751 = env16752 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16751 == env16752) = true)

theorem identity16752 : scanCanonicalize (H12AffineFastState.compose env16752 (packedSelected [2,3,4,5,7] rootPS)) = affineNative (2^(11+1) ^^^ 2405) := by decide +kernel

theorem selectedBound16752 : packedSelected [2,3,4,5,7] rootPS < 2^1333 := by decide +kernel

def env16753 : List Nat := [2,4,8,16,32,64,89,256,512,1024,2048,2405,268,3125,0,262,3109,2420,1024,1,2420,33,17,83,349,65,2048,3188,2405,2420,1365,33,256,112,3125,593]

theorem envBound16753 : H12AffineFastState.Bounded env16753 := by
  intro p hp
  have h : env16753.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16752_16753 : H12AffineEnvironment.transform 11 2405 env16752 = env16753 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2405 env16752 == env16753) = true)

theorem identity16753 : scanCanonicalize (H12AffineFastState.compose env16753 (packedSelected [2,3,5,6] rootPS)) = affineNative (2^(10+1) ^^^ 340) := by decide +kernel

theorem selectedBound16753 : packedSelected [2,3,5,6] rootPS < 2^1333 := by decide +kernel

def env16754 : List Nat := [2,4,8,16,32,64,89,256,512,1024,340,49,268,1377,0,262,1393,32,1024,1,32,33,17,83,349,65,340,1312,49,32,1365,33,256,112,1377,593]

theorem envBound16754 : H12AffineFastState.Bounded env16754 := by
  intro p hp
  have h : env16754.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16753_16754 : H12AffineEnvironment.transform 10 340 env16753 = env16754 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 340 env16753 == env16754) = true)

theorem identity16754 : scanCanonicalize (H12AffineFastState.compose env16754 (packedSelected [0,9] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16754 : packedSelected [0,9] rootPS < 2^1333 := by decide +kernel

def env16755 : List Nat := [2,4,8,16,32,16,9,256,512,1024,260,49,268,1329,0,262,1313,32,1024,1,32,33,17,3,269,17,260,1312,49,32,1285,33,256,32,1329,513]

theorem envBound16755 : H12AffineFastState.Bounded env16755 := by
  intro p hp
  have h : env16755.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16754_16755 : H12AffineEnvironment.transform 5 16 env16754 = env16755 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16754 == env16755) = true)

theorem identity16755 : scanCanonicalize (H12AffineFastState.compose env16755 (packedSelected [2] rootPS)) = affineNative (2^(9+1) ^^^ 5) := by decide +kernel

theorem selectedBound16755 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16756 : List Nat := [2,4,8,16,32,16,9,256,512,5,260,49,268,308,0,262,292,32,5,1,32,33,17,3,269,17,260,293,49,32,256,33,256,32,308,513]

theorem envBound16756 : H12AffineFastState.Bounded env16756 := by
  intro p hp
  have h : env16756.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16755_16756 : H12AffineEnvironment.transform 9 5 env16755 = env16756 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 5 env16755 == env16756) = true)

theorem identity16756 : scanCanonicalize (H12AffineFastState.compose env16756 (packedSelected [1,3] rootPS)) = affineNative (2^(7+1) ^^^ 14) := by decide +kernel

theorem selectedBound16756 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16757 : List Nat := [2,4,8,16,32,16,9,14,512,5,10,49,2,58,0,8,42,32,5,1,32,33,17,3,3,17,10,43,49,32,14,33,14,32,58,513]

theorem envBound16757 : H12AffineFastState.Bounded env16757 := by
  intro p hp
  have h : env16757.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16756_16757 : H12AffineEnvironment.transform 7 14 env16756 = env16757 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 14 env16756 == env16757) = true)

def env16758 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,49169,67754,1024,32769,115870,73770,73755,95497,8328,65,97666,79131,45525,10401,119043,62588,256,21792,46213,63188]

theorem envBound16758 : H12AffineFastState.Bounded env16758 := by
  intro p hp
  have h : env16758.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16746_16758 : H12AffineEnvironment.transform 16 49169 env16746 = env16758 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49169 env16746 == env16758) = true)

theorem identity16758 : scanCanonicalize (H12AffineFastState.compose env16758 (packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS)) = affineNative (2^(14+1) ^^^ 21760) := by decide +kernel

theorem selectedBound16758 : packedSelected [0,1,3,4,5,7,8,10,11,17,18,19,22,23,32] rootPS < 2^1333 := by decide +kernel

def env16759 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,21760,65536,5393,67754,1024,21761,70046,73770,73755,95497,8328,65,97666,79131,25813,10401,66563,8572,256,21792,24965,9172]

theorem envBound16759 : H12AffineFastState.Bounded env16759 := by
  intro p hp
  have h : env16759.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16758_16759 : H12AffineEnvironment.transform 14 21760 env16758 = env16759 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21760 env16758 == env16759) = true)

theorem identity16759 : scanCanonicalize (H12AffineFastState.compose env16759 (packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16759 : packedSelected [3,4,7,9,10,14,24,26,27,35] rootPS < 2^1333 := by decide +kernel

def env16760 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21760,65536,5393,67754,1024,21761,70046,65910,65863,87125,468,65,89310,70727,17801,2557,66563,32,256,21792,16601,648]

theorem envBound16760 : H12AffineFastState.Bounded env16760 := by
  intro p hp
  have h : env16760.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16759_16760 : H12AffineEnvironment.transform 12 348 env16759 = env16760 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16759 == env16760) = true)

theorem identity16760 : scanCanonicalize (H12AffineFastState.compose env16760 (packedSelected [0,2,3,6,7,10,20,24,26] rootPS)) = affineNative (2^(15+1) ^^^ 478) := by decide +kernel

theorem selectedBound16760 : packedSelected [0,2,3,6,7,10,20,24,26] rootPS < 2^1333 := by decide +kernel

def env16761 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,16384,21760,478,5393,2420,1024,21761,4160,168,153,21899,468,65,23808,5529,17801,2557,1501,32,256,21792,16601,648]

theorem envBound16761 : H12AffineFastState.Bounded env16761 := by
  intro p hp
  have h : env16761.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16760_16761 : H12AffineEnvironment.transform 15 478 env16760 = env16761 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 478 env16760 == env16761) = true)

theorem identity16761 : scanCanonicalize (H12AffineFastState.compose env16761 (packedSelected [3,5,10] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound16761 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16762 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,348,5377,1,478,5393,2420,1024,0,4160,168,153,138,468,65,2049,5529,4232,2557,1501,32,256,33,5592,648]

theorem envBound16762 : H12AffineFastState.Bounded env16762 := by
  intro p hp
  have h : env16762.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16761_16762 : H12AffineEnvironment.transform 13 5377 env16761 = env16762 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16761 == env16762) = true)

theorem identity16762 : scanCanonicalize (H12AffineFastState.compose env16762 (packedSelected [0,6,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16762 : packedSelected [0,6,7,11] rootPS < 2^1333 := by decide +kernel

def env16763 : List Nat := [2,4,8,16,1,64,128,256,512,1024,2048,4096,348,5377,1,478,5393,2389,1024,0,4160,137,153,138,468,65,2049,5529,4232,2524,1501,1,256,0,5592,648]

theorem envBound16763 : H12AffineFastState.Bounded env16763 := by
  intro p hp
  have h : env16763.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16762_16763 : H12AffineEnvironment.transform 4 1 env16762 = env16763 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16762 == env16763) = true)

theorem identity16763 : scanCanonicalize (H12AffineFastState.compose env16763 (packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS)) = affineNative (2^(6+1) ^^^ 89) := by decide +kernel

theorem selectedBound16763 : packedSelected [0,1,2,3,4,5,7,8,9,12] rootPS < 2^1333 := by decide +kernel

def env16764 : List Nat := [2,4,8,16,1,64,89,256,512,1024,2048,4096,348,5377,1,263,5393,2389,1024,0,4160,80,64,83,269,65,2049,5440,4177,2309,1284,1,256,0,5377,593]

theorem envBound16764 : H12AffineFastState.Bounded env16764 := by
  intro p hp
  have h : env16764.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16763_16764 : H12AffineEnvironment.transform 6 89 env16763 = env16764 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 89 env16763 == env16764) = true)

theorem identity16764 : scanCanonicalize (H12AffineFastState.compose env16764 (packedSelected [1,2,3] rootPS)) = affineNative (2^(7+1) ^^^ 4) := by decide +kernel

theorem selectedBound16764 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env16765 : List Nat := [2,4,8,16,1,64,89,4,512,1024,2048,4096,88,5125,1,3,5141,2129,1024,0,4160,80,64,83,9,65,2049,5188,4177,2049,1024,1,4,0,5125,593]

theorem envBound16765 : H12AffineFastState.Bounded env16765 := by
  intro p hp
  have h : env16765.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16764_16765 : H12AffineEnvironment.transform 7 4 env16764 = env16765 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 4 env16764 == env16765) = true)

theorem identity16765 : scanCanonicalize (H12AffineFastState.compose env16765 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16765 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16766 : List Nat := [2,4,8,16,1,17,8,4,512,1024,2048,4096,9,5125,1,3,5141,2048,1024,0,4113,1,17,2,9,16,2049,5141,4096,2049,1024,1,4,0,5125,512]

theorem envBound16766 : H12AffineFastState.Bounded env16766 := by
  intro p hp
  have h : env16766.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16765_16766 : H12AffineEnvironment.transform 5 17 env16765 = env16766 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16765 == env16766) = true)

def env16767 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452768,95497,8328,65,292137,458144,45525,10401,399800,144492,256,21792,46213,474735]

theorem envBound16767 : H12AffineFastState.Bounded env16767 := by
  intro p hp
  have h : env16767.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16744_16767 : H12AffineEnvironment.transform 21 272513 env16744 = env16767 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16744 == env16767) = true)

theorem identity16767 : scanCanonicalize (H12AffineFastState.compose env16767 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16767 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16768 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396325,272513,452768,21762,8328,65,292137,458144,45525,10401,399800,144492,256,21792,46213,400996]

theorem envBound16768 : H12AffineFastState.Bounded env16768 := by
  intro p hp
  have h : env16768.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16767_16768 : H12AffineEnvironment.transform 15 8203 env16767 = env16768 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16767 == env16768) = true)

def env16769 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396325,272393,452648,21762,8192,65,292137,458024,45405,10281,399664,144492,256,21792,46093,400996]

theorem envBound16769 : H12AffineFastState.Bounded env16769 := by
  intro p hp
  have h : env16769.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16768_16769 : H12AffineEnvironment.transform 6 8 env16768 = env16769 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16768 == env16769) = true)

theorem identity16769 : scanCanonicalize (H12AffineFastState.compose env16769 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(16+1) ^^^ 46392) := by decide +kernel

theorem selectedBound16769 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16770 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,46392,262144,1024,32769,309533,272393,285968,21762,8192,65,292137,280592,45405,10281,306184,33108,256,21792,46093,306012]

theorem envBound16770 : H12AffineFastState.Bounded env16770 := by
  intro p hp
  have h : env16770.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16769_16770 : H12AffineEnvironment.transform 16 46392 env16769 = env16770 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 46392 env16769 == env16770) = true)

theorem identity16770 : scanCanonicalize (H12AffineFastState.compose env16770 (packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS)) = affineNative (2^(17+1) ^^^ 64604) := by decide +kernel

theorem selectedBound16770 : packedSelected [0,2,4,7,8,10,11,12,14,15,17,22,23,28] rootPS < 2^1333 := by decide +kernel

def env16771 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,46392,64604,1024,32769,17729,54357,41292,21762,8192,65,35189,46156,45405,10281,20564,33108,256,21792,46093,22272]

theorem envBound16771 : H12AffineFastState.Bounded env16771 := by
  intro p hp
  have h : env16771.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16770_16771 : H12AffineEnvironment.transform 17 64604 env16770 = env16771 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 64604 env16770 == env16771) = true)

theorem identity16771 : scanCanonicalize (H12AffineFastState.compose env16771 (packedSelected [0,2,6,7,11,16,17,18] rootPS)) = affineNative (2^(13+1) ^^^ 5376) := by decide +kernel

theorem selectedBound16771 : packedSelected [0,2,6,7,11,16,17,18] rootPS < 2^1333 := by decide +kernel

def env16772 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,5376,32768,8203,46392,43356,1024,32769,4161,33109,41292,2,8192,65,35189,46156,45405,10281,1364,33108,256,32,46093,512]

theorem envBound16772 : H12AffineFastState.Bounded env16772 := by
  intro p hp
  have h : env16772.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16771_16772 : H12AffineEnvironment.transform 13 5376 env16771 = env16772 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16771 == env16772) = true)

def env16773 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,262144,1024,32769,396325,272392,452649,21762,8193,65,292137,458025,45404,10280,399665,144492,256,21792,46092,400996]

theorem envBound16773 : H12AffineFastState.Bounded env16773 := by
  intro p hp
  have h : env16773.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16768_16773 : H12AffineEnvironment.transform 6 9 env16768 = env16773 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16768 == env16773) = true)

theorem identity16773 : scanCanonicalize (H12AffineFastState.compose env16773 (packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 23668) := by decide +kernel

theorem selectedBound16773 : packedSelected [0,3,7,8,9,11,14,20,22,24,26,28,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16774 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,8203,131072,23668,1024,32769,151633,29820,177245,21762,8193,65,10589,172381,45404,10280,148805,144492,256,21792,46092,147984]

theorem envBound16774 : H12AffineFastState.Bounded env16774 := by
  intro p hp
  have h : env16774.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16773_16774 : H12AffineEnvironment.transform 17 23668 env16773 = env16774 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 23668 env16773 == env16774) = true)

theorem identity16774 : scanCanonicalize (H12AffineFastState.compose env16774 (packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS)) = affineNative (2^(14+1) ^^^ 21761) := by decide +kernel

theorem selectedBound16774 : packedSelected [0,4,8,10,12,14,15,18,20,22,23,27,28] rootPS < 2^1333 := by decide +kernel

def env16775 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,21761,8203,131072,23668,1024,21760,151633,29820,155996,21762,8193,65,10589,160860,25693,10280,148805,144492,256,21792,24845,147984]

theorem envBound16775 : H12AffineFastState.Bounded env16775 := by
  intro p hp
  have h : env16775.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16774_16775 : H12AffineEnvironment.transform 14 21761 env16774 = env16775 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21761 env16774 == env16775) = true)

def env16776 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,4194304,452769,95496,8328,65,4218280,458145,45524,10400,399800,4594924,256,21792,46213,474735]

theorem envBound16776 : H12AffineFastState.Bounded env16776 := by
  intro p hp
  have h : env16776.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16743_16776 : H12AffineEnvironment.transform 22 452769 env16743 = env16776 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 452769 env16743 == env16776) = true)

def env16777 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272512,452769,95496,8328,65,292136,458145,45524,10400,399800,144492,256,21792,46213,474735]

theorem envBound16777 : H12AffineFastState.Bounded env16777 := by
  intro p hp
  have h : env16777.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16776_16777 : H12AffineEnvironment.transform 21 272512 env16776 = env16777 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272512 env16776 == env16777) = true)

theorem identity16777 : scanCanonicalize (H12AffineFastState.compose env16777 (packedSelected [21] rootPS)) = affineNative (2^(17+1) ^^^ 212078) := by decide +kernel

theorem selectedBound16777 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16778 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201966,120015,95496,8328,65,215366,115151,45524,10400,75222,144492,256,21792,46213,513]

theorem envBound16778 : H12AffineFastState.Bounded env16778 := by
  intro p hp
  have h : env16778.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16777_16778 : H12AffineEnvironment.transform 17 212078 env16777 = env16778 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 212078 env16777 == env16778) = true)

def env16779 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201830,119879,95496,8192,65,215366,115015,45404,10280,75102,144492,256,21792,46093,513]

theorem envBound16779 : H12AffineFastState.Bounded env16779 := by
  intro p hp
  have h : env16779.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16778_16779 : H12AffineEnvironment.transform 6 8 env16778 = env16779 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16778 == env16779) = true)

theorem identity16779 : scanCanonicalize (H12AffineFastState.compose env16779 (packedSelected [0,4,7,16,20,22] rootPS)) = affineNative (2^(16+1) ^^^ 90139) := by decide +kernel

theorem selectedBound16779 : packedSelected [0,4,7,16,20,22] rootPS < 2^1333 := by decide +kernel

def env16780 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,90139,23669,1024,32769,77899,29821,119879,95496,8192,65,10589,115015,45404,10280,75102,87159,256,21792,46093,513]

theorem envBound16780 : H12AffineFastState.Bounded env16780 := by
  intro p hp
  have h : env16780.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16779_16780 : H12AffineEnvironment.transform 16 90139 env16779 = env16780 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 90139 env16779 == env16780) = true)

theorem identity16780 : scanCanonicalize (H12AffineFastState.compose env16780 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(15+1) ^^^ 54278) := by decide +kernel

theorem selectedBound16780 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env16781 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54278,46109,23669,1024,32769,58445,29821,65,41230,8192,65,10589,5441,45404,10280,61784,32881,256,21792,46093,513]

theorem envBound16781 : H12AffineFastState.Bounded env16781 := by
  intro p hp
  have h : env16781.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16780_16781 : H12AffineEnvironment.transform 15 54278 env16780 = env16781 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54278 env16780 == env16781) = true)

theorem identity16781 : scanCanonicalize (H12AffineFastState.compose env16781 (packedSelected [2,4,6,9,14,20] rootPS)) = affineNative (2^(13+1) ^^^ 13404) := by decide +kernel

theorem selectedBound16781 : packedSelected [2,4,6,9,14,20] rootPS < 2^1333 := by decide +kernel

def env16782 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,32768,41050,46109,10281,1024,32769,36881,33,65,41230,8192,65,10589,5441,45404,10280,34052,32881,256,8572,46093,513]

theorem envBound16782 : H12AffineFastState.Bounded env16782 := by
  intro p hp
  have h : env16782.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16781_16782 : H12AffineEnvironment.transform 13 13404 env16781 = env16782 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13404 env16781 == env16782) = true)

theorem identity16782 : scanCanonicalize (H12AffineFastState.compose env16782 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(14+1) ^^^ 7424) := by decide +kernel

theorem selectedBound16782 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env16783 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13404,7424,15706,10525,10281,1024,7425,3345,33,65,15374,8192,65,10589,5441,11356,10280,6148,7537,256,8572,10509,513]

theorem envBound16783 : H12AffineFastState.Bounded env16783 := by
  intro p hp
  have h : env16783.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16782_16783 : H12AffineEnvironment.transform 14 7424 env16782 = env16783 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 7424 env16782 == env16783) = true)

theorem identity16783 : scanCanonicalize (H12AffineFastState.compose env16783 (packedSelected [0,3,4,5,7,9,10,14] rootPS)) = affineNative (2^(12+1) ^^^ 268) := by decide +kernel

theorem selectedBound16783 : packedSelected [0,3,4,5,7,9,10,14] rootPS < 2^1333 := by decide +kernel

def env16784 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,268,5456,7424,7254,2065,2341,1024,7425,3345,33,65,7426,268,65,2129,5441,3408,2340,6148,7537,256,112,2049,513]

theorem envBound16784 : H12AffineFastState.Bounded env16784 := by
  intro p hp
  have h : env16784.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16783_16784 : H12AffineEnvironment.transform 12 268 env16783 = env16784 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 268 env16783 == env16784) = true)

theorem identity16784 : scanCanonicalize (H12AffineFastState.compose env16784 (packedSelected [1,8,10,12] rootPS)) = affineNative (2^(11+1) ^^^ 3188) := by decide +kernel

theorem selectedBound16784 : packedSelected [1,8,10,12] rootPS < 2^1333 := by decide +kernel

def env16785 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,3188,268,2340,372,34,2065,2341,1024,373,3345,33,65,374,268,65,2129,2357,3408,2340,1136,261,256,112,2049,513]

theorem envBound16785 : H12AffineFastState.Bounded env16785 := by
  intro p hp
  have h : env16785.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16784_16785 : H12AffineEnvironment.transform 11 3188 env16784 = env16785 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 3188 env16784 == env16785) = true)

theorem identity16785 : scanCanonicalize (H12AffineFastState.compose env16785 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(9+1) ^^^ 101) := by decide +kernel

theorem selectedBound16785 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env16786 : List Nat := [2,4,8,16,32,64,8,256,512,101,2048,2065,268,2340,372,34,2065,2341,101,373,2420,33,65,374,268,65,2129,2357,2357,2340,21,261,256,112,2049,513]

theorem envBound16786 : H12AffineFastState.Bounded env16786 := by
  intro p hp
  have h : env16786.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16785_16786 : H12AffineEnvironment.transform 9 101 env16785 = env16786 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 101 env16785 == env16786) = true)

theorem identity16786 : scanCanonicalize (H12AffineFastState.compose env16786 (packedSelected [1,4,8,9,10] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16786 : packedSelected [1,4,8,9,10] rootPS < 2^1333 := by decide +kernel

def env16787 : List Nat := [2,4,8,16,32,16,8,256,512,53,2048,2065,268,2340,292,34,2065,2341,53,293,2340,33,17,294,268,17,2049,2357,2357,2340,21,261,256,32,2049,513]

theorem envBound16787 : H12AffineFastState.Bounded env16787 := by
  intro p hp
  have h : env16787.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16786_16787 : H12AffineEnvironment.transform 5 16 env16786 = env16787 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16786 == env16787) = true)

theorem identity16787 : scanCanonicalize (H12AffineFastState.compose env16787 (packedSelected [0,3,4] rootPS)) = affineNative (2^(8+1) ^^^ 27) := by decide +kernel

theorem selectedBound16787 : packedSelected [0,3,4] rootPS < 2^1333 := by decide +kernel

def env16788 : List Nat := [2,4,8,16,32,16,8,256,27,53,2048,2065,268,2340,292,34,2065,2341,53,293,2340,33,17,294,268,17,2049,2357,2357,2340,21,261,256,32,2049,26]

theorem envBound16788 : H12AffineFastState.Bounded env16788 := by
  intro p hp
  have h : env16788.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16787_16788 : H12AffineEnvironment.transform 8 27 env16787 = env16788 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 27 env16787 == env16788) = true)

def env16789 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,131072,212078,1024,32769,77899,201831,119878,95496,8193,65,215366,115014,45405,10281,75103,144492,256,21792,46092,513]

theorem envBound16789 : H12AffineFastState.Bounded env16789 := by
  intro p hp
  have h : env16789.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16778_16789 : H12AffineEnvironment.transform 6 9 env16778 = env16789 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16778 == env16789) = true)

theorem identity16789 : scanCanonicalize (H12AffineFastState.compose env16789 (packedSelected [4,7,9,18,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 70726) := by decide +kernel

theorem selectedBound16789 : packedSelected [4,7,9,18,23,27] rootPS < 2^1333 := by decide +kernel

def env16790 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,65536,70726,10280,1024,32769,77899,33,119878,95496,8193,65,23808,115014,45405,10281,75103,73770,256,21792,46092,513]

theorem envBound16790 : H12AffineFastState.Bounded env16790 := by
  intro p hp
  have h : env16790.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16789_16790 : H12AffineEnvironment.transform 16 70726 env16789 = env16790 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 70726 env16789 == env16790) = true)

theorem identity16790 : scanCanonicalize (H12AffineFastState.compose env16790 (packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16790 : packedSelected [0,1,2,3,5,6,7,8,11,12,16,18] rootPS < 2^1333 := by decide +kernel

def env16791 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,65536,70726,10280,1024,8540,77899,33,95515,95496,8193,65,23808,90139,4096,10281,75103,73770,256,21792,5457,513]

theorem envBound16791 : H12AffineFastState.Bounded env16791 := by
  intro p hp
  have h : env16791.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16790_16791 : H12AffineEnvironment.transform 14 8541 env16790 = env16791 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16790 == env16791) = true)

theorem identity16791 : scanCanonicalize (H12AffineFastState.compose env16791 (packedSelected [0,1,3,5,7,8,11,12,14] rootPS)) = affineNative (2^(15+1) ^^^ 21591) := by decide +kernel

theorem selectedBound16791 : packedSelected [0,1,3,5,7,8,11,12,14] rootPS < 2^1333 := by decide +kernel

def env16792 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,8541,21591,16401,10280,1024,8540,25628,33,8524,8543,8193,65,23808,13388,4096,10281,28936,29821,256,21792,5457,513]

theorem envBound16792 : H12AffineFastState.Bounded env16792 := by
  intro p hp
  have h : env16792.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16791_16792 : H12AffineEnvironment.transform 15 21591 env16791 = env16792 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 21591 env16791 == env16792) = true)

theorem identity16792 : scanCanonicalize (H12AffineFastState.compose env16792 (packedSelected [3,5,10] rootPS)) = affineNative (2^(12+1) ^^^ 348) := by decide +kernel

theorem selectedBound16792 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16793 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,16384,1,21591,16401,2420,1024,0,17728,33,16,3,349,65,23808,5392,4096,2421,20564,21793,256,21792,5457,513]

theorem envBound16793 : H12AffineFastState.Bounded env16793 := by
  intro p hp
  have h : env16793.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16792_16793 : H12AffineEnvironment.transform 12 348 env16792 = env16793 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 348 env16792 == env16793) = true)

theorem identity16793 : scanCanonicalize (H12AffineFastState.compose env16793 (packedSelected [2,4,6,9,11] rootPS)) = affineNative (2^(13+1) ^^^ 5377) := by decide +kernel

theorem selectedBound16793 : packedSelected [2,4,6,9,11] rootPS < 2^1333 := by decide +kernel

def env16794 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,348,5377,1,342,5392,2420,1024,0,4161,33,16,3,349,65,2049,5392,4096,2421,1365,32,256,33,5457,513]

theorem envBound16794 : H12AffineFastState.Bounded env16794 := by
  intro p hp
  have h : env16794.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16793_16794 : H12AffineEnvironment.transform 13 5377 env16793 = env16794 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16793 == env16794) = true)

theorem identity16794 : scanCanonicalize (H12AffineFastState.compose env16794 (packedSelected [1,3] rootPS)) = affineNative (2^(9+1) ^^^ 565) := by decide +kernel

theorem selectedBound16794 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16795 : List Nat := [2,4,8,16,32,64,9,256,512,565,2048,4096,348,4916,1,342,4901,2420,565,0,4161,33,16,3,349,65,2049,4901,4096,2421,864,32,256,33,4964,513]

theorem envBound16795 : H12AffineFastState.Bounded env16795 := by
  intro p hp
  have h : env16795.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16794_16795 : H12AffineEnvironment.transform 9 565 env16794 = env16795 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 565 env16794 == env16795) = true)

theorem identity16795 : scanCanonicalize (H12AffineFastState.compose env16795 (packedSelected [2,6] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16795 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16796 : List Nat := [2,4,8,16,32,17,9,256,512,565,2048,4096,269,4916,1,263,4901,2341,565,0,4112,33,16,3,268,16,2049,4901,4096,2340,817,32,256,33,4917,513]

theorem envBound16796 : H12AffineFastState.Bounded env16796 := by
  intro p hp
  have h : env16796.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16795_16796 : H12AffineEnvironment.transform 5 17 env16795 = env16796 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16795 == env16796) = true)

theorem identity16796 : scanCanonicalize (H12AffineFastState.compose env16796 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 513) := by decide +kernel

theorem selectedBound16796 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16797 : List Nat := [2,4,8,16,32,17,9,256,512,565,2048,513,269,309,1,263,292,2341,565,0,529,33,16,3,268,16,2049,292,513,2340,817,32,256,33,308,513]

theorem envBound16797 : H12AffineFastState.Bounded env16797 := by
  intro p hp
  have h : env16797.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16796_16797 : H12AffineEnvironment.transform 11 513 env16796 = env16797 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 513 env16796 == env16797) = true)

theorem identity16797 : scanCanonicalize (H12AffineFastState.compose env16797 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 821) := by decide +kernel

theorem selectedBound16797 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16798 : List Nat := [2,4,8,16,32,17,9,256,512,565,821,513,269,309,1,263,292,528,565,0,529,33,16,3,268,16,820,292,513,529,817,32,256,33,308,513]

theorem envBound16798 : H12AffineFastState.Bounded env16798 := by
  intro p hp
  have h : env16798.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16797_16798 : H12AffineEnvironment.transform 10 821 env16797 = env16798 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 821 env16797 == env16798) = true)

theorem identity16798 : scanCanonicalize (H12AffineFastState.compose env16798 (packedSelected [1,5] rootPS)) = affineNative (2^(8+1) ^^^ 293) := by decide +kernel

theorem selectedBound16798 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16799 : List Nat := [2,4,8,16,32,17,9,256,293,272,16,292,269,309,1,263,292,309,272,0,308,33,16,3,268,16,17,292,292,308,20,32,256,33,308,292]

theorem envBound16799 : H12AffineFastState.Bounded env16799 := by
  intro p hp
  have h : env16799.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16798_16799 : H12AffineEnvironment.transform 8 293 env16798 = env16799 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 293 env16798 == env16799) = true)

theorem identity16799 : scanCanonicalize (H12AffineFastState.compose env16799 (packedSelected [0,1] rootPS)) = affineNative (2^(4+1) ^^^ 16) := by decide +kernel

theorem selectedBound16799 : packedSelected [0,1] rootPS < 2^1333 := by decide +kernel

def env16800 : List Nat := [2,4,8,16,16,17,9,256,277,272,16,276,269,261,1,263,276,261,272,0,260,17,16,3,268,16,17,276,276,260,20,16,256,17,260,276]

theorem envBound16800 : H12AffineFastState.Bounded env16800 := by
  intro p hp
  have h : env16800.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16799_16800 : H12AffineEnvironment.transform 4 16 env16799 = env16800 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 16 env16799 == env16800) = true)

theorem identity16800 : scanCanonicalize (H12AffineFastState.compose env16800 (packedSelected [0,7] rootPS)) = affineNative (2^(7+1) ^^^ 20) := by decide +kernel

theorem selectedBound16800 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16801 : List Nat := [2,4,8,16,16,17,9,20,1,4,16,0,25,17,1,19,0,17,4,0,16,17,16,3,24,16,17,0,0,16,20,16,20,17,16,0]

theorem envBound16801 : H12AffineFastState.Bounded env16801 := by
  intro p hp
  have h : env16801.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16800_16801 : H12AffineEnvironment.transform 7 20 env16800 = env16801 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 20 env16800 == env16801) = true)

def env16802 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1024,32769,396325,272513,452769,95496,8328,65,292137,458145,45524,10400,399800,144493,256,21792,46213,474735]

theorem envBound16802 : H12AffineFastState.Bounded env16802 := by
  intro p hp
  have h : env16802.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16776_16802 : H12AffineEnvironment.transform 21 272513 env16776 = env16802 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 272513 env16776 == env16802) = true)

theorem identity16802 : scanCanonicalize (H12AffineFastState.compose env16802 (packedSelected [21] rootPS)) = affineNative (2^(15+1) ^^^ 54495) := by decide +kernel

theorem selectedBound16802 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16803 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,54495,131072,262144,1024,32769,396325,272513,452769,41431,8328,65,292137,458145,45524,10400,399800,144493,256,21792,46213,453296]

theorem envBound16803 : H12AffineFastState.Bounded env16803 := by
  intro p hp
  have h : env16803.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16802_16803 : H12AffineEnvironment.transform 15 54495 env16802 = env16803 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 54495 env16802 == env16803) = true)

def env16804 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,54359,131072,262144,1024,32769,396325,272393,452649,41311,8192,65,292137,458025,45404,10280,399664,144493,256,21792,46093,453176]

theorem envBound16804 : H12AffineFastState.Bounded env16804 := by
  intro p hp
  have h : env16804.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16803_16804 : H12AffineEnvironment.transform 6 8 env16803 = env16804 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16803 == env16804) = true)

theorem identity16804 : scanCanonicalize (H12AffineFastState.compose env16804 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(14+1) ^^^ 21540) := by decide +kernel

theorem selectedBound16804 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16805 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,21540,115,131072,262144,1024,21541,396325,272393,408589,30075,8192,65,292137,403725,25976,10280,399664,144493,256,21792,24617,409116]

theorem envBound16805 : H12AffineFastState.Bounded env16805 := by
  intro p hp
  have h : env16805.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16804_16805 : H12AffineEnvironment.transform 14 21540 env16804 = env16805 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 21540 env16804 == env16805) = true)

theorem identity16805 : scanCanonicalize (H12AffineFastState.compose env16805 (packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16805 : packedSelected [1,3,4,9,10,18,19,20,23,24,26,28,31,35] rootPS < 2^1333 := by decide +kernel

def env16806 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21540,34,131072,262144,1024,21541,396325,272393,408589,29994,8192,16,292137,403725,25897,10280,399664,144444,256,21792,24617,409116]

theorem envBound16806 : H12AffineFastState.Bounded env16806 := by
  intro p hp
  have h : env16806.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16805_16806 : H12AffineEnvironment.transform 5 17 env16805 = env16806 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16805 == env16806) = true)

theorem identity16806 : scanCanonicalize (H12AffineFastState.compose env16806 (packedSelected [0,7,9,14,17,20,22] rootPS)) = affineNative (2^(17+1) ^^^ 146745) := by decide +kernel

theorem selectedBound16806 : packedSelected [0,7,9,14,17,20,22] rootPS < 2^1333 := by decide +kernel

def env16807 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21540,34,131072,146745,1024,21541,12572,136496,308,29994,8192,16,149520,5172,25897,10280,9225,144444,256,21792,24617,805]

theorem envBound16807 : H12AffineFastState.Bounded env16807 := by
  intro p hp
  have h : env16807.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16806_16807 : H12AffineEnvironment.transform 17 146745 env16806 = env16807 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 146745 env16806 == env16807) = true)

theorem identity16807 : scanCanonicalize (H12AffineFastState.compose env16807 (packedSelected [4,9,14,16,17] rootPS)) = affineNative (2^(16+1) ^^^ 24861) := by decide +kernel

theorem selectedBound16807 : packedSelected [4,9,14,16,17] rootPS < 2^1333 := by decide +kernel

def env16808 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,8192,16384,21540,34,24861,23588,1024,21541,12572,29741,308,29994,8192,16,10509,5172,25897,10280,9225,21793,256,21792,24617,805]

theorem envBound16808 : H12AffineFastState.Bounded env16808 := by
  intro p hp
  have h : env16808.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16807_16808 : H12AffineEnvironment.transform 16 24861 env16807 = env16808 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 24861 env16807 == env16808) = true)

theorem identity16808 : scanCanonicalize (H12AffineFastState.compose env16808 (packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16808 : packedSelected [0,2,3,5,6,7,10,11,12,15,16,18] rootPS < 2^1333 := by decide +kernel

def env16809 : List Nat := [2,4,8,16,32,17,8,256,512,1024,2048,4096,269,16384,21540,34,16400,23588,1024,21541,4113,21792,308,21543,269,16,2048,5172,17444,2341,1284,21793,256,21792,16676,805]

theorem envBound16809 : H12AffineFastState.Bounded env16809 := by
  intro p hp
  have h : env16809.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16808_16809 : H12AffineEnvironment.transform 12 269 env16808 = env16809 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16808 == env16809) = true)

theorem identity16809 : scanCanonicalize (H12AffineFastState.compose env16809 (packedSelected [0,4,6,7,9,11] rootPS)) = affineNative (2^(9+1) ^^^ 273) := by decide +kernel

theorem selectedBound16809 : packedSelected [0,4,6,7,9,11] rootPS < 2^1333 := by decide +kernel

def env16810 : List Nat := [2,4,8,16,32,17,8,256,512,273,2048,4096,269,16384,20789,34,16400,22837,273,20788,4113,20529,308,20790,269,16,2048,4389,16693,2341,21,20528,256,20529,16676,805]

theorem envBound16810 : H12AffineFastState.Bounded env16810 := by
  intro p hp
  have h : env16810.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16809_16810 : H12AffineEnvironment.transform 9 273 env16809 = env16810 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 273 env16809 == env16810) = true)

def env16811 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,262144,1024,32769,396325,272392,452648,41310,8193,65,292137,458024,45405,10281,399665,144493,256,21792,46092,453177]

theorem envBound16811 : H12AffineFastState.Bounded env16811 := by
  intro p hp
  have h : env16811.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16803_16811 : H12AffineEnvironment.transform 6 9 env16803 = env16811 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16803 == env16811) = true)

theorem identity16811 : scanCanonicalize (H12AffineFastState.compose env16811 (packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS)) = affineNative (2^(17+1) ^^^ 171060) := by decide +kernel

theorem selectedBound16811 : packedSelected [0,1,3,4,8,11,14,16,17,19,22,24,26,27,31,32,38,41] rootPS < 2^1333 := by decide +kernel

def env16812 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,131072,171060,1024,32769,36881,177212,29724,41310,8193,65,190749,24860,45405,10281,34053,144493,256,21792,46092,30221]

theorem envBound16812 : H12AffineFastState.Bounded env16812 := by
  intro p hp
  have h : env16812.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16811_16812 : H12AffineEnvironment.transform 17 171060 env16811 = env16812 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 171060 env16811 == env16812) = true)

theorem identity16812 : scanCanonicalize (H12AffineFastState.compose env16812 (packedSelected [0,9,16,18,20,22,23,27] rootPS)) = affineNative (2^(16+1) ^^^ 49168) := by decide +kernel

theorem selectedBound16812 : packedSelected [0,9,16,18,20,22,23,27] rootPS < 2^1333 := by decide +kernel

def env16813 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,16384,32768,54358,49168,23588,1024,32769,36881,29740,29724,41310,8193,65,10509,24860,45405,10281,34053,62589,256,21792,46092,30221]

theorem envBound16813 : H12AffineFastState.Bounded env16813 := by
  intro p hp
  have h : env16813.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16812_16813 : H12AffineEnvironment.transform 16 49168 env16812 = env16813 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 49168 env16812 == env16813) = true)

theorem identity16813 : scanCanonicalize (H12AffineFastState.compose env16813 (packedSelected [17] rootPS)) = affineNative (2^(13+1) ^^^ 13324) := by decide +kernel

theorem selectedBound16813 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16814 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,32768,41050,46108,10280,1024,32769,36881,32,16,41310,8193,65,10509,5392,45405,10281,34053,32881,256,8492,46092,513]

theorem envBound16814 : H12AffineFastState.Bounded env16814 := by
  intro p hp
  have h : env16814.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16813_16814 : H12AffineEnvironment.transform 13 13324 env16813 = env16814 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13324 env16813 == env16814) = true)

theorem identity16814 : scanCanonicalize (H12AffineFastState.compose env16814 (packedSelected [2,3,5,6,10] rootPS)) = affineNative (2^(14+1) ^^^ 8460) := by decide +kernel

theorem selectedBound16814 : packedSelected [2,3,5,6,10] rootPS < 2^1333 := by decide +kernel

def env16815 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13324,8460,342,5392,10280,1024,8461,12573,32,16,82,8193,65,10509,5392,4177,10281,9225,8573,256,8492,5376,513]

theorem envBound16815 : H12AffineFastState.Bounded env16815 := by
  intro p hp
  have h : env16815.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16814_16815 : H12AffineEnvironment.transform 14 8460 env16814 = env16815 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8460 env16814 == env16815) = true)

theorem identity16815 : scanCanonicalize (H12AffineFastState.compose env16815 (packedSelected [2,6] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16815 : packedSelected [2,6] rootPS < 2^1333 := by decide +kernel

def env16816 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,269,5377,1,342,5392,2341,1024,0,4112,32,16,82,268,65,2048,5392,4177,2340,1284,112,256,33,5376,513]

theorem envBound16816 : H12AffineFastState.Bounded env16816 := by
  intro p hp
  have h : env16816.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16815_16816 : H12AffineEnvironment.transform 12 269 env16815 = env16816 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16815 == env16816) = true)

theorem identity16816 : scanCanonicalize (H12AffineFastState.compose env16816 (packedSelected [4,9,11] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16816 : packedSelected [4,9,11] rootPS < 2^1333 := by decide +kernel

def env16817 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,4096,269,5377,1,263,5392,2341,1024,0,4112,32,16,3,268,16,2048,5392,4096,2340,1284,33,256,33,5376,513]

theorem envBound16817 : H12AffineFastState.Bounded env16817 := by
  intro p hp
  have h : env16817.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16816_16817 : H12AffineEnvironment.transform 5 17 env16816 = env16817 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16816 == env16817) = true)

theorem identity16817 : scanCanonicalize (H12AffineFastState.compose env16817 (packedSelected [2] rootPS)) = affineNative (2^(11+1) ^^^ 1328) := by decide +kernel

theorem selectedBound16817 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16818 : List Nat := [2,4,8,16,32,17,9,256,512,1024,2048,1328,269,49,1,263,32,2341,1024,0,1312,32,16,3,268,16,2048,32,1328,2340,1284,33,256,33,48,513]

theorem envBound16818 : H12AffineFastState.Bounded env16818 := by
  intro p hp
  have h : env16818.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16817_16818 : H12AffineEnvironment.transform 11 1328 env16817 = env16818 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1328 env16817 == env16818) = true)

theorem identity16818 : scanCanonicalize (H12AffineFastState.compose env16818 (packedSelected [1,3] rootPS)) = affineNative (2^(8+1) ^^^ 277) := by decide +kernel

theorem selectedBound16818 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16819 : List Nat := [2,4,8,16,32,17,9,256,277,1024,2048,1328,269,49,1,263,32,2341,1024,0,1312,32,16,3,268,16,2048,32,1328,2340,1284,33,256,33,48,276]

theorem envBound16819 : H12AffineFastState.Bounded env16819 := by
  intro p hp
  have h : env16819.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16818_16819 : H12AffineEnvironment.transform 8 277 env16818 = env16819 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 277 env16818 == env16819) = true)

theorem identity16819 : scanCanonicalize (H12AffineFastState.compose env16819 (packedSelected [0,4] rootPS)) = affineNative (2^(10+1) ^^^ 1076) := by decide +kernel

theorem selectedBound16819 : packedSelected [0,4] rootPS < 2^1333 := by decide +kernel

def env16820 : List Nat := [2,4,8,16,32,17,9,256,277,1024,1076,1328,269,49,1,263,32,1297,1024,0,1312,32,16,3,268,16,1076,32,1328,1296,1284,33,256,33,48,276]

theorem envBound16820 : H12AffineFastState.Bounded env16820 := by
  intro p hp
  have h : env16820.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16819_16820 : H12AffineEnvironment.transform 10 1076 env16819 = env16820 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 1076 env16819 == env16820) = true)

theorem identity16820 : scanCanonicalize (H12AffineFastState.compose env16820 (packedSelected [1,5] rootPS)) = affineNative (2^(9+1) ^^^ 305) := by decide +kernel

theorem selectedBound16820 : packedSelected [1,5] rootPS < 2^1333 := by decide +kernel

def env16821 : List Nat := [2,4,8,16,32,17,9,256,277,305,261,1,269,49,1,263,32,32,305,0,17,32,16,3,268,16,261,32,1,33,53,33,256,33,48,276]

theorem envBound16821 : H12AffineFastState.Bounded env16821 := by
  intro p hp
  have h : env16821.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16820_16821 : H12AffineEnvironment.transform 9 305 env16820 = env16821 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 305 env16820 == env16821) = true)

def env16822 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,16777216,8328,65,29868032,18973837,10507600,8830976,25265169,23160257,257,27378861,27337993,25207751]

theorem envBound16822 : H12AffineFastState.Bounded env16822 := by
  intro p hp
  have h : env16822.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16613_16822 : H12AffineEnvironment.transform 18 1025 env16613 = env16822 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 18 1025 env16613 == env16822) = true)

theorem identity16822 : scanCanonicalize (H12AffineFastState.compose env16822 (packedSelected [13] rootPS)) = affineNative (2^(23+1) ^^^ 10874021) := by decide +kernel

theorem selectedBound16822 : packedSelected [13] rootPS < 2^1333 := by decide +kernel

def env16823 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,262144,1025,32769,2097152,4194304,8388608,10874021,8328,65,6433957,8677416,10507600,8830976,2386100,12880228,257,272392,313772,2445154]

theorem envBound16823 : H12AffineFastState.Bounded env16823 := by
  intro p hp
  have h : env16823.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16822_16823 : H12AffineEnvironment.transform 23 10874021 env16822 = env16823 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 23 10874021 env16822 == env16823) = true)

def env16824 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,8388608,10588557,8328,65,6433957,8393984,10507600,8568104,2102684,12645452,257,21792,46212,2175562]

theorem envBound16824 : H12AffineFastState.Bounded env16824 := by
  intro p hp
  have h : env16824.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16823_16824 : H12AffineEnvironment.transform 17 32040 env16823 = env16824 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 17 32040 env16823 == env16824) = true)

def env16825 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101328,98781,8328,65,6433957,2098512,17664,2272632,2102684,6349852,257,21792,46212,2175562]

theorem envBound16825 : H12AffineFastState.Bounded env16825 := by
  intro p hp
  have h : env16825.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16824_16825 : H12AffineEnvironment.transform 22 2101328 env16824 = env16825 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101328 env16824 == env16825) = true)

def env16826 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,16,98781,8328,65,4340965,5392,17664,179512,1500,4256860,257,21792,46212,74250]

theorem envBound16826 : H12AffineFastState.Bounded env16826 := by
  intro p hp
  have h : env16826.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16825_16826 : H12AffineEnvironment.transform 20 4160 env16825 = env16826 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env16825 == env16826) = true)

theorem identity16826 : scanCanonicalize (H12AffineFastState.compose env16826 (packedSelected [21] rootPS)) = affineNative (2^(21+1) ^^^ 41341) := by decide +kernel

theorem selectedBound16826 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16827 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,41341,16,98781,8328,65,171416,5392,17664,179512,1500,21793,257,21792,46212,74250]

theorem envBound16827 : H12AffineFastState.Bounded env16827 := by
  intro p hp
  have h : env16827.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16826_16827 : H12AffineEnvironment.transform 21 41341 env16826 = env16827 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 41341 env16826 == env16827) = true)

theorem identity16827 : scanCanonicalize (H12AffineFastState.compose env16827 (packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS)) = affineNative (2^(13+1) ^^^ 13444) := by decide +kernel

theorem selectedBound16827 : packedSelected [0,1,3,5,8,9,10,11,14,15,19,22,27,32,35,38] rootPS < 2^1333 := by decide +kernel

def env16828 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,32768,65536,131072,2476,1025,32769,4160,41341,16,98781,8328,65,171416,5392,12676,179512,1500,8613,257,8612,46212,74250]

theorem envBound16828 : H12AffineFastState.Bounded env16828 := by
  intro p hp
  have h : env16828.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16827_16828 : H12AffineEnvironment.transform 13 13444 env16827 = env16828 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 13444 env16827 == env16828) = true)

theorem identity16828 : scanCanonicalize (H12AffineFastState.compose env16828 (packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS)) = affineNative (2^(15+1) ^^^ 263) := by decide +kernel

theorem selectedBound16828 : packedSelected [0,1,3,4,7,10,16,18,19,20,22,23,24,26,28,31] rootPS < 2^1333 := by decide +kernel

def env16829 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,32768,263,131072,2476,1025,32769,4160,41341,16,32986,8328,65,171416,5392,12676,179512,1500,8613,257,8612,46212,8973]

theorem envBound16829 : H12AffineFastState.Bounded env16829 := by
  intro p hp
  have h : env16829.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16828_16829 : H12AffineEnvironment.transform 15 263 env16828 = env16829 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 263 env16828 == env16829) = true)

theorem identity16829 : scanCanonicalize (H12AffineFastState.compose env16829 (packedSelected [3,10,16,17,19,20,24] rootPS)) = affineNative (2^(16+1) ^^^ 13460) := by decide +kernel

theorem selectedBound16829 : packedSelected [3,10,16,17,19,20,24] rootPS < 2^1333 := by decide +kernel

def env16830 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,13444,32768,263,13460,2476,1025,32769,4160,41341,16,32986,8328,65,43276,5392,12676,35244,1500,8613,257,8612,46212,8973]

theorem envBound16830 : H12AffineFastState.Bounded env16830 := by
  intro p hp
  have h : env16830.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16829_16830 : H12AffineEnvironment.transform 16 13460 env16829 = env16830 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 13460 env16829 == env16830) = true)

def env16831 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,13324,32768,263,13340,2340,1025,32769,4160,41341,16,32850,8192,65,43276,5392,12556,35108,1364,8493,257,8492,46092,8973]

theorem envBound16831 : H12AffineFastState.Bounded env16831 := by
  intro p hp
  have h : env16831.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16830_16831 : H12AffineEnvironment.transform 6 8 env16830 = env16831 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16830 == env16831) = true)

theorem identity16831 : scanCanonicalize (H12AffineFastState.compose env16831 (packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS)) = affineNative (2^(12+1) ^^^ 269) := by decide +kernel

theorem selectedBound16831 : packedSelected [1,2,3,4,5,6,8,9,12,18] rootPS < 2^1333 := by decide +kernel

def env16832 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,32768,263,5393,2340,1025,32769,4160,32880,16,32850,269,65,34817,5392,4097,35108,1364,32,257,33,38145,512]

theorem envBound16832 : H12AffineFastState.Bounded env16832 := by
  intro p hp
  have h : env16832.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16831_16832 : H12AffineEnvironment.transform 12 269 env16831 = env16832 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 269 env16831 == env16832) = true)

theorem identity16832 : scanCanonicalize (H12AffineFastState.compose env16832 (packedSelected [0,5,7,8] rootPS)) = affineNative (2^(14+1) ^^^ 260) := by decide +kernel

theorem selectedBound16832 : packedSelected [0,5,7,8] rootPS < 2^1333 := by decide +kernel

def env16833 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,269,5377,260,263,5393,2340,1025,261,4160,372,16,342,269,65,2309,5392,4097,2080,1364,32,257,33,5125,512]

theorem envBound16833 : H12AffineFastState.Bounded env16833 := by
  intro p hp
  have h : env16833.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16832_16833 : H12AffineEnvironment.transform 14 260 env16832 = env16833 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 260 env16832 == env16833) = true)

theorem identity16833 : scanCanonicalize (H12AffineFastState.compose env16833 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound16833 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16834 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,4096,269,4113,260,263,4097,2340,273,261,4160,372,16,342,269,65,2309,4096,4097,2080,68,32,257,33,4373,512]

theorem envBound16834 : H12AffineFastState.Bounded env16834 := by
  intro p hp
  have h : env16834.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16833_16834 : H12AffineEnvironment.transform 9 272 env16833 = env16834 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16833 == env16834) = true)

theorem identity16834 : scanCanonicalize (H12AffineFastState.compose env16834 (packedSelected [1,2,3,6] rootPS)) = affineNative (2^(11+1) ^^^ 357) := by decide +kernel

theorem selectedBound16834 : packedSelected [1,2,3,6] rootPS < 2^1333 := by decide +kernel

def env16835 : List Nat := [2,4,8,16,32,64,8,256,512,272,2048,357,269,372,260,263,356,2340,273,261,293,372,16,342,269,65,2309,357,356,2080,68,32,257,33,112,512]

theorem envBound16835 : H12AffineFastState.Bounded env16835 := by
  intro p hp
  have h : env16835.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16834_16835 : H12AffineEnvironment.transform 11 357 env16834 = env16835 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 357 env16834 == env16835) = true)

theorem identity16835 : scanCanonicalize (H12AffineFastState.compose env16835 (packedSelected [0,1,3,7,11] rootPS)) = affineNative (2^(10+1) ^^^ 341) := by decide +kernel

theorem selectedBound16835 : packedSelected [0,1,3,7,11] rootPS < 2^1333 := by decide +kernel

def env16836 : List Nat := [2,4,8,16,32,64,8,256,512,272,341,357,269,372,260,263,356,113,273,261,293,372,16,342,269,65,80,357,356,373,68,32,257,33,112,512]

theorem envBound16836 : H12AffineFastState.Bounded env16836 := by
  intro p hp
  have h : env16836.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16835_16836 : H12AffineEnvironment.transform 10 341 env16835 = env16836 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 341 env16835 == env16836) = true)

theorem identity16836 : scanCanonicalize (H12AffineFastState.compose env16836 (packedSelected [0,7,12] rootPS)) = affineNative (2^(7+1) ^^^ 116) := by decide +kernel

theorem selectedBound16836 : packedSelected [0,7,12] rootPS < 2^1333 := by decide +kernel

def env16837 : List Nat := [2,4,8,16,32,64,8,116,512,100,33,17,121,0,112,115,16,113,101,113,81,0,16,34,121,65,80,17,16,1,68,32,117,33,112,512]

theorem envBound16837 : H12AffineFastState.Bounded env16837 := by
  intro p hp
  have h : env16837.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16836_16837 : H12AffineEnvironment.transform 7 116 env16836 = env16837 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 116 env16836 == env16837) = true)

theorem identity16837 : scanCanonicalize (H12AffineFastState.compose env16837 (packedSelected [2,4] rootPS)) = affineNative (2^(5+1) ^^^ 17) := by decide +kernel

theorem selectedBound16837 : packedSelected [2,4] rootPS < 2^1333 := by decide +kernel

def env16838 : List Nat := [2,4,8,16,32,17,8,37,512,53,33,17,40,0,33,34,16,32,52,32,0,0,16,34,40,16,1,17,16,1,21,32,36,33,33,512]

theorem envBound16838 : H12AffineFastState.Bounded env16838 := by
  intro p hp
  have h : env16838.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16837_16838 : H12AffineEnvironment.transform 5 17 env16837 = env16838 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 17 env16837 == env16838) = true)

theorem identity16838 : scanCanonicalize (H12AffineFastState.compose env16838 (packedSelected [0,5] rootPS)) = affineNative (2^(1+1) ^^^ 0) := by decide +kernel

theorem selectedBound16838 : packedSelected [0,5] rootPS < 2^1333 := by decide +kernel

def env16839 : List Nat := [2,0,8,16,32,17,8,33,512,49,33,17,40,0,33,34,16,32,48,32,0,0,16,34,40,16,1,17,16,1,17,32,32,33,33,512]

theorem envBound16839 : H12AffineFastState.Bounded env16839 := by
  intro p hp
  have h : env16839.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16838_16839 : H12AffineEnvironment.transform 1 0 env16838 = env16839 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 1 0 env16838 == env16839) = true)

theorem identity16839 : scanCanonicalize (H12AffineFastState.compose env16839 (packedSelected [0,7] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16839 : packedSelected [0,7] rootPS < 2^1333 := by decide +kernel

def env16840 : List Nat := [2,0,8,16,0,17,8,1,512,17,1,17,8,0,1,2,16,0,16,0,0,0,16,2,8,16,1,17,16,1,17,0,0,1,1,512]

theorem envBound16840 : H12AffineFastState.Bounded env16840 := by
  intro p hp
  have h : env16840.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16839_16840 : H12AffineEnvironment.transform 4 0 env16839 = env16840 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16839 == env16840) = true)

theorem identity16840 : scanCanonicalize (H12AffineFastState.compose env16840 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 0) := by decide +kernel

theorem selectedBound16840 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16841 : List Nat := [2,0,8,16,0,17,8,1,0,17,1,17,8,0,1,2,16,0,16,0,0,0,16,2,8,16,1,17,16,1,17,0,0,1,1,0]

theorem envBound16841 : H12AffineFastState.Bounded env16841 := by
  intro p hp
  have h : env16841.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16840_16841 : H12AffineEnvironment.transform 8 0 env16840 = env16841 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 0 env16840 == env16841) = true)

theorem identity16841 : scanCanonicalize (H12AffineFastState.compose env16841 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16841 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16842 : List Nat := [2,0,8,0,0,1,8,1,0,1,1,1,8,0,1,2,0,0,0,0,0,0,0,2,8,0,1,1,0,1,1,0,0,1,1,0]

theorem envBound16842 : H12AffineFastState.Bounded env16842 := by
  intro p hp
  have h : env16842.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16841_16842 : H12AffineEnvironment.transform 3 0 env16841 = env16842 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16841 == env16842) = true)

def env16843 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,32768,263,13341,2341,1025,32769,4160,41341,16,32851,8193,65,43276,5392,12557,35109,1365,8492,257,8493,46093,8973]

theorem envBound16843 : H12AffineFastState.Bounded env16843 := by
  intro p hp
  have h : env16843.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16830_16843 : H12AffineEnvironment.transform 6 9 env16830 = env16843 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16830 == env16843) = true)

theorem identity16843 : scanCanonicalize (H12AffineFastState.compose env16843 (packedSelected [17] rootPS)) = affineNative (2^(14+1) ^^^ 8541) := by decide +kernel

theorem selectedBound16843 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16844 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,4096,8192,13325,8541,263,13341,2341,1025,8540,4160,32,16,8462,8193,65,2129,5392,12557,10360,1365,8492,257,8493,5456,8973]

theorem envBound16844 : H12AffineFastState.Bounded env16844 := by
  intro p hp
  have h : env16844.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16843_16844 : H12AffineEnvironment.transform 14 8541 env16843 = env16844 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 8541 env16843 == env16844) = true)

theorem identity16844 : scanCanonicalize (H12AffineFastState.compose env16844 (packedSelected [1,2,4,7,8] rootPS)) = affineNative (2^(11+1) ^^^ 625) := by decide +kernel

theorem selectedBound16844 : packedSelected [1,2,4,7,8] rootPS < 2^1333 := by decide +kernel

def env16845 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,625,8192,9852,8541,263,9836,2341,1025,8540,561,32,16,8462,8193,65,2129,1889,9084,10360,1365,8492,257,8493,1825,8973]

theorem envBound16845 : H12AffineFastState.Bounded env16845 := by
  intro p hp
  have h : env16845.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16844_16845 : H12AffineEnvironment.transform 11 625 env16844 = env16845 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 625 env16844 == env16845) = true)

theorem identity16845 : scanCanonicalize (H12AffineFastState.compose env16845 (packedSelected [2,7,9,10] rootPS)) = affineNative (2^(12+1) ^^^ 1052) := by decide +kernel

theorem selectedBound16845 : packedSelected [2,7,9,10] rootPS < 2^1333 := by decide +kernel

def env16846 : List Nat := [2,4,8,16,32,64,9,256,512,1024,2048,625,1052,608,1345,263,624,2341,1025,1344,561,32,16,1298,1053,65,2129,1889,1888,3172,1365,1328,257,1329,1825,1809]

theorem envBound16846 : H12AffineFastState.Bounded env16846 := by
  intro p hp
  have h : env16846.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16845_16846 : H12AffineEnvironment.transform 12 1052 env16845 = env16846 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 1052 env16845 == env16846) = true)

theorem identity16846 : scanCanonicalize (H12AffineFastState.compose env16846 (packedSelected [0,1,4,5,6,11,12] rootPS)) = affineNative (2^(5+1) ^^^ 48) := by decide +kernel

theorem selectedBound16846 : packedSelected [0,1,4,5,6,11,12] rootPS < 2^1333 := by decide +kernel

def env16847 : List Nat := [2,4,8,16,32,48,9,256,512,1024,2048,513,1052,528,1329,263,512,2341,1025,1328,561,32,16,1298,1053,49,2081,1809,1808,3092,1317,1328,257,1329,1825,1809]

theorem envBound16847 : H12AffineFastState.Bounded env16847 := by
  intro p hp
  have h : env16847.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16846_16847 : H12AffineEnvironment.transform 5 48 env16846 = env16847 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 48 env16846 == env16847) = true)

theorem identity16847 : scanCanonicalize (H12AffineFastState.compose env16847 (packedSelected [1,2,3] rootPS)) = affineNative (2^(4+1) ^^^ 1) := by decide +kernel

theorem selectedBound16847 : packedSelected [1,2,3] rootPS < 2^1333 := by decide +kernel

def env16848 : List Nat := [2,4,8,16,1,17,9,256,512,1024,2048,513,1052,528,1296,263,512,2308,1025,1297,528,1,16,1298,1053,16,2048,1809,1808,3092,1284,1297,257,1296,1792,1809]

theorem envBound16848 : H12AffineFastState.Bounded env16848 := by
  intro p hp
  have h : env16848.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16847_16848 : H12AffineEnvironment.transform 4 1 env16847 = env16848 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 1 env16847 == env16848) = true)

theorem identity16848 : scanCanonicalize (H12AffineFastState.compose env16848 (packedSelected [0,1,2,4,5,11] rootPS)) = affineNative (2^(10+1) ^^^ 788) := by decide +kernel

theorem selectedBound16848 : packedSelected [0,1,2,4,5,11] rootPS < 2^1333 := by decide +kernel

def env16849 : List Nat := [2,4,8,16,1,17,9,256,512,1024,788,513,1052,528,1296,263,512,528,1025,1297,528,1,16,1298,1053,16,788,1809,1808,1792,1284,1297,257,1296,1792,1809]

theorem envBound16849 : H12AffineFastState.Bounded env16849 := by
  intro p hp
  have h : env16849.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16848_16849 : H12AffineEnvironment.transform 10 788 env16848 = env16849 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 788 env16848 == env16849) = true)

theorem identity16849 : scanCanonicalize (H12AffineFastState.compose env16849 (packedSelected [2,14] rootPS)) = affineNative (2^(7+1) ^^^ 5) := by decide +kernel

theorem selectedBound16849 : packedSelected [2,14] rootPS < 2^1333 := by decide +kernel

def env16850 : List Nat := [2,4,8,16,1,17,9,5,512,1024,529,513,1052,528,1045,2,512,528,1025,1044,528,1,16,1047,1053,16,529,1556,1557,1541,1025,1044,4,1045,1541,1556]

theorem envBound16850 : H12AffineFastState.Bounded env16850 := by
  intro p hp
  have h : env16850.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16849_16850 : H12AffineEnvironment.transform 7 5 env16849 = env16850 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 5 env16849 == env16850) = true)

theorem identity16850 : scanCanonicalize (H12AffineFastState.compose env16850 (packedSelected [0,2] rootPS)) = affineNative (2^(3+1) ^^^ 0) := by decide +kernel

theorem selectedBound16850 : packedSelected [0,2] rootPS < 2^1333 := by decide +kernel

def env16851 : List Nat := [2,4,8,0,1,1,9,5,512,1024,513,513,1036,512,1029,2,512,512,1025,1028,512,1,0,1031,1037,0,513,1540,1541,1541,1025,1028,4,1029,1541,1540]

theorem envBound16851 : H12AffineFastState.Bounded env16851 := by
  intro p hp
  have h : env16851.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16850_16851 : H12AffineEnvironment.transform 3 0 env16850 = env16851 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 0 env16850 == env16851) = true)

theorem identity16851 : scanCanonicalize (H12AffineFastState.compose env16851 (packedSelected [0] rootPS)) = affineNative (2^(9+1) ^^^ 517) := by decide +kernel

theorem selectedBound16851 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16852 : List Nat := [2,4,8,0,1,1,9,5,512,517,513,513,521,512,512,2,512,512,516,513,512,1,0,514,520,0,513,1,0,0,516,513,4,512,0,1]

theorem envBound16852 : H12AffineFastState.Bounded env16852 := by
  intro p hp
  have h : env16852.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16851_16852 : H12AffineEnvironment.transform 9 517 env16851 = env16852 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 517 env16851 == env16852) = true)

def env16853 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4161,4194304,17,98781,8328,65,4340964,5393,17664,179513,1501,4256861,257,21792,46212,74251]

theorem envBound16853 : H12AffineFastState.Bounded env16853 := by
  intro p hp
  have h : env16853.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16825_16853 : H12AffineEnvironment.transform 20 4161 env16825 = env16853 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4161 env16825 == env16853) = true)

theorem identity16853 : scanCanonicalize (H12AffineFastState.compose env16853 (packedSelected [21] rootPS)) = affineNative (2^(14+1) ^^^ 29909) := by decide +kernel

theorem selectedBound16853 : packedSelected [21] rootPS < 2^1333 := by decide +kernel

def env16854 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,29909,65536,131072,32040,1025,29908,4161,4194304,17,95496,8328,65,4340964,5393,17664,149996,1501,4194440,257,21792,16465,74251]

theorem envBound16854 : H12AffineFastState.Bounded env16854 := by
  intro p hp
  have h : env16854.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16853_16854 : H12AffineEnvironment.transform 14 29909 env16853 = env16854 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29909 env16853 == env16854) = true)

def env16855 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,65536,131072,10280,1025,8660,4161,4194304,17,73736,8328,65,4340964,5393,4096,138476,1501,4194440,257,32,5457,74251]

theorem envBound16855 : H12AffineFastState.Bounded env16855 := by
  intro p hp
  have h : env16855.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16854_16855 : H12AffineEnvironment.transform 13 5376 env16854 = env16855 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5376 env16854 == env16855) = true)

theorem identity16855 : scanCanonicalize (H12AffineFastState.compose env16855 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8322) := by decide +kernel

theorem selectedBound16855 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16856 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5376,8661,8322,131072,10280,1025,8660,4161,4194304,17,138,8328,65,4340964,5393,4096,138476,1501,4194440,257,32,5457,649]

theorem envBound16856 : H12AffineFastState.Bounded env16856 := by
  intro p hp
  have h : env16856.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16855_16856 : H12AffineEnvironment.transform 15 8322 env16855 = env16856 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8322 env16855 == env16856) = true)

theorem identity16856 : scanCanonicalize (H12AffineFastState.compose env16856 (packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS)) = affineNative (2^(12+1) ^^^ 349) := by decide +kernel

theorem selectedBound16856 : packedSelected [0,1,3,4,5,7,8,10,11,18,19,22] rootPS < 2^1333 := by decide +kernel

def env16857 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,479,131072,2421,1025,137,4161,4194304,17,138,469,65,4332985,5393,4096,138476,1501,4194440,257,32,5457,649]

theorem envBound16857 : H12AffineFastState.Bounded env16857 := by
  intro p hp
  have h : env16857.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16856_16857 : H12AffineEnvironment.transform 12 349 env16856 = env16857 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 349 env16856 == env16857) = true)

theorem identity16857 : scanCanonicalize (H12AffineFastState.compose env16857 (packedSelected [0,3,4,5,7,9,10,16,18] rootPS)) = affineNative (2^(21+1) ^^^ 136632) := by decide +kernel

theorem selectedBound16857 : packedSelected [0,3,4,5,7,9,10,16,18] rootPS < 2^1333 := by decide +kernel

def env16858 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,479,131072,2421,1025,137,4161,136632,17,138,469,65,2049,5393,4096,138476,1501,136496,257,32,5457,649]

theorem envBound16858 : H12AffineFastState.Bounded env16858 := by
  intro p hp
  have h : env16858.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16857_16858 : H12AffineEnvironment.transform 21 136632 env16857 = env16858 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 136632 env16857 == env16858) = true)

theorem identity16858 : scanCanonicalize (H12AffineFastState.compose env16858 (packedSelected [1,8,10,15] rootPS)) = affineNative (2^(16+1) ^^^ 5393) := by decide +kernel

theorem selectedBound16858 : packedSelected [1,8,10,15] rootPS < 2^1333 := by decide +kernel

def env16859 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,349,5376,136,479,5393,2421,1025,137,4161,169,17,138,469,65,2049,5393,4096,2557,1501,33,257,32,5457,649]

theorem envBound16859 : H12AffineFastState.Bounded env16859 := by
  intro p hp
  have h : env16859.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16858_16859 : H12AffineEnvironment.transform 16 5393 env16858 = env16859 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5393 env16858 == env16859) = true)

theorem identity16859 : scanCanonicalize (H12AffineFastState.compose env16859 (packedSelected [0,2,4,7,9] rootPS)) = affineNative (2^(6+1) ^^^ 40) := by decide +kernel

theorem selectedBound16859 : packedSelected [0,2,4,7,9] rootPS < 2^1333 := by decide +kernel

def env16860 : List Nat := [2,4,8,16,32,64,40,256,512,1024,2048,4096,349,5376,32,375,5393,2421,1025,33,4161,1,17,34,381,65,2049,5393,4096,2389,1397,33,257,32,5457,545]

theorem envBound16860 : H12AffineFastState.Bounded env16860 := by
  intro p hp
  have h : env16860.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16859_16860 : H12AffineEnvironment.transform 6 40 env16859 = env16860 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 40 env16859 == env16860) = true)

theorem identity16860 : scanCanonicalize (H12AffineFastState.compose env16860 (packedSelected [0,2,7,11] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16860 : packedSelected [0,2,7,11] rootPS < 2^1333 := by decide +kernel

def env16861 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,4096,349,5376,0,343,5393,2389,1025,1,4161,1,17,2,349,65,2049,5393,4096,2389,1365,1,257,0,5457,513]

theorem envBound16861 : H12AffineFastState.Bounded env16861 := by
  intro p hp
  have h : env16861.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16860_16861 : H12AffineEnvironment.transform 4 0 env16860 = env16861 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16860 == env16861) = true)

theorem identity16861 : scanCanonicalize (H12AffineFastState.compose env16861 (packedSelected [1,3] rootPS)) = affineNative (2^(11+1) ^^^ 1872) := by decide +kernel

theorem selectedBound16861 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16862 : List Nat := [2,4,8,16,0,64,8,256,512,1024,2048,1872,349,592,0,343,577,2389,1025,1,1809,1,17,2,349,65,2049,577,1872,2389,1365,1,257,0,513,513]

theorem envBound16862 : H12AffineFastState.Bounded env16862 := by
  intro p hp
  have h : env16862.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16861_16862 : H12AffineEnvironment.transform 11 1872 env16861 = env16862 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 1872 env16861 == env16862) = true)

def env16863 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,65536,131072,10281,1025,8661,4161,4194304,17,73737,8328,65,4340964,5393,4097,138477,1501,4194440,257,33,5456,74251]

theorem envBound16863 : H12AffineFastState.Bounded env16863 := by
  intro p hp
  have h : env16863.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16854_16863 : H12AffineEnvironment.transform 13 5377 env16854 = env16863 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 13 5377 env16854 == env16863) = true)

theorem identity16863 : scanCanonicalize (H12AffineFastState.compose env16863 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8202) := by decide +kernel

theorem selectedBound16863 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16864 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,131072,10281,1025,8661,4161,4194304,17,3,8328,65,4340964,5393,4097,138477,1501,4194440,257,33,5456,513]

theorem envBound16864 : H12AffineFastState.Bounded env16864 := by
  intro p hp
  have h : env16864.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16863_16864 : H12AffineEnvironment.transform 15 8202 env16863 = env16864 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8202 env16863 == env16864) = true)

theorem identity16864 : scanCanonicalize (H12AffineFastState.compose env16864 (packedSelected [0,4,7,9,11,14,18] rootPS)) = affineNative (2^(21+1) ^^^ 8321) := by decide +kernel

theorem selectedBound16864 : packedSelected [0,4,7,9,11,14,18] rootPS < 2^1333 := by decide +kernel

def env16865 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,131072,10281,1025,8661,4161,8321,17,3,8328,65,138341,5393,4097,138477,1501,8201,257,33,5456,513]

theorem envBound16865 : H12AffineFastState.Bounded env16865 := by
  intro p hp
  have h : env16865.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16864_16865 : H12AffineEnvironment.transform 21 8321 env16864 = env16865 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 8321 env16864 == env16865) = true)

theorem identity16865 : scanCanonicalize (H12AffineFastState.compose env16865 (packedSelected [1,3,5,8,10,19] rootPS)) = affineNative (2^(16+1) ^^^ 5392) := by decide +kernel

theorem selectedBound16865 : packedSelected [1,3,5,8,10,19] rootPS < 2^1333 := by decide +kernel

def env16866 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,5377,8660,8202,5392,10281,1025,8661,4161,8321,17,3,8328,65,2421,5393,4097,2557,1501,8201,257,33,5456,513]

theorem envBound16866 : H12AffineFastState.Bounded env16866 := by
  intro p hp
  have h : env16866.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16865_16866 : H12AffineEnvironment.transform 16 5392 env16865 = env16866 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 5392 env16865 == env16866) = true)

theorem identity16866 : scanCanonicalize (H12AffineFastState.compose env16866 (packedSelected [3,5,10] rootPS)) = affineNative (2^(9+1) ^^^ 272) := by decide +kernel

theorem selectedBound16866 : packedSelected [3,5,10] rootPS < 2^1333 := by decide +kernel

def env16867 : List Nat := [2,4,8,16,32,64,128,256,512,272,2048,4096,8192,4113,8660,8202,4096,10281,273,8661,4161,8321,17,3,8328,65,2421,4097,4097,2557,205,8201,257,33,4160,513]

theorem envBound16867 : H12AffineFastState.Bounded env16867 := by
  intro p hp
  have h : env16867.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16866_16867 : H12AffineEnvironment.transform 9 272 env16866 = env16867 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 9 272 env16866 == env16867) = true)

theorem identity16867 : scanCanonicalize (H12AffineFastState.compose env16867 (packedSelected [14] rootPS)) = affineNative (2^(7+1) ^^^ 236) := by decide +kernel

theorem selectedBound16867 : packedSelected [14] rootPS < 2^1333 := by decide +kernel

def env16868 : List Nat := [2,4,8,16,32,64,128,236,512,252,2048,4096,8192,4113,8248,8202,4096,10281,253,8249,4161,8321,17,3,8328,65,2201,4097,4097,2065,205,8201,237,33,4160,513]

theorem envBound16868 : H12AffineFastState.Bounded env16868 := by
  intro p hp
  have h : env16868.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16867_16868 : H12AffineEnvironment.transform 7 236 env16867 = env16868 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 7 236 env16867 == env16868) = true)

theorem identity16868 : scanCanonicalize (H12AffineFastState.compose env16868 (packedSelected [0,27] rootPS)) = affineNative (2^(12+1) ^^^ 160) := by decide +kernel

theorem selectedBound16868 : packedSelected [0,27] rootPS < 2^1333 := by decide +kernel

def env16869 : List Nat := [2,4,8,16,32,64,128,236,512,252,2048,4096,160,4113,152,170,4096,2185,253,153,4161,33,17,3,40,65,2201,4097,4097,2065,205,169,237,33,4160,513]

theorem envBound16869 : H12AffineFastState.Bounded env16869 := by
  intro p hp
  have h : env16869.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16868_16869 : H12AffineEnvironment.transform 12 160 env16868 = env16869 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 12 160 env16868 == env16869) = true)

theorem identity16869 : scanCanonicalize (H12AffineFastState.compose env16869 (packedSelected [0,2,6,7] rootPS)) = affineNative (2^(11+1) ^^^ 2201) := by decide +kernel

theorem selectedBound16869 : packedSelected [0,2,6,7] rootPS < 2^1333 := by decide +kernel

def env16870 : List Nat := [2,4,8,16,32,64,128,236,512,252,2048,2201,160,2184,152,170,2201,2185,253,153,2264,33,17,3,40,65,2201,2200,2200,2065,205,169,237,33,2265,513]

theorem envBound16870 : H12AffineFastState.Bounded env16870 := by
  intro p hp
  have h : env16870.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16869_16870 : H12AffineEnvironment.transform 11 2201 env16869 = env16870 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 11 2201 env16869 == env16870) = true)

theorem identity16870 : scanCanonicalize (H12AffineFastState.compose env16870 (packedSelected [2,4,6,9] rootPS)) = affineNative (2^(6+1) ^^^ 9) := by decide +kernel

theorem selectedBound16870 : packedSelected [2,4,6,9] rootPS < 2^1333 := by decide +kernel

def env16871 : List Nat := [2,4,8,16,32,64,9,101,512,117,2048,2064,41,2049,17,35,2064,2048,116,16,2129,33,17,3,40,65,2064,2065,2065,2065,68,32,100,33,2128,513]

theorem envBound16871 : H12AffineFastState.Bounded env16871 := by
  intro p hp
  have h : env16871.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16870_16871 : H12AffineEnvironment.transform 6 9 env16870 = env16871 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 9 env16870 == env16871) = true)

theorem identity16871 : scanCanonicalize (H12AffineFastState.compose env16871 (packedSelected [2] rootPS)) = affineNative (2^(4+1) ^^^ 0) := by decide +kernel

theorem selectedBound16871 : packedSelected [2] rootPS < 2^1333 := by decide +kernel

def env16872 : List Nat := [2,4,8,16,0,64,9,69,512,85,2048,2064,9,2049,17,3,2064,2048,84,16,2129,1,17,3,8,65,2064,2065,2065,2065,68,0,68,1,2128,513]

theorem envBound16872 : H12AffineFastState.Bounded env16872 := by
  intro p hp
  have h : env16872.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16871_16872 : H12AffineEnvironment.transform 4 0 env16871 = env16872 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 4 0 env16871 == env16872) = true)

theorem identity16872 : scanCanonicalize (H12AffineFastState.compose env16872 (packedSelected [0,1,4] rootPS)) = affineNative (2^(5+1) ^^^ 16) := by decide +kernel

theorem selectedBound16872 : packedSelected [0,1,4] rootPS < 2^1333 := by decide +kernel

def env16873 : List Nat := [2,4,8,16,0,16,9,21,512,5,2048,2064,9,2049,17,3,2064,2048,4,16,2049,1,17,3,8,17,2064,2065,2065,2065,20,0,20,1,2048,513]

theorem envBound16873 : H12AffineFastState.Bounded env16873 := by
  intro p hp
  have h : env16873.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16872_16873 : H12AffineEnvironment.transform 5 16 env16872 = env16873 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 5 16 env16872 == env16873) = true)

theorem identity16873 : scanCanonicalize (H12AffineFastState.compose env16873 (packedSelected [1,3] rootPS)) = affineNative (2^(10+1) ^^^ 513) := by decide +kernel

theorem selectedBound16873 : packedSelected [1,3] rootPS < 2^1333 := by decide +kernel

def env16874 : List Nat := [2,4,8,16,0,16,9,21,512,5,513,529,9,512,17,3,529,513,4,16,512,1,17,3,8,17,529,528,528,528,20,0,20,1,513,513]

theorem envBound16874 : H12AffineFastState.Bounded env16874 := by
  intro p hp
  have h : env16874.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16873_16874 : H12AffineEnvironment.transform 10 513 env16873 = env16874 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 10 513 env16873 == env16874) = true)

theorem identity16874 : scanCanonicalize (H12AffineFastState.compose env16874 (packedSelected [0] rootPS)) = affineNative (2^(8+1) ^^^ 1) := by decide +kernel

theorem selectedBound16874 : packedSelected [0] rootPS < 2^1333 := by decide +kernel

def env16875 : List Nat := [2,4,8,16,0,16,9,21,1,5,0,16,9,1,17,3,16,0,4,16,1,1,17,3,8,17,16,17,17,17,20,0,20,1,0,0]

theorem envBound16875 : H12AffineFastState.Bounded env16875 := by
  intro p hp
  have h : env16875.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16874_16875 : H12AffineEnvironment.transform 8 1 env16874 = env16875 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 8 1 env16874 == env16875) = true)

theorem identity16875 : scanCanonicalize (H12AffineFastState.compose env16875 (packedSelected [1] rootPS)) = affineNative (2^(3+1) ^^^ 1) := by decide +kernel

theorem selectedBound16875 : packedSelected [1] rootPS < 2^1333 := by decide +kernel

def env16876 : List Nat := [2,4,8,1,0,1,9,4,1,5,0,1,9,1,0,3,1,0,4,1,1,1,0,3,8,0,1,0,0,0,5,0,5,1,0,0]

theorem envBound16876 : H12AffineFastState.Bounded env16876 := by
  intro p hp
  have h : env16876.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16875_16876 : H12AffineEnvironment.transform 3 1 env16875 = env16876 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 3 1 env16875 == env16876) = true)

def env16877 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,2097152,4194304,2101329,98780,8328,65,6433957,2098513,17665,2272633,2102684,6349853,257,21792,46212,2175562]

theorem envBound16877 : H12AffineFastState.Bounded env16877 := by
  intro p hp
  have h : env16877.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16824_16877 : H12AffineEnvironment.transform 22 2101329 env16824 = env16877 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 22 2101329 env16824 == env16877) = true)

def env16878 : List Nat := [2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98780,8328,65,4340965,5393,17665,179513,1500,4256861,257,21792,46212,74250]

theorem envBound16878 : H12AffineFastState.Bounded env16878 := by
  intro p hp
  have h : env16878.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16877_16878 : H12AffineEnvironment.transform 20 4160 env16877 = env16878 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 20 4160 env16877 == env16878) = true)

def env16879 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,65536,131072,32040,1025,32769,4160,4194304,17,98644,8192,65,4340845,5393,17665,179513,1364,4256861,257,21792,46092,74250]

theorem envBound16879 : H12AffineFastState.Bounded env16879 := by
  intro p hp
  have h : env16879.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16878_16879 : H12AffineEnvironment.transform 6 8 env16878 = env16879 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 6 8 env16878 == env16879) = true)

theorem identity16879 : scanCanonicalize (H12AffineFastState.compose env16879 (packedSelected [17] rootPS)) = affineNative (2^(15+1) ^^^ 8203) := by decide +kernel

theorem selectedBound16879 : packedSelected [17] rootPS < 2^1333 := by decide +kernel

def env16880 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,32768,8203,131072,32040,1025,32769,4160,4194304,17,41311,8192,65,4340845,5393,17665,179513,1364,4256861,257,21792,46092,513]

theorem envBound16880 : H12AffineFastState.Bounded env16880 := by
  intro p hp
  have h : env16880.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16879_16880 : H12AffineEnvironment.transform 15 8203 env16879 = env16880 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 15 8203 env16879 == env16880) = true)

theorem identity16880 : scanCanonicalize (H12AffineFastState.compose env16880 (packedSelected [0,1,3,5,7,8,10,19,20] rootPS)) = affineNative (2^(14+1) ^^^ 29789) := by decide +kernel

theorem selectedBound16880 : packedSelected [0,1,3,5,7,8,10,19,20] rootPS < 2^1333 := by decide +kernel

def env16881 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,4194304,17,21762,8192,65,4340845,5393,17665,149860,1364,4194304,257,21792,16465,513]

theorem envBound16881 : H12AffineFastState.Bounded env16881 := by
  intro p hp
  have h : env16881.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16880_16881 : H12AffineEnvironment.transform 14 29789 env16880 = env16881 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 14 29789 env16880 == env16881) = true)

theorem identity16881 : scanCanonicalize (H12AffineFastState.compose env16881 (packedSelected [0,1,3,5,8,10,14,19,27] rootPS)) = affineNative (2^(21+1) ^^^ 21872) := by decide +kernel

theorem selectedBound16881 : packedSelected [0,1,3,5,8,10,14,19,27] rootPS < 2^1333 := by decide +kernel

def env16882 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,131072,32040,1025,29788,4160,21872,17,21762,8192,65,157981,5393,17665,149860,1364,21872,257,21792,16465,513]

theorem envBound16882 : H12AffineFastState.Bounded env16882 := by
  intro p hp
  have h : env16882.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16881_16882 : H12AffineEnvironment.transform 21 21872 env16881 = env16882 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 21 21872 env16881 == env16882) = true)

theorem identity16882 : scanCanonicalize (H12AffineFastState.compose env16882 (packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS)) = affineNative (2^(16+1) ^^^ 16401) := by decide +kernel

theorem selectedBound16882 : packedSelected [0,2,4,5,6,7,8,9,10,14,18,19,23,24,28] rootPS < 2^1333 := by decide +kernel

def env16883 : List Nat := [2,4,8,16,32,64,8,256,512,1024,2048,4096,8192,16384,29789,8203,16401,32040,1025,29788,4160,21872,17,21762,8192,65,10508,5393,17665,2421,1364,21872,257,21792,16465,513]

theorem envBound16883 : H12AffineFastState.Bounded env16883 := by
  intro p hp
  have h : env16883.all (fun p => decide (p < 2^37)) = true := by decide +kernel
  exact of_decide_eq_true (List.all_eq_true.mp h p hp)

theorem envTrans16882_16883 : H12AffineEnvironment.transform 16 16401 env16882 = env16883 := by
  exact beq_iff_eq.mp (by decide +kernel : (H12AffineEnvironment.transform 16 16401 env16882 == env16883) = true)

end H12CloudChart1